# Duinvaart Cold Chain: Operations Analyst

**Yes, worth applying to, on one condition: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: D1 (Hybrid, three days a week in Rotterdam office)
- `must_have`: direct: D2, D3, D4
- `important`: direct: D5, D7, D8 · adjacent: D6 (temperature compliance)
- `preferred`: adjacent: D9 (Dutch a plus)

D6 is a bridge from on-time tracking, with its limit named. D9 is conversational Dutch, not fluent.

**Opportunity ledger.** The scope is concrete and names its counterparts (DR3, positive). The posting gives no salary (DR2), and the employer is unchecked (DR1).

- **Hard gates:** unconfirmed: D1 (Hybrid, three days a week in Rotterdam office); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** conditions for `go`: (1) you can work three days a week in Rotterdam (D1); (2) the posting is live on Duinvaart's own careers site (DR1); (3) D6 is presented as an adjacent bridge, never as temperature experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | `[grounded]` posting |
| Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; route changes with depot managers | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | Bounded operational analyst role with named counterparts | `[inferred]` from the responsibility list |
| Market calibration | Not run: the salary and scope searches were refused | — |
| Unknowns | Salary; team size; whether the analyst proposes route changes or depot managers decide them | — |
| Contradictions | None visible in the posting; not checked against a careers page | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | Your location and schedule limits were not given, so the check cannot run | `[grounded]` posting | Answer the location question below |
| D2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; self-reported, not yet probed | `[grounded]` your background | none |
| D3 | Strong SQL | must_have | direct | medium | none | Daily SQL use; "strong" is your own word, unprobed | `[grounded]` your background | none |
| D4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI, including the on-time delivery dashboard depot managers use | `[grounded]` your background | none |
| D5 | Track on-time delivery across the refrigerated fleet | important | direct | medium | none | On-time tracking is your work; the refrigerated fleet is a limit, since you have not run one | `[grounded]` your background; `[inferred]` that the method carries over | none |
| D6 | Track temperature compliance across the refrigerated fleet | important | adjacent | low | transferability | Monitoring against a standard transfers; no temperature data appears in your background | `[inferred]` from your monitoring work | Question D6 below |
| D7 | Weekly dashboards in Power BI | important | direct | medium | none | Weekly route-performance review and the depot dashboard | `[grounded]` your background | none |
| D8 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review; whether you proposed route changes is not stated | `[grounded]` your background | Confirm whether you proposed changes or only reviewed them |
| D9 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational, not fluent; the limit is named | `[grounded]` your background | State the level plainly |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G-D6 | Temperature compliance (D6) | transferability | No temperature data in your material | The cold-chain half of the remit; the bridge is the only route to it | Any threshold-based check at work: failed-delivery or damage rates, handling standards, service breaches you investigated | A sanitized compliance report or dashboard screenshot | `[inferred]` bridge from your on-time work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DR1 | Employer and posting not checked | unknown | — | "Duinvaart Cold Chain, Rotterdam" | The posting may be stale or not come from the named employer; no check has run | `[inferred]` from the absence of any check; not a claim about the employer | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| DR2 | Salary withheld | unknown | — | (no salary in the posting) | Pay may sit below what your experience commands, or may simply be unpublished; no band was searched | `[inferred]` from the posting's silence | What salary is budgeted for this role? | unresolved |
| DR3 | Concrete, bounded scope | positive_signal | — | "Track on-time delivery and temperature compliance… build weekly dashboards in Power BI" | Responsibilities are specific and the counterparts are named | `[grounded]` posting | What share of the week goes to dashboards, and what share to route decisions? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | CV line: "Worked daily in SQL and Power BI, including the on-time delivery dashboard depot managers use; ran the weekly route-performance review." | Presents D2–D4 and D7 in your own sentences; "built" and "owned" are not added | `[grounded]` your background | `resume_edits_pending_approval` |
| P2 | Interview bridge for D6: "I haven't worked with temperature data. I do track depot on-time performance in a dashboard depot managers use, and I'd apply the same method to temperature compliance." | Carries the limit with the bridge | `[grounded]` your background; `[inferred]` that the method transfers | pending your approval |
| P3 | State your Dutch plainly: "My Dutch is conversational." | D9 | `[grounded]` your words | pending your approval |
| P4 | Before applying: confirm the posting on Duinvaart's careers site and ask for the salary range | DR1, DR2 | `[inferred]` | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for Duinvaart and Kroonhaven were refused, so neither employer's site or posting was checked. Would have moved DR1 and KR1 |
| 2. Role-family sweep | unavailable | Salary and scope searches for both titles were refused. Would have set the market calibration and DR2 and KR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

---

# Kroonhaven Foods: Supply Planner

**No, not worth your application time now: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: K1 (On-site in Utrecht)
- `must_have`: adjacent: K5 (fluent Dutch) · unclear: K3 (advanced Excel) · absent: K2 (3+ years of planning in FMCG), K4 (SAP IBP or similar planning system)
- `important`: adjacent: K6 (13-week supply plan, S&OP meeting)

K2 and K4 are both must-haves and both absent, with no closure you can reach before this posting. K5 is conversational Dutch against a fluency requirement. K6 carries over only in its weekly-review form.

**Opportunity ledger.** The scope and cadence are explicit (KR3, positive). The salary is withheld (KR2), and the employer is unchecked (KR1).

- **Hard gates:** unconfirmed: K1 (On-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** for `no_go`, you would need planning experience in FMCG (K2) and use of a planning system such as IBP (K4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready-meals range | `[grounded]` posting |
| Mandate | Own the 13-week supply plan; balance capacity against forecast; run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | Ownership of a planning cycle, not a supporting analyst role | `[inferred]` from "own" and "run" |
| Market calibration | Not run: the searches were refused | — |
| Unknowns | Salary; who sets the capacity figures; who signs off the plan | — |
| Contradictions | None visible in the posting; not checked against a careers page | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | On-site in Utrecht (candidate constraint not given) | hard_gate | unclear | none | hard_gate | Location not given; check unknown | `[grounded]` posting | Answer the location question below |
| K2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You have never worked in planning, by your own statement. Route-performance review is performance analysis, not capacity-against-forecast planning, and not FMCG | `[grounded]` your statement | Closure path in the plan |
| K3 | Advanced Excel | must_have | unclear | none | discovery | Excel does not appear in your background, and "advanced" is unknown | `[grounded]` absence in your background | Only if you pursue this role: a workbook sample or a one-line description of your level |
| K4 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning system in your background | `[grounded]` absence in your background | Closure path in the plan |
| K5 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent; the posting requires fluency | `[grounded]` your statement | State the level plainly; a formal test score would strengthen it |
| K6 | 13-week supply plan, capacity against forecast, weekly S&OP | important | adjacent | low | transferability | The weekly cross-functional review you ran is the nearest form; no forecast, capacity or planning-cycle work | `[inferred]` from your review work | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G-K2 | 3+ years planning in FMCG (K2) | capability | No planning history | A must-have with no direct or adjacent evidence | Any forecast or volume input you prepared for a review; any stock or allocation tracking | Closure path: a demand- or planning-analyst role first | `[grounded]` your statement; `[generic]` that planning roles usually expect prior planning work |
| G-K4 | SAP IBP or similar (K4) | capability | No planning system | A must-have | Any ERP or planning tool used for forecasting or allocation | Closure path: a vendor course or a tool sandbox | `[generic]` |
| G-K5 | Fluent Dutch (K5) | transferability | Conversational | A must-have at a fluency level | Dutch work or study | A formal Dutch test score | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| KR1 | Employer and posting not checked | unknown | — | "Kroonhaven Foods, Utrecht" | The posting may be stale or not come from the named employer; no check has run | `[inferred]` from the absence of any check | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| KR2 | Salary withheld | unknown | — | (no salary in the posting) | Pay may be set against a planning-owner band; no band was searched | `[inferred]` from the posting's silence | What salary is budgeted for this role? | unresolved |
| KR3 | Explicit ownership and cadence | positive_signal | — | "Own the 13-week supply plan… run the weekly S&OP meeting" | Ownership and the meeting are defined, so the role's authority is at least stated | `[grounded]` posting | Who sets the capacity figures the plan is balanced against, and who signs off the plan? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| K-P1 | Do not apply to this posting now | Two must-haves are absent, with no near closure | `[grounded]` K2, K4 | recommendation |
| K-P2 | Target demand-planning or planning-analyst roles in FMCG, where you support a planner | Closure path for K2 | `[generic]` planning analyst roles often sit below owner level | pending your approval |
| K-P3 | Build familiarity with a planning tool, such as a vendor course on IBP | Closure path for K4 | `[generic]` | pending your approval |

## Evidence status

Verified: none yet.

The research line and target table are in the Duinvaart section above, since they cover both postings.

## Dossier offer

If you want a saved copy of both assessments, I can write them to `tuesday-dossier.md`.

## Upgrade menu

- **Web search.** The permission for it was refused, so neither employer was checked and no salary band exists. Grant it and I can rerun the employer check and salary sweep. One search remains in the L1 budget, and both fetches.
- **A live posting link** for each role: closes DR1 and KR1.
- **A budgeted salary** for each role: closes DR2 and KR2, and sets them against a band.
- **A compliance record** from your work with a threshold (failed-delivery rate, damage rate, handling standard): raises D6 from `low`.
- **An Excel sample** or a description of your level: settles K3.
- **Your pay floor and any other non-negotiable:** lets the hard-gate checks run against you.

## Questions

- **D1 / K1:** Where do you live, and can you do three days a week in Rotterdam, or be on-site in Utrecht?
- **D6:** Have you tracked any compliance measure with a threshold beyond delivery time, such as damage, failed deliveries or handling standards? Describe what it was, who set the threshold, and what you did when it was missed.
- **Your constraints:** What is your pay floor, and is there any other non-negotiable I should check the roles against?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.