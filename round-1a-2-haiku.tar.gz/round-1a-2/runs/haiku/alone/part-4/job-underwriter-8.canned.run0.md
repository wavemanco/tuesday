**Decision: no-go. This is a scam. Don't send anything to @VellowayHiring, don't pay the €349, and don't deposit or transfer any cheque.**

The messages alone establish this. I didn't run any web searches, so I can't say whether Velloway Logistics exists. It doesn't matter for the decision.

**Red flags in the posting and the chat:**

- **Payment before any real hiring step.** You're asked to pay €349 for equipment, refunded "with your first wages." Legitimate employers supply their own equipment.
- **The cheque plan is a known fraud pattern.** You're told to deposit a €2,850 cheque, keep €350, and send the rest to a "partner." Banks often credit a cheque before it clears. When it bounces weeks later, the money you transferred out is gone and you may owe the bank the shortfall.
- **Sensitive data requested before any interview.** IBAN, PPS number and passport photo are what identity thieves need. Real payroll doesn't collect these over Telegram before an interview.
- **Telegram-only, no calls or video, and "passed screening" with no screening.** You were approved before any real conversation happened.
- **Contact is a generic address, `velloway.hr@postmail.example`,** not a company domain.
- **The pay doesn't clearly reach your target.** "Up to €26/hr" for 15–30 hours a week comes to roughly €19k–€37k a year before tax, assuming about 48 working weeks. €30k would need close to the top of that range. This is a secondary point; the posting is a scam regardless.

**What to do now:**

1. **Don't paste your IBAN or send the passport photo or PPS number.** You haven't sent them, so keep it that way.
2. **Stop replying on Telegram** and block the account. Report it to Telegram and to the jobs site where you found the posting.
3. **Check the company yourself.** Search the Companies Registration Office (cro.ie) for Velloway Logistics. Also look for the company's own website and careers page, which should match the email domain. Don't use any contact details from the posting to verify it.
4. **If you already sent any details or money,** call your bank right away using the number on the back of your card. Ask them to freeze or flag the account and to reverse any transfers. Tell the Gardaí, and if your PPS number was shared, let the Department of Employment Affairs and Social Protection know.

**On your background:** your experience fits this kind of role well: 60 tickets a day in Zendesk, training new starters, and running a team tracker in Excel. Those are real, verifiable strengths. Look for them in roles at companies you can confirm, such as a parcel courier's own careers page, or in customer support or operations roles listed on the official sites of logistics companies in Ireland. Pay at or above €30k is the number to filter on.

If it would help, I can draft a short report to the jobs site, a message to your bank, or a checklist for vetting the next posting.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.