**Decision snapshot**

| Posting | Decision | Candidate fit | Opportunity | Hard gates |
|---|---|---|---|---|
| Duinvaart Operations Analyst, Rotterdam | `conditional_go` | Strong on the must-haves; cold-chain domain is new | Unverified employer; pay not stated | Hybrid Rotterdam, 3 days/week: unknown until you confirm you can commute |
| Kroonhaven Supply Planner, Utrecht | `no_go` (fit) | Missing core planning experience, SAP IBP, and fluent Dutch | Not assessed negatively; no research run | None stated; on-site Utrecht is unknown until you confirm |

The `no_go` for Kroonhaven is a fit verdict. The role itself may be fine; you'd be applying against stated must-haves you don't have.

Research tier: L0, no searches. Everything about either company is `[generic]` or taken from the posting text.

**Posting 1: Duinvaart Operations Analyst**

Evidence map:

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | 2+ years logistics or ops analysis | Must | Met | High | None | 4 years as ops analyst at a parcel carrier |
| 2 | Strong SQL | Must | Met | High | None | Daily use |
| 3 | Power BI or Tableau | Must | Met | High | None | Daily use; built the on-time dashboard depot managers use |
| 4 | Track on-time delivery | Duty | Met | High | None | Owned that dashboard |
| 5 | Weekly dashboards | Duty | Met | High | None | Ran a weekly route-performance review |
| 6 | Work with depot managers on route changes | Duty | Met | High | None | Route-performance review with depot managers |
| 7 | Temperature compliance, refrigerated fleet | Duty | Partial | Medium | Transferability | Data and process skills transfer; cold-chain or temperature-monitoring experience doesn't appear in your background |
| 8 | Dutch | Preferred | Partial | High | Capability | Conversational, not fluent |
| 9 | Hybrid, 3 days/week in Rotterdam | Hard gate (schedule/location) | Unknown | — | Hard-gate | Depends on your commute tolerance |

Gap queue (no questions here; the closing block asks them):
- **Row 7:** Temperature compliance is a different data domain. It would close with evidence of sensor or cold-chain data work, or a clear account of how you'd learn it.
- **Row 9:** Closes with your answer on commuting.

Risk register:
- Employer unverified. This is standing: with no research run, existence and stability are unknown.
- Temperature compliance may be a heavier monitoring load than the dashboard work you've done. Ask what data they actually have.
- Pay not stated `[inferred]`: the posting withholds it, which is worth a question before you invest time.

Application plan (proposed; nothing is written for external use until you approve it):
- Apply once the commute question is answered and the employer is checked.
- Lead with the on-time delivery dashboard and the route-performance review, the closest matches to what the posting asks for.
- Name cold chain as the new domain, not something you have.
- Describe Dutch as conversational, and ask what level they expect.
- Proposed CV language is pending your approval.

**Posting 2: Kroonhaven Supply Planner**

Evidence map:

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | 3+ years supply or demand planning, FMCG | Must | Gap | High | Capability | Background says you've never worked in planning |
| 2 | Advanced Excel | Must | Unknown | — | Discovery | Not mentioned in your background |
| 3 | SAP IBP or similar planning system | Must | Gap | High | Capability | None listed |
| 4 | Fluent Dutch | Must | Gap | High | Capability | Conversational |
| 5 | Weekly S&OP-style cross-functional review | Duty | Partial | Medium | Transferability | Weekly route-performance review is similar in rhythm, not in content |
| 6 | Balance production capacity against forecast | Duty | Partial | Medium | Transferability | Route capacity against demand is analogous; production isn't |
| 7 | On-site Utrecht | Constraint | Unknown | — | Hard-gate candidate | Depends on your location |

Gap queue:
- **Rows 1 and 3:** Capability gaps. Neither closes with a rewrite of the CV.
- **Row 4:** Capability gap. Closing it takes time, not wording.
- **Row 2:** Discovery. You may already have it; it just isn't on the CV.

Application plan: I'd not apply now. Two must-haves are missing outright. Planning-adjacent roles where capacity-against-demand work transfers (demand analyst, transport or logistics planner) are the closer target. `[inferred]` Going for this role later means first getting SAP IBP or a similar tool in use.

**Evidence status**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | No research consented; tier L0 |
| 2 | Role-family sweep (scope, title, pay) | skipped | No research consented; tier L0 |
| 3 | Hiring manager's public footprint | n/a | No hiring manager named |

**Dossier offer:** I can write these findings to a `tuesday-dossier.md` so a later interview-prep session can pick them up.

**Upgrade menu** (what each missing input would unlock):
- Commute tolerance → resolves the hard gate on Duinvaart.
- Pay floor and other non-negotiables → hard-gate checks against both postings, plus a pay comparison.
- Live posting links or the careers pages → confirms both employers exist as described.
- L1 research (up to 5 searches, 2 page fetches) → verifies Duinvaart and gives a `[generic]` pay band for these titles.
- An Excel example or description → resolves Posting 2 row 2.

**Questions**

1. **(Hard gate, Duinvaart)** Can you commute to Rotterdam three days a week from where you live? Is that a firm no or something you can negotiate?
2. **(Structural)** What's your pay floor, and are there other non-negotiables I should check against these roles?
3. **(Research consent)** Should I run the L1 research (up to 5 searches and 2 page fetches) to confirm Duinvaart exists as described and check the pay band? If you have the live posting links, paste them too.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.