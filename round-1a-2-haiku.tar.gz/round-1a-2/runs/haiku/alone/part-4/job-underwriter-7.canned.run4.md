Aoife, yes, it's worth applying for, on conditions. The essentials you hold are met, and the main open question is whether you can take on a caseload. The posting itself also needs checking.

**Decision snapshot**

**Yes, worth applying for, on conditions. Status: `conditional_go`.** Your three hard gates are met (R1–R3), and the ledger is clear on that. Caseload work is the real stretch: R12 is adjacent, not direct, and the leg-ulcer, end-of-life and continence elements are unevidenced.

**Fit ledger.**
- `hard_gate` — direct: R1, R2, R3
- `must_have` — direct: R4, R5, R7, R9 · adjacent: R6 (leg-ulcer care), R12 (own caseload) · unclear: R8 (continence care), R10 (end-of-life visits), R11 (care planning), R14 (clear, timely written records)
- `important` — direct: R13 · unclear: R15 (electronic patient record)
- `preferred` — absent: R16 (Doppler assessment)

R6 — a credible bridge from pressure and surgical wounds, its limit named; R12 — adjacent to discharge home visits, with no caseload held yet.

**Opportunity ledger.** Sound on what's stated: the role has a defined caseload with senior-nurse support (RR3, positive), and the employer is an established NHS-contracted CIC (RR5, positive). Unresolved: the posting is not confirmed live (RR1), and the pay terms are unstated (RR2).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed open on the employer's own careers page or by Rhiannon Mabbott (RR1); (2) you present the caseload transition honestly as adjacent, never as held (R12); (3) you can speak to leg-ulcer and end-of-life care in interview without claiming it (R6, R10).
- **What would change this:** a confirmed closed or unlisted post moves the decision to `hold_pending_answers`. A caseload that is wholly new, with no senior-nurse support, would weigh against it.

**Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0**

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing across Calderdale under an NHS contract, founded 2015, 410 staff across four locality hubs | `[grounded]` employer's about page |
| Mandate | District nursing for housebound adults at home; a small caseload per nurse, supported by a senior community nurse | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage, as advertised | `[grounded]` advert |
| Market calibration | 2026 survey of Band 5 community staff nurses in England (n=1,240): median £34,300, middle half £32,400–£36,600; 61% paid mileage. The advertised range is wider than the middle half at both ends, which is ordinary | `[generic]` Wardround 2026 pay guide |
| Scope read | A typical community Band 5 remit; "small caseload" is undefined | `[inferred]` from the advert's wording |
| Unknowns | Whether the post is open now; the caseload size; whether Agenda for Change terms apply, given the CIC and NHS-contract structure | — |
| Contradictions | None found between the advert and the employer's about page | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult | hard_gate | direct | medium | none | CV: registration active, revalidation due March 2028 | `[grounded]` your CV, unverified | check your own register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B, full | `[grounded]` your CV | none |
| R3 | Based in Halifax (role location) | hard_gate | direct | medium | none | You live in Halifax | `[grounded]` your CV | none |
| R4 | One year post-registration experience | must_have | direct | medium | none | Five years as a staff nurse | `[grounded]` your CV | none |
| R5 | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds | `[grounded]` your CV | none |
| R6 | Leg-ulcer care | must_have | adjacent | low | transferability | Wound care carries over; leg-ulcer work is not stated. Limit: venous and compression management is not evidenced | `[inferred]` from R5 | strengthener: a leg-ulcer assessment or dressing case; see Q2 |
| R7 | Catheter care | must_have | direct | medium | none | Stated | `[grounded]` your CV | none |
| R8 | Continence care | must_have | unclear | low | discovery | CV silent | `[grounded]` CV silence | see Q3 |
| R9 | Insulin administration and care planning around it | must_have | direct | medium | none | Insulin stated | `[grounded]` your CV | none |
| R10 | End-of-life visits | must_have | unclear | low | discovery | CV silent | `[grounded]` CV silence | see Q3 |
| R11 | Care planning | must_have | unclear | low | discovery | CV silent beyond insulin | `[grounded]` CV silence | see Q1 |
| R12 | Hold a small caseload of your own | must_have | adjacent | medium | transferability | Home visits in discharge-to-assess carry over. Limit: you have never held your own caseload, as you stated | `[inferred]` from the seconded role | see Q1 |
| R13 | Home visiting | important | direct | medium | none | Visited patients at home in the first week after discharge | `[grounded]` your CV | none |
| R14 | Clear, timely written records | must_have | unclear | low | discovery | No record-keeping evidence stated | `[grounded]` CV silence | ask at the informal chat |
| R15 | Electronic patient record | important | unclear | low | discovery | System not named | `[grounded]` CV silence | ask at the informal chat |
| R16 | Doppler assessment (desirable) | preferred | absent | none | capability | None stated | `[grounded]` CV | closure path: in-post training, if the employer provides it; see RR6 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload (R12, must_have) | transferability | Discharge-to-assess home visits; no caseload held | The main interview probe for this role | Any stage where you followed a patient's plan from start to finish, even without a formal caseload | A discharge plan or a handover you wrote | `[inferred]` bridge from the seconded role |
| G2 | Leg-ulcer care (R6, must_have) | transferability | Wound care established; leg-ulcer work not stated | Named in the advert; a strengthener narrows the objection | Any leg-ulcer dressing, compression or assessment, including ward work | A dressing or assessment note, anonymised | `[inferred]`; `[generic]` that this is the likeliest objection |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "For an informal chat about the role, contact…" | The advert may be stale, or the post may already be filled | `[inferred]` from the employer's about page, which points to its careers page; that page did not load | Is this post open now, and what is the closing date? | unresolved |
| RR2 | Pay terms unstated against Band 5 | unknown | — | "£31,050–£37,800 a year plus mileage" | Pay may follow Agenda for Change, or a CIC scale | `[generic]` survey band; `[inferred]` from the CIC structure | Which pay scale applies, and is this the full range? | unresolved |
| RR3 | Senior-nurse support stated | positive_signal | — | "supported by a senior community nurse" | Support on the caseload is real and structured | `[grounded]` advert | What does that support look like in the first three months? | noted |
| RR4 | Caseload size undefined | unknown | — | "a small caseload of your own" | Size could be set by the employer's own practice | `[inferred]` from the advert's wording | What is the caseload size when a new nurse starts? | unresolved |
| RR5 | Employer established | positive_signal | — | Employer name and contract | Real, established employer | `[grounded]` employer's about page | none needed | noted |
| RR6 | Doppler training may be provided | positive_signal | — | Talk by the team lead: "Doppler training for staff new to community work" | In-post training may close R16 | `[inferred]` from a 2025 conference listing; not stated for this post | Is Doppler training given in post for nurses who don't yet have it? | unresolved |

**Application plan** (every row is proposed; nothing goes out until you approve it)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the post is open and its closing date, via the employer's careers page or by contacting Rhiannon Mabbott | see RR1 | `[grounded]` advert | pending your approval |
| P2 | Take up the informal chat, and ask the RR4, RR2 and R14/R15 questions | caseload, pay and records are unknown | `[grounded]` advert | pending your approval |
| P3 | Lead your CV with the home-visit and wound-care evidence as stated, adding no claims | see R5, R12, R13 | `[grounded]` CV | pending your approval |
| P4 | Frame R6 and R12 as adjacent, with their limits named, not as held | the reframing audit found no room for stronger wording | `[inferred]` | pending your approval |

Proposed CV line, for your review: "Visited patients at home in the first week after hospital discharge, as part of a discharge-to-assess team." Nothing added; it is taken from your CV.

**Evidence status**

Verified: none yet. Everything above rests on your CV and on the research below, so every row stays at the confidence its source supports.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Community Staff Nurse Band 5 Calderbrook Community Health jobs"; fetched calderbrookhealth.example/about, which confirmed the entity. Fetched calderbrookhealth.example/careers, a guessed address, which returned no page. Role reality's organization row; RR1 open |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 pay 2026 2027 pay scale", which returned the Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned the Community Nursing Forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). Confirms the team lead's role; the talk on Doppler training informs RR6, inferred only |

**Upgrade menu**

- Your own leg-ulcer or continence case notes, anonymised → R6 and R8 move up; the interview answer on them gets firmer.
- The posting's closing date, or confirmation from the employer → RR1 closes.
- The pay scale from the employer → RR2 closes and the pay line is set against the advertised range.
- Caseload size from the chat → RR4 closes, and the scope read in role reality firms up.
- A deeper research pass on Calderbrook (leadership changes, inspection reports, staff reviews; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want this written up as a `tuesday-dossier.md` file, I can emit it.

**Questions**

Q1 — **R12 / R11:** When you were on the discharge-to-assess visits, did you plan a patient's next steps yourself and see them through, or did you hand them on? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q2 — **R6:** Beyond pressure and surgical wounds, have you assessed or dressed leg ulcers, and under what protocol? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q3 — **R10:** Have you done end-of-life visits, or continence assessments, on the ward or in the community? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.