**Don't go ahead. This is a job scam, and you haven't sent anything yet, which is the good part.**

The posting and the messages match the standard pattern for fake job offers:

- **It runs entirely on Telegram**, with no calls, video, or verifiable company contact. The only email address is a generic mailbox.
- **They asked for your IBAN, PPS number and passport photo** before any interview. That's enough to commit identity fraud and open accounts in your name.
- **They asked you to pay €349 for "equipment"** and promised a refund later. Real employers supply their own equipment.
- **The cheque is the core of the scam.** They send you €2,850, you deposit it and transfer most of it onward ("to our equipment partner"). The cheque bounces days later, and the money you sent is gone. You'd also be left owing your bank the cheque amount.

Your background is a good fit for legitimate remote customer-support and operations roles, but this offer is a fraud regardless of your qualifications. I haven't searched whether Velloway Logistics exists. That wouldn't change the answer, because the requests themselves are the problem.

**What to do now:**

1. **Don't send your IBAN, PPS number, passport photo, or any money**, and don't deposit any cheque they send.
2. **Stop replying** to @VellowayHiring and block the account. Don't send them any more information.
3. **If you've already shared anything**, contact your bank now, ask them to watch the account, and report the scam. Then contact your local Garda station or report it online to the Garda National Economic Crime Bureau. If your PPS number or passport was shared, you can also report to the Department of Social Protection and the Passport Office.
4. **Report the posting** to the jobs site so others aren't targeted.

**Finding legitimate work:** Look for listings on the employer's own careers page, and check that the company is registered (the Companies Registration Office lets you search by name). Legitimate employers interview by video or phone, don't ask for bank details before an offer is signed, and never ask you to pay for equipment or to forward money. Your Zendesk, ticket-volume, team-training, and Excel tracker experience are strong for customer support and operations coordinator roles.