**Decision snapshot**

- **Job decision: conditional_go.** The role fits your payroll experience well. The condition is verifying that Marrowgate is the employer the email says it is before you send anything sensitive.
- **Fit ledger:** Strong on payroll operations, starters and leavers, payroll-to-ledger reconciliation, Excel and the qualification. Gaps: pension changes (never done), Irish PAYE/PRSI/USC depth (not stated in your background), and scale (90 staff fortnightly to 240 monthly).
- **Hard gates:** None failed on what's known. Limerick hybrid (two days a week) is unknown until you confirm you can commute. The €40,000 offer sits inside the advertised €38,000–€42,000 `[grounded]`.
- **Employer verification:** Not established (see evidence status).

**Your question: is it normal?**

Partly. Your instinct not to send anything yet is sound.

- **Normal `[generic]`:** Employers need bank details for salary and a PPS number for Revenue payroll, and collecting them after an offer is standard. Irish right-to-work checks normally mean seeing the original passport in person, which is the step they've described for day one.
- **Less standard `[generic]`:** Asking for a passport scan and bank details through an online portal before you have a signed contract. Some employers do this, but it is also the pattern used in recruitment fraud. A .ie sending address is a good sign, not proof.
- Nothing you pasted proves either way. You also don't need to share any ID or number with me; I haven't used any.

**Research tier: L1 — searches 3 of 5, fetches 0 of 2**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | unavailable | Search permission was not granted in this session, so all three calls were refused. Would have checked that the company exists and the posting is live. |
| 2 | Role-family sweep (Payroll Administrator, Limerick, about €38–42k) | unavailable | Same refusal. Would have calibrated the salary band. |
| 3 | Hiring manager public footprint (Declan Garvagh) | unavailable | Same refusal. Would have checked the named manager exists. |

**Role reality**

- Permanent Payroll Administrator at €40,000, reporting to Declan Garvagh, Finance Manager, hybrid with two days a week in Limerick `[grounded: offer]`.
- Scope per the advert: monthly payroll for 240 staff, starters and leavers, pension changes, monthly reconciliation to the general ledger, staff queries `[grounded: advert]`.
- Your current role is fortnightly payroll for 90 staff, so the monthly cycle and larger headcount are new `[inferred]`.

**Evidence map**

| Requirement | Priority | Fit | Gap | Note |
|---|---|---|---|---|
| 2+ years running payroll | must | strong | none | Three years |
| Working knowledge of Irish PAYE, PRSI, USC | must | unconfirmed | knowledge | Your background doesn't state the jurisdiction |
| Strong Excel | must | strong | none | Pivots and XLOOKUP |
| Payroll qualification or working towards one | must | strong | none | Payroll Technician, 2024 |
| Starters and leavers | core | strong | none | |
| Monthly payroll-to-ledger reconciliation | core | strong | scale | Same task, larger volume |
| Pension changes | core | gap | capability | Never done; your manager handled them |
| Answering staff payroll queries | core | transferable | none | |

**Gap recovery queue**

- **G1, pension changes:** Capability gap. It closes with the scheme rules and a supervised period, or with any pension admin you did do.
- **G2, Irish statutory depth:** Unconfirmed, not a known gap. Confirming your Irish PAYE/PRSI/USC work would move it to strong.
- **G3, scale:** Transferable. Monthly cycles at 240 staff are a volume change, not a new skill `[inferred]`.

**Opportunity risk register**

- **R1 (high), employer unverified:** Sensitive data is requested before any contract. Resolve by calling the switchboard listed on the company's own website (not the number in the email), confirming Declan Garvagh and the offer, and checking that the sender domain matches the website.
- **R2 (medium), offer incomplete:** No pension scheme details, probation terms or notice terms. Ask for a written contract before accepting.
- **R3 (low), five-day deadline:** A legitimate employer will normally accept a request to see the contract first.

**Application plan**

1. Before accepting, ask for the written contract and the pension scheme details.
2. Verify the employer through the company's own website and phone number.
3. Send bank and PPS details only after the contract is signed and the portal's domain is confirmed as the company's own or a named HR vendor's.
4. For the passport, ask why a scan is needed before the in-person check. Under data-protection minimisation `[generic]`, an original seen on day one may be enough.
5. Proposed reply, not sent, pending your approval: *"Thank you for the offer. Before I accept, could you send the written contract and the pension scheme details? I'd also like to confirm the onboarding portal address and why a passport scan is needed in advance."*

**Dossier offer:** I can write a `tuesday-dossier.md` file that keeps this assessment for a later session.

**Upgrade menu**

- **Live posting link or the company's careers page:** Confirms the role is advertised and matches the offer. Would clear R1 in part.
- **Written contract or offer letter:** Confirms pension, probation and notice terms. Would clear R2.
- **Details of your Irish payroll work:** Would move G2 from unconfirmed to strong.
- **Research, once searches are allowed:** Would verify the employer, the salary band and the hiring manager.

**Questions**

1. Have you received a written contract, or only this email?
2. Did you run Irish PAYE, PRSI and USC yourself at the hotel group, or was that handled elsewhere?
3. Can you reach the Limerick office two days a week?

Answer in text, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.