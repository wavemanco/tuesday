**Decision: `go`. Apply.** Your gates are met and most of the essentials are direct. The real gaps are your own caseload and Doppler, and both are learnable.

## Decision snapshot

- **Fit ledger:**
  - hard_gate: R1 (`direct`), R2 (`direct`)
  - must_have: R3, R5a, R6a (`direct`); R4 (`adjacent`); R5b, R6b, R7, R9 (`unclear`); R8 (`absent`)
  - important: R11 (`adjacent`)
  - preferred: R10 (`absent`)
  
  The gates are met, and your one-year post-registration requirement and your catheter and insulin work are direct. Wound care is adjacent, since leg ulcers are not on your CV. Continence, care planning, end-of-life and written records are unclear because your CV is silent on them. Your own caseload is absent, and Doppler is absent.
- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Confidence:** each band sits beside its own row in the table below. The NMC and licence rows are `medium` because they rest on your statement, not a register or licence check.

## Role reality

- **Employer [grounded]:** Calderbrook Community Health's own about page describes a community interest company running adult community nursing across Calderdale under an NHS contract, with 410 staff across four locality hubs. The entity exists as the advert describes it.
- **Posting:** I could not reach the careers page, so I have not confirmed the post is still open.
- **Pay:** The advert gives £31,050–£37,800 plus mileage [grounded]. A 2026 community nursing survey of Band 5 staff nurses in England puts the median at £34,300 and the interquartile range at £32,400–£36,600 [generic]. The advert sits around the middle of that range.
- **Contact:** Rhiannon Mabbott leads the Halifax district nursing team and was previously a district nurse for eleven years. In 2025 she spoke at a forum on Doppler training for staff new to community work [grounded, public footprint only].

## Evidence map

| # | Requirement | Priority | Fit | Gap | Confidence | Reasoning |
|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult | hard_gate | direct | none | medium | Stated as active; check it yourself on the NMC register |
| R2 | Full UK driving licence | hard_gate | direct | none | medium | Category B stated; licence not seen |
| R3 | One year+ post-registration | must_have | direct | none | medium | Five years as staff nurse |
| R4 | Wound and leg-ulcer care | must_have | adjacent | transferability | medium | Pressure ulcers and surgical wounds are direct; leg ulcers are not on your CV |
| R5a | Catheter care | must_have | direct | none | medium | Stated |
| R5b | Continence care | must_have | unclear | discovery | low | Not on your CV |
| R6a | Insulin administration | must_have | direct | none | medium | Stated |
| R6b | Care planning | must_have | unclear | discovery | low | Not on your CV |
| R7 | End-of-life visits | must_have | unclear | discovery | low | Not on your CV; home-visit work may be relevant |
| R8 | Own caseload, senior-nurse support | must_have | absent | transferability | high | You have never held one; the discharge-to-assess work is the nearest adjacent evidence |
| R9 | Clear, timely written records; EPR | must_have | unclear | discovery | low | Your CV says nothing on documentation |
| R10 | Doppler assessment | preferred | absent | capability | high | Never done; short training path likely |
| R11 | Home visiting, housebound adults | important | adjacent | transferability | medium | 18 months of visits in the first week after discharge; short-term, not a housebound caseload |

## Opportunity risk register

- **RR1 — unknown, low:** posting not confirmed live. *Verification question:* "Is the Community Staff Nurse post still open, and is it the one advertised with this contact?"
- **RR2 — unknown, low:** caseload size and senior support are not stated. *Verification question:* "What is a typical caseload for a Band 5 in this team, and how is senior support arranged?"

## Application plan

- **Lead story:** the 18 months of home visits in the first week after discharge. That is the closest match to community work, and you can describe the judgement involved without overclaiming.
- **Proposed CV language, pending your approval:** keep the existing wording. Do not add leg-ulcer care, continence care, caseload or Doppler. If you want the home-visit work described more fully, tell me what you actually did on those visits and I will draft wording from it.
- **Cover letter:** name the caseload gap directly and say you are ready to learn it. Ask Rhiannon about the Doppler training pathway, which she has publicly discussed.
- **Nothing here is sent or published until you approve it.**

## Evidence status

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | yes | Company about page confirms the entity. Careers page not located, so posting liveness is unconfirmed. Query: "Calderbrook Community Health CIC Halifax"; "Calderbrook Community Health careers Community Staff Nurse Band 5 vacancy" |
| 2. Role-family sweep | yes | Pay and norms from a 2026 community nursing pay guide. Query: "Band 5 community staff nurse Agenda for Change pay 2026 district nursing" |
| 3. Hiring manager footprint | yes | Public speaker page for the named contact. Query: "Rhiannon Mabbott Community Nursing Team Lead Calderbrook" |

## Gap recovery queue

- **R9:** no evidence of written records in the CV. Closed by one example of a handover or discharge note you wrote.
- **R6b and R7:** care planning and end-of-life work are unevidenced. Closed by any example of either, even partial.
- **R8:** own caseload is absent. This closes only through practice, not wording.
- **R10:** Doppler is absent. Closed by training, and possibly by the employer's own pathway.

Would you like me to save this analysis as a `tuesday-dossier.md` file for later reuse?

**Upgrade menu** (what each input would change):
- A copy of the live advert or careers page closes RR1.
- An anonymised sample of a discharge note or handover you wrote would move R9 toward `direct`.
- Any care-plan or end-of-life example would move R6b and R7.
- The NMC register check, which you can do yourself, would firm up R1.
- A stated pay floor, schedule or mileage limit would let the hard-gate checks run.

**Questions:**
1. For R9: can you give an example of a clear, timely note you wrote, such as a handover or discharge summary, and what it achieved?
2. For R6b and R7: have you ever contributed to care planning or end-of-life care, even partly, such as planning discharge packages or supporting a dying patient on the ward?
3. For the hard gates: do you have a minimum salary, a schedule constraint or a mileage limit I should check the role against?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.