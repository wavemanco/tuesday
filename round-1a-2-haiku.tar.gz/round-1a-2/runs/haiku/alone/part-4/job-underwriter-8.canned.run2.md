**Decision: no-go. Don't send anything to @VellowayHiring, and don't paste your IBAN, PPS number or passport photo anywhere in this process.**

- **Opportunity ledger:** no-go on its own merits. The process is a recognised advance-fee and fake-cheque pattern, not an unusual hiring style.
- **Candidate fit ledger (kept separate):** your stated background matches the listed requirements well. Fit does not rescue the opportunity.
- **Hard gates:** Pay and hours are unresolved. At the top rate of €26/hour, reaching €30,000 a year takes about 23 hours a week before any commission (€30,000 ÷ 52 ÷ €26 ≈ 22.2 h, from the posting's figures) [grounded]. The posting gives 15–30 hours and "up to" €26, so your floor is not guaranteed.
- **Research tier: L0, no searches.** I have not checked whether Velloway Logistics exists. That check is in the questions below.

## Opportunity risk register

| # | Signal | Class | Severity |
|---|---|---|---|
| R1 | Asks for IBAN, PPS number and passport photo before any interview [grounded, message 1] | Data-harvesting | Severe |
| R2 | Asks you to pay €349 by bank transfer to a third party for "equipment," refunded later [grounded, message 2] | Advance fee | Severe |
| R3 | Sends a €2,850 cheque, tells you to keep €350 and forward the rest to a "partner" [grounded, message 3] | Fake cheque / money-mule | Severe |
| R4 | Telegram-only, no calls or video; you "passed" screening and "interview" in chat within the same thread [grounded] | Process red flag | High |
| R5 | Contact is a generic mail domain, not a company domain [grounded] | Attribution red flag | High |
| R6 | Standing entry: employer existence unverified (no research run) | Failed attribution | High, constrains the decision |
| R7 | Pay is "up to €26" with commission unspecified and 15–30 hours; floor not met at the low end [grounded arithmetic] | Pay mismatch | Medium |

**Why R3 matters most:** a cheque you deposit can look cleared for days before the bank reverses it. If you forward money from it, the shortfall is yours, and moving another party's money this way can make you a money mule, which is a criminal matter in Ireland as elsewhere [generic]. Legitimate employers pay wages through payroll; they do not send cheques to be split and forwarded.

## Role reality

- **Title and scope:** a remote order-processing role with training and a commission element. That's ordinary in logistics [generic]. The posting itself is what's unusual.
- **Employer:** not verified. No company website, registration number or live careers page was given.
- **Contradictions:** "no experience needed" sits alongside requests for banking and identity documents before any interview.

## Evidence map (your stated background)

| Requirement | Your evidence (stated, CV-only) | Fit | Confidence |
|---|---|---|---|
| Attention to detail | Weekly team tracker in Excel | Strong | Stated |
| Spreadsheets | Excel tracker, ownership as you described it | Strong | Stated |
| Written English | Not evidenced in what you sent | Unknown | Not established |
| Quiet workspace | Not stated | Unknown | Not established |
| Order/ticket throughput | ~60 Zendesk tickets/day at a parcel courier, 3 years | Strong | Stated |
| Training others | Trained two new starters | Positive signal | Stated |

Confidence is "stated" because these come from your account, not from documents. They are leads, not verified proof.

## Application plan

1. **Don't apply through this route.** Report the Telegram account to Telegram.
2. **If you decide to pursue a role like this,** find the company's own careers page or a live posting, and verify it before any contact.
3. **If you've already sent anything** (you said you haven't), contact your bank at once, report the scam to the Gardaí, and change passwords for any account linked to your details.

## Gap recovery queue

- **G1 (hard gate, R7):** what hourly rate and weekly hours are guaranteed. Closed only by a written offer from a verified employer.
- **G2 (R6):** employer existence. Closed by a live posting on the jobs site, the company's own domain, or a Companies Registration Office record.

## Evidence status

Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | skipped | L0; research not yet consented |
| 2 | Role-family sweep (scope and pay for this seniority) | skipped | L0; research not yet consented |
| 3 | Hiring manager's public footprint | n/a | No name given |

## Dossier offer

If you want, I can write this up as a `tuesday-dossier.md` file you can keep or share.

## Upgrade menu

- **Company check (L1):** up to 5 searches and 2 page fetches to test whether Velloway Logistics exists as described. This would close R6 if it passes, and it would confirm R5 if it fails.
- **Live posting link or jobs-site name:** lets me check whether the listing is still up elsewhere.

## Questions

1. **Company check:** do you want me to run it (up to 5 searches and 2 page fetches)? Reply "research" or "skip."
2. **Source:** which jobs site did you find the posting on, and do you have its link?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.