**Decision snapshot**

- **Decision:** `conditional_go`. Take the call, but confirm two things first: the employer is real and the invite comes from its domain, and the pay range is what the posting says.
- **Candidate fit:** Strong on the core work. Your checkout redesign and booking-flow ownership map directly to "own the booking flow end to end," and your monthly customer usability sessions cover much of "run your own research." Your real gap is being the only designer, which you've never done.
- **Opportunity:** The company checks out on the one source I could reach. Compensation and the live posting are not yet verified.
- **Hard gates:** None stated. Two days a week in Galway suits you, since you moved back there. You didn't give a salary floor, so the €52k–€60k range is not yet tested against one.

**Research tier: L1, searches 2 of 5, fetches 1 of 2; user links read 0**

**Role reality**

- **Organization** `[grounded]`: The company's About page says Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. It has six people in Galway, was founded in 2023 by Ronan Kehoe and Saoirse Doyle, and is funded by its customers. This matches the posting and the WhatsApp message (Saoirse as CTO).
- **Scope** `[grounded]`: First designer, owning the booking flow, with customer research calls and close work with two engineers. Ronan is the day-to-day contact. A LinkedIn snippet describes him as co-founder and CEO, formerly product lead at a Galway travel-software company for five years.
- **Market calibration:** Not run. I have no verified role-family data, so I can't say whether €52k–€60k is normal for 3+ years in Galway. I won't estimate it from memory.

**Evidence map (summary)**

| Requirement | Fit | Basis |
|---|---|---|
| Booking flow end to end | Strong | Checkout redesign at your Dublin employer |
| 3+ years product design | Met | 4 years |
| Strong Figma | Met | Daily use |
| Run your own user research | Probably met | Monthly usability sessions; confirm you designed and analysed them, not only ran them |
| Work directly with engineers | Met | Four-engineer squad |
| Own design without a design peer | Gap | Never the only designer; the nearest fact is the squad |
| Research with school owners | Transferable gap | Your customers were travel bookers; school owners are a different buyer, a small seasonal business |

**Risk register**

- **Employer verification** (medium, open): The only sources are the company's own site and a founder profile. Check the company name on the Companies Registration Office register (cro.ie).
- **Posting not confirmed live** (low): I didn't reach a careers page or the posting itself.
- **Compensation** (unknown): Unverified against market and against your floor.
- **Channel** (low): WhatsApp contact from a founder is common at small Irish companies. Verify the calendar invite sender's domain matches the company site before you join the video link.

**Application plan (as far as the evidence allows)**

Lead with the checkout redesign and the monthly customer sessions, with the numbers you can stand behind. For "first designer," describe the squad honestly: you worked with four engineers and a product team, and you have not been the sole designer. Don't claim you ran a research programme unless you designed the studies and synthesised the findings yourself.

**Evidence status**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Official site and careers page | yes | About page fetched; careers page not checked |
| 2 | Role-family sweep | skipped | Not run; compensation band unverified |
| 3 | Hiring manager's public footprint | yes | Based on the search snippet for Ronan's LinkedIn profile; profile not opened |

**Dossier offer:** If you want, I can write a `tuesday-dossier.md` file that keeps this analysis for the next stage.

**Upgrade menu**

- The posting or careers-page link: confirms the role is live and matches the posting.
- A role-family compensation check (one search): tests the €52k–€60k range against Galway norms.
- A deeper company check (up to 5 more searches and 2 more fetches): funding, leadership churn, and public candidate reports. Offered once.

**Questions**

1. Did you design and analyse the research yourself, or run sessions someone else planned? This decides whether "run your own user research" is met.
2. Is €52k–€60k firm, and what is the equity vesting schedule?
3. Can you send the posting link or the calendar invite's sender address, so I can check the domain against the company site?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.