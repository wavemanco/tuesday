**Worth pursuing, on conditions: `conditional_go`.** On your evidence you match most of the must-haves. Whether Fernquay is a real, legitimate employer is not established yet, because web search was refused in this session, so I could not check it.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000 plus equity); candidate constraints not given, so checks against your pay floor are unknown.
- **Severe red flags:** none found. Neither the posting nor the WhatsApp message asks you for money, a deposit, or bank or ID details. The message only asks for a video call.

**Fit ledger** (the evidence map, read off its rows):

- `hard_gate`: direct: R1 · unclear: R2 (pay €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (own the booking flow end to end)
- `important`: unclear: R8 (first or only designer)
- `preferred`: adjacent: R9 (booking for school and surf operators)

R7 — a checkout redesign inside a squad, end-to-end ownership not yet shown; R8 (`low`) — no evidence yet of working without a design peer.

**Opportunity ledger:** Mixed, and checkable. The employer is not yet established (RR1). The scope asks one designer to own the whole flow with no design peers (RR3), and the equity and salary terms are unexplained (RR4, RR5). One entry runs the other way: the posting asks for one real project over a polished deck (RR6).

**What would change this:** the conditions for `conditional_go` are (1) Fernquay confirmed as a registered company with the role live on its own site (RR1); (2) your pay floor sitting inside €52,000–€60,000 (R2); (3) a credible account of working without design peers (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Reporting | Works most closely with co-founder Ronan Kehoe; the message also names Saoirse as CTO | `[grounded]` posting and message |
| Working pattern | Hybrid: two days a week in the Galway office, the rest remote | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Scope read | One designer owning a whole flow is a normal shape for a first design hire at a six-person company | `[inferred]` from the scope language against the team size |
| Market calibration | Not run: the role-family sweep was refused, so the pay band is uncalibrated | — |
| Unknowns | Whether the company exists as described; who holds product decisions; equity share class and vesting; runway | — |
| Contradictions | None found between the posting and the message on role details; neither is checked against a source outside them | `[grounded]` both documents |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year | `[grounded]` your statement | None |
| R2 | Pay €52,000–€60,000 plus equity | hard_gate | unclear | low | discovery | Your pay floor was not given, so the check cannot run | `[grounded]` posting; floor unknown | Give your floor (G3) |
| R3 | 3+ years product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company | `[grounded]` your statement | Dated CV line |
| R4 | Strong Figma | must_have | direct | medium | none | Daily Figma use | `[grounded]` your statement | Work sample |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers | `[grounded]` your statement | One study's sample size and what changed |
| R6 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad | `[grounded]` your statement | None |
| R7 | Owns the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout inside a squad; end-to-end ownership is not yet shown | `[grounded]` your statement | G2 |
| R8 | First or only designer | important | unclear | low | discovery | You have never been the only designer; no peer-free work is described | `[grounded]` your statement | G1 |
| R9 | Booking for school and surf operators | preferred | adjacent | medium | transferability | Travel booking, not activity-school booking; school owners are small-business users, not consumers | `[inferred]` from the two domains | Name the bridge |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | First or only designer (R8) | discovery | Squad experience only; no record of working without a design lead or peer | This is the core of the role; the risk is being solo with no one to check decisions against | A product manager or senior designer making the calls in your squad; cross-team design reviews; running usability sessions alone | Notes or a review from a usability session you ran yourself | `[grounded]` your statement |
| G2 | Own the booking flow end to end (R7) | transferability | Checkout redesign inside a squad; who decided scope and what you shipped alone is not stated | Decides whether R7 is `direct` or stays `adjacent` | Checkout decisions you made alone; choosing which changes shipped | The checkout case study | `[grounded]` your statement |
| G3 | Pay against your floor (R2) | discovery | No floor given | Only you can run this check; it is a hard gate | — | Your own number | `[grounded]` posting; floor unknown |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software" | The company may be too small or new to have a footprint, or the posting may not be live; this is unchecked, not a finding of fraud | `[generic]` pattern for companies this size | "Can you point me at the live role on your own careers page, and the company's registered name and number?" | unresolved |
| RR2 | First contact came by WhatsApp rather than email | unknown | low | "Just shout here if the time does not suit" | Informal founder outreach; the invite did come by email | `[inferred]` from the channel | "Was the calendar invite sent from your company email domain, and who hosts the video link?" | unresolved |
| RR3 | First-designer scope with no design peers | risk_signal | medium | "You would be our first designer: own the booking flow end to end" | Design scope may exceed one person's time or authority, and product direction may sit with the co-founder | `[inferred]` from the scope language against team size | "Who sets product priorities and has the final say on the booking flow, and what research time and tools are committed?" | unresolved |
| RR4 | Equity with no share class, vesting or valuation given | unknown | low | "plus 0.5–1% equity" | Equity may be worth little or lock in terms you have not seen | `[grounded]` posting's silence on terms | "What share class, vesting schedule and strike price apply, and what is the current valuation?" | unresolved |
| RR5 | Pay band not calibrated against market | unknown | low | "Salary €52,000–€60,000" | The band may sit above or below the market for this seniority; the check was refused | `[grounded]` posting; market band not checked | "Is the €52,000–€60,000 range firm, and where in it would a hire at my level start?" | unresolved |
| RR6 | Asks for real work over a polished deck | positive_signal | n/a | "we would rather see one messy real project than a polished deck" | Suggests a team that values working evidence | `[grounded]` posting | — | — |

**Standing check:** no request for payment, a deposit, bank details or ID appears in the material, so no red-flag entry is recorded.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, confirm Fernquay on its own website and the Companies Registration Office register (cro.ie), and check that the invite's sender domain matches the company site | Closes RR1 and RR2 | `[generic]` public registers exist for this | proposed |
| A2 | Lead with the checkout case study and the squad-engineer story, framed as end-to-end contribution inside a team, not as sole ownership | Keeps R7 accurate while it is still `adjacent` | `[grounded]` your statement; reframing audit applies | resume_edits_pending_approval |
| A3 | Prepare an honest answer on working without a design peer: what you would do alone, and what you would ask for | Addresses R8 and RR3 | `[inferred]` from the gap | proposed |
| A4 | Ask the three verification questions on the call (RR3, RR4, RR5) | These are facts only the employer holds | `[generic]` interview practice | proposed |

Nothing here is externally visible yet. The A2 wording is not approved for use anywhere.

## Evidence status

Verified: none yet. Your claims in R1, R3–R6 rest on your own statements; the case study and any artifacts are not yet reviewed.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three web searches on Fernquay, Ronan Kehoe and the company registration were refused, so none ran. Would have moved RR1 and the role's contradiction check |
| 2. Role-family sweep | unavailable | No search ran. Would have moved RR5 and the market calibration line |
| 3. Hiring manager's public footprint | unavailable | Ronan Kehoe was named, but no search ran. Would have moved the positioning in A2 |

## Dossier offer

If you want, I can write this up as a `tuesday-dossier.md` file at the end of the engagement.

## Upgrade menu

- Permission to web search in this session → checks Fernquay's own site and registration (RR1), calibrates €52,000–€60,000 (RR5), and looks at Ronan Kehoe's public background. A deeper pass on the company, up to 5 more searches and 2 more fetches, is available once search is granted.
- Your salary floor → closes the R2 gate.
- Any history of working with a design lead or peer → moves R8 out of `unclear`.
- The checkout case study link → lets me check R7's claim against the work itself.

G1 — Have you ever designed without a design peer or design lead to take calls to? If so, who did you go to when a product decision was contested?
G3 — What is your salary floor, and does the equity change whether €52,000 works for you?
RR1 — Where did you first see the posting?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.