## First, a warning about this invite

I'd verify this before you reply with anything. Several features match common recruitment scams:

- **The whole process runs in Telegram.** The invite says the interview, offer and onboarding will all happen in a chat. Real employers usually use email, a video call, or an applicant tracking system for offers.
- **An unsolicited recruiter message on a messaging app.** You applied on their careers page, so an invite should normally come from a company email address.
- **Onboarding in chat.** Scams often move quickly from "interview" to "offer" to requests for bank, tax or ID details.

This doesn't prove it's fake. Some small companies do run informal processes. I haven't checked whether Lumenvale Software exists or what its real hiring channels are.

**Before you reply, check these:**

1. Open Lumenvale's website yourself, not through any link in the message. Confirm the Customer Support Specialist role is on its official careers page and that it matches the one you applied for.
2. Ask the careers page or the company's listed contact about "Marcus Hale" and the Telegram interview. Use the contact details from their official site, not the ones in the message.
3. Reply through the careers page application or an email on the company's domain, and ask for a video call and a written offer by email.
4. Don't send bank details, ID, tax numbers or any payment, and don't deposit or forward a cheque or buy equipment for "onboarding", whatever the reason given.

If the company confirms the invite, the prep below will apply. If they don't, you can drop it.

## Prep, built from your material

I didn't run any research on Lumenvale, so the questions below come from the job ad and your background only. Nothing here is about their values or strategy.

### Fit snapshot

| JD requirement | Your evidence (quoted from your message) | Gap type / bridge |
|---|---|---|
| 2+ years in customer support | "3 years as a customer service advisor at an energy supplier" | Meets it. No gap. |
| Zendesk or similar ticketing tool | "I use Freshdesk every day" | Close match, not the same tool. Bridge: "Freshdesk is a ticketing tool like Zendesk, and I'm comfortable learning a new one." |
| Clear written communication | "~60 calls and emails a day" and "trained four new starters on our refunds process" | Partial evidence. Emails show volume, and training shows you can explain a process clearly. Written-chat experience is not shown. |
| Confidence handling escalations | Not stated in your message | Gap. You need a real example from your job. |
| Software company experience | "I've never worked for a software company" | Gap, but not a disqualifier. Bridge: your product knowledge and ticket handling transfer. |

### Question bank

**1. Tell me about your support experience.** *(Background)*
- **Guidance:** Give a short summary. Three years, about 60 contacts a day across calls and emails, daily use of Freshdesk.
- **Provenance:** Your message: "3 years as a customer service advisor… around 60 calls and emails a day; I use Freshdesk every day."

**2. You've used Freshdesk, not Zendesk. How would you adapt?** *(Gap-bridging)*
- **Guidance:** Don't claim Zendesk experience. Say you know how a ticketing tool handles queues, statuses and macros, and that you'd learn their setup quickly.
- **Provenance:** Your message: "I use Freshdesk every day."

**3. Tell me about a time you handled an escalation.** *(Escalations, your biggest gap)*
- **Guidance:** Use a real case from your job: what the customer was upset about, what you did, what you handed over and why. Don't invent one. If you don't have a clear example, say so and describe how you'd handle one.
- **Provenance:** Answer slot. Your material doesn't show this, so you'll need to supply the example.

**4. How do you write for customers when you can't hear their tone?** *(Written communication)*
- **Guidance:** Use the email volume and the refunds process training as evidence. Explain how you keep written replies clear and calm.
- **Provenance:** Your message: "~60 calls and emails a day" and "trained four new starters on our refunds process."

**5. You trained four new starters on refunds. How did you do it?** *(Training / process clarity)*
- **Guidance:** Describe the steps you taught, how you checked understanding, and what you'd change next time.
- **Provenance:** Your message: "I trained four new starters on our refunds process last year."

**6. You've never worked at a software company. Why would you fit here?** *(Motivation / gap)*
- **Guidance:** Be honest. Say you're learning their product, and point to the customer-facing skills that carry over.
- **Provenance:** Your message: "I've never worked for a software company."

### Reverse questions to ask them

- What does a typical day look like for this role, and what ticket volume should I expect?
- What tools will I use besides the ticketing system?
- How do you handle escalations to the product or engineering teams?
- Could you send the full offer and job details by email on the company domain?

## Questions for you

1. Can you confirm the job on Lumenvale's official careers page, and whether it's the same title and description as the posting you applied to?
2. Do you have the full job ad text? Without it, I've worked from the summary in your message.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.