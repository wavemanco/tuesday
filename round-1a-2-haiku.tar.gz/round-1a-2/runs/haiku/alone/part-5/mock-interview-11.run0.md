I can build the prep pack, but I need the **company name and role title** first. The invite names neither, and I can't build the pack without them. Send them and I'll start right away.

Before you spend time preparing, please check this invite. Several things match a common job scam:

- It came from an unknown number and says "we found your profile online."
- It's a remote role with flexible hours.
- The whole process, from interview to contract, is to run over WhatsApp, with no calls or video.
- It asks you to confirm a time for tomorrow, which leaves little room to check anything.

A hiring process run entirely by chat is a warning sign, even when the job is real. Before you commit to anything:

1. **Ask Jess for the company name, the recruitment firm's name, and the role title.** Then look up the company's official careers page yourself, rather than using any link or contact Jess sends.
2. **Contact the company directly** through its published website or switchboard, and ask whether it is hiring for that role and whether it uses Jess's firm.
3. **Ask for a video or phone call** with a named person from the company, using a work email address on the company's own domain. A legitimate recruiter will usually accept this.
4. **Never pay anything or send bank, tax or ID details** before a written offer from the company. Watch for requests to pay a fee, buy equipment, or deposit a cheque.

If you want a structured check on this specific offer, a job-underwriter review can assess it. I'd recommend running that before the interview.