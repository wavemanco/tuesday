# Customer Support Specialist, Lumenvale Software (remote): interview prep pack

Interviewer: the support team lead (name not given). Round: a text interview in a Telegram chat, so the hiring-manager prior applies and answers are typed. Built at research tier L0: no search was run, and the job ad is your summary, not the posting, so every requirement quote is your wording.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

- **VAL**: behavioural and values fit
- **EXP**: your own experience, checked closely
- **JD**: the job's stated requirements
- **CO**: company and strategy knowledge (not covered here; no research run)
- **CASE**: a live problem from the role

Guidance is scaffolding, not a script. Write answers in short paragraphs you can send.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your summary of the ad) | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" (your message) | high | [grounded] | presentation | Your message says customer service advisor at an energy supplier, not customer support by title. Keep the bridge to your words: "For three years I was a customer service advisor at an energy supplier." Answer slot: the ad asks for support work, so expect a probe on what that role involved. Say it in your own words. |
| F2 | "experience with Zendesk or a similar ticketing tool" (your summary of the ad) | "I use Freshdesk every day" (your message) | high | [grounded] | none | Freshdesk is a ticketing tool of the kind the ad names, so the quote already reaches the requirement. Lead with it. Do not claim Zendesk experience. |
| F3 | "clear written communication" (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not show written work, so the words are an answer slot. If you wrote replies, guides or notes that others used, say what they were and who used them. If not, say so and say how you would show clear writing in this chat. |
| F4 | "confidence handling escalations" (your summary of the ad) | "I trained four new starters on our refunds process last year" (your message) | low | [inferred] | transferability | The refunds process is adjacent to escalations and does not reach them. The bridge stays at the quote's scope: "I trained four new starters on our refunds process last year." Answer slot: the ad raises escalations, so expect a probe. If you handled cases beyond your own remit, say what they were and what you did. If you did not, say so plainly and say how you would learn the escalation path. |

Not a row: your note "I've never worked for a software company" is not a requirement in the ad as you summarised it, but it is the objection most likely to come up. It is rehearsed as A2.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Configured or administered Freshdesk | Inflated form of F2 | "I use Freshdesk every day." Your material shows use, not setup. |
| Handled or led escalations | Inflated form of F4 | The F4 quote at its own scope. Your material shows refunds training, not escalation handling. |
| Designed or ran the refunds process | Inflated form of the refunds quote in F4 | "I trained four new starters on our refunds process last year." |
| Software-company experience | Contradicted by your own quote | "I've never worked for a software company." This is your plain acknowledgment, so it may be said as it stands. |

## Persona weights

| Persona | How it shows up in a chat | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: software background, escalations, written work | High, top weight. A hiring-manager prior, and the ad's requirements show two gaps in your material (F3, F4). | Rehearse A2 until it is routine. Open with the plain acknowledgment, then give a plan, not a past. |
| Case / Strategist | A support scenario typed into the chat | High, second weight. Team-lead chats often use a scenario. | Clarify the facts first, then structure the reply, then draft it. |
| Conversational | A casual opener and "tell me about yourself" | Medium. Casual openers are still scored. | Use the 60-second arc in C1 and use only quoted sentences. |
| Prober | Asks how a figure was counted | Low to medium. You gave one headline figure (around 60 calls and emails a day). | Rehearse D1 so the figure is defended in your own words. |
| Pressure | Time-boxed replies | Low. Chat rarely time-boxes. | Not rehearsed separately. |
| Values / Behavioural | Scored behavioural stories | Not detected: no values source was provided and no research was run. | Dropped from this pack. |

## Question banks

Weights: Skeptic top (4 questions), Case (3), Conversational (2), Prober (1). Ten questions in total is below the usual range. That is the honest cost of having no full job ad and no research, and the upgrade menu says what adding them would unlock.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "confidence handling escalations" (your summary of the ad) | Name the requirement you have least evidence for, which is escalations, in the ad's own terms. Answer slot: if you have handled cases you had to pass up or resolve beyond your own remit, say what they were and what you did. If you have not, say so plainly, then say how you would learn the escalation path in your first two weeks. | F4 is the thinnest row, and this question asks for it directly. |
| A2 | "I don't see software-company experience in your background. How would you handle that on day one?" | JD | [grounded] "I've never worked for a software company" (your message) | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I've never worked for a software company." Then give the plan, not a past: what you would learn first about their product from the tickets, and how you would check your understanding with the team lead. Hold through two follow-ups by returning to the plan. Never claim software experience. | The likeliest hard objection. Its premise is your own negative, so the acknowledgment has a source. |
| A3 | "Why move from energy supply to support for a software product?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | Answer with your real reason in your own words. Answer slot: your material gives no reason. If the reason is specific, say it in one or two sentences. If it is a general wish for different work, say that plainly. Do not invent a motive. | Motivation consistency is the Skeptic's core test. The reason is yours to supply. |
| A4 | "Tell me what you did with the refunds process you trained four people on." | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Story-map on the quote: you trained four new starters on the refunds process last year. Answer slot: if you wrote or changed any part of the process, say which part. If you only trained people on it, say so plainly and describe how you trained them. | The question presumes more than training. The second branch allows that it was not yours to change. |
| B1 | "A customer writes: 'I was charged twice and your last reply didn't help.' Reply in writing, then say what you would check first." | CASE | [generic] | In order: a short apology that names what went wrong with the last reply; confirm the double charge from the account; say what you will do and when the customer hears back; say what you would check first, which is the payment record. Keep it under 120 words. Promise no refund timing you cannot check. | A live problem from the ad's written-communication and escalation requirements. It claims nothing about your past. |
| B2 | "A ticket needs an engineer to fix a bug, and the customer is angry. What do you do?" | CASE | [generic] | Clarify the facts and reproduce what you can. Write an escalation summary complete enough that the engineer does not need to come back with questions. Tell the customer what happens next and when you will update them. Do not guess at a fix time. | Tests escalation judgement, the ad's least-evidenced requirement. No past is claimed. |
| B3 | "Explain a policy a customer will not like, in under 100 words." | JD | [grounded] "clear written communication" (your summary of the ad) | Give the decision first, then the reason in one line, then the next step. Use plain words and no jargon. Count your words before you send. | Tests the written-communication requirement directly, the row with no evidence (F3). In a typed interview, this reply is the evidence. |
| C1 | "So, tell me a bit about your background." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" (your message) | A 60-second arc in this order: the role and how long you did it, the daily volume, Freshdesk every day, the training. Stop there and let the next question be theirs. Use only these sentences. | A casual opener that is still scored. The arc is built only from quoted sentences. |
| C2 | "What tools do you use day to day, and what do you like about them?" | JD | [grounded] "I use Freshdesk every day" (your message) | Say you use Freshdesk every day, what you do in it, and one thing you find useful. Do not mention Zendesk experience. | Asks about the ad's ticketing requirement in a casual register. |
| D1 | "You mentioned around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Answer slot: say how you knew the number, in your own words (a log, a rota, an estimate). Say which part of the work was yours. Say plainly if it is an estimate you cannot source. Do not tighten the figure after the fact. | A figure you gave raises the defend-the-number slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. |

**Highest-ROI prep: A2.** It is the objection most likely to come up in some form, and a calm, plain answer changes the interview.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a first week look like for someone in this role, and which tools do they use?" | Shows you want to learn their stack. Their answer also tells you what the job really is. |
| R2 | "How do support and engineering work together when a bug needs a fix?" | Asks about the escalation process in their own terms. Shows you think about handoffs. |
| R3 | "What is the biggest support problem on the team right now?" | Asks for their current priorities and lets you show you listened. |
| R4 | "How do you judge a good reply? Is there a quality review?" | Puts the written-communication requirement to them directly. |
| R5 | "What are the next steps after this chat, and where will any offer or onboarding details be confirmed?" | Checks the process. Compare their answer with the careers page and the contact details there. |

## Sources

Provided documents: your message (the invite and your background) and your summary of the job ad. No search or fetch was run. The ad is a summary, so requirement quotes are your words.

Research tier: L0. Research was not run at delivery; the upgrade menu offers it.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Values cheat sheet. No values round is detected, so it is dropped here. |
| 2. Interview process for this role family | skipped | The invite already fixes the round: a text chat with the team lead. |
| 3. Lumenvale strategy / recent news | unavailable | Grounding brief and current-company CO questions. |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. |
| 5. Representative job ad | unavailable | Your summary is not the full posting. The full text would fix the fit snapshot's quotes. |

## Upgrade menu

- The full job ad text → the F rows quote the posting itself, and the JD-tagged questions use its exact wording
- The team lead's name → a tailored reverse question, and persona weights read from their public professional footprint only
- Whether the chat includes a written task or scenario → a coverage section for it
- Research at the L1 tier (six searches and two page fetches) on Lumenvale's values, interview process and strategy → a values cheat sheet and current-company questions
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and a sharper objection rehearsal
