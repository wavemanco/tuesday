# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Organisation:** Orrinsford Community School District
**Format:** 45-minute panel interview, Thursday
**Panel:** Principal Dolores Vantongeren (manager-level), two members of the fourth-grade team (peers)
**Built on:** the invite and your message. No job posting, no company research (not run for this pack; see Sources).

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **JD** = the invite's stated requirement. **EXP** = your past work, checked for accuracy. **CASE** = a live classroom problem. **VAL** = company values (none in hand, so none in this pack). **CO** = company knowledge (none in hand).
- Guidance is scaffolding, not a script. Speak it in your own words, in about 90 to 120 seconds.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. Say the license, its endorsement and its expiry, as your CV does. Keep your registration confirmation at hand. |
| F2 | "Fourth Grade Teacher position" (invite) | "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | medium | [grounded] | capability | Your words: "I haven't taught fourth grade." Then: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: say how you would learn the fourth-grade year, as a plan for the first months, not as something you have done. |
| F3 | [generic] Working as part of a grade-level team. The invite names a fourth-grade team on the panel but states no team requirement. | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [generic] | transferability | Your quote is the scope: "I led our grade level's move to a new reading curriculum in 2024." Any step past it is an answer slot: which decisions were yours and which were the team's. |
| F4 | [generic] Leading a team. Not stated in the invite; you raised it as a gap. | "I've never been a team lead" (your message) | high | [grounded] | capability | Your words: "I haven't been a team lead." Then the closest thing your material carries, at its own scope: "I led our grade level's move to a new reading curriculum in 2024." |
| F5 | [generic] Literacy support for students. | "I've run the after-school reading club for the last two years" (your CV) | medium | [generic] | presentation | Reword only that quote: "For the last two years I've run the after-school reading club." Add no outcome or result. |
| F6 | [generic] Communicating with families. | "I write a weekly email to families" (your CV) | medium | [generic] | none | No gap. Say what it is, in those words. |

Your material says the position is third grade to fourth grade, and that you have not led a team. It does not show student reading results, and it does not show whether families read the emails. The pack will not add either.

## Persona weights

| Persona | How it shows up in this panel | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Values / Behavioral | The principal asks for a past example | High | A principal on a panel usually opens with situational questions | Story-map F3 and F5; name what you did and stop |
| Skeptic | A fourth-grade team member or the principal probes the missing grade | High | F2 is the clearest gap in the file | Hold-then-concede on B1 (highest-ROI prep) |
| Peer Evaluator | Team members ask how you plan and teach | High | Panels with team members weight teaching practice | Use your own examples and stop at their edge |
| Data-Driven Prober | "How do you know it worked?" | Medium | Reading curriculum change invites a results question | Answer slot on D1; do not invent results |
| Case / Strategist | A classroom scenario | Medium | Panels for teachers usually include a live problem | Structure the answer; ask a clarifying question first |
| Rapport Builder | An opener about why you chose the role | Low to medium | Short panel, limited time | Keep to your own reasons |

## Question banks

Ordered by weight. Provenance holds every quote the guidance rests on.

### Principal (weight 3)

| ID | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about a time you led a change with colleagues." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Story-mapped on F3: the move and the year, in those words. Answer slot: which decisions were yours and which were the team's. If you made none of them, say so and describe your part. | F3 is the evidence for team work and the likeliest place to be probed. EXP because it tests what you did. |
| A2 | "How would you work with a grade-level team you are joining?" | JD | [generic] | Scaffold: describe how you would listen first, learn the team's shared plans, and ask what they need from a new colleague. Make no claim about past teams. | Team work is in the panel's composition. [generic] because the invite states no team requirement. |
| A3 | "How do you keep families informed during the year?" | EXP | [grounded] "I write a weekly email to families" (your CV) | Say what the weekly email covers, in those words. Answer slot: if you know how families respond, say so; if you do not, say that. | F6 is the evidence. EXP because it asks what you actually do. |
| A4 | "What is your plan for your first three months?" | JD | [generic] | Scaffold: learn the fourth-grade standards and the team's pacing, then the students. Name what you would ask before you change anything. | A plan question, so no past claim. |

### Skeptic (weight 3)

| ID | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't taught fourth grade. Why should we hire you for this position?" | JD | [grounded] "I've never taught fourth grade" (your message); [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | **Highest-ROI prep in this pack.** Hold: "I haven't taught fourth grade. For six years I taught third grade at a public elementary school in Joliet." Answer slot: say how you would learn the fourth-grade year, as a plan. Concede specifically: name the standards you would need to learn first. Hold through two follow-ups by returning to third grade. Do not add a fourth-grade claim to close the gap. | F2 is the biggest gap in the file and the most likely probe. The question's premise is your own sentence, so it is safe to rehearse. |
| B2 | "What would you do if the fourth-grade standards were a level you haven't taught before?" | CASE | [generic] | Structure: check the standards, find out what students already know, plan the first unit with the team. Make no claim about past work. | Follows from B1. A live problem with no past claim. |
| B3 | "Have you led a team of any kind?" | EXP | [grounded] "I've never been a team lead" (your message); [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Hold: "I haven't been a team lead." Then the closest thing you did, in your own words: "I led our grade level's move to a new reading curriculum in 2024." Do not call the move team leadership. | F4 is the second gap. The two quotes keep the gap and the nearest experience at their own scope. |

### Peer Evaluator (weight 4)

| ID | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk us through how you ran the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Story-map F5: two years, the club, in your words. Answer slot: which parts you set (schedule, materials, grouping) and which were given. If you set none of them, say so and describe what you did. | F5 is the evidence. EXP because the club is a concrete claim they can test. |
| C2 | "How do you plan a unit with a grade-level team?" | JD | [generic] | Scaffold: name what you would plan together and what each person owns. If you have planned with a team, say how. If you have not, say so and describe how you would start. | Team members will ask about planning. [generic] because no quote reaches it. |
| C3 | "A student in your group is behind in reading. What do you do in the first two weeks?" | CASE | [generic] | Structure: assess, group, set one goal, check weekly. Make no claim about a past student. | A live reading problem that fits the role. |
| C4 | "Two team members disagree about an intervention. How do you handle it?" | CASE | [generic] | Scaffold: listen to both views, go to the evidence, decide together, and say what you would do if the disagreement stays. | Tests team judgment, which F3 and F4 leave unanswered. |

### Data-driven prober (weight 2)

| ID | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you measure the effect of the reading curriculum change?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: if you measured anything, say what, when and with whom. If you did not measure it, say so and say what you would measure first. Do not describe a result. | F3 gives the move, not a measure. The question's premise is a result your material does not show. |
| D2 | "How do you know families read the weekly email?" | EXP | [grounded] "I write a weekly email to families" (your CV) | Answer slot: if you know how families respond, say how. If you do not, say so. | F6 gives the email, not a response. |

### Pressure / Rapport (weight 2)

| ID | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Your career so far is third grade. What makes you ready for this job?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Hold: the six years, then what you would bring from them. Concede the fourth-grade gap in one sentence. Hold through two follow-ups. | Pressure version of B1. Opens with your strongest fact. |
| E2 | "Tell us why you chose Halvering." | JD | [generic] | Scaffold: give your own reasons. Your material does not carry a fact about the school, so do not state one. | Rapport opener. [generic] because no supplied source names the school's reasons. |
| E3 | "Is your license the one this role needs?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | State the license, its endorsement and its expiry. No further claim. | F1 is the gate, and your material shows it met. |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Valid Illinois PEL with elementary endorsement (invite) | E3 |
| Fourth Grade Teacher position (invite) | B1, B2, E1 |
| Working as part of a grade-level team ([generic]) | A1, A2, C2, C4 |
| Leading a team ([generic], raised by you) | B3 |
| Literacy support for students ([generic]) | C1, C3, D1 |
| Communicating with families ([generic]) | A3, D2 |

## Prohibited claims

Built locally from the fit snapshot. None of the banks above asserts these.

| Not coached | Basis | Honest form |
|---|---|---|
| Fourth-grade teaching experience | Sourced entry: your own negative, "I've never taught fourth grade" | "I haven't taught fourth grade." No slot. |
| Experience as a team lead | Sourced entry: your own negative, "I've never been a team lead" | "I haven't been a team lead." No slot. |
| Leading the grade-level team | Inflated form of "I led our grade level's move to a new reading curriculum in 2024" | The quote at its own scope. Your material says you led a curriculum move, not the team. |
| Student reading results or gains | Inflated form of "I've run the after-school reading club for the last two years" | The quote only. The pack has no result to coach. |
| A family engagement program | Inflated form of "I write a weekly email to families" | The quote only. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does the fourth-grade team plan together each week, and where would a new teacher fit?" | Shows you want to join the team, not just the job |
| 2 | "What has the team found works best for students entering fourth grade?" | Asks about practice, which gives you a true answer to rehearse |
| 3 | "How does the team decide shared assessments, and who leads those conversations?" | Lets you see the team lead question from the inside |
| 4 | "What support does a new teacher get in learning the fourth-grade standards?" | Turns the gap into a question about support |
| 5 | "What would a good first semester look like for this role?" | Shows you are thinking about success, not only getting hired |
| 6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for the team members, who are peers |

## Sources

- Provided: the invite (quoted above); your message; your CV as stated in your message.
- Research: none run for this pack. Research tier: L0. Searches 0 of 0. Fetches 0 of 0.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Halvering or Orrinsford values | skipped | Values section, which is dropped without values in hand |
| 2. Fourth-grade panel interview process | skipped | Loop structure and persona weights |
| 3. District strategy or recent news | skipped | Company knowledge (CO) questions |
| 4. Principal Dolores Vantongeren public footprint | skipped | Interviewer read and a tailored reverse question |
| 5. Representative fourth-grade teacher posting | skipped | Requirements for the fit snapshot |

## Upgrade menu

- The job posting text → rows F3, F5 and F6 become [grounded], and the requirement list is sourced from the posting rather than the invite.
- Permission to run public research on the district and the principal → a values section, a district-specific reverse question, and persona weights from the principal's public footprint.
- Any sample lesson or task the panel announced → a graded-deliverable section built around it.
