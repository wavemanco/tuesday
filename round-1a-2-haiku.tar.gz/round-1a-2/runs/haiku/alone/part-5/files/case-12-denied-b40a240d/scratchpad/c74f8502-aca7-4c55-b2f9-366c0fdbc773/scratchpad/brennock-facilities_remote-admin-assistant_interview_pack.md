# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Candidate:** Aoife
**Round:** 30-minute video call
**Interviewer:** office manager (name not given). Relationship: manager-adjacent, not the hiring manager. Persona weights below are read from that.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what it is scoring.
- **Type key:** VAL = values/behaviour; EXP = your past work, tested for detail; JD = the listed duties; CO = company knowledge; CASE = a live problem.
- **Guidance is scaffolding, not a script.** Say it in your own words. Each answer should run about 90 to 120 seconds.

## Research tier

L0 (provided material only). No search or fetch was run for this pack. Company values, current strategy and the interview format are not verified, so anything about the company is `[generic]`.

## Fit snapshot

Requirements are quoted from your summary of the advert, not the full text. Evidence is quoted from your message.

| ID | Requirement (quoted from advert summary) | Your evidence (quoted) | Fit | Confidence | Gap type | Bridge (with its limit) | Provenance |
|---|---|---|---|---|---|---|---|
| F1 | "managing calendars" | "ran the appointment book for four physios" | adjacent | medium | transferability | Scheduling for four clinicians is the transferable case. The limit: it was one clinic's appointment book, not calendars for people outside it. | [grounded] |
| F2 | "booking travel" | none stated | absent | none | discovery | Your material does not show travel booking. Ask one question: did you ever book travel or logistics for anyone? | [grounded] |
| F3 | "preparing documents in Word and Excel" (Word) | "good with Word" | direct | medium | none | Word is a self-rating with no artifact yet. Say it as stated. | [grounded] |
| F4 | "preparing documents in Word and Excel" (Excel) | "okay with Excel" | adjacent | low | discovery | Excel is "okay", your own word. Do not upgrade it. Ask for one concrete example. | [grounded] |
| F5 | "processing supplier invoices" | "chased unpaid invoices" | adjacent | medium | transferability | Chasing payment is the transferable case. The limit: it is not shown that you entered, matched or approved supplier invoices. | [grounded] |
| F6 | Remote working terms (in the title, not the summary) | none stated | unclear | none | discovery | No remote-working terms were given. Ask the employer (see reverse question R4). | [grounded] |

## Prohibited list

Each entry is the stretched wording of something you said, with its honest form.

| ID | Claim not to coach | Basis | Honest form |
|---|---|---|---|
| P1 | "Advanced or formula-heavy Excel" | Inflated form of "okay with Excel" | "Okay with Excel", plus one real example |
| P2 | "I processed, approved or paid supplier invoices" | Inflated form of "chased unpaid invoices" | "I chased unpaid invoices", at that scope |
| P3 | "I booked travel" or "I managed executives' calendars" | Inflated form of "ran the appointment book for four physios" | "I ran the appointment book for four physios" |
| P4 | "Expert in Word" | Inflated form of "good with Word" | "Good with Word" |

## Question banks

Persona weights: **Conversational screen** 4 (the office manager opens with a friendly tone, but the questions are scored). **Skeptic** 3 (they will test the advert's duties against your CV). **Pressure** 2 (they will follow up on a weak answer).

### A. Conversational screen (weight 4)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about yourself and why this role." | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" | About 90 seconds: two years at the clinic, the appointment book, chasing invoices, why admin. Add no claims. | An opener. It sets the register for the rest of the call. |
| A2 | "How would you manage someone's calendar day to day?" | JD | [grounded] "ran the appointment book for four physios" | Describe how the book ran: who booked, how you handled clashes, how you dealt with changes. Say only what you did. If you did not handle clashes, do not claim it. | Managing calendars is the first duty listed in the advert. |
| A3 | "Have you booked travel for anyone? Tell me about it." | JD | [generic] (no candidate sentence covers this) | Selection scaffold: "Pick a time you arranged bookings or logistics for someone, if there was one. If there was not, say so plainly and name the first thing you would learn about the booking tools." | Travel booking is in the advert and absent from your material. This is the largest gap. |
| A4 | "How comfortable are you with Word and Excel?" | JD | [grounded] "good with Word"; "okay with Excel" | Word is "good". Excel is "okay". Give one concrete example of each that you actually did. Do not move "okay" up. | Documents are a listed duty, and this is a direct question about it. |
| A5 | "Tell me about a time a supplier invoice went wrong." | EXP | [grounded] "chased unpaid invoices" | Describe the chasing: who you contacted and how you followed up. Keep the scope to payment chasing. | Invoice processing is in the advert. Your material shows chasing, not processing. |
| A6 | "Why are you looking for a change from reception?" | EXP | [generic] (no candidate sentence covers this) | Give your own reason in one or two sentences. | Standard opener. Nothing in your material answers it. |

### B. Skeptic (weight 3)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | **(Highest-ROI prep)** "Your background is a clinic. Have you ever booked travel or handled logistics for people outside it?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" | Concede the limit first: "My background is a clinic's appointment book, not travel." Then bridge with F1 only, and say what you would learn first. If you have booked travel before, describe that instead. | The advert names travel and your material is silent on it. The interviewer will probably ask about the biggest gap, so this gets the most rehearsal. |
| B2 | "Have you ever entered, matched or approved supplier invoices?" | JD | [grounded] "chased unpaid invoices" | Answer slot: if you have entered or approved supplier invoices, describe what you did. If you only chased payment, say that and name the difference. | The advert names supplier invoices. Your material shows chasing, not processing. |
| B3 | "Excel is listed as a core skill. What is the most complex thing you have done in it?" | JD | [grounded] "okay with Excel" | Hold "okay". If you have built anything in Excel, describe it. If not, say your level plainly and what you would learn first. | The Skeptic tests whether a self-rating survives a follow-up. |
| B4 | "Talk me through how you would prepare a supplier-payment document in Word." | CASE | [grounded] "good with Word" | Describe the structure: template, sections, figures, a check before sending. Do not invent experience. | A live problem from the advert's document duty. |

### C. Pressure (weight 2)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "People who say they're good with Word and Excel often struggle under deadline. Is that you?" | JD | [grounded] "good with Word"; "okay with Excel" | Hold the Word rating. Concede Excel plainly: "okay, and I would tell you if it were more." Name the document you would be most confident producing. | A hold-then-concede test. A held rating you cannot back is what the second follow-up breaks. |
| C2 | "You chased invoices. Did you ever escalate one to someone above you?" | EXP | [grounded] "chased unpaid invoices" | Answer slot: if you escalated, say to whom and why. If you did not, say what you did instead. | The follow-up tests whether "chased" means more than a reminder email. |

**Coverage:** 12 questions. This is under the usual range because the full advert text was not supplied. Coverage will grow once it is.

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| Managing calendars | A1, A2 |
| Booking travel | A3, B1 |
| Preparing documents in Word and Excel | A4, B3, B4, C1 |
| Processing supplier invoices | A5, B2, C2 |
| Remote working terms | none, and why: the advert summary gives no terms. Reverse question R4 covers it. |

## Reverse questions

| ID | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like for the office manager and the admin team?" | Shows you are picturing the job, not only the offer. |
| R2 | "Which tools do you use for calendars and travel bookings?" | Names the tools you would need to learn, and exposes any gap early. |
| R3 | "How do supplier invoices move from receipt to payment, and who approves them?" | Shows real interest in the invoice process, which is a listed duty. |
| R4 | "How is remote working set up, and does the company provide equipment?" | Asks about the exact point the invite raised. The answer tells you what is normal for this employer. |
| R5 | "What are the next steps after this call, and how would I be contacted?" | Shows you care about process, and gives you a way to check the employer's account of the hiring steps. |

## Delivery coaching

Not included. No working-style assessment was provided.

## Upgrade menu

- The full advert text → requirement rows quote the advert rather than your summary, and the question bank grows toward the usual range.
- The interviewer's name → a tailored reverse question, and persona weights from their public footprint.
- Examples of your Excel and Word work (a file, or a short description) → F3 and F4 gain evidence and can move up a band.
- Permission to run web research (L1) → company values and current strategy replace `[generic]` rows.
- `tuesday-dossier.md` → would record the gaps this prep exposed (travel, supplier invoices) for later sessions.
