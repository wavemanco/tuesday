# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

**Role:** Operations Coordinator, Quillmoor Diagnostics (Avonmouth, Bristol; hybrid, two days a week on site)
**Round:** 30-minute phone recruiter screen, Thursday 2pm, with Hannah Lowther (Talent Partner). Hannah's stated agenda: salary expectations, notice period, hybrid pattern, reason for moving; then the team and next steps.
**Relationship:** recruiter screen. Sections for interviewer read, values, deliverables, and delivery coaching are dropped because no inputs support them.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored: **JD** (the advert's requirements and terms), **EXP** (your record), **CASE** (a live problem), **CO** (company knowledge), **VAL** (values). The guidance is scaffolding for a spoken answer, not a script. Say it in your own words.

## Fit snapshot

Quotes come from your message or the advert. Nothing here is from a CV.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | No gap. Say it as written. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | high | [grounded] | none | Your words reach the requirement directly. Say them as they stand. |
| F3 | "coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material shows delivery scheduling for depots, not production scheduling across planning, warehouse and QA. Answer slot: the advert's planning, warehouse and QA line makes a probe on production scheduling likely. If you coordinated across teams whose schedules had to fit together, say how. If your scheduling was only deliveries, say so and say how you would learn the production side. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | high | [grounded] | presentation | Your sentence says the rebuild came with a fall in discrepancies of about a third over a year. Keep "about", "over a year" and "rebuilt". Your sentence does not say the rebuild alone caused the fall. |
| F5 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | Your material shows a spreadsheet, not the program or your level in it. Answer slot: if it was Excel, say what you built in it, in your own words. If it was another program, say which and what it could do. Do not claim a skill level you have not stated. |
| F6 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | none | [grounded] | capability | Words: "I've never used SAP." Then describe the in-house stock system in your own words. The pack does not call it an ERP. |
| F7 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Answer slot: if you produced any regular figure on deliveries or stock, say what it covered and who received it. If you didn't, say so and say how you would start. |
| F8 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your figure sits inside the band. Fills the pay slot (A1). |
| F9 | "two days a week at our Avonmouth site" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Fits the stated pattern. Your limit is three. |

**Gap types in plain terms:** F3 and F5 need honest answers you have to supply. F6 is a stated gap, and the honest line is the plain acknowledgment above. F7 has nothing in your material, so the answer is what you actually did, even if that is nothing.

## Prohibited claims

Do not say any of these in the call. Each one goes further than what you actually told me.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have production scheduling experience" | Inflated form of F2 and F3 | "I schedule deliveries for our three depots." Your material shows delivery scheduling, not production scheduling. |
| "I have ERP or SAP experience," or "our in-house system is an ERP" | Stated negative (F6) plus an inflated form | "I've never used SAP." Describe the in-house system in your words, without the label. |
| "I'm confident with Excel" | Inflated form of F5 | "I rebuilt our stock-count spreadsheet." Your level is an answer slot (B3). |
| "I cut discrepancies by a third," or "the rebuild caused the drop" | Inflated form of F4 | "Discrepancies fell by about a third over a year." |

## Personas

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / logistics checker (recruiter-screen prior) | Pay, notice, location, reason, and an opener | High. The recruiter has named these four topics as her agenda. | Answer each logistics slot in your own words. Decide your pay answer before the call. |
| Light skeptic | SAP, production scheduling, Excel, late orders | High. The advert names these gaps and your message states the SAP one. | Plain acknowledgment first, then the nearest thing you actually did. |
| Light data prober | Weekly reporting, the stock figure | Moderate. The stock figure is the one number on your record. | Name what it counted and the assumption you would defend least. |

Weights: conversational 5 questions, skeptic 4, prober 1. The screen is 30 minutes, so the pack is short on purpose.

## Question banks

**A. Conversational / logistics (recruiter screen)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations?" | JD (pay) | [grounded] "I'm hoping for £42,000." (your message) | Say: "I'm looking for £42,000." Your figure is inside the advert's band. If you'd rather hear the band first, say: "Could you tell me where the band sits for this role?" Pick one before the call. The pack gives no other figure. | Pay is a first knockout in a recruiter screen, and the band is the role's own term. Fills F8. |
| A2 | "What's your notice period?" | JD (notice) | [grounded] none given; your message does not state one | Give your actual notice period in one sentence. Check your contract before the call. The pack supplies no figure. | A knockout check. The number is yours; this slot is an instruction, not a figure. |
| A3 | "Two days a week at Avonmouth. Does that work for you?" | JD (location) | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | Say: "Two days works for me. Three is the most I'd want." | The hybrid pattern is the advert's term. Your limit is stated, so the answer is yours. Fills F9. |
| A4 | "What's prompting the move?" | EXP (reason) | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | Say: "Our Bristol office is closing next year, and the only offer is relocating to Reading, which I don't want to do." Answer slot: if you want to add what you're looking for next, say it in your own words. If nothing comes to mind, say so plainly and stay with the closure. | Hannah asked directly. The closure is a true, neutral reason. Don't describe it as your choice, and don't invent a positive reason. |
| A5 | "Tell me about yourself." | EXP (open prompt) | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message); "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message); "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | 60–90 seconds: the four years, then the depot deliveries and supplier chasing, then the stock-count rebuild with the figure as worded. Stop there. | The opener sets the scored record. Nothing beyond these sentences. |

**B. Light skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role lists SAP or similar as a plus. What's your ERP experience?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" (your message) | Say: "I've never used SAP." Then describe the in-house stock system: what it holds and what you do in it. Answer slot: if it does what an ERP does for stock, say which parts. If it doesn't, say so. | Your highest-ROI prep. The advert says "a plus", so it is not a knockout, but the question is near-certain. The honest answer is the plain acknowledgment plus your system. |
| B2 | "This role coordinates production schedules across planning, the warehouse and QA. Your background is deliveries. How would you handle it?" | CASE | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | Structure: what you'd ask planning, the warehouse and QA first; how you'd check the schedule against supplier dates; how you'd tell the team when something slipped. Use your delivery scheduling as the evidence. Answer slot: if you have coordinated across teams whose schedules had to fit together, say how. If not, say so and say how you'd learn the production side. | The advert's first duty is production scheduling, so the probe lands here. The answer is a plan, and your experience stays in delivery scheduling. |
| B3 | "The advert wants you confident with Excel. What did you build the stock-count spreadsheet in, and what can it do?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | Say you rebuilt it, what it covers, and the figure as worded. Answer slot: name the program and what you used in it. Weakest-assumption move: name the assumption you'd defend least. The figure covers a year, so say what else you'd check before crediting the rebuild alone. If you didn't check, say so. | The spreadsheet is your only Excel-adjacent evidence. The question tests whether "confident with Excel" holds, and the figure is defended in its own terms. |
| B4 | "A supplier's order is three days late for a production run. What do you do?" | CASE | [grounded] "chase suppliers when orders slip" (your message) | Structure: confirm the new date with the supplier, tell planning and the warehouse what the date means for the run, and report the slip in the weekly figures. Use your own language. Don't claim a production run you haven't run. | A live problem from the advert's late-order line. The plan is yours to build; your experience is the one quoted sentence. |

**C. Light data prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The role reports weekly on on-time dispatch. Have you produced a regular figure like that?" | JD | [grounded] none given; your message does not say | Answer slot: if you produced any regular figure on deliveries or stock, say what it covered and who received it. If you didn't, say so plainly and say how you'd start. | The advert's weekly report has no quote behind it, so the honest answer is the only one. Any figure you give invites a follow-up on how it was counted. |

**Coverage line**

| Requirement | Covered by |
|---|---|
| 2+ years logistics coordination | A5 |
| Confident with Excel | B3 |
| ERP (SAP or similar) a plus | B1 |
| Production schedules across planning, warehouse, QA | B2 |
| Track supplier deliveries, chase late orders | A5, B4 |
| Keep stock records accurate | B3 |
| Weekly on-time dispatch report | C1 |
| £38,000–£44,000 | A1 |
| Hybrid, two days at Avonmouth | A3 |
| Pay, notice, location, reason | A1 to A4 |

## Reverse questions

Ask two or three of these at the end. Each one lands for a reason.

- **"What does a normal week look like in this role?"** It shows you are thinking about the job, not only the offer.
- **"How do planning, the warehouse and QA share the production schedule day to day?"** It uses the advert's three-way line, so the question reads as informed.
- **"What stock system does Quillmoor use for stock records, and how are discrepancies tracked?"** It opens the SAP question on your terms.
- **"What's the band for this role, and where would someone at my level usually sit?"** It is the question to ask first if you'd rather not name a figure.
- **"Which days does the team usually come into Avonmouth?"** It tests the hybrid pattern before you commit.
- **"What happens after this call, and what's the timeline?"** Next steps are the part Hannah said she'd cover.

## Sources

Research tier: L0 for this pack. Two web searches were attempted and the tool was refused permission, so the pack uses only your message, the advert and Hannah's message.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | unavailable | Values cheat sheet, which is dropped because no values round was detected |
| 2. Quillmoor interview process | unavailable | Would have shown whether the screen covers more than the four logistics topics |
| 3. Quillmoor strategy / recent news | unavailable | Would have added one current-context line for the team and next-steps part of the call |
| 4. Hannah Lowther public footprint | unavailable | Would have informed the reverse questions; a Talent Partner's public profile is low-yield for a screen |
| 5. Representative JD | skipped | The advert you supplied fixes the fit snapshot |

## Upgrade menu

- **Your notice period** → A2 gets your figure in your own words.
- **The program the stock-count spreadsheet ran in** → B3 and F5 get a specific answer instead of a slot.
- **One sentence on what the in-house stock system does** → B1 gets your own description.
- **Any regular figure you track on deliveries or stock** → C1 becomes a defend-the-number question you can rehearse.
- **Your CV** → the quotes in the fit snapshot can be checked against its wording.
- **Web research, once search permission is granted** → one values line and one current-news line, if the screen covers them.
