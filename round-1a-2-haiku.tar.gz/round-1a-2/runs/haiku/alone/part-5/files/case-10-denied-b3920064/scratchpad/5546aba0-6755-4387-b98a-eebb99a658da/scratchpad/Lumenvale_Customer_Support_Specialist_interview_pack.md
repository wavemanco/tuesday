# Interview prep: Customer Support Specialist, Lumenvale Software

- **Role:** Customer Support Specialist (remote)
- **Company:** Lumenvale Software (not verified; see Sources)
- **Interviewer:** support team lead (name not given)
- **Round:** text-chat interview on Telegram. Built as a hiring-manager-type round, since the team lead will be assessing day-to-day fit.

## How to use + type key

Personas = how the question is asked. Types = what is being scored.

- **JD**: the job ad's own requirement
- **EXP**: your past work, and whether it holds up when probed
- **CASE**: a live support problem, scored on structure
- **VAL**: values (not detected for this round)
- **CO**: company knowledge (not researched)

Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your message) | "3 years as a customer service advisor at an energy supplier" (your message) | high | [grounded] | none | No gap. Your role is customer service advisor, which is the ad's customer support. Say that link in your own words. |
| F2 | "experience with Zendesk or a similar ticketing tool" (your message) | "I use Freshdesk every day" (your message) | high | [grounded] | presentation | Your material says Freshdesk, not Zendesk. Bridge: "I use Freshdesk every day." Add no Zendesk claim. |
| F3 | "clear written communication" (your message) | none given | none | [grounded] | discovery | Your material does not show written communication yet. Answer slot: if you have written customer replies you are proud of, name one and what made it clear. If not, say so plainly and say how you would write to an upset customer in chat. |
| F4 | "confidence handling escalations" (your message) | none given | none | [grounded] | discovery | Your material does not show escalations handled. Answer slot: if you have handled an escalation, say what it was and what you did, in your own words. If not, say so plainly and say how you would recognise one and where it goes. |
| F5 | Software background (not in the ad; likely objection) | "I've never worked for a software company" (your message) | none | [grounded] | capability | Words: "I haven't worked for a software company." Then the bridge at its own scope: "What I have is three years as a customer service advisor at an energy supplier." |

Gap types follow the routing rule. F2 is presentation because Freshdesk is a similar tool and the quote already reaches the requirement in other terms. F3 and F4 are discovery because the material is silent, so their words are answer slots, not claims. F5 is capability because you stated the absence yourself.

## Prohibited claims

Not coached, and why:

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2. The ad names Zendesk; you named only Freshdesk. | "I use Freshdesk every day." |
| Managed the refunds process | Inflated form of your refunds quote. You trained others on it. | "I trained four new starters on our refunds process last year." |
| Has worked for a software company | Stated negative (F5) | "I haven't worked for a software company." |

## Persona table

| Persona | How it shows up | Likelihood, and why | Counter-strategy | Depth |
|---|---|---|---|---|
| Case / Strategist | Live support problems from the role | High. A support team lead usually tests live handling. | Clarify, act, then tell the customer what happens next. | 5 |
| Skeptic | Probes your two stated gaps: software, and escalations | High. F4 and F5 are the obvious objections. | Rehearse the escalation answer until it is steady. Use a plain acknowledgment, not a bluff. | 4 |
| Pressure | Time-boxed challenge in chat | Medium. Text limits tone, but a timed reply is still a test. | Pause, restate, hold two follow-ups, then concede the specific point. | 3 |
| Conversational | Friendly opener, casual questions | Medium. Chat openers are often scored too. | A 90-second arc. Treat casual questions about Freshdesk as scored. | 3 |

Weights are the relationship prior (hiring manager: Case and Skeptic up), with no interviewer profile and no loop source to adjust them.

## Question banks

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in: the refund you promised two weeks ago hasn't arrived, and they want it today. What are your first three moves?" | CASE | [generic]. The ad's "confidence handling escalations" is the raising source. | Clarify what was promised and when. Check the refund's status before replying. Tell the customer what you can confirm and when they will hear next. If you cannot resolve it, say who you would escalate to. | A live problem from the ad's escalation line. It makes no claim about your past. |
| A2 | "Our team works in Zendesk. What's your experience with tools like that, and how would you get up to speed?" | JD | [grounded] "I use Freshdesk every day" (your message); the ad's "Zendesk or a similar ticketing tool" | Lead with the Freshdesk quote in your words. For Zendesk, say plainly whether you have used it, then give a ramp plan as a plan, not a past. Answer slot: if you have used Zendesk, say when and for what. If not, say so and say how you would learn it. | F2 is the requirement's nearest evidence, and this question tests the gap without assuming it. |
| A3 | "What's the hardest contact you've had with a customer, and how did you handle it?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Selection: pick a difficult contact from a normal week. Say what the customer wanted, what you did, and how it ended. If none comes to mind, say so and give the nearest one. | The volume figure is your only past-work quote here. The question does not presuppose any particular case. |
| A4 | "Your 60-a-day figure: how was it counted, and which part was yours?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Defend the number. Say how you know the count, in your own words. Name, in your own words, the assumption behind it you would defend least. Say which part was yours. If you don't know how it was counted, say so. | A figure you gave raises the defend-the-number slots. This is where a prober goes first. |
| A5 | "A refund request falls outside policy, but the customer's situation looks like an exception. What do you do?" | CASE | [generic] | Clarify what the policy says and what the exception route is. Check whether someone with authority can approve. Decide what you can say now and when you will update the customer. | A live problem on refunds. It makes no claim about your past. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. Why should we expect you to do well here?" | JD | [grounded] "I've never worked for a software company" (your message) | Plain acknowledgment: "I haven't worked for a software company." Then bridge at the quote's own scope: "What I've done is three years as a customer service advisor at an energy supplier." Claim no software work. | F5 is the most likely objection. The acknowledgment is yours, so you can say it. |
| B2 | "Tell me about a time a customer wouldn't accept your answer, and what you did next." | JD | [generic]. The ad's "confidence handling escalations" is the raising source. Also [grounded] "answering around 60 calls and emails a day" (your message) | Highest-ROI prep in this pack. Pick a case where a customer pushed back: what they wanted, what you said, what you did next, how it ended. If none comes to mind, say so plainly, then give the nearest contact from your normal week, or how you would handle it. Hold through two follow-ups by returning to what the customer asked. Concede what you could not fix. | F4 is the weakest point of the fit, and this is the objection the ad's escalation line will produce. Rehearse it until a plain answer comes easily. |
| B3 | "Chat support lives on writing. Show me a message you've written that you're proud of." | JD | [grounded] "clear written communication" (the ad) | Answer slot: name a written customer reply you're proud of and what made it clear. If none comes to mind, say so plainly, then describe how you would write a reply to an upset customer in a chat window. | F3 is discovery, not a claim. A plain answer beats an invented sample. |
| B4 | "Why leave energy for a remote support role?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | Give your real reason, in your own words. The material does not state one, so this is yours to supply. Do not borrow a reason from the ad. | A motivation probe. The answer must be consistent with what you have said above. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over someone with Zendesk and two years in support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day" (your message) | Pause and restate the question. Anchor in the two quotes: three years, and Freshdesk daily. Hold through two follow-ups. If pressed on Zendesk, concede that specific point. | A stress test of composure. The hold is only what your quotes carry. |
| C2 | "That 60-a-day figure: how much of it was actually you?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Hold: say what you answered, in your own words. Concede that volume is not quality, specifically. Hold through two follow-ups. | A probe that tests whether volume is being passed off as skill. |
| C3 | "What's the weakest part of your background for this job? You have one answer." | JD | [generic] | Pause. Name one weakness, then say what you would do about it. Use F4 or F5 as the honest choice. | A timed question to test composure with a gap. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey from energy to here." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | A 90-second arc: the role, the work, the tool you use, and why this now, in your own words. | An opener that is scored. Treat it as a short interview answer. |
| D2 | "What are you actually using in Freshdesk these days?" | JD | [grounded] "I use Freshdesk every day" (your message) | Name the features you use day to day. Answer slot: if you use features beyond the basic queue, name them. If you only work the queue, say so plainly. | A friendly way to test the Freshdesk claim. |
| D3 | "What's the refunds process like, and how did you teach it?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Describe the process and how you taught it: who you trained and what you walked them through. | Your strongest concrete story. Keep it at the scope of the quote: you trained others. |

Total: 15 questions. That is below the roughly 18 floor, because the ad was summarised rather than pasted and no research ran. Adding the full ad would likely add rows.

## Requirement coverage

| Stated requirement | Covered by |
|---|---|
| 2+ years in customer support | D1 (evidence in F1). None needed beyond the arc. |
| Zendesk or a similar ticketing tool | A2, D2 |
| Clear written communication | B3 (F3 is discovery) |
| Confidence handling escalations | A1, B2 (F4 is discovery) |

## Reverse questions

1. "What does a typical week look like for someone in this role?" Why it lands: shows you want the real job, not the title.
2. "Which ticketing tool does the team use day to day, and how is someone trained on it?" Why it lands: asks about the Zendesk gap directly.
3. "How are escalations handed on, and to whom?" Why it lands: connects to the ad's escalation line and tests how the team works.
4. "What would success look like at the end of the first 90 days?" Why it lands: concrete targets, not a vague welcome.
5. "Who issues the offer and the start paperwork, and what is the company's official contact for them?" Why it lands: a clear answer lets you check the process outside this chat.

## Sources

Research tier: L1. Searches 0 of 6 used (both refused). Fetches 0 of 2 used.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Values page would have themed a values round. No values round is detected, so section 10 is dropped. |
| 2. Lumenvale interview process, customer support | unavailable | Would have named the loop. The pack assumes one text-chat session with the team lead. |
| 3. Lumenvale strategy / recent news | unavailable | Would have fed CO questions. None are in this pack. |
| 4. Interviewer name + Lumenvale | n/a | No name was given, so there was no query to form. |
| 5. Representative Customer Support Specialist JD | unavailable | Full JD text was not pasted. The pack relies on your summary of the ad. |

Queries sent, both refused: "Lumenvale Software company careers" (targets 1 and 2); "Lumenvale Software recruiter Telegram job scam" (outside the declared targets).

Provided documents: your message (the invite, the ad summary, your background). No dossier was present.

## Upgrade menu

- The full job ad text → rows F1 to F4 re-quoted verbatim, and the requirements no longer rest on your summary.
- The interviewer's name → a tailored reverse question and persona weights from their public footprint.
- Research, once you can run it → the company's values, loop and recent news, which would add a values section and CO questions.
- A `tuesday-dossier.md` → would record the gaps this prep exposed (escalations, Zendesk, software) for later sessions.
