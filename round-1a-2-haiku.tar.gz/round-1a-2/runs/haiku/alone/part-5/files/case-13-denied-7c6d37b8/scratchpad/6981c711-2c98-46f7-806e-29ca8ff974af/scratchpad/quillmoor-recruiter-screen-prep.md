# Recruiter screen prep: Operations Coordinator, Quillmoor Diagnostics

**Call:** Thursday 2pm, 30 minutes, by phone to the mobile on your application, with Hannah Lowther (Talent Partner).
**Built on:** the advert and your background as you described it. No web research was run; nothing here about Quillmoor's culture, values or interview loop is verified.

## Fit snapshot

| JD requirement | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| 2+ years ops or logistics coordination | "4 years as a logistics coordinator at a building-supplies wholesaler." | High | None | — |
| Track supplier deliveries, chase late orders | "I schedule deliveries for our three depots and chase suppliers when orders slip." | High | None | — |
| Keep stock records accurate | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | High | None | — |
| Coordinate production schedules across planning, warehouse and QA | Scheduling is delivery scheduling across three depots; no production or QA work is stated. | Low | Adjacent experience | "I haven't scheduled production, but I do schedule deliveries across three depots, so I'm used to balancing several sites' timings." |
| Weekly on-time dispatch report | Not stated. | Unknown | Gap (no evidence either way) | Answer slot: see question 3 below. |
| Confident with Excel | "I rebuilt our stock-count spreadsheet." Your level is not stated. | Medium | Unverified level | Answer slot: see question 2 below. |
| ERP (SAP or similar), a plus | "Never used SAP — we run our own in-house stock system." | High | Gap (stated) | "I haven't used SAP. I've worked on our in-house stock system, and I'd want to learn the ERP side properly." |
| Diagnostics or regulated manufacturing | Not stated. | Unknown | Gap (no evidence) | Say so plainly; do not invent a bridge. |

## Prohibited claims (built locally)

- Any SAP or ERP experience, including "familiar with" or "working knowledge of".
- Production planning, QA or regulated-manufacturing experience.
- Weekly dispatch or on-time reporting, unless you have actually done it.
- The one-third reduction credited to you alone. Say it fell "over the year after I rebuilt the sheet".
- An Excel skill level you cannot show (for example, "advanced") unless you can demonstrate it.
- A notice period you have not checked against your contract.

## Persona

A recruiter screen is a Talent Partner checking fit, pay, logistics and motivation. Expect a warm, structured call. The priorities are pay and hybrid terms first, then basic requirements, then why you're moving. Team and next steps come last.

## Question bank: recruiter screen

**1. Tell me about your current role.** *Type: experience.*
- Provenance: quoted sentences 1, 2 and 3 from the fit snapshot.
- Guidance: a 60-second version in this order: role and length, depot scheduling, supplier chasing, the stock-count work. Keep each claim to what you did.

**2. How comfortable are you with Excel?** *Type: skills (answer slot).*
- Provenance: answer slot. You have not stated your level.
- Guidance: give the true level and one concrete example, such as the rebuilt stock-count sheet. If your level is basic-to-solid, say that. Don't use "advanced" unless you can show it.

**3. Have you produced regular performance or dispatch reports?** *Type: skills (answer slot).*
- Provenance: answer slot. Not stated in your material.
- Guidance: if no, say so and link to the nearest real thing, such as the discrepancy tracking on the stock sheet. Do not claim dispatch reporting.

**4. Do you have SAP or ERP experience?** *Type: skeptic.*
- Provenance: quoted sentence "Never used SAP — we run our own in-house stock system."
- Guidance: answer directly: no SAP, an in-house stock system, and a willingness to learn. The role lists it as a plus, so this is not a blocker to name.

**5. Tell me about the stock-count spreadsheet.** *Type: achievement.*
- Provenance: quoted sentence "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year."
- Guidance: say what you built and what changed, and be clear about the timescale. Don't claim the whole result alone.

**6. What's your salary expectation?** *Type: pay.*
- Provenance: stated position, "hoping for £42,000."
- Guidance: the advert range is £38,000–£44,000, so £42,000 sits in the upper half. Say "around £42,000" and ask what the range is for the role. Don't go above £44,000 without knowing the full package.

**7. What's your notice period?** *Type: logistics (answer slot).*
- Provenance: answer slot. Not yet given.
- Guidance: check your contract before the call and give the exact figure.

**8. How would the hybrid pattern work for you?** *Type: logistics.*
- Provenance: stated, "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three."
- Guidance: give that answer as it stands. Don't stretch to three without reason.

**9. What's prompting the move?** *Type: motivation.*
- Provenance: stated, "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want."
- Guidance: keep it factual and brief. Don't criticise the employer. End on what you're looking for: a role in Bristol with the scope you have now.

## Reverse questions for Hannah

1. What does a typical week look like across planning, the warehouse and QA?
2. How is on-time dispatch reporting done at the moment, and who owns it?
3. Who would I report to, and how big is the team?
4. What are the next steps and rough timing after this call?
5. How does the hybrid pattern work at Avonmouth day to day?

## Upgrade menu

- Notice period and contract figure (question 7 above).
- Your Excel level and what you did in the spreadsheet (question 2).
- Any production, QA or reporting experience, even small (question 3).
- Deep research on Quillmoor's values, strategy and interview process: available on request, time cost stated first.
- A dossier from job-underwriter, if you have one, would sharpen the pack.
