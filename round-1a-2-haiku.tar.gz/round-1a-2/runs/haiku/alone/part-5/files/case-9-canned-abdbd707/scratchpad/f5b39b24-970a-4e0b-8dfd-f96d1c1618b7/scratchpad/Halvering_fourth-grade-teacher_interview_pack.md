# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Candidate:** Grace
**Organisation:** Halvering Elementary School, Orrinsford Community School District
**Format:** 45-minute panel on Thursday
**Panel:** Principal Dolores Vantongeren, plus two members of the fourth-grade team (names not given)
**Built on:** the invite and your CV and message. No job posting and no research were used, so this pack runs at the L0 tier.

## 1. How to use this pack

- **Personas** describe how a question will arrive. **Types** describe what is being scored.
- Type key: **VAL** behavioural/values; **EXP** your work-experience claims; **JD** the role's stated requirements; **CO** company knowledge (none in this pack, because nothing was researched); **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words.
- Every answer slot is an instruction for the interview. It is not a question to me, and it asks you to answer from what you actually did.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — invite (HR) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | high | [grounded] | none | Met on your stated license. Say it plainly: "I hold an Illinois Professional Educator License with an elementary endorsement, active through June 30, 2029." Check the status on the state's lookup before Thursday. That check is yours to make; this pack does not verify it. |
| F2 | "the Fourth Grade Teacher position" — invite (HR) | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your message | low | [grounded] | capability | This is the largest gap, and it is one you stated. Words: "I've taught third grade for six years, and I haven't taught fourth grade." Then a plan, not a past: how you would learn the fourth-grade content, pacing and routines in the first weeks. Never describe fourth-grade teaching you have not done. |
| F3 | "two members of our fourth-grade team" — invite (HR) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [grounded] | capability | The invite does not ask for a team lead; the panel includes team members, so the question may come up. Words: "I led our grade level's move to a new reading curriculum in 2024. I haven't been a team lead." The material shows a curriculum move you led. It does not show a team you managed. Do not stretch "led the move" into "led the team". |
| F4 | "[generic] reading instruction beyond the classroom" — role family, no quote | "I've run the after-school reading club for the last two years" — your CV | medium | [generic] | transferability | The club is after school, not a classroom block. Say that yourself: "I've run the after-school reading club for the last two years." Any claim about in-class reading results is not in your material. |
| F5 | "[generic] communication with families" — role family, no quote | "I write a weekly email to families" — your CV | medium | [generic] | presentation | The email shows the habit; it does not show outcomes. Quote the habit and stop there. |

**Pack observations (analysis, not words for you):**
- Your material does not show any figure, measure or result for the reading curriculum move or the reading club.
- Your material does not show a team you managed.
- Your material does not show any fourth-grade teaching.

## 3. Prohibited claims

These are claims the pack will not coach, because your material does not support them.

| Not coached | Basis | Honest form |
|---|---|---|
| Taught fourth grade | Negative you stated in your message | "I haven't taught fourth grade." Plain acknowledgment, with no slot. |
| Have been a team lead | Negative you stated in your message | "I haven't been a team lead." Plain acknowledgment, with no slot. |
| Led the grade level | Inflated form of "I led our grade level's move to a new reading curriculum in 2024" | The quote at its own scope: you led the curriculum move. The limit is the pack's observation: the material shows a move, not leadership of the grade level. |
| Measured the curriculum's effect on reading scores | Inflated form of the curriculum sentence; the material names no measure | The quote at its own scope. Questions about measurement get an answer slot (see D2), not a claim. |

## 4. Persona table

Panel rule: the principal carries the hiring-manager priors; each team member carries the peer priors. Team members are not named in the invite, so the blend is across the panel.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the fourth-grade gap and the team-lead gap | **High.** The principal is hiring a fourth-grade teacher, and the two gaps are visible in your own message. Weighted 4 (A1–A4). | Rehearse the gap until it is boring: state it, bridge only from what you did, then give a plan. |
| Case / Strategist | A live fourth-grade or classroom problem | **Medium-high.** Hiring-manager panels usually include a scenario. Weighted 3 (B1–B3). | Clarify first, then structure: assess, group, intervene, families. |
| Peer Evaluator | Seams with fourth-grade colleagues; disagreement | **Medium.** The team members will judge whether you can work beside them. Weighted 3 (C1–C3). | Offer what you bring from third grade and ask what the team needs. |
| Data-Driven Prober | Asks how the reading club or curriculum move was measured | **Medium.** Team members who teach reading will ask how you know it worked. Weighted 2 (D1–D2). | Say what you tracked. If you tracked nothing, say so. |
| Values / Behavioural | "Tell me about a time…" | **Medium.** No school values were supplied, so these are open prompts with selection scaffolds. Weighted 2 (E1–E2). | Choose your own example. Use "we" for context and "I" for what you did. |
| Conversational | Opening biography; "what do you enjoy" | **Low-medium.** Casual openers are still scored. Weighted 2 (F1–F2). | Have a 90-second arc ready. |
| Pressure | "Why you over a candidate who has taught fourth grade?" | **Low-medium.** Weighted 2 (G1–G2). | Hold the position through two follow-ups, then concede the specific gap. |

**Total:** 18 questions, which sits within the 18–26 range.

## 5. Question banks

### Skeptic (principal), weighted 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see fourth grade in your background. How would you handle that on day one?" | JD | [grounded] "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet" — your CV | Say the fact first: "I haven't taught fourth grade." Then what you have taught: "I've taught third grade for six years." Then a plan for the first two weeks: the fourth-grade standards, the pacing guide, the team's routines. Use "I'd learn" for anything you have not done. | F2 is the largest gap and the likeliest probe. |
| A2 | "Why should we hire a third-grade teacher for a fourth-grade position?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV | **Highest-ROI prep in this pack.** Hold: six years of elementary teaching is the quote, at its own scope. Concede specifically: "I haven't taught fourth grade, and that is the real gap." Then what you would do about it. Hold through two follow-ups by returning to the six years, never by adding to them. | F2 is the objection most likely to come from the principal. Rehearse until the concession comes out calmly. |
| A3 | "Have you led a team of teachers before?" | JD | [grounded] "I've never been a team lead" — your message; "I led our grade level's move to a new reading curriculum in 2024" — your CV | "I haven't been a team lead." Then the closest thing you did: "I led our grade level's move to a new reading curriculum in 2024," described in your own words. Answer slot: if your role included deciding things for other teachers, say what; if it was coordinating, presenting or organising, say that instead. | F3 is the team-lead gap. The honest branch is the limit. |
| A4 | "You describe a reading curriculum move. What did it leave unresolved?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Answer slot: if something stayed unresolved, name it and say what you would change. If nothing did, say so plainly. Do not invent a problem to look candid. | The skeptic tests whether your strongest line survives a second question. |

### Case / Strategist (principal), weighted 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Three students in your class are reading two grade levels below. What do you do this week?" | CASE | [grounded] "I write a weekly email to families" — your CV | Clarify first: which assessment, what support is already in place, which reading curriculum. Then structure: assess, group, intervene, and involve families. You may use the family email as your channel, quoted as it is. | A live problem from the role. The email gives you a concrete channel without claiming any result. |
| B2 | "A fourth-grade colleague wants to skip a fractions unit to catch up on reading. What do you say?" | CASE | [generic] | Clarify what the unit covers and what it costs to skip it. Propose a decision rule, then talk to the colleague first, then the principal if needed. Do not claim you have done this before. | A team seam. Gives you a chance to show judgement without a past claim. |
| B3 | "Walk us through your first 30 days with us." | CASE | [generic] | Name the sequence: learn the standards and pacing, meet students and families, observe routines, ask the team what they need. Keep it as a plan. | Panels like structured thinking. This is also where F2's plan lives. |

### Peer Evaluator (team members), weighted 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our team has taught fourth grade for years. Where would you need us to bring you in?" | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV | Name the seam you can see: students arriving from third grade, and what you know of third-grade content. Then ask what the team expects from a new fourth-grade teacher. | Team members judge partnership. Acknowledging the fourth-grade gap while offering what you bring is the right balance. |
| C2 | "How do you handle a disagreement with a colleague who has more years on the team?" | VAL | [generic] | Answer slot: if you have a disagreement from your six years in which you raised a concern and it was settled, describe what you said and how it resolved. If you do not have one, say so, then describe how you would raise it: ask for the reasoning first. | Peer disagreement is scored collegially. |
| C3 | "What have you done as part of a grade-level team?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Describe the curriculum move in your own words: what you did, who else was involved, and who made which decisions. Answer slot: if others made calls you did not make, say so. | F3. Peers will probe the word "led" to see whether it held. |

### Data-Driven Prober (team members), weighted 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you know the reading club worked?" | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Say what happened in the club, in your own words. Answer slot: if you tracked anything (attendance, reading logs, assessments), say what and how it was counted. If you tracked nothing, say so plainly. Never give a figure you do not have. | The club's results are not in your material. The honest answer is the one you can defend. |
| D2 | "How did you measure whether the new curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Answer slot: if you measured something, name it, say how it was counted, and name the assumption you would defend least. If you did not measure it that way, say so, and say what you did observe. The question presupposes a measure your material does not show. | Prober risk. The honest branch is the one you can repeat under a second question. |

### Values / Behavioural, weighted 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to share hard news with a family." | VAL | [grounded] "I write a weekly email to families" — your CV | Selection scaffold: pick a real time a family heard something they did not want to hear. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then describe how you would handle it. | Open prompt. Your choice of example. |
| E2 | "Tell me about a time a lesson or program did not go as planned." | VAL | [generic] | Selection scaffold: pick one real example, then state what you changed. If none comes to mind, say so plainly and describe how you would handle it. | Open prompt. Panels score honest reflection. |

### Conversational, weighted 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk us through your journey to teaching in Joliet." | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV | A 90-second arc: where you started, where you teach now, what you have led, and why fourth grade. Say the fourth-grade part plainly. | Opener. Casual openers are still scored. |
| F2 | "What do you enjoy most about teaching reading?" | JD | [grounded] "I've run the after-school reading club for the last two years" — your CV | Answer from the club, in your own words. Say what you enjoy. Do not claim results. | Reading instruction is likely a panel focus. |

### Pressure, weighted 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why should we choose you over a candidate who has taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet" — your CV | Hold: six years of elementary teaching. Concede specifically: fourth-grade content is what you would learn fastest in the job, and you have not taught it. Hold through two follow-ups. Never claim to be the stronger candidate. | Composure test. Hold, then concede the specific gap. |
| G2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Answer slot: say in your own words which parts were yours. If others decided some parts, say which. Hold the core ("I led the move") through two follow-ups, and concede the parts that were not yours. | F3 under pressure. Do not fold on what you did, and do not inflate it. |

### Requirement coverage

| Requirement (invite) | Covered by | Note |
|---|---|---|
| Valid Illinois PEL with elementary endorsement | F1 | None, and why: met on your stated license. Confirm the status yourself before Thursday. |
| Fourth Grade Teacher position | A1, A2, A4, B3, G1 | Covered. The gap is named, not hidden. |
| Panel with the fourth-grade team | C1, C2, C3 | Covered. |
| Team lead (not asked, but likely) | A3, C3, G2 | Covered. |

## 6. Reverse questions

Each one lands for a reason:

1. "What does a strong first semester look like for someone new to the fourth-grade team?" Why it lands: it shows you are planning for the gap you named.
2. "How does the grade-level team plan together from week to week?" Why it lands: it shows interest in collaboration, which the team members will score.
3. "Which reading practices is the team using now, and which are still being decided?" Why it lands: it shows you care about reading, and it lets the team describe its own work.
4. "What could a new teammate do in their first month that would genuinely help your team?" Why it lands: it is the reciprocity question for the team members, and it turns the seam into a joint plan.
5. "How does the school tell families what is happening in class?" Why it lands: it ties to your weekly email and shows you already work this way.

No interviewer profile was supplied, so none of these is tied to an interviewer's career path.

## 7. Delivery coaching

Not included. No working-style assessment was provided.

## 8. Sources

- **Provided documents:** the invite from Human Resources, Orrinsford Community School District; the candidate's CV summary; the candidate's message.
- **Searches and fetches:** none run. The tier is L0.

**Research tier: L0. No search or fetch was run.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering Elementary values | unavailable | Values cheat sheet, which was dropped. Would have supplied published values to map stories to. |
| 2. Halvering interview process | unavailable | Whether the panel is scored on a rubric. Would have moved the persona weights. |
| 3. District strategy / recent news | skipped | No CO bank was built, and the invite names no strategy topic. |
| 4. Dolores Vantongeren + Halvering | unavailable | Public footprint for the principal's persona weights and a tailored reverse question. |
| 5. Representative fourth-grade teacher JD | unavailable | A JD-derived bank. Would have turned F-rows and JD questions from `[inferred]` to `[grounded]`. |

## 9. Upgrade menu

- The posting or full job description → firm up the JD-tagged questions and mark each requirement `[grounded]`.
- Any demo lesson, sample plan or task the school mentioned → a build section for it.
- Research at L1 (values, interview format, and the principal's public footprint) → a values cheat sheet, reweighted personas and a tailored reverse question.
- The two team members' names → persona assignments per member.
- Any scoring rubric or focus areas from HR → reweighted banks.
- `tuesday-dossier.md` → would record the gaps this prep exposed, for later sessions.
