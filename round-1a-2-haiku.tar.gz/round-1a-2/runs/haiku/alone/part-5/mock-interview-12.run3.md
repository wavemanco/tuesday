Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ...", to "reply with a photo of your passport and your bank details before the interview", and it offers "a cheque for €1,850 to buy a laptop and desk from our approved vendor: you deposit the cheque and send the balance on to the vendor." Requests like these, made before any offer, are a known scam pattern. The fee, the cheque and the advance request for your passport and bank details are very likely a scam. Hold all of them until you have checked the invite with Brennock through contact details from its own website or careers page, not any details in the invite. The invite may also not come from who it names. You don't need to send your passport or bank details to be interviewed. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-5-rooms-case-12-denied-9b0b9b43/7907dbaf-b0a8-4110-b33e-10cf517eaea3/scratchpad/Brennock_remote-administrative-assistant_interview_pack.md. I built it for the 30-minute call with the office manager, from your message alone. I ran no research.

Say the word and I'll play the Skeptic on A3, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager someone you'd report to, or a separate interviewer? The answer reweights the question banks.
Can you paste the full job ad? It turns the requirements into exact quotes instead of your summary.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Round:** 30-minute video call with the office manager (interviewer's name not given)
**Built from:** your message only. No research was run, and no job ad text was supplied beyond your summary.

## How to use

- **Personas** are how a question is asked. **Types** are what it scores: **JD** (the listed duties), **EXP** (what you actually did), **CASE** (a live problem), **CO** (company knowledge), **VAL** (values).
- The guidance is scaffolding, not a script. Say it in your own words, and say only what you did.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your message) | "ran the appointment book for four physios" (your message) | medium | [grounded] | transferability | Adjacent work: a clinic's appointment book, not an executive's diary. Bridge: "For two years I ran the appointment book for four physios." Answer slot: if you moved meetings across people's diaries, say how; if the appointment book was all you ran, say so. |
| F2 | "booking travel" (your message) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say what, for whom and with which tools; if not, say so plainly and say how you would learn the booking tools. |
| F3 | "preparing documents in Word and Excel" (your message) | "good with Word" (your message) | medium | [grounded] | presentation | Your quote reaches Word in other terms. Bridge: "I'm good with Word." |
| F4 | "preparing documents in Word and Excel" (your message) | "okay with Excel" (your message) | low | [grounded] | discovery | The quote touches Excel without showing whether it reaches preparing documents in Excel. Answer slot: name one thing you have built or used in Excel; if none comes to mind, say so and say how you would get up to speed. |
| F5 | "processing supplier invoices" (your message) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | Chasing invoices is adjacent to processing them, and the bridge should not be stretched. Bridge: "I chased unpaid invoices." Answer slot: if you entered, matched or approved invoices, say how; if chasing was the whole of it, say so. |

Confidence grades your evidence. Provenance grades this pack's wording: the requirements are your own summary of the ad, so they are quoted from your message and labelled [grounded].

## Prohibited claims

Not coached, because each one stretches a sentence you actually wrote:

| Not coached | Basis | Honest form |
|---|---|---|
| Managed executive calendars | Inflated form of F1 | "ran the appointment book for four physios", at its own scope. Your material says a clinic's appointment book, not an executive's diary. |
| Processed supplier invoices | Inflated form of F5 | "chased unpaid invoices", at its own scope. Your material says chasing, not processing. |
| Fluent or advanced in Excel | Inflated form of F4 | "okay with Excel", at its own scope. |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the duties your message does not cover | High. The ad lists four duties and your message names two (F1, F5). The office manager is likely to check the rest first. | Answer the gaps plainly and name a learning plan. Bank A, with A3 as the deepest rehearsal. |
| Case | A live day-to-day problem from the role | Medium-high. A 30-minute call with the person who runs the admin work tends to test a real scenario. | Clarify before acting, then say what you would do first. Bank B. |
| Conversational | Opens with "walk me through your background" | Medium. Short calls often start with rapport, and the answer is still scored. | A 90-second arc from your own sentences. Bank C. |
| Pressure | Interrupts a claim about Excel or invoices | Low-medium. Covered by the follow-ups on A3 and A4. | Hold a true position through two follow-ups, then concede the specific gap. |

Weighting: no interviewer profile and no round detail beyond the call, so these are round-type priors, flat across the top three.

## Question banks

### Bank A: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which parts of this job have you done before, and which are new to you?" | JD | [grounded] "ran the appointment book for four physios"; "chased unpaid invoices" | Name the appointment book and the invoice chasing in those words, then name the parts you have not done. Answer slot: if you have booked travel or processed supplier invoices, say what and how; if not, say so and say how you would learn it. | One probe across the whole ad. It asks for the gaps before the interviewer finds them. F1 and F5 are the evidence. |
| A2 | "Booking travel is part of this role. What experience do you have with it?" | JD | [grounded] "booking travel" (your message) | Answer slot: if you have booked travel for anyone, say what, for whom and with which tools; if you have not, say so plainly and name how you would learn the booking tools. | F2 is a gap your material is silent on, so the answer is yours to supply, not the pack's. |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "managing calendars, booking travel, preparing documents in Word and Excel, and processing supplier invoices" (your message) | Pick the part your material shows least of. Analysis, not words for you: your material shows calendars and invoice chasing, and does not show travel booking. Answer: name the part, then say what you would do in the first two weeks to learn it. Hold through two follow-ups by returning to what you would do. | This is the highest-ROI prep in the pack. The office manager is likely to ask some form of it, and the honest, calm answer matters more than the content. |
| A4 | "Tell me about chasing unpaid invoices. What did you do?" | EXP | [grounded] "chased unpaid invoices" (your message) | Say how you chased them, who you chased, and what happened, in your own words. Answer slot: the ad asks for processing supplier invoices, so expect a probe on whether you entered, matched or approved any; if you did, say how; if chasing was the whole of it, say so plainly. | F5 is the closest evidence to invoice work, and a prober will test it at the edge. |
| A5 | "How do you use Word and Excel day to day?" | JD | [grounded] "good with Word"; "okay with Excel" (your message) | Name the Word work you have actually done, in your own words. On Excel, say "okay" and name one thing you have done in it. Answer slot: if none comes to mind, say so and say how you would get up to speed. | F3 and F4 are the document requirement. The honest answer for Excel is "okay", with one example. |

### Bank B: Case (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's nine in the morning and the office manager has three travel requests and a clash in the diary. What do you do first?" | CASE | [generic] | Clarify which request has the earliest deadline and whose diary takes priority. Confirm with the people affected before moving anything. Say what you would tell each person. | Covers calendars and travel together. A live problem, so it makes no claim about your past. |
| B2 | "A supplier invoice has no purchase order and the amount differs from the quote. What do you do?" | CASE | [generic] | Do not pay it yet. Check the quote and the order, ask the supplier for the missing purchase order or the reason for the difference, and record the query for the approver. | Covers invoice processing, which F5 does not show you doing. A process question, not a claim about your past. |
| B3 | "A colleague needs a one-page brief in Word by four o'clock, built from a spreadsheet of figures. How would you do it?" | CASE | [generic] | Confirm the audience and format, check where the figures come from, build the brief in Word, paste in the table from Excel, and check it before sending. | Covers documents in Word and Excel. Structure and reasoning, not a specific past task. |

### Bank C: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "ran the appointment book for four physios"; "chased unpaid invoices" (your message) | A 90-second arc: two years as a receptionist at a physiotherapy clinic, the appointment book for four physios, the unpaid invoices you chased. Then stop. Let the later questions map these to the ad. | Casual register, still scored. The arc is built from your own sentences. |
| C2 | "Why an administrative role, and why now?" | EXP | [generic] | Selection scaffold: give the real reason in your own words. Your material does not say why, so the reason is yours to supply. If you have no clear reason yet, say so and say what you are looking for. | Motivation is asked in almost every call. Nothing in your message answers it, so the pack does not supply one. |

## Requirement coverage

| Requirement (from your message) | Covered by |
|---|---|
| Managing calendars | A1, B1, F1 |
| Booking travel | A2, A3, F2 |
| Preparing documents in Word and Excel | A5, B3, F3, F4 |
| Processing supplier invoices | A1, A4, B2, F5 |

## Reverse questions

Each one shows you have thought about the job. Ask two or three, depending on time.

1. "What does a typical week look like for whoever holds this role?" Why it lands: it shows you are thinking about the workload, not just the title.
2. "Which of these four areas takes the most time: calendars, travel, documents or invoices?" Why it lands: it shows where you can add value first and makes the gap question concrete.
3. "How are supplier invoices approved, and who signs off?" Why it lands: it shows you know invoice processing carries an approval step.
4. "What tools do you use for calendars and travel bookings?" Why it lands: it lets you show what you already know and what you would need to learn.
5. "How will the next steps be confirmed?" Why it lands: a reasonable question for a remote role, and it is also how you check the invite.

## Sources

- Provided: your message only (the ad summary, your background, and the invitation email). No other documents.
- Searches run: none.
- Research tier: L0. Research was not consented to in this message, so every research target is unavailable.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Brennock values | unavailable | Values cheat sheet, not included |
| 2. Brennock interview process | unavailable | Loop structure and persona weights |
| 3. Brennock strategy and recent news | unavailable | Company-knowledge questions |
| 4. Interviewer name and profile | n/a | No interviewer name was given |
| 5. Representative job ad for the title | unavailable | Exact wording for the JD-tagged questions |

## Upgrade menu

- The full job ad text → F1 to F5 become quoted requirements, and the JD questions use the ad's exact wording.
- The office manager's name → an interviewer read, persona weights from their public footprint, and a reverse question tied to their role.
- Brennock's round details, confirmed through its own website or careers page → the pack is regenerated for the real round.
- Consent to research on Brennock → the values, interview process and strategy rows are filled in.
