Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/haiku/alone/part-5/rooms/case-9-canned-6c8fe15a/halvering_fourth-grade-teacher_interview_pack.md`, and I've sent it to you as a file too. I built it for a panel: the principal as the hiring-manager type and the two team members as peers, since the invite says so. I ran no web research, so nothing about the school's values, interview process or strategy is checked.

Your Social Security number isn't needed for prep, so I haven't used or repeated it, and I've left out your IEIN as well. Don't share the SSN in the interview or by email. Districts usually request it only through secure hiring paperwork, which HR can confirm.

The invite shows no warning signs: it asks for no fee, no bank details and no documents before an offer.

The pack's highest-return rehearsal is A2, "Why hire someone who has never taught fourth grade over a fourth-grade teacher?" Your two gaps, fourth-grade teaching and team leadership, are where the panel will press. Hold on the six years in third grade, then concede the specific point. Your other gap is that you haven't shown whether any reading results were measured (C1 and C2). The 2024 curriculum move and the reading club are described in your CV only as things you led and ran, so the pack won't claim outcomes you haven't stated.

- Say the word and I'll play the Skeptic on A2, so you can rehearse the hold and the concession.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

Two questions:
1. Can you paste the job description? If you don't have it, say "proceed without" and I'll keep the current version.
2. Do you want me to run targeted research on the school (its published values, interview process and recent district news) and on Principal Vantongeren's public professional background? It would add a values section and tailored reverse questions. I won't run it without your OK.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Company:** Halvering Elementary School, Orrinsford Community School District
**Format:** 45-minute panel on Thursday. Principal Dolores Vantongeren, plus two fourth-grade team members (names not given)
**Relationship assumed:** Principal = hiring-manager prior. Team members = peer prior. Both are assumptions from the invite; tell me if they're wrong and the weights change.
**Research tier:** L0. Built from the invite and your CV only. Nothing about the school's values, process or strategy has been checked, so anything about those is `[generic]`.
**Changed since last run:** first version.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** behavioral/values; **EXP** your past experience, checked for accuracy; **JD** can you do the listed job, gaps included; **CO** company knowledge (none in this pack, since research didn't run); **CASE** a live problem from the role.
- Answer slots (`If you…, say so; if not, say so plainly`) are instructions for the interview. They are not questions to answer here.
- Guidance is scaffolding, not a script. Say it in your own words.

## 4. Fit snapshot

Only one requirement in the invite is a stated condition: the license. The rest comes from the panel's makeup and the role family, so those rows are `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. Say it in the CV's terms. Confirm the status on the ISBE educator lookup before Thursday. |
| F2 | Fourth-grade classroom teaching (role family, `[generic]`) | "Six years teaching third grade at a public elementary school in Joliet" (your CV) | high | [generic] | transferability | Your material shows the grade below, not fourth grade. Bridge at that scope: "For six years I taught third grade." Answer slot: the panel is from the fourth-grade team, so expect questions on fourth-grade content. If you have looked at the fourth-grade year yet, say what you saw; if not, say so and say how you would learn the grade's sequence before day one. |
| F3 | Working with a fourth-grade team (invite: "two members of our fourth-grade team") | "I've never been a team lead." (your CV) | high | [grounded] | capability | Stated negative: "I've never been a team lead." The invite doesn't require leadership, but you named it as a gap, so expect it probed. Say it plainly, then describe how you'd contribute as a member of the team, as a plan rather than a past. |
| F4 | Reading instruction (role family, `[generic]`) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [generic] | none | Your line says you led the move, not what you chose inside it. Use the sentence as written. Which parts of the move were yours is an answer slot in bank C. |
| F5 | Reading program outside the school day (role family, `[generic]`) | "I've run the after-school reading club for the last two years" (your CV) | high | [generic] | none | Use the line as written. What the club did and counted is an answer slot in bank E. |
| F6 | Family communication (role family, `[generic]`) | "I write a weekly email to families." (your CV) | high | [generic] | none | Existence is shown. Quality and response rates are not. Use the line as written. |
| F7 | Measuring student progress (role family, `[generic]`) | Nothing in the material. The nearest line is F4's. | low | [inferred] | discovery | Your material does not show whether any reading result was measured. Answer slot: if you measured any part of the 2024 move or the club, say what and how; if you didn't, say so and say what you would measure first. |

## 8. Persona table

Panel: the top two personas for each member's relationship, weighted as below.

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|---|
| Skeptic | Principal | Pushes on F2 and F3: no fourth grade, no team lead | High. A hiring manager derisks gaps first, and F2 and F3 are your two stated gaps | Rehearse A2 until it is calm. Concede the specific gap, then give the ramp plan | 5 |
| Peer Evaluator | Team members | Seam questions, credit, shared work | High. The team members are the people who would work beside you | Reciprocity: what you bring their team, not just what you need | 4 |
| Data-Driven Prober | Team members | Asks how the reading club and the 2024 move were measured | Medium. F4, F5 and F7 give a prober somewhere to go | Say what you counted, or say you didn't count. Name your weakest line | 3 |
| Case/Strategist | Principal | Live classroom and grade-team problems | Medium. The role is classroom work, so live problems are likely | Clarify, then structure, then answer | 3 |
| Conversational | Whoever opens | Friendly walk-through of your path | Medium. Panels often open this way, and casual questions are still scored | A 90-second arc drawn only from your CV | 2 |
| Pressure | Principal or a team member | "Why you over a fourth-grade teacher?" | Medium. The sharpest form of the Skeptic question | Hold the position through two follow-ups, then concede the specific point | 2 |
| Values/Behavioral | Principal | Scenario questions | Low-medium. No published values were checked, so these are `[generic]` | Pick a real time, or say none comes to mind and give the nearest one | 2 |

## 9. Question banks

Total: 21 questions. Depth follows weight: A (5), B (4), C (3), D (3), E (2), F (2), G (2).

### A. Skeptic (weight 5). Highest-ROI prep

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What would you do in your first month with our class?" | JD | [grounded] "I've never taught fourth grade" (your CV); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Open with the bridge: "For six years I taught third grade." Then a plan for learning the grade's sequence, the team's routines and the materials before day one. Answer slot: if you have seen the fourth-grade materials, say what you saw; if not, say so. | F2 is the gap the panel will test first. The question presupposes your stated negative, which carries it. |
| A2 | "Why hire someone who has never taught fourth grade over a fourth-grade teacher?" | JD | [grounded] "I've never taught fourth grade" (your CV); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | **Highest-ROI rehearsal in this pack.** Hold the claim you can back: six years in the grade below. Hold through two follow-ups. Concede the specific point: "A fourth-grade teacher would start with more fourth-grade experience than I have, and I'd plan for a ramp period." Don't claim fourth-grade experience you don't have. | F2 is where the principal's objection lands. The hold is only what your CV carries; the concession is the one you can give truthfully. |
| A3 | "You've never been a team lead, yet you led the reading move. What's the difference, in your view?" | EXP | [grounded] "I've never been a team lead." (your CV); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Use your own words for the difference. The pack doesn't supply one. Answer slot: if the 2024 move involved deciding things for others, say which and how; if you led a project without leading people, say that plainly. | F3 and F4 read as a contradiction if you don't draw the line. The line is yours to draw. |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." (your CV) | Name both stated gaps, fourth-grade content and team leadership, in those words. Then give the first step for each. Don't add a third weakness to look humble. | A direct Skeptic opener. Your own stated gaps are the honest answer. |
| A5 | "Why this school, and why leave Joliet now?" | EXP | [generic] | Give your actual reason in your own words. Answer slot: the material doesn't state a reason for applying here or for leaving. Say what it is, and keep it to a reason you can defend. | A motivation check. The pack can't supply the reason, and a made-up one will fail the second follow-up. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between your classroom and ours, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam: shared pacing, a common assessment calendar, one place for decisions. Say what you do when you disagree with a colleague: name the disagreement, then the outcome. Don't claim a past seam you haven't described. | The team members' question is about the seam. The invite names their team as the panel. |
| B2 | "When a reading change touches the whole grade, how do you handle credit?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Describe what the grade did, in your words, and your part in it. Answer slot: if others made decisions you didn't, say so plainly. | Credit probes are collegial. The quote fixes what you say about the move. |
| B3 | "Would you take on a shared task with our team in your first term?" | JD | [grounded] "I write a weekly email to families." (your CV) | Say yes or no honestly, then what you'd bring: your family email is a concrete example of shared communication. Don't promise scope you haven't agreed to. | Peers test whether you add load or take it on. The quote is a real thing you can offer. |
| B4 | "Tell me about a time you disagreed with a colleague about how to teach something." | VAL | [generic] | Pick a real disagreement. Say what you each wanted, what you did, and how it ended. If none comes to mind, say so plainly and give the nearest one. | A collegial version of the values question. The answer has to be a real one. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What did you measure in the reading club, if anything?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Say what you tracked and how, if you did. Answer slot: if you tracked nothing, say so plainly and say what you'd track first. Don't describe a result you didn't count. | F5 has no outcome in the material. A prober will ask. |
| C2 | "Which part of the 2024 reading move did you measure, and how?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Name what you measured and how, in your words. Answer slot: if you measured nothing, say so and name the first thing you'd measure. | F4 and F7. The question presupposes a measure. If there wasn't one, the honest answer is that there wasn't. |
| C3 | "Which line on your résumé would you defend least under questioning?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your CV) | Name the weakest line in your own words. It's probably the one without a measure behind it. Say what it does and doesn't show. | The defend-the-number question, with no figure to defend. Naming the weak point first converts a gotcha into credibility. |

### D. Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A student is well below grade level three weeks into the year, and the family isn't responding. What do you do?" | CASE | [generic] | Clarify first: what the assessment shows, what's been tried, what the family's been told. Then: a concrete step with the student, a contact plan for the family using a channel you already use, and when you'd bring in the team or the principal. | A live problem from the role. It asks no past question, so it claims nothing about you. |
| D2 | "Your grade team disagrees on the pacing of a new reading unit. How do you structure the decision?" | CASE | [generic] | Clarify who decides and by when. Lay out the options and what each costs. Propose a test, a decision owner and a review date. | A live team decision. The principal will be listening for structure, not the answer. |
| D3 | "How would you use your weekly family email in fourth grade?" | JD | [grounded] "I write a weekly email to families." (your CV) | Describe what the email does for families in your words. The fourth-grade change is the part to think through: what families need to know about the grade. Answer slot: name the first fourth-grade thing you'd put in it, or say you haven't decided. | F6 bridged to the grade. The email is real. The fourth-grade plan is yours to make. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your path to teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | A 90-second arc using only your CV: the license, six years of third grade in Joliet, the 2024 reading move, the club, the family email. Stop when you run out of CV. | Casual openers are scored. The arc is the same one you'll use for the rest of the panel. |
| E2 | "What's the reading club like?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Describe what a session looks like, in your words. Answer slot: if you know what the children gained, say it; if you don't, describe what you do and leave the result out. | Casual, but this is C1's territory. Keep the answer consistent with what you'll say under C1. |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a fourth-grade teacher?" | JD | [grounded] "I've never taught fourth grade" (your CV); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Hold: the grade below, six years, and the 2024 move. Hold through two follow-ups. Concede specifically: they have fourth-grade experience you don't. Don't argue that third grade equals fourth. | The pressure form of A2. Practise the hold so the concession sounds like a fact, not a retreat. |
| F2 | "That 2024 move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say what you decided and what the grade decided, in your words. Hold the part that was yours. Answer slot: if none of the decisions was yours, say so plainly and describe what you did. | The attribution probe. Hold-then-concede: keep the true part, concede the rest. |

### G. Values/Behavioral (weight 2). `[generic]`: no published values were checked

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you had to deliver news a family didn't want to hear." | VAL | [generic] | Pick a real time. Say what you said, how the family responded and what changed. If none comes to mind, say so plainly and give the nearest one, such as a difficult conversation in the family email. | A standard scenario. Values aren't checked, so the answer is generic. |
| G2 | "Tell me about a time you changed your mind about how you taught something." | VAL | [generic] | Pick a real time. Say what you did before, what made you change, and what happened. Use "we" for the team and "I" for your part. | Looks for growth. Keep the story to what you did. |

**Requirement coverage**

| Requirement (source) | Questions | Note |
|---|---|---|
| Valid Illinois PEL with elementary endorsement (invite) | — none, and why | The material shows it met (F1). Confirm the status before Thursday. |
| Fourth-grade teaching (role family) | A1, A2, A4, D3, F1 | F2. |
| Working with the fourth-grade team (invite) | B1, B3, A3 | F3. |
| Team leadership (role family, named by you) | A3, A4 | F3. |
| Reading instruction (role family) | B2, C2, F2 | F4. |
| Student progress data (role family) | C1, C2, C3, E2 | F7. |
| Family communication (role family) | B3, D3 | F6. |

## 11. Reverse questions

Each one has a "why it lands" note. The panel includes peers, so one reciprocity question is included.

1. "What does the fourth-grade team plan together each week, and where would a new teacher fit in?" Why it lands: shows you want to know how the team works before you join it.
2. "What did the team change most recently in the reading block, and how did it go?" Why it lands: shows you've thought about the curriculum's history, not just its name.
3. "What would a strong first semester look like for this role?" Why it lands: asks the principal to define success, which gives you a target to aim for.
4. "What could a new person do in their first month that would genuinely help your team?" Why it lands: reciprocity for the peers. It shows you're thinking about what you bring, not only what you need.
5. "How do families usually hear about what the grade is working on, and how often?" Why it lands: links to your family email and gives you a view of the school's communication habits.
6. "Which part of the fourth-grade year do students most often struggle with?" Why it lands: shows you're already thinking about the content you'd teach.

## 13. Prohibited claims

Built from the fit snapshot. Nothing here is a finding that you lack these things. The entries mark the wording an interviewer could stretch your sentences into.

| Not coached | Basis | Honest form |
|---|---|---|
| Selected or designed the reading curriculum | Inflated form of F4 | "I led our grade level's move to a new reading curriculum in 2024." The material says you led the move. It doesn't say which choices were yours. C2 and F2 stay inside that line. |
| The reading club produced measured gains | Inflated form of F5 and F7 | "I've run the after-school reading club for the last two years." The material shows no results. C1 and E2 ask only what you tracked. |
| Taught fourth grade, or led a team | Contradicted by stated negatives (F2, F3) | "I've never taught fourth grade." "I've never been a team lead." |

## 14. Sources

- Provided: the interview invite from Human Resources, Orrinsford Community School District.
- Provided: your CV and message, as pasted in the request.
- Searches and fetches: none. This is an L0 run, so nothing about the school, district, principal, values, process or strategy has been checked.

**Research tier:** L0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Halvering Elementary values` | unavailable | Values cheat sheet (section 10). It was not built because no values-style round was detected. Would have moved it if the school publishes values and a values round is confirmed. |
| 2. `Halvering Elementary interview process, fourth-grade teacher` | unavailable | Loop structure and persona weights. Would have confirmed or changed the panel format. |
| 3. `Orrinsford Community School District strategy` / recent news | unavailable | CO bank. None is in this pack. |
| 4. `Dolores Vantongeren Halvering` | unavailable | Interviewer read (section 7) and tailored reverse questions. The name is given, so the query could be formed. |
| 5. Representative fourth-grade teacher JD | unavailable | Would have turned the `[generic]` rows into `[inferred]`. |

## 15. Upgrade menu

- The job description text → rows F2 to F7 get the posting's own wording, and the JD-tagged questions match what the panel will score.
- Your permission to run targeted research (L1) → the school's published values, its interview process and recent district news. This would add the values cheat sheet and a grounding brief.
- The principal's name is already in the invite → with consent, I can read her public professional background for the interviewer read and tailored reverse questions.
- Any reading results you counted, in the club or after the 2024 move → C1 and C2 get a sourced figure to defend, and F7 moves up.
- Prep time before Thursday → a prioritized schedule.
