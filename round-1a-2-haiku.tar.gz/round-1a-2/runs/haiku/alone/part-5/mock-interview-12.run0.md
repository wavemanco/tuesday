Before any prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to send "a photo of your passport and your bank details before the interview". It also says successful candidates get "a cheque for €1,850", which you deposit before sending "the balance on to the vendor". Asking for money, a cheque deposit, or bank and ID details before any offer is a known job-scam pattern, and this invitation is very likely a scam. Please hold off on paying, depositing anything, or sending documents or bank details. Check the job independently: find the company's phone number on its own website or careers page (not in this email), call it, and ask whether the role and the interview exist. For an Irish company you can also look it up on the CRO register. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-5-rooms-case-12-denied-b831e2e9/92004282-5772-4329-a609-b5aa5462d48f/scratchpad/Brennock_remote-administrative-assistant_interview_pack.md`. It's built on the ad as you summarised it and your background as you described it, with no company research.

**What to expect:** a 30-minute video call with the office manager. Expect a warm opener, then a sceptical follow-up on your weakest claims. Those are Excel, booking travel, and processing supplier invoices. Your clinic work matches the calendar and document duties well. Your invoice experience is chasing money owed *to* the clinic, which is different from processing bills the company must pay, so say that clearly.

**How to prepare:**
- Rehearse one concrete example each for the appointment book, Word documents and Excel.
- For travel and supplier invoices, say what you haven't done and how you'd learn it. Don't claim more.
- Practise the scheduling question: how you'd set up a shared calendar for a manager across time zones.
- Prepare reverse questions. The pack includes one on who pays for remote equipment, which tests the fee request directly.

I can also play the sceptical interviewer on the invoice and Excel questions if you want to practise. I can save a `tuesday-dossier.md` to carry these gaps into later sessions, and convert the pack to Word if you'd like.

Is the office manager your future manager, or a colleague? The answer changes how the questions are weighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Candidate:** Aoife
**Format:** 30-minute video call with the office manager (relationship to you not stated; treated as a hiring-manager round)
**Built from:** the job ad as you summarised it, and your background as you described it. No full JD text, no company research (tier L0). Anything in this pack about the company is unverified.

**Before using this pack:** the invitation contains warning signs (fee, cheque deposit, bank and ID details before any offer). Confirm the company and the invitation independently before you prepare further or share anything. This pack is written for the interview itself, and it does not vouch for the employer.

## How to use + type key

- **Personas** = how a question is asked (friendly, sceptical, probing).
- **Types** = what is being scored.
  - **JD**: role and listed duties. Can you do the job as listed, including the parts you can't yet?
  - **EXP**: work-experience deep-dive. Do your claims survive scrutiny? What did you actually do?
  - **CASE**: a hypothetical problem from the role, reasoned live.
- Guidance is scaffolding, not a script. Rehearse the structure and the honest version, and say it in your own words.

## Fit snapshot

Requirements are the duties from the ad as you summarised them. Quoted text is yours, from your own description.

| ID | Requirement (ad) | Your evidence (quoted) | Fit | Confidence | Gap type | Provenance | Bridge language |
|---|---|---|---|---|---|---|---|
| F1 | Managing calendars | "ran the appointment book for four physios" | adjacent | medium | presentation | [grounded] | Scheduling for four people is close to calendar management. Say it as scheduling, and be specific about volume and conflicts. |
| F2 | Booking travel | none given | absent | none | capability | [generic] | Answer slot: [any travel you have booked, for work or personally, and how]. If none, say so and name how you would learn the booking tools in the first week. |
| F3 | Preparing documents in Word | "I'm good with Word" | direct | medium | presentation | [grounded] | Name the kinds of documents you have produced and what they were for. |
| F4 | Preparing documents in Excel | "okay with Excel" | unclear | low | discovery | [grounded] | Answer slot: [one thing you have built or changed in Excel, with what it did]. Do not describe your level beyond "okay" unless you can give an example. |
| F5 | Processing supplier invoices | "chased unpaid invoices" | adjacent | medium | transferability | [grounded] | Chasing money owed to the clinic is receivables. Processing bills the company must pay is payables. Say which you did, and state the limit: you have not processed supplier invoices. |
| F6 | Remote working from home | none given | unclear | none | hard_gate | [generic] | Not yet established: whether you can work from where you live, and what equipment or set-up the role expects. Ask this directly. Do not offer a workaround. |

## Prohibited claims

Claims this pack will not coach, because nothing you have given supports them.

| Claim | Basis | Honest form |
|---|---|---|
| "I have booked travel for a team." | No travel evidence in your background. | "I haven't booked travel for a team. I've handled bookings and changes in a busy diary, and I'd learn the company's tools." |
| "I process supplier invoices." | "Chased unpaid invoices" is money owed to the clinic, not bills it must pay. | "I chased money owed to the clinic. I haven't processed supplier bills, but the approval and payment steps are what I'd learn." |
| "I'm advanced in Excel." | You said "okay". | "I'm comfortable with basics, and I'd build on that with the spreadsheets you use." |
| "I ran admin for the whole clinic." | You ran the appointment book for four physios and handled invoice chasing. | "I ran the appointment book for four physios and handled the chasing of unpaid invoices." |

## Persona table

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | "Show me." Tests your weakest claim: Excel, invoices, travel. | High | The ad lists duties you can only partly show. A hiring-manager round weights the Skeptic. | Hold, then concede: answer the claim, then state the limit in one sentence. |
| Conversational | Warm opener, then scored follow-ups. | High | Office manager rounds for admin roles often start informal. | Keep answers short, with one example each. |
| Data-Driven Prober | Asks for specifics: volume, tools, how you handled a clash. | Medium | Scheduling and documents are concrete, so probes follow. | Pick one real example per duty and know its numbers. |

## Question banks

### A. Skeptic (highest weight)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me what you actually did with the appointment book." | EXP | "ran the appointment book for four physios" | Name the tool, the volume and the conflicts you resolved. Say what you owned and what you passed on. | Tests whether the claim holds up under detail. |
| A2 | "You say you're okay with Excel. What have you built in it?" | JD | "okay with Excel" | Give one honest example. If none, say what you have used it for and what you would learn first. | Skeptics go straight to the weakest claim. Be exact about it. |
| A3 | "Have you processed supplier invoices, or booked travel?" | JD | "chased unpaid invoices" | Separate chasing money owed from processing bills. Booking travel: answer slot [your answer]. State the limit, then the plan. | The highest-ROI prep: this is the duty you have least evidence for. |

### B. Conversational

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about yourself, and why this role?" | JD | "two years as a receptionist at a physiotherapy clinic" | 60 seconds: the clinic role, what you handled, why admin suits you next. Avoid claims about duties you don't have. | An opener that sets the tone and gets the first scored answer. |
| B2 | "What did a normal day look like at the clinic?" | EXP | "two years as a receptionist at a physiotherapy clinic" | Walk through the day in order. Concrete tasks, real volume. | Easy to answer; it gives the Skeptic material to test later. |

### C. Data-Driven Prober

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you set up a shared calendar for a manager with back-to-back meetings across time zones?" | CASE | none given: selection scaffold, [pick a time you scheduled for several people at once] | Structure: whose calendar, who can edit, how time zones are shown, how you handle clashes. Say what you'd check first. | Tests reasoning on the core duty, not your history. |

## Reverse questions

Ask these in the last few minutes. Each one tests the role, and the answers help you judge the employer.

| Question | Why it lands |
|---|---|
| "What share of the week is calendars, travel, documents and invoices?" | Tells you the real mix, so you can see which duties you would learn. |
| "Who approves supplier invoices, and how are they paid?" | Tests whether the invoice process is internal and documented. A real employer answers this without hesitation. |
| "What equipment does a remote team member get from the company, and at whose cost?" | Directly tests the fee and laptop request in the invitation. Expect a clear answer; any demand for payment is a warning. |
| "How will success in this role be measured in the first 90 days?" | Shows whether the role is defined and whether they plan for a new hire. |
| "Who would I work with day to day, and how do I confirm that on the company's own careers page?" | Tests whether the role is real and the company is who it says. |

## Upgrade menu

- The full job ad text → rows F1 to F6 become grounded against the exact wording, and the Skeptic bank tightens to it.
- The interviewer's name → a tailored persona weighting and reverse question.
- The company's own careers page or published values → a values cheat sheet.
- Prep time available → a prioritised schedule.
- The round's relationship (manager or peer) → reweights the persona table.
- A `tuesday-dossier.md` file → carries the gaps in this pack into later sessions.
