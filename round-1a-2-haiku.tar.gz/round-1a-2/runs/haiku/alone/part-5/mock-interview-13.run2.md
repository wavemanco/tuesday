Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-5-rooms-case-13-denied-4c037672/6f99ac53-1a59-41ed-b2ec-a967e9b16762/scratchpad/quillmoor_operations-coordinator_interview_pack.md`. It's built only from your message and the advert. The web searches were refused by the permission check, so there is no company research: nothing on Quillmoor's values, interview process or recent news.

The call covers four things, and the pack has a ready answer for each:

- **Pay:** say about £42,000 in your own words. It sits inside the advertised £38,000–£44,000.
- **Notice period:** your message doesn't give one, so you'll need to give your actual figure on the call.
- **Hybrid:** two days at Avonmouth works; you'd want no more than three.
- **Reason for moving:** the Bristol closure and the Reading relocation, stated plainly without criticising the employer.

Expect two gaps to come up. The advert asks for production planning across planning, warehouse and QA, and your experience is deliveries and supplier chasing. It also lists SAP as a plus, and you haven't used it. The pack gives you the plain wording for both. It also has five questions to ask Hannah, and the next steps are the one she promised to cover.

Want me to run the drill now? I can play Hannah and push on pay and notice.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** Recruiter screen, 30 minutes by phone, Thursday 2pm
**Interviewer:** Hannah Lowther, Talent Partner
**Candidate:** Sam
**Changelog:** First version.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| **JD** | Stated role terms: pay, notice, location, and the job's requirements |
| **EXP** | Your own experience and reasons, tested for what was actually yours |
| **CASE** | A live problem from the role (not used in this screen) |
| **VAL** | Values alignment (not used: no company values in hand) |
| **CO** | Company knowledge (not used: no research ran) |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — JD | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | transferability | Your material says deliveries across three depots, not production schedules across planning, warehouse and QA. The words stay there: "I schedule deliveries for three depots." Answer slot: if you coordinated anything between planning, the warehouse or QA, say what and how; if your work sat between the depots and suppliers, say that. |
| F2 | "track supplier deliveries and chase late orders" — JD | "chase suppliers when orders slip" — your message | high | [grounded] | none | Covered by your own words. Say it as you said it: you chase suppliers when orders slip. |
| F3 | "keep stock records accurate" — JD | "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year" — your message | medium | [grounded] | presentation | Your quote already reaches the requirement in other terms. Reword only that: "I rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year." Do not add a method or a result. |
| F4 | "report weekly on on-time dispatch" — JD | none given | none | [grounded] | discovery | Your material does not show dispatch reporting. Answer slot: if you produced any regular report on dispatch or on-time delivery, say what it covered and how often; if not, say so and say how you would build one. |
| F5 | "2+ years in operations or logistics coordination" — JD | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | high | [grounded] | none | Met on your own words. |
| F6 | "confident with Excel" — JD | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | Your material names a spreadsheet, not Excel. Answer slot: if you used Excel, say which features you used for the stock count; if you used another tool, name it. |
| F7 | "ERP experience (SAP or similar) a plus" — JD | "Never used SAP — we run our own in-house stock system" — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't used SAP. We ran our own in-house stock system." Describe that system only as it was. Do not call it an ERP unless you know it was. |
| F8 | "Hybrid: two days a week at our Avonmouth site" — JD | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Met on your own words. |
| F9 | "£38,000–£44,000" — JD | "I'm hoping for £42,000" — your message | high | [grounded] | none | Your figure sits inside the advertised range. |

Requirement coverage: F1 → A5; F2 → A5; F3 → A7; F4 → A9; F5 → A5 (context only); F6 → A8; F7 → A6; F8 → A3; F9 → A1. Notice period and reason for leaving are not in the advert; they are the recruiter's logistics questions → A2, A4.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| SAP or ERP experience | Negative you stated (F7) | "I haven't used SAP." No slot. |
| Owning production scheduling across planning, warehouse and QA | Inflated form of F1: the material says deliveries across depots | F1's quote at its own scope. The limit is this pack's observation: your material says deliveries, not production planning. |
| The stock-count drop as your work alone | Inflated form of F3: the material says you rebuilt the sheet and discrepancies fell; it does not say what else changed | F3's quote, with the result stated as the drop that happened over the year. |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| **Screener** (Hannah, Talent Partner) | Checks the logistics in turn: pay, notice, hybrid, reason for moving; then covers team and next steps | High. The call's agenda is stated in their message, so these questions will almost certainly come | Answer each in one or two sentences, in your own words, then stop and let them lead |

## Question banks

### Screener (weight: primary)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | Say your figure in your own words: around £42,000. If they give the band first, you can say that £42,000 is what you're aiming for within it. Do not give a current salary or history unless asked for one. | Pay is on their stated agenda. Your figure sits inside the advertised range, so it needs no defence |
| A2 | "What's your notice period?" | JD | [generic] no notice figure in your material | Give your actual notice period, in your own words. This is an instruction for the call, not a figure to supply here. | Stated on their agenda. Your material gives no figure, so the answer must come from you |
| A3 | "Two days at Avonmouth is the pattern. How would that work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Say two days works and that you live in north Bristol. Say, in your own words, that three days is the most you'd want. Do not agree to more than your quote does. | Hybrid is on their agenda, and your stated limit is the honest answer |
| A4 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | State the closure and the Reading relocation plainly. Say what you are looking for next, in your own words. Do not criticise the employer. | Reason for moving is on their agenda. Your quote is the true reason; a plain answer is stronger than a polished one |
| A5 | "The role coordinates production planning, the warehouse and QA. What's your experience there?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Describe the deliveries and the supplier chasing as they happened. Answer slot: if you worked with planning, the warehouse or QA, say how, in your own words; if your work sat between the depots and suppliers, say that and stop. | F1's gap. Expect this from a screener checking the advert against the CV |
| A6 | "Do you have SAP or ERP experience?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Plain acknowledgment: "I haven't used SAP." Then describe the in-house stock system as it was. | F7, a stated gap. A plain answer here is credible, and the ERP line is only a plus |
| A7 | "Discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "discrepancies fell by about a third over a year" | Name the count and the period you used. Name the assumption you would defend least, before they do. Answer slot: say which part was yours; if you can't say how it was counted, say so plainly. | F3's figure. A figure raises a defend-the-number slot; it does not raise a slot for any other practice |
| A8 | "How confident are you in Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: if you used Excel, name the features you used for the stock count; if you used another tool, name it. Do not claim a level you can't back. | F6, low confidence. Excel is in the advert and not in your quote |
| A9 | "Have you produced a weekly on-time dispatch report?" | JD | [generic] no quote covers dispatch reporting | Answer slot: if you produced a regular report on dispatch or on-time delivery, say what it covered and how often; if not, say so and say how you'd start one. | F4, discovery. Silence in your material is not a yes |

Coverage note: the advert's requirements are covered above; A1–A4 are the call's logistics. The highest-ROI rehearsal is A5 and A6 together, because the planning/QA gap and the SAP gap are the two things a screener is most likely to probe.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How many production schedules would the role own week to week, and how many suppliers?" | Turns the advert into a workload picture and shows you read it |
| R2 | "Which days at Avonmouth are fixed, and which are flexible?" | Tests the hybrid pattern you can accept and shows you planned around it |
| R3 | "How is the weekly on-time dispatch report produced today?" | Shows you noticed the reporting line; the answer tells you what the job inherits |
| R4 | "What systems would I use day to day, and is ERP training offered?" | Puts the SAP gap on the table as a question, not a confession |
| R5 | "What are the next steps and roughly when would you expect them?" | Ends the call on the process; it is the one question the recruiter's message promised to answer |

## Prohibited claims
(See the table above, placed in the pack before the banks.)

## Sources

No provided documents beyond the candidate's message and the advert.

Research tier: L1 — searches 0 of 6, fetches 0 of 2 (the three searches were refused by the tool's permission check)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Values cheat sheet, not built. Not run because the search tool was refused |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Would have shown the screen's structure; no query sent, because search was refused |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Would have confirmed the company's current position and any Avonmouth news; no query sent, because search was refused |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Would have given a public footprint for the interviewer; no query sent, because search was refused |
| 5. representative Operations Coordinator JD | skipped | Your advert fixes the fit snapshot and the JD-tagged questions |

Searches refused: "Quillmoor Diagnostics"; "Quillmoor Diagnostics values"; "Quillmoor Diagnostics Avonmouth Bristol operations coordinator" — each returned "permission not granted", not a result.

## Upgrade menu

- Search permission granted → company values, interview process and recent news for Quillmoor can be checked; rows 1–4 above become searchable
- Your notice period → A2 becomes `[grounded]` and the answer is ready
- Your Excel detail (features, level) → A8 moves from a slot to a grounded answer
- Any regular dispatch or on-time report you produced → A9 moves from a slot to a grounded answer
- The recruiter's prep email, if they send one → any stated focus areas for the call
