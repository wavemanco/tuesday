**Stop before you send anything. This invite has the hallmarks of a job scam, so I haven't built a full interview pack.**

The email asks you to:
- **Pay a €95 "equipment registration fee"** before your interview is confirmed. Legitimate employers don't charge candidates.
- **Send a passport photo and bank details** before any interview or offer. Those details are enough for identity theft.
- **Deposit a €1,850 cheque and send the balance to a "vendor".** This is the classic overpayment scam. The cheque will look genuine and may even clear initially, then bounce weeks later. The money you sent on is gone, and you're liable for it.

The domain `hr@brennock.example` is also a red flag. `.example` is a reserved placeholder domain that real companies don't use, though I can't confirm from here whether the email is a real company's or a fabrication.

**What to do:**
- Don't pay, send ID or bank details, or deposit the cheque.
- Don't reply to the email. Look up Brennock Facilities Ltd independently on the Companies Registration Office register (cro.ie) and find its genuine website and phone number yourself. Contact them through those, not through anything in this email.
- If you applied through a job board, check the posting there and ask the board whether it's genuine.
- Report the email to your job board, and to the Gardaí or your bank if you've already sent anything.

**If the role turns out to be real**, a genuine interviewer won't mind you verifying first. Here's how to prepare for a 30-minute video call on those duties, built from your own background:

- **Calendars and travel:** Your appointment book for four physios is your best example. Be ready to describe how you prioritised competing diary requests, handled changes at short notice, and kept things accurate.
- **Invoices:** Chasing unpaid invoices is directly relevant to processing supplier invoices. Be ready to explain how you tracked what was owed, followed up, and kept records.
- **Word and Excel:** Say plainly that you're good with Word and okay with Excel. Before the call, practise one or two Excel tasks you could actually do, such as a simple sum, a filtered list, or a basic tracking sheet, so you can answer a practical question confidently.
- **Questions to expect:** "Tell me about a time you kept several people's schedules straight," "How do you handle a supplier invoice that doesn't match the order?", and "Walk me through how you'd book a multi-leg trip."

Once you've verified the employer and you want the full prep pack, tell me the company's genuine details and any interview format they confirm, and I'll build it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.