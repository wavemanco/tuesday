Your resume includes your Social Security number and your IEIN. Neither is needed for this interview, and the invite doesn't ask for either, so don't send them in reply. I haven't repeated them here. Consider removing them from the resume before you send it anywhere. Also, the invite names no contact details. Check it with the district through its official website or main phone line before sharing personal data. Today is Thursday, November 19, so confirm whether the interview is today or next Thursday, November 26.

I saved the pack to `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-5-rooms-case-9-canned-b7e7a071/3f2b019c-96af-4dab-aec3-312f8b6dc2a6/scratchpad/Halvering_FourthGrade_interview_pack.md`. The full pack is below.

# Interview prep: Fourth Grade Teacher, Halvering Elementary (Orrinsford Community School District)

Panel interview, 45 minutes. Principal Dolores Vantongeren, plus two fourth-grade team members (names not given).

## How to use this pack

- **Personas** are how a question is asked. **Types** are what is being scored: EXP (your past work), JD (the role's requirements), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Rehearse the shape, then answer in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. Say "registered and active through June 30, 2029." Confirm the status on the ISBE site and bring a copy. |
| F2 | "Fourth Grade Teacher position" (invite) | "I've never taught fourth grade" (your message) | none | [grounded] | capability | Your words: "I haven't taught fourth grade." Then the bridge: "Six years teaching third grade at a public elementary school in Joliet." The plan for learning the grade is a plan, never a past. Don't claim fourth-grade experience you haven't shown. |
| F3 | "two members of our fourth-grade team" (invite, team setting) | "I've never been a team lead" (your message) | none | [grounded] | capability | Your words: "I haven't been a team lead." Bridge: "I led our grade level's move to a new reading curriculum in 2024." Keep it at what you led; don't stretch it into a title. |
| F4 | Grade-level collaboration (no quoted source; role-family requirement) | "I led our grade level's move to a new reading curriculum in 2024." (your CV) | medium | [generic] | transferability | Your closest team evidence. Name its exact scope: what you led, and what the team did. Answer slot: if asked what the move involved, say what you did and what others did. |
| F5 | Reading support (no quoted source; role-family requirement) | "I've run the after-school reading club for the last two years." (your CV) | medium | [generic] | none | No gap. Lead with the two years and what the club does. Don't claim results you haven't given me. |
| F6 | Family communication (no quoted source; role-family requirement) | "I write a weekly email to families." (your CV) | medium | [generic] | none | No gap. Lead with the weekly rhythm. Answer slot: an example of what one of those emails covered, if you have one. |

## Prohibited claims

| Claim | Basis | Honest form |
|---|---|---|
| "I have taught fourth grade" or any fourth-grade experience | your message | "I've taught third grade for six years, and I haven't taught fourth grade." |
| "I have been a team lead" | your message | "I haven't been a team lead. I led our grade level's curriculum move." |
| Any result from the 2024 move or the reading club | your material has no outcome data | Answer slot: "What did you measure? If nothing, say so." |
| Familiarity with fourth-grade standards or team routines | not in your material | "Here's how I'd learn them in my first weeks." |

## Persona weights

The principal carries hiring-manager weight; the two team members carry peer weight. No interviewer profiles were provided, so there's no public-footprint read.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "Why hire a third-grade teacher for fourth grade?" | High. Hiring-manager weight, plus two stated gaps. | Rehearse the objection until boring. Bridge from third grade and the curriculum move. |
| Peer Evaluator | "What would you need from us, and what would you bring?" | High. Two team members. | Reciprocity first: what you bring, then what you need. |
| Data-Driven Prober | "How did you know the move worked?" | Medium. Your material has no outcome data. | Name what you measured, if anything. If nothing, say so. |
| Case/Strategist | A first-weeks planning scenario | Medium. Hiring-manager weight. | Clarify, then objective, approach, metrics. |
| Conversational | "Walk us through your path." | Medium. Casual, but scored. | A 90-second arc. |

Depth follows weight: Skeptic 4 questions, Peer 3, Prober 2, Case 1, Conversational 2.

## Question banks

### Persona A: Skeptic (highest weight)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | JD | "You've never taught fourth grade. Why should we hire you for it?" | [grounded] "Six years teaching third grade at a public elementary school in Joliet." (your CV); "I've never taught fourth grade" (your message) | Start from the record: six years of third grade. Then say what you'd do in the first weeks to learn the fourth-grade scope with the team. Don't claim familiarity you haven't shown. | **Highest-ROI prep in this pack.** It's the most likely objection and goes to the panel's central question. Rehearse it until boring. |
| A2 | EXP | "You haven't been a team lead. What would make you one?" | [grounded] "I've never been a team lead" (your message); "I led our grade level's move to a new reading curriculum in 2024." (your CV) | Say "I haven't been a team lead." Then the curriculum move, scoped exactly. Answer slot: what you'd want to lead first, and how you'd bring the team along. | Pressure on a stated gap. Composure matters as much as content. |
| A3 | JD | "Which part of this role would you be weakest at on day one?" | [grounded] "I've never taught fourth grade" (your message) | Name it plainly: fourth-grade content and team routines. Then one concrete ramp plan. | Calibrated candor. A stated gap can be named without apology. |
| A4 | EXP | "That 2024 curriculum move: how much of it was actually you?" | [grounded] "I led our grade level's move to a new reading curriculum in 2024." (your CV) | Hold the claim as written: you led the move. Name what the team did too. | Pressure follow-up. Shrinking an inflated claim gracefully is the skill tested. |

### Persona B: Peer Evaluator

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | JD | "We're planning a shared reading unit. What would you need from us, and what would you bring?" | [grounded] "I've run the after-school reading club for the last two years." (your CV) | Bring first: the reading club and your reading routines. Then what you need. | Reciprocity framing. |
| B2 | EXP | "When grade-team members disagree on an approach, how do you handle it?" | [generic] No sentence from your material carries this. Answer slot: pick a time you disagreed with colleagues on a shared plan. If none comes to mind, say so and describe how you'd handle it. | Use the scaffold. Don't invent a disagreement story. | Partnership fit. The honest branch is the answer here. |
| B3 | EXP | "How do you keep families informed across the grade?" | [grounded] "I write a weekly email to families." (your CV) | Describe the weekly rhythm and what the email covers. Offer to share a sample. | Family communication is shared across the team. |

### Persona C: Data-Driven Prober

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | EXP | "How did you know the reading curriculum move worked?" | [grounded] "I led our grade level's move to a new reading curriculum in 2024." (your CV) | Answer slot: if you measured anything (scores, assessments, a comparison), name it and how you counted it. If not, say so. Never guess an outcome. | No outcome data in your material. |
| C2 | EXP | "The reading club ran two years. Who attended, and how did you measure growth?" | [grounded] "I've run the after-school reading club for the last two years." (your CV) | Same honest branch as C1. Name attendance or growth only if you tracked it. | Same reason. |

### Persona D: Case/Strategist

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| D1 | CASE | "It's October, and your class's reading scores are flat. What would you do first?" | [generic] No sentence from your material carries this. | Clarify first: what the scores measure, and against what. Then objective, approach, how you'd check progress. Think aloud. | Scored on structure, not a correct answer. |

### Persona E: Conversational

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| E1 | EXP | "Walk us through your path to Halvering." | [grounded] "Six years teaching third grade at a public elementary school in Joliet." (your CV) | A 90-second arc: Joliet, third grade, the curriculum move, the reading club, what draws you to fourth grade. | Casual openers are still scored. |
| E2 | EXP | "Why fourth grade, and why Halvering?" | Answer slot: your material doesn't say why. Give the honest reason in your own words. | Don't borrow a reason you don't hold. If you haven't looked into the school, say what you plan to find out. | Motivation consistency. |

## Reverse questions

1. "What does a typical week look like for the fourth-grade team?" Shows you're planning for the work itself.
2. "What would success look like for this role in the first semester?" Gets the panel's criteria in their own words.
3. "How does the team plan and share curriculum decisions?" Speaks to the team-lead gap without naming it.
4. "What support do new team members get in learning the grade's scope?" Turns the fourth-grade gap into a question about support.
5. For the team members: "What do you wish the teacher who joins you already knew?" Asks peers for their side of the partnership.
6. "What is the team's biggest priority this year?" Shows where the panel's attention is.

## Sections dropped

Prep triage (prep time not stated), values cheat sheet (no published values in hand), graded deliverables (none declared), grounding brief (no research run), delivery coaching (no assessment provided).

## Sources

- Provided: the invite, your message, and your resume text.
- Research: none run. The principal, the school, the district's current strategy and the panel's values are unresearched.
- Research tier: L0 (provided documents only).

## Upgrade menu

- The job posting text → replaces the [generic] rows with quoted requirements and adds JD questions.
- HR's focus areas, or anything they asked you to prepare (a sample lesson, a portfolio) → weights those sections.
- The two team members' names and roles → per-member persona weights.
- Permission to research the school and district (public pages only) → the principal's public background and the district's current priorities.
- Any outcome data from the 2024 curriculum move or the reading club → stronger answers to C1 and C2.
- `tuesday-dossier.md` → a record of the gaps this prep exposed, for later sessions.

---

Want me to play the principal on A1, the objection I'd rehearse most? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed.

Three questions that would reshape the pack:

1. Can you paste the job posting? If not, I'll keep building from the invite.
2. Did HR say what the panel will focus on, or ask for anything before Thursday, such as a sample lesson, a portfolio or a written response?
3. Is Thursday today (November 19) or next week (November 26), and how much prep time do you have?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_FourthGrade_interview_pack.md -----
# Interview prep: Fourth Grade Teacher, Halvering Elementary (Orrinsford Community School District)

Panel interview, 45 minutes. Principal Dolores Vantongeren, plus two fourth-grade team members (names not given).

## How to use this pack

- **Personas** are how a question is asked. **Types** are what is being scored: EXP (your past work), JD (the role's requirements), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Rehearse the shape, then answer in your own words.
- Read the sections in order before Thursday; the fit snapshot and the Skeptic bank matter most.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. Say "registered and active through June 30, 2029." Confirm the status on the ISBE site and bring a copy. |
| F2 | "Fourth Grade Teacher position" (invite) | "I've never taught fourth grade" (your message) | none | [grounded] | capability | Your words: "I haven't taught fourth grade." Then the bridge from your record: "Six years teaching third grade at a public elementary school in Joliet." The plan for learning the grade is a plan, never a past. Do not claim fourth-grade experience or familiarity you have not shown. |
| F3 | "two members of our fourth-grade team" (invite, team setting) | "I've never been a team lead" (your message) | none | [grounded] | capability | Your words: "I haven't been a team lead." Bridge: "I led our grade level's move to a new reading curriculum in 2024." Keep it at what you led; do not stretch it into a title. |
| F4 | Grade-level collaboration (no quoted source; role-family requirement) | "I led our grade level's move to a new reading curriculum in 2024." (your CV) | medium | [generic] | transferability | This is your closest team evidence. Name its exact scope: what you led, and what the team did. Answer slot: if asked what the move involved, say what you did and what others did, in your own words. |
| F5 | Reading support (no quoted source; role-family requirement) | "I've run the after-school reading club for the last two years." (your CV) | medium | [generic] | none | No gap. Lead with the two years and what the club does. Do not claim results you have not given me. |
| F6 | Family communication (no quoted source; role-family requirement) | "I write a weekly email to families." (your CV) | medium | [generic] | none | No gap. Lead with the weekly rhythm. Answer slot: an example of what one of those emails covered, if you have one. |

## Prohibited claims

These claims are not coached anywhere in this pack.

| Claim | Basis | Honest form |
|---|---|---|
| "I have taught fourth grade" or any fourth-grade experience | your message: "I've never taught fourth grade" | "I've taught third grade for six years, and I haven't taught fourth grade." |
| "I have been a team lead" or any team-lead experience | your message: "I've never been a team lead" | "I haven't been a team lead. I led our grade level's curriculum move." |
| Any result from the 2024 move or the reading club (scores, growth) | your material has no outcome data | Answer slot: "What did you measure? If nothing, say so." |
| Familiarity with fourth-grade standards or team routines | not in your material | "Here's how I'd learn them in my first weeks." |

## Persona weights

Panel: the principal carries hiring-manager weight, and the two team members carry peer weight. No interviewer profiles were provided, so no public-footprint read was run.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "Why hire a third-grade teacher for fourth grade?" | High. Hiring-manager weight, plus two stated gaps. | Rehearse the objection until it is boring. Bridge from the quoted third-grade years and the curriculum move. Plan for the gap. |
| Peer Evaluator | "What would you need from us, and what would you bring?" | High. Two team members, peer weight. | Reciprocity first: what you bring, then what you need. |
| Data-Driven Prober | "How did you know the move worked?" | Medium. Team members may ask, and your material has no outcome data. | Name what you measured, if anything. If nothing, say so. |
| Case/Strategist | A first-weeks planning scenario | Medium. Hiring-manager weight. | Clarify, then objective, approach, metrics. |
| Conversational | "Walk us through your path." | Medium. Casual opener, still scored. | A 90-second arc. |

Depth follows weight: Skeptic 4 questions, Peer 3, Prober 2, Case 1, Conversational 2.

## Question banks

### Persona A: Skeptic (highest weight)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | JD | "You've never taught fourth grade. Why should we hire you for it?" | [grounded] "Six years teaching third grade at a public elementary school in Joliet." (your CV); "I've never taught fourth grade" (your message) | Start from the record: six years of third grade. Then say what you would do in the first weeks to learn the fourth-grade scope with the team. Do not claim familiarity you have not shown. | **Highest-ROI prep in this pack.** It is the most likely objection, and it goes to the panel's central question. Rehearse it until it is boring. |
| A2 | EXP | "You haven't been a team lead. What would make you one?" | [grounded] "I've never been a team lead" (your message); "I led our grade level's move to a new reading curriculum in 2024." (your CV) | Say "I haven't been a team lead." Then the curriculum move, scoped exactly. Answer slot: what you would want to lead first, and how you would bring the team along. | Pressure on a stated gap. Composure matters as much as content. |
| A3 | JD | "Which part of this role would you be weakest at on day one?" | [grounded] "I've never taught fourth grade" (your message) | Name it plainly: fourth-grade content and team routines. Then one concrete ramp plan. | Calibrated candor. A stated gap can be named without apology. |
| A4 | EXP | "That 2024 curriculum move: how much of it was actually you?" | [grounded] "I led our grade level's move to a new reading curriculum in 2024." (your CV) | Hold the claim as written: you led the move. Name what the team did too. Do not claim the whole change. | Pressure follow-up. Shrinking an inflated claim gracefully is the skill being tested. |

### Persona B: Peer Evaluator

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | JD | "We're planning a shared reading unit. What would you need from us, and what would you bring?" | [grounded] "I've run the after-school reading club for the last two years." (your CV) | Bring first: the reading club and your reading routines. Then what you need from them. | Reciprocity framing. Peers score what the hire adds to their load. |
| B2 | EXP | "When grade-team members disagree on an approach, how do you handle it?" | [generic] no sentence from your material carries this. Answer slot: pick a time you disagreed with colleagues on a shared plan. If none comes to mind, say so and describe how you would handle it. | Use the scaffold. Do not invent a disagreement story. | Partnership fit. Your material has no story here, so the honest branch is the answer. |
| B3 | EXP | "How do you keep families informed across the grade?" | [grounded] "I write a weekly email to families." (your CV) | Describe the weekly rhythm and what the email covers. Offer to share a sample if they want one. | Communication with the team's families is a shared responsibility. |

### Persona C: Data-Driven Prober

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | EXP | "How did you know the reading curriculum move worked?" | [grounded] "I led our grade level's move to a new reading curriculum in 2024." (your CV) | Answer slot: if you measured anything (scores, assessments, a comparison), name it and how you counted it. If you did not, say so. Never guess an outcome. | No outcome data in your material. Prober questions go to the assumption behind a claim. |
| C2 | EXP | "The reading club ran two years. Who attended, and how did you measure growth?" | [grounded] "I've run the after-school reading club for the last two years." (your CV) | Same honest branch as C1. Name attendance or growth only if you tracked it. | Same reason as C1. |

### Persona D: Case/Strategist

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| D1 | CASE | "It's October, and your class's reading scores are flat. What would you do first?" | [generic] no sentence from your material carries this. | Clarify first: what the scores measure and against what. Then objective, approach, and how you would check progress. Think aloud. | Scored on structure, not a correct answer. |

### Persona E: Conversational

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| E1 | EXP | "Walk us through your path to Halvering." | [grounded] "Six years teaching third grade at a public elementary school in Joliet." (your CV) | A 90-second arc: Joliet, third grade, the curriculum move, the reading club, and what draws you to fourth grade. | Casual openers are still scored. |
| E2 | EXP | "Why fourth grade, and why Halvering?" | Answer slot: your material does not say why. Give the honest reason in your own words. | Do not borrow a reason you do not hold. If you have not yet looked into the school, say what you plan to find out. | Motivation consistency. |

## Reverse questions

Each question has a reason it lands.

1. "What does a typical week look like for the fourth-grade team?" Lands because it shows you are planning for the work itself.
2. "What would success look like for this role in the first semester?" Lands because it gives you the panel's scoring criteria in their own words.
3. "How does the team plan and share curriculum decisions?" Lands because it speaks to the team-lead gap without naming it.
4. "What support do new team members get in learning the grade's scope?" Lands because it turns the fourth-grade gap into a question about support.
5. Reciprocity, for the team members: "What do you wish the teacher who joins you already knew?" Lands because it asks peers for their side of the partnership.
6. "What is the team's biggest priority this year?" Lands because the answer tells you where the panel's attention is.

No reverse question is tied to the principal's career path, because no profile was provided.

## Sections dropped

Prep triage (prep time not stated), values cheat sheet (no published values in hand), graded deliverables (none declared), grounding brief (no research run), delivery coaching (no assessment provided).

## Sources

- Provided: the invite, your message, and your resume text.
- Research: none run. The principal, the school, the district's current strategy and the panel's values are unresearched.
- Research tier: L0 (provided documents only).

## Upgrade menu

- The job posting text → replaces the [generic] rows with quoted requirements and adds JD questions.
- HR's focus areas, or anything they asked you to prepare (a sample lesson, a portfolio) → weights those sections and adds graded deliverable prep.
- The two team members' names and roles → per-member persona weights.
- Permission to research the school and district (public pages only) → the principal's public background and the district's current priorities.
- Any outcome data from the 2024 curriculum move or the reading club → stronger answers to C1 and C2.
- `tuesday-dossier.md` → a record of the gaps this prep exposed, for later sessions.
