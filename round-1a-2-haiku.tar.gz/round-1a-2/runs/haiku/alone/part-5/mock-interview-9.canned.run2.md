You also included your Social Security number. I didn't use it, and the prep doesn't need it. Keep it out of chats like this one, and give it only through the district's own HR process.

Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-5-rooms-case-9-canned-4f403c1d/e3b09049-2b4a-47fd-8acc-8fba243192af/scratchpad/Halvering_fourth-grade-teacher_interview_pack.md. I built it for a panel where the principal is the hiring authority and the two team members are peers. That assumption came from the invite; tell me if it's wrong.

The most important thing to prepare is the fourth-grade gap. Your six years in third grade, the 2024 curriculum move, and the reading club are real and carry well. The gap itself is the likely first probe. Rehearse A2 until you can say "I've never taught fourth grade" plainly, then give a plan for how you'd get ready. Don't frame the plan as past experience. The team-lead gap is also likely to come up, even though the invite doesn't ask for it.

I ran no web research for this pack, so it rests only on the invite, your CV and your note. Values and the interview structure are missing as a result.

Say the word and I'll play the Skeptic on A2, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Did the invite or HR say what the panel will focus on, or ask you to bring anything, such as a lesson plan?
2. Can you paste the job posting or full job description? If not, I'll work from the invite's wording alone.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Fourth Grade Teacher, Halvering Elementary School: Panel Interview Prep

**Round:** 45-minute panel, Thursday
**Panel:** Principal Dolores Vantongeren, plus two members of the fourth-grade team
**Assumed relationships:** principal as hiring authority; team members as peers (no interviewer profiles supplied)
**Built on:** the HR invite, your CV, and your note. No web research was run.
**Changelog:** first version.

---

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** EXP = what you actually did (work-experience deep-dive). JD = the listed job and its requirements. CASE = a live problem from the role. VAL = values alignment (not used: no company values were supplied). CO = company strategy (not used: no research was run).
- Guidance is scaffolding, not a script. Rehearse the beats in your own words.
- Every claim about your past rests on a sentence you wrote, quoted in the Provenance column. Where the material does not show something, the cell is an answer slot: an instruction to answer truthfully either way.

---

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "a valid Illinois Professional Educator License with an elementary endorsement" (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. Say the license and its active-through date in those words. The endorsement's grade band (1–6) includes fourth grade; that is this pack's reading of the license, not a claim about your teaching. |
| F2 | "Fourth Grade Teacher position" (invite) | "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | none | [grounded] | capability | Your words: "I've never taught fourth grade." Your third-grade years are adjacent, not fourth-grade work, and the material does not show fourth-grade teaching, so the pack does not bridge the gap. How you would learn fourth-grade work is for you to say as a plan, never as a past. |
| F3 | "two members of our fourth-grade team" (invite; panel composition, not a stated job requirement) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [inferred] | transferability | The sentence carries a curriculum move on your own grade level. It does not show work with a fourth-grade team, so do not stretch it. Answer slot: if you worked with other teachers on the move, say who and how, in your own words; if you did not, say what your part was. |
| F4 | [generic] team leadership (role family; not stated in the invite) | "I've never been a team lead" (your message) | none | [grounded] | capability | Your words: "I've never been a team lead." The invite does not ask for team leadership, but you named it as a gap, so it is rehearsed as a likely probe. |
| F5 | [generic] reading instruction (role family) | "I've run the after-school reading club for the last two years" (your CV) | medium | [inferred] | transferability | The club is after-school. The sentence does not say classroom reading instruction, so the bridge stays at the club. Answer slot: say what the club involved, in your own words; if it measured anything, say what. |
| F6 | [generic] communication with families (role family) | "I write a weekly email to families" (your CV) | medium | [grounded] | none | No gap. Describe the weekly email in those terms. |

**Gap-type routing.** F1 is a gate the material shows met, so it routes by its evidence cell and gets `none`. F2 and F4 are stated absences, so `capability`. F3 and F5 are adjacent work that does not reach the requirement, so `transferability`. F6's quote already reaches its requirement, so `none`.

---

## 3. Prohibited claims

Claims this pack will not coach. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Taught fourth grade, or fourth-grade experience of any kind | Sourced negative, F2 | Plain acknowledgment: "I've never taught fourth grade." No slot about past fourth-grade work. |
| Led the grade team, or led the grade level | Inflated form of F3 | F3's quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The material says the curriculum move, not team leadership. |
| Been a team lead, or led teams | Sourced negative, F4 | Plain acknowledgment: "I've never been a team lead." |
| Ran a reading program for the school | Inflated form of F5 | F5's quote at its own scope: "I've run the after-school reading club for the last two years." |

---

## 4. Persona weights

Panel weighting: the principal carries the hiring-manager pair (Skeptic, Case/Strategist); the team members carry the peer pair (Peer Evaluator, Data-Driven Prober). Weights are shown so you can recalibrate if you know more.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight and depth |
|---|---|---|---|---|
| Skeptic | Probes the fourth-grade gap and the team-lead gap, and asks why now | High. The principal is the hiring authority, and F2 and F4 are the gaps you named, so they are the predictable objections. | Rehearse A2 until it is plain: a plan, not a past. Hold, then concede specifically. | 5 questions |
| Peer Evaluator | Seams with the grade team, what they would need from you, credit and disagreement | High. Two team members are the peer side of the panel. | Reciprocity: what you bring their team, not only what you need. Show disagreement style with equals. | 4 questions |
| Case/Strategist | A live fourth-grade planning problem | Medium. A 45-minute panel often includes one scenario. | Clarify before you structure. Say the order of your thinking aloud. | 3 questions |
| Conversational | A friendly opener asking for your path | Medium. Openers are scored too. | A 90-second arc from your CV lines. | 2 questions |
| Pressure | A time-boxed challenge to your motives or your claims | Low to medium. Panels sometimes time-box. | Pause, restate, hold a claim through two follow-ups, then concede what is real. | 2 questions |
| Data-Driven Prober | Asks how the club was run or what it measured | Low. Your CV has no figures, so there is little to count. | Say plainly what you did and did not measure. | 2 questions |

Total: 18 questions. The panel's individual members are not identified, so personas are assigned to the panel as a whole.

---

## 5. Question banks

### Bank A: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your résumé shows six years in third grade. Why is that the right preparation for a fourth-grade role?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | Say what the third-grade years gave you, in those words. Then say plainly that fourth grade is new to you. Answer slot: name any part of your third-grade work that carries straight into fourth grade, and how you would use it; if none does, say so. | F2 is the stated gap, and this is its most direct form. |
| A2 | "You have never taught fourth grade. How would you be ready on the first day?" | JD | [grounded] "I've never taught fourth grade" | **The highest-ROI rehearsal in this pack.** Open with the plain acknowledgment, then give your plan as a plan: what you would learn first and whom you would ask. Hold through two follow-ups by returning to the plan, never to a past. Concede specifically: name the fourth-grade work you have not done yet. | F2 is the likeliest objection, and it will arrive in some form. A rehearsed, non-defensive answer changes this interview. |
| A3 | "Why move from third grade to fourth grade?" | JD | [generic] | Give your own reason, in your own words. The material does not state one, so the pack supplies none. Answer slot: if the move has a reason you have not yet said aloud, say it now in your own words; if the move has no particular reason, say so plainly. | Motivation probe the Skeptic persona uses. The question makes no claim about your past. |
| A4 | "Tell us about the after-school reading club. How did you run it?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Say what the club involved, in those words and your own. Answer slot: if the club measured anything, say what was counted; if it measured nothing, say so plainly. | F5 is a transferability row. The club is the sentence's scope, so the answer stays there. |
| A5 | "Have you ever led a team?" | JD | [grounded] "I've never been a team lead" | Plain acknowledgment: "I've never been a team lead." Then your real leadership, at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Then how you would learn team leadership, as a plan. | F4 is a stated absence; the plain acknowledgment is its source. Keep the curriculum move at its scope. |

### Bank B: Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you need from us to plan fourth-grade units well in your first month?" | JD | [generic] | Name what you need: materials, planning time, the team's pacing, a standards list. Ask for these specifically. The pack supplies no list of your own. | Reciprocity question from the team members. It asks what you need, which shows you know a seam exists. |
| B2 | "Tell us about a time your grade-level colleagues disagreed about a change. What did you do?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Open prompt. If the curriculum move involved disagreement, say how it was settled and what part you played. Answer slot: if there was no such disagreement, say so, then describe how you would handle one. | The peer persona's disagreement-style probe. The disagreement beat is a slot, because the sentence does not state one. |
| B3 | "How do you handle credit when work spans two teams?" | JD | [generic] | Give a principle: name the people who did the work. If you use the curriculum move as the example, name only what you did, in your own words. | Stem from the peer persona. Answer from a principle first; examples second. |
| B4 | "You write a weekly email to families. What does it cover?" | JD | [grounded] "I write a weekly email to families" | Describe what the email covers, in your own words. Answer slot: if you would keep the same format for fourth-grade families, say so; if you would change it, say what. | The team members will ask how you communicate with families. The question rests on your own sentence. |

### Bank C: Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It's week three. A fourth grader reads two levels below the group. What do you do first?" | CASE | [generic] | Clarify first: what data you have, what the reading block looks like, and whom you would talk to. Then structure: diagnose, group, contact the family, involve the team. Make no claims about past cases. | A live problem from the role. CASE asks about no past, so it presupposes nothing about you. |
| C2 | "A parent emails that their child has moved to a reading group they did not expect. How do you reply?" | CASE | [generic] | Structure the reply: explain the basis for the grouping, invite the parent to talk, and say what you would check first. | Family communication under pressure, which is a likely scenario for this role. |
| C3 | "Plan the first two weeks of a reading unit for a grade you have not taught." | CASE | [generic] | Clarify first: the standards, the materials, and the team's pacing. Then order: standards, then assessment, then plan, then check. Say the order aloud. | Makes the fourth-grade gap a planning problem rather than a confession. |

### Bank D: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk us through your path to this role." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | A 90-second arc in this order: Joliet and six years in third grade; the 2024 curriculum move at its scope; the club; then your reason for applying, in your own words. | The opener is scored. A pre-scripted arc built only from your quoted lines is the safest version. |
| D2 | "What's been the best part of running the reading club?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Answer from your own experience. Answer slot: name one thing that happened in the club, in your words; if nothing stands out, say so. | Casual register, scored: it tests whether you can describe your own work with specifics you actually have. |

### Bank E: Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we pick you over a candidate who has taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" | Pause. Restate the question. Hold on what your quotes carry: six years in third grade and a license for grades 1–6. Concede specifically that you have not taught fourth grade. Do not fold on the whole fit. | Pressure tests composure. The hold has to be one your own quotes support. |
| E2 | "That curriculum move in 2024. How much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold on what the sentence says: you led the move. Answer slot: if others did parts of the move that you did not, name them; say what you did, in your own words. | An attribution probe. The answer is the sentence's scope, not more. |

### Bank F: Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "How do you know the reading club worked? What did you measure?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Answer slot: if you measured anything, say what and how; if you did not, say so plainly and say what you would measure first. Never describe a measure you did not track. | F5 is the transferability row. The probe asks for a measure the material does not show, so the honest branch is ready before the question. |
| F2 | "Your license is listed as active through June 30, 2029. What is your plan for renewal?" | JD | [grounded] "registered and active through June 30, 2029" | State the date in those words. If you have a renewal plan, state it; if not, say what you would check. | The license is the gate (F1). A prober asks for the plan behind the date. |

---

## 6. Requirement coverage

| Requirement | Source | Covered by |
|---|---|---|
| Valid Illinois PEL with elementary endorsement | invite | F2 (license), F1 in the fit snapshot |
| Fourth Grade Teacher position | invite | A1, A2, C3, E1 |
| Two members of the fourth-grade team on the panel | invite | B1, B3 |
| Team leadership (named by you as a gap; not in the invite) | your message | A5 |
| Reading instruction (role family) | [generic] | C1, C3, D2, F1 |
| Communication with families (role family) | [generic] | B4, C2 |
| Motivation for the move | [generic] | A3 |

No stated requirement goes without a question.

---

## 7. Reverse questions

Each asks the panel something, and each has a reason it lands.

1. "What does a successful first semester look like for someone joining the fourth-grade team?" Why it lands: it frames the role by its outcomes and signals that you plan around them.
2. "Which reading materials does fourth grade use now, and where is the team with them?" Why it lands: it shows you look at the current work rather than an archive.
3. "How is the planning split between the teachers on the team?" Why it lands: it tests the team's structure and shows you intend to fit it.
4. "How does the school usually communicate with families each week?" Why it lands: it connects to your weekly email and invites them to compare.
5. (Reciprocity, because two panel members are peers) "What could a new fourth-grade teacher do in the first month that would really help your team?" Why it lands: it asks what you bring to their work rather than only what you need.

No interviewer profile was supplied, so no reverse question is tied to an interviewer's own path.

---

## 8. Sources

- **Provided documents:** the HR invite; your CV (the résumé block in your note); your note.
- **Searches and fetches:** none run. Research depth was not chosen; the choice is in the upgrade menu.
- **Dossier:** none consumed.

**Research tier:** none run (L0 in effect; research was not consented to).

| Target | Status | What it would have moved |
|---|---|---|
| 1. `Halvering Elementary School values` | unavailable | Values cheat sheet (section 10 is dropped without it; no values round was detected) |
| 2. `Orrinsford Community School District interview process` | unavailable | Loop structure and persona weights |
| 3. `Halvering Elementary School strategy` / recent news | unavailable | Grounding brief and current context |
| 4. `Dolores Vantongeren Halvering` | unavailable | Interviewer read and a tailored reverse question |
| 5. Representative `Fourth Grade Teacher` JD | unavailable | Fit-snapshot requirements for the team members' roles |

---

## 9. Upgrade menu

- The job posting or full job description → the `[generic]` rows in the fit snapshot (F4 to F6) become `[grounded]`, and the JD-tagged questions gain their requirement text
- Research depth, L1: a short public search on the district and school → values, loop structure and current context, and a read of the principal's public footprint
- Any focus areas or deliverables HR named (for example, a lesson demonstration) → a graded-deliverable section
- The panel members' names → personas assigned per member, and a reverse question tied to their own path
- Prep time before Thursday → a prioritized prep schedule
