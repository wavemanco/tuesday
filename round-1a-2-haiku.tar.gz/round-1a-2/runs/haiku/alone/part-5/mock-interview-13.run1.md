Your prep pack is saved at `/var/tmp/tuesday-measure/1a2/runs/haiku/alone/part-5/rooms/case-13-denied-8c44c13e/quillmoor_operations_coordinator_interview_pack.md`. I built it from the advert, your message and Hannah's message. I didn't run any web research, so it has no company values or strategy.

**Salary (her Q1).** Say £42,000 once, in your own words, then stop. If she gives the band first, respond to that. The advert's range is £38,000–£44,000, so your figure sits in the upper half. Don't offer a lower number unprompted.

**Notice period (Q2).** You haven't told me yours, so give your actual figure on the call. Don't round it or guess.

**Hybrid (Q3).** Say two days at Avonmouth is fine, and that you wouldn't want more than three. Give your own commute time if she asks; your material doesn't include one.

**Reason for moving (Q4).** Keep it to what you told me: the Bristol office is closing next year, the only offer is relocating to Reading, and you don't want that. Don't add criticism of your current employer.

**Fit-gap map**

| Advert requirement | Your evidence | Gap |
|---|---|---|
| 2+ years in ops/logistics coordination | 4 years as a logistics coordinator | None |
| Coordinate production schedules (planning, warehouse, QA) | Scheduling deliveries for three depots | Production and QA are not in your material. Say so if that's true. |
| Track supplier deliveries, chase late orders | Chase suppliers when orders slip | None |
| Keep stock records accurate | Rebuilt the stock-count spreadsheet; discrepancies fell by about a third over a year | Be ready to explain how the third was counted |
| Confident with Excel | Rebuilt a spreadsheet | Your material doesn't show which features you used |
| ERP (SAP or similar) a plus | Never used SAP; in-house stock system | Say "I haven't used SAP." Don't call the in-house system an ERP. |
| Weekly on-time dispatch reporting | Nothing | Say what you'd track first if you haven't done it |

**Things not to claim:** production or QA scheduling, ERP experience, advanced Excel, or sole credit for the one-third drop.

**Reverse questions for Hannah**
1. What does a typical week look like across planning, the warehouse and QA?
2. How is on-time dispatch measured today, and what is the current figure?
3. Which stock system will I use: the in-house one, or SAP?
4. Which two days are fixed, and who decides the on-site days?
5. What is the band for this role, and is there room within £38,000–£44,000?
6. What happens after this call, and what's the timeline for next steps?

If you tell me your notice period, or any production or QA exposure, I can update the answers that depend on them.

Would you like a drill, where I play Hannah and ask Q1 with follow-ups? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations_coordinator_interview_pack.md -----
# Prep pack: Operations Coordinator, Quillmoor Diagnostics

**Call:** 30-minute phone call with Hannah Lowther (Talent Partner), Thursday 2pm. She will ring the mobile number on your application.
**Round type:** recruiter screen. Relationship: recruiter, not your future manager.
**Built on:** the advert, your message, and Hannah's message. No research was run (L0).

## How to use + type key

- **Personas** describe how a question is asked. **Types** describe what is scored.
- **VAL** values · **EXP** your experience · **JD** the listed job · **CO** company knowledge · **CASE** live problem
- Guidance is scaffolding, not a script. Answer slots are instructions for the interview, not questions to answer here.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | Say the years and the role in those words. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material shows delivery scheduling, not production or QA scheduling. Words: "I schedule deliveries for our three depots." Answer slot: if you had any input into production or QA scheduling, say what it was in your own words; if not, say so and stay with delivery scheduling. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | high | [grounded] | presentation | Reword only that quote: you chase suppliers when orders slip. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | presentation | Say the rebuild and the drop in those terms. The one-third figure is yours to defend (see A6). |
| F5 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | The material shows a spreadsheet you rebuilt, not which Excel skills you used. Answer slot: say which features you used, in your own words; if it was mostly basic work, say so. |
| F6 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | Words: "I haven't used SAP." Then describe the in-house stock system as what it is. Do not call it an ERP. |
| F7 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Nothing in your material shows dispatch reporting. Answer slot: if you reported on delivery timeliness, say what and how often; if not, say so and say what you would track first. |

**Hard gates:** the advert names none. Hybrid pattern and pay are logistics terms, handled in Q1 to Q4.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Production or QA scheduling experience | Inflated form of F2 | F2's quote at its own scope: deliveries for three depots. |
| ERP experience, or calling the in-house stock system an ERP | Inflated form of F6 | "I haven't used SAP," then the in-house system described as it is. |
| Advanced or expert Excel | Inflated form of F5 | F5's quote at its own scope: a spreadsheet you rebuilt. |
| Sole credit for the one-third drop in discrepancies | Inflated form of F4 | The quote, with the attribution question left to A6's answer slot. |

Analysis (not words for you): your material shows delivery scheduling, supplier chasing, and a spreadsheet rebuild. It does not show production scheduling, QA, SAP, or dispatch reporting.

## Persona

**Recruiter screen.** Hannah's message sets the agenda: pay, notice, hybrid pattern, reason for moving, then team and next steps. Expect her to be screening for fit and logistics, not testing depth. Counter-strategy: short, factual answers to the logistics questions, then use your remaining time to ask good reverse questions.

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Q1 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." (your message) | Logistics slot, filled by your figure. Say £42,000 in your own words, once, then stop. If she gives the band first, respond to it. The advert's range is £38,000 to £44,000, so £42,000 sits in its upper half. That is arithmetic on the advert, not market data. | Pay is a logistics question. Your figure fills the slot; nothing else is added to it. |
| Q2 | "What is your notice period?" | JD | [generic] | Logistics slot with no figure given: give your actual notice period. Do not estimate it or round it. | Notice is a logistics question. You have not stated a figure, so the slot is an instruction. |
| Q3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | Say two days at Avonmouth is fine and that you would not want more than three. If she asks about travel time, give your own, in your own words; none is stated in your material. | Location is a logistics question. Your stated limit fills the slot. |
| Q4 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message) | Say the office is closing next year and the only offer is relocation to Reading, which you don't want. Keep it to that. Do not add criticism of your current employer. | Reason for leaving is a logistics question, and your stated reason fills the slot. |
| Q5 | "This role coordinates production schedules between planning, the warehouse and QA. What's your experience there?" | JD | [grounded] "I schedule deliveries for our three depots" (your message) | Story-mapped on F2: deliveries for three depots. Answer slot: if you had any input into production or QA scheduling, say what it was in your own words; if not, say so plainly and stay with delivery scheduling. | F2 is the largest gap against the advert's main requirement, so expect this probe. |
| Q6 | "How do you handle supplier deliveries that are running late?" | JD | [grounded] "chase suppliers when orders slip" (your message) | Say you chase suppliers when orders slip, in those words. Answer slot: describe how you tracked the late order, in your own words. | F3 covers the supplier-chasing line. The slot asks only for what you did. |
| Q7 | "Tell me about your stock records work." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | Story-mapped on F4: the rebuild, and the drop over a year. Answer slot: say how the discrepancies were counted, what the figure is sensitive to, the assumption you would defend least, and which part was yours. | Metric question: the one-third figure gets the defend-the-number slots. |
| Q8 | "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet" (your message) | Answer slot: say which Excel features you used, in your own words. If it was mostly basic work, say so. Do not claim advanced skills. | F5 is low confidence, so the honest answer is the limit, not a stronger claim. |
| Q9 | "Do you have ERP experience, SAP or similar?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." (your message) | Words: "I haven't used SAP." Then describe the in-house stock system and what you did in it. Answer slot: say what you used it for. Do not call it an ERP. | F6 is a stated absence. The plus in the advert is not a requirement, so the answer is short. |
| Q10 | "The role reports weekly on on-time dispatch. Have you produced that kind of report?" | JD | [generic] | Answer slot: if you reported on delivery timeliness, say what and how often. If not, say so plainly and say what you would track first. | F7 has no quote. The advert raises it, so the probe is likely. |

**Coverage:** each advert requirement maps to a question or a stated reason. Advert line "2+ years": F1 (no question; answered in the opening). "Coordinate production schedules": Q5. "Track supplier deliveries, chase late orders": Q6. "Keep stock records accurate": Q7. "Confident with Excel": Q8. "ERP (SAP or similar) a plus": Q9. "Weekly on-time dispatch reporting": Q10. Pay, hybrid pattern: Q1, Q3.

**Coverage note:** the rubric's session total is 18 to 26 questions. This is a 30-minute screen, so the bank is short on purpose.

## Values / principles cheat sheet

Not included. No values-style round was detected, and no published values were provided.

## Reverse questions

Ask Hannah these. Each has a reason it lands.

1. **"What does a typical week look like for this role across planning, the warehouse and QA?"** Lands because it uses the advert's own terms and shows you have read it.
2. **"How is on-time dispatch measured today, and what is the current figure?"** Lands because it is specific, and it prepares you for the reporting requirement.
3. **"Which stock system will I work in: the in-house one, or SAP?"** Lands because it resolves the ERP question in the interview itself.
4. **"Which two days are fixed, and who decides the on-site days?"** Lands because it moves hybrid from a yes or no to how the team runs it.
5. **"What is the band for this role, and is there room within the advertised £38,000 to £44,000?"** Lands because it asks for the number before you commit to yours.
6. **"What happens after this call, and what's the timeline for next steps?"** Lands because the recruiter controls that answer, and it sets your follow-up.

## Sources

- Provided documents: the advert, your message, Hannah's message.
- Searches: none. Fetches: none.

**Research tier:** L0, provided documents only.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | unavailable | Values cheat sheet, section skipped; a screen does not need it for the logistics questions |
| 2. Quillmoor interview process | unavailable | Loop structure; not needed for a recruiter screen |
| 3. Quillmoor strategy / recent news | unavailable | CO bank; would have added a company question |
| 4. Interviewer name + company | n/a | No interviewer beyond Hannah, a recruiter; no profile to research |
| 5. Representative JD | skipped | The advert fixes the fit snapshot |

## Upgrade menu

- A Quillmoor values page or recent news, if pasted → a short company section and a sharper reverse question. Needs research or a pasted page.
- Your notice period, if you want it rehearsed → Q2 becomes a stated answer instead of an instruction.
- Any production or QA exposure, in your own words, if you have it → Q5 and F2 move from answer slots to stated evidence.
- The name of the team manager, if Hannah shares it → a team-specific reverse question.

