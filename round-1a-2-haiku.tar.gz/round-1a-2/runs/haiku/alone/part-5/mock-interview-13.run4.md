Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-5-rooms-case-13-denied-6fc78441/953b556f-2e74-45bb-b5ba-e6502c6d4faf/scratchpad/quillmoor_operations-coordinator_interview_pack.md`.

The short version for Thursday:

- **Pay:** "I'm hoping for £42,000." It sits inside the advert's £38,000–£44,000. You could also ask Hannah for the band first.
- **Notice period:** you haven't told me yours. Have the exact figure ready, because she may ask early.
- **Hybrid:** "Two days at Avonmouth is fine. I live in north Bristol, and I wouldn't want more than three."
- **Reason for moving:** "Our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Keep it factual and don't criticise anyone.
- **SAP:** "I haven't used SAP. We ran our own in-house stock system." Then say how you'd learn it, as a plan.
- **Production scheduling (biggest gap, so rehearse this one most):** start from "I schedule deliveries for our three depots and chase suppliers when orders slip." Then say honestly whether you coordinated timing between teams. If the work was deliveries only, say so and describe how you'd coordinate with planning, the warehouse and QA.
- **Stock figure:** be ready to say how the "about a third" was counted, or say plainly that you don't know.

Questions to ask Hannah are in the pack's reverse-question table. The strongest are how planning, the warehouse and QA hand over a schedule, whether there's ERP training, and where £42,000 sits in the band.

I couldn't run research. Web search was refused in this session, so I haven't checked Quillmoor's values, the interview process or Bristol salary data. The pack uses only the advert, your messages and Hannah's note. Give me permission for search, or paste Quillmoor's values page, and I can add those.

Two one-line offers:
- I can run a live drill: I play Hannah and push on the production-scheduling or SAP answer.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Recruiter screen, Thursday 2pm, 30 minutes by phone, with Hannah Lowther (Talent Partner). Built from the advert, your messages, and Hannah's booking note. Research was not run (see Sources).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD (the listed job), EXP (your own experience), CASE (a live problem).
- The answers are scaffolding, not a script. Say them in your own words.
- Quoted sentences are yours, taken from your messages. Anything in an answer slot is for you to answer truthfully in the call.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | No gap. Say the years and the role in those words. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | high | [grounded] | none | No gap. Say what you do in those terms: deliveries across three depots, chasing when orders slip. |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Say the rebuild and the drop in discrepancies as you did it. Do not add how many counts or how often. |
| F4 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | transferability | The material shows a spreadsheet, not which Excel skills you used. Answer slot: say which Excel features you used to build it, in your own words; if you are not sure how you would rate your Excel, say so. |
| F5 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | low | [inferred] | transferability | Deliveries across depots is adjacent to production scheduling, not the same work. Answer slot: if you coordinated timing between teams to set or change it, say how; if the work was deliveries only, say so and describe how you would coordinate with planning, the warehouse and QA. |
| F6 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show on-time reporting. Answer slot: if you tracked on-time figures, say what and how often; if not, say so and say how you would start. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | none | [grounded] | capability | A plus, not a requirement, and you have stated the gap. Words: "I haven't used SAP. We ran our own in-house stock system." Then how you would learn it, said as a plan, never as a past. |

**Logistics (Hannah's stated agenda)**

| Topic | Your stated position | Provenance | Gap type | Note |
|---|---|---|---|---|
| Salary | "I'm hoping for £42,000." (your message) | [grounded] | none | Inside the advert's £38,000–£44,000. |
| Hybrid | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | [grounded] | none | Fills the hybrid question. |
| Reason for moving | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message) | [grounded] | none | Fills the reason question. |
| Notice period | none given | none | discovery | Answer slot in the call. Not a figure you have given me. |

## Prohibited claims

Not to be coached, with the honest form for each.

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP or any ERP | Stated negative (F7) | "I haven't used SAP." The plus is answered only by that and your plan to learn. |
| Ran or set production schedules | Inflated form of F2 and F5. Your material says deliveries | The quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material does not show production scheduling. |
| Owned on-time dispatch reporting | No quote supports it (F6) | Answer slot only, as in F6. |
| Reduced discrepancies by a third on your own | Inflated form of F3. The quote says the spreadsheet was rebuilt and discrepancies fell over a year, not what caused it | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Do not add other causes or credit. |

## Persona weights

Relationship: recruiter screen. Prior: Conversational plus light Skeptic (`personas.md`).

| Persona | How it shows up here | Likelihood | Why | Counter-strategy |
|---|---|---|---|---|
| Conversational / rapport | Friendly opener, "walk me through your background" | High | Hannah's note is warm and structured | Have a 90-second arc ready. Treat the chatty questions as scored |
| Skeptic | "Why leave, why now?", "This role needs SAP, how do you feel?" | High | Logistics and knockout checks are the screen's job | Rehearse the SAP answer and the reason for moving until they are boring to say |
| Pressure | Rare, unless the call runs short | Low | A screen, not a panel | Pause, restate, answer plainly |
| Data-Driven Prober | Possible on the stock figure | Low to medium | The stock-count claim is a number | Say what you know of how it was counted, and say plainly where you do not know |

Depth: Conversational and Skeptic each get the most rehearsal. Pressure and Prober get one or two.

## Question banks

### Conversational and Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say the figure in your own words: "I'm hoping for £42,000." You can add that you would like to hear the band first, if you want. Do not add a salary history. | Pay is a logistics slot. The figure you gave fills it, so no slot is raised. |
| A2 | "What's your notice period?" | JD | none given | Give your actual notice period in your own words. Hannah may ask this early; have the exact figure ready. | Notice is a logistics slot. You have not stated a figure, so the answer is yours to give. |
| A3 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say: "Two days at Avonmouth is fine. I live in north Bristol, and I wouldn't want more than three." | Hybrid is a logistics slot filled by your own words. |
| A4 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say the closure and the relocation offer in those words. Keep it factual and do not criticise anyone. | This is the reason for leaving. Hannah asked for it directly. |
| A5 | "What's your experience with SAP or other ERP systems?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Say: "I haven't used SAP. We ran our own in-house stock system." Then say how you would learn it, as a plan. | F7 is the knockout most likely to be raised. Rehearse it as a plain answer, not an apology. The plan is what you will do, not what you have done. |
| A6 | "Have you coordinated production schedules across planning, the warehouse and QA?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Start from the quote: deliveries across three depots, and chasing when orders slip. Answer slot: if you coordinated timing between teams to set or change it, say how, in your own words; if the work was deliveries only, say so and describe how you would coordinate with planning, the warehouse and QA. | The production-scheduling line is the largest gap and the most likely probe. This is the highest-return rehearsal in the pack. |
| A7 | "Tell me how you handle late supplier orders." | JD | [grounded] "chase suppliers when orders slip" | Describe one time you chased a late order, in your own words. Answer slot: name the step that got the order moving, if you know it. | Matches the advert's chase-late-orders line, where your quote is strongest. |

### Pressure and Prober (lower weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The stock figure, about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what you know of how it was counted. Name the assumption you would defend least. If you do not know how it was counted, say so. | F3 is the one number on your CV. Being precise about it is safer than explaining it. |
| B2 | "Which Excel skills did you use for that spreadsheet?" | JD | [inferred] "I rebuilt our stock-count spreadsheet" | Answer slot: name the features you used, in your own words. If you are not sure how you would rate your Excel, say so. | F4. The bridge is about what you built, not a rating you have not given. |
| B3 | "On-time dispatch is reported weekly. Have you done that?" | JD | none given | Answer slot: if you tracked on-time figures, say what and how often. If not, say so and say how you would start. | F6 is a gap your material does not show. Rehearse the honest answer. |

### Reverse questions for Hannah

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do planning, the warehouse and QA usually hand over a production schedule?" | Tests the production-scheduling gap from the other side and shows you understand the work. |
| R2 | "Is there a training path for the ERP system, and does it cover SAP?" | Addresses the SAP gap directly and tells you whether the company would invest in you. |
| R3 | "How is on-time dispatch measured and reported at the moment?" | Shows you understand the weekly report, and tells you what you would take over. |
| R4 | "Which days does the team usually sit at Avonmouth, and is the hybrid pattern fixed?" | Checks the two-to-three-day pattern you named, and shows you have thought about it. |
| R5 | "What is the band for this role, and where does £42,000 sit within £38,000 to £44,000?" | Lets you hear the band before you answer, which is a reasonable thing to ask. |
| R6 | "Who would I report to, and is this a new post or a replacement?" | Gets the team and the context, and is the question a peer would ask. |

## Coverage

| Requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A7 (background), F1 |
| Track supplier deliveries and chase late orders | A7, F2 |
| Keep stock records accurate | B1, F3 |
| Confident with Excel | B2, F4 |
| Coordinate production schedules across planning, warehouse and QA | A6, F5 |
| Weekly on-time dispatch reporting | B3, F6 |
| ERP (SAP or similar), a plus | A5, F7 |
| Pay band | A1, R5 |
| Hybrid at Avonmouth | A3, R4 |

## Sources

- **Provided documents:** the advert (text pasted in your request); your messages (background, SAP, Avonmouth, salary, reason for moving); Hannah's booking note.
- **Research tier:** L1, searches 0 of 6, fetches 0 of 2.
- **Searches sent:**
  - "Quillmoor Diagnostics values": refused (search permission not granted in this session).
  - "Operations Coordinator salary Bristol": refused (same).
- **Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | unavailable | The values cheat sheet. Dropped, since no values round is detected and no values page was supplied |
| 2. Interview process | unavailable | Loop structure. The call is a single recruiter screen, so persona weights are set from the relationship prior alone |
| 3. Strategy / recent news | unavailable | Current strategy for a CO question. No CO round is detected, so nothing was lost for this call |
| 4. Interviewer (Hannah Lowther) | unavailable | Interviewer read. Hannah's role is known from the booking note; no public profile was checked |
| 5. Representative JD | skipped | The supplied advert fixes the fit snapshot and the JD questions |

- Persona weights and question banks use only the advert, your messages and Hannah's note.
- The salary band and the Quillmoor values were not checked. Treat the band in the advert as the only source.

## Upgrade menu

- Your notice period, stated in your own words → A2 becomes a grounded answer instead of an instruction.
- The Quillmoor values page (pasted) → a values cheat sheet, and A6 and A7 can be mapped to a published value.
- Search permission granted for this session → the company's values, interview process and the Bristol salary band can be checked, and rows 1 to 4 in the accounting can be filled.
- Your Excel details (which functions you used) → F4 and B2 become grounded, and the bridge gets a concrete sentence.
- The on-time report details, if you had one → F6 and B3 become grounded.
- A tuesday-dossier.md recording the gaps this prep exposed → carried into later sessions.
