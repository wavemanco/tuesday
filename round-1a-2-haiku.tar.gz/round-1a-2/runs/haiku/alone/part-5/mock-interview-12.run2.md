Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." before your interview is confirmed, to "reply with a photo of your passport and your bank details before the interview", and it offers "a cheque for €1,850" that you "deposit" before you "send the balance on to the vendor". Fee payments before interview, passport and bank details before any offer, and a cheque you deposit and pay the balance from are a known scam pattern, and this job is very likely a scam. Hold all of them: don't pay, deposit any cheque, or send documents or bank details until you've checked the invite with the employer, using a phone number or address from its own website or careers page, not anything in the email. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-5-rooms-case-12-denied-b8367d4f/7d46a438-1443-404c-9a2f-9f27218600a1/scratchpad/brennock_remote-administrative-assistant_interview_pack.md. It's built for a 30-minute video call with the office manager, the format your invite gives.

# Remote Administrative Assistant, Brennock Facilities Ltd: interview prep pack

Interview format (from the invite): 30-minute video call with the office manager. No round or interviewer profile was given, so personas are weighted from the round type alone.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: **JD** (the ad's duties), **EXP** (your own experience), **CASE** (a live problem).
- Guidance is scaffolding, not a script. Say answers in your own words.
- Question IDs are letter-by-persona (A1, B2...) so you can refer back to them.

## Prep triage

Prep time wasn't given, so there's no timed schedule. In order:

1. Rehearse **B1** until you can answer it without stalling. It's the question most likely to come up in some form.
2. Rehearse **C1** (the opener) and **A4** (the appointment book) so your background sounds natural.
3. Rehearse the **A1** and **A2** scenarios aloud once each.
4. Everything else is insurance.

## Fit snapshot

Requirements are the duties from the job ad as you summarised it. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (job ad, as you summarised it) | "where I ran the appointment book for four physios" (your message) | medium | [grounded] | transferability | Your material shows a clinic appointment book for four people, not calendars for an admin's manager. Say: "I ran the appointment book for four physios." Answer slot: if you've managed someone else's diary outside the clinic, say whose and how; if not, say so plainly and say how you'd learn their calendar set-up. |
| F2 | "booking travel" (job ad) | none given | none | [grounded] | discovery | Your material doesn't show travel booking. Answer slot: if you've booked travel for anyone, say what, for whom and in which tool; if not, say so plainly and say how you'd learn the booking tool and travel policy first. |
| F3 | "preparing documents in Word and Excel" (job ad) | "I'm good with Word, okay with Excel" (your message) | medium | [grounded] | presentation | Your own level, in your words: good with Word, okay with Excel. Don't round Excel up. Answer slot: if asked for an Excel task, name one you've actually done; if none, say so. |
| F4 | "processing supplier invoices" (job ad) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | Chasing unpaid invoices is adjacent to processing them. Say: "I chased unpaid invoices." Answer slot: if you entered, matched or approved invoices for payment, say which steps; if you only chased them, say so and say what you'd learn about the payment process. |
| F5 | "Remote Administrative Assistant" (employer's invite) | none given | none | [grounded] | discovery | Your material doesn't show remote working. Answer slot: if you've worked from home or remotely, say how; if not, say so plainly and say how you'd keep a remote routine. |

## Prohibited claims

These are claims this pack won't coach, because the material doesn't support them.

| Not coached | Basis | Honest form |
|---|---|---|
| "Managed calendars for executives" | Inflated form of F1 | The F1 quote at its own scope: "I ran the appointment book for four physios." Limit, in the pack's analysis: your material shows a clinic appointment book, not executive calendars. |
| "Processed supplier invoices through to payment" | Inflated form of F4 | The F4 quote at its own scope: "chased unpaid invoices." Limit, in the pack's analysis: your material shows chasing, not processing. |
| "Advanced Word and Excel" | Inflated form of F3 | "good with Word, okay with Excel." |

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live scheduling, travel and invoice problems | Highest (weight 4): the ad's duties are operational, and a 30-minute call is where they get tested | Clarify, then sequence the steps aloud |
| Conversational / Rapport | Opener and a casual "what's a typical day" | Medium (weight 3): the usual first few minutes of a short call; still scored | 90-second arc, then answer casual questions as if scored |
| Skeptic | "Where's the travel and Excel experience?" | Medium (weight 3): the two duty gaps (F2, F5) are the obvious probes | Answer the gap in your own words; bring a week-one plan |
| Pressure | Time-boxed "why you over someone with more experience" | Low (weight 2): a short call with one interviewer tends toward fewer challenges | Hold what you have, concede the rest plainly |

## Question banks

### Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A director needs to fly to Cork for a 9am meeting on Thursday, and two of their calls clash that morning. What do you do?" | CASE | [generic] | Clarify first: which call can move, who must attend, the budget and the latest acceptable flight. Offer two options with the cost of each. Confirm the change with the attendees and tell the director. Say which step you'd take first. | A live problem from the ad's calendar and travel duties (F1, F2). Generic: a pattern for the problem, with no claim about your past. |
| A2 | "Walk me through processing a supplier invoice from arrival to payment." | JD | [generic] | Order: log it on arrival; check it against the order or agreed price; get approval; code it to the right account; schedule payment; file the copy. Say what you'd do if it doesn't match. | Covers "processing supplier invoices", which no quote reaches (F4). It tests the process, not your history. |
| A3 | "How would you find out the booking tool and travel policy on your first day?" | JD | [generic] | Ask the office manager for the tool, the policy and one example booking. Read the policy before booking. Keep a short log of what you learn. | Covers the travel gap (F2) with a plan, not a claim. Generic: makes no claim about your past. |
| A4 | "How did you keep the appointment book for four physios from double-booking?" | EXP | [grounded] "where I ran the appointment book for four physios" | Name the book and the four physios, in your words. Answer slot: if you had a method for avoiding clashes, say what it was; if the clinic's system prevented them, say so and what you did with it. | F1 is the evidence and the likeliest probe. The method isn't in your material, so it's a slot, not a claim. |

### Conversational / Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me a bit about yourself." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | 90-second arc: the clinic, the two years, the appointment book for four physios, chasing unpaid invoices, then why this role. Give your reason for applying in your own words; it isn't in your material. | The opener, scored casually. F1 and F4 are the evidence it draws on. |
| C2 | "What's a typical day like in your current job?" | EXP | [grounded] "where I ran the appointment book for four physios and chased unpaid invoices" | Walk the day in the order it happens, using only the two quoted duties. Don't add tasks to make the day sound fuller. | A casual question about F1 and F4, still scored. |
| C3 | "What software are you most comfortable with day to day?" | JD | [grounded] "I'm good with Word, okay with Excel" | Word first, then Excel, in the same words as your message. Don't stretch the Excel level. | F3 in a casual register. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Booking travel and managing a calendar for someone you haven't worked with, from home, on day one. How would you do that?" | JD | [grounded] "where I ran the appointment book for four physios" | **Highest-ROI prep in this pack.** Answer slot: if you've booked travel or managed someone's calendar, say what, for whom and in which tool; if not, say so plainly, then give the first-week plan from A3. Hold through two follow-ups by returning to the plan, not by adding experience. | F2 and F5 have no quote, so this is the likeliest probe. Your honest answer is the plan; an invented history fails the second follow-up. |
| B2 | "You're okay with Excel. What would you do with a spreadsheet you've never seen?" | JD | [grounded] "okay with Excel" | Say what you'd check first (headers, totals, formulas), what you'd ask the owner, and that you'd flag anything you couldn't work out. Answer slot: if you've built a spreadsheet for work, name one feature you used; if not, say so. | Probes the level in F3. The honest answer is the level you stated. |
| B3 | "Admin roles like this run on Word and Excel every day. Where would you be slowest?" | JD | [grounded] "I'm good with Word, okay with Excel" | Name the Excel features you'd learn first and concede the slowness plainly. Don't claim speed you haven't shown. | F3's limit, asked directly. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why should we hire you over someone who has already done travel booking and invoice processing full-time?" | JD | [grounded] "where I ran the appointment book for four physios and chased unpaid invoices" | Hold: name what you do bring, in those quoted words. Hold through two follow-ups. Concede specifically: they may be faster on travel and invoices; say how you'd close that in your first month. | A pressure answer holds a position, then concedes uncertainty without folding on the core claim. |
| P2 | "How much of that appointment book was actually you?" | EXP | [grounded] "where I ran the appointment book for four physios" | Say what you did: kept the book for four physios, in your words. Answer slot: if the clinic set the system and its rules, say so; then say which parts you ran. | Tests attribution under pressure (F1). The honest answer separates the system from your work. |

### Requirement coverage

| Requirement (job ad) | Covered by |
|---|---|
| Managing calendars | A4, B1, P2 |
| Booking travel | A3, B1 |
| Preparing documents in Word and Excel | C3, B2, B3 |
| Processing supplier invoices | A2, P1 |
| Remote working (from the invite's title) | B1, reverse question 3 |

## Reverse questions

1. "Which calendar and travel-booking tools does the team use?" Why it lands: shows you read the ad, and gives you the tool names to use in your answers.
2. "What does a normal week look like in this role?" Why it lands: shows you're weighing the workload, not just the title.
3. "Who provides equipment for remote work, and is any cost ever passed to the person in the role?" Why it lands: a plain question an employer can answer clearly, and the answer tells you about the offer.
4. "How will the next step be confirmed, and by whom?" Why it lands: a real process has a named contact and a clear next step.
5. "What would make someone in this role successful after three months?" Why it lands: aims at the gaps in F2 and F4 and shows you plan to close them.

## Sources

- Provided: your message (background and duties summary), and the employer's invite (quoted in the warning above).
- Research: none run. The research tier is L0, so every claim in the pack rests on your own material. Check the role and interview format on Brennock's own website or careers page.

**Research tier:** L0, no searches or fetches run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Values cheat sheet (not produced: no values round detected) |
| 2. Company interview process | unavailable | Loop structure; persona weights follow the round type alone |
| 3. Company strategy / recent news | unavailable | Grounding brief for a role-specific pitch |
| 4. Interviewer name and company | n/a | No interviewer name was given |
| 5. Representative JD | skipped | The duties you summarised fix the fit snapshot |

## Upgrade menu

- The full job ad text → F1, F2 and F4 gain their exact wording, and the ad's own requirement list enters the coverage table
- Your CV → quotes for the rows currently carried by your message alone
- The office manager's name → a tailored reverse question
- Brennock's careers page, found on its own website → checks the role title, duties and interview format against a source you chose
- tuesday-dossier.md → records the gaps this prep exposed, for later sessions

I can run a live drill on B1, the question most likely to come up, with me playing the Skeptic. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.

Where did you see the ad, and can you paste its full text?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote-administrative-assistant_interview_pack.md -----
# Remote Administrative Assistant, Brennock Facilities Ltd: interview prep pack

Interview format (from the invite): 30-minute video call with the office manager. No round or interviewer profile was given, so personas are weighted from the round type alone.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: **JD** (the ad's duties), **EXP** (your own experience), **CASE** (a live problem).
- Guidance is scaffolding, not a script. Say answers in your own words.
- Question IDs are letter-by-persona (A1, B2...) so you can refer back to them.

## Prep triage

Prep time was not given, so there is no timed schedule. In order:

1. Rehearse **B1** until you can answer it without stalling. It is the question most likely to come up in some form.
2. Rehearse **C1** (the opener) and **A4** (the appointment book) so your background sounds natural.
3. Rehearse the **A1** and **A2** scenarios aloud once each.
4. Everything else is insurance.

## Fit snapshot

Requirements are the duties from the job ad as you summarised it. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (job ad, as you summarised it) | "where I ran the appointment book for four physios" (your message) | medium | [grounded] | transferability | Your material shows a clinic appointment book for four people, not calendars for an admin's manager. Say: "I ran the appointment book for four physios." Answer slot: if you have managed someone else's diary outside the clinic, say whose and how; if not, say so plainly and say how you would learn their calendar set-up. |
| F2 | "booking travel" (job ad) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say what, for whom and in which tool; if you have not, say so plainly and say how you would learn the booking tool and travel policy first. |
| F3 | "preparing documents in Word and Excel" (job ad) | "I'm good with Word, okay with Excel" (your message) | medium | [grounded] | presentation | Your own level, in your words: good with Word, okay with Excel. Do not round Excel up. Answer slot: if asked for an Excel task, name one you have actually done; if none, say so. |
| F4 | "processing supplier invoices" (job ad) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | Chasing unpaid invoices is adjacent to processing them. Say: "I chased unpaid invoices." Answer slot: if you entered, matched or approved invoices for payment, say which steps; if you only chased them, say so and say what you would learn about the payment process. |
| F5 | "Remote Administrative Assistant" (employer's invite) | none given | none | [grounded] | discovery | Your material does not show remote working. Answer slot: if you have worked from home or remotely, say how; if not, say so plainly and say how you would keep a remote routine. |

## Prohibited claims

These are claims this pack will not coach, because the material does not support them. Each has an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "Managed calendars for executives" | Inflated form of F1 | The F1 quote at its own scope: "I ran the appointment book for four physios." Limit, in the pack's analysis: your material shows a clinic appointment book, not executive calendars. |
| "Processed supplier invoices through to payment" | Inflated form of F4 | The F4 quote at its own scope: "chased unpaid invoices." Limit, in the pack's analysis: your material shows chasing, not processing. |
| "Advanced Word and Excel" | Inflated form of F3 | "good with Word, okay with Excel." |

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live scheduling, travel and invoice problems | Highest (weight 4): the ad's duties are operational, and a 30-minute call is the place to test them | Clarify, then sequence the steps aloud |
| Conversational / Rapport | Opener and a casual "what's a typical day" | Medium (weight 3): usual first few minutes of a short call; still scored | 90-second arc, then answer the casual questions as if scored |
| Skeptic | "Where's the travel and Excel experience?" | Medium (weight 3): the two duty gaps (F2, F5) are the obvious probes | Answer the gap in your own words; a plan for week one |
| Pressure | Time-boxed "why you over someone with more experience" | Low (weight 2): a short call with one interviewer tends toward fewer challenges | Hold what you have, concede the rest plainly |

## Question banks

### Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A director needs to fly to Cork for a 9am meeting on Thursday, and two of their calls clash that morning. What do you do?" | CASE | [generic] | Clarify first: which call can move, who must attend, the budget and the latest acceptable flight. Offer two options with the cost of each. Confirm the change with the attendees and tell the director. Say which step you would take first. | A live problem from the ad's calendar and travel duties (F1, F2). Generic: a pattern for the problem, with no claim about your past. |
| A2 | "Walk me through processing a supplier invoice from arrival to payment." | JD | [generic] | Order: log it on arrival; check it against the order or agreed price; get approval; code it to the right account; schedule payment; file the copy. Say what you would do if it does not match. | Covers "processing supplier invoices", which no quote reaches (F4). It tests the process, not your history. |
| A3 | "How would you find out the booking tool and travel policy on your first day?" | JD | [generic] | Ask the office manager for the tool, the policy and one example booking. Read the policy before booking. Keep a short log of what you learn. | Covers the travel gap (F2) by a plan, not a claim. Generic: it makes no claim about your past. |
| A4 | "How did you keep the appointment book for four physios from double-booking?" | EXP | [grounded] "where I ran the appointment book for four physios" | Name the book and the four physios, in your words. Answer slot: if you had a method for avoiding clashes, say what it was; if the clinic's system prevented them, say so and what you did with it. | F1 is the evidence and the likeliest probe. The method is not in your material, so it is a slot, not a claim. |

### Conversational / Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me a bit about yourself." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | 90-second arc: the clinic, the two years, the appointment book for four physios, chasing unpaid invoices, then why this role. Say the reason for applying in your own words; it is not in your material. | The opener, scored casually. F1 and F4 are the evidence it draws on. |
| C2 | "What's a typical day like in your current job?" | EXP | [grounded] "where I ran the appointment book for four physios and chased unpaid invoices" | Walk the day in the order it happens, using only the two quoted duties. Do not add tasks to make the day sound fuller. | A casual question about F1 and F4, still scored. |
| C3 | "What software are you most comfortable with day to day?" | JD | [grounded] "I'm good with Word, okay with Excel" | Word first, then Excel, in the same words as your message. Do not stretch the Excel level. | F3 in a casual register. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Booking travel and managing a calendar for someone you haven't worked with, from home, on day one. How would you do that?" | JD | [grounded] "where I ran the appointment book for four physios" | **Highest-ROI prep in this pack.** Answer slot: if you have booked travel or managed someone's calendar, say what, for whom and in which tool; if you have not, say so plainly, then give the first-week plan from A3. Hold through two follow-ups by returning to the plan, not by adding experience. | F2 and F5 are the requirements with no quote, so this is the likeliest probe. Your honest answer is the plan; a made-up history fails the second follow-up. |
| B2 | "You're okay with Excel. What would you do with a spreadsheet you've never seen?" | JD | [grounded] "okay with Excel" | Say what you would check first (headers, totals, formulas), what you would ask the owner, and that you would flag anything you could not work out. Answer slot: if you have built a spreadsheet for work, name one feature you used; if not, say so. | Probes the level in F3. The honest answer is the level you stated. |
| B3 | "Admin roles like this run on Word and Excel every day. Where would you be slowest?" | JD | [grounded] "I'm good with Word, okay with Excel" | Name the Excel features you would learn first and concede the slowness plainly. Do not claim speed you have not shown. | F3's limit, asked directly. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why should we hire you over someone who has already done travel booking and invoice processing full-time?" | JD | [grounded] "where I ran the appointment book for four physios and chased unpaid invoices" | Hold: name what you do bring, in those quoted words. Hold through two follow-ups. Concede specifically: they may be faster on travel and invoices; say how you would close that in your first month. | A pressure answer holds a position, then concedes uncertainty without folding on the core claim. |
| P2 | "How much of that appointment book was actually you?" | EXP | [grounded] "where I ran the appointment book for four physios" | Say what you did: kept the book for four physios, in your words. Answer slot: if the clinic set the system and its rules, say so; then say which parts you ran. | Tests attribution under pressure (F1). The honest answer separates the system from your work. |

### Requirement coverage

| Requirement (job ad) | Covered by |
|---|---|
| Managing calendars | A4, B1, P2 |
| Booking travel | A3, B1 |
| Preparing documents in Word and Excel | C3, B2, B3 |
| Processing supplier invoices | A2, P1 |
| Remote working (from the invite's title) | B1, reverse question 3 |

## Reverse questions

1. "Which calendar and travel-booking tools does the team use?" Why it lands: shows you read the ad, and gives you the tool names to use in your answers.
2. "What does a normal week look like in this role?" Why it lands: shows you are weighing the workload, not just the title.
3. "Who provides equipment for remote work, and is any cost ever passed to the person in the role?" Why it lands: a plain question an employer can answer clearly; the answer tells you about the offer.
4. "How will the next step be confirmed, and by whom?" Why it lands: a real process has a named contact and a clear next step.
5. "What would make someone in this role successful after three months?" Why it lands: aims at the gaps in F2 and F4 and shows you plan to close them.

## Sources

- Provided: your message (background, duties summary), and the employer's invite (quoted in the message that presents this pack).
- Research: none run. The research tier is L0, so every pack claim rests on your own material. Verify the role and the interview format through Brennock's own website or careers page.

**Research tier:** L0, no searches or fetches run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Values cheat sheet (not produced: no values round detected) |
| 2. Company interview process | unavailable | Loop structure; persona weights follow the round type alone |
| 3. Company strategy / recent news | unavailable | Grounding brief for a role-specific pitch |
| 4. Interviewer name and company | n/a | No interviewer name was given |
| 5. Representative JD | skipped | The duties you summarised fix the fit snapshot |

## Upgrade menu

- The full job ad text → F1, F2 and F4 gain their exact wording, and the ad's own requirement list enters the coverage table
- Your CV → quotes for the rows currently carried by your message alone
- The office manager's name → a tailored reverse question
- Brennock's careers page, found on its own website → checks the role title, duties and interview format against a source you chose
- tuesday-dossier.md → records the gaps this prep exposed, for later sessions
