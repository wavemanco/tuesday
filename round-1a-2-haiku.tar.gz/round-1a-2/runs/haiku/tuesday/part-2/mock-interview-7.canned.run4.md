Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-7-canned-15ec3fb8/aa4d5f42-f90a-40b7-a5f0-4b918cee9633/scratchpad/Saltmarsh_Live_Operations_Producer_interview_pack.md`. I built it as a hiring-manager round, since your note didn't say who you're meeting. It uses only your message and the JD, because I haven't run any research yet.

The main thing to prepare: Tobias will likely press on the team-leadership gap against the JD's line about coordinating design, art, engineering and community. That's question S1 in the pack, and it's the one I'd rehearse most. Your answers should lead with what you actually did: the two-year content-drop calendar and the QA checklist. Then say plainly that you haven't led a team, and give a concrete plan for coordinating without line authority.

The pack also flags where your material is thin: one title versus two, no clear post-event review, and no in-app purchase work. Each has a plain acknowledgment and a bridge you can say without stretching.

Want me to play the Skeptic on S1 as a drill? I can also save a `tuesday-dossier.md` recording these gaps for later sessions, or convert the pack to Word.

Two questions to sharpen it:
1. Is Friday a hiring-manager round with Tobias, or a different round (screen, panel, peer)? The answer reweights the personas.
2. May I run light research (up to 6 searches and 2 page fetches) on Saltmarsh's published values, its interview process, and Tobias's public talks and writing? I'd use public material only.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh_Live_Operations_Producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep pack

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager, not yet confirmed. Round length: 60 minutes. Built from your message and the JD only. No research has run yet (L0).

## How to use

Personas are how a question arrives. Types are what is being scored:

- **JD**: a stated responsibility or qualification
- **EXP**: a deep-dive on something you did
- **CASE**: a live problem from the role, solved aloud
- **VAL**: values alignment (not detected for this company yet)
- **CO**: company and strategy knowledge (needs research)

The guidance is scaffolding, not a script. Say it in your own words. Where a line says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly that the practice was not yours.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one title and weekly content drops, not live events across two titles. Keep it there: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the two-title scope makes a probe on a second calendar likely. If you planned across more than one title, or beyond weekly drops, say what. If not, say so and describe how you would take on the second title. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | The material is silent on coordinating the four teams, and the QA line touches only one of them. Do not stretch it. Answer slot: name the teams you worked with on a content drop and what each needed from you, in your own words. If the work ran mainly through the calendar and QA, say so. |
| F3 | "own the post-event review" (JD) | none given | none | [grounded] | discovery | Your material does not show a post-event review. Answer slot: if you ran one, say what it covered and what changed after it. If none was run, or it was not yours, say so plainly and say how you would run one. |
| F4 | "the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the KPI line in other terms. Words: "I presented the monthly retention numbers to the studio head." Do not extend it to owning KPIs. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | Words: "I wrote the release checklist our QA team still uses." Write and manage are different verbs. Expect a probe on how the checklist runs each release. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | Four years meets the length. The material does not say the title was live-service, though weekly drops are a live-service pattern. Words: "For four years I worked as an associate producer at a puzzle-game studio." This is a length requirement, not a gate. Expect a probe on the title's model. |
| F7 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Expect a probe on the calendar itself, so know what it looked like in practice. |
| F8 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | Your material says you presented the numbers, not how they were built. Words: "I presented the monthly retention numbers to the studio head." Answer slot: expect a probe on the definition and the cohort window. If you know which the studio used, say so. If you did not build the figure, say so plainly. |
| F9 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | Words: "I wrote the release checklist our QA team still uses." No writing sample is in the material, so this stays medium. |
| F10 | People leadership on a live team (not in the JD, [generic]) | "Never led a team" (your message) | none | [grounded] | capability | Words: "I haven't led a team." Then how you would coordinate without line authority, as a plan and never as a past. |
| F11 | In-app purchase economics for mobile titles (not in the JD, [generic]) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan. |

## Prohibited claims

These are not coached, in any cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated | "I haven't led a team." Plain acknowledgment. |
| Worked on a game with in-app purchases | Negative you stated | "I haven't worked on a game with in-app purchases." Plain acknowledgment. |
| Ran the live-events calendar for two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." The limit is this pack's observation: your material says one title. |
| Owned the post-event review and its KPIs | Inflated form of F3 and F4 | F4's quote at its own scope. F3 is an answer slot only. |
| Coordinated design, art, engineering and community on updates | Inflated form of F2 | F2's answer slot. Nothing beyond the QA line is stated. |
| Managed the release checklist | Inflated form of F5 | "I wrote the release checklist our QA team still uses." |
| Had a live-service title | Inflated form of F6 | "4 years as an associate producer at a puzzle-game studio," with the title's model in your words. |

## Persona table

Relationship: hiring manager, assumed. Prior from the relationship table: Case/Strategist and Skeptic lead. The Prober follows from the retention line in the JD. Interviewer signals: none beyond a title, so no interviewer read.

| Persona | How it shows up | Likelihood, with reasoning | Weight | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Quiet probing of the team-leadership and in-app purchase gaps | Very high. The JD asks for coordination across four teams, and you have stated two negatives that touch it. | 5 | Calibrated candor: the plain acknowledgment, then a plan. Hold the calendar and the checklist as the evidence. |
| Case/Strategist | Live problems on the two-title calendar | High. A hiring manager buys capability by testing the actual job. | 5 | Clarify, then structure, then metrics, then risks. Say the framework briefly. |
| Data-Driven Prober | Retention numbers and KPI definitions | Medium to high. You presented retention, and the JD names it. | 4 | Know your definitions, say when you don't know the method, and name the weakest assumption you know of. |
| Pressure | Attribution and composure under a stronger profile | Medium. Hiring managers use this once or twice. | 2 | Hold through two follow-ups, then concede a specific limit. |
| Conversational | Biography opener and a casual question on a game you play | Certain to open, and scored anyway. | 2 | A 90-second arc from your quotes only. Name a game you actually play. |

## Question banks

Ordered by weight. 18 questions in total.

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You've never led a team. How do you coordinate design, art, engineering and community on an update when none of them report to you?" | JD | [grounded] "Never led a team" (your message); "coordinate design, art, engineering and community teams on each update" (JD) | Open with the plain words: "I haven't led a team." Then the coordination you can describe from your material, the calendar and the QA checklist, and what those needed from other teams in your words. Then your plan for influence without authority: the decisions you would put in writing, and who you would bring in first. Hold through two follow-ups by returning to the calendar and the checklist. Concede plainly that coordinating four teams without authority is what you would learn first. Answer slot: if you coordinated a content drop with other teams, say which ones and what each needed from you. If the work ran mainly through the calendar and QA, say so. | This is the highest-ROI prep in the pack. The leadership negative sits against the JD's coordination line (F10 and F2), and a hiring manager tests it first. |
| S2 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] persona stem | Name one real weakness, not a humble one: cross-team coordination without authority, or in-app purchase economics. Then a first-30-day plan: which decisions you would sit in on, which calendars you would read, what you would ask engineering. Speakable in 90 seconds. | The Skeptic's stock stem. The answer is candor plus a plan, and it names no past. |
| S3 | "I don't see in-app purchases in your background. How would you handle monetisation decisions on a title?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then how you would learn the monetisation side, who on the team you would lean on, and what you would check in the first weeks. Answer slot: if any of your work touched purchase, offer or pricing decisions, say what. If none did, say so. | F11. The negative is yours, so the gap is named, not bridged. |
| S4 | "You presented the retention numbers. Presenting isn't owning. What did you own?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold the quote: "I presented the monthly numbers to the studio head." Then what you did with them, in your own words, from the calendar work. Hold through two follow-ups. If you did not own the KPIs, concede that plainly. | F4 against "own ... the KPIs it reports". The probe is about the verb, so hold the verb you used. |
| S5 | "Four years on a puzzle game. Was it live-service, and how did it make money?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Describe the title's model in your words: weekly content drops, as the quote shows. If you know how it earned, say so. If you were not on that side of the business, say so plainly. | F6. The material shows a live-service pattern, not the label, and monetisation is the probe that follows. |

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You're taking over live events for two mobile titles. Walk me through how you'd plan the calendar for next quarter." | CASE | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Clarify first: current cadence, what is already committed, team capacity, each title's KPI targets. Then the objective, the sequence, what each team needs and by when, the release checklist gates, the metric per event, and the risk you would watch. Name the one assumption you would check first. Speakable in 90 to 120 seconds. | The most likely live problem on the stated scope. The structure is [generic]. The question presupposes nothing about you. |
| C2 | "Day-7 retention on one title fell three points after last week's drop. Diagnose it." | CASE | [grounded] "comfortable with player-retention metrics" (JD) | Clarify the metric definition and cohort window. Check whether the drop coincided with the release, a bug, or a reward or price change, and which cohorts moved. Name the first thing you would ask for: the denominator. | Tests the JD's retention line. The method is [generic]. |
| C3 | "QA flags one checklist item as failing the night before a release. What happens next?" | CASE | [grounded] "manage the release checklist with QA" (JD) | Say what the item guards, who decides hold versus ship, the player impact, what design and engineering need to know, and the mitigation if it ships. Say what you would not do: ship over QA's objection without the decision-maker. | Candidates often answer the checklist as a document. This question asks for a decision. Ties to F5. |
| C4 | "Players say the last event's rewards felt unfair. What do you do in the next 48 hours?" | CASE | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Triage: pull the data, decide what to say to the community and when, bring in the right people on design and engineering, and decide what would change in the next event. | The JD's community line, put under a clock. |
| C5 | "Design wants a bigger event and engineering says the build can't carry it. How do you decide?" | CASE | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Clarify the constraint and the date. Name the trade-off in terms the team can check. Propose options with their costs. Decide with a named owner and a fallback, and say what you would write down. | Tests coordination without authority (S1's gap) in a live form. Presupposes nothing about you. |

### Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "How was the monthly retention number you presented calculated?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: if you know how it was calculated, say the definition, the cohort window, and what it was sensitive to, in your own words. If you did not build the figure, say who did, and say plainly that you don't know the method. | F8. A presented metric is a probe magnet. |
| P2 | "What's the difference between D1 and D7 retention, and which one did your studio watch?" | JD | [grounded] "comfortable with player-retention metrics" (JD); "Presented the monthly retention numbers to the studio head." (your message) | A two-sentence definition, spoken plainly. Answer slot: which window the studio watched, if you know it. If you don't, say so. | The JD's retention line is the scoring item, and definitional precision is a quick test. |
| P3 | "A KPI you report went up 4% while revenue fell. What do you check first?" | JD | [grounded] "the KPIs it reports" (JD) | Check the definitions and any change in them, the cohort mix, overlap with events or promotions, and the denominator. Name the weakest assumption before they do. The method is [generic]. | Tests "the KPIs it reports" by reasoning, not by history. |
| P4 | "On your calendar, who ran the post-event review, and what was in it?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message); "own the post-event review" (JD) | Answer slot: if you ran a post-event review, say what it covered and what changed after it. If none was run, or it was not yours, say so plainly and describe what you would put in one. | F3. The JD raises the review, and your quote does not carry it. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T1 | "Sixty seconds: why you over someone who has run two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message); "Wrote the release checklist our QA team still uses." (your message) | Hold through two follow-ups: a two-year calendar on one title, and a checklist QA still uses. Concede: you haven't run two titles. Say what you would do to close that in the first month. Don't lead with the negative. | A stress stem tests composure against a stronger profile. |
| T2 | "That checklist. How much of how QA works is actually yours?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Hold: you wrote it, and QA still uses it. Concede: how QA runs each release is their process. Say what you would ask them. | Tests attribution on F5. |

### Rapport builder (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | A 90-second arc in these beats: the studio, the calendar, the checklist, the retention reporting, and why you want two live titles. The last beat is your reason, in your own words. | Casual register, scored. The arc uses only your quoted sentences. |
| V2 | "What mobile game are you playing right now, and what's its live calendar like?" | JD | [generic] persona stem | Name a game you actually play, and describe its events in your own words. Don't name one you don't play. | A casual question on a JD topic is still scored. |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | C1, S1 |
| Coordinate design, art, engineering and community on each update | S1, C4, C5 |
| Own the post-event review and the KPIs it reports | P3, P4, S4 |
| Manage the release checklist with QA | C3, T2 |
| 3+ years producing live-service games or apps | S5, V1 |
| Experience running a content calendar | P4, V1 |
| Comfortable with player-retention metrics | C2, P1, P2 |
| Clear written communication | none, and why: a written test would need a writing sample. Ask the recruiter whether one is coming. |

## Reverse questions

Each one has a reason it lands.

1. "What would a strong first six months look like in this role, on the calendar and on the KPIs?" Why: it makes KPI ownership concrete, and you learn what they measure.
2. "When design and engineering disagree on an update's scope, who makes the call, and how fast?" Why: it asks about the seam the coordination requirement lives on.
3. "How is the post-event review run today, and who reads the output?" Why: it tests the process the role owns, and it signals that you read the JD.
4. "When QA and a live event date collide, how does the release checklist decision get made?" Why: it shows you've thought about the checklist as a decision, not a document.
5. "Which of the two titles has the harder calendar right now, and why?" Why: it shows you've read the brief and it invites them to talk about the work.

No interviewer profile exists, so none of these ties to Tobias's path. Adding a name-based public footprint would add one.

## Sources

- Provided: the JD as pasted in the request, and your background as stated in the request.
- Research tier: L0. No searches and no fetches have been run.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet (section 10). Not run: L0 until you answer question 2. |
| 2. Saltmarsh interview process, live operations | unavailable | Loop structure and persona weights. |
| 3. Saltmarsh strategy and recent news | unavailable | Current CO bank and grounding brief. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read, persona weights, a tailored reverse question. |
| 5. Representative JD for Live Operations Producer | skipped | The JD you supplied fixes the fit snapshot. |

## Upgrade menu

- The round type and whether Tobias is your hiring manager → persona weights recomputed. The Case and Skeptic weights may move.
- Research at L1 (question 2) → Saltmarsh's published values, its live-ops strategy, and Tobias's public talks and writing → a grounded reverse question and a current CO bank.
- The content calendar or the release checklist as a document → F5 and F7 move toward high confidence, because they become inspectable artifacts.
- A writing sample → F9 moves from presentation to something checkable.
- A `tuesday-dossier.md` from an earlier session → S1 gets its prior wording, and the prohibited list gets its sourced entries.
- Prep time before Friday → a prep triage, with the few things to do first.
