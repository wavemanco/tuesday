Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-4-denied-d9f5423e/b71f36a4-d062-4739-9829-0b8de2212bbe/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md` and attached here. I built it for a hiring-manager round from your dossier alone. Web search was refused (the permission isn't granted in this session), so the pack has no company values, interview-loop structure or strategy. Those sections are absent rather than guessed.

The main thing to rehearse is the objection the underwriting named: "You have never held the PM title or owned a roadmap — why should we hire you into one?" The answer shape is:

- Say the two negatives first, in your own words: you haven't held the PM title and you haven't owned a roadmap.
- Then bridge with the integration work at its own scope: the 30+ integrations you led end to end, and the quarterly roadmap-input sessions that fed client evidence to product.
- Name the limit yourself: you fed evidence into product's planning; you didn't set its priorities.
- Concede the trade-off: a PM with three years on the job starts faster on roadmap ownership, and give a ramp plan as a plan, not as something you've already done.

Don't say you shipped an API product, set priorities for a squad, or ran a programme. Your material supports none of those.

Two things to check:
- Your dossier is dated 14 August. If the posting has changed since, send me the current text and I'll re-check the requirement quotes.
- I graded the fit from the dossier's handoff section only, because the dossier you sent has no evidence map. Treat the gap types as my reading.

Would you like me to play the Skeptic on A1, the objection above? I can also write a `tuesday-dossier.md` with `pack_feedback` that carries the gaps this prep exposed, and convert the pack to Word if you want it.

Is Thursday today (19 November), or next week? It sets how much prep time the schedule gets.

Is the hiring manager the person you'd report to directly? That changes how the persona weights are set.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes. **Interviewer:** not named. **Relationship:** hiring manager (see question 2 in the message).
**Built from:** the underwriting dossier (decision conditional_go, dated 2026-08-14), read for `role_profile` and `handoff_to_mock_interview`. No other inputs.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored.

- **JD**: can you do the listed job, gaps included
- **EXP**: do the claims on your record survive scrutiny, and what exactly was yours
- **CASE**: structure and reasoning on a live problem from this role
- **CO**: company strategy knowledge (none written; see Sources)
- **VAL**: published values (none written; no values page was read)

Guidance is scaffolding, not a script. Say it in your own words. Anything in quotation marks is a sentence from your own material.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [inferred] | transferability | The adjacent work is integration leadership, not a PM role. Say the limit first: you have not held the PM title. The transferable case is the integration work, at its own scope. Nothing here shows roadmap ownership. |
| F2 | "Owning a roadmap and prioritization authority" (dossier R1 sub-claim, acknowledge_gap area) | none given | none | [grounded] | capability | Your stated gap, from the dossier's acknowledge_gap area. Words: "I haven't owned a product roadmap." Then how you would learn it, said as a plan and never as a past. |
| F3 | "Shipped API or platform products" (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | medium | [grounded] | transferability | Integration work on someone else's API is the adjacent side. Confirmed, with an integration playbook as inspectable proof, but nothing in the material shows an API product you shipped. Name the integrations; do not name a shipped product. The dossier does not grade R2, so this grading is the pack's own. |
| F4 | "Technical fluency: API docs, schemas" (dossier role_profile R3) | "Wrote the internal integration playbook her team uses" — dossier V2 | low | [inferred] | discovery | The playbook is documentation of process, not shown to cover API docs or schemas. Answer slot: if you wrote or reviewed API docs or schemas, say which and what you did; if not, say so and say how you would get fluent. |
| F5 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [grounded] | discovery | Customer and product threads have quotes. Sales has none. Answer slot: if you worked with sales, say how; if not, say so and stay with the customer and product work. |
| F6 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [inferred] | discovery | No material speaks to it. Clarify strategy: ask how the team defines it, and say what you would want to confirm. |

**Caveat on this table:** the dossier you sent carries no `evidence_map`, so the confidence and gap grading above is the pack's reading of `handoff_to_mock_interview` only. It is not checked against the underwriter's map.

## Prohibited claims

Built from the dossier's `prohibited_claims` and `acknowledge_gap` fields, plus two inflated forms built here. The honest form is the candidate's own quote at its own scope, or the plain acknowledgment where a dossier field gives one a source.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier `prohibited_claims` | Plain acknowledgment: "I haven't held a product manager title." No slot. |
| Having owned a product roadmap | dossier `prohibited_claims`; acknowledge_gap (F2) | Plain acknowledgment: "I haven't owned a product roadmap." No slot. |
| Having set prioritization for an engineering squad | dossier `prohibited_claims` | Plain acknowledgment: "I haven't set prioritization for an engineering squad." No slot. |
| Set the quarterly roadmap | Inflated form of V3 ("roadmap-input sessions") | V3 at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." The limit is the pack's observation: the material says input, not decisions. |
| Owned the partner integration programme | Inflated form of V1 ("Led … integrations") | V1 at its own scope. Do not add a programme, a portfolio or a partner-facing platform. |

## Persona weights

Hiring manager prior: Case/Strategist and Skeptic dominant. No interviewer profile, and no loop source, so no interviewer-signal adjustments. The loop is not documented, so the weights rest on the round-type prior, not on this company's process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Probes the title and roadmap gap; asks why you over a PM | Highest. The dossier's likely objection is this persona's question, and the requirements it targets are the ones with no evidence | Plain acknowledgment, then the bridge with its limit named; hold two follow-ups |
| Case/Strategist (B) | Live adoption and squad-decision problems | High. Hiring managers buy capability and test it on their own roadmap | Clarify, then structure, then metrics; say what you need to know first |
| Data-Driven Prober (C) | Asks how the 30+ and the sessions were counted | Medium. The headline figure is the likeliest place for a probe | Say what you know about the count, and the assumption you would defend least |
| Pressure (D) | Sixty-second challenges; "how much of that was you" | Medium. Hold a position; concede specifically | Hold two follow-ups, then concede the exact gap |
| Conversational (E) | Opening "walk me through" and a casual API question | Low to medium. Casual questions are still scored | A 90-second arc; treat the casual API question as scored |

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "I haven't held a product manager title" (dossier prohibited_claims); "I haven't owned a product roadmap" (dossier acknowledge_gap); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Acknowledge first, in those words. Then the bridge at its own scope: the integration work, then the roadmap-input sessions, with the limit named — you fed evidence to product; you did not set its priorities. Concede the trade-off: a PM with three years on the job starts faster on roadmap ownership. Give a ramp plan as a plan, not a past. Hold through two follow-ups by returning to the quoted work. Highest-ROI prep: the underwriter named this objection. | The dossier's likely objection, derived from confirmed evidence. Its negatives have dossier sources. Covers R1 |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I haven't owned a product roadmap" (dossier acknowledge_gap) | Name roadmap ownership first, in those words, and say how you would learn it. Name the Agile question as the second weak point, and treat it as a clarify item. | Persona stem. Covers R1 and R5 |
| A3 | "I don't see product-management ownership in your background. How would you handle roadmap decisions in this role?" | JD | [grounded] "I haven't owned a product roadmap" (dossier acknowledge_gap) | Acknowledge, then describe a plan for taking roadmap decisions with the squad leads. Do not describe a past in which you made them. | Persona stem, premised on the dossier's acknowledged gap. Covers R1 sub-claim |
| A4 | "The role works with sales. Tell me about a time you worked with them." | JD | [grounded] "Stakeholder management across engineering, sales, customers" (dossier role_profile R4, the JD line) | Answer slot: if you worked with sales, say what it was and what part was yours, in your own words. If you did not, say so plainly and move to the customer and product work you can quote. | Raising source is the JD line; the slot's second branch allows the premise is false. Covers R4 |
| A5 | "You integrated the vendor's REST APIs for clients. Have you built or shipped an API product yourself?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: say what you did with the APIs, in your own words. If you did not build or ship a product, say so plainly. Do not name a product you did not ship. | Premise anchored to the quote. Covers R2 |

### B. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you'd define an adoption baseline for partner APIs. What do you need to know first?" | CASE | [generic] | Clarify first: which partners, which integration stage, what counts as adopted. Then the baseline, the metric, and the risk of measuring the wrong thing. Make no claim about your past. | Dossier unknown: adoption is measured today with no stated baseline. Live problem, so no claim about you |
| B2 | "Two squads, one API roadmap, and a partner who wants a feature next quarter. How do you decide what goes first?" | CASE | [generic] | Clarify who decides and what the squad leads own before structuring. Then a decision frame: partner value, squad capacity, the platform's risk. Name the decision rights as the thing to confirm. | Dossier unknown: decision authority versus the squad leads. Live problem |
| B3 | "Partner adoption dropped twenty percent after a version change. Diagnose it." | CASE | [generic] | Clarify the metric and the window. Segment by partner type and integration stage. Separate the version change from other causes before naming a fix. | Adoption measurement is a named responsibility with no baseline. Live problem |
| B4 | "How have you worked with engineering on delivery? What cadence does it run on?" | JD | [grounded] "Agile delivery experience" (dossier role_profile R5, the JD line) | Clarify: say how you define Agile delivery, in your own words. Answer slot: if you ran a delivery cadence with engineering, say what it was and your part. If you did not, say so, and say what you would want to confirm about how this team runs it. Never claim a cadence you did not run. | Clarify strategy for R5, which the dossier grades low. The question's premise is the JD's |
| B5 | "The role is partner-facing discovery. How would you run discovery with a partner you have never spoken to?" | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | Describe the session structure as the nearest case, in the quote's terms. Answer slot: if you set the agenda or chose the questions, say so; if not, say so and describe what the sessions asked. Expect a probe: V3 is medium confidence. | Discovery is the JD's listed work; V3 is the nearest quote. Covers R4 |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the thirty integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot (defend-the-number): how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Say plainly if you do not know how it was counted. | The headline figure is the likeliest probe. The count method is not in any quote |
| C2 | "Which assumption behind the thirty would you defend least?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Name the weakest assumption in your own words, before it is named for you. If you have none to name, say so. | Weakest-assumption move for the same figure |
| C3 | "You say the sessions fed client evidence to product. What changed in product's plan because of them?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | Answer slot: if a decision changed, say what, and whether your input was part of it. If none can be named, say so and describe what the sessions produced. Do not supply an outcome. | V3 is medium confidence; the probe tests the outcome the quote does not carry |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has held the title?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause, restate the question, then hold the integration work. Concede the title and the roadmap time specifically. Hold two follow-ups before any concession. | Pressure test of the title gap, the same objection as A1 in a shorter form |
| D2 | "That's integration work. Is that really product?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the quoted scope: what you led, end to end. Concede that roadmap ownership is not in it. Do not argue that integration work is product work. | Tests whether the bridge holds without inflation |
| D3 | "How much of those integrations was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: name the parts you led, and the parts others led. If you led none of a stage, say so. | Attribution honesty under pressure |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in this order: the integrations, the playbook, the input sessions, then why this role. Keep the quotes' scope in every clause. | Opening question scored for communication economy |
| E2 | "What are you actually playing with in the API stack these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" (dossier V2) | Answer slot: name what you have worked with in API docs or schemas, in your own words. If none, say so, and what you would start with. | The JD's technical-fluency line, asked casually. Covers R3 |

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| R1, 3+ years PM experience | A1, A2, A3, D1 | Gap is transferability; bridge named |
| R2, shipped API or platform products | A5, D2 | Adjacent work only |
| R3, API docs, schemas | E2 | Discovery; answer slot |
| R4, stakeholder management | A4, B5 | Sales has no quote |
| R5, Agile delivery | B4, A2 | Clarify; preferred requirement |

## Reverse questions

Each one tests an opportunity risk from the dossier. Ask at most three in the hour.

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: decision authority is asserted in the JD but not evidenced. A direct answer tells you the job's real shape.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: adoption is a named responsibility with no stated baseline. The answer shows whether the role has a number to own.
3. "How do the two squads plan together, and where does the PM sit in that cadence?" Why it lands: tests the Agile gap from the employer's side. It shows how much delivery discipline the role expects.
4. "What did the last person in this seat get stuck on in the first ninety days?" Why it lands: it gets the honest version of the role, not the posting's.
5. "What would you need to see in the first three months to call this hire a good one?" Why it lands: it shows you want the success measure, and it gives you the bar you will be judged on.

## Prohibited list: reminder

The list above binds every answer slot, hold and bridge in this pack. Any answer that claims a title, a roadmap or squad prioritization you have not stated is out of bounds, whatever the question seems to invite.

## Sources

**Provided documents:** the underwriting dossier, envelope version 1.1, read for `role_profile` and `handoff_to_mock_interview`. It also carries `decision` (conditional_go), which is context only. The dossier is about 97 days old, dated 2026-08-14. If the posting has changed since, the requirement quotes may be out of date.

**Dossier origins used:** V1, V2 and V3 are the three entries of `handoff_to_mock_interview.verified_candidate_evidence`. R1 to R5 are `role_profile.requirements`, which stand as the JD's lines. The `prohibited_claims`, `acknowledge_gap` and `likely_interviewer_objections` fields are as the dossier gives them.

**Searches and fetches sent:**
- "Quartzline company values": refused. The search permission was not granted.
- "Quartzline interview process product manager platform APIs": refused. Same cause.
- "Quartzline strategy news 2026": refused. Same cause.

**Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have moved the values cheat sheet. No values page was read, so no values cheat sheet is included. Every search refused |
| 2. Quartzline interview process, product manager | unavailable | Would have moved the loop structure and persona weights. No loop source, so the weights above rest on the hiring-manager round-type prior, not on this company's process |
| 3. Quartzline strategy and recent news | unavailable | Would have moved the CO bank. None is written, so there are no grounded differentiator questions |
| 4. Interviewer name and Quartzline | n/a | No name given, so there was no query to form. The reading of the interviewer is absent |
| 5. Representative product manager JD | skipped | The dossier's `role_profile` fixes the requirement list and the JD-tagged questions |

No values round is detected: no loop source was read, and the fallback archetype is generic, which reads no. So the values cheat sheet is dropped.

## Upgrade menu

- Grant search permission, or paste Quartzline's values page and any recent strategy note → a values cheat sheet if a values round is documented, and grounded CO questions in place of generic ones.
- The hiring manager's name → persona weights from their public footprint, and a reverse question tied to their own path.
- Full JD text, if the posting has changed since August → the responsibilities become quotable lines, and the requirement quotes are checked against the current posting.
- The raw CV behind the three verified claims → more quoted sentences for the defend-the-number slots in C1 and C2, and a stronger scope check on A5.
- A deeper research pass, if search is enabled: up to 6 more searches and 2 more fetches, several more minutes. Covers the strategy brief, the loop reports and recent org changes. Want it?
