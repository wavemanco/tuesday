Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-4-denied-36a4baca/68d8379e-d636-407a-b591-907c1c53a924/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for your Thursday hiring-manager round and used the dossier's verified evidence, weak areas and prohibited claims.

Web search was refused for this session, so the pack has nothing on Quartzline's values, interview loop or strategy. The file's Sources section records that. Nothing about the company is from memory.

The most important rehearsal is the objection the underwriter named: "You have never held the PM title or owned a roadmap." The answer is a one-sentence acknowledgment, then the integration work at its exact scope, then the limit named by you, then a ramp plan. Two lines are not to be used: anything claiming the PM title, roadmap ownership, or priority-setting for an engineering squad. The roadmap-input sessions are medium confidence, so mention their limited proof before anyone asks.

Would you like me to play the Skeptic on that objection so you can rehearse it out loud? I can also save a `tuesday-dossier.md` recording the rehearsal gaps this prep exposes, or convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: hiring-manager conversation, 45 minutes, Thursday. Interviewer name not given. Built on the job-underwriter dossier (version 1.1, generated 2026-08-14) and your own description of the round.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and stop where your material stops.

- **EXP**: your past work, tested for attribution and detail.
- **JD**: the posting's own requirements and responsibilities, including the gaps.
- **CASE**: a live problem from the role. It asks about no past of yours.
- **CO**: company strategy knowledge. No questions in this pack, because strategy research did not run (see Sources).
- **VAL**: values or behavioural round. None in this pack: no loop source establishes a values round, and the fallback archetype does not assume one.

Provenance labels: `[grounded]` is traceable to the dossier's verified entries or the posting. `[inferred]` is a derivation, named where used. `[generic]` is a role-family pattern with no claim about you or Quartzline.

Evidence in this pack is quoted from the dossier's `verified_candidate_evidence`, which is the underwriter's wording of what you confirmed. Where your CV or your own sentences say it differently, use yours. The upgrade menu covers this.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Shipped API or platform products" (dossier role_profile, R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | high | [grounded] | presentation | The quote already reaches the requirement in other terms: integration work on the vendor's REST APIs, taken through go-live. Say it in those words. "Shipped" is the interviewer's word, so do not turn the integrations into a product you shipped. |
| F2 | "3+ years product management experience" (dossier role_profile, R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | low | [inferred] the dossier's transferability call on R1 | transferability | The adjacent work is integration leadership and roadmap input, not product management, and the limit stays named. Words: the two quotes at their own scope, then the acknowledgment in A1. The material shows no product-management title or role. |
| F3 | "Own the roadmap for the partner-facing API platform" (dossier role_profile, responsibilities) | none given | none | [grounded] | capability | The dossier records this as an acknowledged gap. Words: the plain acknowledgment, "I haven't owned a product roadmap," sourced to the dossier's acknowledge_gap area and prohibited_claims. Then a ramp plan, said as a plan and never as a past. Add nothing to make the gap feel smaller. |
| F4 | "Run discovery with integration partners" (dossier role_profile, responsibilities) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | high | [grounded] | presentation | "Scoping" and "requirements" with clients are the nearest thing to partner discovery, and the quote reaches it only that far. Describe those steps in the quote's words. Any discovery beyond scoping is an answer slot, not a bridge. |
| F5 | "Write specs and drive delivery with two engineering squads" (dossier role_profile, responsibilities) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | high | [grounded] | transferability | The quote carries the client-side delivery steps. It does not reach the two squads. Words: the quote at its own scope. Answer slot: if you worked with an engineering team on any of those integrations, say who and what you did with them; if the work ran through others, say so and describe how you would work with two squads, as a plan. |
| F6 | "Technical fluency: API docs, schemas" (dossier role_profile, R3) | "Wrote the internal integration playbook" — dossier verified evidence 2 | high | [grounded] | presentation | The playbook is documentation of integration work, in the quote's own terms. Say what it covers. Schemas are not in the quote: answer slot, if you have read or written a schema for an API, name one; if you have not, say so. |
| F7 | "Stakeholder management across engineering, sales, customers" (dossier role_profile, R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | medium | [grounded] | transferability | The quotes reach customers and product. They do not reach sales or the engineering squads. The roadmap-input entry is medium confidence: confirmed, with limited inspectable proof, so volunteer that before it is probed. Answer slot: if you worked with sales or with an engineering owner on any of this, say how; if you did not, say so. |
| F8 | "Agile delivery experience" (dossier role_profile, R5) | none given. Nearby but not quoted: the roadmap-input sessions, which do not say Agile | low | [grounded] | discovery | Evidence may exist; the material does not show it. Answer slot: say how the work you led ran in cadence terms, in your own words. If it did not run to a sprint cadence, say so, and say what you would want to confirm about the team's cadence. |
| F9 | "Define and track adoption metrics" (dossier role_profile, responsibilities) | none given | none | [grounded] | discovery | Evidence may exist; the material does not show it. The dossier notes that no current baseline is stated. Answer slot: if you defined or tracked a usage or adoption measure, say what it counted; if you did not, say so, and name the first number you would want. |

## Prohibited claims

Not coached in any cell of this pack. The first three are absolute, from the dossier's `prohibited_claims`. The last is built here from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier prohibited_claims item 1 | Plain acknowledgment, sourced to that field: "I haven't held the product manager title." No slot. |
| Having owned a product roadmap | dossier prohibited_claims item 2; acknowledge_gap area | Plain acknowledgment, sourced to those fields: "I haven't owned a product roadmap." Then the ramp plan. |
| Having set prioritization for an engineering squad | dossier prohibited_claims item 3; acknowledge_gap area | Plain acknowledgment, sourced to those fields: "I haven't set prioritization for an engineering squad." |
| Ran partner discovery, or owned the discovery work | Inflated form of F4, built here | F4's quote at its own scope: "scoping, requirements, architecture, UAT, go-live." The limit is the pack's observation, not words for you: the material shows scoping and requirements, not discovery programmes. |
| Owned what went into the roadmap | Inflated form of F2 and F7, built here | The roadmap-input quote at its own scope: "feeding client evidence to product." |

## Question banks

Persona weights (shown reasoning, then the banks):

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gap between your background and this seat | 5 (top) | The relationship prior for a hiring manager is Case plus Skeptic. The dossier names the central objection, and it sits on the largest gap (F2, F3). | Rehearse A1 until it is plain. Name the gap before it is asked for, then the bridge with its limit. |
| Case / Strategist | Live problems from the posting: two squads, a partner feature, a metric that is flat | 4 | Hiring managers buy capability and test it on their own roadmap. The posting names two squads and adoption metrics. | Clarify, then structure: objective, segments, approach, metrics, risks. Say the decision-rights question out loud. |
| Data-Driven Prober | Asks how a number was counted and what it assumes | 4 | The headline figure "30+" and the adoption-metric responsibility will draw a probe. | Know what you can say about how each count was made. Say plainly where you do not know. |
| Pressure / Stress | Interrupts, time-boxes, presses the "why you" point | 3 (mid) | Mid-weight because the round is a single conversation with the hiring manager, not a stress format. The R1 gap is the natural pressure point. | Pause, restate, hold the adjacent case through two follow-ups, then concede the title and roadmap gap specifically. |
| Conversational / Rapport | Open, casual, "walk me through it" | 2 (low) | The relationship prior does not lean this way, but casual openers are scored. | A 90-second arc that ends on the gap in one sentence, not on the title. |

Total 18 questions. Each row carries a type tag. Dossier evidence is quoted from its verified entries; the upgrade menu says what would replace those with your own sentences.

### Persona A: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; the two negatives sourced to dossier prohibited_claims and acknowledge_gap, named by field | Acknowledge first, in one sentence: "I haven't held the product manager title, and I haven't owned a product roadmap." Then the adjacent case in the quote's words: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through go-live." Name the limit yourself: that was client integration work, not roadmap or priority decisions. Then the roadmap-input sessions, with their caveat: you can show limited proof, so say that before you are asked. Answer slot: say what you put in front of product in those sessions and what happened to it; if you cannot show what happened, say so. Then the ramp, as a plan: what you would learn first. Hold through two follow-ups by returning to the integrations, never by adding to them. | The underwriter named this as the most likely objection, so it gets the deepest rehearsal. F2 holds the bridge; F3 holds the acknowledgment. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] dossier acknowledge_gap and prohibited_claims, named by field; raising source: "Own the roadmap for the partner-facing API platform" (dossier role_profile) | Name the roadmap first, in one sentence: "I haven't owned a product roadmap, so that is where I would be weakest on day one." Then one plan: who you would talk to about decision rights. Stop there. Do not add a second weakness the material does not show. | This is the Skeptic's stem on F3. It lets you name the gap before the interviewer does. |
| A3 | "I don't see a roadmap or squad-priority role in your background. How would you run decisions across two squads?" | JD | [grounded] dossier prohibited_claims item 3 and acknowledge_gap, named by field; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence 1) | Acknowledge first: "I haven't set prioritization for an engineering squad." Then the work you did alongside engineering on those integrations, at its own scope: the quote names architecture, UAT and go-live, so say those. Answer slot: if you worked alongside a squad lead on any integration, say what the two of you did, in your own words; if you did not, say so. Then how you would work out decision rights with the two leads, as a plan. | F5 and the dossier's unresolved squad-authority question. The Skeptic tests whether the authority claim survives. |
| A4 | "Tell me about an API product you have shipped, and your part in it." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence 1) | An open prompt, so choose the instance. If you shipped a product yourself, say so and your part in it. Otherwise use the nearest thing the material carries: the integrations you led went live end to end, and say what your part was in those words. Answer slot: if no product you shipped comes to mind, say so plainly before you describe the integrations. | R2 is a must-have. F1 is the row it draws on, and the open prompt keeps the answer to what you can stand behind. |
| A5 | "What is your experience inside an agile delivery cadence?" | JD | [grounded] raising source: "Agile delivery experience" (dossier role_profile, R5) | Answer slot: if the integrations you led ran to a cadence, say which, in your own words; if they did not, say so, and say what you would want to confirm about the team's cadence. Do not describe sprints you did not run. | F8 is discovery, low confidence. This question asks for the honest branch rather than a bridge. |

### Persona B: Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your two squads disagree on whether the next partner release ships webhooks or fixes the auth flow. Walk me through how you would decide." | CASE | [generic] | Clarify before structuring: who decides, what the release date is, and what each squad's delay costs. Then the objective: what the partners lose if the wrong one ships. Then segment the partners by how much each depends on each change. Propose a decision rule to the two leads, name the metrics you would watch, and the risk you would reverse. Make the decision-rights question your first clarify. Do not assume you would decide. | A live problem from the posting. It asks no past of you, so the guidance claims nothing about you. The unresolved authority question is why the clarify comes first. |
| B2 | "Adoption of the partner API has been flat for two quarters. Where do you look first?" | CASE | [generic] | Start by asking what adoption means here and what the baseline is. Then split the funnel: first call that succeeds, documentation friction, partners who signed up and never shipped. Give one hypothesis per stage and the check that would rule it out. Do not quote a number you were not given. | Covers F9. The baseline is not stated, and the case shows whether you ask for it. |
| B3 | "A partner wants a feature that forks the API for them alone. Sketch your first conversation with them, and who else you would bring in." | CASE | [generic] | Clarify their use case and what they would do without the feature. Name who inside needs to be in the room: engineering, the account owner in sales, and the other partners on the platform. Propose a next step, not a yes or no. | Covers the R4 stakeholder requirement and the partner-discovery responsibility (F4). It asks for a plan, not a past. |
| B4 | "You have to give two squads one spec for the same partner feature. What goes in it?" | CASE | [generic] | Name the outcome and the partner it is for first. Then the acceptance criteria a partner would test, the API shape, and what changes for existing users. State what you are explicitly not doing, and the one open question you would send back to the squads. Keep it to what a squad needs to start. | Covers the spec-writing responsibility (F5) as a live exercise. Nothing about your past is asked. |

### Persona C: Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the 30 integrations. What made one count as an integration?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence 1) | Defend the number in your own words: what made one integration count. Then the assumption behind the count that you would defend least, before they name one. Then which part was yours: you led them; say what others did. Answer slot: if the count was never defined, say that plainly. If some of the 30 were supported rather than led, say which. | The headline figure on your material. Defend-the-number applies here, and the pack supplies no counting method. |
| C2 | "What did the integration playbook cover, and which parts would you show me?" | EXP | [grounded] "Wrote the internal integration playbook" (dossier verified evidence 2) | Name the sections you wrote, in your own words. Do not claim how widely it is used: the quote does not say. If asked, say you do not know unless you do. Answer slot: if it covered API request and response shapes or schemas, name the part; if it did not, say so. | F6, and the one inspectable artifact in the material. Showing it is what raises the band. |
| C3 | "How would you know a partner is actually adopting the API? Which number?" | JD | [grounded] raising source: "Define and track adoption metrics" (dossier role_profile, responsibilities) | Answer slot: if you defined or tracked a usage or adoption measure, say what it counted and what it was sensitive to. If you did not, say so, name the first number you would want, and say that the current baseline is not yet known to you. | F9. The dossier notes no baseline is stated, and this question is where that surfaces. |
| C4 | "What happened to the client evidence you fed to product in those roadmap-input sessions? How would you know?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified evidence 3; medium confidence) | Caveat first: you can show limited proof for these sessions, so say what you can point to and what you cannot. Answer slot: say what happened to the evidence after it reached product, if you saw it; if you did not see what happened, say so. Hold the sessions at the scope of "feeding evidence." | The medium-confidence entry is the seam a prober will find. Volunteer the limit before it is extracted. |

### Persona D: Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That is a PM job. Give me one reason it should be you, in ten seconds." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence 1); the title negative sourced to dossier prohibited_claims item 1, named by field | Pause for a beat and restate: "You are asking why I am the one for a PM role." Then the acknowledgment, "I haven't held the product manager title," and the integrations quote. Hold through two follow-ups: the integration work is the reason. Concede specifically: "The PM title and roadmap ownership I don't have." Hold the integrations; concede the title. | The pressure version of the central objection. Hold-then-concede is the skill being rehearsed. |
| D2 | "How much of those 30 was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence 1) | Hold each part you led. Name what the team did, and concede specifically where others did it. Do not fold on what you led, and do not add anything to what you led to sound stronger. | An attribution probe on a "led" claim. The honest answer is the rehearsal. |
| D3 | "Two squads, one roadmap, and you have never set priorities for an engineer. Who wins when they disagree?" | JD | [grounded] dossier prohibited_claims item 3 and acknowledge_gap, named by field; raising source: "Write specs and drive delivery with two engineering squads" (dossier role_profile) | Acknowledge first: "I haven't set prioritization for an engineering squad." Then the plan: how decision rights would be settled before any disagreement, and what you would take to the two leads. Hold the plan through two follow-ups. Concede what you do not yet know about these leads. | F5 and the squad-authority unknown. It tests a plan under pressure, not a past. |

### Persona E: Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey to here." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook" (dossier verified evidence 1 and 2) | A 90-second arc: the integration work, the playbook, the roadmap-input sessions with their caveat, then the gap in one sentence. End on what you want to take on next, in your own words. Do not end on the title. | Casual openers are scored. F1, F6 and F2 are the rows it draws on. |
| E2 | "What are you playing with in API docs these days?" | JD | [grounded] "Wrote the internal integration playbook" (dossier verified evidence 2); raising source: "Technical fluency: API docs, schemas" (dossier role_profile, R3) | Name the playbook first, and what it covers, in your own words. If you have worked with request and response schemas, name one. If you have not, say so, and say what you would read first. | R3 is important. F6 is the row. The casual register is still scored. |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1: 3+ years product management experience (must-have) | A1, D1, E1 |
| R2: Shipped API or platform products (must-have) | A4, C1 |
| R3: Technical fluency: API docs, schemas (important) | C2, E2 |
| R4: Stakeholder management across engineering, sales, customers (important) | A3, B3 |
| R5: Agile delivery experience (preferred) | A5 |
| Responsibility: Own the roadmap for the partner-facing API platform | A1, A2, A3, B1, D3 |
| Responsibility: Run discovery with integration partners | B3 |
| Responsibility: Write specs and drive delivery with two engineering squads | B4, A3, D3 |
| Responsibility: Define and track adoption metrics | B2, C3 |

## Reverse questions

Every question below is yours to ask the interviewer. Each one tests a risk the dossier left open.

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | It is the dossier's own question on decision authority. It reads as diligence and answers the thing you most need to know before accepting. |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | It is the dossier's question on the missing baseline. Asking it shows you have already noticed the metric is undefined. |
| RQ3 | "How do the two squad leads and the PM handle disagreement today, and how is it settled?" | It turns the authority risk into a process question about the real working relationship. |
| RQ4 | "Which partner integration is most at risk right now, and why?" | It asks for the live problem without asking for a case, and shows where you would start. |
| RQ5 | "What does a sprint cadence look like on these two squads: planning, and who owns the backlog?" | It tests the Agile unknown (F8) and makes the answer about their process rather than yours. |
| RQ6 | "What would make the first 90 days in this seat a success, from the hiring manager's side?" | It asks the interviewer to name the outcome they are buying, which is the answer to the capability question. |

## Sources

Provided documents:
- `tuesday-dossier.md`, version 1.1, generated 2026-08-14. Consumed: `role_profile` (requirements and responsibilities), `handoff_to_mock_interview` (verified evidence, weak areas and their strategies, likely objection, risks, employer questions, prohibited claims). `decision` (conditional_go) is context only. The pasted dossier carries no `evidence_map`, `risk_register` or `evidence_state`, so none of them was consumed. The dossier is about three months old; check that the posting has not changed.
- Your description: hiring-manager round, 45 minutes, Thursday.
- Dossier verified evidence is cited by its numbered order in the dossier's list: 1 is the integrations entry, 2 the playbook, 3 the roadmap-input sessions.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet not built. Query sent: "Quartzline values" — refused. |
| 2. Quartzline interview process product manager platform APIs | unavailable | Loop structure. No loop source establishes the loop, so persona weights rest on the hiring-manager round prior, not on this company's documented process. Query sent: "Quartzline interview process product manager platform APIs" — refused. |
| 3. Quartzline strategy / recent news | unavailable | Would have moved the CO bank. No CO questions are in the pack, and the CASE questions are generic. Query sent: "Quartzline strategy news 2026" — refused. |
| 4. interviewer name Quartzline | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent. |
| 5. representative Product Manager, Platform APIs JD | skipped | The dossier's role_profile supplies the requirements in hand. |

Web search was refused by the host for this session. Nothing about Quartzline's values, loop or strategy is in this pack, and none of it is from memory.

## Upgrade menu

- Web search access, granted for a new run → the values cheat sheet, a documented loop (confirming whether the 45 minutes is one session), and the CO questions that a strategy brief would ground
- The interviewer's name → persona weights from their public footprint, and a reverse question tied to their own path
- Your CV or resume → the dossier's quotes replaced with your own sentences, which upgrades the `[grounded]` rows to your words
- The integration playbook, or a section of it → inspectable proof for C2 and F6, and a stronger answer to the playbook question
- The recruiter's note on the round → confirms the format, and whether a values or deliverable element is planned
- A current copy of the posting → checks that R1 to R5 and the responsibilities still match the dossier, which is three months old
