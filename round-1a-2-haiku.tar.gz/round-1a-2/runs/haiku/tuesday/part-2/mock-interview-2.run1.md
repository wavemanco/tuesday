Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-2-denied-b7eccc11/43398b4c-3ecc-4d2b-9a79-c2d90f8f76f0/scratchpad/atlas-freight_operations-manager_interview_pack.md, and I've sent it to you. I built it with flat persona weights because your note didn't say who you're meeting or what round it is. Web search was refused by a permission denial, so the pack has no company values, interview process or news. Everything company-specific is missing until that's fixed.

The most likely objection is the scale gap: the job runs four sites and 12 supervisors, and your material shows one site and three people. That's question D1, and it's the one I'd rehearse first.

Say the word and I'll play the Skeptic on D1 with follow-ups. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is the person you're meeting your future manager, or a peer on the team? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager, Atlas Freight (regional logistics, about 800 employees, four sites, 12 supervisors).
Interviewer: not named. Round and relationship: not stated. Built with flat persona weights, which is noticeably weaker than a pack built on a known round.
Research: web search was refused by a permission denial, so every company-specific fact is absent and the pack is built from the JD and your message only.

## How to use + type key

Personas are how a question is asked. Types are what it scores.

- **JD**: a requirement from the job description. Can you do the listed job, gaps included?
- **EXP**: your own record. Does what you said survive scrutiny, and what exactly was yours?
- **CASE**: a live problem from this role. Structure and reasoning count more than a right answer.
- **VAL**: behaviour, in the form of a past example. Used because no company values were available.
- **CO**: company knowledge. None in this pack, because research was refused.

Guidance is scaffolding, not a script. Say only what you did, in your own words.

## Fit snapshot

Requirements are the JD's own words. Evidence is your message, quoted exactly. Gap and bridge language holds what you can say, and where an answer is needed it is an answer slot: an instruction for the interview, not a question for here.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "ran the site's peak-season surge plan two years running" (your message); "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows one site and a team of three. It does not show four sites. Say what you ran, at the scope you ran it. Answer slot: if daily operations at more than one site were yours to run, say which and how; if not, say so plainly and describe the one site you ran. |
| F2 | "drive on-time performance" (JD) | "cut mis-pick rate 40% by redesigning pick path" (your message) | low | [grounded] | discovery | Your material shows an accuracy measure, not on-time performance. Answer slot: if you tracked on-time performance at any scale, say what you tracked and how; if you did not, say so and name the measure you would watch first. |
| F3 | "cost-per-shipment down" (JD) | none given | none | [grounded] | discovery | Your material shows no cost measure. Answer slot: if you tracked a cost per unit or per shipment, say what it was and how it was worked out; if you did not, say so. |
| F4 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors. Say three, and do not extend the number. Answer slot: if you have directed the work of more people than that, say who and how. |
| F5 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | discovery | Your material shows seven years in operations and a current leading role, not how long you have led. Answer slot: of those seven years, how many were in a role where others reported to you, and from when. |
| F6 | "build reporting in Excel/Power BI" (JD), Excel part | "solid Excel" (your message) | low | [grounded] | presentation | The quote reaches Excel in general terms, not reporting. Say "solid Excel" and nothing more. Answer slot: name one thing you have built in Excel that someone else used. |
| F7 | "build reporting in Excel/Power BI" (JD), Power BI part | "never used Power BI" (your message) | none | [grounded] | capability | Your own words: "I've never used Power BI." Then how you would learn it, said as a plan, never as a past. |
| F8 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | Lean and Six Sigma are met on the certificate. Say the certification in those words. The certificate is not inspected, so expect a probe on what the belt meant in practice. |

Gate rows: the JD names no location, schedule, credential, pay or travel term as a gate, so none is surfaced. The 5+ years requirement is a length of experience, graded on fit (F5), not a gate.

## Prohibited claims

Built locally from the fit snapshot. No dossier was present. No answer slot, hold or rationale asserts these.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran daily terminal operations across four sites | Inflated form of F1 | The sentence at its own scope: "ran the site's peak-season surge plan two years running." Your material shows one site. |
| Leads 12 supervisors | Inflated form of F4 | "currently a senior shift manager over 3 supervisors" |
| Led the pick path redesign on your own | Inflated form of the mis-pick sentence, which does not say whose the redesign was | "cut mis-pick rate 40% by redesigning pick path." The slot in A2 asks which part was yours. |
| Ran the pick path change as a Lean or Six Sigma project | Inflated form of F8 | "green belt certified" |
| Built Excel reporting that others used | Inflated form of F6 | "solid Excel" |
| Has used Power BI | Stated negative, F7 | Plain acknowledgment: "I've never used Power BI." No slot. |

## Persona table

Round and relationship are unknown, so weights are flat and shown below. Depth follows weight.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (A) | Asks how your 40% was counted, and what the cost and on-time numbers are | High. The 40% is the most quantified line and the JD names on-time and cost measures your message does not show | Say how the figure was counted in your own words; name the assumption you would defend least; say plainly what you do not know |
| Pressure / Stress (B) | Interrupts, time-boxes, asks how much was really you | High. Scale gap (F1, F4) is the obvious pressure point | Pause, restate, hold the quoted position through two follow-ups, then concede the specific uncertainty |
| Case / Strategist (C) | Live ops problems from the role: a missed on-time target, a cost rise, an Excel mess | High. An operations manager is judged on how they run a problem | Clarify the measure first, then structure, then name a first action |
| Skeptic (D) | Probes the four-site and twelve-supervisor gap, Power BI, the Lean claim | Highest. Three JD requirements are graded gap rows | Rehearse the main objection until it is plain; use only what you stated; calibrated candour over bluffing |
| Conversational (E) | Casual opener on the journey and on Excel | Low to mid. Casual questions are still scored | A 90-second arc for the journey; answer the Excel question straight |
| Values / Behavioral (F) | Past-example questions on candour and process change | Low. No company values were available to map to | Selection scaffold ending in its honest branch where the material has no story |
| Peer Evaluator (G) | Seams with other functions, credit when a fix spans teams | Low unless the interviewer is a peer | Propose seam principles rather than pretend to know them |

## Question banks

Provenance comes before guidance. Every candidate sentence the guidance rests on is quoted in its row.

### A. Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning pick path" | Say in your own words how the figure was counted. Name the assumption you would defend least before they do. Answer slot: if you measured it yourself, say how; if you did not know how it was counted, say so plainly. | The headline metric on your material; F2 is adjacent |
| A2 | "Which part of that pick path redesign was yours, and which part was the team's?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning pick path" | Hold to the sentence: the redesign cut the rate. Answer slot: if you designed the change, say what you did and why; if you ran its rollout, say that; if you were not part of it, say so plainly. | Attribution probe on the same figure; the second branch lets the premise be false |
| A3 | "How have you measured on-time performance?" | JD | [grounded] "cut mis-pick rate 40% by redesigning pick path"; the JD line "drive on-time performance" | Answer slot: if you tracked on-time performance, say what you tracked, how often and what it showed; if you did not, say so and name the nearest measure you did track, which is the mis-pick rate | F2 is discovery; this is where the JD presses |
| A4 | "Which cost measure have you tracked, and how did you calculate it?" | JD | [grounded] the JD line "cost-per-shipment down" | Answer slot: if you tracked a cost measure, name it and how it was calculated; if you did not, say so plainly and name the cost lever you would look at first | F3 has no quote; the honest answer is ready before the probe |

### B. Pressure / Stress (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Four sites and twelve supervisors. Why would a three-person team be a fair preview?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Hold: three is what you have run. Concede: the scale is larger, and say what you do not yet know about it. Do not argue that the team of three proves scale | F4 and F1 gaps said as a challenge |
| B2 | "You ran the peak-season plan two years running. What did the second year need that the first did not?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Answer slot: describe what changed, if anything, in your own words; if nothing changed, say so plainly | Pressure on repetition; a plan run twice invites a question about learning |
| B3 | "Sixty seconds: why should we hire someone with three supervisors for a twelve-supervisor job?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Hold your three and the work you did with them. Concede the gap in one sentence. Give the first step you would take, as a plan | Time-boxed version of the scale objection |

### C. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two of your four sites missed their on-time target this month. What do you do in the first week?" | CASE | [generic] | Clarify the target, the measure and the period first. Then structure: which sites, which shifts, which lanes. Then contain, then find the cause, then name a first action. Makes no claim about your past | Live problem from the on-time line; a case, not a record |
| C2 | "Cost per shipment rose 8 percent over a quarter at one terminal. Walk me through how you would diagnose it." | CASE | [generic] | Clarify the cost definition first. Segment by volume, lane, labour and dock before you name a cause. Makes no claim about your past | Cost-per-shipment line as a diagnosis |
| C3 | "You inherit a site whose reporting is three people's spreadsheets. What do you build first, and why?" | CASE | [generic] | One definition, one source, one owner, then the report the decision needs. Name Excel as the first tool and say Power BI is a later option if the site needs it | The reporting line; Power BI is a plan, not a past |
| C4 | "A supervisor's team has a mis-pick spike after a layout change. How do you run the next 48 hours?" | CASE | [generic] | Confirm the measure, contain the change, get the shift-level picture, then decide whether the layout is the cause. Makes no claim about your past | Connects your strongest result to a live problem |

### D. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This job runs four sites and twelve supervisors. Your material shows one site and three. Why would that scale?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; [grounded] "ran the site's peak-season surge plan two years running" | Highest-ROI prep in this pack. Hold the scope of both quotes: one site, three people. Concede the scale directly. Answer slot: if you have had daily oversight of more people or places than those, say who and how; if not, say that and then give your first 90 days as a plan. Do not argue that the work proves the scale | This is the objection the material most predicts; F1 and F4 are its source |
| D2 | "The role builds reporting in Power BI. What do you do on day one?" | JD | [grounded] "never used Power BI" | Plain acknowledgment: "I've never used Power BI." Then the plan: what you would learn first and how you would test it on a real report | F7 is a stated gap, so the words are yours to say |
| D3 | "What Lean or Six Sigma work have you done beyond the certification?" | EXP | [grounded] "green belt certified" | Answer slot: if you led a project, name it and your part in it; if the certification is the extent of it, say so plainly | Lean is a plus, and the certificate invites a probe on practice |

### E. Conversational / Rapport (weight: low to mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; [grounded] "currently a senior shift manager over 3 supervisors" | A 90-second arc: where you started, the years, the current role. Stop there. Nothing added | Casual opener, still scored |
| E2 | "What are you actually playing with in Excel these days?" | JD | [grounded] "solid Excel" | Answer slot: say what you do in Excel, in your own words; if you have not built reporting others use, say so | Excel is the only reporting tool you have |

### F. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you had to tell a senior manager something they did not want to hear." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a point where you did not fold, and a working relationship at the end. If none comes to mind, say so plainly, then give the nearest thing you have done | No company values to map; the question stays generic |
| F2 | "When did you change a process that others depended on?" | VAL | [grounded] "cut mis-pick rate 40% by redesigning pick path" | Beats the sentence states: the mis-pick problem, the redesigned pick path, the 40%. Answer slot: who was affected and how they reacted, in what you actually saw | The pick path redesign is the one story your material carries |

### G. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where does your site's seam with transport sit, and what happens when you disagree?" | JD | [generic] | Propose seam principles, not a claimed history. Describe how you would raise a disagreement with an equal | Peer-style probe; no past is claimed |
| G2 | "How do you handle credit when a fix spans two teams?" | VAL | [generic] | Name the people you would credit and the work each did. Do not claim a credit history you have not stated | Peer probe on credit |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own daily terminal operations across 4 sites | B1, D1 |
| Drive on-time performance | A3, C1 |
| Cost-per-shipment down | A4, C2 |
| Lead a team of 12 supervisors | B1, B3, D1 |
| Build reporting in Excel/Power BI | C3, D2, E2 |
| 5+ years operations leadership | E1, B3; fit row F5 |
| Lean/Six Sigma a plus | D3 |

## Reverse questions

Five, each with why it lands. No interviewer profile exists, so none ties to an interviewer's own path. A reciprocity question applies only if the interviewer is a peer.

1. "What does a strong first 90 days look like in this role?" Why it lands: it turns the scale objection into a plan conversation.
2. "How is cost per shipment measured across the four sites today?" Why it lands: it tests whether the measure is defined, which is the honest question about F3.
3. "How many people report to this role directly, and how many supervisors sit beneath them?" Why it lands: it resolves what the 12 supervisors actually means.
4. "Which site has the largest on-time gap right now, and what has been tried?" Why it lands: it shows you read the JD and want the real problem.
5. "What reporting does the site team use today, and what would a Power BI report need to replace?" Why it lands: it defines the Power BI scope before anyone asks you to claim it.

## Prohibited list check

Each prohibited entry above is reflected in the banks as its honest form only. No bank entry says you ran four sites, led 12 supervisors, owned the redesign alone, used Power BI, or ran a Lean project.

## Sources

Provided documents: the JD text and your message, both in the conversation. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0

Searches sent, all refused by a permission denial:
- "Atlas Freight regional logistics company values": refused
- "Atlas Freight regional logistics terminal operations interview process": refused
- "Atlas Freight logistics news 2026": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet, which is not built; the values bank (F) is written without company values |
| 2. Atlas Freight interview process | unavailable | Loop structure; persona weights are flat as a result |
| 3. Atlas Freight strategy and recent news | unavailable | Company and strategy questions (CO type), none written |
| 4. Interviewer name | n/a | No name was given |
| 5. Representative JD | skipped | The JD was supplied |

## Upgrade menu

- The round type and the interviewer's name → persona weights, the reverse question about their path, and a relationship-tuned bank
- The recruiter's note on focus areas or any exercise → coverage of whatever they name, and a changed bank order
- Atlas's published values page, pasted → a values cheat sheet, and the F bank mapped to stories
- Site-level on-time and cost figures you can share → turns F2 and F3 from discovery into answerable rows and adds defend-the-number slots
- Your Lean or Six Sigma project summary, if you have one → F8 moves from medium toward high
- A recruiter email on the round's focus → the same as the first line, without a second round trip
- tuesday-dossier.md → carries the gaps this prep exposes into later sessions
