Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-5-denied-1e4bed62/2bf6dc75-050d-4c85-bf32-86d0b4b6724a/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it for a panel round, since that's what your recruiter's email describes.

Research didn't run. Web search was refused, so the pack has nothing on Kelverton's values, interview loop, strategy, or Deepa and Ross's public backgrounds. Everything about the company is labelled as unverified. The market report isn't in this conversation either, so the POV can't yet depart from its consensus view.

The main points in the pack:

- **POV:** I'd lead with "shorten the loop between a timetable change and the operator's own planners." It's the thesis where your transport-planning background carries the most weight, and it needs the least commercial evidence you don't have. Keep the outcome-linked pricing idea as the answer if Ross presses on commercials.
- **Skeptic objections:** "never sold into rail" and "never carried a direct quota." Rehearse the plain acknowledgment, then what you did carry, then a ramp plan. Don't let either one turn into a claim you can't back.
- **The £4M figure:** Ross will probably ask how it was counted. The pack gives you four slots to answer from your own knowledge: how it was counted, what it's sensitive to, the assumption you'd defend least, and which part was yours. If you can't reconstruct the method, say so and stop there.

Two things would sharpen this, and I'd need both before I could tighten it:

1. Paste the JD, and tell me whether it names any gates such as location, right to work or travel.
2. Paste the headline view from the market report, so the differentiation section can depart from it rather than repeat it.

If you'd like the pack as a Word document, say so and I'll convert it. I can also run a drill on any question, starting with the Skeptic rehearsal on A2 that I'd put first, and save a `tuesday-dossier.md` recording the gaps this prep exposed.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail, second-round panel

**Interviewers:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). Panel, 60 minutes: first 15 minutes a spoken POV, the rest Q&A with commercial pressure from Ross.
**Changelog:** first build. No JD, no research, no interviewer profiles in hand; see the Sources section.

## 1. How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values), EXP (your past work), JD (the role), CO (company knowledge), CASE (live problem).
- Guidance is scaffolding, not a script. Say it in your own words.

## 2. Prep triage (about 4 hours)

1. **60 min: build and rehearse the POV (section 5).** Pick one thesis, write the concession, then say the 15-minute version aloud twice. Land it on what changes for the operators.
2. **45 min: commercials (section 8, bank B, rows B2 and B3; section 9).** Prepare the defend-the-number answer for the £4M figure and the plain acknowledgment on quota.
3. **30 min: the operator-side story.** Write down three things you saw from the planning side of bus and light rail work. Use only what you did, in those words.
4. **30 min: the Skeptic rehearsal.** Run the rail and quota objections (A2, A3) until the answer is short and unflustered.
5. **30 min: reverse questions and the close.**

Everything else is insurance.

## 3. Fit snapshot

No JD was supplied, so the requirements below come from the recruiter's words in your message, quoted as `[grounded]`. Gaps are scored against those words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter | "running the ISV channel" — your CV | medium | [grounded] | transferability | Your material shows partner-channel work with software partners, not operators. Say the channel part in your own words; the operator link is an answer slot, not a claim. |
| F2 | "Ross will push on commercials" — recruiter | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message; "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | capability | Words: "I've never carried a direct quota. What I carried was partner growth and influenced revenue of roughly £4M." Never call the £4M sourced or owned. |
| F3 | "Please land on what it means for the operators themselves" — recruiter | "bus and light rail network planning, so I know the operator world from the other side" — your message | medium | [grounded] | presentation | The quote already reaches operators from the planning side. Lead with that planning experience, in its own terms. |
| F4 | Rail experience (implied by the role's sector; no JD line) — [generic] | "Never sold into rail specifically" — your message | none | [grounded] | capability | Words: "I've never sold into rail specifically." Then how you would learn the buying cycle, said as a plan, never as a past. |

**Gate check:** no JD, so no gates are established. See the question in section 12.

## 4. Requirement coverage

| Requirement | Questions covering it |
|---|---|
| Operator partnerships over 18 months (recruiter) | POV, A1, A4 |
| What it means for operators (recruiter) | POV, A1, A4, B1 |
| Commercials (recruiter) | B1, B2, B3 |
| Rail buying cycle (F4, [generic]) | A2 — no JD line to test it against, so it is covered by the Skeptic row only |

## 5. Graded deliverable: 18-month POV (15 minutes, spoken, no slides)

The recruiter asked for a POV on where you would take operator partnerships over 18 months, landing on what it means for the operators. Build two or three theses. Each needs a concession.

**Thesis 1 — Shorten the loop between a timetable change and the operator's own planners.** *[generic]* Operators re-plan under pressure. A partnership that cuts the time from change to published service is a benefit to the operator's own customers. *Concession:* you have not seen how the operators you would target currently run change control, and that determines whether this is the right first move. *What it means for operators:* fewer manual re-plans and a faster response when service changes.

**Thesis 2 — Partner with the planning team, not only the buyer.** *[generic]* Scheduling decisions are made by planners who live with the output. Your partnership-channel experience (F1) argues for building with the people who use the product. *Concession:* partnering with planners slows the sale and makes the commercial case harder to see, which is what Ross will press on.

**Thesis 3 — Tie the commercial model to what operators are paid to deliver.** *[generic]* Operators answer to a funder and a regulator; a price that tracks their delivery outcomes is easier for them to defend internally. *Concession:* outcome-linked pricing shifts risk onto Kelverton and needs proof you do not yet have.

**Recommended:** Thesis 1, with Thesis 3 as the commercial answer if Ross presses. It has the most operator-side logic and the least that depends on a number you cannot yet defend.

**Differentiation against consensus:** not built. The market report you have read is not in this conversation, so I cannot tell which positions the strategy team has already circulated. Paste its headline view and I will rebuild this section to depart from it.

**Requested close:** what it means for the operators. Keep it to one sentence about a rider or a planner's Monday, not a market figure.

## 6. Reading the interviewers

Dropped. No public profiles were read (see section 14).

## 7. Persona table

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Case/Strategist (Deepa, Ross) | "What would you do first?" on a live operator problem | High: a VP Partnerships will test the plan on her own accounts | Clarify, then structure, then answer. Name one premise you would challenge. |
| Skeptic (Deepa) | "Why you, with no rail sales and no quota?" | High: this is the predictable objection | Plain acknowledgment, then the nearest thing you did carry, then a ramp plan. |
| Pressure (Ross) | Time-boxed challenges to the POV's revenue logic | High: he is the commercial voice | Hold the position through two follow-ups, then concede the specific unknown. |
| Data-Driven Prober (Ross) | "How was the £4M counted?" | High: the figure is the obvious probe | Defend-the-number answer, section 8 A4. |

**Weighting:** Deepa leads on Case and Skeptic; Ross leads on Pressure and Prober. Both are a blend of a hiring-manager and an executive round, so every bank gets at least two questions.

## 8. Question banks

### Bank A — Deepa (Case/Strategist, then Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What would you do in your first 90 days with our operator partnerships?" | CASE | [generic] | Clarify which operators and which partnerships come first. Then state one thesis from section 5 and what you would measure in the first month. Make no claim about your past. | The panel's core question; a live problem, so it presumes nothing about you. |
| A2 | "You've never sold into rail. What's your weakest point on day one?" | JD | [grounded] "Never sold into rail specifically" | Plain acknowledgment: "I've never sold into rail specifically." Then the nearest transferable thing: the channel work in F1 in its own words. Then a ramp plan you would actually run. | F4 is the predictable Skeptic objection and the highest-ROI rehearsal. |
| A3 | "Why should we trust you to own a partnership number with no quota behind you?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" | Plain acknowledgment: "I've never carried a direct quota." Then what you did carry, in the quote's own terms: partner growth and influenced revenue. Do not describe the number as yours to own alone. | F2 is the second Skeptic objection. |
| A4 | "What does a partnership look like to an operator's planning team?" | CASE | [grounded] "bus and light rail network planning, so I know the operator world from the other side" | Use the planning-side experience from F3 in your own words. Answer slot: if you saw a specific operator process in that work, describe it; if you did not, say the planning view is a secondhand one and name what you would verify first. | F3 is the operator-side mirror; the planning-side view is the one thing you bring that the other candidates may not. |

### Bank B — Ross (Pressure, then Prober)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Operators run on thin margins. Why would one pay for this?" | CO | [generic] | Answer from the operator's own budget and its change cost, not from Kelverton's wish. Hold the position through two follow-ups. | Ross's commercial lens; a generic pattern, not a claim about this company. |
| B2 | "Without a quota, how do I know you'll deliver a revenue number?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" | Plain acknowledgment as A3. Hold: influence is what you can show; name how you would turn it into a forecast you would defend. Concede that you do not yet know the sales cycle. | Pressure on F2; the hold-then-concede structure. |
| B3 | "Walk me through how a partner's revenue got counted as influenced." | EXP | [grounded] "roughly £4M of influenced revenue" | Defend-the-number slot (section 9, A4 rule): how it was counted, what it was sensitive to, the assumption you would defend least, and which part was yours. Say each in your own words. | The obvious probe on the one figure you have. |

## 9. Defend-the-number rule (applies to B3)

The £4M figure raises four slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. You have not given the method or the attribution rule in your message, so the pack supplies none. If you can answer all four, say them. If you cannot, say "I can't reconstruct how that was counted" and stop there.

## 10. Reverse questions

1. "What does a good first year look like for this role, in numbers?" *Why it lands:* it shows you plan against a result.
2. "Which operators are you already in conversation with, and where is the friction?" *Why it lands:* it asks for the real pipeline, not the brochure.
3. "How is commercial risk shared between Kelverton and an operator today?" *Why it lands:* it goes straight to Ross's territory.
4. "What would make you say no to an operator deal?" *Why it lands:* the anti-pick question; it shows judgment.
5. "What did the last person in this role get right, and what did they miss?" *Why it lands:* it asks Deepa to show her own standard.

## 11. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or sourced the £4M | Inflated form of F2 ("influenced" widened to "owned") | The quote at its own scope: "roughly £4M of influenced revenue." The limit is the pack's observation, not a first-person negative. |
| Sold into rail, or knows the rail buying cycle | Inflated form of F4 | "I've never sold into rail specifically." No slot about rail sales. |
| Knows how operators buy scheduling software | Not in your material; inferred from transport planning | Your planning-side view only (F3). Describe what you saw, not what operators buy. |

## 12. Upgrade menu

- **The JD text** → the requirement-coverage table covers every JD line, and F1–F4 become `[grounded]` where the JD quotes them. Also tells us whether the role names any gate (location, right to work, travel).
- **The market report's headline view** → the differentiation strategy in section 5, which currently cannot depart from consensus.
- **The interviewers' public footprints** (Deepa and Ross; surnames help, so the search can tell them apart from others of the same first name) → the interviewer read, persona weights and a tailored reverse question.
- **The recruiter's process email** → whether the POV is graded by a rubric, and whether the panel's other rounds exist.

## 13. Sources

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Refused (permission not granted). Values cheat sheet not built. |
| 2. `Kelverton Rail interview process` | unavailable | Refused (permission not granted). Loop structure unknown; persona weights follow the generic archetype. |
| 3. `Kelverton Rail strategy operators scheduling software` | unavailable | Refused. Would have fed the CO bank and the differentiation strategy. |
| 4. `Deepa VP Partnerships Kelverton Rail` | unavailable | Refused. Would have made the interviewer read and a tailored reverse question. |
| 5. representative `Senior Partnerships Manager` JD | unavailable | No search sent after the refusals. Would have fed the JD-tagged questions. |

Every call was refused, so no source was read. No values, loop or strategy fact in this pack comes from research.

Provided documents: your message (quoted recruiter email, background). The market report was not provided to me in this conversation.

## 14. Loop and archetype

No loop source established the loop. The archetype fallback is **generic**: flat persona weights, said plainly.

