Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-8-canned-b10e36c2/38f5bddf-5af3-4cf8-bca3-046f61051a3c/scratchpad/ashgrove_member-experience-lead_interview_pack.md`. It covers all three rounds. I didn't run any web searches, because the values, the round structure and the strategy summary were already in your message.

The biggest prep item is the one the pack names as highest-ROI: you've never presented above regional level, and the Head of Member Services is likely to press on it (question B1). I'd rehearse holding that position for two follow-ups, then conceding it exactly, without promising a senior presentation you haven't given.

Say the word and I'll play the Skeptic on B1. I can also save a `tuesday-dossier.md` that records the gaps this prep exposed (F7 to F9), so later sessions start from them. If you'd like the pack as a Word document, say so and I'll convert it.

How much prep time do you have before 28 November?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Rounds on 28 November 2026**
- Round 1: recruiter screen, 30 minutes.
- Round 2: behavioural, 45 minutes, with the Head of Member Services (your future manager). Mostly behavioural, per the recruiter.
- Round 3: panel of two branch managers, 60 minutes, including a 20-minute complaint escalation case. The panel also scores the four values.

Names of the Head and the two branch managers are not yet known. Each is treated by role only.

**Built on:** the JD and the recruiter's email as you pasted them; your background as you stated it; the four values as you copied them from the site on 19 November 2026; the July 2026 strategy brief as you summarised it.
**Not built on:** a CV, a dossier, a working-style assessment, or any named interviewer.

---

## How to use this pack

Personas describe how a question arrives. Types describe what it scores.

| Type | Name | What it scores |
|---|---|---|
| VAL | Values and behaviour | Whether past behaviour shows the published values |
| EXP | Experience deep-dive | What you actually did, and whether the CV claims survive a follow-up |
| JD | Listed job | The responsibilities and requirements in the posting, including the gaps |
| CO | Company and strategy | Whether you know where Ashgrove is going and can think at that level |
| CASE | Live problem | Structure and reasoning on a problem from this role |

Guidance is scaffolding, not a script. Say it in your own words, in 90 to 120 seconds. Where a line is an answer slot, the answer is yours to give, and either honest branch is a good answer.

---

## Fit snapshot

Each requirement from the JD is set against the sentences you gave me. Quotes are yours or the JD's, verbatim.

The JD has no requirement that is a gate in the sense of a term you meet or do not (location, pay, licence, schedule). So no gate row appears.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | No gap. Say the six years and the three as branch supervisor as written. Confidence is medium because no CV or record has been inspected, so expect a probe on dates. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | Your material says formal complaints log. It does not say regulated. Say the log in the quote's own terms. Answer slot: the JD raises the regulated part, so expect a question on which rules or timelines the log ran to. If you worked to named ones, say which. If the log had none you can name, say so and say how it was kept. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Say the spreadsheet as written. The JD names resolution times, and your material does not say what the spreadsheet measured. Answer slot: if it held resolution times, say which measure and how it was counted. If it held only volumes, say so and say what you would add first. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | No gap. Confidence is medium because the spreadsheet has not been seen. Expect a request to walk through it. |
| F5 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message); "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | This is adjacent work: one branch's log, and tellers trained on a script. End to end across branches is not in your material, so the words stay at the branch: "I handled the branch's formal complaints log." Answer slot: if you set steps of the process beyond your branch, say which and how you decided. If you did not, or they were not yours, say so and stay with the branch log. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | This is adjacent: you trained tellers. Coaching supervisors is not in your material. Say the training as written. Answer slot: if you have coached a supervisor on an escalation, say what happened in your own words. If you have not, say so and say how you would start. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Nothing in your material shows this. Answer slot: if you have worked with any team on a digital channel or self-service journey, say which and what your part was. If you have not, say so and say what you would examine first on a member's route through a complaint. |
| F8 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Plain acknowledgment: "I've never worked in a contact centre." Then say how you would learn it, as a plan and never as a past. |
| F9 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Plain acknowledgment: "I've never presented to anyone above regional level." Then say how you would learn it, as a plan and never as a past. |

**Observations from the analysis (not words for you):** your material shows a branch complaints log, a spreadsheet, and tellers trained on a script. It does not show work across branches, supervisor coaching, digital journeys, a contact centre, or presenting above regional level. The three capability rows (F8, F9) are the ones an interviewer will test first.

---

## Grounding brief

Built from your summary of the July 2026 strategy brief. I have not read the brief itself.

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- Main competitive pressure: app-only banks.

Use these as current vocabulary. Nothing in your summary is stale as far as I can tell.

---

## Persona table

| Round | Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Recruiter, 30 min | Conversational, with light Skeptic | Friendly opener, then logistics: pay, notice, location, reason for leaving | High. The recruiter's own description is a screen, and logistics are its stated content | Treat the friendly questions as scored. Give logistics in your own words |
| Head of Member Services, 45 min | Skeptic, with Values/Behavioral | Behavioural stories, then probes at F8 and F9 | High. The recruiter says the round is mostly behavioural and that this person would manage you, so they are testing the gaps they would carry | Use one story per question. Hold F9, then concede precisely |
| Panel, 60 min | Values/Behavioral, then Case/Strategist, then Peer Evaluator | Four scored value questions, a 20-minute escalation case, then seam questions from peers | High for values (the recruiter says the panel scores them). Medium for the case. Low to medium for peer probing, because the branch managers' roles are known and their questions may be collegial | Map a story to each value. Clarify the case before you structure it |
| All rounds | Data-Driven Prober | Asks how the spreadsheet counted things | Low. You have no published figure to probe, but F3 and F4 invite it | Say what the spreadsheet counted, and say plainly what you do not know |

Question counts follow weight: the top round has the most. Recruiter 5 (logistics count as rows). Head 5. Panel: values 4, case 3, peer 2.

---

## Question banks

Provenance comes first. Each row carries every sentence its guidance rests on, quoted from the fit snapshot or the JD.

### A. Recruiter screen (Conversational, light Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | JD, EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Ninety seconds, in this order: the six years and the three as branch supervisor, then the complaints log, then the spreadsheet, each in the words quoted. Stop there. Add no figure, team size or result you have not already said. | Casual openers are scored. F1, F2 and F4 are the sentences it draws on, and the order follows the JD's first requirement. |
| A2 | "Why are you looking to leave your current role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Logistics slot, reason for leaving: give your own reason in your own words. Your material gives none, and this pack does not supply one. Keep it to the move, not to criticism of your employer. | The recruiter's reason-for-leaving check. Your current role is the only thing the quote shows, so nothing about the reason is inferred. |
| A3 | "What are you looking for on pay?" | JD | [generic] | Logistics slot, pay: give the figure or band you need, in your own words. You can also ask for the role's band first. The pack gives no figure, because none is in your material. | Pay is a screen knockout the JD does not state. The guidance makes no claim about you, so it carries its label alone. |
| A4 | "When could you start, and what notice do you need to give?" | JD | [generic] | Logistics slot, notice: give your actual notice period in your own words. Your material does not state it. | Notice is a screen knockout. The guidance claims nothing about your past. |
| A5 | "Which locations could you work from, and could you travel between branches?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD) | Logistics slot, location: name the locations and the travel you can do, in your own words. Your material states neither. | The JD's "across branches and the contact centre" makes travel the likely question. Nothing about your past is claimed. |

### B. Head of Member Services (Skeptic, with behavioural probes)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never presented to anyone above regional level. Why would senior leaders trust a presentation from you?" | JD | [grounded] "I've never presented to anyone above regional level" (your message); "confident presenting to senior leaders" (JD) | Highest-ROI prep in this pack. Hold: say plainly that you have not presented above regional level, in the words quoted. Hold through two follow-ups by returning to that sentence, and to the first thing you would do, given as a plan, not a past. Concede precisely: presenting to senior leaders is the part you have not done. Answer slot: if you have presented at regional level, say what it was and to whom, in your own words. If you have not, say so. Never describe a senior presentation you did not give. | F9 is a stated gap the JD scores directly, and it is the objection most likely to come up in some form. Rehearse the hold-then-concede shape until it is ordinary. |
| B2 | "Self-service journeys are part of this role. Which member journey would you look at first, and why?" | JD, CO | [grounded] "work with digital teams on self-service journeys" (JD); "move 40% of member service to digital channels by 2028" (the July 2026 brief, as you summarised it) | Pick one route a member takes to complain, such as a complaint started in an app or at a branch, and say what you would examine first on it. Answer slot (F7): if you have worked with any team on a digital channel or journey, say which and what your part was. If you have not, say so and say what you would check first. | Ties the JD's self-service line to the 2028 target. F7 has no quote, so the guidance cannot claim any digital work. |
| B3 | "Tell me about a complaint you handled that did not go the member's way. What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Scaffold: pick one complaint that ended against the member. Say what you decided, what you told the member, and what you did next, in your own words. If none comes to mind, say so plainly, then say how you would handle one now. Do not improve the ending. | A behavioural probe on honesty about outcomes, which the Head's round is built to test. The log is the only sentence it draws on, so the story stays inside it. |
| B4 | "This role handles regulated complaints. Which rules and timelines did the log you kept run to?" | JD | [grounded] "I handled the branch's formal complaints log" (your message); "experience handling regulated complaints" (JD) | The premise is only that the log existed. Which rules it ran to is the JD's raise, and your material does not say. Answer slot: if the log ran to rules or timelines you can name, name them and say which part was yours to meet. If it ran to none you can name, say so plainly and say how it was kept. Do not name a framework you cannot name in the room. | F2 carries the requirement with the least support, and the regulated part is what the Head will probe. The second branch lets the premise be false. |
| B5 | "Our branch supervisors escalate to the contact centre and sometimes get it wrong. How would you coach them?" | JD, CASE | [grounded] "coach branch supervisors on escalations" (JD); "trained new tellers on our escalation script" (your message) | Coach in three steps: what you would watch in a supervisor's escalations, how you would give feedback in a one-to-one, and how you would check it a month later. Answer slot (F6): if you have coached a supervisor on an escalation, say what happened. If you have only trained tellers on the script, say so and say how you would start with supervisors. | Turns the JD's coaching line into a live problem. F6 is the nearest sentence, and it is about tellers, so the answer says so. |

### C. Panel, values round (Values/Behavioral, one question per published value)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold: pick a decision that changed the outcome for a member because you looked at it from their side. Say what the member would have faced, what you chose, and what changed. If none comes to mind, say so plainly, then say how you would make the call on a complaint you saw today. | Members First, Always. No quoted sentence records a decision of this kind, so the guidance gives selection criteria and the honest branch. F5 is the nearest sentence. |
| C2 | "Tell me about a time you had to explain something so that someone understood it the first time." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Story map from the training: the script, the tellers, and what you taught them. Answer slot: say how you checked they had understood, in your own words. If you did not check, say so. Do not describe the script's wording as yours unless you wrote it. | Plain Words. Only the training sentence is quoted, so the checks on understanding are slots. |
| C3 | "When has knowing a town or a branch changed how you handled a customer's problem?" | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Open prompt, framed by the three years as branch supervisor. Pick one customer whose local situation mattered to the outcome, and say what you knew and what you did with it. Answer slot: if no case turned on local knowledge, say so and give the nearest case where a customer's own situation shaped the result. | Neighbours, Not Numbers. The supervisor years are the only sentence that places you in a branch, so the story starts there. |
| C4 | "Tell me about a problem you found that you kept hold of until it was fixed." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Scaffold: pick a complaint or pattern you kept hold of until it was closed. Say what you found, who you told, and how you knew it was solved. Answer slot: if the fix went beyond your branch, say how you followed it. If you handed it on, say to whom and what you did until then. | Own the Fix. The log is where you held complaints. Do not stretch this answer to the contact centre (F8). |

### D. Panel, escalation case (Case/Strategist)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A member has waited three weeks. The branch says the contact centre has the file. The contact centre says the branch has it. The member wants a senior person to ring them today. What do you do?" | CASE | [generic] (an invented rehearsal case; the real one will differ) | Structure in order. Clarify what the member was told, by whom, and what they need by when. Set the objective: one named owner and one clear answer to the member today. Separate what is known from what is not. Choose an approach: take the owner role, call the member, then agree the handover. Name the metrics: time to a clear answer, repeat contacts. Name a risk: two records that disagree. Think aloud and say each step. | A live escalation problem from the JD's cross-branch line. It makes no claim about your past, so it carries only its label. The panel scores clarifying before structuring. |
| D2 | "The branch manager tells you the contact centre caused it. What do you say?" | CASE | [generic] | Hold the cause open. Ask for the record before naming one. Agree with what the record supports, and say what you would check next. Do not blame either side in the room. | A pressure version of D1. It tests composure under a challenged premise. |
| D3 | "The role reports monthly on complaint volumes and resolution times. What would you put on that page first, and what would it hide?" | JD | [grounded] "report monthly on complaint volumes and resolution times" (JD); "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Name volumes and resolution times, as the JD does. Say what each would hide: volume alone does not show how long cases stayed open, and an average time does not show which cases were slow. Answer slot (F3): if the spreadsheet held resolution times, say which measure and how it was counted. If it held only volumes, say so and say what you would add first. If you give any figure, name the assumption behind it you would defend least. | Covers the JD's reporting requirement and the Excel claim (F4). A branch manager reading the spreadsheet is the most likely source of a measure question. |

### E. Panel, peers (Peer Evaluator)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A complaint starts in a branch and ends in the contact centre. Who owns it, and when does that change?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD); "Never worked in a contact centre" (your message) | Propose seam principles, not facts about their seam: one named owner from first contact to close, one shared record, an agreed handover point. Say plainly that you have not worked in a contact centre, then say what you would need from their team first. Do not claim you know how their handover works. | The Peer persona tests seams between branches and the contact centre. F8 is the stated gap, kept as a plain acknowledgment with a plan. |
| E2 | "When two teams both resolved part of a complaint, how do you decide who gets the credit?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Name the principle first: credit goes to whoever holds the member's case through to the answer. Answer slot: if a complaint you closed involved another team, say what they did and what you did. If none did, say so and say how you would credit shared work. | Credit-sharing is a peer probe. The principle is generic, and the answer makes no claim about your past beyond the log. |

**Totals:** 19 questions (A 5, B 5, C 4, D 3, E 2).

### Requirement coverage

| JD requirement or responsibility | Questions |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B4 |
| Confident presenting to senior leaders | B1 |
| Comfortable with Excel reporting | D3 |
| Report monthly on complaint volumes and resolution times | D3 |
| Own the member complaints process end to end across branches and the contact centre | E1, C4 |
| Coach branch supervisors on escalations | B5 |
| Work with digital teams on self-service journeys | B2 |
| Small-business lending (in the strategy brief, not the JD) | None, and why: the JD does not ask for it, so it is a reverse-question topic |

---

## Values cheat sheet

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a decision of this kind. Selection scaffold, C1, with its honest branch |
| Plain Words | If a member needs it explained twice, the writing was wrong | F6: "trained new tellers on our escalation script". C2, with its check-for-understanding slot |
| Neighbours, Not Numbers | Every branch is part of its town | F1: "6 years in retail banking, the last 3 as a branch supervisor". C3, a scaffold with its honest branch |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F5: "I handled the branch's formal complaints log". C4, with the beyond-branch slot |

---

## Reverse questions

| Question to ask | Why it lands |
|---|---|
| "What does complaints reporting look like today, and who reads it first?" | Shows you want to understand the reporting you would own, not replace it |
| "How do branch supervisors escalate now, and where does it usually stall?" | Puts your coaching focus into the conversation |
| "As more service moves to digital by 2028, which complaints do you expect to rise?" | Ties the July brief to the work |
| "What happens to the complaints log while the eight branches move into five hubs in 2027?" | Shows you think about the member during a change |
| "What did the last person in this role find hardest?" | Asks about the real job, not the posting |
| "What would a new person do in their first month that would genuinely help your team?" (panel branch managers only) | Reciprocity for peers, who are pricing what the hire adds to their work |

No interviewer profile exists, so no reverse question is tied to an interviewer's career path.

---

## Prohibited claims

Not coached in any answer, slot, hold or drill, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F5 | F5's quotes at their own scope: "I handled the branch's formal complaints log"; "trained new tellers on our escalation script". Observation, not a claim about you: your material shows one branch's log |
| Coached branch supervisors on escalations | Inflated form of F6 | "trained new tellers on our escalation script". Observation: your material shows tellers, not supervisors |
| Worked in contact-centre operations | Negative you stated, F8 | Plain acknowledgment: "I've never worked in a contact centre." |
| Presented to senior leaders | Negative you stated, F9 | Plain acknowledgment: "I've never presented to anyone above regional level." |
| Handled regulated complaints under a named framework | Inflated form of F2 | "I handled the branch's formal complaints log". The framework is B4's slot, not a claim |
| Built reporting that senior leaders use | Inflated form of F3 and F4 | "I built the monthly complaints spreadsheet our regional manager uses" |

---

## Sources

- **Provided documents:** the JD and the recruiter's email as pasted; the four values as pasted from the values page, copied 19 November 2026; the July 2026 strategy brief, as your summary of it; your background message.
- **Searches and fetches sent:** none.

**Research tier: L1, searches 0 of 6, fetches 0 of 2.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The four values were pasted, so the input fixes the values cheat sheet |
| 2. Ashgrove interview process, Member Experience Lead | skipped | The recruiter's email fixes three rounds, their lengths and their content |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief supplies the priorities. A search would add only the brief's own wording, which the upgrade menu offers |
| 4. Interviewer name and Ashgrove | n/a | No names were given. The Head and the branch managers are named by role only |
| 5. Representative JD for the title | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Names of the Head of Member Services and the two branch managers → persona weights per round member, a tailored reverse question, and a read of each interviewer's public footprint.
- The monthly complaints spreadsheet, or its column headings → F3 and F4 can move toward high confidence once it is shown, and the Excel question gets a named artifact.
- The complaints rules your branch worked to, by name → B4's answer slot becomes a story map instead of a scaffold.
- Your prep time before 28 November → a prep triage section sized to it, with the few things to do first.
- The recruiter's prep email, if it names any focus for the 60-minute round → coverage of that focus in the banks.
- The July 2026 brief itself → the grounding brief quotes the brief instead of your summary.
- Deep research, level L2 → the brief, interviewer talks and recent organisation news, at up to six more searches and two more fetches. Each takes time; say yes and I will run it.
- `tuesday-dossier.md` → adds F7 to F9 to a file, so later sessions start from the gaps rather than from scratch.
