Interview-prep module is loaded. Next I'll run the research its playbook calls for (company values, interview process, recent news, and the interviewer's public footprint), in parallel.
I'll write the pack now. Web search was refused in this session, so the pack runs on your material and the JD only, and every outside fact is labelled as generic.
Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-7-denied-571b1711/ce249e4a-b122-41ed-8ffb-601ce8b271b3/scratchpad/saltmarsh_live-ops-producer_interview_pack.md. I built it for a hiring-manager round, since Tobias is Head of Live Operations.

The pack is built without web research. Web search was refused in this session, so I had no Saltmarsh values, interview-loop details, recent news or public footprint for Tobias. Everything about the company is labelled generic. If you allow search, I can re-run it and add those.

The three things that matter most:

- **B2 is the highest-ROI prep.** Expect "you've never led a team" plus "how would you coordinate design, art, engineering and community?" Practise the plain "I haven't led a team," then the coordination you have actually done, then the plan.
- **Your gaps are on the page, not hidden.** The pack flags that your calendar covers one title against their two, that the QA checklist is the only cross-team evidence, and that "presented" retention numbers is not the same as owning KPIs. It also flags in-app purchases, which the JD doesn't mention. Those answers are short, honest and rehearsable.
- **Friday is tomorrow if today is Thursday.** Use the triage order in section 2 of the pack.

I can run a drill on B2 next, or keep building the pack if you tell me more.

Is Tobias your future manager, and is this the only round? The answer changes the persona weights.

Watch-out: Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-ops-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Role:** Live Operations Producer. **Company:** Saltmarsh Games (mobile, about 350 people). **Interviewer:** Tobias Wrenfield, Head of Live Operations. **Relationship:** taken as hiring manager; to confirm. **Round:** 60-minute interview, Friday.
**Changelog:** first version.

## 1. How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values), EXP (your past work), JD (the listed job), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Say it in your own words, and only what you actually did.
- Answer slots are instructions for the interview. Each one has two honest branches: you did it, or you did not and you say so.
- Provenance: `[grounded]` traces to your message or the JD. `[inferred]` is a derivation. `[generic]` is a pattern for this kind of role with no claim about Saltmarsh.

## 2. Prep triage

Friday is the deadline. Work in this order:

1. **B2**, the highest-ROI prep. Rehearse it out loud three times, including the two follow-ups.
2. **A4 and A5**: say the calendar story in 90 seconds, then the two-title answer (F3).
3. **A3**: a KPI plan for one live event, with a success metric, a baseline, a guardrail and a read window.
4. **C1**: the retention numbers, and which part was yours.

Everything else is insurance.

## 3. Fit snapshot

The JD's requirements are quoted from the JD. Your background is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | presentation | Your quotes already reach the years. Say them in your own words. Your material shows content drops, not that the title was live-service in the sense the JD means; expect that probe. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | No gap. Lead with the calendar in your terms: the weekly drops, the main title, the two years. Expect a probe on how it was run. |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material covers one title. For the last two years I ran the weekly content-drop calendar for our main title. Answer slot: if the calendar or any live plan covered a second title, say which and what you did; if not, say so plainly and describe how you would plan across two. |
| F4 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses" (your message); "Never led a team, and never worked on a game with in-app purchases." (your message) | low | [grounded] | discovery | Your material touches QA only. It says nothing about design, art, engineering or community, and "never led a team" is about leading, which this line does not ask for. Answer slot: name an update where you coordinated another team and your part in it; if none was yours, say so plainly and describe how you would coordinate those four teams on each update. |
| F5 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Bridge: I presented the monthly retention numbers to the studio head. Your material shows presenting numbers, not owning the KPIs or a post-event review. Answer slot: if you chose the KPIs a report used or ran a post-event review, say which and what you decided; if not, say so plainly and say how you would set one up. |
| F6 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | Bridge: I wrote the release checklist our QA team still uses. Your quote says written and in use. It does not say you ran each release against it; expect that probe. Inspectable artifact: the checklist itself, which would lift this row to high if you can bring it. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | Bridge: I presented the monthly retention numbers to the studio head. Your quote shows presenting, not computing. Answer slot: if you defined or calculated the figures, say how they were counted and which assumption you would defend least; if you did not, say so plainly. |
| F8 | "clear written communication" (JD) | none in your material is a writing sample for evaluation | low | [grounded] | discovery | Your material names one written artifact, the checklist. Answer slot: bring a written piece you wrote, such as the checklist or a post-event note, and say what it was for. |

**Gates:** the JD states no location, schedule, work-authorization or credential term, so the snapshot holds no gate row.

## 4. Prohibited list

Built locally from the snapshot. Nothing below may be asserted in an answer, a hold or a bridge.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Your stated negative, F4 ("Never led a team") | The plain acknowledgment: "I haven't led a team." No slot asserts otherwise. |
| Coordinated design, art, engineering and community on updates | Inflated form of F4. No quote carries it. | F4's quotes at their own scope. The limit is my observation: your material shows QA, not the other four teams. |
| Ran two live titles | Inflated form of F3 | F3's quote at its own scope: one main title. |
| Owned the KPIs and post-event reviews | Inflated form of F5 ("presented" to "owned") | F5's quote at its own scope. |
| Managed the release process with QA | Inflated form of F6 ("wrote" to "managed") | F6's quote at its own scope. |
| Defined or computed the retention metrics | Inflated form of F7 | F7's quote at its own scope; the slot asks how the figures were counted. |
| Live-service title ownership | Inflated form of F1 | F1's quotes at their own scope. |
| Experience with in-app purchases | Your stated negative ("never worked on a game with in-app purchases") | The plain acknowledgment: "I haven't worked on a game with in-app purchases." |

## 5. Persona weights

Relationship prior for a hiring-manager round: Case/Strategist and Skeptic dominate. The loop is unknown: no loop source was read, so the weights below are a prior, not Saltmarsh's documented process. Flat weights are used across the rest.

| Persona | Weight | Questions | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|---|
| Case/Strategist | top | 5 | Live plans for the two titles | High. A hiring manager buys capability and tests it on the live roadmap. | Clarify, then objective, then segments, then approach, then metrics, then risks. Think aloud. |
| Skeptic | top | 5 | The gaps: teams, KPIs, IAP | High. The JD's breadth against your four years of one title is the obvious probe. | Rehearse the top objection until it is boring. Plain acknowledgment, then the plan. |
| Data-Driven Prober | mid | 3 | Retention numbers, the checklist | Medium. Retention is a JD requirement. | Say what you counted and what you did not. Name the weakest assumption you know. |
| Pressure | low | 2 | A one-title challenge | Medium. Hiring managers sometimes time-box. | Pause, restate, hold through two follow-ups, then concede specifically. |
| Values/Behavioral | low | 2 | Open prompts | Low. No values round is detected. The fallback is "no", so this bank is [generic]. | Pick a real instance. If none comes to mind, say so. |
| Conversational | low | 2 | The opener, and a hot JD topic asked casually | Medium. Casual questions are still scored. | A 90-second arc. Treat casual questions as scored. |

## 6. Question banks

Total: 19 questions, within the 18 to 26 range.

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you'd plan the next month of live events for two mobile titles. What do you need to know first?" | CASE | [grounded] JD: "Plan and run the live-events calendar for two of our mobile titles" | Clarify before structuring: title sizes, update cadence, the current retention baseline, team capacity. Then objective, segments, approach, metrics, risks. Say the framework aloud. Makes no claim about your past. | F3 and F2 are the candidate's nearest evidence. CASE because the question is a live problem from the role. |
| A2 | "Retention drops twenty percent after this week's update. Diagnose it." | CASE | [generic] | Clarify what changed and when. Segment by new against returning players, platform and region. Check the release checklist against what shipped. Separate the update from outside causes. Name the metric you would check first. | Retention is a JD requirement (F7). Pattern for the problem, no fact about Saltmarsh. |
| A3 | "The role owns the post-event review and the KPIs it reports. What would you measure in the first week after an event, and what would make you call it a miss?" | JD | [grounded] JD: "own the post-event review and the KPIs it reports"; [grounded] "Presented the monthly retention numbers to the studio head" | Plan, not past: a success metric set before launch, a baseline, a guardrail metric, a read window, and what you would report. Answer slot: if you have set KPIs for a report before, say which and what you decided; if you have not, say so plainly and give the plan above. | F5 is where the KPI requirement presses. The question scores the plan; the past is an answer slot. |
| A4 | "Walk me through the weekly content-drop calendar you ran for the last two years." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped on F2: the weekly drops, the main title, the two years, in your own words. Answer slot: if you chose what went into a week, say how you decided; if the calendar was set by someone else, say so plainly and describe your part in running it. | The JD raises planning ("Plan and run"), so a probe on decisions is likely. F2 carries the calendar. |
| A5 | "You ran the calendar for one title. What would you need to learn before you could plan across two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; [grounded] JD: "Plan and run the live-events calendar for two of our mobile titles" | Transferability, stated plainly: one main title, two years. Name what you would learn about the second title first. Hold the one-title fact; do not add a second title to your story. | F3 is the thin row. This is the requirement-level version of its answer slot. |

### B. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Wrote the release checklist our QA team still uses"; [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: name the requirement where your quotes are thinnest (F4 or F5), say what you have and have not done, then say how you would close it in the first month. | The Skeptic's standard opener. The honest answer is a named gap plus a plan. |
| B2 | "You've never led a team. How would you coordinate design, art, engineering and community on each update?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message); [grounded] JD: "coordinate design, art, engineering and community teams on each update" | Plain acknowledgment first: "I haven't led a team." Then the coordination you have actually done. Answer slot: if you coordinated another team on an update, name it and your part; if not, say so plainly. Then the plan, as a plan. Hold through two follow-ups by returning to the QA work and the plan. Concede specifically if pressed further. Never claim team leadership. | **Highest-ROI prep.** This objection is near certain in some form. The rehearsed honest answer changes how the interview goes. Deepest rehearsal here. |
| B3 | "The role owns the KPIs its post-event reviews report. Which KPI would you own, and what would you not claim?" | JD | [grounded] JD: "own the post-event review and the KPIs it reports"; [grounded] "Presented the monthly retention numbers to the studio head" | Name one KPI you would own and why it fits the job. Say what you presented in the past and what you did not define. Do not claim ownership of KPIs you only presented. | F5. Scores the stated requirement and separates presenting from owning. |
| B4 | "You haven't worked on a game with in-app purchases. What would you need to learn before planning a live event that involves them?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the learning plan: the data you would ask for, the people you would ask. No claim about past monetisation work. | The gap you stated. Its honest answer is short and undefended. |
| B5 | "Why this role, when your background is a puzzle game?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Answer slot: say why this role and this studio, in your own words. Your material gives no reason, so none is supplied here. | Motivation probe. The honest answer comes from you, not the pack. |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented to the studio head. How were they worked out, and which part was yours?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if you computed or chose the retention definition, say how it was counted and which assumption you would defend least; if you presented figures produced by others, say so plainly and say what you presented and to whom. | F7. The prober checks attribution. Presenting and computing are different claims. |
| C2 | "Which assumption behind a retention number would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if you know an assumption behind a figure you presented, name it in your own words. If you do not know how the figure was counted, say so plainly. | Weakest-assumption move for a figure the candidate presented. Names no assumption for them. |
| C3 | "What is on the release checklist, and why is each line there?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Describe the lines in your own words. Answer slot: if a line came from a specific failure, say which and whether you were there; if no line came from a failure, say so plainly. | F6. The prober checks whether the checklist is inspectable and whether the candidate authored it. |

### D. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, when the role is about two titles and you have run calendar work for one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; [grounded] JD: "Plan and run the live-events calendar for two of our mobile titles" | Pause, restate. Hold the one-title fact and what the calendar work carries. Hold through two follow-ups. Concede specifically: one title, no second title, no team lead. Do not argue the requirement away. | Time-boxed challenge on the main gap. Scores composure, not content. |
| D2 | "That retention presentation: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold: "I presented them." Concede exactly what you did not produce. Answer slot: if you produced any of the figures, say which; if you presented figures someone else produced, say so plainly. | Hold-then-concede. The attribution challenge is answered by precision. |

### E. Values/Behavioral (2), [generic]

No values round was detected and no published values were read. These are open prompts from persona stems.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] persona stem; [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: pick a time you told a senior person something they did not want to hear. It needs a stake, a moment you did not fold, and a working relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries: the retention presentation, saying only what you said in it. | Persona stem. Open prompt with a selection scaffold and its honest branch. |
| E2 | "When did you put a player ahead of a number on a dashboard?" | VAL | [generic] persona stem | Selection scaffold: pick a decision where a player-facing consideration outweighed a metric. If none comes to mind, say so plainly and say how you would weigh it. | Persona stem. No candidate claim. |

### Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; [grounded] "Wrote the release checklist our QA team still uses"; [grounded] "Presented the monthly retention numbers to the studio head" | A 90-second arc. Four beats, each a quoted sentence: the four years, the calendar, the checklist, the retention presentation. Then one sentence on what you want next. | Casual opener, still scored. Each beat is a quote, so nothing is added. |
| K2 | "What live-service game are you playing these days, and what do its events do well?" | JD | [generic] | Name a game you actually play. Describe one event in your own words and what you noticed about it. Do not claim expertise you do not have. | Casual version of the live-service JD topic. Pattern, no claim about you. |

### Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A5, D1, F3 |
| "coordinate design, art, engineering and community teams on each update" | B1, B2, F4 |
| "own the post-event review and the KPIs it reports" | A3, B3, F5 |
| "manage the release checklist with QA" | C3, F6 |
| "3+ years producing live-service games or apps" | A4, K2, F1. None separately: the years are a stated fact in F1, and B5 covers the framing. |
| "experience running a content calendar" | A4, F2 |
| "comfortable with player-retention metrics" | A2, C1, C2, F7 |
| "clear written communication" | None, and why: your material has no writing sample to test, so the question would only repeat the checklist. F8 asks for an artifact instead. |

## 7. Reverse questions

Each one lands for a stated reason. No interviewer profile was read, so none is tied to Tobias's own path.

1. "What would a good first two live events look like, measured how?" Lands because it shows you are planning to be judged on outcomes.
2. "How are the two titles' calendars planned today, and who decides what ships in a given week?" Lands because it tests the A1 and A4 answers against reality.
3. "How is the post-event review run today, and what goes to whom?" Lands because it asks about the F5 requirement directly.
4. "Who owns the release checklist with QA now?" Lands because it tests F6 and shows you know it matters.
5. "What did the last live-events miss look like, and what changed afterwards?" Lands because it signals you expect a real answer, not a brochure one.

## 8. Sources

Research tier: L1 — searches 4 of 6, fetches 0 of 2. Every search below was refused by the host (permission denied), so none returned a result.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, not built: values are not in hand and no values round was detected. Queries sent: "Saltmarsh Games values" (refused). |
| 2. Saltmarsh Games interview process, live operations | unavailable | Loop structure, persona weights. Persona weights here are a prior; the loop is unknown. Queries sent: "Saltmarsh Games interview process live operations producer" (refused). |
| 3. Saltmarsh Games strategy / recent news | unavailable | CO bank would have gone from generic to grounded. Queries sent: "Saltmarsh Games mobile game news strategy" (refused). |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read, a tailored reverse question, persona weights from his public footprint. Queries sent: "Tobias Wrenfield Saltmarsh Games Head of Live Operations" (refused). |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Provided documents: your message (background), the JD as pasted in it. No dossier was present.

## 9. Upgrade menu

- **Search access** (refused this session) → the values, loop, strategy and Tobias's public footprint: a tailored reverse question, persona weights from his talks, and the values cheat sheet if Saltmarsh publishes values. A deeper research pass is offered once, at the same caps, if search becomes available.
- **Saltmarsh's recruiter prep email** → the loop structure and any pre-declared deliverable, which would reweight the banks.
- **The release checklist itself** → lifts F6 from medium to high, because it is an inspectable artifact.
- **A post-event review or KPI report you worked on** → turns F5 from transferability into grounded, with the exact figures in your words.
- **One update where you coordinated design, art, engineering or community** → turns F4 from discovery into grounded and reshapes B2.
- **Any second title, even a small one** → lets A5 and D1 answer with evidence rather than a plan.
- **A written piece you wrote** → resolves F8.
