Your prep pack for all three rounds is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-6-denied-d999e247/734f7d58-c05e-46c2-8601-8d48a16d5e9a/scratchpad/larkfield-systems_engineering-manager_interview_pack.md. I built it as one shared fit snapshot with a separate question bank for each round, since you have a fixed schedule for all three.

The main thing to prepare is the scale gap. Your material shows a team of six and a backend hiring loop. The role is eleven engineers across two squads, with a hardware roadmap you haven't owned. Every round will probe that. H2 is the question I'd rehearse first: the Director is most likely to ask it in some form.

Web search was refused in this session, so the Larkfield values, interview process and strategy are not established. The values cheat sheet is left out, and the strategy question in the VP round is generic.

Two things would make the pack more specific:

1. Can you paste the full posting and your CV? The fit rows currently rest on the role paragraph and your message, so the posting and CV would ground the medium-confidence rows and the questions about your figures.
2. Does the posting state a location, on-site pattern or work-authorisation requirement? The snapshot has one gate it can't settle from what you've shared.

I can also play the Skeptic on H2 as a drill, and save a tuesday-dossier.md recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, about 600 people). Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on the roadmap.

**Loop (three rounds, loop mode):**

- Round 1, Tuesday, 45 min: hiring manager, Director of Engineering (your would-be boss)
- Round 2, Thursday, 60 min: panel of two staff engineers and a product manager (names unknown)
- Round 3, Monday, 30 min: VP Engineering, described by the recruiter as "values and leadership philosophy"

Dates assume the next Tuesday, Thursday and Monday after 19 Nov 2026: 24, 26 and 30 Nov.

**Built from:** your message only. No CV, no full posting, and no research (see Sources).

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **Type key:** VAL = behavioral and values. EXP = work-experience deep-dive. JD = role and JD-driven. CO = company and strategy. CASE = live problem.
- **Guidance is scaffolding, not a script.** Answer in your own words. Where a slot says "say so," say so.
- **Question IDs:** H = round 1, P = round 2, V = round 3.

## Fit snapshot (shared across all rounds)

Quotes come from your message unless the row says otherwise.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Lead two squads building device-management services (role text you pasted) | "9 years engineering, 3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says a team lead of six. Words: "I led a team of six." Two squads and device management are not in it. Answer slot: if any work near device management was yours, say what and what your part was; if none was, say so and say how you would get up to speed. |
| F2 | Own hiring (role text: "own delivery, hiring and growth for 11 engineers") | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | presentation | The quote reaches hiring, but for backend roles and the loop. Words: "I run our hiring loop for backend roles." Add nothing to it. |
| F3 | Own delivery for 11 engineers (role text) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | A reliability quarter delivered at team scale, against roadmap pressure. Not delivery ownership across eleven people. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: which delivery decisions were yours to make. |
| F4 | Grow engineers (role text: "growth for 11 engineers") | none given | none | [grounded] | discovery | Your material does not show growth of engineers. Answer slot: if you grew someone, say who, what changed and what you did; if you did not, say so and say how you would start. |
| F5 | Partner with hardware on the roadmap (role text: "partner with hardware and product on roadmap") | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | capability | The stated absence is hardware-adjacent roadmap ownership. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn hardware constraints, said as a plan and never as a past. |
| F6 | Partner with product on the roadmap (role text) | "pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Your material shows pushing against roadmap pressure, not partnering with product on the roadmap. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: how you worked with product on that quarter, or, if you pushed past them, say so. |
| G1 | Location or on-site pattern (not in the role text) | none given | none | [generic] | hard_gate | Your material does not establish this. Surfaced, not bridged. Settled only by the posting or the recruiter (see the questions at the end). |

Requirement source for the role-text rows: the role paragraph in your message. It is a summary, not the full posting.

## Prohibited claims (built locally from the snapshot)

Each entry names its basis. Silence is not listed: growing engineers and customer work are answer slots, not prohibited claims.

| Not coached | Basis | Honest form |
|---|---|---|
| "Led two squads building device-management services" | Inflated form of F1 | "I led a team of six." Your material says a team of six, not two squads. |
| "Owns hiring across the organisation" | Inflated form of F2 | "I run our hiring loop for backend roles." |
| "Designed the reliability quarter" or "set its scope" | Inflated form of F3 and F6 | "I pushed a reliability quarter through against roadmap pressure." |
| "The 60% on-call drop was mine alone" | Inflated form of your 60% sentence | "My team's on-call burden dropped 60% after I pushed a reliability quarter through." |
| "I have managed managers" | Negative you stated | Plain acknowledgment: "I haven't managed managers." |
| "I have owned a hardware-adjacent roadmap" | Negative you stated (F5) | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." |

## Persona weights per round

| Round | Persona | Weight | Reasoning |
|---|---|---|---|
| 1, hiring manager | Case/Strategist | 4 | Hiring managers buy capability and derisk gaps; expect live problems on their roadmap. |
| 1, hiring manager | Skeptic | 3 | Gaps F1, F4 and F5 are the visible ones; "why now" is a standard probe. |
| 1, hiring manager | Data-Driven Prober | 1 | The forty-interview figure (F2) is the one number to test. |
| 1, hiring manager | Conversational | 1 | Casual openers are scored. |
| 2, panel | Peer Evaluator | 4 | Two staff engineers and a PM price the hire by what it does to their load. Assigned per member: staff A and B get Peer plus Prober; the PM gets Case plus Peer. |
| 2, panel | Data-Driven Prober | 2 | Staff engineers probe numbers and assumptions. |
| 2, panel | Case/Strategist | 2 | The PM's roadmap questions. |
| 3, VP | Values/Behavioral | 4 | A values and leadership round, named by the recruiter. |
| 3, VP | Pressure | 3 | Skip-level composure, time-boxed answers. |
| 3, VP | Case/Strategist | 1 | Strategy-heavy, but no research ran, so it stays generic. |

Panel members are unnamed, so personas are assigned by role rather than person.

## Round 1: Hiring manager (Tuesday, 45 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6"; [grounded] "I run our hiring loop for backend roles — about 40 interviews last year."; [grounded] "currently at a payments company" | About 90 seconds, in this order: nine years in engineering; three as a team lead of six; now at a payments company; running the backend hiring loop. Then stop and invite the next question. Give a reason for the move only if you have one. | Conversational prior: a casual opener is still scored. Uses only what F1 and F2 carry. |
| H2 | "You've run six engineers, and this is eleven across two squads. Which part of that would you be weakest at on day one?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" | Name the scale gap before they do. Part one: the scale you have run, in your own words. Part two: the part you have not, and how you would find out first, said as a plan. Answer slot: if you have run work across more than one team, say where and your part; if you have not, say so. Hold nothing you cannot back. Expect a second follow-up on week one. | This is the highest-ROI prep in the pack. The gap is visible on your own CV line (F1, F4), and the question will come in some form. Deepest rehearsal here. |
| H3 | "I don't see hardware in your background. How would you handle the hardware side of this roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then answer as a plan: what you would ask hardware leads first and how you would learn their constraints. Do not claim hardware experience. | F5, a gap you stated. The interviewer's premise uses only that negative. |
| H4 | "Why this role, and why now?" | EXP | [grounded] "currently at a payments company" | Say what you are moving toward and what you are leaving, in your own words. Answer slot: the reason you are looking, if you have one; say it plainly. The material gives no reason, so none is supplied here. | Motivation consistency is the Skeptic's test. |
| H5 | "Your first ninety days: two squads, eleven engineers, a device-management roadmap. Where do you start?" | CASE | [generic] | Clarify, then objective, then segmentation, then approach, then metrics, then risks. Ask which service is most at risk first, and name one assumption aloud. | Live role problem. No claim about your past. |
| H6 | "A fleet of devices shows uptime falling for a week after a firmware change. Diagnose it." | CASE | [generic] | Clarify what fell and for whom. Separate the firmware change from everything else. State two hypotheses before pulling any data, and say what you would check first. | Live device-management problem. |
| H7 | "A hardware dependency slips and a product date can't move. What do you do?" | CASE | [generic] | Clarify the dependency's real date and what the product date really costs. Bring hardware and product into the same room with options. Name the option you would not take. | Tests the partnering line of the role as a live trade-off. |
| H8 | "You ran about forty interviews last year. How do you know that number, and which of them were yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Defend-the-number slots. Answer slots: how the figure was counted; the assumption you would defend least; which part was yours. Keep the word "about" as you said it. | F2's figure. The slots it raises are the four defend-the-number slots and no others. |
| H9 | "How would you size on-call load across two squads before you have seen the services?" | CASE | [generic] | Structure it: which services page, how often, and what a page costs in hours. Name the data you would need, then the one number you would want first. Do not quote a figure from your past here. | Delivery at eleven people (F3), tested as a live problem. |

**Reverse questions, round 1** (each with why it lands):

1. "What would make the first ninety days a success for whoever holds this seat?" Why: shows you are planning for the job, not for the interview.
2. "Where do the two squads' roadmaps collide with hardware's work right now?" Why: asks about the live seam the role names.
3. "What did the last person in this seat do that you want more of, and what would you change?" Why: surfaces the real bar.
4. "What would you expect me to decide without you, and what should come to you?" Why: tests the autonomy line.
5. "What does on-call look like on these services today?" Why: opens the on-call topic without claiming anything about it.
6. "Which recent hire went better than you expected, and why?" Why: shows interest in growth.

No interviewer profile exists, so no reverse question is tied to the interviewer's career path.

## Round 2: Panel (Thursday, 60 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story map from your sentence: the roadmap pressure, then you pushed the quarter through, then the burden dropped 60%. Say what the disagreement was, with whom, and how it ended. Answer slot: if the other side had a point, say so; if the quarter was agreed rather than fought, say that. | Peer probe on spine and tact. Built on F3 and F6. |
| P2 | "Walk me through how the 60% on-call drop was measured." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Defend-the-number slots. Answer slots: how it was counted; the assumption you would defend least; which part was yours. If it was not measured formally, say so, then say what you can point to. Give no method you did not use. | The most-quoted figure in the pack. Prober stem. |
| P3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: if others carried the fix, name them and say what you did. Keep "my team" as your sentence has it. | Peer credit probe. Your sentence says the team did the work, so credit is a real question. |
| P4 | "Of about forty interviews last year, which changed a hiring decision?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Answer slot: which of them changed a decision, how you know, and which part was yours. | Prober on F2's figure. |
| P5 | "Roadmap: a hardware dependency slips two months and a customer launch is fixed. What do you cut?" | CASE | [generic] | Clarify whether the dependency sits on the critical path. Name what each option costs the customer. Pick one and name the one you would reject. | Case stem on the partnering line. |
| P6 | "What would you need from me in the first month to make the roadmap work?" | JD | [generic] | Name two things you would bring to the product team before you need anything from them. This is a plan, not a past. | Reciprocity from a peer: what you bring, not only what you need. |
| P7 | "Product wants features, and hardware needs a platform fix. How do you rank them?" | CASE | [generic] | Clarify the cost of delay on each and who bears it. Name the principle you would use. Say what you would give up. | Roadmap trade-off. |
| P8 | "What's one thing you'd push back on in how we ship device-management services?" | JD | [generic] | Give a specific view if you have one. If you have none yet, say so and name what would change it. Do not flatter the team. | Tests judgment and candour with peers. No quote supports a view, so none is supplied. |

**Reverse questions, round 2:**

1. "What's the hardest seam between this team and the hardware team today?" Why: the live problem, asked by the people who live in it.
2. "What would a new person do in their first month that would genuinely help your team?" Why: the reciprocity question a peer panel weights heavily.
3. "Where do disagreements with product usually land, and who decides?" Why: decision rights.
4. "What does the on-call rota look like on the device services now?" Why: anchors the on-call story in their world.
5. "What's the one thing about this codebase a new person would get wrong first?" Why: practical, and it signals you plan to work in it.

## Round 3: VP Engineering (Monday, 30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Selection scaffold: pick a time you told someone senior what they did not want to hear. Give the named stake, the moment you did not fold, and how it ended. Your reliability quarter is the nearest thing your material carries, but it does not show a truth landing with leadership. If no such time comes to mind, say so plainly, then give the nearest thing you have. | Values round, theme from the recruiter's words. The honest branch is required. |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time. If none comes to mind, say so plainly. Do not supply a customer story; your material contains no customer sentence. | Values stem on customer-first. |
| V3 | "Tell me about someone on your team who grew, and what you did to help that happen." | VAL | [grounded] | Selection scaffold: pick a time you grew someone; name what changed and your part. Your material shows no growth story. If none, say so plainly and say how you would start. | Growth is a role requirement with no quote behind it (F4). The honest branch is the answer. |
| V4 | "In a sentence, what's your leadership philosophy, and where did it come from?" | VAL | [generic] | Give your own sentence, not a slogan. The pack will not write it for you. Then one example from your own experience that shows it. | The recruiter's "leadership philosophy" framing. |
| V5 | "Sixty seconds: why should we hire you for this role?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6"; [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold through two follow-ups on what you can back: nine years, three as a team lead of six, a hiring loop you run, and a reliability result. Concede specifically when a follow-up names the gap: "I haven't managed managers, and I haven't owned a hardware-adjacent roadmap." Do not fold on the first two follow-ups. | Pressure stem. Hold-then-concede, with the concession as a plain acknowledgment from your own words. |
| V6 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold: "I pushed the quarter through, and the burden dropped after that." Answer slot: which part was yours and which was the team's. If you cannot separate them, say so and concede that uncertainty specifically. Do not fold on "I pushed it through." | Pressure on attribution. The hold is only what your sentence carries. |
| V7 | "Name a roadmap argument you expect to lose with product this year." | CASE | [generic] | Name a real type of argument, what you would concede in it, and why. Do not claim a past loss. | Pressure-style hypothetical. No claim about your past. |
| V8 | "What does device management need to get right in the next two years?" | CO | [generic] | Name one bet, with a reason, and one risk. Research did not run, so the company's strategy is not in this pack. Label anything from general sector knowledge as your view. | CO question, generic because no research ran. |

**Reverse questions, round 3:**

1. "What leadership behaviour here do you most want the next manager to repeat?" Why: links straight to the values round.
2. "How does the engineering manager role change as these squads grow?" Why: shows you think about altitude.
3. "What failure do you see most often in managers here, and what is done about it?" Why: candour from the top.
4. "What would you need to see in the first six months to call this hire a good one?" Why: surfaces the VP's bar.
5. "Which of the company's values is hardest to live by in device management?" Why: a values question asked of the values owner.

## Requirement coverage

| Requirement | Questions |
|---|---|
| Lead two squads building device-management services | H2, H5, H6 |
| Own delivery for 11 engineers | H9, P1, P2, V1 |
| Own hiring | H8, P4 |
| Grow engineers | V3 (F4 has no quote, so the answer is the honest branch) |
| Partner with hardware and product on the roadmap | H3, H7, P5, P6, P7 |
| Recruiter's "values and leadership philosophy" | V1, V2, V3, V4 |
| Location or on-site pattern (G1) | none, and why: the material cannot settle a gate; it is for the posting or the recruiter |

## Sources

- **Provided documents:** your message (role paragraph, round details, background). No CV. No full posting.
- **Searches sent, both refused by the host:**
  - "Larkfield Systems industrial IoT company values": refused
  - "Larkfield Systems interview process engineering manager": refused
- **Research tier:** L1. Searches attempted 2 of 6, none returned results; fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Values cheat sheet dropped, since no published values are in hand. Round 3 themes come from the recruiter's words. |
| 2. Interview process | unavailable | Loop is established by your message and the recruiter's words, so no archetype fallback was used. |
| 3. Strategy and recent news | unavailable | CO question V8 stays generic. |
| 4. Interviewer footprint | n/a | No interviewer names were given. |
| 5. Representative JD | skipped | The role paragraph you pasted fixes the requirement list. A full posting would sharpen it. |

Values-style round detected: yes, from the recruiter's words naming "values and leadership philosophy" for round 3. Loop established by your and the recruiter's words.

## Upgrade menu

- **Full posting text:** rows F1 to F6 move from role-paragraph quotes to the posting's own wording, and mid-list requirements get their own questions.
- **Your CV:** the medium-confidence rows get an artifact check, the figures in H8, P2 and V6 get your exact wording, and EXP questions appear for roles you list.
- **Larkfield's published values:** the values cheat sheet for round 3, with V1 to V4 mapped to your stories.
- **Recruiter's prep email:** confirms the panel format and whether round 3 is scored, and settles G1.
- **Whether the two squads have their own leads:** decides whether managing managers becomes a stated requirement, which adds a Skeptic question.
- **Interviewer names:** assigns personas per panel member, adds an interviewer read, and personalises the reverse questions.
- **Web search permission:** research at L1 for values, loop and strategy. That would replace the generic rows in V2, V8 and the coverage table with sourced ones.
