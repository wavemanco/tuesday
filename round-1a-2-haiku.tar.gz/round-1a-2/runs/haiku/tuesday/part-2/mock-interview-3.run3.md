I couldn't run the Stripe research: the web search was refused permission, so the pack has no company values, interview-loop structure or strategy in it. I'm building it from your request alone and labeling everything generic.
Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-3-denied-7eaf7ad3/efff2311-0baf-488a-94e1-f6cbd60384f3/scratchpad/stripe_product-operations-manager_interview_pack.md.

The web search was refused permission, so the pack has no Stripe values, interview-loop structure or current strategy. Everything in it is generic, and the persona weights are flat because I don't know who you're meeting. Once you send the JD and CV, the pack can quote your real experience and drop the generic labels.

I can run a live drill on C3, "how much of the outcome was actually you," which is the probe I'd rehearse first. I can also save a tuesday-dossier.md recording the gaps this prep exposed, and convert the pack to Word if you want it.

Two things would restructure the pack:

1. Who are you meeting in the final, and what is their role relative to yours: hiring manager, peer, or skip-level? Is the final several back-to-back sessions?
2. Can you paste the job description and your CV? If you'd rather proceed without them, say so. If the JD states a location, work-authorization, schedule, pay or travel term, point it out, since the pack will treat those as gates.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe · Product Operations Manager · Final-round prep pack

Role: Product Operations Manager. Company: Stripe. Interviewer: not given. Round: final round, relationship not given.
Build: full-loop pack with flat persona weights, because the relationship and the round format are unknown. Noticeably weaker than a pack built on the relationship; the upgrade menu says how to fix it.
Changelog: first build. No JD, CV, research or interviewer information was available.

## How to use

- Personas describe how a question arrives. Types describe what is being scored.
- Type key: **VAL** behavioral and values, **EXP** your past work under scrutiny, **JD** the listed job, **CO** company and strategy knowledge, **CASE** a live problem.
- Guidance is scaffolding, not a script. Each cell is speakable in about 90 seconds.
- Every row's Provenance says what it rests on. Here that is `[generic]` for everything, because nothing about you, the company or the role has been provided yet.

## Fit snapshot (worksheet variant)

No JD and no CV were provided, so no requirement is quoted and no evidence is on record. The rows below are role-family requirements, written as plain prose and labeled `[generic]`. Each row needs your own evidence, and the bridge column says what strong evidence looks like.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designing and running operating processes across several teams, role-family pattern | none given | none | [generic] | discovery | Strong evidence is one named process you designed or ran, the decision it changed and what moved. Say it in your own words. None is on record here |
| F2 | Measuring whether a process or launch worked, role-family pattern | none given | none | [generic] | discovery | Strong evidence is one metric you defined, its source and its denominator. None is on record here |
| F3 | Driving decisions between product, engineering and go-to-market, role-family pattern | none given | none | [generic] | discovery | Strong evidence is one decision you moved across functions and how you got agreement. None is on record here |
| F4 | Executive-level written and spoken communication, role-family pattern | none given | none | [generic] | discovery | Strong evidence is one summary you wrote for a senior audience and what they did with it. None is on record here |

No gate row exists yet. If the JD states a location, work-authorization, schedule, pay or travel term, it becomes a gate row, and the pack will surface it without trying to bridge it.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live operations problem | Flat weight. A final round usually includes a live problem, but no round format is on record | Clarify, then structure, then name metrics; say the approach aloud |
| Data-Driven Prober | Asks how a number was counted | Flat weight. Probing is common in finals, and no interviewer signal is available | Name the weakest assumption before they do; say plainly when you do not know |
| Pressure / Stress | Interrupts and time-boxes | Flat weight. Unknown; the Pressure persona is the one most often used in finals | Pause, restate, hold a position through two follow-ups, then concede the specific uncertainty |
| Values / Behavioral | Asks for past stories | Flat weight. No values-style round is detected, because no loop source establishes one and the archetype is generic | Tell one story in STAR shape; "we" for context, "I" for your contribution |
| Skeptic | Probes gaps and motivation | Flat weight. Motivation and leaving-reason probes are standard at this stage | One true sentence per motivation question; calibrated candor, no bluffing |
| Conversational | Opens with "walk me through" | Flat weight. Casual questions are still scored | A 90-second arc you have rehearsed |
| Peer Evaluator | Probes seams and disagreement | Flat weight. Relevant if one of the interviewers is a peer | Propose seam principles; give a disagreement story with spine and tact |

## Question banks

Every row is `[generic]`: no quoted sentence about you exists yet, so no guidance may say what you did. Where a question asks about your past, it is an open prompt, and the guidance says so.

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A key metric for a payments product dropped 20 percent week over week. How do you diagnose it?" | CASE | [generic] | Clarify scope and the metric's definition. Check for an instrumentation or data change first. Segment by region, merchant type and payment method. Rank hypotheses by likelihood and name the next metric you would check | Diagnosis is a core product-ops task; the pattern is generic, not a claim about Stripe |
| A2 | "You are setting up a launch-review process for eight teams. Where do you start?" | CASE | [generic] | Clarify the problem the process solves. Map the current flow and its owners. Find the one bottleneck. Pilot with one team and define how you would know it works | Process design under ambiguity, the case a Case interviewer uses most |
| A3 | "A launch is two weeks out and the reviewing team says it is not ready. What do you do?" | CASE | [generic] | Name the decision owner. State the readiness criteria. Separate blocking issues from acceptable risk. Say what you would tell the launch owner today | Tests escalation judgment; asks about no past, so it presupposes nothing about you |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you built a metric or dashboard a team actually used. How was it counted?" | EXP | [generic] | Open prompt. Pick one instance. Give the definition, the source, the denominator and the assumption you would defend least. Answer slot: if you have no such instance, say so plainly and describe how you would define one | Attribution and method are the probe's target; the prompt asks you to choose the instance |
| B2 | "Pick a number you have reported. Which assumption behind it would you defend least?" | EXP | [generic] | Open prompt. Name the assumption before they do. Answer slot: if you have no reported number, say so and name the assumption you would check first | Prober's standard follow-up; hold to what you can repeat under a second question |
| B3 | "How would you measure whether an internal process change worked?" | JD | [generic] | Baseline, then a leading indicator and a lagging one. Say what result would make you call it a failure | F2's requirement, asked as a method; generic because no JD was supplied |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then give one true reason you would stand behind under a follow-up. Hold it through two follow-ups; concede a specific uncertainty if asked | Pressure persona's signature opener; motivation is scored, not chatted |
| C2 | "Tell me about a time a process you proposed was rejected by someone senior. How much of it was your call?" | EXP | [generic] | Open prompt. Say what you kept and what you changed. Hold-then-concede: hold the part you still believe, concede the part that failed. Answer slot: if you have no such time, say so and describe how you would handle it | Pressure plus attribution; the answer depends on choosing your own instance |
| C3 | "You have described a lot of coordination. How much of the outcome was actually you?" | EXP | [generic] | Name your part, the others' parts and the limit on your part. Answer in your own words, using only what you did | The attribution probe is the one most likely to carry in a final round. It is also the one you cannot prepare without your own stories |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Open prompt. STAR shape. "We" for context, "I" for what you did. Say how the truth landed. Answer slot: if no such time comes to mind, say so and give the nearest one | Persona stem; no values round is detected, so this is a generic behavioral probe |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Open prompt. Name the metric, the customer and the decision. Answer slot: if you have no such time, say so and describe how you would decide | Persona stem for customer-first framing; generic because no published values are on record |
| D3 | "Tell me about a cross-team process that failed. What did you do in the following week?" | EXP | [generic] | Open prompt. Name the failure in your own words, your action and the result. Do not blame a team. Answer slot: if you have no such instance, say so | Tests recovery and ownership without presupposing a failure in your past |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one real gap. Give a concrete plan to close it. Calibrated candor, no bluffing | Skeptic's standard question; the answer is your own gap, not a generic one |
| E2 | "Which operations tools have you used day to day, and how deeply?" | EXP | [generic] | Open prompt. Name the tools you used and the depth in your own words. Say plainly which you have not used | Checks the claim against the CV; answer only what you used |
| E3 | "Why leave your current role?" | EXP | [generic] | One true sentence, forward-looking. No criticism of the employer | Motivation consistency is scored in finals; the reason is yours to give |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your journey." | EXP | [generic] | A 90-second arc: each role in order, the through-line, and one sentence on why this role. Use only what your CV or your own words state | Casual openers are scored; a rehearsed arc prevents an improvised one |
| F2 | "What are you reading or using to think about operations at scale these days?" | CO | [generic] | Name one or two sources you actually use, and say what you took from them. Do not name a source you have not read | CO question generic because strategy research did not run; a named source must be real |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a map you do not have. Give one disagreement story: what you argued, what you conceded, what was decided | Peer persona; asks for judgment rather than a fact about the company |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Open prompt. Name who did what, including your share. Answer slot: if you have no such instance, say how you would handle it | Credit-sharing probe; the honest answer is an attribution one |

Coverage: 19 questions. No JD was supplied, so there is no requirement-coverage table. A JD would let each stated requirement map to question IDs. CO coverage is one generic question because strategy research did not run.

## Prohibited claims

No quoted sentence about you exists in this conversation, so no inflated-form entry can be built, and the list is empty. The pack will not coach any claim about your experience, tools, scale, results or titles, because none has been stated here. Once your CV or your own sentences are provided, this section will list the stretched wordings it refuses.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the first ninety days look like for this role, and what would success look like by then?" | Shows you think in operating terms, not role-title terms |
| R2 | "Which team's launch or review process is working least well right now, and what do you think is causing it?" | Invites the interviewer's own diagnosis, which tells you what they care about |
| R3 | "When two owners disagree on a launch, how does the decision get escalated?" | Tests whether the process has a decision owner, which the role will depend on |
| R4 | "How is this role's success measured, and who reviews that measure?" | Asks what the role is judged on; the answer shapes your follow-up |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer interviewer; signals you want to contribute, not only to be assessed |

## Sources

- Provided documents: none beyond the request itself
- Searches sent, each refused with a permission error: "Stripe company values principles"; "Stripe interview process product operations manager final round"; "Stripe strategy news 2026"
- Research tier line: Research tier: L1, searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values section, not built; the search was refused |
| 2. Stripe interview process, product operations | unavailable | Loop structure; persona weights stay flat; the search was refused |
| 3. Stripe strategy and recent news | unavailable | CO questions would have been strategy-grounded; the search was refused |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | JD-tagged questions and the fit rows would have rested on a representative posting; no call was sent, because the host refused search |

Persona weights, loop detection and the values-round decision therefore rest on no loop source. The archetype is generic, flat weights, and no values-style round is detected.

## Upgrade menu

- JD text → the four `[generic]` fit rows become `[grounded]`, the JD-tagged questions get raising sources, and the requirement-coverage table can be built
- CV or your own sentences → the fit snapshot quotes your evidence, the question banks get story maps, and the prohibited list is built from your sentences
- Round type and who you are meeting → persona weights stop being flat, and the reverse questions can tie to the interviewer's path
- The recruiter's note on the final's format or focus areas → the graded-deliverable section, if one was announced
- Search access, once granted → values, interview-loop structure and current strategy can be researched for Stripe, which would add a values section and strategy-grounded CO questions
