Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-8-denied-692162c2/1b814e0b-704a-4acf-9776-2d4eb27fa4aa/scratchpad/ashgrove_member-experience-lead_interview_pack.md, and I've sent it to you. I built it in loop mode: one shared fit snapshot, then a mini-pack for each of the three rounds. The panel section holds the values cheat sheet, since the recruiter says that round scores against the four values.

The pack rests on your message's summary of your background and the strategy brief. I haven't used any web research, because the JD, values and recruiter's email were all in hand.

The sharpest prep point: the contact centre gap. Your message says you've never worked in one, and the JD asks for end-to-end complaints ownership across branches and the contact centre. That will come up in the screen, the behavioural round and the panel. Rehearse the plain line, "I haven't worked in a contact centre," then the branch log you did handle, then a first-month plan said as a plan. Don't stretch "handled the complaints log" into owning the process.

The same applies to presenting above regional level. Say it plainly, then give a preparation plan. Don't invent a presenting history.

Say the word and I'll play the Skeptic on B6, the contact-centre question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste your CV? Every fit row currently rests on your message's summary. A CV would let me quote more of your own wording, and it could raise confidence where the document backs a claim.
How many hours can you give to prep before 28 November? That decides what goes first in a triage section, which I've left out for now.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview pack

**For:** Dara. **Role:** Member Experience Lead (member-owned credit union, about 900 staff). **Mode:** loop, three rounds on 28 November 2026.

| Round | Length | Who | What it scores |
|---|---|---|---|
| 1. Recruiter screen | 30 min | Recruiter | Logistics, motivation, knockouts |
| 2. Behavioural | 45 min | Head of Member Services (your future manager) | Behaviour and capability, mostly behavioural |
| 3. Panel | 60 min, including a 20-minute complaint-escalation case | Two branch managers (not yet named) | The four published values, scored; the case |

Interviewers beyond their roles are not yet assigned, so personas are weighted by round, not by name.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

- **VAL**: behavioural and values alignment, against the published values
- **EXP**: work-experience deep-dive; what you actually did
- **JD**: the role's stated requirements, including the gaps
- **CO**: company and strategy knowledge
- **CASE**: a live problem from the role, worked out aloud

Guidance is scaffolding, not a script. Rehearse what you did, in your own words. Where guidance says "answer slot", the honest answer for either branch is a good answer.

## Fit snapshot (shared across all rounds)

Evidence comes from your message, which summarises your background. No CV was provided. Every quote below is your own sentence or the JD's or the company's own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | Six years, the last three as a branch supervisor: the length is met. Whether branch front-line work counts as customer operations is the interviewer's call, so say the work and let them draw the line. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Your material shows branch scope only. Words: "For the branch, I handled the formal complaints log." Limit, plainly: "I haven't worked in a contact centre." Answer slot: if you owned any part of a complaint beyond the branch log (a stage, a decision, a hand-off), say which and how you decided, in your own words; if it stopped at the branch, say so plainly. |
| F3 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | low | [inferred] | transferability | Derivation: the quote is about tellers, and coaching supervisors is a different act, so the bridge does not stretch it. Words: "I trained new tellers on our escalation script." Answer slot: if you ever coached a supervisor on an escalation, say what the case was and what you suggested; if you didn't, say so. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | discovery | Monthly reporting is in the quote. Resolution times are not, and nothing shows whether the spreadsheet counted them. Answer slot: if it recorded how long complaints took to close, say which measure and how it was counted; if it did not, say so and say what you would add first. |
| F5 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | high | [grounded] | capability | A gap you stated; the words come from that negative. "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Do not add presenting history that is not in your material. |
| F6 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The quote reaches reporting in other terms: you built a spreadsheet and someone uses it. Bridge rewords only that: say "spreadsheet", and say "Excel" only if that is what it was. |
| F7 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | "Formal" is in the quote; the rules that made the log regulated (timescales, referrals) are not. Answer slot: if the log tracked timescales, referrals or rules you applied, say which and how; if it did not, say so and say how formal complaints were handled. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Silence, not absence: your material does not show it either way. Answer slot: if you have worked with a digital or systems team on how members do something, say what and what you did; if you have not, say so and say how you would start. |

**Gates.** No requirement in this JD is a gate. "4+ years" is a length of experience, graded on fit, not a term you meet or miss.

## Prohibited claims (shared)

Built from the fit snapshot. These are the claims a candidate reaches for under pressure, and the pack will not coach them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F2 | "For the branch, I handled the formal complaints log." Limit, as the pack's own observation: your material says the branch log, not the process. |
| Coached branch supervisors on escalations | Inflated form of F3 | "I trained new tellers on our escalation script." |
| Reported monthly on resolution times | Inflated form of F4 | The spreadsheet as you built it. Resolution times only if you can say how they were counted. |
| Presented to senior leaders | Stated negative, F5 | "I haven't presented to anyone above regional level." No slot. |
| Handled regulated complaints | Inflated form of F7 | "I handled the branch's formal complaints log." The word "regulated" is the JD's, not yours. |
| Worked in a contact centre | Stated negative, F2 | "I haven't worked in a contact centre." No slot. |

## Grounding brief (strategy, from your summary of the July 2026 brief)

The brief itself was not pasted; these are the points your message gives. It was published in July 2026, so it is under six months old and still current.

| Point | Provenance | What it means in the room |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | [grounded] your message | Self-service is the direction; complaints will meet digital journeys. Use "digital channels", not "online". |
| "consolidate eight branches into five hubs over 2027" | [grounded] your message | Branch managers on the panel may be living this. Say "hub" in their words. Ask the recruiter whether your branch is affected before you mention it. |
| "launch a small-business lending product in Q1 2027" | [grounded] your message | Less direct for complaints; useful for a reverse question on how complaints would change for a new product. |
| "the main competitive pressure is app-only banks" | [grounded] your message | Members compare Ashgrove with an app. Complaint handling and self-service are judged against that comparison. |

## Round 1: Recruiter screen (30 min)

**Persona weights.** The recruiter prior is Conversational with a light Skeptic. Logistics and motivation are the job of this round, and the risk is treating it as unscored.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport (weight 5) | Friendly opener, then logistics: pay, notice, location, reason for leaving | High: the screen's job is logistics and motivation | Pre-scripted 90-second biography; treat every casual question as scored |
| Skeptic, light (weight 2) | Two knockout-style checks: the contact centre and senior presenting | Medium: both JD lines have no supporting quote beyond what you stated | Plain acknowledgment, then the nearest thing you did |

### Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Talk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A 90-second arc using the beats those two quotes state: the years and the supervisor role, then the complaints log, then the teller training. Stop at the quotes. Add no outcome. | The biography is the most casual question and still scored. F1 is the length requirement, and both quotes carry the answer. |
| R2 | "What are your pay expectations for this role?" | JD | [generic] logistics question, no claim about you | Logistics slot: give your own figure, or ask for the band first. Do not give a figure you have not settled. | Pay is a recruiter knockout. The only safe answer is yours, and the pack supplies none. |
| R3 | "What's your notice period?" | JD | [generic] logistics question | Logistics slot: give your actual notice period in your own words. | Notice is a timing knockout. Your figure goes in, not the pack's. |
| R4 | "Which office or hub could you work from, and how often could you get there?" | JD | [generic] logistics question | Logistics slot: name the offices you could work from and the days you could attend, in your own words. If you do not yet know the role's pattern, ask the recruiter for it first. | The JD does not state a location, so the recruiter will ask it directly. |
| R5 | "What's your reason for leaving your current role?" | EXP | [generic] logistics question | Logistics slot: give your actual reason in one sentence, about the move rather than the bank. | Motivation consistency is checked in the screen. A reason you did not give will fail a probe later. |

### Skeptic, light (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R6 | "You haven't worked in a contact centre. What's your answer to that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Plain acknowledgment: "I haven't worked in a contact centre." Then the nearest thing you did: the branch log. A plan for the contact centre is fine, said as a plan. | This is the most predictable objection in the pack. B6 has the deepest rehearsal. |
| R7 | "How comfortable are you presenting to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level or above, say what and to whom; if you have not, say so and say how you would prepare. | F5 is a stated gap. The screen will test whether you can name it without apology. |

**Reverse questions (recruiter)**
- "What's the pay band for this role, so I know where to start?" Why it lands: it asks for the figure the recruiter holds, so you do not have to guess one.
- "Who makes the decision after the 28th, and when?" Why it lands: it shows you read the three rounds as one process.

## Round 2: Head of Member Services (45 min, your future manager)

**Persona weights.** The recruiter says mostly behavioural, and this is your future manager. The relationship prior is Hiring manager (Case and Skeptic), but the round's own stated format is behavioural, so Values/Behavioral leads.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (weight 5) | Scenario probes mapped to the values; STAR-shaped answers | High: the recruiter names this round as mostly behavioural | A story per value where a quote carries one; a scaffold where none does |
| Skeptic (weight 3) | Gaps: contact centre, senior presenting, end-to-end ownership | High: a manager hiring you is derisking those three gaps | Plain acknowledgment, then the plan |
| Pressure (weight 2) | Time-boxed challenge on your record | Medium: the panel is where pressure is most likely, but a manager may still test composure | Hold through two follow-ups; concede exactly |

### Values / Behavioral (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you chose the member's side of a decision." | VAL | [grounded] the published value, quoted: "we decide from the member's side of the counter". No sentence of yours carries a member-side decision. | Selection scaffold: pick a complaint where you chose the outcome because of how it would land for the member. Say what the member needed, what you decided and why. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: handling the branch's formal complaints log. | Members First is the value an interviewer hears first. Your material has no story for it yet, so the honest branch is the rehearsal. |
| B2 | "When have you kept hold of a problem until it was solved?" | VAL | [grounded] "I handled the branch's formal complaints log" | Map: the quote states handling, not solving. Answer slot: if a complaint in the log stayed yours until it closed, say which, what you did at each step, and how it ended. If you passed it on, say where it went and what you did while it was yours. | Own the Fix. "Handled" is what you can say; "solved" has to be shown by the case. |
| B3 | "Tell me about a time a member had to hear something twice." | VAL | [grounded] "trained new tellers on our escalation script" | Scaffold: pick a time a member, or a new teller, had to hear a process explained twice. Nearest thing you carry: you trained new tellers on the escalation script. Say what you taught and how you checked it landed, if you checked. If you did not check, say so. | Plain Words. Teaching is the closest your material comes to explaining something clearly. |
| B4 | "What does 'end to end' mean to you in a complaint?" | JD | [grounded] JD: "Own the member complaints process end to end across branches and the contact centre" | Describe the stages you would own, as a plan, in your own words. Then say which of those stages you have owned now: from your quote, the branch. | F2 is a transferability gap. The answer has to separate the plan from the past. |
| B5 | "A branch supervisor sends you every complaint to decide. How do you coach them?" | CASE | [generic] | Method: find out what they are escalating and why; check the script they are using; coach a decision rule rather than deciding each case; agree when they can hold it themselves; check the next month's figures. Say it as a method. | This is the JD's coaching line, put as a live problem. It asks for method and says nothing about your past. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B6 | "You've never worked in a contact centre. Why would this work?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Plain acknowledgment: "I haven't worked in a contact centre." Then the nearest thing you did: the branch log. Say what that lets you see of a complaint, and what it does not. Then the plan for the first month, said as a plan. Under two follow-ups, return to the log; do not add to it. | Highest-ROI prep in this pack. The gap is in the JD and in your message, so it will come in some form. The rehearsal is the plain line, the limit and the plan. |
| B7 | "You've never presented above regional level. How would you present to our leadership?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan: how you would prepare, who you would test it on, what figures you would bring. Answer slot: if you have presented at regional level, say what and to whom. | F5 is a stated gap. The plan is the answer; a presenting history you do not have would fail the next question. |
| B8 | "What did you enjoy most about supervising a branch, and what would you keep from it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Scaffold: name the part of the work you would keep, in your own words. If it is the complaints work, say what about it. Point to the spreadsheet only as what you built. | Motivation consistency. The spreadsheet is the one piece of your work that already reaches this role's reporting. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B9 | "Your log covers one branch. This role covers branches and a contact centre. Why shouldn't we hire someone who runs both?" | JD | [grounded] "I handled the branch's formal complaints log" | Hold the branch work at its scope: "I handled the branch's formal complaints log." Concede explicitly: "I haven't worked in a contact centre." Do not fold on the branch work, and do not argue the contact centre away. | Pressure scores holding a position you can back, then conceding a gap you have already stated. |
| B10 | "Sixty seconds: why you over someone who has run a contact centre?" | JD | [grounded] "I handled the branch's formal complaints log"; "I haven't worked in a contact centre" (your message, stated negative) | Hold the branch work; concede the contact centre; close with the first-month plan. The sixty seconds is the whole answer. | A persona stem asked of your own record. It tests composure under a time box. |

**Reverse questions (Head of Member Services)**
- "What does a complaint closed well look like to you, in the member's words?" Why it lands: it asks for the member's test, which is the value at the centre of the round.
- "As branches move into hubs, which complaints will still come to a branch?" Why it lands: it shows you have read the strategy and asks about the seam without guessing at it.
- "What would you want the monthly complaints report to show that it does not show now?" Why it lands: it names a report you built and asks about the part you have not done.

## Round 3: Panel of two branch managers (60 min, including the 20-minute case)

The recruiter says the panel is the values round and scores against the four values. This section is where the values cheat sheet sits.

**Persona weights.** Two branch managers, peers in the sense that matters here: they price what the hire adds to their branches. Relationship priors: Peer Evaluator with Data-Driven Prober, plus the scored values round and the 20-minute case.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (weight 3) | The four values, scored | High: the recruiter says the panel scores against them | A story per value; scaffold and honest branch where none exists |
| Case / Strategist (weight 2) | The 20-minute complaint-escalation case, and a strategy case | High: the case is in the brief | Clarify, then structure, then method; say the method aloud first |
| Peer Evaluator (weight 2) | Seams between branch, contact centre and digital | Medium to high: two branch managers pricing the hire's effect on their branches | Propose seam principles, not facts about the seam |
| Data-Driven Prober (weight 2) | The monthly figures and the regulated log | Medium: the spreadsheet is on your background line | Name the weakest assumption before they do |

### Values cheat sheet (the four published values, as scored by the panel)

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No sentence of yours carries a member-side decision. Scaffold: see B1. Nearest thing you carry: handling the branch's formal complaints log. If no story comes to mind, say so plainly. |
| Plain Words | If a member needs it explained twice, the wording was wrong | Quote: "trained new tellers on our escalation script". Scaffold: see B3 and P9. |
| Neighbours, Not Numbers | Every branch is part of its town | No sentence of yours carries a town story. Scaffold: see P1. Be ready for this one: your spreadsheet is numbers, so say what it counts and what it does not. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Quote: "I handled the branch's formal complaints log": handled, not solved. Scaffold: see B2 and P8, which carry the honest branch. |

### Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Tell me about a time the numbers and the town told you different things." | VAL | [grounded] the published value, quoted: "every branch is part of its town" | Selection scaffold: pick a time a count and a local picture disagreed; say what each showed and what you did with the difference. If none comes to mind, say so plainly, then give the nearest thing your material carries: the monthly spreadsheet, described by what it counts and what it does not. | Neighbours, Not Numbers is the value your spreadsheet sits against, so expect this one. |
| P8 | "How do you know a complaint is fixed, not just closed?" | VAL | [grounded] "I handled the branch's formal complaints log" | Answer slot: if you can say how you checked that a closed case was fixed, say the check. If you closed cases without checking, say so, and say what you would check. | Own the Fix. The quote supports handling, so the answer must show the check, not claim it. |
| P9 | "Tell us about a complaint response you wrote or changed so a member could follow it." | VAL | [grounded] "trained new tellers on our escalation script" | Scaffold: the nearest thing you carry is teaching the script. Say what you taught and what you changed in the wording, if you changed any. If you did not change any wording, say so. | Plain Words is tested with a document as well as a story. Teaching is the honest nearest answer. |

### Case / Strategist (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P2 | "Case, twenty minutes: a member says the branch refused their complaint, and then the contact centre sent them back to the branch. Walk us through it." | CASE | [generic] representative case; the panel's actual case may differ | Method, aloud first: clarify the facts, the member's outcome and which clock applies to a formal complaint. Name one owner today and say who it is. Fix what the member needs now, in plain words, with a date. Then the cause: is this a pattern, and what would the monthly report show? | The case is a live problem from the JD's cross-branch line. It asks for method, so it makes no claim about your past. |
| P3 | "Eight branches are moving into five hubs during 2027. What would you ask first about complaints in that change?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (your message, the brief's summary) | Clarify before structuring. Ask which complaints move with a branch and which with a hub, who holds open cases on the day of a move, and how members are told. Ask for the hub design; do not assume it. | A strategy case from the brief. The panel is branch managers, so the branch and the town are in the room. |

### Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P4 | "Our branches and the contact centre hand complaints to each other. Where's the seam, and what happens when we disagree about who owns a case?" | JD | [grounded] JD: "Own the member complaints process end to end across branches and the contact centre" | Propose seam principles, not facts: one owner per case, a named hand-off time, and a rule for disagreement that the member never sees. Say plainly that you have not worked the contact centre side, then give the principle. | Peers check turf awareness. Principles beat pretending to know their seam. |
| P7 | "We're moving 40% of member service to digital channels by 2028. Where do self-service journeys and complaints meet, in your view?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your message, the brief's summary) | Answer slot: if you have worked with a digital or systems team on a member journey, say what it was; if you have not, say so, and name the first seam you would want to see. | F8 is silent in your material, so the honest answer is a slot. |

### Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P5 | "Walk me through the monthly complaints spreadsheet. Which number would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Weakest-assumption move: name in your own words the number you would defend least, and why. Answer slot: if it counted how long complaints took to close, say how it was counted; if it did not, say so and say what you would add first. Say "spreadsheet" unless you know the tool was Excel. | F4 and F6 meet here: the JD's monthly report and resolution times. Naming the weak number first turns a gotcha into credibility. |
| P6 | "Which formal complaints did your log track against a deadline, and how did you know they were met?" | EXP | [grounded] "I handled the branch's formal complaints log" | Answer slot: if the log tracked deadlines, referrals or rules you applied, say which and how you checked them. If it did not, say so and say how formal complaints were handled. | F7. The question presumes deadlines your material does not state, so the second branch must allow that none were tracked. |

**Reverse questions (panel)**
- "What could a new person do in their first month that would genuinely help your team?" Why it lands: the panel are peers, and this reciprocity question turns the conversation to what you bring.
- "When a case crosses from a branch to the contact centre today, who holds it?" Why it lands: it tests the seam and shows you are already thinking end to end.
- "Which of you reads the monthly complaints numbers most closely, and what do you look for?" Why it lands: it shows you the prober's test before you meet it.
- Hold this one until you know the panel's view of the hubs: "How are the eight branches being chosen for the five hubs?" It can land badly with branch managers whose branches are affected, so ask the recruiter about the panel first.

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | R1, B8 |
| Own the member complaints process end to end across branches and the contact centre | B4, B6, B9, P2, P4 |
| Report monthly on complaint volumes and resolution times | P5 |
| Coach branch supervisors on escalations | B5 |
| Work with digital teams on self-service journeys | P7 (F8 is silent; answer slot) |
| Experience handling regulated complaints | P6 |
| Confident presenting to senior leaders | R7, B7 |
| Comfortable with Excel reporting | P5, F6 (wording slot) |

## Sources

**Provided documents**
- The JD, as pasted in your message.
- The recruiter's email on the process, as quoted in your message.
- The published values, copied from ashgrovecu.org/about/values on 19 November 2026 (read as pasted text, not fetched).
- The July 2026 strategy brief, summarised in your message, not pasted in full.
- Your background, from your message.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2. No search or fetch was sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet, panel section. The values you pasted from the company's page are in hand. |
| 2. Interview process | skipped | Loop structure. The recruiter's email names the three rounds, their length and who holds each one. |
| 3. Strategy and recent news | skipped | Grounding brief and CO questions. The July 2026 brief, under six months old, is summarised in your message. The competitive set and where Ashgrove is losing ground are not in the summary; see the upgrade menu. |
| 4. Interviewer footprint | n/a | No interviewer name was given. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Your CV → every fit row quotes it instead of your message, and confidence can rise where the CV shows the artifact (the spreadsheet itself, a complaint file).
- The full July 2026 strategy brief → the grounding brief and CO questions are checked against its own text, and the competitive set and where Ashgrove is losing ground are added.
- Names of the Head of Member Services and the two branch managers → persona weights per member, an interviewer read, and a reverse question tied to each one's path.
- The complaint-escalation case's real shape, if the recruiter will say → P2 is replaced with the actual case.
- A complaint you held to closure, and how you checked it → B2 and P8 become mapped stories instead of answer slots.
- The complaint rules the branch worked to (the regime or internal standard) → F7, P6 and B9 get named rules instead of answer slots.
- The tool the spreadsheet was built in → F6 and P5 use your words for it.
- Prep hours before 28 November → a prep triage that puts the few things that matter first.
- Deeper research, offered once: up to 6 more searches and 2 more fetches on the strategy brief, the interview loop reports and recent organisational change. Several more minutes. Say if you want it.
