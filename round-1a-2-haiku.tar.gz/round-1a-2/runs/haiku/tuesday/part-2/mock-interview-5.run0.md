Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-5-denied-0b38699e/4cb58161-39a5-4495-a23e-8caf4f01fdce/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md. It covers the 15-minute POV, the fit against the recruiter's stated focus, and 18 questions weighted to Deepa (case and skeptic) and Ross (numbers and pressure). It has a 4-hour prep schedule, five reverse questions, and a list of what I could not state.

Web search was refused when I tried it, so the pack has no company values, strategy, loop structure or interviewer background. I did not retry. If you grant search permission, I can rerun those checks. The pack also doesn't include the internal market report, since you read it but didn't paste it, so the POV can't yet depart from its shortlist.

The most important prep is the rail gap (question C1). Say "I haven't sold into rail" plainly, then your adjacent evidence, then a ramp plan, and hold through two follow-ups. Ross's questions on the £4M and the 6-to-40 growth need an answer in your own words about how each was counted and which part was yours. The pack doesn't supply a method for either.

Three questions that would sharpen it:
1. Is there a job description? Pasting it lets me map the requirements to your evidence instead of the recruiter's three focus areas.
2. Would you paste the operator-facing parts of the market report, or its headline recommendations? Only if you're comfortable sharing it. The POV needs to depart from its shortlist.
3. Is rail-sector sales experience a stated requirement or a preference? That decides how hard to press the gap.

Want a 20-minute drill on C1 or the POV? Or I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail, second-round panel

Panel on Tuesday: Deepa (VP Partnerships, future manager) and Ross (Commercial Director). 60 minutes. First 15 minutes: a spoken point of view on operator partnerships over 18 months, no slides, landing on what it means for the operators. Then Q&A, with Ross pushing on commercials.

Built without a job description and without any research (see Sources). Every candidate sentence below is quoted from your message. Guidance is scaffolding for a spoken answer, not a script.

## 1. How to use, and the type key

- Personas describe how a question arrives. Types describe what is being scored.
- **CASE**: live problem from the role. **EXP**: whether what you did survives scrutiny. **JD**: stated responsibility or gap. **CO**: company and strategy knowledge. **VAL**: values (none detected here).
- Answer slots are instructions for the interview. They ask for nothing back here.

## 2. Prep triage (about 4 hours)

1. **70 min: build and time the POV.** Pick one thesis from section 5 and its concession. Speak it aloud twice, timed to 15 minutes, ending on the operator outcome.
2. **45 min: defend the two numbers.** Write, in your own words, how the 6-to-40 partners and the £4M were counted, what the £4M is sensitive to, the assumption you would defend least, and which part was yours. Rehearse B1 and B2.
3. **40 min: rail gap.** Rehearse C1 until "I haven't sold into rail" comes out plainly, then the adjacent evidence, then a ramp plan. Hold through two follow-ups.
4. **30 min: commercials.** Rehearse B3, D1 and D3. Say the quota fact in one sentence, then what you would propose as an operator number, as a plan and not a past.
5. **20 min: reverse questions.** Ask the five in section 10 aloud and cut any you cannot say comfortably.
6. **Remaining time: rest.** Everything else is insurance.

## 3. Fit snapshot

Requirements come from the recruiter's own words, since no job description was supplied. Quotes are verbatim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your material shows partner growth in the ISV channel, not operator partnerships. Words: "At the payments company I was running the ISV channel, and I took it from 6 partners to 40." Answer slot: say which part of that method you would carry to operators, and which you would not. |
| F2 | "Ross will push on commercials" (recruiter email) | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't carried a direct quota. My number was influenced revenue." Then how you would take on an operator number, said as a plan and never as a past. |
| F3 | Rail-sector sales experience (inferred from the company's customer base: train operating companies, per your message; not quoted from the recruiter) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't sold into rail." Then the adjacent evidence at its own scope, and a ramp plan. Never a claim to rail sales. |
| F4 | "what it means for the operators themselves" (recruiter email) | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | medium | [grounded] | presentation | Your material reaches the operator side through planning work. Words: "I know the operator world from the other side." Limit, as the pack's observation: the material shows bus and light rail planning, not operator buying or rail commercial decisions. |

Rows F1 and F4 carry the most weight in the POV. Row F3's gap is the one most likely to be probed.

## 4. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I've sold into rail" or any rail sales history | Negative you stated (F3) | "I haven't sold into rail." No slot |
| "I carried a quota" or "I owned a number" | Negative you stated (F2) | "I haven't carried a direct quota. My number was influenced revenue." No slot |
| "I drove £4M of revenue" | Inflated form of "roughly £4M of influenced revenue" (F1) | Quote the figure as influenced, at its own scope. Ross's probes stay inside that wording |
| "I built the ISV channel" | Inflated form of "running the ISV channel" (F1) | "I was running the ISV channel." |
| "I know how operators buy" | Inflated form of "I know the operator world from the other side" (F4) | Quote at its own scope, with the limit in section 3 |

## 5. Graded deliverable: the 15-minute POV

Recruiter named this deliverable, so it is graded. Build on F1 and F4 only. Everything in the theses is domain reasoning, labelled [generic], and nothing in them is a fact about operators, contracts or timing. Verify any of it before you say it aloud.

**Thesis 1 [generic].** Operators will pay for partnerships that move their own reliability numbers. Sell to those numbers, not to the software.
- Mandatory concession: "I haven't seen how operators make scheduling purchases, so I'd test this with two operator conversations before committing."

**Thesis 2 [generic].** Partnerships should be built around operator change events, when scheduling decisions get reopened, not around the product calendar.
- Mandatory concession: "I don't yet know which operators face change in the next 18 months. That's the first thing I'd check."

**Anti-pick [generic].** Stop chasing every operator. Choose three or four where scheduling pain is largest, and say no to the rest.
- Mandatory concession: "Fewer partners means slower growth in year one. I'd tell you that up front rather than hide it in the plan."

**Differentiation.** The internal market report is a shared source, and the panel will know its shortlist. Do not recite it. Bring one item from it, then one divergence with reasons. This section cannot be finished without the report's text, which is in the upgrade menu.

**Requested close: what it means for operators.** End on one outcome in the operator's own terms. Answer slot: say how you would know it had happened, in your own words, and what you would measure first.

Grounded facts to build on: F1 ("took it from 6 partners to 40") and F4 ("I know the operator world from the other side"). Use them as bridges into the operator view, not as proof that you have already solved it.

## 6. Persona weights

Panel mode: each interviewer is weighted by their role, and the total is 18 questions.

| Persona | Who | How it shows up | Likelihood, with reasoning | Weight | Counter-strategy |
|---|---|---|---|---|---|
| Case / Strategist | Deepa | Live problems on the operator plan | High. She is the future manager and is buying capability for 18 months | 5 | Clarify, then structure, then answer. Say the framework aloud once |
| Skeptic | Deepa | "Why you, given no rail sales" | High. F3 is the gap most likely to surface | 4 | Rehearse C1 until it is plain and not defensive |
| Data-Driven Prober | Ross | Asks how 6-to-40 and £4M were counted | High. Commercial Director and "will push on commercials" | 4 | Defend-the-number slots, in your own words |
| Pressure / Stress | Ross | Time-boxed challenge on quota and numbers | Medium. Likely as a test of composure on F2 | 3 | Hold through two follow-ups, concede specifically |
| Conversational / Rapport | Either | Opening "walk me through the journey" | Medium. Casual openers are still scored | 2 | 90-second arc, quote-bound |

The Values/Behavioral persona is absent. No values round was detected (section 9).

## 7. Question banks

Questions are the interviewer's lines. Guidance rests only on the quotes in the Provenance column.

### Case / Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the 18-month plan for our operator partnerships. What do you need to know first?" | CASE | [generic] | Clarify before structuring: which operators, which contract types, what Kelverton has already committed. Then state an objective, segment operators, and name your first two metrics. Say what you would check first, not what you already know | Live problem from the recruiter's stated 18-month focus. The question presupposes nothing about your past |
| A2 | "What would it mean for an operator, concretely, if we got this right?" | CO | [grounded] "Please land on what it means for the operators themselves." (recruiter email) | Answer in the operator's terms, one outcome, one way you would know. Do not cite the internal report's shortlist as your own view. Depart from it with reasons once the report is in hand (upgrade menu) | The recruiter's own raising line. This is the POV's close, asked again in conversation |
| A3 | "Which operator would you target first, and why not the biggest?" | CASE | [generic] | Name a segment by its scheduling pain, not by size. Answer slot: if you have a view of one operator's pain from your planning work, say what you saw and what you did not see | Tests whether the POV's anti-pick holds under a direct probe |
| A4 | "An operator says the scheduling tool is fine but partnership-led sales won't move their budget. What do you do?" | CASE | [generic] | Ask what would have to be true for the budget to move. Propose a test, a time-boxed one, and say what would make you stop | Objection handling as a live problem. Presupposes nothing about the candidate |
| A5 | "What would you do in your first 90 days?" | JD | [generic] | Listen before acting: two operator conversations, one internal review of the partner tiers, and one number agreed with Deepa. Name what you would not change yet | The most common first-90-days probe. Generic because no job description was supplied |

### Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Say how it was counted in your own words. Answer slot: if you can say the attribution rule, say it; if there was no such rule, or it was not yours, say so plainly and say what you can and cannot stand behind. Name the assumption you would defend least before he does | Defend-the-number slot on the headline figure. This is where a figure gets probed hardest |
| B2 | "How much of the move from 6 partners to 40 was your work, and how much was the market?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Answer slot: say which part was yours to set and which was not. If you cannot separate the two, say so. Do not claim the whole move | Attribution honesty. Coaching a clean split would be invention |
| B3 | "You've never carried a direct quota. How would you be accountable for an operator number here?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Hold: "I haven't carried a direct quota. My number was influenced revenue." Then propose how you would own an operator number, as a plan. Concede plainly that the step is new | Premised on your own stated negative. The second follow-up is where a weak answer folds |
| B4 | "What does an operator's margin look like on a scheduling deal, and how would you price a partnership?" | CASE | [generic] | Ask about the margin structure before naming a price. Say what you would test with one operator. Do not quote a price or margin you have not seen | A commercial live problem. Presupposes nothing about your past |

### Skeptic (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never sold into rail. Why would operators trust you with their commercial problems?" | JD | [grounded] "Never sold into rail specifically" (your message) | **Highest-ROI prep.** Say it first, plainly: "I haven't sold into rail." Then the adjacent evidence at its own scope: "I know the operator world from the other side," and "took it from 6 partners to 40." Name the limit before it is asked for: your planning work is not operator buying. Hold through two follow-ups by returning to the adjacent evidence, not by adding to it. Close with a ramp plan in your own words | This objection will come in some form. A rehearsed non-defensive answer changes the interview. Deepest rehearsal in the pack |
| C2 | "Your background is partner management in payments. What makes you the right person for operators' buying process?" | JD | [grounded] "running the ISV channel," and "I know the operator world from the other side" (your message) | Acknowledge the difference between ISV and operator buyers. Use the operator-side planning work as the bridge, quoted at its own scope. Do not claim you know how operators buy | Tests whether the pivot is honest. The planning-side bridge is the only evidence the material supports |
| C3 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the commercial ownership gap, which you stated in F2, in your own words. Name one more gap of your own. Calibrated candour beats bluffing | A standard skeptic stem. Generic, because no job description was supplied |
| C4 | "Why leave a 40-partner programme for a company of about 600 people?" | EXP | [generic] | Answer slot: give your own reason in your own words. If the reason is not in what you have told me, say so plainly and name what you are looking for | The motivation-consistency probe. The material holds no reason for the move, so the guidance supplies none |

### Pressure / Stress (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should I trust a channel leader with a rail commercial number?" | JD | [grounded] "never carried a direct quota" (your message) | Pause, restate the question, then answer in 60 seconds. Hold the position through two follow-ups: the channel scale is real, the quota is new. Concede the one specific thing you cannot yet show | Pressure persona test on F2 and F3 together. A hold is only what your quotes carry |
| D2 | "Operators are cutting costs. Why would they pay for partnership over a cheaper tool?" | CO | [generic] | Answer slot: say what you would need to see from one operator to believe the partnership pays. Do not assert a cost figure | Probes the POV's Thesis 1. Presupposes nothing about your past |
| D3 | "Give me the number you'd commit to in year one." | JD | [generic] | Ask for the baseline first, or give your own number and say what it rests on. Do not name a figure you have not been given | A pressure question with no baseline. The honest move is to ask for one, not to invent one |

### Conversational / Rapport (either)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting" and "took it from 6 partners to 40" (your message) | 90-second arc: transport planning, then the payments channel, then why operators now. Use only those sentences | Casual openers are scored. The arc is the pre-scripted biography |
| E2 | "What's the most interesting partnership you've built?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Open prompt. Choose one partner from the 6-to-40 growth and say what you did and what you did not do. If the most interesting one is not yours to claim, say so | Open-prompt story map from the one quoted sentence that carries partners |

Total: 18 questions (A1–A5, B1–B4, C1–C4, D1–D3, E1–E2).

**Requirement coverage.** No job description was supplied, so the recruiter's stated focus is the checklist:
- 18-month operator partnership plan: A1, A3, A4, D2
- What it means for the operators: A2, POV section 5
- Commercials, which Ross will push on: B1, B2, B3, B4, D1, D3
- Rail-sector experience (inferred, F3): C1, C2
- Job-description requirements: none supplied, so none mapped. See upgrade menu.

## 8. Reading the interviewers

No public profiles were available: research was refused (section 11). The interviewer read is absent. Persona weights rest on each interviewer's role, not on their career.

## 9. Values cheat sheet: not included

No values round was detected. No loop source documents one, and no fallback archetype was established. The values page was not retrieved.

## 10. Reverse questions

Each has a one-line reason it lands.

1. **To Deepa:** "What did the person who last held this role get right, and what did they wish they'd had from the business?" Lands because it asks what the job needs in practice, which is her own view of the role.
2. **To Deepa:** "How will you know in six months that the operator partnerships are working?" Lands because it asks for her success measure and shows you are already thinking in outcomes.
3. **To Ross:** "Which operator contracts matter most to the commercial plan over the next 18 months?" Lands because it signals that you think in contract terms, not in partner counts.
4. **To Ross:** "Who carries the margin in an operator deal today, and where does partnership change that?" Lands because it asks a commercial question he can answer, and it tests the POV's Thesis 1.
5. **To either:** "What would a strong first 90 days look like to you?" Lands because it turns the 90-day question around and tells them you are prepared to be measured.

## 11. Sources

Provided documents: your message, including the recruiter's email quoted in it. The internal market report was not pasted, so it is not an input.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Queries sent (all refused, so no results were returned):
1. "Kelverton Rail values": refused
2. "Kelverton Rail strategy scheduling software train operators": refused
3. "Deepa VP Partnerships Kelverton Rail": refused
4. "Ross Commercial Director Kelverton Rail": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Values cheat sheet, section 9. No values round was detected, so the cheat sheet would have been omitted in any case |
| 2. `{company} interview process {role family}` | unavailable | No call sent after the first refusals, so this target was not retried. Would have named rounds beyond Tuesday |
| 3. `{company} strategy` / recent news | unavailable | Refused. Would have fed the CO bank (A2, D2) with current priorities. The POV now rests on the internal report, once you paste it |
| 4. `{interviewer name} {company}` | unavailable | Both name queries refused. Would have produced the interviewer read (section 8) and tailored reverse questions |
| 5. representative `{role title}` JD | unavailable | No job description supplied and no call sent after the refusals. Would have fed the JD bank and fit snapshot |

Tuesday dossier: none present.

## 12. Upgrade menu

- **Job description, full text** → the six JD-tagged rows become grounded, and the requirement coverage line maps to real requirements
- **Internal market report, operator sections** → POV section 5 can depart from its shortlist with reasons, and A2 can cite its consensus
- **Interviewer names with a profile or public talks** → persona weights per panellist, and a reverse question tied to their path
- **Permission to run web search** → values, strategy and loop rows become `yes`; rerun is one step
- **Clear answer on whether rail-sector sales experience is a stated requirement or a preference** → F3's status is settled, and C1 is rehearsed against the right weight
