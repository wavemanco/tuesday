Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-8-denied-ceb6bd3c/370b82ee-7292-4910-8330-3b0fdbfb8447/scratchpad/ashgrove_member-experience-lead_interview_pack.md`, and I've attached it. It's built in loop mode: one shared fit snapshot, then a question bank for each of the three rounds, the values cheat sheet for the panel, and an upgrade menu at the end.

The main finding is that your gaps sit on the JD's headline items. You have no contact-centre work, no presenting above regional level, and no digital or self-service work. The pack gives you one plain acknowledgment for each gap rather than a bridge the material doesn't support. Your strongest material is the branch complaints log, and the pack ties the Own the Fix and end-to-end questions to it.

I didn't run any searches. The values and strategy come from what you pasted, and I haven't seen the strategy brief itself, so check the wording against the recruiter's copy. The panel's escalation case is a generic shape until the recruiter says more about its format.

I can run a live drill next: pick a round and a question ID, or I'll start with the Head of Member Services round on B7, the presenting gap.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead, interview prep pack

**Candidate:** Dara. **Role:** Member Experience Lead. **Company:** Ashgrove Credit Union.
**Rounds:** 28 November 2026, three rounds (loop mode). **Prepared:** 19 November 2026.
**Changelog:** first version.

## How to use this pack

- **Personas** are how a question is asked. **Types** are what is being scored:
  - **VAL**: values and behaviour
  - **EXP**: your own experience
  - **JD**: the role's stated requirements
  - **CO**: company and strategy
  - **CASE**: a live problem
- The guidance is scaffolding, not a script. Say it in your own words.
- An **answer slot** is an instruction for the interview: answer from your experience, either branch. It is not a question to me and needs no reply here.
- Every "your message" quote is a sentence you wrote in your message to me. Every "JD" quote is from the job description you pasted.

## Prep triage

You have nine days. Do these in order; everything else is insurance.

1. Build your 90-second arc (A1) from the four sentences of your background, and say it aloud twice a day.
2. Rehearse the two plain acknowledgments (B5 and B7) until you can say them without apologising or over-explaining.
3. Write one complaint story from "I handled the branch's formal complaints log" (B1, C4): what the log held, what you did with a case, and where your part stopped. Then rehearse the escalation case (C5) against a clock.
4. Fill in the logistics slots (A4 to A7) in your own words.
5. Work out exactly what your monthly spreadsheet tracked (C9, C10). Round 2 and the panel both depend on it.

## Fit snapshot (shared across all rounds)

No JD requirement is a gate under the evidence conventions: none names a term, credential or legal bar the candidate must meet. So no gate question is asked.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material shows the branch log, not end-to-end ownership of the process. Say what your part covered, in your own words. Answer slot: if you took a complaint through steps beyond the log, say which steps were yours and how you decided; if you did not, say so and stay with the log. |
| F2 | "and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | transferability | Stated absence. Plain acknowledgment: "I haven't worked in a contact centre." Then: "My complaints work was on the branch's formal complaints log." Do not stretch the branch work into contact-centre work. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | Your material shows a monthly spreadsheet but not what it counted. Answer slot: say which measures it carried, in your own words. If volumes or resolution times were not among them, say so. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | The material does not name the tool, so "Excel" is not established. Answer slot: say what tool the spreadsheet ran in and what you did with it, in your own words. |
| F5 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | The years are covered. Expect a probe on whether branch work counts as customer operations; answer from the branch role you held. |
| F6 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material says formal complaints, not which rules they ran under. Answer slot: say which rules or timelines applied to the log, if any, and what was yours to follow. If none applied, say so. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Plain acknowledgment: "I've never presented to anyone above regional level." Then say how you would prepare for a senior audience, as a plan, never as a past. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material shows no digital or self-service work. Answer slot: say what, if anything, you have done that touches self-service; if nothing, say so and say what you would do first. |
| F9 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | low | [grounded] | transferability | Your material shows training tellers, not coaching supervisors. Answer slot: if you have coached supervisors on escalations, say how. If you have only trained tellers, say so and say how you would approach supervisors. |

Background, for the bank's reference: "6 years in retail banking, the last 3 as a branch supervisor" (your message); "I handled the branch's formal complaints log" (your message); "trained new tellers on our escalation script" (your message); "I built the monthly complaints spreadsheet our regional manager uses" (your message).

## Prohibited claims (shared, built from the fit snapshot)

These are claims the pack will not coach. Each one is a wording the material does not support.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned the complaints process end to end across branches and the contact centre" | Inflated form of F1, and F2 is a stated negative | F1's quote at its own scope. The limit is the pack's observation: your material shows the branch log, not contact-centre work or end-to-end ownership. |
| "I've worked in or run a contact centre" | Stated negative, F2 | Plain acknowledgment: "I haven't worked in a contact centre." |
| "I've presented to senior leaders" | Stated negative, F7 | Plain acknowledgment: "I've never presented to anyone above regional level." |
| "I report monthly on complaint volumes and resolution times" | Inflated form of F3 | "I built the monthly complaints spreadsheet our regional manager uses." C10's slot asks only what it carried. |
| "I built the spreadsheet in Excel" | Inflated form of F4 | "I built the monthly complaints spreadsheet our regional manager uses." The tool is an answer slot (F4). |
| "I coached branch supervisors on escalations" | Inflated form of F9 | "trained new tellers on our escalation script." The supervisor question is an answer slot (F9). |

## Sources and research

**Provided documents:**
- The job description, as pasted in your message.
- Ashgrove's values, as you copied them from ashgrovecu.org/about/values on 19 November 2026. Pasted, not fetched by me.
- The recruiter's process email: three rounds on 28 November, who runs each, and what each holds.
- The July 2026 strategy brief, as you summarised it. I have not seen the brief itself; check the exact wording against the recruiter's copy.
- Your background, from your message.

**Searches sent:** 0. **Fetches sent:** 0.

**Research tier: L1, searches 0 of 6, fetches 0 of 2; user links read 0.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values you pasted today fix the value names and meanings in the cheat sheet. |
| 2. Interview process | skipped | The recruiter's email names the three rounds, who runs each and what each holds. It establishes the loop. |
| 3. Strategy and recent news | skipped | The July 2026 brief, as you summarised it, is under six months old and fixes the strategy content. |
| 4. Interviewer name | n/a | No interviewer named yet. The interviewer read and per-person personas are absent. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

The values-style round is detected because the recruiter's email says the panel "scores against the four values." So the values cheat sheet sits with Round 3.

## Grounding brief

The vocabulary Ashgrove uses in the material you have: member-owned; about 900 staff; members; branches; the contact centre; digital channels; hubs.

The headline numbers from the brief as you summarised it:
- 40% of member service moved to digital channels by 2028.
- Eight branches consolidated into five hubs over 2027.
- A small-business lending product launched in Q1 2027.
- The main competitive pressure is app-only banks.

Speak about these as the brief frames them. I know of no stale framings in the material you gave me.

## Round 1: Recruiter screen, 30 minutes

**Who:** the recruiter. **Prior:** Conversational plus light Skeptic.

| Persona | Weight | Why |
|---|---|---|
| Conversational | 5 questions (A1 to A7) | The recruiter-screen prior. Logistics are asked in a friendly register, and a casual question is still scored. |
| Skeptic | 1 question (A8) | A light challenge on the contact-centre gap. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in the order of your four sentences: the six years, the last three as supervisor, the complaints log, the tellers, the spreadsheet. Stop there. Do not add a result the quotes do not state. | Your arc is the first thing the recruiter hears. F5, F1, F9 and F3 are the evidence it draws on. |
| A2 | "What is drawing you to Ashgrove?" | CO | [grounded] "member-owned, about 900 staff" (JD) | Name one thing about the member-owned model or the branch network that you want to work on, and say why in your own words. If the reason is personal, give the personal reason. | A motivation check. The reason must be yours, not borrowed from the brief. |
| A3 | "The brief has you moving 40% of member service to digital by 2028. Where does a complaint fit in that?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (brief) | Give a view on how complaints change when more service moves digital. Say what you know from your own branch work, and where you would be guessing, say so. | This is the strategy question the brief sets up. F8 is the gap it will probe. |
| A4 | "What are you looking for in pay?" | JD | [generic] logistics slot | Give your own figure, or ask for the band first. Say it in your own words. | A logistics slot. Nothing about pay is in the material, so none is supplied. |
| A5 | "What notice do you owe your current employer?" | JD | [generic] logistics slot | Give your actual notice period. | A logistics slot. The notice period is yours to state. |
| A6 | "Which branches or hubs can you work from?" | JD | [grounded] "eight branches into five hubs over 2027" (brief) | Say where you can work, in your own words. Ask which hub or site this role sits at, because the consolidation may change it. | The location question. The consolidation makes the answer a real question, and it is worth asking the recruiter. |
| A7 | "Why are you looking to move?" | EXP | [generic] logistics slot | Give your reason in your own words. The material does not state one, so this is yours to give. | A logistics slot. Never a reason you did not give. |
| A8 | "You've never worked in a contact centre. Why would that not matter here?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I haven't worked in a contact centre." Then say what you would learn first, as a plan. Do not argue that it does not matter. | The skeptic's obvious probe. It is answered by the plain acknowledgment, not by a claimed adjacency. |

**Reverse questions (Round 1):**
1. "How will the five-hub consolidation change which site this role sits at?" Why it lands: it shows you read the brief and it asks a question the recruiter can answer.
2. "Will the role be measured on complaint volumes, resolution times, or both?" Why it lands: it ties the JD's monthly reporting to how success is judged.
3. "Who is on the panel, and how are the four values scored?" Why it lands: it shows you know the panel scores values and gives you the scoring frame.
4. "Where does the digital self-service work sit, in this role or with a digital team?" Why it lands: it asks about the JD's digital requirement, which the material does not cover.
5. "What does success look like at six months?" Why it lands: it signals you think about outcomes, not just duties.

## Round 2: Head of Member Services, 45 minutes

**Who:** your future manager. **Format:** mostly behavioural. **Prior:** Case and Skeptic, shifted towards Values/Behavioral by the round's format.

| Persona | Weight | Why |
|---|---|---|
| Values/Behavioral | 4 questions (B1 to B4) | The round is mostly behavioural. |
| Skeptic | 3 questions (B5 to B7) | The manager is buying capability and derisking gaps: the contact centre, senior presentation, digital work. |
| Case/Strategist | 1 question (B8) | A live problem from the branch network. |
| Pressure | 2 questions (B9, B10) | Testing composure on your own numbers. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a complaint you followed through the formal log." | EXP, JD | [grounded] "I handled the branch's formal complaints log" (your message) | Tell the story in the log's terms: what the log held, the complaints in it, what you did with one. Answer slot: if you took a complaint beyond the log, to resolution or to another team, say which step was yours and how you decided. If it left your hands, say where it went. | F1 is the evidence for end-to-end ownership, and this is where the manager will test it. |
| B2 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | The published value is Own the Fix. Map the story to the log, as you did in B1. Answer slot: if a complaint left your hands before it was solved, say where it went and why. | The Own the Fix value, asked in the manager's voice. |
| B3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] selection scaffold | Pick a time a rule or target pulled against the member. If none comes to mind, say so plainly, then give the nearest thing your material carries: the branch's formal complaints log (F1). | The Members First value. Your material shows no such decision, so the honest branch matters. |
| B4 | "Walk me through how the escalation script works when a teller can't resolve a complaint." | EXP, VAL | [grounded] "trained new tellers on our escalation script" (your message) | The script is yours to describe. Say what it told tellers to do, and what you taught. Answer slot: if you wrote or changed the script, say so. If you taught it as written, say so. | Your escalation experience, asked as a process question. F9 is the evidence. |
| B5 | "I don't see contact-centre work in your background. How would you handle that in this role?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I haven't worked in a contact centre." The nearest thing you have is the branch's formal complaints log. Then say what you would learn first and from whom, as a plan. | F2 is the gap, and this is the manager's skeptic probe. Hold the acknowledgment; do not build a bridge the material does not support. |
| B6 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Name the weakest part. The material shows no self-service work, so if you name it, say what you would do first. Answer slot: if you have done digital or self-service work, say what it was; if not, say so. | F8 is the gap this probe lands on, and the JD's digital requirement is the strategy's core. |
| B7 | "You've never presented to anyone above regional level. Why would the senior team trust you?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Plain acknowledgment: "I've never presented to anyone above regional level." Then say how you would prepare for a senior audience, as a plan. Do not claim presenting skills. | F7 is the largest gap for this role. A calm, honest answer here is the highest-return rehearsal in this round. |
| B8 | "A member asks why the branch's answer on a fee differs from the contact centre's. How would you approach it?" | CASE | [generic] live problem | Clarify which fee and which records first. Put the member first. Find where the two answers came from. Give one answer, tell both managers, and check the record. No claim about your past. | A live problem drawn from the JD's "across branches and the contact centre". |
| B9 | "Your monthly report shows complaints up in one town. What do you do in your first week?" | CASE, JD | [generic] live problem | Clarify how the count was made before reacting to it. Check the data, look for branch-level causes, and talk to the branch supervisor. Do not claim you have done this before. | Ties the JD's monthly reporting to the strategy's branch consolidation. |
| B10 | "That monthly report: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Hold: "I built the monthly complaints spreadsheet our regional manager uses." Then say what you built and what the regional manager used. Hold through two follow-ups. If you do not know a specific, concede it explicitly. | A pressure probe on your own reporting. F3 and F4 are the evidence, and an honest concession is better than a stretch. |

**Reverse questions (Round 2):**
1. "What complaint pattern are you watching most closely right now?" Why it lands: it shows you want to start from the real problem, not the job description.
2. "How do you want branch supervisors to escalate to this role?" Why it lands: it turns the JD's coaching requirement into a working relationship question.
3. "How far has the hub work got, and where does complaint handling sit in it?" Why it lands: it connects the role to the strategy without quoting the brief at her.
4. "What would make the first six months a success for you?" Why it lands: it asks for the manager's criteria directly.
5. "Which of the four values is hardest to hold in a branch?" Why it lands: it invites the manager to talk about the values from inside the network.

## Round 3: Panel of two branch managers, 60 minutes

**Who:** two branch managers. **Format:** a 20-minute complaint escalation case, plus values scoring. **Prior:** Values/Behavioral plus Case, blended with Peer and Prober, because the branch managers are the operating peers the role serves.

| Persona | Weight | Why |
|---|---|---|
| Values/Behavioral | 4 questions (C1 to C4) | The panel scores against the four values. |
| Case/Strategist | 3 questions (C5 to C7) | The 20-minute escalation case, plus two shorter live problems. |
| Peer Evaluator | 1 question (C8) | Branch managers judge whether the hire adds to or removes load from their branches. |
| Data-Driven Prober | 2 questions (C9, C10) | Your monthly report is the figure a prober will test. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] selection scaffold | As B3: pick a time a rule or target pulled against the member. If none comes to mind, say so plainly, then give the nearest thing your material carries (F1). | Members First, scored by the panel. |
| C2 | "Tell me about a time a member needed something explained twice." | VAL | [generic] selection scaffold | Pick a time a member needed something explained twice and what you changed. If none comes to mind, say so, then say how you would check that a letter or script is plain. | Plain Words, asked as a behavioural probe. |
| C3 | "Tell me about a time a branch's local situation changed what a regional number meant." | VAL | [generic] selection scaffold | Pick a time local context changed what a figure meant. If none comes to mind, say so plainly, then say how you would tell the local from the regional. | Neighbours, Not Numbers. Your material shows no such case; the honest branch matters here. |
| C4 | "Tell me about a complaint you kept hold of until it was solved." | VAL, EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Tell it in the log's terms: what the log held and what you did with a complaint you owned. Answer slot: if a complaint left your hands before it was solved, say where it went and why. | Own the Fix. F1 is the evidence, scoped to the log. |
| C5 | "A member has complained twice about the same fee. The branch says it is resolved, the contact centre says it is not, and the member now mentions a regulator. You have twenty minutes. Walk us through it." | CASE, JD | [generic] case shape | Clarify the facts first. Contact the member and keep one owner (Own the Fix). Fix the fee, find the root cause, coach the supervisors, and record it. Time-box it. This is a shape for the case, not the panel's actual case; the recruiter may say more about format. | The JD's regulated-complaints and end-to-end requirements, in a live case. |
| C6 | "The member wants the complaint closed today, and the branch can't close it. What do you tell the member?" | CASE, VAL | [generic] live problem | Say what you can do and by when. Do not promise a date you cannot keep. Use plain words. | Plain Words under pressure. |
| C7 | "A branch supervisor sends you every complaint to decide. What do you do?" | CASE, JD | [grounded] "coach branch supervisors on escalations" (JD) | Coach the decision rule, not the individual cases. Answer slot: if you have coached supervisors on escalations, say how. If you have only trained tellers, say so, and say how you would approach supervisors. | The JD's coaching requirement, with F9 as the only evidence. |
| C8 | "Our branch and contact-centre teams sit side by side. Where's the seam, and what happens when we disagree?" | VAL | [grounded] "across branches and the contact centre" (JD) | Propose seam principles, such as one case with one owner at handoff. Do not claim anything about the panel's current teams or your past handoffs. | The peer probe on turf and disagreement. Reciprocity: what you bring to their branches. |
| C9 | "Walk me through how that spreadsheet's numbers were counted." | EXP, JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: if you can say what the spreadsheet counted and how, say so in your own words. If you cannot, say so plainly. | The defend-the-number probe on your reporting. Holding an honest "I don't know" is better than an explanation you cannot repeat. |
| C10 | "Which figures did your monthly spreadsheet carry?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: name the measures it carried. If volumes were in it and resolution times were not, say so. A truthful limit is better than a stretch. | The JD's monthly reporting requirement, and F3's gap. |

**Reverse questions (Round 3):**
1. "What could someone in this role do in the first month that would help your branches most?" Why it lands: it is the reciprocity question for a peer panel, and it moves the conversation from what you need to what you bring.
2. "Where do branches send complaints to the contact centre most often, and what goes wrong?" Why it lands: it shows you want to fix the seam, not just describe it.
3. "What does a good escalation look like to you, when you see one?" Why it lands: it asks the panel to define the standard you will be measured against.
4. "Which value do branches find hardest to hold to in practice?" Why it lands: it invites an honest answer about Own the Fix or Neighbours, Not Numbers.
5. "How do your branch teams tell whether a complaint was resolved?" Why it lands: it links the panel's view of resolution to the JD's reporting requirement.

## Values cheat sheet (Round 3)

| Value (official name) | Working meaning (paraphrased) | Mapped story, or selection scaffold with its honest branch |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No quote carries a story here. Scaffold: pick a decision where you chose the member's side when a rule or target pulled the other way. If none comes to mind, say so plainly, then give the nearest thing your material carries: the branch's formal complaints log (F1). |
| Plain Words | If a member needs it explained twice, the wording was wrong. | No quote carries plain wording. Scaffold: pick a time a member needed something explained twice and what you changed. If none comes to mind, say so, then say how you would check a letter or script is plain. The escalation script you taught (F9) is the nearest thing your material carries. |
| Neighbours, Not Numbers | Every branch is part of its town. | No quote carries local context. Scaffold: pick a time a branch's local situation changed what a regional figure meant. If none comes to mind, say so and say how you would tell the local from the regional. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F1: "I handled the branch's formal complaints log" (your message). Tell the log story, then the answer slot: if a complaint left your hands before it was solved, say where it went. |

## Requirement coverage

| JD requirement | Questions | JD-tagged question |
|---|---|---|
| Own the member complaints process end to end across branches | B1, B2, C4, C8 | B1 |
| ...and the contact centre | B5, C5, C8 | B5 is the skeptic's form; C5 covers the case |
| Report monthly on complaint volumes and resolution times | B9, B10, C9, C10 | C10 |
| Coach branch supervisors on escalations | B4, C7 | C7 |
| Work with digital teams on self-service journeys | A3, B6 | B6 |
| 4+ years in financial-services customer operations | A1, B1 | A1 |
| Experience handling regulated complaints | B1, C5 | C5 |
| Confident presenting to senior leaders | A3, B7 | B7 |
| Comfortable with Excel reporting | C9, C10 | C9 |

## Upgrade menu

- The interviewers' names: personas per panel member and reverse questions tailored to each person's public career. Your recruiter can share them.
- The recruiter's note on the case format: whether the 20-minute escalation case is written or spoken, and what the panel hands over. This turns C5 from a generic shape into a grounded one.
- Your monthly spreadsheet: bring the file you built and check it yourself. Naming the measures and the tool (F3, F4, C9, C10) moves these from discovery to grounded. The file itself is the inspectable artifact.
- Your notice period and pay expectation: fill in A4 and A5 in your own words. Nothing about either is in the material yet.
- Any digital or self-service work you have done: this would move F8 out of discovery.
- Any coaching of supervisors on escalations: this would move F9 from transferability.
- Any presentation above regional level: this would move F7.
- The recruiter's focus areas for each round: one email, and it can refine the banks.
- Optional deeper research on recent organisational context (leadership changes, how far the hub programme has got): up to six searches and two fetches, several more minutes. Say the word and I will run it.
- A `tuesday-dossier.md` would add verified evidence and any prohibited claims you record, so later packs can use them.

---

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.
