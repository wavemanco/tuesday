Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-2-denied-33ed9f32/cc202dd6-7dea-48a2-af81-11dd0e7745f5/scratchpad/atlas-freight_operations-manager_interview_pack.md`. I built it on a hiring-manager round, since your note didn't say who you're meeting. Web search was refused in this session, so the pack has nothing about Atlas Freight itself: no values, no strategy, no interview format. Those sections are missing, and the role-family material is labelled `[generic]`.

The three things most worth rehearsing:

- **A1, the span question.** "You've managed three supervisors. This role leads twelve across four sites." Your strongest evidence is three supervisors, so the answer is a plain concession plus a concrete first-30-days plan. Don't stretch the span.
- **C1–C2, the 40% mis-pick figure.** Expect "how was it counted?" and "what was the baseline?" Your message doesn't say, so the pack leaves those as answer slots. Figure out the answers before the interview, and don't reconstruct numbers you don't remember.
- **A3 and D3, Power BI.** Say "I haven't used Power BI" and then give a plan for learning it. Don't bluff.

Offers, not pushed:
- I can run a drill on any persona. I'd start with A1, the Skeptic.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- I can convert the pack to a Word document if you want one.

Two questions, since they would change the pack the most:

1. Who are you meeting, and what kind of round is it: hiring manager, recruiter, panel or final? Did the recruiter name focus areas or a take-home?
2. Where are the four sites, and does the role require you on site at all of them, or a particular shift pattern? The posting doesn't say, and it would change the location and schedule questions.

If you can grant web search permission, I can rerun the Atlas Freight research and add the values and strategy sections.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not named. Relationship: not stated. Built on a hiring-manager prior (the role owns four sites and twelve supervisors, so the person most likely interviewing is the manager it reports to). If the round is a recruiter screen or a peer conversation, the persona weights below shift; see the upgrade menu.

## How to use

- Personas describe how a question arrives. Types describe what is being scored: **JD** (the posting's requirements), **EXP** (your past work, and whether it holds up), **CASE** (a live problem from the role), **VAL** (values; none detected here), **CO** (company knowledge; none, because research did not run).
- Guidance is scaffolding, not a script. Rehearse it in your own words, and only the things you actually did.
- Every candidate sentence used below is quoted from your message. Nothing about your history has been added.

## Research status

Web search was refused in this session, so the pack has no company-specific facts. Anything about Atlas Freight itself is absent, and the role-family material is labelled `[generic]`. The values section and the strategy-based questions are missing for that reason.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "a senior shift manager over 3 supervisors" (your message); "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows one shift team and one site's peak plan, not ownership across four sites. Words: "I'm a senior shift manager over 3 supervisors." Answer slot: if you have overseen operations across more than one site, say which and how. If not, say so and describe how you would set up daily control across four. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | low | [inferred] | transferability | Your quote is an accuracy metric on picking. The JD names on-time performance and cost per shipment, and your material does not show you measured either. Words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time or cost per shipment, say what and how it was counted. If not, say so and say what you would measure first. |
| F3 | "lead a team of 12 supervisors" (JD) | "a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Three supervisors is the evidence; twelve is four times the span. Words: "I'm a senior shift manager over 3 supervisors." Answer slot: if you have led more than three managers at any point, say when and how. If not, say that plainly and describe how you would build the span. |
| F4 | "build reporting in Excel/Power BI" (JD), Excel part | "solid Excel" (your message) | low | [inferred] | discovery | Excel skill is stated, but reporting built in Excel is not shown. Answer slot: name a report you built and who used it. If you built none, say so. |
| F5 | "build reporting in Excel/Power BI" (JD), Power BI part | "never used Power BI" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't used Power BI." Then how you would learn it, said as a plan, never as a past. |
| F6 | "5+ years operations leadership required" (JD; length requirement, not a gate) | "7 years in warehouse and distribution ops" (your message) | medium | [grounded] | discovery | Years in operations are shown. Years leading people are not separated from them. Answer slot: how many years you have led people, in your own words. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The credential reaches the requirement. Expect a probe on what you applied it to. Answer slot: say which project, if any, your green belt covered. |

Gate check: no requirement in the JD is a gate under the suite's definition. Location and shift pattern are not stated in the posting; see the upgrade menu.

Gap-type routing: F1, F2, F3 are `transferability` because adjacent work is shown and does not reach the requirement. F4 is `discovery` because the evidence may exist. F5 is `capability` because you stated the absence. F6 is `discovery` because years are shown but not split. F7 is `none` because the quote reaches the requirement.

## Prohibited claims

Inflated forms of your own sentences. Each one is listed because the stretched wording is easy to reach for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Runs terminal operations across four sites | Inflated form of F1 | "a senior shift manager over 3 supervisors." The limit is the pack's observation: your material shows one shift team, not four sites. |
| Leads twelve supervisors | Inflated form of F3 | "a senior shift manager over 3 supervisors." No claim of larger scope. |
| Improved on-time performance and cost per shipment | Inflated form of F2 | "cut mis-pick rate 40% by redesigning the pick path." Nothing about other metrics. |
| Built Power BI reporting | Negative you stated, F5 | "I haven't used Power BI." No slot. |
| Runs Lean and Six Sigma projects | Inflated form of F7 | "green belt certified." The certificate only. |

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the span and the Power BI gap | High (weight 5). A hiring manager is buying capability and checking the gap between three supervisors and twelve | Rehearse the span question until it is ordinary. Concede the gap plainly, then state the plan |
| Case / Strategist | Live problems on four sites: diagnosis, peak planning, staffing | High (weight 4). The JD is written as a set of operating responsibilities, which invites live problems | Clarify, then structure: objective, segments, metrics, risks. Think aloud |
| Data-Driven Prober | Denominators and attribution on the 40% figure | Medium (weight 4). The 40% is the headline number on your CV, and probers go to headline numbers | Name the weakest assumption before they do. Say plainly what you do not know about how it was counted |
| Pressure | Time-boxed challenges on fit and attribution | Medium (weight 3). Standard for a manager-level final-stage interview | Pause, restate, hold through two follow-ups, then concede the real gap |
| Conversational | A warm opener that is still scored | Lower (weight 2). Likely at the start of any round | Use a 90-second arc drawn from your own sentences |
| Peer Evaluator | Seam questions with the site leads | Lower (weight 2). Relevant if the loop includes peers | Propose seam principles. Do not pretend to know their process |

Depth follows weight: 5 questions for the Skeptic, 4 for Case and Prober, 3 for Pressure, 2 each for Conversational and Peer.

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've managed three supervisors. This role leads twelve across four sites. Why should I believe you can do it?" | JD | [grounded] "a senior shift manager over 3 supervisors" | **Highest-ROI prep in this pack.** Hold: name the three supervisors and what you did with them, in your own words. Hold through two follow-ups by returning to that. Concede: the span is larger than you have run. Then say the first things you would do, as a plan. Answer slot: if you have led more than three managers at any point, say when. If not, say so plainly. | F3 is the gap the JD presses hardest. A rehearsed, non-defensive concession changes the answer more than any other item here. |
| A2 | "Walk me through your first thirty days across four sites." | CASE | [generic] | Structure: learn each site's baseline first, then the supervisors, then the two metrics the JD names. Name what you would not change yet. | Live problem from the first JD clause. No claim about your past. |
| A3 | "Power BI is in the posting. What is your experience with it?" | JD | [grounded] "never used Power BI" | "I haven't used Power BI." Then one concrete plan: how you would learn it and what you would build first. Present the plan as a plan. | F5 is a stated gap. A plain answer beats a bluffed one. |
| A4 | "How many years have you led people, specifically?" | EXP | [grounded] "7 years in warehouse and distribution ops" | Separate years in operations from years leading people, and give your own count. Answer slot: if your leadership years are fewer than five, say so plainly and point to what you did lead. | F6. The JD says 5+ years of leadership, so this will be asked as a count. |
| A5 | "Which of the terminal's metrics have you owned, and how did they look?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The metric you own is mis-pick rate. Say that. Answer slot: if you tracked on-time or cost per shipment, say which and how it was counted. If not, say so and say what you would measure first. | F2. The JD's metrics are not the metric you have. Say so. |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A site's on-time rate dropped eight points last month. Diagnose it." | CASE | [generic] | Clarify the baseline and the period. Segment: carrier, dock, shift, lane. Name the two or three metrics you would check first. State the risk of acting before diagnosing. | The JD's on-time requirement as a live problem. |
| B2 | "Cost per shipment is up six percent across the four sites. Where do you look first?" | CASE | [generic] | Clarify whether the rise is one site or all four. Split cost into labor, overtime and rework. Ask which lever you can move in the first month. | The JD's cost requirement as a live problem. |
| B3 | "Peak arrives in eight weeks and volume is thirty percent over plan. What is your surge plan?" | JD | [grounded] "ran the site's peak-season surge plan two years running" | Tell the two years in your own words, and say what the plan covered. Answer slot: if you set the plan's scope yourself, say which part and how you decided. If the scope was set for you, say so. | F1. Your peak experience is the strongest operating evidence you have. Keep it at the scope you stated. |
| B4 | "Four site leads disagree on staffing levels. What do you do?" | CASE | [generic] | Clarify the decision that has to be made and the deadline. Get the data each lead is using. Decide on one principle, then have the leads agree to it. | Tests judgment across sites, which is the JD's central demand. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the mis-pick rate was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: say how it was counted, in your own words. If you do not know how the denominator was set, say so. Then name the assumption you would defend least. | Headline numbers get probed first. The pack does not supply a counting method. |
| C2 | "What was the baseline, and over what period?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: give the baseline and period as you remember them. If you do not know, say so. Do not reconstruct a figure. | The 40% has no baseline in your message. Do not fill one in. |
| C3 | "Which part of that redesign was yours, and which was the team's?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Keep the scope of your sentence. Say what you designed, what others did, and what you decided. Answer slot: if the redesign was not yours to shape, say so. | Attribution is the probe's real target. |
| C4 | "Your green belt: which project, and what was measured?" | EXP | [grounded] "green belt certified" | Name the certification. Answer slot: if a project ran under it, say which and what it measured. If none did, say so plainly. | F7. Credentials attract a question on application. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who already runs four sites?" | JD | [grounded] "a senior shift manager over 3 supervisors" | Hold: state what you have delivered at its own scope, using the pick-path result and the peak plan. Concede: the scope of four sites is larger than yours. Do not fold on the delivered results. | Hold-then-concede on F1 and F3. |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the share your sentence claims. Concede what was shared, specifically. Answer slot: if the team did parts of it, name them. | Attribution under pressure. |
| D3 | "You haven't built a reporting system. Why would I hire you to build one?" | JD | [grounded] "solid Excel" and "never used Power BI" | Hold Excel as the tool you have used. Concede Power BI plainly. Then the plan. Answer slot: name a report you built in Excel, if you have one. | F4 and F5 together. The honest form is the held position plus the plain concession. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" and "a senior shift manager over 3 supervisors" | A 90-second arc in this order: the seven years, the move to senior shift manager, the pick-path result, the peak plan. Use only those four facts. | A rapport opener is still scored. Keep the arc to your own sentences. |
| E2 | "What are you playing with in Excel these days?" | JD | [grounded] "solid Excel" | Answer slot: name the one Excel task you do most often, and what it produces. | F4. Casual questions about a JD topic are scored. |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Your supervisors and our site leads sit side by side. Where is the seam between you, and what happens when you disagree?" | EXP | [generic] | Propose seam principles, not a map of their processes: who decides what, how disagreements are escalated, and how the data is shared. Select one disagreement you have handled, in your own words. | The peer version of the span question. |
| F2 | "Tell me about a time a supervisor and a peer disagreed about a schedule. How did it end?" | EXP | [generic] | Selection scaffold: pick a time two people had to agree on a schedule. It needs a clear decision and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest one you have. | No quoted sentence carries this. The pack supplies the shape of the answer, not the story. |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, A2, B1, B4, D1 |
| Drive on-time performance and cost-per-shipment down | A5, B1, B2 |
| Lead a team of 12 supervisors | A1, D1, F1 |
| Build reporting in Excel/Power BI | A3, D3, E2 |
| 5+ years operations leadership required | A4 |
| Lean/Six Sigma a plus | C4 |

## Reverse questions

Each has a reason it lands. No interviewer profile exists, so none is tied to the interviewer's own path.

1. "What does success look like in the first six months?" Lands because it shows you are planning around the outcome, not the title.
2. "How is on-time performance measured across the four sites today?" Lands because the answer tells you whether the JD's metric is defined before you have to inherit it.
3. "What reporting do the sites send up now, and in what form?" Lands because it places the Excel and Power BI gap in the actual workflow.
4. "Which site is the hardest to run right now, and why?" Lands because it asks for the real problem and shows you expect one.
5. "How long have the current supervisors been in post?" Lands because it signals you want the team's stability before you change anything.

## Sources

Provided documents: the JD text and your message, both in this conversation.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Two search calls, both refused in this session. Would have moved the values cheat sheet, which is absent because no values were in hand |
| 2. Atlas Freight operations manager interview process | unavailable | Call refused in this session. Would have moved the round structure and persona weights; both rest on the hiring-manager prior |
| 3. Atlas Freight strategy / recent news | unavailable | No call sent. Would have moved the CO bank; the pack has no CO questions |
| 4. Interviewer name | n/a | No name was given |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Search calls sent in this session:
- "Atlas Freight regional logistics company values": refused
- "Atlas Freight operations manager interview process": refused

## Upgrade menu

- The interviewer's name → a tailored reverse question, and persona weights from their public footprint
- The round type and whether it is a recruiter screen, hiring-manager round, panel or final → reweights every bank
- The four sites' locations and the shift pattern → the site and location gate, which the posting does not state
- Atlas Freight's published values or strategy page, pasted → the values cheat sheet and current-strategy questions
- Your on-time and cost-per-shipment figures, if you have them, and how they were counted → F2 moves from `[inferred]` to `[grounded]`, and A5 and C1 become story-mapped
- The mis-pick rate baseline, period and counting method → C1 and C2 move from answer slots to story-mapped answers
- The recruiter's prep email → coverage of any pre-declared deliverable
- A `tuesday-dossier.md` file, if you have one → sharpens the Skeptic bank
