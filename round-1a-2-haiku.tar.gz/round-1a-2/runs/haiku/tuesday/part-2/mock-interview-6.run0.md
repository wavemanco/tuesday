Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-6-denied-690d966e/4e585a6a-c78f-4079-a530-6a49b8ea3dfb/scratchpad/Larkfield_engineering-manager_interview_pack.md. I built it as one loop pack: a shared fit snapshot, then a mini-pack for each round with its own persona weights, 8–9 questions and reverse questions. Web search was refused in this session, so nothing about Larkfield's values, interview loop or strategy is in it. The values cheat sheet is dropped for that reason.

The biggest gap to rehearse is the hardware roadmap. Your role description names it, and you've said you've never owned one. Question A3 is the highest-return prep, and B9 and C6 repeat the same objection in the other rounds, so your answer needs to hold in all three. The second is scale: one team of six against two squads and eleven engineers. Question A1 covers that one.

I can also:
- Play the Skeptic on A3 in a live drill.
- Save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- Convert the pack to Word if you want it.

Two questions so I can tighten the pack:
1. Did the recruiter name a focus area or a deliverable for any round, and how many days of prep do you have?
2. Can you paste the full job posting and your CV? The evidence column currently quotes only your message, and a CV would let the probe questions be checked against your own wording.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems (three rounds)

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, about 600 people)
**Rounds (loop mode, three scheduled rounds):**
- **Round A**, Tuesday 24 Nov, 45 min: Director of Engineering (hiring manager)
- **Round B**, Thursday 26 Nov, 60 min: panel of two staff engineers and a product manager. If the panel is in the US, 26 Nov is Thanksgiving, so confirm the slot is still on.
- **Round C**, Monday 30 Nov, 30 min: VP Engineering, described by the recruiter as "values and leadership philosophy"

Interviewer names are not known, so the personas are assigned by each interviewer's role in the loop.

## How to use + type key

Personas describe how a question arrives. Types describe what it scores.

- **VAL**: behavioral and values. Whether past behavior shows the leadership philosophy the round asks about.
- **EXP**: work-experience deep-dive. Whether your claims survive a close look, and what you did yourself.
- **JD**: role-driven. Whether you can do what the role description lists, including its gaps.
- **CO**: company and strategy knowledge. Not used in this pack, because company research did not run (see Sources).
- **CASE**: a live problem from the role. Structure and reasoning, not a recalled answer.

Guidance is scaffolding, not a script. Say it in your own words, and only the parts you actually did.

## Fit snapshot (shared across all three rounds)

Requirements come from your role description, the only role text in hand. Evidence is quoted verbatim from your message. There is no CV in hand, so every evidence cell cites your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your role description | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says three years as team lead of six. Say it in those terms and stop there. The scale step to two squads and eleven engineers is the gap to name aloud. Answer slot: the two-squad split raises a probe on how work was divided between groups; if you had a say in that split, say how; if you did not, say so plainly. |
| F2 | "own delivery, hiring and growth for 11 engineers" — your role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The quote is delivery work at team scope, not across eleven engineers. Keep the sentence's sequence: the burden dropped after the quarter. The figure is a defend-the-number slot (A4). |
| F3 | "own delivery, hiring and growth for 11 engineers" — your role description | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | The quote reaches hiring in role terms. The count of about 40 is not shown to be interviews you personally ran; that is a probe to expect (A7, B2). |
| F4 | "own delivery, hiring and growth for 11 engineers" — your role description | none given | none | [grounded] | discovery | Your material does not show growth work for engineers. That is this pack's observation, not words for you. Answer slot: if you developed engineers on your team, say how; if no such step was yours, say so plainly and say what you would do in the first quarter. |
| F5 | "partner with hardware and product on roadmap" — your role description (product part) | "pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Your material shows roadmap pressure handled on the software side. It does not show partnering with product on a roadmap. Keep the quote at its own scope. Answer slot: if you set roadmap priorities with product, say how; if the quarter was decided elsewhere, say so. |
| F6 | "partner with hardware and product on roadmap" — your role description (hardware part) | "never owned a hardware-adjacent roadmap" — your message | high | [grounded] | capability | Your own statement, so the stated absence is the words you may use: "I haven't owned a hardware-adjacent roadmap." Then a plan, never a past: what you would ask hardware first. No claim of hardware knowledge. |

Notes on the snapshot:
- The gap types follow the evidence cells. F6 is `capability` because you stated the absence yourself.
- No row is a gate. Your role description names no location, schedule, authorization or credential term, so none is surfaced.
- "I've never managed managers" is not a requirement in your role description, so it is not a row. It is your stated negative and is used in A2 and C5. It is also on the prohibited list.

## Prohibited list

Each entry names its basis and its honest form. No answer, hold, bridge or reverse question in this pack asserts a listed claim.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads, or led several teams | Inflated form of F1 | "3 as a team lead of 6", at its own scope. The pack's observation: your material shows one team of six, not two squads. A1 and B7 stay inside the team. |
| Owned a hardware roadmap, or worked hardware roadmaps | Your stated negative, F6 | "I haven't owned a hardware-adjacent roadmap." Plain acknowledgment. |
| Managed managers | Your stated negative | "I've never managed managers." Plain acknowledgment. |
| Designed or built the hiring process | Inflated form of F3 | "I run our hiring loop for backend roles." The pack's observation: your material does not say you designed the loop, or that the 40 interviews were yours alone. |
| Cut on-call by 60% through your work alone | Inflated form of F2 | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." The sequence is "after", not "because of". How the figure was counted is a slot (A4), not a claim. |

## Persona weights and reasoning

Round A's weights come from the hiring-manager prior: they are buying capability and checking gaps. Round B's come from the panel rule, which blends each member's top two personas. Round C's come from the skip-level prior, plus the recruiter's values theme.

| Round | Persona | Questions | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|---|
| A | Skeptic | 4 (A1 to A4) | Probes the gaps: scale, managers, hardware | Highest. The role description names the hardware gap, and the scale step from one team to two squads is visible in your own message | Name the gap before it is asked. Hold the stated facts. Plan, do not bluff |
| A | Case/Strategist | 2 (A5, A6) | A live problem on the roadmap | High. The role's partnership line makes a live roadmap problem likely | Clarify, then structure, then think aloud |
| A | Prober | 1 (A7) | Checks the one figure you gave for hiring | Moderate. One checkable number in the message | Say what the number counted, or say you do not know |
| A | Pressure | 1 (A8) | A time-boxed challenge on why you | Moderate. A director often tests composure on a scale gap | Pause, restate, hold two follow-ups, concede one specific limit |
| A | Conversational | 1 (A9) | An opener that is still scored | Certain to open the round | Ninety seconds, from your own quoted sentences |
| B | Prober | 3 (B1 to B3) | Staff engineers check the reliability figure and the hiring claim | High. Two staff engineers, and your two quantified claims are the first thing they will check | Name the weakest assumption before they do, or say you don't know how it was counted |
| B | Peer Evaluator | 3 (B4 to B6) | Seam-splitting with hardware and product; credit-sharing | High. Peers price what you add to their work, and the seam is the role's own line | Propose seam principles, not a seam you have not seen; reciprocity |
| B | Case/Strategist | 2 (B7, B8) | Product trade-off and the two-squad split, live | Moderate to high. The PM will test roadmap thinking | Clarify first; state a decision rule |
| B | Skeptic | 1 (B9) | Hardware, asked by the panel | Moderate. Repeats A3's objection on purpose, so the same answer holds in both rounds | Plain acknowledgment, then a ramp plan |
| C | Values/Behavioral | 4 (C1 to C4) | Scored stories on leadership philosophy | Guaranteed. The recruiter named a values and leadership round | Selection scaffolds where your material is thin; say so where it is |
| C | Pressure | 2 (C5, C6) | Managers and hardware, at VP altitude | Moderate. Skip-level composure, and the two stated gaps | Hold the plan, concede the specific limit |
| C | Case/Strategist | 1 (C7) | Reliability versus roadmap, at strategy altitude | Moderate. VP altitude on the trade-off the role owns | Name the decision rule and the cost in business terms |
| C | Conversational | 1 (C8) | A casual question on leadership | Low to moderate. Casual, still scored | Sixty seconds, in your own words |

## Round A: Director of Engineering, hiring manager (45 min)

Nine questions. Weights: Skeptic 4, Case 2, Prober 1, Pressure 1, Conversational 1.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "3 as a team lead of 6" | Start from the quote: three years as team lead of six. The gap to say aloud is scale, one team of six against two squads and eleven engineers. Say what you would do first to learn the second squad's work. Answer slot: if there is a part of the role you already know you would find harder, name it and your plan to close it. | F1 is where the scale gap sits. The question rewards naming the gap before anyone asks about it. |
| A2 | "You haven't led managers before. What would you do the first time one of them underperforms?" | JD | [grounded] "I've never managed managers" | Plain acknowledgment: "I've never managed managers." Then a plan, not a past: the first two weeks, such as asking the manager for their read, looking at what they track, and pairing on one decision. | The question rests on your stated negative. A plan answer beats a bluff. |
| A3 | "You've never owned a hardware-adjacent roadmap. Why should we believe you can partner with hardware on one?" | JD | [grounded] "never owned a hardware-adjacent roadmap"; [grounded] "pushed a reliability quarter through against roadmap pressure" | The hold: "I haven't owned a hardware-adjacent roadmap." Then what carries over, at its own scope: a reliability quarter pushed through against roadmap pressure, on the software side. Hold through two follow-ups by returning to that and to your plan: what you would ask hardware first, about their constraints and their release cadence. Concede specifically: you do not yet know the device-side constraints. Answer slot: if you have worked alongside hardware teams in any capacity, say what you did there; if you have not, say so plainly. | F6 is the one gap the role description names outright. This is the highest-ROI rehearsal in the pack, because this objection will be asked in some form. |
| A4 | "Is the 60% drop something you can defend?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say the figure as the sentence states it: the burden dropped after the quarter. Defend-the-number slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, all in your own words. If you do not know how it was counted, say so. That is an honest answer. | F2 holds the only quantified claim. The pack supplies none of the four defend-the-number answers. |
| A5 | "Two squads, one roadmap, and hardware says the next release needs a quarter that product has not planned for. Walk me through your first thirty days." | CASE | [grounded] "partner with hardware and product on roadmap" | Clarify before structuring: which squad, which commitment, and what hardware's constraint is. Then objective, approach, metrics and risks, thinking aloud. Make no claim about your past. | The role's partnership line, asked as a live problem. |
| A6 | "Device fleet reliability is slipping and a roadmap commitment is due. How do you decide?" | CASE | [generic] | Name the decision criteria, who you would talk to, and what you would measure first. Say what you would need to know before deciding. | A trade-off the reliability work touched, asked as a problem rather than a record. No claim about your past. |
| A7 | "Which assumption behind about 40 interviews would you defend least?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say what the count covers: your interviews, or the loop's total. If you cannot say how many you personally ran, say so. Defend-the-number slots apply: how it was counted, and which part was yours. | F3 is a figure you gave, and a prober checks whether it was yours. |
| A8 | "Sixty seconds: why should this be you, with three years as team lead of six?" | JD | [grounded] "3 as a team lead of 6" | Pause, restate the question in your words, then anchor in the quote. Hold through two follow-ups. Concede one specific limit, that you have not led two squads, without folding on the hiring and reliability record. | Pressure tests composure on the scale gap in F1. |
| A9 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Ninety seconds: nine years of engineering, three leading a team of six, now at a payments company. Close with your reason for this move, in your own words. | The casual opener is scored. The arc is built only from the quote. |

**Reverse questions, Round A**
- "What would success look like for the second squad in six months?" Why it lands: it moves the conversation to the work, and shows you are thinking in squads.
- "Where do hardware and software most often pull against each other on roadmap decisions here?" Why it lands: it names the gap head-on and signals you are ready to learn it.
- "What did the last person in this role do well, and what did they find hardest?" Why it lands: a standard question that gets you the real job.

## Round B: panel, two staff engineers and a product manager (60 min)

Nine questions. Weights: Prober 3, Peer Evaluator 3, Case 2, Skeptic 1. Staff engineers are peers and get Prober and Peer. The product manager gets Case and Peer.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What did the on-call burden look like before the quarter, and after?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say the before and after in the sentence's own terms. Name the assumption behind the 60% before they do, but only if you know it. Otherwise say you do not know how it was counted. Answer slot: which part of the quarter was yours. | A staff engineer will check the reliability figure first. F2 is the only quantified claim. |
| B2 | "How is your hiring loop built, and which part of it do you run?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say which stages you run and which others run, in your words. Answer slot: if you set the loop's structure, say what you set; if it was set before you, say so. | Staff engineers can check the hiring claim by sitting on the loop. F3. |
| B3 | "Which assumption in a two-squad delivery plan would you check first?" | CASE | [generic] | Name the weakest assumption in the plan you would write, and say what evidence would change your mind. | A prober expects a weakest-assumption move on any plan. No claim about your past. |
| B4 | "Our teams sit side by side. Where's the seam between hardware and software on a device, and what happens when we disagree?" | JD | [grounded] "partner with hardware and product on roadmap"; [grounded] "I pushed a reliability quarter through against roadmap pressure" | Propose seam principles, not a seam you have not seen. For disagreement, use only a story your material carries, at its own scope: the reliability quarter against roadmap pressure. If you have no disagreement with a peer team to tell, say so, and describe how you would approach one. | A peer seam question. F5 and F6 sit under it. |
| B5 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Keep "I pushed" as your verb. Name the other teams who carried part of the quarter only if you can. Answer slot: if others did part of the work, name who and what, in your own words; if you cannot say, say so. | A credit-sharing probe, in collegial packaging. |
| B6 | "What would you need from product in your first month to make roadmap trade-offs stick?" | JD | [grounded] "partner with hardware and product on roadmap" | Reciprocity first: what you would bring to product's team. Then what you would need, stated as a plan. | The product manager's test of whether the hire adds to their load or reduces it. |
| B7 | "Walk me through how you would split one roadmap across two squads." | JD | [grounded] "Lead two squads building device-management services" | Clarify first: what is on the roadmap, what is fixed, and what each squad owns. Then structure. Answer slot: if you have split work across two groups before, say how; if not, say so and describe the split you would propose. | The two-squad requirement, F1. |
| B8 | "Product wants the device-management feature in six weeks. Hardware says the fleet needs a firmware fix first. Your call?" | CASE | [generic] | State the decision rule, the data you would need, and who decides. Name the metric before you give the answer. | A product trade-off asked live. No claim about your past. |
| B9 | "I don't see hardware anywhere in your background. How would you handle it in this role?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then a ramp plan, as a plan: the first questions you would ask hardware, and what you would learn before committing to a roadmap. | The panel's sharpest skeptic probe on the requirement. It repeats A3 on purpose, so your answer holds in both rounds. |

**Reverse questions, Round B**
- To the product manager: "What is the last roadmap trade-off product and hardware argued about, and how did it end?" Why it lands: it shows you want the seam in live work, not in a slide.
- To a staff engineer: "What does on-call look like on the device side today?" Why it lands: it tests whether the reliability work carries over, and invites a real answer.
- Reciprocity, because this is a peer round: "What could a new person do in their first month that would genuinely help your team?" Why it lands: it turns the conversation into a partnership and signals you are thinking about their load.

## Round C: VP Engineering, values and leadership philosophy (30 min)

Eight questions. Weights: Values/Behavioral 4, Pressure 2, Case 1, Conversational 1.

This round is a values-style round, detected from the recruiter's own words. No published company values are in hand, so the VAL questions use the recruiter's theme, not named values. Value names are not coached.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | Open prompt. Pick a time you told someone senior something they did not want to hear. It needs a named stake, a moment you did not fold, and a relationship intact at the end. The nearest thing your material carries is the reliability quarter, if the pressure came from leadership. If it did not, or no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it. | A standard values probe. The quote is the nearest story; the honest branch covers the rest. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The story the sentence carries: a team-health choice made against roadmap pressure. Answer slot: if you know what the quarter pushed back, say what it was; if you do not, say so. | VAL theme with one quoted story. |
| C3 | "Tell me about someone you developed who went on to do more than you expected." | VAL | [grounded] "own delivery, hiring and growth for 11 engineers" | Open prompt. Answer slot: pick a person you developed. If none comes to mind, say so plainly, then say how you would build growth for eleven engineers in the first quarter. | F4 is silent in your material. The role's growth line raises the theme, so the answer is a slot, not a story. |
| C4 | "What's a leadership decision you would make differently now?" | VAL | [generic] | Open prompt. Name one decision, the change you would make, and the cost you carry. If you have made no such decision, say so plainly, and name one you are still uncertain about. No slogans. | Tests self-awareness. The answer has to be your own. |
| C5 | "Leading managers is a different job from leading engineers. What's your honest plan for the first time you're wrong about one?" | JD | [grounded] "I've never managed managers" | Plain acknowledgment: "I've never managed managers." Then a plan, as a plan. Hold through two follow-ups: say what you would do in the first week, not what you did. Concede that you will likely make mistakes you cannot predict yet. | The same stated negative as A2, at VP altitude. |
| C6 | "Sixty seconds: why hire someone with no hardware roadmap experience for a role that partners with hardware?" | JD | [grounded] "never owned a hardware-adjacent roadmap"; [grounded] "partner with hardware and product on roadmap" | Hold: "I haven't owned a hardware-adjacent roadmap." Then what you would do first. Concede the specific limit. Do not claim hardware knowledge. | The VP version of A3. |
| C7 | "Reliability or roadmap: which do you protect when they conflict, and what does that cost the business?" | CASE | [grounded] "pushed a reliability quarter through against roadmap pressure" | State the decision rule, then the cost side in business terms. The only story is the quoted quarter. Answer slot: what the quarter pushed back, if your material shows it; if you do not know, say so. | Altitude question at VP level. Reliability against roadmap is the trade-off this role owns. |
| C8 | "What does a good engineering leader do that a good engineer doesn't?" | VAL | [generic] | One answer, in your words, about sixty seconds. Use an example from your quoted sentences only where it fits. No slogans. | The casual register is still scored. This tests the leadership philosophy you state plainly. |

**Reverse questions, Round C**
- "What does leadership here expect from an engineering manager in the first year that the job description does not say?" Why it lands: it shows you read the gap between the paper and the practice.
- "When engineering and the business disagree on a roadmap, how is it usually settled?" Why it lands: it tests altitude and how decisions get made.
- "What would you want the next person in this seat to do differently?" Why it lands: it signals you are thinking about the role's future, not only your own entry.

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Lead two squads building device-management services | A1, A8, B7 |
| Own delivery | A4, B1, C7 |
| Own hiring | A7, B2 |
| Own growth for 11 engineers | C3 (F4 is silent in your material) |
| Partner with hardware on roadmap | A3, A5, B4, B9, C6 |
| Partner with product on roadmap | A5, B6, C7 |

## Sources

- **Provided documents:** the role description and your background in the message. No full job posting, no CV, no published values page, no recruiter email.
- **Searches sent:**
  - "Larkfield Systems values": refused. Web search permission was not granted in this session.
  - "Larkfield Systems interview process engineering manager": refused, for the same reason.
- **Fetches sent:** none.
- **Research tier:** L1, searches 2 of 6, fetches 0 of 2; user links read 0.

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet, not produced: no published values in hand. Both calls refused. Round C's VAL questions use the recruiter's theme instead. |
| 2. Larkfield Systems interview process engineering manager | unavailable | Loop structure. Your account of the three rounds, with who runs each, is a loop source, so the loop is established and no archetype fallback is used. Call refused. |
| 3. Larkfield Systems strategy or recent news | unavailable | Would have fed CO questions. Not attempted after the first two calls were refused. |
| 4. Interviewer name and Larkfield | n/a | No interviewer names were given, so there was no query to form. |
| 5. Representative Engineering Manager job posting | unavailable | Your role description is three lines, not a posting. A representative posting would have added requirement rows labeled [inferred]. No call sent. |

The values-style round is detected from the recruiter's own words, "values and leadership philosophy". Because no published values are in hand, the values cheat sheet is dropped, as the template's condition requires. The grounding brief, the reading-the-interviewer section, the graded deliverables and the delivery coaching are also dropped. No deliverable was named, no interviewer is named, no assessment was given, and no strategy brief is in hand.

## Upgrade menu

- Full job posting text → the requirement quotes become exact posting lines, any requirement the summary left out gets a row, and its questions are added.
- Your CV → the evidence column can quote CV lines, and the prober questions (A7, B1, B2) can be checked against the CV's own wording.
- Larkfield's published values page, pasted → a values cheat sheet for Round C, and the VAL questions mapped to named values.
- The recruiter's note on each round's focus, or any deliverable → per-round focus and any deliverable build section.
- The Director's name and the panel members' names, with public profiles → the interviewer read, per-member persona weights for Round B, and a tailored reverse question for Round A.
- A company strategy brief → CO questions for Rounds A and C, grounded instead of generic. Web search was refused in this session, so this needs search access. A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) is available on your yes.
- Prep time per round → a priority schedule across the three rounds.
