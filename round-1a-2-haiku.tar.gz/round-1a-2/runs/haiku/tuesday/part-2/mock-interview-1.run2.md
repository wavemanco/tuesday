Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-1-denied-54f9d9d3/8eeaf46c-3672-47d9-923f-8df9b48634b4/scratchpad/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It has 19 questions across Dan's likely personas, with a fit snapshot, persona weights, a prohibited-claims list, reverse questions and an upgrade menu.

Research did not run. Three web searches (Northwind values, Northwind interview process, Dan Kovac's public footprint) were refused permission, so the values page, the loop structure and Dan's public background are not in the pack. Everything about Dan comes from your description, and the strategy comes from your research note, which is undated.

The fit gaps that matter most for this round:
- **Partner-motion design** is a "required" line in the posting. Priya's evidence is a partner revenue model used in carrier negotiations, which is adjacent, not the same work.
- **Sales ops and quota-setting** are absent from her material. Dan, as a sales-strategy peer, is likely to probe target-setting. Her material shows "volume targets with cross-org consensus," so the pack keeps that wording and never calls it quota work.
- **The ~$400M ARR uplift** is credited to a proposal. Expect attribution and assumption probes; the pack gives her an honest "how much was mine" branch rather than a stronger claim.

I took one reading to finish the pack: a peer round with a data-driven, pricing-background interviewer, so Prober and Peer carry the most weight. No values sheet is included because no values-style round was detected.

Offers:
- **Drill:** I can run a live rehearsal of D1, the highest-ROI prep, where Dan asks about target-setting and follows up twice.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for carrying into later sessions.
- **Word:** I can convert the pack to a Word document when you're ready.

One question: does the role have an office or travel requirement, and does Priya need work sponsorship? The highlights you sent don't say, and the pack treats both as a hard gate until you answer.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products

**Company:** Northwind Data
**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy. Peer: both report to the same VP. Pronouns not stated, so this pack uses "they."
**Round:** One 60-minute conversation
**Version:** First pack. No changelog.

---

## 1. How to use this pack

- **Personas** describe how a question arrives: the register, the pace, what the interviewer is listening for.
- **Types** describe what is being scored:
  - **EXP**: work-experience deep-dive. Do the claims in the material survive scrutiny?
  - **JD**: a stated requirement from the posting. Can you do the listed job, gaps included?
  - **CO**: company and strategy knowledge, from your research note.
  - **CASE**: a live problem from the role, with no claim about your past.
- No VAL type is used. No values-style round was detected, so there is no values cheat sheet.
- Guidance is scaffolding, not a script. Say it in your own words.
- **Answer slots** are instructions for the interview. They are not questions for this conversation. Where the material does not show something, the pack says so and does not supply the answer.
- **Sources:** "your message" means what you sent me. Everything the pack says about Priya's past comes from a quoted sentence in that message.

---

## 2. Fit snapshot

Requirements are quoted from your JD highlights where they appear there. Evidence is quoted from your message. Gap type follows the routing rule: the evidence cell decides it, not the writer's sense of the row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights, your message) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | medium | [grounded] | transferability | Your material shows a product change with a credited uplift. It does not show go-to-market ownership. Words: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: if you set any part of how a launch was taken to market, say which decisions were yours, in your own words. If none were, say so and stay with the change you proposed. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights, your message) | none given | none | [grounded] | discovery | Your material does not show whitespace work across the customer lifecycle. Answer slot: if you have looked for unclaimed revenue across any stage of a customer's lifecycle, say what you looked at and what came of it. If you have not, say so and say how you would start. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights, your message) | "skilled in SQL/Tableau" (your message) | low | [inferred] | discovery | A skill claim with no analysis behind it is a lead, not evidence. The bridge derives from the tools in your message and the task in the posting. Answer slot: name one analysis you ran in SQL or Tableau from start to finish, what it was for and what came of it. If you have none, say so and say which one you would build first. |
| F4 | "partner-motion design experience required" (JD highlights, your message) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | A revenue model used in negotiations is adjacent to designing a partner motion, not the same work. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you designed any part of how a partner was engaged, paid or run, say which parts and what you decided. If none were yours, say so and stay with the model. |
| F5 | "strong cross-functional influence" (JD highlights, your message) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | presentation | Reword only the quote: "I set annual volume targets with cross-org consensus." It reaches influence in other terms. Add nothing about who was persuaded or how. Answer slot: if you brought the teams to agreement, say what you did. If the consensus came from elsewhere, say so. |
| F6 | "AI experience a plus" (JD highlights, your message) | "uses AI tools daily" (your message) | medium | [grounded] | transferability | Daily use is adjacent to building AI features. It is a plus item, not the requirement. Words: "I use AI tools daily." Answer slot: if you have scoped, priced or launched a feature that uses AI, say which and what you decided. If not, say so. |
| F7 | "enterprise expansion" (your research note) | "9 at a large consumer-tech company in product strategy & ops" (your message) | medium | [grounded] | transferability | Consumer-tech product strategy is adjacent to business-customer expansion, not a substitute for it. Words: "I spent nine years at a large consumer-tech company in product strategy and ops." Answer slot: if any of your decisions were about business customers, name them. If none were, say so and say what you would learn first. |
| F8 | Sales-ops and quota-setting experience (role-family requirement for a sales-strategy peer, [generic]) | "No classic sales-ops or quota-setting experience." (your message) | none | [generic] | discovery | Your message gives this as a note about Priya, not as her own words, so the pack will not give it back to her as a statement. Answer slot: say whether you have set quotas or worked on sales operations, in your own words. If you have, say what and when. If not, say so plainly. |
| F9 | Office location, travel and work authorization (not in the JD highlights; a gate in most loops, [generic]) | none given | none | [generic] | hard_gate | Your material does not establish these. This row is surfaced, not bridged. The one question in the message presenting this pack asks whether the gate is met. |

**Gap-type calls, in brief:** F1, F4, F6 and F7 are transferability because the quote is adjacent work that does not reach the requirement. F5 is presentation because the quote already reaches influence in other terms. F2, F3 and F8 are discovery because the material is silent or thin. F9 is a hard gate because the material does not establish it. No row is capability, because you have not stated an absence yourself. If you do, that row upgrades (section 15).

---

## 3. Grounding brief

Your research note is the only company material in this pack. It is undated and was not checked by search (see section 13), so treat it as your note, not as current fact.

- **Stated priorities** [grounded]: "enterprise expansion", "an AI copilot launch ('Compass')", "reaching profitability" (your message, research note).
- **Main competitive threat** [grounded]: "bundling by a much larger platform vendor" (your message, research note).
- **Not in the material:** recent moves, financials, leadership changes, the values page and the loop structure. None are asserted here.

---

## 4. Reading the interviewer

Source: your description of Dan's profile. Nothing was checked by search.

- **Self-description** [grounded]: "relentlessly data-driven" (your message).
- **Career pattern** [grounded]: "pricing and monetization roles, with one early-stage-startup chapter" (your message).

**Practical implications**

1. Pricing, packaging and unit economics are Dan's native language. Case questions will tilt there (C1, C3).
2. A data-driven interviewer will probe every number to its assumptions. Expect denominators and method (A1 to A4).
3. A startup chapter means builder stories will land, and a scrappiness probe is plausible. The pack does not assume Priya has a startup chapter.
4. Mirror opportunity, professional domain only: the monetization overlap with F4's sentence. "Built a partner-level revenue model used in carrier negotiations" sits in the pricing domain Dan knows. Mention it once, in F4's words. This is a shared professional domain, not an identity.
5. No shared career jump is offered. Priya's move from consumer-tech to B2B is not Dan's move from pricing to sales strategy, and no row carries both sides of a jump.

---

## 5. Persona table

Relationship prior for a peer round: Peer Evaluator and Data-Driven Prober. Interviewer signals then push the Prober up (data-driven profile) and tilt Case questions toward pricing (pricing spine). The loop is unknown: no loop source was read, and the fallback archetype is Generic, which has no values-style round. Weights are shown so you can recalibrate if you know something the pack does not.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Reads the $400M and "volume targets" lines and asks for denominators and assumptions two levels deep | 5 questions. Top weight: the profile says "relentlessly data-driven," and the headline figures are the first thing a prober goes to | Know what you can say about how each figure was counted. Say plainly when you do not know. Name the weakest assumption before they do. Offer to walk one analysis end to end |
| Peer Evaluator | Seam questions between the two teams, "what would you need from me," credit, disagreement | 4 questions. Co-top prior for a peer round | Reciprocity first: what you bring their team, then what you need. Propose seam principles, not a seam map. One disagreement story with spine and tact |
| Case / Strategist | Live GTM problems for the new lines, tilted to pricing and unit economics; CO on the three priorities and the bundling threat | 3 questions. Mid weight: the JD's GTM line calls for it, and the pricing spine tilts the content | Clarify, objective, segmentation, approach, metrics, risks. Say the pricing assumption aloud before using it |
| Skeptic | The sales-ops and target-setting gap; enterprise; day-one weakness on partner design | 3 questions. Mid weight. The gaps in section 2 are this persona's best material, and the highest-ROI objection sits here | Rehearse the objection until it is boring. Hold through two follow-ups. Concede exactly what you have not done, in your own words |
| Pressure / Stress | Time-boxed "why you," and "how much of that was actually you" on the headline number | 2 questions. Low-mid weight. Interviewers of this kind attach to one big figure, and the $400M line is the one |  Pause, restate, anchor in the quote, hold through two follow-ups, concede specific uncertainty |
| Conversational / Rapport | Open "walk me through the journey" and a casual AI question | 2 questions. Low weight for a peer round, but casual questions about JD plus-items are still scored | Keep the arc to 90 seconds. Treat the AI question as scored |
| Values / Behavioral | Not expected | 0 questions. No values-style round detected; no loop source established one; the Generic archetype reads no. Say so if your recruiter describes a values round | None needed |

---

## 6. Prohibited claims

Built locally from the fit snapshot, because no dossier was provided. Nothing in the banks, the holds or the reverse questions may assert, soften or imply these. Where a claim is listed, the honest form is the quote at its own scope, with the limit stated as the pack's own observation in analysis.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market for the two new lines, or any launch | Inflated form of F1 | F1's quote at its own scope. The material shows a proposal, not go-to-market ownership. A3's slot stays inside the proposal |
| Designed a partner motion | Inflated form of F4 | F4's quote at its own scope. The material shows a revenue model, not a designed motion. D2's slot asks only which parts of partner design were touched |
| Set quotas, or ran sales operations | Inflated form of F5 and F8 | F5's quote with the word "targets" kept. The pack's observation: the material shows targets set with consensus, not quotas. F8's slot asks what was done |
| Drove the ~$400M ARR, or delivered the uplift | Inflated form of F1's quote, whose verb is "credited" | F1's quote. E2's slot asks only what share of the decision was theirs |
| Ran independent SQL or Tableau analysis end to end, as a stated fact | Inflated form of F3's "skilled in SQL/Tableau" | F3's quote at its own scope. F3's slot asks which analysis, if any |
| Designed or launched AI features | Inflated form of F6's "uses AI tools daily" | F6's quote. The limit is use, not building |
| Decisions about business customers | Inflated form of F7's consumer-tech line | F7's quote at its own scope. D3's slot asks what, if anything, was about business customers |
| A first-person negative about sales-ops or quota-setting, stated for Priya | Basis: the note in your message is yours, not her words. No stated negative from her exists | No words supplied. F8's answer slot asks her to say it in her own terms, either branch |

---

## 7. Question banks

Guidance is written to be speakable in 90 to 120 seconds. Provenance lists the candidate sentences each guidance cell rests on. Rationale refers to the fit snapshot by row ID only.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped on the quote: you proposed a store-surface change, and the uplift is credited to it. Those are the beats the sentence states. Tell them in your own words. Answer slot: if you know how the figure was counted, say how. If you do not, say so. Say which part of the change was yours | F1 and the largest figure in the material. The defend-the-number slot is mandatory for a headline figure. EXP because it tests attribution |
| A2 | "Which assumption behind that uplift would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Weakest-assumption move: name, before they do, the assumption you would defend least. Answer slot: if you can name one, name it in your words. If you cannot, say you do not know how the figure was built, and say what you can stand behind, which is the proposal. Keep the word "credited." Do not change it to "delivered" or "drove" | Second follow-up to A1. A named weak point converts a gotcha into a credibility gain. The material names no assumption, so the pack supplies none |
| A3 | "Your partner revenue model: which of its inputs did you take on trust?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on the quote: you built the model, and it was used in carrier negotiations. Name the input you checked least, in your words. Answer slot: if you were in the negotiations, say what you did there. If you were not, say so | F4 is the row it rests on. A prober's likely target, because a model used in negotiations is where assumptions carry money |
| A4 | "Walk me through how a volume target is counted, and what it is a share of." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Quote states the beats: you set annual volume targets, with cross-org consensus. Say them in your words. Call them targets, not quotas. Answer slot: if you know what the target was a share of, say it. If you did not set the base, say so, and say who did, if you know | F5. The prober asks for method, not a number, and the slot asks only the base. The "targets, not quotas" line keeps the honest scope |
| A5 | "Take a new product line with no installed base. How would you find whitespace across land, adopt, expand and renew, and what would you pull first in SQL and Tableau?" | JD / CASE | [generic] | Structure aloud: define the segment and the unit being counted. Name the lifecycle stage each step covers. List the data you would pull first, and the one denominator you would check before trusting the result. Then name one risk. No claim about your past. Say which parts you would run yourself | F2 and F3 have no past to bring, so this is a live problem. JD-tagged because it scores the whitespace and SQL/Tableau requirements. [generic] because it is a method, not a fact |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our two teams sit side by side. Where would you draw the seam between a new product line's go-to-market and the partner team, and what happens when you disagree?" | JD | [grounded] "strong cross-functional influence" (your message, JD highlights) | Seam principles, not a seam map. Propose two or three principles for where ownership splits, and say the seam is theirs to confirm. Answer slot: if you have disagreed with a team you worked beside, say what it was, what you did, and how it ended. If you have not had one, say so and describe how you would handle the first one | The peer's seam probe is how the JD's influence line is scored between equals. The disagreement half is where spine and tact show |
| B2 | "When a model you built goes into a negotiation someone else runs, how do you handle credit?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on the quote. Say what the model is yours for. Say where others' work came in, if it did. Answer slot: if you were part of the negotiations, say what you did in them. If you were not, say so | Credit-sharing is the peer probe. The honest split matches A3, said in collegial terms |
| B3 | "What would you need from my team to make a partner motion work?" | JD | [grounded] "partner-motion design experience required" (your message, JD highlights) | Reciprocity framing: name two or three things you would need from the peer team, and what you would bring to it, in that order. Bring only what you have stated: the model, at its own scope. Answer slot: if you have designed any part of a partner motion, say which part. If not, say so and name what you would learn first | The required partner line is what the peer team cares about most. Reciprocity is the peer's test. F4 is the row this rests on |
| B4 | "Our targets get set in a cross-org review. How do you keep a target honest when another team's number depends on yours?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on the quote: you set annual volume targets with cross-org consensus, and the quote gives the setting, the cadence and the consensus. Answer slot: if you kept a target honest when another team depended on it, say how. If you did not, say so | A peer's worry is the load on their side. The consensus quote is the only record of cross-team targets, and its scope limits the answer |

### C. Case / Strategist (weight 3, pricing tilt)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A new product line has no price yet, and a partner wants exclusive terms. What do you need to know first?" | CASE | [generic] | Structure: clarify the objective, meaning what the new line is for: land, adopt, expand or renew. Then the segment the exclusivity touches, then the price-to-value question, then the approach, the metrics and the risks. Say the pricing assumption aloud before you use it. No claim about your past | A live problem from the GTM line. Pricing and unit economics are Dan's native ground, so this is where the tilt lands |
| C2 | "Northwind is pushing enterprise expansion, an AI copilot launch and reaching profitability at once. For one new product line, which would you sequence first, and what would you give up?" | CO | [grounded] "enterprise expansion", "an AI copilot launch ('Compass')", "reaching profitability" (your message, research note) | Name one priority and one concession. Do not recite all three. Use the note's wording, and present it as the note's view, not as this quarter's fact. No claim about your past | The strategy question is the differentiator. Reciting the three priorities scores as homework, so one thesis with one concession. The note is undated, so the pack does not present it as current |
| C3 | "A much larger platform vendor bundles a similar feature into its suite. What does your new product line do in the first ninety days?" | CO | [grounded] "bundling by a much larger platform vendor" (your message, research note) | Position: name what you would defend (the price, the segment or the integration point) and what you would concede. Say the price move before the packaging move, since pricing is Dan's ground. Name the one metric you would watch first. No claim about your past | The competitive threat from the note is the frame. The question tests altitude without recitation. Type CO, delivered as CASE |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The JD asks you to identify whitespace across land, adopt, expand and renew. How would you set the targets that show a team whether it is covering that whitespace?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (your message, JD highlights); [grounded] "set annual volume targets with cross-org consensus" (your message) | Highest-ROI prep. The objection under this question is that the candidate has not set quotas or run sales ops, which is F8. Hold on what the material carries: the volume targets set with cross-org consensus, at their own scope, as targets. Follow-up 1, likely: "Have you set a quota?" Answer slot: say whether you have set a quota or worked on sales operations, in your own words. If you have, say what and when. If not, say so plainly, then return to the targets you did set. Follow-up 2: "What would your first ninety days look like?" Say what you would measure first. That is a plan, not a past. Concede exactly what you have not done, and never fold on the targets | The objection is aimed at F8, the gap the material shows most plainly, and a peer in sales strategy will ask about target-setting. Deepest rehearsal: two follow-up levels, the quote as the hold, the concession in her own words. The question presupposes a need for targets, not that she set them |
| D2 | "The posting says partner-motion design experience is required. Where would you be weakest on day one?" | JD | [grounded] "partner-motion design experience required" (your message, JD highlights) | Name the weakest part honestly. Partner-motion design is where the material shows least. Answer slot: say which part of partner design you have touched, in your words. If none, say so and name the first thing you would learn. Describe the revenue model at its own scope, and say where it stops. Do not call it partner design | F4's gap. The stem is a skeptic's day-one probe, and the honest answer is a named limit, not a bluff |
| D3 | "I don't see enterprise expansion in your background. How would you handle that here?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" (your message) | Transferability with its limit. Name the product-strategy and ops decisions that were yours, and say what carries over to business customers and what does not. Answer slot: if any of your decisions were about business customers, name them. If none were, say so, and say what you would learn in the first month | F7's gap. The stem is an interviewer's observation of the record, which is allowed as a persona stem; the pack does not add a claim about business customers |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "set annual volume targets with cross-org consensus"; [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, then restate the question in your own words. Answer in the posting's order, each claim at its quote's scope: the partner model (F4), the targets set with consensus (F5), the proposed change (F1). Hold through two follow-ups, returning to those quotes. Concede one specific uncertainty, in your words. Do not add a claim | Pressure stem. It tests composure under a time box, and the quotes are the only ground the answer can stand on |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed a store-surface change, and the uplift is credited to it." Hold through two follow-ups. Concede exactly the share you cannot put a number on, in your words, and keep the attribution you do know. Never fold to "I drove it" | The headline figure's attribution probe. The hold is the quote, not a stronger claim, and the concession is the one that protects the answer |

### F. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | 90-second arc in your words: consulting first, then nine years in product strategy and ops at a consumer-tech company, then the pull toward this role. Answer slot: give your own reason for moving to this role. If you have not settled it, say so, and name what you want to find out in the role | An open opener that is still scored. The arc is the quoted sentence. The reason for the move is not in the material, so it is a slot |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message); [grounded] "AI experience a plus" (your message, JD highlights) | Name the tools you use and the task each one does. Name one task you would still check before trusting the output. Do not describe building or launching AI features; the material shows use only. Answer slot: if you have scoped, priced or launched a feature that uses AI, say which and what you decided. If not, say so | A plus item asked casually. Casual register is scored, and F6's limit applies |

**Coverage check:** Every JD requirement maps to at least one question. See section 8.

---

## 8. Requirement coverage

| Requirement | Question IDs | Note |
|---|---|---|
| own GTM strategy for two new product lines | C1, D1, E1 | F1 gap is covered by C1 (strategy) and D1 (targets) |
| identify whitespace across land/adopt/expand/renew | A5, D1 | F2 gap is covered by A5 (live problem) and D1 (targets) |
| run independent analysis in SQL and Tableau | A5, A3 | F3 gap: A5 is the live test; A3 asks what inputs were checked |
| partner-motion design experience required | A3, B2, B3, D2 | F4 gap is covered at four points |
| strong cross-functional influence | B1, B4, E1 | F5 is presentation, covered by B4 and E1 |
| AI experience a plus | F2 | F6 gap is covered in the casual register |
| enterprise expansion (research note) | C2, D3, reverse R4 | F7 gap is covered by D3 |
| location, travel and work authorization (gate) | none in the question bank. Asked once, in the message presenting this pack | F9 is a hard gate. It is surfaced, not bridged |

---

## 9. Persona coverage

Question totals: A, 5. B, 4. C, 3. D, 3. E, 2. F, 2. Total 19. Within the 18 to 26 session range.

---

## 10. Reverse questions

Five or more, each with why it lands. One ties to the interviewer's path, and one is a peer reciprocity question.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your background runs through pricing and monetization, and you now lead sales strategy. What did that move change about how you decide what a new product should charge and who sells it?" | Ties to Dan's own path. It turns an interview into a peer conversation, and shows the candidate read the profile |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, which a peer weights heavily. It turns the question back toward the team's load |
| R3 | "How do the two new lines' targets get set, and who signs off on them?" | Shows the candidate understands targets are cross-org, and asks about the process that will decide whether D1's answer matters |
| R4 | "Of the three priorities, enterprise expansion, the Compass launch and profitability, which one is most likely to change this role's scope first?" | Uses the research note without reciting it. Asks for the interviewer's altitude, which is what a strategy peer answers best |
| R5 | "Where does pricing sit relative to sales strategy for a new product line: who sets the price, and who lives with it?" | Goes to the interviewer's native ground, and tests whether pricing and sales strategy are separate decisions at Northwind |
| R6 | "If a much larger platform vendor bundled a comparable feature next quarter, what would the team want the new line to do first?" | Uses the competitive threat from the note as a question, and asks for the interviewer's view, not a recital |

---

## 11. Values / principles cheat sheet

Not included. No values-style round was detected, and no values page was read. See section 13.

---

## 12. Delivery coaching

Not included. No working-style assessment was provided.

---

## 13. Sources

- **Provided documents:** your message. It contains the JD highlights, the candidate notes about Priya, your research note on Northwind's priorities and threat, and your description of Dan's profile. No dossier was provided. No links were given to read.
- **Searches attempted:** three. Each was refused permission by the host, so none returned a result.
  - "Northwind Data company values principles": refused
  - "Northwind Data interview process sales strategy": refused
  - "Dan Kovac Director of Sales Strategy Northwind Data": refused

**Research tier: L1, searches 3 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Every call was refused. Would have moved the values sheet, but no values-style round is detected, so the sheet would stay out either way. Would have confirmed or retired the values-theme questions |
| 2. Northwind interview process, peer / sales strategy | unavailable | Every call was refused. Would have moved the loop structure and persona weights. The fallback archetype stands, and the weights are labelled as priors |
| 3. Northwind strategy / recent news | skipped | Your research note supplies the three priorities and the bundling threat, so the inputs fix the CO bank's content. The note is undated, and that caveat is in section 3 |
| 4. Dan Kovac, Northwind | unavailable | The search was refused. Would have moved the interviewer read, the mirror opportunities and the reverse questions. The interviewer read here rests on your description only |
| 5. Representative JD for this title | skipped | Your JD highlights fix the fit snapshot. They are highlights, not the full posting, which is an upgrade-menu item |

---

## 14. Upgrade menu

- **Full JD text** → the fit snapshot rests on six highlights. The full posting would add requirements, and the JD-tagged banks would check against all of them.
- **Your answer to the gate question in the message presenting this pack** → F9 leaves the hard-gate surfacing, or stays surfaced with its answer.
- **Your own words on whether you have set quotas or worked in sales operations** → F8 becomes a statement she made, and D1's answer slot gains a stated branch.
- **How the ~$400M figure was counted, and which part was yours, in your words** → A1 and A2 move from answer slots to grounded claims. This is new material for the fit snapshot.
- **Dan's public footprint, once search is permitted again** → the interviewer read gains published talks and writing, and R1 can name a theme Dan has published.
- **Your recruiter's note on the round format (conversation, panel or case)** → the persona weights can be reset from the loop rather than the fallback archetype.
- **The values page address** → if a values-style round is documented, the values cheat sheet can be added.
- **The date of your research note** → C2 and C3 get a freshness label, or are refreshed.
