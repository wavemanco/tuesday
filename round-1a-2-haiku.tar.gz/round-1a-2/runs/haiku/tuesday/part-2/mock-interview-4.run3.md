Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-4-denied-93a3cb8c/be73349c-b494-49f1-a432-7032170723c4/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. It's built from your dossier for a hiring-manager round. Web search was refused, so the pack has no Quartzline values, interview-loop structure or current strategy, and its company questions are generic.

The highest-ROI prep is B1: "You have never held the PM title or owned a roadmap. Why should we hire you into one?" Structure the answer as name the gap, anchor on the integration work, hold through two follow-ups, then concede specifically on setting priorities across two squads.

Two things to check before Thursday:
- **Shipped API products (R2).** Your dossier doesn't list this requirement as uncertain. The pack reads your integration work as consumer-side (you integrated the vendor's APIs for clients), so expect a probe. Don't say you shipped an API product unless you have.
- **The dossier is three months old.** Confirm the posting still matches its requirements.

I can play the Skeptic on B1 whenever you want to drill it.

I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes. Interviewer name and profile not given.
**Built from:** the pasted `tuesday-dossier.md` (generated 2026-08-14, about three months old, so check the posting still matches its requirements), plus no web research (see Sources).
**Changed since last version:** first version.

## How to use, and the type key

Personas describe how a question arrives. Types describe what is being scored.

- **CASE** live problem from the role, structure and reasoning
- **EXP** your past work, whether it survives scrutiny and what was actually yours
- **JD** a stated responsibility or qualification, including its gaps
- **VAL** published values (none detected for this round)
- **CO** company strategy (none researched; see Sources)

Guidance is scaffolding, not a script. Say it in your own words. Anything quoted in the Provenance column is a sentence from your dossier or your own message; everything else is labelled.

## Fit snapshot

Requirements come from the dossier's `role_profile`, which stands in for the JD. There are no gate rows: the dossier lists no hard gates.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row 1 | low | [inferred] dossier uncertain_or_weak_areas, transferability | transferability | Bridge, with its limit named: adjacent work only. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." Pack observation, not words for you: your material shows integration work, not a product management role. Plain acknowledgment sourced to the dossier prohibited_claims field: "I haven't held a product manager title or role." |
| F2 | "Shipped API or platform products" (dossier role_profile R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row 1 | low | [inferred] pack's reading of dossier row 1 against R2 | transferability | The dossier does not list R2 as uncertain. This pack's reading is that row 1 shows you integrating other people's APIs for clients, not shipping an API product. Expect this probe. Words stay at the quote's scope: you integrated the vendor's APIs for clients. Do not say you shipped one. If you have, say what, in your own words. Tell the underwriter if you think the dossier is right. |
| F3 | "Technical fluency: API docs, schemas" (dossier role_profile R3, important) | "Wrote the internal integration playbook her team uses" — dossier row 2 | none | [inferred] dossier silence on R3 | discovery | The playbook touches the requirement without showing whether it reaches it. Answer slot: say what you have written or read in API docs or schemas. If you have not worked with schemas directly, say so and say how you would learn them first. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row 3 (medium); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row 1 (high) | medium | [grounded] with the caveat named: row 3 is confirmed with limited inspectable proof, so expect a probe | presentation | Lead with row 1: client scoping, requirements and UAT in your own terms. Then row 3, with its limit named: the sessions are confirmed, but there is limited inspectable proof of what reached product. Engineering and sales are not in either quote. Do not add them. |
| F5 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [inferred] dossier uncertain_or_weak_areas, clarify | discovery | Clarify strategy. Answer slot: say how you have run delivery with engineering, and what you would want to confirm about how this team defines agile. If you have not worked in an agile product org, say so. |
| F6 | "Owning a roadmap and prioritization authority" (dossier role_profile R1 sub-claim) | none given | none | [grounded] dossier uncertain_or_weak_areas, acknowledge_gap | capability | Plain acknowledgment sourced to the dossier acknowledge_gap field: "I haven't owned a product roadmap." Then a ramp plan, as a plan and never as a past. No bridge here. |

## Prohibited claims

These are not coached in any cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | Plain acknowledgment: "I haven't held a product manager title or role." No bridge built on it. |
| Having owned a product roadmap | Dossier prohibited_claims and acknowledge_gap | Plain acknowledgment: "I haven't owned a product roadmap." |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | Plain acknowledgment: "I haven't set prioritization for an engineering squad." |
| Shipped an API or platform product | Inflated form of F2 | Row 1 at its own scope. Limit as pack observation only: your material shows integrations for clients, not a product you shipped. No first-person negative. |
| Owned the roadmap input process | Inflated form of dossier row 3 | Row 3 at its own scope: you ran the sessions. The sessions' effect on product is not claimed. |
| Wrote the API documentation or schemas | Inflated form of dossier row 2 | Row 2 at its own scope: you wrote the integration playbook. |

## Persona weights

Relationship prior for a hiring manager: Case/Strategist and Skeptic dominate. The dossier names an objection, which raises the Skeptic. No loop source establishes a loop, and the archetype is generic, so the weights are flat within the two dominant personas and this is said plainly. Single session, so session mode.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Skeptic | Probes the PM-title gap and the roadmap gap | High. The dossier named the objection, and R1 is must-have | Name the gap in one sentence, then the bridge with its limit, then hold | 5 (B) |
| Case/Strategist | Live adoption and alignment problems | High. Hiring managers buy capability on their roadmap | Clarify, objective, segmentation, approach, metrics, risks | 5 (A) |
| Data-Driven Prober | Counts how adoption was measured | Medium. Adoption measurement is a stated responsibility with no baseline | Say what you counted; name the weakest assumption | 3 (C) |
| Pressure | Time-boxed challenges on the headline claims | Medium. A hiring manager may test composure on the thin bridge | Pause, restate, hold through two follow-ups, concede specifically | 3 (D) |
| Conversational | Opening biography, casual questions on API platforms | Lower here. Casual questions still count | Pre-built 90-second arc; treat casual questions as scored | 2 (E) |

## Question banks

Types are one token each. Provenance comes first. A row whose guidance makes no claim about you carries its label alone.

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Partner adoption of an API is lower than the team expected. How would you diagnose it?" | CASE | [generic] | Clarify what adoption means here, then segment partners, then name the metric you would define first. Name the risk of a wrong baseline. Make no claim about past work | Adoption metrics are a stated responsibility with no current baseline, per the dossier's unknowns. Live problem, so no past claim is presupposed |
| A2 | "Two squads disagree on which partner integration ships first. How would you decide?" | CASE | [generic] | Clarify who holds the decision. Say what you would take to the squad leads, and what you would decide alone. Do not claim prioritization authority | The decision-authority question is unverified in the JD, so the answer should name the question rather than assume an answer |
| A3 | "Which roadmap decisions would you make alone, and which would sit with the squad leads?" | JD | [inferred] JD line "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibility) | Answer with the question back, then a proposed split. No claim about having held this authority before | Roadmap ownership is an acknowledge_gap area (F6); this tests it under the role's own terms |
| A4 | "The role aligns engineering, sales and customers. Walk me through a time you kept all three aligned." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row 1 | Story-mapped on F4: scoping, requirements, architecture, UAT and go-live, in your words. Answer slot: if you worked with engineering or sales on those integrations, say how. If not, say so and describe how you handled the client side | R4 is important; row 1 carries the client side only, so the engineering and sales branch is a slot |
| A5 | "How do you run delivery with two engineering squads?" | JD | [inferred] dossier uncertain_or_weak_areas, clarify | Clarify strategy. Answer slot: how you have run delivery with engineering, with a branch that allows you have not worked that way, then what you would confirm about how this team defines agile | R5 has no evidence quote (F5). Clarify, not bridge |

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap. Why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row 1; plain acknowledgment sourced to the dossier prohibited_claims and acknowledge_gap fields | The highest-ROI rehearsal in this pack. Structure: (1) name the gap in one sentence: "I haven't held a product manager title or role." (2) Anchor on row 1 in its own words. (3) Hold through two follow-ups by returning to the adjacent work and its limit. Do not claim the PM years. (4) Concede specifically: "The part I would ramp on is setting priorities across two squads," then your ramp plan | The dossier named this objection. It targets F1, the transferability gap on a must-have. Likely follow-ups: "what is the difference between your work and the PM's," and "what would you do in month one." Rehearse both |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] plain acknowledgment sourced to the dossier acknowledge_gap field (roadmap and prioritization authority) | Name roadmap ownership and prioritization authority as the weakest part, in one sentence. Then the ramp plan. No bridge | F6 is an acknowledge_gap area. The answer is a plain acknowledgment, not a bridge |
| B3 | "Have you shipped an API or platform product?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row 1 | Answer from row 1 at its own scope: you integrated the vendor's APIs for clients. Answer slot: if you have shipped one, say what, in your own words. If you have not, say so plainly | R2 is must-have, and this pack reads it as F2's transferability gap. The second branch allows the honest no |
| B4 | "How do you read an API schema, and what would you check in the docs before a partner sees them?" | JD | [grounded] "Wrote the internal integration playbook her team uses" — dossier row 2 | Answer slot: what the playbook covers, in your words. If you have not worked with schemas or API docs directly, say so and say how you would learn them | R3 is important; row 2 does not show schema work, so the answer is a slot |
| B5 | "Why would you leave where you are for a PM-titled role you have never held?" | EXP | [grounded] plain acknowledgment sourced to the dossier prohibited_claims field: "I haven't held a product manager title or role." | Answer slot: your reason for the move, in your own words. The material gives no motivation statement, so the pack supplies none. Keep it consistent with B1 | Motivation consistency is the Skeptic's test. The pack has no stated reason to offer |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you count adoption of a partner API, and which assumption behind that count would you defend least?" | JD | [generic] | Answer slot: if you have counted adoption before, say how and what it was sensitive to. If not, say so, and name the assumption you would test first | Adoption measurement is a stated responsibility with no baseline, so the honest answer may be that you have not counted it. Make no claim about past metrics |
| C2 | "What does the integration playbook cover, and how do you know your team uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" — dossier row 2 | Story-mapped: you wrote the playbook, and your team uses it. Answer in your own words. Say how you know the use, which is the probe | Row 2 is high-confidence but has an inspectable artifact the interviewer may ask to see. Offer the playbook itself if you can share it |
| C3 | "Describe one roadmap-input session: who came, and what went to product?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row 3 | Story-mapped: you ran the sessions, and they fed client evidence to product. Name the limit: confirmed, with limited inspectable proof of what reached product. Do not claim a decision that product made because of it | Row 3 is medium confidence. The caveat belongs in the answer before the prober finds it |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM with three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row 1 | Pause, then restate the question. Hold on the adjacent work in one sentence. Concede specifically on the PM years and roadmap, then stop. Hold-then-concede: do not fold on the work you did | This is B1 under time pressure. It tests composure, not content |
| D2 | "That integration work: how much of the outcome was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row 1 | Stay with what the quote carries: you led the integrations end to end, from scoping to go-live. Name the parts you led, and name any part you did not carry | Attribution is the probe. The answer stays inside row 1's scope |
| D3 | "You said 30+ integrations. How was that counted, and which of them were yours?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row 1 | Answer slot, per the figure rule: how the count was made, what it is sensitive to, the assumption you would defend least, and which of the integrations were yours to lead. In your own words | The figure raises defend-the-number slots. The pack does not supply a counting method |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] the three verified rows: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (row 1); "Wrote the internal integration playbook her team uses" (row 2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (row 3) | A 90-second arc in this order: the integrations, the playbook, the roadmap-input sessions, then one sentence on the PM gap | Casual questions are scored. The arc should carry the adjacent work, not the title |
| E2 | "What have you been reading or building about API platforms lately?" | CO | [generic] | Answer slot: say what you have read or built, in your own words. If nothing, say so | Casual, scored. The pack has no research on Quartzline's current strategy |

## Coverage

| Requirement | Question IDs |
|---|---|
| R1, 3+ years PM experience | B1, B2, B5, D1, A3 |
| R1 sub-claim, roadmap ownership | B1, B2, A3 |
| R2, shipped API or platform products | B3, D3, C2 |
| R3, API docs and schemas | B4, C2 |
| R4, stakeholder management | A4, D2, E1 |
| R5, agile delivery | A5 |
| Adoption metrics (responsibility, no baseline) | A1, C1 |
| Decision authority (unverified) | A2, A3 |

## Reverse questions

Five, each with why it lands. The first two come from the dossier.

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: it tests the decision-authority claim the JD makes without evidence, and it reads as diligence.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: the baseline is an unknown the dossier flagged, and you need it before accepting.
3. "What would make someone succeed in the first 90 days in this role?" Why it lands: it turns the PM-title gap into a plan you can discuss.
4. "How do the two squads split work today, and where does API platform work sit?" Why it lands: it shows where your bridge would land and lets the manager name the seam.
5. "How does this team set delivery cadence across the squads?" Why it lands: it opens the agile question (R5) from the employer's side rather than defending the gap.

## Prohibited claims: what the list does not cover

The dossier's three prohibited_claims items are the full dossier list. The local list above adds three inflated forms. Nothing here asserts a PM title, roadmap ownership, or squad prioritization.

## Sources

- **Provided document:** the pasted `tuesday-dossier.md`, generated 2026-08-14. Sections consumed: `role_profile` (JD equivalent), `handoff_to_mock_interview` (verified evidence, uncertain areas, objection, risks, employer questions, prohibited claims). `decision` read as context only. No `evidence_map` or `risk_register` were in the pasted file. Dossier row n means the nth item of `verified_candidate_evidence`.
- **Searches attempted, all refused by permission (WebSearch was not granted):**
  - "Quartzline company values", refused
  - "Quartzline interview process product manager platform APIs", refused
  - "Quartzline strategy news 2026", refused
- **Consequence:** no values, loop structure or current strategy is established. The pack uses no values cheat sheet, the loop is not established, and persona weights are a generic prior. CO questions are generic.

**Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Values cheat sheet. Every call refused. A values round would be detected only from a loop source, which was not reached |
| 2. `Quartzline interview process` | unavailable | Loop structure and persona weights. Every call refused; the weights stay a generic prior |
| 3. `Quartzline strategy` / recent news | unavailable | CO bank and any grounding brief. Every call refused. Dossier is about three months old, so recent moves are unknown |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given, so there was no query to form |
| 5. representative JD | skipped | The dossier role_profile fixes the requirements and the JD-tagged questions |

## Upgrade menu

- Quartzline's values and interview loop → a values cheat sheet and loop-based persona weights, if web search is granted. A three-search pass; the values names must come from the official page.
- Deeper research, once, offered and not run: up to 6 more searches and 2 fetches, several minutes. Say so and I will run it if web search is granted.
- The interviewer's name → an interviewer read, a tailored reverse question, and persona weights from their public footprint.
- The current posting text → checks whether the dossier's role_profile still matches the role, three months on. Any changed requirement becomes a new fit-snapshot row.
- The integration playbook itself, if you can share it → raises the inspectable proof behind row 2 and upgrades C2.
- The adoption metric definition from the recruiter or posting → converts C1 from a slot to a premised question.
