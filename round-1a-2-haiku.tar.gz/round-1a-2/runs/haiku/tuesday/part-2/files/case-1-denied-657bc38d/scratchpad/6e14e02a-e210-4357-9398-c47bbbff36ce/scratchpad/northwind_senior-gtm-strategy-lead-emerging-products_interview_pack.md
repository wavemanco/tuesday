# Northwind Data: Senior GTM Strategy Lead, Emerging Products

**Interview:** one 60-minute round with Dan (Director of Sales Strategy), a peer on the same VP's team. First version; no earlier pack to change.

## 2. How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows the value, not generic virtue |
| EXP | Work-experience deep-dive | What was actually yours, and how the numbers were counted |
| JD | Role / JD-driven | Whether she can do the listed job, including its gaps |
| CO | Company and strategy | Whether she thinks at Northwind's altitude |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Guidance is scaffolding, not a script. Answer slots are instructions for the interview: each names the honest branch, including "that was not mine" or "I have not done that." Provenance labels: `[grounded]` traces to your message or research note; `[inferred]` is a derivation; `[generic]` is a role-family pattern. "Your message" means your brief; "JD highlights" means the highlights you wrote; "your research note" means the priorities and threat you gave.

## Prep triage

Prep time was not stated, so no schedule is set. Priority order, regardless of time: (1) Question D2, the quota and sales-ops gap, which is the likeliest objection from a Director of Sales Strategy and has the deepest rehearsal; (2) A1 and A3, the $400M figure's method and confounds; (3) C1 to C4, the Compass and bundling cases. Everything else is insurance.

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | Your material says a revenue model used in carrier negotiations, not a go-to-market strategy for a product line. Keep the claim at that scope. Answer slot: if you set the go-to-market approach for any product, say which decisions were yours, in your own words; if none were, say so and describe the revenue model. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | low | [inferred] | discovery | Your material shows one proposed change and the ARR it is credited with. It does not show whitespace work across land, adopt, expand or renew; that is the pack's observation. Answer slot: if you have located a gap in customer coverage or lifecycle stage, say how you found it; if you have not, say so and say how you would start. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (your message) | medium | [grounded] | presentation | Say the skill in those terms and no more: "I am skilled in SQL and Tableau." The JD asks for independent analysis, so expect a probe on analysis you ran yourself. |
| F4 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | none | No gap: the quote reaches cross-team influence in role terms. Lead with the target and the consensus in the quote's own words. A probe on how the consensus was reached is answered in your own words. |
| F5 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | Partner-facing work at the scope of a revenue model in negotiations. The material does not show designing partner motions. Answer slot: if you designed any partner terms, incentives or channel rules, say which and why; if you did not, say so and describe the model's role in those negotiations. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (your message) | medium | [grounded] | transferability | Say daily use of AI tools, not building AI products or features. The JD makes AI a plus, so this is a depth question, and the material does not show more. |
| F7 | Quota-setting and sales-ops work in a sales-strategy seat ([generic] role-family expectation; not in the JD highlights) | "No classic sales-ops or quota-setting experience" (your message) | high | [grounded] | capability | A stated absence, so the words may be given back: "I haven't run classic sales-ops or quota-setting." Then how you would learn it, said as a plan, never as a past. Do not present the volume-target line in F4 as quota work. |

Rules these rows follow: the quotes are your sentences, not my summaries. Requirements quoted from the JD highlights are your wording of the JD, not the posting's; full JD text would change that (see the upgrade menu).

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. None may be coached, implied or softened in any answer.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a revenue model, not a GTM strategy |
| Mapped whitespace across land, adopt, expand and renew | Inflated form of F2 | F2's quote at its own scope. Your material does not show this mapping |
| Caused the ~$400M ARR uplift | Inflated form of F2: "credited with" is a stated attribution, not sole causation | "proposed a store-surface change credited with a ~$400M ARR uplift," at that scope |
| Designed partner motions | Inflated form of F5 | F5's quote at its own scope |
| Ran quota-setting or sales-ops work | Inflated form of F4; F7 is the stated absence | F4's volume-target quote at its own scope; F7's plain acknowledgment |
| Ran independent SQL and Tableau analysis end to end | Inflated form of F3 | "skilled in SQL/Tableau" |
| Built or shipped AI products | Inflated form of F6 | "uses AI tools daily" |

## 7. Reading the interviewer

Public signals from your profile of Dan only; no footprint search ran (see Sources).

- **Career pattern:** a pricing and monetization spine, with one early-stage-startup chapter. Self-described as "relentlessly data-driven."
- **Implications:** (1) every number Priya gives will be probed to its assumptions, so the A bank carries the most rehearsal; (2) case questions tilt toward pricing, packaging and unit economics, which is Dan's native language; (3) the startup chapter means builder stories land, and expect scrappiness probes on big-company pace.
- **Mirror:** no shared career jump. The one overlap is domain: revenue modelling. Offer it only through F1's quote, never as a claimed shared path.

## 8. Persona table

Weights follow the peer prior, adjusted by the interviewer signals above. Depth: top persona 5 questions, mid-weight 3 to 4, low-weight 2. No loop source established the loop, so the weights rest on the relationship prior, not on Northwind's documented process.

| Persona | Weight | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | 5 | Follows the $400M figure and the revenue model to their assumptions | High: Dan's self-described style, plus two headline numbers on the CV | Name the weakest assumption before it is asked; say plainly what you do not know about how figures were counted |
| Peer Evaluator | 4 | Seam questions between sales strategy and GTM; credit and disagreement | High: a peer pricing the hire's cost to Dan's team | Reciprocity framing; propose seam principles rather than claiming knowledge of the seam |
| Case / Strategist | 3 | Compass launch, bundling threat, whitespace | Medium-high: the research note's priorities are live; Dan's pricing spine | Clarify, then structure: segments, motion, pricing; state one hypothesis early |
| Skeptic | 2 | Quota gap and partner-motion gap | Medium: F5 and F7 are the material's visible gaps | Plain acknowledgment, then a ramp plan; never a bluff |
| Conversational | 2 | Opening biography; casual AI question | Medium: openers are scored too | A 90-second arc; treat the casual AI question as scored |
| Pressure | 2 | Challenges the $400M share | Low-medium: a peer register rarely presses, but the figure invites it | Hold the claim through two follow-ups; concede the uncertain share specifically |

## 9. Question banks

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the $400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say the attribution in the quote's words, then the weakest assumption you would defend least, in your own words. Answer slot: the method, baseline and attribution behind the figure are not in your material; if you know a part, say which; if you do not, say "I don't know how it was counted" for that part. | F2 is the figure the Prober will test first; EXP because it tests what was yours |
| A2 | "Which assumption behind that revenue model would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Name the assumption you would defend least before it is asked, in your own words. Answer slot: if any assumption was set by someone else, say so and say which parts you built. | F1 and F5 rest on this quote; a figure-free model still gets the weakest-assumption move |
| A3 | "What would have to be true for that uplift to be mostly the store change and not something else that moved at the same time?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Name the confound you would check first and how, in your own words. Do not assert the uplift was isolated. Answer slot: if you tested for a confound, say what you did; if you did not, say so. | Standard Prober move on F2; the answer's honesty counts more than its polish |
| A4 | "Show me the SQL or Tableau analysis you ran yourself. What question did it answer?" | JD | [grounded] "skilled in SQL/Tableau" | Answer slot: if you ran an analysis yourself, name the question, the data source and the decision it fed. If your SQL or Tableau work was done for others' questions, say so. If you have not run one of your own, say so and name what you would analyse first. | JD requires independent analysis; F3 is the thin side, so the honest branch must be ready |
| A5 | "How was the model used in the negotiation, and which part of it was yours?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Separate what you built from what the negotiation team did with it, in your own words. Hold the attribution without folding on the model itself. | Attribution probe on F1; a Prober will ask which part was hers |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side on sales strategy. Where is the seam between your GTM work and ours?" | JD | [generic] | Propose seam principles: who owns the target, who owns the deal-level motion, how disagreements get escalated. Do not claim to know the seam today. | Seam probe is the Peer Evaluator's first move; it asks for principles, so no past claim is made |
| B2 | "What would you need from my team in the first 90 days?" | JD | [generic] | Name two or three specific inputs (data, decision rights, a named counterpart) and what each unlocks. Keep it to inputs, not promises. | Peer framing of the same JD fit; it turns the gap into a request rather than a claim |
| B3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | Story-map on F4: the target and the consensus in the quote's words; say who was in the room and which part you proposed. Answer slot: if you proposed the target, say so; if it came from a group decision, say that and what your part was. | F4 carries cross-team influence; VAL because the credit answer is the behavior |
| B4 | "Tell me about a time you disagreed with an equal on a number. How did it end?" | VAL | [generic] | Selection scaffold: pick a disagreement with a peer over a figure, a moment you did not fold, and an intact working relationship at the end. Answer slot: if no such time comes to mind, say so plainly, then describe how you would handle it. | No quote in the material carries a disagreement story; the scaffold names its honest branch |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is launching. Where would you start on its GTM for existing enterprise accounts?" | CASE | [grounded] "an AI copilot launch ('Compass')" (your research note) | Clarify first: which accounts, what price point, what the launch must prove. Then segments, attach motion, pricing. Name one assumption and what would falsify it. | Compass is a stated priority; the case tests altitude, not a claim about her past |
| C2 | "Bundling by a much larger platform vendor is the main threat. How would you price Compass against it?" | CO | [grounded] "bundling by a much larger platform vendor" (your research note) | Frame the choice: compete on price, on packaging, or on partner. State what you do not know about the rival's bundle economics. Give one hypothesis early. | Competitive threat from your note; Dan's pricing spine makes this the likeliest hard case |
| C3 | "Profitability is one of three priorities. What would you give up from the Compass launch to protect it?" | CO | [grounded] "reaching profitability" (your research note) | Name one trade-off and why, then what you would measure to know it was right. | Tests altitude: a priority ranking, not a list |
| C4 | "Where is the whitespace across land, adopt, expand and renew for Compass?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights) | Structure by lifecycle stage, one segment at a time. Name the data you would need for each stage and one assumption to test first. | Covers the JD's whitespace requirement, which the fit snapshot marks as discovery; nothing here claims past work |

### D. Skeptic (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" (JD highlights); [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Name the requirement your material does not show, in your own words, and the first two weeks of a ramp plan. Answer slot: if you designed any partner term, say which. Do not claim partner-motion design. | Covers the JD's partner requirement and F5; the Skeptic's favorite opener |
| D2 | "I don't see quota or sales-ops work in your background. How would you handle target-setting in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message) | **Highest-ROI prep in this pack.** Plain acknowledgment: "I haven't run classic sales-ops or quota-setting." Then the plan: what you would learn first, from whom, and how you would test a target before setting it. Hold through two follow-ups. Do not cite the volume-target line as quota work. | F7 is the gap a Director of Sales Strategy is most likely to press; the honest answer is the acknowledgment plus a plan |

### E. Conversational / Rapport Builder (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (your message) | A 90-second arc from that sentence: consulting, then consumer-tech product strategy and ops, then why emerging products. Use the quote's beats only. | Opener is scored for economy; the arc is the quote's own structure |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message) | Name the tools you use daily and one task you use them for. Say use, not building. | AI is a JD plus asked casually; F6 is the thin side |

### F. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-1 | "Sixty seconds: why you over a candidate who has run a partner program?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Hold the strongest specific from that quote. Concede specifically that you have not run a partner program, if that is true, and stay with what you built. | Pressure probe on F5; hold then concede, never fold on the model |
| F-2 | "That $400M figure. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Hold: "I proposed the change; the figure is credited to it." Concede uncertainty about your share of the credit, specifically, and do not restate a larger share. | Attribution pressure on F2; the hold is the quote, and the concession is the share |

### Requirement coverage

| Stated requirement | Question IDs |
|---|---|
| Own GTM strategy for two new product lines | D1, C1 |
| Identify whitespace across land/adopt/expand/renew | C4 |
| Run independent analysis in SQL and Tableau | A4 |
| Partner-motion design experience required | D1, F-1 |
| Strong cross-functional influence | B3 |
| AI experience a plus | E2 |
| (Not in JD highlights; the round's expected probe, from F7) quota and sales-ops | D2 |

No requirement is left without a question. Session total: 19 questions across six personas.

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You moved from pricing and monetization into sales strategy. What did the pricing work teach you that the sales side needed?" | Ties to Dan's own career path; turns the interview into a peer conversation |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer; signals you are thinking about what you bring |
| R3 | "Where does the sales strategy team's number stop and the product GTM number start?" | Surfaces the seam directly; the answer shows how the two teams split the work |
| R4 | "How has the Compass launch changed what sales strategy is asked to decide?" | Shows you know the priority; the answer tells you what Dan's team is carrying |
| R5 | "Which of the three priorities (enterprise expansion, Compass, profitability) does the team argue about most?" | Shows you read the priorities as a set; invites candor about trade-offs |
| R6 | "If the bundling threat lands in the next two quarters, what changes first for your team?" | Shows you have thought about the competitive frame; a useful answer for either side |

## 13. Values / principles cheat sheet

Omitted. No values-style round is detected: no loop source establishes the loop, and the Generic fallback reads `no` for values. Values research did not run (see Sources).

## Sources

Provided documents: your message (the candidate summary, JD highlights, and interviewer profile); your research note (three priorities, Compass, the bundling threat).

Searches sent, all refused by the host:

- `Northwind Data company values operating principles`: refused
- `Northwind Data interview process GTM strategy role`: refused
- `Dan Kovac Director of Sales Strategy Northwind Data`: refused

Research tier: L1; searches 3 of 6 (all refused), fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Would have moved the values cheat sheet; none is detected, so section 13 is omitted |
| 2. Northwind Data interview process, GTM role family | unavailable | Would have established the loop; without it, persona weights rest on the Peer relationship prior |
| 3. Northwind strategy / recent news | skipped | Your research note fixes the three priorities, Compass, and the bundling threat; that output is fixed by the input |
| 4. Dan Kovac, Northwind Data | unavailable | Would have added public professional footprint and tested the reading in section 7 |
| 5. Representative GTM strategy JD | skipped | The JD highlights supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → turns the JD highlights into quoted requirements, surfaces mid-list items, and shows any gate such as location or pay
- Full CV text → quotes her own sentences rather than your summary, which tightens F1 to F7 and every A-bank provenance cell
- Round format (conversation, case, presentation, or a mix) → reweights the Case persona and adds drills for whichever format applies
- If web search becomes available → targets 1, 2 and 4 can run; the values, loop and Dan's public footprint rows become grounded
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → strategy brief for the C bank, plus loop reports; want it?
- A `tuesday-dossier.md` → would carry verified evidence and the prohibited claims into a re-run
