# Saltmarsh Games: Live Operations Producer interview prep pack

**Role:** Live Operations Producer, Saltmarsh Games
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** 60 minutes. Treated as a hiring-manager round, since Tobias leads the function. Not yet confirmed.
**Changelog:** first version.

## 1. How to use

- **Personas** describe how a question is asked. **Types** describe what it scores.
- Types: **EXP** your past work · **JD** the listed job · **CASE** a live problem · **CO** company knowledge (none in this pack) · **VAL** values (none detected).
- Guidance is scaffolding, not a script. Each is speakable in about 90 seconds.
- Provenance: **[grounded]** traces to the JD or your message · **[inferred]** a derivation from them, named · **[generic]** a pattern for this kind of role, not a fact about Saltmarsh.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title's weekly content drops, not a calendar across two titles. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you planned across a second title, say how; if you did not, say so and say how you would set up two calendars. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination across those teams. Answer slot: if you coordinated design, art, engineering or community on a content drop, say which and how; if there was no such coordination, say so and say how you would run it for an update. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | transferability | Presenting monthly numbers is adjacent to owning a post-event review. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you wrote a review after an event and said what it reported, say so; if not, say so and say how you would set the KPIs before an event runs. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the requirement. Lead with it in its own terms: you wrote it, and QA still uses it. Expect a probe on what it covers. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | low | [grounded] | transferability | The four years are stated. That the studio's game was live-service is not. Say the live part through the content drops you ran. The length is graded here and is not a gate. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement directly. Lead with it. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: presenting retention is not analysing it. Say only the quoted line; add no analysis you did not do. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | presentation | The checklist is the only written work in your message. Derivation: this pack reads it as written communication. That is the pack's inference, not your claim. Answer slot: name one piece of writing you are proud of and what it did. |
| F9 | Team leadership: not a JD line. [generic] a coordination role draws this probe | "Never led a team" (your message) | none | [grounded] | capability | The absence is yours. Words: "I haven't led a team." Then what you did instead, in your own words, drawn from F1 or F4. Never claim to have led. |

**Not in the JD, so not a row:** in-app purchases. The JD does not raise monetisation, so no question is built on it. See the prohibited list.

## 3. Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic | Probes the gaps: leadership, two titles, the thin KPI line | **High.** A hiring manager is buying capability and checking derisking. F2, F5 and F9 are where your material is thin. | Hold the line you stated, then concede the specific gap. | A1 to A5 (5) |
| Case / Strategist | Live problems from the calendar and the release | **Medium-high.** Hiring managers pose live roadmap problems. | Clarify, then structure, then name a metric and a risk. | B1 to B4 (4) |
| Data-Driven Prober | How the figures were counted | **Medium.** Retention and KPIs are in the JD. Your message gives no figures. | Say plainly what you know and what you do not. | C1 to C3 (3) |
| Pressure | Interruption, time-boxing | **Medium-low.** A 60-minute hiring manager may test composure on the leadership gap. | Pause, restate, hold through two follow-ups. | D1, D2 (2) |
| Conversational | Opener, "walk me through" | **Near-certain opener.** The first five minutes are scored casually. | A 90-second arc from your four sentences. | E1, E2 (2) |
| Peer Evaluator | Seams between teams, credit | **Low.** The interviewer leads the function, so a peer-style probe is less likely. Kept for the four-team line. | Principles, not invented knowledge. | F1, F2 (2) |

## 4. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I ran live events across two titles" | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." Observation: your material says one title. |
| "I owned the post-event review" | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." Observation: your material does not say you wrote a review. |
| "I analysed retention" | Inflated form of F7 | The presented line, with no analysis added. |
| "I own the release checklist with QA" | Inflated form of F4 | "Wrote the release checklist our QA team still uses." |
| "I've led teams" | Stated negative, F9 | "I haven't led a team." Plain acknowledgment. |
| "I've worked on in-app purchase games" | Stated negative, your message | "I've never worked on a game with in-app purchases." Plain acknowledgment. Used only if the interviewer raises monetisation. |

## 5. Question banks

Questions are the interviewer's lines. Guidance and rationale refer to your material only through the quotes in Provenance.

### A. Skeptic (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Name the two-title line honestly, in F1's words: one title's calendar. Then a plan to close it in the first 90 days. A plan is not a past. Do not say you have planned for two titles. | Hiring managers buy capability and derisk gaps. F1 is the first place a probe lands. |
| A2 | "You haven't led a team. What makes you think you can coordinate four teams on an update without managing any of them?" | JD | [grounded] "Never led a team" (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | **Highest-ROI prep.** Say "I haven't led a team." Then return to what the calendar did, in its own words. Hold through two follow-ups. Concede the specific coordination you have not done. Answer slot: if you coordinated design, art, engineering or community on a drop, say which and how; if you did not, say so and describe how you would run it. Never claim leadership to close the gap. | F9 is the gap this interviewer is most likely to test, and your material does not close it. The deepest rehearsal goes here. |
| A3 | "QA has to sign off a release. What happens when they say no?" | JD | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Answer slot: if you handled a QA hold on a release, say what you did; if you did not, say so and say how you would handle one with the checklist you wrote. | F4 is the release line. The question is open, so it presupposes no hold. |
| A4 | "Tell me how you would own a post-event review and the KPIs it reports." | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | A plan, not a past. Start from the retention numbers you presented, in their own words. Answer slot: if you have written a review after an event, say what it reported; if you have not, say so. | F3's thin bridge. The JD raises the review and the KPIs. |
| A5 | "Your calendar covered one title. How would you run two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Keep to "our main title". Describe how you would split the calendar across two titles and what you would share between them. Do not say you did this. | F1. The premise is the quote's own scope. |

### B. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A live event's day-three retention is 15% below plan. Diagnose it." | CASE | [generic] | Clarify first: what the plan assumed and what "retention" means here. Then segment (new or returning, platform, the event's reward). Then check whether the event or something else moved. Name one metric to check first and one risk to the call. Think aloud. | A live problem from the role. Generic because it is a pattern, not a fact about Saltmarsh. |
| B2 | "You are planning a two-week live event for one of two titles. Design, art, engineering and community all need to be ready. What do you need to know first?" | CASE | [generic] | Clarify: the event's goal, its dates, each team's lead time, and what is already committed. Then the order of dependencies, and where you would escalate. | Covers the JD's calendar and coordination lines. Asks no past claim. |
| B3 | "The morning of a launch, QA flags an open item on the checklist, and the event is already announced. What do you do?" | CASE | [generic] | Structure it: what the item is, who can say whether it blocks, the cost of slipping against shipping, and what you tell the community. Name who owns the decision. | Covers the JD's release line. |
| B4 | "What would you measure to know a live event worked, and what would make you call it a failure?" | JD | [generic] | A primary KPI, a guardrail, and the threshold for each call. Name the weakest assumption in the target. | Covers the JD's KPI line through a metric question. |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which retention figure did you present most often, and what did it measure?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name the figure and what it measured, in your words. Answer slot: if you know how it was calculated, say so; if you did not calculate it, say so plainly. Weakest-assumption move: name the assumption you would defend least, if you know one. | Your message gives no figure, so the pack supplies none. F7 and F3. |
| C2 | "Which assumption behind a retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name one only if you know one. If you do not know how the numbers were built, say that plainly. Do not reconstruct a method on the spot. | The prober's stem. Tests the claim behind F7. |
| C3 | "What does the release checklist you wrote cover, and what does it leave out?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Describe what it covers in your words. If you know what it leaves out, say so. If QA has changed it, say how. If you do not know, say so. | Tests the F4 claim at its own scope. |

### D. Pressure (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run live-service at a bigger studio?" | JD | [generic] pressure stem; [grounded] "4 years as an associate producer at a puzzle-game studio." (your message) | Pause and restate the question. Hold: the calendar and the checklist are the case you can make, in those words. Hold through two follow-ups. Concede exactly: "I haven't led a team." Do not concede a studio comparison your message does not state. | Tests composure. The hold-then-concede structure is the rehearsal. |
| D2 | "The checklist QA still uses: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Say what you wrote and what others shaped, in your words. If others shaped it, say so. Claim no more than "wrote". | An attribution test on F4. |

### E. Conversational (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message); [grounded] "Wrote the release checklist our QA team still uses." (your message); [grounded] "Presented the monthly retention numbers to the studio head." (your message) | A 90-second arc in that order, using those four sentences as they stand. Then say, in your words, why this role's two-title scope is the next step. | The opener is scored casually. Your four sentences are everything your material says about your past. |
| E2 | "What are you playing in our titles these days?" | JD | [generic] | Name a title you have actually played and one thing you noticed about its content cadence. If you have not played them, say so and ask what the cadence is. Do not describe a session you did not play. | The JD's two titles, asked casually. |

### F. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our design and community teams sit side by side. Where's the seam, and what happens when you disagree?" | JD | [generic] | Propose seam principles: who owns the update's scope, who owns the player message. For disagreement, your material holds none. Pick a time you disagreed with a peer. If none comes, say so, then give the nearest thing you did. | Peer stem. The JD raises coordination with those teams (F2). |
| F2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Say who did what on the checklist, in those terms. Claim no credit for QA's use of it beyond "still uses". | Peer stem and an attribution test. |

## 6. Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A5, B2 |
| Coordinate design, art, engineering and community teams | A2, B2, F1 |
| Own the post-event review and the KPIs it reports | A4, B4, C1 |
| Manage the release checklist with QA | A3, B3, C3, D2 |
| 3+ years producing live-service games or apps | E1 carries the walk-through. The length is graded in F5, not questioned on its own. |
| Experience running a content calendar | A5, E1 |
| Comfortable with player-retention metrics | B1, C1, C2 |
| Clear written communication | None, and why: no written exercise is announced. It is delivered through every answer. |

**Totals:** 18 questions (A5, B4, C3, D2, E2, F2).

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a successful live event look like here, and measured against what baseline?" | Turns the JD's KPI line into a conversation about the target. |
| R2 | "How are design, art, engineering and community coordinated on an update today?" | Asks about the working model, and gives you the seam facts you will need. |
| R3 | "Who owns the post-event review now, and what happens after it?" | Tests whether the role is real and what "own" means here. |
| R4 | "What does QA's sign-off look like on a launch day?" | Shows you know the checklist is a gate, and asks how it runs. |
| R5 | "What would the first 90 days need to deliver for you to call this hire a success?" | Converts the interview into success criteria. Pairs with A1's plan. |

## 8. Sources

- **Provided:** the JD text and your message.
- **Searches sent (all refused by the session's permissions, not retried):**
  1. "Saltmarsh Games values": refused
  2. "Saltmarsh Games interview process live operations producer": refused
  3. "Saltmarsh Games strategy mobile games news": refused
  4. "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused
- **Fetches:** none sent. User links read: 0.

**Research tier: L1, searches 4 of 6 (all refused), fetches 0 of 2**

| Target | Status | What it would have moved |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, section 10. Not built, and no values round is detected. |
| 2. Saltmarsh interview process | unavailable | Loop structure. Personas rest on the hiring-manager prior, not on this company's loop. |
| 3. Saltmarsh strategy / recent news | unavailable | The CO bank. None is written, so no company-specific strategy questions. |
| 4. Tobias Wrenfield, Saltmarsh | unavailable | Interviewer read and a tailored reverse question. Reverse questions are role-generic. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## 9. Upgrade menu

- Allow web search, or paste text: Saltmarsh's values page, its careers page on interviewing, and Tobias's public profile or talks → a values sheet, a loop-based reweight of personas, a CO bank, and a tailored reverse question.
- Confirm the round's format with the recruiter (one session or several, and any exercise) → the persona weights and any deliverable section.
- Name the live-service titles you worked on and what one content drop involved → F3 and F5 move from low to medium.
- Any figure from your retention work that you can state, with its source → unlocks the defend-the-number slots on C1.
