# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Role:** Live Operations Producer, Saltmarsh Games (mobile, about 350 people)
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager. Round: the Outage Hour, a single 60-minute interview with the hiring manager (company careers page, read in Sources).

## How to use

- **Personas** are how the question is asked. **Types** are what is being scored: VAL (values), EXP (your experience), JD (the listed job), CO (company knowledge), CASE (a live problem).
- The Outage Hour, per the company's own page, is a live-incident tabletop on a simulated outage during a live event, then a values conversation. Rehearse both halves.
- Guidance is scaffolding, not a script. Each guidance cell is meant to be spoken in 90 to 120 seconds.
- Answer slots ("Answer slot:") are instructions for the interview. Each one has an honest branch. Use the branch that is true.

## Fit snapshot

Requirements are the JD's own words. Evidence is your own sentences, quoted exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one title and weekly content drops, not a live-events calendar across two titles. Say that scope. Answer slot: the JD's two-title line makes a probe on the second title likely. If you planned any part of a second title's calendar, say which; if you did not, say so and say how you would take it on. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating these four teams. Answer slot: name a release where you coordinated across teams, how it ran and who decided; if you have not done this, say so and describe how you would set up the first update. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | transferability | Presenting monthly numbers is not owning a post-event review or the KPIs behind it. Answer slot: if you chose which KPIs were reported, say so; if you did not, say so. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | Reword only the quote: "I wrote the release checklist, and QA still uses it." |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | The years meet the count. Your material does not say the puzzle title was live-service. Answer slot: if it ran content drops or events, say what; if not, say so and name the nearest live element you carry. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | Confirmed, specific, with limited inspectable proof. Expect a probe on how much of the calendar was yours to set. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | Reword only the quote: "I presented the monthly retention numbers to the studio head." No figure is given, so no defend-the-number slot is raised yet. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | A checklist shows you write documents people use. It does not show writing for a live audience. Answer slot: name a written piece you would put in front of Tobias; if none is yours to show, say so. |

**Gates.** No JD line is a gate under the suite's definition (no location, schedule, pay, credential or legal term). The pack has no hard-gate rows.

**Not a JD line, but likely to come up.** You have never worked on a game with in-app purchases. The JD does not name it. The mobile-title setting makes a probe plausible; that is a derivation from the JD, not a JD line. It is covered in B2 and in the prohibited list.

## Prohibited claims

Not coached in any cell of this pack, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've led a team." | Negative you stated: "Never led a team" | Plain acknowledgment: "I haven't led a team." No answer slot on this line. |
| "I've worked on a game with in-app purchases." | Negative you stated: "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |
| "I ran the content calendar for both titles." / "I ran live events." | Inflated form of F1's quote | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is this pack's observation: your material says one title and content drops, not live events across two. |
| "I owned the post-event review and the KPIs." | Inflated form of F3's quote | F3's quote at its own scope: "Presented the monthly retention numbers to the studio head." |
| "I managed the release checklist with QA." | Inflated form of F4's quote | "I wrote the release checklist our QA team still uses." |

## Reading the interviewer

Public footprint only. Source: a 2026 GDC talk and a short profile, both read as search snippets, not opened (see Sources).

- **Career pattern:** previously QA lead at a console studio, now Head of Live Operations.
- **Recurring theme:** the talk "Patch Notes Are a Promise" argues that a live team is judged by how often its patch notes describe what actually shipped.
- **Implications:**
  1. Lead with what shipped and what was verified. Claims that cannot be checked get probed.
  2. Expect probes on how each number was counted, and on whether a checklist item was actually checked.
  3. A plain "I haven't" will land better with him than a bluff. His own framing is about accuracy.
  4. The QA-checklist line (F4) is shared territory with his background: release discipline and QA. It is not a shared career jump, because your material carries no jump on your side. Do not present it as one.

## Persona table

Relationship prior for a hiring manager is Case/Strategist and Skeptic. The loop source documents a values conversation, so Values is guaranteed in this session. His published theme adds weight to Prober. Weights are shown with reasons so you can recalibrate if you know something I don't.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | A live-incident tabletop on an outage during a live event | High. The company's page names the tabletop as the first half of the Outage Hour. Hiring-manager prior. | Clarify, objective, owners, metrics, risks. Think aloud. |
| Skeptic | Gap probes: teams without authority, in-app purchases, two titles | High. Hiring-manager prior, plus two negatives you stated. | Rehearse the predictable objection (B1) until it is plain. Plain acknowledgment. |
| Values/Behavioral | The values conversation, against the three published values | High. Documented by the loop source. | Map stories where your sentences carry them; scaffold with an honest branch where they do not. |
| Prober | Claims versus what shipped; how KPIs were counted | Medium-high. His published theme; the JD's KPI line. | Defend-the-number slots. Name the weakest assumption before he does. |
| Pressure | Composure on the leadership gap, time-boxed | Medium. One interviewer in 60 minutes, likely time-boxed. | Hold through two follow-ups, then concede the absence plainly. |
| Conversational | Opener and "walk me through" | Medium. The first minutes. | Keep a 90-second arc built only from your quotes. |

## Question banks

Question IDs are letter by persona. Session total: 18 questions, the Outage Hour's 60 minutes with its two halves.

### Bank A: Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A reward-claim bug is hitting players during a live event. Walk me through your first hour." | CASE | [generic] | Clarify who is affected and whether players can still claim. Name the owners to pull in: engineering for the fix, QA for verification, community for the message. Decide what players hear before the cause is known. Say the plan in order: clarify, objective, owners, metrics, risks. | The tabletop is the first half of the Outage Hour. This is a hypothetical; it claims nothing about your past. |
| A2 | "If your two titles moved onto one shared events calendar and one live-ops group, what would you protect first?" | CO | [grounded] Project Larkspur, saltmarshgames.com news (search snippet only) | Name what each title's players depend on from its own calendar: content cadence, event timing, what the community expects. Anchor to "Players Before Plans." Do not claim knowledge of Larkspur's details beyond the one line you have read. | The one current company move research found. Conditional, because the JD does not name the two titles. |
| A3 | "Retention on one title dipped two weeks after the last event. What do you need to know before you change next month's calendar?" | CASE | [generic] | Clarify the measurement window, what changed in the event, and whether the dip is across all players or one cohort. Propose what you would check before moving content. Do not name a retention figure. | A calendar decision in the JD's own terms, as a hypothetical. |
| A4 | "Tell me how you would run the release checklist with QA on a live event." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Say what the checklist covers, in your words, and who signs off each step. Answer slot: if the sign-off was yours, say which steps; if QA owned sign-off, say so plainly and describe your part. Hold to the checklist you wrote and the team that uses it. | F4 is the evidence for the JD's QA line. The question is open, so it presupposes nothing about your past. |
| A5 | "A drop shipped well, but retention fell two weeks later. What do you check before you call it a success?" | JD | [generic] | Name the checks: what shipped against the spec, what players saw, and whether the KPI measures the drop or something else. Say which of these you have run yourself, if any. Answer slot: if you ran a post-event check, say how; if you did not, say so and say what you would check first. | The JD's post-event review and KPI line (F3), as a hypothetical. |

### Bank B: Skeptic (weight 5 with the JD items)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our JD asks you to coordinate four teams on every update. You haven't led a team. How do you get design, art, engineering and community to move?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment: "I haven't led a team." Then describe the coordination you have actually done, in your own words. Answer slot: if you have coordinated a team without authority, say which and how; if you have not, say so and describe how you would set up the first update. Hold the coordination claim to what you did. | Highest-ROI prep in this pack (see below). F2 is the gap. |
| B2 | "Have you worked on a game with in-app purchases?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say what you know about how content drops differ on a puzzle title, and name the first thing you would learn about purchases. | The JD does not name in-app purchases. Mobile live ops often does; that is a derivation, not a JD line. |
| B3 | "The JD asks for 3+ years producing live-service. Was your puzzle title live-service?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | The years meet the count. Say what live elements the title had. Answer slot: if it ran content drops or events, say what and your part in them; if it did not, say so and name the nearest live element you carry. | F5. The years are fact; whether they count as live-service is the probe. |
| B4 | "What does a post-event review have to show before you trust the KPIs it reports?" | JD | [generic] | Name what a trusted review holds: what shipped, what players saw, and how each KPI was counted. Say which parts you have owned, in your words. | The JD's post-event KPI line. A framework question, so no claim about your past. |
| B5 | "On day one, which part of this JD would you be weakest at?" | JD | [generic] | Name the requirement you are weakest on, using the honest words from F2 or the in-app purchases gap, and a ramp plan. Do not pick a strength to dodge it. | A stock Skeptic stem for this JD. |

### Bank C: Values/Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a calendar choice had to give way to what players needed." | VAL | [grounded] "Players Before Plans" (company values page); nearest sentence: "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick a time a planned drop moved or was cut because players needed something else. If none comes to mind, say so plainly, then give the nearest content-drop decision your material carries. The honest branch is a complete answer. | No sentence of yours carries a trade-off, so this is a scaffold, not a story map. |
| C2 | "Tell me about a time you reported a number before you could stand behind it." | VAL | [grounded] "Ship the Patch Not the Promise" (company values page); your sentence: "Presented the monthly retention numbers to the studio head." | Scaffold: say what the numbers measured and what you would not claim from them. If you never had to walk one back, say so plainly and give the nearest thing you did check. | Matches his published theme. Only your presenting is quoted; the scaffold adds no event. |
| C3 | "Which item on a release checklist would you keep even if it slowed a drop, and why?" | VAL | [grounded] "Leave the Build Greener" (company values page); your sentence: "Wrote the release checklist our QA team still uses." | Story map: you wrote a checklist QA still uses. Say what it covers and why it has lasted. Then name one item you would keep at the cost of a drop. Answer slot: if you added the item, say so; if you did not, say so. | The quote's "still uses" carries the durability beat, at its own scope. |

### Bank D: Prober and Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how those retention numbers were counted. Which assumption would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Defend-the-number: say how they were counted, the weakest assumption, and which part was yours. Answer slot: if you did not set the counting, say so. Say only what you can repeat under a second question. | A figure raises these slots. His published theme makes this likely. |
| D2 | "Sixty seconds: why should we hire someone who has never led a team, for a role that coordinates four of them?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Hold, then concede. Hold on the calendar you ran and the checklist QA still uses, through two follow-ups. Concede the absence plainly: "I haven't led a team." Do not fold on the core claim to restore the mood. | Pressure stem. The held positions are the quoted material; nothing is added. |
| D3 | "Your patch notes should describe what shipped. How would you check that your post-event KPIs describe what players actually saw?" | JD | [generic] | Name the checks: the shipped build against the event spec, the player-facing text against the review, and each KPI definition against the data. Say which of these you have run yourself, if any. | His published theme, put as a question. A framework, so no claim about you. |

### Bank E: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." | A 90-second arc built only from these sentences: four years, the calendar, the checklist, the retention reporting. Keep it to what the quotes say. | Casual register, still scored, and the JD's experience line. |
| E2 | "What would you change first about how live events get announced?" | CASE | [generic] | One change, tied to "Ship the Patch Not the Promise": announce what is built, not what is hoped. Keep it short. | A casual question on a JD topic, still scored. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A2, A3 |
| coordinate design, art, engineering and community teams on each update | B1, A1 |
| own the post-event review and the KPIs it reports | A5, B4, D3 |
| manage the release checklist with QA | A4, C3 |
| 3+ years producing live-service games or apps | B3, E1 |
| experience running a content calendar | E1, A3 |
| comfortable with player-retention metrics | C2, D1 |
| clear written communication | none, and why: the Outage Hour is spoken, and the material holds no written sample. The upgrade menu asks for one. |

**Highest-ROI prep: B1.** He is likely to probe the team-leadership gap against the four-team coordination line. The answer is the plain acknowledgment followed by the coordination you actually did, with no added leadership.

## Values cheat sheet

Condition met: the loop source documents a values conversation. Values are from the fetched company page.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | No sentence of yours carries a trade-off. Scaffold, from C1: a time a planned drop gave way to players; if none, say so and give the nearest calendar decision you carry ("I ran the weekly content-drop calendar for our main title for the last two years."). |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | F7's sentence: "Presented the monthly retention numbers to the studio head." Scaffold, from C2: what the numbers measured and what you would not claim from them. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | F4's sentence: "Wrote the release checklist our QA team still uses." Story map, from C3: what the checklist covers and why it has lasted. |

## Reverse questions

At least five. Each has a reason it lands.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong Outage Hour look like from your side of the table?" | Shows you read the loop page. Invites him to name what he scores. |
| R2 | "If this role's two titles are part of Project Larkspur, which one would move first, and who would own the calendar then?" | Ties to the company's own published move. Conditional, because the JD does not name the titles. |
| R3 | "You came into live ops from QA. What did that background make you look for first in a live team?" | His public path (QA lead, then Head of Live Ops). It turns the probe into a peer conversation. |
| R4 | "Which decision on a live title takes longest today, and what would make it faster?" | A seam question. Shows you think about process, not only output. |
| R5 | "What would have to be true at six months for you to say this hire worked?" | Gets his scorecard in his own words. |

## Prohibited claims check

Built in Step 3 from the fit snapshot. Each entry is above, in the Prohibited claims table. No guidance cell asserts any listed claim.

## Sources

**Provided documents:** your message (background and JD).

**Research** (L1 default; both fetches are the company's own pages):

| Query | Result |
|---|---|
| "Saltmarsh Games values" | saltmarshgames.com/values, fetched |
| "Saltmarsh Games interview process live operations producer" | saltmarshgames.com/careers/interviewing, fetched |
| "Tobias Wrenfield Saltmarsh Games" | talks.gdconf.example/2026/patch-notes-are-a-promise, search snippet only, not opened |
| "Saltmarsh Games news live events 2026" | saltmarshgames.com/news/project-larkspur, search snippet only, not opened |

The talk's link is on a domain ending ".example". Confirm the talk exists on the GDC site before you cite it to him.

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet: three values, named from the fetched page. |
| 2. Saltmarsh Games interview process | yes | Loop: a single 60-minute Outage Hour with the hiring manager, a tabletop then a values conversation. Establishes the loop, so no archetype fallback. Persona weights follow it. |
| 3. Saltmarsh Games strategy / recent news | yes | One current move (Project Larkspur, snippet only): grounds A2 and R2. |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Reading the interviewer: a 2026 talk and a prior role (snippets only). Persona weights and R3. |
| 5. Representative live ops producer JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- A CV or written résumé → your sentences gain a CV source, and F1 and F5 can name the title count and the live elements.
- The two titles' names → F1 and A2 become specific, and R2 becomes direct.
- What the puzzle title's content drops and events looked like → F5 resolves from "may not be live-service" to a stated fact.
- One written piece you have produced for players or a team → F8 moves from discovery, and the coverage line gets a question.
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief and his talks and writing; the CO questions sharpen.
- A tuesday-dossier.md → carries this pack's gaps into later sessions.
