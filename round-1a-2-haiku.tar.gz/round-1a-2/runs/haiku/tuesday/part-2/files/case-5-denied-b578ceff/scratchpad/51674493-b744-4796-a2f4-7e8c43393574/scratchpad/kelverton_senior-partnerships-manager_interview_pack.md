# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

Round: second round, panel, 60 min. Deepa (VP Partnerships, future manager) and Ross (Commercial Director).
First 15 min: spoken POV on operator partnerships over 18 months, no slides, must land on what it means for the operators. Remaining 45 min: Q&A, Ross pushes on commercials.

Changelog: first version. No JD supplied; research tools refused, so this is an L0 pack built from the recruiter's email and the candidate's message.

## 1. How to use + type key

- Personas = how it's asked (Deepa: manager, prober; Ross: commercial, pressure).
- Types: EXP (what you did), JD (scored requirement), CASE (live problem), POV (spoken argument), COMM (commercial pressure).
- Guidance is scaffolding, not a script. Speak it in your own words.

## 2. Prep triage (about 4 hours)

1. 0:00-1:15. The POV. Pick three theses (section 4), write a 90-second spoken version of each, and say each out loud, timed, twice. Every thesis must end in an operator consequence.
2. 1:15-2:00. Ross's commercial questions (section 6). Write the honest answer to each, then say it aloud.
3. 2:00-2:30. The two gap answers, F1 and F4 (section 5). Short, plain, then the 90-day plan.
4. 2:30-3:15. Deepa's questions and your reverse questions (section 7). Then one full pressure drill with Ross.
5. 3:15-4:00. One full run: 15 min POV, 10 min Q&A. Read the watch-out line.

Everything else is insurance.

## 3. Fit snapshot

Requirements come from the recruiter's words (quoted, source: recruiter email). No JD.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships" — recruiter email | "Never sold into rail specifically" — your message | none | [grounded] | capability | Words: "I haven't sold into rail." Then a plan for the first 90 days, said as a plan. Never a rail sales claim. |
| F2 | "know the operator world" — implied by the recruiter's "operator" framing; the candidate's own description | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail planning, from the consultant's side. Words: "I spent five years on the planning side of bus and light rail networks." Do not extend it to train operating companies. |
| F3 | Partnership scale and channel management | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | none | The quote reaches the requirement. Lead with the partner count, since it is the most checkable fact. |
| F4 | Direct revenue ownership / quota | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | Words: "I haven't carried a direct quota." Then how you'd expect to be measured and what you'd need to ramp. |
| F5 | Commercial accountability — recruiter: "Ross will push on commercials" | "roughly £4M of influenced revenue" — your message | low | [inferred] | discovery | Answer slot: how influence was counted (touch rules, which stage), and what share of the £4M you could attribute to your own actions. If you can't say, say so and say how you'd count it. |

## 4. Graded deliverable: the 15-minute POV

Declared by the recruiter: a spoken POV, no slides, on operator partnerships over 18 months, landing on what it means for the operators.

Facts to build on (quoted, fit snapshot): F2 "I spent five years on the planning side of bus and light rail networks." F3 "took it from 6 partners to 40."

Three candidate theses. Each needs a concession.

- T1. Operators buy from partners who change their planners' week, not from feature lists. So the partner motion should attach to the operator's own cycle: timetable change, rostering, disruption. Operator consequence: fewer surprises at timetable change and less reworking of plans. Concession: you don't yet know how TOC planning teams are organised, and that is the first thing you'd learn.
- T2. Partnership value shows up as recovered capacity and lower disruption cost, so the partners should share an outcome the operator already measures (planned vs operated, crew utilisation). Operator consequence: the operator can justify the spend to its own board. Concession: attribution will be hard, and operator data-sharing will be a real blocker.
- T3. Rail's buyer count is small, so breadth-of-channel is the wrong metric and depth is the right one. The payments channel taught you breadth; this market teaches depth. Operator consequence: fewer, deeper partners who each carry a named operator's plan. Concession: this is a hypothesis drawn from a different sector, and Kelverton's partner base may already look different.

Do not present T3 as "I've built channels in rail." Present it as a transfer, and say which part does not transfer.

Land each thesis on one line: "For the operator, that means ___."

## 5. Gap-handling answers (short, plain)

- F1 (no rail sales): "I haven't sold into rail. What I'd do in the first 90 days is ___." Then one concrete thing: shadow a live operator deal, learn the procurement route, map the decision makers. Do not add a rail win.
- F4 (no quota): "I haven't carried a direct quota. I'd expect to, and here's what I'd need to ramp." Then name the ramp: pipeline visibility, a pricing floor, a first target account.

## 6. Commercial pushback (Ross), question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never sold into rail. Why would a train operator take a call from you?" | COMM | [grounded] "I haven't sold into rail." (F1) | Hold the sentence, then go to what you'd bring: operator-side planning knowledge from F2, and a plan. Hold through a follow-up by returning to the plan. | F1 is the obvious objection. |
| C2 | "£4M influenced. What was your share, and what does influenced mean?" | COMM | [grounded] "roughly £4M of influenced revenue" (F5) | Give the definition you used and what share you could attribute to your own actions. Answer slot: if you can't split the figure, say so and say how you'd split it. Never restate it as closed or sold. | F5 is the likeliest probe on the number. |
| C3 | "Give me the partner-sourced pipeline and what share closes. Which partners are below plan?" | COMM | [grounded] "took it from 6 partners to 40" (F3) | Partner count is what you can state. For pipeline and conversion, say what you'd need to measure first. Never invent a conversion rate. | Pressure on the commercial metric. |
| C4 | "How would you price a partner deal with a TOC when they run a procurement framework?" | COMM | [generic] | Structure it: what you'd learn first (framework rules, margin floor, who signs off), then how you'd keep the partner's margin intact. No claim about past deals. | A live problem. Honest answer is structure, not a price. |
| C5 | "Operators buy direct. Why do you need partners at all?" | COMM | [generic] | Challenge the premise. Where partners add delivery or reach an operator's own team can't, and where they don't, say so. | Tests whether you'll defend the premise or concede it. |

## 7. Panel questions (Deepa) and reverse questions

- D1 (JD-style, manager): "What would you change in the first 90 days?" Answer with the plan from F1, then one thing you'd stop doing.
- D2 (prober): "How would you measure a partner is healthy?" Name a leading and a lagging signal. Say which you trust less.
- Reverse questions (at least five, each with why it lands):
  1. To Deepa: "Which operators are the 18-month priority, and where is each one now?" Shows you plan around accounts, not slides.
  2. To Deepa: "What did the last person in this role get right, and what did they get wrong?" Invites an honest answer about the gap.
  3. To Ross: "How is partner-influenced revenue counted here, and how does it reach the forecast?" Shows you want the rules, not the number.
  4. To Ross: "When an operator asks for a price concession, what's the approval path and the margin floor?" Ties directly to his pushback.
  5. To Deepa: "What would make the first 90 days a success for you?" Reciprocity question for a panel.

## 8. Prohibited claims (not coached)

| Not coached | Basis | Honest form |
|---|---|---|
| Closed or sold £4M | Inflated form of F5 | "roughly £4M of influenced revenue", at its own scope |
| Sold into rail or to train operators | Stated negative, F1 | "I haven't sold into rail." |
| Carried a quota | Stated negative, F4 | "I haven't carried a direct quota." |
| Knows how train operators decide or buy | Overreach from F2 | "I know bus and light rail planning, from the consultant's side." |
| Any claim about Kelverton's partners, strategy or market report | No research ran; report not pasted | Say nothing about it until you have the report. |

## 9. Persona weights

- Ross (commercial, pressure): high on commercials; expect C1 to C2 early.
- Deepa (manager, prober): high on fit and 90-day plan; expect D1 to D2.
- Weighting is a judgement from the role title and the recruiter's note, not from research.

## 10. Sources

Research tier: L0. Four searches were sent (Kelverton Rail and operator partnerships; Ross; Deepa; UK rail operator scheduling market) and every one was refused by the permission prompt. No pages were fetched.

| Target | Status | What it moved, or would have |
|---|---|---|
| Kelverton values | unavailable | Would have set the values cheat sheet; no section for it is included |
| Kelverton interview process | unavailable | Would have fixed the persona weights and round structure |
| Kelverton strategy / recent news | unavailable | Would have grounded the POV in their current priorities |
| Interviewer public footprint (Deepa, Ross) | unavailable | Would have added the interviewer read and mirror points |
| Representative JD | unavailable | Would have turned the requirement rows from [grounded] to [inferred]-or-grounded |

## 11. Upgrade menu

- The full JD → F-rows gain their requirement quotes, and the gate question in the message can be answered from it.
- The market report's main findings (paste them) → the POV theses get checked against the company's own framing and the strategy row can be filled.
- Web research granted → Kelverton's values, strategy and both interviewers' public footprint, and personalised reverse questions.
- A recruiter email asking what the panel expects beyond the POV → tighter coverage of the Q&A.
- A dossier (tuesday-dossier.md) → the gap rows and the commercial objection get verified evidence and stricter prohibited claims.
