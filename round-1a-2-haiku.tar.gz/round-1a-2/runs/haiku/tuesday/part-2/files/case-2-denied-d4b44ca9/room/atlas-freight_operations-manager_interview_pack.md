# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager. Company: Atlas Freight (regional logistics, 800 employees, as you described it). Interviewer: not given. Round: not given; this pack assumes a hiring-manager round and says so below.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what it scores: EXP (your past, tested for precision), JD (the listed job), CASE (a live problem, no past claim), CO (company knowledge), VAL (values; none detected here).
- Guidance is scaffolding for a spoken answer, not a script. Each answer should run 90 to 120 seconds.
- Answer slots are instructions for the interview. They say what to do when a question reaches past what your material shows, and they always allow the honest answer.

## Fit snapshot

Requirements are quoted from the JD text in your message. Evidence is quoted from your message only. No research ran (see Sources), so nothing here comes from outside sources.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | low | [grounded] | discovery | Your material refers to a single site ("the site's") and does not use the word terminal. Multi-site daily running is not shown. Answer slot: if you have run daily operations across more than one site, say how many and how you kept them on one daily rhythm. If you have run one, say so, and say how you would set the daily rhythm across four. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The quote carries pick accuracy, not on-time performance or cost per shipment. Say it at its own scope: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time or cost per shipment in any role, say what and how; if not, say so and say what you would measure first. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The quote is 3 supervisors. Say the 3, and say no larger number. Answer slot: how you lead those 3 day to day, and what you would change at 12. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" — your message; "senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material gives 7 years in operations and a current leadership role. It does not say how many years you have led people. Answer slot: say how many years you have led people, in your own words. If that is fewer than your years in operations, say so. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel" — your message | low | [grounded] | transferability | Excel is named; no report you built or used is named. Answer slot: name a report or spreadsheet you used to track operations, what it tracked and who read it. If there is none, say so. |
| F6 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" — your message | none | [grounded] | capability | You stated the absence. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" — your message | medium | [grounded] | none | The quote reaches the requirement in its own terms. Expect a probe on which project you applied the belt to; that is the slot in E2. |
| F8 | "across 4 sites" (JD; the JD states no site locations or travel) | none given | none | [grounded] | hard_gate | Your material does not establish whether you can work at each of the four sites. Surfaced, not bridged. The one question this gate allows is asked in the message that presents this pack. |

## Prohibited claims

Built locally from the fit snapshot, because no dossier was supplied. Each entry gives its basis and its honest form. Nothing in the banks asserts these.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran daily operations across four sites | Inflated form of F1 | Your sentences at their own scope: "7 years in warehouse and distribution ops", "ran the site's peak-season surge plan two years running". Pack observation: the material refers to one site. |
| Led 12 supervisors | Inflated form of F3 | "currently a senior shift manager over 3 supervisors" |
| Improved on-time performance or cost per shipment | Inflated form of F2 | "cut mis-pick rate 40% by redesigning the pick path", with the metric named |
| Built Power BI reports or dashboards | Sourced entry: F6 stated negative | "I haven't used Power BI." Plain acknowledgment, no slot. |
| Five years of operations leadership | Inflated form of F4 | 7 years in operations, and the leadership years left as B2's slot. The material does not give that number. |

## Persona weights

No loop source was found and no interviewer is named, so the loop uses the generic fallback: flat weights, said plainly. The relationship prior for a hiring-manager round is the one used.

| Persona | How it shows up in this loop | Likelihood and reasoning | Depth | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Live problems on the four-site, twelve-supervisor job | High. A hiring manager is buying capability, and the JD is mostly operating problems. | 4 | Clarify, then objective, approach, metrics, risks. Think aloud. |
| Skeptic | The step from 3 supervisors to 12, and the missing Power BI | High, and this is the persona that carries the highest-ROI objection (B1). Fit rows F3, F4 and F6 are the thinnest in the material. | 4 | Rehearse B1 until it is plain. Bridge from the 3 you lead today plus a concrete plan. |
| Data-Driven Prober | The 40% figure and the reporting line | Medium-high. A single headline number gets probed to its assumptions. | 3 | Say how it was counted if you know. If you do not, say so, and name the weakest assumption you can. |
| Pressure | A challenge on why you over a stronger internal candidate | Medium. Common for a hiring manager with a thin-looking CV line. | 3 | Pause, restate, anchor in your own sentences. Hold through two follow-ups before any concession. |
| Conversational | A casual opener that asks about the JD's plus and your tools | Medium-low. Casual questions are still scored. | 2 | A 90-second arc. Treat the plus-skill question as scored. |
| Peer Evaluator | Seams with adjacent sites or teams | Low. Only if the round is a peer conversation. | 2 | Seam principles, not invented facts about their team. |

Total: 18 questions in the banks, inside the 18 to 26 range.

## Question banks

Provenance lists every sentence of yours that the guidance rests on. A `[generic]` or `[grounded]` label on a question with no past claim carries the label alone.

### A. Case/Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "One of the four sites is behind on on-time performance. Where do you start?" | CASE | [generic] | Clarify what behind means and against what target. Then the objective, the segment that is failing, the approach, the metric, and the risk. Name one premise you would test before acting. No claim about your past. | Live problem from the on-time line of the JD. Generic because it is a pattern, not a fact about Atlas Freight. |
| A2 | "Cost per shipment is up while volume is flat. What do you check first, and what would change your mind?" | CASE | [generic] | Name the cost denominator before any driver. Then the two or three drivers you would test in order. No past claim. | Cost-per-shipment line of the JD. |
| A3 | "Twelve supervisors across four sites, and peak is six weeks out. Sketch the first two weeks." | CASE | [grounded] "lead a team of 12 supervisors" — JD | Clarify who the twelve are and which sites are weakest before you plan. Then a plan in order. This is a plan, not a record. | Tests the team-size requirement by asking what you would do, not what you did. |
| A4 | "What would you need to know about one of our sites before you changed its daily plan?" | JD | [grounded] "Own daily terminal operations across 4 sites" — JD | Name three things you would ask for before any change: the volume profile, the labour plan, and the current failure points. Say you would ask before you change anything. No past claim. | Tests site-level thinking you have not shown yet (F1). |

### B. Skeptic (4). Deepest rehearsal: B1.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role leads twelve supervisors across four sites. You lead three today. What makes you ready for that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message; "lead a team of 12 supervisors" — JD | The highest-ROI prep in this pack. Open on the three you lead today, in your own words. Concede the step plainly: twelve is a bigger team than the three you lead. Then the first thing you would do in the first thirty days. Hold through two follow-ups by returning to the three you lead and the plan. Answer slot: the plan is yours to state; there is no past claim to make here. Never say you have led twelve. | F3 is the thinnest requirement that matters most, and this objection will come in some form. |
| B2 | "How many years have you led people, as opposed to working in operations?" | JD | [grounded] "7 years in warehouse and distribution ops" — your message; "senior shift manager over 3 supervisors" — your message | Answer slot: say the number of years you have led people, in your own words. If it is fewer than your years in operations, say that plainly. Do not round up. | F4: the 5-plus-years line is met only if the leadership years are. The material does not say. |
| B3 | "Your 40% came from pick accuracy. This role is measured on on-time performance and cost per shipment. What's the link?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Say the link you actually believe, in your own words. If you did not measure it, say so. Answer slot: if you tracked on-time or cost per shipment, say what and how; if not, say what you would measure first. Hold through two follow-ups by returning to the pick-path result. | F2: the bridge from accuracy to the JD's metrics is a belief, and a belief must be labelled one. |
| B4 | "Power BI is part of the reporting. Where are you on it?" | JD | [grounded] "never used Power BI" — your message | Plain acknowledgment: "I haven't used Power BI." Then how you would learn it, as a plan with a timeframe you can keep. No slot. | F6: the one stated gap. The honest answer is the whole answer. |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Answer slot: this is your figure. Say how it was counted, over what period, against what baseline, and which part of the result was yours. If you do not know how it was counted, say so plainly. Never supply a method you did not use. | Defend-the-number slot for your headline figure (F2). |
| C2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Name the weakest assumption in your own words, before the interviewer does. If you cannot name one, say you do not know how the figure was counted. Do not invent an assumption to sound thorough. | Weakest-assumption move. |
| C3 | "Tell me about a report or spreadsheet you have used to track operations. What did it track?" | EXP | [grounded] "solid Excel" — your message | Open prompt. Answer slot: name the report or spreadsheet, what it tracked, who read it and how often. If none comes to mind, say so plainly and say which one you would build first. | F5: the reporting line is the Excel side of the requirement. |

### D. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate who already knows the network?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message; "ran the site's peak-season surge plan two years running" — your message | Pause before answering. Restate the question in your own words. Anchor in those three sentences, each at its own scope. Hold through two follow-ups. Do not claim knowledge of the network you do not have. | Pressure stem. The answer rests only on what you have already said. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Hold-then-concede. Hold the part your sentence states: the result came from redesigning the pick path. Then concede specifically whatever others did, if that is true, and say which part was yours. Do not fold on the core claim to restore harmony. | Attribution probe. This question exists to catch inflation; an honest hold is the rehearsal. |
| D3 | "If peak volume came in thirty percent above plan, what would you change first?" | CASE | [generic] | Time-box it: state the first decision and the trigger that prompts it, then one risk. A plan, not a record. | Pressure delivery of a live problem; no claim about your past. |

### E. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message; "ran the site's peak-season surge plan two years running" — your message | A 90-second arc with four beats, each one a clause you have already said: operations, shift manager, the pick path, the peak plan. No further beats. | Casual opener, scored like the rest. |
| E2 | "What are you actually playing with in Lean and Six Sigma these days?" | JD | [grounded] "green belt certified" — your message | Say the belt in your own words. Answer slot: if you applied it to a project, name the project and what you did; if you have not applied it yet, say so and say what you would apply it to first. | F7: a plus-skill asked casually is still scored. |

### P. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not facts about their team. For a disagreement story, use a selection scaffold: pick a time you disagreed with a peer and it was resolved; if none comes to mind, say so plainly and say how you would handle it. | Peer prior. No disagreement story is in your material, so none is claimed. |
| P2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time credit was shared across teams. If none comes to mind, say so plainly and say how you would handle it. | Peer prior; the honest branch is the answer. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A4, B1; the location gate (F8) is asked in the message |
| Drive on-time performance and cost-per-shipment down | A1, A2, B3, C1 |
| Lead a team of 12 supervisors | A3, B1 |
| Build reporting in Excel/Power BI | C3, B4 |
| 5+ years operations leadership required | B2 |
| Lean/Six Sigma a plus | E2 |

## Reverse questions

Each one has a reason it lands. No interviewer profile exists, so no question is tied to an interviewer's path, and the reciprocity question is not needed (the relationship is not peer).

1. "What would a strong first 90 days look like in this role?" Why it lands: it shows you are planning for the job, not for the interview.
2. "Which of the four sites is furthest from its on-time target right now, and what does the team think is driving it?" Why it lands: it treats the JD's metric as a daily working tool.
3. "How is cost per shipment defined, and is it the same definition at all four sites?" Why it lands: a metric-discipline question you can own, and the answer shows you how the numbers are kept.
4. "What reporting do the site leads use day to day, and where do they wish it was better?" Why it lands: it turns the Power BI line into their real pain, not the tool.
5. "How will the twelve supervisors be spread across the four sites?" Why it lands: it shows you think in structure, and the answer tells you the load.
6. "What has been hardest for the supervisor team in the last year?" Why it lands: it brings out risks before any offer exists.

## Sources

Provided documents: your message only, containing the JD text and your background. No link was given and none was read.

Searches and fetches were sent as follows. Each returned an error: the search tool asked for permission and was not granted. None was retried.

- "Atlas Freight company values": refused
- "Atlas Freight interview process operations manager": refused
- "Atlas Freight regional logistics strategy news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Would have set the values cheat sheet and the VAL questions. Without it, no values round is detected, so neither is built. |
| 2. Atlas Freight interview process, operations | unavailable | Would have named the loop's rounds and set the persona weights. Without it, the generic fallback is used and stated above. |
| 3. Atlas Freight strategy and recent news | unavailable | Would have grounded the CO and CASE questions in current strategy. Without it, A1 to A3 and D3 are `[generic]`. |
| 4. Interviewer name and Atlas Freight | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD in your message fixes the fit snapshot and the JD-tagged questions. |

Because research did not run, every claim about Atlas Freight in this pack is either your own words or a label `[generic]`. Nothing about the company's values, loop or strategy is assumed.

## Upgrade menu

- Round type and who you meet (asked in the message) → sets the persona weights for the actual round, and may drop or add banks
- Whether you can work at all four sites (asked in the message) → resolves the location gate F8, and settles whether the gate is met
- The full posting text, not the summary → turns the JD-tagged rows from summary wording into the employer's own words, and may add requirements the summary left out
- Your green belt certificate → raises F7 from medium to high, since the credential becomes inspectable
- A report or spreadsheet you have used or built (name, what it tracked) → raises F5 from low to medium and gives C3 real material to tell
- How the 40% was counted (period, baseline, count method) → gives C1 and C2 material you can repeat; without it they stay answer slots
- The interviewer's name → interviewer read, persona weights from their public footprint, and a tailored reverse question
- The recruiter's prep email → coverage of any pre-declared deliverable or case, and the process details
- Prep time before the interview → a prioritized prep triage, so you know what to drill first
- Working WebSearch access → the three searches above can run at L1: Atlas Freight's values page, its interview process and its recent news, each replacing an `[generic]` or `unavailable` row
