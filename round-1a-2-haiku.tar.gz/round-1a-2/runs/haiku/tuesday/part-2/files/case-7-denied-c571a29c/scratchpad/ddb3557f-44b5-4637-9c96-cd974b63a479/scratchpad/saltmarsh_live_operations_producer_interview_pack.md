# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager (not yet confirmed). Format: 60 minutes. Structure: unknown beyond that.
Changes in this version: first build.

## How to use + type key

Personas are how a question arrives. Types are what it scores.

- **CASE**: live problem from the role, scored on structure
- **EXP**: your past work, scored on whether it survives scrutiny and what was actually yours
- **JD**: a stated requirement from the posting
- **CO**: company and strategy knowledge (not covered; see Sources)
- **VAL**: values alignment (not covered; no values round detected)

Guidance is scaffolding, not a script. Say the answers in your own words.

## Research status

Web search was refused in this session. Saltmarsh's values, interview process, strategy and Tobias's public footprint are **not established**. The pack uses none of them. Everything about the company is marked `[generic]`.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one title and content drops, not two titles and live events. Words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned across more than one title, say which and what you decided; if you did not, say so and say how you would take on the second. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Never led a team" (your message) | none | [grounded] | discovery | Your material does not show coordinating these teams, and the stated absence of leading a team does not settle whether you coordinated them. Words: "I haven't led a team." Answer slot: if you got several teams to act on a shared update without line authority, describe it in your own words; if not, say so and say how you would set up that coordination. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | transferability | Retention reporting is adjacent to a post-event review and KPI ownership; the bridge should not be stretched. Words: "I presented the monthly retention numbers to the studio head." Answer slot: say whether you set those KPIs or were given them, and whether any post-event review was yours to run. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches retention in role terms; the bridge rewords only that quote. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you know how those numbers were counted, say so; if not, say that plainly. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote already reaches the requirement. Limited inspectable proof, so expect a probe. Lead with it in the quote's own terms: "I wrote the release checklist our QA team still uses." Do not say you managed QA sign-off. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | discovery | Years fit. Your material does not say whether the puzzle title ran on continuous content after launch. Words: "4 years as an associate producer at a puzzle-game studio." Answer slot: if it did run on continuous content, describe the cadence in your own words; if not, say so. This requirement is an experience tier, not a gate. |
| F7 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement. Lead with the calendar and its two years. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | A checklist is written work but not evidence of writing for a wider audience, and no writing sample was supplied. Answer slot: name a document you wrote that others relied on. If you have a sample, offer it. |

Stated negatives used above: "Never led a team" (F2). Not a JD requirement, so no row: "never worked on a game with in-app purchases." If Tobias raises monetization, the sourced line is "I haven't worked on a game with in-app purchases." The pack does not raise it itself.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar across two titles | Inflated form of F1 | The quote at its own scope: one title, weekly content drops, two years. Analysis, not words for you: your material says one title. |
| Led design, art, engineering and community teams | Inflated form of F2 | "I haven't led a team." |
| Owned the KPIs and post-event reviews | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." |
| Live-service experience | Inflated form of F6 | "4 years as an associate producer at a puzzle-game studio." Analysis: your material says puzzle-game studio, not live-service. |
| Managed QA sign-off | Inflated form of F5 | "I wrote the release checklist our QA team still uses." |
| Worked on an in-app purchase game | Negative you stated | "I haven't worked on a game with in-app purchases." |

## Persona table

Weights come from relationship priors (hiring manager: Case/Strategist and Skeptic). No interviewer profile was found, so there is no interviewer adjustment. No loop source was found, so the archetype fallback is Generic: flat weights, values round not assumed. Depth follows weight.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the calendar and the post-event review | Top (5 questions). A hiring manager is buying the job's live problems. | Clarify, then structure, then metrics, then risks. Think aloud. |
| Skeptic | Probes the one-title scope, leadership, and presenting vs owning | Co-top (4). Gaps F1, F2 and F3 are where the objection will land. | Rehearse the most predictable objection until it is boring. Concede the gap plainly. |
| Data-Driven Prober | Asks how retention was counted and what you own | Mid (3). Your retention line is short and will get questions. | Say what you know about how the numbers were counted, and say plainly when you do not know. |
| Pressure | Time-boxed challenges on the release checklist and leadership | Mid (3). Composure test. | Pause, restate, hold through two follow-ups, then concede the specific point. |
| Conversational | Friendly opener, casual questions about live games | Mid-low (3). Casual questions are still scored. | Keep a 90-second arc ready. Treat casual questions as scored. |

## Question banks

### Case/Strategist (weight: 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you would plan the live-events calendar for two titles for next quarter. What do you need to know first?" | CASE | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Clarify first: each title's current cadence, team capacity, QA windows, what the KPIs are. Then structure: objective, cadence, event slots, dependencies on the release checklist, post-event review. Your own calendar work can be mentioned only as F1's quote. | Covers the JD's headline line. Presupposes nothing about your past. |
| A2 | "A retention metric on one title drops 20% in the week after an event. Diagnose it." | CASE | [grounded] "comfortable with player-retention metrics" (JD) | Ask what changed: the event, build, cohort, region, platform, any concurrent campaign. Split by cohort. Check instrumentation before blaming the event. Name the first thing you would check. | Retention is a stated requirement. The number is theirs, not yours. |
| A3 | "Two teams disagree on whether an update ships Thursday. Walk me through the decision." | CASE | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Use the release checklist and QA status as the evidence, weigh community risk, name who decides, escalate, write the decision down. Answer slot: if you resolved a cross-team disagreement on an update, say what it was and what you decided; if you have not, say so and give how you would run it. | Covers F2, which has no story in the material. |
| A4 | "What would you put in a post-event review, and which KPIs would you report?" | CASE | [grounded] "own the post-event review and the KPIs it reports" (JD) | Goal, what shipped, reach, retention, any monetization metric if it applies, baseline comparison, what to change. Ask which KPIs they already track. | Covers the JD's review-and-KPI line, which has no story (F3). |
| A5 | "What would you change about the release process in your first 30 days?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Start from the checklist you wrote. Name one thing you would change, why, and how you would check it with QA. Do not describe QA's agreement as if you had it. | Covers the release-checklist line with your own artifact. |

### Skeptic (weight: 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've run one title's calendar. This role covers two. How do you plan for the second?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | **Highest-ROI prep.** Hold on the calendar you ran for two years. Concede the one-title scope in one sentence. Answer slot: if you planned across more than one title, say which and what you decided; if not, say so and say how you would split time and priorities across two. Follow-up levels: three. | F1 is the likeliest objection and the material is thin there. |
| B2 | "I don't see team leadership in your background. This role coordinates four teams without managing them. How do you get them to move?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD); "Never led a team" (your message) | Plain acknowledgment: "I haven't led a team." Then the answer slot: describe a time you got teams to act on a shared update without line authority, if you did, in your own words; if not, say so and say how you would set up the coordination. | F2 is a stated gap, so the acknowledgment has a source. The slot stays inside what you did. |
| B3 | "You presented retention numbers. Did you own the KPIs, or present someone else's?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD); "Presented the monthly retention numbers to the studio head." (your message) | Hold on "presented." Answer slot: say whose numbers they were, which ones you set and which you were given. If you owned none of the KPIs, say so. | F3 is adjacent, and this question tests the difference between presenting and owning. |
| B4 | "Your title was a puzzle game. Did it run on continuous content after launch, or was it a one-off release?" | JD | [grounded] "3+ years producing live-service games or apps" (JD); "4 years as an associate producer at a puzzle-game studio" (your message) | Answer slot: if there was continuous content, describe the cadence in your own words; if not, say so and say what you did run. | F6: the years fit, but the live-service part is not in your material. |

### Data-Driven Prober (weight: 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through one cycle of the content-drop calendar: how did you decide what went in each week?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Story: the weekly cadence, what you decided, what others decided. Answer slot: if you set the priorities, say how; if the calendar was set by others, say so. | F7's evidence, tested for what was yours. |
| C2 | "Which step on your release checklist does QA rely on most, and how do you know?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Name the step, how you know QA relies on it, and where you did not check. | Tests F5 without presupposing defect counts. |
| C3 | "Walk me through how the monthly retention numbers were counted. If you didn't own the counting, say so." | EXP | [grounded] "comfortable with player-retention metrics" (JD); "Presented the monthly retention numbers to the studio head." (your message) | No figure was given, so no defend-the-number slot applies. Say what you know about the counting, and say plainly if you do not. | F4: the depth of your retention work is the unknown. |

### Pressure (weight: 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run live events on a bigger title?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Pause. Restate. Anchor in the calendar. Hold through two follow-ups. Concede that you have not run two titles, without folding on the calendar. | Composure test on F1. |
| D2 | "That's a checklist, not a process. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Hold on "wrote." Concede what is shared with QA. Do not fold on the authorship. | Tests whether you can own the artifact without inflating it. |
| D3 | "You've never led a team. Why should we trust you to coordinate four of them?" | JD | [grounded] "Never led a team" (your message); "coordinate design, art, engineering and community teams on each update" (JD) | Plain acknowledgment: "I haven't led a team." Hold on what coordination you did do, if your material carries it. Concede the authority gap without folding. | F2 under pressure. |

### Conversational (weight: 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | 90-second arc: studio, the calendar you ran, the checklist you wrote, the retention reporting, why live operations. | Rapport opener. Casual, still scored. |
| E2 | "What are you playing right now, and what would you change about how its events run?" | JD | [generic] | Name a live game you play and what its events do, in your own words. Do not claim knowledge of Saltmarsh's titles; none was researched. | Casual probe of live-ops interest. |

Question total: 17. Requirement coverage:

| Requirement | Covered by |
|---|---|
| Live-events calendar, two titles | A1, B1 |
| Coordinate design, art, engineering, community | A3, B2, D3 |
| Post-event review and KPIs | A4, B3 |
| Release checklist with QA | A5, C2, D2 |
| 3+ years live-service | B4 |
| Content calendar | C1 |
| Player-retention metrics | A2, C3 |
| Clear written communication | None, and why: the interview is spoken. A writing sample is in the upgrade menu. |

## Reverse questions

Each one, with why it lands:

1. "What does success look like for the live calendar on both titles in six months?" Frames your plan around their KPI.
2. "How is the post-event review run today, and who owns the KPIs it reports?" Asks them to say how the JD's line works in practice.
3. "Where does the release checklist break down most often with QA?" Shows you have thought about your strongest artifact's weak points.
4. "How is the team set up around the two titles, and who would I coordinate with day to day?" Clarifies the coordination requirement.
5. "How does live operations work with the monetization model on these titles?" Surfaces the in-app purchase question without stating your gap.

## Sources

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Refused: web search permission was not granted. Values not established; no values cheat sheet. |
| 2. Saltmarsh interview process, live-ops producer | unavailable | Refused. Loop not established; Generic archetype used (flat weights, no values round assumed). |
| 3. Saltmarsh strategy and recent news | unavailable | Refused. CO questions absent; the strategy brief would have moved them. |
| 4. Tobias Wrenfield, Saltmarsh | unavailable | Refused. No interviewer read; personas use relationship priors only. |
| 5. Representative JD | skipped | The JD supplied fixes the fit snapshot and the JD-tagged questions. |

Research tier: L1 — searches 4 of 6 (all refused), fetches 0 of 2.

Queries sent, all refused: "Saltmarsh Games values"; "Saltmarsh Games interview process live operations producer"; "Saltmarsh Games mobile studio news strategy"; "Tobias Wrenfield Saltmarsh Games Head of Live Operations".

Provided documents: the job description and background in the invitation message.

## Upgrade menu

- Permission to run web search, or a pasted copy of Saltmarsh's values page and recent news on the two titles → unlocks CO questions and a values check, and moves the `[generic]` rows to grounded.
- Tobias's public profile or talks, pasted → a tailored reverse question and persona weights from their footprint.
- A writing sample you produced (a checklist, a postmortem, a doc others used) → moves F8 from low to medium and gives the written-communication requirement a question.
- The hour's agenda (conversation only, or a case, presentation or panel) → a graded-deliverable section if one is declared.
- A `tuesday-dossier.md` would add your verified evidence and the gaps this prep exposes; it is optional.
