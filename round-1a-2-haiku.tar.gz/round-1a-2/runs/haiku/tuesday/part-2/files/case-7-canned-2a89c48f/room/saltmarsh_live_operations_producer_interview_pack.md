# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Role:** Live Operations Producer. **Company:** Saltmarsh Games. **Interviewer:** Tobias Wrenfield, Head of Live Operations. **Round:** the Outage Hour, one 60-minute interview with the hiring manager (careers page, Sources). I am assuming Tobias is that hiring manager; the careers page says so of the round, and the Step 1 question below asks you to confirm it.

First version. No earlier version exists.

## 1. How to use, and the type key

Personas are how a question arrives. Types are what it scores.

- **CASE:** live problem, delivered live. Structure and reasoning, not a right answer.
- **EXP:** your past work. Whether what you claim survives scrutiny, and what was actually yours.
- **JD:** the posting's own requirements, including the gaps.
- **VAL:** published company values, asked as a behavioral conversation.
- **CO:** company knowledge. Thin here, because strategy research was one snippet only (Sources).

Guidance is scaffolding for a spoken answer, not a script. Speak each cell in 90 to 120 seconds, and only about what you did.

## 2. Prep triage

Prep time: about one day, to Friday. The whole interview is one 60-minute Outage Hour, so spend the time in this order:

1. **A1, the outage tabletop.** This is the highest-return prep in the pack, because the careers page confirms a live-incident tabletop is the core of the round and your material says nothing about live incidents. Say the first fifteen minutes aloud, three times, in under two minutes each.
2. **B1 and B2, coordinating without authority.** The JD asks you to coordinate four teams you do not manage, and you have said you have never led a team. Rehearse the plain sentence and the honest branch until they come out evenly.
3. **A4 and A5, the post-event review and the checklist call.** These are the two JD duties with no direct story from you. Rehearse the plan, not a past.
4. **C1 to C3, the values.** Each value gets its honest branch, and C3 gets your checklist sentence exactly.
5. **Verify before Friday.** Open the Larkspur page and the GDC talk listing (Sources). Do not cite either unless you have read it.

Everything else is insurance.

## 3. Fit snapshot

Requirements are the JD's own words. Evidence is quoted from your message, unless marked otherwise.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title's weekly content-drop calendar, not a live-events calendar across two titles. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you planned any part of a calendar across more than one title, say what and how; if you did not, say so and say how you would keep two titles on one calendar. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | transferability | The one cross-team artifact you describe is with QA. Your material does not show design, art, engineering or community. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you got a team to act on work you did not manage, say how; if you did not, say so and say how you would set up the coordination. |
| F3 | "own the post-event review and the KPIs it reports" (JD, KPI half) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Presenting numbers is not owning the KPIs. Words: "I presented the monthly retention numbers to the studio head." Answer slot: say which numbers went into that presentation; if you did not choose them, say so. |
| F4 | "own the post-event review and the KPIs it reports" (JD, post-event review half) | none given | none | [grounded] | discovery | Your material says nothing about a post-event review. Answer slot: if you have run a post-event review, say what it covered; if you have not, say so and say how you would structure one. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | The quote reaches the requirement. Caveat: the words are "wrote" and "still uses", and "manage" is the JD's. Expect a probe on who ran the checklist day to day. The checklist is an inspectable artifact; bring it. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Four years meets the length requirement, and length is not a gate. Your material does not say "live-service". Words: "I was an associate producer at a puzzle-game studio for four years." Answer slot: say how the main title's content and events were released, in your own words; a probe on whether that model was live-service is likely. |
| F7 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | The quote reaches the requirement directly. Caveat: the calendar exists and has not been inspected; bring a copy if you can. |
| F8 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Caveat: presenting a metric is not defining it; expect a probe on how retention was defined. |
| F9 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | presentation | A checklist other teams follow is written work, which reaches the requirement in other terms. The bridge only rewords that quote. Confidence is low: one artifact, and clarity itself is not shown. |
| F10 | none in the JD text you gave | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | The JD text you gave does not mention monetization. If the interviewer raises it, the plain acknowledgment is: "I haven't worked on a game with in-app purchases." |
| F11 | none of its own; raised by the coordination line in F2 | "Never led a team" (your message) | none | [grounded] | capability | A gap you stated. Plain acknowledgment: "I haven't led a team." Do not add a team you led. |

Caveats on the table. F4 is the only row with no evidence at all, so it is the one a Skeptic or Prober can open with. F10 and F11 are gaps you named yourself; they are yours to say, and the pack will not say them for you unless a question raises them.

## 4. Prohibited claims

Each entry names its basis. The honest form is the quote, at its own scope, with any limit stated as the pack's observation.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a two-title events calendar | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title." Your material says one title's calendar, not two. |
| Managed the release checklist | Inflated form of F5 | "I wrote the release checklist our QA team still uses." |
| Coordinated design, art, engineering and community | Inflated form of F2 | The F2 quote at its own scope. No slot names this wording. |
| Owned the post-event review and its KPIs | Inflated form of F3 and F4 | "I presented the monthly retention numbers to the studio head." Post-event review: answer slot only. |
| Has live-service experience | Inflated form of F6 | "4 years as an associate producer at a puzzle-game studio." |
| Has led a team | Sourced negative, F11 | "I haven't led a team." No slot. |
| Has worked on in-app purchases | Sourced negative, F10 | "I haven't worked on a game with in-app purchases." No slot. Use only if raised. |

Live incidents are not on this list. Your material is silent on them, so the outage question is an answer slot, not a prohibited claim.

## 5. Reading the interviewer

Public footprint only, from a search listing for Tobias Wrenfield (not opened; see Sources).

- **Career pattern:** listed as Head of Live Operations at Saltmarsh Games, and, per the listing, previously a QA lead at a console studio.
- **Published talk:** "Patch Notes Are a Promise" (GDC 2026). Per the listing, his argument is that "a live team is judged by how often its patch notes describe what actually shipped."
- **Practical implications:**
  1. Expect release probes: what the notes said, what shipped, and who checked the difference. Keep answers to F5 exact.
  2. The talk's theme matches the "Ship the Patch Not the Promise" value. Values answers that stay on what shipped will land with him.
  3. Do not assert the talk's contents beyond the listing. Open it before Friday, or do not cite it.
- **Mirror opportunity:** a release checklist (F5) and his QA background touch the same work. Offer this only if the QA background is confirmed. It is not a shared jump, because your material has no QA-to-live-ops move to pair with his.

## 6. Persona table

Relationship prior: hiring manager, so Case and Skeptic lead. The careers page documents the loop: one 60-minute Outage Hour, which is a live-incident tabletop followed by a values conversation. That puts Case, Values and Skeptic in one session, and the loop is established by a loop source, so no archetype fallback applies. Peer does not apply, since Tobias is the head of the function, not a peer.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Case / Strategist | The outage tabletop and live problems on the actual calendar | High. The careers page names the tabletop as the core of the round. Weight 5. | Clarify, then scope, then decide, then communicate. Name the decision rule before the steps. | A1 to A5 |
| Skeptic | Coordination without authority, the missing team, one studio's record | High. Hiring managers buy capability and probe gaps, and F2, F10 and F11 are the gaps. Weight 3. | Hold the plain sentence. Then give the principle for the gap, not a past. | B1 to B3 |
| Values / Behavioral | The values conversation that closes the Outage Hour | High. The careers page documents it. Weight 3. | One value, one honest branch. Do not supply an ending the material does not carry. | C1 to C3 |
| Data-Driven Prober | Precise attribution of the retention numbers and the calendar | Medium. The JD names retention metrics, and F3 and F8 have no defined method. Weight 3, up from flat on the talk's "what shipped" theme. | Name the weakest assumption in your own words, or say plainly you did not set the definition. | D1 to D3 |
| Pressure / Stress | Time-boxed challenge to "why you" | Low to medium. Priors for a hiring manager are not dominant. Weight 2. | Hold the calendar sentence, then concede the specific part you did not set. | E1, E2 |
| Conversational / Rapport | An opener that is scored anyway | Low. Weight 2. | A 90-second arc from four quoted sentences, in order. | G1, G2 |

## 7. Question banks

Provenance comes before guidance. Every candidate sentence a claim rests on is quoted in that row's Provenance cell.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's 20:40 on the second evening of a live event. Players report currency is being granted twice, and telemetry agrees. Walk me through your first fifteen minutes." | CASE | [generic] | Clarify first: which players, which event, what the telemetry measures. Then decide whether to pause the grant, roll back or ship a fix, and say who makes that call. Put owners on the work: engineering on the fix, QA on verification, community on the message. Say what players see, and say only what is built. Speak the decision rule before the steps. No claim about your past. | Highest-ROI prep in this pack. The round is a live-incident tabletop (careers page), and your material is silent on incidents, so this is where the pack is thinnest. [generic] because the scenario is an illustration, not the company's. |
| A2 | "Day-seven retention dropped after the last content drop. Diagnose it." | CASE | [grounded] "comfortable with player-retention metrics" (JD) | Clarify the cohort and what changed: the event, the reward, a bug, the timing. Split by new and returning players and by platform. Rank causes by how cheaply each can be checked. | The JD names retention, so a retention diagnosis is the likeliest live problem. No claim about your past. |
| A3 | "Two of our mobile titles, one events calendar. What do you need to know before you lock next quarter?" | CASE | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Clarify each title's cadence, what each event depends on (engineering, art, QA capacity), what is already committed, and which event wins when two clash. Then state a principle for clashes. No claim about your past. | Covers the JD's calendar duty, which F1 is thin on. |
| A4 | "Walk me through how you would run a post-event review, from the first data pull to the actions." | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Set the target KPIs before launch. Pull the data. Separate signal from noise. Map each finding to the decision it feeds. Name owners and a date. A plan, not a past. | Covers F4, the row with no evidence, by asking for a plan the candidate can actually give. |
| A5 | "Your release checklist is the gate before an update. QA says the build is not ready, and the event starts in four hours. What do you do?" | CASE | [grounded] "manage the release checklist with QA" (JD) | Decide with QA, not around them. Ask what the failing item blocks, what can be gated or cut, who signs off, and what players are told. Speak the call and its reason. | Puts the checklist duty into a live decision. No claim about your past. |

### B. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you coordinated people you did not manage." | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Selection scaffold: pick a time you needed a team that did not report to you: a named update, the teams, the one thing each needed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the QA release checklist: "Wrote the release checklist our QA team still uses." Then say how you would set coordination up for the four teams. | F2 is the thinnest coordination evidence. The open prompt asks for an instance and supplies none. |
| B2 | "You haven't led a team. Who on those four teams would take direction from you?" | JD | [grounded] "Never led a team" (your message); [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Hold: "I haven't led a team." Then answer the principle: how you would earn direction from teams that do not report to you. Do not describe a past team. Concede the gap in those words. | F11 is the gap the Skeptic is most likely to open with. The question presupposes only the negative you stated. |
| B3 | "Your experience is one puzzle-game studio. Why would mobile live-service work suit you?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message); [grounded] "Wrote the release checklist our QA team still uses" (your message); [grounded] "Presented the monthly retention numbers to the studio head" (your message); [grounded] "never worked on a game with in-app purchases" (your message) | Name what carries over, each in its quoted words: the content-drop calendar, the checklist, the retention presentation. If monetization comes up, the plain acknowledgment is: "I haven't worked on a game with in-app purchases." Then say what you would learn first. | F6 and F10. The question's "live-service" is the JD's word, which is a raising source; your material does not say it. |

### C. Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and what players needed pulled apart." | VAL | [grounded] "when the calendar and the players disagree, the players win" (values page); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Selection scaffold: pick a time a calendar commitment and what players needed came apart. Say what you moved, why, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the content-drop calendar, and how you would handle the conflict. | Maps to "Players Before Plans". Your material has no such conflict stated, so the answer must be a selection, not a story. |
| C2 | "Tell me about a time you told players something about an update before it was done." | VAL | [grounded] "we announce what is built, not what is hoped" (values page); [grounded] "Wrote the release checklist our QA team still uses" (your message) | Selection scaffold: pick a time you announced something and it had not shipped, or you held back a claim until it had. Say what you announced and what changed. If the checklist decided what got announced, say how; if it did not, say so. | Maps to "Ship the Patch Not the Promise". Your checklist sentence does not show announcement practice, so the slot stays open. |
| C3 | "Walk me through the release checklist you wrote: what it checks, and who on QA still uses it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Say what the checklist checks, in your words, and that QA still uses it. Do not claim it improved on anything. Answer slot: if you changed it after a release, say what and why; if you did not, say so. | Maps to "Leave the Build Greener", the only value your material touches directly. "Wrote" means you started it, not that you improved it, so the claim stays at that. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented: what did they measure?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Say what the numbers measured, in your words. Answer slot: say how retention was defined, and whether you chose that definition; if you did not, say so. Name the weakest assumption you know of before they do. | F3 and F8. The JD raises retention metrics, so a definition question is in scope. |
| D2 | "What is the weakest assumption in the retention story you presented?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Name it in your own words, or say plainly you did not set the definition. Do not invent a method to fill the gap. | No figure is quoted, so no defend-the-number rule applies. This is the attribution probe for a presentation. |
| D3 | "You ran the content-drop calendar for two years. Which parts did you set, and which were handed to you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Say which parts were yours, in your words. Answer slot: if any part was set elsewhere, say so plainly. Stay with what you ran. | F1 and F7. The attribution probe in its plainest form. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: what makes you the right hire over someone who has already run live events?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message); [grounded] "Wrote the release checklist our QA team still uses" (your message) | Hold: the calendar and the checklist, in those words. Concede: name one part of this role you have not done, in your own words. Do not say you have run live events. | Hold-then-concede. The second follow-up is the one that breaks a held claim you cannot back. |
| E2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Hold the sentence through two follow-ups. Concede the specific part you did not set. Do not fold on the core claim to restore harmony. | Pressure on attribution. Answer the second follow-up with the concession, not a new claim. |

### G. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message); [grounded] "Wrote the release checklist our QA team still uses" (your message); [grounded] "Presented the monthly retention numbers to the studio head" (your message) | A 90-second arc, using those four sentences in that order. Nothing else. | Casual register, still scored. The arc is four sentences you can defend. |
| G2 | "What are you playing right now on mobile?" | CASE | [generic] | Name one live-service title you actually play, and say what one of its events did for you. No claim about your material. | Casual question on a JD topic, still scored. |

**Totals:** 19 questions. Weights: Case 5, Skeptic 3, Values 3, Prober 3, Pressure 2, Conversational 2.

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A3, D3 |
| Coordinate design, art, engineering and community teams on each update | B1, B2 |
| Own the post-event review and the KPIs it reports | A4, D1 |
| Manage the release checklist with QA | A5, C3 |
| 3+ years producing live-service games or apps | B3. The years are met by F6. |
| Experience running a content calendar | D3, G1 |
| Comfortable with player-retention metrics | A2, D2 |
| Clear written communication | C3. Your material shows one written artifact only. Nothing else is coverable from it. |

## 8. Values / principles cheat sheet

Condition met: the careers page documents a values conversation inside the Outage Hour (loop source).

| Value (official name) | Working meaning (paraphrased) | Candidate's mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | No sentence carries a conflict. Selection scaffold ending in the honest branch: C1. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | F5 sentence ("Wrote the release checklist our QA team still uses") shows a checklist in use, not what it stopped. Selection scaffold ending in the honest branch: C2. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | F5 sentence shows you started the checklist. It does not show you improved it. Answer slot only: C3. |

## 9. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "When a title's event and the other title's event clash on the shared calendar, who makes that call, and how fast?" | Tests the seam between two titles. It shows you understand the calendar is the real product of this role. |
| R2 | "In the Outage Hour, which part do strong candidates usually miss?" | Shows you have thought about the format, not just the title. |
| R3 | "Your talk argues a live team is judged by how often its patch notes describe what actually shipped. How do you check that day to day?" | Ties to his public work. Only use this after you have opened the talk and confirmed it says that. |
| R4 | "The values say the players win when the calendar and the players disagree. Who here has overruled a calendar for players, and what happened?" | Turns a value into a conversation about a real decision. |
| R5 | "Who else will be in the room with you during the Outage Hour?" | Shows you know the format is theirs to run. Also answers the Step 1 question. |
| R6 | "What would make someone in this role successful at six months?" | Generic and safe. Asked to show you are planning for the job, not the interview. |

## 10. Sources

**Provided documents:** the JD text and your background, as given in your message.

**Searches and fetches:**

- "Saltmarsh Games values". Returned https://saltmarshgames.com/values. Fetched. Official values page.
- "Saltmarsh Games interview process live operations producer". Returned https://saltmarshgames.com/careers/interviewing. Fetched. Official careers page: the loop is "a recruiter call, then the Outage Hour: a single 60-minute interview with the hiring manager", and "There is no take-home."
- "Tobias Wrenfield Saltmarsh Games". Returned https://talks.gdconf.example/2026/patch-notes-are-a-promise. Search listing only, not opened. Used for the interviewer read, with the caveat in section 5.
- "Saltmarsh Games news 2026". Returned https://saltmarshgames.com/news/project-larkspur. Search snippet only, not opened. Snippet: Project Larkspur moves two titles to a season-pass model with one shared events calendar from February 2027, and retires per-title event teams in favour of a single live-ops group. The snippet is not a raising source for any question, so no bank presupposes it. The snippet names titles, and I have not confirmed they are the two titles in your JD.

**Target accounting:**

Research tier: L1, searches 4 of 6, fetches 2 of 2.

| Target | Status | What it moved |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet, section 8: three values by name, from the fetched page. |
| 2. Saltmarsh Games interview process | yes | Loop structure: one 60-minute Outage Hour, a live-incident tabletop then a values conversation. Persona weights follow it. |
| 3. Saltmarsh Games strategy and news | yes | One search, a Larkspur snippet only. Moved the CO framing, but no question presupposes it. |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Interviewer read, section 5, from a search listing only. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## 11. Upgrade menu

- Your release checklist, the document itself → F5 and F9 move to high confidence on an inspectable artifact; C3 and B1 gain a concrete sentence to build on.
- The retention presentation, or the slide it came from → F3 and F8 get the defend-the-number slots their figures would raise, and D1 and D2 get the actual definitions.
- Anything you were on the hook for during a live incident, however small → A1 gets a grounded story, and F4 gets its answer; without it, A1 stays a plan.
- Whether any part of the content-drop calendar was shared across titles → F1 and A3 get a grounded answer for the two-title question.
- Confirmation that Tobias is the hiring manager and who else joins the Outage Hour → the persona weights and R5 are confirmed rather than assumed.
- Opening the Larkspur page and the GDC talk listing → C-series and R3 can cite what they say, and CO questions can rest on the page itself.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes. It would cover the strategy brief, Tobias's talks and writing, loop reports for this role, and recent org context. Offered once; say if you want it.
