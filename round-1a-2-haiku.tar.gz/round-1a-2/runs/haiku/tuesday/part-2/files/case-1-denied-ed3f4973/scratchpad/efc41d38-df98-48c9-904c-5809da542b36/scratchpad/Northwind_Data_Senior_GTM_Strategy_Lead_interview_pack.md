# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

- **Candidate:** Priya
- **Round:** one 60-minute session, a peer round with Dan Kovac, Director of Sales Strategy. Dan and Priya would report to the same VP.
- **Built on:** your notes on Priya, the six JD highlights, Dan's profile as you summarised it, and your research note. No full JD text was supplied, so JD-tagged rows rest on the highlights.
- **Gate check:** the highlights name no location, work-authorization, schedule or pay gate, so none surfaced.
- **Research:** L1 was attempted and refused. Details are in Sources.

## 2. How to use this pack, and the type key

Personas describe how a question arrives. Types describe what it scores.

| Type | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values | Whether past behaviour shows the trait being asked about, with a specific decision rather than a slogan |
| EXP | Experience deep-dive | Whether the claims in your notes survive scrutiny, and what you personally did |
| JD | Role / JD-driven | Whether you can do what the JD lists, including its gaps |
| CO | Company and strategy | Whether you think at the company's altitude, using its own priorities |
| CASE | Live problem | Structure and reasoning on a problem from the role, delivered live |

Guidance is scaffolding, not a script. Speak the quoted sentence in your own words, and stop where the quote stops. An **answer slot** is an instruction for the interview, not a question for this conversation: answer it truthfully, from your own experience, whichever branch fits.

## 4. Fit snapshot

Confidence grades your evidence. Provenance grades what this pack says about it. Every quote is verbatim from your notes ("the coach's notes"), the JD highlights ("JD"), or your research note ("your research note").

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD) | "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | medium | [grounded] | transferability | Bridge: "For nine years, at a large consumer-tech company, I worked in product strategy and ops." The notes show product strategy, not GTM for a product line. Answer slot: name any GTM decision for a product line that was yours to make. If none was, say so and name the nearest product-strategy call you made. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD) | "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | medium | [grounded] | transferability | Bridge: "I built a partner-level revenue model used in carrier negotiations." That is a revenue model for partner deals, not a land, adopt, expand or renew map, so expect a probe. Answer slot: if you have sized revenue a customer was not capturing, say how. If not, say so. |
| F3 | "run independent analysis in SQL and Tableau" (JD) | "skilled in SQL/Tableau" (the coach's notes) | low | [inferred] | discovery | The notes give a self-rated skill. They do not show an analysis you ran yourself. Answer slot: name one analysis you ran yourself in SQL or Tableau and what it changed. If you have none to name, say so. Derivation: a vague self-rating read against a hard JD line. |
| F4 | "partner-motion design experience required" (JD) | "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | medium | [grounded] | transferability | Bridge: the same sentence, at its own scope. A model used in negotiations is not the design of a partner motion, so say which parts of a motion, if any, were yours to set. If none, say so. |
| F5 | "strong cross-functional influence" (JD) | "set annual volume targets with cross-org consensus" (the coach's notes) | medium | [grounded] | presentation | Bridge: "I set annual volume targets with cross-org consensus." The quote reaches influence in other terms. Answer slot: name one point where another team disagreed and what you did about it. If there was none, say so. |
| F6 | "AI experience a plus" (JD) | "uses AI tools daily" (the coach's notes) | low | [inferred] | discovery | The notes give no tasks or outcomes. Answer slot: name a task where you use an AI tool daily and what it changed. If it changed little, say so. Derivation: a vague self-report read against a plus-skill. |
| F7 | Set annual sales quotas or run sales operations ([generic] role-family pattern, not a JD line) | "No classic sales-ops or quota-setting experience" (the coach's notes) | none | [grounded] | capability | Your own stated absence. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, as a plan, never as a past. |
| F8 | "enterprise expansion" (your research note, not a JD line) | "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | none | [grounded] | discovery | The notes show no enterprise or B2B work, and you have not stated an absence. Answer slot: name any work with enterprise or B2B buyers. If none, say so. |
| F9 | Revenue impact you can defend ([generic] pattern, not a JD line) | "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | medium | [grounded] | none | No gap. Bridge: "I proposed a store-surface change credited with a ~$400M ARR uplift." Expect a defend-the-number probe; A1 and B3 rehearse it. |

**Reading the table.** The bridges use your sentences at their own scope. The pack does not supply methods, baselines, attribution models, stakeholders' reactions or outcomes. Where a bridge needs one, it is an answer slot.

## 5. Prohibited claims

Built here from the fit snapshot, because no dossier was supplied. Each entry names its basis. Every answer slot, hold, bridge and rationale in this pack keeps to these limits.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the ~$400M ARR uplift, or drove it | Inflated form of "credited with a ~$400M ARR uplift" | The quote at its own scope. The pack's observation, not words for you: the notes say proposed and credited, not that you drove it |
| Quota-setting or sales-ops experience | Negative you stated (F7) | The plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." No slot |
| Set quotas | Inflated form of "set annual volume targets with cross-org consensus" | The quote at its own scope. A1 and D1 keep the slot inside the targets you set |
| Designed the partner motion | Inflated form of "built a partner-level revenue model used in carrier negotiations" | The quote. The pack's observation: a model used in negotiations, not a motion designed |
| Ran independent analysis in SQL and Tableau | Inflated form of "skilled in SQL/Tableau" | The quote. A2 asks only about an analysis you can name |
| Led the cross-org consensus | Inflated form of "with cross-org consensus" | The quote. G1 asks what you did in the agreement |
| Owned GTM strategy for a product line | Inflated form of "9 at a large consumer-tech company in product strategy & ops" | The quote. F1 asks which GTM calls were yours |
| Used AI tools to build workflows | Inflated form of "uses AI tools daily" | The quote. F6 asks which tasks, and what changed |

## 7. Reading the interviewer

Public footprint and your summary of Dan's profile only. No personality inference.

| Signal | Source | Practical implication |
|---|---|---|
| Self-described "relentlessly data-driven" | His profile | Expect every number probed to its assumptions. A1 and A2 are the likeliest rounds |
| Career spine in pricing and monetization | Your summary of his roles | Case questions lean to pricing, packaging and unit economics (C2, C3) |
| One early-stage-startup chapter | Your summary | Builder stories land well, and a scrappiness probe is possible. Keep answers to what you did |

**Mirror opportunity.** A shared professional domain, monetization, pairs his pricing and monetization roles with the F4 quote: "built a partner-level revenue model used in carrier negotiations." Name the model once in those words. Do not build on it beyond the sentence.

## 6. Grounding brief

Built from your research note, which is undated. Its age is unverified, so check its date before you quote it in the room. No stale framing is flagged.

| Theme | Your note says | Used in |
|---|---|---|
| Priority: enterprise expansion | "enterprise expansion" | B4, D2, R3, R6 |
| Priority: AI copilot launch | "AI copilot launch" ("Compass") | B4, R3 |
| Priority: profitability | "reaching profitability" | C1, R5 |
| Main competitive threat | "bundling by a much larger platform vendor" | C2 |

## 8. Persona table

Weights are relationship priors for a peer round, adjusted by Dan's profile. There is no loop source beyond your words, which establish one session with Dan. No values-style round is detected, so no values cheat sheet is built.

| Persona | How it shows up in this round | Likelihood, with reasoning | Counter-strategy | Weight and questions |
|---|---|---|---|---|
| Data-Driven Prober | Denominators and assumptions behind the $400M and the SQL/Tableau claim | High: peer prior, and his self-description is "relentlessly data-driven" | Name your weakest assumption yourself. Say plainly when you do not know how a figure was counted | Top, 4: A1–A4 |
| Peer Evaluator | Seams with sales strategy, credit-sharing, "what would you need from me" | High: a peer prices what the hire adds to his own team | Reciprocity. Propose seam principles rather than pretending to know the seam | 4: B1–B4 |
| Case/Strategist | Bundling, two product lines, channel pricing | Medium: your note names the bundling threat, and his pricing career tilts cases to unit economics | Clarify, then structure. Challenge one premise per case | 3: C1–C3 |
| Skeptic | The quota gap, enterprise transfer, why now | Medium: F7 is the largest gap, and it sits next to his own function | Plain acknowledgment, bridge, then a ramp plan as a plan | 3: D1–D3 |
| Pressure | Holding the $400M and the quota gap | Low to medium: peer rounds seldom time-box, but a headline figure invites a hard follow-up | Hold through two follow-ups, then concede the specific part | 2: E1–E2 |
| Conversational | The opening "journey" and the AI question | Low as a register, but casual questions are still scored | A 90-second arc. Treat the AI question as scored | 2: F1–F2 |
| Values/Behavioral | Cross-org agreement, and an unpopular truth | Low: no values round is detected, so only the JD's influence line raises it | Story where the notes carry one, selection scaffold where they do not | 2: G1–G2 |

Total: 20 questions, inside the 18–26 range.

## 9. Question banks

### A. Data-Driven Prober (top weight, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Story map on the sentence's beats, in order: you proposed it, the store-surface change, the uplift it was credited with. Defend-the-number slots: how it was counted (answer in your own words; if you do not know, say so plainly); what it is most sensitive to; the assumption you would defend least, named before he does; which part was yours, and who did the crediting if you know. Hold the figure exactly as "~$400M". | The only figure in your notes, and a headline number, so it draws the defend-the-number slots the coverage rule requires. F9 carries the same sentence. A prober goes here first. |
| A2 | "Tell me about an analysis you ran yourself in SQL or Tableau, and what it changed." | JD | [grounded] "skilled in SQL/Tableau" (the coach's notes) | Selection scaffold with an honest branch. Pick one analysis you ran yourself; name its data and its denominator; say what it changed. The notes carry a skill, not an analysis, so if none comes to mind, say so plainly, then describe the nearest analysis you did run, or how you would run one. Do not describe an analysis whose denominator you cannot name. | The JD's hard line "run independent analysis in SQL and Tableau" meets F3, which is discovery. This question tests that gap directly. JD is the requirement; EXP-style probing sits in the follow-ups. |
| A3 | "How would you size whitespace across land, adopt, expand and renew for a new product line, and what would you measure first?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights) | No claim about your past. Clarify which product line and what whitespace means for it. Set the four stages as the objective, segment accounts by stage, name the metric for each stage and the one assumption behind it. If price is a lever, say what you would test first. | A live problem from the JD's whitespace line, rehearsed as structure. The prober will ask for the denominator here too. |
| A4 | "Walk me through the partner-level revenue model you built and what it was used for." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Story map on the quote's beats: built, partner-level, used in carrier negotiations. Say what the model was for, in those words. Answer slot: if you built only part of it, say which part; if others built parts, say who did what. Do not describe a partner motion; your notes carry a model, not a motion. | F4 is the partner requirement, which the JD marks as required. Type is EXP because the question scores attribution; the JD requirement it covers is partner-motion design. |

### B. Peer Evaluator (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between GTM strategy and sales strategy, and what happens when we disagree?" | VAL | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Propose seam principles rather than pretending to know the seam: who owns the target, who owns the account list, how a disagreement gets settled. Story map on the quote's beats: the target, the orgs, the consensus. Answer slot: name a disagreement you resolved over a target and what part was yours. If you did not resolve one, say so. | The peer's seam and disagreement probe, raised by the JD's cross-functional influence line. Type is VAL because it scores partnership fit. F5 carries the quote. |
| B2 | "What would you need from my team in the first ninety days to set a target you could defend?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Reciprocity first: what you bring his team is the partner model's use in negotiations, in the quote's words. Then name the inputs you would ask his team for, framed as a plan. Do not invent a team size or data source you were not told about. | Peer probe on load: whether the hire adds or reduces work. The reciprocity framing answers that. JD type; the partner-motion requirement is the one it touches. |
| B3 | "How do you handle credit when work spans teams? Give me one example from your own work." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Open prompt. Choose an instance. If you pick the store-surface change, its beats are the quote's: you proposed it, and it was credited with the uplift. Answer slot: say who decided the credit and whether you disputed it. If you did not decide it, say so. | A peer credit-sharing probe that reuses the F9 sentence, so the figure stays exactly as quoted. |
| B4 | "Compass is launching while enterprise expansion is a priority. Where does a new product line's partner motion fit?" | CO | [grounded] "enterprise expansion" and "AI copilot launch" (your research note) | Structure: name the objective (expansion and profitability), where partner motion is a lever, one metric and one risk. Say which company priority you would protect first. Claim nothing about Compass beyond your note's words. | Tests company altitude and how the GTM seam holds under a launch. The company priorities come from the note, not from memory. |

### C. Case/Strategist (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which of the two new product lines would you start with next quarter, and why?" | CASE | [grounded] "own GTM strategy for two new product lines" (JD highlights) | Clarify first: which two lines, and what "start" means. Then objective, segmentation, approach, metrics, risks. Lens: unit economics per account for each line, which is where his pricing background will press. Name one premise you would challenge. | The JD's headline requirement, asked as a live choice. No claim about your past, so the guidance makes none. |
| C2 | "A much larger platform vendor starts bundling a comparable capability into its suite. What changes in our go-to-market in the next two quarters?" | CASE | [grounded] "bundling by a much larger platform vendor" (your research note) | Clarify which customers and which bundle. Challenge one premise, for instance that every bundle loses the deal. Then structure: segments at risk, price-to-value against the bundle, what you would test first, and the metric that would show the bundle winning. Do not assert the threat is confirmed. | Your note names this as the main threat, and a peer with a pricing background will press the unit economics. |
| C3 | "A partner-sourced deal would pay less than a direct deal at list price. How do you decide which channel gets the list price?" | CASE | [generic] No sentence in your notes carries this | No claim about your past. Define the decision and the channel-conflict risk. Name the data you would ask for before deciding. Set out unit economics per channel. State the one trade-off you would accept, and why. | His pricing and monetization career tilts the case bank toward pricing. This is a pattern for the problem, not a fact about this company. |

### D. Skeptic (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (the coach's notes); [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | **Highest-ROI prep in this pack.** Expect it in some form. Honest answer, in order: "I don't have classic sales-ops or quota-setting experience." Bridge at the quote's scope: "I set annual volume targets with cross-org consensus." Then a ramp plan, framed as a plan: how you would learn quota design in the first ninety days. Follow-ups, deepest first: (1) "What's the nearest thing you've done?" Repeat the bridge, unchanged. (2) "How were those targets agreed?" Answer slot: say how, in your own words; if you did not set the number, say so. (3) "Would you defend a target you didn't set?" Hold: you defend a number only as far as you can trace it. Say which parts you can trace, and concede plainly the parts you cannot. | The predictable objection. F7 is the largest gap in the fit snapshot and sits beside his own function. Both sentences are yours, so both can be said aloud without inflation. |
| D2 | "Where does a consumer-tech planning background transfer to enterprise data buyers, and where doesn't it?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | Name one part of planning that transfers, in your own words. For the limit, answer slot: if your work touched enterprise or B2B buyers, say how. If it did not, say so and say what you would learn first. Do not describe how enterprise buyers behave unless you have observed it. | F8 is discovery: the notes show no enterprise work. Asked as transferability, not as a deficiency. |
| D3 | "What's pulling you from consumer tech toward this role?" | EXP | [generic] No sentence in your notes gives a reason | Answer slot: give your actual reason in your own words. The notes record none, so none is supplied here. Keep to what pulls you toward the role, not what pushes you out of consumer tech. | His why-now probe, and the reason-for-leaving question a round like this often asks. |

### E. Pressure (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That result. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Hold-then-concede. Hold the position through two follow-ups: you proposed the store-surface change. Concede specifically: if you cannot separate your share from the credit, say that, and say what you can say. Do not fold into "I drove it." Answer slot for the share: if you can separate it, say how; if you cannot, say so plainly. | A pressure test on the same figure. The answer has to hold without turning defensive. |
| E2 | "Sixty seconds: why you over someone who has set quotas?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes); [grounded] "set annual volume targets with cross-org consensus" (the coach's notes); [grounded] "No classic sales-ops or quota-setting experience" (the coach's notes) | Hold the first two parts: the partner model, and the volume targets set with cross-org consensus. Concede the third, plainly: "I don't have classic sales-ops or quota-setting experience." Then stop. The pressure is in the pause, not in more words. | Tests composure on the stated gap, and uses the hold-then-concede structure. |

### F. Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | 90-second arc, using only the quotes' beats: consulting, then nine years in product strategy and ops, then the partner model. Close with what you want next, in one sentence of your own. Add no reason for a move unless you state it yourself. | Casual register is still scored. A pre-scripted arc, sourced sentence by sentence, keeps it short. |
| F2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" (the coach's notes). Derivation: a self-report with no specifics, read against the JD's "AI experience a plus" | Name two tasks where you use an AI tool, in your own words, and what each changed. If it changed little, say so. Do not call it AI experience; your notes do not. | The JD's plus-skill, asked casually. This is the pack's one discovery answer (F6). |

### G. Values/Behavioral (2 questions; no values round detected)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you got several teams to agree on one number." | VAL | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Open prompt: pick the time you got agreement on a target across orgs. Story map on the quote's beats: the target, the orgs, the consensus. Answer slot: if a team disagreed, say what you did about it; if none did, say so. If no such time comes to mind, say so plainly and give the nearest thing your notes carry. | The theme comes from the JD's cross-functional influence line. No published value is raised here, so this is a theme question, not a values round. |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] No sentence in your notes carries this | Selection scaffold: pick a time you told someone senior what they did not want to hear, with a named stake and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your notes carry, or how you would handle it. | A persona stem. Your notes carry no instance, so no story is supplied. |

### Requirement coverage

Every JD line, and the stated gap, maps to questions below.

| Requirement (source) | Questions |
|---|---|
| own GTM strategy for two new product lines (JD) | C1 (JD question); F1 (fit) |
| identify whitespace across land/adopt/expand/renew (JD) | A3 |
| run independent analysis in SQL and Tableau (JD) | A2 |
| partner-motion design experience required (JD) | A4; B2 |
| strong cross-functional influence (JD) | B1; G1 |
| AI experience a plus (JD) | F2 |
| Sales-ops and quota-setting (role-family pattern; your stated gap) | D1; E2; D3 |
| Defend the headline figure (your notes) | A1; B3; E1 |
| Enterprise expansion (your research note) | B4; D2 |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer round. It asks what the hire adds, not what it costs. |
| R2 | "Your career includes pricing and monetization roles and an early-stage chapter. How did that chapter change the way you think about price?" | Ties to his own path, turning an interview into a peer conversation and showing you read his profile. |
| R3 | "Where is Compass changing the way your team thinks about expansion revenue?" | Shows you read the launch, and invites his view on your note's second priority without claiming anything about it. |
| R4 | "Where do sales strategy and GTM strategy disagree most today?" | A seam question, asked first, which shows you expect a seam. |
| R5 | "How does the profitability goal change which new product line gets investment?" | Puts the company's third priority into the investment decision, where a peer will have a view. |
| R6 | "How does your team split expansion effort from renewal effort on an account?" | The JD's land, adopt, expand and renew line, asked as a question. |

## 14. Sources

**Provided documents**

- Your notes on Priya: the sentences quoted as "the coach's notes" throughout.
- The JD highlights: six lines, quoted as "JD highlights" or "JD". No full JD text was supplied.
- Dan's profile, as you summarised it: the self-description "relentlessly data-driven", a pricing and monetization career spine, and one early-stage-startup chapter.
- Your research note: three priorities, and the bundling threat. Undated.

**Searches sent**

| Query | Result |
|---|---|
| "Northwind Data values principles" | refused |
| "Northwind Data interview process" | refused |
| "Dan Kovac Director of Sales Strategy Northwind Data" | refused |

The search tool returned a permission error. I did not retry.

**Research tier:** L1 — searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Every call refused. Would feed a values cheat sheet, which this round does not trigger, since no loop source documents a values round. Nothing here depends on it |
| 2. Northwind Data interview process | unavailable | Every call refused. Would test the loop. Your words already establish one session with Dan, so the persona weights rest on that |
| 3. Northwind Data strategy / recent news | skipped | Your research note already fixes the priorities and the bundling threat. Its age is unverified, so check it before quoting |
| 4. Dan Kovac, Northwind Data | unavailable | Call refused. Would have fed the interviewer read. The read rests on your summary of his profile |
| 5. Representative JD | skipped | The six JD highlights were supplied |

Values cheat sheet: not built. No values-style round is detected.

## 15. Upgrade menu

- **Full JD text** → the six highlights become full requirements, and any mid-list requirement gets its own question.
- **Search permission granted** → targets 1, 2 and 4 run. A values cheat sheet appears only if a values round turns up.
- **Your recruiter's note on the other rounds, if any** → reweights the personas, and shows whether a values round is in the loop.
- **Your CV or resume text** → the quotes come from your own sentences rather than your notes, and the rows read as CV lines.
- **How the ~$400M was counted, in your words** → A1's slots become sourced lines. Without it, the pack cannot say how the figure was reached, and does not try.
- **A named example of designing a partner program** → F4 moves from transferability toward presentation.
- **Deeper research, L2** → strategy brief, Dan's public talks and writing, and role-family loop reports: up to 6 more searches and 2 more fetches, several more minutes. Only once search is granted. Want it?
- **A tuesday-dossier.md, if you have one** → would tighten the prohibited list and the objection bank.
