# Quartzline: Product Manager, Platform APIs. Hiring-manager round (45 min). Prep pack

**Built on:** the underwriting dossier (conditional_go, generated 2026-08-14, stage: interviewing). Today is 2026-11-19, so the dossier is about three months old. Re-check the JD and the squad structure with the recruiter before Thursday.
**Round:** hiring manager, 45 minutes, one conversation. Round type is known, so the Case/Strategist and Skeptic weights come from the round.

## How to use + type key

Personas are how a question is asked. Types are what is being scored. Guidance is scaffolding, not a script.

- **JD**: can you do the listed job, gaps included
- **EXP**: do your claims survive scrutiny
- **CASE**: a live problem from the role, scored on structure
- **CO**: company and strategy knowledge (not covered here, research was unavailable)
- **VAL**: values (not detected for this round, so none in this pack)

## Prep triage

Time before Thursday is not stated, so this is sized to one 45-minute conversation.

1. **B1 out loud, at least three times.** This is the objection the underwriter named, and it is the highest-ROI rehearsal in the pack.
2. **C1 and C2 as spoken walkthroughs.** These are the live roadmap problems a hiring manager will likely pose.
3. **P1 to P3 hold lines.** Know where you hold and where you concede.
4. **Reverse questions.** Ask at least three; the dossier's two employer questions are first.

Everything else is insurance.

## Fit snapshot

Evidence is quoted from the dossier's `verified_candidate_evidence` or its `evidence_map` quotes, or it is "none given". "Dossier" names the origin.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (JD, R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier | high | [grounded] | transferability | Adjacent work, not PM experience: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." The material shows integration leadership. It does not show product-management tenure, and the bridge does not stretch it. |
| F2 | Owning a roadmap and prioritization authority (R1 sub-claim) | none given (dossier: acknowledge_gap) | none | [grounded] | capability | Plain acknowledgment, from the dossier's acknowledge_gap area: "I haven't owned a product roadmap or set priorities for an engineering squad." Then a ramp plan, said as a plan and never as a past. |
| F3 | "Shipped API or platform products" (JD, R2) | Same quote as F1 — dossier | low (this pack's grading; dossier does not grade R2) | [inferred] | discovery | Integrations for clients are not shipped products, and the bridge should not be stretched. Answer slot: if any product you worked on was yours to ship, say which and your part; if your work was client integrations, say that plainly. |
| F4 | "Stakeholder management across engineering, sales, customers" (JD, R4) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier | medium | [grounded] | presentation | Confirmed, with limited inspectable proof. Expect a probe. The quote reaches customers and product, not sales. Say it at its own scope. |
| F5 | "Technical fluency: API docs, schemas" (JD, R3) | "Wrote the internal integration playbook her team uses" — dossier | high | [grounded] | discovery | The playbook is integration documentation. Whether you have written API reference docs or schemas is not shown. Answer slot: if you have, name them; if not, say what the playbook covers. |
| F6 | "Agile delivery experience" (JD, R5, preferred) | none given | low (dossier) | [inferred] | discovery | No quote touches it. Answer slot: if you ran a delivery cadence with engineers, say how; if not, say so and describe how you would work with the squads. |

Gap-type routing: F1 transferability because the quote is adjacent work at its own scope. F2 capability because the dossier records the absence. F3, F5 and F6 discovery because the material is silent. F4 presentation because the quote reaches the requirement in other terms.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live roadmap problems | Highest. A hiring manager is buying capability and will pose a problem on their actual roadmap. Weight 5. | Clarify, then objective, segments, approach, metrics, risks. Think aloud. |
| Skeptic | The gap, "why now," "why into a PM role" | High. The underwriter named the objection; the gap is in the requirements. Weight 4. | Plain acknowledgment, the bridge at its own scope, and a ramp plan. Rehearse until it is boring. |
| Pressure | Interruptions, "why you over an internal PM" | Medium. Weight 3. | Pause, restate, hold two follow-ups, then concede the specific thing. |
| Data-Driven Prober | Adoption metrics, "how was 30+ counted" | Medium. Adoption is a named responsibility with no stated baseline. Weight 3. | Name the weakest assumption before they do. Say plainly what you do not know. |
| Conversational | Opening "walk me through" | Certain to open with something. Casual questions are still scored. Weight 2. | A 90-second arc. Never answer the closing question with "I think you've covered everything." |

Interviewer read: none, because no interviewer name was given.

## Prohibited claims

Sourced entries come from the dossier. Each one says what the pack will not coach, and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | F1 at its own scope, plus F2's plain acknowledgment |
| Having owned a product roadmap | Dossier prohibited_claims | F4 at its own scope: you ran roadmap-input sessions; you did not own the roadmap |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | F2's plain acknowledgment, and the ramp plan |

Inflated-form entries, built locally:

| Not coached | Basis | Honest form |
|---|---|---|
| "I shipped API products" | Inflated form of F1 | F1 at its own scope: client integrations, scoping through go-live |
| "I defined and tracked adoption metrics" | Inflated form of nothing quoted | Not listed: no quote speaks to it, so it is an answer slot (D1), not a claim. Say what you would measure first. |

## Question banks

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Partner API adoption is flat this quarter. Where do you start?" | CASE | [generic] | Clarify what adoption means: first successful call, live integration, or sustained traffic. Segment partners. Diagnose onboarding, docs and versioning. Name one metric before you name a fix. | The JD's "define and track adoption metrics" as a live problem. Pattern only, no claim about the candidate. |
| C2 | "How would you decide which partner requests make the roadmap?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (JD) | Criteria: partners affected, revenue at risk, engineering cost, platform consistency. Say who decides and where the squad leads sit. | Tests R1's authority question without asking about your past. |
| C3 | "Two squads want to build the same capability two ways. How do you resolve it?" | CASE | [generic] | Clarify decision rights first. Propose a decision frame and say what you would escalate, and to whom. | Squad-authority risk, asked as a decision. |
| C4 | "Walk me through how you'd run discovery with a partner you have never worked with." | JD | [grounded] "Run discovery with integration partners" (JD); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier) | Story map on F1: scoping and requirements are the stated beats. Answer slot: if a partner pushed back on scope, say how it was resolved; if none did, say so. | The JD's discovery line, answered with the nearest real evidence. |
| C5 | "What is the most complex API integration you have led, and what made it hard?" | EXP | [grounded] F1 quote | Open prompt. Story map from F1's beats. Answer slot: if the hard part was a product decision rather than integration work, say so. | Open prompt, so the candidate picks the instance. |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You've never held a PM title or owned a roadmap. Why should we hire you into one instead of a PM with three years of the job?" | JD | [grounded] F1 quote; dossier acknowledge_gap plain acknowledgment | **Highest-ROI rehearsal, named by the underwriter.** Words: "I haven't held a PM title or owned a roadmap." Then F1 at its own scope. Concede specifically: "For the first months I'd be slower than a PM with three years on prioritization, and I'd say so." Ramp plan as a plan: learn both squads' backlogs, sit in on prioritization, build an adoption baseline before proposing targets. Hold through two follow-ups by returning to the integration work. | The underwriter's objection, in its own words. It is asked as written because its negatives come from the dossier. |
| S2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] F2 plain acknowledgment | Name prioritization authority against the two squad leads. Then the ramp plan. | Skeptic's standard day-one probe; the honest answer is already in the dossier. |
| S3 | "Have you shipped API or platform products?" | JD | [grounded] F1 quote | Answer slot (F3): if you shipped anything product-like, say what and your part; if your work was client integrations, say that plainly. | R2 has no quote that reaches it. |
| S4 | "Stakeholder management covers sales too. What is your sales side?" | JD | [grounded] F4 quote | Answer slot: if you worked with sales on a client, say which and what you did; if you did not, say so plainly. | R4 names sales; the quote does not. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over an internal PM?" | JD | [grounded] F1 and F4 quotes | Hold: the integration depth, with F1's beats. Concede: "An internal PM has roadmap experience I don't have, and I'd say so." | Pressure test on the central gap. Hold, then concede the specific thing. |
| P2 | "What did the quarterly roadmap-input sessions change, if anything?" | EXP | [grounded] F4 quote | Answer slot: if you can name a roadmap decision the sessions changed, say it; if you cannot, say they fed client evidence to product and that you do not know what it moved. | An open question. A premised one would claim an outcome the quote does not carry. |
| P3 | "Are you saying you can do this job today?" | JD | [grounded] F2 plain acknowledgment | Honest answer: not on day one, and here is the ramp. Do not hedge the core claim. | Direct pressure on capability. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How would you tell whether a partner has really adopted the API?" | JD | [generic] | Define stages. Name the weakest assumption: a live key does not equal real use. Answer slot: if you measured adoption on your integrations, say what you counted and its weakest assumption; if not, say what you would count first. | Named responsibility, no stated baseline. |
| D2 | "How did you count the 30+ integrations? Was 'done' go-live?" | EXP | [grounded] F1 quote | Name the weakest assumption in your own words. Answer slot: how the count was made, and which part was yours. | A figure raises a defend-the-number slot. |
| D3 | "Where would an integration stall first after go-live?" | CASE | [generic] | Pattern: the handoff from go-live to first production traffic. Say what you would check. | Live problem, no claim about your past. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "So, walk me through the journey to here." | JD | [grounded] F1 and F4 quotes | 90-second arc: F1's quote, then F4's, then why the platform side. | An opener that is still scored. |
| K2 | "What are you playing with in API tooling these days?" | JD | [grounded] F5 quote | Name the playbook you wrote, in your own words. Answer slot: if you have written API reference docs or schemas, say so; if not, say what the playbook covers. | R3, casually asked. |

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| R1 3+ years PM | S1, S2, P1, P3, C2 | |
| R2 Shipped API products | S3, C5 | |
| R3 API docs, schemas | K2, F5 | |
| R4 Stakeholder management | S4, P2, K1 | |
| R5 Agile delivery | S2 (partial) | No dedicated question: no quoted evidence to build one on. |
| Adoption metrics (JD responsibility) | C1, D1, D2 | |

## Reverse questions

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** Why it lands: the dossier's top unknown, asked as diligence.
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: no baseline is stated in the JD, and you need one before you set targets.
3. **"What does success look like at 90 days for this role?"** Why it lands: it turns the ramp plan into the interviewer's own definition.
4. **"How do partner requests reach the roadmap today?"** Why it lands: it shows how the authority question works in practice.
5. **"What would make you say the first six months went badly?"** Why it lands: it surfaces the failure mode they are most worried about.

## Sources

- **Provided documents:** the pasted dossier (job-underwriter, v1.1, generated 2026-08-14). Consumed sections: `handoff_to_mock_interview`, `role_profile`, and `decision` (context only). No full JD text was supplied, so the JD lines are the dossier's `role_profile` requirement text.
- **Research tier: L1. Searches 0 of 6, fetches 0 of 2.** The one web search was refused: permission was not granted in this session.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Refused. Values cheat sheet would have been built if a values round were detected; it is not. |
| 2. `Quartzline interview process, product management` | unavailable | Refused. Would have set loop structure and the persona weights above. |
| 3. `Quartzline strategy` / recent news | unavailable | Not attempted after the first refusal. Would have added a grounding section and CO questions. |
| 4. Interviewer name + company | n/a | No name given. |
| 5. Representative JD | skipped | The dossier's `role_profile` fixes the JD tier. |

## Upgrade menu

- Interviewer's name → persona weights from their public footprint, and a reverse question tied to their career path
- Full JD text, checked against the dossier's 2026-08-14 `role_profile` → confirms R1 to R5 and whether the "two squad leads" line still holds
- Web search permission, or a deeper research pass → company values, interview process and strategy rows stop being unavailable
- Your CV, with any product you shipped listed → moves F3 from answer slot to a quoted row
