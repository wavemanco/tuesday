# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. Peer, same VP. One 60-minute conversation.
**Candidate:** Priya.

## How to use, and the type key

Personas describe how a question arrives. Types describe what it is scoring. Guidance is scaffolding, not a script. Rehearse it aloud until the words are yours.

| Tag | Meaning |
|---|---|
| EXP | Work-experience deep-dive: does what you did survive scrutiny |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: can you think at Northwind's altitude |
| CASE | Live problem from the role, delivered in the moment |
| VAL | Values alignment. Not in this pack: no values round is detected |

Provenance labels: `[grounded]` traces to a sentence you supplied or a document you gave me. `[inferred]` is my derivation. `[generic]` is a role-family pattern with no claim about you or Northwind.

## Fit snapshot

Requirements are quoted from your JD highlights and your message. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "then 9 at a large consumer-tech company in product strategy & ops" (your message) | low | [grounded] | transferability | Your material says product strategy and ops. It does not show GTM ownership of a product line, and the bridge should not stretch to it. Answer slot: if any GTM decision on a product was yours to make, name it and how you decided; if none was, say so and say what you did in product strategy. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | The model sizes revenue at partner level. It does not show whitespace across the lifecycle. Say the model's scope in its own words and do not extend it to the four stages. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (your message) | medium | [grounded] | presentation | The quote reaches the tools, not the word "independent". Say the skill as stated. Expect a probe on whether you ran an analysis end to end. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | Partner-facing economics are adjacent to partner-motion design, not the same. Say what the model did. Do not describe a partner motion you designed. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms. Say the targets and the consensus in your own words. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (your message) | medium | [grounded] | transferability | Use is stated. Building with AI is not. Say how you use the tools and do not describe building anything with them. |
| F7 | Quota and sales-ops experience (your background, not a JD line) | "No classic sales-ops or quota-setting experience" (your message) | none | [grounded] | capability | This is a gap you stated. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make it smaller. |

Observation, in my own analysis: the JD highlights contain no location, travel or work-authorization line, so no gate row is set. Step 1 item (d) asks about that below.

## Grounding brief

Source: your research note. Its date is not known to me. Confirm it is current before you rely on it.

- Three stated priorities: enterprise expansion; an AI copilot launch ("Compass"); reaching profitability.
- Main competitive threat: bundling by a much larger platform vendor.

I could not verify any of this against a public source in this session (see Sources). Use these as the vocabulary to sound current in, not as facts you can cite from memory.

## Reading the interviewer

Source: your description of Dan Kovac. I did not verify it publicly in this session.

- **Career pattern:** pricing and monetization roles, with one early-stage startup chapter. Now Director of Sales Strategy.
- **Self-described style:** "relentlessly data-driven."
- **Implications:**
  1. Every number you give will be taken apart. Know its counting and its weakest assumption before he asks.
  2. His native language is pricing, packaging and unit economics. Expect the case to arrive there.
  3. He has startup experience. Expect "scrappiness" questions, and builder stories will land if they are true and specific.
  4. He is a peer, so the conversation tests seams and credit, not just answers.
- **Shared professional path:** none I can find in your description. Do not build a rapport line on one.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Two levels deep on every figure; asks for inputs and denominators | Top. A peer relation prior plus his "relentlessly data-driven" self-description | Name the counting and the weakest assumption before he does. Say plainly what you do not know. |
| Peer Evaluator | Seams between teams; disagreement; credit; what you need from him | High. The peer prior. He is pricing what the hire adds to his load | Reciprocity: what you bring to his team. Propose seam principles, not a seam you have not seen. |
| Case / Strategist | Pricing or packaging problem; expansion diagnosis; Compass | Mid. His pricing spine tilts cases to packaging and unit economics | Clarify, then segment by land/adopt/expand/renew, then metrics. Say the framework once, briefly. |
| Skeptic | Quota and sales-ops gap; GTM ownership gap; "skilled" versus "ran" | Mid. Two gaps you stated or the JD raises | Hold to what you did. Name the gap plainly. Give a ramp plan. |
| Pressure | Time-boxed challenge to the one held position | Low. Peer register, but one held claim will be tested | Pause, restate, hold through two follow-ups, concede specifically. |
| Conversational | Warm opener; "walk me through the journey" | Low. Opener only, and still scored | A 90-second arc. Treat the AI question as scored. |

Question depth follows weight: Prober 5, Peer 4, Case 3, Skeptic 3, Pressure 2, Conversational 2.

## Question banks

### A. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you arrived at the ~$400M ARR figure." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Say the sentence as written: a change you proposed, credited with the uplift. Then, in your own words, how it was counted, what it is sensitive to, and which part was yours. Answer slot: if you saw the count, say how; if you did not, say so plainly and say who ran it. | The headline figure on your CV. A headline number raises the defend-the-number slots. The most likely first probe from a data-driven peer. |
| A2 | "Which assumption behind that uplift would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Name the assumption you would defend least before he does. If you do not know one, say that. Do not invent a sensitivity. | Prober stem. Converts a gotcha into a credibility point. Same figure as A1, second level. |
| A3 | "What did the partner revenue model take as inputs, and which one moves the answer most?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Name the model's purpose: used in carrier negotiations. Name the input you would most want to check. Answer slot: if you set the inputs, say which; if you did not, say whose they were. | JD partner language and your strongest modeling line. A pricing peer will want inputs. |
| A4 | "What is the first SQL query you would run on a whitespace question for one product line?" | JD | [grounded] "skilled in SQL/Tableau" (your message); "run independent analysis in SQL and Tableau" (JD highlights) | Clarify the grain first, then the join you would check and the one assumption it rests on. Answer slot: if you have run an analysis in SQL end to end, name the one you would show; if you have not, say the skill is what you have and how you would check your first result. | F3 and F2 meet here. The JD names the tools, so the probe is likely. Keep to the skill as stated. |
| A5 | "What has 'uses AI tools daily' changed in an analysis you actually did?" | EXP | [grounded] "uses AI tools daily" (your message); "AI experience a plus" (JD highlights) | Describe how you use the tools, in concrete tasks. Answer slot: if you built anything with them, name it; if you did not, say so and say what the tools do for your work. | F6, and the JD's plus line. Usage is stated; building is not. Probers test that gap. |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where would you draw the seam between a product-line GTM plan and a sales-strategy team?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights) | Propose principles for the seam: who sets the number, who owns the account, how disagreement is resolved. Do not claim you know his team's seam. | Peer probe on the JD's core ownership line. F1 is the gap here, so keep principles, not history. |
| B2 | "When a model you built gets used by another team, how do you handle credit?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Say who used it and what you did, in the sentence's terms. Credit the users plainly. | Peer probe on attribution. The model is your cleanest example of shared use. |
| B3 | "If the partner motion we'd design conflicts with the pricing team's plan, what happens?" | JD | [grounded] "partner-motion design experience required" (JD highlights); "strong cross-functional influence" (JD highlights) | Say how you would bring the disagreement to the table, first with data, then with the people who own the number. Answer slot: if you have disagreed with a peer team over a number, say how it resolved; if you have not, say how you would start. | F4 and F5 meet here. The JD names both the design and the influence. |
| B4 | "What do you need from a GTM lead that your pricing work isn't getting today?" | JD | [grounded] "set annual volume targets with cross-org consensus" (your message) | Reciprocity: name what you bring, at your scope. You set annual volume targets with cross-org consensus. Ask what load would move off him. | Peer question on load. The answer is your reciprocity line. |

### C. Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A new product line lands with enterprise accounts but does not expand. How would you diagnose it?" | CASE | [grounded] "enterprise expansion" (your research note) | Clarify, then segment by land/adopt/expand/renew, then metrics, then the risk you would check first. Say the framework once. | CO grounded in the stated priority. Expansion is the first of Northwind's three priorities in your note. |
| C2 | "How would you package a data product against a bundle from a much larger platform?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | Name the unit-economics question first: what the bundle costs them and what it costs you. Then packaging options, then one risk. | Dan's pricing spine makes this his native question. Your note names the threat. |
| C3 | "Compass is launching. Which product line would you lead first, and why?" | CASE | [grounded] "an AI copilot launch ('Compass')" (your research note) | Challenge one premise, then state your order and its reason. Do not claim knowledge of Compass's roadmap. | CO on the second priority. Tests altitude without private information. |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The role designs partner motions, and you have no sales-ops or quota work. Where have you owned a target a sales team had to hit?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message); "set annual volume targets with cross-org consensus" (your message); "partner-motion design experience required" (JD highlights) | Hold, then concede. Plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." Bridge at scope: "I set annual volume targets with cross-org consensus." Answer slot: say which targets you set, who had to agree, and whether a sales team lived with them. Hold through two follow-ups by returning to the targets. Concede that quota design is what you would learn first. | The single most predictable objection, and the highest-ROI prep in this pack. The gap is stated by you, so the probe will arrive. |
| D2 | "Which of the two product lines would you be weakest on day one?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights) | Name the weakest area plainly. Words for you: your material shows product strategy and ops, not GTM ownership of a product line. Answer slot: name the part you have led and the part you would learn first. | F1 is the gap. Answering the weakest area first reads as candor. |
| D3 | "You say you're skilled in SQL and Tableau. Show me the last thing you built end to end." | EXP | [grounded] "skilled in SQL/Tableau" (your message) | Hold to "skilled" as stated. Answer slot: if you built something end to end, name it and its one assumption; if not, say the skill is what you have and name the nearest work. | F3. The most natural skeptic line for a tool claim. |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That number. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Pause and restate: "I proposed the change, and the uplift was credited to it." Hold through two follow-ups. Concede specifically: other drivers you cannot separate, if you cannot. | Pressure form of A1. Attribution is where candidates fold. Hold the proposal, concede the share. |
| E2 | "Sixty seconds: why hand a GTM strategy lead role to someone who has never set a quota?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message) | Hold the strategy case in one sentence, then concede the quota gap plainly: "I don't have quota-setting experience." Do not fold on the strategy claim to restore harmony. | D1's pressure form. A time-boxed version of the same objection. |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (your message) | A 90-second arc: consulting, then product strategy and ops, then the work you are proudest of, stated at its own scope. | Casual opener, still scored. Your arc is the cleanest fit to the role's altitude. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message); "AI experience a plus" (JD highlights) | Name two or three tools and the tasks they serve. Say what you use them for, not what you built. | F6, asked casually. The JD's plus line, in a rapport register. |

### Requirement coverage

| Requirement (JD highlights) | Question IDs | Note |
|---|---|---|
| own GTM strategy for two new product lines | B1, D2 | |
| identify whitespace across land/adopt/expand/renew | C1, C3 | |
| run independent analysis in SQL and Tableau | A4, D3 | |
| partner-motion design experience required | A3, B3, D1 | |
| strong cross-functional influence | B3, B4 | |
| AI experience a plus | A5, F2 | |

## Grounding and values

No values-style round is detected. The loop is set by your words: one 60-minute conversation with a peer. No values bank is included.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your path runs through pricing and monetization and one early-stage chapter. Which monetization call from that chapter would you make differently now?" | Ties to his own path. Converts an interrogation into a peer conversation and shows you researched him. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, the peer question. Shows you are thinking about his load, not only yours. |
| R3 | "Which of the three priorities, enterprise expansion, Compass or profitability, is taking your team's time hardest right now?" | Shows you have your note's priorities in view. Safe to ask. Confirm the note is current first. |
| R4 | "When a partner-led deal and a direct deal compete for the same account, who decides the seam today?" | Opens the partner-motion seam on his side, which is where B3 goes. |
| R5 | "When the bundling threat comes up in your pricing reviews, is it a discount request or a packaging question?" | Ties to C2. Tests the threat on his desk, not in the deck. |

## Prohibited claims

Not coached in any answer, bridge or rationale. Each entry shows its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns GTM strategy for product lines | Inflated form of F1 | The quote at its scope: "product strategy & ops." My observation: your material does not show GTM ownership of a product line. |
| Designed partner motions | Inflated form of "built a partner-level revenue model used in carrier negotiations" | The quote at its scope. My observation: your material shows the model, not partner-motion design. |
| Set quotas or ran sales ops | Stated negative: "No classic sales-ops or quota-setting experience" | Plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." No slot on quota work. |
| Sole credit for the ~$400M | Inflated form of "credited with" | "proposed a store-surface change credited with a ~$400M ARR uplift," at that scope. |
| Ran SQL analysis end to end | Inflated form of "skilled in SQL/Tableau" | The skill, as stated. |
| Builds with AI | Inflated form of "uses AI tools daily" | The usage, as stated. |

## Sources

Provided documents:
- Your message: the JD highlights and your background summary.
- Your research note: the three priorities and the bundling threat. Its date is not known.

Research tier: L1 — searches 2 of 6, fetches 0 of 2. Both searches were refused; this session had no search permission.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Query sent: "Northwind Data company values". Refused. It would have moved a values bank, but no values-style round is detected, so the bank is not built. |
| 2. Northwind Data interview process | unavailable | Query sent: "Northwind Data interview process sales strategy". Refused. It would have moved the loop, but your words already set a single peer conversation. |
| 3. Northwind Data strategy or recent news | skipped | Your research note supplies the three priorities and the bundling threat. Age unknown. |
| 4. Dan Kovac, Northwind Data | unavailable | Name given. No call sent, since search was refused on the first two. It would have moved the interviewer read and the reverse questions. |
| 5. Representative Senior GTM Strategy Lead JD | skipped | Your JD highlights fix the fit snapshot and the JD questions. |

User links read: 0.

## Upgrade menu

- Full JD text → the six JD rows gain verbatim quotes, and the coverage table can be checked line by line.
- Your CV, verbatim → the evidence cells quote CV lines, not your summary.
- Search permission for this session → the two refused company queries, the interviewer footprint and the note's currency can be checked.
- Dan's public profile or talks → the interviewer read gains real material, and the reverse questions tighten.
- Current Northwind strategy material under six months old → confirms or replaces the three priorities in the grounding brief.
- Deep research (L2), offered once: up to 6 more searches and 2 more fetches, several more minutes. Want it?
