# Ashgrove Credit Union — Member Experience Lead — Interview Prep Pack

Three rounds on 28 November 2026, run as a loop: a 30-minute recruiter screen, a 45-minute behavioural round with the Head of Member Services (your future manager), and a 60-minute panel of two branch managers that includes a 20-minute complaint-escalation case and scores the four values. Interviewer names are not yet known, so persona weights come from the round type and the recruiter's email.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your past work), JD (the listed job), CO (company and strategy), CASE (a live problem).
- Guidance is scaffolding for a spoken answer, not a script. Each cell is either a story built from one of your own sentences (quoted in the Provenance column) or an answer slot, which asks you for your own experience and allows the honest answer that a practice was not yours.
- Provenance labels: `[grounded]` traces to your message, your CV or the supplied documents. `[inferred]` is derived from the JD or the role. `[generic]` is a pattern with no claim about you or Ashgrove.

---

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the JD you sent. Evidence is quoted from your own message, which is the only source about your history. Where your message says nothing, the cell says `none given`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | Bridge: "I have six years in retail banking, the last three as a branch supervisor." Expect a probe on whether branch work counts as customer operations in the JD's sense. Answer in your own words. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | presentation | Bridge: "I handled the branch's formal complaints log." Your message does not say the complaints ran under rules or time limits. Answer slot: if they did, name the rules or deadlines you worked to; if not, say so and describe how the log was actually handled. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Bridge: "For one branch, I handled the formal complaints log." A log is one stage, not the end-to-end process across branches. Answer slot: which stages of a complaint, from first contact to closure, were yours. If the log was one part of a process run by others, say so and describe your part. |
| F4 | "and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap you stated, so no bridge claims contact-centre work. Words: "I haven't worked in a contact centre." Then how you would learn it, as a plan and never as a past. |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Bridge: "I trained new tellers on our escalation script." That is tellers, not supervisors. Answer slot: if you ever coached a supervisor on an escalation, say how; if not, say so and say how you would start. |
| F6 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | Bridge: "I built the monthly complaints spreadsheet our regional manager uses." Your message does not say whether it tracked resolution times. Answer slot: if it did, say which figure and how it was counted; if it did not, say so. |
| F7 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't presented to anyone above regional level." Then how you would build that skill, as a plan. |
| F8 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | Bridge: "I built the monthly complaints spreadsheet." Your message does not name the tool. Answer slot: name the tool you used, in your own words. |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | No quote touches this. Answer slot: if you have worked with a digital or product team on a customer journey, say what you did; if not, say so and say what you would do first. |

**Gates.** The JD states no gate, such as location, pay or schedule. The recruiter's logistics questions are covered in the Round 1 bank.

---

## Prohibited claims (shared)

Built from the fit snapshot. These are wording you should not use in the interview, even though the JD invites it. Each entry gives the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the complaints process end to end across branches and the contact centre | Inflated form of F3 and F4 | F3's quote at its own scope. Observation, for your prep only: your material describes a branch log, not an end-to-end process across branches. F4's plain acknowledgment applies to the contact centre. |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. Observation: your material says "formal complaints log", not regulated complaints. |
| Presented complaint reporting to senior leaders | Inflated form of F6, plus a contradiction | F6's quote. The regional manager uses the spreadsheet; your message does not say you presented it. F7's plain acknowledgment applies. |
| I have presented to senior leaders | Contradicted by your stated negative | F7: "I haven't presented to anyone above regional level." |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote. You trained tellers. |
| Excel expertise | Inflated form of F8 | F8's quote. You said "spreadsheet", not Excel. |

---

## Grounding brief (from your summary of the July 2026 strategy brief)

I have your summary of the brief, not its text. Read the brief itself before the panel round; the quoted lines below are your own words.

- "move 40% of member service to digital channels by 2028" — digital self-service is the direction of the role's F9 requirement.
- "consolidate eight branches into five hubs over 2027" — this is the most sensitive point for a panel of branch managers. See P2 below.
- "launch a small-business lending product in Q1 2027"
- "the main competitive pressure is app-only banks"

---

## Round 1 — Recruiter screen (30 minutes)

**Persona weights**

| Persona | Questions | Why |
|---|---|---|
| Conversational / Rapport Builder | 2 open, plus 4 logistics | Recruiter screens are friendly but scored. Logistics are checked here. |
| Skeptic (light) | 2 | Checks motivation and the one stated gap, the contact centre. |

**Recruiter bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-1 | "So, walk me through your journey to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message; [grounded] "I handled the branch's formal complaints log" — your message | Ninety-second arc: the six years, the last three as supervisor, then the complaints log. Stop there. Do not add a stage or result the sentences do not carry. | F1 and F2. A casual opener is still scored. |
| R1-2 | "What do you know about the digital side of this role?" | JD | [grounded] "work with digital teams on self-service journeys" — JD; [grounded] "move 40% of member service to digital channels by 2028" — your summary of the brief | Name the 2028 digital target in the brief's own words. Answer slot: if you have worked with a digital team on a customer journey, say what you did. If not, say so and say what you would want to learn first. | F9, the one requirement with no evidence. Asked casually, but scored. |
| R1-3 | "Why this role, and why now?" | EXP | [generic] recruiter-screen motivation pattern; no candidate sentence in your message gives a reason | Give your own reason in one or two sentences. Your material gives none, so this is an open answer. Keep it to the work itself (complaints, members), not the employer's size. | Motivation consistency is a Skeptic check. |
| R1-4 | "What are your salary expectations?" | JD | [generic] logistics slot; no figure given | Give your own figure, or ask for the band first. Do not guess a band. | Pay is a logistics slot, not a bluff. |
| R1-5 | "What's your notice period?" | JD | [generic] logistics slot; no figure given | Give your actual notice period. | Knockout check. |
| R1-6 | "Where are you based, and which days can you work?" | JD | [generic] logistics slot; no figure given | State your location and the days you can work, in your own words. Mention it if you would move with a hub change. | The 2027 consolidation into five hubs may change where this role sits. |
| R1-7 | "Why are you leaving your current role?" | EXP | [generic] logistics slot; no reason given | Give one sentence in your own words. Keep it factual and forward-looking. | Logistics slot. |
| R1-8 | "You've never worked in a contact centre. What makes you ready to own a complaints process that runs through one?" | JD | [grounded] "Never worked in a contact centre" — your message | Plain acknowledgment: "I haven't worked in a contact centre." Then a plan, not a past: what you would learn first and from whom. | F4. This is the screen's likeliest knockout question, and your honest answer is the strongest. |

**Reverse questions (Round 1)**

- "What would a strong first 90 days look like in this role?" — Shows you think about outcomes, not the job description.
- "Which part of the complaints work is taking the most time right now?" — Shows you are listening for the problem, not just the role.

---

## Round 2 — Head of Member Services (45 minutes, your future manager)

**Persona weights**

| Persona | Questions | Why |
|---|---|---|
| Values / Behavioral | 5 | The recruiter says this round is mostly behavioural. Scored on STAR-shaped stories. |
| Skeptic | 2 | Your manager will test the contact-centre gap and senior presentation. |
| Case / Strategist | 2 | The role's digital and complaint-data work is practical. |

**Round 2 bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you told someone senior something they did not want to hear." | VAL | [generic] open prompt; theme from the Values persona stem; no candidate sentence carries an unwelcome truth | Selection scaffold: pick a time you told a senior person something unwelcome. It needs a named stake, what you said, and what happened. If none comes to mind, say so plainly, then give the nearest thing your material carries: the complaints log or the spreadsheet your regional manager uses. | Scored behavioural probe. Your material shows no such moment, so do not supply one. |
| B2 | "Tell me about a complaint where the member's side of the counter changed the outcome." | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Value: Members First. Story from the log: the complaints you handled. Answer slot: if a decision moved toward the member, say what you saw and what you did. If the log recorded complaints but you did not decide them, say so and describe what happened to them. | Maps to the first published value. Your message shows that you handled the log, not that you decided outcomes. |
| B3 | "Tell me about a time someone needed an explanation twice, and what you did." | VAL | [grounded] "trained new tellers on our escalation script" — your message | Value: Plain Words. Story: the script you taught new tellers. Answer slot: if you changed how the script was explained to members, say how. If you did not change the wording, say so and describe how you taught it. | Maps to the second value. Your nearest sentence is about staff training, not member wording. |
| B4 | "Tell me about a decision where the numbers pointed one way and the town pointed the other." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message | Value: Neighbours, Not Numbers. Your branch-supervisor years are the setting. Answer slot: if you have a decision where the local view mattered against a target, say what you did. If not, say so and describe how you would weigh the two. | Maps to the third value. Hub consolidation makes this a likely topic. |
| B5 | "Tell me about a problem you kept hold of until it was fixed." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Value: Own the Fix. Story: the spreadsheet you built, as a tool. Answer slot: if you kept a specific problem until it was solved, say which and what held it open. If the spreadsheet only reported volumes and you did not act on what it showed, say so. | Maps to the fourth value. A reporting tool is not a fix. Do not present it as one. |
| B6 | "You've never worked in a contact centre, and this role owns the complaints process across one. Where does your experience carry over, and where doesn't it?" | JD | [grounded] "Never worked in a contact centre" — your message; [grounded] "I handled the branch's formal complaints log" — your message | Highest-ROI rehearsal in this pack. Plain acknowledgment: "I haven't worked in a contact centre." Then the carry-over, using only the log: you know how a complaint moves through a branch. Hold that position through two follow-ups by returning to the branch work. Concede where the contact-centre side is new to you, and say how you would learn it. | This objection will come in some form. Its honest answer is the rehearsed one, and it changes the interview. |
| B7 | "Sixty seconds: why should I hire someone who has never presented above regional level?" | Pressure | [grounded] "I've never presented to anyone above regional level" — your message; [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Pause. Plain acknowledgment: "I haven't presented to anyone above regional level." Hold the one thing your material does show: a report your regional manager uses. Concede the senior-presentation gap explicitly and name how you would build it. | F7. Pressure test: hold through two follow-ups, then concede the gap; do not fold the reporting claim. |
| B8 | "How would you work with a digital team on a self-service journey you did not design?" | JD | [generic] live problem; the question presupposes nothing about your past | Structure it: what you would ask the digital team first, what complaint data would tell you about where journeys fail, and how you would bring member voice into design. No past claim. | F9 as a live problem. Tagged JD, CASE delivery. |
| B9 | "You inherit a complaints backlog on day one. Where do you start?" | CASE | [generic] live problem | Clarify the backlog's age and type first. Then separate what members are waiting for from what is only late. Name who holds each item. Say what you would report to your manager in week one. | Case coverage for the manager's own practical question. |

**Reverse questions (Round 2)**

- "How does the complaints process sit alongside the 2027 hub changes?" — Tests altitude: the hub plan is in the brief, and asking how the two fit signals you read it.
- "What did the last person in this role do well, and where did it stall?" — Turns an interview into a peer conversation about the job.
- "Which part of the digital target, the 40% by 2028, is most likely to change how complaints come in?" — Ties your question to the brief's own words.
- "What would you need from me in the first 30 days that you have not had from anyone in this role before?" — Shows you are planning to be managed, not just hired.

---

## Round 3 — Panel of two branch managers (60 minutes, including 20 minutes of case)

**Persona weights**

| Persona | Questions | Why |
|---|---|---|
| Case / Strategist | 2 | The 20-minute escalation case is one block. Two items cover it. |
| Values / Behavioral | 2 | The panel scores the four values. Your cheat sheet is in Round 3. |
| Peer Evaluator | 2 | Two branch managers are operational peers. Their questions are about the seam and disagreement. |
| Pressure | 1 | One composure test. |
| Data-Driven Prober | 1 | One defend-the-number question on your spreadsheet. |

**Round 3 bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | The 20-minute case: a member has complained twice at a branch and now wants the contact centre to escalate. The branch says the fee was correct. Walk us through the first hour. | CASE | [generic] pattern for a branch-to-contact-centre escalation; the actual case is not in the material | Clarify: what the member is asking for, and whether the fee rule was explained clearly. Check the file. Decide who holds the case: Own the Fix. Keep the decision on the member's side: Members First. Write the reply in plain words: Plain Words. Record the outcome and the reason. | You have not seen the actual case. Ask the recruiter for its brief (see the upgrade menu). |
| P2 | "Consolidation takes eight branches into five hubs over 2027. What do you tell a member in one of the towns that is closing?" | VAL | [grounded] "consolidate eight branches into five hubs over 2027" — your summary of the brief; [grounded] "every branch is part of its town" — Ashgrove's Neighbours, Not Numbers value | Do not argue the strategy. Say what you would tell the member, what you would own, and what you would not promise. | This is the hardest question for a panel of branch managers. The value is theirs; the plan is the company's. |
| P3 | "Tell me about a time a peer at your level disagreed with how you were handling a complaint." | Peer Evaluator | [generic] open prompt; theme from the peer stem; the nearest sentence is "I handled the branch's formal complaints log" — your message | Selection scaffold: pick a disagreement with a peer, what each of you wanted, and how it resolved. If none comes to mind, say so, then give the nearest thing the log carries. | Peer disagreement is the panel's collegial test. |
| P4 | "Where is the seam between a branch complaint and the contact centre, and who decides when they disagree?" | JD | [grounded] "across branches and the contact centre" — JD; [grounded] "Never worked in a contact centre" — your message | Propose principles for the seam, not a claimed answer. Plain acknowledgment: "I haven't worked in a contact centre," then how you would learn the seam from the people who run it. | F3 and F4 in front of peers. |
| P5 | "Why would we trust your escalation judgement over ours? You have supervised for three years." | Pressure | [grounded] "the last 3 as a branch supervisor" — your message; [grounded] "trained new tellers on our escalation script" — your message | Hold: your three years as supervisor and the escalation script you taught are the position. Concede what you have not yet done at branch-manager level. Do not fold on the core. | Composure test on your strongest sentence. |
| P6 | "Write three sentences to a member who was charged twice. Read them to us." | CASE | [generic] live problem; no past claim | Say the fact first, then the fix, then the next step. Avoid internal terms. Read it aloud once. | Plain Words in a live exercise. |
| P7 | "Your spreadsheet reports monthly complaints. How many did it count last month, and how long did they take?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | You have given no figure. Honest answer: if you can name the count, say how it was counted. If the spreadsheet did not track time to resolve, say so. A figure you give raises the defend-the-number questions: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. | F6 and F8. Expect the prober's question on the figure, not the reporting. |
| P8 | "Tell me about a time you chose the member's side when the branch wanted a different answer." | VAL | [generic] open prompt; theme from the Members First value; nearest sentence is "I handled the branch's formal complaints log" — your message | Selection scaffold with honest branch: pick a complaint where the member's view and the branch's view differed. If you did not choose, say so and describe what happened. | Second Members First probe, from peers. |

**Values cheat sheet (Round 3, shared panel)**

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | F2's sentence, the complaints log. B2 and P8: pick a complaint where the member's side mattered. Honest branch: if the log only recorded complaints, say so. |
| Plain Words | If a member needs it explained twice, the wording was wrong. | F5's sentence, the escalation script you taught tellers. B3 and P6: the script, and whether member wording was yours to change. Honest branch: if you did not change the wording, say so. |
| Neighbours, Not Numbers | Every branch is part of its town. | F1's sentence, six years in retail, the last three as supervisor. B4 and P2: a branch decision where the town mattered against a target. Honest branch: if none, say how you would weigh them. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F6's sentence, the spreadsheet you built. B5 and P1: a problem you kept hold of until solved. Honest branch: a tool that reports is not a fix. Say so if so. |

**Reverse questions (Round 3)**

- "When a complaint moves from a branch to the contact centre, who holds it, and when does it change hands?" — Shows you look for the seam and who owns it. Peer reciprocity.
- "What could a new person do in their first month that would genuinely help your branches?" — Reciprocity: the branch managers are peers; this asks what you bring to their work.
- "Which branch's complaints would you want me to look at first?" — Shows you want to start with members, not reports.

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | R1-1, B4 |
| experience handling regulated complaints | B2, R1-1 (answer slot on F2) |
| Own the member complaints process end to end across branches and the contact centre | B6, R1-8, P4 |
| report monthly on complaint volumes and resolution times | P7 |
| coach branch supervisors on escalations | P5 (answer slot on F5) |
| work with digital teams on self-service journeys | R1-2, B8 |
| confident presenting to senior leaders | B7 |
| comfortable with Excel reporting | P7 (answer slot on F8); no question on Excel itself — none, and why: the spreadsheet is covered by P7 |

---

## Sources

- Provided documents: the JD text, the four published values (copied from ashgrovecu.org/about/values on 19 November 2026), the recruiter's email, your summary of the July 2026 strategy brief, and your background.
- Searches and fetches: none sent.

Research tier: L0 — no searches; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values were pasted from the company page this morning, so the values cheat sheet needs no search. |
| 2. `Ashgrove Credit Union interview process Member Experience Lead` | skipped | The recruiter's email fixes the loop: three rounds, their lengths and content, and the panel scoring against the values. |
| 3. `Ashgrove Credit Union strategy / recent news` | skipped | Your summary of the July 2026 brief supplies the current priorities. Reading the brief itself would strengthen the grounding brief. |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names were given, so there is no query to form. |
| 5. representative Member Experience Lead JD | skipped | The JD you sent fixes the fit snapshot and the JD-tagged questions. |

---

## Upgrade menu

- The Head of Member Services and the two branch managers' names → persona weights from their public footprint, and a reverse question tied to their career path.
- The recruiter's brief for the 20-minute case, or its scoring → replaces the generic case P1 with the real one, so P1 becomes `[grounded]`.
- The text of the July 2026 strategy brief, pasted → the grounding brief quotes the brief's own words, and P2 and the reverse questions rest on text, not your summary.
- Your answers to the answer slots (F2, F3, F5, F6, F8, F9) → those rows move from answer slots to stories, quoted in the Provenance column.
- Your notice period, salary expectation, location, and reason for leaving → fills the Round 1 logistics slots (R1-4 to R1-7) in your own words.
- A `tuesday-dossier.md`, if one exists from an earlier session → would add verified evidence and any objections already tested.
