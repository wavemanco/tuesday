# Stripe: Product Operations Manager, final round. Interview prep pack

**Built on:** the role and company you named. No CV, no job description, no interviewer name and no round details were supplied, and web search was refused in this session. Every row and question is `[generic]`. Nothing here is a claim about Stripe's values, process or strategy.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **VAL**: behavioral and values. **EXP**: your own past work. **JD**: the role's requirements. **CO**: company and strategy. **CASE**: a live problem.
- Guidance is scaffolding, not a script. Say only what you did, in your own words.

## Fit snapshot (worksheet variant)

No CV and no job description are in hand, so no requirement is quoted and no evidence is quoted. The requirements are role-family prose. Every evidence cell reads `none given`. Gap type is `discovery` throughout, because the material is silent, not because you have stated an absence.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designing or running planning and review forums for a product org (role family, unquoted) | none given | none | [generic] | discovery | Strong evidence is one forum you took part in, with what it decided and your part in it. Scaffold: pick one planning or review forum. Say what it decided and what you did in it. If you have none, say so plainly, then describe how you would set one up. |
| F2 | Defining and tracking outcome measures (role family, unquoted) | none given | none | [generic] | discovery | Strong evidence is a measure you chose, with how it was counted. Scaffold: pick one measure you used. Say what it counted, who relied on it, and its weakest assumption. If you have none, say so, then say what you would measure first. |
| F3 | Coordinating product, engineering, finance and go-to-market on one decision (role family, unquoted) | none given | none | [generic] | discovery | Strong evidence is a decision that needed three or more functions. Scaffold: pick one such decision. Say who had to agree, what you did, and what stayed open. If none comes to mind, say so, then give the nearest one. |
| F4 | Driving a launch or initiative whose ownership was unclear (role family, unquoted) | none given | none | [generic] | discovery | Strong evidence is a launch you drove to a finish without a clear owner. Scaffold: pick one. Say what was unowned, what you took on, and what you left to others. If none exists, say so and describe how you would establish ownership on day one. |
| F5 | Writing a summary a senior leader acts on (role family, unquoted) | none given | none | [generic] | discovery | Strong evidence is a document a leader acted on, with the decision it fed. Scaffold: pick one document you wrote for a senior reader. Say what decision it fed and what you would change about it. If none exists, say so and describe the first document you would write. |

## Prohibited claims

None yet. No sentence from your own material is in hand, so no stretched form of one can exist. Until a CV or your own quoted sentences arrive, the one binding rule is that no answer claims ownership of a metric, a launch, a forum or a decision unless you state it in your own words.

## Persona table

Relationship, round and interviewer roles are unknown, and no loop source is in hand. The fallback is a generic archetype, so weights are flat and said plainly. No values-style round is detected, so no values cheat sheet is included.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live planning and launch problems | High. Flat weight, depth 3. A live problem is the usual test for this role family `[generic]` | Clarify, then structure, then name the first check |
| Data-Driven Prober | Follow-ups on how a figure was counted | High. Flat weight, depth 3 | Name the weakest assumption before it is asked |
| Skeptic | Gap and motivation probes | High. Flat weight, depth 3 | One real gap, one ramp plan, no bluffing |
| Pressure / Stress | Time-boxed challenges to your position | Medium. Flat weight, depth 2 | Pause, restate, hold two follow-ups, then concede only what is real |
| Peer Evaluator | Seams between functions, credit | Medium. Flat weight, depth 2. Applies if an interviewer is a peer | Propose seam principles, not invented history |
| Conversational / Rapport | Open, friendly openers that are still scored | Medium. Flat weight, depth 2 | A ninety-second arc, rehearsed aloud |

## Question banks

Provenance is `[generic]` for every row, and no row says anything about your past. Rows marked as open prompts ask you to choose an instance. Answer slots are instructions for the interview, not questions to answer here.

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A quarterly launch review has slipped two weeks in each of the last three quarters. How would you find out why?" | CASE | [generic] | Clarify first: what counts as slipping, measured from when, and who set the date. Split the causes into scope, dependencies, and decisions waiting on someone. Say what you would check first and the one change you would test. | A live problem from the role family. It presupposes nothing about your past. |
| A2 | "You are asked to set up how a product org plans each quarter. What do you build first?" | CASE | [generic] | Ask which decisions leaders must make and by when. Start with the smallest cadence that forces those decisions. Name the artifact it produces and the review it feeds. | Planning design is a common live problem for this role family. F1 is the row it tests. |
| A3 | "Which metric would you cut from a product dashboard first, and what would replace it?" | CASE | [generic] | Name the decision the metric feeds. A metric nobody acts on goes first. Propose a replacement that is harder to game, and say what would prove you wrong. | Tests reasoning about measures, not your history. F2 is the row it tests. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "How would you tell whether a process change actually worked?" | JD | [generic] | Name the baseline, the comparison group, the time window, and the metric's weakest assumption. Say plainly what you could not separate from the change. | The prober's standard follow-up, answered as method. F2 is the row it tests. |
| B2 | "Tell me about a metric you defined yourself, and how you knew it was right." | EXP | [generic] | Open prompt. Pick a metric you defined, or one you used and say whose it was. Say what it counted and its weakest assumption, in your words. If you defined none, say so plainly, then give the nearest metric you tracked and who owned it. | The prober reads for attribution. No sentence from you is in hand, so the guidance claims nothing. F2 is the row it tests. |
| B3 | "Which number from your work would you defend least?" | EXP | [generic] | Open prompt. Choose one figure. Name the assumption behind it before the interviewer does. If you cannot say how it was counted, say so. | The defend-the-number move. A figure you give is the one a prober will test. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one real gap in one sentence. Then the ramp: what you would do in the first thirty days to close it. If you can name no gap, name the area you would check first and why. | The skeptic's standard probe, and the highest-ROI rehearsal in this pack. A bluffed answer fails it, and this is the question most likely to come in some form. |
| C2 | "Your background may not look like product operations on paper. What is the strongest case you would make that it is?" | EXP | [generic] | Name the closest work you have done, at its real scope, and say what it does not cover. Let the interviewer draw the link. If no such work exists, say so and describe the ramp. | The skeptic tests whether the story survives cross-examination. |
| C3 | "Why this role over the other roles you could take?" | JD | [generic] | Answer with the part of the job you most want to do and why. Keep claims about the company to what you have checked yourself. | Motivation consistency is scored by the skeptic. |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone who has done this exact job?" | JD | [generic] | Pause and restate the question. Answer with the one thing you would bring that you can back with an example. If pressed twice, concede plainly what the other candidate has that you lack and what you would do to close it. Hold through two follow-ups before conceding anything real. | A stress interviewer tests composure, not content. |
| D2 | "Pick the process you are proudest of. How much of it actually changed anything, and who would say so?" | EXP | [generic] | Open prompt. Say what changed and how you know, in your own words. If the change went unmeasured, concede that plainly rather than adding a number. | A pressure probe on attribution. |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Product, engineering and finance want different things from the planning process. Where does your job stop and theirs start?" | JD | [generic] | Describe decision rights as principles you would propose, not as history you have. Say what you would need from each function. | Peer seam-splitting. F3 is the row it tests. |
| E2 | "When a process change spans three teams, how do you handle credit?" | EXP | [generic] | Open prompt. Use "we" for the context and "I" for what you specifically did. If no such change comes to mind, say so and describe the nearest one. | A collegial credit probe. |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the path to here." | EXP | [generic] | Build a ninety-second arc in your own words: the work, its scope, and why this role follows. Rehearse it aloud until it runs under two minutes. | Casual openers are scored. The arc is the rehearsal. |
| F2 | "What are you reading or testing in product operations these days?" | CO | [generic] | Name one thing you actually use or read, and why. Do not name a tool you have only heard of. | A casual question on a current topic, still scored. |

## Reverse questions

1. "What does a strong first quarter look like in this seat?" Why it lands: the interviewer has to define success in their own terms.
2. "Where does product operations sit in decisions today, and where would you like it to sit?" Why it lands: it treats the function as a design question, which is how a peer would frame it.
3. "What would make you say in six months that this hire was a mistake?" Why it lands: it names the risk openly, which disarms a skeptic.
4. "How do you tell whether the planning process is working?" Why it lands: it turns the metric question around and asks for the interviewer's own measure.
5. "Which decision in this role has been made too slowly recently?" Why it lands: it asks for the real problem rather than the brochure version.
6. Only if an interviewer is a peer: "What could a new person do in their first month that would genuinely help your team?" Why it lands: it is reciprocity, and it turns the conversation into a peer one.

## Requirement coverage

No job description is in hand, so there is no list of stated requirements to map. The five rows in the fit snapshot are role-family prose, and their coverage is F1 to F5 through the banks as marked in each row's rationale.

## Sources

**Provided documents:** your message only. No CV, job description, interviewer profile or recruiter note was supplied.

**Calls sent and refused:** each returned "permission not granted" and no result.

- `Stripe company values principles`: refused
- `Stripe interview process final round loop product operations`: refused
- `Stripe strategy news 2026`: refused
- `Stripe "Product Operations Manager" job description`: refused

**Research tier: L1, searches 4 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Values cheat sheet, section 10. Not included, because no values page was read, and the pack names no Stripe values |
| 2. `Stripe interview process final round` | unavailable | Loop structure and persona weights. The archetype fallback applies, weights are flat, and the round is not described as a known structure |
| 3. `Stripe strategy / recent news` | unavailable | Current-strategy CO and CASE questions. Only F2 is CO, and it is generic |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | Quoted requirements in the fit snapshot. The rows stay role-family prose and `[generic]` |

## Upgrade menu

- The final round's sessions and each interviewer's role → loop-mode mini-packs with per-session persona weights, in place of the flat weights above.
- The job description text → the fit rows become quoted requirements, and the questions can cite the posting's own lines.
- Your CV or notes → the evidence cells fill with your own quoted sentences, and each selection scaffold becomes a story map wherever a sentence carries one.
- The recruiter's note on focus areas or a take-home → a graded-deliverable section for each one declared.
- Interviewer names → a public-footprint read of each person, persona weights from it, and a tailored reverse question.
- Stripe's values page, pasted → a values cheat sheet, if the recruiter names a values-style round.
- A session where web search is permitted → targets 1, 2, 3 and 5 run in place of the refused calls. A deeper pass is also available: up to 6 more searches and 2 more fetches, several more minutes. Say if you want it, and I will offer it once.
- A `tuesday-dossier.md` from earlier prep, if you have one → verified evidence and prohibited-claim guardrails for these banks.
