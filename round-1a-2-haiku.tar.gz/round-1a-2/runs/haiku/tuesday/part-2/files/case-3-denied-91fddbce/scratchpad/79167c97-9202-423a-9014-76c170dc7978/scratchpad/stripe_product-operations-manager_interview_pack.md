# Stripe: Product Operations Manager, final round prep pack

**Role:** Product Operations Manager
**Company:** Stripe
**Interviewer:** not given
**Round:** final round. Type and relationship to interviewers not stated, so persona weights are blended (see Persona table). Read as one multi-session final with unknown structure; this pack does not assume a loop.

## How to use

Personas describe how a question is asked. Types describe what is being scored.

- **VAL**: behavioral / values alignment
- **EXP**: work-experience deep-dive
- **JD**: role-driven requirement
- **CO**: company and strategy knowledge
- **CASE**: live problem, structured on the spot

Guidance is scaffolding, not a script. Nothing here describes something you did unless you said it yourself.

## Fit snapshot (worksheet variant)

No CV and no job description are in the conversation. The requirements below are role-family patterns, not quotes from a posting, so they are `[generic]` and unquoted. Every evidence cell is `none given`, so confidence is `none` throughout. Each row is a `discovery` gap: the evidence may exist, but nothing here shows it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designing or running an operating process that several teams depend on (role family) | none given | none | [generic] | discovery | Strong evidence looks like a process you set up that other teams used, and what changed because of it. Selection scaffold: pick one such process you ran or helped run. If you have none, say so, and say how you would learn this team's operating cadence first. |
| F2 | Launching a product change and measuring how it landed (role family) | none given | none | [generic] | discovery | Strong evidence looks like a launch where you defined the measure in advance and reported against it. Selection scaffold: pick one launch you were close to. If you did not define the measure yourself, say who did. |
| F3 | Defining and tracking operating metrics (role family) | none given | none | [generic] | discovery | Strong evidence looks like a metric you chose, the source it came from, and what you did when it moved. Selection scaffold: name one metric you tracked. If you did not choose it, say so. |
| F4 | Coordinating across product, engineering, finance and legal (role family) | none given | none | [generic] | discovery | Strong evidence looks like a decision that needed two or more of these functions, and your part in it. Selection scaffold: pick one such decision and say your own role in it. |
| F5 | Writing a brief or decision memo for senior leaders (role family) | none given | none | [generic] | discovery | Strong evidence looks like a document that changed a decision, with its audience named. Selection scaffold: pick one document you wrote and who read it. |

**Provenance rule for this table.** Each row's label is `[generic]` because its requirement comes from role-family knowledge, not a posting. Once a JD is supplied, these rows are re-derived from its own words.

## Prohibited claims

No candidate claims have been made yet, so there are no sourced entries and no inflated-form entries. The standing rule holds until a CV or your own sentences exist: do not rehearse a metric, team size, scale, tool, title or outcome you have not stated in your own words in this conversation.

## Persona table

No loop source was read, since the Stripe searches were refused (see Sources). Weights are therefore a judgment from the usual final-round shape, not from Stripe's documented process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live operating problem for the role | High. Product ops finals usually test structure on a live problem. Top weight, 4 to 5 questions | Clarify, then structure, then state your metrics and risks, thinking aloud |
| Values / Behavioral | Scenario mapped to published values | Medium. Big-tech structured loops often have one values-style round, but no loop source confirmed it here. 3 questions | Story per value only where you have one; otherwise say so |
| Skeptic | "Why leave, why here, why now?" and gap probes | High. Finals often press on motivation and fit. 3 questions | Rehearse the motivation answer until it is plain; name real gaps and a ramp plan |
| Peer Evaluator | Seam between your work and theirs | Medium. Likely if you meet a cross-functional partner. 2 questions | Propose seam principles, not false certainty |
| Pressure | Time-boxed challenge on your strongest claim | Low to medium. Could appear at a senior session. 2 questions | Hold a position through two follow-ups, then concede the specific uncertainty |

## Question banks

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A team's onboarding completion rate dropped 15% after a release. How would you diagnose it?" | CASE | [generic] | Clarify what changed and for whom. Define the metric. Segment (new versus returning, platform, region). Name two or three hypotheses, the data that would test each, and the risk of acting too early | Common live problem for this role family. No claim about the candidate, so no provenance quote is needed |
| A2 | "Sketch how you would set up the operating cadence for a launch touching four teams." | CASE | [generic] | Ask who owns the launch decision and what the decision needs. Propose one cadence (weekly review, one shared tracker, one escalation path). State what you would drop first if the cadence got heavy | Tests whether you structure coordination, not whether you have run one. Ties to F1 |
| A3 | "What would you need to know in your first 30 days?" | CASE | [generic] | Name three things you would ask about: the decision rights, the current metrics, and the people whose work you depend on | Low-cost question that shows you plan. Ties to F1 |

**Values / Behavioral** (3 questions: stated fallback, no published values read)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you had to deliver an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time a plan you backed was not what the room wanted. Name the stake, the moment you did not fold, and the state of the relationship afterward. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it | Open prompt. Theme from the persona stems. Ties to the Pressure bank |
| B2 | "When did you put a customer's need ahead of an internal metric?" | VAL | [generic] | Same scaffold: pick one such decision. Say what the metric was, what you gave up, and what the customer got | Open prompt. Common in operations roles |
| B3 | "Tell me about a process you changed that people resisted." | VAL | [generic] | Selection scaffold: name the process, the resistance, and the one thing that changed your opponents' minds, if anything | Tests change management in your own words. Ties to F1 |

**Skeptic** (highest-ROI prep)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Why leave where you are, why here, and why now?" | EXP | [generic] | The highest-ROI rehearsal in this pack: this is asked in some form in almost every final. Give your actual reason for leaving, in your own words. Then say what about this role matches it. Do not invent a reason to sound aligned | Motivation consistency is the most likely probe with no CV in hand |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one real gap. Give the ramp plan (what you would learn, from whom, by when). Do not bluff a competency the interviewer owns | Calibrated candor is what this probe scores |

**Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where's the seam between product operations and our team, and what happens when we disagree?" | JD | [generic] | Propose seam principles, such as who decides what, and how disagreement gets escalated. Do not pretend to know their team's specifics | Collegial version of the Skeptic's probes |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name how you credit others specifically. Describe one case where credit was contested, if you have one; if not, describe the practice you would follow | Partnership fit |

**Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | EXP | [generic] | Pause, restate the question, give one concrete reason in your own words. When challenged, hold through two follow-ups. Concede only the specific uncertainty, never the core claim | Tests composure under a time box |

**Session total: 10 questions.** Below the 18-question floor. Coverage is thin because no JD and no CV are in the conversation, and the pack will not invent requirements or history to fill the gap. The upgrade menu says what adds questions.

## Requirement coverage

No JD requirements supplied, so there is no requirement list to map. Coverage of the role-family patterns F1 to F5: F1 is covered by A2, A3, B3; F2 by none, and why: no launch detail to build a question on until a JD or CV arrives; F3 by none, and why: same reason; F4 by D1; F5 by none, and why: no document-writing probe without a JD or CV.

## Reverse questions

Each has a reason it lands.

1. "What does a strong first 90 days look like in this role?" Lands because it shows you are planning, not just interviewing.
2. "Where does product operations sit relative to product and finance today?" Lands because it shows structural awareness without assuming.
3. "What operating cadence does the team run on now, and what is the one thing you'd change?" Lands because it invites a candid answer and signals judgment.
4. "How do you know product operations is working?" Lands because it signals you think about measurement.
5. "What has the hardest part of this role been for people who held it?" Lands because it asks for candor, which the interviewer can give.
6. Reciprocity, if the interviewer is a peer: "What could a new person do in their first month that would genuinely help your team?" Lands because it turns the conversation into a working one.

## Values / principles cheat sheet

Omitted. The Stripe values search was refused, so no published values are in hand, and this pack will not use values from memory.

## Delivery coaching

Omitted. No working-style assessment was provided.

## Prohibited list (summary)

No entries. See the section above.

## Sources

Provided documents: none. No CV and no job description in the conversation.

Every search sent, with what came back:

- `Stripe company values operating principles`: refused (tool permission not granted)
- `Stripe interview process product operations manager final round`: refused (tool permission not granted)
- `Stripe strategy recent news 2026`: refused (tool permission not granted)
- `Product Operations Manager job description responsibilities qualifications`: refused (tool permission not granted)

Research tier: L1 — searches 4 of 6 attempted, all refused; fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Values cheat sheet, section 10: omitted. Would have named four principles by their published names |
| 2. `Stripe interview process product operations` | unavailable | Loop structure: the persona weights are a judgment, not a documented process |
| 3. `Stripe strategy` / recent news | unavailable | CO questions are generic. Would have moved the CO bank |
| 4. `{interviewer name} Stripe` | n/a | No name given |
| 5. Representative `Product Operations Manager` JD | unavailable | Requirements are `[generic]`. Would have moved the fit snapshot to `[inferred]` rows |

## Upgrade menu

- **The job description text** → the fit snapshot's `[generic]` rows become quoted requirements, and JD-tagged questions get written against them
- **Your CV** → each evidence cell fills with your own quoted sentences, and the story and defend-the-number questions become possible
- **Round type and who you are meeting** → the persona weights reweight and the reverse questions retune
- **Permission to run web research (WebSearch)** → Stripe's values, interview process and recent strategy become `[grounded]` and the CO and values sections can be built
- **The recruiter's prep email** → coverage of any exercise or presentation they announced
- **The interviewer's name** → a tailored reverse question and persona weights from their public footprint
- **A `tuesday-dossier.md` from a prior session** → carries forward gaps this prep has already found
