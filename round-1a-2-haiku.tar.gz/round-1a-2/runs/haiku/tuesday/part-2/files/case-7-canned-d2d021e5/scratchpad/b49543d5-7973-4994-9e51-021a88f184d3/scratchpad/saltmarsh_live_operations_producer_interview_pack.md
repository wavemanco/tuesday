# Saltmarsh Games: Live Operations Producer, hiring-manager interview (Friday)

Interviewer: Tobias Wrenfield, Head of Live Operations (hiring manager). Format per the careers page: one 60-minute "Outage Hour" session, a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.

Changelog: first pack; no earlier version.

## 1. How to use this pack

- **Personas** describe how a question will be asked. **Types** describe what is being scored: EXP (your past work, checked closely), JD (the listed job), CO (company knowledge), CASE (a live problem), VAL (the company's published values).
- Guidance is scaffolding, not a script. Say it in your own words and only what you actually did.

## 2. Fit snapshot

Requirements are the JD's own words. Evidence is quoted from what you sent me. Gap and bridge language is the only place a qualifier goes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | presentation | Your material says weekly content drops on one puzzle title. It does not say "live-service". Reword only what you have: "For four years I was an associate producer on a puzzle game with weekly content drops." Answer slot: if you would call that live-service, say why in your own words. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | No gap. Lead with the calendar in that sentence's own terms. Expect a probe on how the calendar was planned. |
| F3 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Presenting retention numbers is adjacent to owning them. Say what you presented, not what you analysed. Answer slot: how those numbers were counted, and which part was yours. |
| F4 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | The checklist is written communication in daily use. Expect a probe on whether it is still yours. |
| F5 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | One title, not two. Say that first. Answer slot: how you would plan one calendar across two titles, as a plan, not as something you did. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | none given; "Wrote the release checklist our QA team still uses" (your message) touches release work but not cross-team coordination | none | [grounded] | discovery | Answer slot: if you coordinated design, art, engineering or community on a drop, name them and what you handled; if you did not, say so and describe how you would run it. |
| F7 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | low | [grounded] | transferability | Presenting numbers is not owning the post-event review. Answer slot: whether post-event reviews ran, and which parts were yours. |
| F8 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | Quote reaches the requirement in role terms: you wrote it, QA uses it. Expect "who maintains it now?". Answer it from what you did. |

Notes on gates: the JD contains no legal, location or credential gate. "3+ years" is a length-of-experience line, graded above. Nothing here is a hard gate.

Notes on the JD's leadership picture: the JD does not ask you to lead people. It does ask you to coordinate four teams (F6). Your material says you have never led a team. That is a fact about your past, not a JD gap, and it is handled in the prohibited list and E1.

## 3. Prohibited claims

Built locally from the fit snapshot. These are not coached, in the form shown.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated: "Never led a team" | Plain acknowledgment: "I haven't led a team." Then how you would approach leading one, as a plan. |
| Owned the post-event review or the KPI reporting | Inflated form of F7: "Presented the monthly retention numbers to the studio head" | Quote at its own scope: "I presented the monthly retention numbers to the studio head." The pack's own observation: your material says presenting, not owning. |
| Ran live events across two titles | Inflated form of F5 | Quote at its scope: one title, weekly content drops. |
| Live-service experience, as a label | Inflated form of F1 | Say "weekly content drops on one puzzle title" unless you choose the term yourself. |
| Worked on in-app purchase economics | Negative you stated: "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then how you would learn their effect on a calendar, as a plan. |

## 4. Reading the interviewer

Public footprint only.

- Head of Live Operations at Saltmarsh. Previously a QA lead at a console studio (from the GDC 2026 listing).
- GDC 2026 talk, "Patch Notes Are a Promise": his argument is that a live team is judged by how often its patch notes describe what actually shipped.

Implications:
1. He will test precision. Say what shipped, what was built, and what was only planned. Do not round up.
2. QA is his home ground. Your release checklist is the strongest thing you can point to, and he will probe it.
3. Mirror opportunity: your checklist, quoted exactly ("Wrote the release checklist our QA team still uses"), is a QA-side artifact he will recognise.

## 5. Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The Outage Hour's live-incident tabletop; live problems on the real calendar | Highest. The careers page names a tabletop as the core of this session, and a hiring manager is buying capability (5 questions) | Clarify, then impact, then decision, then comms, then what you record for the review. Think aloud. |
| Values / Behavioral | The values conversation after the tabletop | High. The careers page names it (3 questions) | Map each value to a story only where a quote carries one; otherwise a scaffold and its honest branch |
| Skeptic | "Why you, for this JD?" | Medium. Hiring managers derisk gaps (3 questions) | Rehearse the IAP and team-lead gaps until boring; plain acknowledgment, then a plan |
| Data-Driven Prober | Questions on the retention number and the post-event review | Medium. Retention is a JD requirement and his talk is about accuracy (3 questions) | Know how the number was counted; name the weakest assumption you know; say plainly what you do not know |
| Pressure / Stress | Time-boxed challenge on "never led a team" | Lower for a 60-minute session, but the gap is the one most likely to be pressed (2 questions) | Hold the position through two follow-ups, then concede specifically |
| Conversational / Rapport | Opening biography and the "any questions?" slot | Medium at the start and end (2 questions) | Pre-scripted 90-second arc from your quotes; treat casual questions as scored |

Total: 18 questions. Top persona has 5; mid-weight personas 3; low-weight 2.

## 6. Values / principles cheat sheet

The values page names three values. The careers page documents a values conversation, so this round is values-style.

| Value (official) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | F3 row: no quote carries a player-over-calendar story. Scaffold: pick a time a calendar item and player feedback disagreed; if none comes to mind, say so plainly, then give the nearest thing your material carries: "Presented the monthly retention numbers to the studio head." |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | F8 row: "Wrote the release checklist our QA team still uses." Beats the quote states: you wrote it, QA uses it. Answer slot: if the checklist ever held a release back, say what; if it never did, say so and stay with the checklist. |
| Leave the Build Greener | Every release leaves the codebase and checklist better | F8 row: the quote does not say the checklist improved. Scaffold: if you revised it, say what and why; if it has not changed, say so and name what you would improve first. |

## 7. Question banks

Each row's Provenance carries every sentence its guidance rests on. The interviewer's Question is written as they would ask it.

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Live event, 18:00 launch. At 18:40 players report one reward granted twice. Walk me through the next 30 minutes." | CASE | [grounded] "live-incident tabletop on a simulated outage during a live event" (careers page) | Clarify scope and affected players; decide whether to pause the event; agree the message with community; record what happened for the review. No claim about your past. | The Outage Hour's core format, from the careers page |
| A2 | "Retention drops 9% the week after a Friday drop. What do you check first?" | CASE | [grounded] JD: "comfortable with player-retention metrics" | Clarify the metric definition and cohort; check what else shipped that week; segment by platform and version before blaming the drop. | Covers F3 as a live problem, not a memory |
| A3 | "You have two titles and one calendar. How would you plan next quarter?" | JD | [grounded] JD: "Plan and run the live-events calendar for two of our mobile titles"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Plan from principles: one calendar, one owner per drop, a freeze date, a review after each. Say that your calendar ran one title. Answer slot: if you have planned across two titles, say how; if not, say so and describe the plan. | Covers F5 and F2 |
| A4 | "The two titles move to one shared events calendar from February. What breaks first?" | CO / CASE | [grounded] "one shared events calendar from February 2027" (Saltmarsh news, search snippet only) | Name the likely failure points: shared freeze dates, cross-title conflicts, one live-ops group's queue. Ask what the team has decided already. | Grounded in the current strategy; the snippet is all that was read |
| A5 | "A drop needs art, design, engineering and community sign-off in five days. Walk me through the plan." | JD | [grounded] JD: "coordinate design, art, engineering and community teams on each update" | Plan: the sign-off order, who decides when two teams disagree, what the community hears and when. A plan, not a past. | Covers F6 as a live problem |

### Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "Players Before Plans: when the calendar and the players disagree, the players win" (values page); [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Open prompt. Pick an instance where player feedback and a calendar item conflicted. Answer slot: if none comes to mind, say so plainly, then give the nearest thing your material carries, which is presenting the retention numbers, and what you did with them. | The value's own question; the honest branch is required |
| B2 | "Tell me about a time you announced only what had shipped." | VAL | [grounded] "Ship the Patch Not the Promise: we announce what is built, not what is hoped" (values page); [grounded] "Wrote the release checklist our QA team still uses" (your message) | Map to the checklist: you wrote it, QA uses it. Answer slot: if the checklist ever held a release back, say what; if it never did, say so. | Strongest mapped story in the material |
| B3 | "How has the release checklist changed since you first wrote it?" | VAL | [grounded] "Leave the Build Greener: every release leaves the codebase and the checklist better than it found them" (values page); [grounded] "Wrote the release checklist our QA team still uses" (your message) | Scaffold: if you revised it, say what and why; if it has not changed, say so and name what you would change first. | Tests the third value without inventing a revision |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your background is a puzzle game. Have you ever run a game with in-app purchases?" | EXP | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then how you would learn their effect on a calendar, as a plan. No claim of IAP experience. | Highest-ROI rehearsal: the gap will come up |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never led a team" (your message); JD: "coordinate design, art, engineering and community teams on each update" | Plain acknowledgment: "I haven't led a team." Then the coordination without authority you would start with, as a plan. | Stem from the persona set; the honest answer is the gap itself |
| C3 | "Your calendar ran one title. Why should we trust you with two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message); JD: "Plan and run the live-events calendar for two of our mobile titles" | Hold the one-title fact, then say what carries across. Concede plainly where it does not. | Covers F5 under skepticism |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Defend-the-number: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you did the counting, say how in your own words; if you only presented them, say so plainly and say who counted. | F3's defend-the-number slot |
| D2 | "What would you put in a post-event review, and which KPIs would it report?" | JD | [grounded] JD: "own the post-event review and the KPIs it reports" | Plan-style: retention, a few event-level KPIs, what counts as a miss, and what the team does next. No past claim. | Covers F7 |
| D3 | "What did you do after a drop went out, to show whether it worked?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Open prompt. Answer slot: if you looked at results after a drop, say what; if you only reported the monthly numbers, say so plainly and describe how you would check a drop. | F7's honest branch |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire someone who has never led a team?" | JD | [grounded] "Never led a team" (your message) | Hold: "I haven't led a team." Hold the case for the coordination work you did, quoted only. Concede that leadership is unproven, specifically, and do not fold on the rest. | Hold-then-concede on the largest gap |
| E2 | "That release checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Hold the one thing the quote says: you wrote it. Say what QA changed, if you know, and do not claim more than the quote. | Tests attribution on F8 |

### Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Ninety-second arc from those two sentences, in your own words. | Opening question; casual but scored |
| F2 | "Which piece of release work would you change first?" | JD | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Name one change and why, as a plan. | Written communication and QA, asked casually |

### Coverage

| JD requirement | Questions |
|---|---|
| 3+ years producing live-service games or apps (F1) | F1, A3 |
| Content calendar experience (F2) | A3, F1 |
| Player-retention metrics (F3) | A2, D1, D3 |
| Clear written communication (F4) | F2, E2 |
| Live-events calendar for two titles (F5) | A3, C3, A4 |
| Coordinate design, art, engineering, community (F6) | A5, C2 |
| Post-event review and KPIs (F7) | D2, D3 |
| Release checklist with QA (F8) | B2, E2 |

## 8. Reverse questions

1. "You went from QA lead at a console studio to running live ops. What from the QA years shaped how you run a live calendar?" Why it lands: a peer conversation about his own path, from his public history.
2. "Project Larkspur puts two titles on one events calendar from February. What does a good first quarter look like for that calendar?" Why it lands: shows you read the current strategy.
3. "Your GDC talk says a live team is judged on patch notes that match what shipped. What would you check a post-event review against?" Why it lands: shows you read his work and connects it to the KPIs in the JD.
4. "What does success look like for this role at six months?" Why it lands: the standard question done well.
5. "What is the live-ops risk the team is carrying into next year?" Why it lands: a question an interviewer can answer usefully.

## 9. Prohibited-list check

Section 3 covers the prohibited claims. No question, answer slot or reverse question asserts a leadership, IAP, KPI-ownership or two-title claim.

## 10. Sources

Provided documents: your message (background and the JD text).

Searches and fetches, with what came back:
- "Saltmarsh Games values": saltmarshgames.com/values (fetched).
- "Saltmarsh Games interview process live operations producer": saltmarshgames.com/careers/interviewing (fetched).
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations": a GDC 2026 talk listing, talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only; not fetched).
- "Saltmarsh Games news 2026 live game update strategy": saltmarshgames.com/news/project-larkspur (search snippet only; not fetched).

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet, section 6: three values by name |
| 2. `Saltmarsh Games interview process {role family}` | yes | Loop structure: recruiter call, then the 60-minute Outage Hour; values-style round detected; persona weights |
| 3. `Saltmarsh Games strategy` / recent news | yes | Project Larkspur (Sept 2026): Tidepool Tactics and Lantern Row to one shared events calendar from February 2027; question A4 and reverse question 2. Read from a search snippet only; the full page was not fetched |
| 4. `{interviewer name} {company}` | yes | Interviewer read, section 4: prior role and a GDC 2026 talk. Snippet only |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 11. Upgrade menu

- Tell me the Friday format from the invite or the recruiter, if it differs from the careers page (one 60-minute session with the hiring manager) → confirms the loop; no change to the persona weights unless it differs.
- The full Project Larkspur announcement pasted → A4 and reverse question 2 move from snippet-level to full-text grounding.
- Your release checklist's current version, or a description of its sections → B2, B3, E2 and F2 can use the real content, not just the sentence you sent.
- A list of the two titles' cadences and sizes → A3 and C3 can be answered from numbers you gave, not from a plan.
- A deeper research pass, up to 6 more searches and 2 more fetches, several minutes: a strategy brief, the interviewer's other talks and writing, and role-family loop reports → a grounding brief and a deeper reverse-question bank. Want it?
- A recruiter email confirming whether the 60 minutes is the whole session → confirms the timing of the tabletop versus the values conversation.
