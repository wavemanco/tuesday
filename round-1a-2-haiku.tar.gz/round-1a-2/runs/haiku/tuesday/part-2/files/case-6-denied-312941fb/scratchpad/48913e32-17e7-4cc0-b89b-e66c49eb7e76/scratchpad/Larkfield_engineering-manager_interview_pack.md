# Interview Prep Pack: Engineering Manager, Larkfield Systems

**Role:** Engineering Manager (industrial IoT, ~600 people). Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap.
**Candidate:** Yusuf
**Rounds (loop mode, three sessions):**
- H: Director of Engineering, hiring manager, Tuesday, 45 min
- P: Two staff engineers and a product manager, panel, Thursday of the following week, 60 min
- V: VP Engineering, Monday, 30 min, "values and leadership philosophy" (recruiter's words)

No interviewer names were given, so there is no interviewer read. No research ran (see Sources). Questions tagged `[generic]` rest on role-family patterns, not on anything published about Larkfield.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script.

- **JD**: the role's stated requirements
- **EXP**: whether your past work survives scrutiny
- **CASE**: a live problem from the role
- **VAL**: whether past behavior shows the values being asked about
- **CO**: company and strategy knowledge (not covered: research did not run)

## Fit snapshot

Shared across all three rounds. Requirements are quoted from your role description. Your evidence is quoted from your own messages only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role description, your message) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows a team of six led for three years, not two squads or a device product. Bridge at its own scope: "For three years I was team lead of six." Answer slot: if you have led work across more than one team, or anything with a device or hardware dependency, say what it was and how you led it; if you have not, say so plainly and say how you would learn the device side. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role description, your message) | "I run our hiring loop for backend roles" (your message); "about 40 interviews last year" (your message) | medium | [grounded] | none | Hiring is covered in role terms: you run the loop. Expect a probe on the backend scope, since the role's hiring is for all of its engineers. Say the backend scope yourself before it is asked. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role description, your message) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | This is delivery work on one reliability quarter and one team's on-call load, not ownership of delivery for 11 engineers. Bridge at its own scope. Answer slot: if you set the team's delivery commitments for a quarter, say how you decided them; if the roadmap was set above you, say so plainly and say what you pushed for. |
| F4 | "own delivery, hiring and growth for 11 engineers" (role description, your message) | none given | none | [grounded] | discovery | Your material does not show growth work. Answer slot: if you have moved an engineer into bigger scope or changed how someone was growing, say what changed and how you judged it; if you have not, say so plainly and say how you would start. |
| F5 | "partner with hardware and product on roadmap" (role description, your message) | "never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | The candidate stated this absence. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan, never as a past. Never a claim to hardware roadmap work. |
| F6 | "partner with hardware and product on roadmap" (role description, your message) | "pushed a reliability quarter through against roadmap pressure" (your message) | low | [inferred] | discovery | Your sentence touches roadmap negotiation but does not show partnering with hardware or product. Answer slot: if you have shaped a roadmap with product or hardware, say what you did and what they did; if that did not happen, say so plainly and describe how you handled the pressure. |

The gap types follow the routing in `references/output-template.md`. F5 is the only capability gap because you stated it.

## Prohibited claims

Built locally from the fit snapshot. Nothing here may be asserted, softened or implied in any answer, hold or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| Owning a hardware-adjacent roadmap | Stated negative, F5 | "I've never owned a hardware-adjacent roadmap." Plus the plan for learning it. |
| Having managed managers | Stated negative: "I've never managed managers" (your message) | "I've never managed managers." Then what you would do in the first month. |
| Leading two squads | Inflated form of F1 | "For three years I was team lead of six." |
| Having caused the 60% drop alone | Inflated form of F3's quote | Your quote at its own scope. The material says the burden dropped and that you pushed the quarter through; it does not say what share of the drop was yours. |
| Having designed the hiring process | Inflated form of F2's quote | "I run our hiring loop for backend roles." |

## Persona weights per round

| Round | Dominant personas | Reasoning | Counter-strategy |
|---|---|---|---|
| H (Director, hiring manager) | Case/Strategist (high), Skeptic (high), Pressure (low) | Hiring-manager prior: they are buying capability and checking gaps, and expect a live problem on their own roadmap. F5 and F1 are where they will press. | Clarify before structuring. Name the hardware gap before they do, and say how you would learn it. |
| P (panel) | Data-Driven Prober (high), Peer Evaluator (high), Case (mid), Pressure (mid) | Staff engineers blend Prober and Pressure; the PM blends Peer and Case. No names, so personas cannot be assigned per member. | Know how every figure you give was counted. Use "we" for the team, "I" for your part. |
| V (VP, values round) | Values/Behavioral (high), Pressure (mid), Case/Strategist, strategy-heavy (low) | Your recruiter's words, "values and leadership philosophy", establish a values-style round. No published values were read, so the VAL questions use selection scaffolds. | Pick the story that shows the hard call, not the one that was easiest to tell. Say where the material shows none. |

## Round H: Director, hiring manager (Tuesday, 45 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Two squads are shipping device-management services and you take them over next month. What do you need to know first?" | CASE | [generic] | Clarify: what the squads own, what the hardware team commits to, what product has already promised. Then structure: stabilise delivery, learn the roadmap, make the first hiring call. Name what you would ask the hardware lead before any decision. Make no claim about your past. | Live problem from the role's roadmap line (F5, F6). `[generic]` because it is a pattern for the problem, not a fact about Larkfield. |
| H2 | "Walk me through the reliability quarter, and how you got it through against roadmap pressure." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Tell the quarter in your own words: the pressure, what you pushed for, the on-call result. Stay inside the sentence. Weakest-assumption move: name the assumption behind the 60% you would defend least. Answer slot: if you counted it, say how and what you would defend least; if you did not count it that way, say so plainly. | F3 is the most likely place for a figure to be probed; a figure raises a defend-the-number slot. |
| H3 | "Which part of this role would you be weakest at on day one?" | Skeptic stem | [grounded] "never owned a hardware-adjacent roadmap" | Highest-ROI prep in this pack. Say: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, in the order you would learn it: the hardware team's constraints, the device lifecycle, then the roadmap. Hold through one follow-up, then concede the gap plainly. | F5 is a stated gap, and it is the objection this role is most likely to raise. |
| H4 | "I don't see hardware roadmap ownership in your background. How would you handle that here?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | Same acknowledgment as H3, then the plan. Do not add a partial example. If asked for one, say which part was adjacent and what it did not include. | Same objection as H3 in a sharper form; the premise is your stated negative. |
| H5 | "How do you run hiring for a team you are building?" | JD | [grounded] "I run our hiring loop for backend roles"; "about 40 interviews last year" | Describe the loop you run, its stages and how you decide, all in your words. Say that it covers backend roles. Answer slot: if you have hired for roles outside backend, say how; if not, say so plainly and say how you would set the bar for them. | F2 is a clean fit on hiring; the probe will be the backend scope. |
| H6 | "How have you grown engineers into bigger scope?" | JD | [inferred] growth requirement, role description | Open prompt. Choose one engineer you grew, and say what changed. Selection scaffold: if no such time comes to mind, say so plainly, then give the nearest thing you did, or how you would start. | F4 has no quote. Do not invent a growth story. |
| H7 | "You have led six people. Why would eleven be different?" | Pressure | [grounded] "3 as a team lead of 6" | Hold: team size changes the work, and the work you did with six is still yours. Hold through two follow-ups by returning to the six. Concede where it is true: eleven engineers across two squads is more coordination than you have run. Say what you would change first. | F1 is the scope gap. The second follow-up is where a held position without a story breaks. |
| H8 | "Roadmap pressure: product wants a feature next quarter, the hardware team says the firmware cannot support it. What do you do?" | CASE | [generic] | Clarify what the firmware limit is and what product's date is tied to. Structure: separate the constraint from the pressure, then decide with both leads in the room. Name who decides if they do not agree. | Live problem on F6's partnering requirement. Make no claim about a past decision. |

Reverse questions (H): "What did the last manager of these squads do that you want me to keep?" Why it lands: it asks for their standard without asking for a judgment. "Where does the hardware team's roadmap get decided, and who has final say?" Why it lands: it tests the partnering model you will need in week one.

## Round P: Panel, staff engineers and product manager (Thursday, 60 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "The 60% on-call drop: how was it counted, and which part of it do you think is weakest?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer in your own words: what was counted, over what period, and the assumption you would defend least. Answer slot: if you measured it, say how; if you did not, say so plainly and say what you tracked. | A prober's exact question on F3. Figure raises the defend-the-number slots only. |
| P2 | "Walk me through how delivery was tracked across that quarter." | EXP | [grounded] "pushed a reliability quarter through" | Describe the tracking you did, in your words. Answer slot: if you tracked delivery in a particular way, say what and how often; if no tracking was set up, say so plainly and say what you used instead. | A premised question with no quote for tracking. The second branch must allow that tracking never existed. |
| P3 | "Where is the seam between your squads and the hardware team, and what happens when you disagree?" | Peer stem | [generic] | Propose principles for the seam: who owns the interface, how disagreements escalate, who decides. Do not claim you know their seam. Disagreement story only if you have one: say what you disagreed about, and what you did. | Peer seam question on F5/F6. The hardware seam is one you have not worked, so state the principle, not an experience. |
| P4 | "How do you handle credit when work spans teams?" | Peer stem | [generic] | Scaffold: say "we" for the team, "I" for your part. If you have a case, name it in your own words; if not, say how you would handle it. | Standard peer probe; no past claim needed. |
| P5 | "You have never owned a hardware roadmap. Why should we trust your judgment on firmware constraints?" | Pressure | [grounded] "never owned a hardware-adjacent roadmap" | Hold: your judgment is about the trade-offs you can see, not firmware detail, which you would learn from the team. Hold through two follow-ups. Concede the gap in the detail. | Staff engineers will press this from the technical side. |
| P6 | "Our device fleet grows about a third each quarter. What do you need to know before you plan the next two quarters?" | CASE | [generic] | Clarify: what is growing (devices, services, on-call load), what the constraints are, and what the roadmap commits to. Structure: capacity, reliability, then hiring. Name the metric you would use and its weakest assumption. | Live problem from the device-management role. Make no claim about your past. |
| P7 | "What debt would you refuse to put on the roadmap?" | JD | [generic] | Name one kind of debt you would refuse and why, in terms you can defend. Do not cite a specific past refusal unless you have one; if you do not, say the principle. | Probes judgment on delivery ownership (F3) without asking for an event. |
| P8 | "What would a new person do in their first month that would genuinely help your team?" | Reciprocity | [generic] | Answer with what you would do for their team, not what you need. Name one concrete first-month action. | The reciprocity question a peer round rewards. |

Reverse questions (P): "Where do the staff engineers see the biggest drag on delivery right now?" Why it lands: it turns a panel into a working conversation about the job. "What does the PM expect from an engineering manager in the first quarter?" Why it lands: it shows you are planning around product, not just engineering.

## Round V: VP Engineering, values and leadership philosophy (Monday, 30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | Open prompt. The reliability quarter is the closest story your material carries: say the pressure, the position you held, and the on-call result. Answer slot: if the truth reached leadership and changed a decision, say what they decided; if it did not land, say so plainly and say what happened next. | Values-style round recruiter named. VP-level hard-truth probe. |
| V2 | "What is your leadership philosophy, in a sentence you would defend?" | VAL | [generic] | Scaffold: one principle, then one decision that shows it. If you have no decision behind the principle, say the principle and say you have not tested it. | Your material has no philosophy statement; do not invent one. |
| V3 | "In sixty seconds: why grow engineers rather than hire senior ones?" | Pressure | [generic] | Hold a position you can defend: growth is cheaper and retains context, but it takes time. Concede the limit: it fails when the team needs seniority now. Do not cite a case you have not got. | Skip-level composure probe on F2 and F4. |
| V4 | "What would you bet on for our device fleet in three years?" | CO | [generic] | No research was run, so you know nothing about Larkfield's strategy from the web. Say that the bet depends on the strategy you have not seen, name the two forces you would watch, and ask for the strategy. | Altitude probe. `[generic]` because no strategy source was read. |
| V5 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Scaffold: name a customer-facing decision if you have one. Your reliability quarter is the nearest; do not claim it was customer-led unless you can say how. | Customer-first is a common value probe; the material does not show a customer story. |
| V6 | "You have never managed managers. What would you do in your first month if you did?" | Skeptic | [grounded] "I've never managed managers" | Say: "I've never managed managers." Then the plan for the first month: meet the managers, learn what they hold, decide what to change. | A stated negative. Plain acknowledgment, then plan. |
| V7 | "Give me the one thing about your leadership you would change." | Pressure | [generic] | Name one real habit and the evidence for it. Do not invent a fault to look humble; the honest answer is the one you can show. | Composure probe; an invented weakness is a second coached claim. |

Reverse questions (V): "What does a manager of managers do that a manager of engineers does not?" Why it lands: it asks what the job is, not what you would be paid. "What would make the first six months a success for you?" Why it lands: it shows you are thinking about their priority, not yours.

## Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| Lead two squads building device-management services | H7, P1, P6 | F1 is the scope gap |
| Own delivery | H2, P1, P2 | F3 |
| Hiring for 11 engineers | H5 | F2, backend scope |
| Growth | H6, V3 | F4 has no quote |
| Hardware roadmap partnering | H3, H4, P5, H8 | F5 is a stated gap |
| Product roadmap partnering | P3, P6, H1 | F6 |
| Values (recruiter's words) | V1, V2, V5 | No published values in hand |

## Values cheat sheet

Dropped. A values-style round was detected, but no published Larkfield values were in hand, and the condition for this section requires them. Paste the values page to restore it.

## Sources

- Provided documents: your message (role description, background, round details, the recruiter's "values and leadership philosophy").
- Searches sent, all refused by permission:
  - "Larkfield Systems values": refused
  - "Larkfield Systems interview process engineering manager": refused
  - "Larkfield Systems strategy news industrial IoT device management": refused

Research tier: L1, searches 3 of 6, fetches 0 of 2

| Target | Status | What it would have moved |
|---|---|---|
| 1. Larkfield values | unavailable | Values cheat sheet (dropped); V1, V2, V5 are `[generic]` scaffolds |
| 2. Interview process, engineering manager | unavailable | Loop structure. The loop is established by your message, not by research |
| 3. Strategy and recent news | unavailable | CO question V4 is `[generic]` |
| 4. Interviewer name | n/a | No names given |
| 5. Representative JD | skipped | The pasted role description fixes the fit snapshot |

## Upgrade menu

- Full job description text → exact requirement quotes replace the summary, and H1, H8, P6 can be tied to posted language
- Recruiter's prep email (focus areas, any take-home or presentation) → coverage of any pre-declared deliverable
- Interviewer names for the Director, panel and VP → interviewer read, per-member personas for the panel, and reverse questions tied to their career paths
- Larkfield's published values page, pasted → the values cheat sheet for round V, and V1, V2, V5 move from scaffolds to mapped stories
- Web search permission for a rerun of research targets 1 to 3 → grounded values, loop structure and strategy in place of `[generic]` rows
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → a strategy brief for V4 and the strongest CO questions
- Prep time available → a prioritized schedule, most important first
- Any location, on-site days or work-authorization requirement in the posting → gate rows in the fit snapshot
