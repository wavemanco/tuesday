# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second-round panel, 60 minutes. Deepa (VP Partnerships, future manager) and Ross (Commercial Director). First 15 minutes: a spoken POV on operator partnerships over 18 months, landing on what it means for operators. Remaining 45 minutes: Q&A, with commercials pressed by Ross.
**Built on:** the recruiter's email, your background message, no JD text, no research (see Sources).

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored: **VAL** behavioural/values, **EXP** your past work, **JD** the listed role, **CO** commercial and company knowledge, **CASE** a live problem. Guidance is scaffolding, not a script. Quotes in the Provenance column are your own sentences; say things in your own words, but do not go beyond what the quote says.

## Prep triage (about 4 hours)

1. **The POV, about 90 minutes.** Write three notes (the theses in section 6), then say the whole 15 minutes aloud twice, timing it. Stop at 15.
2. **The commercial hold, about 60 minutes.** B1, B2, D2, D3. Say the hold, then the concession, out loud, until it is plain.
3. **The rail-gap answers, about 45 minutes.** A4, B3, C2. Keep each short.
4. **Reverse questions and the close, about 30 minutes.** Pick five from section 9.

Everything else is insurance.

## Fit snapshot

Requirements come from the recruiter's own words, quoted. The JD was not supplied, so role requirements beyond these are `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | presentation | Your material gives partner growth and an influenced-revenue figure. It does not show an operator strategy. The bridge stays at the quote: you grew a partner channel from six to forty. |
| F2 | "what it means for the operators themselves" (recruiter email) | "bus and light rail network planning, so I know the operator world from the other side" (your message) | medium | [grounded] | presentation | You have the operator-side view from planning work. Say what planning work taught you about operators; do not extend it to how operators buy. |
| F3 | "Ross will push on commercials" (recruiter email) | "never carried a direct quota, only influenced revenue" (your message) | medium | [grounded] | capability | You stated the absence. Words: "I haven't carried a direct quota. What I've carried is influenced revenue." Then how you would learn the commercial model, said as a plan. |
| F4 | Sell into rail (inferred from the role's title and the panel's focus, `[generic]`) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | Words: "I haven't sold into rail." Then how you would learn it, as a plan, never as a past. |
| F5 | Ownership of partner channel revenue (role-family, `[generic]`) | "running the ISV channel" (your message) | low | [inferred] | discovery | Running a channel is not owning its revenue line. Answer slot: if you set the partner targets or the programme design, say which and how you decided; if not, say so and describe what you ran. |

## Graded deliverable: the POV (first 15 minutes)

Recruiter-declared: a spoken POV, no slides, about where you'd take operator partnerships over 18 months, landing on what it means for operators.

**Facts to build on:** F1 ("took it from 6 partners to 40") and F2 ("so I know the operator world from the other side"). Say these at their own scope.

**Thesis 1 (with concession).** The operator's binding constraint is the timetable-change cycle, not the sale, so partnerships should attach to that cycle. *Concession:* I am working from outside; I don't yet know how operators run their change cycles today.

**Thesis 2 (with concession).** Make operator value measurable in the operator's own performance measures before any price conversation. *Concession:* I don't know which measures they are held to, so this is a hypothesis to test.

**Anti-pick (with concession).** Don't add more resellers to reach every operator; fewer, deeper operator partnerships. *Concession:* fewer partners means fewer routes to market, and I'd need to show that the trade is worth it.

**Differentiation.** The consensus answer is "widen the partner ecosystem and integrate more data sources". Lead with operator-side sequencing instead. The internal market report was not shared with me, so I have not checked this against it; check before the panel that you are not reciting it.

**Close.** Name what the operator gets by month 18, in their terms.

## Persona table

| Persona | Who | Weight | How it shows up | Likelihood, and why | Counter-strategy |
|---|---|---|---|---|---|
| Case/Strategist | Deepa (hiring manager) | Top | POV follow-ups; live operator problems on their roadmap | High: Deepa is buying the 18-month plan and will test it | Clarify the operator's problem first; state the plan in three moves |
| Skeptic | Deepa | Mid | "Why you, with no rail sales and no quota?" | High: the gaps in F3 and F4 are the obvious probes | Hold, then concede, with the quote returned to each time |
| Conversational | Deepa | Low | A casual opener that scores the biography | Medium: common in hiring-manager rounds | A 90-second arc, prepared |
| Pressure | Ross (commercial director) | Top | Interrupts on the numbers; "how much was actually you" | High: the recruiter said Ross will press on commercials | Pause, restate, hold two follow-ups before any concession |
| Case/Strategist | Ross | Mid | Unit economics of one operator deal | High | Structure first: who pays, what it costs, what you don't know yet |

Panel weighting: Deepa and Ross each get their top two. Deepa's Skeptic and Ross's Pressure are the two places the candidate is most exposed.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| "I've sold into rail" | Sourced negative (F4) | "I haven't sold into rail." |
| "I've carried a quota" | Sourced negative (F3) | "I haven't carried a direct quota." |
| "I owned the £4M" | Inflated form of F1's "roughly £4M of influenced revenue" | Quote at its own scope. Limit, as this pack's observation: your material says influenced, not owned |
| "I know how operators buy or fund scheduling" | Inflated form of F2, which is about planning | Quote at planning scope. Procurement is silence, so it is an answer slot, not a claim |

## Question banks

### A. Case/Strategist: Deepa (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you take our operator partnerships over the next 18 months?" | CASE | [grounded] "where you'd take our operator partnerships over the next 18 months" (recruiter email) | This is the POV, asked again as a conversation. Open with the operator's problem, not your channel. Three moves, each with what the operator gets. Close on what you'd stop. Speakable in 90–120 seconds. | The POV's main question; Deepa will test the plan's shape |
| A2 | "What does that actually mean for an operator?" | CASE, VAL | [grounded] "what it means for the operators themselves" (recruiter email) | Name one operator-side outcome you would measure. Say it in the operator's terms. | The recruiter asked for this landing; A1 can miss it |
| A3 | "Which operator would you call first, and what would you ask them?" | CASE | [generic] | Pick one operator type. Ask three questions about their change cycle and who owns the scheduling decision. | A live problem; no claim about your past |
| A4 | "What would you need to learn about rail in your first 90 days?" | JD | [grounded] "Never sold into rail specifically" (your message) | "I haven't sold into rail." Then three people you'd talk to and one thing you'd read. | F4's gap, given the words its source allows |
| A5 | "What would make you change the plan after six months?" | CASE | [generic] | Name one leading indicator and the threshold you'd set in advance. Say if you have no operator data yet. | Tests whether the plan can be wrong |

### B. Skeptic: Deepa (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a direct quota. Why would we trust your revenue plan?" | EXP, JD | [grounded] "never carried a direct quota, only influenced revenue" (your message) | **Highest-ROI prep in this pack.** Hold: "I haven't carried a direct quota. What I've carried is influenced revenue, roughly £4M across the channel." Concede, specifically: "The first months are about learning how operator budgets get approved." Hold through two follow-ups by returning to the quote. Do not name a revenue number you haven't been measured on. | F3 is the likeliest objection and the deepest rehearsal |
| B2 | "Your £4M was influenced, not owned. What part of it was yours?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message); "running the ISV channel" (your message) | Answer slot: if you set the partner targets or programme design, say which and how you decided, in your own words. If not, say so plainly and describe what you ran. | F5 |
| B3 | "You've moved from payments to rail. What transfers?" | EXP | [grounded] "bus and light rail network planning, so I know the operator world from the other side" (your message) | Say what planning work taught you: how services are planned and where timetable change hurts. Stop there. | F2; the quote's scope is planning, not procurement |

### C. Conversational: Deepa (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey." | VAL | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" (your message) | 90 seconds: partnerships, the ISV channel, then the planning years and why now. | Casual openers are scored |
| C2 | "What's different about rail partners from payments partners?" | CASE | [generic] | Name one difference you would check first, and label it as an assumption. | Low weight; a chance to show curiosity |

### D. Pressure: Ross (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should an operator buy through a partner rather than direct?" | CASE, JD | [generic] | One reason, tied to an operator outcome. Hold through two follow-ups. | A pressure opener on the commercial core |
| D2 | "How much of that £4M was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message); "took it from 6 partners to 40" (your message) | Hold: "I took the partner count from six to forty. The revenue was influenced through that channel, not owned by me." Concede: "I don't yet know the attribution model, so I'd ask how it was counted." | Ross's version of B2; the hold must stay at the quotes |
| D3 | "How was the £4M counted?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: if you know how it was counted, say so. If you don't, say you don't know and name what you'd check first. Ends without a question mark. | The defend-the-number slot a figure raises |
| D4 | "Who pays for a scheduling tool at an operator, and who signs?" | CO | [generic] (theme raised by "Ross will push on commercials", recruiter email) | Structure: the economic buyer, the budget line, and what you don't yet know. | Ross will ask about commercials; this is the buyer question |
| D5 | "What discount would you give an operator to win the first contract?" | CO | [generic] | Say what you'd trade and what you would not. A non-negotiable stays one. | Tests whether you hold a commercial line |

### E. Case/Strategist: Ross (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the economics of one operator deal through a partner." | CASE, CO | [generic] | Structure: who pays, partner margin, operator price, cost to win. Name what you don't know. No figures. | Ross scores the structure more than the answer |
| E2 | "What would you watch in the first quarter?" | CASE | [generic] | One operator-side and one revenue-side measure, and which you would trust more. | A measure choice shows judgement |
| E3 | "What would you stop doing in operator partnerships?" | CASE | [generic] | Name one partner motion you'd kill and why. | The anti-pick, in a commercial frame |

**Requirement coverage.** Recruiter-stated: operator strategy over 18 months → A1, E3. Operator outcomes → A2, A3. Commercials → B1, B2, D1, D3, D4, D5, E1. Rail background → A4, B3, C2. Partner-channel scale → C1, D2. No row is uncovered.

## Sources

- Provided: the recruiter's email (quoted in your message); your background message.
- Research tier: **L0**. L1 was attempted: three WebSearch calls were refused by the host (permission not granted), so the company values, the interview process and the strategy are not established.
  - "Kelverton Rail values": refused
  - "Kelverton Rail scheduling software train operating companies": refused
  - "Kelverton Rail interview process partnerships": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | No values round is detected, so no values cheat sheet. Would have named published principles |
| 2. `Kelverton Rail interview process` | unavailable | Loop structure. The recruiter's email describes this round only |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Would have moved the CO questions. The internal market report was not shared with me |
| 4. Deepa / Ross public footprint | unavailable | Would have tuned persona weights and the reverse questions |
| 5. Representative `Senior Partnerships Manager` JD | unavailable | JD not supplied; the fit snapshot's requirements are the recruiter's own words |

## Reverse questions

1. **What does a good operator partnership look like at month 18, and who signs it off?** *Why it lands:* it shows you're planning for the operator's outcome, and it asks Deepa how success is judged.
2. **Which two operators are the test cases this year?** *Why it lands:* a concrete question that a strategist answers well.
3. **How is the partnerships function measured: owned revenue, influenced revenue, or both?** *Why it lands:* it turns the B1 gap into a question about the role's own scorecard.
4. **Where do operator budgets get set, and what's the window to get into them?** *Why it lands:* it is a commercial question Ross will value.
5. **What have operators pushed back on hardest in the last year?** *Why it lands:* it asks for the reality behind the report, not the report.

## Upgrade menu

- **JD text** → turns the recruiter-stated rows into full JD rows and lets the coverage line cover mid-list requirements.
- **Whether the role carries a quota or revenue target** → turns B1 and D3 from holds into firm answers.
- **Deepa's and Ross's public footprint** (talks, posts, career path) → personalised persona weights and a tailored reverse question. Search was refused in this session.
- **Headline claims from the internal market report** (pasted, not the whole document) → lets the POV's differentiation be checked against it.
