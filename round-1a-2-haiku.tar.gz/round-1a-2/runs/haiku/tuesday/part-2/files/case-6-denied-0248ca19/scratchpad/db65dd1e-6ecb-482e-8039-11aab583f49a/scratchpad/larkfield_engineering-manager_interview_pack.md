# Engineering Manager, Larkfield Systems: interview prep (three rounds)

Role: Engineering Manager, Larkfield Systems (industrial IoT, about 600 people). Two squads on device-management services; 11 engineers.
Loop (from your message and the recruiter's phrasing):
- Round 1, Tuesday, 45 min: hiring manager, Director of Engineering (your future boss). Name not given.
- Round 2, Thursday of the following week, 60 min: panel of two staff engineers and a product manager. Names not given.
- Round 3, the Monday after, 30 min: VP Engineering, described by the recruiter as "values and leadership philosophy". Name not given.

Mode: loop. One shared fit snapshot and sources block, then a mini-pack per round, then a shared upgrade menu.

## How to use this pack

- Personas are how a question is asked. Types are what is being scored: VAL (values and leadership), EXP (your past work, attribution), JD (the listed job), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Rehearse the beats in your own words.
- Provenance: [grounded] means traceable to your message or the role text you sent. [inferred] means a derivation from the role. [generic] means a role-family pattern with no entity-specific claim.
- An answer slot is an instruction for the interview. It names the honest branch: say what you did, or say plainly that it was not yours or did not happen.

## Fit snapshot (shared across rounds)

Requirements come from the role text you sent, quoted as written. Evidence is quoted from your message. No CV or full posting was supplied, so every evidence cell rests on your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role text you sent) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six. Say it as the sentence states it: nine years in engineering, three as a team lead of six. Answer slot: if you have led work across two groups at once, say how, in your own words; if you have not, say so plainly and say how you would set up two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role text you sent) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | presentation | The quote reaches delivery under pressure, but in reliability work. Reword only the quote: "I pushed a reliability quarter through against roadmap pressure." Any figure's attribution is handled in the banks as a slot, not here. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role text you sent) | "I run our hiring loop for backend roles" (your message); "about 40 interviews last year" (your message) | medium | [grounded] | transferability | Your material shows a hiring loop for backend roles, run by you, with about 40 interviews last year. Owning hiring for a team of eleven is the step the material does not show. Say what you ran; do not describe a hiring plan you did not own. |
| F4 | "own delivery, hiring and growth for 11 engineers" (role text you sent) | none given | none | [grounded] | discovery | Your material says nothing about growing people. Answer slot: if you have helped someone you led get ready for more, say who and what changed, in your own words; if you have not, say so plainly. |
| F5 | "partner with hardware and product on roadmap" (role text you sent) | "pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Your material shows you pressing a roadmap decision under pressure. It does not show partnering with hardware on a roadmap. Keep the product side at the quote's scope. |
| F6 | "partner with hardware and product on roadmap" (role text you sent) | "never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | Plain acknowledgment, from your own words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F7 | Gap you named: managing managers (your message; your own note, not a posted requirement) | "I've never managed managers" (your message) | none | [grounded] | capability | Plain acknowledgment: "I've never managed managers." Then the plan for learning it, said as a plan. No interviewer's words raise it yet, so it lives in round 3 as the plain line, not as a claim. |

Reading of the table: your strongest material is the team of six, the reliability quarter, and the backend hiring loop. The two capability rows are the gaps you stated yourself. Nothing in the material shows growth work (F4).

## Prohibited claims (built locally from the fit snapshot)

Each entry names its basis and its honest form. No answer, hold, bridge or question in this pack asserts any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've led two squads" | Inflated form of F1 | F1's quote at its own scope: "9 years engineering, 3 as a team lead of 6". The limit is the pack's observation, not words for you: your material shows one team of six. |
| "I've owned a hardware roadmap" | Negative you stated, F6 | "I've never owned a hardware-adjacent roadmap." |
| "I've managed managers" | Negative you stated, F7 | "I've never managed managers." |
| "I set the hiring plan for the org" | Inflated form of F3 | "I run our hiring loop for backend roles", at its scope. |
| "The reliability quarter caused the 60% drop" | Inflated form of F2 | "My team's on-call burden dropped 60% after I pushed a reliability quarter through", keeping "after". |

F4 (growth) has no quote, so it is an answer slot, not a listed claim. Do not describe growth work you have not told us about.

## Sources

Provided documents: your message (the role text, your background, and the recruiter's phrase "values and leadership philosophy"). No CV, no full posting, no interviewer names, no company pages.

Research tier: L1, searches 2 of 6, fetches 0 of 2. Both calls were refused because search permission was not granted in this session. I did not retry them.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet (section 10), which is omitted because no published values are in hand. Round 3's VAL questions use the recruiter's words as their raising source instead. |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Loop structure. Your message and the recruiter's phrasing establish the three rounds, so no archetype fallback is needed; the search would have confirmed the round formats. |
| 3. Larkfield Systems strategy and recent news | unavailable | Company-strategy questions. B6 and C7 are therefore labeled [generic]. |
| 4. Interviewer name with company | n/a | No names were given for the Director, the staff engineers, the product manager or the VP. |
| 5. Representative engineering manager JD | skipped | Your role text fixes the requirement list, so no representative posting was needed. |

Refused calls, listed:
- "Larkfield Systems values industrial IoT": refused (target 1)
- "Larkfield Systems engineering manager interview process": refused (target 2)

## Round 1: Hiring manager, Director of Engineering (45 min)

Persona table, with reasoning. Relationship prior for a hiring manager: Skeptic and Case/Strategist. They are buying capability and derisking gaps, and expect live problems on the roadmap.

| Persona | How it shows up | Likelihood | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic (weight 5) | Probes the scope step and the hardware gap; "why this, why now" | High: your two capability gaps are exactly what a hiring manager derisks | Rehearse the scope objection until it is plain; say the gap once, then the plan | A2, A3, A4, A9 |
| Case/Strategist (weight 4) | Live problems on the hardware and product seam | High: the role is partnership on the roadmap | Clarify, name the decision owner, state one trade | A6, A7 |
| Pressure (weight 3) | Challenges the on-call figure and your motivation | Medium: a director tests composure on a headline number | Hold the quote, concede uncertainty without folding | A5, A8 |
| Conversational (weight 2) | Opens with the biography | Low to medium: a warm-up, still scored | Ninety-second arc from your own sentences | A1 |

Question banks:

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your last nine years, briefly." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | Ninety-second arc in your own words: the nine years, three as a team lead, a team of six, and where you are now. Say the numbers as they stand, and add nothing. | Opener in a rapport register, still scored. F1 is the row it draws on. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | Hold the gap in one line: "I've never owned a hardware-adjacent roadmap." Then the first month, as a plan: who you would talk to, and what you would ask. Do not offer an adjacent example you have not given us. | F6 is the stated gap. A plain acknowledgment with a plan is the honest answer. |
| A3 | "I don't see hardware in your background. How would you handle that part of the role?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | Acknowledge it first, in those words. Then describe the plan: the hardware leads you would meet first, and the constraints you would ask about. This is a plan, not a past claim. | Same gap as F6, asked as a probe. Keeps the plan separate from any history. |
| A4 | "Two squads and eleven engineers. Have you led more than one team at once?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | Hold the quote: one team of six. Answer slot: if you have led work across two groups at once, say how, in your own words; if you have not, say so plainly and say how you would set up two squads. Hold through two follow-ups by returning to the team of six, never by adding to it. | F1 is transferability, and this is the most predictable objection in the loop. Highest-ROI prep in this pack: deepest rehearsal, most follow-up levels. |
| A5 | "That on-call figure. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Hold: "I pushed the quarter through." Keep the figure's order: the burden dropped after the quarter. Answer slot: if you know how the 60% was counted, say how; if you do not, say so, and say which part of the drop you would defend. Concede the uncertainty explicitly; do not fold on the quarter itself. | Headline number, so it is a defend-the-number question. The attribution test a pressure interviewer uses. |
| A6 | "Two squads, and the hardware team's firmware release slips a month. Product wants the feature anyway. What do you do in the first two weeks?" | CASE | [generic] | Clarify who decides and what the slip costs. Name the options and who you would talk to. Say one trade you would make and why. Make no claim about past work. | A live problem from the partnership line of the role. No research, so generic. |
| A7 | "How would you decide what goes on the device-management roadmap when hardware and product disagree?" | CASE | [generic] | Separate the decision owner, the evidence, and the cost of reversing. Name the premise you would challenge first. | F5 is the roadmap seam. Structure over answer. |
| A8 | "Why leave a payments company for industrial hardware?" | EXP | [grounded] "currently at a payments company" (your message) | Say what draws you, in words you would repeat under a second question. Do not claim hardware exposure you do not have. | Motivation probe. The pull has to be specific and yours. |
| A9 | "You run a hiring loop for backend roles. What changes when you're hiring for a team of eleven?" | JD | [grounded] "I run our hiring loop for backend roles" and "about 40 interviews last year" (your message) | Say what you ran: the loop, about 40 interviews last year. Answer slot: if you have owned a hiring plan or target for a team, say so; if you have not, say which part of hiring you have run and what you would bring to the plan. | F3. The question's premise matches the quote. |

Reverse questions (at least five; no interviewer profile, so none are tied to a career path):

1. "What would the first ninety days need to deliver for the two squads?" Why it lands: it turns the scope risk into a shared plan.
2. "When hardware and product disagree on the roadmap, how does it get settled?" Why it lands: it tests the partnership under your stated gap.
3. "Where does delivery slip most often on these two squads today?" Why it lands: it shows you think of delivery as the job.
4. "How is the hiring loop for this role different from the backend one?" Why it lands: it ties to your own loop and shows homework on the role.
5. "What has to be true six months in for you to call this hire a success?" Why it lands: it anchors the director's expectations.

## Round 2: Panel, two staff engineers and a product manager (60 min)

Persona table, with reasoning. Each member's relationship sets the top two personas, and the panel blends them. Staff engineers are peers who read the work closely and price the hire's cost to their own work. The product manager owns the roadmap conversation.

| Persona | How it shows up | Likelihood | Counter-strategy | Questions |
|---|---|---|---|---|
| Data-Driven Prober (weight 4) | Staff engineers probe the on-call figure and the claims about what you touched | High: a staff engineer reads the CV line by line | Name the weakest assumption before they do; say where your work ended | B2, B3, B7, B9 |
| Peer Evaluator (weight 4) | Seam probes between squads and platform; "what would you need from me" | High: they are pricing what the hire costs their work | Propose seam principles rather than pretending to know the seam | B1, B4, B8 |
| Case/Strategist (weight 3) | Product manager's roadmap trade-off | Medium: a product manager tests roadmap judgment | Clarify, option, trade | B5, B6 |

Question banks:

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between yours and ours, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a known seam. Say how you would settle a disagreement with equals. | Peer Evaluator stem. The guidance makes no claim about your past. |
| B2 | "Walk me through how the 60% on-call drop was counted." | EXP | [grounded] "My team's on-call burden dropped 60%" (your message) | Say what you know of the count, and name the weakest assumption behind it before they do. If you do not know how it was counted, say so. Answer slot: if a count was yours to set, say which, and how you decided. | Defend-the-number. Same attribution test as A5, from a prober's side. |
| B3 | "Which of those reliability changes did you make yourself?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Hold to the sentence: you pushed the quarter through, against roadmap pressure. Answer slot: if you wrote or changed specific work, name it and how you decided; if the work was your team's and you pushed the plan through, say so plainly. | Probers test whether the claim is theirs. The honest answer is the one that matches the sentence. |
| B4 | "Who on the hardware side would you go to first, and what would you need from them?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | Name the first hardware lead you would meet and the two things you would ask. This is a plan. If they ask about past hardware work, give the plain acknowledgment. | F5 and F6 in a peer register. |
| B5 | "Product wants a feature that adds a quarter to the reliability backlog. How do you respond?" | CASE | [generic] | Clarify the feature's deadline and the reliability risk. Give two options and the trade between them. Make no past claim. | Product manager's roadmap question. Generic. |
| B6 | "If you were our PM's partner for the next two quarters, what would you push back on in the roadmap?" | CO | [generic] | Name one push-back, the reason for it, and what you would need to know first. No company facts from memory: we have no research, so this is generic. | Company knowledge, but generic because no strategy source was run. |
| B7 | "For a team of eleven, which delivery numbers would you look at first, and which would you distrust?" | JD | [generic] | Name two measures and the assumption behind each that you would distrust. Keep it to the role's delivery, not numbers from your past. | Mirrors the role's "own delivery" line. Generic because it asks about a practice, not your history. |
| B8 | "Tell me about a time you helped someone on your team get ready for more." | JD | [grounded] role text: "own delivery, hiring and growth for 11 engineers" | Open prompt. If you have a case, tell its beats in your own words: the person, what you did, what changed. Answer slot: if none comes to mind, say so plainly, then say how you would start with a team of eleven. | F4 has no quote, so this is an answer slot, not a story. |
| B9 | "What did you learn from the roughly 40 interviews last year?" | EXP | [grounded] "about 40 interviews last year" (your message) | Say what you changed in the loop, if anything; if nothing changed, say so. | F3. Premise matches the quote. |

Reverse questions (at least five; one reciprocity question for a peer panel):

1. "What could a new engineering manager do in the first month that would genuinely help your team?" Why it lands: reciprocity, in a peer register.
2. "Where do the two staff engineers spend most of their week now: review, on-call, design?" Why it lands: it maps the load you would be joining.
3. "How much of the on-call load sits with the two staff engineers today?" Why it lands: it ties to the 60% figure without repeating it.
4. "When hardware and product disagree, which side usually gives way?" Why it lands: it reveals the seam.
5. "What would make you say a new manager is doing the job well at month three?" Why it lands: it sets the expectations the panel holds.

## Round 3: VP Engineering, values and leadership philosophy (30 min)

Values-style round: detected from the recruiter's words, a loop source that names a values round. No published values are in hand, so section 10 is omitted and the VAL questions use the recruiter's phrase as their raising source.

Persona table, with reasoning. A skip-level VP prior is Case/Strategist plus Pressure, and a dedicated values round prior is Values/Behavioral. The recruiter's words weight the round toward values.

| Persona | How it shows up | Likelihood | Counter-strategy | Questions |
|---|---|---|---|---|
| Values/Behavioral (weight 5) | Scenario questions on principles and past decisions | High: the recruiter named the round | Stories with a decision in them; say what was yours | C1, C2, C3, C6 |
| Pressure (weight 3) | Altitude and composure; time-boxed answers | Medium: VP round, thirty minutes | Hold the position; concede uncertainty without folding | C4, C5 |
| Company knowledge (generic) | One question on what the company gets right | Low: no research run | Generic, labeled as yours | C7 |

Question banks:

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What's your leadership philosophy, in two minutes?" | VAL | [grounded] "I run our hiring loop for backend roles" and "pushed a reliability quarter through against roadmap pressure" (your message) | Two or three principles, in your own words. Attach each to one of the quoted sentences. A principle with no decision behind it is said as a principle, not told as a story. Answer slot: if a principle has no decision behind it yet, say so. | The recruiter's "leadership philosophy" is the raising source. Coverage of the stated theme. |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Story-mapped on the quote, in beats it states: the roadmap pressure, the quarter, the on-call outcome. Answer slot: how leadership reacted. If you do not know, say so; do not supply an ending. | Values round, persona stem. The quote carries the story's first two beats. |
| C3 | "When did you put reliability ahead of a roadmap commitment?" | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Say what was deferred and who pushed back, in the quote's words. Hold through one follow-up. Answer slot: if the decision was not yours, say whose it was. | Premised question. The premise matches the quote exactly. |
| C4 | "You've led a team of six. What would you need to see before you led managers?" | JD | [grounded] "I've never managed managers" (your message) | Plain acknowledgment: "I've never managed managers." Then your plan for learning it, as a plan. Ask what they would look for. | F7. Stated negative, so it needs no slot. |
| C5 | "Why should we trust a payments-company team lead with hardware roadmaps?" | JD | [grounded] "currently at a payments company" and "never owned a hardware-adjacent roadmap" (your message) | Hold on what you do own, at its scope. Give the plain acknowledgment for hardware. Do not claim hardware experience. | Pressure probe on the scope and seam gap. |
| C6 | "How do you handle a team member whose growth has stalled?" | VAL | [grounded] role text: "growth for 11 engineers" | Open prompt. If you have an example, give its beats in your own words. Answer slot: if none comes to mind, say so plainly, then say how you would start. | F4 has no quote. The theme comes from the role text. |
| C7 | "What do you think Larkfield gets right about its own engineering?" | CO | [generic] | One observation, labeled as yours, with the reason. No company facts from memory. | Company knowledge without research. Generic by design. |

Reverse questions (at least five):

1. "What does a good leadership decision look like here, in the last quarter?" Why it lands: it asks for the values in practice.
2. "How do you want a new manager to handle a hard call between product and hardware?" Why it lands: it tests your partnership plan at altitude.
3. "What would make you say I made the wrong hire at six months?" Why it lands: it sets the expectations for the first two quarters.
4. "Which principle does the leadership team argue about most?" Why it lands: it invites candor and shows judgment.
5. "What should I read on the operating principles before the next round?" Why it lands: it uses the values loop, and the recruiter can answer it in one email.

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| Lead two squads building device-management services | A4, A6, A7, B5 |
| Own delivery | A5, B2, B3, B7 |
| Hiring for 11 engineers | A9, B9 |
| Growth for 11 engineers | B8, C6 |
| Partner with hardware on roadmap | A2, A3, A7, B4, C5 |
| Partner with product on roadmap | A7, B1, B5 |
| Managing managers (your gap) | A2, C4 |

## Upgrade menu

- Full posting text → F1 to F5 move from "your message" and the role text to quoted lines of the posting, and the JD questions can use its exact wording.
- Your CV → F1, F3 and F5 can be checked against a document, which can raise the medium rows.
- The source of the 60% figure (a dashboard or ticket count) → A5 and B2 can name the count instead of "I don't know how it was counted".
- The Director's, the two staff engineers', the product manager's and the VP's names → a per-member persona weight and a tailored reverse question for each.
- The recruiter's note on round 3's content → C1 to C3 can name the values set they test.
- The company's values page, pasted → section 10 (values cheat sheet), and round 3's VAL questions can map a story to each value.
- Search permission in a later session → targets 1 to 3 (values, loop, strategy) can run, which would make B6 and C7 company-specific.
- Deep research, offered once: up to 6 more searches and 2 more fetches, several more minutes. Say if you want it.
