# Ashgrove Credit Union: Member Experience Lead interview pack

**Changelog:** first build, no regeneration.

**Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)

**Interviews, 28 November 2026:**
- Round 1, recruiter, 30 minutes.
- Round 2, Head of Member Services (your future manager), 45 minutes, mostly behavioural.
- Round 3, panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case. The panel scores you against the four values. Panel members are not yet named.

## How to use this pack

Personas are how a question is asked. Types are what it scores.

- **VAL**: behavioural and values alignment, against the company's published values.
- **EXP**: your own experience, checked for what you actually did.
- **JD**: the job's stated requirements.
- **CO**: company and strategy knowledge.
- **CASE**: a live problem, reasoned aloud.

Guidance is scaffolding, not a script. Text in quotation marks in the guidance is your own sentence from your material, or the company's own words. Everything else is structure.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | The years and the supervisor role are already in your material; the gap is in the wording. Say it as written: six years in retail banking, the last three as a branch supervisor. The material does not show whether that work matched the JD's customer operations. If you can say how it did, say so in your own words. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The quote is adjacent work: formal complaints handled at branch level. It does not show regulated handling. Answer slot: say which rules, if any, the formal complaints followed and what you did to meet them. If none applied, say so and describe how the log was kept. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The quote covers one branch's log. It does not show the whole process, or work across branches. Say it at that scope. Answer slot: if you held any part of the process beyond the log, say which part and what was yours. If you held only the log, say so plainly. |
| F4 | "across branches and the contact centre" (JD, contact centre part) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A stated absence. Words you can say: "I haven't worked in a contact centre." Then how you would learn the contact centre, said as a plan and never as a past. No claim to contact-centre work, and nothing added to make the gap feel smaller. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | discovery | The spreadsheet may hold the JD's two measures, but your material does not say. Answer slot: say which of volumes and resolution times the spreadsheet recorded. If it recorded neither, say so and say what you would need to see first. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Say what you trained: new tellers, on the escalation script. The material does not show coaching a supervisor. Answer slot: if you coached a branch supervisor on an escalation, say what you did. If not, say so and say how you would start. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | The material is silent on digital work, so the requirement is shown neither way. Answer slot: if you have worked with a team on a customer-facing digital or self-service change, say what it was and your part. If not, say so and describe how you would find out what the digital team is building. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A stated absence. Words you can say: "I haven't presented to anyone above regional level." Then how you would learn it, said as a plan. No claim to senior presentation, and no added detail. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The quote is a spreadsheet, and the JD names Excel. Say it as written. Answer slot: name the tool you used and what you did in it, in your own words. |

**Gates:** none in this JD. "4+ years" is a length-of-experience requirement, and "experience handling regulated complaints" is experience, not a term you meet or do not. Both are graded on fit like every other row.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3 | The quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's analysis: the material shows one branch's log, not the whole process. |
| Has worked in a contact centre | Negative you stated (F4) | "I haven't worked in a contact centre." |
| Ran a regulated complaints process | Inflated form of F2 | "I handled the branch's formal complaints log." The pack's analysis: the material does not show the log was regulated. |
| Built a regional complaints dashboard | Inflated form of F5 and F9 | "I built the monthly complaints spreadsheet our regional manager uses." A spreadsheet, used by your regional manager. |
| Coached branch supervisors on escalations | Inflated form of F6 | "trained new tellers on our escalation script" |
| Has presented to senior leaders | Negative you stated (F8) | "I haven't presented to anyone above regional level." |

Digital work is not listed. No sentence of yours speaks to it, so it is an answer slot (F7), not a prohibition.

## Grounding brief

From your summary of Ashgrove's July 2026 strategy brief. I have not read the full document, so check wording against it before you quote it at the panel.

- **Digital:** move 40% of member service to digital channels by 2028.
- **Network:** consolidate eight branches into five hubs over 2027.
- **Lending:** launch a small-business lending product in Q1 2027.
- **Competition:** the main competitive pressure is app-only banks.

Use the company's own terms: "member service", "digital channels", "hubs".

## Values cheat sheet

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No sentence of yours carries a member decision. Selection scaffold: pick a time a branch rule and a member's need pointed different ways, what you decided, and what happened to the member. If none comes to mind, say so plainly, then say how you would handle one. (B7, C4) |
| Plain Words | If a member needs it explained twice, the wording is the fault. | F6 carries the teaching: "trained new tellers on our escalation script." The beats are the script, the tellers and your training. Whether the script was plain is not in the material. If you changed how it was explained, say what and why. If not, say how you would test it. (C1) |
| Neighbours, Not Numbers | Every branch is part of its town. | F9 is the number-side line, and no sentence carries a branch-as-town story. Selection scaffold: pick a time you put local context ahead of a figure. If none comes to mind, say so, then say how a town's view would change how you read a figure. (C3, C6) |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F3 carries holding the log, "I handled the branch's formal complaints log," but not an ending. The beats stop at holding it. Say how a complaint you held ended, in your own words. If you did not follow one to the end, say so. (C2, C7) |

**The tension to rehearse:** "Neighbours, Not Numbers" pulls against your spreadsheet line, and the hub plan tests the same value. Rehearse C3 and C6 together.

## Persona table

Round 2 is mostly behavioural, so the Skeptic leads it because the JD's gaps are the hardest to cover. The panel scores values, so Values/Behavioral leads round 3, with a Case block for the 20-minute escalation.

| Persona | Round and weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Conversational / Rapport Builder | Round 1, weight 4 | Biography and logistics in a friendly register | High. A recruiter screen's usual mix, and the logistics checks are scored | A pre-scripted 90-second arc (A1). Give logistics in your own words. |
| Skeptic | Round 2, weight 5 | Probes the JD against your gaps | High. Hiring-manager prior, and the fit snapshot's biggest gaps are the contact centre, presenting above regional level, and end-to-end scope | Rehearse B1 until it is boring. Hold, then concede. |
| Values / Behavioral | Round 2, weight 3; round 3, weight 4 | Scenario probes against the four values | High. The recruiter calls round 2 mostly behavioural and says round 3 scores the values | Selection scaffolds where no story exists, and say so plainly. |
| Case / Strategist | Round 3, weight 3 | The 20-minute escalation case, the hub question, the volume-doubling problem | High for the case, which the recruiter stated | Clarify, objective, approach, measures, risks. Challenge one premise. |
| Peer Evaluator | Round 3, weight 2 | Where the seam sits between branches and the contact centre, and the digital work | Medium to high. Branch managers are the colleagues you would work beside | Propose seam principles, not seams you have not seen. |
| Data-Driven Prober | Round 3, weight 2 | Counting in the monthly spreadsheet | Medium. The spreadsheet line is your one number-type claim, and the JD asks for monthly reporting | Say what it counted. Say plainly when you do not know. |

## Question banks

### A. Round 1: recruiter (Conversational, with logistics checks)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | The 90-second arc: six years in retail banking, the last three as a branch supervisor, then the complaints log and the tellers you trained. Stop at the present. Leave out the reason for leaving, which is A6. Say each part in your own words, and use only the facts in those quotes. | Opening biography on a conversational screen. Scored anyway: F1 and F2 are what this round checks first. |
| A2 | "What are you using day to day for complaint reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Name the spreadsheet as it is: what it covers, who reads it, how often it goes out. Answer slot: name the tool you used and what you did in it, in your own words. | A casual question, but the JD asks for "comfortable with Excel reporting," and F9 is the stated answer. Scored. |
| A3 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot: give your own figure or expectation in your own words, or ask for the band first. Do not give a figure you have not decided. | Pay is a recruiter-screen knockout check. The answer is yours, and the material holds none. |
| A4 | "How much notice do you need to give your current employer?" | JD | [generic] | Logistics slot: give the notice you actually owe, without rounding it. | Notice is a recruiter-screen logistics check. The only safe answer is your own. |
| A5 | "Where are you based, and what travel would the role need?" | JD | [generic] | Logistics slot: say where you are based and what travel you can do, in your own words. The JD names no travel. | Location is a knockout check. The answer is yours. |
| A6 | "Why are you leaving your current role?" | EXP | [generic] | Logistics slot: give the reason in your own words. The material gives none, so do not supply one. | Reason for leaving is a recruiter-screen logistics check, and the material holds no answer for it. |

### B. Round 2: Head of Member Services (Skeptic, then Values/Behavioral)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked in a contact centre. What would you bring to complaints across one?" | JD | [grounded] "Never worked in a contact centre" (your message); [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD); [grounded] "I handled the branch's formal complaints log" (your message); [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | **The highest-ROI prep in this pack.** Hold: the log and the spreadsheet, quoted above. Hold through two follow-ups by returning to those sentences. Concede plainly: "I haven't worked in a contact centre." Then the plan, said as a plan: what you would learn first, and from whom. The third follow-up is where it breaks. Concede there. Never claim contact-centre work to close the gap. | The JD puts the contact centre in scope, and F4 is the stated absence a skeptic will test first. This gets the deepest rehearsal. |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "confident presenting to senior leaders" (JD); [grounded] "I've never presented to anyone above regional level" (your message) | Name presenting to senior leaders as the weakest part, in your words: "I haven't presented to anyone above regional level." Then how you would learn it, said as a plan. Describe no past presentation above regional level. | The skeptic's stock question. Your negative is stated, so say it plainly. The plan carries the rest (F8). |
| B3 | "Your complaints work is one branch's log. What changes when the process runs across several branches?" | JD | [grounded] "I handled the branch's formal complaints log" (your message); [grounded] "Own the member complaints process end to end across branches" (JD) | Say what the log covered, at its own scope: one branch. Answer slot: if you held any part of the process beyond that log, say which part and what was yours. If you held only the log, say so plainly, and say what you would need to learn about how branches differ in complaints. | The JD asks for end to end across branches. F3 is the transferability gap, and this question tests its scope. |
| B4 | "Does your spreadsheet give you volumes, resolution times, both, or neither?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message); [grounded] "report monthly on complaint volumes and resolution times" (JD) | Answer slot: say which of the two the spreadsheet recorded, in your own words. If it recorded neither, say so, and say what you would need to see first. Name no figure you cannot give. | F5 is a discovery gap. The question tests whether your material reaches the JD's two measures. No figure is given, so no defend-the-number slot applies. |
| B5 | "Which rules, if any, did the complaints in your formal log have to follow?" | JD | [grounded] "I handled the branch's formal complaints log" (your message); [grounded] "experience handling regulated complaints" (JD) | Answer slot, both branches: if the complaints followed rules set outside the branch, or by the bank's own policy, say which and what you did to meet them. If none applied, say so plainly and describe how the log was kept. | F2 is the transferability gap on regulated complaints. "If any" leaves room for the honest second branch. |
| B6 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [generic] | Selection scaffold: pick a time you told someone above you something they did not want to hear. It needs a named stake, a moment you did not fold, and a working relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries, which is the escalation training in B8, or how you would handle it. | A persona stem. No sentence of yours carries a senior conversation, so the guidance selects rather than maps. |
| B7 | "When did you put a member ahead of a figure?" | VAL | [grounded] "we decide from the member's side of the counter" (company values) | Selection scaffold: pick a time a member's need went against a target, a report or a rule. If none comes to mind, say so plainly. Do not stretch the spreadsheet line (F9) into a member story: it is about reporting. Say how you would handle one instead. | Members First, Always. The only figure in your material is about reporting, so the honest answer is a real time or a plain "not one I can give." |
| B8 | "Tell me about a time you coached someone through an escalation." | VAL | [grounded] "coach branch supervisors on escalations" (JD); [grounded] "trained new tellers on our escalation script" (your message) | Story map from the quote: you trained new tellers on the escalation script. Those are the beats. Do not add how it landed. Answer slot: if you coached a branch supervisor through an escalation, say what you did and what you said. If you did not, say so and describe how you would start with a supervisor's escalation. | The JD's coaching line is the raising source. The tellers sentence is the nearest real story. Coaching supervisors is not in your material, so the slot carries it. |

### C. Round 3: panel of two branch managers (Values/Behavioral, Case, Peer, Prober)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about something you explained to someone who needed it twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" (your message); [grounded] "if a member needs it explained twice, we wrote it wrong" (company values) | Story map: you trained new tellers on the escalation script. Name the script and the tellers. Answer slot: if you changed how the script was explained after someone needed it twice, say what you changed and why. If not, say so and say how you would test whether it was plain. | Plain Words. The sentence carries the teaching, not the outcome, so the outcome stays a slot. |
| C2 | "Tell me about a complaint you kept hold of until it was solved. How did it end?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message); [grounded] "whoever finds the problem keeps hold of it until it is solved" (company values) | If the log is the nearest thing, say what you handled in it and how a complaint ended, in your own words. If you did not follow any complaint to its end, say so and say how you would keep hold of one. | Own the Fix. The sentence carries the log, not an ending, so an ending is a slot. |
| C3 | "Neighbours, Not Numbers. Your CV line is a monthly spreadsheet. How do you square the two?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message); [grounded] "every branch is part of its town" (company values) | Do not defend the spreadsheet as the answer. Say what it is for, in your words. Then a time you put a branch's local context ahead of a figure. If none, say so, and say how a town's view of a branch would change how you read the monthly figures. | The spreadsheet line and this value pull against each other, and the panel may probe it. Rehearse with C6. |
| C4 | "When did you put the member's side of the counter ahead of a branch rule?" | VAL | [grounded] "we decide from the member's side of the counter" (company values) | Selection scaffold: pick a time a branch rule and a member's need pointed different ways, what you decided, and what happened to the member. If none comes to mind, say so plainly, then say how you would handle one. | Members First, Always. No sentence of yours carries a member decision, so the guidance selects rather than maps. |
| C5 | "A member's fee complaint has sat in a branch for weeks. The branch manager escalates it to you this morning, and the member says they were told it would be sorted. Walk us through the next twenty minutes." | CASE | [generic] | Structure aloud, in this order. Clarify what was promised, by whom, and what is on the file. State the objective: the complaint resolved, and the branch learns why it stalled. Then the approach: who owns it now, what the member hears from you, and by when. Name the measures: how long it has been open, and what the member has been told. Name one risk: the member's trust in the branch. Challenge one premise respectfully. Speakable in 90 to 120 seconds. Follow-up, if the member says they would rather talk to the contact centre: say what you do with that request. | Case/Strategist. A rehearsal scenario, not the real case, which the recruiter has not described. Use the 20 minutes to show structure and ownership, not to recite policy you have not seen. |
| C6 | "Branches are moving from eight into five hubs over 2027. How do you keep a complaint close to its town when the branch that took it is gone?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the July 2026 brief); [grounded] "every branch is part of its town" (company values) | Build from the two sources, not from other banks. Say what you would keep local: the member's named contact, the record, the branch they know. Name one thing you would not assume about the hubs yet, and say what you would ask for first. | The CO question grounded in the strategy brief. It separates a considered answer from "digital is good." Pair with C3. |
| C7 | "Our branches sit beside the contact centre. Where is the seam, and what happens when we disagree about who owns a complaint?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD) | Say you do not yet know the seam, then propose a principle rather than a map: one owner per complaint until it is solved. Then how you would settle a disagreement: put the facts on the file, and decide who holds it. Describe no past disagreement you did not have. | Peer Evaluator. Seam principles, not invented seams. |
| C8 | "Tell us what your monthly complaints report counted, and how you would check it." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Answer slot: say what the report counted, in your words. If it counted nothing you can name, say so and say what you would check first. Give no figure you cannot defend. | Data-Driven Prober. The counting question the spreadsheet line invites. F5 applies. |
| C9 | "A branch's complaint volume doubled in one month. What would you check before you reported it?" | CASE | [generic] | Structure: first whether the count changed or the complaints did; then whether one branch's log, or a new channel, explains it; then what the member-facing record shows. Name the assumption you would test first, and say what you would report before you know. | Case/Strategist, with a Prober check on the monthly reporting the JD asks for. A live problem. It asks about no past of yours. |
| C10 | "The JD asks you to work with digital teams on self-service journeys. Suppose they want to move a complaint step into the app. What would you need to see before you agreed?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Say what you would need to see: what the member does today at that step, where complaints come back from, and what the digital team measures. If you have worked with a digital team on a customer-facing change, say which and your part. If not, say so and describe how you would find out what they are building. | Peer Evaluator, and the digital shift in the brief. F7 is silent, so the slot carries it. |

## Requirement coverage

| Requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B5 |
| Own the member complaints process end to end across branches and the contact centre | B1, B3, C7 |
| Report monthly on complaint volumes and resolution times | A2, B4, C8 |
| Coach branch supervisors on escalations | B8 |
| Work with digital teams on self-service journeys | C10 |
| Confident presenting to senior leaders | B2 |
| Comfortable with Excel reporting | A2, C8 |
| Company value: Members First, Always | B7, C4 |
| Company value: Plain Words | C1 |
| Company value: Neighbours, Not Numbers | C3, C6 |
| Company value: Own the Fix | C2, C7 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What would make the first 90 days a clear success for the person in this role?" | Puts you in ownership terms before any decision. The answer shows what the Head of Member Services will judge you on. |
| "When the eight branches become five hubs, how will complaints from the branches that close be handled?" | Shows you read the strategy summary, and sets up C6 from their side. |
| "Who will own complaints from the small-business lending product, and how will they be handled in the first months?" | The launch is in Q1 2027. The question is about the next year's problem, which signals you are thinking ahead. |
| "Which of the four values do complaints teams here find hardest to hold, and where does that show up?" | Ties the values to real work. It invites the Head of Member Services to say where the gaps are. |
| "What would a new person in your branches need from the complaints function in their first month?" | Peer reciprocity for the branch managers. It moves the panel from scoring you to working with you. |
| "How will the case and the values be scored, and by whom?" | Asks for the weighting you are currently guessing at. Use it at the recruiter stage. |

There is no interviewer profile, so no reverse question is tied to an interviewer's own career path yet (see the upgrade menu).

## Sources

Provided documents, all as pasted or relayed in this conversation:
- The job description, as pasted.
- The recruiter's email, on the three rounds and the panel's values scoring.
- Ashgrove's four values, copied from its values page on 19 November 2026.
- Your summary of the July 2026 strategy brief, as relayed. I have not read the full brief.
- Your background, from your message.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values cheat sheet. The pasted values text is in hand, copied this morning. |
| 2. Interview process | skipped | Loop structure. The recruiter's email names the three rounds and says the panel also scores values. |
| 3. Strategy / recent news | skipped | The grounding brief and C6. Your summary of the July 2026 brief is in hand, and it is under six months old. |
| 4. Interviewer name | n/a | No interviewer is named, and the panel is not yet assigned. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Not built, because the inputs do not support them: the prep triage (no prep time given), the interviewer read (no interviewer named), graded deliverables (none declared), and delivery coaching (no assessment offered).

## Upgrade menu

- Panel members' names and roles → persona weights for each panel member, and a reverse question tied to their career path
- The full July 2026 strategy brief → the grounding brief quotes its own figures, and C6 and the reverse questions use its exact terms
- The recruiter's words on the 20-minute case → C5 and C9 move from scenarios to the case as it will be set
- Your prep time before 28 November → a prioritised schedule, so you know what to rehearse first
- Your pay expectation, notice owed, and where you are based, in your own words → A3 to A5 become your answers, in your words
- What your monthly spreadsheet counted (volumes, resolution times, or neither) → F5, B4 and C8 are grounded in your words, and the defend-the-number slots open if you can state a figure
- The rules, if any, your formal log followed → F2 and B5 get their answer
- The tool and what you did in the spreadsheet → F9 and A2 get exact wording for "Excel reporting"
- Any working-style assessment, if the panel offers one → a delivery-coaching section
