# Ashgrove Credit Union: Member Experience Lead, interview prep pack (loop mode, three rounds on 28 November 2026)

Role: Member Experience Lead. Company: Ashgrove Credit Union. Rounds: recruiter screen (30 min), Head of Member Services (45 min, your future manager), panel of two branch managers (60 min, including a 20-minute complaint-escalation case, scored on the four values).

## How to use this pack

- **Personas** = how a question arrives (tone, pressure, register). **Types** = what is being scored.
- Type key: **VAL** behavioural and values alignment; **EXP** your own experience, tested for attribution; **JD** the listed job, gaps included; **CO** company and strategy knowledge; **CASE** a live problem from the role.
- Guidance is scaffolding, not a script. Say only what you actually did, in your own words.
- Labels: **[grounded]** traces to your message, the JD, the recruiter's email, the values page or the strategy brief. **[generic]** is a pattern, not a claim about you or Ashgrove.

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own complaints end to end across branches and the contact centre | F2, F3; R-B1, R-B3, R-S1, R-P-CASE |
| Report monthly on complaint volumes and resolution times | F5; R-B2, R-P-PROBE |
| Coach branch supervisors on escalations | F8; R-B1, R-B2, R-P-CASE |
| Work with digital teams on self-service journeys | F9; R-B4, R-C1 |
| 4+ years in financial-services customer operations | F1; R1-C1 |
| Experience handling regulated complaints | F4; R-B3, R-P-CASE |
| Confident presenting to senior leaders | F7; R-S2 |
| Comfortable with Excel reporting | F6; R-S3, R-P-PROBE |

## Fit snapshot

Shared across all three rounds. The only candidate material is your message; there is no CV text.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | No gap. Say the years and the setting as you stated them. Limit: the material shows retail banking, not a contact centre. |
| F2 | "own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The quote is one branch's log. Say it at that scope. Answer slot: the JD asks about end to end, across the contact centre too. If you took a complaint from first contact to close, say which steps were yours; if not, say so and describe where your handling started and stopped. |
| F3 | "the contact centre" (JD, same line as F2) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't worked in a contact centre." Then a plan, never a past: how you would learn how the contact centre takes and routes a complaint. |
| F4 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says formal, not regulated. Keep the quote as it is. Answer slot: the JD's regulated line makes a probe on external timeframes likely. If the log was held to any outside deadline or rule, say which and how you kept to it; if none applied, say so and describe how the log was kept. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | The material shows a monthly spreadsheet, not that it carried resolution times, so do not say it did. Answer slot: if resolution times were in it, say which measure and how it was counted, in your words; if not, say so and say what you would add first. |
| F6 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | transferability | Adjacent work: a spreadsheet, not named as Excel. Answer slot: the JD names Excel, so expect a probe on the tools. If you used Excel and which features, say which; if it was another tool, say so. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Plain acknowledgment, at its own scope: "I haven't presented to anyone above regional level." Then a plan: how you would prepare a senior-leader presentation. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Tellers, not supervisors. Say it at that scope. Answer slot: if you coached anyone other than tellers, including supervisors, say who, on what, and how; if not, say so and describe what the training covered. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Silence, not absence. Answer slot: if you worked with a digital or product team on a customer-facing change, say what changed and your part in it; if not, say so and say what you would bring from the branch side. |

Gate check: no requirement here is a term or credential bar (`evidence-conventions.md` §3), so no hard gate is raised.

## Prohibited claims

Not coached in any answer, bridge or drill. Each has its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Handled complaints across the contact centre | Inflated form of F2; stated negative in F3 | "I handled the branch's formal complaints log." Plus "I haven't worked in a contact centre." |
| Presented to senior leaders | Inflated form of F7; stated negative | "I haven't presented to anyone above regional level." No slot. |
| Handled regulated complaints | Inflated form of F4 | "I handled the branch's formal complaints log." The pack's analysis: your material says formal, not regulated. |
| Wrote or designed the escalation script | Inflated form of "trained new tellers on our escalation script" | "I trained new tellers on our escalation script." The material does not say who wrote it. |
| Coached branch supervisors | Inflated form of F8 | "I trained new tellers on our escalation script." |
| Spreadsheet tracked resolution times | Inflated form of F5 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Built Excel models or dashboards | Inflated form of F6 | "I built the monthly complaints spreadsheet our regional manager uses." |

## Grounding brief (company vocabulary)

Sourced from the values page you copied on 19 November 2026, the recruiter's email, and the strategy brief as you summarised it. A search for the brief on 19 November returned the same summary and nothing newer, so the figures below stand as published in July 2026.

- Vocabulary: "member-owned", "about 900 staff", the four values by name.
- Strategy [grounded, your message]: "move 40% of member service to digital channels by 2028"; "consolidate eight branches into five hubs over 2027"; "launch a small-business lending product in Q1 2027".
- Competition [grounded, your message]: "the main competitive pressure is app-only banks".
- Sound current, not archival: refer to the hubs and the digital target as the brief states them. Do not correct the interviewer.

## Values cheat sheet

Lives with Round 3 (panel), the round the recruiter names as the values round. Four values, each mapped to your quoted material, or a selection scaffold ending in its honest branch where no quote carries a story.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F2: "I handled the branch's formal complaints log." No member-side decision is in your material. Scaffold: pick a case where the member's side changed your answer; if none comes to mind, say so and give the complaints log as it stands. |
| Plain Words | If a member needs it explained twice, the wording was wrong | F8: "trained new tellers on our escalation script." Scaffold: the script is the nearest carrier; say what you changed in its wording and why, or say you did not change it. |
| Neighbours, Not Numbers | Every branch is part of its town | F2 at branch scope. No town-level decision is in your material. Scaffold: a decision that affected a branch's community; if none, describe how branch complaints reached you. The hub plan is the live tension. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F5: "I built the monthly complaints spreadsheet our regional manager uses." No kept-to-resolution story is in your material. Scaffold: a problem you found and followed to resolution; if you did not, say so. |

## Round 1: Recruiter screen (30 min)

**Persona weights:** Conversational 3 (main), light Skeptic 1, logistics 4. Relationship prior: recruiter screen. The risk is treating this as unscored.

**Persona table**

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly opener, background, motivation | High: the screen is their first read of you | 90-second arc; treat every answer as scored |
| Skeptic (light) | "What's the gap?" | High: the JD's contact-centre and senior-presentation lines are the obvious gaps | Name the gap plainly, then the plan |
| Logistics | Pay, notice, location, reason for leaving | Certain: the recruiter row of the persona model | Give your own answer in your own words |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-C1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | 90-second arc: the years, the branch, the complaints log, the escalation training, the spreadsheet. Use only these beats. | F1 is the strongest fit; this is the first place to state it. |
| R1-C2 | "What do you know about us?" | CO | [grounded] "member-owned, about 900 staff" (JD); "move 40% of member service to digital channels by 2028" (your message) | Name what the material states: member-owned, the four values, the digital target. Do not guess at internal detail. | The screen tests whether you read the material. |
| R1-C3 | "What draws you to this role?" | VAL | [generic] | Selection scaffold: name the complaint-ownership line in the JD and say what about it draws you. If you cannot yet name it, say so. | No quote carries a motivation; the answer must be yours. |
| R1-S1 | "What's the biggest gap between your experience and this role?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I haven't worked in a contact centre." Then the plan from F3. | Pre-empts the Round 2 objection in a lighter register. |
| R1-L1 | "What are your pay expectations?" | JD | [generic] | Logistics slot: give your own figure, or ask for the band first. | Standard screen question. |
| R1-L2 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period. | Standard screen question. |
| R1-L3 | "Where can you work from?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" (your message) | Logistics slot: name the locations you can work from, and whether a hub is within reach. | The hub plan may change where the role sits. |
| R1-L4 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: give your actual reason in your own words. | Standard screen question; no reason is in your material. |

**Reverse questions** (ask at the end; one line each on why it lands)

1. "What does a good first 90 days look like?" Why it lands: shows you are planning the job, not the offer.
2. "How is the hub plan affecting complaint volumes so far?" Why it lands: shows you read the strategy as operations.
3. "Who is the panel, and what do they most want from this role?" Why it lands: a recruiter can answer, and it lets you prepare for Round 3.
4. "What has the recruiter already heard the panel say about complaints?" Why it lands: it surfaces the values expectations.
5. "What is the next step after the third round?" Why it lands: shows you are tracking the process.

## Round 2: Head of Member Services (45 min, future manager, mostly behavioural)

**Persona weights:** Values/Behavioural 4 (the recruiter says mostly behavioural), Skeptic 3 (hiring-manager prior: derisk the gaps), Case/Strategist 2 (live roadmap problems). Relationship prior: hiring manager.

**Persona table**

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioural | STAR-shaped prompts about escalation, coaching, ownership | High: the recruiter says mostly behavioural | Quote-or-slot stories; "we" for context, "I" for contribution |
| Skeptic | The gaps in F3, F7, F2 | High: the most predictable objections | Rehearse the contact-centre objection until it is boring |
| Case/Strategist | Digital target and hub consolidation | Medium: the manager owns the roadmap | Clarify, then structure, then name the risk |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-B1 | "Tell me about a time you had to escalate a complaint you could not resolve at branch level." | VAL | [grounded] "trained new tellers on our escalation script" | Open prompt. Scaffold: pick an escalation where the complaint moved beyond the branch; say what you did and what happened next. If none comes to mind, say so plainly, then give the nearest thing your material carries: the escalation script you trained tellers on. | The JD's escalation line; F8 is the nearest carrier. |
| R2-B2 | "Walk me through how you trained new tellers on the escalation script." | EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped from the quote: the training and the script. Answer slot: if you checked whether tellers used it correctly, say how; if you did not, say so. | Premised only on the quoted training; probes the coaching half of F8. |
| R2-B3 | "Tell me about a time you had to hold a line with a colleague or a member under pressure." | VAL | [generic] | Selection scaffold: pick a time the position mattered and held; if none, say so. | Typical behavioural prompt; no quote carries it. |
| R2-B4 | "When has a complaint shown you a process problem nobody asked you to fix?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Open prompt. Scaffold: a problem you noticed and took on; the spreadsheet is the nearest carrier, but say only what it shows. If you have no such case, say so. | Tests the Own the Fix value and the end-to-end line in the JD. |
| R2-S1 | "You have never worked in a contact centre, and this role owns complaints across it. What is your answer?" | JD | [grounded] "Never worked in a contact centre" | Highest-ROI prep in this pack. Hold: "I haven't worked in a contact centre." Then the plan from F3 (how you would learn the contact centre's complaint routing). Hold through two follow-ups by returning to what you have done: the branch's formal complaints log. Concede plainly when pressed: the contact centre is the part you have not done. | This is the most predictable objection, because the JD names the contact centre and F3 is a stated absence. |
| R2-S2 | "You have never presented above regional level. Why would you present to senior leaders now?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the preparation plan from F7. Do not claim a presentation you have not given. | Derisks F7 directly. |
| R2-S3 | "Did your monthly spreadsheet show resolution times?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot from F5: if it did, say which measure and how it was counted; if not, say so and say what you would add first. | The JD requires resolution times, and your material is silent on them. |
| R2-C1 | "The brief moves 40% of member service to digital by 2028. What would you do first to keep complaints handled well during that shift?" | CASE | [generic] | Live problem, no claim about your past. Clarify: which complaints move to digital and which stay human. Objective: no member left without a route to a person. Approach: segment by complaint type. Metrics: resolution time and repeat contacts. Risk: digital-only members. | Tests whether you think at the company's altitude. |
| R2-C2 | "Eight branches become five hubs during 2027. How would you keep complaint handling consistent while branches close?" | CASE | [generic] | Clarify: which branches and which members. Approach: a common escalation standard across hubs. Metrics: volume and resolution time by hub. Risk: members in a town losing their branch. | The Neighbours, Not Numbers tension in the brief. |

**Reverse questions**

1. "What would a good first 90 days look like, and what would you want fixed by then?" Why it lands: it shows you plan to own the work.
2. "Where do complaints get stuck between branch and contact centre today?" Why it lands: it shows you know the seam is the job.
3. "What resolution-time target is reported monthly now?" Why it lands: it turns your spreadsheet into a question about their numbers.
4. "How will the digital self-service work be prioritised against the hub consolidation?" Why it lands: it shows you read the brief as a sequencing problem.
5. "What would make you say the role has been a success after a year?" Why it lands: it lets you show the outcome you would own.

## Round 3: Panel of two branch managers (60 min, values round, 20-minute escalation case)

**Persona weights:** Values/Behavioural 4 (the panel scores against the four values), Case/Strategist 1 (the 20-minute case), Peer Evaluator 2 (two branch managers are peers in the branch network), Data-Driven Prober 1 (the monthly reporting). Relationship prior: panel, blend the top two personas of each member's relationship. Individual members are not named, so the blend is not per person.

**Persona table**

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioural | One question per value | Certain: the recruiter says the panel scores the four values | One story per value, or the scaffold with its honest branch |
| Case/Strategist | Twenty-minute escalation | Certain: the recruiter names it | Clarify, then structure, then name the risks |
| Peer Evaluator | "Where's the seam?" | Medium: branch managers test the seam with the contact centre | Propose seam principles; name what you bring |
| Data-Driven Prober | "Which figure would you defend least?" | Medium: the monthly report is a JD line | Say what the spreadsheet did and did not count |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-V1 | "Tell me about a time you decided something from the member's side of the counter, even though the process pointed the other way." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a case where the member's side changed your answer. If none comes to mind, say so plainly, then give the complaints log as it stands. | Members First; F2 is the carrier. |
| R3-V2 | "When have you had to make an explanation clearer for a member?" | VAL | [grounded] "trained new tellers on our escalation script" | Open prompt. Scaffold: the script is the nearest carrier; say what you changed in its wording and why. If you changed nothing, say so. | Plain Words. |
| R3-V3 | "When has a branch decision affected the people of its town, and how did you account for it?" | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Scaffold: a decision that affected a branch's community; if none, describe how branch complaints reached you. | Neighbours, Not Numbers; the hub plan is the live tension. |
| R3-V4 | "Tell me about a problem you found and kept until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Open prompt. Scaffold: a problem you followed to resolution. The spreadsheet is the nearest carrier, but say only what it shows. If you did not keep a problem to resolution, say so. | Own the Fix. |
| R3-CASE | Twenty-minute case (practice version, generic): "A member has been to your branch twice about a disputed fee. The branch wants to close it. The member says they will take it further. Walk us through what you do." | CASE | [generic] | Clarify: the complaint file and any deadline that applies. Objective: a decision the member can understand. Approach: confirm the facts; check the escalation route; coach the branch supervisor on what to record. Metrics: time to resolution, repeat contacts. Risks: a missed deadline, a member who feels unheard. Say aloud what you would check before you decide. | This is the escalation case the panel will run. The scenario is a practice version, not Ashgrove's case. |
| R3-PEER1 | "Our branches and the contact centre sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a made-up seam. Reciprocity: what you bring the contact centre, not only what you need from it. Selection scaffold for a disagreement; if none, say so. | Peer Evaluator stem; you have no contact-centre material. |
| R3-PEER2 | "How do you handle credit when a complaint fix spans teams?" | VAL | [generic] | Selection scaffold: pick a fix that spanned teams and say who did what, in your words. If none, say so. | Peer credit probe. |
| R3-PROBE | "Walk us through what your monthly complaints spreadsheet counted, and how." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Premised only on the quote: a monthly complaints spreadsheet. Answer slot: if you can say what it counted and how, say so; if not, say so and say what you would check first. Do not invent a method. | Tests the monthly reporting line; the figure is yours to define only if you did. |

**Reverse questions**

1. "What would a new complaints lead do in the first month that would help your branches most?" Why it lands: a reciprocity question, the one the peer persona rewards.
2. "How do branches and the contact centre hand over a complaint today?" Why it lands: it shows you know the seam.
3. "Where do escalations stall now?" Why it lands: it shows you want the real problem.
4. "How is the hub plan changing branch complaint volumes?" Why it lands: it connects the brief to the work.
5. "What does a good escalation look like to you?" Why it lands: it lets the panel show their standard, which you can then match.

## Sources

- Provided: the job description (in your message); the recruiter's email on rounds and format (as you relayed it); the values page as copied on 19 November 2026; the strategy brief as summarised in your message; your background (your message).
- Search sent: "Ashgrove Credit Union 2026 strategy branches hubs digital". Result: the strategy brief, same figures as your summary. Nothing newer.

Research tier: L1 — searches 1 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. ashgrovecu.org values | skipped | The values page is in hand (copied 19 November 2026), so the cheat sheet is fixed. |
| 2. Interview process | skipped | The recruiter's email fixes the three rounds and their formats. |
| 3. Strategy / recent news | yes | The one search returned the strategy brief with the same figures as your summary. It moved nothing; the grounding brief stands as written. |
| 4. Interviewer name | n/a | No names were given for the Head of Member Services or the panel. |
| 5. Representative JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Names of the Head of Member Services and the two branch managers → personas weighted from their public footprint, and a tailored reverse question.
- The escalation case brief, if the recruiter will share it → the Round 3 case replaced with Ashgrove's real scenario.
- Your monthly complaints spreadsheet, described by its columns → F5 and F6 move from answer slots to grounded lines, and R3-PROBE gets a real figure to defend.
- Any contact-centre or digital project you worked on, even as a participant → F3 and F9 move from gaps to bridges, and R2-S1 gets a stronger hold.
- The full strategy brief text → the grounding brief gains the detail the summary leaves out.
- A deeper research pass at L2 (strategy brief, interviewer talks, loop reports, recent org news), with its caps and time cost stated, offered once, run only on your consent.
