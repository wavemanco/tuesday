# Interview prep: Product Manager, Platform APIs at Quartzline

**Role:** Product Manager, Platform APIs · **Company:** Quartzline · **Round:** hiring-manager conversation, 45 minutes, Thursday · **Interviewer:** not named

**Built from:** `tuesday-dossier.md` (job-underwriter, dossier version 1.1, generated 2026-08-14, decision conditional_go). That dossier is three months old. If the posting or the role has changed since, the rows below may be stale.

**Research:** none. Web search was refused in this session, so no company facts are in the pack. Anything the pack would have taken from company research is labeled `[generic]`.

## How to use this pack

- **Personas** are how a question arrives. **Types** are what it scores.
- Type key: **JD** role requirement · **EXP** work-experience deep-dive · **CASE** live problem · **CO** company knowledge (none: no company research ran) · **VAL** values (none: no values round was detected).
- Guidance is scaffolding, not a script. Each guidance cell is speakable in about 90 to 120 seconds.
- **Answer slots** are instructions for the interview. They ask nothing of you here. Either branch is honest: answer from your own experience, or say plainly the step was not yours or did not happen.

## 1. Fit snapshot

Evidence is quoted from the dossier's verified entries. Requirement text is quoted from the dossier's `role_profile`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "none given" for the PM title. Adjacent: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified 3 | low | [inferred] | transferability | Your material shows adjacent work, not the title. Say the title plainly: "I haven't held a product manager title." Then quote the integration work word for word. Limit: that is integration work, not product management. Answer slot: if any of the years you would count toward this requirement involved product decisions, say which and how you decided, in your own words; if not, say so and stay with the integration work. |
| F2 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified 1 | high | [grounded] | transferability | The quote carries go-live on client integrations of the vendor's APIs. It does not say you shipped a platform product. Limit, said plainly: your material does not say which side of that API you sat on, and you should know the answer before Thursday. |
| F3 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Wrote the internal integration playbook her team uses" — dossier verified 2 | high | [grounded] | presentation | Your playbook is integration documentation. Say what it covers and how your team uses it, in those words. Answer slot: the requirement names schemas, so expect a probe. If you wrote or reviewed schemas, say how, in your own words; if not, say so and return to the playbook. |
| F4 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified 3 | medium | [grounded] | discovery | The client side is quoted. Engineering and sales are not. Answer slot: if you worked with the engineering or sales side on those integrations or on the roadmap inputs, say how, in your own words; if you did not, say so and stay with the client side. |
| F5 | "Agile delivery experience" — dossier role_profile R5 | "none given." No verified entry speaks to agile delivery. | low | [inferred] | discovery | Say what you ran, in those words, if anything. If you worked on sprints or a comparable cadence, say how. If you worked another way, say so and ask how they define delivery here. Clarify, not bridge: the dossier's strategy for this requirement is clarify. |

**Confidence note.** Verified entry 3 is medium: confirmed, with limited inspectable proof. Expect a probe on it and volunteer the limit before it is pulled out of you.

## 2. Prohibited claims

Each entry names its basis and its honest form. No answer, bridge, slot, reverse question or drill may assert, soften or imply any entry here.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | Plain acknowledgment, sourced to that field: "I haven't held a product manager title." No slot. |
| Owning a product roadmap | Dossier `prohibited_claims` and `uncertain_or_weak_areas` (acknowledge_gap, "Owning a roadmap and prioritization authority") | Plain acknowledgment, sourced to those fields: "I haven't owned a product roadmap." No slot. |
| Setting prioritization for an engineering squad | Dossier `prohibited_claims` | Plain acknowledgment, sourced to that field: "I haven't set prioritization for an engineering squad." No slot. |
| Owned the partner API roadmap | Inflated form of verified entry 3 | Entry 3 at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." The limit is this pack's observation, not words for you: your material says input to product, not a roadmap. No first-person negative. |
| Shipped platform products | Inflated form of verified entry 1 | Entry 1 at its own scope: client integrations going live on the vendor's APIs. The limit is this pack's observation: your material does not say you shipped a platform product. No first-person negative. |

The decision summary in the dossier says "seven years of integration leadership." No verified entry carries that figure, so no pack line uses it. It can be quoted only after you confirm it (see the upgrade menu).

## 3. Question banks

Persona weights are set by relationship. A hiring manager is mainly a Skeptic and a Case/Strategist. The interviewer's name is not given, so the interviewer read is absent and no interviewer signals adjust the weights.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Skeptic | The objection to the missing title and roadmap, asked plainly | Highest. Hiring managers buy capability and derisk gaps. The dossier names the objection. | Plain acknowledgment, then the limit, then a ramp plan stated as a plan | 5 |
| Case/Strategist | Live problems from this role | High. The JD asks for owning delivery across two squads and an API platform. | Clarify, then structure, then metrics, then risks | 4 |
| Data-Driven Prober | Denominators and assumptions behind your numbers | Medium. The verified entries carry one count, 30+. | Say how it was counted and the assumption you would defend least | 3 |
| Pressure | Time-boxed challenge to the core claim | Low to medium. Hiring managers test composure on the weakest point. | Hold through two follow-ups, then concede the specific limit | 2 |
| Conversational | Open opener, a casual question on a JD topic | Low to medium. Casual questions are still scored. | 90-second arc in your own words | 2 |
| Values/Behavioral | Open prompt on a hard truth or a customer over a metric | Low. No values round was detected. Persona stems only. | Selection scaffold; say so if none comes to mind | 2 |

Total: 18 questions.

### Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified 3; the negatives are sourced to dossier `prohibited_claims` and `uncertain_or_weak_areas` by field | **The highest-ROI rehearsal in this pack. The underwriter named this objection, so this is theirs.** Start with the plain acknowledgment: "I haven't held a product manager title or owned a roadmap." Then quote verified 1 word for word. Name the limit: it is integration work. Then the closest roadmap work, quoted: input to product, not ownership. Hold through two follow-ups by returning to verified 1. Concede roadmap ownership specifically if pushed. Ramp-plan answer slot: say in your own words what you would do first to learn how the squads set priorities. It is a plan, not a record. | Named by the underwriter. Skeptic item and the highest-ROI prep. The premise is kept because each negative has a dossier source. |
| B2 | "Which roadmap decisions would you make alone in this role, and which would you need the two squad leads for?" | JD | [grounded] "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | Answer slot: say which decisions you would make alone and which need the squad leads, in your own words. If you have not made roadmap decisions before, say so and say how you would find the line. | Decision authority is the dossier's unresolved risk. This is the interview's version of the employer question. |
| B3 | "If an engineering lead disagreed with a priority this role set, what would you do?" | JD | [generic] | Structure it: hear the disagreement, name what it changes, decide with the lead, record the call. Make no claim about a past squad. | A hypothetical that presupposes no past. It tests the prioritization the prohibited list keeps off your record. |
| B4 | "On the integrations you led, who decided what each client got in scope?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified 1 | Answer slot: say which scoping decisions were yours and which were the client's or someone else's, in your own words. If none were yours, say so plainly and describe how scope was set. | Tests the scoping word in verified 1 at attribution. Answer slot, not a claim: the quote does not say who set scope. |
| B5 | "What would you count first to know partner API adoption is working?" | JD | [grounded] "Define and track adoption metrics" — dossier role_profile responsibilities | Name the metric you would ask for first. The dossier records no current baseline, so say you would ask for one before setting a target. Do not invent a baseline or a figure. | The dossier names adoption metrics with no baseline. The honest answer asks for the baseline first. |

### Case/Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch your first 90 days. What do you need to know before you touch the roadmap?" | CASE | [generic] | Clarify: which partners, which squads, what the roadmap is measured on. Then structure: discovery with partners, the squad leads' view, the adoption baseline, one risk to name. Speak the structure first. | A live problem from the role. Generic: no company fact is used, because no company research ran. |
| C2 | "Partner adoption of the API has stalled. How would you diagnose it?" | CASE | [generic] | Clarify the metric and the baseline first. Segment partners by integration size and use case. Then check onboarding friction, docs and version changes. Name the assumption you would test first. | Covers adoption and partner discovery. Generic framework, no past claimed. |
| C3 | "Two engineering squads disagree on sequencing. What do you do on day one?" | CASE | [generic] | Clarify what each squad owns and what each dependency blocks. Propose one decision rule, a shared written sequence, and a date to revisit. | The JD names two squads. This covers the delivery requirement, R5, as a decision rather than a record. |
| C4 | "A partner's integration is blocked by a schema change. What do you weigh before deciding?" | CASE | [generic] | Walk the trade-off in your own words: backward compatibility, the partner's timeline, the cost of a version. Answer slot: if you have handled a schema or versioning decision, say what it was and what you decided. If not, say so and describe how you would weigh it. | Covers R3 (schemas) as a live problem. The slot allows that you have not made such a decision. |

### Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "How did you count the 30+ integrations, and what counts as end-to-end?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified 1 | Answer slot on the figure: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so. | The figure raises the defend-the-number slots. Verified 1 is high confidence, so expect the count to be tested. |
| A2 | "What would you need to see before you called partner adoption a success?" | JD | [generic] | Name the metric and the baseline you would ask for. Say what you would not count as success. | Adoption is a stated responsibility with no baseline. Generic: no company fact is used. |
| A3 | "Which of the roadmap inputs you gathered each quarter changed a decision, and how do you know?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified 3 | Answer slot: if any input changed a decision, say which and how you know. If you cannot show that an input changed one, say so plainly and say what you did with the evidence. | Verified 3 is medium confidence and says feeding, not deciding. The slot allows that no decision was shown. |

### Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we take a chance on you over a PM with the title?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified 1 | Pause, then restate the question. Give the plain acknowledgment, then verified 1 word for word, then the limit. Hold through two follow-ups. Concede the roadmap specifically, never the core claim. | Pressure item on R1. Hold-then-concede is the structure. |
| D2 | "That integration work: how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified 1 | Answer slot: name which stages you ran yourself and which you supported, in your own words. If the word "led" means something narrower than the whole stage list, say so. | Tests the attribution of verified 1. Expect this if the Pressure persona is in the room. |

### Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | JD | [grounded] "Wrote the internal integration playbook her team uses" — dossier verified 2; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified 3 | A 90-second arc in your own words: the integrations, the playbook, the roadmap inputs. End on the limit: the title and the roadmap are the parts you have not held. | Casual opener, still scored. A pre-scripted arc keeps the ending on the limit. |
| E2 | "What are you playing with in API docs these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" — dossier verified 2 | Answer slot: name the documentation tools you have used, in your own words. If you have not used one, say so and say how you would learn it. | R3 asked casually. Scored as casual. |

### Values/Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | Selection scaffold: pick a time you told a senior person something they did not want to hear, with a named stake, a moment you did not fold, and a relationship intact at the end. If none comes to mind, say so plainly, then give the nearest thing you have done. | Persona stem. No quoted sentence carries this story, so the guidance is a selection scaffold. |
| V2 | "When did you put a customer ahead of an internal metric?" | EXP | [generic] | Selection scaffold: pick a time a client's need cost you a number you were tracking. If none, say so and give the nearest thing you have done. Do not borrow the go-live from verified 1 as a story unless it had that tension. | Persona stem. The client side of your work is the likeliest home for the answer. |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1 3+ years product management | B1, B2, D1, E1; F1 slot |
| R2 Shipped API or platform products | A1, B4, D2; F2 limit |
| R3 Technical fluency: API docs, schemas | C4, E2; F3 slot |
| R4 Stakeholder management | B2, B4, A3; F4 slot; reverse 5 |
| R5 Agile delivery | C3; F5 clarify; reverse 4 |

No requirement is uncovered.

## 4. Reverse questions

Each one has a "why it lands." No interviewer profile exists, so none ties to the interviewer's own career path. Add the name and one can be tailored (upgrade menu).

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: it is the open risk in the dossier and the question you need answered before you accept.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: adoption is a named responsibility with no baseline in the dossier. Asking shows you will check the number before you promise a target.
3. "What would the first 90 days need to deliver for you to call this hire a success?" Why it lands: it turns the Skeptic's objection into the manager's own bar.
4. "How does the team define agile delivery across the two squads?" Why it lands: it resolves R5 in their words, since the dossier has no evidence on it.
5. "Where does partner discovery sit today: product, the squads, or sales?" Why it lands: it tests R4 and shows you already see the seam.

## 5. Sources

- **Provided documents:** `tuesday-dossier.md` (job-underwriter, version 1.1, generated 2026-08-14). Sections consumed: `role_profile`, `handoff_to_mock_interview` (high-priority requirements, verified evidence, uncertain areas, likely objection, risks, employer questions, prohibited claims). The `decision` summary was used as context only. The `seven years` figure in it is not used as a fact.
- **Searches sent:** "Quartzline company values"; "Quartzline Product Manager Platform APIs interview process"; "Quartzline partner API platform strategy". All three were refused (web search permission not granted in this session). No results came back.

Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Values cheat sheet, section 10. Not built: no values-style round was detected. |
| 2. `Quartzline interview process` | unavailable | Loop structure and persona weights. Weights were set from the relationship priors instead. |
| 3. `Quartzline strategy` / recent news | unavailable | The CO bank and a strategy-grounded CASE question. Those are generic (C1 to C3) instead. |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given. |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` fixes the requirements and the JD-tagged questions. |

## 6. Upgrade menu

- **Which side of the vendor's API you sat on** (the client integrating it, or the team that provided it) → tightens F2 and the B1 bridge. This is the most useful single fact you can confirm.
- **The years behind "3+ years," and the seven years in the dossier's summary** → confirm the count and what it covered. Once confirmed, either can be quoted in the bridge instead of left out.
- **The interviewer's name** → a tailored reverse question and persona weights from their public footprint.
- **Company values or the interview-process page, pasted** → a values cheat sheet and a loop structure. Search is refused here, so pasting is the route.
- **Deep research (L2)** → strategy brief, interviewer talks and role-loop reports. Offered once. It would need search access, which this session does not have, or pasted material.
- **Refreshed dossier** → if the posting has changed since 2026-08-14, a fresh underwriting pass would update F1 to F5.
