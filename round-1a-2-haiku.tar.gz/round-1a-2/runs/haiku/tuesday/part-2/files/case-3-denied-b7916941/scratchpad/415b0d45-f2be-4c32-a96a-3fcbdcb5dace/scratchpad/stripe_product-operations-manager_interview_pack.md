# Stripe — Product Operations Manager — Final-round prep pack

First delivery. No earlier version.

## How to use + type key

- **Personas** describe *how* a question is asked. **Types** describe *what* is being scored.
- Type tags: **VAL** behavioral/values · **EXP** your past work, tested for attribution · **JD** the role's stated responsibilities · **CO** company and strategy knowledge · **CASE** a live problem.
- Guidance is scaffolding, not a script. Speak in your own words, and only about what you actually did.

## Fit snapshot

No job description and no CV were supplied, so every row is a worksheet row: the requirements are role-family patterns (`[generic]`), no evidence is on file, and every confidence is `none`. Each row's gap is `discovery`, because the material is silent, not because you lack the skill.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| W1 | Design and document operating processes that several teams follow — role family, no source | none given | none | [generic] | discovery | Selection scaffold: pick a process you designed or ran that other people depended on; say what it replaced and how you would know it worked. If no such process comes to mind, say so plainly, then give the nearest one you have. |
| W2 | Define and track metrics that show whether operations are healthy — role family, no source | none given | none | [generic] | discovery | Selection scaffold: pick one metric you have reported; say how it was counted and which assumption you would defend least. If you have never reported one, say so and describe how you would define one. |
| W3 | Influence engineering, finance, legal and go-to-market teams without direct authority — role family, no source | none given | none | [generic] | discovery | Selection scaffold: pick a case where you moved a decision owned by another team; say whose call it was and what you contributed. If none comes to mind, say so and describe how you would approach it. |
| W4 | Plan and run rollouts and change management — role family, no source | none given | none | [generic] | discovery | Selection scaffold: pick a rollout you ran end to end; say what you controlled and what you did not. If you have not run one, say so and describe your rollout plan. |
| W5 | Choose priorities and say no when capacity is short — role family, no source | none given | none | [generic] | discovery | Selection scaffold: pick a time you dropped or delayed work; say what you cut, who decided, and what it cost. If none comes to mind, say so and describe how you would decide. |

## Prohibited claims

No candidate sentence is on file, so there is no wording to stretch. These are the claims a candidate reaches for under pressure, built locally.

| Not coached | Basis | Honest form |
|---|---|---|
| A figure, team size or dollar amount you have not already stated | Built locally: a number given in an interview is one you must defend | Give a number only if you know how it was counted; otherwise describe the change without one |
| Ownership of a decision or process that was someone else's call | Built locally: role-family pattern, not your statement | Say whose call it was and what you contributed |
| Hands-on use of a tool, method or certification you have not named | Built locally: role-family pattern, not your statement | If you have not used it, say so and say how you would learn it |

## Persona weights

No relationship to the interviewers is known, so the weights are flat across a blend for a final round. Final rounds often run as several sessions with different people; the weights will change once you say who you are meeting.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Case / Strategist | Live operations problems | High: product-ops roles are judged on structure under a live problem | Clarify, then structure, then answer | 5 (A) |
| Data-Driven Prober | Asks how a number was counted | Medium: operations roles are metric-heavy | Name the weakest assumption before they do | 3 (B) |
| Skeptic | Probes the gaps: "why this, why now" | Medium-high: the fit snapshot has no evidence on file, so the gaps are untested | Rehearse the predictable objection until it is calm | 3 (C) |
| Pressure / Stress | Interrupts, time-boxes, challenges | Medium: final rounds often test composure | Pause, restate, hold through two follow-ups, concede specifically | 3 (D) |
| Values / Behavioral | Scenario probes against published values | Low-medium: no values round is established, so this is a fallback tilt, not a detected round | STAR-shaped stories with an honest branch | 2 (E) |
| Peer Evaluator | Seams between teams | Medium: operations work sits beside many teams | Propose seam principles, not invented detail | 2 (F) |
| Conversational / Rapport | Casual opener, scored anyway | Low-medium: casual questions are still scored | A 90-second arc; treat casual questions as scored | 2 (G) |

## Question banks

Session total: 20 questions. Every `[generic]` question makes no claim about you; guidance that speaks about your past is an open prompt with an honest branch.

### A — Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A process that works for one team is breaking for another as the company grows. How would you diagnose it?" | CASE | [generic] | Clarify what "breaking" means and which signal shows it. Segment the teams. Name two hypotheses, the metric that would separate them, and the first change you would test. | Generic live problem at the core of the role (W1) |
| A2 | "The volume of a queue your team depends on doubled last month. Walk me through your first hour." | CASE | [generic] | Check for a change event, then whether volume or handling time moved. Segment by source. State what you would pull first and what would change your plan. | Generic diagnosis problem (W4) |
| A3 | "A launch slipped two weeks and the owning team says the dependency belongs to someone else. What do you do?" | CASE | [generic] | Map the dependency and find the decision owner. Propose a reset plan with dates and a named escalation path. | Cross-team influence as a live problem (W3) |
| A4 | "How would you decide what the operations team should stop doing?" | CASE | [generic] | Start from the goal, then list the work and what each item protects. Propose a test, not a verdict. | Prioritization under capacity (W5) |
| A5 | "Leadership wants one metric for operational health. What would you propose, and what would you reject?" | CASE | [generic] | Name one candidate metric and its failure mode (gaming, a lagging signal). Add a guardrail metric. | Metric design (W2) |

### B — Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a metric you reported to leadership. How was it counted?" | EXP | [generic] | Selection scaffold: choose a metric you actually reported; give its definition and source. Say the assumption you would defend least. If you have never reported one, say so and describe how you would define one. | Every headline figure draws a probe; this asks for attribution, not inflation (W2) |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Follow-up to B1. Name the weakest assumption in your own words before the interviewer does. If you do not know how it was counted, say so. | Converts a gotcha into a credibility gain (W2) |
| B3 | "How would you know a process change worked, when the baseline itself moves?" | JD | [generic] | Name a before-and-after comparison plus a control or holdout. Say what you would do if the control also moved. | Measurement under change (W1, W2) |

### C — Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one part honestly. Then give a ramp plan for the first 30 days: who you would learn from and what you would look at first. | Predictable and fair; calibrated candor beats bluffing |
| C2 | "Why operations rather than a product or program role?" | JD | [generic] | One honest sentence on what draws you to operations work, then one on what you would want to avoid repeating from past roles. | Motivation consistency is scored for every final (Skeptic) |
| C3 | "Describe a process you owned that failed. What did you do?" | EXP | [generic] | Selection scaffold: pick a failure you owned; state what broke, what you changed and what you would do differently. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it. | Highest-ROI prep in this pack: the objection that comes up in some form. It sharpens once the JD and CV arrive |

### D — Pressure / Stress (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have sixty seconds: why should we hire you over someone who has run this exact role?" | JD | [generic] | Pause. Restate the question. Answer with the one thing you can do that the comparison hinges on. Hold through two follow-ups. | Tests composure under a comparison you cannot win on pedigree |
| D2 | "That sounds like the process mattered less than the people running it. Push back." | EXP | [generic] | Hold your position through two follow-ups. Concede only the specific point that is true, and say what you would check. Do not fold on the core claim. | Hold-then-concede structure |
| D3 | "Your last answer was vague. Give me one number." | EXP | [generic] | If you have a figure, give it and say how it was counted. If not, say so and describe the change without a number. Never invent one under pressure. | Tests honesty under pressure to be specific |

### E — Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time the truth landed and the relationship survived. Use "we" for context and "I" for what you did. If no such time comes to mind, say so, then give the nearest one. | Fallback values tilt; no published values are on file |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold with the same honest branch as E1. Name the metric you gave up and what it cost. | Customer-over-metric stories are a common scoring theme |

### F — Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles (who owns the handoff, who decides on a conflict) rather than pretending to know their seam. Give one disagreement you handled with a peer, in your own words. | Peer pricing of the hire: turf and disagreement style |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a shared piece of work; say what you named and what you did not claim. | Partnership fit |

### G — Conversational / Rapport (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, what you have done, why this role. Keep each beat to what you have actually done. | Casual opener, scored on economy |
| G2 | "What part of how a company runs its operations do you find most interesting?" | JD | [generic] | One specific answer, tied to one thing you have done or want to learn. Avoid a generic list. | Casual, but a plus signal for product-ops interest |

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| W1 process design | A1, A4, B3 | |
| W2 metrics | A5, B1, B2, B3 | |
| W3 cross-functional influence | A3, F1, F2 | |
| W4 rollout and change | A2, A3 | |
| W5 prioritization | A4, C1, D1 | |

## Reverse questions

Each one has a reason it lands.

1. "What does a strong first six months look like in this role?" Why it lands: it signals you are planning to deliver, not just to be hired.
2. "Which decision in this team has been slowest to make lately, and why?" Why it lands: it invites a candid answer and shows you think about decision speed.
3. "How does the team measure operations health today, and what do you think it misses?" Why it lands: it tests your metric thinking on their live problem.
4. "What would you most want the person in this seat to fix first?" Why it lands: it surfaces the real priority behind the posting.
5. "What could a new person do in their first month that would genuinely help your team?" Why it lands: a reciprocity question. Use it whenever the interviewer is a peer.

## Sources

Provided documents: none. The role title and company came from your message.

Searches sent, all refused by the host (permission not granted), each returning nothing:

- `Stripe company values operating principles` — refused
- `Stripe interview process product operations manager final round` — refused
- `Stripe strategy recent news 2026` — refused

Research tier: L1 — searches 3 of 6 (all refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Values cheat sheet, section 10: not built, because no published values were in hand and no detected values round. Refused search. |
| 2. `Stripe interview process product operations` | unavailable | Loop structure and persona weights: the weights above are flat because the loop is unknown. Refused search. |
| 3. `Stripe strategy` / recent news | unavailable | CO and CASE questions grounded in current strategy: none written, and the CASE questions above are generic. Refused search. |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form. |
| 5. representative Product Operations Manager JD | unavailable | Would have grounded the fit snapshot and the JD-tagged questions. No call was sent. |

## Upgrade menu

- Pasted Stripe values page, or permission to search → the values cheat sheet, and the E-bank questions mapped to real published values
- Pasted job description → W-rows become `[grounded]` quotes, and the JD-tagged questions become tied to the posting
- Your CV, or a bulleted list of your experience → the selection scaffolds become story maps from your own sentences
- Who you are meeting and the round's structure → personas reweighted, and reverse questions tied to their path
- The recruiter's note on focus areas or any take-home → a graded-deliverable section
- A deeper research pass (up to 6 more searches and 2 more fetches, several minutes) → strategy brief for CO and CASE questions, once search is granted
