Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/haiku/tuesday/part-2/rooms/case-8-canned-b71fc157/ashgrove_member-experience-lead_interview_pack.md`. I built it as three mini-packs, one per round, since all three fall on 28 November.

The biggest finding: your material gives the panel nothing to score on the values. None of your sentences carries a decision of yours for Members First, Plain Words, Neighbours, Not Numbers or Own the Fix. The values section gives you selection prompts with an honest "say so, then give the nearest thing" branch, not stories. Build four real cases from your own work before the panel, and only use ones where the decision was yours.

Your strongest gap is the contact centre, which you stated yourself and which the JD puts first. Rehearse that question (B5) hardest. It's a plain "I haven't worked in a contact centre," then the branch log you do have, then a plan. The senior-leader gap is the same shape (B6).

The pack also covers the logistics questions (pay, notice, location, reason for leaving), a 20-minute escalation case built on generic facts, and a hub-closure case grounded in the strategy brief you pasted. The values and strategy text came from your paste; I did not check them against the live site, and I ran no searches.

Offers, none pushed:
- **Drill:** I can run the 20-minute case as the panel, or play the Skeptic on B5.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- **Word:** I can convert the pack to .docx if you want it.
- **Extra section (beyond the spec):** a separate presenting-and-Excel plan. Say the word and I'll add it.

Watch-out: Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Three rounds on 28 November 2026, so this is loop mode: one shared fit snapshot, then one mini-pack per round. Built 19 November 2026 from your message, the JD, the values and strategy text you pasted, and the recruiter's email. I have not checked the pasted values or strategy text against the live site.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores.
- **Types:** JD = a stated job requirement. EXP = your past work, tested for what you actually did. VAL = one of Ashgrove's four published values. CO = company and strategy knowledge. CASE = a live problem with no claim about your past.
- Guidance is scaffolding, not a script. An **answer slot** is a question you answer in your own words; either honest branch it names is a good answer.

## Prep triage (9 days)

All three rounds fall on one day, so the notes you take in round one carry into rounds two and three. In order:

1. **Write four values stories from real cases only** (C1 to C4). Your material shows no decision of yours for any of the four values, and the round-three panel scores on them.
2. **Rehearse B5 out loud, twice, with two follow-ups.** It is the highest-ROI item. The JD's first responsibility runs across the contact centre, and you have stated that gap yourself. Then rehearse B9 under pressure.
3. **Run the 20-minute case (C5) against a timer, twice.**
4. **Rehearse the 90-second arc (A5)** and have real answers ready for A1 to A4 (pay, notice, location, reason for leaving).
5. **Prepare the spreadsheet:** what it recorded, what it did not, and which tool it sits in (B4, B8, F7, F8).

Everything else is insurance.

## 1. Fit snapshot

No requirement in this JD is a gate under the evidence conventions. "4+ years" is a length-of-experience line and is graded like any other. "Regulated complaints", "Excel reporting" and "digital teams" are experience or skills, not terms. So no row is `hard_gate`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Your words already reach this in retail-banking terms. Bridge: "I've spent six years in retail banking, the last three as a branch supervisor." Let the interviewer place it under customer operations. Expect a probe on whether branch work counts. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Formal complaints are close, but your material does not show regulation. Bridge: "I handled the branch's formal complaints log." Answer slot: if the log ran to a set timescale or was reported beyond the branch, say which and how you kept to it, in your own words; if it did not, say so and stay with the log. |
| F3 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | transferability | Your material shows teller training on the script, not coaching of supervisors. Clarify-strategy note: say tellers, and say what you taught them. Do not say supervisors. |
| F4 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log." — your message | low | [inferred] | transferability | The log is branch-level, and the material does not show the process end to end. Bridge: the log in its own terms. Any wider claim is an answer slot inside the branch: which steps ran through you, and say plainly if the rest was not yours. |
| F5 | "and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated this absence. Words: "I haven't worked in a contact centre." Then how you would learn how contact-centre complaints reach the team, said as a plan, never as a past. |
| F6 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated this absence. Words: "I haven't presented to anyone above regional level." Then how you would prepare for a senior audience, said as a plan. |
| F7 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | Monthly reporting is reached. Volumes and resolution times are not stated. Bridge: the spreadsheet sentence as written. Answer slot: say which of the two measures it carried, if either, and how each was counted, in your own words; if it carried neither, say so and say what you would add first. |
| F8 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your material says spreadsheet, not Excel. Clarify-strategy note: say spreadsheet until you have named the tool. Answer slot: name the tool it sits in and the parts you built yourself; if you did not build the parts, say so. |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent here, and you have not stated an absence. Answer slot: if you have worked on any change to how members serve themselves, say what it was and your part in it; if you have not, say so and say what you would test first. |

**Requirement coverage**

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | A5 |
| Regulated complaints | B10 |
| Coach branch supervisors on escalations | B1, B7 |
| End to end across branches | B3, C7 |
| Contact centre | A7, B5, B9 |
| Monthly volumes and resolution times | B4, B8 |
| Presenting to senior leaders | B6 |
| Excel reporting | A8 |
| Digital teams, self-service | C9 |
| Four values | C1 to C4 |

## 2. Prohibited claims

Built here from the fit snapshot. Each entry names its basis and its honest form. None of these may appear in any answer, hold or slot.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F4 | "I handled the branch's formal complaints log." Limit, as the pack's own observation: your material shows the branch log, not the process. |
| Worked in a contact centre | Negative you stated, F5 | "I haven't worked in a contact centre." No slot. |
| Presented to senior leaders | Negative you stated, F6 | "I haven't presented to anyone above regional level." No slot. |
| Coached branch supervisors on escalations | Inflated form of F3 | "I trained new tellers on our escalation script." |
| Built reporting on volumes and resolution times | Inflated form of F7 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Excel reporting | Inflated form of F8 | "spreadsheet", with the tool named in the slot. |
| Regulated complaints | Inflated form of F2 | "formal complaints log." |
| Six years in customer operations | Inflated form of F1 | "6 years in retail banking, the last 3 as a branch supervisor." |

## 3. Grounding brief

The strategy brief you pasted (July 2026, under six months old) is the company's current frame. Use its own words. Do not correct the interviewer if they use an older framing.

- **Digital:** "move 40% of member service to digital channels by 2028"
- **Branches:** "consolidate eight branches into five hubs over 2027"
- **Lending:** "launch a small-business lending product in Q1 2027"
- **Competition:** the main pressure is app-only banks

## 4. Values cheat sheet (round 3)

Detected: the recruiter's email says the panel scores against the four values. The values are pasted from the site. None of your quoted sentences carries a decision for any value, so each row is a selection scaffold ending in its honest branch.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold: a decision you made for a member against a default or a target. Your material does not show one. If none comes, say so, then describe what you handled on the log, and no more. |
| Plain Words | If a member needs it explained twice, the writing was wrong | Scaffold: a time you rewrote an explanation a member did not follow. Your material shows teller training on the script, not plain wording. If none comes, say so, then describe the training as it happened. |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold: a case where a local fact changed the answer. Your spreadsheet is numbers; expect the panel to ask where the town shows up in it. If none comes, say so, and say what the spreadsheet does not show. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Scaffold: a complaint you kept hold of to a close. "I handled the branch's formal complaints log" shows handling, not holding a fix to solved. If none comes, say so, then describe the log. |

## 5. Loop and persona weights

**Loop source:** the recruiter's email names the sessions: 30 minutes with the recruiter; 45 minutes with the Head of Member Services, who would be your manager, "mostly behavioral"; 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case, which also scores the values. Interviewers beyond the roles are not assigned, so the weights are per round, not per person.

### Round 1: recruiter screen (30 minutes)

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Opener, background walk-through, logistics in a friendly register | High: a screen prior, and the logistics are scored | 90-second arc; treat casual JD questions as scored |
| Skeptic (light) | "I don't see contact-centre work" | Medium: a screen flags gaps for round two | Plain acknowledgment, then the plan |

### Round 2: Head of Member Services (45 minutes, mostly behavioral)

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Behavioral | "Tell me about a time…" | High: the recruiter says the round is mostly behavioral, so this moves up from the hiring-manager prior | STAR; "we" for context, "I" for your part |
| Skeptic | Contact centre, senior leaders | High: the hiring-manager prior, plus two gaps you stated (F5, F6) | Plain acknowledgment, plan, hold then concede |
| Prober | The spreadsheet, the regulated log | Medium-high: the JD's reporting line | Say what it counts; say what you do not know |
| Case | A supervisor who escalates everything | Medium: a manager's live problem | Clarify first |
| Pressure | "Sixty seconds" | Medium | Hold through two follow-ups |

### Round 3: panel of two branch managers (60 minutes, with the 20-minute case)

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Four values, scored | Highest: the panel scores against them | A real decision for each value, or the honest branch |
| Case | The 20-minute escalation case; the hub closure | High: a named case | Time-box each phase |
| Pressure | "Your experience is at branch level" | Medium: two panellists, one likely to test scope | Hold the scope; concede it specifically |
| Peer | The seam between branch and complaints team | Medium: branch managers are the people you would coach | Reciprocity: what you bring their branches |
| CO | Digital shift | Low-medium: a follow-up | Plan, not past |

## 6. Question banks

### Round 1: recruiter screen (A)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your pay expectations for this role?" | JD | [generic] recruiter-screen logistics | Logistics slot: give the figure you need, in your own words, or ask for the band first. | Pay is a recruiter-screen logistics row. The figure is yours; the pack supplies none. |
| A2 | "What is your notice period?" | JD | [generic] recruiter-screen logistics | Logistics slot: give your actual notice period. | As A1. |
| A3 | "Where are you based, and what can you do on office days?" | JD | [generic] recruiter-screen logistics | Logistics slot: state your location and your actual office availability, in your terms. | As A1. |
| A4 | "What is drawing you from banking into member complaints?" | EXP | [generic] recruiter-screen logistics | Logistics slot: give the real reason in one or two sentences, in your own words. If it concerns the branch network, say only what is true for you. | The recruiter checks this against the rest of the pack. |
| A5 | "Walk me through your background." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Give the 90-second arc in your own sentences, in this order: six years in retail banking, the last three as a branch supervisor; the formal complaints log; teller training on the escalation script; the monthly spreadsheet. Add nothing. | Answers the 4+ years line (F1) and is the spine every other answer draws on. Rationale: JD content, EXP delivery. |
| A6 | "Why complaints, and why Ashgrove?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." (the values text you pasted) | Name one value in your own words and say what about complaints work draws you to it. One sentence on why; make no claim about your record. | The conversational opener is scored as motivation. |
| A7 | "I don't see contact-centre work in your background. How does that square with this role?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't worked in a contact centre." Then the nearest thing: "I handled the branch's formal complaints log." Then how you would learn the contact centre, as a plan. | A light version of B5, which the round-two panel is likely to press harder. |
| A8 | "What are you actually playing with in Excel these days?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: name the tool the spreadsheet sits in and the parts you built yourself. Do not say Excel until you have checked it is the tool. | F8 is low confidence, so this question is where the tool gets confirmed. |

### Round 2: Head of Member Services (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you coached someone through an escalation they handled badly." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Your material shows teller training on the script, not supervisor coaching. Answer slot: if you coached someone through an escalation, tell that case; if not, say so plainly and describe the teller training as it happened. | Scores F3. The honest answer is the teller training. |
| B2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] selection scaffold; [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Pick a time you told someone above you something they did not want to hear: the stake, the moment you said it, what followed. Your material shows the spreadsheet, not a truth delivered. If none comes, say so, then describe what the spreadsheet shows and what it does not. | Behavioral stem; no quote carries a story. |
| B3 | "Tell me about a complaint you were handling that went badly wrong." | JD | [grounded] "I handled the branch's formal complaints log." | Answer slot: if a logged complaint went wrong and you were handling it, say what happened and what you did. If none comes, say so, then describe how you handled the log day to day. | Scores the end-to-end line (F4). Do not stretch "handled" into "owned". |
| B4 | "Tell me about a time a monthly figure you produced changed what someone did." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Scaffold: say what the spreadsheet is for and who uses it. If you can name a decision a manager made from it, say what it was; if not, say so and say what it showed. Do not claim a change you cannot describe. | Tests F7 in use. The JD raises monthly volumes and resolution times. |
| B5 | "The role runs complaints across branches and the contact centre. You haven't worked in a contact centre. What do you do first?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Highest-ROI prep. Hold: "I haven't worked in a contact centre." Then the nearest thing: the branch's formal complaints log, and what it does and does not cover. Then your first step, as a plan. Hold through two follow-ups by returning to the log and the plan. Concede the gap in one line; do not fold on the core claim. | F5 is the gap you stated, and the JD's first responsibility runs across the contact centre. This is the question to rehearse hardest. |
| B6 | "How would you present complaint volumes to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then how you would prepare for that audit, as a plan. | F6. Plan language only. |
| B7 | "A branch supervisor escalates every complaint to you. What do you do?" | CASE | [generic] case structure | Structure it: what you would ask first, how you would check the escalation against the script, what you would coach and how you would see whether it stuck. Make no claim about your past. | The JD's coaching line, as a live problem. |
| B8 | "What does the monthly complaints spreadsheet record?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: say what it records, in your own words. If it holds a figure, name the assumption behind it you would defend least. If it records no figure, say so. If you cannot say how a number was counted, say that. | Defend-the-number for F7. |
| B9 | "Sixty seconds: why should we hire someone with no contact-centre background for a role that runs one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pressure. Restate the question. Anchor: "I haven't worked in a contact centre; the nearest thing I've handled is the branch's formal complaints log." Hold through two follow-ups; concede the gap specifically, then give the plan. | Pressure form of B5. |
| B10 | "What rules did the formal complaints log work to, and how did you keep to them?" | JD | [grounded] "I handled the branch's formal complaints log." | Answer slot: if the log had set rules or timescales, say what they were and how you kept to them. If it had none, or that part was not yours, say so and describe how the log was kept. | Scores the regulated-complaints line (F2). The rules are the interviewer's premise, not in your material. |

### Round 3: panel of two branch managers (C)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] selection scaffold; [grounded] "I handled the branch's formal complaints log." | Pick a time a member's interest beat a target or a standard you were measured on, and say what you did. If none comes, say so, then say what you handled on the log, and no more. | Members First. The raising source is the values text. |
| C2 | "Tell me about a time an explanation to a member did not land, and you had to put it right." | VAL | [generic] selection scaffold; [grounded] "trained new tellers on our escalation script." | Pick a time you rewrote an explanation a member did not follow. If none comes, say so, then describe the teller training in your own words. | Plain Words. The raising source is "if a member needs it explained twice, we wrote it wrong." |
| C3 | "Tell me about a case where a local detail changed the answer." | VAL | [generic] selection scaffold; [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Pick a case where something specific to the town changed how you handled it. If none comes, say so, then say what the spreadsheet is for and what it does not show. | Neighbours, Not Numbers. Your evidence is a spreadsheet, so expect the question. |
| C4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log." | Story-mapped only as far as the sentence goes: you handled the log. It does not say you held a complaint to a close. Answer slot: if you saw one logged complaint through to a close, say what you did. If you cannot say it was yours to see through, say so. | Own the Fix. Do not turn handling into holding. |
| C5 | Case: a member's refund dispute, 20 minutes. The brief is below the table. | CASE | [generic] case structure | Phases: 0 to 3 minutes, clarify the deadline, who can authorise the refund, and what the member asked for. 3 to 8 minutes, the member side: one named owner, one call back, one plain written line. 8 to 13 minutes, find the problem: check the refund across the branch and the contact centre, and keep hold of it. 13 to 17 minutes, the cause: three answers from three people is a script gap, so fix it once, not case by case. 17 to 20 minutes, measure: open count, resolution time and repeat contacts, reported to the Head each month. Think aloud and challenge one premise, such as the timescale. | The recruiter's 20-minute case, generic and with no Ashgrove facts. Each phase maps to a value. |
| C6 | "Eight branches become five hubs over 2027. A branch in your patch closes in the spring. What happens to its open complaints?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your message, describing the brief) | Clarify which complaints are open and what each member has been told. Objective: no complaint lost or repeated in the move, and every member keeps a named contact. Segments: members who used that branch, members in the town. Approach: move a single list of open complaints with its owner. Metrics: open count and resolution time before and after, and repeat contacts. Risk: a spike at cutover, and the tension with Neighbours, Not Numbers. Make no claim that you have run a closure. | Strategy-grounded differentiator. The structure is generic; the fact is from the brief. |
| C7 | "Your experience is at branch level. Why would we trust you across a network?" | JD | [grounded] "I handled the branch's formal complaints log." | Hold the scope: the log you handled was the branch's. Hold through two follow-ups. Concede the limit specifically: you have not worked across a network. Then give the plan for that scope, not a claim to it. | Pressure on the end-to-end line (F4). |
| C8 | "Our teams sit side by side. Where is the seam between a branch and the complaints team, and what happens when we disagree?" | JD | [grounded] "trained new tellers on our escalation script." | Reciprocity first: what you would bring to a branch team. Propose seam principles: who holds the member contact, who holds the fix. Disagreement: a story only if you have one; otherwise say what you would do and keep it as a plan. | Peer stem. The coaching line in the JD is the raising source. |
| C9 | "The bank plans to move 40% of member service to digital channels by 2028. What would you change first in the complaints journey for a member who starts in the app?" | JD | [grounded] "work with digital teams on self-service journeys" (the JD). | Plan, not past: where a complaint is raised in the app, how a member sees its status, and which contact a member repeats. Answer slot: if you have worked on any self-service change, say what and your part in it; if not, say so and name the first change you would test. | Scores F9. The strategy line is the hook. |

**Case brief for C5 (generic, no Ashgrove facts):** A member's card was blocked after a fraud alert, and a fee was taken on the day. The branch said it would be refunded. The contact centre has no record of the refund. The member has written a formal complaint, says three different people have given three different answers, and wants one named person to call them. The complaint reached you on day 6 of a timescale whose length the panel will give you. You have 20 minutes.

### Reverse questions

| Round | Question | Why it lands |
|---|---|---|
| 1 | "What has made candidates for this role stumble in past rounds?" | Signals you are preparing for the next two rounds, not just this one. |
| 1 | "What does the Head of Member Services want to see in the first 90 days?" | Shows you are thinking about the manager and the role's first real problem. |
| 2 | "With the branch hubs and the digital channels both moving, where should the complaints process be in a year?" | Puts the strategy into the manager's terms and invites a view on the work. |
| 2 | "Which supervisors are you most concerned about on escalations, and why?" | Converts the coaching gap into a working conversation. |
| 3 | "When a complaint moves from a branch to the contact centre, who holds it today?" | Tests Own the Fix in practice and gives you the seam. |
| 3 | "What do you wish the complaints team understood about your town?" | Lets Neighbours, Not Numbers come from the panel, not from a story you supply. |

## 7. Sources

Provided: your message; the Ashgrove values text you pasted; the July 2026 strategy brief as you described it; the recruiter's email; the JD.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The four values were pasted from the site and fix the names and definitions. Built the cheat sheet from them. |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the loop: three named sessions on 28 November. |
| 3. Ashgrove strategy / recent news | skipped | The July 2026 brief you pasted is under six months old and fixes the current priorities and moves. |
| 4. Interviewer name + Ashgrove | n/a | No interviewer is named; they are not yet assigned. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## 8. Upgrade menu

- **Interviewer names, once assigned** → a personal persona weight for each panellist, reverse questions drawn from their own career paths, and a per-member plan for the panel.
- **The complaints rules for the formal log** (what timescales or outside reporting applied to it) → turns the answer slots in F2 and B10 into grounded answers.
- **What the spreadsheet recorded, and the tool it sits in** → upgrades F7 and F8 from medium and low, and lets A8 and B8 be answered from evidence.
- **One real decision for each value, if one exists** → turns C1 to C4 from scaffolds into story-mapped answers. Without them, the honest branch is the answer.
- **Pay, notice, location and reason for leaving** → fills the logistics slots A1 to A4 with your own figures and reasons. The pack supplies none.
- **Any work on member self-service** → fills the answer slot in F9 and C9.
- **Whether your branch is among the eight in the 2027 plan** → lets C6 use your own branch rather than a hypothetical.
- **A deeper research pass (L2, offered once):** up to 6 more searches and 2 more fetches, several minutes, covering recent organisation context and role-family loop reports. Want it?
