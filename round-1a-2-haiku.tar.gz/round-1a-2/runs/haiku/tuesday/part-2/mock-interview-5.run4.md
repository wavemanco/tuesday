Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-5-denied-f2556476/e7c4fc6a-476e-4ccb-9b4d-605e03531fea/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it for a second-round panel, since the recruiter's email named Deepa and Ross and their roles. I didn't have the JD, so it works from the recruiter's quoted lines and your background.

**The POV is the graded part.** Three theses, each with a concession you have to say out loud:
- **T1:** The operator's constraint is change, not capacity. Partners win by reducing timetable-change and disruption risk for the planning team.
- **T2:** Partner-led, but judged on operator outcomes rather than partner count. Concede that rail partners are fewer and slower than ISV ones.
- **T3 (the anti-pick):** Don't build an ISV-style programme for operators. Name the one thing you'd say no to.

Close on one operator outcome you'd be accountable for. The 15 minutes is roughly 3 on the operator's problem, 6 on your thesis, 4 on what it means for operators, and 2 on the 18-month shape.

**The highest-ROI rehearsal is A3:** "You haven't sold into rail. Why would an operator take a proposal from you?" Concede first, then make the case from your planning background. Don't claim sales experience. Ross is likely to press on B1 (what "influenced" counted) and B2 (no quota). The pack gives the hold-then-concede structure for B2 and an honest branch for B4 (how concentrated the £4M was). The pack leaves the influenced-revenue definition as a slot you fill in your own words. Its guidance can't supply that.

**Research didn't run.** My two web searches were refused by the permission check, so the pack has no sourced values, interview loop or strategy. I didn't retry. Check their values page and the loop yourself, and paste the strategy report's headlines if you want them worked in.

Two questions that would sharpen it:
1. Can you paste the full JD? Without it the pack can't check gate requirements, and its coverage is thinner.
2. What do you know of Deepa's and Ross's backgrounds? That changes how I weight the two personas and what I'd ask them in reverse.

Your four hours: about 75 minutes on the POV, 60 on Ross's commercials, 45 on the Skeptic items, 30 on the reverse questions and close, and 30 to skim the rest.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** Second-round panel, 60 minutes. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director).
**Format:** First 15 minutes is a spoken POV on operator partnerships over 18 months, no slides. The rest is Q&A, and Ross will push on commercials.
**Built on:** the recruiter's email (quoted lines), your background as you described it in this conversation, and no JD. No company research ran (see Sources).

## How to use + type key

Personas are how a question is asked. Types are what it scores.

| Tag | Name | What it scores |
|---|---|---|
| **VAL** | Values alignment | Not used: no values-style round is detected for this loop |
| **EXP** | Experience deep-dive | Whether what you did survives scrutiny |
| **JD** | Role-driven | Whether you can do the job as described (no JD yet, so limited) |
| **CO** | Company and strategy | Not used: no company research ran |
| **CASE** | Live problem | Structure and reasoning on a problem from the role |

Guidance is scaffolding, not a script. Rehearse the beats, not the words.

## Prep triage (about 4 hours)

1. **About 75 min: the POV.** Outline the three theses below, pick one, and rehearse it aloud twice against a timer at 15 minutes. Section "Graded deliverable" below.
2. **About 60 min: Ross's commercials, B1 to B4.** These are where the numbers get tested. Write down exactly what "influenced" means in your own words before anything else.
3. **About 45 min: the Skeptic items, A3 and A2.** A3 is the single highest-ROI prep in this pack, because the rail gap will come up in some form.
4. **About 30 min: reverse questions and the close.**
5. **About 30 min: skim the rest.**

Everything else is insurance.

## Fit snapshot

No JD was supplied, so the requirements below are the recruiter's own words, quoted. A `[generic]` row marks an expectation I inferred from the company's sector, with no source.

| ID | Requirement | Evidence (your words, quoted) | Confidence | Provenance | Gap type | Bridge language |
|---|---|---|---|---|---|---|
| F1 | "a short POV on where you'd take our operator partnerships over the next 18 months" | "took it from 6 partners to 40, roughly £4M of influenced revenue" | medium | [grounded] | transferability | Your partner-scale work is ISV, not operator. Make that transfer, and its limits, explicit |
| F2 | "Please land on what it means for the operators themselves." | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | medium | [grounded] | transferability | Operator-side knowledge from planning, not from selling to a train operating company |
| F3 | "Ross will push on commercials." | "roughly £4M of influenced revenue" and "never carried a direct quota, only influenced revenue" | medium | [grounded] | transferability | Influence is the measure you ran. A direct-quota record is absent, and you say so |
| F4 | Rail sales experience, not in the recruiter's words | "never sold into rail specifically" | none | [generic] | capability | State the limit plainly; name a closure path (shadowing a rail sales cycle, operator reference calls) |

## Graded deliverable: the 15-minute POV

Pre-declared by the recruiter, so it is graded. Build it, do not improvise it.

**What to build on (only what is in hand):** F1 and F2. Do not claim rail sales experience (F4).

**Thesis options, each with a mandatory concession:**

- **T1, the operator's constraint is change, not capacity.** Partners win when they reduce timetable-change and disruption-recovery risk for the operator's planning team, not when they add reseller reach. *Concession:* "I haven't sold into rail, so I'd test this with three operators before I commit to it."
- **T2, partner-led, measured by operator outcomes, not partner count.** Judge the programme on operator results (punctuality, change readiness), not on how many partners you sign. *Concession:* "My six-to-forty was ISV scale. Rail partners are fewer and slower, so the number will drop before it grows."
- **T3, the anti-pick: do not build an ISV-style programme for operators.** The buyer is one or two people per operator, and the channel runs through the operator's own consultants. *Concession:* "This may be wrong. I'd rather learn it from the first two operators than assume it."

**Differentiation against the consensus answer:** the consensus is a tiered partner programme with co-selling, certification and a marketplace. Bring one consensus item to show grounding, then one thesis-driven divergence (T3), and say where you would say no: a partner-led deal that bypasses the operator's planning team.

**The requested close (what it means for operators):** name one operator outcome the programme is accountable for, for example fewer failed timetable changes or faster recovery after disruption. Put it as the last sentence, not an afterthought.

**Timing:** about 3 min on the operator's problem, 6 min on your thesis and concession, 4 min on what it means for operators, 2 min on the 18-month shape.

## Persona table

| Persona | How it shows up here | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Deepa asks you to work a live operator problem | High | Hiring manager, buying capability for an 18-month plan | Structure out loud; name the first question you'd ask |
| Skeptic | Deepa on the rail gap and on operator trust | High | The rail gap is the obvious risk; A3 is the likely form | Concede plainly, then point to the operator-side evidence you do have |
| Data-Driven Prober | Ross asks what "influenced" counts | High | Commercial director, and the influenced-revenue figure is the most inspectable number you gave | Define the term in your words before he asks |
| Pressure | Ross on the missing quota | Medium-high | The direct-quota gap is the commercial soft spot | Hold the influence measure through two follow-ups, then concede precisely |
| Conversational | Opening and close | Medium | Panels open warmly | Use C1 and C2 for the opening, and R1 to R5 for the close |
| Values / Behavioral | Not expected | Low | No loop source establishes a values round, and no archetype fallback applies | No VAL questions in this pack |
| Peer Evaluator | Not expected | Low | Neither interviewer is a peer | Not used |

## Prohibited claims

What this pack will not coach, and why. Built locally from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've sold into rail" or "I've managed operator accounts" | Negative you stated: "never sold into rail specifically" | "I've never sold into rail. My operator knowledge comes from transport planning." No slot |
| "I carried a quota" or "I hit my number" | Negative you stated: "never carried a direct quota" | "I never carried a direct quota. I was measured on influenced revenue, about £4M." No slot |
| "I generated £4M" | Inflated form of F3. The quote says influenced | F3's quote at its own scope: "roughly £4M of influenced revenue." B1's slot asks what "influenced" counted |
| "I built the programme from six to forty partners by myself" | Inflated form of F1. The quote says the scale, not the sole ownership | F1's quote at its own scope. A2's slot asks which partners were yours |

## Question banks

Totals: 18 questions. Weights: Deepa's block 6 (Case/Strategist and Skeptic), Ross's block 6 (Prober and Pressure), Conversational 3, and 3 more across the two.

### A. Deepa (Case/Strategist, Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Pick one operator on our list. What does your first 90 days with them look like?" | CASE | [generic] | Name the first question you would ask the operator and the first thing you would not do. Then one 90-day milestone tied to the POV's operator outcome | Closes the POV loop in a live setting; the answer tests whether the POV is real |
| A2 | "What did you personally do to take the ISV channel from six partners to forty?" | EXP | [grounded] "took it from 6 partners to 40" | Name the two or three moves you made yourself. Answer slot: if some of the 40 came through a team or a previous owner, say which, and how you knew it was yours to take | F1 is the strongest sentence you have, and it is the most likely place for an attribution probe |
| A3 | "You haven't sold into rail. Why would an operator take a partnerships proposal from you?" | JD | [grounded] "never sold into rail specifically" and "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Concede plainly first: "I haven't sold into rail." Then point to the operator-side knowledge: how operators plan, what they need from a schedule change. Hold through two follow-ups by returning to the planning knowledge, never by claiming sales experience | F4 is the gap Deepa is most likely to probe. Highest-ROI rehearsal in the pack |
| A4 | "Operators are judged on punctuality and change disruption. Where does a partner actually fit?" | CASE | [generic] | Answer with the thesis you picked. Use the operator's constraint, not the partner's reach | Tests whether the POV holds up under a probe |
| A5 | "What would you cut from the POV if you had to give it in five minutes?" | CASE | [generic] | Name the cut, and say why it is the weakest of your three theses. Do not defend the cut to the last word | Checks whether your POV has a spine |
| A6 | "What's the first operator relationship you'd lose, and why?" | JD | [generic] | Name a realistic loss: a planning team that won't change its tooling. Say what you would learn from it | Tests humility and risk judgement without a fact about the company |
| A7 | "Tell me about a partner you lost. What did you change afterwards?" | EXP | [generic] | Answer slot: if you lost a partner, name the cause and the change you made. If none was lost, say so and describe the nearest case | Expected probe on the ISV work; pick a real example from your own record |
| A8 | "How would you structure a rail partner programme differently from an ISV one?" | JD | [generic] | Name two structural differences, such as fewer partners, longer cycles, and operator-led referrals. Say which of these you have seen and which you are inferring | Mid-list JD-style question; the gap here is real and worth saying |

### B. Ross (Prober, Pressure, commercial)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your £4M is influenced revenue. Define influenced, and tell me what you'd defend least." | EXP | [grounded] "roughly £4M of influenced revenue" | Give the definition in your own words first. Name the assumption you would defend least, before he asks. Answer slot: if you did not set the counting method, say so, and say how you would verify the figure | The weakest-assumption move is the credibility gain here. The figure is the most inspectable number you gave |
| B2 | "You've never carried a quota. What number would you sign up to in year one?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Hold the position: influence is the measure you ran, and you do not yet know what a rail number should be. Hold through two follow-ups. Then concede precisely: "I'd want to see the operator pipeline before I commit to a number." Do not invent a figure | Pressure item. The hold-then-concede structure matters more than the number |
| B3 | "How would a partner make money on a rail deal with a multi-year contract cycle?" | CASE | [generic] | Say what you know from ISV economics: referral fees, rev share, co-sell. Say which of those survive a long procurement cycle and which do not | Prober question on the commercial model; answer what you know and name what is unfamiliar |
| B4 | "Of your 40 partners, how many were material? What share of the £4M came from the top five?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: if you know the concentration, say it. If you do not, say "I don't know how concentrated it was" and say how you would find out | Denominator probe; the honest branch is the one I would rehearse |
| B5 | "A TOC will pay less for a longer rollout if it gets a discount. Do you give it?" | CASE | [generic] | Say what you would test first: whether the discount buys a referral, a reference or a longer term. Say what you would not trade | Commercial trade-off; the answer shows judgement, not a rule |
| B6 | "Why shouldn't we hire a sales leader with rail experience and skip the partnerships layer?" | JD | [generic] | Make the case for the partnerships role in one sentence, then concede the case for the sales leader. Say what the role must do that a sales leader would not | Pressure on the role itself; holds your case without overclaiming |
| B7 | "Make the case in 60 seconds for why this is worth a senior hire." | CASE | [generic] | Speak in the POV's terms: the operator outcome, the first 90 days, the one thing you would not do | Compression test. Tests whether the POV and the commercial case agree |

### C. Conversational (low weight; the opening and the close)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What made you move from transport planning into payments?" | EXP | [grounded] "5 years in transport consulting" and "payments company" | Story-select: the reason for the move, in your own words, in one sentence | Opening question; keep it short and true |
| C2 | "What did your transport years teach you about operators that a payments person wouldn't know?" | JD | [grounded] "so I know the operator world from the other side" | Name one operator behaviour you learned in planning, and say how it changes a partner conversation | This is F2 turned into a question. Use it to open the POV |
| C3 | "What from payments won't travel to rail?" | JD | [grounded] "a payments company running the ISV channel" | Name the two things that will not travel: the sales cycle length and the buyer count. Say it plainly | Skeptic-adjacent; answering it honestly defuses A3 |

### Requirement coverage

| Recruiter requirement | Question IDs |
|---|---|
| POV on operator partnerships over 18 months | A1, A4, A5, C2 and the graded deliverable |
| Land on what it means for operators | A1, A4, A6, B7 |
| Commercials | B1 to B5, B7 |
| Partnership experience (your 9 years) | A2, A7, C1 |
| Rail sales experience (F4, `[generic]`) | A3, A8, C3, B3 |

## Reverse questions

At least five. No interviewer profile exists, so none ties to a career path.

1. **To Deepa:** "What did the last person in this role get right, and what did they get wrong in the first six months?" *Why it lands:* shows you are thinking about the job's real shape, not the advert.
2. **To Deepa:** "Which operator relationships work best today, and what do they have in common?" *Why it lands:* signals you want the operator view, which is the POV's whole subject.
3. **To Ross:** "When a deal with an operator stalls, where does it usually stall: procurement, the planning team or the budget holder?" *Why it lands:* a commercial question that shows you know operators buy in stages.
4. **To Ross:** "How is influenced revenue counted here, and does it match how partners are paid?" *Why it lands:* turns the commercial probe into a shared problem.
5. **To Deepa:** "What would a good first 90 days look like to you?" *Why it lands:* gives her a chance to set the bar, and tells you what she is measuring.

## Sources

**Provided documents:** the recruiter's email, quoted in this conversation. The strategy team's market report was read by you but not provided here, so nothing from it is used.

**Research:** no company research ran. Both web searches I sent were refused by the permission check, so there are no sourced values, loop structure or strategy in this pack.

**Target accounting**

Research tier: L1, searches 2 of 6 (both refused), fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Kelverton Rail values | unavailable | Search sent; refused by the permission check. Values would have fed a VAL row, but no values-style round is detected anyway |
| 2 | Kelverton Rail interview process | unavailable | Not sent: the permission check refused search. Would have tested whether a values round exists |
| 3 | Kelverton Rail strategy | unavailable | Search sent; refused. Would have fed CO questions, which are absent here |
| 4 | Interviewer public footprint (Deepa, Ross) | unavailable | Not sent. Would have fed the reading of the interviewer and the reverse questions |
| 5 | Representative JD | unavailable | Not sent. No JD was supplied, so this would have fed the JD tier |

## Upgrade menu

- **The full JD text** → six requirements in the fit snapshot move from recruiter quotes to `[grounded]` JD lines, and JD-tagged questions gain their own coverage. It also tests whether there are gate rows.
- **The strategy report's headline themes, pasted** → CO and CASE questions grounded in your team's own readout, and a sharper differentiation against the consensus answer
- **What you know of Deepa's and Ross's backgrounds** → a persona weighting for each, and tailored reverse questions
- **Research permission, if you want it later** → company values, loop structure and strategy, each sourced
- **Influenced revenue's definition, in your words** → B1's slot becomes a grounded answer, not a slot
