Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-8-canned-f400ac7e/02147a29-5320-408e-8c8e-8012296a3b8a/scratchpad/ashgrove_member-experience-lead_interview_pack.md. It's built in loop mode, with a shared fit snapshot and one mini-pack for each of the three rounds.

The main thing to work on: your material has no story of a decision for any of the four values, and the panel is the values round. Upgrade menu item 1 (two or three complaint cases you handled) is the fix.

Say the word and I'll play the Skeptic on B5, the contact-centre question. The pack names it as the highest-return prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the 20-minute case brief sent before 28 November, or given on the day?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep: Member Experience Lead, Ashgrove Credit Union

**Rounds, 28 November 2026.** Round 1: recruiter, 30 minutes. Round 2: Head of Member Services (your future manager), 45 minutes, mostly behavioural. Round 3: panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case; the panel also scores you against the four values.

Interviewers for rounds 2 and 3 are not named yet, so this pack is built on roles, not people. It runs in loop mode: one shared fit snapshot, then a mini-pack per round.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores:

- **VAL**: behaviour against Ashgrove's published values
- **EXP**: what you actually did in your past roles
- **JD**: the listed job and its requirements
- **CO**: company strategy
- **CASE**: a live problem from the role

Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview: where your material does not show something, the guidance asks for your own answer and gives the honest branch, which is to say so plainly. The **Provenance** column gives the label first, then the sentences from your material that the guidance rests on.

## Fit snapshot (shared across all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. Say it in your words: six years in retail banking, the last three as a branch supervisor. The JD's words "customer operations" are not yours, so don't borrow them for your own history. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material shows a formal log. It does not show whether external rules or deadlines applied to it. Words: "I handled the branch's formal complaints log." Answer slot: the JD's "regulated" line makes a probe on the rules likely. If external rules or deadlines applied, say which and how you kept to them; if they did not, say so plainly. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | One branch's log is adjacent to the process end to end across branches. The pack's observation: your material shows one branch's log, not the whole process. Words: "At my branch I handled the formal complaints log." Answer slot: say which steps of a complaint's life were yours, from first contact to closure. If others set or ran those steps, say so plainly. |
| F4 | "Own the member complaints process end to end across branches and the contact centre" — JD (contact-centre part) | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap you stated yourself. Words: "I haven't worked in a contact centre." Then a plan, not a past: what you would learn first in your first month. Never describe contact-centre experience. |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Training tellers on a script is adjacent to coaching supervisors on live escalations: the audience and the skill differ. Words: "I trained new tellers on our escalation script." Answer slot: the JD asks about coaching supervisors, so expect a probe. If you have coached a supervisor on a live escalation, say what you did and what they did; if not, say so plainly. |
| F6 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The sheet is monthly and covers complaints. Your material does not show whether it counted volumes, resolution times, or both. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: say which measures it held, in your own words. If it held no resolution times, say so plainly and say what you would add first. |
| F7 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | none | Covered. Your material says spreadsheet, not Excel; the pack has not assumed the tool. Words: "I built the monthly complaints spreadsheet our regional manager uses." |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you stated yourself. Words: "I haven't presented above regional level." Then a plan, not a past: how you would get ready for a first senior presentation. Answer slot: if you have presented at regional level, say what it involved, in your own words. |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital work, so this is silence, not a stated absence. Answer slot: if you have shaped or worked alongside a self-service or app journey, say what you changed and what you did not own. If not, say so plainly. |

No JD requirement here is a gate (a term such as pay, location, a licence or a work right), so no row is `hard_gate`. Experience length is graded like any other requirement.

Reading the snapshot: F1 and F7 are your strongest rows. F4, F8 and F9 are the thinnest, and F4 and F8 are gaps you stated yourself. F3 is the row the panel is most likely to test, because your material shows one branch's log and the JD asks for the process across branches.

## Grounding brief: the 2026 strategy, as you summarised it

Provenance: [grounded], the 2026 strategy brief (July 2026), as you summarised it in your message. I have not seen the brief itself, so use the figures as you have read them.

- "move 40% of member service to digital channels by 2028" — the JD's self-service line sits on this.
- "consolidate eight branches into five hubs over 2027" — a branch supervisor will be asked about this. Expect the question of what happens to members, and to you.
- "launch a small-business lending product in Q1 2027" — no JD line touches it. Do not build an answer on it.
- "the main competitive pressure is app-only banks" — the frame for any strategy question.

Use Ashgrove's own words, such as digital channels and hubs. Stale framing: none found in the material you gave; the brief is under six months old.

## Prohibited claims

What this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have run the complaints process end to end across branches" | Inflated form of F3 | "I handled the branch's formal complaints log." The limit is the pack's observation: your material shows one branch's log, not the process across branches. |
| "I have worked in or run a contact centre" | Negative you stated (F4) | "I haven't worked in a contact centre." No slot. |
| "I have coached branch supervisors on escalations" | Inflated form of F5 | "I trained new tellers on our escalation script." |
| "I have presented to senior leaders" | Negative you stated (F8) | "I haven't presented above regional level." No slot. |
| "I have handled regulated complaints" | Inflated form of F2, taking the JD's words | "I handled the branch's formal complaints log." The limit is the pack's observation: your material shows a formal log, not the rules it ran under. |
| "I have tracked resolution times in a monthly report" | Inflated form of F6 | "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: your material does not show resolution times. |

---

## Round 1: Recruiter screen (30 minutes)

**Persona weights.** Conversational is the top persona, because a recruiter screen is friendly in register but scored. Logistics checks (pay, notice, location, reason for leaving) are part of the screen. A light Skeptic covers motivation and the contact-centre gap. Source: the recruiter's email, plus the recruiter-screen prior.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational (A1, A2) | Open invitations to tell your story and say why you're here | High: the opener sets the frame for every later round | Pre-set a 60 to 90 second arc, and keep it to what you stated |
| Logistics (A3 to A6) | Direct knockout-style questions | High: the recruiter must clear pay, notice, location and reason before passing you on | Give your own answers; have the figures ready before the call |
| Skeptic (A7, A8) | Short, pointed checks on the gaps | Medium: motivation consistency and the contact-centre gap | Plain acknowledgment, then a plan; keep the motive tied to the role's scope |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." ; "I handled the branch's formal complaints log" ; "I built the monthly complaints spreadsheet our regional manager uses." | Open with the six years and the last three as a branch supervisor, in your own words. Then one sentence each on the complaints log and the spreadsheet. About 60 to 90 seconds. Stop there; the panel can ask for more. | The opener frames every later answer. It draws only on F1, F2 and F6, so it must not grow. |
| A2 | "What's drawing you to Ashgrove, and to this role?" | CO | [grounded] "move 40% of member service to digital channels by 2028" ; "consolidate eight branches into five hubs over 2027" | Name one line from the strategy you've read, and say in your own words what in your work connects to it. Don't claim digital or hub experience you haven't stated (F9 is silence). About 30 seconds. | Motivation comes up in every round. A motive tied to what Ashgrove has published reads as research; a generic one reads as a template. |
| A3 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot: give your own figure, in your own words, or ask for the band first. Settle your number before the call; the pack does not supply one. | Pay is a screen logistic. The only safe answer is yours. |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give the notice you actually owe, in your own words. If you are not sure what your contract requires, say so and check with HR before the call. | Notice is a knockout check in screens. A guessed number becomes a broken promise later. |
| A5 | "Are you able to work from the hubs as they're set up?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" | Logistics slot: name the places you can reach, and any constraint you actually have. Don't agree to a location you haven't checked. | The question exists because of the brief. The answer is yours. |
| A6 | "Why are you leaving your current role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Logistics slot: give the reason you actually have, in your own words, in two sentences. The material gives no reason, so the pack supplies none. Say nothing about your employer that you can't stand behind. | The reason is checked against everything else. A reason that doesn't match A1 is the one the next round breaks. |
| A7 | "I don't see a contact centre in your background. What would you do in one?" | JD | [grounded] "Never worked in a contact centre" | Say the plain acknowledgment first: "I haven't worked in a contact centre." Then a plan, not a past: what you would learn first, such as listening to live calls and reading the escalation log. Don't describe contact-centre experience. | The JD's contact-centre line meets a gap you stated yourself. The honest answer is the acknowledgment and a credible plan. |
| A8 | "You've been a branch supervisor for three years. Why look now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Hold to what the role asks: a process across branches, not one branch's log. Hold through two follow-ups by returning to the role's scope. Concede plainly any part you have not done yet. | The recruiter's skeptic check: does the reason for moving match the role? |

**Reverse questions, round 1**

- "How are the four values weighed against the case in the panel's score?" Why it lands: it shows you read the values as scored, and the answer tells you where to put your effort.
- "What would make you want to move someone from this screen to the next round?" Why it lands: it shows what the screen actually scores, and it is a conversation rather than a recital.

---

## Round 2: Head of Member Services (45 minutes, mostly behavioural)

**Persona weights.** The recruiter's email says this round is mostly behavioural, and that is a loop source. So behavioural questions lead, above the usual hiring-manager prior of Case and Skeptic. The Skeptic weight stays high because F4 and F8 are gaps you stated. Source: the recruiter's email.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural (B1 to B4) | STAR-shaped prompts about complaints, escalations, and feedback to supervisors | Top weight: the recruiter describes the round as mostly behavioural | Situation and action in "I" for what you did, "we" for context; keep each story to what your material carries |
| Skeptic (B5 to B7) | Pointed questions on the contact-centre gap, presenting, and regulation | Mid weight: this is a manager's usual prior, and your gaps are stated | Plain acknowledgment, then a plan; concede specifically, never fold on the core |
| Case / Strategist (B8) | A live problem from the brief | One question: a manager will test the strategy against the role | Clarify before structuring; name the weakest assumption |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you took a member's complaint from first contact to close." | EXP | [grounded] "I handled the branch's formal complaints log" | Open prompt: choose one complaint from the log and walk it from first contact to close, in your own words, about two minutes. If you can't name one you carried to close, say so plainly, then give the nearest case the log carries and what you did with it. | The JD's end-to-end line. F3 can only partly show it, and the log is the one sentence that supports an instance. |
| B2 | "Tell me about a time you helped someone handle an escalation better." | EXP | [grounded] "trained new tellers on our escalation script" | Open prompt. If you have coached a supervisor on a live escalation, say what you did and what they did. If you haven't, say so plainly, then give the nearest thing: the escalation script you trained tellers on, and what you trained them to do with it. | The JD's coaching line is what this scores. F5's gap is tellers, not supervisors, so the honesty of the answer carries it. |
| B3 | "Tell me about a time a rule and a member's interest pulled apart." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt: a case where the rule and the member's interest diverged, and what you did. If you have no such time, say so plainly, then describe the nearest case the log carries and how you handled the rule. Keep the decision yours, and name who else was involved. | Members First, Always is the value the panel is most likely to hear here. F2's gap means the answer stays inside the log you actually handled. |
| B4 | "What's the hardest feedback you've given a supervisor, and how did it land?" | JD | [grounded] "trained new tellers on our escalation script" | Open prompt. If you have given a supervisor hard feedback, say what you said and what changed. If you haven't, say so and say how you would start. | Coaching supervisors is a JD line your material has not yet evidenced. The honest answer is the feedback you have given, at its real scope. |
| B5 | "You haven't worked in a contact centre. How would you run complaints that come through a contact-centre queue?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment first: "I haven't worked in a contact centre." Then the plan, in order: what you would learn in week one, who you would ask, what you would change in month one, and what you would wait to change. Hold the plan through two follow-ups. Concede specifically what you don't yet know about queues. Don't claim queue experience. | The highest-ROI prep in this pack. The contact-centre gap is the widest in the JD, and the panel will test it. F4 is a stated gap, so the words for it are yours. |
| B6 | "You've never presented above regional level, and the role asks for confidence with senior leaders. How?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented above regional level." Then the plan for getting ready for a first senior presentation. If you have presented at regional level, say what it involved, in your own words. Don't describe senior presentations you haven't made. | F8 is a capability gap you stated. The honest answer names it first, then the plan. |
| B7 | "What made the log 'formal', and what did that mean in how you ran it?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: if external rules or deadlines applied to the log, say which and how you kept to them, in your own words. If they did not, say so plainly and describe how the log was run. The pack does not assume regulation. | The JD's regulated-complaints line is a probe to expect. F2 is discovery, not capability, so the true answer is the one your material supports. |
| B8 | "Member service is moving 40% to digital by 2028. A branch member can't use the app. What happens to them?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" | Think aloud from the brief. Clarify who the members who can't use the app are, what they need from a branch, and how their complaints would show up. Structure: who is most exposed, what they keep and what they lose, the complaint signal you would watch, and the one assumption you would test first. Name the weakest assumption. | The JD's digital line, asked through the brief. The question asks for a method, and makes no claim about your history. |

**Reverse questions, round 2**

- "How will complaint volumes be expected to move while the branches consolidate into hubs in 2027?" Why it lands: it shows you read the brief and asks for the manager's own plan, which only they can give.
- "When you coach a supervisor on an escalation, what has worked for your team, and what hasn't?" Why it lands: it asks about the job itself, invites a working conversation, and tells you what this manager values.

---

## Round 3: Panel of two branch managers (60 minutes, values round)

**Persona weights.** The recruiter's email says the panel scores against the four values, so Values / Behavioural leads. It also sets a 20-minute case, so Case is next. The Data-Driven Prober comes third, because the JD asks for monthly reporting, not because the panel has said it will probe. Source: the recruiter's email; the panel is not yet named, so the weights are blended across members.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural (C1 to C4) | Scenario prompts mapped to the four values | Top weight: the values scoring is stated by the recruiter | Choose real instances; say plainly where none exists; name the hard truth when it lands |
| Case / Strategist (C5 to C7) | The 20-minute complaint-escalation case, then a pressure variant and a rollout question | High: the case is the timed block | Clarify, structure, think aloud, hold a position through two follow-ups |
| Data-Driven Prober (C8, C9) | Questions about what the monthly figures count and how they are checked | Lower: the JD's reporting line makes it likely | Say what you know and what you don't; name the weakest assumption if you can |

**Values cheat sheet.** The panel is the values round; the recruiter's email says so, and the values are the official names from Ashgrove's page. Your material carries no story of a decision for any value, so the mapped story is a selection scaffold with its honest branch. The pack will not supply a story. Upgrade menu item 1 is the fix.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No quoted sentence carries a story for this value. Scaffold: C1. Nearest material: "I handled the branch's formal complaints log" (F2). If no decision of yours shows the member's side, say so. |
| Plain Words | If a member needs it explained twice, the wording was wrong. | No story carried. Scaffold: C2. Nearest material: "trained new tellers on our escalation script" (F5). |
| Neighbours, Not Numbers | Every branch is part of its town. | No story carried. Scaffold: C3. Nearest material: "I built the monthly complaints spreadsheet our regional manager uses" (F6). Hold both sides honestly: reporting is the numbers this value warns about. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | No story carried. Scaffold: C4. Nearest material: "I handled the branch's formal complaints log" (F2). The hard truth is where a case stopped, and whose it became after that. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you put a member ahead of an internal target." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a time the member's side of the counter changed what you did, even if the target was still met. If none comes to mind, say so plainly, then give the nearest thing the log carries and how you ran it from the member's side. | Members First, Always, scored by the panel. No sentence of yours carries a story here, so the honest branch is the answer. |
| C2 | "Tell me about an explanation that didn't land the first time, and what you changed." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: a time the first explanation failed and you changed the wording or the order. If none, say so, then give the nearest: the escalation script you trained tellers on, and what you changed for them, if anything. | Plain Words. The panel is testing whether you can name a rewrite, not whether you like plain English. |
| C3 | "How do you keep a branch's town in view when the monthly figures are on your desk?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Name the tension honestly: the figures describe the town but do not show it. If you have looked past a figure to a local cause, say what it was; if not, say so, and say what you would check locally first. Don't set the numbers aside. | Neighbours, Not Numbers sits beside your reporting work. The panel is checking whether the numbers stay answerable to the place. |
| C4 | "Tell me about a complaint you didn't let go of until it was fixed." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: a complaint you kept until it was solved, what you did when you were stuck, and when you handed it on. If you did not keep one to the end, say so, and give the nearest log case and where it stopped. | Own the Fix. The panel will check the hand-off, so the hard truth is where the case stopped and whose it became. |
| C5 | "Hypothetical: a member's fee complaint has gone from branch to contact centre and back twice with no answer, and they say they will go to the regulator. Walk us through your next 48 hours." | CASE | [generic] | Structure: pin the facts (what was promised, when, and in which record), name one owner, and name the rules you would check rather than assuming them. Then a reply the member can follow, the fix, and what you would record and coach. Use about 15 of the 20 minutes to think aloud. | The 20-minute case is a live problem and asks nothing about your past, so it presupposes nothing about you. It is scored on structure and on one owner. |
| C6 | "Same complaint. The branch manager says the fee is correct and the member should accept it. What now?" | CASE | [generic] | Hold: the member is owed a clear answer even if the fee stands. Separate whether the fee is right from whether the member understood it. Hold through two follow-ups; concede where the branch manager has facts you don't. | A branch manager is on the panel, and this variant tests whether you fold to the local view. Hold the principle, concede the facts. |
| C7 | "You want one escalation rule across all eight branches as they consolidate. Two branch managers object. What do you do?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" | Clarify the objection first. Choose one rule. Test it in two branches before the rest. Say how you would measure it, and name the trade-off you would accept. | Coaching supervisors and the consolidation sit together here. The answer should be a method, not a claim about the hubs. |
| C8 | "What did your monthly complaints spreadsheet count, and what did it leave out?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: say what it held, in your own words. If it held resolution times, say how they were counted and which assumption you would defend least. If it did not, say so plainly and say what you would add first. | The prober's defend-the-number question. Resolution times are the JD's line and F6 is discovery, so the honest answer may name a gap. |
| C9 | "How would you check a monthly complaints figure before a senior leader sees it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Describe the checks you run, in your own words. If you run none you can name, say so, then name what you would add first. Don't claim a control you have not operated. | The JD's Excel and monthly-reporting requirement, asked as a method. It shows whether you know what you would defend. |

**Reverse questions, round 3**

- "Which of the four values tends to separate the strongest answers on this panel?" Why it lands: it shows you want to know where the scoring bites, and the answer will be specific.
- "What would help a new Member Experience Lead most in the first 90 days?" Why it lands: it invites the panel to describe the work, and it is a question a branch manager can answer well.
- Peer reciprocity: "What could a new person do in their first month that would genuinely help your branch?" Why it lands: it turns the panel's attention to what you bring, which is the peer test the pack's persona table names.

---

## Requirement coverage

Each JD requirement, and the questions that cover it.

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | A1 (the background); F1 needs no more |
| Experience handling regulated complaints | B7, C5 |
| Confident presenting to senior leaders | B6 (a stated gap; no story exists) |
| Comfortable with Excel reporting | C9 |
| Own the complaints process end to end across branches and the contact centre | B1, B5, C5 |
| Report monthly on complaint volumes and resolution times | C8 (F6 is discovery) |
| Coach branch supervisors on escalations | B2, B4, C7 |
| Work with digital teams on self-service journeys | B8 (from the brief); no story from you yet, see upgrade menu item 4 |

## Sources

- **Provided documents.** The recruiter's email (round structure, lengths, the panel's values scoring, the 20-minute case). The JD as you pasted it. Ashgrove's values, copied from ashgrovecu.org/about/values on 19 November 2026. The 2026 strategy brief (July 2026), as you summarised it; I have not seen the brief itself. Your background, as stated in your message.
- **User links read:** 0. Searches sent: none.

**Research tier: L1, searches 0 of 6, fetches 0 of 2.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The four values were pasted from the official page this morning, so the official names are in hand; they fix the values cheat sheet. |
| 2. Interview process | skipped | The recruiter's email names the three rounds, their lengths, who runs each, and the case. That establishes the loop, so the round weights and the values round come from it. |
| 3. Strategy and recent news | skipped | The July 2026 brief is under six months old and already gives the priorities and moves used in the grounding brief. |
| 4. Interviewer name | n/a | Interviewers for rounds 2 and 3 are not named, so there is no query to form. The interviewer read is absent; upgrade menu item 2 says what names would add. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- **Two or three complaint cases you actually handled, with what you did.** This gives C1 to C4 and B1 and B3 a grounded story in place of a scaffold. Right now no sentence you have given carries one.
- **The names of the Head of Member Services and the two branch managers.** The pack would weight personas per person and add a tailored reverse question for each, from public professional footprint only.
- **Whether the complaints log carried external rules or deadlines, and which.** This turns F2 from discovery into a grounded answer, and lets B7 and C5 be rehearsed against the real rules.
- **Whether you have shaped or worked alongside a self-service or app journey.** This turns F9 and B8 from silence into an answer.
- **Whether the monthly sheet held resolution times, and how they were counted.** This moves F6 and C8 from discovery to grounded.
- **Your pay expectations, notice period and locations.** A3 to A5 fill their logistics slots. Only you can supply these.
- **How many hours you have before 28 November.** This turns the pack into a prioritised prep schedule.
- **A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes.** It would add the named interviewers' public footprint once you have their names, and recent consolidation news. Want it?
