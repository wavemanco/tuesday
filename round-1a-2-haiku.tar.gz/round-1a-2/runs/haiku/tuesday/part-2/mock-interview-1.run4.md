Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-1-denied-1cf75ef3/7bef87f7-952b-4728-aae3-0c06e6835e21/scratchpad/northwind-data_senior-gtm-strategy-lead_interview_pack.md. I built it for a peer round, since you said Dan is a peer. It has 21 questions weighted toward his data-driven probing, a fit snapshot, a prohibited-claims list, reverse questions and sources. I ran no new research. It uses only your JD highlights, your background summary and your research note.

The most important prep is question D1, the sales-ops and quota gap. It's the objection a sales-strategy peer is most likely to press, and the pack rehearses holding the position, then conceding precisely. The second priority is A1, how the ~$400M figure was counted and which part was hers.

Say the word and I'll play the Skeptic on D1. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Does the full JD mention any location, travel, schedule or work-authorization terms? The answer decides whether any gate row is needed.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. Peer round, same VP. 60 minutes, one conversation.
**Changelog:** First version. Built from your message, your JD highlights and your research note. No new research was run.

---

## 1. How to use this pack

- **Personas** describe how a question arrives: its tone, pace and follow-up style.
- **Types** describe what is being scored.

| Type | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values | Past behavior against stated values. No published values were supplied, so these are scaffolds. |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny and what you actually did |
| JD | Role / JD-driven | Stated responsibilities, including the gaps |
| CO | Company and strategy | Homework depth and altitude |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Guidance is scaffolding, not a script. Each cell is written to be said aloud in 90 to 120 seconds.

---

## 2. Grounding brief (from your research note only)

| Item | What your note says | How the pack uses it |
|---|---|---|
| Three stated priorities | "enterprise expansion", "an AI copilot launch ('Compass')", "reaching profitability" | Case and CO questions C3 and reverse question R6. Know all three; do not recite them. |
| Main competitive threat | "main competitive threat is bundling by a much larger platform vendor" | Case question C1. This is a pricing and packaging question, which is Dan's home ground. |

These facts come from your note and have not been checked against outside sources. If anything in the note is stale, verify it before you say it aloud.

---

## 3. Fit snapshot

Requirements come from your JD highlights, which are not the full posting. Evidence quotes come from your message, the summary of your background. Quotes are your words as you relayed them. Each one should be checked against your own CV before the interview.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (your message) | medium | [grounded] | transferability | Your material shows strategy and operations work, not a go-to-market plan you owned for a product line. Words: "I spent 9 years in product strategy & ops at a large consumer-tech company." Answer slot: if you owned any part of a launch's go-to-market, say which part and how you decided. If none of it was yours, say so and stay with the strategy and ops work. |
| F2 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | This is partner economics, not partner-motion design. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you designed any part of how partners were engaged, say which and how you decided. If none of it was yours, say so plainly and stay with the model. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (your message) | low | [inferred] | discovery | A skill claim with no analysis named, so do not describe an analysis you have not named. Answer slot: name one analysis you ran yourself in SQL or Tableau: the question, the grain and one validation step. If none was yours to run, say so and describe how you used the tools. |
| F4 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | none given | none | [grounded] | discovery | Your material does not show work on any of the four motions. Answer slot: if you have worked on one of them, say which and what you saw. If you have not, say so and describe how you would find the whitespace first. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | presentation | The sentence already reaches the requirement in other terms. Reword only it: "I set annual volume targets with cross-org consensus." Add no practice to it. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (your message) | low | [inferred] | transferability | Daily use is adjacent to AI product experience. Words: "I use AI tools daily in my work." Answer slot: if you have built or shipped anything with AI, say what. If not, say so. |
| F7 | Sales-strategy and quota fluency (role-family, not in your highlights) | "No classic sales-ops or quota-setting experience" (your message) | medium | [grounded] | capability | A stated absence. Words: "I haven't done classic sales-ops or quota-setting work." Then say what F5 carries, at its own scope. |
| F8 | Headline metric the interviewer will probe (not a JD line) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | medium | [grounded] | discovery | The figure is attributed to a change you proposed. Your share of the outcome is not shown. Words: "I proposed a store-surface change, and it is credited with a ~$400M ARR uplift." Answer slots: the defend-the-number slots in A1 and E1. |

**Gate check.** Your highlights name no location, travel, schedule or work-authorization term. The pack treats none as a gate until you confirm (see the closing question). Your material is silent on pay and notice, so no logistics slot applies here.

**Background context.** "skilled in SQL/Tableau" and "uses AI tools daily" are your words, but neither names an artifact.

---

## 4. Prohibited claims

What this pack will not coach, and why. Each entry names its basis and its honest form. No answer, hold, bridge or rationale in this pack asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Quota-setting or sales-ops experience | Inflated form of F5, and it contradicts the negative in F7 | F7's plain acknowledgment: "I haven't done classic sales-ops or quota-setting work." Then F5's quote at its own scope. The pack's observation, in analysis only: your material says volume targets, not quotas. |
| Designed partner motions or partner programs | Inflated form of F2 | F2's quote at its own scope. The pack's observation, in analysis only: your material says a revenue model, not a partner motion. |
| Owned the $400M, or "the uplift was mine" | Inflated form of F8 | F8's quote at its own scope. Your share is an answer slot (A1, E1), never a stated figure. |
| Pricing decisions or pricing ownership | Inflated form of F2, which says a revenue model | F2's quote at its own scope. The pack's observation: your material says a revenue model used in negotiations, not a price you set. |
| AI product experience, or having built with AI | Inflated form of F6 | "I use AI tools daily in my work," at that scope. Anything beyond it is an answer slot (D2). |
| Ran independent SQL or Tableau analyses | Inflated form of F3 | "skilled in SQL/Tableau," at that scope. The analysis itself is an answer slot (A5). |

Silence is not on this list. Land, adopt, expand and renew work, and any pricing experience, are not in your material. They are answer slots (B4, D3), not listed claims.

---

## 5. Reading the interviewer

**Career pattern (from the profile as you relayed it).** A pricing and monetization spine, with one early-stage startup chapter. Sales strategy is the current remit.

**Self-described style.** "relentlessly data-driven".

**Practical implications:**
- Every metric will be probed to its assumptions. Prepare the defend-the-number slots first: A1, A2, E1.
- Cases will lean toward pricing, packaging and unit economics. C1 is the one to rehearse.
- The startup chapter means builder stories land well with him, and he will probe for scrappiness. Your material has no startup-style story, so do not invent one. If you have a build-it-yourself story outside this pack, bring that one.
- As a peer, he will probe the seam between his team and yours: who sets price, who owns the target, how disagreement is settled (B1, B4).

**Mirror opportunity (shared professional path).** His pricing and monetization career pairs with F2's sentence: "built a partner-level revenue model used in carrier negotiations." This is a shared professional path (monetization modeling), so it is fair to lead with. It is not a shared identity, so do not use it as affinity.

---

## 6. Persona weights and counts

Weights come from the relationship prior for a peer round, adjusted by the profile. Dan's self-described data orientation moves Prober up. His pricing spine tilts Case toward pricing. There is no values-style round signal.

| Persona | Questions | Likelihood | How it shows up | Why this weight | Counter-strategy |
|---|---|---|---|---|---|
| Data-Driven Prober | 5 (A1 to A5) | high | Asks for the denominator, the grain and the assumption behind a number | Peer prior plus "relentlessly data-driven"; the ARR figure and SQL requirement are the likely openers | Know what you can and cannot say about how each number was counted; name the weakest assumption first |
| Peer Evaluator | 4 (B1 to B4) | high | Seam-splitting, "what would you need from me", credit and disagreement | Peer prior; he reports to the same VP, so his concern is load on his team | Reciprocity framing; propose seam principles instead of claiming to know the seam |
| Case / Strategist | 3 (C1 to C3) | medium | Live pricing or renewal problem; the competitive threat in your note | Pricing spine tilts cases toward pricing and packaging | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise |
| Skeptic | 3 (D1 to D3) | medium | Quiet probing of the sales-ops gap and the two JD gaps | F7 plus F2 and F4 leave the largest gaps in the material | Rehearse the most predictable objection until it is calm; concede precisely |
| Pressure | 2 (E1 to E2) | low to medium | Time-boxed challenge on the ARR figure | Nothing in the profile signals a stress style; the ARR attribution is the likely pressure point | Pause, restate, hold the position, concede the share without folding on the proposal |
| Conversational | 2 (F1 to F2) | low to medium | Casual opener; a plus-skill asked lightly | Peer rounds often open casually, and casual questions are still scored | Pre-scripted 90-second arc; treat the AI question as scored |
| Values / Behavioral | 2 (G1 to G2) | low | Scenario probes | No values-style round detected and no published values supplied, so these are scaffolds | Selection scaffold ending in the honest branch |

Total: 21 questions, within the 18 to 26 band.

---

## 7. Question banks

Provenance is the label, then every sentence the guidance rests on. An answer slot is an instruction for the interview, not a question to you.

### A. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | Defend the number in your own words: what the figure counts, what it is most sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you know how it was counted, say how. If you do not, say so plainly and say what you would need to find out. Name your part as the sentence allows: you proposed the change, and it is credited with the uplift. | F8 is the headline metric and the likeliest prober opener. Dan's self-described style makes it near-certain. Type EXP because it tests attribution. |
| A2 | "What does the partner revenue model assume that you would defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" — your message | Weakest-assumption move: name, before he does, the assumption you would defend least. Answer slot: were you in the carrier negotiations? If yes, say what you did there. If the model went to others to use, say so. | F2 is the strongest pricing-adjacent evidence, and his monetization background makes him read it closely. Type EXP because it asks what the model assumed. |
| A3 | "Partner-motion design is required for this role. Which parts of a partner motion have you designed yourself?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" — your message; "partner-motion design experience required" — JD highlights | Answer slot: if you designed any part of how partners were engaged, name it and how you decided. If none of it was yours, say so plainly and stay with the revenue model you built. | F2 against a stated requirement. This is the most likely place for design and modeling to be confused. Type JD because it scores the requirement. |
| A4 | "That store-surface change was a consumer product. What carries over to B2B data infrastructure?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — your message; "B2B data-infrastructure SaaS" — your message | Transferability with its limits. Name the mechanism you can describe, in your own words, and say what does not carry over. Do not claim B2B experience. | F8 against a B2B role is a transferability probe. Type EXP for the story, with JD in the rationale, because the answer is scored against the role. |
| A5 | "Show me one analysis you ran yourself in SQL or Tableau: the grain, and how you validated it." | JD | [inferred] "skilled in SQL/Tableau" — your message | Answer slot: if you ran one, name the question, the grain and one validation step. If none was yours, say so and describe how you used the tools. Derivation: low-confidence skill claim with no named analysis, so this is a clarify-strategy note only. | F3 is low confidence, and the JD's "independent analysis" line makes a grain-and-validation probe likely. Type JD for the requirement, with EXP in the rationale. |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where's the seam between your GTM work and my pricing and sales-strategy work, and what happens when we disagree about a price?" | JD | [grounded] "strong cross-functional influence" — JD highlights; "set annual volume targets with cross-org consensus" — your message | Propose seam principles, not a seam you have not seen: who sets price, who owns the volume target, how a disagreement is escalated. Answer slot: if you disagreed with a peer on a number that reached a decision, say how it resolved. If none did, say so and describe how you would run one. Use F5 as your evidence. | The peer's seam probe. F5 is the nearest consensus evidence, and it is the candidate's own sentence. Type JD for the requirement. |
| B2 | "How do you handle credit when a number spans two teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | Name who did what, including people who were not in the room. Answer slot: if the credit was shared, name what each person did, in your own words. Do not claim the whole figure. | Peers probe credit. F8 is the case; the stem comes from the Peer Evaluator persona. Type VAL because the question is behavioral. |
| B3 | "If your team took GTM for one of these two new lines, what would you need from my team, and what would you give back?" | JD | [grounded] "own GTM strategy for two new product lines" — JD highlights | Reciprocity first: name one thing you would give his team before you ask for anything. No claim about your past is needed. | Reciprocity framing; a peer weighs whether the hire adds load or reduces it. Type JD for the role. |
| B4 | "Land, adopt, expand, renew: where would you look first for whitespace, and who on my side would you need?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" — JD highlights | Answer slot: if you have worked on one of the four motions, name it and what you saw. If you have not, say so and describe how you would find the whitespace first. | F4 has no quote, so the honest answer is a plan. Type JD because it scores the whitespace requirement. |

### C. Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor is bundling a similar capability into its suite. How would you decide whether to match, bundle or stay separate for one of the new lines?" | CASE | [grounded] "main competitive threat is bundling by a much larger platform vendor" — your research note | Clarify the objective and the customers first. Structure as pricing and packaging questions. Challenge one premise: that bundling is the threat rather than a feature gap. Name the metrics you would watch, then the risks. No claim about your past is needed. | His pricing spine makes this the case he is likeliest to pick. The threat is from your note. Type CASE, with CO in the rationale. |
| C2 | "Renewal rate on one new line fell 15% last quarter. Diagnose it." | CASE | [generic] | Clarify the renewal definition and the cohort. Split the drop into price, adoption and partner-channel effects. Say what data you would pull first, and name one hypothesis early. | A diagnose case from the renew motion, asked in the register of a data-driven peer. Generic, because it is a pattern for the problem and states no fact about Northwind. Type CASE. |
| C3 | "Northwind is pushing enterprise expansion, an AI copilot launch ('Compass') and profitability. Which one should this line's GTM bend toward, and what would you give up?" | CO | [grounded] "enterprise expansion", "an AI copilot launch ('Compass')", "reaching profitability" — your research note | Take a position with a named concession. Do not recite the three priorities. Differentiate from the obvious answer. | CO from your research note. Type CO because it tests altitude on the company's own priorities. |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't done sales-ops or quota work. Why would a sales-strategy peer trust your GTM plan on quotas?" | EXP | [grounded] "No classic sales-ops or quota-setting experience" — your message; "set annual volume targets with cross-org consensus" — your message | Hold, then concede. Hold through two follow-ups. Opening: "I haven't done classic sales-ops or quota-setting work. What I've done is set annual volume targets with cross-org consensus." First follow-up: return to the target, at its own scope. Second follow-up, the real test: concede specifically. You do not yet know the quota mechanics, and say what you would need from his team to learn them. Never claim quota or sales-ops work. | Highest-ROI prep in this pack. It is the most predictable objection for a sales-strategy peer, and it is where your material is thinnest. Type EXP because it asks about your past. |
| D2 | "AI experience is a plus here. What have you built with AI, not just used?" | JD | [grounded] "uses AI tools daily" — your message; "AI experience a plus" — JD highlights | Answer slot: if you have built something with AI, name it and your part. If you have only used AI tools in your own work, say so: "I use AI tools daily" is true and specific. | F6 is low confidence, and plus items get scored even when they are asked casually. Type JD for the requirement. |
| D3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" — JD highlights; "identify whitespace across land/adopt/expand/renew" — JD highlights | Be candid about the thinnest area, which is partner-motion design or whitespace identification. Then give a first-30-day plan, stated as a plan and never as a past. | F2 and F4 are the two thinnest rows in the material. The honest answer is a plan. Type JD for the requirements. |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | Hold, then concede. Hold through two follow-ups: "I proposed a store-surface change, and it is credited with a ~$400M ARR uplift." Concede the share specifically: "I can't give you the share that was mine. I can tell you what I proposed." Do not fold on the proposal. | The attribution probe in its pressure form. The held position is the quoted sentence, nothing stronger. Type EXP. |
| E2 | "Sixty seconds: why you over someone who has run sales strategy for a B2B company?" | JD | [generic] pressure pattern; "built a partner-level revenue model used in carrier negotiations" — your message; "set annual volume targets with cross-org consensus" — your message | Pause and restate the question. Then sixty seconds anchored in the two quotes: the partner revenue model, and the volume targets you set with cross-org consensus. Name the one thing you would need to learn first. Do not claim a sales-strategy role. | A Pressure stem adapted to the JD. It presupposes nothing about your past, and the answer must not supply a sales-strategy role you do not have. Type JD for the role. |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | A ninety-second arc, using only the facts in your sentence: the consulting years, then the nine years in product strategy and ops, then why Northwind. Do not name the firm. | A casual opener that is still scored. Pre-scripting it protects against freezing. Type EXP because it is about your past. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" — your message; "AI experience a plus" — JD highlights | Name two tools you use and what each does in your work. Keep to daily use. | The plus item asked casually. Type JD for the requirement. |

### G. Values / Behavioral (2)

No published values were supplied, so these are scaffolds, not mapped stories.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you pushed back on a number a senior leader wanted." | VAL | [generic] scaffold; "set annual volume targets with cross-org consensus" — your message | Selection scaffold: pick a time you disagreed with a number someone senior wanted. It needs a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the volume targets you set with cross-org consensus. | Low-weight values probe. There is no published value to map a story to, so the honest branch is the scaffold. Type VAL. |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] scaffold | Selection scaffold: pick a time a customer outcome cost you an internal number. Say what you gave up and what you would do again. If no such time comes to mind, say so plainly, then give how you would handle it. | Your material holds no customer story, so the honest branch carries the answer. Type VAL. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | C1, B3 |
| identify whitespace across land/adopt/expand/renew | B4, D3 |
| run independent analysis in SQL and Tableau | A5 |
| partner-motion design experience required | A3, D3 |
| strong cross-functional influence | B1, B2 |
| AI experience a plus | D2, F2 |
| Not in your highlights (role-family): sales-ops and quota | D1 |

Only the six highlights are covered. A full JD could add requirements this table does not yet reach.

---

## 8. Reverse questions

Each one has a "why it lands." R1 ties to Dan's own path. R2 is the reciprocity question for a peer.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career has centred on pricing and monetization, with one early-stage startup chapter. What did that chapter change about how you think about price?" | It ties to his path from the profile, and it turns an interrogation into a peer conversation. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer. It signals you are thinking about his load. |
| R3 | "Where do your team's pricing decisions and this line's GTM plan most often collide?" | It names the seam directly and invites him to describe it. |
| R4 | "When a price and a volume target disagree, who decides, and how does that get settled?" | It shows you know the decision rights matter, which is the question a peer cares about most. |
| R5 | "Which number in your team's data do you trust least, and why?" | A data-driven question that matches his self-description, and it invites the assumption talk he will enjoy. |
| R6 | "What would make you say in six months that this hire was right for your side of the seam?" | It asks for the success criteria from his side, which tells you what to prove. |

---

## 9. Sources

**Provided documents:**
- Your message: background summary, JD highlights, and the stated negative about sales-ops and quota work.
- Your research note: three priorities and the competitive threat.
- Dan Kovac's profile, as you relayed it.

**Searches and fetches sent:** none. You said you have everything needed, so the pack runs at L0 and uses provided documents only.

**Research tier: L0. Searches 0 of 0, fetches 0 of 0.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | The values cheat sheet, which is absent for that reason. G1 and G2 stay scaffolds. |
| 2. Northwind interview process, peer loop | unavailable | Loop structure and the persona weights. The weights here follow the peer prior and the profile alone. |
| 3. Northwind strategy and recent news | skipped | Your research note already supplies the three priorities and the threat. |
| 4. Dan Kovac and Northwind | unavailable | The public-footprint part of the interviewer read. The profile you relayed stands in for it. |
| 5. Representative Senior GTM Strategy Lead JD | skipped | Your JD highlights fix the requirement rows and the question tags. |

---

## 10. Upgrade menu

- Full JD text → the requirements beyond the six highlights get quoted rows. Location, travel and work-authorization terms become checkable gate rows, and the requirements now marked as role-family pattern become quoted.
- Your CV text → the evidence rows quote your own sentences instead of the summary. F3 and F6 can rise if you have an artifact to name, such as a query, a dashboard or a shipped tool.
- Dan's public talks or writing → the persona weights and reverse questions read his own recurring themes. His profile alone gives the pattern but not his voice.
- Northwind's published values → a values cheat sheet, with each value mapped to a sentence of yours where one exists. G1 and G2 become mapped stories.
- Research at L1 → the company's hiring process and values are checked. The two unavailable rows in section 9 would move to yes.
- Other rounds on the calendar → loop mode, with a shared fit snapshot and per-round mini-packs.
- A `tuesday-dossier.md` → would carry the gaps this prep exposes into later sessions.
