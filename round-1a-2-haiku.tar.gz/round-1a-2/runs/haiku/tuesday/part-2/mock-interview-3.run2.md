Your Stripe prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-3-denied-3186c7dc/a4ce0517-d821-424c-a5ce-d61574b8c716/scratchpad/Stripe_product-operations-manager_interview_pack.md`.

I built it without a job description, a CV, or any research. The host refused every web search, so I couldn't check Stripe's values, interview process or recent strategy. The pack doesn't claim any of them. Every requirement and question is a generic Product Operations pattern, labeled `[generic]`. Its 18 questions are spread across six interviewer styles, with flat weights because I don't know who you're meeting. Nothing in it describes your experience yet, so the answer slots are for you to fill in your own words.

The fastest upgrade is to paste the job description and your CV. That turns the generic rows into quoted requirements and gives the answers real material. Once search is allowed again, I can also pull Stripe's published values and strategy.

I can also run a live drill with one of these interviewer styles, or save a `tuesday-dossier.md` to carry this prep's gaps into later sessions.

Two questions:
1. Who are you meeting in the final round, and what is their role relative to yours: manager, peer, or someone cross-functional? Is it one session or several?
2. Can you paste the job description and your CV?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Stripe_product-operations-manager_interview_pack.md -----
# Stripe · Product Operations Manager · Final-round prep pack

Interviewer: not named. Relationship to the interviewer: not given, so persona weights are flat and the pack says so. Round: final round, length and number of sessions not given.

What this pack is built on: no job description, no CV, no interviewer details, and no research (every search was refused by the host, see Sources). Every requirement and question is therefore a role-family pattern, labeled `[generic]`. Nothing here asserts Stripe's values, process, or current strategy.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: rehearse the shape, then say it in your own words.

- **VAL**: behavioral and values alignment, whether past behavior shows the company's published values.
- **EXP**: work-experience deep-dive, whether your claims survive scrutiny.
- **JD**: role-driven, whether you can do the listed job, including its gaps.
- **CO**: company and strategy knowledge, homework depth.
- **CASE**: hypothetical or live problem, scored on structure and reasoning.

## Fit snapshot

Worksheet variant: no requirements were supplied and no evidence was given, so every row is a role-family requirement. Each row's bridge is a selection scaffold or an answer slot, because nothing in the conversation raises a specific requirement.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designing and running operating processes for a product area (role-family pattern) | none given | none | [generic] | discovery | Answer slot: describe a process you designed or ran from start to finish. If you did not design it, say so and describe what you did run. |
| F2 | Coordinating product, engineering, finance and go-to-market teams (role-family pattern) | none given | none | [generic] | discovery | Selection scaffold: pick a time two or more functions had to agree on one decision. Say what you did to get them there. If none comes to mind, say so and give the nearest one. |
| F3 | Building metrics and business reviews that drive decisions (role-family pattern) | none given | none | [generic] | discovery | Answer slot: name a metric you have used to make a decision, and how it was counted. If you have not used one, say so and describe how you would choose one. |
| F4 | Coordinating launches and rollouts (role-family pattern) | none given | none | [generic] | discovery | Answer slot: describe a launch or rollout you were part of, and your part in it. If you were not part of one, say so and describe how you would plan one. |
| F5 | Prioritising under competing requests and constraints (role-family pattern) | none given | none | [generic] | discovery | Selection scaffold: pick a time you had more requests than capacity. Say how you chose and who decided. If none comes to mind, say so and give the nearest one. |

Gate check: no gate row can be identified. A gate is a term such as work authorisation, location or schedule, and those come from the posting. Check the posting for them before the interview.

## Prohibited claims

Nothing to list yet. No sentence about your past appears in the conversation, so no claim has been stretched. Standing rule: rehearse only what you actually did, in your own words.

## Persona table

Weights are flat because the round and the interviewer are unknown. Round type is the one fact that would reweight this, and the upgrade menu asks for it.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live operating problem from the role | High: final rounds often include one live problem (generic pattern) | Clarify, then state the objective, then structure, then the metric you'd watch, then the risk |
| Data-Driven Prober | Asks how a figure was counted and what it assumes | High: operations roles are judged on measurement (generic) | Name the weakest assumption before they do; say plainly what you don't know |
| Pressure / Stress | Interrupts, time-boxes, challenges your motive | Medium: common late in a loop, rarely the whole loop (generic) | Pause, restate the question, hold a position through two follow-ups, then concede a specific point |
| Skeptic | Probes the gap in your background against the role | Medium: depends on the posting, unknown here (generic) | Give a concrete ramp plan, not a bluff |
| Values / Behavioral | Scenario prompts about how you worked with people | Medium: not detected as a named round (no loop source) | Use a specific story with a named stake and an honest outcome |
| Conversational | Friendly, unstructured openers | Medium: casual questions are still scored (generic) | Have a 90-second arc ready; treat "any questions" as scored |
| Peer Evaluator | Seams between teams, credit, disagreement | Low to medium: a peer-round prior only (generic) | Offer seam principles, not claimed answers; show spine with tact |

## Question banks

Every question is tagged with its type. Provenance is `[generic]` throughout because no candidate sentence exists yet. Guidance is scaffolding, not a script, and no guidance here claims anything about your past.

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Four product teams each say their request is the most urgent. How do you choose?" | CASE | [generic] | Clarify who decides and by when. State criteria before ranking. Name the trade-off you would put in front of the decision owner, and what you would stop doing. | Live prioritisation problem; tests F5. No claim about your past. |
| A2 | "A launch you are accountable for is behind on a readiness item two weeks out. Walk me through it." | CASE | [generic] | Clarify what "behind" means and who owns each dependency. Set go or no-go criteria. Say who you tell, and when. | Tests F4 as a live problem, not a record. |
| A3 | "A key product metric fell 15% week over week. How do you find out why?" | CASE | [generic] | Check instrumentation first. Segment by the obvious cuts. Name two or three hypotheses and the fastest check for each. | Metric diagnosis; tests F3 and F5. |
| A4 | "There is no regular metrics review for a product area. How would you set one up?" | CASE | [generic] | Purpose, cadence, inputs, who decides what, and what gets dropped. Keep it to 90 seconds. | Tests F1 and F3 together. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which metrics belong on a business review dashboard, and why those?" | JD | [generic] | Name the decision each metric informs. Say how you would fix its definition. Answer slot: if you have built such a dashboard, say how its figures were counted and which you would defend least. If you have not, say so and describe how you would set definitions. | Tests F3. The slot keeps the honest branch open. |
| B2 | "Name a metric you would propose, and the assumption behind it you would defend least." | EXP | [generic] | Name the metric, then the assumption, in plain words. Do not pick an assumption you cannot explain. | Hypothetical version of the defend-the-number habit. |
| B3 | "How would you know a process change actually worked?" | JD | [generic] | Set the baseline first. Name the comparison, the time window, and what would count as failure. | Tests F1 on measurement. |

### Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two minutes: why hire a product operations manager and not an internal candidate?" | JD | [generic] | Pause, then restate the question. Answer from what the role needs, not from your history. Concede where an internal candidate would be stronger. | Pressure on motive and fit. |
| C2 | "Where has this approach failed for you?" | EXP | [generic] | Name a failure only if you have one, in your own words. If not, say so and name the condition under which the approach would fail. | Open prompt with an honest branch. |
| C3 | "Which part of what you have just said would you concede is weakest?" | EXP | [generic] | Hold the core claim through two follow-ups. Concede one specific limit, named exactly. Never fold on the core to restore harmony. | Hold-then-concede structure. |

### Skeptic (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the area honestly. Give a ramp plan: what you would learn first, from whom, and by when. | Tests the gap rows, F1 to F5. |
| D2 | "What draws you to this role over others in the same space?" | EXP | [generic] | Answer in your own reasons. Keep to what the published role and company information says. | Motivation consistency. |

### Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unwelcome truth to someone senior." | VAL | [generic] | Pick a time with a named stake, a moment you did not fold, and a relationship that survived. If none comes to mind, say so, then give the nearest one. | Open prompt; the candidate chooses the instance. |
| E2 | "When did you put a customer's problem ahead of an internal metric?" | VAL | [generic] | Same scaffold: a specific decision, what you traded, and what happened. Say so plainly if the honest answer is that nothing like it happened. | Open prompt on customer-first judgement. |

### Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey to here." | JD | [generic] | A 90-second arc in your own words, moving from role to role. Name what you actually did in each. | Casual opener, still scored. |
| F2 | "What are you curious about in payments right now?" | CO | [generic] | Name a question you genuinely want answered. Check public material before you say anything factual. | Scored casually; shows curiosity without recitation. |

### Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not claimed answers. For disagreement, pick a time you held a view and still worked well with the other side. | Peer-round prior; tests partnership. |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say how you name contributors, and one time you did it. If none comes to mind, say so. | Peer-round prior on credit-sharing. |

### Requirement coverage

No job description was supplied, so coverage is against the role-family rows only. The coverage is partial by design and the rows are `[generic]`:

- F1: A4, B1, B3, D1
- F2: A2, G1
- F3: A3, A4, B1
- F4: A2
- F5: A1, A3, D1, E1

## Reverse questions

Each one has a reason it lands.

1. "What does a strong first 90 days look like in this role?" Why it lands: shows you are planning the job, not only interviewing for it.
2. "Which decision this team makes most often is the slowest today?" Why it lands: shows operator thinking, and gives you the seam to work on.
3. "How do product operations, finance and go-to-market split the planning cycle?" Why it lands: shows you understand the seams this role sits in.
4. "What would make you say six months from now that this hire was a clear success?" Why it lands: turns the interview toward the outcome they actually want.
5. "Which metric does leadership check first, and how often?" Why it lands: shows you think in measures, and tests how the review cadence works.
6. If the round is peer-level: "What could a new person do in their first month that would genuinely help your team?" Why it lands: reciprocity, which keeps a peer conversation a peer conversation.

## Prep triage

Skipped: prep time was not given. Default is the full pack.

## Sources

Provided documents: none. The conversation holds only the request, the company, and the role.

Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read none

Searches sent, all refused by the host:

- "Stripe company values principles official page": refused
- "Stripe interview process product operations manager final round": refused
- "Stripe strategy recent news 2026": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet, section 10. Not written: the values are not in hand, so none are asserted. |
| 2. Stripe interview process, product operations | unavailable | Loop structure and persona weights. Flat weights used instead. |
| 3. Stripe strategy and recent news | unavailable | CO questions grounded in current strategy. Written generic instead, with no CO question about Stripe's current moves. |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative Product Operations Manager JD | unavailable | Would have grounded F1 to F5 as `[inferred]`. Not sent, because the host would not search. |

Section 10 (values cheat sheet) is not included: no values round was detected, and no published values are in hand.

## Upgrade menu

- A job description → fit rows F1 to F5 become `[grounded]`, the requirement-coverage line becomes real, and the gate check runs against the posting.
- Your CV → the answer slots become story-mapped answers in your own words, and the discovery rows get evidence.
- Who you are meeting and their role → persona weights and an interviewer read, plus a reverse question tied to their path.
- The round schedule, if the final is several sessions → one mini-pack per session, with its own weights.
- Stripe's published values and recent strategy, once searching is allowed → a values cheat sheet, and CO questions grounded in current strategy.
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several minutes, if searching is allowed → interviewer and loop detail at the deep tier.
- A `tuesday-dossier.md` → carries this prep's gaps into later sessions.
