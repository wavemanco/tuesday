Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-7-canned-2b531619/a9ee14bc-1893-4b01-b118-c99a50ebb975/scratchpad/saltmarsh_live-operations-producer_interview_pack.md. I ran light research on Saltmarsh, which found the careers page describing the interview as one 60-minute "Outage Hour" with the hiring manager: a live-incident tabletop, then a values conversation. I've treated Tobias as that hiring manager.

The pack's main points:

- **Rehearse first:** A1 (live-incident opener) and A3 (the Larkspur calendar question) out loud. Then B2, the question most likely to come up in some form: "The role owns the post-event review and the KPIs it reports. What have you owned in that area?" Your honest answer is that you presented the retention numbers to the studio head. Practise holding that line through two follow-ups.
- **Gaps to name, not hide:** the post-event review, coordinating design, art, engineering and community, and in-app purchases. Your own "Never led a team" and "never worked on a game with in-app purchases" get plain acknowledgments in the pack, not spin.
- **Values:** Saltmarsh publishes three: Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener. Only the last maps to a sentence in your material: you wrote the release checklist QA still uses. The other two have no story in what you've given me, so the pack gives you a selection prompt and an honest "if none comes to mind, say so" branch.
- **Interviewer:** Tobias's GDC 2026 talk, "Patch Notes Are a Promise", argues a live team is judged by whether its patch notes match what shipped. He was previously a QA lead. Expect the shipped-versus-announced theme, and use the QA checklist as shared ground without overplaying it.

Two caveats: the Larkspur news (two titles moving to a season pass and one shared calendar from February) came from a search snippet, not a full page read. And I did not verify the GDC talk beyond its listing.

Would you like me to play the Skeptic on B2 as a drill? I can also save a tuesday-dossier.md recording the gaps this prep exposed, and I can convert the pack to a Word document if you want one.

Is Tobias running the whole 60 minutes, or is this a panel? The answer changes how the questions are weighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship read as hiring manager, from Saltmarsh's careers page, which says the Outage Hour is the hiring manager's 60-minute interview. Candidate: Femi (they/them).

## How to use + type key

Personas = how the question is asked. Types = what is being scored.

- **JD**: the job's own requirements
- **EXP**: what you actually did, tested by follow-up
- **VAL**: whether past behaviour shows Saltmarsh's published values
- **CO**: company and strategy knowledge
- **CASE**: a live problem from the role, solved aloud

Guidance is scaffolding, not a script. Say it in your own words.

## Prep triage

Friday is tomorrow, so the schedule is short.

1. Say A1 and A3 aloud until the structure comes without notes. The Outage Hour is a live-incident tabletop, so this is most of the hour.
2. Rehearse B2 with two follow-ups. It is the highest-ROI prep in this pack.
3. Learn the VAL story in C3 and the three values by name.
4. Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your message. Nothing is added to either.

Requirement sources: the JD supplied by you. The JD names no gate such as location, pay or authorisation.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Your material gives four years at a puzzle-game studio. It does not say the game was live-service. Say the years as you ran them, and let the live-service question be answered in your words. Answer slot: if the title ran content or events after launch, say what they were; if it was not live-service in the JD's sense, say so plainly. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | This meets the requirement. Lead with the calendar in your own terms: weekly content drops, one title, two years. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | low | [grounded] | discovery | Your material shows monthly retention numbers presented. It does not show a post-event review, or who chose what the numbers reported. Answer slot: if you chose what a review reported, say which and how; if you did not, say so plainly, then say how you would run one. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | none | This meets the requirement in its own terms. Keep the verb: presented. Say what the numbers were and who read them. Do not say how they were calculated unless you know. |
| F5 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [grounded] | discovery | The material shows a checklist used by QA. It does not show coordination with design, art, engineering or community. Answer slot: name one update you moved through another team, who was on it, and what you did when their plan and yours differed. If no update did, say so and say how you would set that coordination up. |
| F6 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | This meets the requirement in role terms. Say "wrote" and "still in use". Do not say you managed the checklist's owners unless you did. |
| F7 | "clear written communication" (JD) | none given | none | [grounded] | discovery | No writing sample is in the material. Your message itself is not a sample of the work. Answer slot: describe one thing you wrote for a team, such as a checklist, a retention note or a review, and how it was used. |

Gaps the pack names but cannot quote (analysis, not words for you): Saltmarsh's published news describes a season-pass model. Your material shows no monetised title. Expect a probe on in-app purchases. See B5.

## Reading the interviewer

Public footprint only. From a search result for a GDC 2026 talk by Tobias Wrenfield titled "Patch Notes Are a Promise". The listing says he is Head of Live Operations at Saltmarsh and was previously a QA lead at a console studio. Its argument: a live team is judged by how often its patch notes describe what actually shipped.

Implications:

1. "Ship the Patch Not the Promise" is his own theme. Expect a question on it. Answer with what you announced and what shipped, in your own words.
2. The QA background is a professional mirror. Your release checklist, used by QA, is a point of common ground. Use it as a fact about your work, not as rapport.
3. Know his argument. Do not claim to agree with every point of it.

## Persona table

Relationship prior for a hiring manager: Case/Strategist and Skeptic dominate. The careers page establishes the loop as a recruiter call, then one 60-minute Outage Hour with the hiring manager, which is a live-incident tabletop followed by a values conversation. That loop source sets the weights, so no archetype fallback applies.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist, weight 5 | Live incident on a live event, then the calendar's trade-offs | High. The careers page names a live-incident tabletop | Clarify scope, name who you call, decide what to pause, say what players hear and when |
| Skeptic, weight 4 | Gaps in the JD: post-event review, cross-team coordination, monetisation | High. F3, F5 and the in-app purchase gap are the material's thinnest rows | Hold on what you did, then concede the gap in a sentence |
| Values/Behavioral, weight 3 | The three published values, one question each | High. The values conversation is documented on the careers page | One specific decision per value, or the honest branch |
| Data-Driven Prober, weight 3 | Retention numbers probed for how they were counted | Medium. The JD asks for retention comfort; no figure is given | Say what you know about the count and what you do not |
| Conversational, weight 3 | Opening and closing rapport, then a scored question | Medium. Casual openers are scored too | Ninety-second arc; the reverse-question slot is never generic |
| Pressure, weight 0 | Not weighted | Low. No signal in the material | B2's hold-then-concede is the pressure rehearsal |

Session total: 19 questions. Depth follows weight, so Case carries the most.

## Question banks

Requirement coverage:

| JD requirement | Covered by |
|---|---|
| 3+ years live-service | B1 |
| Experience running a content calendar | A2, B3 |
| Own the post-event review and the KPIs | B2, A5, D1 |
| Plan and run the calendar for two titles | A2, A3, B3 |
| Coordinate design, art, engineering and community | B4, A2 |
| Manage the release checklist with QA | C3, A1 |
| Comfortable with player-retention metrics | D1, D2, A4 |
| Clear written communication | none, and why: there is no writing sample to rehearse from. Upgrade menu asks for one |

### A. Case/Strategist, weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It is 19:40 on a Saturday. The event on one of the two titles is live, and the reward-claim step is failing for some players. Walk me through your first ten minutes." | CASE | [generic] | Clarify scope first: how many players, which platform, when the event ends. Name who you call: engineering on call, QA, community. Decide whether to pause the event or only the claims, and say what you would tell players and when. Say the decision out loud before the reasons. | The Outage Hour is a live-incident tabletop, per the careers page. [generic] because it is a pattern for the problem, not a fact about this team. Tests the release-checklist requirement in a live setting. |
| A2 | "The role runs one calendar across two titles. How do you choose which title's update goes first in a week when both have something ready?" | JD | [inferred] "two of our mobile titles" from the JD | Name the criteria in order: player impact, dependencies with engineering and QA, what is already committed to players. Say the trade-off aloud. Players Before Plans: when the calendar and the players disagree, the players win. | The JD's "two of our mobile titles" is the raising source. [inferred] because the criteria are a derivation from the role. Covers the coordination requirement. |
| A3 | "Saltmarsh is moving two titles to a season pass and one shared calendar from February. What would you check first about that calendar in your first month?" | CO | [grounded] Saltmarsh news, search result: "moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027" | Name what you would check first: release dates across titles, what per-title data still matters, how the checklist changes. Do not claim knowledge of the calendar's current state. | The CO question the research supports. Tests current awareness of the company, which the Outage Hour's values conversation also draws on. |
| A4 | "Retention drops eight percent in the second week after a content drop. Diagnose it." | JD | [generic] | Clarify what retention means on the dashboard and the cohort it measures. Check whether the drop coincides with a release or event. Split by platform and version. Name the assumption behind the baseline you would defend least. | Covers the retention requirement as a reasoning test. [generic] because it is a pattern. |
| A5 | "The event's KPI went up, but the players who joined late churned. What do you do before you write the review?" | JD | [generic] | Decide what question the review answers. Check the KPI's definition. Separate the late joiners from everyone else. Write what you know and what you do not. | Covers the post-event review requirement at the interviewer's own altitude. |

### B. Skeptic, weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Four years at a puzzle-game studio. Is that live-service in the sense the role means?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Answer from what the title did after launch, in your words: the content drops you ran, the events, the calendar. Answer slot: if it was not live-service in the JD's sense, say so plainly and say what the closest thing was. | F1 is the gap the JD's first requirement raises. Premised only on your own quotes. |
| B2 | "The role owns the post-event review and the KPIs it reports. What have you owned in that area?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | The highest-ROI rehearsal in this pack. Hold on what you did: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose what a review reported, say which and how you decided. If you did not, say so plainly, then say what you would put in a post-event review. Hold through two follow-ups by returning to the numbers you presented. | F3 is where the JD's ownership line presses hardest, so this objection arrives in some form. Pressure-style hold-then-concede. |
| B3 | "You ran one title's calendar. Which parts of that will not transfer to two?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Name the parts you would have to learn: cross-title conflicts, a second title's dependencies, a shared checklist. Say what you would check first. | Premised on your own quote, at its scope: one title. |
| B4 | "You have never led a team. This role coordinates four teams on every update. How do you get them to agree on a date?" | JD | [grounded] "Never led a team" | Plain acknowledgment: "I haven't led a team." Then the answer slot: how you would get design, art, engineering and community to agree on a date. If you have done that without a title, say how. If not, say so and say how you would start. | F5 is the gap, and "Never led a team" is your own negative. The plain acknowledgment has its source. |
| B5 | "Have you worked on a game with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say what monetisation you did see in your own titles, if any. Do not name the season pass as your experience. | The season pass in the company news makes this likely. The pack's analysis names it; the answer stays inside your experience. |

### C. Values/Behavioral, weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed." | VAL | [generic] open prompt; selection scaffold | Pick a time when a committed date and a player-facing problem pulled in different directions. If none comes to mind, say so plainly, then give the nearest thing your material carries: the weekly content-drop calendar you ran for two years. | Values: Players Before Plans. The material shows no such incident, so the guidance offers only selection. |
| C2 | "Tell me about a release where what you announced and what shipped did not match." | VAL | [generic] open prompt; selection scaffold | Pick a release where an announcement and the shipped build differed. If none, say so plainly, then give the nearest thing your material carries, or how you would handle it. | Values: Ship the Patch Not the Promise. This is his talk's theme. |
| C3 | "Tell me about a process you changed that stayed changed." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped: you wrote the release checklist, and QA still uses it. Those are the beats the sentence states. Answer slot: if you revised it after a release, say what and why. If you only wrote it, say that, and say it is still in use. | Values: Leave the Build Greener, mapped to your own quoted sentence. |

### D. Data-Driven Prober, weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you know about how they were counted and who counted them. Name the assumption you would defend least. If you do not know how they were counted, say so. | F4. A premised question about your own quote. Defend-the-number slot. |
| D2 | "Which part of the retention number was yours?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Be exact about the verb. Presented is what you did. If you computed any part, say which part and how. | Attribution test on F4's verb. |
| D3 | "How would you tell whether a live event worked, apart from retention?" | CASE | [generic] | Name a measure that is not retention, say why it would move, and what would make you distrust it. | Covers the KPI requirement without any claim about your past. |

### E. Conversational, weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" | A ninety-second arc: the studio, the role, the calendar, the checklist. Stop before you describe what you did not do. | The biography opener. Casual, and still scored. |
| E2 | "What are you playing right now?" | JD | [generic] | Name a real title. If it is live-service, say one thing you noticed about its events. | Rapport question with a JD-adjacent score. |
| E3 | "What was the best live event you have seen in a game you did not make?" | VAL | [generic] | Name the event, what it did, and why it worked for players. Do not claim you ran anything like it. | Values-adjacent, casual register. |

## Reverse questions

Each one ties to what the public record supports. Ask at least two of them.

1. "Tobias, you were a QA lead before this role. What did that background make you check first on a live event?" Why it lands: it ties to his own path and turns the interview into a peer conversation.
2. "The calendar moves to one shared group from February. Which title's calendar does this role take on first?" Why it lands: it shows you read the company news and asks about scope.
3. "What would make a post-event review good enough that you would not have to ask me about it?" Why it lands: it asks how the team judges the review, not whether it exists.
4. "When an Outage Hour scenario ends, what is the one thing you most want to see a candidate do differently?" Why it lands: it asks for the standard directly.
5. "What does a producer's first ninety days look like on a title with a live event in it?" Why it lands: it reads as planning, and invites the interviewer to describe the real work.

## Values / principles cheat sheet

Three published values from saltmarshgames.com/values, fetched in this run.

| Value (official name) | Working meaning | Candidate's mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold, no quoted story. See C1. Honest branch: if none comes, say so and give the nearest thing your material carries. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold, no quoted story. See C2. Honest branch: if none comes, say so. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | "Wrote the release checklist our QA team still uses" (F6). See C3. |

## Prohibited claims

Not coached, with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the post-event review and its KPIs | Inflated form of F3 | "Presented the monthly retention numbers to the studio head." The pack's own observation: the material shows presenting, not owning a review. |
| Managed or owned the release checklist | Inflated form of F6 | "Wrote the release checklist our QA team still uses." |
| Ran live events across both titles | Inflated form of "for our main title" | "I ran the weekly content-drop calendar for our main title for the last two years." |
| Four years of live-service production | Inflated form of "4 years as an associate producer at a puzzle-game studio" | The quote at its own scope. |
| Led a team | Your own negative, "Never led a team" | Plain acknowledgment: "I haven't led a team." |
| Worked on a game with in-app purchases | Your own negative | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |

## Sources

Provided documents: your message (the JD text and your background).

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. saltmarshgames.com values | yes | Values cheat sheet: three values by name, fetched from the official page |
| 2. Saltmarsh interview process | yes | Loop established: recruiter call, then one 60-minute Outage Hour with the hiring manager, a live-incident tabletop then a values conversation. Persona weights and the values round follow |
| 3. Saltmarsh strategy / recent news | yes | CO question A3. The Larkspur announcement (September 2026) is a search snippet, not a fetched page |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Interviewer read: GDC 2026 talk listing, public footprint only |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot |

Queries and results:

- "Saltmarsh Games values": saltmarshgames.com/values, fetched
- "Saltmarsh Games interview process live operations producer": saltmarshgames.com/careers/interviewing, fetched
- "Saltmarsh Games strategy news": saltmarshgames.com/news/project-larkspur, snippet only
- "Tobias Wrenfield Saltmarsh Games": talks.gdconf.example/2026/patch-notes-are-a-promise, snippet only

## Upgrade menu

- The round's format: confirm that Tobias runs the whole 60 minutes, or that it is a panel → persona weights and per-round banks
- Your post-event review, retention note or any writing you did for a team → F3 and F7 move from low or none to quoted evidence
- The release checklist itself → F6 and C3 move from quoted sentence to an inspectable artifact, raising confidence
- The full Larkspur announcement → A3 and the reverse question 2 rest on a fetched page, not a snippet
- The recruiter's prep note → coverage of anything the Outage Hour scenario is said to cover
