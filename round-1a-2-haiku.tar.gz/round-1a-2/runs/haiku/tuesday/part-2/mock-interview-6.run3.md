Web search was refused in this session (permission not granted), so the company research is missing. I'll build the pack from your own material and label the company-specific parts as not established.
Your prep pack covers all three rounds and is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-6-denied-045554fe/9f5c8e1a-0c21-4bb5-bfa6-abdbd80eb6c7/scratchpad/larkfield_engineering_manager_interview_pack.md`. It's also attached to this message.

**Company research didn't run.** The web search was refused in this session, so I have no facts about Larkfield's values, interview process or strategy. The pack doesn't use any. Company-specific questions are labelled generic, and the VP round uses the recruiter's words "values and leadership philosophy" rather than published values.

**The shape of the pack**
- **Round 1, Director (hiring manager):** expect a live problem on the two-squad roadmap and the question "which part of this role would you be weakest at on day one?" The hardware-roadmap gap is the one to rehearse hardest. Say it plainly, then give a plan for closing it, not a past.
- **Round 2, panel:** the staff engineers will probably test the 60% on-call figure, and the PM and staff engineers will probe the hardware seam. Their questions are about trade-offs and how you handle disagreement with peers.
- **Round 3, VP:** values and leadership philosophy. Your strongest story is the reliability quarter against roadmap pressure. Expect a question about motivation for leaving a payments company, which your notes don't yet answer.

**Things to avoid saying.** The pack lists four claims not to make, each with the honest wording to use instead:
- Don't say you led two squads. You led a team of six for three years.
- Don't say you owned a hardware roadmap or managed managers. You've said you haven't, so say so plainly.
- Don't take sole credit for the 60% drop. Say you pushed the quarter through.

**Questions for you**
1. Did the recruiter say whether any round includes a presentation, take-home or written exercise?
2. Can you paste the full job posting? I've built requirements from your summary, and the full text would firm up the rows that are currently inferred.

If you can paste Larkfield's values page or any recent coverage of the company, I can rebuild the VP round on those. I can also run a mock drill on the hardware-roadmap question, which the pack names as the highest-value prep.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering_manager_interview_pack.md -----
# Larkfield Systems: Engineering Manager, prep for three rounds (loop mode)

**Role:** Engineering Manager, two squads building device-management services, 11 engineers.
**Company:** Larkfield Systems (industrial IoT, about 600 people).
**Rounds:** Round 1, Tuesday, 45 min, Director of Engineering (hiring manager). Round 2, the Thursday after, 60 min, panel of two staff engineers and a product manager. Round 3, the following Monday, 30 min, VP Engineering ("values and leadership philosophy"). Interviewer names not given.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores.
- Type key: **JD** = role requirement. **EXP** = your past work, deep-dived. **CASE** = live problem. **VAL** = behaviour against stated values or leadership principles. **CO** = company and strategy knowledge.
- Guidance is scaffolding, not a script. Rehearse only what you did, in your own words.

## Sources and research status

Research tier: L1 — searches 3 of 6, fetches 0 of 2. Company research was not available in this session: the search tool was refused, so no company facts were retrieved.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Searches refused. The VAL bank uses the recruiter's words "values and leadership philosophy" and the role summary, not the company's published values. No values cheat sheet is included. |
| 2. Larkfield interview process | unavailable | Searches refused. Loop structure comes from your message and the recruiter's words, which name three rounds, their interviewers and the values focus. |
| 3. Larkfield strategy / recent news | unavailable | Searches refused. No grounding brief. CO questions are labelled [generic]. |
| 4. Interviewer name + company | n/a | No names given. |
| 5. Representative role JD | skipped | Your role summary fixes the requirement list used here. A full posting would upgrade it (see upgrade menu). |

Loop established by: your message (the three rounds and their interviewers) and the recruiter's words "values and leadership philosophy" (a values-style round). The archetype fallback is not used.

Nothing in this pack is a claim about Larkfield's values, process or strategy.

## Shared fit snapshot

Requirements are quoted from your role summary, which is not a full job posting. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "lead two squads building device-management services" — role summary | "9 years engineering, 3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says a team of six, for three years. It does not say two squads. Say the six in those words. Answer slot: what you would carry over to two squads, and what you would do differently, in your own words. |
| F2 | "own delivery, hiring and growth for 11 engineers" — role summary | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | The hiring part is covered at its own scope: backend roles, about 40 interviews. Delivery ownership and growth of engineers are not shown by this quote. Answer slot: one engineer you grew, what you did, or say plainly that this is still being built. |
| F3 | "own delivery" — role summary | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | presentation | The quote already reaches delivery under roadmap pressure. Say it in those terms. The 60% is a figure you gave: the defend-the-number slots in A3 and B1 apply. |
| F4 | "partner with hardware and product on roadmap" — role summary | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | You stated this absence. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, as a plan, never as a past. |

**Gates:** your material does not mention location, on-site pattern, schedule or travel. These are gates if the posting sets them. Not assessed here (see upgrade menu).

## Prohibited claims

Built from the fit snapshot. Not to be coached in any round.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads | Inflated form of F1 | "For three years I led a team of six." Your material says the six, not the two squads. |
| Owned a hardware-adjacent roadmap | Negative you stated, F4 | "I've never owned a hardware-adjacent roadmap." No slot. |
| Managed managers | Negative you stated in your message | "I've never managed managers." No slot. |
| Sole credit for the 60% | Inflated form of F3 | "My team's on-call burden dropped 60% after I pushed a reliability quarter through." Your material does not say what others did. |

## Loop-level persona weights

Weights come from the relationship priors, adjusted by the round's interviewers. Names of the panel members are not known, so per-member weights are not assigned.

| Round | Persona | Weight | Why |
|---|---|---|---|
| 1 Director (hiring manager) | Case/Strategist | high | They are buying capability for a two-squad mandate. Expect a live problem on the roadmap. |
| 1 | Skeptic | high | Your F4 gap and the "managed managers" negative are the likely objections. |
| 1 | Data-Driven Prober | medium | Your 60% figure will be probed. |
| 2 Panel (staff engineers + PM) | Data-Driven Prober | high | Staff engineers test figures and assumptions. |
| 2 | Peer Evaluator | high | PM and staff engineers price the seam with hardware and product. |
| 2 | Pressure | low | Possible, given the reliability-vs-roadmap story. |
| 3 VP (values) | Values/Behavioral | high | Recruiter named the round as values and leadership philosophy. |
| 3 | Pressure | high | Executive round, time-boxed. The hardware gap will be raised. |
| 3 | Case/Strategist (CO) | low | Strategy questions are likely at this level, but no company research is in hand, so they stay generic. |

## Round 1: Director of Engineering (hiring manager), 45 min

Question budget: about 8. Highest-ROI prep for the loop: **A2**, the hardware-roadmap objection.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your first 90 days: two squads, a device-management service, and a hardware team on its own release cycle. What do you do first?" | CASE | [generic] | Clarify before structuring: which roadmap item is most at risk, and what the hardware cadence is. Name listening as the first two weeks. Make no claim about your past. | A live problem from the role summary. The question needs no past claim. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in this pack. Say the gap in your words: "I've never owned a hardware-adjacent roadmap." Then a plan: what you would read, who you would ask, what you would check first. Hold through two follow-ups by returning to the plan. | F4 is the strongest gap and the most likely objection. |
| A3 | "Walk me through how the on-call number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say what the 60% measures and its baseline period, if you know them. Answer slot: if you know the baseline and what was counted, say so. If not, say you don't know how it was counted and how you would find out. Name the assumption you would defend least. | F3 is a figure, and the defend-the-number rule applies. |
| A4 | "You've led a team of six. What changes at eleven, across two squads?" | JD | [grounded] "3 as a team lead of 6" | Say what you have done at six, and what you would do differently at eleven. Do not claim two-squad experience. | F1 is the scope gap; the question tests it directly. |
| A5 | "Walk me through how you run the hiring loop." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Story-mapped on the quote: the loop, your part in it, the roughly 40 interviews. Answer slot: which parts of the loop were yours to set, and which were fixed. Do not add decisions you did not make. | F2 is hiring; this is the one thing the material shows. |
| A6 | "How would you grow an engineer into a lead?" | JD | [grounded] "own delivery, hiring and growth for 11 engineers" (role summary) | No growth track record is in the material. Answer slot: name one engineer you grew, what you did, and the result. Or say plainly that this is still being built, and how you would start. | F2's growth gap; the question presupposes the role's growth mandate and nothing about your past. |
| A7 | "Where do you see the friction between a hardware team and a software team?" | CASE | [generic] | Describe seams in principle: release cadence, who owns the device interface, how disagreements get settled. Do not claim you have owned that seam. | Tests the partnership part of the role without requiring a past claim. |

**Reverse questions (at least five):**
1. "What would success look like for the two squads at six months?" Why it lands: shows you plan against outcomes.
2. "Which hardware release is most likely to test the roadmap this year?" Why it lands: shows you think about the seam.
3. "How is the hiring plan for the 11 engineers sequenced against delivery?" Why it lands: connects your hiring record to the role.
4. "What did the last person in this role do that you would want more of?" Why it lands: a direct way to learn what the role is for.
5. "What would make you say, at the end of the year, that the hire was the right call?" Why it lands: surfaces the evaluation criteria.

## Round 2: panel (two staff engineers, one PM), 60 min

Question budget: about 8. Names not given, so members are not assigned personas.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Name the weakest assumption before they do. Answer slot: if you know what the 60% depends on, say so. If not, say so plainly. | Prober move on F3. |
| B2 | "Where's the seam between your squads and the hardware team, and what happens when you disagree?" | CASE | [grounded] "partner with hardware and product on roadmap" (role summary) | Propose seam principles, not a seam you have run. If you have run a disagreement with a peer team, say it in your own words. | Peer probe on the partnership requirement. |
| B3 | "A hardware team says a roadmap item isn't feasible this quarter. How do you handle it?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | State the gap plainly, then the approach: what you would verify, who you would ask, how you would decide. Do not describe a hardware disagreement you have not had. | F4 in peer form. |
| B4 | "You pushed reliability against roadmap pressure. Did you hold, or did the roadmap win anywhere?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Hold the decision you made. Concede specifically what slipped if something did. Answer slot: if anything slipped, say what and why. If nothing did, say so. Never fold on the core decision to restore harmony. | Pressure-style hold on F3. |
| B5 | "Two squads, eleven engineers, a device fleet with a firmware release in six weeks. Plan the next two quarters." | CASE | [generic] | Clarify first: which release is fixed, what reliability work is already committed. Then structure. Make no claim about past plans. | A live case from the role. |
| B6 | "What would your staff engineers push back on in your first month?" | JD | [generic] | Name likely pushback: scope, technical decisions, delivery pace. Describe how you would take it. No past claim. | Peer probe in collegial form. |
| B7 | "What would a new person do in their first month that would genuinely help your team?" | reciprocity | [generic] | Ask it, and listen. Do not answer with what you need. | Peer reciprocity question. |
| B8 | "Which of your hiring numbers would you trust least?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Name the figure and what it counts. Answer slot: if you know how the 40 was counted, say so. If not, say so. | Defend-the-number applied to F2. |

**Reverse questions (at least five):**
1. "Where does the hardware team sit in the planning cycle?" Why it lands: shows you are thinking about the seam before being asked.
2. "What would you need from a new engineering manager in the first quarter?" Why it lands: a peer-style ask.
3. "What has the panel found most useful in past hires for this role?" Why it lands: shows interest in what the role needs.
4. "How do the staff engineers and the product manager disagree when they do?" Why it lands: surfaces the working norms.
5. "What would make a new manager's first sprint go badly?" Why it lands: invites candour.

## Round 3: VP Engineering, values and leadership philosophy, 30 min

Question budget: about 7. Values-style round detected from the recruiter's words. Larkfield's published values were not retrieved, so VAL questions use the recruiter's words and the role summary as raising sources, with honest branches where your material does not carry a story.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | Story-mapped on the quote: the stake was roadmap pressure, the decision was the reliability quarter, the measured result is the 60%. Say who you told and what they said in your own words. Answer slot: if the response from leadership is part of the story, say what it was. | The quote carries the stake and the decision; the rest is yours to supply. |
| C2 | "What's your leadership philosophy, in one example?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Selection scaffold: pick one decision where a principle shaped the outcome. If the hiring loop is the example, say what principle you applied and the result, without adding decisions. | Open prompt; the recruiter's words raise the theme. |
| C3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | No quote carries a customer story. Pick a time when a user or customer-facing outcome conflicted with a team metric. If none comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter, read for its customer side. | Persona stem; no past claim beyond the open prompt. |
| C4 | "You've never owned a hardware roadmap. Why you over someone who has?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then what you would bring instead, using only quotes you have. Do not claim equivalence to hardware ownership. | Pressure question on F4. |
| C5 | "Where do you think device management in industrial IoT is heading?" | CO | [generic] | Generic answer, labelled as such: say what you would want to learn first and how you would check it. Do not claim knowledge of Larkfield's strategy. | No company research was available. |
| C6 | "How do you choose between engineer growth and delivery when they conflict?" | VAL | [generic] | Selection scaffold: name a principle you would apply and what you would give up. If you have decided this before, say how, in your own words. | Leadership-philosophy probe in general form. |
| C7 | "Sixty seconds: why this role over your current payments company role?" | VAL | [grounded] "currently at a payments company" | Motivation is not in your material. Answer slot: name what the role offers that your current role does not, in your own words. | Motivation probe, slot only. |

**Reverse questions (at least five):**
1. "What principle does the leadership team argue about most?" Why it lands: shows interest in how decisions are made.
2. "How do you see the balance between reliability work and feature work on these squads?" Why it lands: ties to your reliability story.
3. "What would the VP want a new engineering manager to have done in 90 days?" Why it lands: asks for the bar directly.
4. "What does your leadership philosophy look like when a team misses a commitment?" Why it lands: an invitation to show judgment on the VP's own terms.
5. "What's the one thing about this role that is easy to get wrong?" Why it lands: asks for what the VP has learned.

## Requirement coverage

| Requirement (role summary) | Questions |
|---|---|
| lead two squads building device-management services | A4, B5 |
| own delivery | A3, B4, C1 |
| hiring | A5, B8, C2 |
| growth for 11 engineers | A6 |
| partner with hardware and product on roadmap | A2, A7, B2, B3, C4 |
| Not covered: none |  |

## Upgrade menu

- Full job posting text → requirements become [grounded] rather than from your summary, and any row without a source is cut.
- Recruiter's note on any deliverable (presentation, take-home) for any round → build section for each.
- Panel and VP names → per-member persona weights and an interviewer read.
- Larkfield's values page, pasted → values cheat sheet for Round 3 and VAL questions mapped to published values.
- Larkfield's strategy or recent news, pasted → CO questions grounded in current strategy in place of [generic].
- Location, on-site pattern and schedule from the posting → gate rows in the fit snapshot.
- Whether "two squads" means managers reporting to you → sharpens A4 and B5.
