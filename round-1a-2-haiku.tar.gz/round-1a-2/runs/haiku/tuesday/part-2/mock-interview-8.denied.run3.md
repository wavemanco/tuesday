Your prep pack is saved as /var/tmp/tuesday-measure/1a2/runs/haiku/tuesday/part-2/rooms/case-8-denied-dc1ead76/ashgrove_member-experience-lead_interview_pack.md. I built it in loop mode, one mini-pack per round, since you have three dated rounds. I ran no web searches: the values, the round structure and the strategy brief summary you sent already cover what the pack needs.

The pack's central point is that your material supports the complaints work well but leaves three JD requirements thin. Those are scope across branches and the contact centre, senior presenting, and Excel. The pack gives you plain acknowledgments for the two things you have not done, and a plan for each.

Say the word and I'll run the Skeptic on H2, the question the pack names as the highest-ROI prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview pack

**Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
**Mode:** Loop. Three dated rounds on 28 November 2026, one mini-pack each.
**Round R:** recruiter, 30 minutes.
**Round H:** Head of Member Services (future manager), 45 minutes, mostly behavioural.
**Round P:** panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case. The panel scores against the four values.
**Interviewers:** the recruiter is named in the invite. The Head of Member Services and the two branch managers have not been named.
**Built:** 19 November 2026.

## 1. How to use this pack

Personas describe how a question arrives. Types describe what it scores:

- **VAL**: behavioural and values alignment, tested against Ashgrove's published values.
- **EXP**: work-experience deep-dive, testing whether your claims hold up.
- **JD**: role-driven, testing whether you can do the listed job, gaps included.
- **CO**: company and strategy knowledge.
- **CASE**: a live problem, testing structure and reasoning.

Guidance is scaffolding, not a script. Answer slots are instructions for the interview. Rehearse both honest branches, not only the one you hope for.

"Your message" means what you told me in this conversation. I have not seen a CV.

## 2. Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The material shows one branch's log, not the process across branches and the contact centre. Bridge: "For the branch's formal complaints log, I handled it." Answer slot: if you owned any step beyond that log, say which and how you decided; if none was yours, say so plainly, and say how you would learn the whole process. |
| F2 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | Monthly complaints reporting is there. Whether it held volumes or resolution times is not in the material. Answer slot: if it held either figure, say what it counted and how; if it held neither, say what it did hold. |
| F3 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Teller training carries over. Coaching supervisors is not in the quote. Bridge: "I trained new tellers on our escalation script." Answer slot: if you coached a supervisor on escalations, say how; if not, say so, and say how you would start. |
| F4 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if you worked with a digital or self-service team, say what that work was; if you have not, say so, and say what you would look at first. |
| F5 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't presented to anyone above regional level." Then how you would learn it, said as a plan, never as a past. |
| F6 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | Your material says spreadsheet, not Excel, and does not say what you did in it. Answer slot: say which tool you built it in and what it held, in your own words; if you have not used Excel, say so. |
| F7 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | The quote reaches the length and the sector. It does not use the words customer operations, so expect a probe on whether branch work counts. Bridge: "I've spent six years in retail banking, the last three as a branch supervisor." |
| F8 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material says formal, not regulated, and is silent on which rules or referral routes applied. Answer slot: say which external rules or referral route governed the log and your part in them; if none applied, say so, and say what governed it. |
| F9 | "the contact centre" (JD duties) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't worked in a contact centre." Then a plan for learning it, never a past. |

No row is a gate. The JD states no location, schedule, pay or credential bar. The logistics the recruiter will ask about appear as recruiter slots in Round R.

## 3. Grounding brief

Built from the strategy brief as you summarised it. I have your summary, not the brief's text, so check exact wording before you quote a number in the room.

- Current language: member service moving to digital channels; branch consolidation into hubs; small-business lending; app-only banks as the main competitive pressure.
- Headline numbers (your summary): 40% of member service to digital channels by 2028; eight branches into five hubs over 2027; a small-business lending product in Q1 2027.
- Competitive frame: app-only banks.
- Leadership context: nothing supplied.
- Stale framings flagged: none, since the brief is under six months old.

## 4. Round R: recruiter, 30 minutes

### Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational (top weight) | Friendly openers and casual JD questions, plus the recruiter's logistics checks | A recruiter screen's prior is Conversational. The logistics are knockout checks asked in the same register | Pre-script a 90-second arc. Treat casual questions about JD topics as scored |
| Skeptic (light) | Gentle probes on the contact centre and on senior presenting | The prior is a light Skeptic. Both gaps appear in the JD and in your message as stated absences | Plain acknowledgment, then the plan. Do not bluff |
| Logistics slots (not a persona) | Pay, notice, location and reason for leaving | The recruiter-screen coverage rule | Give your own answer in your own words. Your material supplies no figure for any of them |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Walk me through your background in about 90 seconds." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | Tell it in this order: six years in retail banking, the last three as a branch supervisor; then the complaints log and the teller training, in the words quoted. Add nothing. Stop at 90 seconds. | An opener that is scored under casual register. It draws on F7, F1 and F3, in the order the recruiter will test them. |
| R2 | "What do you know about Ashgrove?" | CO | [grounded] "move 40% of member service to digital channels by 2028"; "consolidate eight branches into five hubs over 2027" (your summary of the brief) | Name the two brief points as the recruiter's own framing: member service moving to digital, and branches consolidating into five hubs. Say in one sentence each what it could mean for complaints. Do not claim to know how it is being run. | A casual CO question, still scored. Recent strategy knowledge separates candidates at this stage. |
| R3 | "What have you built in Excel, or in a spreadsheet, that someone else relies on?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F6: you built the monthly complaints spreadsheet, and your regional manager uses it. Those are the beats the sentence states. Answer slot: say which tool it is in and what it held, in your own words. If you have not used Excel, say so. | F6's discovery gap. The recruiter will test whether this is Excel. |
| R4 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words. Nothing in this pack supplies one. | The recruiter's logistics check on the reason for leaving. Only your answer is safe. |
| R5 | "What are you looking for on pay?" | JD | [generic] | Logistics slot: give your own figure, or ask first for the band the role carries. Do not give a salary history you have not stated. | The recruiter's logistics check on pay. |
| R6 | "What notice would you need to give?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words. | The recruiter's logistics check on notice. |
| R7 | "Where would you need to be based, and how would you get to a hub?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the brief) | Logistics slot: know the role's location and which hub it sits in before you answer. Then give your own constraint, in your own words. The JD states no location. | The JD is silent on location, but the hub plan in the brief makes this question likely. |
| R8 | "Your background is branch-based, and this role includes a contact centre. Where does that leave you?" | JD | [grounded] "Never worked in a contact centre"; "6 years in retail banking, the last 3 as a branch supervisor" | Plain acknowledgment: "I haven't worked in a contact centre." Then the plan: what you would learn first. Then stay with your branch experience at its own scope. | F9 is a stated absence. The recruiter will want it said once, plainly. |
| R9 | "This role presents to senior leaders regularly. How do you do with that?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then how you would prepare. That is a plan, not a past. Do not describe a presentation you did not give. | F5 is a stated absence. The JD's "confident presenting to senior leaders" is the raising source. |

### Reverse questions

- "Which of the three areas do you most need covered in the first 90 days: the branches, the contact centre, or the digital work?" Why it lands: it shows you read the duties and want to sequence them.
- "Where does the hub timeline stand, and which branches are in scope for 2027?" Why it lands: it uses the brief's own sentence, and the recruiter can answer what the public text cannot.

## 5. Round H: Head of Member Services, 45 minutes

### Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (top weight) | Probes on scope, senior presenting and the contact centre | A hiring manager's prior is Case and Skeptic. This manager is buying capability and will check the gaps your message states | Plain acknowledgment with a plan. H2 is the highest-ROI rehearsal in the pack |
| Values/Behavioral | STAR-format asks; the round is mostly behavioural | The recruiter's stated format for this round | One story per question. "We" for the team, "I" for what you did |
| Case/Strategist | Live complaint and digital-thesis problems | The hiring-manager prior includes Case. H8 is the CO question from the brief | Clarify, then structure, then answer. Name one premise you would challenge |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you had to deliver an unpopular truth to someone senior." | VAL | [generic] | Story-selection scaffold, not a story. Pick a time you told someone senior something they did not want to hear. Say who, what, and what happened next. If none comes to mind, say so plainly, then give the nearest thing your material carries and how you would handle it. | A persona stem for a behavioural round. The cell makes no claim about your past. |
| H2 | "This role owns the complaints process across branches and the contact centre. Your material shows one branch's formal log. What would you do to own the whole process?" | JD | [grounded] "I handled the branch's formal complaints log" | Hold the position: for the branch's formal log, you handled it. Hold through two follow-ups by returning to that log, never by adding to it. Follow-up to rehearse: "How many branches would that cover?" Answer with the branch you ran, or say you do not know the count. Answer slot: if you owned any step beyond the log, say which and how you decided. If none was yours, say so plainly, and say how you would learn the whole process. | This is the highest-ROI prep in the pack. It presses on F1's scope, which the JD states and your message does not carry. |
| H3 | "You have never presented above regional level. How would you present to our senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan: how you would prepare, and what you would practise first. Do not offer a past presentation to rescue the answer. | F5 is a stated absence. "Above regional level" is your scope. |
| H4 | "You have not worked in a contact centre. What would you need to learn first?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I haven't worked in a contact centre." Then the learning plan: what you would learn first, and from whom. | F9 is a stated absence. |
| H5 | "Walk me through how you trained new tellers on the escalation script." | EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped from the quote: you trained new tellers on the escalation script, in those words. Answer slot: if you coached any supervisor on escalations, say how. If not, say so, and say how you would start with branch supervisors. | F3's transferability. The story is about tellers, and the JD asks about supervisors. |
| H6 | "Tell me about a time a complaint on your log needed a decision above the branch." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Pick a complaint that went above the branch, and say who decided, what you did, and how it ended. If none did, say so, then give the nearest case from the log and how you handled it. | An open prompt whose theme comes from the JD's escalation duty. The quote fixes the log, not any escalation. |
| H7 | "A regional manager asks for a monthly complaints pack in two weeks, including resolution times for every branch. What do you do first?" | CASE | [generic] | Clarify what the pack must answer and who reads it. Confirm which systems hold the data. Set a cut-off date. Then structure the pack. Name one assumption you would check with the regional manager. | A live problem from the JD's reporting duty. It asks no past from you. |
| H8 | "Forty per cent of member service moves to digital channels by 2028. What does that change for complaints?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the brief) | Answer at the brief's altitude. Complaints move with channels: name the types you would expect to rise and the types that should fall. Make no claim about digital work you have done. F4 is silent on it. | A current-strategy question from the brief summary. Answers to it separate candidates. |
| H9 | "Two branches are merging into one hub next year. How would you keep complaints handled while that happens?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the brief) | Clarify which members and which open cases move. Set one rule for open complaints. Agree the handover with the branch managers. Say how you would tell members. | A live consolidation problem. It asks no past from you. |
| H10 | "Six years in branches, and now you want a role across branches and a contact centre. Why this move?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Give your own reason, in your own words, tied to what the role does. Your material states no reason. Do not borrow the brief's language to supply one. | A Skeptic probe on motivation. The answer is yours to give. |

### Reverse questions

- "What would a strong first 90 days look like, and which decision would you want made by then?" Why it lands: it turns "own it end to end" into an expectation you can be measured against.
- "How do you want the monthly complaints report to change once the hubs open?" Why it lands: it uses the brief's hub plan, and this manager knows what they need from the report.
- "How would you want senior presenting to develop over the first year?" Why it lands: it turns the presenting gap into a development plan the manager would own.

No interviewer profile exists, so no reverse question ties to this manager's career path.

## 6. Round P: panel of two branch managers, 60 minutes

### Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (top weight) | Scored answers against the four values | The recruiter named this panel as the values round | Map one story per value. Use the honest branch where none exists |
| Peer Evaluator | Seam questions between branches and the contact centre; "what would you need from me" | Two branch managers are peers in function, and the role coaches their supervisors, so turf is the likely probe. This is inferred from the JD. Nothing is known about these two managers | Reciprocity first. Propose seam principles. Do not pretend to know the seam |
| Case/Strategist | The 20-minute complaint-escalation case, and a metric drop | The recruiter named the 20-minute case | Clarify, then structure. Think aloud |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Tell me about a time you put a member ahead of a branch target or a rule." | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." (the values, as you copied them) | Scaffold for the value: pick a time you decided from the member's side. Say what the member wanted, what you decided, and what it cost. If none comes to mind, say so plainly, then give the nearest thing your material carries: "I handled the branch's formal complaints log." | The value's own words raise the question. The panel scores it. |
| P2 | "Tell me about a time something you wrote or said had to be explained a second time. What did you change?" | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong."; nearest: "trained new tellers on our escalation script" | Scaffold: pick a time a message did not land, and what you changed afterwards. If none comes to mind, say so, then give the nearest thing: you trained new tellers on the script. Say how, if at all, you checked they understood it. | The value's test is whether it had to be explained twice. Your nearest story is the training. |
| P3 | "Tell me about a time a local issue changed how you handled a branch's complaints." | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town." | Scaffold: pick a time the town mattered to a decision, and say what you knew about it and what you did. If none, say so plainly. Do not describe a town you did not work in. | Nothing in your material touches a town, so the honest branch is required. |
| P4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved."; nearest: "I handled the branch's formal complaints log" | Scaffold: pick a complaint you held from first contact to close, and say what you did when it stalled. Answer slot: if you kept a specific complaint open until it was solved, tell it: who, what, and how it ended. If none, say so, and describe how you handled the log's open cases. | The value's test is holding on. The log is the nearest thing. The held-until-solved part is not in the material. |
| P5 | "The central complaints process sits across branches and the contact centre. Where is the seam, and what happens when a branch manager disagrees with it?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" (the JD) | Reciprocity first: say what you would bring to a branch manager's team. Then propose seam principles, such as who decides and who is told. Do not describe a past disagreement unless your material carries one. It does not. | A peer-evaluator turf probe from the JD's scope. |
| P6 | "Your branch supervisors already handle escalations. What would you need from branch managers to coach them well?" | JD | [grounded] "coach branch supervisors on escalations" (the JD) | Reciprocity framing: name what you would offer their supervisors, then what you would ask of the managers. Say what you would not change without them. | A peer question on the coaching duty. The managers' turf is the likeliest worry. |
| P7 | "A member says a fee was taken after they asked for a refund. The branch manager says the fee was correct, and the member is threatening to go to an external body. Work through the first 20 minutes." | CASE | [generic] | Clarify the dates, what was agreed, what the fee terms say, and who holds the file. Set the objective: a decision the member can understand, and a file that would survive review. Structure: confirm the facts, confirm who owns the decision, decide what the member is told and in writing, then record it. Challenge the branch manager's "correct" once, respectfully: ask what the policy says before what the fee was. Think aloud. | A live escalation drawn from the round's own brief. It asks no past from you. |
| P8 | "Your monthly report shows complaints up 20 per cent at two branches, and resolution times up at the contact centre. Where do you start?" | CASE | [generic] | Structure: is the rise real, or a change in counting? Which two branches, and what changed there? Is the contact centre's rise volume or time? Then segment, and pick one action. Name the metric you would trust least before you start. | A metric-diagnosis case from the JD's monthly reporting duty. |
| P9 | "How would you know a complaint was resolved properly, and not just closed?" | VAL | [grounded] "report monthly on complaint volumes and resolution times" (the JD) | Answer from what resolution means to the member and how you would check it, and what would show a closed complaint still hurting them. Do not describe measures you have tracked unless you have. | Tests whether "resolved" means anything to you. It draws on the JD's reporting duty. |
| P10 | "How do you handle credit when a fix spans two teams?" | VAL | [generic] | Reciprocity: name the other team's share first, then yours. Say what you would put in writing. Claim no past example. | A peer stem. Credit probes are common among managers who share a process. |

### Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Your material carries no story for this. P1 is a scaffold with an honest branch, then the nearest thing: F1, "I handled the branch's formal complaints log" |
| Plain Words | If a member needs it explained twice, the writing was wrong | Your material carries no story for this. P2 is a scaffold with an honest branch, then the nearest thing: F3, "trained new tellers on our escalation script" |
| Neighbours, Not Numbers | Every branch is part of its town | Your material carries no story for this. P3 is a scaffold, and the honest branch is required |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1 carries the log, not the held-until-solved part. P4 is a scaffold with an answer slot |

### Reverse questions

- "What could a new person in this role do in their first month that would genuinely help your branches?" Why it lands: it is the reciprocity question a peer round needs. It shows you think about their work first.
- "Where does a branch manager most need the central process to stop getting in the way?" Why it lands: it hands them the seam, in their own terms.
- "When a branch and the centre disagree on an escalation, how is it settled?" Why it lands: it asks for the actual rule, not the ideal one.

No interviewer profile exists, so no reverse question ties to either manager's career path.

## 7. Requirement coverage

| Requirement | Question IDs |
|---|---|
| Own the complaints process end to end across branches and the contact centre | H2, P5 |
| Report monthly on complaint volumes and resolution times | R3, P8, P9 |
| Coach branch supervisors on escalations | H5, P6 |
| Work with digital teams on self-service journeys | H8. Note: F4 is silent, so no story is coached |
| 4+ years in financial-services customer operations | R1, H10 |
| Experience handling regulated complaints | H6 |
| Confident presenting to senior leaders | R9, H3 |
| Comfortable with Excel reporting | R3 |
| The contact centre (a duty) | R8, H4 |
| The four values (scored by the panel) | P1, P2, P3, P4 |
| Recruiter logistics: pay, notice, location, reason for leaving | R4, R5, R6, R7. These are the recruiter's coverage rule, not JD requirements |

## 8. Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 | F1's quote at its own scope. The pack's own observation, not words for you: your material shows one branch's log, not the process. The H2 slot stays inside the log |
| Coached branch supervisors on escalations | Inflated form of F3 | "trained new tellers on our escalation script," at its scope. The material says tellers |
| Handled regulated complaints under a named rule or route | Inflated form of F8 | "I handled the branch's formal complaints log." The material says formal, and names no rule |
| Produced monthly volume and resolution-time reporting | Inflated form of F2 | "I built the monthly complaints spreadsheet our regional manager uses." The material does not say what it held |
| Presented to senior leaders | Negative you stated, F5 | "I haven't presented to anyone above regional level." No slot |
| Worked in a contact centre | Negative you stated, F9 | "I haven't worked in a contact centre." No slot |

Not listed: digital and Excel work. Your material is silent on both, so they are answer slots (F4, F6), not claims.

## 9. Sources

**Provided documents, all from your message:** the JD text (its requirements and four duties); the recruiter's round structure as you relayed it; the four values as you copied them on 19 November 2026; the strategy brief as you summarised it, which the recruiter sent you; and your background.

**Research tier: L1, searches 0 of 6, fetches 0 of 2.** No search or fetch was sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values section and P1 to P4. The four names are in hand as you copied them this morning |
| 2. Ashgrove interview process, role family | skipped | Loop structure. The recruiter's own words name the three rounds, their dates and who runs each, which establishes the loop. No archetype fallback applies |
| 3. Ashgrove strategy and recent news | skipped | CO bank and grounding brief. The July 2026 brief is under six months old and is in hand as your summary, not its text |
| 4. Interviewer name | n/a | No names were given, so there was no query to form |
| 5. Representative JD | skipped | Your JD fixes the fit snapshot and the JD questions |

## 10. Upgrade menu

- The names of the Head of Member Services and the two branch managers → a persona weight for each, and reverse questions tied to their career paths.
- Your CV → the quotes become document evidence. A spreadsheet you can show is the artifact that would raise F2 and F6.
- The strategy brief itself → exact wording and figures for R2, R7, H8 and H9. The pack currently rests on your summary.
- The role's location and hub → an exact R7 logistics slot.
- The external rule or referral route that governed your complaints log → F8 becomes grounded, and H6 can carry a regulated-complaints story.
- Whether your branch is among the eight being consolidated → H9 and the CO answers become concrete.
- The recruiter's brief for the 20-minute case → P7 and P8 built to its format.
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes. Want it?
