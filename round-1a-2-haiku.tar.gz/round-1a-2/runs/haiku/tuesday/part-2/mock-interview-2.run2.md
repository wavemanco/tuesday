Your prep pack is saved as atlas-freight_operations-manager_interview_pack.md, at /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-2-denied-d4213c6e/07b24b0a-0377-40c8-8b1f-7c2d979200e1/scratchpad/atlas-freight_operations-manager_interview_pack.md. I built it for a hiring-manager round, since your note didn't say who you're meeting.

The three things to get ready for most:

- **Scale.** The JD asks you to lead 12 supervisors across four sites. You currently lead 3, at one site. Expect this to come up in some form. The pack's highest-priority question is S1, and it asks you to say your largest team plainly and then describe your plan for 12.
- **Power BI.** Say "I haven't used Power BI" without hedging, then give a concrete plan for learning it. Don't reach for the Excel work as a substitute.
- **The 40%.** Be ready to say how it was counted, what period it covers, and which part was yours. If you don't know how it was counted, say so.

I didn't run any web research for this pack, so there are no company values, interview process or recent-news sections yet.

Offers:
- Want to rehearse? I can play the Skeptic on S1 and push back on your answer. The drill is one live round with follow-ups.
- I can save a tuesday-dossier.md that records the gaps this prep exposed, for you to carry into later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

Questions:
1. Who are you meeting, and what round is it: hiring manager, a peer, a panel or a screen? Has HR named any focus areas or a task to prepare?
2. Does the role sit at one site, or does it mean moving between the four? Can you do that?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Atlas Freight: Operations Manager interview prep pack

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** not known. **Round:** not known. Built for a hiring-manager round, since your note didn't say who you're meeting. The first question in the message will reweight the banks.
**Version:** first version.

## How to use, and the type key

Personas describe how a question arrives. Types describe what is being scored.

- **JD:** can you do the listed job, including its gaps
- **EXP:** do your past claims survive scrutiny, and what did you actually do
- **CASE:** structure and reasoning on a live problem from this role
- **VAL, CO:** not used in this pack. No values round was detected and no company research has run yet.

Guidance is scaffolding, not a script. Each answer should run 90 to 120 seconds. Anything in quotation marks in a Provenance cell is your own sentence, or a line from the JD you pasted.

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows one site and one surge plan, not four sites. Words: "For two years I ran the site's peak-season surge plan." Answer slot: if you have run or shared operations across more than one site, say how many and what your part was; if not, say so and stay with the site you ran. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | The quoted result is picking accuracy, not on-time performance or cost per shipment, so the bridge stays at accuracy. Words: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if your work moved on-time or cost-per-shipment figures, say which and how; if it did not, say so and describe what the 40% measured. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows 3 supervisors, not 12, so the bridge is at 3. Words: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have led a larger group, say its size and how it was set up; if not, say so and say what you would put in place first at 12. |
| F4 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | low | [grounded] | discovery | The quote touches Excel but does not show reporting built in it, and the material is silent on that. The pack will not turn "solid Excel" into reporting. Answer slot: if you have built reporting in Excel, say what it tracked and who used it; if you have not, say so and say how you would start. |
| F5 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. No claim of Power BI work. |
| F6 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message), "currently a senior shift manager over 3 supervisors" (your message) | low | [grounded] | discovery | Your material shows seven years in operations. It does not say how many of them were leadership, so the five-year leadership length is not established. Words: "I have 7 years in warehouse and distribution ops." Answer slot: say how many years you have led people, in your own words; if that is under five, say so and say what leadership you did have. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote reaches the requirement. Words: "I'm green belt certified." Limit: the certificate has not been inspected, so expect a probe on what the belt was applied to. |
| F8 | "Own daily terminal operations across 4 sites" (JD) | none given | none | [grounded] | hard_gate | Your material does not establish whether the role is site-based or requires travel between the four sites. Nothing is bridged here. The one question allowed asks whether the gate is met (question 2 in the message). |

Limit on the snapshot: the JD is the summary you pasted, not the full posting. Requirements in the full posting that are missing here have no row yet.

## 8. Persona table

Starting weights come from the hiring-manager prior: a hiring manager is buying capability and derisking gaps.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the scale gap, the Power BI gap and the years of leadership | Top weight, 5 questions. The gaps are the most visible things on the page, so this is where the hiring manager will look first. | Say the quoted sentence, then the limit, then the plan as a plan. Hold through two follow-ups. |
| Case/Strategist | Live problems on four sites: on-time performance, cost per shipment, a short-staffed site | Top weight, 5 questions. The role is operations, so live problems are the expected format. | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. |
| Data-Driven Prober | Asks how the 40% was counted and what the Excel work was | 3 questions. The headline figure and the "solid Excel" line are the targets. | Name the weakest assumption before they do. Say plainly when you don't know. |
| Pressure | Interrupts on scale and Power BI; asks how much was really you | 3 questions. Mid weight. Hiring managers with a hard role sometimes run it. | Pause, restate the question, hold through two follow-ups, concede specifically. |
| Conversational | An opening "walk me through" and a casual Lean question | 2 questions. Low weight, but scored. | A pre-scripted 90-second arc. Treat the casual Lean question as scored. |

Peer and recruiter-screen personas are not weighted here. If this round is one of those, the weights change (see the upgrade menu).

## 9. Question banks

### Skeptic (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "This role leads 12 supervisors across four sites. What's the biggest team you've led, and what changes at that size?" | JD | [grounded] "lead a team of 12 supervisors" (JD); "currently a senior shift manager over 3 supervisors" (your message) | Highest-ROI prep in this pack. Start from what you lead now, in your own words: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have led a larger group, say its size and how you set it up; if not, say so plainly and describe what you would put in place first at 12. Hold through two follow-ups by returning to the 3 and to the plan, never by adding to either. | F3 is the evidence. The 12-across-four mismatch is the likeliest objection, and the JD raises it directly. |
| S2 | "How would you run daily operations across four sites?" | JD | [grounded] "Own daily terminal operations across 4 sites" (JD) | A plan, with no past claim. Say what you would check first each morning across the four sites, what you would expect to see by the end of week one, and how you would know a site was slipping. | The JD line is the requirement. F1 shows one site, so the answer is a plan, not a record. |
| S3 | "Power BI is part of the job, and you haven't used it. What's your plan, and how long would it take?" | JD | [grounded] "never used Power BI" (your message) | Plain acknowledgment first: "I haven't used Power BI." Then the plan: what you would learn first, from whom, and what you would build with it. Answer slot: if you have used any BI tool, name it and what you did in it; if not, say so. Concede the timeline honestly rather than give a number you cannot back. | F5 is the sourced negative. The question presupposes it, which the source allows. |
| S4 | "The role asks for 5+ years of operations leadership. How do your years add up?" | JD | [grounded] "5+ years operations leadership required" (JD); "7 years in warehouse and distribution ops" (your message) | Say how many years you have led people, starting from when, in your own words. The seven years are operations; the leadership portion is yours to state. Answer slot: if the leadership years are under five, say the number and what you led in that time. Do not count operations years as leadership unless you held a lead role in them. | F6 is discovery: the material shows the operations years, not the leadership years. |
| S5 | "Lean and Six Sigma are a plus here. Tell me about your Green Belt: what it covered, and what it did for your work, if anything." | JD | [grounded] "green belt certified" (your message) | Open with the certification in your words: "I'm green belt certified." Answer slot: if you applied the method to a piece of work, name the work and what you did; if it has not changed your work, say so. Expect a follow-up on the project. Hold it at what you did. | F7 is the quote. The probe tests whether the credential has a project behind it. |

### Case/Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "On-time performance at one of your four sites drops eight points overnight. Walk me through your first hour." | CASE | [generic] | Clarify before you structure: what changed overnight, what the shift data says, and whether the drop is one lane, one shift or one dock. Then structure: objective, segments, the likeliest causes, the check for each, and what you would tell the site lead. Think aloud. No claim about your past. | A live problem from the JD's on-time line and its four-site scope. Generic because it is a pattern for the problem, not a fact about this employer. |
| C2 | "Cost per shipment is up for the quarter. Where do you look first?" | CASE | [generic] | Ask what cost per shipment includes and what changed in volume, mix and labour hours. Split the cost into its parts before you pick a cause. Name one metric you trust and one you would not. | The JD's cost-per-shipment line. The answer rests on decomposition, not on any figure. |
| C3 | "Peak season starts in six weeks and one site is short of supervisors. How do you plan it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Structure first: demand, the labour gap, who covers, and what gets cut if the gap stays. If you draw on a surge plan you have run, describe its steps in your own words and say which were yours. If the steps you would use are not ones you ran, say so and give the ones you would use. | The quote gives the story to draw on. Its steps are not stated, so they are an answer slot. |
| C4 | "Mis-pick rate is back up at one site after a process change. What do you check?" | CASE | [generic] | Structure: confirm the measure, check whether the change touched the pick path, compare the sites before and after, and look for a staffing or slotting shift. No claim about your past. | Your 40% (F2) is what this will be set against. The case itself is a pattern, so it is generic. |
| C5 | "A supervisor tells you her team can't hit pick targets because the system is slow. What's your first move?" | CASE | [generic] | Go and look: check the system's data against the team's data, talk to the supervisor and the team, and separate a system fault from a process fault before you escalate. Say what you would tell her and when you would come back to her. | Supervisor-level problem the role leads. No past claim is made. |

### Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "How did you count the 40% on mis-picks? What period, and what denominator?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Defend-the-number slot. Say how the 40% was counted, in your own words, and the period it covers. Then name the assumption you would defend least, before they do. Answer slot: if you measured it yourself, say how; if the figure came from someone else's report, say so and say which part you checked. "I don't know how it was counted" is an honest branch. Do not supply a baseline, a denominator or a method. | F2 is the headline figure and the likeliest target for a probe. EXP because it tests attribution. |
| P2 | "Tell me about a spreadsheet you've used at work to answer an operations question." | EXP | [grounded] "solid Excel" (your message); theme from the JD's "build reporting in Excel/Power BI" | Open prompt. Pick one you used, say what question it answered and who used the answer. If none comes to mind, say so plainly, then say how you would approach the first report you were asked for. | F4 is discovery. The open prompt lets the interviewer find out whether the Excel work exists. |
| P3 | "Walk me through the surge plan: its steps, and who set them." | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Story map from the quote: you ran it for two years. Say the steps in your own words and which ones you set. Answer slot: if you set the steps, say which and why; if they came from elsewhere, say so and say what you ran. Do not describe results the quote does not carry. | F1 is the evidence, and the probe tests what was yours. |

### Pressure (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| PR1 | "Sixty seconds: why you, when the role asks you to lead 12 supervisors and you lead 3?" | JD | [grounded] "lead a team of 12 supervisors" (JD); "currently a senior shift manager over 3 supervisors" (your message) | Hold-then-concede. Hold with your quoted result: "I cut the mis-pick rate 40% by redesigning the pick path." Concede specifically: "I haven't led 12 supervisors. I'm over 3 now." Do not argue the 12 away, and do not claim a scale you don't have. | F2 and F3. The hold is a quoted result. The concession is the stated limit. |
| PR2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold the verb you used. If you led the redesign, say so. If others shaped it, name them and your part. Concede only what you cannot back: if the rest was the team's, say that plainly. | F2. The attribution probe tests the sentence, so the answer must match its verb. |
| PR3 | "You've never used Power BI. Why would we hire you to build it?" | JD | [grounded] "never used Power BI" (your message); "solid Excel" (your message) | Plain acknowledgment: "I haven't used Power BI." Hold on your starting point: "solid Excel" is what I'd start from. Hold through two follow-ups by returning to the plan. Concede that the gap is real. | F5 and F4. The sourced negative and the Excel quote, nothing added. |

### Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| CV1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops, currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc: start with the seven years, move to the shift manager role, then the pick path result and the surge plan. Stop there. Do not add a fact the quotes do not carry. | F1, F2 and F3 in order. The arc is the quotes, nothing more. |
| CV2 | "Where does Lean fit in how you're developing at the moment?" | JD | [grounded] "green belt certified" (your message) | Name the Green Belt as where you start. For the next step, give a plan, not a past. Answer slot: if you have a current Lean practice, name it; if not, say so and name the one you would start with. Treat this casual question as scored. | F7. The Lean plus is asked lightly, and the answer is still scored. |

### Coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | S2, C1, RQ1 |
| Drive on-time performance and cost-per-shipment down | C1, C2, RQ2 |
| Lead a team of 12 supervisors | S1, C5, PR1 |
| Build reporting in Excel | P2, PR3 |
| Build reporting in Power BI | S3, PR3, RQ3 |
| 5+ years operations leadership required | S4 |
| Lean/Six Sigma a plus | S5, CV2 |
| Location and travel across the four sites (gate) | none, and why: a gate is asked in the message, not in the banks |

### Highest-ROI prep

**S1.** It is the scale objection the JD raises directly, and it will come in some form. Rehearse it until the concession is plain and the plan is specific.

## 11. Reverse questions

Each one has a "why it lands."

- **RQ1.** "What would you expect the first 90 days in this role to be measured on?" *Why it lands:* it shows you are planning for four sites, not one.
- **RQ2.** "How do on-time performance and cost per shipment compare across the four sites right now?" *Why it lands:* it shows you think in site-by-site comparisons, which is the job.
- **RQ3.** "What does reporting look like today, and where does the Power BI work fit?" *Why it lands:* it puts your gap on the table as a shared project, not as a flaw.
- **RQ4.** "What's the hardest operational problem the next person in this role inherits?" *Why it lands:* it asks for the real job, and answers come back more candid than a standard question gets.
- **RQ5.** "How are the 12 supervisors spread across the four sites, and what does a typical week look like for one of them?" *Why it lands:* it shows you are thinking about scale as a management problem.

## 13. Prohibited claims

What this pack will not coach, and why. Built locally from the fit snapshot, since no dossier is present.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've run daily operations across four sites" | Inflated form of F1 | F1's quote at its own scope: "ran the site's peak-season surge plan two years running." Limit, as the pack's observation: your material shows one site. |
| "I've led 12 supervisors" or "I've led at that scale" | Inflated form of F3 | "currently a senior shift manager over 3 supervisors." Limit, as the pack's observation: 3, not 12. |
| "I've improved on-time performance or cost per shipment" | Inflated form of F2 | The mis-pick result at its own scope. Limit, as the pack's observation: it measures accuracy. |
| "I've built Excel reporting" | Inflated form of F4 | "solid Excel" at its own scope. What you built, if anything, is the answer slot in P2. |
| "I've built Power BI reporting" or "I use Power BI" | Negative you stated, F5 | Plain acknowledgment: "I haven't used Power BI." |
| "I have five years of operations leadership" | Inflated form of F6 | Your quotes. Your material does not show how many years were leadership. |

## 14. Sources

- **Provided documents:** the JD summary you pasted, and your background as stated in your message. No CV file and no full posting.
- **Research tier:** L0. No searches or fetches were run in this pack.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet, not built. No values round was detected. |
| 2. Atlas Freight interview process, operations manager | unavailable | Loop structure. Persona weights use the hiring-manager prior until the round is known. |
| 3. Atlas Freight strategy and recent news | unavailable | The grounding brief, and the company and strategy questions. None were written. |
| 4. Interviewer name | n/a | No name was given, so there was no query to form. |
| 5. Representative Operations Manager JD | skipped | Your JD summary fixes the fit snapshot and the JD questions. |

## 15. Upgrade menu

- **The round and who you're meeting:** reweights the personas, and tells the pack whether this is a hiring-manager, peer, panel or screen round.
- **The interviewer's name:** a tailored reverse question, and persona weights from their public footprint.
- **The full posting:** checks every line of it against the fit snapshot. The summary may have dropped requirements.
- **How many years you have led people:** moves F6 from discovery to a stated figure.
- **The Green Belt certificate and the project it was used on:** gives F7 an inspectable artifact, and gives S5 a story.
- **A short example of Excel reporting you have built:** can move F4 and give P2 a story.
- **Level 1 research on Atlas Freight's values, interview process and recent news** (up to 6 searches and 2 page fetches): adds a values cheat sheet, the loop structure, and a grounding brief for the company questions.
- **A tuesday-dossier.md:** would sharpen the scale objection and the prohibited list with evidence from a fit check.
