Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-7-denied-3ddd75aa/971fc69d-a27f-48c2-b517-7df782ca1729/scratchpad/saltmarsh_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round with Tobias, since you didn't say what kind of final this is. The weights will change once you answer question 1.

I couldn't research Saltmarsh or Tobias: the web search permission was refused, so the pack uses only your JD and your message. Its biggest gap is the coordination requirement, since you have no quoted evidence for design, art, engineering or community work. The rehearsal for that is question B1.

The pack's three priorities:
- **B1, the team-leadership objection.** Say "I haven't led a team" plainly, then give a plan. Don't claim coordination you didn't do.
- **A2 and A4, post-event review and KPIs.** Your material shows you presented retention numbers, not that you owned the review. Don't let the answer say you did.
- **C1 and C2, the retention number.** You didn't give a figure in your message, so be ready to say "I don't know how it was counted" if asked.

Prohibited wordings include "I ran live events across two titles" and "I owned the KPIs." Your message supports neither.

Offers, neither pushed:
- **Drill:** I can play the Skeptic on B1, or any persona you choose, with follow-ups that react to your answers.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed.
- **Word:** I can convert the pack to .docx if you want it.

Three questions:
1. Is Friday's round a hiring-manager interview with Tobias, a skip-level, or a panel, and is it one session or several?
2. Was the puzzle title live-service (updates and events after launch), and was it a mobile game?
3. Do you have your CV? If so, paste it and I'll rebuild the quotes from it.

Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Round:** Final round, 60 minutes, Friday
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Relationship (assumed):** hiring-manager round. You didn't say whether this is a hiring-manager, skip-level or panel session, so every weight below is provisional. Question 1 in the message asks.
**Changelog:** first version.

## 1. How to use this pack

- **Personas** = how the question is asked (the register, the pressure, the angle).
- **Types** = what is being scored: **JD** (a stated requirement), **EXP** (your own work, tested for accuracy), **CASE** (a live problem), **CO** (company knowledge, not covered here), **VAL** (company values, not covered here).
- Guidance is scaffolding, not a script. Each guidance cell is written to be said aloud in 90 to 120 seconds, and it says only what your quoted sentences say.
- Rule for the room: if a sentence isn't in the Provenance column, don't say it.

## 2. Fit snapshot

Requirements are the JD's own words. Evidence is quoted from your message. Nothing else is quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one main title and a weekly content-drop calendar, not live events across two titles. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned a calendar across more than one title, say so; if you did not, say so and say how you would split the calendar. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination with these four teams. Answer slot: if you coordinated any of them on an update, name the team and what you agreed; if you did not, say so and say how you would run one. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Your material shows you presented retention numbers, not that you owned a post-event review. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran a post-event review, say what it covered; if you did not, say so and say what you would review first. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Bridge: "I wrote the release checklist our QA team still uses." No added practice. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | Your material gives four years and a puzzle-game studio. It does not say the title was live-service. Bridge: "Four years as an associate producer at a puzzle-game studio." Answer slot: if the title's updates were live-service, say which ones; if not, say so. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote already says what the JD asks. Bridge: the quote, in your own words. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | none | The quote reaches the requirement directly. Your message gives no retention figures, so no defend-the-number slot is raised yet. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | transferability | A checklist is adjacent written work. It does not show written communication beyond itself. Bridge: the quote, unchanged. Answer slot: name the document you would most want them to read, and why. |
| F9 | not in the JD; likely probe | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't led a team." Then how you would learn to, said as a plan, never as a past. |
| F10 | not in the JD; likely probe | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked on a game with in-app purchases." Then what you would need to learn first, said as a plan. |

**Confidence** grades your evidence. Every line here is a self-reported line with nothing inspected behind it, so the highest is medium.

## 3. Prohibited claims

Each entry is a wording the interview should not reach for. The honest form is the quote at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| "I ran live events across two titles" / "I planned the calendar for two titles" | Inflated form of F1 ("our main title") | F1's quote at its own scope. The limit is the pack's observation: your material says one main title, not two. B2's slot stays inside it. |
| "I owned the post-event review and the KPIs it reported" | Inflated form of F3 ("Presented the monthly retention numbers") | F3's quote at its own scope. The limit is the pack's observation: your material says you presented retention numbers, not that you owned the review. |
| "I ran a live-service game" | Inflated form of F5 ("a puzzle-game studio") | F5's quote at its own scope. B4's slot asks which updates were live-service. |
| "I designed the release process QA uses" | Inflated form of F4 ("Wrote the release checklist") | F4's quote, unchanged. |
| "I have led a team" | Sourced negative, F9 | The plain acknowledgment: "I haven't led a team." No slot. |
| "I have worked on a game with in-app purchases" | Sourced negative, F10 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot. |

## 4. Persona table and weights

Relationship prior: a hiring-manager round carries Case/Strategist plus Skeptic. "Final round" with a Head of function tilts toward Pressure, so it gets a mid weight. No interviewer footprint was available (see Sources), so there is no interviewer-signal adjustment.

| Persona | How it shows up in this loop | Likelihood | Weight | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Live calendar, retention and release problems | High | 5 questions | Clarify, then structure, then metrics, then risks; think aloud |
| Skeptic | Team leadership and in-app purchases gaps; the single most likely objection | High | 5 questions | Plain acknowledgment, then a plan; calibrated candour |
| Data-Driven Prober | Retention figure you presented: how counted, which assumption | Medium | 3 questions | Name the weakest assumption before they do; "I don't know how it was counted" is an honest answer |
| Pressure | Single-title versus two-title calendar; "a step back" framing | Medium | 3 questions | Pause, restate, hold through two follow-ups, then concede specifically |
| Conversational | Journey opener; "what have you been playing" | Medium | 2 questions | 90-second arc; treat casual questions as scored |

Weighting is provisional until Question 1 is answered.

## 5. Question banks

Type tags are in the Type column. Provenance comes before guidance. A question about your past names a quote, or the question is an open prompt whose theme the JD raises.

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're asked to plan the live-events calendar for two mobile titles starting next month. What do you need to know in week one?" | CASE | [generic] | Clarify first: goals per title, current event load, release cadence, team capacity. Then objective, segments, approach, metrics, risks. No claim about your past. | Raised by the JD's first line (F1). The problem is the role's, not your history. |
| A2 | "Day-seven retention fell after a weekend event. Walk me through the diagnosis." | CASE | [generic] | Separate the event from the cohort and from any release change. Name the metric you'd check first and what would change your mind. | Raised by the JD's "own the post-event review and the KPIs it reports". |
| A3 | "A content update needs design, art, engineering and community on the same day, and QA has a freeze on Thursday. How do you sequence it?" | CASE | [generic] | Work back from the freeze date. Name an owner per team and the checklist step each one clears. Say what you would drop first if the date slips. | Raised by the JD's coordination and release-checklist lines (F2, F4). |
| A4 | "What KPIs would you put in a post-event review, and what would make you distrust one?" | JD | [generic] | Name a short set of KPIs with the denominator for each. Name the weakest assumption in one of them. Monetisation KPIs only if the title has them. | Raised by the JD's post-event review line (F3). |
| A5 | "Tell me about a content drop that didn't land. What did you change for the next one?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Open prompt, so pick a real drop. Use the calendar you ran, in your own words. Answer slot: if you changed the next drop, say what you changed and why; if you saw no miss to act on, say so and say how you would review one. | Theme from the JD's post-event review line (F3). Tests what you did, not the calendar's existence. |

### B. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't led a team. How would you coordinate design, art, engineering and community on an update with no reports?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | **Highest-ROI prep.** Plain acknowledgment: "I haven't led a team." Then the answer slot: if you coordinated any of those four teams on a drop, name the team, the decision and what you agreed; if you did not, say so and say how you would set up an update's cross-team plan (owners and dates). Hold through two follow-ups by returning to what you did with the checklist (F4), never by claiming coordination you did not do. Concede specifically: name the team you have not worked with. | The most predictable objection, and the JD's coordination line (F2) is where the material is thinnest. This is where a pack is tempted to thicken, so the rehearsal stays inside the quote. |
| B2 | "Your calendar was one title. How would you plan it across two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Plain: "The calendar I ran covered one main title." Answer slot: if you planned across more than one title, say how; if not, say so and say how you would split the calendar and what you would check first. | F1 is the evidence for the two-title requirement. The premise is your own quote. |
| B3 | "You haven't worked on a game with in-app purchases. What would you need to learn first?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say what you would learn first, as a plan. Never describe monetisation you have not run. | F10 is a gap you stated. The question is about the candidate, not about the employer. |
| B4 | "You've spent four years at a puzzle studio. Which part of that was live-service, specifically?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Answer slot: if the title's updates or events were live-service, name which ones and your part in them; if not, say so and say what the updates were. | F5 is the three-year requirement, and "live-service" is the JD's word, not your quote. |
| B5 | "Which document from the last two years would you most want us to read, and why?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Name the checklist. Say what makes it usable, only as the quote says it: QA still uses it. Answer slot: if you have a writing sample, name it. | F8 is the written-communication requirement; the checklist is your only written evidence. |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented monthly retention numbers to the studio head. Walk me through how one of them was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: name the figure and how it was counted, in your own words. Your message gives no figure, so the honest branch is: "I don't know how it was counted," or "I didn't own the counting." | F7 is the retention requirement. A figure you name in the interview becomes material. |
| C2 | "Which assumption behind that retention number would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name the assumption in your own words, before they do. If you don't know the assumption, say so. | The weakest-assumption move converts a gotcha into a credibility gain. |
| C3 | "How would you know a post-event review had told you the truth?" | JD | [generic] | Name the check you would run: a holdout, a second cut, a re-run on a different cohort. Name one way a review could mislead you. | Raised by the JD's post-event review line (F3). A general question, not a claim about your past. |

### D. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run live events across two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause. Hold the position through two follow-ups: "Two years of weekly drops on one main title, and a release checklist QA still uses." Concede specifically: say plainly the calendar you ran covered one title. | The stem is a rival comparison. Hold only what the quote carries. |
| D2 | "Four years as an associate producer, and you've never led a team. Why isn't that a step back?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "Never led a team, and never worked on a game with in-app purchases." | Hold on the four years and the calendar. Concede "I haven't led a team" plainly, then move to what you would do first in the role. Do not argue that it isn't a step back. | The pressure comes from the gap you stated. Hold-then-concede keeps the concession exact. |
| D3 | "That checklist QA still uses: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it." Answer slot: if QA changed it afterwards, say who changed what, and what you wrote. If others wrote parts, name them. | F4 is a written claim the interviewer will test. |

### E. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." / "I ran the weekly content-drop calendar for our main title for the last two years." / "Wrote the release checklist our QA team still uses." / "Presented the monthly retention numbers to the studio head." | 90-second arc, four beats, each a quoted sentence in your own words: the studio and role, the calendar, the checklist, the retention numbers. End on the calendar, the part of the role you most want. | Casual openers are scored. Use the quoted beats only. |
| E2 | "What have you been playing lately, and what did its events do well?" | CASE | [generic] | Name one game you have played and one live-ops thing you noticed in it. Answer slot: if you have not played a live game lately, say so and name the nearest one. | Casual register, scored content: it checks whether you follow the category. |

### W. Written communication (1, covered by B5)

B5 carries the written-communication requirement. No separate row.

## 6. Requirement coverage

| JD requirement | Question IDs | Notes |
|---|---|---|
| Plan and run the live-events calendar for two mobile titles | A1, B2 | Second title is an answer slot (F1) |
| Coordinate design, art, engineering and community teams on each update | A3, B1 | Thinnest area in the material (F2) |
| Own the post-event review and the KPIs it reports | A2, A4, A5, C3 | Post-event review not shown in material (F3) |
| Manage the release checklist with QA | A3, D3 | Quote carries it (F4) |
| 3+ years producing live-service games or apps | B4 | Live-service not shown in material (F5) |
| Experience running a content calendar | A5 | Quote carries it (F6) |
| Comfortable with player-retention metrics | C1, C2 | No figures given yet (F7) |
| Clear written communication | B5 | Only one written artefact in material (F8) |

## 7. Reverse questions

Each has a one-line "why it lands." Tobias's own path is not in the material, so none is tied to it yet.

1. "What does the first 90 days look like for whoever takes this calendar?" Why it lands: it shows you are already planning the job.
2. "How are post-event reviews run today, and who reads them?" Why it lands: it asks about the KPI process the JD names, before you commit to a view of it.
3. "Which of the two titles needs the calendar most right now?" Why it lands: it turns the two-title question into a prioritisation conversation.
4. "When something breaks after a release, how does the checklist with QA get updated?" Why it lands: it tests the release process from the team's side.
5. "What did the last live-events calendar miss, and what would you want the next person to fix first?" Why it lands: it asks for the honest version of the job, and shows you expect to learn from it.

## 8. Sources

- **Provided:** the JD text, your background (from your message, not a CV file), and the interviewer's name and title.
- **Searches attempted:** "Saltmarsh Games mobile game studio": **refused** (search permission not granted). "Tobias Wrenfield Head of Live Operations": **refused**. No fetches were sent.
- **Research tier:** L0. No search ran, so no company or interviewer information is in this pack.

**Target accounting**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | unavailable | Values cheat sheet (section 10): omitted, since no values are in hand |
| 2. Saltmarsh interview process | unavailable | Loop structure and persona weights: weights here are the relationship prior only |
| 3. Saltmarsh strategy / recent news | unavailable | CO bank: absent |
| 4. Tobias Wrenfield | unavailable | Interviewer read, personalised reverse question, persona weights: absent |
| 5. Representative Live Operations Producer JD | skipped | The JD supplied fixes the fit snapshot and the JD-tagged questions |

**Sections not included, and why:** the interviewer read (no public footprint), the values cheat sheet (no values in hand), the grounding brief (no research), graded deliverables (none declared), delivery coaching (no assessment), and prep triage (prep time not stated).

## 9. Upgrade menu

- Your CV or pasted resume → quotes come from the document instead of your message; F1 to F8 become checkable against a written source
- Round format and who else is in the room → persona weights and the reverse-question set
- Saltmarsh's values and recent strategy (with web search permission) → values cheat sheet, grounding brief, and CO questions
- Tobias's public footprint (with web search permission) → interviewer read, persona weights tuned to his path, and a reverse question tied to it
- Whether the puzzle title was live-service and mobile → B4 and F5 move from answer slots to a grounded answer
- Prep time before Friday → a prioritised triage of the top questions
- Any recruiter email about focus areas → coverage of anything they name
