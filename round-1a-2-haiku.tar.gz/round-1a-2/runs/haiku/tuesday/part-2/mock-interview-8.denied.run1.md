Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-8-denied-96e937a6/5fb38bca-d9ba-40e2-bd01-7359e1aed7ec/scratchpad/ashgrove_member-experience-lead_interview_pack.md. I built it on your message, the JD, the values text and the strategy brief as relayed, and treated the 30-minute call as a recruiter screen and the 45-minute round as behavioural, with the Head of Member Services as your manager.

The pack's most important finding is that the JD asks for three things your material doesn't show: contact-centre work, presenting to senior leaders, and resolution-time reporting. Question B1, "You've never worked in a contact centre. How would you own complaints across one?", is the one to rehearse hardest.

Say the word and I'll play the Skeptic on B1 in a live drill. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.

Could you paste your CV? Every evidence cell currently says "your message", and a CV would let me check your dates and titles against it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead, interview prep pack

Rounds on 28 November 2026: a 30-minute recruiter screen; a 45-minute behavioural round with the Head of Member Services (your future manager); a 60-minute panel of two branch managers, including a 20-minute complaint-escalation case, scored against the four values. Interviewer names are not yet assigned. Built 19 November 2026.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored: **VAL** (values), **EXP** (your own experience, probed), **JD** (the listed job), **CO** (company and strategy), **CASE** (a live problem). Guidance is scaffolding, not a script. Speak it in your own words, and rehearse only what you did.

Provenance labels: **[grounded]** traces to a document you gave me or to your own words; **[inferred]** is my derivation from a grounded fact, with the derivation named; **[generic]** is a pattern for the role, with no claim about you or Ashgrove.

## Fit snapshot

Evidence is quoted from your message, which is the only material about your background so far. No CV was provided.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | No gap. Your words: "I have six years in retail banking, the last three as a branch supervisor." Keep the three years as supervisor; do not round them up. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | Your words reach the requirement in other terms: "I handled the branch's formal complaints log." Add no regulator, timescale or outcome. Answer slot: the JD says "regulated", so expect a probe on what made the log formal. If regulatory rules or timescales applied, say which and how you worked to them; if they did not, say so plainly and describe how the log was kept. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message); "Never worked in a contact centre" (your message) | low | [inferred] | transferability | Transfer at the log's scope: "I handled the branch's formal complaints log." The limit, said plainly: "I haven't worked in a contact centre." The pack's observation: your material shows one branch's log, not a process across branches or a contact centre. Answer slot: if you followed a complaint from first contact to close, say which steps were yours. |
| F4 | "report monthly on complaint volumes" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Your words reach monthly complaint reporting: "I built the monthly complaints spreadsheet our regional manager uses." Say nothing about what it counted until you can say it. |
| F5 | "resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | Your material does not show resolution times in the spreadsheet. Answer slot: if it recorded how long complaints took to close, say how that was counted, in your own words; if it did not, say so plainly and say what you would track first. |
| F6 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Your words reach reporting, though Excel is not named: "I built the monthly complaints spreadsheet our regional manager uses." If it was Excel, say so. Claim no more tool skill than building that one spreadsheet shows. |
| F7 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message); "the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | Transfer at scope: "I trained new tellers on our escalation script," and "the last 3 as a branch supervisor." The limit: your material shows training tellers, not coaching supervisors. Answer slot: if you coached another supervisor on an escalation, say what you did; if you did not, say so and say how you would start. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | No evidence in your material. Answer slot: if you have worked with a digital or self-service channel, say what you did; if you have not, say so plainly and say what you would ask a digital team first. |
| F9 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Your words: "I haven't presented to anyone above regional level." Then how you would learn it, said as a plan and never as a past: for example, presenting a monthly complaints report to a regional forum first. Make no claim of confidence in presenting to senior leaders. |

No requirement in this JD is a gate under the suite's definition, so no row is `hard_gate`. "4+ years" is a length of experience and is graded like any other row.

## Prohibited claims

These are not coached in any answer, hold or bridge. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned complaints end to end across branches and the contact centre | Inflated form of F3 | "I handled the branch's formal complaints log." Your material shows one branch's log. |
| Handled regulated complaints | Inflated form of F2 | "I handled the branch's formal complaints log." Whether it was regulated is an answer slot. |
| Reported resolution times | Inflated form of F4 and F5 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Coached branch supervisors on escalations | Inflated form of F7 | "I trained new tellers on our escalation script." |
| Advanced Excel | Inflated form of F6 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Presented to senior leaders | Negative you stated, F9 | Plain acknowledgment: "I haven't presented to anyone above regional level." No slot. |
| Contact-centre experience | Negative you stated, F3 | Plain acknowledgment: "I haven't worked in a contact centre." No slot. |

## Persona table

Weights come from the relationship priors, adjusted by the round the email describes. No interviewer profiles exist yet, so there is no interviewer read.

| Round and persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Recruiter screen: Conversational, light Skeptic | Friendly opener, then pay, notice, location and reason for leaving | High for Conversational: the recruiter is screening logistics and motivation in a relaxed register. Medium for Skeptic: the recruiter will check the complaints scope against the JD. | Treat casual questions as scored. Give the logistics as your own figures or choices, not guesses. |
| Head of Member Services (45 min, future manager, mostly behavioural): Values/Behavioral | STAR-shaped prompts mapped to the four values | High: the email says the round is mostly behavioural, and the manager will weigh the values. | Map a story to each value where you have one. Where you do not, say so and give the nearest thing you did. |
| Head of Member Services: Skeptic | Quiet probing of F3 (contact centre), F9 (senior presentation) and "why now" | High: the manager is the person who would carry the gaps. | Rehearse B1 until it is plain. Hold what you did; concede what you have not done. |
| Head of Member Services: Pressure | Time-boxed challenge on one claim | Medium: a 45-minute round tends to include one. | Pause, restate, hold through two follow-ups, then concede the specific limit. |
| Panel (60 min, includes 20-min case, values scored): Values/Behavioral | Values-mapped prompts; the panel scores each value | High: the recruiter says the panel scores against the four values. | Use the values cheat sheet below. |
| Panel: Case/Strategist | The 20-minute complaint-escalation case, and strategy questions | High: the case is stated in the email; strategy questions are likely from the brief. | Clarify, own, contact, fix, record. Think aloud. |
| Panel: Data-Driven Prober | Asks how the spreadsheet counted things | Medium: the branch managers may read the numbers closely; no profile says so. | Say what the spreadsheet counted and what it left out. |
| Panel: Peer Evaluator | Seams between branches and the contact centre | Medium: branch managers may be peers, and a peer reads the seam. | Propose seam principles. Do not pretend to know their seam. |

## Question banks

Question types: VAL, EXP, JD, CO, CASE. Provenance is the candidate's own sentence the guidance rests on, quoted exactly.

### G. Recruiter screen (30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through your background." | JD, EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | A 90-second arc in this order: retail banking, the complaints log, the escalation training, the monthly spreadsheet. Use only those sentences, in your own words. | Conversational, but scored. F1 and F2 are the opening facts. |
| G2 | "What pay are you looking for?" | JD | [generic] | Logistics slot: give your own figure, or ask for the band before naming one. | Recruiter logistics. The material has no pay figure, and none is supplied here. |
| G3 | "What's your notice period?" | JD | [generic] | Logistics slot: give the notice you actually owe. | Recruiter logistics. No notice figure is in the material. |
| G4 | "Where are you based, and what travel can you do?" | JD | [generic] | Logistics slot: give where you live and the travel you can actually do. | Recruiter logistics; the role's location terms are not in the JD. |
| G5 | "Why are you leaving your current role?" | EXP | [generic] | Logistics slot: give your reason in your own words. | Motivation consistency. Your reason is not stated in the material. |

### A. Head of Member Services (behavioural) and panel values

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about a time you put a member's outcome ahead of the script." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: pick a time a member's outcome made you depart from a rule or script. If none comes to mind, say so plainly, then give the nearest thing your material carries: the escalation script you trained tellers on, and what you would change in it to put the member first. | Members First is scored. F7 is the nearest evidence, and it does not carry a member decision. |
| A2 | "Tell me about a time a member needed something explained more than once." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: pick a time a member needed a second explanation, and what you changed. If none comes to mind, say so, then give the script you trained tellers on and how you would make its wording plain. | Plain Words: "if a member needs it explained twice, we wrote it wrong." |
| A3 | "Tell me about a complaint you kept until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick one complaint you kept until it was solved, in order: what you found, what you owned, when it closed. The quote carries handling the log; it does not carry holding a complaint to its close. Answer slot: if the log closed complaints without you following them through, say so and say what you did about open ones. | Own the Fix. F3 and F2 are the nearest evidence. |
| A4 | "When did a number point one way while a branch's town needed another?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold: pick a time a figure did not capture what a member or town needed. Say what the number was, what it missed, and what you did. If none comes to mind, say so, then give the spreadsheet and what it does not show. | Neighbours, Not Numbers. The spreadsheet is numbers, so this is the value most at risk. |
| A5 | "Tell me about a time you put a member ahead of an internal target." | VAL | [generic] | Selection scaffold: pick a time a member's need beat a target. If none comes to mind, say so plainly. No sentence of yours carries this one. | Persona stem for Values/Behavioral. No claim about your past. |
| A6 | "How would you coach a branch supervisor who is escalating too often?" | JD, CASE | [grounded] "the last 3 as a branch supervisor"; "trained new tellers on our escalation script" | Say how you would coach, in your own words. Answer slot: if you coached a supervisor on escalations, say what you did; if you did not, say so and say what you would check first, such as a sample of their escalated cases. | JD: "coach branch supervisors on escalations" (F7). |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked in a contact centre. How would you own complaints across one?" | JD, EXP | [grounded] "Never worked in a contact centre" | **Highest-ROI prep in this pack.** Hold with what you did: the branch log, from intake to close, in your own words. Hold through two follow-ups by returning to the log. Concede the specific limit: you have not run a contact-centre queue. Then a plan, not a past: what you would learn first, such as queue volumes and how complaints reach branches. Rehearse this until it is plain. | F3 is the gap every interviewer will test. Calibrated candour beats bluffing. |
| B2 | "You haven't presented above regional level. Why would senior leaders trust a monthly report from you?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then what you would do to earn trust, as a plan: for example, a trial report with one worked example. Do not defend the gap. | F9. The acknowledgment is your own sentence. |
| B3 | "Why leave branch supervision for this role?" | EXP | [grounded] "the last 3 as a branch supervisor" | Give the motivation in your own terms. Do not describe the role as a step up or a step down. | Why-leave probe. Grounded in one quote only. |

### C. Case and strategy (panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member's complaint about a charge has passed between a branch and the contact centre for three weeks. The member is angry and the file has no owner. Walk us through what you do." | CASE, JD | [generic] | Structure aloud: clarify the facts; name one owner today; contact the member with a plain answer and a date; find where the file stalled; fix the handover; record it. Speak in 90 to 120 seconds. Make no claim about a past case. | This is the panel's 20-minute case. Own the Fix and Members First are scored here. |
| C2 | "Eight branches are moving into five hubs over 2027. Which complaints are most at risk in that move, and what do you do first?" | CO, CASE | [grounded] "consolidate eight branches into five hubs over 2027" | Clarify which complaints are open when a branch closes. First step: a list of open complaints by branch, owner and date. Then contact the members affected. Make no claim about any hub move you have done. | Strategy from the brief. Neighbours, Not Numbers applies: each branch is part of its town. |
| C3 | "Forty percent of member service is moving to digital by 2028. Which complaints should never move to self-service, and why?" | CO, JD | [grounded] "move 40% of member service to digital channels by 2028" | Name a category of complaint that should stay with a person, such as one involving money at stake or a vulnerable member, and say why. Speak it as your view, not as past practice. | Links the JD's self-service line (F8) to the strategy. |

### D. Data and the spreadsheet

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What did your monthly complaints spreadsheet count, and what did it leave out?" | EXP, JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what it counted, in your words, and what it did not. Answer slot for resolution times: if it recorded how long complaints took to close, say how that was counted; if it did not, say so plainly and say what you would track first. | F4 and F5. Resolution times are the JD's gap. |
| D2 | "Which assumption behind your complaints numbers would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Weakest-assumption move: name the assumption you are least sure of before they do. If the spreadsheet carried no assumption you can name, say so plainly. | Persona stem for the prober. |
| D3 | "Walk me through how you built the spreadsheet, step by step." | EXP, JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what you built, what came from elsewhere, and which tool it was. Answer slot: if it was Excel and you wrote the formulas, say so; if someone else set the structure, say so plainly. | F6: "comfortable with Excel reporting". |
| D4 | "What made the branch's formal complaints log formal?" | JD, EXP | [grounded] "I handled the branch's formal complaints log" | Say what made it formal, in your own words. Answer slot: if regulatory rules or timescales applied, say which and how you worked to them; if none applied, say so plainly. | F2: "experience handling regulated complaints". |

### E. Peer evaluation (panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam between the branch and the contact centre, and what happens when we disagree?" | JD, VAL | [generic] | Propose seam principles, such as one owner per complaint and one shared log. Do not pretend to know their seam. If you have a disagreement story in your material, use it; if not, say how you would disagree and then commit. | Peer Evaluator. Branch managers may be peers. |
| E2 | "How do you handle credit when a complaint fix spans two teams?" | VAL | [generic] | Name whose fix it was and what others contributed. Do not claim team outcomes you did not own. | Own the Fix, and turf awareness. |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Pause and restate the question. Anchor in the two quotes. Hold through two follow-ups. Concede the specific limit: you have not worked in a contact centre. | Pressure persona, time-boxed. |
| F2 | "That spreadsheet. How much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold "I built it." If the regional manager changed it afterwards, say so plainly and say what you changed yourself. | Attribution under pressure. |

### Coverage of the JD

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | G1 |
| Experience handling regulated complaints | D4, A3 |
| Own the member complaints process end to end across branches and the contact centre | B1, C1, A3 |
| Report monthly on complaint volumes and resolution times | D1, D2 |
| Coach branch supervisors on escalations | A6 |
| Work with digital teams on self-service journeys | C3 |
| Confident presenting to senior leaders | B2 |
| Comfortable with Excel reporting | D3 |

Session total: 25 questions across five personas and two rounds.

## Values cheat sheet

The recruiter says the panel scores against these four values. Your material carries no story that is a clear fit for any of them, so each row is a selection scaffold ending in its honest branch.

| Value (official name) | Working meaning (paraphrase) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F7 carries training, not a member decision. Use A1. If none comes to mind, say so and give the script you trained tellers on. |
| Plain Words | If a member needs it explained twice, the wording was wrong | F7 again. Use A2. Honest branch: say so, then give the nearest wording you changed. |
| Neighbours, Not Numbers | Every branch is part of its town | F4 is numbers, so this is your riskiest value. Use A4. Honest branch: say what the numbers missed. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F2 carries handling the log, not holding a complaint to its close. Use A3. Honest branch: say what you did with open complaints. |

## Reverse questions

1. To the Head of Member Services: "What would a good first 90 days look like for the complaints process?" Why it lands: it asks what ownership means at manager level.
2. To the Head of Member Services: "How will the 2027 hub moves change where complaints are handled?" Why it lands: it shows you read the brief and ties the question to the job.
3. To the Head of Member Services: "Where does the digital self-service plan stand, and which complaint types come up first?" Why it lands: it names the JD's digital line and asks for the order.
4. To the panel, a peer reciprocity question: "What could someone new do in their first month that would genuinely help your branches?" Why it lands: it turns the panel toward what you would bring to their teams.
5. To the panel: "What do your supervisors find hardest about escalations today?" Why it lands: it shows you are listening to the branch side of the work, which is the coaching requirement.
6. To the recruiter: "How is the 20-minute case set up? Is there a written complaint file in advance?" Why it lands: it lets you prepare the case's format, not just its content.

## Grounding brief

From the July 2026 strategy brief, as relayed to you by the recruiter. No later sources were checked, and no deep research ran.

- Digital: "move 40% of member service to digital channels by 2028." Used in C3.
- Branches: "consolidate eight branches into five hubs over 2027." Used in C2. Do not assert that your current branch is affected.
- Lending: "launch a small-business lending product in Q1 2027." Vocabulary only; no question uses it.
- Competition: the main pressure is app-only banks. Vocabulary only.

Nothing in the brief is flagged as stale, because no later source was checked.

## Sources

Provided documents: the JD and the values text (both pasted into your request); the recruiter's email on the rounds (summarised in your request); the July 2026 strategy brief (as relayed in your request); your background (your message). No CV was provided.

Research tier: L1, searches 0 of 6, fetches 0 of 2. No call was sent: every target is fixed by the inputs.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text pasted from the values page this morning fixes the four values and the cheat sheet. |
| 2. Interview process | skipped | The recruiter's email fixes the three rounds, the panel's values scoring and the 20-minute case. |
| 3. Strategy and recent news | skipped | The July 2026 brief fixes the current priorities used in C2, C3 and the grounding brief. A news search could only add later events. |
| 4. Interviewer name | n/a | No names were given, so there was no query to form. The interviewer read is absent. |
| 5. Representative JD | skipped | The JD pasted in your request fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Your CV → every "your message" evidence cell becomes "your CV", and dates and titles can be checked against it.
- An anonymised copy of the monthly complaints spreadsheet, with no member data → F4 and F6 move from a sentence about the spreadsheet to an inspectable artifact, and D1 to D3 can be checked against it.
- Two or three complaints you handled, in order, in your own words → A1 to A4 and A6 become story-mapped answers in place of scaffolds.
- Interviewer names → persona weights for each panel member, and a reverse question tied to their career path.
- Whether the 20-minute case is a written brief sent ahead or a live verbal case → C1 gets a prep schedule.
- The recruiter's prep email, if it lists anything else → coverage of any pre-declared deliverable.
- A tuesday-dossier.md, if one exists from an earlier session → verified evidence and the prohibited list carried in without re-asking.
