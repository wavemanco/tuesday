Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-2-denied-a6608726/e1abca4d-7554-49e5-853b-e0c3f66fe21b/scratchpad/atlas-freight_operations-manager_interview_pack.md`. I built it for a full loop with flat weights, since your note didn't say who you're meeting, so it's weaker than it could be.

**What the pack says:**

- **The scope gap is the main risk.** The JD asks for four sites and 12 supervisors. Your material shows one shift-level role over three supervisors. Question A1 presses both at once, so rehearse it first.
- **Power BI is a stated gap.** Say "I haven't used Power BI" plainly, then give a learning plan. Don't describe any use.
- **The 40% mis-pick figure is your strongest number, but it isn't the JD's metric.** The JD asks about on-time performance and cost per shipment. You have no number for either, so expect a probe. Be ready to say the mis-pick figure is what you moved.
- **"Ran" stays "ran."** Don't upgrade it to "designed" or "owned." The pack's prohibited list flags those stretches.
- **Your 5+ years of leadership is unclear.** Seven years in operations and a current leadership role don't show how many years were leadership. Question 2 below asks.

**Three questions that would sharpen it:**

1. Who is the round with: hiring manager, peer, panel, or recruiter? Does the recruiter's note say what will be covered or name a deliverable?
2. Does your 5+ years include leading people above shift level, or owning a budget or cost target?
3. Should I run research on Atlas Freight at the default depth (up to 6 searches and 2 page fetches) to check their values and interview format? Without it, the company-level parts are generic.

**Offers, not pushed:**

- I can play the Skeptic on A1, the highest-ROI rehearsal, and give you feedback against its guidance.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
- I can convert the pack to a Word document.

Watch-out: Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Atlas Freight: Operations Manager interview prep pack

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** not named. Round type not yet known.
**Built as:** a full-loop pack with flat persona weights. That is noticeably weaker than a pack built for a known round. The upgrade menu says what would fix it.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values), EXP (your experience, probed), JD (the job's stated requirements), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Say it in your own words, and only the parts you actually did.

## Fit snapshot

Requirements come from the job description you pasted. Evidence comes from your message, which stands in for a CV because none was provided.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | low | [grounded] | transferability | Your material shows a shift-level role over three supervisors. Four sites are not in it. Words for you: "currently a senior shift manager over 3 supervisors." Answer slot: if you have run operations across more than one site, say which and what you were accountable for, in your own words. If not, say so plainly and say how you would get four sites running in your first 90 days. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Three supervisors, quoted at that scope. Twelve is not in the material. Answer slot: if you have led a layer of more than three supervisors, say how many and how it was structured, in your own words. If not, say so plainly and say how you would structure a team of twelve. |
| F3 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | low | [grounded] | hard_gate | Your material does not establish the leadership years. It gives seven years in operations and a current leadership role, and does not say when leadership began. This cell asks nothing. Step 1 question 2 asks whether the gate is met. |
| F4 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | No gap: the credential is stated. Words: "green belt certified." A certificate with no applied project behind it draws a probe. See A5. |
| F5 | "build reporting in Excel/Power BI" (JD, Excel part) | "solid Excel" (your message) | medium | [grounded] | none | Excel reaches the requirement. Say it in the quote's terms: "solid Excel." A named report you built in Excel is an answer slot, not a bridge: name one if you built one, and say so if you did not. |
| F6 | "build reporting in Excel/Power BI" (JD, Power BI part) | "never used Power BI" (your message) | none | [grounded] | capability | A stated negative. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller. |
| F7 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | presentation | Your quote reaches the requirement in other terms: it is a cut in a quality rate, not in on-time performance or cost per shipment. The bridge rewords only that quote: "I cut the mis-pick rate 40% by redesigning the pick path." It adds no figure. |
| F8 | "drive on-time performance and cost-per-shipment down" (JD) | none given | none | [grounded] | discovery | Your material does not show either metric moved. Answer slot: if you moved on-time performance or cost per shipment, say which, the figure, and how it was measured, in your own words. If not, say so plainly and give the nearest number you did move, which is F7's. |

**Reading the snapshot:** the material is strong on the process side (F7, F4, E1) and thin on scope (F1, F2, F3) and on the two JD metrics (F8). Those thin rows are where the interview will press.

## Prohibited list

Claims this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across four sites | Inflated form of F1 | "currently a senior shift manager over 3 supervisors," at its own scope. Your material does not show multi-site scope. A1's slot stays inside what you ran. |
| Leads twelve supervisors | Inflated form of F2 | "currently a senior shift manager over 3 supervisors." The twelve is not in the material. A1's slot asks only how many you have led. |
| Moved on-time performance or cost per shipment | Inflated form of F7 | The mis-pick quote at its own scope. F8's slot asks only what was moved. |
| Designed the peak-season surge plan | Inflated form of "ran the site's peak-season surge plan two years running" | The quote as written. The verb is ran. |
| Led Lean or Six Sigma projects | Inflated form of F4 | "green belt certified." E3's slot asks where it was applied. |
| Built Power BI reporting | Stated negative, F6 | "I haven't used Power BI." No slot. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic | Probes the scope gaps: sites, team size, the reporting tool | Top weight. The JD names four sites, twelve supervisors and a reporting tool. Your material shows one shift-level role over three supervisors and a stated Power BI gap. With no round type known, this is the flat-weight default for a hiring-manager loop. | Rehearse A1 until it is plain. Name the gap before they do. | 5 |
| Data-Driven Prober | Asks how the 40% was counted and what the cost and on-time figures are | High. One headline figure in your material, and the JD's cost and on-time lines have no number behind them. | Name the baseline and the assumption you know. Say plainly when you do not know. | 4 |
| Case / Strategist | Live terminal problems across the sites | High for an operations role. The JD describes live operations. | Clarify, segment, choose metrics, then risks. | 4 |
| Pressure / Stress | "Why you over someone with more scope?" | Medium. The 3-versus-12 contrast invites it. | Hold through two follow-ups, then concede specifically. | 3 |
| Conversational / Rapport | "Walk me through the journey." A casual Power BI question. | Medium. Casual openers are scored. | A 90-second arc. No bluffing on Power BI. | 3 |

Nineteen questions in total, inside the 18-to-26 range for a pack this size.

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A1, A4, C1 |
| Drive on-time performance and cost-per-shipment down | B3, C2, C4 |
| Lead a team of 12 supervisors | A1, D1, D3 |
| Build reporting in Excel/Power BI | A3, A4, C3, E2 |
| 5+ years operations leadership | A2 (gate; surfaced, not bridged) |
| Lean/Six Sigma a plus | A5, E3 |

## Question banks

### Skeptic (weight: top, 5 questions)

**Highest-ROI prep: A1.** It presses both scope gaps at once, and it is the one most likely to be asked in some form.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The role runs four sites and twelve supervisors. Your current team is three. What makes you ready for that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "7 years in warehouse and distribution ops" | Give the seven years at their own scope, then the current role. Answer slot: if you have run more than one site or led more than three people, say what, in your own words. If not, say so plainly, then say what you would do in the first 90 days to learn four sites. | F1 and F2 are both gaps, and this question presses both. The question's premise (four sites, twelve supervisors) comes from the JD. |
| A2 | "Five years of operations leadership is a requirement. Take me through the years that count." | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Premised on the JD's 5+ line. Give the seven years and the current role at their own scope. Answer slot: if any of those years were leadership above shift level, say when and what you led, in your own words. If the leadership years are fewer than five, say so plainly. Never round a year up. | F3 is a hard gate the material does not establish. The honest answer is the count itself. |
| A3 | "The role builds reporting in Power BI. Where are you on it?" | JD | [grounded] "never used Power BI" | Plain acknowledgment: "I haven't used Power BI." Then how you would learn it, as a plan. No answer slot. | F6 is a stated negative. This is the question you will almost certainly get. |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; "currently a senior shift manager over 3 supervisors" | Answer in the JD's own order: scale first, then reporting. Say each gap in one sentence at your quote's scope, then the one thing you would do first. Do not name a strength to soften it. | F1, F2 and F6 are the honest answers. The JD supports the premise that a gap exists. |
| A5 | "You're green belt certified. Where have you applied it?" | JD | [grounded] "green belt certified" | Premised on application, which the quote does not carry. Answer slot: if you applied the methodology, say where and what you did, in your own words. If the certificate is the extent of it, say so plainly, then name the one place you would apply it in this role. | F4 has no applied project in the material. The second branch keeps the answer honest. |

### Prober (weight: 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Defend the number. Say the baseline period and how mis-picks were recorded, in your words. Name the assumption you would defend least before they do. Answer slot: if you know the baseline and what the rate was divided by, say both. If you do not know how it was counted, say so plainly. | A headline figure is a magnet for a prober. The material gives no denominator, so the pack supplies none. |
| B2 | "Which part of the pick path did you change, and which part was your call?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Story-mapped on the sentence: you redesigned the pick path, and the 40% is the result it carries. Answer slot: if you designed the change, say what you changed. If others shaped it, say which parts were yours, in your own words. | An attribution probe on the same figure. "Redesigning" is a verb you must own precisely. |
| B3 | "The role targets on-time performance and cost per shipment. Which of those have you moved, and how did you measure it?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you moved on-time performance or cost per shipment, name which, the figure, and how it was measured, in your words. If you did not, say so plainly and give the mis-pick figure at its own scope. | F8 is a discovery gap: the JD raises both metrics and the material shows neither. |
| B4 | "You ran the peak-season surge plan two years running. What did the plan do, and what would you change?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Story-mapped: the plan, run two years in a row. Hold the verb: ran, not designed. Say what you would change in your own words. If you would change nothing, say why. | A second headline the prober may test. It is also your strongest operational story. |

### Case / Strategist (weight: 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two of your four terminals are running late at peak. What do you look at in your first week?" | CASE | [generic] | Clarify the on-time measure and the peak volume. Segment by terminal, shift and lane. Name the metrics that would move on-time performance. Say what you would change first and what you would leave alone for now. Think aloud, and name one risk. | A live problem drawn from the JD's first line. It is scored on structure and makes no claim about your past. |
| C2 | "Cost per shipment rose 8% quarter on quarter at one site. Diagnose it." | CASE | [generic] | Decompose the cost: volume mix, labour hours per shipment, overtime, rework and mis-picks, one-off events. State your first cut and what would prove it wrong. Do not claim a measured result. | The JD's cost line as a live problem. The 8% is a case figure, not a fact about you. |
| C3 | "Four sites, one monthly operations report, and you've not used Power BI. How would you build it?" | CASE | [grounded] "solid Excel"; "never used Power BI" | Start with the decision the report serves, then the five or six metrics, then the source data. Start in Excel, the tool you have described as "solid Excel." Say that Power BI is the next step, and the plan for it, as a plan. | The JD's reporting line in case form. It uses only what you have said. |
| C4 | "What would you measure in the first 90 days to know a site was improving?" | JD | [generic] | Name three measures tied to the JD's two metrics. Name a baseline step before any target. Say how you would share the measures with supervisors. No claim about your past. | The JD's on-time and cost lines, in planning form. The Skeptic may ask it in another form. |

### Pressure / Stress (weight: 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run four sites?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path" | Hold: lead with the seven years and the 40%, in your words, then stop. Hold through two follow-ups by returning to what you did. Concede the scope difference specifically, in your own words. Never claim the four sites. | The 3-versus-12 contrast invites this. The hold is what you actually did. |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold-then-concede. Hold the position you stated: you cut the rate by redesigning the pick path. Concede any shared parts in your own words. Answer slot: if others worked on it, say who and what they did. Do not fold on the redesign itself. | Pressure on attribution. The hold is the sentence you already said. |
| D3 | "Two years of a peak plan isn't a track record for a role this size. Why would it scale?" | JD | [grounded] "ran the site's peak-season surge plan two years running" | Hold on the two years as you ran them. Concede uncertainty about scale in your own words, and name one thing you would check first. Do not stretch "two years" into a claim about four sites. | The honest answer is the quote at its own scope, plus a specific concession. |

### Conversational / Rapport (weight: 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified" | A 90-second arc in this order: the seven years, the current role, the pick-path change, the green belt. Each beat is one of the quoted sentences, said in your words. | The opener is scored. A clean arc is one you can rehearse cold. |
| E2 | "What are you actually playing with in Power BI these days?" | JD | [grounded] "never used Power BI"; "solid Excel" | Plain acknowledgment: "I haven't used Power BI." Then Excel, in the quote's terms. Do not describe any Power BI use. | A casual question on a JD topic is still scored. This is the trap a rapport interviewer sets. |
| E3 | "What did the green belt change in how you work?" | EXP | [grounded] "green belt certified" | Premised on a change the quote does not carry. Answer slot: if it changed how you work, say how and where. If it stayed a certificate, say so plainly. | A casual version of A5, with the same honest second branch. |

## Reverse questions

Asked of the interviewer. There is no profile, so none ties to their career path. Ask one or two, not all.

| Question | Why it lands |
|---|---|
| "What does success look like in the first six months across the four sites?" | Shows you are thinking about the actual scope, not the title. |
| "How is on-time performance measured across the terminals today, and who owns that number?" | Puts the JD's first metric on the table and shows you know it is the job. |
| "What reporting do the site leads use now, and what is missing from it?" | Sets up the Excel and Power BI conversation on their terms. |
| "What is the team's biggest open problem right now?" | Invites a peer-level answer and tells you where the pressure sits. |
| "What would make you say the first year in this role went well?" | Gives you their success measure in their own words, to use later. |

## Sources

- **Provided documents:** the job description you pasted, and your message. No CV was provided, so your message stands in for one.
- **Research tier:** L0. No searches or page fetches have been run. Research depth is a question for you (see the questions after the pack).

| Target | Status | What it would have moved |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet, which is absent without it. Company-level guidance stays generic. |
| 2. Atlas Freight interview process, operations manager | unavailable | Loop structure; would replace the flat persona weights. |
| 3. Atlas Freight strategy / recent news | unavailable | Company-level CO questions; the pack has none, because none can be grounded yet. |
| 4. Interviewer name and Atlas Freight | n/a | No interviewer name was given, so there is no query to form. |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The round type and who you are meeting → replaces the flat persona weights with weights for that round, and tailors one reverse question to the interviewer.
- Your answer to question 2 in the message → F3 and A2 move from a surfaced gap to a stated count of years.
- Research at the default depth → adds values, the interview process and current company context. Rows C1 and C2 stay generic whatever the research finds.
- The interviewer's name → an interviewer read and persona weights from their public footprint.
- The recruiter's prep email → coverage of any deliverable they have named.
- How the 40% was counted → B1's answer slot becomes your own words, checked against the figure.
- A `tuesday-dossier.md`, if one exists → replaces the inferred objection in A1 with its own, and adds any verified evidence.
