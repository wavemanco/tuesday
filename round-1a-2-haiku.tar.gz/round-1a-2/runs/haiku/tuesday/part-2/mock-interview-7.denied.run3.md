Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-2-rooms-case-7-denied-08f5f8ec/d366ce3e-bb6c-4976-aca0-8635991a0454/scratchpad/saltmarsh-games_live-ops-producer_interview_pack.md. I built it for a hiring-manager round, since your note didn't say who you're meeting. Web search was refused in this session, so the pack has nothing about Saltmarsh's values, interview loop, strategy, or Tobias himself. Those sections are marked unavailable, and the upgrade menu says what would fill them.

The most important prep is the question B1: your title is associate producer, and the JD asks for 3+ years producing live-service games. Rehearse the calendar as the thing you ran end to end, and concede plainly anything you didn't own. The pack also has a plain acknowledgment for the two gaps you named, never having led a team and never having worked on an in-app-purchase game.

Say the word and I'll run a drill as Tobias on B1, the question the pack names as its highest-ROI prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, or is this a different kind of round? And has the recruiter announced any deliverable, such as a plan or presentation, for the 60 minutes?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-ops-producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep pack

**Role:** Live Operations Producer. **Company:** Saltmarsh Games (mobile, about 350 people). **Interviewer:** Tobias Wrenfield, Head of Live Operations. **Round:** a 60-minute conversation, assumed to be a hiring-manager round because the interviewer heads the function. Not confirmed; see the upgrade menu.

## How to use this pack

- **Personas** describe how a question will arrive. **Types** describe what is being scored.
- **Types:** VAL = behavioural or values fit. EXP = your past experience, probed. JD = a stated requirement. CO = company knowledge. CASE = a live problem.
- Guidance is scaffolding for a spoken answer, not a script. Say only what your quotes support.

## 4. Fit snapshot

Requirements are quoted from the JD you pasted. Your evidence is quoted from your message. Nothing else is cited.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title, not two, so do not claim two. Words: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned for more than one title, say which and how; if you did not, say so and say how you would plan two. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination across these four teams. Answer slot: name the teams that touched one of your content drops and what you did to get their part done; if none of them touched it, say so. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Presenting numbers is not owning the review or choosing the KPIs. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs went in or ran the review, say which and how; if not, say so. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Expect a probe on how it is kept up day to day. Lead with the quote: "I wrote the release checklist our QA team still uses." |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | Years are not a gate, and the title is associate producer. Your material does not say live-service. Words: "Four years as an associate producer at a puzzle-game studio." Answer slot: name which parts of that work were live-service and which you carried from start to finish. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on scope. Lead with the quote. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on how the figures were counted (see C3 and A5). Lead with the quote. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | One written artifact is in the material. Say that one artifact, and no more. |
| F9 | [generic] team leadership (JD does not name it) | "Never led a team" (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't led a team." Then how you would learn to coordinate without managing, as a plan and never as a past. |
| F10 | [generic] monetised mobile titles (JD does not name it) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't worked on a game with in-app purchases." Then how you would get up to speed, as a plan and never as a past. |

**Gates:** the JD text states none (no location, schedule, licence or travel term), so no row is `hard_gate`.

## 8. Persona table

Relationship is assumed to be hiring manager. No interviewer profile or loop source was available, so these weights rest on the relationship prior alone, not on this company's documented process. No values-style round is detected.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live calendar and launch problems from the role | Top, 5 questions. A hiring manager is buying capability on the live calendar | Clarify, then objective, then approach, then metrics, then risks. Say the framework aloud |
| Skeptic | Probes the gaps: title, team leadership, in-app purchases | 4 questions. The gaps in F5, F9 and F10 are where this interviewer will press | Rehearse the predictable objection until it is plain. Concede specifically, never bluff |
| Data-Driven Prober | Asks how figures were counted | 3 questions. Every headline figure invites it | Say how it was counted, in your own words. Name the weakest assumption before they do |
| Pressure / Stress | Time-boxed challenges to your case for the role | 3 questions. Tests composure against a stronger candidate | Pause, restate, hold two follow-ups, then concede only what is true |
| Values / Behavioural | Scenario probes | 2 questions, weighted low. No values round is detected, and no company values were read | Open prompts with an honest branch when nothing fits |
| Conversational | A casual opener that is scored anyway | 2 questions. Casual questions about JD topics still count | A 90-second arc from your quotes. Never answer "I think you've covered everything" |

## 9. Question banks

Questions are numbered by persona. Each guidance cell rests only on the sentences in its Provenance cell.

### A. Case / Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A content drop went out on Thursday, and retention on one of your titles fell in the week after. Walk me through what you would check first." | CASE | [generic] | Clarify what fell and against which baseline. Then split by platform, cohort and region. Then check what else shipped that week. Say the order aloud. Do not name a figure you do not have. | A live problem from the KPI-owning requirement (F3). Generic because it is a method, not a claim about your past. |
| A2 | "Plan the next six weeks of live events for two mobile titles. What do you need to know first?" | CASE | [generic] | Clarify team capacity and what is already committed. Then the objective. Then sequencing around each team's lead time. Then the release checklist step with QA. | Covers F1 and F2 as a live problem. |
| A3 | "Design, art, engineering and community all touch every update. Which would you align first, and why?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Answer by principle, not history: the team whose lead time sets the date, then the team whose sign-off can stop the update. Say what you would need from each. Make no claim about past coordination. | Covers F2 without asserting a past. The JD line is the raising source. |
| A4 | "Walk me through how you ran the weekly content-drop calendar for your main title." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Story-mapped from that sentence: the weekly calendar, the main title and the two years, in your own words. Answer slot: expect a probe on how the calendar was set against other teams' work. If you set the order, say how you decided it; if it was set for you, or another team set it, say so and describe your part. | F6 is the evidence for the calendar requirement. The slot's second branch lets the practice be someone else's. |
| A5 | "The retention numbers you presented each month: how were they counted, and which assumption would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Defend the number: say how it was counted in your own words, name the weakest assumption before they do, and say which part was yours. Answer slot: if you did not define the method, say so plainly. That is an honest branch. | F7. The quote carries no method, so each defend-the-number point is a slot. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your title is associate producer. Which parts of the live calendar did you produce end to end?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message) | **Highest-ROI prep in this pack.** Say the title and the years first, as quoted. Answer slot: name the parts you carried from start to finish, and where another team set a step, say so. Hold on the calendar. Never claim the producer title or live-service producing. Through two follow-ups, return to the calendar. Concede any step you did not own, in those words. | F5 is where the JD's years line presses hardest, so this objection lands in some form. A rehearsed, non-defensive answer changes the interview. |
| B2 | "You haven't worked on a game with in-app purchases. How would you get up to speed on purchase-driven events?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then how you would learn it, as a plan: which figures you would read first and whom you would ask. Never a claim to purchase-driven work. | F10. The question rests on the negative you stated, and nothing about any title's monetisation. |
| B3 | "You haven't led a team. This role coordinates four teams on every update. How do you get people to act without managing them?" | JD | [grounded] "Never led a team" (your message) | Plain acknowledgment: "I haven't led a team." Then describe any coordination that was yours, in your own words. Answer slot: if none was yours, say so and give the first thing you would do to earn each team's trust. | F9 and F2 together. The second branch allows that no such work exists. |
| B4 | "Your retention numbers went to the studio head. Did you pick which numbers, or only report them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Say what you presented and how often, in those words. Answer slot: if you chose which numbers went in, say which and why; if you only presented them, say so plainly. Do not claim ownership of the metrics. | F3. The "pick" is the premise the KPI-ownership line raises, so the answer must stay in the quote's scope. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through what your release checklist covers, and who signs off each item." | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Describe what the checklist covers, in order, from the checklist itself. Answer slot: sign-off practice is not in your material. If you set sign-off, say how; if QA set it, say so. | F4. Tests the QA requirement. Sign-off is a practice the question presupposes and the material does not carry. |
| C2 | "How many content drops did your calendar ship in a typical quarter, and how did you count one?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Give a count only if you know it, and say what counted as one drop. If you did not count, say so and say how you would find out before Friday. Never estimate a count you cannot stand behind. | F6. A count is a figure the candidate gives, so defend-the-number applies. The question asks for one and supplies none. |
| C3 | "A retention move follows a content drop. What share could you attribute to the drop itself, and how sure are you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: if you attributed any movement, give the method and the assumption behind it. If you did not, say that plainly, and say what you would test first. "I can't attribute a share without measuring it" is a valid answer if it is true. | F7. The premise that attribution was done is not in the quote, so this stays a slot whose second branch allows that it never happened. |

### D. Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run a monetised live title?" | JD | [grounded] "never worked on a game with in-app purchases" (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message); [grounded] "Wrote the release checklist our QA team still uses." (your message) | Hold: in about 20 seconds, lead with the calendar and the checklist, in your words. Concede plainly: "I haven't worked on a game with in-app purchases." Through two follow-ups, hold on what you ran. Never fold on the calendar to restore harmony. | Pressure persona. The held position is only what the quotes carry, and the concession is the one you stated. |
| D2 | "That calendar you ran for two years: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Hold the position on the calendar: say which parts you ran. Say where others shared it. Through two follow-ups, concede a shared step specifically. | Attribution stem from the pressure persona. Tests composure and honesty together. |
| D3 | "Tell me about a time someone pushed back on a number you presented." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Open prompt: pick a time a presented number was challenged. Name the stake, what you did and how it ended. If none comes to mind, say so plainly, then give the nearest thing your material carries: the monthly presentation itself. | Open prompt on F7. Do not invent an objection to tell. |

### E. Values / Behavioural (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Open prompt: pick a time you gave a senior person a number they did not want. Name the stake, what you said and whether it landed. If none comes to mind, say so plainly, then give the nearest thing your material carries: the monthly retention presentation. | Persona stem. No values were read, so VAL is generic and weighted low. |
| E2 | "When did you put a player ahead of an internal metric?" | VAL | [generic] | Open prompt: pick one time. Name the metric and what you did instead. If no such call came up, say so, and give your nearest calendar decision. | Persona stem. Weighted low, as E1 is. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message); [grounded] "Wrote the release checklist our QA team still uses." (your message) | A 90-second arc from those sentences: the studio and the years, the calendar, the checklist, the retention presentation, and what you want next. Add no event, figure or title beyond them. | Opener scored casually. The arc uses only quoted beats. |
| F2 | "What are you actually playing in mobile live right now?" | JD | [generic] | Name a game you actually play and one thing you noticed about how its events arrive. If you do not play live mobile, say so and name what you do play. Never name a game you do not play. | Casual, but it is the JD's mobile-live topic and it is scored. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the calendar for two titles | A2, A1 |
| Coordinate design, art, engineering and community | A3, B3, A2 |
| Own the post-event review and the KPIs | A1, A5, B4 |
| Manage the release checklist with QA | C1 |
| 3+ years producing live-service games or apps | B1 |
| Experience running a content calendar | A4, C2 |
| Comfortable with player-retention metrics | A5, C3 |
| Clear written communication | none, and why: the checklist is the only written work quoted, and no question asks for a writing sample |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a successful live-events calendar look like at the six-month mark for these two titles?" | It asks for the success measure before you commit to one. |
| R2 | "Who owns the calendar across design, art, engineering and community today, and where does that break down?" | It shows you read the JD's coordination line as a real problem. |
| R3 | "How is the post-event review run now, and who sees the KPI readout?" | It separates ownership from presentation, which your F3 answer depends on. |
| R4 | "How does the release checklist work with QA now, and what changed in it most recently?" | It shows you know the checklist exists as a live process. |
| R5 | "What would you want the person in this role to deliver in the first month?" | It asks for the expectation directly. |

No interviewer profile exists, so no reverse question is tied to his career path yet.

## 13. Prohibited claims

Built locally from the fit snapshot. These claims are not coached. The honest form of each is shown.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Stated negative, F9 | Plain acknowledgment: "I haven't led a team." |
| Worked on a monetised title | Stated negative, F10 | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |
| Owned the post-event review or the KPIs | Inflated form of F3 | F3's quote at its own scope. Observation, not words for you: your material says presented, not owned. |
| Ran the calendar for both titles | Inflated form of F1 | F1's quote at its own scope. Observation: your material says one title. |
| Producer experience on live-service titles | Inflated form of F5 | F5's quote at its own scope: an associate producer at a puzzle-game studio. |

## 14. Sources

Provided documents: the JD text, and your message with the background.

Searches sent this engagement. Every call was refused by the host, so none returned a result:

- `Saltmarsh Games values`: refused
- `Saltmarsh Games interview process live operations producer`: refused
- `Tobias Wrenfield Saltmarsh Games`: refused
- `Saltmarsh Games mobile game news strategy`: refused

Fetches sent: none.

Research tier: L1 — searches 4 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Values cheat sheet, section 10: not established, so no cheat sheet was built. The search was refused by the host. |
| 2. `{company} interview process {role family}` | unavailable | Loop structure and persona weights. Not established, so the weights rest on the relationship prior alone. |
| 3. `{company} strategy` / recent news | unavailable | Current priorities for the CO bank. None were built, so no CO question appears. |
| 4. `{interviewer name} {company}` | unavailable | The interviewer read, persona weights, and a reverse question tied to his path. The name was given, so a query was formed and refused. |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Because research was refused, every company-specific fact is absent. Nothing above describes Saltmarsh's values, loop, strategy or interviewer.

## Upgrade menu

- Permission to run web search this session, or the company values page, the interview-process page and his public profile pasted in → a values cheat sheet, persona weights from the real loop, a CO bank, and a reverse question tied to his career path
- The recruiter's email on the round format → confirms whether this is a hiring-manager round, and whether any deliverable is announced
- The two titles you would run, and whether either earns through in-app purchases → turns F1 and F10 from slots into grounded lines
- A figure you actually counted for the calendar, such as drops per quarter → C2 and A5 can be rehearsed with a number you can defend
- What the design, art, engineering or community teams did on one of your content drops → upgrades F2, A3 and B3 from slots to grounded lines
- The release checklist text → C1 can name what it covers, rather than asking you to recall it
