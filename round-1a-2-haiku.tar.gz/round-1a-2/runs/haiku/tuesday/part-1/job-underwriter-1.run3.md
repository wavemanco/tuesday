**Yes, apply, with conditions.** On fit you read as a strong match for the analytics core. The gaps are healthcare data, clinician partnership, and mentoring, and none of them is a hard gate. Status: `conditional_go`, not `go`, because I could not verify the employer or the posting from here.

## Decision snapshot

**Yes, on fit: R1, R2, R3, R4, R6 and R9 read `direct`, and no hard gate is stated. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6 · adjacent: R5 (metrics layer)
- `important` — direct: R9 · unclear: R8 (mentor two junior analysts) · absent: R7 (partner with clinicians)
- `preferred` — adjacent: R10 (healthcare data)

R3 — the 11% lift needs its method stated; R5 — ownership of a company-wide metric layer is unconfirmed; R7 — no clinician-facing work to point to; R8 — mentoring is unknown; R10 — HIPAA is not exercised, though consent work transfers.

**Opportunity ledger.** The posting is specific about deliverables (RR5). Location, pay and the employer's existence are unverified (RR1, RR2, RR3), and the scope is broad (RR4, low).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Harborlight's own careers page (RR3); (2) location and pay fit your terms (RR1, RR2); (3) R7 and R10 are described as adjacent work, never as clinical or HIPAA experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C | `[grounded]` posting text as provided; not verified here (RR3) |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, mentoring | `[grounded]` posting text |
| Scope read | A senior individual-contributor remit with mentoring added | `[inferred]` from the responsibility list |
| Market calibration | Not run; search was unavailable | — |
| Unknowns | Location and remote policy, pay, contract type, whether clinicians are in-house, HIPAA-covered status | — |
| Contradictions | None detectable in the text provided; no live posting checked | — |

## Evidence map

Your background is prose, so the ceiling is `medium` and nothing reaches `high` yet.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company, stated in prose | `[grounded]` your background | Confirm dates with a CV |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake; "expert" rests on daily use | `[grounded]` your background | Offer a sanitized query sample |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran 30+ tests a year, including a pricing test with an 11% retention lift. Relative or percentage points is unstated | `[grounded]` your background | Be ready to state the lift's basis and sample |
| R4 | Looker or similar, self-serve dashboards | must_have | direct | medium | none | Built the Looker instance; 40+ governed dashboards | `[grounded]` your background | Offer a dashboard or governance doc |
| R5 | Own the metrics layer | must_have | adjacent | medium | transferability | Governed dashboards and definitions; no statement that you owned a company-wide metric dictionary | `[inferred]` from governed dashboards | Ask whether a metric dictionary or LookML was yours |
| R6 | Partner with PMs; turn analysis into roadmap decisions | must_have | direct | medium | none | Monthly metrics memo to the exec team; monthly presentation to the VP Product | `[grounded]` your background | none |
| R7 | Partner with clinicians | important | absent | none | transferability | No clinician work; nearest is non-technical exec and PM stakeholder work | `[grounded]` absence in background; `[generic]` that clinician partnership is usually a differentiator | Frame as stakeholder work; ask about clinical contact |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Not mentioned | `[grounded]` absence in background | Ask (closing questions) |
| R9 | Written communication with non-technical stakeholders | important | direct | medium | none | The monthly exec memo is the evidence | `[grounded]` your background | none |
| R10 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model transfer. No PHI or HIPAA-covered work. Preferred, not a gate | `[grounded]` background; `[generic]` that HIPAA is a separate regime from GDPR/CCPA | Ask whether any health data touched the consent model |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Clinician partnership (R7, important) | transferability | Non-technical exec and PM work; no clinical contact | Likely raised in interviews | Defining metrics with ops, finance or legal; explaining results to specialists | A memo or readout written for a non-specialist | `[inferred]` bridge; `[generic]` that clinician contact is probed |
| G2 | HIPAA (R10, preferred) | transferability | Consent and PII work, consumer only | Preferred, so a lesser risk | Consent-state design, data minimization, access controls | Sanitized consent-model doc | `[grounded]` background; `[generic]` HIPAA differs |
| G3 | Mentoring (R8, important) | discovery | Nothing stated | Named responsibility | Onboarding analysts, reviewing their SQL or tests | A review or onboarding example | `[grounded]` absence |
| G4 | Metric layer ownership (R5, must_have) | transferability | Governed dashboards; no stated metric dictionary | Named responsibility | Owning metric definitions, a metric dictionary | A definition doc or LookML sample | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location and remote policy absent | unknown | — | (absent from the text provided) | Location could rule the role out for you | `[inferred]` from the text provided | Is this role remote, hybrid or on-site, and in which cities? | unresolved |
| RR2 | Pay absent | unknown | — | (absent from the text provided) | Pay may sit outside your expectations | `[inferred]` from the text provided | What is the base salary range, and is equity included? | unresolved |
| RR3 | Employer and posting unverified here | unknown | — | "Harborlight Health" | The posting may be live; this session could not check | `[grounded]` search unavailable, see research line | Can you point me at this role on Harborlight's own careers site, and who would I interview with? | unresolved |
| RR4 | Broad remit: all analytics, plus mentoring and clinician partnership | risk_signal | low | "Own product analytics… mentor two junior analysts" | Ownership without stated decision rights could make this harder to deliver | `[inferred]` from the responsibility list against its silence on authority | Which analytics decisions does this role make alone, and what does clinician work involve day to day? | unresolved |
| RR5 | Concrete deliverables and named tools | positive_signal | — | "build self-serve dashboards in Looker" | Scope is defined enough to plan against | `[grounded]` posting text | Which dashboards and experiments are live that this role would inherit? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | State the 11% lift as you measured it, with its basis, before any interview use | Relative or points is unstated | `[grounded]` your figure; R3 | pending your approval |
| A2 | Describe HIPAA as consent and PII experience, not healthcare data | R10 is adjacent | `[grounded]` R10 | pending your approval |
| A3 | Describe clinician work as stakeholder work, not clinical partnership | R7 is absent | `[grounded]` R7 | pending your approval |
| A4 | Confirm pay, location and posting before tailoring an application | RR1–RR3 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report, so every claim above is unverified.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Harborlight Health (care-navigation product, Series C, the posting) were refused by the session's search permission, so the employer and posting stay unverified. Would move RR3 |
| 2. Role-family sweep | unavailable | One search for senior product analyst pay and scope was refused. Would move RR2 and the market calibration line |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Search was denied by permission in this session, so the employer, pay and market checks are open. Granting search access would run targets 1 and 2.

I can also write this up as a `tuesday-dossier.md` for reuse in interview prep, if you want it.

## Upgrade menu

- Search access granted → targets 1 and 2 run: the employer and posting are verified, and pay is calibrated against role-family norms (RR2, RR3).
- The posting link from Harborlight's careers site → RR1, RR2 and RR3 close or sharpen.
- A sanitized readout of the pricing test (design, metric, relative or points, guardrails) → R3 to `high`.
- A sanitized dashboard, governance doc or LookML sample → R4 and R5 move toward `high`.
- A sanitized consent-model doc → strengthens the R10 bridge.
- A CV or prior resume with dates and titles → R1 to `high`.
- The hiring manager's name → sharpens the scope read and positioning.

## Questions

RR1, RR2, RR3 — Can you paste the link to the posting, ideally from Harborlight's careers site? Pay and location will show there if listed.

R8 — Have you mentored or managed junior analysts? Who, how many, for how long, and what did you do?

R10 — Did your consent-state work touch any health or medical data, or any HIPAA-covered flow?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.