**Yes, apply, on conditions: `conditional_go`.** The must-haves match your record closely. What's open is whether the role carries people management, the salary and contract type, and whether the posting checks out. Web research did not run (see Evidence status), so those checks are still open.

**Decision snapshot**

- **Fit ledger.**
  - `hard_gate`: unclear: R1 (Fully remote UK-based role)
  - `must_have`: direct: R2, R3, R4, R5
  - `important`: direct: R6 · adjacent: R8 (Pet-insurance product domain) · unclear: R7 (Recommendations to product)
  - `preferred`: direct: R9 (Insurance experience)

  R2, R3, R4 and R5 are the four must-haves, each `direct` at `medium` because the evidence is your own prose. R8 is the pet gap, a transferability case. R7 is the product side of the recommendations, which you haven't evidenced.
- **Opportunity ledger.** The role itself is sound on the posting: build, monitor, test and recommend is a clear scope. RR1 (whether the role manages people) and RR2 (salary and contract type) are unknown, and RR3 (the employer and posting are unverified) is open because research didn't run. RR4 is positive: the hiring manager leads pricing.
- **Hard gates:** none failed; unconfirmed: R1 (Fully remote UK-based role); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed: UK-based with the right to work; (2) RR2 answered: a base salary range and permanent or fixed-term stated; (3) RR3 verified: the live posting is on Brindlemoor's own careers page.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` your posting |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | An individual-contributor analytics remit is the likely reading; the posting says nothing about reports | `[inferred]` from "own" and the silence on reports |
| Market calibration | Not run; no salary band | — |
| Unknowns | Reports, salary, contract type, team size, whether the pet book has its own pricing data | — |
| Contradictions | None visible in the posting you pasted | `[grounded]` JD |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | low | hard_gate | Your location and right to work aren't stated; a UK motor employer suggests it but doesn't settle it | `[inferred]` from employer country | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two senior; prose intake, not probed | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | `[grounded]` your background | none |
| R4 | GLM experience; building and monitoring rating models | must_have | direct | medium | none | Built and maintained the young-driver GLM | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6 | Designing and reading price tests | important | direct | medium | none | 14 tests last year with underwriting | `[grounded]` your background | none |
| R7 | Recommendations to product, not only underwriting | important | unclear | low | discovery | Underwriting side is covered by R5; nothing shows product-facing recommendations | `[grounded]` absence in your background | G2, Q3 |
| R8 | Pet-insurance product domain | important | adjacent | medium | transferability | Same pricing method on motor; no pet work | `[inferred]` from R2–R4 | G1 |
| R9 | Insurance experience | preferred | direct | medium | none | UK motor insurer | `[grounded]` your background | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance domain (R8, important) | transferability | Motor pricing only; the method carries over, the pet-specific drivers don't | Likely the first objection; a bridge with its limits stated narrows it | Any pricing work on a non-motor line; a motor-to-pet analogy you could explain (e.g. how you'd handle a condition-exclusion pattern) | A sanitized note on how the GLM structure would change for pet | `[inferred]` bridge from R2–R4; `[generic]` that pet pricing turns on claims-cost and cover-design drivers |
| G2 | Product-facing recommendations (R7, important) | discovery | Underwriting recommendations are evidenced; product ones aren't visible | Closes the "and product" half of the mandate | Any pricing decision that changed a product or commercial choice | A quarterly-review slide that went to product | `[grounded]` absence in your background |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Line management scope | unknown | — | "Own pricing analytics" | If the role carries reports, the gap moves from fit to capability | `[inferred]` from the silence on reports | Does this role have direct reports, and if so what would I be managing? | unresolved |
| RR2 | Salary and contract type unstated | unknown | — | (not stated) | The package may sit below your expectation, or be fixed-term | `[generic]` pattern for postings that omit pay | What's the base salary range, and is the role permanent? | unresolved |
| RR3 | Employer and posting not verified | risk_signal | low | "Brindlemoor (insurtech)" | Research could not confirm the employer or the live posting; this is an unrun check, not a failed one | `[generic]` pattern for an unverified posting | Can you point me to the role on Brindlemoor's own careers page? | unresolved |
| RR4 | Hiring manager's pricing background | positive_signal | — | "Director of Pricing" | A pricing leader is a realistic reader of your evidence | `[inferred]` from title | What has the pet pricing function delivered in the last year that this role builds on? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with R4 and R6: the GLM and the price tests, with the motor scope named | These are your strongest evidence against the must-haves | `[grounded]` R4, R6 | pending your approval |
| P2 | State the pet gap plainly and show the transfer, not pet expertise | Avoids the objection being raised by someone else | `[inferred]` from R8 | pending your approval |
| P3 | Ask RR1, RR2 and RR3 before spending application time | Each can change the decision | `[grounded]` register | pending your approval |

No CV wording is proposed in this turn; any wording would go through the reframing audit first.

**Evidence status**

Verified: none yet. Your background is self-report from this conversation and hasn't been probed.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both search calls were refused (web search permission not granted); no result. Would have checked the posting is live and that the employer exists as described (RR3) |
| 2. Role-family sweep | unavailable | Refused with the first call. Would have set the market salary band against RR2 |
| 3. Hiring manager's public footprint | unavailable | You named Odile Varga, but no search was sent after the first two were refused. Would have shaped how you position for this reader |

**Dossier offer:** If you want this written up as a `tuesday-dossier.md` to keep, I can emit one.

**Upgrade menu**

- The live posting link or Brindlemoor's careers page → RR3 closes, and the `conditional_go` cap lifts.
- A salary range and contract type from the recruiter → RR2 closes.
- A sanitized quarterly pricing review or a price-test readout → R2–R6 move from `medium` to `high`.
- Permission for web search, if you grant it → the three targets above run (up to 5 searches and 2 fetches), and the market band and the hiring manager's public background get checked.
- Any non-motor pricing work → R8 moves from `adjacent` toward `direct`.

**Questions**

Q1 (R1): Are you UK-based with the right to work, and is a fully remote UK role workable for you?

Q2 (RR1): Does this role have direct reports? If it does, what would you be managing?

Q3 (G2): Have you made pricing recommendations that went to product or commercial teams, not only to underwriting?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.