**Yes, worth applying, on conditions. Status: `conditional_go`.** Your must-haves read `direct` on your intake, and the pay sits at market. Two gates are unanswered (location and pay floor), two requirements (ingestion, data contracts) have no evidence yet, and I could confirm the company only on its own website.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3 (5+ years data engineering), R4 (SQL and Python), R5a (dbt), R5b (cloud warehouse), R7 (Airflow or similar), R8 (data quality testing)
- `important` — adjacent: R6 (BigQuery warehouse); unclear: R9 (ingestion from app and CRM), R10 (data contracts)

R6 (`medium`) — a bridge with its limit named; R9 and R10 — not yet in evidence; R1 and R2 — gates not yet answered.

**Opportunity ledger.** Sound posting with market-level pay and no red flags (RR5). Open items: the employer is confirmed only on its own domain (RR1), the scope may be wider than one domain (RR2), and no hiring manager is named (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 confirmed as workable for you; (2) R9 and R10 shown in an interview or an artifact; (3) the employer confirmed through a contact from its own domain (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 states, founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company About page, fetched; matches your pasted text. No independent source found |
| Mandate | Build and run reporting pipelines: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Posting status | Live, "Accepting applications" | `[grounded]` careers page, fetched |
| Pay | $148,000–$166,000 plus equity; equity amount not stated | `[grounded]` JD |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, IQR $139,000–$163,500. The posted band brackets the median, and its top is above the IQR | `[generic]` Datawright 2026 report (search snippet only, not opened); band from `[grounded]` JD |
| Scope read | Three areas named (ingestion, warehouse, contracts), wider than the report's typical one-domain ownership | `[inferred]` from the JD's listed areas against `[generic]` typical scope |
| Unknowns | Hiring manager, team size, equity amount, whether ingestion and contracts are in this role's scope | — |
| Contradictions | None found between the JD, the careers page and the About page | `[grounded]` fetched pages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location is not in the material, so the gate is not settled | `[grounded]` JD; no candidate statement | Q1 |
| R2 | Base pay $148,000–$166,000 against your floor | hard_gate | unclear | none | hard_gate | Your floor is not in the material. Posted band brackets the market median | `[grounded]` JD; `[generic]` market band | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated in intake, not inspected | `[grounded]` intake statement | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated; no artifact yet | `[grounded]` intake statement | none |
| R5a | dbt | must_have | direct | medium | none | Built a dbt project of about 180 models | `[grounded]` intake statement | none |
| R5b | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The posting's named platform, BigQuery, is R6 | `[grounded]` intake statement | none |
| R6 | BigQuery warehouse (named in the posting body) | important | adjacent | medium | transferability | Snowflake and dbt carry over. Limit: no BigQuery use stated | `[grounded]` intake, "never used BigQuery"; `[inferred]` adjacency | G2 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow stated | `[grounded]` intake statement | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite; ongoing ownership not stated | `[grounded]` intake statement | none |
| R9 | Ingestion from app and CRM | important | unclear | none | discovery | Not in intake | `[grounded]` JD; silence in material | Q2 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Not in intake | `[grounded]` JD; silence in material | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion and data contracts (R9, R10, important) | discovery | Intake describes warehouse and dbt work; it does not mention source ingestion or contracts | Both are named in the posting's opening sentence, so their absence could matter | Batch or CDC ingestion from a product database; a CRM sync; a schema or freshness contract an analyst relied on | A DAG, a contract document, a schema-change ticket | `[grounded]` JD; `[inferred]` that they are central to the role |
| G2 | BigQuery (R6, important) | transferability | Snowflake production warehouse with dbt; no GCP use stated | Narrows the one platform-specific objection | Any GCP project, even a test account | A repo or config touching BigQuery or Dataflow | `[grounded]` intake; `[generic]` that platform differences are the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer seen only on its own domain | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | The employer may be too small or new for independent coverage, or the posting may be stale | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` one company-name search returned no coverage | Which email domain will the recruiting team write from, and can you point me to the role on your own careers site? | reduced |
| RR2 | Scope may be wider than one domain | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | This role may own ingestion, warehouse and contracts jointly, or share them with others | `[inferred]` from the JD's three areas against `[generic]` typical scope | Which pipelines does this role own end to end, and which do other data engineers own? | unresolved |
| RR3 | Hiring manager not named | unknown | — | Posting names no hiring manager | Reporting line and team size are unknown | `[grounded]` absence in the JD | Who would I report to, and how many data engineers are on the team? | unresolved |
| RR4 | Equity amount not stated | unknown | — | "$148,000–$166,000 plus equity" | Equity value is unquantified | `[grounded]` absence in the JD | What is the equity grant range and vesting schedule? | unresolved |
| RR5 | Pay at market, posting live on own site | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is not below market; the posting is current | `[grounded]` JD and careers page; `[generic]` market band | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the employer through the recruiter's email domain before investing in the application | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask RR2–RR4 in the first contact with the recruiter or hiring manager | the register doubles as interview prep | `[grounded]` register | pending your approval |
| A3 | Hold the application until Q1 is answered | see R1, R2 | `[grounded]` gate rows | pending your approval |

No candidate-facing language is proposed in this pass.

## Evidence status

Verified: none yet. Intake statements are leads at `medium` until you answer a probe.

Research tier: L1 — searches 3 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning senior data engineer job" (returned the careers page) and "Pellucid Learning live online tutoring K-12 Denver" (no results). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): live, matches the posting. Fetched "About Pellucid Learning" (pellucidlearning.com/about): matches. Moved the stage row and RR1; no independent coverage found |
| 2. Role-family sweep | yes | Searched "Datawright 2026 Data Engineering Pay Report": result at datawright.example/2026-data-engineering-pay-report shows the same figures as your pasted report. Figures rest on the snippet; the page was not opened. No broader sweep was run |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- A recruiter reply naming the hiring manager and team size → RR2 and RR3 close.
- The equity range and vesting → RR4 closes.
- The recruiter's answer on location and pay floor → R1 and R2 resolve.
- A sanitized ingestion job or data-contract document from your payroll work → R9 and R10 move from `unclear` toward `direct`.
- Any GCP artifact, even from a test project → R6 narrows.
- Deeper research on the company (funding, leadership changes, recent news): up to 5 more searches and 2 more fetches. Say the word and it runs.

If you want, I can save this as `tuesday-dossier.md` so that `mock-interview` can pick it up later.

1. **Q1 (R1, R2):** Does Remote (US) or the Denver office work for where you live, and is a base of $148,000 at the bottom of the range above your floor?
2. **Q2 (R9, R10):** Have you built ingestion from a product database or a CRM into a warehouse, or owned a data contract that analysts relied on? What did you own?
3. **Q3 (R6):** Have you used any Google Cloud service, BigQuery included, even in a side project or test account?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.