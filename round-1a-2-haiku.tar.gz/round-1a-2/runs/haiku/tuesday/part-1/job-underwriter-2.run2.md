**Not a waste of time, but it's a stretch on the must-have. `conditional_go`: apply only once you have a verified story of a product decision you owned and a recruiter's answer on the PM-years bar.**

- **Fit ledger.** `must_have`: direct R3 (technical fluency), R5 (stakeholder management); adjacent R1 (3+ years PM), R2 (shipped API/platform products); unclear R6 (agile delivery). `important`: direct R4 (partner discovery); adjacent R8 (specs and delivery); unclear R7 (adoption metrics). R1 and R2 are the rows that matter: R1 is adjacent through seven years of implementation work, not a PM title, and R2 is adjacent because you shipped integrations as the implementer, not as the owner.
- **Opportunity ledger.** The scope is concrete: a partner-facing roadmap, two engineering squads, named adoption metrics (RR3, positive). The main risk is that a "3+ years PM" must-have is a likely screen-out (RR2), and decision rights are unstated (RR1). No severe red flags found.
- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.

**Research tier: L1 — searches 3 of 5, fetches 0 of 2**; the search permission was refused, so this is an analysis of the posting and your summary only.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` posting as provided, not verified |
| Mandate | Own the partner-facing API roadmap; discovery, specs, delivery with two squads, adoption metrics, launches | `[grounded]` posting |
| Scope read | Concrete and specific for a PM role | `[inferred]` from the named squads and metrics |
| Market calibration | Not run; the search that would have set PM-years norms was refused | — |
| Unknowns | Decision rights over the roadmap; base salary (not in the posting); whether the 3-year bar is firm | — |
| Contradictions | None visible inside the posting | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | 3+ years PM experience | must_have | adjacent (no PM title) | medium | transferability | Seven years of requirements, UAT and client-facing roadmap input, with no product-ownership title. The limit is that none of it was product ownership | `[grounded]` CV; `[inferred]` adjacency |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST API integrations delivered end to end, as implementer, not owner | `[grounded]` CV |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI named; self-reported, no artifact | `[grounded]` CV, self-reported |
| R4 | Partner discovery | important | direct | medium | none | Scoping workshops; quarterly client roadmap-input sessions | `[grounded]` CV |
| R5 | Stakeholder management: eng, sales, customers | must_have | direct | medium | presentation | Coordinated your engineers, client engineers and PMs. Sales-facing work is not stated | `[grounded]` CV |
| R6 | Agile delivery | must_have | unclear | low | discovery | Resume silent on sprints, backlogs or ceremonies | `[grounded]` CV silence |
| R7 | Define and track adoption metrics | important | unclear | low | discovery | No metrics work stated. The triage-tool lead is unconfirmed (see the gap queue) | `[grounded]` CV silence |
| R8 | Specs and delivery with two squads | important | adjacent | medium | transferability | Requirements documents and integration architecture, written for client builds, not a squad backlog | `[grounded]` CV; `[inferred]` |

## Gap recovery queue

| # | Gap (req) | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | PM years (R1, must_have) | transferability | Seven years of adjacent work, no ownership title | A decision you owned and can show: a spec, a roadmap call, a result | `[grounded]` CV |
| G2 | Shipped products (R2, must_have) | transferability | Integrations shipped as implementer | One integration where your scoping changed what the product did next | `[grounded]` CV |
| G3 | Agile delivery (R6, must_have) | discovery | Not stated | Your actual delivery cadence on those builds | `[grounded]` CV silence |
| G4 | Adoption metrics (R7, important) | discovery | Not stated; the triage tool is an unconfirmed memory lead, not evidence | Confirm the tool, its users, and how adoption was measured | `memory_lead`, unconfirmed |

## Opportunity risk register

| # | Signal | Class | Severity | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|
| RR1 | Roadmap decision rights unstated | unknown | — | The role may execute roadmap asks from sales and partners, not set them | `[inferred]` from the posting's silence on authority | Which roadmap decisions does this role make alone, and which go to the squads or leadership? | unresolved |
| RR2 | 3+ year PM bar is a likely screen-out | risk_signal | medium | Recruiters often filter on a hard years-of-PM number before reading experience | `[generic]` pattern for must-have experience bars, not a claim about this employer | Is the 3-year PM requirement firm, or would owned product outcomes substitute for it? | unresolved |
| RR3 | Scope is specific | positive_signal | — | Clear mandate and named metrics | `[grounded]` posting | What adoption metrics does this role own today? | noted |
| RR4 | Employer not checked | risk_signal | medium | The posting could be stale or aggregated. Pattern for companies of this size, not a claim about this one | `[generic]` | Can you point me at this role on your own careers site, and who would I interview with? | unresolved |
| RR5 | Salary absent from posting | unknown | — | Band may differ from expectation | `[generic]` band not run | What is the base range for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting on Quartzline's careers site before applying | RR4 | `[generic]` | pending your approval |
| A2 | Ask the recruiter whether the PM-years bar is firm | RR2, R1 | `[generic]` | pending your approval |
| A3 | Write down one product decision you owned, with the outcome, before you apply | G1, G2 | `[grounded]` gap queue | pending your approval |
| A4 | Resume lines, proposed as edits: "Scoped and delivered 30+ client REST API integrations end to end. Wrote the integration playbook the team uses. Ran quarterly client roadmap-input sessions for product." Do not add "product manager", "owned the roadmap" or "shipped" to any line | Reframing audit: none of those is in your sentences | `[grounded]` CV | resume_edits_pending_approval |

## Evidence status

Verified: none yet. Everything above rests on your summary, which is a CV-source claim, not confirmed.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Official site and careers page | unavailable | Whether the employer exists and the posting is live (RR4) |
| 2. Role-family sweep | unavailable | Market calibration and PM-years norms (RR2, RR5) |
| 3. Hiring manager's footprint | n/a | No name given |

The search permission was refused, so these two rows could not run.

## Dossier offer

If you want, I can write this assessment to `tuesday-dossier.md` so it carries into interview prep later.

## Upgrade menu

- The live posting link or Quartzline's careers page → RR4 closes; I can then run the L1 research pass (up to 5 searches, 2 fetches) if you grant search permission.
- The base salary range, or a recruiter's answer → RR5 closes.
- One inspectable artifact: a spec you wrote with a decision you made, a roadmap doc, or the triage tool's documentation with adoption figures → R1, R2 and R7 rise.
- The recruiter's answer on the PM-years bar → R1's fit call is settled.

## Questions

1. **[R1]** Think of a product or integration-template decision where your call went to clients or the product team. What was it, and who else decided?
2. **[R7]** Did you build an internal request-triage tool that support agents adopted? If so, what did it do, how did you measure adoption, and who else owned it?
3. **[R6]** How did delivery run in your integration work: sprints and a backlog, or per-client plans?

Answer any of these, skip any, or say "skip." A skip counts as an answer, and I won't re-ask it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.