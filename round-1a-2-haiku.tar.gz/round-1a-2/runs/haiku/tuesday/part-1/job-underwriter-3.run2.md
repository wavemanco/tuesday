**No. Don't pursue this one as posted.** It fails both of your hard constraints: the base is $70–85k against your $150k floor, and it requires five days a week on-site in Austin against your remote-only requirement. Your gut was right. Status: `no_go`.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Novaline were refused at the permission step, so nothing was read. Would have moved the employer-not-established entry (RR4) and whether the posting is live. |
| 2. Role-family sweep | unavailable | One search for Head of Growth pay at Series A was refused. Would have moved the market calibration line. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (base pay floor), R2 (remote-only work)
- `must_have` — direct: R3 (8+ years growth leadership), R4 (paid acquisition), R5 (lifecycle and CRM), R6 (revenue scale with budget control)
- `important` — unclear: R7 (SEO and content), R8 (brand, PR, partnerships), R9 (sales ops)
- `preferred` — unclear: R10 (operating as a team of one)

R1 and R2 — both gates fail on the posting's own terms; R3, R4, R5 and R6 — your stated history, `medium` because nothing is inspectable yet.

**Opportunity ledger.** Two risk signals sit on the role's scope and expectations: RR1 (always-on evenings and weekends) and RR2 (seven functions on a team of one at this pay). RR3 (success metrics deferred) and RR4 (employer not established, since the searches were refused) add to them. RR6 is a positive: the reporting line to the CEO is stated.

- **Hard gates:** failed: R1 (base pay floor), R2 (remote-only work).
- **Severe red flags:** none found.
- **What would change this:** only Novaline changing both terms. R1 needs base pay near $150k, and R2 needs remote work. The posting says on-site "no exceptions," so this is unlikely. Nothing in the rest of the map would change the answer.

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting; the stage and profitability claims are unverified |
| Mandate | Owns all revenue growth across seven named functions, from a team of one | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Pay | $70–85k base plus equity | `[grounded]` posting |
| Market calibration | Not established; the pay search was refused | — |
| Unknowns | Whether the employer exists as described; actual hours; what success means | — |
| Contradictions | None found in the posting itself | `[grounded]` |

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay of $150k or more (your floor) | hard_gate | hard_gate_fail | high | hard_gate | Your own stated floor; the posting's $70–85k is more than $60k below it | `[grounded]` posting and your constraint | Surface in snapshot; only an employer change of terms resolves it |
| R2 | Remote-only, living in Portland | hard_gate | hard_gate_fail | high | hard_gate | Your own stated constraint; the posting requires Austin five days a week, "no exceptions" | `[grounded]` posting and your constraint | Surface in snapshot; only an employer change of terms resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, Growth lead then Head of Growth; self-reported, no inspectable artifact | `[grounded]` your stated history | None |
| R4 | Paid acquisition | must_have | direct | medium | none | You owned paid; self-reported | `[grounded]` your stated history | None |
| R5 | Lifecycle and CRM | must_have | direct | medium | none | You owned lifecycle; deep in Braze; self-reported | `[grounded]` your stated history | None |
| R6 | Revenue growth with budget control | must_have | direct | medium | none | $8M to $40M ARR with a budget you controlled; self-reported | `[grounded]` your stated history | None |
| R7 | SEO and content | important | unclear | low | discovery | Not in your history | `[grounded]` absence | None; does not change the decision |
| R8 | Brand, PR, partnerships | important | unclear | low | discovery | Not in your history | `[grounded]` absence | None; does not change the decision |
| R9 | Sales ops | important | unclear | low | discovery | Analytics (SQL, GA4) is not sales operations | `[inferred]` from your tool list | None; does not change the decision |
| R10 | Running as a team of one | preferred | unclear | low | discovery | You have managed teams of 3–7; no solo-operator evidence | `[grounded]` your history against the posting's "don't need a bench" | None |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Routine after-hours work, not occasional | `[inferred]` from the posting's own words | What does a normal week look like, and how often are evenings and weekends needed? | unresolved |
| RR2 | Scope against team size and pay | risk_signal | medium | "Own all revenue growth end to end … a team of one to start" | Seven functions on one person at this pay may mean under-resourced or deferred scope | `[inferred]` from scope against team and pay; `[generic]` that bundled scope usually signals this | Which of these functions have budget and people committed now? | unresolved |
| RR3 | Success metrics deferred | risk_signal | medium | "success metrics will evolve as we learn" | Accountability may arrive without a definition of success | `[inferred]` from the posting | What three numbers define success at twelve months, and who sets them? | unresolved |
| RR4 | Employer not established | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A …)" | The employer is unverified here because the searches were refused; it may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Novaline's own careers page, and who would I interview with? | unresolved |
| RR5 | Financial claims unverified | unknown | — | "Series A, profitable since day one" | Stated by the employer and not checked here | `[grounded]` posting wording; unverified | What is the latest funding round, and is the company profitable today? | unresolved |
| RR6 | Reporting line stated | positive_signal | — | "Report to the CEO with a dotted line to the board" | The authority line is concrete | `[grounded]` posting | Who sits on the board line, and how often do you meet them? | noted |

**Evidence status.** Verified: R1 and R2 (your own constraints, stated and confirmed in this session). R3, R4, R5 and R6 are specific and self-reported, with no inspectable artifact, so they are `medium`. Unverified leads: none. Rejected inferences: none.

**Dossier offer.** I can write `tuesday-dossier.md` with this report and its envelope if you want to keep it for later.

**Upgrade menu.**
- Web search access: if you approve it, I'd rerun the searches (up to 5 searches and 2 page fetches) to confirm Novaline exists and is hiring for this role, and to set the pay band against role-family norms. It would not change R1 or R2, which rest on the posting's own terms.
- A recruiter's answer on remote work and base pay: this is the only thing that could reopen R1 and R2. The posting says "no exceptions," so I'd expect no.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.