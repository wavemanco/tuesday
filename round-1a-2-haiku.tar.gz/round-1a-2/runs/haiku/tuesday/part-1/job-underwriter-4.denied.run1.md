**Yes, it's worth applying to, with three checks first. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (UK-based, eligible to work in UK)
- `must_have`: direct: R2, R3, R4, R5
- `important`: direct: R6, R7 · adjacent: R8 (recommendations for underwriting and product), R10 (pet-insurance product)
- `preferred`: direct: R9 (insurance experience)

R10 is the main gap: motor pricing carries the method, but pet itself is untested. R8 is evidenced for underwriting and not for product. R1 is the gate the material doesn't settle.

**Opportunity ledger.** Sound but under-specified. The employer is unverified (RR1), decision authority is unstated (RR2), and pay and contract type are absent (RR3). The scope is concrete: a named product and named outputs (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (UK-based, eligible to work in UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor's own careers site shows the role live (RR1); (2) R1 is confirmed; (3) the pet gap is stated plainly in the application, never presented as pet experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` your posting; not verified externally |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` posting |
| Working pattern | Fully remote, UK | `[grounded]` posting |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message; not verified |
| Scope read | Individual-contributor analyst scope on the page; "Senior" and team size unstated | `[inferred]` from the absence of any reporting line in the posting |
| Market calibration | Not run. No salary band was checked | — |
| Unknowns | Pay, contract type, reporting line, team size, decision authority, whether the role is new | — |
| Contradictions | None visible in the single posting you provided | `[grounded]` posting; careers page not checked |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | UK-based and eligible to work in UK | hard_gate | unclear | low | hard_gate | Location and eligibility are not stated. A UK motor insurer role is a lead, not a settlement | `[grounded]` employer named in your message; location not stated | G3 (question) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two senior. Stated, no artifact | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated, no artifact | `[grounded]` your message | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM rating model. The method is shown on motor data only | `[grounded]` your message | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your message | none |
| R6 | Build and monitor rating models | important | direct | medium | discovery | Build is evidenced through R4. Monitoring is not stated | `[grounded]` your message | verify in interview prep; no question this turn |
| R7 | Design and read price tests | important | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your message | none |
| R8 | Turn results into recommendations for underwriting and product | important | adjacent | medium | transferability | Recommendations to underwriting are evidenced. Product-side recommendations are not | `[grounded]` your message; `[inferred]` that the product side is the gap | G2 (question) |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your message | none |
| R10 | Pet-insurance product knowledge (inferred from the posting's product context; not stated as a requirement) | important | adjacent | medium | transferability | Motor pricing carries the method. Pet itself is untested: you have never worked on it | `[inferred]` from "our pet-insurance product" and your statement; `[generic]` that pet books usually differ from motor in claim patterns | G1 (question) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R10) | transferability | Motor only. Nothing on pet or any non-motor line | The most likely objection at interview; a stronger bridge narrows it | Pricing or modelling on home, travel or other non-motor lines; any personal pet-data analysis; a frequency/severity model outside motor | An anonymised methods note or a short analysis | `[inferred]` bridge from the GLM work; `[generic]` that this is the likely objection |
| G2 | Product-side recommendations (R8) | transferability | Recommendations to underwriting are evidenced; product is not | "Recommendations for … product" is in the posting | A recommendation that went to a product team, changed a feature or a price structure | A product-facing deck or memo | `[grounded]` posting wording against your account |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a live hiring employer. Research was refused this run, so this is unverified, not established as absent | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Decision authority unstated | unknown | — | "turn the results into recommendations for underwriting and product" | The role may recommend while pricing decisions sit with underwriting or product | `[inferred]` from the recommendation wording against its silence on decision rights | Which pricing decisions does this role make itself, and which go to underwriting or product? | unresolved |
| RR3 | Pay and contract type unstated | unknown | — | Posting states no salary or contract type | The figure may be withheld or sit outside your expectations. No market band checked | `[grounded]` the posting's silence | What is the base salary range for this role, and is it permanent? | unresolved |
| RR4 | Concrete scope | positive_signal | — | "Own pricing analytics for our pet-insurance product" | Scope and outputs are named, so success is measurable | `[grounded]` posting | Which rating models will this role own from the start? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead the first application answer with the GLM build and the 14 price tests; name the pet limit in the same answer | R4, R7, R10 | `[grounded]` your message | pending your approval |
| P2 | Before applying, confirm the posting is live on Brindlemoor's own careers site | RR1 | `[grounded]` RR1 | pending your approval |
| P3 | Put the RR2 and RR3 questions in the first screen | Register doubles as screen prep | `[grounded]` register | pending your approval |

## Evidence status

Verified (your statements, no artifact yet): R2, R3, R4, R5, R6 (build), R7, R9. Unverified: R1 (no claim made), R8's product side, and R10's gap, which is only what your "never worked on pet" implies.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search refused by the host, not retried. Would have moved RR1: whether the employer and posting exist |
| 2. Role-family sweep | unavailable | Search refused by the host, not retried. Would have set the market calibration for RR3 |
| 3. Hiring manager's public footprint | unavailable | Search refused by the host, not retried. Would have checked Odile Varga's public role and background |

Dossier offer: If you want, I can write this up as `tuesday-dossier.md` to reuse when you prep.

## Upgrade menu

- Brindlemoor's live posting link, or its careers page → RR1 closes, and the decision can move from `conditional_go` to `go`.
- Anonymised test readouts or your quarterly review deck → R6 and R7 move to `high`.
- Any pricing work on a non-motor line or pet data → R10 narrows.
- Permission for the three searches and two page fetches, so research can run → RR1 and RR3 can be checked. Say the word and I'll run it.

## Questions

G1 — Have you done any pricing or modelling outside motor, on home, travel, pet data or a side project? What did you own, and what did it show?

G2 — Have any of your recommendations gone to a product team rather than to underwriting? If so, what changed as a result?

G3 (R1) — Are you based in the UK, with the right to work there without sponsorship?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.