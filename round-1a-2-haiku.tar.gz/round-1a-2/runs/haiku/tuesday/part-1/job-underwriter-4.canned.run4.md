**Yes, apply, but only after one question about location is answered. Status: `conditional_go`.** Your must-haves are a strong match. The one thing that could stop you is that the posting contradicts itself on where the job is: the ad says fully remote, and the careers page says Leeds four days a week.

**Fit ledger.**

- `hard_gate`: unclear: R9 (fully remote UK versus four days a week in Leeds)
- `must_have`: direct: R1, R2, R3, R4, R5, R6
- `important`: adjacent: R8 (pet-insurance product knowledge)
- `preferred`: direct: R7 (insurance experience in general)

R9 — the location term, which is unsettled; R8 — a credible bridge from motor pricing, its limit named; R1, R2, R3, R4, R5 and R6 — each direct on what you have stated, `medium` because nothing is inspectable yet; R7 — direct for insurance in general, not for pet.

**Opportunity ledger.** Sound and well specified: the employer checks out, the hiring manager's public work lines up with monitoring, and the role has defined outcomes. Against that, the location contradiction (RR1) and the missing pay (RR3) need answers. The pet-domain gap is yours to be honest about (R8).

- **Hard gates:** none failed; unconfirmed: R9 (fully remote UK versus four days a week in Leeds); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the recruiter confirms the working pattern, and you can meet it (RR1, R9); (2) you present pet as a gap you are closing, not as experience you have (R8).
- **What would change this:** if the four-day Leeds pattern is real and you can't meet it, R9 fails and the status becomes `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech; pet-insurance product. Careers page is live and accepting applications | `[grounded]` careers page fetched |
| Mandate | Own pricing analytics for the pet product; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page |
| Working pattern | JD: fully remote (UK). Careers page: Leeds office four days a week | `[grounded]` both sources, contradictory |
| Scope read | A normal scope for a senior analyst role. No people management is stated in the JD, so you are not being asked to have managed anyone | `[inferred]` from the JD's wording |
| Market calibration | Pricewell 2026 pay survey for senior pricing analysts at UK insurers and insurtechs: median £58,400, interquartile range £52,100–£64,900 (n=612) | `[generic]` role-family survey, not this employer's offer |
| Unknowns | Pay; the working pattern; whether the pet book has its own rating team | — |
| Contradictions | Remote (JD) versus Leeds four days a week (careers page) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two senior. Self-reported, no artifact yet | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use. Self-reported | `[grounded]` your background | none |
| R3 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model for a young-driver motor book | `[grounded]` your background | none |
| R4 | Build and monitor rating models | must_have | direct | medium | none | Maintained the model in production; monitoring is part of that | `[grounded]` your background | none |
| R5 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your background | none |
| R6 | Present to underwriting or actuarial leads | must_have | direct | medium | none | Present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R7 | Insurance experience | preferred | direct | medium | none | UK motor insurer. This is insurance, not pet | `[grounded]` your background | none |
| R8 | Pet-insurance product knowledge | important | adjacent | medium | transferability | Motor pricing method carries over. Pet risk drivers (breed, vet-fee inflation, lifetime versus annual cover) are not exercised by your work | `[inferred]` from "our pet-insurance product" in the JD | see G1 |
| R9 | Working location and pattern | hard_gate | unclear | none | hard_gate | JD says fully remote UK; careers page says Leeds four days a week. Your location is not stated, so the gate is not established | `[grounded]` both sources | question Q1 |

Confidence is `medium` throughout because your statements are specific and confirmed, but nothing has been inspected. A work sample, or a short note of a real analysis, would raise them.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R8, important) | transferability | Motor pricing method transfers. You have not priced a pet book | R8 is the one domain gap in the map. The honest answer is the bridge, with its limit | Any pet-related data work, however small. Otherwise, the motor analyses where a risk driver behaved unlike its motor assumption | A pet-pricing note you wrote, a pet-claims extract you analysed, or a plan for how you would test pet risk drivers | `[inferred]` bridge from your motor work; `[generic]` that pet books differ in these ways |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working location contradicts itself | risk_signal | medium | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | One of the two is stale, or the working pattern is not settled | `[inferred]` from two contradictory sources | "The job ad says fully remote, and the careers page says Leeds four days a week. Which applies to this role, and what would the working pattern be?" | unresolved |
| RR2 | Employer established | positive_signal | — | Careers page: "Accepting applications. Senior Pricing Analyst, Leeds office…" | The role is live on the company's own site, so the employer-not-established entry does not apply | `[grounded]` careers page fetched. Search footprint is thin, `[generic]` for a company this size | Is this role live on your careers site, and who would I be interviewing with? | reduced |
| RR3 | Pay not in the posting | unknown | — | The JD as pasted states no pay | Pay may be set below, at, or above the survey band; the posting does not say | `[grounded]` JD; band `[generic]` | "What is the base salary band for this role?" | unresolved |
| RR4 | Hiring manager's public interest matches the JD | positive_signal | — | Search snippet: 2025 talk "Small Books, Loud Errors", on monitoring rating models in small books | Your monitoring work speaks directly to what she has spoken about | `[grounded]` search snippet, not fetched | "Which monitoring checks matter most on a small book, and how is it reviewed?" | noted |

**Severe red flags:** none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Email the recruiter: confirm the working pattern (RR1) and the pay band (RR3) | These two decide whether this is `go` | `[grounded]` RR1, RR3 | pending your approval |
| P1 | Lead with motor pricing rigour: "Built and maintained the GLM rating model for a young-driver motor book. Ran 14 price tests with underwriting. Present the quarterly pricing review to the head of underwriting." | These are your own sentences, nothing added | `[grounded]` your background | pending your approval |
| P2 | On pet, say: "My work is motor pricing. Pet risk drivers are new to me, and here is how I would test them first." Do not claim pet experience | Keeps R8 at its real level | `[grounded]` R8 | pending your approval |

## Evidence status

Verified: R1, R2, R3, R4, R5, R6, R7 claims (your statements, medium: confirmed, limited inspectable proof). Unverified: R8 is an inference from your motor work, not a claim about pet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results). Searched "Brindlemoor Senior Pricing Analyst careers", which returned brindlemoor.co.uk/careers/senior-pricing-analyst; fetched it. Moved: RR2 (employer established) and the working-pattern contradiction (RR1, R9) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved: market calibration `[generic]` and RR3's band |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned a profile listing (linkedin.example/in/odile-varga, snippet only, not fetched) describing the 2025 forum talk "Small Books, Loud Errors" and her earlier role at Calloway Re. Moved: RR4 and the positioning in P1 and P2 |

## Upgrade menu

- Your location and the recruiter's answer on the working pattern → R9 and RR1 close. The decision becomes `go` or `no_go`.
- Any pet-related work you have done, however small → R8 may rise above `adjacent`, if it is real.
- The budgeted salary → RR3 closes, and the figure is set against the band in role reality.
- Deeper research on Brindlemoor (funding, leadership changes, public candidate reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you want, I can save this assessment as `tuesday-dossier.md` for your prep later.

**Question**

Q1 (R9, RR1): Where are you based, and could you work four days a week in the Leeds office if the role needs it?
Q2 (R8, G1): Have you touched any pet-insurance data or pricing, even in a side project or a pet line inside a broader book?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.