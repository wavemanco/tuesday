**Yes, go for it, on three conditions: `conditional_go`.** The two gaps are real, but the role's core is close to your 5 years in sales ops and your last 2 running RevOps.

**Fit ledger.**

- `hard_gate`: unclear: R8 (Bristol hybrid, two days a week in the office)
- `must_have`: direct: R1, R2, R3 · adjacent: R4 (own the quarterly forecast), R5 (billing or revenue data with finance)
- `important`: direct: R6 (own CRM data), R7 (build pipeline and renewal reporting)

R4 is adjacent through your monthly pipeline review, but you have never owned or signed off a forecast. R5 is adjacent through renewal revenue data, but billing data is absent.

**Opportunity ledger.** The posting states its pay, and the scope is explicit. Quillfield checks out on its own about page (RR1 is still open because the posting is not on its careers page). The forecast ownership sits at the top of the scope and is the main risk (RR2).

- **Hard gates:** none failed; unconfirmed: R8 (Bristol, two days a week in office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R4: you can show how your pipeline review fed a forecast and who held the number; (2) R5: you name billing data as a gap, not claim it; (3) R8 is confirmed, and RR1 is closed by a live link on Quillfield's own site.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; founded 2018 in Bristol; 96 staff; £11M Series A, April 2025 | `[grounded]` search snippet of quillfield.co.uk/about |
| Role | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly forecast with the CFO | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Market calibration | UK B2B software RevOps lead: median £64,200, interquartile range £57,800–£70,400 (n=438). The posted range sits mid-band | `[generic]` Ledgerline 2026 pay guide; not a claim about this employer's offer |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Requirements tiers | The posting does not rank its requirements; I have tiered the five listed as must-haves | `[inferred]` my tiering |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; before that four years in sales operations at Corvane Payments | `[grounded]` LinkedIn search snippet; name and employer match the recruiter's, not yet confirmed as the same person |
| Unknowns | Whether this role reports to the Head of RevOps; who holds the forecast today; who owns billing data | — |
| Contradictions | None found between the posting and what I could find | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years in RevOps, sales ops or analytics at a B2B software company | must_have | direct | medium | none | Five years in sales ops, two running RevOps. Your company is B2B payments, which is close to software but not the same | `[grounded]` your intake | none |
| R2 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; certificate not inspected | `[grounded]` your intake | none |
| R3 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily; the depth of modelling is not described | `[grounded]` your intake | G2 may show modelling depth |
| R4 | Experience owning a forecast | must_have | adjacent | medium | transferability | The pipeline review is a forecast input; you have never owned the forecast, and finance did | `[inferred]` adjacency from the pipeline review | G1 |
| R5 | Working with finance on billing or revenue data | must_have | adjacent | medium | transferability | Renewal and pipeline dashboards are revenue data; no billing data and no stated finance partnership | `[grounded]` your intake; adjacency `[inferred]` | G2 |
| R6 | Own CRM and billing data | important | direct | medium | none | CRM ownership as admin is direct; billing ownership is absent, and it shares G2 | `[grounded]` your intake | G2 |
| R7 | Build pipeline and renewal reporting | important | direct | medium | none | You rebuilt pipeline and renewal dashboards | `[grounded]` your intake | none |
| R8 | Bristol hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | I have no statement from you on this constraint, so the check is unknown | `[grounded]` posting | Q3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R4, must_have) | transferability | Monthly pipeline review with the sales director; no forecast ownership | This is the row the role's CFO-facing duty sits on, and it is the one most likely to be probed | Pipeline-weighting or stage-probability inputs you fed; a variance review where you explained the gap to plan; a deal-slip analysis | A pipeline review pack or variance review (anonymised) | `[inferred]` adjacency; `[generic]` that this duty is typically probed in a Lead interview |
| G2 | Billing data and finance work (R5, R6) | transferability | Renewal and pipeline revenue data; no billing | The posting names billing twice, so an honest "this is new to me" with a plan is the answer to give | Invoice-to-booking reconciliation; billing-to-CRM sync; revenue questions raised with finance | A reconciliation example or a finance-facing report | `[grounded]` posting; `[inferred]` adjacency |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not on the company's own careers page | unknown | — | "Revenue Operations Lead — Quillfield" (Tallyboard listing) | The listing may be stale or aggregated, or the role may sit under another title | `[generic]` pattern for aggregator listings | Can you point me at this role on Quillfield's own careers site, and who would I interview with? | unresolved |
| RR2 | Forecast accountability on day one | risk_signal | medium | "run the quarterly revenue forecast with the CFO" | The role may carry forecast accountability without a handover period | `[inferred]` from the posting's scope against your history | How is the forecast built today, who owns each input, and what would success look like at 90 days? | unresolved |
| RR3 | Billing data ownership unclear | risk_signal | medium | "you will own our CRM and billing data" | Billing may sit with finance in practice, so ownership is narrower than the wording | `[inferred]` from the posting's wording | Who owns billing data day to day, and where does it sit relative to the CRM? | unresolved |
| RR4 | Pay stated, with share options | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is stated and sits mid-band | `[grounded]` posting; `[generic]` band | How are the share options structured, and what is the vesting schedule? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter for a link to the live posting on Quillfield's own site | RR1 | `[grounded]` RR1 | proposed |
| A2 | Build your forecast story from the pipeline review: what you fed in, not what you owned | G1, R4 | `[grounded]` your intake | proposed |
| A3 | Prepare a plain answer on billing: what you know, what is new, and how you would learn it | G2, R5 | `[grounded]` posting | proposed |

**Evidence status**

Verified: none yet. Everything above is your own account, which is a lead until it is probed.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers Revenue Operations Lead", which returned quillfield.co.uk/about. Fetched quillfield.co.uk/careers: no page. Moved: the employer is established; the posting is not confirmed on the company's own site (RR1) |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B software Bristol", which returned the Ledgerline 2026 UK Revenue Operations Pay Guide. Moved: market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned a LinkedIn profile snippet: Head of Revenue Operations at Quillfield; earlier four years at Corvane Payments. Moved: role reality (hiring manager) and positioning; the match is by name and employer, so confirm it before relying on it |

**Dossier offer:** I can save all of this as a `tuesday-dossier.md` file if you want to carry it into later sessions.

**Upgrade menu**

- An example of you feeding a forecast (pipeline inputs, a variance review, stage weighting agreed with finance) → R4 moves from adjacent toward direct.
- A billing or invoice-reconciliation example, even a small one from Corvane → R5 and the billing half of R6.
- A copy of the Salesforce certificate → R2 to `high`.
- The live posting on Quillfield's careers site, or a recruiter email from a Quillfield address → RR1 closes.
- A deeper research pass on Quillfield (funding history, leadership changes, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1 — Have you ever fed into a revenue forecast, even just the pipeline inputs or a variance review with finance? What did you own, and what did finance own?

G2 — Have you worked on billing or invoice data, such as reconciling invoices to bookings or syncing billing with the CRM? If not, say skip.

Q3 (R8) — Is two days a week in the Bristol office workable for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.