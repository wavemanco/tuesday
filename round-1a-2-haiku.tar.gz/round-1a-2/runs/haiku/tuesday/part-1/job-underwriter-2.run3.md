**Not a waste of time, but not a clean fit: `conditional_go`.** Apply if the posting verifies and your answer to G1 below holds up. The gap is the title and the years, not the substance of the work.

**Fit ledger** (projected from the evidence map)

- `must_have`: direct: R3, R4 · adjacent: R1, R2, R5, R6, R8 · unclear: R7
- `important`: direct: R10 · unclear: R9

R3 (`direct`, `medium`): confirmed on the resume, expect a schema probe. R1 and R2 (`adjacent`): the 3+ years of PM and API-product ownership are the limits. R7 (`unclear`): agile delivery is not evidenced. R9 (`unclear`): adoption metrics are not evidenced.

**Opportunity ledger.** The posting shows no red flags. Its scope is defined and the platform is partner-facing (RR4 is a positive signal in the register's sense). Open items: the employer is unverified (RR1), pay and location are withheld (RR2), and the 3+ years bar may be screened literally (RR3).

- **Hard gates:** none stated (the pasted posting names no location, pay, authorization or schedule gate); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) a product decision you made can be named concretely (G1); (2) the live posting verifies (RR1); (3) the years question is answered (RR3)

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics tech, about 150 people, Series B | `[grounded]` pasted posting; not checked against the web (see research) |
| Mandate | Own the roadmap for a partner-facing API platform: discovery, specs, delivery with two squads, adoption metrics, launch coordination | `[grounded]` posting |
| Scope read | Ordinary for a PM owning one platform surface with two squads | `[inferred]` from the squad count against the roadmap ownership |
| Market calibration | Not run: web search was declined in this session | — |
| Unknowns | Pay, location, reporting line, which roadmap decisions the role makes alone | — |
| Contradictions | None visible in the pasted text | `[grounded]` pasted posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product management | must_have | adjacent | medium | transferability | No PM title and no PM ownership in the resume; seven years of adjacent implementation work. A length-of-experience bar, not a gate, so graded on fit | `[grounded]` resume; `[inferred]` adjacency | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You delivered 30+ integrations of the company's REST APIs to clients, from the customer-facing side. No record of owning a product release | `[grounded]` resume | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading and integration architecture are on the resume. Self-reported, so expect a schema probe | `[grounded]` resume; caveat: expect a probe | none |
| R4 | Stakeholder management: engineering, sales, customers | must_have | direct | medium | none | Coordinated vendor engineers, client engineers and PMs on custom builds; ran scoping workshops | `[grounded]` resume | none |
| R5 | Discovery with integration partners | must_have | adjacent | medium | transferability | Scoping workshops and quarterly roadmap-input sessions are discovery-shaped, but they collected requests rather than framed problems | `[inferred]` from the resume's session descriptions | G1 |
| R6 | Write specs, drive delivery with engineering squads | must_have | adjacent | medium | transferability | Requirements documents and UAT on client builds; no evidence of spec-to-release ownership | `[grounded]` resume | G2 |
| R7 | Agile delivery experience | must_have | unclear | low | discovery | Not stated on the resume; coordinating engineers may or may not have been sprint-based | `[grounded]` resume silence | G2 |
| R8 | Own the roadmap | must_have | adjacent | medium | transferability | Roadmap-input sessions only; no evidence you set priorities | `[grounded]` resume; `[inferred]` adjacency | G1 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | Nothing on the resume; the playbook may have adoption outcomes behind it | `[grounded]` resume silence | G3 |
| R10 | Coordinate launches with sales and support | important | direct | medium | none | Client go-live coordination is on the resume; support coordination is not | `[grounded]` resume | none |

Note: the memory lead about a request-triage tool is not in this map. It is unconfirmed and cannot be evidence (see G1).

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owned product decisions (R1, R2, R5, R8) | discovery | Resume shows input-gathering and implementation, not prioritization | Decides whether the years and roadmap rows move from adjacent toward direct | Any tool, feature or playbook section where you decided what got built or in what order; an integration pattern that became a product change | A spec, a roadmap doc, a before/after of a decision | `[grounded]` resume silence; `[inferred]` that this moves the status |
| G2 | Agile delivery (R6, R7) | discovery | Coordinated engineers; no sprint or backlog ownership stated | A must-have row sits unclear | Sprint planning, backlog grooming, release coordination with an engineering team | A sprint board, a release calendar | `[grounded]` resume silence |
| G3 | Adoption metrics (R9) | discovery | No outcomes recorded | An important row sits unclear; metrics are the next thing interviewers ask about | Time-to-first-call, time-to-go-live, partner usage tracked per integration | A dashboard, a go-live tracker, the playbook | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified | risk_signal | medium | "Quartzline … Series B" (pasted header) | The posting may be stale, aggregated, or not from the employer | `[generic]` pattern for postings this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I interview with? | unresolved |
| RR2 | Pay and location withheld | unknown | — | not stated | The band may sit below your floor, or the role may be hybrid or on-site | `[inferred]` from the posting's silence | What is the base range, and where does the role sit? | unresolved |
| RR3 | 3+ years PM stated as a must-have | risk_signal | medium | "3+ years product management experience (must-have)" | Screeners often read a years line literally and filter by title | `[generic]` pattern for PM postings with a years bar | Is the 3+ years a hard screen, or would product-adjacent ownership count? | unresolved |
| RR4 | Decision rights unclear | unknown | — | "Own the roadmap" with two squads | The role may own scope but not priority calls | `[inferred]` from the posting's scope against its silence on authority | Which roadmap decisions does this role make alone, and which go through squad or leadership planning? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead your summary with the integration line as written: "Led 30+ client integrations of our REST APIs end to end, from scoping to go-live." Do not write "product manager," "owned roadmap" or "shipped" | Carries R2 and R10 without inflating any verb | `[grounded]` resume | pending your approval |
| P2 | Change "collecting client feedback for product" to "collecting client feedback for the product team's roadmap." Do not say you set priorities | Keeps the roadmap-input claim at its real scope (audit: relationship and verb drift) | `[grounded]` resume | pending your approval |
| P3 | Ask RR1 and RR3 of the recruiter before investing in the loop | Verifies the employer and the years screen | `[grounded]` RR1, RR3 | pending your approval |
| P4 | Prepare an honest answer to "have you owned a roadmap?" in the form: what you decided, what you only input, who decided the rest | Interviewers will probe the decision line | `[generic]` interview pattern for product roles | pending your approval |

## Evidence status

Verified: none yet. Your resume claims are leads, not verified evidence, until you confirm them in this engagement.

Unverified lead: a request-triage tool, from earlier notes. It prompts G1 and nothing more.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three search calls were refused because web search permission was declined in this session. Would have checked the employer exists and the posting is live (RR1) |
| 2. Role-family sweep | unavailable | Same refusal. Would have set the PM title, years and pay band against norms (RR2, RR3, market calibration) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I did not retry after the refusal. If you grant web search, the L1 checks can run.

Ahead of the closing block: a tuesday-dossier.md of this assessment is available if you want one for your records, and mock-interview can pick it up later.

## Upgrade menu

- The live posting link or Quartzline's careers page → resolves RR1 and lets the employer check run.
- Pay band and location → resolves RR2 and sets the posting against the role-family band.
- Permission for web search → runs the L1 employer and role-family checks above.
- Answers to G1–G3 → R1, R2, R5, R6, R7, R8, R9 can each move.
- The integration playbook, sanitized → an inspectable artifact that could raise the discovery and spec rows toward `high`.

**Questions**

G1 — Have you ever decided what got built, or in what order, even informally? Your earlier notes mention a request-triage tool. If that's right, what did you decide, did support use it, and could you show it?

G2 — Did you run sprint planning or backlog work with an engineering team, or only coordinate engineers on client builds?

G3 — For any integration or the playbook, did you track an adoption outcome, such as time to first call, time to go-live, or partner usage?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.