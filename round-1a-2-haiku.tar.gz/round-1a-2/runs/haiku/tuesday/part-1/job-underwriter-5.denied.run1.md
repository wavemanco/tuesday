**Yes, worth applying, as `conditional_go`.** Your stack covers the five must-have rows directly (R2–R6). The two open items are your location against the remote-US-or-Denver terms (R1) and whether the employer checks out, which I could not verify here (RR1).

**Fit ledger**

- `hard_gate`: unclear: R1 (remote-US or Denver location)
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: adjacent: R7 (BigQuery, named in the role's description); unclear: R8 (ingestion from app and CRM), R9 (data contracts analysts depend on)

R2–R6 are your years, Python, SQL, dbt, orchestration and data-quality work, each in your own figures. R7 is a credible bridge with its limit named. R8 and R9 are absent from your CV, so they are unknown, not missing.

**Opportunity ledger.** The posting is concrete: named responsibilities, a named stack and a stated salary (RR4). The employer is unverified from here (RR1). The team and scope are unnamed (RR3), and equity is unquantified (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (remote-US or Denver location); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) confirm your location and US work eligibility (R1); (2) find the role on Pellucid's own careers page and get the hiring team from the recruiter (RR1, RR3); (3) present BigQuery as adjacent, never as experience (R7)

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 states; Denver; 264 employees; Series C, $52M, Feb 2026 | `[grounded]` the about page as you pasted it; not checked externally |
| Role | Build and run ingestion from app and CRM, a dbt warehouse in BigQuery, and analyst data contracts | `[grounded]` posting as pasted |
| Scope read | Ownership of reporting pipelines and contracts, with no team named | `[inferred]` from "build and run" with no team named |
| Pay | $148,000–$166,000 plus equity | `[grounded]` posting |
| Market calibration | Senior, Series B–D: median $151,000, IQR $139,000–$163,500. The posting's midpoint ($157,000) sits in the upper half of the IQR; its low end is just under the median | `[grounded]` figures in the recruiter's report; `[generic]` that this band applies to this employer |
| Unknowns | Team size, hiring manager, equity size, your location fit | — |
| Contradictions | None between the posting and the about page as pasted | `[grounded]` both pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver location | hard_gate | unclear | none | hard_gate | No location or work-status statement from you | `[grounded]` posting terms | Your answer (question 1) |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years, your statement; no artifact yet | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, your statement | `[grounded]` your message | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake | `[grounded]` your message | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, your statement | `[grounded]` your message | none |
| R6 | Data quality testing | must_have | direct | medium | none | You set up a Great Expectations suite | `[grounded]` your message | none |
| R7 | BigQuery, the warehouse the role names | important | adjacent | medium | transferability | Snowflake and dbt carry over; BigQuery itself is unexercised | `[inferred]` adjacency from your Snowflake work | Gap G1 |
| R8 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your CV | `[grounded]` CV silence | Question 2 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your CV | `[grounded]` CV silence | Question 3 |

Your CV claims are capped at `medium` on this first pass because nothing has been inspected yet.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7) | transferability | Snowflake and dbt work; no BigQuery | Named in the role's description, so it will come up | Any BigQuery work, including a sandbox, cost tuning or a migration plan | A repo or model you could show | `[grounded]` your statements; `[inferred]` that the tool is central |
| G2 | Ingestion from app and CRM (R8) | discovery | Not in your CV | Core of the role's first job | Any source-to-warehouse loads, from a product database, a SaaS API or a CRM | A pipeline diagram or DAG | `[grounded]` CV silence |
| G3 | Data contracts (R9) | discovery | Not in your CV | Analysts depend on them | Schema agreements, versioning, a breaking-change process | A contract doc or review thread | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified from here | risk_signal | medium | "live online tutoring for K-12 schools in 31 US states" | The posting may be stale, or the company may not be the hiring entity | `[generic]` pattern for companies of this size, not a claim about this one. Web search was refused, so this is unchecked, not found missing | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Equity unquantified | unknown | — | "plus equity" | Equity could be worth much or little | `[inferred]` from the posting's silence on grant size | What is the equity grant for this role, with vesting and strike price? | unresolved |
| RR3 | Team and ownership unnamed | unknown | — | "Build and run the pipelines" | You might be the only data engineer on these pipelines | `[inferred]` from the absence of team or budget language | Who else builds and runs these pipelines, and which contracts and ingestion would be mine to own? | unresolved |
| RR4 | Stated pay and named stack | positive_signal | — | "$148,000–$166,000" | The salary is on the page and the stack is concrete | `[grounded]` posting | What does on-call look like for the reporting pipelines? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Find the role on Pellucid's careers page before you apply | RR1 | `[grounded]` RR1 | pending your approval |
| P2 | Describe the warehouse experience as: "Built and ran a dbt project of about 180 models on Snowflake. Have not worked in BigQuery." | R7 | `[grounded]` your sentences; traced clause by clause | pending your approval |
| P3 | Ask the recruiter about team, CRM ingestion and data contracts | RR3, R8, R9 | `[grounded]` register | pending your approval |
| P4 | Ask for equity size, vesting and strike price | RR2 | `[grounded]` RR2 | pending your approval |

## Evidence status

Verified as you stated them in this conversation: R2–R6 and R7's Snowflake base. Verification of R2–R6 is `medium` until an artifact is inspected. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused (web search permission not granted), so I could not check that the company exists or that the posting is live. The posting and about page were read as pasted. This is RR1 |
| 2. Role-family sweep | skipped | Your recruiter's pay report already covers Senior Data Engineer at Series B–D companies, so the band comes from it |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Your location and US work-eligibility answer → R1 closes; the decision moves to `go` or `no_go`.
- A link to the live posting on Pellucid's careers page, or the recruiter's email domain → RR1 closes.
- Any BigQuery work, including a sandbox → R7 strengthens.
- A work sample of a data contract or a CRM ingestion pipeline → R8 or R9 rise to `high`.
- Your pay floor → the band can be set against it.
- Permission for web search → I can re-run target 1 (company and posting check).

If you want it, I can write this up as a `tuesday-dossier.md` to carry into prep.

**Questions**

1. Are you based in the US, and would you take fully remote, or could you get to Denver? (R1)
2. Have you built ingestion from a product database or a CRM into a warehouse? What was the source, what tooling did you use, and what did you own? (G2, R8)
3. Have you owned data contracts with analysts, such as schema agreements, versioning or a breaking-change process? Which ones, and who enforced them? (G3, R9)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.