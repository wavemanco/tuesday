**Probably yes, but hold the application until one answer comes back: `hold_pending_answers`.** Your fit on the core duties is strong on your own account. The posting contradicts itself on location, and that decides whether the role is open to you at all.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (location: fully remote or Leeds four days a week)
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — adjacent: R9 (pet-insurance product knowledge)
- `preferred` — direct: R8

R2–R7 — your core duties, each `medium`: confirmed by your account, not yet backed by an artifact. R9 (`medium`) — a bridge from motor, with its limit named. R1 — the one gate the inputs don't settle.

**Opportunity ledger.** Risks: RR1 (the pasted JD says fully remote, the careers page says Leeds four days a week) and RR2 (my company search found no independent footprint for Brindlemoor). Unknowns: RR3 (pay), RR4 (decision rights), RR5 (direct reports). Positive: RR6 (the director's public work on monitoring rating models overlaps the role's first duty).

- **Hard gates:** none failed; unconfirmed: R1 (location: fully remote or Leeds four days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** If the offer is fully remote, or you can work from Leeds four days a week, this moves to `conditional_go`, with conditions: pay sits in the band, the company checks out, and decision rights are concrete. If the role is in Leeds and you can't do that, it is `no_go` on R1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor; its careers page describes a pet-insurance product. No independent company profile found | `[grounded]` careers page; `[grounded]` empty company search |
| Role | Senior Pricing Analyst; owns pricing analytics for the pet product; reports to the Director of Pricing | `[grounded]` careers page and your JD |
| Location | Contradiction: "Fully remote (UK)" in your JD, "Leeds office four days a week" on the careers page | `[grounded]` both sources |
| Scope read | Build and monitor rating models, design and read tests, turn results into recommendations: a normal senior-analyst remit | `[inferred]` from the JD's verbs |
| Market calibration | UK senior pricing analysts at insurers and insurtechs: median £58,400, interquartile range £52,100–£64,900 | `[generic]` Pricewell 2026 survey (n=612), read from its search snippet only |
| Unknowns | Pay; decision rights over price changes; direct reports; company size and status | — |
| Contradictions | Location (above) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) per JD; Leeds four days a week per careers page | hard_gate | unclear | none | hard_gate | No candidate constraint given, so no claim to grade. The two sources conflict and nothing settles it | `[grounded]` both sources | Q1 below |
| R2 | Build and monitor rating models | must_have | direct | medium | none | You built and maintained the young-driver GLM. "Maintained" is not proof of "monitored" | `[grounded]` your account | Ask for a monitoring example (drift check, recalibration trigger) |
| R3 | GLM experience | must_have | direct | medium | none | Same model, same caveat: specific and yours, no artifact yet | `[grounded]` your account | Upgrade menu |
| R4 | Design and read price tests | must_have | direct | medium | none | 14 tests last year with underwriting. Ran versus designed is not yet separated | `[grounded]` your account | Q2 below |
| R5 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | `[grounded]` your account | None |
| R6 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, two as senior analyst. A length requirement, not a gate | `[grounded]` your account | None |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your account | None |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your account; JD wording | None |
| R9 | Pet-insurance product knowledge (implied by "our pet-insurance product") | important | adjacent | medium | transferability | Motor pricing carries over: rating, GLM, test design. No pet-specific work | `[inferred]` from the JD's product name against your background; `[generic]` that pet books price differently from motor | G1 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R9, important) | transferability | Motor insurance only; no pet data, claims or pricing work | The bridge is the objection most likely to come up; a limit stated plainly is what makes it hold | Any pet-insurance reading, comparison or conversation about pet pricing; general insurance pricing principles you have applied to new lines | Reading notes, a pet-product comparison, a short write-up of how you'd approach a pet rating model | `[inferred]` bridge from motor; `[generic]` that pet books differ from motor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location terms conflict | risk_signal | medium | "Fully remote (UK)" (your JD); "Leeds office four days a week" (careers page) | One source is out of date, or the arrangement is different from either description | `[grounded]` both sources; `[inferred]` on the cause | Is this role fully remote, or based in Leeds four days a week, and which would the offer state? | unresolved |
| RR2 | Company footprint not established | risk_signal | medium | "Own pricing analytics for our pet-insurance product" | Brindlemoor's size, funding and regulatory status are not established from independent sources | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` empty search | How many people work at Brindlemoor, and who regulates the pet product this role prices? | unresolved |
| RR3 | Pay not stated | unknown | — | No salary in the JD text or on the careers page | The budget may sit above or below the survey band, or pay may simply not be published | `[inferred]` from the silence, against the `[generic]` band | What base salary is budgeted for this role? | unresolved |
| RR4 | Decision rights unclear | unknown | — | "turn the results into recommendations for underwriting and product" | The role may recommend price changes while underwriting or product decide them | `[inferred]` from "recommendations" against silence on decision rights | Which price changes does this role decide itself, and which go to underwriting or product? | unresolved |
| RR5 | Direct reports unstated | unknown | — | "reports to the Director of Pricing" | The role may have no direct reports; the posting says nothing either way | `[inferred]` from the silence | Does this role have direct reports now, or planned? | unresolved |
| RR6 | Manager's public focus overlaps the role | positive_signal | — | Forum talk "Small Books, Loud Errors" on monitoring rating models in small books | The director's stated focus is the role's first duty, and it overlaps your strongest-sourced experience | `[grounded]` profile snippet; `[inferred]` on the overlap | What changed in the team's practice after the monitoring work in that talk? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with your own sentence: "built and maintained the GLM rating model for the young-driver book." Don't turn "maintained" into "monitored" unless you did monitor it | R2, R3 | `[grounded]` your account | pending your approval |
| A1 | Ask the recruiter before applying: fully remote or Leeds four days a week, and the base-salary band | RR1, RR3 | `[grounded]` the register | pending your approval |
| A2 | Check Brindlemoor on its own site and public listings (headcount, regulator status) before investing time | RR2 | `[generic]` standard check, not a claim about this company | pending your approval |
| W1 | Pet bridge: motor rating, GLM and test design carry over. The limit: no pet claims or pet pricing work yet | R9 | `[inferred]` from your background and the JD | pending your approval |
| Q1 | In the first interview, ask RR4 and RR5 verbatim | The register doubles as interview preparation | `[grounded]` the register | pending your approval |

## Evidence status

Verified: none yet. Everything above is your account, which is self-report until it is probed or backed by an artifact.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results) and "Brindlemoor Senior Pricing Analyst pet insurance careers"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved the location contradiction (RR1), the company-footprint gap (RR2), and the reports-to line (RR5) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary GLM pricing role", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Read from the snippet only; not fetched. Moved the market calibration and the pay check (RR3) |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Snippet only. Moved the positioning (RR6, W1) |

## Upgrade menu

- A test design write-up or the brief for one of your 14 tests → R4 to `high`.
- A monitoring pack or drift report from the young-driver model → R2 to `high`.
- The recruiter's answer on location → R1 and RR1 close, and the status moves.
- The budgeted salary → RR3 closes; the figure is set against the band.
- A deeper pass on Brindlemoor (funding, leadership changes, public candidate reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

You can keep this as `tuesday-dossier.md` for later work if you want it.

**Questions:**

1. R1 / RR1 — Is your constraint "fully remote only", or could you work from Leeds four days a week?
2. R4 — Of the 14 price tests, which did you design, and which did you only run and read?
3. G1 — What do you already know about pet-insurance pricing, even secondhand?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.