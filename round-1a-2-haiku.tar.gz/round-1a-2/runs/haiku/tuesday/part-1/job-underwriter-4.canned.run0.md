**Yes, worth applying, once one condition is settled.** `conditional_go`

**Decision snapshot**

- **Fit ledger.**
  - `hard_gate`: unclear: R1 (working location), R2 (base pay)
  - `must_have`: direct: R3, R4, R5, R6, R7
  - `important`: adjacent: R9 (pet-insurance product)
  - `preferred`: direct: R8 (insurance experience)

  R9 — a credible bridge, its limit named; R1 (`unclear`) — the posting and the JD disagree on location; R2 (`unclear`) — pay is withheld.
- **Opportunity ledger.** Sound but under-specified. The location contradiction (RR1) and the withheld pay (RR2) are unresolved, and the company's public footprint is thin (RR3). One entry runs the other way: the director has published on monitoring rating models (RR6).
- **Hard gates:** none failed (R1 `unclear`, R2 `unclear`); unconfirmed: R1 (working location), R2 (base pay); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the conditions for `go` are (1) the working pattern is one you can do (R1); (2) the pay is acceptable against the band (R2); (3) the pet-product bridge is presented with its limit named, not as pet expertise (R9).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor; the careers page is on its own domain and the posting is live | `[grounded]` careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product; reports to the Director of Pricing | `[grounded]` careers page; JD |
| Working pattern | Posting says Leeds office four days a week; your JD says fully remote (UK) | `[grounded]` both sources |
| Market calibration | Pricewell 2026 survey, senior pricing analyst at UK insurers and insurtechs (n=612): median £58,400, interquartile range £52,100–£64,900. The posting withholds the salary, so this is what to expect, not this employer's offer | `[generic]` role-family sweep |
| Unknowns | Working location; base pay; contract type; whether the role has direct reports; how much of the company's footprint exists beyond its careers page | — |
| Contradictions | Location, as above | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Working location: Leeds four days a week vs fully remote UK | hard_gate | unclear | none | hard_gate | Sources contradict; your location and pattern not given, so no constraint to grade | `[grounded]` careers page; JD | Q1 |
| R2 | Base pay (withheld by the posting) | hard_gate | unclear | none | hard_gate | No salary published; your floor not given. Band is `[generic]` | `[grounded]` posting silence; `[generic]` band | Q2 |
| R3 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two senior. Self-report, no artifact yet | `[grounded]` your message | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact yet | `[grounded]` your message | none |
| R5 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM for the young-driver book. Motor, not pet | `[grounded]` your message | none |
| R6 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your message | none |
| R7 | Design and read price tests; recommendations to underwriting and product | must_have | direct | medium | none | 14 tests last year with the underwriting team | `[grounded]` your message | none |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your message | none |
| R9 | Pet-insurance product pricing | important | adjacent | medium | transferability | Motor personal-lines pricing carries over. No pet-specific experience; limits are pet risk drivers and claims patterns | `[inferred]` product line against your motor history; limits `[generic]` | G1 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product (R9, important) | transferability | Motor pricing and GLM work; no pet product | The posting's product is pet, so this is the objection most likely to be raised | Any pricing or monitoring work on a new or thin book; any product whose risk drivers differed from motor; any work with claims or vet-cost data | A short note on how a motor risk driver was tested, or a small-book analysis | `[inferred]` bridge; `[generic]` that this is the likely objection |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working location contradicts across sources | risk_signal | medium | "Leeds office four days a week" (careers page); JD: "Fully remote (UK)" | The posting may be out of date, or the remote wording may apply to a different hire | `[inferred]` from the two sources disagreeing | Is this role Leeds four days a week, or fully remote across the UK? | unresolved |
| RR2 | Base pay withheld | unknown | — | Posting gives no salary | The budget may sit below the band, or the posting may simply not publish pay | `[inferred]` from the posting's silence, against the `[generic]` band | What base salary is budgeted for this post? | unresolved |
| RR3 | Thin public footprint beyond the careers page | unknown | — | Search for the company and "insurtech pet insurance" returned no results | A small or new company often has little public footprint; this is a pattern, not a finding about Brindlemoor | `[generic]` pattern for companies of this size | Can you point me to the product, stage and team size? | unresolved |
| RR4 | Line management not stated; you have not managed people | unknown | — | JD silent on direct reports; "own pricing analytics" | The role may carry stakeholder leadership without reports, or may expect people management later | `[inferred]` from the JD's silence and its "own" language | Does this role have direct reports now or planned, and how is success measured for it? | unresolved |
| RR5 | Pet-specific pricing decisions unknown | risk_signal | low | "own pricing analytics for our pet-insurance product" | The role may need pet risk knowledge quickly | `[inferred]` from the product line | Which pricing decisions in the pet book would this role make in its first six months? | unresolved |
| RR6 | Director publishes on monitoring rating models | positive_signal | — | 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors" | Monitoring discipline may be taken seriously in this team | `[inferred]` from one public talk; not a claim about the team | Which rating models does the monitoring remit cover today, and how is drift caught? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead the CV's GLM and price-test lines with what you owned and what changed; add no new claims | Positions R5 and R7 for the reader | `[grounded]` R5, R7 | resume_edits_pending_approval |
| P2 | Put RR1, RR2 and RR4 to Odile before investing in the full loop | These decide whether the role fits | `[grounded]` register | pending your approval |
| P3 | Frame the pet bridge (R9) as transferable motor work with its limit named | Avoids the claim an interviewer will test | `[inferred]` from G1 | pending your approval |

**Evidence status**

Verified: none yet. Your message is self-report, so it counts as intake prose until you confirm specifics.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor careers Senior Pricing Analyst" and fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst): posting live, Leeds four days a week, reports to the Director of Pricing. Searched "Brindlemoor insurtech pet insurance": no results. Moved R1 and RR1, and the thin-footprint entry RR3 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK pet insurance salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved the `[generic]` band under R2 and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned a public profile (linkedin.example/in/odile-varga): previously head of pricing analytics at Calloway Re for six years, and a 2025 forum talk, "Small Books, Loud Errors", on monitoring rating models. Moved RR6 and the positioning read in P3 |

Your background is at a motor insurer. Odile's public work is on monitoring rating models in small books, which suggests the monitoring story in your GLM work is the one to lead with for this reader. That reading is `[inferred]`.

I can write this up as `tuesday-dossier.md` if you want a file to keep.

**Upgrade menu**

- Confirmation of the working location (R1) → the gate resolves, and the decision likely simplifies to `go` or `no_go`.
- The budgeted base salary (R2, RR2) → set against the `[generic]` band above.
- An answer to G1, or any pet or non-motor pricing work you can point to → R9 moves toward `direct` or narrows.
- A deeper pass on Brindlemoor (funding, leadership changes, news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

Q1 (R1): Can you work from Leeds four days a week, or is remote-only a condition for you?
Q2 (R2): What is your base-pay floor?
G1 (R9): Have you priced or monitored a product whose risk drivers differed from motor, such as home, pet, travel, or a new book with thin data? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.