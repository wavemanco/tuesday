**Yes, it's worth applying, on conditions.** Your fit is strong on the requirements the posting lists. The open questions are about location, pay floor, and data contracts, and I can't settle those from the posting. Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver location and eligibility), R2 (Salary $148k–$166k plus equity)
- `must_have`: direct: R3 (5+ years data engineering), R4 (Strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (Orchestration with Airflow or similar), R7 (Experience with data quality testing)
- `important`: adjacent: R8 (BigQuery warehouse); unclear: R9 (Data contracts our analysts depend on), R10 (Ingestion from our app and CRM)

R8 — Snowflake and dbt carry over; BigQuery itself is new. R9 and R10 — your background doesn't mention either, so they need a question, not an assumption.

**Opportunity ledger.** The employer checks out and the pay is in the normal band (RR1, RR4). Two things are unknown: whether the BigQuery warehouse is greenfield or live, and who owns the pipelines day to day (RR2, RR3). No severe red flags.

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver location and eligibility), R2 (pay against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) location and US eligibility confirmed for the remote or Denver option (R1); (2) $148k is at or above your floor (R2); (3) you can speak to data contracts or ingestion from your Snowflake work, or you frame them as the stretch they are (R9, R10).

## Research

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched pellucidlearning.com/careers/senior-data-engineer: live, and the text matches what you pasted. Searched "Pellucid Learning Series C funding 2026", which returned pellucidlearning.com/about with the description you pasted. The About text is from a search snippet, not a full fetch. A search for "Pellucid Learning live online tutoring K-12 Denver" returned nothing. The employer is attributed to its own domain: the RR1 positive signal. |
| 2. Role-family sweep | yes | Searched "Datawright 2026 Data Engineering Pay Report senior data engineer median base salary", which returned datawright.example/2026-data-engineering-pay-report with the band you gave. Market calibration is `[generic]`. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office; US eligibility | hard_gate | unclear | none | hard_gate | No location or authorization constraint was given. The posting names both options. | `[grounded]` posting; candidate constraint not given | Ask: are you authorized to work in the US, and can you work from your location or Denver? |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor was given. Equity is unquantified. | `[grounded]` posting; candidate constraint not given | Ask: is $148k your floor, and what is the equity worth to you? |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company. Self-reported and unprobed, so `medium` is the ceiling. | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Both used daily. | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake. Snowflake is the cloud warehouse the requirement asks for. | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration. | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations test suite. | `[grounded]` your background | none |
| R8 | BigQuery warehouse (named in the role description, not the requirements) | important | adjacent | medium | transferability | Snowflake and dbt carry over. BigQuery itself is absent from your background. | `[inferred]` from the posting's description, against your statement that you've never used BigQuery | Bridge case below |
| R9 | Data contracts our analysts depend on | important | unclear | low | discovery | Your background doesn't mention contracts. | `[inferred]` from the description | Ask the question in the closing block |
| R10 | Ingestion from app and CRM | important | unclear | low | discovery | Ingestion is likely in your Snowflake work, but it's not stated. | `[inferred]` from the description | Ask the question in the closing block |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake warehouse and dbt, with no BigQuery | The posting names BigQuery as the warehouse, so it's the most likely technical objection | Any GCP work, or a warehouse migration or move between platforms | A migration plan, a dbt project on any platform, or a GCP project | `[inferred]` bridge from your Snowflake work; `[generic]` that BigQuery is the likeliest objection |
| G2 | Data contracts (R9, important) | discovery | Your background doesn't mention contracts | The posting names them directly for analysts | Schema agreements with producers, breaking-change rules, or a data-quality gate tied to consumers | A contract, schema doc, or change-process write-up | `[grounded]` posting; `[inferred]` that contracts are a probe area |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer established | positive_signal | — | "Series C ($52M, February 2026)"; "264 employees" | The employer is funded, sized as described, and the posting is live on its own domain | `[grounded]` careers page fetched; About text from search snippet | Which team would this role sit in, and who manages it? | noted |
| RR2 | Greenfield or live warehouse | unknown | — | "Build and run the pipelines … a dbt-modelled warehouse in BigQuery" | The BigQuery warehouse may be newly built, which changes the scope and the BigQuery gap | `[inferred]` from "build and run" against the posting's silence on migration | Is the BigQuery warehouse being built now or already live, and how many analysts depend on it? | unresolved |
| RR3 | Ownership unclear | unknown | — | "Senior Data Engineer … build and run the pipelines" | The role may own one domain's pipelines, or the whole platform | `[generic]` typical scope for the title (from the Datawright profile); `[inferred]` from the posting's silence on ownership | Which pipelines does this role own day to day, and is the role working alone or inside a team? | unresolved |
| RR4 | Equity unquantified | unknown | — | "plus equity" | The equity value is unknown, so the total pay can't be compared with the band | `[grounded]` posting; no grant terms given | What is the grant size, vesting schedule, and strike price, and what is the current valuation? | unresolved |

No payment requests, and no contact off the employer's domain. The register holds no severe red flags.

**Market calibration (`[generic]`).** The Datawright 2026 report puts a Senior Data Engineer at Series B–D companies at a $151,000 base median and a $139,000–$163,500 interquartile range. The posted $148k–$166k sits around that median and into the upper half of the range. This is a pattern for the role family, not a claim about this employer.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm location and eligibility, and your pay floor, before applying | R1, R2 | `[grounded]` gate rows | pending your approval |
| A2 | Describe the Snowflake work as the transferable base, and name BigQuery as new | R8 | `[inferred]` bridge | pending your approval |
| A3 | Ask RR2 and RR3 verbatim in the first recruiter call | Both are unknown and change the scope | `[grounded]` register | pending your approval |

I haven't drafted any resume or cover-letter language. If you want that, it comes next, and every line stays within what you've told me.

## Evidence status

Verified: R3, R4, R5, R6, R7 claims (your background, self-reported). Unverified: R8 is an adjacency read, not a claim. Rejected inferences: none yet.

**Dossier offer:** I can write these findings to a `tuesday-dossier.md` for later use with mock-interview if you want.

## Upgrade menu

- Location, eligibility, and pay floor confirmed → R1 and R2 move to `direct`, and the decision can become `go`.
- Any GCP or warehouse-migration work, or a BigQuery project → R8 moves toward `direct`.
- A piece of work on data contracts or ingestion, such as a schema doc, a change-process note, or a pipeline you built → R9 and R10 move off `unclear`.
- The hiring manager's name → RR3 can be checked against their public footprint.

1. Are you authorized to work in the US, and can you work remotely or from Denver? (R1)
2. Is $148,000 your floor, and what do you need from the equity to make the total package worth it? (R2, RR4)
3. Have you defined data contracts, schemas, or ingestion for consumers of your warehouse, even informally? If yes, describe one. If not, say skip. (R9, R10)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.