**No.** R1 and R2 both fail your hard constraints, and the posting states both outright. Decision: `no_go`.

Your instinct is picking up real things. The top of the stated base range is $65k below your $150k floor, and the office requirement is written as "no exceptions."

- **Hard gates:** failed: R1 (Base salary at least $150k), R2 (Remote-only work). Candidate constraints given, so the checks ran.
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** Novaline would have to offer base pay of at least $150k and accept remote work, in writing. The posting's "no exceptions" makes that unlikely.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1, R2
- `must_have` — direct: R3, R4, R5, R9 · unclear: R6 (SEO/content), R7 (PR, brand, partnerships, sales ops)
- `important` — direct: R8

R3, R4, R5, R9 are the paid, lifecycle, team and growth-leadership work you've described. R6 and R7 are unclear, not absent: your account doesn't mention them, so they're open questions.

**Opportunity ledger.** RR1 and RR2 are confirmed red flags from the posting's own terms. RR3 (one-person scope), RR4 (always-on hours) and RR5 (undefined success metrics) are risk signals about the role. RR6 is the one positive: "profitable since day one," a claim from the posting alone.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting. Not verified: see evidence status |
| Scope | Seven revenue functions, "team of one to start," reporting to the CEO | `[grounded]` posting |
| Pay | $70–85k base plus equity | `[grounded]` posting |
| Market calibration | Not run. Web search was refused, so I can't say what this title pays | — |
| Working pattern | Austin on-site, five days, evenings and weekends | `[grounded]` posting |
| Contradictions | "Team of one" against "8+ years growth leadership" and a seven-function mandate | `[inferred]` from the posting's own wording |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base salary at least $150k | hard_gate | hard_gate_fail | high | hard_gate | Your stated floor, specific and confirmed. Posting: $70–85k | `[grounded]` posting and your constraint | None; only new terms resolve it |
| R2 | Remote-only, Portland | hard_gate | hard_gate_fail | high | hard_gate | Posting requires Austin five days a week, "no exceptions" | `[grounded]` posting and your constraint | None; only new terms resolve it |
| R3 | Paid acquisition ownership | must_have | direct | medium | none | Owned paid with a budget you controlled. No inspectable artifact yet | `[grounded]` intake prose | None |
| R4 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle; Braze in use | `[grounded]` intake prose | None |
| R5 | Growth leadership, team building | must_have | direct | medium | none | Built and managed teams of 3–7; scaled $8M to $40M ARR | `[grounded]` intake prose | None |
| R6 | SEO/content | must_have | unclear | none | discovery | Not mentioned in your account | `[grounded]` absence in intake | Ask whether you've owned it |
| R7 | PR, brand, partnerships, sales ops | must_have | unclear | none | discovery | Not mentioned in your account | `[grounded]` absence in intake | Ask whether you've owned any of these |
| R8 | Experimentation, analytics | important | direct | medium | none | SQL, GA4, experimentation owned | `[grounded]` intake prose | None |
| R9 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then Head of Growth | `[grounded]` intake prose | None |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|
| RR1 | Pay sits $65k or more below your floor (see R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | `[grounded]` posting against your floor | What base salary is budgeted for this role? | confirmed |
| RR2 | Office requirement is non-negotiable (see R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | `[grounded]` posting against your constraint | Would the role consider remote work, and if not, why not? | confirmed |
| RR3 | Responsibility without resources | risk_signal | medium | "Team of one to start … we believe in players who don't need a bench" | `[inferred]` from seven functions against one person | What budget and headcount back paid, lifecycle and sales ops in year one? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "Evenings and weekends when it matters is just who we are" | `[grounded]` posting wording | How often does this role work evenings or weekends, and what happens when it's not possible? | unresolved |
| RR5 | Absent success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | `[grounded]` posting wording | What are the success metrics for year one, and when will they be fixed? | unresolved |
| RR6 | Stated financial health | positive_signal | — | "profitable since day one" | `[grounded]` posting only, unverified | What is the current runway or revenue trajectory? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply on these terms | R1 and R2 fail | `[grounded]` posting and your constraints | proposed |
| A2 | If you want to test the terms, send one written question to the recruiter on base pay and remote work | RR1, RR2 | `[grounded]` register | pending your approval; I won't send anything |

## Evidence status

Verified: R1 and R2, your stated constraints (specific, `high`). Everything else is intake prose at `medium` or below, unverified.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused: web search permission was not granted. It would have checked that Novaline exists as described and the posting is live. The employer-not-established entry is therefore not assessed either way |
| 2. Role-family sweep | unavailable | Same refusal. It would have set the $70–85k against market pay for this title. The gap against your floor doesn't depend on it |
| 3. Hiring manager's footprint | n/a | No name was given |

## Upgrade menu

- Granting web search runs targets 1 and 2: it would confirm Novaline exists, whether the posting is live, and a market band for the title. Those results can't reverse `no_go` on R1 and R2 alone.
- A written answer from Novaline on base pay and remote work is the only thing that could move R1 and R2, and it would have to change both.
- If you've owned SEO/content, PR, partnerships or sales ops, a specific example would move R6 and R7 from unclear.

If you want this on file, I can write it up as `tuesday-dossier.md`.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.