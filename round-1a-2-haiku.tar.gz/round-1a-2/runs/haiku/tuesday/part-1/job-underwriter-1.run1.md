**Yes, apply, on conditions: `conditional_go`.** On the core of this role you're a credible fit. The gaps are clinician-facing work, people management, and healthcare data, and a hiring panel will probe all three.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · unclear: none · absent: none · adjacent: R6
- `important` — adjacent: R7 · unclear: R8
- `preferred` — adjacent: R9

R1–R5 are direct, each at `medium`, because the evidence is your own account plus the work you described, with no artifacts yet (R1 5+ years, R2 daily SQL, R3 the 30+ test program, R4 the Looker build, R5 the exec memo). R6 (clinician partnership) is `adjacent` at `low`. R7 (metrics layer) is `adjacent` at `medium`. R8 (mentoring two analysts) is `unclear` at `low`. R9 (healthcare/HIPAA, a plus) is `adjacent` at `medium`. Your GDPR/CCPA and consent-model work is the bridge, and the limit is that you haven't handled PHI or HIPAA obligations.

**Opportunity ledger.** Scope is clear and the responsibilities are specific (RR3). Employer and posting are unverified, because the research calls were refused (RR1). Clinician scope, mentoring structure, pay, location and contract type are all unstated (RR2, RR4).

- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and posting verify on Harborlight's own careers page; (2) the clinician-facing scope is concrete, not a generic "partner with stakeholders"; (3) the mentoring role and reporting line are clear.

**Research tier: L1 — searches 3 of 5, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | All three search calls were refused because web search permission wasn't granted. I did not retry them. Would have checked that the company exists as described and that the posting is live. |
| 2. Role-family sweep | unavailable | Would have set a title and pay band for this seniority. No band is stated here. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, ~400 people, Series C, care-navigation app | `[grounded]` your paste; not yet verified |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, mentoring two juniors | `[grounded]` JD |
| Scope read | A senior IC scope with people-leadership elements; mentoring two analysts is ordinary for the title | `[inferred]` from the responsibility list |
| Market calibration | Not run; no band | — |
| Unknowns | Location, pay, contract type, reporting line, how much clinical work the role does | — |
| Contradictions | None visible in the material | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years, self-reported; no inspectable artifact yet | `[grounded]` your account | none |
| R2 | Expert SQL | must_have | direct | medium | presentation | Daily SQL on Snowflake is what you have; "expert" is their word, so don't claim it unless you agree | `[grounded]` your account | Phrase as "daily SQL on Snowflake" |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and a pricing test behind an 11% retention lift | `[grounded]` your account | Confirm the test design and how the lift was measured before quoting it |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the instance and 40+ governed dashboards | `[grounded]` your account | none |
| R5 | Written communication for non-technical stakeholders | must_have | direct | medium | none | Monthly exec memo and monthly VP Product presentation | `[grounded]` your account | none |
| R6 | Partner with clinicians | must_have | adjacent | low | transferability | Partnering with PMs and execs is the nearby work; no clinician work described | `[inferred]` from your stakeholder work | Question G1 |
| R7 | Define and maintain the metrics layer | important | adjacent | medium | transferability | Governed dashboards and the consent model are the near thing; metric-definition ownership isn't evidenced | `[grounded]` your account; `[inferred]` the bridge | Question G1 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Not in your account | `[grounded]` absence | Question G2 |
| R9 | Healthcare data, HIPAA (a plus) | preferred | adjacent | medium | transferability | GDPR/CCPA PII handling and consent state; no PHI or HIPAA work. Limit: HIPAA's obligations are a different regime | `[grounded]` your account; `[generic]` that healthcare analysts commonly face PHI rules | Question G3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Clinician work (R6, R7) | transferability | Stakeholder partnership with PMs and execs; no clinical or care-team work | A must-have row at `adjacent`; this is the most likely objection | Any work with care teams, clinical content, payer or provider partners, or clinical-quality metrics | A metric spec, a stakeholder brief, a readout | `[inferred]` bridge from your stakeholder work |
| G2 | Mentoring (R8) | discovery | No people-leadership evidence | Affects whether the role is a fit on its own terms | Informal onboarding of analysts; code or query review; a reporting line | Team notes, a onboarding plan | `[grounded]` absence |
| G3 | Healthcare data (R9) | transferability | Consumer PII and consent work; no PHI | A preferred row; the honest answer is the bridge plus its limit | Any work with sensitive data, data-use agreements, or audit | A consent-model doc (sanitized) | `[generic]` regime difference |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting unverified | unknown | — | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Company may exist as described; research could not check | `[grounded]` research unavailable | "Can you point me at the live posting on your careers site, and who would I be interviewing with?" | unresolved |
| RR2 | Clinician scope undefined | unknown | — | "partner with product managers and clinicians" | Clinician work may be occasional, or may be daily | `[inferred]` from the responsibility list | "How much of this role's work is with clinicians, and which clinical decisions does the analysis feed?" | unresolved |
| RR3 | Specific scope signals | positive_signal | — | "define and maintain the metrics layer … build self-serve dashboards in Looker" | Scope is concrete and measurable | `[grounded]` JD | "Which metrics does the metrics layer cover at launch?" | noted |
| RR4 | Pay, location, contract withheld | unknown | — | not stated | Unknown until you share constraints | `[grounded]` absence | "What is the pay band, location policy and contract type?" | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting and employer before investing in an application | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the experiment program and the Looker build, and name the healthcare bridge as adjacent | see R3, R4, R9 | `[grounded]` rows | pending your approval |
| A3 | Prepare one honest answer on clinician work and one on mentoring | see R6, R8 | `[grounded]` rows | pending your approval |

Nothing above is approved for external use. Any CV or outreach wording needs your approval before it goes anywhere.

**Dossier offer.** I can write this up as a `tuesday-dossier.md` file you can keep and reuse, if you want one.

**Upgrade menu**

- A link to the live posting, or the careers-page listing → RR1 closes, and the employer question becomes checkable.
- A pay band or the posted salary → RR4 closes; I can set it against a role-family band once a search can run.
- A description of any clinician-facing work → R6 moves from `adjacent` toward `direct`.
- A deeper look at Harborlight (funding, leadership, recent news) → available if web search is allowed; it's not offered as an extra search here.

**Questions**

G1 — Have you worked with clinicians, care teams or clinical content, even as a stakeholder? What did you own, and what happened?

G2 — Have you formally managed or mentored analysts, or only onboarded or reviewed their work informally?

G3 — Are there non-negotiables on location or remote work, work authorization, a pay floor, or contract type?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.