**Yes, it's worth applying, on two checks: `conditional_go`.** Apply once the posting is confirmed live on Pellucid's own careers page, and once you've confirmed the location and the $148,000 base clear your constraints.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office), R2 (base salary $148,000–$166,000)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (orchestration with Airflow or similar), R7 (data quality testing)
- `important` — adjacent: R8 (BigQuery); unclear: R9 (data contracts analysts depend on), R10 (ingestion from app and CRM)

R1, R2 — gate terms your constraints don't yet settle; R8 — transferable from Snowflake, limit named; R9, R10 — unknown until you answer G2.

**Opportunity ledger.** Mostly sound: pay sits in the market band (RR1) and the scope is one domain with no reports named (RR3). Open: the employer and live posting are unverified (RR2), no hiring manager is named (RR4), and BigQuery expectations are unstated (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (base salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR2 — the posting is live on pellucidlearning.com and the recruiter's contact matches that domain; (2) R1 and R2 — you confirm location and pay floor; (3) R8 is framed as transferable, never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online K-12 tutoring, 31 states, founded 2016, Denver, 264 employees, Series C ($52M, Feb 2026) | `[grounded]` your paste of their About page; not verified, see Evidence status |
| Mandate | Pipelines behind the tutoring platform's reporting: app and CRM ingestion, dbt models in BigQuery, data contracts | `[grounded]` posting |
| Working pattern | Remote (US) or Denver office | `[grounded]` posting |
| Scope read | One domain (reporting), no direct reports named | `[inferred]` from the posting's wording |
| Market calibration | Senior at Series B–D: base median $151,000, IQR $139,000–$163,500. The posted $148,000–$166,000 sits around the median up into the upper quartile | `[generic]` recruiter-supplied Datawright 2026 report (n=2,310); `[grounded]` posted figures |
| Unknowns | Hiring manager, equity value, whether ingestion and contracts sit with this role, BigQuery ramp expectations, your location and pay floor | — |
| Contradictions | None found in the material you pasted | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No candidate location given | `[grounded]` posting | G3 |
| R2 | Base salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor given; the band itself sits at market | `[grounded]` posting; `[generic]` band | G3 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years stated, inside the report's 5–8 senior band | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact yet | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | ~180-model dbt project on Snowflake | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow stated | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Great Expectations suite stated | `[grounded]` your background | none |
| R8 | BigQuery warehouse | important | adjacent | medium | transferability | Snowflake and dbt carry over; BigQuery itself never used | `[inferred]` from the Snowflake work; `[generic]` that dbt carries across warehouses with adapter-specific setup | G1 |
| R9 | Data contracts analysts depend on | important | unclear | none | discovery | CV silent on consumer contracts | `[grounded]` posting; CV silence | G2 |
| R10 | Ingestion from app and CRM | important | unclear | none | discovery | CV silent on app or CRM sources | `[grounded]` posting; CV silence | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake dbt work; no BigQuery | Named in the role description | Any GCP work, including a sandbox or side project; moving dbt models between warehouses | A repo or sandbox project | `[inferred]` transfer from Snowflake; `[generic]` on adapter differences |
| G2 | Contracts and ingestion (R9, R10, important) | discovery | CV names dbt, Airflow, GE; silent on contracts and app/CRM ingestion | Both are in the role's own description | Schema agreements with analysts; versioned models with consumers; ingestion from an app database, CRM API or webhooks | A contract doc, schema spec or ingestion DAG | `[grounded]` posting |
| G3 | Location and pay (R1, R2, hard_gate) | hard_gate | No location or floor given | Gate terms; unsettled means unchecked | — | Your own statement | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay disclosed and inside the market band | positive_signal | — | "$148,000–$166,000" | Pay is realistic for the title and stage | `[grounded]` posting; `[generic]` band | What is the target base within this range, and does it differ for remote hires? | noted |
| RR2 | Employer and live posting unverified | unknown | — | "Series C ($52M, February 2026)" | Research was refused this session, so company facts rest on your paste alone | `[grounded]` your paste; the gap is in this run, not in the employer | Which recruiter or team is this posting open under, and where is the live posting on your careers page? | unresolved |
| RR3 | One domain, no direct reports named | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | Ownership is scoped; the posting names no reports | `[grounded]` posting; `[generic]` typical senior scope | Which parts of ingestion and contracts sit with this role, and which with other teams? | noted |
| RR4 | No hiring manager named | unknown | — | (no hiring manager in the posting) | Could be a recruiter-led process | `[grounded]` posting | Who would I interview with, and what should the first 90 days look like? | unresolved |
| RR5 | BigQuery named in the role description but not in requirements | risk_signal | low | "a dbt-modelled warehouse in BigQuery" | BigQuery fluency may be expected from day one; the posting doesn't say | `[inferred]` from the posting's split between description and requirements; `[generic]` on ramp-up | Is BigQuery expected from day one, or is ramp-up planned? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Pellucid's careers page and that the recruiter's contact matches its domain, before applying | see RR2 | `[grounded]` RR2 | pending your approval |
| A2 | Lead with the Snowflake dbt project (~180 models) and the Great Expectations suite as the direct matches | see R5, R7 | `[grounded]` your background | pending your approval |
| A3 | Describe BigQuery as: "Snowflake-based dbt project; no BigQuery experience yet" | see R8, RR5 | `[grounded]` your sentences | pending your approval |
| A4 | Ask RR4 and RR5 in the first conversation | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report until you confirm specifics.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches were sent for Pellucid's existence, its funding, and the live posting. Web search permission was not granted, so all three were refused. Unchecked: the Series C, headcount and state facts, and whether the posting is live (RR2) |
| 2. Role-family sweep | skipped | The pasted Datawright report already gives the band and scope norm, so no search was sent |
| 3. Hiring manager's public footprint | n/a | No name was given |

User links read: 0. The URLs you cited were the source of your pasted text, so they were not read as links.

I have not recorded the standing failed-attribution entry, because no search returned a result. The employer is unverified, not shown to be absent.

If you want the employer and posting checked, grant web search permission and I'll run target 1 in the next turn.

The dossier offer: I can save this assessment as `tuesday-dossier.md` if you want it on file.

## Upgrade menu

- Web search permission → verifies RR2 and the Series C, headcount and state claims
- Your location and pay floor → R1 and R2 move off `unclear`
- Any BigQuery or GCP work, even a sandbox → R8 gets an artifact to stand on
- An example of consumer contracts or app/CRM ingestion → R9 and R10 resolve
- The hiring manager's name → the scope read and which story to lead with

## Questions

G3 — Are you based in the US, and would remote-US or the Denver office work for you?

G3 — Does a base of $148,000 clear your floor?

G2 — Have you owned data contracts with analyst consumers, or built ingestion from an app database or a CRM? If so, what did you build and who used it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.