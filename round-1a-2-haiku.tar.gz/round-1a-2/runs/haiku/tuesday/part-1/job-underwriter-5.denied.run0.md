**Yes, it's worth applying, once the posting checks out. Status: `conditional_go`.** Your Snowflake dbt, Airflow and data-quality work matches the required stack, and the pay range sits inside the market band. The one thing I couldn't check is whether Pellucid is real, because outside searches were refused in this session.

**Fit ledger.**

- `hard_gate` — unclear: R1, R2
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 · unclear: R9, R10

R1, R2 — the gate terms can't be settled until you say where you're based and what your floor is; R8 — a credible bridge from Snowflake, its limit named; R9, R10 — discovery, one question each.

**Opportunity ledger.** The posting is transparent on pay and sets a clear scope with no red flags. Three items stay open: the employer's facts come only from its own page (RR1), the role may bundle several domains (RR2), and BigQuery is named in the responsibilities though the requirements only say "a cloud warehouse" (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (remote-US or Denver location), R2 (the $148,000–$166,000 range against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** for `conditional_go`, the conditions are (1) the posting is live on Pellucid's own careers page (RR1); (2) R1 and R2 hold against your constraints; (3) you present BigQuery as a bridge from Snowflake, never as experience you have.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 states, founded 2016, Denver, 264 staff, Series C $52M (Feb 2026) | `[grounded]` company page, self-reported and unverified |
| Mandate | Ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Pay | $148,000–$166,000 plus equity (unquantified) | `[grounded]` JD |
| Market calibration | Senior band: median $151,000, IQR $139,000–$163,500; the posting's midpoint ($157,000) sits inside it. This is a pattern, not this employer's offer. Basis: the Datawright 2026 report you shared (US, n=2,310, Series B–D). Not checked against any other source. | `[generic]` band; `[grounded]` posting figure |
| Scope read | Senior, 5–8 years, typically one domain. The JD lists several sources and a warehouse. | `[inferred]` from the JD's responsibility list against `[generic]` typical scope |
| Unknowns | Hiring manager, equity size, current BigQuery footprint, team size | — |
| Contradictions | None between the JD and the company page. Within the JD, BigQuery is a responsibility while the requirement says only "a cloud warehouse." | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location isn't given, so the term is neither met nor failed | `[grounded]` JD | Q1 |
| R2 | Salary $148k–$166k plus equity | hard_gate | unclear | none | hard_gate | Posting figure is grounded; your floor isn't given | `[grounded]` JD; band `[generic]` | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; self-reported, no artifact | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | About 180 dbt models on Snowflake, a cloud warehouse | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite; ongoing ownership not stated | `[grounded]` your background | ask in screen |
| R8 | BigQuery warehouse (responsibility) | important | adjacent | medium | transferability | Snowflake dbt and SQL carry over; BigQuery cost, partitioning and IAM are untested | `[inferred]` bridge from Snowflake work; `[generic]` that BigQuery specifics differ | G1 |
| R9 | Ingestion from app and CRM (responsibility) | important | unclear | low | discovery | Not in your background; sources unknown | `[grounded]` CV silence | G2, Q2 |
| R10 | Data contracts analysts rely on (responsibility) | important | unclear | low | discovery | Not in your background | `[grounded]` CV silence | G3, Q3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | Snowflake dbt project; no BigQuery | The named warehouse is the likeliest objection | Porting dbt models; cost-aware query design; any warehouse migration | A sandbox dbt project on BigQuery, or a migration you led | `[inferred]` bridge; `[generic]` that cost and partitioning are the usual learning curve |
| G2 | App and CRM ingestion (R9) | discovery | Payroll-source ingestion only | Named first in the responsibilities; CRM ingestion would be a direct fit | CRM or event-stream pulls; API loads; incremental loads | A pipeline diagram or README | `[grounded]` JD against CV |
| G3 | Data contracts (R10) | discovery | Not in background | A direct differentiator if you've done it | Schema agreements with consumers; breaking-change rules | A contract doc or schema-change log | `[grounded]` |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified from outside | risk_signal | medium | "runs live online tutoring for K-12 schools in 31 US states" | The company facts are self-reported; the outside check didn't run | `[grounded]` refused searches | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Scope may bundle several domains | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse…, and the data contracts" | One senior role may own ingestion, warehouse and contracts at once | `[inferred]` from the JD; `[generic]` typical senior scope | Which of these pipelines does this role own end to end, and which are shared? | unresolved |
| RR3 | BigQuery ramp | risk_signal | low | "a dbt-modelled warehouse in BigQuery" | Early months may go to BigQuery-specific work | `[inferred]` JD against CV | What BigQuery work is in the first 90 days, and is there a dbt project to inherit? | unresolved |
| RR4 | Pay stated, equity unquantified | positive_signal | — | "$148,000–$166,000 plus equity" | Transparent pay | `[grounded]` JD | What is the equity grant and vesting schedule at this level? | noted |
| RR5 | Hiring manager not named | unknown | — | (posting names none) | Reporting line unknown | — | Who is the hiring manager, and who would I work with day to day? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting on Pellucid's careers page, and the recruiter's email domain, before applying | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Confirm location and pay floor against R1 and R2 | R1, R2 | `[grounded]` JD | pending your approval |
| A3 | Keep Snowflake named in the CV; add no BigQuery line | R5, R8 | `[grounded]` your background | resume_edits_pending_approval |
| A4 | Interview bridge, in your words: "I've run dbt, Airflow and data-quality tests on Snowflake. I haven't used BigQuery in production; its cost and partitioning model is what I'd need to learn." | R8 | `[grounded]` your background; limit stated by you | pending your approval |
| A5 | Ask RR2 and RR3 in the first screen | RR2, RR3 | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet. Your background is self-report, so it stays at `medium` until a probe or an artifact confirms it. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches on Pellucid's existence and Series C funding were refused permission, so the company facts are unchecked. Would have moved RR1 and condition (1). |
| 2. Role-family sweep | skipped | The Datawright report you shared fixes the band; no search sent. Its basis is the report, not checked. |
| 3. Hiring manager's public footprint | n/a | No name given. |

**Upgrade menu**

- The live posting link, or Pellucid's careers page → RR1 clears, and the status can move to `go`.
- Your location and pay floor → R1 and R2 resolve, and the hard-gates line clears.
- Permission for web search → target 1 runs and can confirm the employer and funding.
- A small BigQuery dbt project, even in a sandbox → an inspectable artifact for R8's limit.
- The hiring manager's name → RR5 and which story to lead with.
- A deeper pass on Pellucid (leadership changes, hiring pattern, employee reports; up to 5 more searches and 2 more fetches) → runs once search permission is granted.

I can also save this as `tuesday-dossier.md` so later interview prep can pick it up.

**Questions**

Q1 — R1, R2: Are you based in the US, or within reach of Denver, and is $148,000 at or above the lowest salary you'd accept?

Q2 — G2: Have you built ingestion from a CRM or an app's event data, and which part did you own?

Q3 — G3: Have you defined data contracts with the teams that consume your tables, and who enforces them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.