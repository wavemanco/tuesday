**Status: `conditional_go`.** You're not wasting your time, but you're a stretch on the literal bar. The posting asks for 3+ years of product management (R1b), and you have none in a PM title. Your integration work is a credible bridge (R1a, R2), so apply only with the conditions below.

**Fit ledger**

- `must_have`: direct: R3 · adjacent: R1a (3+ years product management), R2 (shipped API or platform products) · absent: R1b (3+ years product management)
- `important`: direct: R4a (stakeholder management across engineering and customers) · adjacent: R5 (discovery with integration partners), R8 (coordinating launches) · unclear: R4b (stakeholder management across sales), R6 (defining and tracking adoption metrics), R7 (agile delivery experience)

R1b — no titled product years, the literal bar; R2 — integrations shipped as implementation, not as the product; R6 and R7 — silent on your CV, one question each.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Opportunity ledger:** RR1 and RR5 are open questions about decision rights and level; RR2 is open because web search was refused, so the employer is unverified; RR4 is a risk that a screen reads the 3+ years bar literally. RR3 runs the other way: the posting names concrete scope and two squads to lead.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your answer to G1 shows you owned product or tool decisions, probed in interview (R2, R1a); (2) Quartzline is verified on its own careers page (RR2); (3) the recruiter confirms whether the 3+ years bar counts product-adjacent delivery and what decision rights the role has (RR1, RR4).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` posting as pasted |
| Mandate | Own the roadmap for a partner-facing API platform | `[grounded]` posting |
| Team | Two engineering squads, partner discovery, launches with sales and support | `[grounded]` posting |
| First-year outcomes | None stated | `[grounded]` absence |
| Scope read | One PM carrying roadmap, discovery, delivery and launch across two squads is broad for the title | `[inferred]` from the scope list against the single title |
| Market calibration | Not run; web search refused | — |
| Compensation | Not stated | `[grounded]` absence |
| Unknowns | Decision rights, level, pay, sales and support scope, who owns adoption metrics | — |
| Contradictions | None within what was provided; careers page not checked | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management (adjacent part) | must_have | adjacent | medium | transferability | Seven years of client-facing integration delivery and quarterly roadmap-input sessions. Limit: input is not ownership, and no PM title | `[grounded]` CV; `[inferred]` adjacency | Bridge case, G1 |
| R1b | 3+ years product management (titled part) | must_have | absent | none | capability | No PM title on your CV, and you have said so | `[grounded]` your statement | Closure path, gap queue |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Led 30+ REST integrations end to end, so you shipped the client's integration, not the platform. No platform change you drove is on the CV | `[grounded]` CV | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI, integration architecture on CV. Medium because self-reported, with no inspectable artifact | `[grounded]` CV | Probe in loop; no question asked |
| R4a | Stakeholder management: engineering and customers | important | direct | medium | none | Coordinated your engineers, client engineers and PMs; UAT and go-live | `[grounded]` CV | none |
| R4b | Stakeholder management: sales | important | unclear | low | discovery | CV silent on sales | `[grounded]` CV silence | Carried as minor risk |
| R5 | Discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and client roadmap input are per-client discovery, not a discovery program | `[grounded]` CV; `[inferred]` adjacency | Name the limit in loop |
| R6 | Define and track adoption metrics | important | unclear | low | discovery | CV silent. An unconfirmed earlier-context lead exists but is not evidence | `[grounded]` CV silence | G2 |
| R7 | Agile delivery | important | unclear | low | discovery | CV silent on sprints or agile practice | `[grounded]` CV silence | G3 |
| R8 | Coordinating launches with sales and support | important | adjacent | medium | transferability | Go-live coordination for 30+ clients. Sales and support work not on CV | `[grounded]` CV; `[inferred]` adjacency | Limit named; no question |

**Gap recovery queue** (no questions here; they sit in the closing block)

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owned product decisions (R1a, R2) | transferability | Integration delivery and input sessions; no decision you owned about what got built | This is the objection a screen raises first, so a concrete owned decision narrows it | An internal tool you chose the scope of; a client-requested field that became a shipped feature; a launch plan you wrote | A spec, roadmap, launch plan, or usage numbers | `[inferred]` bridge from your integration work |
| G2 | Adoption metrics (R6) | discovery | Nothing on CV about measuring usage after go-live | Adoption tracking is a named responsibility | Go-live checklists, call volume or error reviews you ran | A dashboard, metric definition, or go-live report | `[grounded]` CV silence |
| G3 | Agile delivery (R7) | discovery | Nothing on CV about sprints or backlog ownership | Named in the posting; a delivery gap | Sprint work with an engineering squad; acceptance decisions | A sprint board, backlog or release note | `[grounded]` CV silence |
| G4 | Titled PM years (R1b) | capability | No PM title and no PM-titled work | No credible direct evidence after looking | Product-owner roles on an integrations team; an internal PM rotation | An offer or role description | `[grounded]` your statement; closure path `[generic]` |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Decision rights over roadmap unstated | unknown | — | "Own the roadmap for our partner-facing API platform" | Ownership may be in name while squads or leadership set priorities | `[inferred]` from scope against silence on decision rights | Which roadmap decisions does this role make alone, and which go to the squads or leadership? | unresolved |
| RR2 | Employer unverified | unknown | — | The posting as pasted; no link | Web search was refused, so no check ran. The posting may be stale, or the employer may be too new to show a footprint | `[generic]` pattern for employers of this kind; no claim about Quartzline | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Concrete scope | positive_signal | — | "two engineering squads" | Scope is defined and checkable | `[grounded]` posting | Which two squads, and what does success look like in year one? | noted |
| RR4 | Literal 3+ year bar | risk_signal | medium | "3+ years product management experience (must-have)" | A screen may reject without titled PM time, whatever the adjacent work | `[generic]` pattern for must-have experience bars in PM postings | Is the 3+ years requirement product-management time specifically, or can product-adjacent delivery count? | unresolved |
| RR5 | Level and pay withheld | unknown | — | No level or salary stated | The level could be senior, which would widen the bar | `[grounded]` absence | What level and salary band is budgeted for this role? | unresolved |

**Application plan** (every row is proposed, pending your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line, under the integrations bullet: "Ran quarterly roadmap-input sessions collecting client feedback for product." | R1a, R5 | `[grounded]` your CV sentence, unchanged | resume_edits_pending_approval |
| E2 | Summary line: "Led 30+ client integrations of our REST APIs end to end: scoping, requirements, architecture, UAT, go-live." | R2 | `[grounded]` your CV sentence, unchanged | resume_edits_pending_approval |
| A1 | Verify the posting on Quartzline's careers site before any application effort | RR2 | `[generic]` pattern | pending your approval |
| A2 | Ask the recruiter RR1 and RR4 verbatim before investing | RR1, RR4 | `[grounded]` register | pending your approval |
| A3 | Ask whether your current employer has an internal product-facing integrations role | R1b | `[generic]` pattern that internal moves are often faster than external ones | pending your approval |

**Evidence status**

Verified: none yet. Unverified lead: an internal request-triage tool that support agents adopted, from earlier context. It is not used as evidence; G1 asks about it. Rejected inferences: none.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | My one search for Quartzline was refused by permission, so the posting and employer were not checked. Would have moved RR2 and the contradictions row |
| 2. Role-family sweep | unavailable | Not sent after the refusal. Would have calibrated the bar in RR4 and the level in RR5 |
| 3. Hiring manager's public footprint | n/a | No name given |

I'm not retrying the search without your go-ahead.

I can save this assessment as `tuesday-dossier.md`, a reusable record that a later prep run can read.

**Upgrade menu**

- Allow web search, and I'll run targets 1 and 2 → RR2 verified or not; RR4 and RR5 set against role-family norms.
- A careers-page link for the role, if one exists → RR2 and the contradictions check.
- Product artifacts: a roadmap, PRD, launch plan, or the triage tool's spec or usage figures → R2 and R1a to `high`.
- Your constraints (location, contract type, start date, pay floor) → hard-gate checks, currently unknown.
- The hiring manager's name → positioning for that reader.

**Questions**

G1 — Tell me about the one thing you've shipped where you chose what got built and tracked whether anyone used it. Did you build an internal request-triage tool that support agents adopted? If so, what did you decide, and how did you know it was adopted?

G2 — For any integration or API you delivered, what did you measure after go-live to know it was working: adoption, call volume, errors, time to first live call?

G3 — Have you worked in sprints or an agile loop with an engineering squad? Whose backlog was it, and who accepted the work?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.