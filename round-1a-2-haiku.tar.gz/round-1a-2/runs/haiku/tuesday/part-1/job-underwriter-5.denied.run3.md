**Yes, it's worth applying, once three checks clear.** Your must-haves are in your history. Two gates (location and pay) are unconfirmed because I don't have your constraints, and the employer is unverified because web search was refused in this session. Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver location), R2 (base salary $148,000–$166,000 against your floor)
- `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (Airflow or similar), R7 (data quality testing)
- `important`: adjacent: R8 (BigQuery warehouse); unclear: R9 (data contracts for analysts), R10 (ingestion from app and CRM)

R8 — Snowflake carries over, BigQuery is unused, limit named; R9 and R10 — no evidence either way yet.

**Opportunity ledger.** The posted pay sits inside the market band (RR3), and the posting is unusually explicit about outcomes (RR5 is a funding signal, not verified). Against that, the scope spans four pipeline areas (RR2), the employer is unverified (RR1), and the hiring manager and equity value are unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver location), R2 (base salary against your floor); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) R1 and R2 confirmed by you; (2) RR1 verified on Pellucid's own careers site; (3) R9 and R10 answered, see the closing questions.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C $52M, Feb 2026 | `[grounded]` your pasted about page, not verified (RR1) |
| Mandate | Build and run the pipelines behind tutoring reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Scope read | Spans ingestion, modelling, contracts and orchestration, broader than one domain | `[inferred]` from the JD's four-area scope against the market norm below |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, IQR $139,000–$163,500; "senior" typically 5–8 years; one domain's pipelines, no direct reports. The posted $148,000–$166,000 sits around the median to upper quartile; the top end is above the IQR | `[generic]` Datawright 2026 report, US, n=2,310, as your recruiter sent it; `[grounded]` posted figure |
| Unknowns | Equity value; hiring manager; team structure; contract type; whether ingestion and contracts are one owner's job | — |
| Contradictions | None between the JD and your pasted about page | `[grounded]` as pasted; the live careers page was not checked |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver location | hard_gate | unclear | none | hard_gate | Your location and work authorization weren't given, so nothing settles it | `[grounded]` JD; constraint not stated | Q1 |
| R2 | Base $148,000–$166,000 against your floor | hard_gate | unclear | none | hard_gate | Your floor wasn't given | `[grounded]` JD | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years, stated in your background; not yet probed or inspected | `[grounded]` your intake, self-report | share a CV for inspection |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no inspectable artifact yet | `[grounded]` your intake | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | ~180-model dbt project on Snowflake (a cloud warehouse) | `[grounded]` your intake | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow orchestration stated | `[grounded]` your intake | none |
| R7 | Data quality testing | must_have | direct | medium | none | Great Expectations suite stated as set up by you | `[grounded]` your intake | none |
| R8 | BigQuery warehouse (in the role description) | important | adjacent | medium | transferability | Snowflake and dbt work carries over; no BigQuery use stated. Limit: the platform itself is unexercised | `[inferred]` from your Snowflake work; the BigQuery limit is `[generic]` | G1 |
| R9 | Data contracts for analysts | important | unclear | none | discovery | Not mentioned in your background | `[grounded]` JD; silence in your intake | Q3, tagged G2 |
| R10 | Ingestion from app and CRM | important | unclear | none | discovery | Not mentioned in your background | `[grounded]` JD; silence in your intake | Q3, tagged G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake dbt project and daily SQL; no BigQuery stated | The role is described as BigQuery-based; the limit is the platform's own features | Porting or testing models in a different warehouse; tuning cost and performance on Snowflake | A small BigQuery dbt project or a note on how you'd port the project | `[inferred]` bridge from your Snowflake work; `[generic]` that platform differences (partitioning, cost model, dialect) are the usual limit |
| G2 | Data contracts (R9, important) | discovery | Nothing stated | The JD names contracts as a deliverable | Schema agreements with downstream users; breaking-change processes; contract-style tests | A contract doc or schema-change process | `[grounded]` JD; `[generic]` that contracts are usually an analyst-facing deliverable |
| G3 | Ingestion from app and CRM (R10, important) | discovery | Nothing stated | Named as the first stage of the pipeline | Source connectors, CDC or batch loads, source-schema drift handling | A pipeline diagram or ingestion job from your payroll work | `[grounded]` JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning" | Research didn't run: both web searches were refused, so nothing attributed the employer. That is a gap in verification, not evidence the employer is fake | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Scope bundles four pipeline areas | risk_signal | low | "Build and run the pipelines behind our tutoring platform's reporting: ingestion…, a dbt-modelled warehouse…, and the data contracts…" | Could be one senior owner across the stack, or several roles under one title | `[inferred]` from the JD's breadth against the one-domain norm | Which of these pieces does this role own alone, and is there a separate platform or analytics-engineering team? | unresolved |
| RR3 | Posted pay sits in the market band | positive_signal | — | "$148,000–$166,000 plus equity" | Not a seniority-pay mismatch | `[grounded]` posted figure against `[generic]` band | Is the base the full cash pay, and what does the equity cover? | noted |
| RR4 | Hiring manager and equity value unstated | unknown | — | "no hiring manager named"; "plus equity" | Could be a recruiter-led posting; equity value is unknown | `[inferred]` from silence in the posting | Who is the hiring manager for this role, and what is the equity package? | unresolved |
| RR5 | Recent funding round | positive_signal | — | "Series C ($52M, February 2026)" | A recent raise may mean funded hiring, not verified | `[grounded]` your pasted about page; runway is `[generic]` | What does the Series C fund, and is this role part of that plan? | noted |

Severe red flags: none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Answer Q1 on location and authorization | R1 is a hard gate | `[grounded]` JD | your answer |
| A2 | Answer Q2 on your pay floor | R2 is a hard gate | `[grounded]` JD | your answer |
| A3 | Confirm the posting is live on Pellucid's careers site, then ask the recruiter RR2 and RR4 verbatim | RR1, RR2, RR4 | `[grounded]` the register's questions | pending your approval |
| A4 | Frame BigQuery as the adjacent bridge with its limit named, not as experience | R8 | `[inferred]` from G1 | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report at the medium ceiling until probed or inspected. Unverified leads: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused permission ("Pellucid Learning live online tutoring K-12 Denver"; "Pellucid Learning senior data engineer careers"). Would have moved RR1 and the contradictions row |
| 2. Role-family sweep | skipped | The Datawright report figures are in hand from your recruiter, so the band and scope norm are already fixed by the inputs |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

## Upgrade menu

- Web search permission granted → verifies RR1 and the posting's liveness (up to 5 searches and 2 fetches).
- A deeper pass on Pellucid Learning: funding, leadership changes, public employee reports (up to 5 more searches and 2 more fetches). Offered once; it needs the search permission first.
- Your location and pay floor → R1 and R2 close, and the decision can move to `go` or `no_go`.
- A CV or repository with dbt or Airflow work → R3–R7 can rise from `medium` to `high`.
- A BigQuery project, even small → R8 rises from `adjacent` toward `direct`.
- The hiring manager's name → RR4 closes, and positioning can be tailored to that reader.

If you want, I can write this up as a `tuesday-dossier.md` you can keep and append to.

Questions (three, one per open gate or gap):
- **Q1 (R1):** Can you work remotely from the US, or from Denver, without sponsorship?
- **Q2 (R2):** Is a base of $148,000–$166,000 above your floor?
- **Q3 (G2, G3):** In your payroll work, have you owned data contracts or ingestion from an app and CRM? If so, describe what you owned, who depended on it, and what broke.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.