**Yes, apply, but check three things first. Status: `conditional_go`.** Your must-haves match the JD line for line, and you can back each one with what you've done. The open items are one hard gate you haven't confirmed, the role's decision rights and pay, which the posting doesn't show, and the pet-insurance gap.

**Fit ledger.**

- `hard_gate`: unclear: R1 (fully remote UK)
- `must_have`: direct: R2 (4+ years pricing or actuarial analytics), R3 (strong SQL and Python), R4 (GLM experience), R5 (presenting to underwriting or actuarial leads)
- `important`: direct: R6 (design and read price tests) · adjacent: R7 (recommendations for underwriting and product)
- `preferred`: direct: R8 (insurance experience) · adjacent: R9 (pet-insurance product)

R1 — the gate is not established, and it is the one item that could stop this. R7 — underwriting recommendations are evidenced, product ones are not. R9 — motor pricing carries over, and the pet-specific limit is named.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Opportunity ledger:** sound on the JD's own terms. Scope is concrete, with rating models and price tests named (RR3). Unknowns remain on decision rights and team (RR1), pay (RR2), and whether the employer is as described (RR4).
- **Conditions for go:** (1) R1 confirmed: you are UK-based with the right to work; (2) RR1 answered concretely: which price changes this role decides itself, and whether it has reports; (3) R9 framed as adjacent, never as pet expertise.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech, pet-insurance product | `[grounded]` JD |
| Mandate | Own pricing analytics: rating models, price tests, recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message |
| Scope read | Senior analyst-level scope; the JD names no team or reports | `[inferred]` from the JD's silence on both |
| Market calibration | Not run (search refused) | — |
| Unknowns | Decision rights, team, pay, employer verification | — |
| Contradictions | None visible in what you gave me | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote UK: location and right to work | hard_gate | unclear | none | hard_gate | Your location and right to work aren't in what you've given me. A UK motor role suggests it but doesn't settle it | `[inferred]` from your UK employer history | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two senior. Stated, not yet inspectable | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use. "Strong" is your word; no artifact yet | `[grounded]` your message | offer: a query or script sample |
| R4 | GLM experience; build and monitor rating models | must_have | direct | medium | none | Built and maintained the young-driver GLM. Monitoring is not stated, only maintenance | `[grounded]` your message | E1 |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your message | E1 |
| R6 | Design and read price tests | important | direct | medium | none | Ran 14 price tests last year with underwriting | `[grounded]` your message | E1 |
| R7 | Recommendations for underwriting and product | important | adjacent | medium | transferability | Underwriting recommendations are stated; product-side work is not. The limit is named | `[inferred]` from the split of your stated work | G2 |
| R8 | Insurance experience | preferred | direct | medium | none | UK motor insurer | `[grounded]` your message | none |
| R9 | Pet-insurance product (implied by "our pet-insurance product") | preferred | adjacent | medium | transferability | Motor pricing carries over: GLM, testing, presenting. The limit is no pet claims, pet risk drivers or cover terms | `[inferred]` adjacency; `[generic]` that pet risk drivers differ from motor | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product (R9, preferred) | transferability | Motor pricing only | The JD names the pet product, so the first interview probe is likely to be about it | Any non-motor pricing, or any work on a product with a different claims pattern | A model summary or test write-up from a non-motor book, or a benchmark you built | `[inferred]` from the JD; `[generic]` on how pet risk differs |
| G2 | Recommendations to product (R7, important) | transferability | Underwriting recommendations documented | "Underwriting and product" is in the JD's own sentence | A recommendation that changed cover terms or a product feature, or a pricing committee paper | A paper or deck sent to a product lead | `[grounded]` JD; `[inferred]` that product is the gap |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Decision rights and reports unstated | unknown | — | "Own pricing analytics … turn the results into recommendations" | The role may recommend price changes while others decide, and may carry no reports | `[inferred]` from "recommendations" against silence on decision rights | Which price changes does this role decide itself, and does it have direct reports? | unresolved |
| RR2 | Pay not in the posting | unknown | — | (no pay stated in the JD) | Pay may be withheld until interview | `[grounded]` the JD gives no pay | What is the base salary range for this role? | unresolved |
| RR3 | Concrete scope | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope is defined, and the outputs are measurable | `[inferred]` from the listed deliverables | What would success look like for the rating models in year one? | noted |
| RR4 | Employer not verified | unknown | — | "Brindlemoor (insurtech)" | Employer and role unconfirmed; the web check did not run | `[grounded]` search refused | How large is the pricing team this role sits in, and who is on the interview loop? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV lead: "Built and maintained the GLM rating model for our young-driver book"; "Ran 14 price tests with the underwriting team"; "Presents the quarterly pricing review to the head of underwriting" | R4, R5, R6 | `[grounded]` your words | pending your approval |
| E2 | Pet framing as a stated limit: "Motor pricing; applying the same GLM and testing methods to a pet book would be new work" | R9 | `[inferred]` adjacency | pending your approval |
| Q1 | Ask RR1, RR2 and RR4 on the first call, verbatim | The register doubles as interview prep | `[grounded]` register | your call |
| A1 | Confirm your UK base and right to work before you apply | R1 | `[grounded]` gate row | your call |

## Evidence status

Verified: none yet. Your statements here are prose background: leads for verification, not proof.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search refused. Would have checked the posting is live and that Brindlemoor exists as described (RR4) |
| 2. Role-family sweep | unavailable | Search refused. Would have set the market calibration and pay band for RR2 |
| 3. Hiring manager's public footprint | unavailable | Search refused on Odile Varga's name, which you gave. Would have shaped positioning |

Your web search permission was denied, so the four calls were refused and count against the budget. Everything about Brindlemoor here comes from the JD alone.

I can also write this up as a `tuesday-dossier.md` you can keep and append to after interviews.

## Upgrade menu

- A CV, or a sanitized note on the GLM and price tests → R2–R6 move from `medium` toward `high`
- Any non-motor pricing example, however small → R9 moves from adjacent toward direct
- The recruiter's pay range and team shape → RR1 and RR2 close
- Web search permission → the three checks in the tier table (up to 5 searches and 2 fetches), which would also settle RR4

1. **R1** — Is a fully remote UK role workable for you? Are you based in the UK with the right to work?
2. Setting search aside, what are your non-negotiables on pay, contract type and start date? None are on file, so those checks are unknown.
3. **R7** — Have you ever put a recommendation to product, such as a change to cover terms or a pricing committee paper, rather than only to underwriting?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.