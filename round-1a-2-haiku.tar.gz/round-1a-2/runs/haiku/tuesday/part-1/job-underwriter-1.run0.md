**Yes, apply, conditionally: `conditional_go`.** On your own account, the six must-haves (R1 through R6) read `direct`. The open items are healthcare scope (R9), clinician partnership (R7b) and mentoring (R8), and I could not verify that the employer exists as described.

**Fit ledger.**

- `hard_gate`: none stated
- `must_have`: direct: R1, R2, R3, R4, R5, R6
- `important`: direct: R7a · adjacent: R7b (clinician partnership) · unclear: R8 (mentoring two junior analysts)
- `preferred`: adjacent: R9 (healthcare data, HIPAA)

R3 (`medium`): the pricing test is confirmed, pending its design readout. R7b: an adjacent bridge through exec-facing work, with the clinical limit named. R8: mentoring is not established either way. R9: consumer privacy work is a transferable bridge, not healthcare experience.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Opportunity ledger:** The pasted posting is silent on location, pay and contract type (RR2), and the employer is unverified from here (RR3, a standing entry). Its scope is concrete, with named responsibilities (RR4). The HIPAA data scope is unknown (RR1).
- **Conditions for go:** (1) RR3 clears: the posting is live on Harborlight's own careers site; (2) R8 is answered with your actual mentoring record; (3) RR1 clears in interview: what data the role touches, and how much of it is PHI.

**Research tier: L1 — searches 2 of 5, fetches 0 of 2**

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` pasted posting; not verified |
| Mandate | Own product analytics for the care-navigation app | `[grounded]` posting |
| Market calibration | Not run. Both searches were refused, so there is no band | — |
| Unknowns | Location, pay, contract type, PHI access, who the clinicians are | — |
| Contradictions | None visible; the pasted posting is the only source | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years, consumer-subscription, specific; self-report and unprobed, so medium with the caveat: expect a probe | `[grounded]` intake | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" is a level claim the intake does not show | `[grounded]` intake; `[inferred]` that daily use supports the level | A sanitized query or model as artifact raises to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, program owned by you. The 11% lift's basis (relative or points, design, significance) is unstated, so the figure goes out only with its qualifier | `[grounded]` intake | Q2; a sanitized readout raises to high |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | Built the Looker instance; 40+ governed dashboards | `[grounded]` intake | A screenshot of the dashboard index raises to high |
| R5 | Define and maintain the metrics layer | must_have | direct | medium | none | Governed dashboards and a monthly metrics memo imply owned definitions, though not stated in those words | `[grounded]` intake; `[inferred]` from governance | A metric-definitions doc raises to high |
| R6 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly memo read by the exec team; presents monthly to VP Product | `[grounded]` intake | A sanitized memo raises to high |
| R7a | Partner with product managers on roadmap decisions | important | adjacent | medium | transferability | Presenting to VP Product is adjacent evidence. PM partnership itself is not stated | `[grounded]` intake; `[inferred]` adjacency | Describe one PM decision you shaped |
| R7b | Partner with clinicians | important | adjacent | low | transferability | No clinical stakeholder work stated; exec-facing work is the only bridge | `[grounded]` intake; `[inferred]` adjacency | G3 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Intake is silent. Silence is not absence | `[grounded]` intake silence | Q1 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model are credible adjacency. No PHI, no HIPAA safeguards, no clinical data | `[grounded]` intake; `[inferred]` that consent-state work transfers | G2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Mentoring (R8, important) | discovery | Intake silent on managing or mentoring analysts | Named in the posting; it decides whether R8 stays a risk | Onboarding or reviewing a new analyst's SQL; running an analyst's first experiment readout; hiring or interviewing analysts | Team charter, a mentoring plan, or a review you wrote | `[grounded]` silence |
| G2 | Healthcare data (R9, preferred) | transferability | Consumer privacy and consent work, no clinical or PHI data | The posting flags HIPAA; overclaiming it is the main risk | Consent-state logic that gated which data could be used; data-access reviews; GDPR/CCPA deletion workflows | A sanitized description of the consent model | `[grounded]` intake; `[generic]` that health-data roles probe PHI handling |
| G3 | Clinician partnership (R7b, important) | transferability | Exec-facing work only | Clinicians are named stakeholders; this is the likeliest interview probe | Analysis that changed a non-technical executive's decision; work with ops or support leads on user-facing problems | A decision memo that changed a non-technical audience's call | `[inferred]` bridge; `[generic]` that clinician audiences probe clinical context |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Healthcare and PHI scope unknown | unknown | — | "healthcare data experience (HIPAA) a plus" | The role may touch PHI under HIPAA controls you have not worked under | `[inferred]` from the HIPAA line and the care-navigation product | What data does this role query, and how much of it is PHI under HIPAA? | unresolved |
| RR2 | Location, pay and contract type not stated | unknown | — | (silent in the pasted posting) | Terms may be on the employer's full listing, or withheld | `[grounded]` pasted posting | What are the salary band, location and contract type for this role? | unresolved |
| RR3 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health" | The employer may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Here verification was refused, so there is no result either way | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR4 | Concrete mandate with named responsibilities | positive_signal | — | "own product analytics for our care-navigation app" | Scope is specific enough to test against | `[inferred]` from the listed responsibilities | Who owns the metrics layer today, and what would this role change? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Find the live posting on Harborlight's careers site before investing in an application | see RR3 | `[grounded]` RR3 | pending your approval |
| P2 | Lead with the experiment program and the pricing test, once you can state the 11% lift with its basis | see R3 | `[grounded]` R3 | pending your approval |
| P3 | Describe the consent and privacy work as adjacent to HIPAA, never as healthcare experience | see R9; a clause like "healthcare privacy experience" would be a logical-form and kind drift | `[grounded]` R9 | pending your approval |
| P4 | If you have not partnered with clinicians, say so and name the nearest exec-facing bridge | see R7b | `[inferred]` R7b | pending your approval |

No resume wording is proposed here. Any line drafted later needs your approval.

**Evidence status**

Verified: none yet. Your background is intake self-report, not probed.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health careers Senior Product Analyst care navigation"; the call was refused by the permission gate and returned nothing. Would have moved role reality's organization row and RR3 |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range experimentation Looker"; refused, nothing returned. Would have moved the market calibration line and the pay check against RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

The two searches were refused by the permission gate, not by the host lacking search. I did not retry them. Granting search permission lets me run the L1 targets.

**Upgrade menu**

- The live posting link, or the recruiter's email domain → RR3 clears or stays open, and the employer check runs.
- A sanitized pricing-test readout or design doc → R3 to `high`.
- Any mentoring of analysts, however small → R8 resolves.
- Clinician-facing or health-adjacent work, however small → R7b and R9 move.
- Budget, location and contract type → RR2 closes.
- Granting search permission → the L1 targets run (up to 5 searches and 2 fetches). A deeper pass (up to 5 more searches and 2 more fetches) is available once L1 runs.

Want me to save this as a `tuesday-dossier.md` so a later prep session can start from it?

1. Do you have any mentoring or management of analysts, direct or informal? Who, how many, and what did you own about their work? (R8, G1)
2. For the pricing test: was the 11% a relative or a percentage-point lift, what was the design (sample, duration, primary metric), and can you share a sanitized readout? (R3)
3. Do you have the live posting link, or the recruiter's email domain? That is the one thing that moves the employer check. (RR3)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.