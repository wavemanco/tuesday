**Yes, it's worth applying, with two checks first.** Status: `conditional_go`. Your fit on the must-haves is strong, and the posting checks out as a live role at a real employer. Before you apply, confirm your location and whether $148,000 base clears your floor, because I have no information on either.

**Decision snapshot**

- **Fit ledger.**
  - `hard_gate`: unclear: R1 (remote US or Denver), R2 (base pay $148,000 floor)
  - `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (orchestration with Airflow), R7 (data quality testing)
  - `important`: adjacent: R8 (BigQuery warehouse); unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)
  - `preferred`: none stated

  R8 — BigQuery is the one new tool, `medium` and transferable from Snowflake; R9, R10 — no evidence in your background yet; R1, R2 — checks against your constraints, not yet run.

- **Opportunity ledger.** The posting and employer are verified and the pay is published. Open items are scope (RR1, RR3) and the stack question (RR2).
- **Hard gates:** none failed (no `direct` gate rows); unconfirmed: R1 (remote US or Denver), R2 (base pay $148,000 floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you are US-based and remote or Denver works; (2) $148,000 base clears your floor; (3) BigQuery is presented as adjacent experience, not claimed.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 in 31 states, Series C | `[grounded]` about page (search snippet) |
| Posting | Live on the employer's careers page, matching your JD text | `[grounded]` careers page fetched |
| Pay | $148,000–$166,000 midpoint $157,000 sits above the $151,000 median and near the top of the $139,000–$163,500 IQR; top end is above the IQR | `[grounded]` posting; `[generic]` Datawright 2026 band |
| Scope | "Build and run" pipelines for one reporting domain, consistent with typical Senior scope | `[inferred]` from JD wording |
| Unknowns | Stack (BigQuery live or migrating), data contracts ownership, team size, on-call, hiring manager | — |
| Contradictions | None between the JD and the careers page | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver office | hard_gate | unclear | none | hard_gate | No candidate statement of location | `[grounded]` JD | Confirm |
| R2 | Base pay at or above your floor | hard_gate | unclear | none | hard_gate | No floor stated | `[grounded]` JD | Confirm |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; prose background, not yet probed | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, both | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow set up and run | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite | `[grounded]` your background | none |
| R8 | Warehouse in BigQuery | important | adjacent | medium | transferability | Cloud warehouse and dbt carry over; no BigQuery work | `[inferred]` from R5 | See G1 |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Background silent on ingestion sources | `[grounded]` silence | See G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Background silent on contracts | `[grounded]` silence | See G2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | dbt on Snowflake; no BigQuery | Named in the JD; the limit is BigQuery's own specifics (partitioning, cost model, SQL dialect) | dbt modelling, warehouse performance tuning, cost work on Snowflake | A short BigQuery project or course, or a sanitized dbt note | `[inferred]` bridge; `[generic]` that BigQuery's cost model and partitioning differ |
| G2 | Ingestion and contracts (R9, R10) | discovery | Background silent on both | Two `important` responsibilities the posting names | Pipelines from a production database or SaaS API; schema change handling; versioned schemas or dbt contracts | A pipeline diagram or a contract doc | `[grounded]` silence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Data contracts ownership unclear | unknown | — | "the data contracts our analysts depend on" | You may own contracts end to end, or only the pipelines behind them | `[inferred]` from JD scope | Which data contracts would this role own end to end, and which stay with analysts? | unresolved |
| RR2 | Warehouse stack unclear | unknown | — | "a dbt-modelled warehouse in BigQuery" | BigQuery may be live, or a migration may be in scope | `[inferred]` from JD wording | Is the warehouse on BigQuery today, or is a migration part of this role? | unresolved |
| RR3 | Team and on-call unstated | unknown | — | "Build and run the pipelines" | "Run" may mean on-call | `[inferred]` from JD wording | Who is on the data team, and what does on-call look like for these pipelines? | unresolved |
| RR4 | Pay inside the market band | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is published and sits in the upper part of the band | `[generic]` band; `[grounded]` posting | Is there room within the published range for a senior hire with this stack? | noted |

**Application plan** (all proposed; nothing is sent)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with dbt, Airflow and Great Expectations as one story | Those are your direct must-haves | `[grounded]` R5–R7 | pending your approval |
| P2 | Present BigQuery as adjacent, with the Snowflake basis named | Avoids claiming experience you lack | `[grounded]` R8 | pending your approval |
| P3 | Ask the recruiter RR1–RR3 before the first interview | They decide scope and stack | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet. Your background is self-report, so it stays `medium` until probed.

Research tier: L1 — searches 2 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results) and "senior data engineer salary Series B D company base pay 2026" (returned the about page). Fetched pellucidlearning.com/careers/senior-data-engineer, which is live and matches the JD. Attribution rests on the careers page plus the about page on the same domain. |
| 2. Role-family sweep | yes | The salary search returned the Datawright 2026 Data Engineering Pay Report (datawright.example/2026-data-engineering-pay-report). The snippet matches your recruiter's figures; I did not open the full report. Market calibration `[generic]`. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` if you want to keep it or hand it to mock-interview later.

**Upgrade menu**
- A BigQuery artifact (short project or course) → R8 moves toward `direct`.
- A pipeline diagram or a contract doc → R9 and R10 move off `unclear`.
- The recruiter's answer on stack and contracts → RR1 and RR2 close.
- The hiring manager's name → the scope read in role reality.
- A deeper research pass on Pellucid (funding, leadership, past hiring; up to 5 more searches and 2 more fetches). Say the word and I'll run it.

**Questions**
1. R1, R2 — Are you based in the US, does remote or Denver work for you, and does $148,000 base clear your floor?
2. R9, R10 — Have you built ingestion from a production app database or a CRM, or owned data contracts that analysts depend on?
3. R8 — Have you used BigQuery at all, even in a side project or course?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.