**Worth applying, on conditions. Status: `conditional_go`.** The pay, the title and the core tooling fit. The two things you can't yet show are owning the forecast and working with billing data, and both are must-haves. Apply, and be ready to answer both in the first conversation.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days a week)
- `must_have`: direct: R2a (4+ years in RevOps or sales ops), R3 (Salesforce admin), R4a (strong SQL) · adjacent: R2b (B2B software), R5 (owning a forecast) · unclear: R4b (spreadsheet modelling), R6 (finance work on billing or revenue data)
- `important`: direct: R7 (pipeline and renewal reporting)

R2b — payments, not software, a limit to name; R5 — you feed the pipeline review, but finance owned the forecast; R6 — no billing data yet, the gap most likely to move the decision.

**Opportunity ledger.** The posting is specific and pays near the middle of the market: RR4 is a positive, and RR1 and RR2 are the unknowns that decide whether the scope is what it claims.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the forecast role is confirmed as yours to build and present, and you can describe how you took pipeline into a forecast number; (2) you have, or will get, access to billing data or a clear working route with finance; (3) Bristol two days a week works for you.

## Research tier

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol", which returned quillfield.co.uk/about: founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025, invoicing and payments for UK builders' merchants. The entity is established. The search did not return the role on their careers page, so the posting's live status is still unchecked (RR4). |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B software £61,500", which returned Ledgerline 2026 UK Revenue Operations Pay Guide (ledgerline.example/2026-uk-revenue-operations-pay-guide): median £64,200, interquartile range £57,800–£70,400, n=438. This moved the market calibration. |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned linkedin.example/in/tamsin-achebe: Head of Revenue Operations at Quillfield; previously four years as sales operations manager at Corvane Payments. This moved the positioning read. |

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield, invoicing and payments software for UK builders' merchants, Bristol, 96 staff | `[grounded]` quillfield.co.uk/about, via search |
| Mandate | Own the CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options, stated | `[grounded]` posting |
| Market calibration | The stated range sits around the median and inside the middle half of the sample | `[generic]` Ledgerline 2026 guide, n=438 |
| Scope read | Four functions on one role: CRM, billing data, reporting and the forecast. Ordinary for a Head-led team at this size, but heavy for one lead | `[inferred]` from the posting's responsibility list |
| Reporting line | Probably under Tamsin, Head of Revenue Operations; the posting does not say | `[inferred]` from the title and the recruiter's hiring-manager statement |
| Unknowns | Who signs off the forecast; who owns the billing system; team size; location fit | — |
| Contradictions | None found between the posting and the company's own page | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two office days a week | hard_gate | unclear | none | hard_gate | Your location and constraints were not given | `[grounded]` posting; constraint not given | Ask where you are based |
| R2a | 4+ years in RevOps, sales ops or similar analytics | must_have | direct | medium | none | Five years in sales ops, the last two in RevOps for the UK team; self-reported | `[grounded]` your intake | none |
| R2b | At a B2B software company | must_have | adjacent | medium | transferability | A B2B payments company, not software. The years and the role carry over; the sector is the limit | `[inferred]` from your employer's description | Name the limit in the cover letter |
| R3 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; rebuilt the pipeline and renewal dashboards | `[grounded]` your intake | Attach the certificate to raise to high |
| R4a | Strong SQL | must_have | direct | medium | none | SQL weekly | `[grounded]` your intake | none |
| R4b | Spreadsheet modelling | must_have | unclear | low | discovery | Excel daily is established, but modelling is not | `[grounded]` your intake | Ask: what did you build in Excel that others relied on? |
| R5 | Owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with the sales director but never owned the company forecast; finance did | `[grounded]` your intake; `[inferred]` that pipeline review is an input to forecast | Make the bridge with its limit stated |
| R6 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | No billing data. Renewal data is revenue-adjacent, but the finance link is not established | `[grounded]` your intake | Ask: have you touched invoices, renewals against billing, or revenue questions with finance? |
| R7 | Pipeline and renewal reporting | important | direct | medium | presentation | Rebuilt the dashboards; the evidence is strong but needs a bullet | `[grounded]` your intake | Lead the CV with it |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R5) | transferability | Pipeline review, not forecast ownership | A must-have that the posting describes as a core duty | Any time you took pipeline data into a number someone committed to; a rolling forecast you built for the sales director; a variance review you ran | A pipeline-to-forecast sheet (anonymised), a review deck | `[inferred]` the bridge; `[generic]` that this is the likeliest objection |
| G2 | Billing data (R6) | discovery | No billing data in your intake | The posting names billing data as part of the job | Renewal reconciliation; invoice-to-contract checks; revenue questions answered for finance | A reconciliation example, a finance request | `[grounded]` your intake |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The lead may build the model while finance owns the number, or the reverse | `[inferred]` from "owning a forecast" against "with the CFO" | Who signs off the forecast number, and does this role own the model, the submission, or both? | unresolved |
| RR2 | Billing data ownership unclear | unknown | — | "own our CRM and billing data" | Billing may sit with finance; the lead may get read access only | `[inferred]` from the posting's silence on the billing system's owner | Which system holds billing, who administers it, and what access does this role have? | unresolved |
| RR3 | Breadth of one role | risk_signal | medium | "own our CRM and billing data … build the pipeline and renewal reporting … run the quarterly revenue forecast" | Four functions on one lead may mean a thin team, or a role that has been scoped too wide | `[inferred]` from the responsibility list; team size unknown | How many people are in RevOps, and what does finance own that this role does not? | unresolved |
| RR4 | Posting not seen on the company's careers page | unknown | — | Aggregator listing only | The posting may be stale, or may sit under a different URL | `[inferred]` from the search, which did not return the role | Can you point me at the role on your careers site, and who would I interview with? | unresolved |
| RR5 | Salary stated and near median | positive_signal | — | "£61,500–£67,000 plus share options" | The offer is at a market level and is transparent | `[grounded]` posting; `[generic]` band | What is the bonus and share-option structure? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the pipeline and renewal dashboards, under revenue operations | See R7 | `[grounded]` your intake | pending your approval |
| E2 | Prepare a plain account of what you fed into forecasting and what you did not own | See R5, G1 | `[grounded]` R5 row | pending your approval |
| A1 | Ask the recruiter RR1 and RR2 before investing in the loop | The two must-haves turn on the answers | `[grounded]` register | pending your approval |

Verified: none yet.

Research tier line is above; no claim is verified, so every row's confidence stays at the intake band.

Upgrade menu:
- A pipeline-to-forecast example, anonymised → R5 moves toward direct, and G1 closes.
- A billing reconciliation example or a note of finance work → R6 moves up from unclear.
- The Salesforce certificate → R3 moves to high.
- Your location and office-day constraints → R1 closes.
- The recruiter's answer on forecast ownership and billing access → RR1 and RR2 close, and the decision likely settles.
- Deeper research on Quillfield (funding, leadership changes, staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can write this into a `tuesday-dossier.md` you can keep and add to as you go.

Questions:
1. R1: Where are you based, and does two office days a week in Bristol work?
2. G1 (R5): Have you ever built a forecast figure, even a partial one, that someone committed to, or fed one that finance then owned?
3. G2 (R6): Have you touched billing or invoice data at all, such as renewals against billing, or revenue questions that went to finance?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.