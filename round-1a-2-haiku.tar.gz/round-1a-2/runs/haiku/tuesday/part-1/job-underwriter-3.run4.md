**No, I wouldn't pursue this one.** Both terms you can't trade fail: the posting is on-site in Austin five days a week (you need remote-only), and the base is $70–85k (you need at least $150k). Status: `no_go`.

## Decision snapshot

- **Status: `no_go`.** R1 and R2, both hard gates, fail. The fit on the must-haves is strong, but a failed gate caps the decision regardless.
- **Fit ledger**
  - `hard_gate`: failed: R1 (on-site in Austin 5 days a week), R2 (base $70–85k)
  - `must_have`: direct: R3 (8+ years growth leadership), R4 (paid acquisition), R5 (lifecycle/CRM)
  - `important`: unclear: R6 (SEO/content), R7 (brand, PR, partnerships, sales ops)

  R3, R4 and R5 are `medium`: self-reported, with no inspectable proof yet. R6 and R7 are `low`: the material doesn't address them either way.
- **Opportunity ledger.** The role has a red-flag pattern: always-on hours (RR1), a seven-function mandate on one person with no budget named (RR3), and no defined success metrics (RR4). The pay (RR2) sits well below what this title usually commands. The employer is unverified (RR5) because web search was refused. RR6 runs the other way: Series A, profitable, a direct CEO line.
- **Hard gates:** failed: R1 (on-site in Austin 5 days a week), R2 (base compensation $70–85k against a $150k floor); met: none.
- **Severe red flags:** none found. No entry is `severity: high`, but RR5 is unchecked.
- **What would change this:** the posting would have to change on both R1 and R2. It says "no exceptions" on Austin, so I wouldn't expect that.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, profitable since day one | `[grounded]` JD |
| Mandate | All revenue growth end to end, team of one to start, reports to CEO with a dotted line to the board | `[grounded]` JD |
| Working pattern | Austin on-site, 5 days; evenings and weekends "when it matters" | `[grounded]` JD |
| Market calibration | Not run; the sweep was refused. A $70–85k base for 8+ years and a seven-function mandate looks low for this title | `[generic]` pattern, unverified |
| Contradictions | None found; no jobs page was checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site Austin, 5 days/week (candidate: remote-only, Portland) | hard_gate | hard_gate_fail | high | hard_gate | Your own stated constraint, specific and confirmed. The posting says "no exceptions" | `[grounded]` JD quote; your constraint | none |
| R2 | Base compensation (your floor: $150k) | hard_gate | hard_gate_fail | high | hard_gate | Posted range tops out at $85k, $65k under your floor | `[grounded]` JD range; your constraint | none |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | 9 years; Growth lead, then Head of Growth. Self-reported, so expect a probe | `[grounded]` your intake | none |
| R4 | Own paid acquisition | must_have | direct | medium | none | Owned paid; no inspectable artifact yet | `[grounded]` your intake | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle; Braze | `[grounded]` your intake | none |
| R6 | SEO/content | important | unclear | low | discovery | Not in your material | `[grounded]` silence | Ask only if the decision reopens |
| R7 | Brand, PR, partnerships, sales ops | important | unclear | low | discovery | Not in your material | `[grounded]` silence | Ask only if the decision reopens |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Off-hours work is routine, not occasional | `[inferred]` from the quote | How often has this role worked evenings or weekends in the last two quarters? | unresolved |
| RR2 | Seniority–pay mismatch | risk_signal | medium | "8+ years growth leadership"; "$70–85k base" | The pay sits below the usual band for this title | `[generic]` pattern; sweep refused | What is the budgeted base for this role, and how was it set? | unresolved |
| RR3 | Responsibility without resources | risk_signal | medium | "team of one to start … we believe in players who don't need a bench" | Seven functions on one person, with no budget named | `[inferred]` from the scope against the team size | What budget and headcount are committed to paid, SEO, brand, PR, partnerships and sales ops in year one? | unresolved |
| RR4 | Success metrics undefined | risk_signal | medium | "success metrics will evolve as we learn" | Accountability without a defined target | `[inferred]` from the quote | What three numbers define success at six and twelve months? | unresolved |
| RR5 | Employer not verified | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A)" | Employer existence and live posting unchecked | `[generic]` pattern for companies this size; research refused | Can you point me to this role on your careers site, and who would I interview with? | unresolved |
| RR6 | Stated stage and reporting line | positive_signal | — | "Series A, profitable since day one"; "report to the CEO" | Clear authority and resources at the top | `[grounded]` JD | Who owns the board-level revenue targets today? | noted |

## Application plan

None. The decision is `no_go`, so I'm not proposing a CV edit, outreach or positioning.

## Research

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both search calls were refused, so the employer's existence and live posting are unverified (RR5) |
| 2. Role-family sweep | unavailable | Both search calls were refused, so the market band behind RR2 is unverified |
| 3. Hiring manager's public footprint | n/a | No name was given |

Neither refusal changes the decision: the gates are fixed by the posting's own terms.

## Evidence status

Verified: R1 and R2 (your own stated constraints, specific and confirmed). R3, R4 and R5 are your self-report at intake and remain unverified.

## Upgrade menu

- Allowing web search would verify Novaline's existence and the live posting (RR5), and would set the market band (RR2). It would not reverse R1 or R2, which are stated in the posting.
- Evidence of SEO/content, brand, PR, partnerships or sales ops would move R6 and R7. That matters only if the decision reopens.

If you want this written up, I can save the analysis as `tuesday-dossier.md`.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.