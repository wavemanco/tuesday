**Yes, apply, but as a stretch.** Your sales-ops and RevOps background matches most of the posting. The two places you'd be stretching are the ones the role is built around: owning the forecast and working with billing and finance data. `conditional_go`: apply if you can show credible adjacency on both in a first conversation.

**Fit ledger**
- `must_have`: direct: R1a, R2, R3, R5a · adjacent: R1b, R4 (forecast ownership) · absent: R5b (billing data) · unclear: R6 (finance work on revenue data)
- R1b, R4 and R5b are the rows you'd need to argue. R6 is unclear because I can't tell from what you've shared whether the pipeline and renewal work ever involved finance.

**Hard gates:** none failed; unconfirmed: H1 (Bristol hybrid, two days a week in office), H2 (£61,500–£67,000 salary); candidate constraints not given, so checks against them are unknown.

**Opportunity ledger.** The employer checks out and the pay is in range. The open questions are scope and reporting line: the posting gives this role the forecast with the CFO and the billing data, and a Head of Revenue Operations is already in place (RR1, RR2). No severe red flags. The posting asks nothing of you up front.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organisation | Quillfield, Bristol; invoicing and payments software for UK builders' merchants; 96 staff; £11M Series A in April 2025 | `[grounded]` search snippet of quillfield.co.uk/about (not fetched) |
| Scope | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Market calibration | Median base £64,200, interquartile range £57,800–£70,400 (UK B2B software RevOps lead, n=438) | `[generic]` Ledgerline 2026 pay guide; a vendor survey, so treat as rough |
| Hiring manager | Tamsin Achebe, listed as Head of Revenue Operations; previously four years in sales operations at Corvane Payments | `[grounded]` profile snippet (not fetched) |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Next action |
|---|---|---|---|---|---|---|
| R1a | 4+ years in RevOps, sales ops or analytics | must_have | direct | medium | none | none |
| R1b | At a B2B software company | must_have | adjacent | medium | transferability | Say B2B payments, not software-first; the limit is that you haven't sold or invoiced software |
| R2 | HubSpot or Salesforce administration | must_have | direct | medium | presentation | Share the certificate to move to high |
| R3 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | none |
| R4 | Owning a forecast | must_have | adjacent | medium | transferability | Monthly pipeline review feeds the forecast, but you've never owned it (G1) |
| R5a | Owning CRM data | must_have | direct | medium | none | none |
| R5b | Owning billing data | must_have | absent | medium | transferability | Ask whether payment or settlement data was ever close to invoicing (G2) |
| R6 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Ask (G2) |
| H1 | Bristol hybrid, two days in office | hard_gate | unclear | none | hard_gate | Ask (Q3) |
| H2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | Ask (Q3) |

Confidence is `medium` on your claims because you've described them in prose, not shown me an artifact. The posting doesn't tier its requirements, so I've marked each as `must_have`.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Verification question | Status |
|---|---|---|---|---|---|---|
| RR1 | Forecast ownership may sit closer to finance than the title suggests | risk_signal | medium | "run the quarterly revenue forecast with the CFO" | Which parts of the forecast does this role own end to end, and which does the CFO sign off? | unresolved |
| RR2 | Reporting line and split with the existing Head of RevOps unclear | unknown | — | "Lead" title against a Head of Revenue Operations on the team | Who does this role report to, and where does its remit stop against the Head of RevOps? | unresolved |
| RR3 | Posting seen only on an aggregator; not yet on Quillfield's own careers page | risk_signal | low | "Revenue Operations Lead, Quillfield" (Tallyboard listing) | Is this role live on your careers page, and who would I be interviewing with? | reduced |
| RR4 | Salary sits inside the market band | positive_signal | — | "£61,500–£67,000 plus share options" | — | noted |

**Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1**

| Target | Status | What it moved |
|---|---|---|
| 1. Official site and careers page | yes | Search "Quillfield invoicing software company Bristol" returned the about page: employer exists as described. Your careers page not checked |
| 2. Role-family sweep | yes | Search "revenue operations lead salary UK B2B software £60,000" returned the Ledgerline 2026 pay guide. Market calibration only |
| 3. Hiring manager's public footprint | yes | Search "Tamsin Achebe Quillfield" returned a profile snippet. Scope read and positioning only |

**Dossier offer:** If you want, I can write this up as a `tuesday-dossier.md` to keep alongside the role.

**Upgrade menu**
- A Salesforce certificate or admin credential → R2 to `high`.
- A forecast you contributed to, even on the sales side (commit calls, pipeline-to-close accuracy) → R4 up from `adjacent`.
- A sanitised pipeline or renewal dashboard → R1a and R3 to `high`.
- The live posting on Quillfield's careers page → clears RR3 and confirms the listing.
- Deeper research on Quillfield (funding, leadership churn, hiring patterns; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

G1: Have you ever been named on a forecast number, even as a contributor? What did you own, and how accurate was it against what closed?

G2: At the payments company, did you touch transaction, settlement or invoice data that finance used for revenue reporting?

Q3: Are Bristol (two days a week in the office) and £61,500–£67,000 workable for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.