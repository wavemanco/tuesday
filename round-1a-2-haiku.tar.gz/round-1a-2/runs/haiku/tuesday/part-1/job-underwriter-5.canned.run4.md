**Yes, it's worth applying to, with conditions. Status: `conditional_go`.** Your stack matches most of the posting, the pay sits inside the market band, and the one real gap is BigQuery, which is a transferable gap. Three things are unconfirmed: your location, work authorization and pay floor, because you didn't give them.

**Fit ledger.**

- `hard_gate`: unclear: R1 (remote US or Denver), R2 (base pay against your floor), R3 (US work authorization)
- `must_have`: direct: R4 (5+ years data engineering), R5 (SQL and Python), R6 (dbt and a cloud warehouse), R8 (Airflow or similar), R9 (data quality testing)
- `important`: adjacent: R7 (BigQuery warehouse); unclear: R10 (ingestion from app and CRM), R11 (data contracts analysts rely on)

R7 — Snowflake to BigQuery, a transferable case with its limit named; R10 and R11 — not in your intake, one question each.

**Opportunity ledger.** The stated pay ($148,000–$166,000) sits inside the role-family interquartile range (RR1), and the employer is confirmed only through its own site (RR2). The posting names no hiring manager and leaves team size and equity open (RR3, RR4). No severe red flags.

- **Hard gates:** none failed (no gate row has been tested against your inputs yet); unconfirmed: R1 (remote US or Denver), R2 (base pay against your floor), R3 (US work authorization); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) R1–R3 check out against your own situation; (2) RR2 is closed by an independent source for the employer; (3) BigQuery is presented as adjacent, never as experience.
- **What would change this:** a failed gate (for example, no US work authorization) makes this `no_go`, with that gate as the reason.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; Denver; 264 employees; Series C, $52M, Feb 2026 | `[grounded]` its about page, read from a search snippet, not fetched in full |
| Mandate | Build and run ingestion from the app and CRM, a dbt warehouse on BigQuery, and data contracts for analysts | `[grounded]` posting; careers page fetched and matches |
| Working pattern | Remote (US) or Denver office | `[grounded]` posting |
| Scope read | Domain-owning senior IC role; no direct reports stated | `[inferred]` from the responsibility list |
| Market calibration | Stated base sits inside the IQR ($139,000–$163,500), median $151,000; equity unquantified | `[generic]` Datawright 2026 report (n=2,310), read from a search snippet; `[grounded]` the posting's range |
| Unknowns | Equity size; team size; hiring manager; whether BigQuery is the current stack | — |
| Contradictions | None between the pasted posting and the careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location isn't in the intake | `[grounded]` posting | G3 question |
| R2 | Base pay against your floor | hard_gate | unclear | none | hard_gate | Pay band is stated; your floor isn't given | `[grounded]` posting | Q3 question |
| R3 | US work authorization | hard_gate | unclear | none | hard_gate | Not stated by you or the posting | `[inferred]` from "Remote (US)" | Q2 question |
| R4 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; intake prose, so medium ceiling | `[grounded]` your intake | none |
| R5 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated in intake | `[grounded]` your intake | none |
| R6 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of ~180 models on Snowflake | `[grounded]` your intake | none |
| R7 | BigQuery warehouse (in responsibilities) | important | adjacent | medium | transferability | Cloud warehouse and dbt carry over; BigQuery-specific cost and partitioning never exercised | `[inferred]` from the Snowflake work | G1 |
| R8 | Airflow or similar | must_have | direct | medium | none | Airflow orchestration in intake | `[grounded]` your intake | none |
| R9 | Data quality testing | must_have | direct | medium | none | Great Expectations suite set up; ownership depth unclear | `[grounded]` your intake | none |
| R10 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your intake | `[inferred]` from the responsibility list | G2 question |
| R11 | Data contracts analysts rely on | important | unclear | low | discovery | Not in your intake | `[inferred]` from the responsibility list | G2 question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7) | transferability | Snowflake and dbt work; no BigQuery | The posting names BigQuery; the limit is the one most likely to be raised | A dbt model or cost check on any cloud warehouse; a dbt adapter swap; query optimization on Snowflake that carries over | A small BigQuery dbt project, or a query-cost note | `[inferred]` bridge from the Snowflake work |
| G2 | Ingestion and contracts (R10, R11) | discovery | Nothing in intake covers app or CRM ingestion or schema contracts | Two of the role's three named responsibilities | Pipelines from a product database or a CRM API; schema agreements with downstream consumers | A pipeline diagram; a data-contract document | `[inferred]` from the posting's responsibilities |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Stated pay inside the band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is at or slightly above median | `[grounded]` posting; `[generic]` band | Is the base flexible toward the top of the range, and what is the equity grant? | noted |
| RR2 | Employer confirmed only through its own site | risk_signal | medium | "Series C ($52M, February 2026)" | The employer is real but its funding and size are self-reported | `[generic]` pattern for companies of this size, not a claim about this one | Which funding announcement or press coverage confirms the Series C? | reduced |
| RR3 | Scope of data contracts and ingestion unstated | unknown | — | "the data contracts our analysts depend on" | Ownership may be shared with an existing platform team | `[inferred]` from the responsibility list | Which data sources and contracts exist today, and who owns their schemas upstream? | unresolved |
| RR4 | No hiring manager named | unknown | — | (posting names no hiring manager) | The team may be new or the posting generic | `[grounded]` posting | Who is the hiring manager, and how big is the team this role joins? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check R1–R3 yourself before applying (location, authorization, pay floor) | These gates are unconfirmed and could change the status | `[grounded]` gate rows | pending your approval |
| A2 | Proposed resume line: "Built and maintained a dbt project of ~180 models on Snowflake; orchestrated with Airflow; set up a Great Expectations test suite." | Leads with the two strongest must-haves; no BigQuery claim | `[grounded]` your intake wording | resume_edits_pending_approval |
| A3 | Confirm the Series C from a funding source before investing in the loop | Closes RR2 | `[generic]` pattern | pending your approval |
| A4 | Say "BigQuery is new to me; my dbt and Snowflake work transfers" if it comes up | Keeps R7 at adjacent | `[grounded]` R7 row | pending your approval |

## Evidence status

Verified: none yet. Everything so far is your intake, which is leads for verification, not proof.

Research tier: L1 — searches 2 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched pellucidlearning.com/careers/senior-data-engineer: live, text matches your paste. Searched "Pellucid Learning live online tutoring K-12 Denver": no results. The about page (pellucidlearning.com/about) surfaced in a salary search, read as a snippet only. Moved: RR2 and the contradictions row (none) |
| 2. Role-family sweep | yes | Searched "Senior Data Engineer salary Series B-D base median 2026 pay report": returned datawright.example/2026-data-engineering-pay-report, a snippet that matches your recruiter's copy. Moved: market calibration and RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Level 2 was not run.

**Dossier offer:** I can write this up as a `tuesday-dossier.md` for reuse in interview prep, if that would help.

**Upgrade menu**

- A small BigQuery dbt project or a query-cost note → R7 moves toward direct.
- A pipeline diagram or a data-contract document from your payroll work → R10 and R11 move off unclear.
- Your base floor and equity expectations → R2 closes and RR1 is sized against you.
- The hiring manager's name and team size → RR4 closes.
- A funding announcement for the Series C → RR2 closes.
- Deeper company research (leadership, hiring history, up to 5 more searches and 2 more fetches) — say the word and I'll run it.

**Questions**

Q1 (G2, R10 and R11): Have you built ingestion from a product app or a CRM into a warehouse, and did you own the schemas downstream users depended on? What did you own?

Q2 (R3, hard gate): Are you authorized to work in the US without sponsorship?

Q3 (R2, hard gate): What is the minimum base pay you would accept, and does $148,000 meet it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.