## Decision snapshot

Not wasted, but the posting asks for product-management years you don't have. R1 (3+ years of product management) is adjacent, not met. Status: `hold_pending_answers`.

**Fit ledger**

- `must_have`: direct: R3, R4a · adjacent: R1 (3+ years product management), R2 (shipped API or platform products) · unclear: R4b (stakeholder management, sales), R5 (agile delivery)
- `important`: adjacent: R6 (discovery with integration partners), R7 (specs and delivery with two squads), R9 (launch coordination with sales and support) · unclear: R8 (adoption metrics)

R3 — technical fluency is a direct match with your Postman, SQL and OpenAPI work; R4a — engineering and customer coordination is a direct match; R1 and R2 — the integration work carries over, but no product ownership is claimed; R8 — adoption metrics rest on a memory lead, not CV evidence.

**Opportunity ledger.** Scope is defined but decision rights are not: whether this role decides engineering capacity across the two squads is unstated (RR1). The employer and posting are unverified from here because research did not run (RR4). One entry runs the other way: adoption metrics are named as part of the job (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** the three answers in the closing questions. A shipped product decision moves R1 and R2 toward direct. Without one, the case rests on the bridge alone, which reads as `conditional_go` at most, with the limit named.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header |
| Mandate | Own the roadmap for a partner-facing API platform; drive delivery with two engineering squads | `[grounded]` JD |
| Scope read | A platform-owner remit: one platform, two squads, launches with sales and support | `[inferred]` from the JD's own verbs |
| Market calibration | Not run. Research did not run, so no pay or title band is set | — |
| Unknowns | Pay, location, contract type, whether the partner API is live or a build-out, who decides squad capacity | — |
| Contradictions | None visible; only one source was provided | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management | must_have | adjacent | medium | transferability | Seven years of implementation and solutions work, no PM title. Limit: no product decisions owned. The JD tags the years as must-have, which makes them graded, not a gate | `[grounded]` CV; `[generic]` that screens often read years literally | Q1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ client integrations of the company's REST APIs, end to end, through go-live. Limit: you shipped integrations, not a product you owned | `[grounded]` CV | Q1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | presentation | Postman, SQL, OpenAPI named; integration architecture work. The CV does not show a schema decision you made | `[grounded]` CV | show one schema decision |
| R4a | Stakeholder management: engineering, customers | must_have | direct | medium | none | Coordinated vendor engineers, client engineers and product managers on custom builds | `[grounded]` CV | none |
| R4b | Stakeholder management: sales | must_have | unclear | low | discovery | No sales coordination in the CV | `[grounded]` CV silence | Q3 |
| R5 | Agile delivery | must_have | unclear | low | discovery | Not mentioned | `[grounded]` CV silence | Q3 |
| R6 | Discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and quarterly roadmap-input sessions collecting client feedback. Limit: you collected input for product; you did not decide from it | `[grounded]` CV | none |
| R7 | Specs and delivery with two squads | important | adjacent | medium | transferability | Requirements documents and a team integration playbook. Squad delivery not stated | `[grounded]` CV | Q3 |
| R8 | Adoption metrics | important | unclear | low | discovery | Nothing in the CV. The triage-tool lead is a memory lead, not evidence | `memory_lead`, unconfirmed | Q2 |
| R9 | Launch coordination with sales and support | important | adjacent | medium | transferability | Client go-live and UAT. Limit: client launches, not internal launches with sales and support | `[grounded]` CV | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product ownership (R1, R2) | transferability | Integration and implementation depth; no product decision in the CV | Decides whether the adjacent reads as a bridge or a stretch | Feature or partner-request calls you made that shipped; what the API did next because of your input | A spec, a roadmap slide, a release note with your name on the decision | `[grounded]` CV; `[inferred]` that a shipped decision moves the status |
| G2 | Adoption metrics (R8) | discovery | Memory lead only | Metrics are a named job duty | A tool, process or report you measured use of | A dashboard, a usage export, a launch doc | `memory_lead`, unconfirmed |
| G3 | Agile and squad delivery (R5, R7) | discovery | Specs written; squad delivery and cadence not stated | A must-have row with no evidence | Backlog ownership, sprint planning, release sign-off, even informally | A backlog view, a sprint summary | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Roadmap ownership without stated capacity authority | unknown | — | "Own the roadmap ... drive delivery with two engineering squads" | The role may set priorities without deciding squad capacity | `[inferred]` from the ownership verbs against the JD's silence on capacity | Who decides engineering capacity across the two squads, and where do partner requests rank against it? | unresolved |
| RR2 | Maturity of the partner API | unknown | — | "partner-facing API platform" | The platform may be live with partners, or a first build-out | `[inferred]` from the JD's wording against its silence on maturity | Is the partner API live with integration partners today, or is this its first build-out? | unresolved |
| RR3 | Adoption metrics named as duty | positive_signal | — | "define and track adoption metrics" | Success is at least partly measurable | `[grounded]` JD | What adoption measure is the target this year, and who set it? | noted |
| RR4 | Employer and posting not verified | unknown | — | the posting as pasted | The posting may be stale, or the employer may be hard to confirm | `[inferred]` from research that did not run | Is this role live on your own careers page, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the bridge: "30+ client integrations of the company's REST APIs, end to end, through go-live; the integration playbook the team uses" | R2, R9 | `[grounded]` CV | pending your approval |
| P2 | State the limit in the first conversation: "I haven't held a PM title. My product-facing work has been on the integration side of a platform." | R1, R2 | `[grounded]` CV; limit as a proposed sentence | pending your approval |
| P3 | Do not write "owned the roadmap" for the roadmap-input sessions. You collected client input for product; "owned the roadmap" would be a verb drift | R6 | Reframing audit, verb axis | pending your approval |
| P4 | Keep the triage tool out of every document until you confirm it | R8 | `memory_lead` is never evidence | pending your approval |
| P5 | Verify the posting on Quartzline's careers page before applying | RR4 | `[grounded]` register | pending your approval |

This is a recoverable gap, not a capability one. Closure is a shipped product decision (G1) plus a bridge with its limit named. The years line itself closes only with product years, so this posting is a bridge application, not a match. `[generic]` Roles that ask for integration or solutions background alongside product work are the usual route for this move.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology careers Product Manager Platform APIs"; the call was refused. Would have confirmed the employer and that the posting is live (RR4) |
| 2. Role-family sweep | unavailable | Searched "product manager API platform salary B2B logistics software Series B 3+ years experience"; refused the same way. Would have set the title and pay band |
| 3. Hiring manager's public footprint | n/a | No name given, so no query to form |

The search permission was declined in this session, so I did not retry.

Dossier offer: I can save this as `tuesday-dossier.md` if you want one file to carry into your next steps.

**Upgrade menu**

- Permission to run the two searches → verifies the posting (target 1) and sets a pay and title band (target 2).
- The live posting link from Quartzline's careers page → verifies RR4 and shows the posting's own wording on decision rights (RR1).
- A spec, roadmap slide, or release note you wrote → raises R7 and R2 from medium to high.
- A tool doc or usage export for the triage tool, if it exists → resolves G2 and R8.

**Questions**

G1 — Have you ever made a product decision that shipped on a platform, such as which partner request got built, which was cut, or what the API did next? Name one: what you owned, who you had to persuade, and what happened.

G2 — Did you build an internal request-triage tool that support agents adopted? If so, what did you own, how did you measure adoption, and is there anything I could look at?

G3 — Have you owned a backlog or run delivery with engineering squads, even informally? Which tools and cadence, and what was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.