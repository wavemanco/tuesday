**Yes, apply.** On the requirements you gave, R1, R2, R3, R4 and R5 all read `direct`, so this is `conditional_go`. The condition is that the posting checks out on Harborlight's own careers site and that pay, location and contract type are acceptable. Web search was refused in this session, so I could not verify the employer or the posting.

## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: adjacent: R6 (metrics layer), R7 (PM partnership); unclear: R9 (mentoring junior analysts); absent: R8 (clinician partnership)
- `preferred`: adjacent: R10 (HIPAA)

- R1 to R5 — direct, with the years, SQL, experiment and Looker claims still unprobed; R6 — adjacent, limit named; R7 — adjacent, PM-level partnership not described; R8 — absent, closure path named; R9 — unclear, one question asked; R10 — adjacent, the HIPAA bridge with its limit named.

- **Opportunity ledger.** Pay, location and contract type are unknown (RR1). The employer and posting are unverified in this run (RR2). Clinician involvement is named but not described (RR4). One entry runs the other way: the ownership language is explicit (RR3).
- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the live posting is confirmed on Harborlight's careers site, and pay, location and contract type come back acceptable (RR1, RR2); (2) you can speak concretely to clinician work, or name the gap plainly as R8 (G3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, described as a digital-health scale-up of about 400 people, Series C | `[grounded]` your description; not verified in this run |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` posting |
| First-year outcomes | None stated in the posting | `[grounded]` posting |
| Working pattern | Location and remote or hybrid policy not stated | — |
| Scope read | A senior individual-contributor seat that also leads two juniors and owns a metrics layer | `[inferred]` from the responsibilities list against the mentoring line |
| Market calibration | Not run; the pay band cannot be checked in this run | — |
| Unknowns | Pay, location, contract type, reporting line, clinician involvement | — |
| Contradictions | None visible in what you provided; the employer's own pages were not read | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years stated; meets the bar on its face. Self-reported and unprobed, so `medium` is the ceiling | `[grounded]` your intake background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake for six years. "Expert" is a level claim the intake does not show; expect a probe on joins and performance | `[grounded]` your intake background | A sanitized query or metric definition would raise to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran 30+ tests a year, including the pricing test behind the 11% retention lift. Method and readout not inspected; expect a probe on attribution and power | `[grounded]` your intake background | A redacted test readout would raise to `high` |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | Built the company's Looker instance and 40+ governed dashboards. Self-serve use by non-analysts is not stated | `[grounded]` your intake background | A dashboard inventory or governance note would raise to `high` |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Writes the monthly metrics memo the exec team reads, and presents monthly to VP Product. The memo is confidential | `[grounded]` your intake background | A redacted excerpt, with your approval, would raise to `high` |
| R6 | Define and maintain the metrics layer | important | adjacent | medium | transferability | Governed dashboards and the memo's metric definitions sit near a metrics layer. No shared semantic layer or cross-team metric ownership is described | `[grounded]` dashboards and memo; `[inferred]` the adjacency | Frame as governed dashboards and metric definitions, with the limit stated (G1) |
| R7 | Partner with PMs to turn analysis into roadmap decisions | important | adjacent | medium | transferability | Presents to VP Product and writes exec memos, which are decision-facing. A working partnership with PMs is not described | `[grounded]` memo and presentations; `[inferred]` the adjacency | Name one case where analysis changed a roadmap decision (G2) |
| R8 | Partner with clinicians | important | absent | none | discovery | Nothing in the intake covers clinicians; the background is consumer subscription only. Not yet established that no such evidence exists | `[grounded]` absence in the intake | Question G3 in the closing block |
| R9 | Mentor two junior analysts | important | unclear | none | discovery | Mentoring is not in the intake, so it is unclear rather than absent | `[grounded]` absence in the intake | Question G4 in the closing block |
| R10 | Healthcare data experience (HIPAA), a plus | preferred | adjacent | medium | transferability | GDPR and CCPA consumer PII handling and the consent-state model carry over. HIPAA's PHI rules and BAAs are not exercised | `[grounded]` consent-model work; `[generic]` that HIPAA is a separate regime from GDPR and CCPA | Frame as consumer privacy, not healthcare (G5) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | transferability | Governed dashboards and metric definitions; no shared semantic layer described | The bridge is the objection most likely to come up | Metric definitions you set that other teams relied on; a dispute you settled over what a metric counts | A governance doc, metric dictionary excerpt | `[grounded]` intake; `[inferred]` the bridge |
| G2 | PM partnership (R7, important) | transferability | Decision-facing exec work; no PM-level partnership described | Roadmap influence is what the role is for | A case where a PM changed scope or sequencing because of your analysis | A short case write-up | `[grounded]` intake; `[inferred]` the bridge |
| G3 | Clinician partnership (R8, important) | discovery | Nothing about clinicians; the background is consumer only | A named gap for the care-navigation context | Work with ops, support or any staff close to care-related decisions | Any clinical-ops or care-team brief | `[grounded]` absence; `[generic]` care-navigation teams involve clinical staff |
| G4 | Mentoring (R9, important) | discovery | Mentoring not in the intake | Stated in the mandate | Onboarding or reviewing a junior's analysis, formally or informally | Any onboarding plan or review you wrote | `[grounded]` absence |
| G5 | HIPAA (R10, preferred) | transferability | Consent-state model for consumer PII | The bridge's limit is the regime, not the rigor | Data-classification or access rules you designed | A description of the consent model | `[grounded]` intake; `[generic]` regime difference |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay, location and contract type not in posting | unknown | — | (none in the posting) | Terms may be set after screening, or the posting may be a template | `[generic]` pattern for postings of this kind | What is the base salary range, where is the role based, and is it a permanent position? | unresolved |
| RR2 | Employer and live posting not verified in this run | unknown | — | "Senior Product Analyst — Harborlight Health" | The posting may be as described; nothing was read from the employer's own pages in this run | `[grounded]` the research calls were refused; see Evidence status | Which page on your careers site lists this role, and who would I be interviewing with? | unresolved |
| RR3 | Explicit ownership scope | positive_signal | — | "Own product analytics for our care-navigation app" | Scope and ownership are stated, not implied, so this is an owner seat | `[grounded]` posting ownership language | Which metric definitions does this role sign off alone, and who else decides them? | noted |
| RR4 | Clinician involvement named, not described | unknown | — | "partner with product managers and clinicians to turn analysis into roadmap decisions" | Clinicians may review or gate decisions, which changes how the work reads | `[inferred]` from the posting's silence on how clinicians take part | How do clinicians take part in analysis decisions, and how often do analysts sit with them? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Harborlight's own careers site before investing in the application | see RR2 | `[grounded]` RR2 | pending your check |
| A2 | Ask the recruiter the three RR1 questions: pay, location, contract type | see RR1 | `[grounded]` RR1 | pending your check |
| W1 | Source a redacted test readout (R3) and, with your approval, a memo excerpt (R5) | Moves them to `high` | `[grounded]` R3, R5 | pending your approval; confidential, so redact |
| P1 | Describe the consent-state work as consumer privacy (GDPR/CCPA), not as healthcare experience | Avoids implying HIPAA work | `[grounded]` R10 | proposed wording, pending your approval |
| P2 | Prepare the pricing test: what you owned versus the team, and how the 11% was measured | This is the claim most likely to be probed | `[grounded]` R3 | prep, no approval needed |

## Evidence status

Verified: none yet. Nothing has been confirmed with a probe or an inspectable artifact. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Web search was refused for all calls in this run. Would have confirmed the employer exists and the posting is live (RR2) |
| 2. Role-family sweep | unavailable | Also refused. Would have set the pay and scope band for this title (R1, RR1 calibration) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

If you'd like, I can save this as `tuesday-dossier.md` so you can append to it as answers come in.

## Upgrade menu

- A live posting link from Harborlight's careers site → RR2 closes; the posting's own wording gets read in place of your paste.
- Base salary range, location and contract type → RR1 closes; the pay band can then be checked against the role-family pattern.
- Permission for web search → the L1 pass runs: employer, posting and a role-family pay band.
- A redacted test readout (for example, the pricing test) → R3 moves to `high`.
- A redacted memo excerpt, with your approval → R5 moves to `high`.
- A dashboard inventory or governance note → R4 and R6 strengthen.
- A paragraph on the consent-state model → the R10 bridge's limit narrows.

## Questions

G4 — Have you managed or mentored junior analysts, formally or informally? What did you own, and what happened?

G3 — Have you worked directly with clinicians, nurses or clinical operations on analysis or product decisions? If so, what did you do, and who was on the other side?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.