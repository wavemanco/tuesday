**Yes, apply, with the forecast and billing parts of the role treated as open.** Status: `conditional_go`. The two must-have gaps are R7 (owning the quarterly forecast) and R8a (billing data). Your five years of pipeline and renewal work carry most of the rest.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, two office days a week), R2 (£61,500–£67,000 plus share options)
- `must_have`: direct: R3 (4+ years in RevOps or sales ops), R4 (Salesforce admin), R5 (SQL) · adjacent: R7 (forecast ownership, via the pipeline review) · unclear: R6 (spreadsheet modelling), R8b (finance work on revenue data) · absent: R8a (billing data)
- `important`: direct: R9 (pipeline and renewal reporting)

R7 — the pipeline review is a real input, but finance has always owned the number; R8a — no billing work to point to; R6 and R8b — need your answers before you claim them.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week), R2 (£61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the forecast is yours to build and present to the CFO, not finance's to own (RR1, R7); (2) you would have direct or reliable access to billing data (RR2, R8a); (3) Bristol and the pay range work for you (R1, R2).

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organisation | Quillfield, invoicing and payments software for UK builders' merchants; Bristol; 96 staff; £11M Series A in April 2025 | `[grounded]` company About page (search result) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Hybrid, two office days a week, Bristol | `[grounded]` posting |
| Market calibration | Posted range sits inside the middle half of UK revenue-ops lead pay (IQR £57,800–£70,400; median £64,200; n=438) | `[generic]` 2026 UK pay guide. Not this employer's offer |
| Unknowns | Who signs off the forecast; billing-system ownership and access; whether this builds reporting from scratch or changes an existing function | — |
| Contradictions | None found between the posting and the company's About page | `[grounded]` |

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two office days | hard_gate | unclear | none | hard_gate | Your constraint was not given | `[grounded]` posting | Q3 |
| R2 | Pay £61.5–67k plus options | hard_gate | unclear | none | hard_gate | Your pay floor was not given; share options unquantified | `[grounded]` posting | Q3 |
| R3 | 4+ years in RevOps or sales ops at a B2B software company | must_have | direct | medium | presentation | Five years in sales ops at a B2B payments company, two of them running UK RevOps. Payments is close to software but is not the same label | `[grounded]` your intake | Make the B2B link explicit |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; certificate not yet seen | `[grounded]` your intake | Share the certificate → high |
| R5 | Strong SQL | must_have | direct | medium | none | SQL weekly | `[grounded]` your intake | Name one query or model you wrote |
| R6 | Strong spreadsheet modelling | must_have | unclear | low | discovery | Excel daily, but daily use is not modelling | `[inferred]` from intake | Q2 |
| R7 | Owning a revenue forecast, with the CFO | must_have | adjacent | medium | transferability | You run the monthly pipeline review with the sales director and have never owned the company forecast, which finance did | `[grounded]` your intake; `[inferred]` adjacency | Q1 |
| R8a | Billing data | must_have | absent | medium | transferability | You have never worked on billing data. Renewal and pipeline data are the nearest adjacent work | `[grounded]` your statement | Q2 |
| R8b | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Renewal dashboards may count as revenue data; the finance interaction is unstated | `[grounded]` absence in intake | Q2 |
| R9 | Build pipeline and renewal reporting | important | direct | medium | presentation | You rebuilt the pipeline and renewal dashboards | `[grounded]` your intake | Sanitised screenshot → high |

**Gap recovery queue.** Each gap is described here. Its question is asked in the closing block.

- **G1, R7 (transferability).** The pipeline review is a real input to the number, but you have never set or defended the forecast. The limit is ownership, not skill. To close it, show how your pipeline review fed a number finance then used.
- **G2, R8a and R8b (transferability, then discovery).** You have never worked with billing data. Renewal and pipeline data are the nearest bridge, and whether finance interaction counts depends on your answer.

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast accountability not defined | unknown | — | "run the quarterly revenue forecast with the CFO" | You may be accountable for the forecast while finance sets the method and sign-off | `[inferred]` from the posting's silence on who signs off | Who signs off the forecast figure, and which model and inputs does this role own versus finance? | unresolved |
| RR2 | Billing data ownership without stated access | risk_signal | low | "own our CRM and billing data" | The role may own data it cannot change or query directly | `[inferred]` from the posting's silence on system access | Who owns the billing system today, and what access would this role have? | unresolved |
| RR3 | Posting not confirmed on the company's own careers site | risk_signal | low | Posting on an aggregator (tallyboard.example) | The listing may be stale or re-posted | `[generic]` pattern for aggregator listings, not a claim about this one | Is this role live on your careers page, and is it the one the recruiter discussed with me? | unresolved |
| RR4 | Whether this is a new function or an existing one | unknown | — | "build the pipeline and renewal reporting" | The function may already exist; this role may change it | `[inferred]` from the posting's wording | What reporting exists today that this role would replace? | unresolved |
| RR5 | Pay published and in band | positive_signal | — | "£61,500–£67,000 plus share options" | The posted range sits inside the middle of the market band | `[generic]` band against `[grounded]` posting | What is the share option grant, and how is it valued? | noted |

**Application plan.** Every row is proposed and waits for your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with R3, R4, R5 and R9 evidence, and state the payments-to-software link in one clause | Those are the rows you can prove | `[grounded]` rows R3, R4, R5, R9 | pending your approval |
| P2 | Describe the pipeline review as input to the forecast, not as owning it. Proposed wording: "contributed pipeline inputs to the monthly review with the sales director" | Keeps the claim within what you did (R7) | `[grounded]` your intake | pending your approval |
| P3 | Confirm the forecast and billing-access questions before the first interview | Both are must-have gaps | `[grounded]` RR1, RR2 | pending your approval |

The Tamsin Achebe profile is a public snippet: Head of Revenue Operations at Quillfield, previously a sales operations manager at Corvane Payments for four years (`[grounded]`, search result). It is a useful reader. Her payments background is close to yours, so lead with the payments sales-ops work.

**Evidence status.** Verified: none yet. Your intake is CV-equivalent until you answer a probe. Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol". Read the company's About page (quillfield.co.uk/about): confirms the entity, size and funding. Careers page not checked (see RR3) |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software 2026", which returned the Ledgerline 2026 UK Revenue Operations Pay Guide. Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Quillfield Revenue Operations Lead Tamsin Achebe", which returned a public profile (linkedin.example/in/tamsin-achebe). Positioning for P1 |

**Upgrade menu.**

- A copy of the Salesforce admin certificate → R4 to `high`.
- A sanitised screenshot of the pipeline or renewal dashboard → R9 to `high`.
- One short description of a forecast-adjacent number you fed into the review, and what happened to it → R7 moves toward `direct` if you ran the number.
- The recruiter's answers on forecast sign-off, billing access and the careers-page listing → RR1, RR2 and RR3 close.
- A deeper research pass on Quillfield (funding rounds, leadership changes, employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can also write a fuller dossier you can keep and add to; that's one more step, not part of this reply.

**Questions.**

Q1 (R7, RR1): Would you own the forecast number and the model, or feed a number finance signs off? Who would sign off the figure you take to the CFO?

Q2 (R8a, R8b, RR2): Have you ever worked with billing data, or with finance on revenue numbers, even informally? If not, would this role get direct access to billing data, or only exports from finance?

Q3 (R1, R2): Can you work in Bristol two days a week, and what is your pay floor? I'm asking only whether those gates are met for you, not for a workaround.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.