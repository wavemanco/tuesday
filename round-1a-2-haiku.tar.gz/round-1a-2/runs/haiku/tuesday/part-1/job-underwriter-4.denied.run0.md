**Yes, it's worth applying, on conditions. Status: `conditional_go`.**

Your must-have experience (GLM, SQL and Python, presenting to underwriting, running price tests) lines up with the posting. The gaps are pet insurance, whether you designed the tests or only ran them, and the product side of the recommendations.

**Fit ledger.**

- `hard_gate`: unclear: R1 (UK location, fully remote)
- `must_have`: direct: R2, R3, R4, R5, R7, R8, R9 · unclear: R6 (design price tests), R10 (product recommendations)
- `important`: adjacent: R11 (pet-insurance product knowledge)
- `preferred`: direct: R12 (insurance experience)

R6 — you ran the tests, and the posting asks you to design them; R10 — no product-side recommendations in what you gave me; R11 — the pricing method transfers, but you have no pet data; R1 — your base is not stated.

**Opportunity ledger.** Under-specified rather than unsafe: no pay, no stated decision rights over rates, and no line-management line (RR1, RR2, RR3). The duties and tools are concrete (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (UK location, fully remote); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1: you confirm you're UK-based with the right to work; (2) R6: you confirm you designed the price tests, not only ran them; (3) RR5: the live posting appears on Brindlemoor's own careers page. I could not check (3) this session.
- **What would change this:** if R1 fails, this becomes `no_go`. If R6 comes back as "ran only", the must-have is weaker but the decision stays `conditional_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech | `[grounded]` your header |
| Mandate | Own pricing analytics for the pet-insurance product; build and monitor rating models; design and read price tests; turn results into recommendations | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message |
| Scope read | A senior individual-contributor analytics role over one product. The posting names no team, budget or reporting line | `[inferred]` from the duty list against what it omits |
| Market calibration | Not established. The salary search was refused, so there is no band, and I have not used memory for one | — |
| Unknowns | Pay; rate decision rights; line management; team size; available pet data | — |
| Contradictions | None between your header and the JD. Not checked against the employer's own site | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | UK-based, fully remote UK role | hard_gate | unclear | low | hard_gate | Your base is not stated. Your UK motor employer suggests it, but that is a lead, not a statement | `[inferred]` from the UK employer you named | Question R1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, stated; not yet inspected | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | `[grounded]` your statement | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM. The method is the same; the product is motor | `[grounded]` your statement | none |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" covers building; monitoring cadence is not stated | `[grounded]` your statement | none |
| R6 | Design price tests | must_have | unclear | medium | discovery | You "ran" 14 tests. Running does not establish that you set the design | `[grounded]` your wording | Question G1 |
| R7 | Read price tests | must_have | direct | medium | none | Results were read and presented in the quarterly review | `[grounded]` your statement | none |
| R8 | Present to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R9 | Recommendations for underwriting | must_have | direct | medium | none | Your quarterly review and price-test work reach underwriting | `[grounded]` your statement | none |
| R10 | Recommendations for product | must_have | unclear | low | discovery | Nothing product-side in what you gave me | `[grounded]` absence in your background | Question G2 |
| R11 | Pet-insurance product knowledge | important | adjacent | medium | transferability | No pet experience, stated. Motor pricing method transfers. Pet risk differs in ways I cannot evidence here | `[inferred]` transfer from motor work; `[generic]` that pet books differ from motor | Bridge case, G3 |
| R12 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your statement | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Design of price tests (R6, must_have) | discovery | "Ran 14 tests" does not say who set the test design | Moves a must-have between `direct` and `unclear` | Choosing segments or cells; defining what success meant; deciding what to vary; writing up the readout | A test brief, a readout deck, or a summary of one test | `[grounded]` your wording |
| G2 | Product recommendations (R10, must_have) | discovery | No product-side work described | Half of one responsibility | Pricing input to a product launch, a feature or a coverage decision | A product brief or sign-off record | `[grounded]` absence in your background |
| G3 | Pet-domain bridge (R11, important) | transferability | Motor pricing, same method | The objection most likely to be raised | Any work on animal, health or claims-cost data; reviews of loss ratios | A short note on how you'd adapt a GLM to pet risk | `[inferred]` bridge; `[generic]` on what the objection will be |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Recommendations without stated rate authority | risk_signal | medium | "Own pricing analytics … turn the results into recommendations" | The role may own the analysis, while rates are set by underwriting or product | `[inferred]` from "recommendations" against silence on rate decisions | Does this role set final rates, or recommend them for underwriting and product to decide? | unresolved |
| RR2 | Pay not in the posting | unknown | — | No pay in the material you shared | Pay may be withheld, or left out of what you pasted | `[grounded]` absence; no band (search refused) | What is the salary range for this role? | unresolved |
| RR3 | Line management unstated | unknown | — | "Senior" in the title; no people duties listed | The role may be expected to manage people, which you have not done | `[inferred]` from the title against the duty list | Does this role line-manage anyone now, or within the first year? | unresolved |
| RR4 | Concrete duties and tools | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope is specified and sits close to your core work | `[grounded]` JD | Which of these duties already has an owner on the team? | noted |
| RR5 | Employer and posting not verified this session | risk_signal | medium | "Brindlemoor (insurtech)" from your header | Pattern for companies of this size, not a claim about this one: the employer may be too new or small to have a footprint, the posting may be stale, or it may not be a live hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the live posting on your own careers site, and who would I be interviewing with? | unresolved |

Decision rule for RR5: verify the employer and the posting are live before investing application effort. This caps the decision at `conditional_go`.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the live posting on Brindlemoor's own careers page before applying | RR5 | `[generic]` pattern | your action, no approval needed |
| P2 | Keep the verb "ran" for the 14 price tests until G1 is answered. Proposed CV line: "Ran 14 price tests with the underwriting team; read results and presented them to the head of underwriting" | Upgrading "ran" to "designed" would claim the design work before you have confirmed it (see the reframing audit) | `[grounded]` your sentence | `resume_edits_pending_approval` |
| P3 | State the pet gap in the application: "GLM pricing in motor; no pet data yet; here is how the method carries over" | R11 is a known gap, and naming it protects you in interview | `[inferred]` from R11 | pending your approval |
| P4 | Ask the RR1 and RR2 questions in the first call | They decide whether the role is worth the time | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on your own statements in this conversation, which count as a CV-equivalent lead until you have shown an artifact or answered a probe. Stage assumed: evaluating (you didn't say). No CV file was supplied; I worked from your background prose.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches were refused by the host (search permission not granted). The employer and posting are unverified, which is why RR5 stands |
| 2. Role-family sweep | unavailable | The same refusal. No pay band, so RR2 stays open and the market-calibration line is empty |
| 3. Hiring manager's public footprint | unavailable | Name given (Odile Varga); no search was sent because the host refused search. Would have moved the positioning in P2 and P3 |

## Upgrade menu

- An anonymised price-test brief or readout → R6 and R7 to `high`, and it shows whether you designed the test.
- The young-driver GLM documentation or model card, anonymised → R4 and R5 to `high`.
- The budgeted salary or pay range → RR2 closes, and the figure can be set against a band.
- Search permission turned on → a rerun checks the Brindlemoor posting (RR5), sets a UK salary band for the title (RR2), and looks at Odile Varga's public footprint, up to 5 searches and 2 fetches.

I can also save this as `tuesday-dossier.md` if you want a file to carry into the next round.

Three questions:

- **R1:** Are you based in the UK, with the right to work there, for a fully remote UK role? Answer yes, no, or skip.
- **G1 (R6):** When you ran the 14 price tests, who set the test design: what changed, for which segment, and what success looked like? Did you design it, or run a design someone else set?
- **G2 (R10):** Have you presented pricing recommendations to a product lead, or only to underwriting?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.