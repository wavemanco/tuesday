**Not a waste of time, but a stretch. `conditional_go`: apply only if you can back up a product-ownership story.**

The must-have "3+ years product management" is the screen most likely to cut you before anyone reads your adjacent work. It is experience length, not a legal gate, so it is graded on fit, not treated as a disqualifier.

**Fit ledger**
- `must_have`: direct: R8 · adjacent: R1, R2, R3, R4a, R7, R9 · unclear: R4b
- `important`: adjacent: R6 · unclear: R5

R8 (technical fluency) is your strongest match. R1, R2 and R3 are real adjacent work, but each stops short of owning product decisions. R4b (agile delivery) is silent on your CV. R5 (adoption metrics) is unevidenced unless the triage tool you may have built is real.

**Opportunity ledger.** The role is clearly scoped, with named responsibilities, two squads and defined adoption metrics (RR3, positive). Pay is absent from the pasted text (RR1), and the employer could not be verified (RR2).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** `conditional_go` holds if (1) you can name a product decision you actually made (R1, R2); (2) your agile delivery practice is confirmed (R4b); (3) the posting verifies on Quartzline's own careers page (RR2). A confirmed triage tool would move R5 off `unclear`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` JD header; existence unverified (RR2) |
| Mandate | Own the roadmap for a partner-facing API platform | `[grounded]` JD |
| Team | Two engineering squads; partner discovery; launches with sales and support | `[grounded]` JD |
| Outcomes | Adoption metrics defined and tracked; no target stated | `[grounded]` JD |
| Pay | Not in the pasted text | RR1 |
| Scope read | Platform PM plus two squads is a normal-sized remit for this title | `[inferred]` from the JD's own scope against its squad count |
| Market calibration | Not run; the search that would have set seniority norms was refused | — |
| Contradictions | None visible in the pasted text | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years PM experience | must_have | adjacent | medium | transferability | 7 years of implementation and solutions work; no PM title | `[grounded]` CV | Bridge case with its limit named |
| R2 | Owns roadmap for partner API platform | must_have | adjacent | medium | transferability | Ran roadmap-input sessions. That is input-gathering, not deciding what gets built | `[grounded]` CV | Q2 |
| R3 | Discovery with integration partners | must_have | adjacent | medium | transferability | Scoping workshops and requirements docs are discovery in substance, but run per client build, not per product | `[grounded]` CV; equivalence `[inferred]` | Bridge; name the per-client limit |
| R4a | Writes specs for product delivery | must_have | adjacent | medium | transferability | Requirements docs for 30+ integrations; no product-squad specs shown | `[grounded]` CV | A sanitized requirements doc would raise this |
| R4b | Drives delivery with engineering, agile practice | must_have | unclear | low | discovery | Coordinated engineers on custom builds; CV silent on sprints, backlog or ceremonies | `[grounded]` CV silence | Q3 |
| R5 | Defines and tracks adoption metrics | important | unclear | low | discovery | CV silent. A triage-tool lead from memory is unconfirmed and cannot count as evidence | `[grounded]` CV silence | Q1 |
| R6 | Coordinates launches with sales and support | important | adjacent | medium | transferability | 30+ go-lives and UAT with client teams; sales and support not mentioned | `[grounded]` CV | Bridge; name the sales/support gap |
| R7 | Shipped API or platform products | must_have | adjacent | medium | transferability | Delivered REST integrations to clients; did not own the platform | `[grounded]` CV | Bridge with limit |
| R8 | Technical fluency: API docs, schemas | must_have | direct | medium | presentation | OpenAPI, Postman, SQL, integration architecture on CV; no artifact shown | `[grounded]` CV; medium, no inspectable proof | Lead with it; a schema review would raise it to high |
| R9 | Stakeholders: engineering, sales, customers | must_have | adjacent | medium | transferability | Coordinated your engineers, client engineers and PMs; sales not evidenced | `[grounded]` CV | Name the sales gap rather than imply it |

## Gap recovery queue

| # | Gap (req) | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Product ownership (R1, R2, R7) | transferability | Strong delivery and input work; no decision you made as owner | One product decision you owned, with its limit, in a bridge case | `[grounded]` CV |
| G2 | Agile delivery (R4b) | discovery | Engineering coordination, but no agile practice shown | A description of your sprint or backlog practice | `[grounded]` CV silence |
| G3 | Adoption metrics (R5) | discovery | Nothing on CV; triage tool unconfirmed | Details of the tool and how adoption was measured | `[grounded]` CV silence; memory lead, unverified |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | (absent from pasted text) | Pay may sit below the usual band, or may simply not be published | `[inferred]` from the pasted text's silence | What is the base salary range for this role? | unresolved |
| RR2 | Employer not established | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Unverified, not failed: the search was refused, so the employer was never tested | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Scope and outcomes defined | positive_signal | — | "define and track adoption metrics" | Success is measurable and the remit is concrete | `[grounded]` JD | Who holds product decision rights, and what is the year-one adoption target? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Quartzline's own careers page before applying | RR2 | `[generic]` pattern | proposed |
| A2 | Pick one product decision you owned as your lead example | G1 | `[grounded]` CV | proposed |
| A3 | Draft the bridge for R1, R3 and R7: adjacent evidence, limit, strengthener | Must-have transferability rows | `[grounded]` map rows | proposed; any wording needs your approval |
| A4 | Send one tailored application, not a batch | Titled-years requirements are often screened literally `[generic]`, so the bridge must sit in the first read | `[generic]` | proposed |

## Evidence status

Verified: none yet. Every CV claim is self-reported. Unverified lead: the request-triage tool from prior memory, which prompts Q1 and is not evidence. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches to check whether Quartzline exists and the posting is live were refused by tool permissions. RR2 stays open |
| 2. Role-family sweep | unavailable | The search for seniority and scope norms was refused. Market calibration is absent, not guessed |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- The live posting link or Quartzline's careers-page URL → RR2 closes or escalates, and target 1 can run.
- Permission for WebSearch in this session → the L1 searches run, giving an employer check and a market band.
- One artifact you own (a roadmap, a PRD, a launch plan, an adoption figure) → R2 and R5 toward `high`.
- Details of the triage tool, if it is real → R5 moves from `unclear` toward `adjacent`.
- Deeper research on Quartzline's funding, leadership and recent news (up to 5 more searches and 2 more fetches) → say the word and it runs.

If you want, I can emit this as a `tuesday-dossier.md` you can keep and append to as answers come in.

1. **Q1 (R5):** Did you build an internal request-triage tool that support agents adopted? If so, what did it do, who decided to build it, and how did you know agents used it?
2. **Q2 (R2):** Name one product decision you actually made, even a small one: what you chose, what you rejected, and who could have overruled you.
3. **Q3 (R4b):** How did you run delivery with engineering on the custom builds (sprints and backlog, or a project plan), and who owned the backlog?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.