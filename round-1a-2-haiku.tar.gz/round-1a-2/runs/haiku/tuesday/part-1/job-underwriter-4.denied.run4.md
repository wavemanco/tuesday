**Yes, apply, with conditions. Status: `conditional_go`.** Your record covers all four must-haves on paper (R2, R3, R4, R5). Two open points could change that: whether you're UK-based and eligible to work here (R1), and whether you designed the price tests or only ran them (R6a). Company checks didn't run, because web search was declined in this session.

**Fit ledger.**

- `hard_gate` — unclear: R1 (fully remote, UK-based)
- `must_have` — direct: R2, R3, R4, R5
- `important` — direct: R6b, R7 · adjacent: R8 (pet-insurance product) · unclear: R6a (design the price tests)
- `preferred` — direct: R9

R1 and R6a could move the status. R8 is a credible motor-to-pet bridge, with its limit named.

**Opportunity ledger.** The posting reads as a real analytics role with a named pricing director as hiring manager (RR4). Pay is withheld (RR3), authority over price changes is unstated (RR1), and nothing has checked the posting against Brindlemoor's own site (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you're UK-based and can work here without sponsorship (R1); (2) you find the live posting on Brindlemoor's careers page (RR2); (3) you know whether you designed the price tests (R6a).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | A senior individual-contributor analytics role; nothing asks for line management | `[inferred]` from the verbs and the silence on reports |
| Market calibration | Not established; the sweep was declined, so no pay or scope band | — |
| Unknowns | Pay, price-change authority, line management, your location | — |
| Contradictions | None within the pasted posting | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based (location and right to work) | hard_gate | unclear | none | hard_gate | The term is in the JD; your location and eligibility aren't in what you've shared. No constraint given, so confidence is none | `[grounded]` JD; no candidate statement | G3 question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years at a UK motor insurer, last two senior. Self-report, not yet inspected, so medium | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use; self-report | `[grounded]` your statement | A query sample would raise it (upgrade menu) |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model for the young-driver book. Motor, not pet; the technique carries over | `[grounded]` your statement | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R6a | Design price tests | important | unclear | low | discovery | You ran 14 tests. You didn't say whether you designed them, so design isn't established | `[grounded]` absence of a design claim | G1 question |
| R6b | Run and read price tests | important | direct | medium | none | 14 tests run with underwriting last year; reading results is implied by running them | `[grounded]` your statement; `[inferred]` that running includes reading | none |
| R7 | Build and monitor rating models | important | direct | medium | none | Built and maintained the young-driver GLM. "Monitor" isn't stated separately; maintenance is the nearest evidence | `[grounded]` your statement; `[inferred]` that maintenance covers monitoring | Monitoring example would raise it |
| R8 | Pet-insurance product knowledge | important | adjacent | medium | transferability | Motor rating, testing and GLM work carry over. Pet-specific drivers (breed, age, vet-cost trends, lifetime vs annual cover) aren't in your history | `[inferred]` from the JD's product line against your motor work | G2 |
| R9 | Insurance experience | preferred | direct | medium | none | UK motor insurer, five years | `[grounded]` your statement | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | Design price tests (R6a) | discovery | Running 14 tests is established; designing them isn't | It's the difference between "ran" and "owned," and the posting asks for design | An account of one test: who chose the hypothesis, segments and read-out | `[grounded]` R6a |
| G2 | Pet-insurance knowledge (R8) | transferability | Motor pricing carries over; no pet work | Likely the first objection | Any pet, companion-animal or vet-cost work, even a side project. Otherwise, a plan for learning pet risk drivers, stated as a limit | `[inferred]` bridge from motor work; `[generic]` that this is the likely objection |
| G3 | Location and eligibility (R1) | hard_gate | Not established | A gate; wording can't solve it | Confirm you're UK-based and can work here without sponsorship | `[grounded]` JD term |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Price-change authority not stated | unknown | — | "turn the results into recommendations for underwriting and product" | This role may recommend rate changes while underwriting or product decide them | `[inferred]` from the recommendations language against its silence on decision rights | Does this role decide rate changes, or recommend them to underwriting and product? | unresolved |
| RR2 | Posting not verified on the employer's own site | risk_signal | low | "Senior Pricing Analyst — Brindlemoor (insurtech)" | The posting may be stale, reposted or aggregated. Not checked here | `[generic]` pattern for postings pasted without a link; not a claim about Brindlemoor | Where is the live version of this role on your careers site? | unresolved |
| RR3 | Pay withheld | unknown | — | No salary in the posting | The budget may sit below your band, or pay is simply unpublished | `[grounded]` posting silent on pay; no band calibrated | What is the budgeted salary band for this role? | unresolved |
| RR4 | Hiring manager named, with a clear remit | positive_signal | — | "Hiring manager: Odile Varga, Director of Pricing" | A pricing director owns the role, which suggests a clear reporting line | `[grounded]` JD; her public footprint was not checked | What would success look like for this role at six months? | noted |
| RR5 | Line management not addressed | unknown | — | Silence on reports, against "Senior" | You haven't managed people; the posting doesn't say whether this role does | `[inferred]` from the JD's silence | Is this role expected to line-manage anyone, now or within a year? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm your UK base and right to work before you apply | R1 is a gate and unconfirmed | `[grounded]` R1 | proposed |
| P2 | Find the live posting on Brindlemoor's careers page and use that link | RR2 | `[generic]` pattern | proposed |
| P3 | Describe each price test in one line: what you decided, what you ran, what you read out. Claim design only if you did it | R6a, R6b | `[grounded]` R6 rows | pending your approval (wording) |
| P4 | Lead with GLM and the underwriting presentation. Name pet as the limit: "motor pricing, new to pet," not "pet experience" | R4, R5, R8 | `[grounded]` R4, R5; `[inferred]` R8 | pending your approval (wording) |

## Evidence status

Verified: none yet. Every claim so far is your own statement, not yet inspected.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search for Brindlemoor's careers page was refused. Would have checked that the employer exists as described and that the posting is live (RR2) |
| 2. Role-family sweep | unavailable | Search for pay and scope for this title was refused. Would have set the market calibration and the RR3 comparison |
| 3. Hiring manager's public footprint | unavailable | The name was given, so the query could be formed; the search was refused. Would have informed RR4 and how you position the application |

Market calibration is not established, so RR3 stays open.

I can write this up as a `tuesday-dossier.md` you can keep and reuse for interview prep, if that's useful.

**Upgrade menu**

- The live posting link, or the careers page listing → confirms the employer and posting, closing RR2.
- Confirmation of location and right to work → closes R1, the hard gate.
- One price test you designed, in a few lines → moves R6a toward direct.
- A sanitised model summary, a test read-out slide, or a sample query → raises R2–R7 from `medium` toward `high`, since they become inspectable.
- The budgeted salary band, from the posting or the recruiter → closes RR3.
- Any pet, companion-animal or vet-cost work, even a side project → raises R8.
- Web search allowed → runs the three L1 checks above: the careers page, the pay and scope sweep, and Odile Varga's public professional footprint.

**Questions**

G1 — On the 14 price tests: did you choose the hypotheses, segments and read-out, or did someone else design them and you ran them? Describe one test.

G3 — Are you based in the UK and eligible to work here without sponsorship?

Do you have the link to the posting on Brindlemoor's own careers page?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.