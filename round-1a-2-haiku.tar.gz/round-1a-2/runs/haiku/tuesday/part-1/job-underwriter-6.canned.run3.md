**Should you go for it? Yes, with conditions.** Status: `conditional_go`. You clear the core of the role, and the real risk is the forecast. Two hard gates (Bristol attendance and salary) are unchecked because you haven't given me your location or pay floor.

- **Hard gates:** none failed; unconfirmed: R9 (Bristol, two days a week in the office), R10 (salary £61,500–£67,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software Bristol careers": quillfield.co.uk/about confirms the company exists (Bristol, invoicing and payments for UK builders' merchants, 96 staff, Series A April 2025). Searched "Quillfield Revenue Operations Lead job": no result, so the role is not established on the open web. Careers page not fetched. Moved RR4. |
| 2. Role-family sweep | yes | Searched "revenue operations manager salary UK B2B software 2026": Ledgerline 2026 UK Revenue Operations Pay Guide (n=438), median £64,200, IQR £57,800–£70,400. Moved role reality's market calibration and R10. |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield": a LinkedIn profile snippet (linkedin.example/in/tamsin-achebe) lists Tamsin as Head of Revenue Operations at Quillfield. The snippet was not opened. Moved RR5. |

**Fit ledger**

- `hard_gate` — unclear: R9 (Bristol, two days in the office), R10 (salary £61,500–£67,000)
- `must_have` — direct: R2 (HubSpot or Salesforce administration), R3 (SQL and spreadsheet modelling); adjacent: R1 (4+ years at a B2B software company), R5 (finance work on billing or revenue data); absent: R4 (owning the forecast)
- `important` — direct: R6 (pipeline and renewal reporting)

R4 is the one must-have with nothing behind it; R5 is a bridge to test; R1 is a years match with the software qualifier to frame honestly.

**Opportunity ledger.** The posting is concrete: the scope, hybrid pattern and salary are stated, and the employer is real. The unknowns are how the forecast is split with the CFO (RR1) and what "own billing data" means in practice (RR2). The hiring manager appears to run revenue operations already, so the role's place in her team is open (RR5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield, Bristol; invoicing and payments software for UK builders' merchants; 96 staff; Series A April 2025 | `[grounded]` quillfield.co.uk/about (search snippet) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in Bristol | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options (options unvalued) | `[grounded]` posting |
| Market calibration | The posted range sits around the UK B2B software median of £64,200 (IQR £57,800–£70,400) | `[generic]` Ledgerline 2026 pay guide, one search, this month; never this employer's offer |
| Unknowns | Forecast authority versus the CFO; billing-data ownership; whether the role is live on the careers page; the role's reporting line | — |
| Contradictions | None between the posting and the company's About page | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years in RevOps, sales ops or analytics at a B2B software company | must_have | adjacent | medium | transferability | Five years in sales operations, two in RevOps, at a B2B payments company. The years match; "software" is not in the record | `[grounded]` your intake; the software qualifier is `[inferred]` from the posting | Frame as B2B payments; never describe it as software |
| R2 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; certificate not yet inspected | `[grounded]` your intake | Attach the certificate if asked |
| R3 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily; "modelling" beyond reporting is not described | `[grounded]` your intake | none |
| R4 | Experience owning a forecast | must_have | absent | medium | transferability | You have never owned the company forecast; finance did. Adjacent: you run the monthly pipeline review with the sales director | `[grounded]` your intake; the adjacency is `[inferred]` | G1 (Q2) |
| R5 | Experience working with finance on billing or revenue data | must_have | adjacent | medium | transferability | Renewal and pipeline reporting touches revenue data; you have never worked on billing data | `[grounded]` your intake | G2 (Q3) |
| R6 | Build pipeline and renewal reporting | important | direct | medium | none | Rebuilt the pipeline and renewal dashboards | `[grounded]` your intake | none |
| R9 | Bristol, two days a week in the office | hard_gate | unclear | none | hard_gate | Your location is not given | `[grounded]` posting | Q1 |
| R10 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | Your pay floor is not given; the band is around the median | `[grounded]` posting | Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R4, must_have) | transferability | Never owned it; you feed pipeline inputs into the monthly review | The posting makes it a core duty, and it is the most likely objection | Any forecast work: pipeline-to-forecast reconciliation, a sign-off you gave, a forecast-accuracy review | `[inferred]` that it is the main objection; `[grounded]` intake |
| G2 | Billing data (R5, must_have) | transferability | Revenue reporting, no billing data | The role says "own our billing data" | Any billing or invoice-level reporting, or a finance reconciliation you ran | `[grounded]` intake |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast authority unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may own the model while the CFO signs it off, or the reverse | `[inferred]` from the posting's wording | Which parts of the quarterly forecast does this role own, and which does the CFO sign off? | unresolved |
| RR2 | Billing data ownership unclear | unknown | — | "own our CRM and billing data" | "Own" may mean reporting access, not accountability for the billing system | `[inferred]` from the posting's wording | Who is accountable today for the accuracy of billing data, and who in finance would I work with? | unresolved |
| RR3 | Share options unvalued | unknown | — | "plus share options" | The total package may be less than the salary suggests, or more | `[inferred]` from the posting's silence on terms | What is the option grant, the strike price and the vesting schedule? | unresolved |
| RR4 | Role not visible on the company's careers page | unknown | — | "Revenue Operations Lead, Quillfield" (aggregator listing) | The listing may be stale, or the company may advertise it elsewhere | `[inferred]` from a single search returning no role result; the company itself is established | Is this role live on quillfield.co.uk, and is it the same role the recruiter described? | unresolved |
| RR5 | Reporting line and scope overlap | unknown | — | Hiring manager's public title: Head of Revenue Operations | This may be a second RevOps lead under her, or a broader remit | `[inferred]` from a profile snippet, not opened | How does this role split with yours as Head of Revenue Operations? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the pipeline review and renewal dashboards, and describe the forecast gap as pipeline input work | R4, R6 | `[grounded]` intake | pending your approval |
| A1 | Ask the recruiter to confirm the role is live on the careers page and the forecast split | RR1, RR4 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Every claim above is intake self-report.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

(The target table above is the accounting for this tier.)

## Upgrade menu

- Your Bristol commute and pay floor → R9 and R10 close, and the decision is final.
- Any forecast work, such as a reconciliation or sign-off → R4 moves from `absent` to `adjacent`.
- Any billing or invoice-level reporting → R5 moves toward `direct`.
- Your Salesforce certificate → R2 moves to `high`.
- The role's page on quillfield.co.uk → RR4 closes.
- Opening the hiring manager's full public profile → RR5 and E1's framing for her.

## Questions

Q1 (R9, R10): Can you work in Bristol two days a week, and is £61,500–£67,000 above your floor? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q2 (G1, R4): Have you ever done anything forecast-related, such as reconciling pipeline to actuals, reviewing forecast accuracy, or signing off a number? What did you own, and who was involved? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q3 (G2, R5): Have you ever worked with finance on invoices, billing exports or a revenue reconciliation, even at pipeline level? What did you own? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

If you want this kept for later, I can save it as a `tuesday-dossier.md`, which would also carry the interview-prep handoff.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.