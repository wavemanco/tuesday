## Decision snapshot

**Not worth pursuing on these terms: R1 and R2, both hard gates, fail. Status: `no_go`.**

- **Fit ledger.**
  - `hard_gate` — hard_gate_fail: R1 (base salary at or above $150k), R2 (on-site five days, Austin)
  - `must_have` — direct: R3, R4, R5, R6
  - `important` — unclear: R7 (SEO/content), R8 (brand, PR), R9 (partnerships), R10 (sales ops)
  - `preferred` — adjacent: R11 (e-commerce enablement)

  R3, R4, R5 and R6 are your stated experience; R7, R8, R9 and R10 are silent in what you gave me; R11 is consumer subscription work, not e-commerce enablement; R1 and R2 are gates, not fit.

- **Opportunity ledger.** RR1 and RR2 restate the two failed gates against the posting's own terms. RR3 (always-on hours) and RR4 (one-person mandate with undefined success) are risk signals. RR5 (employer not established) is unresolved because my searches were refused. RR6 runs the other way: the reporting line and channel scope are explicit.

- **Hard gates:** failed: R1 (base salary at or above $150k), R2 (on-site five days, Austin).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** both gates would have to be different facts. The posting's base is $70–85k, so even the top of the range is $65k under your floor, and equity doesn't count toward base. It also says on-site "no exceptions." Neither is a wording problem.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` your summary; not verified (see RR5) |
| Mandate | Own all revenue growth across paid, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` posting |
| Reporting | CEO, dotted line to the board | `[grounded]` posting |
| Working pattern | On-site, Austin, five days a week, "no exceptions" | `[grounded]` posting |
| Compensation | $70–85k base plus equity | `[grounded]` posting |
| Scope read | One person with no team at launch, covering every revenue channel at once | `[inferred]` from "team of one to start" against the channel list |
| Market calibration | Not established. The salary search was refused, so there is no band here | — |
| Unknowns | Whether Novaline exists as described; what the equity is worth; what "evenings and weekends" means in practice; what success is measured against | — |
| Contradictions | None inside the posting. "Profitable since day one" comes from your summary, not the posting | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base salary at or above $150k (your constraint) | hard_gate | hard_gate_fail | high | hard_gate | Your own stated floor, specific and firm. The posting's $70–85k base is below it at every point in the range | `[grounded]` your constraint; posting figure | Surfaced in the snapshot; no workaround resolves it |
| R2 | Remote-only, living in Portland (your constraint) | hard_gate | hard_gate_fail | high | hard_gate | Your own stated constraint. The posting requires on-site Austin five days, "no exceptions" | `[grounded]` your constraint; posting | Surfaced in the snapshot |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then Head of Growth at two companies. Prose self-report, no inspectable artifact yet | `[grounded]` your intake prose | none |
| R4 | Paid acquisition ownership | must_have | direct | medium | none | You owned paid at two B2C subscription companies. Prose self-report | `[grounded]` your intake prose | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle; deep in Braze. Prose self-report | `[grounded]` your intake prose | none |
| R6 | End-to-end revenue ownership, with budget | must_have | direct | medium | none | Scaled one company from $8M to $40M ARR over three years with a budget you controlled. Strongest claim in your intake, still unverified | `[grounded]` your intake prose | none |
| R7 | SEO/content | important | unclear | low | discovery | Not mentioned in your intake | `[inferred]` from the posting's list | Recall question in the upgrade menu |
| R8 | Brand and PR | important | unclear | low | discovery | Not mentioned in your intake | `[inferred]` from the posting's list | Recall question in the upgrade menu |
| R9 | Partnerships | important | unclear | low | discovery | Not mentioned in your intake | `[inferred]` from the posting's list | Recall question in the upgrade menu |
| R10 | Sales ops | important | unclear | low | discovery | Not mentioned in your intake | `[inferred]` from the posting's list | Recall question in the upgrade menu |
| R11 | E-commerce enablement domain | preferred | adjacent | medium | transferability | Consumer subscription growth carries over. Enablement tooling for merchants is a different buyer and product | `[inferred]` adjacency from your B2C work | Bridge case in G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content, brand and PR, partnerships, sales ops (R7, R8, R9, R10) | discovery | Your intake covers paid, lifecycle and revenue growth. It is silent on the other four channels | Four of the posting's channels are unaddressed. This would not change the decision, because the gates already fail | Content or organic programs you ran, PR or partner launches, sales-to-subscription handoffs | A channel plan, a dashboard, or a launch brief from any of those | `[grounded]` intake silence; `[inferred]` that the posting's list is what the role weights |
| G2 | E-commerce enablement domain (R11) | transferability | Consumer subscription growth, with no merchant-facing or B2B tooling work | Limit: you have not sold to or built for merchants. Strengthener: a case showing work with a retail or brand customer | Any work where your growth program served a merchant or partner, not only end consumers | A merchant-facing case study or launch note | `[inferred]` bridge from your B2C work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay below your floor | red_flag | high | "Compensation: $70–85k base plus meaningful equity upside" | The top of the stated base is $65k under your floor. Equity does not meet a base-salary floor | `[grounded]` posting figure against your stated floor | "What is the total base salary for this role, and is the range open to a candidate at this scope?" | confirmed |
| RR2 | On-site, five days, no exceptions | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The posting forecloses the remote-only arrangement you need | `[grounded]` posting against your constraint | "Is any remote or hybrid arrangement available for this role, given the posting says no exceptions?" | confirmed |
| RR3 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Hours may run past the stated schedule as a matter of course | `[inferred]` from the posting's wording; pattern `[generic]` for startups that write it this way | "What does a typical week look like, and how often do evenings and weekends come up?" | unresolved |
| RR4 | One-person mandate, undefined success | risk_signal | medium | "team of one to start"; "success metrics will evolve as we learn" | Accountability for every revenue channel may come with no team and no agreed measure of success | `[inferred]` from scope against silence on resources; pattern `[generic]` | "What revenue target and budget will this role own in year one, and what team is committed?" | unresolved |
| RR5 | Employer not established | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | Could not be checked, because the searches were refused. `[generic]` pattern for companies of this size, not a claim about this one | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at this role on Novaline's own careers site, and who would I be interviewing with?" | unresolved |
| RR6 | Explicit reporting line and scope | positive_signal | — | "Report to the CEO with a dotted line to the board" | Scope and reporting are concrete, which is more than most postings give | `[grounded]` posting | "Which channels does the CEO expect this role to own first?" | noted |

RR5 still caps the decision at `conditional_go`, but the gates already put it below that, so it does not lift the `no_go`.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply on the posted terms | R1 and R2 fail; the posting says "no exceptions" on location | `[grounded]` R1, R2, RR2 | your decision |
| A2 | If you want to look at this anyway, verify Novaline on its own careers site before spending any effort | RR5 is unresolved | `[generic]` pattern for employers of this size | your decision |

## Evidence status

Verified: R1, R2 (your own constraints, `high`); R3, R4, R5, R6 (your stated experience, `medium`; prose self-report, so expect a probe). Verified is about the claim, not the fit: R3 to R6 are direct, but the gates still decide the status.

Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches on Novaline were refused by permission, so nothing returned. They would have checked that the company exists as described and that the posting is live. That is RR5 |
| 2. Role-family sweep | unavailable | The salary search was refused. It would have set the market band for the calibration line. It would not change the gate results |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- A working search: verifies Novaline and the posting (RR5). It would not reverse the `no_go`, because the gates are stated in the posting itself.
- The posting's source (a recruiter's message or Novaline's careers page): confirms whether RR1 and RR2 are the final terms.
- A merchant-facing case from your work: R11 moves from `adjacent` toward `direct`.
- Any content, PR, partnership or sales-ops work: R7 to R10 each move off `unclear`.

I can also write this up as a `tuesday-dossier.md` if you want it saved for later; say the word.

No questions this turn: nothing you could answer would change the `no_go`.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.