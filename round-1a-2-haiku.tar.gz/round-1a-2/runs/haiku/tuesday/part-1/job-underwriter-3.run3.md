**No, not as posted.** The role fails both of your hard constraints: its base is $70–85k against your $150k floor (R1), and it is on-site in Austin five days a week against your remote-only requirement (R2). Status: `no_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (Compensation: $70–85k base), R2 (On-site in Austin, 5 days a week)
- `must_have` — direct: R3, R4, R5, R6 · unclear: R7 (Must thrive on ambiguity)
- `important` — unclear: R8 (SEO/content), R9 (Brand), R10 (PR), R11 (Partnerships), R12 (Sales ops)

R1 and R2 — the posting's terms against your two constraints; R3–R6 — your career claims, direct but self-reported; R7 — the team-of-one setting, not yet evidenced; R8–R12 — functions your intake doesn't mention.

**Opportunity ledger.** The posting's terms conflict with both of your constraints (RR1, RR2). Its team-of-one scope, always-on wording and unstated success measures are risk signals (RR3, RR4, RR5), and equity, employer and funding status are unverified (RR6, RR7). The CEO reporting line with a board dotted line is the one positive signal (RR8).

- **Hard gates:** failed: R1 (Compensation: $70–85k base), R2 (On-site in Austin, 5 days a week). Other constraints (work authorization, schedule) not given — checks against them unknown.
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** As posted, nothing short of a change in terms. R1 and R2 would both have to change, a base at or above $150k and a remote arrangement, and only the employer can change them. Even then, the employer and stage (RR7) would need checking before any application effort.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting's own claims; not checked (search refused) |
| Reporting | CEO, with a dotted line to the board | `[grounded]` JD |
| Mandate | Own all revenue growth end to end across seven named areas | `[grounded]` JD |
| Starting team | "A team of one to start" | `[grounded]` JD |
| Working pattern | On-site Austin, 5 days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` JD |
| Stated pay | $70–85k base plus "meaningful equity upside" | `[grounded]` JD |
| Pay against your floor | $65k–$80k below your $150k minimum | `[grounded]` JD figure against your stated floor |
| Market calibration | Not run: the role-family search was refused, so no market band is stated | — |
| Unknowns | Contract type, spending authority, budget for the seven areas, success measures, equity terms, funding round | — |
| Contradictions | "8+ years required" and "team of one, no bench" sit beside a $70–85k base | `[inferred]` read from the JD's own lines |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Compensation: $70–85k base plus equity | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your $150k floor, your own specific statement. The posted base sits $65k–$80k below it; not a near miss | `[grounded]` JD; your intake | Surface in snapshot; only a base change resolves it |
| R2 | On-site in Austin, 5 days a week | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your remote-only, Portland, not-relocating statement. Posting says "no exceptions" and offers no remote option | `[grounded]` JD; your intake | Surface in snapshot; only a change to remote resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years in growth, Head-of-Growth titles at two B2C subscription companies. Self-reported, no artifact | `[grounded]` your intake | none |
| R4 | Own all revenue growth end to end | must_have | direct | medium | none | Scaled one company from $8M to $40M ARR over three years, with a budget you controlled. Self-reported; the end-to-end scope is not claimed for sales ops (see R12) | `[grounded]` your intake | Upgrade menu: an ARR summary would raise to `high` |
| R5 | Paid acquisition | must_have | direct | medium | none | Owned paid. Companies and spend levels not stated | `[grounded]` your intake | none |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle; Braze named as a tool | `[grounded]` your intake | none |
| R7 | Must thrive on ambiguity, as a team of one | must_have | unclear | low | discovery | Your record is building and managing teams of 3–7 and scaling a company. Nothing shows solo work without defined targets | `[inferred]` from your team-size history against the JD's "team of one" | Recall question G1 |
| R8 | SEO/content | important | unclear | none | discovery | Not mentioned in intake; may exist | `[grounded]` absence from intake | Recall question G2 |
| R9 | Brand | important | unclear | none | discovery | Not mentioned in intake | `[grounded]` absence from intake | Recall question G3 |
| R10 | PR | important | unclear | none | discovery | Not mentioned in intake | `[grounded]` absence from intake | Recall question G3 |
| R11 | Partnerships | important | unclear | none | discovery | Not mentioned in intake | `[grounded]` absence from intake | Recall question G3 |
| R12 | Sales ops | important | unclear | none | discovery | SQL, GA4 and Braze are data-side skills; no pipeline or sales-tool work named | `[grounded]` your intake | Recall question G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Team-of-one ambiguity (R7, must_have) | discovery | Team leadership and scaling; no solo or undefined-target work named | A must-have, but it cannot move the decision while R1 and R2 fail | Launching a channel or function with no team or targets; setting your own 90-day plan | A plan or retro you wrote for a launch | `[inferred]` from your history against the JD |
| G2 | SEO/content (R8, important) | discovery | Not mentioned | Part of the seven-area mandate | Any organic channel you owned, even partly | A traffic report or content calendar | `[grounded]` absence from intake |
| G3 | Brand, PR, partnerships (R9–R11, important) | discovery | Not mentioned | Three of the seven areas, all absent from intake | Launches, press, co-marketing deals | A press list or partner deal summary | `[grounded]` absence from intake |
| G4 | Sales ops (R12, important) | discovery | Data tools named; no pipeline or sales tooling | The mandate includes it end to end | CRM admin, pipeline reporting, sales-to-growth handoffs | A pipeline dashboard or CRM report | `[grounded]` intake tool list |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Remote-only conflicts with a no-exceptions on-site mandate | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The role is incompatible with a stated non-negotiable, whatever the market | `[grounded]` JD against your stated constraint | Is any remote or hybrid arrangement possible for this role, now or later? | confirmed |
| RR2 | Base sits below the floor | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted pay is incompatible with your $150k minimum | `[grounded]` JD against your stated floor | Is $70–85k the approved budget for this role, and is there any higher band? | confirmed |
| RR3 | Team of one accountable for seven functions | risk_signal | medium | "You will be a team of one to start … paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | The role may be accountable for areas with no team or budget yet | `[inferred]` from the JD's list against its "team of one" line | Which of these seven areas already have budget and people, and which would this hire build? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work may be routine, not occasional | `[inferred]` from the posting's wording; frequency unknown | In the last quarter, how many evenings or weekends did this role's holder work, and why? | unresolved |
| RR5 | Demanding mandate, undefined success | risk_signal | medium | "success metrics will evolve as we learn" | Accountability may come without agreed targets | `[generic]` pattern for demanding mandates with stated-to-evolve metrics, not a claim about this employer | What two numbers is this role judged on in year one, and what are the targets? | unresolved |
| RR6 | Equity unquantified | unknown | — | "meaningful equity upside" | Equity may be small or conditional | `[grounded]` JD wording | What is the grant as a share of fully diluted equity, with strike price and vesting? | unresolved |
| RR7 | Employer and stage unverified | unknown | — | "Novaline (… Series A, profitable since day one)" | The company, its stage and its profitability are unconfirmed | `[grounded]` posting claims; search refused, so nothing checked | Can you point me to this role on your own careers page, and what round did you close, and when? | unresolved |
| RR8 | CEO reporting line with board visibility | positive_signal | — | "Report to the CEO with a dotted line to the board." | Access to decision-makers is clear | `[grounded]` JD | Who holds budget authority for this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't apply to the posting as written | R1 and R2 fail; RR1 and RR2 are confirmed | `[grounded]` R1, R2, RR1, RR2 | Recommendation; no text to approve |
| P2 | Before any application effort, ask the employer for the budgeted base and whether any remote arrangement exists | RR1, RR2 | `[grounded]` register questions | pending your approval |
| P3 | Confirm the role on Novaline's own careers page before spending any time on it | RR7 | `[generic]` pattern for companies this size, not a claim about this one | pending your approval |

## Evidence status

Verified: R1 and R2, your stated constraints, which are specific and stated in your own message. Career claims R3–R6 are unverified intake prose.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search for Novaline was refused by the host (permission not granted), so no result. Would have moved RR7 and whether the posting is live |
| 2. Role-family sweep | unavailable | Search for Head of Growth pay at Series A e-commerce companies was refused. Would have moved the market calibration line and whether $70–85k is low for this seniority (RR2) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I did not retry the refused searches.

Dossier offer: I can save this analysis as `tuesday-dossier.md` if you want a record to keep.

## Upgrade menu

- **Web search allowed for this session** → runs targets 1 and 2: an employer check and a pay-band sweep. The band would show whether $70–85k is low for this seniority.
- **The live posting link, or the role on Novaline's careers page** → RR7 closes or stays open.
- **The budgeted base from the recruiter** → RR2 and R1 get rechecked. Only a figure at or above $150k changes R1.
- **Option grant details** → RR6 closes.
- **An ARR trend or board summary from one of your roles, names redacted** → R4 moves from `medium` to `high`.

**Question**

Q1 — Do you have any other hard constraints I should check against this posting, such as work authorization or a schedule limit? If none, say so, and the checks against them stay unknown.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.