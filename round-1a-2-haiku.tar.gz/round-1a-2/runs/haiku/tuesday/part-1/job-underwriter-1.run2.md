**Yes, apply, with conditions: `conditional_go`.** On substance you fit: your five must-haves (R1, R2, R3, R4, R5) read as direct, though all of it is your own account and not yet checked. The honest gaps are the metric-definition ownership (R6), mentoring (R9), clinician partnership (R8b) and healthcare data (R10), plus an unverified posting and unstated pay (RR1, RR2). Web search was refused this turn, so I couldn't check the posting, the company, or market pay.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.

**Fit ledger.**

- `hard_gate` — none stated
- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — direct: R7 · adjacent: R6 (define and maintain the metrics layer), R8a (partner with product managers) · unclear: R9 (mentor two junior analysts) · absent: R8b (partner with clinicians)
- `preferred` — adjacent: R10 (healthcare data, HIPAA)

Your claims to R6, R8a and R10 are adjacent, not direct, so don't present them as direct. Your direct rows are R1, R2, R3, R4, R5 and R7, each at `medium` confidence. R3 at `medium` is your own account of the 30+ tests and the 11% lift, so expect them to be probed.

Opportunity ledger: RR1 and RR2 are unknowns, RR3 is a set of unstated terms, and RR4 is a positive signal. Conditions for go: RR1 verified (posting live, employer real); RR2 pay confirmed against your floor; R9 answered with what you actually did for analysts; R10 framed as consumer privacy, never as healthcare experience; R8b tested in interviews.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C, care-navigation app | `[grounded]` your JD header; not checked (search refused) |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, mentor two analysts | `[grounded]` JD |
| Scope read | A senior IC role with mentoring; the scope is concrete on paper | `[inferred]` from the responsibility list |
| Market calibration | Not run. No pay band was searched and none is given here | — |
| Unknowns | Pay, location and remote terms, contract type, whether the role is open now, hiring manager, clinician touchpoints | — |
| Contradictions | None visible between JD and your notes | `[grounded]` |

**Evidence map** (confidence is `medium` throughout, since your intake account is CV-equivalent and unprobed)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company, your own account | `[grounded]` your account | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on Snowflake | `[grounded]` your account | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, including a pricing test with an 11% retention lift | `[grounded]` your account; the lift needs its readout | offer: test readout doc |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the Looker instance; 40+ governed dashboards | `[grounded]` your account | none |
| R5 | Strong written communication, non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo read by the exec team; presents to the VP Product | `[grounded]` your account | none |
| R6 | Define and maintain the metrics layer | important | adjacent | medium | transferability | Governed dashboards and a metrics memo show definitions work; ownership of canonical definitions isn't stated | `[inferred]` from governed dashboards | G1 |
| R7 | Build self-serve dashboards | important | direct | medium | none | Built 40+ dashboards and the Looker instance | `[grounded]` your account | none |
| R8a | Partner with product managers on roadmap decisions | important | adjacent | medium | transferability | Exec-facing analysis is close, but PM partnership on roadmap calls isn't stated | `[inferred]` | none; check at interview |
| R8b | Partner with clinicians | important | absent | none | discovery | No clinician contact in your account | `[grounded]` silence | G3 |
| R9 | Mentor two junior analysts | important | unclear | none | discovery | Nothing stated about mentoring | `[grounded]` silence | G2 |
| R10 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model; no PHI and no HIPAA work | `[inferred]` | G4 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | transferability | Governed dashboards and a monthly memo; no statement that you owned canonical metric definitions | This is the responsibility the role opens with | Defining a company-wide metric, settling a disputed definition, a metric dictionary | A metric definitions doc or dictionary page | `[inferred]` bridge from the dashboards; `[generic]` that this is the likeliest probe |
| G2 | Mentoring (R9, important) | discovery | Nothing stated about analysts you coached | An explicit responsibility, and likely to be probed | Onboarding an analyst, reviewing their SQL, pairing on a test readout | Nothing you'd send; a short account is enough | `[grounded]` silence |
| G3 | Clinician partnership (R8b, important) | discovery | No clinician contact in your account | A named partnership, and the least transferable row | Working with ops, care or support staff on an analysis | Any example of a non-product stakeholder you worked with | `[grounded]` silence |
| G4 | Healthcare data (R10, preferred) | transferability | Consumer privacy work, no health data | Preferred, not a gate; the risk is overclaiming | GDPR/CCPA consent modeling, PII handling, retention rules | None needed; frame it honestly | `[inferred]` bridge; no HIPAA claim |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting and employer not verified | unknown | — | "Senior Product Analyst — Harborlight Health" | The posting may be stale or aggregated, or the role may not be open. Web search was refused, so this is unverified, not failed | `[generic]` pattern for unverified postings | Is this role open now, and who is the hiring manager? | unresolved |
| RR2 | Pay not stated | unknown | — | (no compensation in the JD as provided) | Pay may sit below your floor, or the company may withhold it | `[inferred]` from the JD's silence | What is the budgeted base salary for this role? | unresolved |
| RR3 | Location, contract type, work pattern not stated | unknown | — | (not in the JD as provided) | These may conflict with constraints you haven't given | `[inferred]` from the JD's silence | Is this role remote, hybrid or on-site, and is it permanent? | unresolved |
| RR4 | Concrete responsibilities | positive_signal | — | "Own product analytics for our care-navigation app" | The scope is named and specific | `[grounded]` JD | Which decisions does this role make on its own? | noted |

**Application plan** (all proposed, none applied; pending your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the experimentation program and the pricing test, stated as you described it | Strongest direct evidence (R3) | `[grounded]` your account | pending your approval |
| P2 | Describe the Looker work as "built and governed 40+ dashboards" | Keeps the claim to what you did; R6 ownership is unconfirmed | `[grounded]` your account | pending your approval |
| P3 | Describe the privacy work as consumer PII under GDPR/CCPA with a consent model, never as healthcare data | Avoids implying HIPAA experience you don't have | `[grounded]` your account | pending your approval |
| P4 | Ask the recruiter for pay, location and contract type before investing in the loop | RR2, RR3 | `[grounded]` RR2, RR3 | pending your approval |

Reframing audit: P1 to P3 keep your scope, verb and kind; none adds a title, a healthcare claim or a clinician story.

**Evidence status**

Verified: none yet. Every claim above is your own account and not yet probed.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches were refused (web search permission not granted). Would have checked the posting is live, the employer exists, and the stage and size. Moves RR1 |
| 2. Role-family sweep | unavailable | Same refusal. Would have set a market pay band and scope norm. Moves RR2 and market calibration |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

I did not use model memory for company facts or pay.

Dossier offer: I can write this up as a `tuesday-dossier.md` you can keep and reuse across these modules.

**Upgrade menu**

- Allow web search and I'll rerun targets 1 and 2, which would check the posting, the company, and a market pay band (RR1, RR2).
- The posted pay band or the budgeted salary (RR2 closes).
- Your constraints: pay floor, location or remote terms, contract type, start date (RR3 and any gate).
- A metric definitions doc or a test readout, to raise R6 or R3 to `high`.
- The hiring manager's name, to fill target 3 and shape the story for that reader.

Questions:

1. **G2:** Have you mentored or coached analysts? What did you own: hiring, reviews, or informal pairing?
2. **G1:** On your Looker and warehouse, who defined and maintained canonical metric definitions: you, a data team, or product managers?
3. **RR3:** What are your non-negotiables on pay floor, location or remote terms, contract type and start date?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.