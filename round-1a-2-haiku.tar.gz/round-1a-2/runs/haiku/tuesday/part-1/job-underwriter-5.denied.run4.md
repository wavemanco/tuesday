**Worth applying to, on conditions: `conditional_go`.** Your years, stack and data-quality work line up with the requirements, and the pay and seniority sit at market. The open items are the employer facts (I could not check them), equity, your location and pay floor, BigQuery, and two responsibilities your background doesn't reach.

**Decision snapshot**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3 (5+ years data engineering), R4 (Strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (Airflow or similar orchestration), R7 (data quality testing)
- `important`: adjacent: R10 (BigQuery); unclear: R8 (Ingestion from app and CRM), R9 (Data contracts)

R3, R4, R5, R6, R7 are direct, with nothing inspected yet. R10 is a Snowflake-to-BigQuery bridge with its limit named. R8 and R9 are responsibilities the background does not reach.

Opportunity ledger: RR1 (employer facts unverified), RR2 (equity unquantified) and RR3 (no hiring manager named) are unknowns. RR4 (stated pay and bounded scope) is a positive.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1: the posting is confirmed live on Pellucid's own careers page; (2) R1 and R2 are checked against your location and pay floor.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online K-12 tutoring in 31 states; Denver; 264 staff; Series C, $52M, Feb 2026 | `[grounded]` your paste of the about page; not checked, search refused |
| Scope | Reporting pipelines: app and CRM ingestion, dbt warehouse on BigQuery, data contracts for analysts | `[grounded]` posting |
| Seniority | "Senior" at 5+ years; your 6 years meet the bar | `[grounded]` posting; `[generic]` 5–8 years is the usual senior range (supplied report) |
| Pay | $148,000–$166,000 base. Midpoint $157,000 is inside the supplied interquartile range ($139,000–$163,500) and $6,000 above its $151,000 median. The top is $2,500 above the IQR. | `[grounded]` posting and supplied Datawright report (n=2,310, not independently checked); `[generic]` band for Series B–D senior roles, not this employer's offer |
| Equity | "plus equity", with no amount, type or vesting | `[grounded]` posting silence |
| Working pattern | Remote (US) or Denver office | `[grounded]` posting |
| Hiring manager | Not named | `[grounded]` posting silence |
| Unknowns | Equity terms; whether ingestion and contracts are yours to own; direct reports; whether BigQuery is a real requirement or a stack note | — |
| Contradictions | None between the posting and your paste of the company page. BigQuery appears in the description, not the requirements. | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location isn't given | `[grounded]` posting | Q1 |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your floor isn't given; the range sits in the market band | `[grounded]` posting; `[generic]` band | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company; intake prose, not probed | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both; no artifact yet | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Set up and used Airflow | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite | `[grounded]` your background | none |
| R8 | Ingestion from app and CRM | important | unclear | none | discovery | Not in your background | `[inferred]` from the posting's description | G2 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Your GX testing is adjacent; contracts aren't stated | `[inferred]` from your GX work | G2 |
| R10 | BigQuery (named in description only) | important | adjacent | medium | transferability | Snowflake and dbt carry over; no BigQuery work | `[grounded]` your background; `[generic]` that BigQuery's cost and partitioning model differs | G1 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R10, important) | transferability | Snowflake and dbt experience; no BigQuery | The posting names it as the platform; likely a ramp, not a blocker | Any BigQuery exposure, or cost and partition tuning on Snowflake | A small dbt project run on BigQuery | `[grounded]` background; `[generic]` that a ramp is typical |
| G2 | Ingestion and data contracts (R8, R9, important) | discovery | Warehouse and orchestration, not source ingestion or consumer contracts | Two named responsibilities at the centre of the role | Pulls from a product database, CRM API or event stream; schema agreements with downstream teams | A DAG, a contract document, or a schema-change process | `[inferred]` from the posting's description |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer facts and live posting unverified | unknown | — | "Series C ($52M, February 2026)" (your paste) | The posting may not be live, or may be out of date | `[grounded]` your paste; check refused | Is this role open now on your careers page, and who is the hiring manager? | unresolved |
| RR2 | Equity unquantified | unknown | — | "plus equity" | The equity could be small relative to base | `[inferred]` from the posting's silence on grant size | What equity is offered: type, grant size, vesting, and the latest valuation basis? | unresolved |
| RR3 | No hiring manager named | unknown | — | Posting names none | The reporting line and direct reports are unknown | `[generic]` unnamed managers are common in postings | Who would I report to, and does this role have direct reports? | unresolved |
| RR4 | Pay stated, bounded scope | positive_signal | — | "$148,000–$166,000" | Transparent pay and one defined domain | `[grounded]` posting; `[generic]` band basis | — | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Pellucid's careers page before applying | RR1, the first condition for go | `[grounded]` RR1 | pending your approval |
| A2 | Ask RR2 and RR3 at the first contact | Equity and reporting line are unknown | `[grounded]` RR2, RR3 | pending your approval |
| A3 | Proposed positioning: lead with the dbt build on Snowflake and the GX suite; say BigQuery is new to you, and claim no BigQuery work | R5, R7, R10 | `[grounded]` your sentences; no BigQuery claim | pending your approval |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused (no search permission), so nothing was checked. It would confirm the employer, its stage and size, and that the posting is live (RR1). |
| 2. Role-family sweep | skipped | Your supplied pay report already fixes the band and the scope norm in role reality (RR4); a search would not change them. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

The standing "employer not established" entry does not apply. The check did not run, so nothing has been shown to be missing.

**Dossier offer:** I can write this assessment to a `tuesday-dossier.md` to carry into later steps if you want it.

**Upgrade menu**

- Search access: rerun target 1 to verify the employer and posting (RR1).
- A link to the live posting, or its text: RR1 narrows.
- Your location and pay floor: R1 and R2 close.
- Equity details: RR2 closes.
- A sanitized dbt repo or GX suite excerpt: R3–R7 can move to `high`.
- A small BigQuery project: G1 narrows.

1. Are you based in the US, and what base salary is your floor? (R1, R2)
2. Have you built ingestion from a product database or CRM, or agreed a data contract with a downstream team? Which, and what did you own? (G2: R8, R9)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.