**Short answer: yes, worth applying, on two checks you haven't confirmed yet.** Status: `conditional_go`. Your core stack matches almost every requirement. The gaps are BigQuery, which you can frame as a transfer, and two responsibilities you haven't told me about.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

## Decision snapshot

**Status: `conditional_go`.** Apply once two things check out: your location and pay floor against the terms, and whether ingestion and data contracts are part of your history.

**Fit ledger**
- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (salary $148,000–$166,000)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R7 (Airflow or similar), R8 (data quality testing) · adjacent: R6 (dbt-modelled warehouse in BigQuery)
- `important` — unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R6 — a transferable case with its limit named; R9 and R10 — not in your inputs, one question each.

**Opportunity ledger.** The posting is transparent: the salary is stated, the posting is live, and it matches the careers page. The unknowns are team shape, equity terms and the hiring manager (RR1–RR3). No red flags (RR4–RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) R1 and R2 confirmed workable for you; (2) R9 and R10 confirmed as in your history, or the gap accepted; (3) R6 framed as a transfer with its limit stated.
- **What would change this:** a failed R1 or R2 means `no_go` with that gate as the reason, however strong the rest. Confirmed R9/R10 gaps lower the status to `hold`, since those are must-level scope questions.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states, founded 2016, 264 employees, Series C | `[grounded]` company About page, fetched |
| Mandate | Own ingestion, a dbt warehouse in BigQuery, and data contracts for analysts | `[grounded]` JD and careers page, identical text |
| Pay | Posted $148,000–$166,000. Base median for this title at Series B–D is $151,000 (IQR $139,000–$163,500). The posting's midpoint sits in the upper-middle of the band; the top sits above its upper quartile | `[grounded]` posting and pay report; the band comparison is `[generic]` |
| Scope read | One reporting platform with no direct reports stated. The pay report's typical scope for this title is one domain's pipelines, so this reads as a broader, platform-style remit | `[inferred]` from the JD's three-part scope against the report's typical scope |
| Contradictions | None between the JD and the careers page | `[grounded]` fetched page |
| Unknowns | Team size and reporting line, equity amount and vesting, the hiring manager, and whether the Series C claim holds | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location wasn't given, so the gate isn't settled | `[grounded]` JD | Ask whether it's met |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your floor wasn't given. The band is `[grounded]`; comparing it to you is not yet possible | `[grounded]` JD | Ask whether it's workable |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years, stated at intake and not yet probed; no artifact | `[grounded]` your intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated at intake | `[grounded]` your intake | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of ~180 models on Snowflake, stated at intake | `[grounded]` your intake | Offer a sanitized dbt sample to raise to `high` |
| R6 | dbt-modelled warehouse in BigQuery | must_have | adjacent | medium | transferability | dbt-on-Snowflake carries over; you have never used BigQuery. Limit: BigQuery's cost model and partitioning are unexercised | `[inferred]` transfer from R5's claim; the limit is `[grounded]` in your statement | Bridge case (see G1) |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow orchestration, stated at intake | `[grounded]` your intake | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, stated at intake | `[grounded]` your intake | none |
| R9 | Ingestion from our app and CRM | important | unclear | none | discovery | Nothing in your inputs covers app or CRM ingestion | `[grounded]` absence in your inputs | Ask (Q2) |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Nothing in your inputs covers contracts with analysts | `[grounded]` absence in your inputs | Ask (Q2) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, must_have) | transferability | dbt on Snowflake at ~180 models; no BigQuery | The posting names the warehouse, so the objection is likely | Any dbt model design, test or incremental-load work that carried over; any cost-aware query tuning on Snowflake | A sanitized dbt model or README | `[inferred]` transfer; `[generic]` that BigQuery's specifics are what interviewers probe |
| G2 | Ingestion and data contracts (R9, R10, important) | discovery | Neither appears in your inputs | Two responsibilities in the first sentence of the JD | Source-system ingestion from a product app or CRM; agreed schemas or SLAs with downstream consumers | A pipeline diagram or a contract doc | `[grounded]` absence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team and authority not stated | unknown | — | "Build and run the pipelines" | You may own the platform alone, or a team may share it | `[inferred]` from JD silence on team | Who else works on this warehouse, and who signs off data contracts with analysts? | unresolved |
| RR2 | Equity unquantified | unknown | — | "plus equity" | The equity may be material or may be token | `[inferred]` from the JD's silence on amount | What is the equity grant, vesting schedule and strike price? | unresolved |
| RR3 | Hiring manager not named | unknown | — | (no name in the posting) | Routine for this kind of posting; a question, not a risk | `[inferred]` from the JD's silence | Who would I report to? | unresolved |
| RR4 | Salary stated | positive_signal | — | "$148,000–$166,000" | Transparent, and in the band for this seniority | `[grounded]` JD and pay report | Is this range the budgeted band for the level? | noted |
| RR5 | Posting live, consistent | positive_signal | — | Careers page: "Accepting applications" | No stale or aggregated-posting signal | `[grounded]` fetched page | Is this role open to hire now? | noted |
| RR6 | Series C claim self-reported | unknown | — | "Series C ($52M, February 2026)" | The claim comes only from the company's own site; I didn't check a press source | `[inferred]`: L1 targets were the company's own pages | Could you share the Series C announcement? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Describe BigQuery as a transfer, not a skill. Draft line: "Built and maintained a dbt project of about 180 models on Snowflake; have not yet used BigQuery." | Keeps R6 honest and visible | `[grounded]` your intake; the draft cuts nothing you said | pending your approval |
| P2 | Lead with Airflow and Great Expectations for R7 and R8 | Both are direct, and each has a clear story | `[grounded]` your intake | none needed (planning) |
| P3 | Ask RR1–RR3 in the first screen | The register doubles as interview prep | `[grounded]` register | none needed (planning) |

## Evidence status

Verified: none yet. Your intake is CV-equivalent until a question probes it.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched pellucidlearning.com/careers/senior-data-engineer and pellucidlearning.com/about. Both match the pasted text and the posting is live. Confirms the entity as described, from its own site only; no third-party check. |
| 2. Role-family sweep | skipped | The Datawright 2026 pay report you supplied already fixes the band and scope norm (R2, RR4, role reality) |
| 3. Hiring manager's public footprint | n/a | No name was given |

L2 was not run.

## Dossier offer

I can save this analysis as `tuesday-dossier.md` so the prep module can reuse it.

## Upgrade menu

- Your location and pay floor → R1 and R2 close, and the status settles
- Any project showing app or CRM ingestion, or data contracts with analysts → R9 and R10 move from `unclear`
- A sanitized dbt sample, or any GCP work, however small → R5 moves to `high`; R6 narrows
- The equity terms and team size → RR1 and RR2 close
- Deep research on the company (funding, leadership, hiring; up to 5 more searches and 2 more fetches) → verifies RR6. Say the word and it runs.

## Questions

**Q1 (R1, R2):** Are you based in the US, and is $148,000 at the bottom of the range workable for you?

**Q2 (R9, R10):** Have you built ingestion from a product app and a CRM, or owned data contracts with analysts? Examples that may count: a sync job from your product database, a schema agreement with a reporting team, or an SLA on a published table. Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.