**Yes, apply, once the posting is confirmed live.** Status: `conditional_go`. Aoife meets all three of the role's hard gates on her own statements. The main gap is that she has never held a caseload, which the role's own description makes central. The Doppler assessment is desirable, not essential, so its absence doesn't block an application.

**Fit ledger.**

- `hard_gate` — direct: R1, R2, R3
- `must_have` — direct: R4 · unclear: R5 (Clear, timely written records)
- `important` — direct: R6, R8, R10 · adjacent: R7, R11, R12 (Holding own caseload) · unclear: R9, R13, R14
- `preferred` — absent: R15 (Doppler assessment)

R12 — adjacent, limits named; R5 — `unclear`, needs one question; R15 — absent, closure path named.

**Opportunity ledger.** The employer exists as described (RR3 is not a risk). The posting itself is not confirmed live (RR1), and the pay is stated and sits within the market band (RR2, a positive signal).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 — the posting is confirmed open on the employer's own careers page; (2) R12 — the caseload gap is answered honestly in interview; (3) R5 — written-records quality is shown with an example.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing across Calderdale under an NHS contract, founded 2015, 410 staff | `[grounded]` calderbrookhealth.example/about |
| Mandate | Own small caseload of housebound adults; wound, catheter, insulin, end-of-life, care planning, all on the EPR | `[grounded]` posting |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` posting |
| Market calibration | Survey median £34,300, IQR £32,400–£36,600 (n=1,240, England). The posting range spans the IQR | `[generic]` Wardround 2026 guide; `[grounded]` posting figure |
| Unknowns | Posting still open; caseload size and support in first months; pay point for experience | — |
| Contradictions | None found between posting and the employer's About page | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | NMC registration, Adult Nurse | hard_gate | direct | medium | none | Stated registration with number; not yet checked on the NMC register | `[grounded]` CV | Register printout would raise to high |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B stated; pool cars mean it is used daily | `[grounded]` CV | none |
| R3 | Halifax base (location) | hard_gate | direct | medium | none | Lives in Halifax, the posting's base | `[grounded]` CV | none |
| R4 | One year+ post-registration | must_have | direct | medium | none | Five years as staff nurse, stated on the CV | `[grounded]` CV | none |
| R5 | Clear, timely written records | must_have | unclear | low | discovery | CV silent on record quality; no artifact | `[grounded]` CV silence | Ask Q3 |
| R6 | Wound care (pressure, surgical) | important | direct | medium | none | Named on CV, not inspected | `[grounded]` CV | none |
| R7 | Leg-ulcer care | important | adjacent | medium | transferability | Wound care transfers; leg ulcers not on CV | `[inferred]` from R6 | see G3 |
| R8 | Catheter care | important | direct | medium | none | Named on CV | `[grounded]` CV | none |
| R9 | Continence care | important | unclear | low | discovery | Not on CV | `[grounded]` CV silence | Upgrade menu |
| R10 | Insulin administration | important | direct | medium | none | Named on CV | `[grounded]` CV | none |
| R11 | Care planning | important | adjacent | medium | transferability | Discharge planning in home visits | `[inferred]` from CV | Note in application |
| R12 | Holding own caseload | important | adjacent | medium | transferability | Home visits in first week after discharge; no ongoing caseload held | `[grounded]` CV; `[inferred]` bridge | Ask Q1 |
| R13 | End-of-life visits | important | unclear | low | discovery | Not on CV | `[grounded]` CV silence | Ask Q2 |
| R14 | Electronic patient record | important | unclear | low | discovery | EPR not on CV | `[grounded]` CV silence | Ask Q3 |
| R15 | Doppler assessment (desirable) | preferred | absent | none | capability | No evidence on CV | `[grounded]` CV | see G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Holding own caseload (R12, important) | transferability | Home visits in discharge-to-assess; no caseload of her own | Biggest interview objection; the role is built on it | Any case where she planned and reviewed a patient's care across weeks | `[inferred]` bridge; `[generic]` that interviewers probe this |
| G2 | Doppler assessment (R15, preferred) | capability | No Doppler evidence | Desirable only; a named training path closes it | A course, or the employer's own training offer | `[inferred]` from a 2025 forum talk by the team lead on Doppler training for staff new to community work |
| G3 | Leg-ulcer care (R7, important) | transferability | Wound care on the ward, not leg ulcers | Core to the posting's first sentence | Any leg-ulcer dressing or compression work | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Current vacancies are listed on our careers page." | The post may be filled, or the listing may be stale | `[generic]` pattern for listings found through aggregators | Is this Community Staff Nurse post still open on your careers site, and what is the closing date? | unresolved |
| RR2 | Pay stated against market | positive_signal | — | "£31,050–£37,800 a year plus mileage." | Pay spans the survey IQR | `[generic]` survey; `[grounded]` posting | Where on the Band 5 scale would a new starter with five years' experience enter? | noted |
| RR3 | Support for a first caseload | unknown | — | "supported by a senior community nurse" | Support is stated, its level is not | `[grounded]` posting | What caseload size and supervision would a nurse new to caseloads get in the first three months? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on the careers site or the NHS jobs board before applying | RR1 | `[grounded]` RR1 | pending your check |
| A2 | Ask Rhiannon Mabbott about the informal chat, including Doppler training and caseload support | RR3, G2 | `[grounded]` forum profile | pending your approval before any message is sent |
| A3 | Prepare the caseload answer from real discharge-to-assess cases only | G1, R12 | `[grounded]` CV | pending your approval of any wording |

## Evidence status

Verified: R1, R2, R3, R4, R6, R8, R10 claims (CV, stated; none inspected yet). Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health vacancies Community Staff Nurse careers": calderbrookhealth.example/about (NHS-contracted, Calderdale, 410 staff). Fetched calderbrookhealth.example/careers: no page. Moved: employer established as described; posting not confirmed (RR1) |
| 2. Role-family sweep | yes | Searched "Community Staff Nurse Band 5 district nursing salary £31,050 £37,800": Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide). Moved: market calibration; RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead": communitynursingforum.example/speakers/rhiannon-mabbott. Moved: G2 lead. The name was given as the contact; the search does not confirm this person is the hiring manager |

Target 3 is public footprint only. Nothing personal was searched.

## Upgrade menu

- The live posting from the careers site → RR1 closes; `conditional_go` becomes `go`.
- An NMC register printout (no PIN needed in the reply) → R1 to `high`.
- An anonymised care-plan extract or case note → R5 moves; R12 is strengthened.
- Wound, catheter or insulin training certificates → R6, R8, R10 to `high`.
- A deeper pass on Calderbrook (CQC report, staff reviews, leadership changes; up to 5 more searches and 2 more fetches) — say the word and it runs.

Would you like me to save this as `tuesday-dossier.md` so it carries into later sessions?

**Questions** (tagged to their rows; answer in text, paste a voice transcript, attach a document, drop a link, or say skip):

- Q1 (R12) — In your discharge-to-assess visits, did you ever plan and review a patient's care over several weeks, or were patients always handed back to the team after the first visit?
- Q2 (R13) — Have you made end-of-life or palliative home visits, and if so, what did you own in them?
- Q3 (R5, R14) — Which records system did you use on the ward and for home visits, and how did you keep notes timely?

When an interview is booked, mock-interview can prepare the caseload and Doppler questions.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.