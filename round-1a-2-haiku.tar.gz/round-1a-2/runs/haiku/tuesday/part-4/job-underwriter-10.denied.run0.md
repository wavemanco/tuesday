**Take the call, after a check on the company. Status: `conditional_go`.** You can't confirm from here that Fernquay exists as described, because every web search was refused, so the company is unverified rather than found to be fake. Nothing in the posting or the WhatsApp message asks you for money, bank details, or a hiring process run wholly by chat.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (pay, €52,000–€60,000)
- `must_have`: direct: R3 (3+ years product design), R4 (strong Figma), R6 (own user research), R7 (working with engineers) · adjacent: R5 (own the booking flow end to end), R8 (first designer)
- `important`: adjacent: R9 (research calls with school owners)

R5 — the checkout redesign is a bridge, with its limit (end-to-end ownership not yet stated) named; R8 — squad work is the bridge, and never having been the only designer is the limit; R2 — waiting on your pay floor, which you haven't given.

- **Hard gates:** `none failed` (R1 `direct`); unconfirmed: R2 (pay, €52,000–€60,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Opportunity ledger:** Unverified rather than bad. The employer can't be checked from here (RR1), the role has no design peer (RR2), and pay and equity can't be valued yet (RR3). The WhatsApp contact is a verification step, not a warning (RR4). One entry runs the other way (RR5).
- **Conditions for go:** (1) RR1 clears: you find the company's own site yourself and it lists this role and both Ronan Kehoe and Saoirse; (2) the invite's email domain matches that site; (3) R2: the €52,000 base meets your floor.
- **What would change this:** if the company's own site doesn't list the role or the people, stop, and don't share anything beyond scheduling.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Six people in Galway, making booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | First designer: own the booking flow, run research with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Market calibration | Not run. The role-family search was refused, so there is no band to set the salary against | — |
| Contradictions | None found. The WhatsApp message names the same co-founder and CTO as the posting, but nothing was checked independently | `[grounded]` posting and message |
| Unknowns | Funding and runway, equity value and vesting, design budget, who sets product priorities, what "end to end" includes | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two office days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway; willingness to do the office days is not yet stated | `[grounded]` your statement | none |
| R2 | Pay €52,000–€60,000 | hard_gate | unclear | none | hard_gate | No pay floor given, so the check is unknown | `[grounded]` posting | Question 1 |
| R3 | 3+ years product design | must_have | direct | medium | none | Four years at a travel-booking company; self-reported | `[grounded]` your statement | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use, self-reported; no file to inspect | `[grounded]` your statement | Share a checkout file if it's yours to show |
| R5 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout, one stage of a flow; ownership from discovery to launch is not stated | `[grounded]` your statement | Question 2 |
| R6 | Run your own user research | must_have | direct | medium | none | Monthly usability sessions with travel customers | `[grounded]` your statement | none |
| R7 | Work directly with engineers | must_have | direct | medium | none | Squad of four engineers | `[grounded]` your statement | none |
| R8 | First designer (no design peer) | must_have | adjacent | medium | transferability | Squad design work is the bridge; you've never been the only designer, the limit | `[grounded]` posting and your statement | Ask on the call who reviews design (RR2) |
| R9 | Research calls with school owners | important | adjacent | low | transferability | Customer sessions exist, but none with this niche B2B audience | `[grounded]` your statement; audience gap `[inferred]` from the posting | Ask on the call how many owner interviews they've done |

**Gap recovery queue**

- **G1 (R5, transferability):** The bridge is the checkout redesign. The limit is that ownership from discovery to launch isn't stated. What would narrow it is the case study you sent them, with the decisions you made named and the squad's share stated.
- **G2 (R8, transferability):** The bridge is daily work inside a design-and-engineering squad. The limit is sole ownership of design decisions. The closure path is asking, before you accept, how design is reviewed and who you'd take feedback from.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Product Designer — Fernquay" | The company may be too new or small to have a footprint, the posting may be stale, or it may not be a hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at this role on your own careers page, and who would I be interviewing with?" | unresolved |
| RR2 | First designer with no design peer | risk_signal | medium | "You would be our first designer" | You may carry the design function with no senior review | `[inferred]` from a single-designer scope against a two-engineer team and no stated design lead | "Who reviews design decisions here, and what is the design budget for the first six months?" | unresolved |
| RR3 | Pay and equity not fully valued | unknown | — | "€52,000–€60,000 plus 0.5–1% equity" | The equity's worth depends on the share count and vesting, which the posting doesn't state | `[inferred]` from the posting's silence on both | "How many shares are issued, what's the vesting schedule, and is the salary fixed for this role?" | unresolved |
| RR4 | First contact by WhatsApp, invite by email | unknown | — | "I have emailed you a calendar invite with the video link" | Small teams often schedule through whichever channel the founder uses; this is not a sign on its own | `[generic]` pattern for small teams | "Which email address will the invite come from, and will the interview include the CTO?" | unresolved |
| RR5 | Named co-founder and clear preference for real work | positive_signal | — | "we would rather see one messy real project than a polished deck" | Hiring is judged on working evidence, which suits the checkout case study | `[grounded]` posting | "What would a good first six months look like?" | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Find Fernquay's own site and careers page yourself, without using the WhatsApp message's links, and check the role and both names are there | Closes RR1 | `[generic]` verification practice | your call |
| P2 | Check that the invite's email domain matches that site | Closes RR4 | `[generic]` verification practice | your call |
| P3 | Prepare the checkout walkthrough: what you decided, what the squad decided, what you didn't own. Use only what you did, and don't stretch "redesigned" into "owned" | R5, G1 | `[grounded]` your statement | pending your approval |
| P4 | Rehearse the 45-minute call and the RR questions. The mock-interview skill can run that drill | RR1–RR3 | — | your call |

**Evidence status**

Verified: none yet. Your background came in as prose, so the ceiling is `medium` until there's a file to inspect. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Fernquay's site and listing. Both were refused by the session's permission setting, so RR1 and the Contradictions row stay open |
| 2. Role-family sweep | unavailable | One search for Irish product-designer pay and scope. Refused, so R2 and the market calibration have no band |
| 3. Hiring manager's public footprint | unavailable | One search for Ronan Kehoe's public footprint. Refused; a name was given, so the query could be formed |

The search permission was denied in this session. I didn't retry or look for another route to the same pages.

**Upgrade menu**

- Approving web search for this session runs targets 1–3 above. RR1 and RR3 would harden or close, and R2 would get a market band.
- The company's careers-page link, or the invite's email address, would close RR1 and RR4 without any search.
- Your pay floor would resolve R2, and the snapshot would then carry a clean hard-gates line.

If you want this written up as a file, I can produce `tuesday-dossier.md` in a later turn.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. R2: Is €52,000 base at or above the lowest pay you'd accept for this role?
2. G1 / R5: On the checkout redesign, what did you decide yourself, what did the squad decide, and did you own anything from discovery through launch?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.