**Yes, worth applying, with conditions. Status: `conditional_go`.** R1, R2 and R3 (registration, licence, Halifax location) are direct matches. The open items are the clinical areas the advert names that your CV doesn't show (R5b, R6b, R9, R11), the caseload you haven't held (R10), and the employer, which I have not checked.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears: the employer is confirmed as real and the post is funded; (2) R11 and R9 hold up in conversation with the Team Lead (RR3 covers caseload ramp); (3) the caseload is framed as home visiting, never as a caseload you have held (P1).
- **What would change this:** `hold_pending_answers` if RR1 can't be confirmed; `no_go` only if a hard gate turns out not to be met, which nothing so far suggests.

**Research tier: L0 — no searches; user links read 0.** I haven't searched for the employer or the pay band yet. That's your call, and the upgrade menu says what it would add.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, Halifax | `[grounded]` advert |
| Role | Community Staff Nurse, Band 5; district nursing for housebound adults at home; own small caseload with senior community nurse support | `[grounded]` advert |
| Pay | £31,050–£37,800 a year plus mileage | `[grounded]` advert |
| Market calibration | Not run at L0; the pay band is unchecked against role-family norms | — |
| Working pattern | Home visits, pool cars provided, electronic patient record | `[grounded]` advert |
| Scope read | A caseload-holding post on a Band 5 grade, with support named | `[inferred]` from "your own caseload" and "senior community nurse support" |
| Unknowns | Caseload size, support model, pay scale, EPR system, Doppler training, who commissions the service | — |
| Contradictions | None found within the advert; no second source checked | — |

## Evidence map

Confidence is `medium` at most, because nothing from your CV has been inspected or confirmed yet.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | Your CV states it active; the register check is yours | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B stated; the licence itself is yours to check | `[grounded]` CV | none |
| R3 | Work in or near Halifax | hard_gate | direct | medium | none | You live in Halifax; the advert names Halifax | `[grounded]` CV and advert | none |
| R4 | At least one year post-registration | must_have | direct | medium | none | Five years as staff nurse | `[grounded]` CV | none |
| R5a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5b | Leg-ulcer care | must_have | adjacent | low | transferability | Wound work carries over; no leg-ulcer work is stated | `[inferred]` from R5a | G3 |
| R6a | Catheter care | must_have | direct | medium | none | Stated in CV | `[grounded]` CV | none |
| R6b | Continence care | must_have | unclear | none | discovery | CV silent | `[grounded]` CV silence | G1 |
| R7 | Insulin administration | must_have | direct | medium | none | Stated in CV | `[grounded]` CV | none |
| R8 | Care planning | must_have | adjacent | low | transferability | Discharge work implies planning; the CV doesn't say so | `[inferred]` from discharge-team role | G2 |
| R9 | End-of-life visits | must_have | unclear | none | discovery | No mention in CV | `[grounded]` CV silence | G2 |
| R10 | Own small caseload with senior support | important | adjacent | medium | transferability | Home visits to discharged patients; you have never held a caseload | `[grounded]` CV | G5 |
| R11 | Clear, timely written records on EPR | must_have | unclear | none | discovery | CV silent on records and timeliness | `[grounded]` CV silence | G1 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | Never done; desirable only | `[grounded]` CV | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records and continence care (R11, R6b) | discovery | CV is silent on documentation, timeliness and continence | Records are essential in the advert; continence is a named duty | Discharge visit notes; wound or catheter records; any continence assessment or product review | An anonymised visit note with names removed | `[grounded]` CV silence; `[generic]` that records are usually audited in community posts |
| G2 | End-of-life visits and care planning (R9, R8) | discovery | CV is silent on end-of-life and on planning beyond discharge | Both are must-haves in the advert | Palliative referrals; discharge plans for patients going home; family conversations at discharge | A discharge plan or care plan, anonymised | `[grounded]` CV silence |
| G3 | Leg-ulcer care (R5b) | transferability | Wound care is strong; leg ulcers aren't named | Leg-ulcer care is a headline duty | Compression, dressing choice, wound review on the ward or at home | Any leg-ulcer wound record, anonymised | `[inferred]` bridge from R5a |
| G4 | Doppler assessment (R12) | capability | No evidence | Desirable only; closure is training, not experience | Vascular assessment or ABPI-style checks, if any | None needed | `[grounded]` CV; `[generic]` that trusts often train Doppler in post |
| G5 | Own caseload (R10) | transferability | Home visits to discharged patients; no caseload held | The advert offers your own caseload, so this is the biggest change in role | Patient lists on the discharge team; visits you planned and followed up alone | A typical week's visit list, anonymised | `[inferred]` bridge from home-visit work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified | unknown | — | "Calderbrook Community Health CIC, Halifax" | The post may be funded and commissioned in ways the advert doesn't say | `[grounded]` advert omits commissioning; no research run | Who commissions this district nursing service, and how is this post funded? | unresolved |
| RR2 | Pay scale unstated | unknown | — | "Band 5 … £31,050–£37,800 a year plus mileage" | The range may follow a published scale, or it may not | `[generic]` Band 5 is a pay-band label; the scale isn't named | Is this post on the Agenda for Change scale, and what are the increments and mileage rate? | unresolved |
| RR3 | Caseload support model | risk_signal | low | "a small caseload of your own, supported by a senior community nurse" | Your first months may involve visiting patients with limited supervision | `[generic]` community nursing often involves lone visits; `[inferred]` from the wording | How many patients will I hold in my first month, and who covers the caseload when I'm away? | unresolved |
| RR4 | Concrete role details | positive_signal | — | "pool cars are provided" | The advert names vehicles and a named contact, which suggests the role is defined | `[grounded]` advert | Could I speak with the Team Lead before applying? | noted |

**Severe red flags:** none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Describe your first-week discharge visits as home visits to patients, not as a caseload | Keeps R10 at `adjacent` | `[grounded]` CV | pending your approval |
| P2 | Say you have not done Doppler and would want training, rather than implying experience | Keeps R12 honest | `[grounded]` CV | pending your approval |
| P3 | Ask the Team Lead about caseload ramp, senior support, records system and Doppler training | Tests RR1 to RR3 and G1 to G2 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your CV is leads for verification until you confirm specifics.

Research tier: L0 — no searches; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Not run: no research consent yet. Would check RR1 and whether the post is live |
| 2. Role-family sweep | unavailable | Not run: no research consent yet. Would set R-level pay context and RR2 against norms |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Consent to L1 (up to 5 searches and 2 fetches): checks the employer and the pay scale and moves RR1 and RR2. Say the word and it runs.
- One anonymised visit or discharge record → R11 moves toward `high`, and G1 closes.
- Any leg-ulcer record, anonymised → R5b moves toward `direct`.
- Your non-negotiables (pay floor, hours, mileage limits) → hard-gate checks against them become possible.

Would you like a `tuesday-dossier.md` saved for this assessment?

Three questions for you, all answerable in text, by voice transcript, by attached document or by link, or you can say skip:

**G1 (R11):** Can you describe one home visit where you wrote up the record the same day: what system you used, what you recorded, and whether anyone checked it for timeliness?

**G2 (R9, R8):** Have you been involved in end-of-life visits, or in planning a patient's care when they went home? What did you own, and what happened?

**G3 (R5b):** Have you managed leg ulcers, in compression, dressings or wound review, on the ward or on discharge visits? What did you personally do?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.