**Snapshot: `conditional_go`.** Taking the 45-minute call is low-risk and sensible. The fit is strong. I can't establish from here that Fernquay is a real, hiring employer, so verify that before you share anything beyond the call. I couldn't search at all: web search was not granted in this session, so the company check, the pay check and the check on Ronan's public footprint did not run.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (pay €52,000–€60,000 against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Fit:** `must_have` rows are direct, apart from R7 and R8; R9 is adjacent. R7 is the checkout work, which is the closest match to "own the booking flow." R8 is the solo-designer part, and your squad experience is adjacent to it, not direct.
- **Opportunity:** the one open risk that caps the decision is RR1, the employer not being established. RR2 (first-designer scope with no stated design authority) and RR3 (equity terms) are unknowns to ask about. RR5 is about the WhatsApp contact, which is not a warning sign by itself.
- **What would change this:** the conditions for `go` are (1) Fernquay checks out on its own careers page and in the Irish Companies Registration Office (CRO) register, which you can search yourself; (2) the invite and video link come from a Fernquay address; (3) pay and equity terms are in writing before any offer; (4) you answer Q1 below.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting; not checked externally |
| Scope | First designer: own the booking flow end to end, run research with school owners, ship with two engineers | `[grounded]` posting |
| Reporting | Works most closely with co-founder Ronan Kehoe; CTO Saoirse on the next call | `[grounded]` posting and WhatsApp message |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Market calibration | Not established: the pay search was refused | — |
| Unknowns | Design decision rights, research budget, equity class and vesting, runway | — |
| Contradictions | None found within the posting or the message | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days in Galway | hard_gate | direct | medium | none | You moved back to Galway last year. Self-report, so medium | `[grounded]` your statement | none |
| R2 | Pay €52,000–€60,000 against your floor | hard_gate | unclear | medium | hard_gate | Your floor isn't known, so the gate can't be settled | `[grounded]` posting | Q1 |
| R3 | 3+ years product design | must_have | direct | medium | none | Four years at a travel-booking company | `[grounded]` your statement | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use | `[grounded]` your statement | none |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers | `[grounded]` your statement | none |
| R6 | Works directly with engineers | must_have | direct | medium | none | Squad of four engineers | `[grounded]` your statement | none |
| R7 | Owns a booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout, but how much you owned from research to ship is unstated | `[inferred]` from the checkout work | Q2 |
| R8 | Works as first/sole designer (inferred from "first designer") | must_have | adjacent | medium | transferability | Squad work, never the only designer. Limit: no solo design decisions | `[inferred]` from "first designer" against your squad history | Q2 |
| R9 | Runs research calls with school owners | important | adjacent | medium | transferability | Customer usability work, not small-business owners. Limit: a different kind of customer | `[inferred]` from the usability sessions | Q3 |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have a web footprint, the posting may be stale, or it may not be a hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at the role on your own careers site, and who would I be interviewing with?" | unresolved |
| RR2 | Sole-designer scope without stated decision rights | risk_signal | low | "You would be our first designer: own the booking flow end to end" | Design direction and research budget may sit with the co-founder; the role may carry the outcome without owning the direction | `[inferred]` from scope language against silence on authority | "Which product decisions does this role make alone, and what research time and budget are committed?" | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | Without share class, total shares and vesting, the percentage means little | `[inferred]` from the posting's silence | "What class of shares does 0.5–1% represent, how many are in issue, and what vesting applies?" | unresolved |
| RR4 | Pay basis unstated; market check not run | unknown | — | "Salary €52,000–€60,000" | The band may suit the scope or the budget; the posting gives no basis | `[inferred]` from the posting's range | "How was the band set for this role, and does it move with the level of ownership?" | unresolved |
| RR5 | First contact by WhatsApp | unknown | — | "Just shout here if the time does not suit." | Scheduling by chat is common; the open question is whether the invite comes from a Fernquay address | `[grounded]` message text | "Could you confirm the invite came from a Fernquay address and the video link is hosted on it?" | unresolved |
| RR6 | Clear reporting line and technical lead on the first call | positive_signal | — | "You will work most closely with our co-founder, Ronan Kehoe." | Named reporting and a CTO in the process suggest a real team | `[grounded]` posting and message | "Who makes the final hiring decision, and who would I report to day to day?" | noted |

**Application plan** (all proposed; nothing is sent without your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check Fernquay's site, the careers page and the CRO register | Clears RR1 | `[grounded]` RR1 | proposed |
| A2 | Ask Ronan for the live posting link and for the invite to come from a company address | Clears RR1 and RR5 | `[grounded]` RR5 | pending your approval |
| A3 | Share no bank, tax or ID details until a written offer names the role and pay; enter them only in the employer's own portal | Standard caution; nothing has been requested | `[generic]` pattern | proposed |
| A4 | Honest line on the call: "I've worked in a squad of four engineers. I haven't been the only designer." | R8, the gap an interviewer will probe | `[grounded]` your background | pending your approval |

**Evidence status**

Verified: none yet. Your background is still your own statement, so it is medium at most until you give specifics.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Company searches refused (permission not granted). Would have checked whether Fernquay exists, and RR1 |
| 2. Role-family sweep | unavailable | Galway product-designer pay search refused. Would have set the market calibration and RR4 |
| 3. Hiring manager's public footprint | unavailable | Search naming Ronan Kehoe refused. Would have informed how you position with Ronan |

**Upgrade menu**

- Granting web search lets the remaining two L1 searches and two fetches check the company and the pay band. Each one counts against the budget.
- Your pay floor (Q1) closes R2. A non-negotiable stated in writing would also let the snapshot's hard-gates line report on it.
- Any written evidence of the checkout redesign, such as a case study or a launch note, would raise R7 to `high`.
- A written offer naming the role, pay, equity and contract type would close RR3, RR4 and the snapshot's unconfirmed items.

Would you like me to write this up as `tuesday-dossier.md`? I can do it at any point.

**Questions** (you can answer in text, paste a voice transcript, attach a document, drop a link, or say skip)

1. **R2:** What is your lowest acceptable salary, and is €52,000 above it?
2. **R7/R8:** On the checkout redesign, which parts did you own from research through to launch, and was any call yours alone?
3. **R9:** Have you ever interviewed small-business owners, not just your company's customers, about how they run their day-to-day work?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.