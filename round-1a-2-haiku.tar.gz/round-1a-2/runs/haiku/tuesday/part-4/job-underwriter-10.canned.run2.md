## Decision snapshot

**Yes, worth it, and it looks legitimate. You have already applied and been invited to a call, so the next step is the call. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 (hybrid, two days a week in Galway); unclear: R2 (salary €52,000–€60,000)
- `must_have`: direct: R3 (3+ years of product design), R4 (strong Figma), R5 (own user research); adjacent: R7 (own the booking flow end to end); unclear: R9 (first designer, no design peers)
- `important`: direct: R8 (work directly with engineers); adjacent: R6 (research with school owners)

R9 is the question the job turns on. R7 is a checkout redesign standing in for a whole booking flow. R2 is waiting on your pay floor.

**Opportunity ledger.** The employer checks out and the posting matches its careers page and about page (RR5, positive). Still open: the equity terms, the runway and who decides priorities (RR1, RR2, RR3).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) on the call, you can describe design decisions you made with no design peer (R9); (2) the equity terms and runway are stated plainly (RR2, RR3); (3) the salary range works for you (R2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Employer check | Fernquay exists as described: about page (six people, Galway, founded 2023, makes Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland); careers page shows the same role and terms; co-founder Ronan Kehoe's public profile lists him as co-founder and CEO | `[grounded]` fetched about and careers pages; `[grounded]` profile search result |
| Mandate | First designer: own the booking flow, run research with school owners, ship with two engineers | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting and careers page |
| Market calibration | Tillerby 2026 Ireland survey (n=520): product designers with 3–5 years, median €57,000, interquartile range €51,500–€62,000. The posted range sits inside that band | `[generic]` one survey, 2026, not this employer's offer |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` posting |
| Contact channel | Applications go to jobs@fernquay.example. The interview invite is by email and the scheduling by WhatsApp. Nothing asks you to pay, deposit a cheque or give bank details | `[grounded]` careers page and your message. Scheduling by chat is not a warning sign |
| Stage | Applied; invited to a 45-minute video call with Ronan and Saoirse Doyle | `[grounded]` your message |
| Unknowns | Equity terms, runway, decision rights and budget, Saoirse's title | — |
| Contradictions | None between posting, careers page and about page. Your invite calls Saoirse "CTO"; the about page calls Saoirse a co-founder. Compatible, not yet confirmed | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week in the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year. You have not stated a constraint on office days | `[grounded]` your statement | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | Your pay floor was not given, so the check cannot run. The posted range sits inside the market band | `[grounded]` posting; `[generic]` band | Question 2 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer, stated in prose. Medium because no artifact has been inspected | `[grounded]` your statement | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" at your last job | `[grounded]` your statement | none |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers. The audience was travellers, not school owners (see R6) | `[grounded]` your statement | none |
| R6 | Research with school owners | important | adjacent | medium | transferability | The method transfers. The customers differ: small-business owners running schools, not consumers | `[inferred]` from R5 against the posting's audience | Gap G3 |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout, one stage of a booking flow. You have not said you owned search through confirmation | `[grounded]` your statement; `[inferred]` that this is adjacent | Question 3; gap G2 |
| R8 | Work directly with engineers | important | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your statement | none |
| R9 | First designer, no design peers | must_have | unclear | low | discovery | You have never been the only designer. Nothing stated shows you setting design practice or deciding alone | `[grounded]` your statement, silence on solo work | Question 1; gap G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | No design peers (R9, must_have) | discovery | Squad work and a checkout redesign, but no stated case of making design calls alone | This is the job's central condition; if the answer is strong, R9 moves to `direct` | Deciding a flow change with engineers and no reviewer; running a usability round you set up and acted on alone; choosing a research method when nobody else would | A design brief, a usability-round summary, or a decision log you wrote | `[grounded]` silence in your message; `[generic]` that first-design hires are judged on solo judgment |
| G2 | Whole booking flow (R7, must_have) | transferability | Checkout redesign, nothing stated on search, availability or confirmation | Ownership of the whole flow is the posting's first line | Any flow you shaped before checkout; the confirmation or cancellation screens; the handoff points you designed | A sanitized flow map or the checkout case study you sent them | `[inferred]` bridge from checkout to the flow |
| G3 | Research with B2B owners (R6, important) | transferability | Consumer research only, monthly | Research is a named part of the job | Any interview with a non-consumer buyer, even informal | Notes from one call with a small-business user | `[inferred]` method carries over; `[generic]` that B2B research is slower to book |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Ownership stated, decision rights and research budget not | unknown | — | "own the booking flow end to end" | Ownership may be real, but priorities may be set by the founders and paid research may have no budget | `[inferred]` from scope language against silence on budget | Which product priorities does this role decide alone, and what budget is set aside for paid research calls and tools? | unresolved |
| RR2 | Equity terms not stated | unknown | — | "plus 0.5–1% equity" | The value depends on share count, vesting and strike, none of which is given | `[generic]` early equity usually comes with vesting and a strike price | How many shares are in issue, what is the vesting schedule, and what is the strike price of the options? | unresolved |
| RR3 | Runway not stated | unknown | — | "funded by its customers" (about page) | A customer-funded firm can be stable, but the hiring plan depends on runway, which is unpublished | `[inferred]` from the about page against silence on funding | How many months of runway does the company have, and is this hire funded beyond the next year? | unresolved |
| RR4 | Saoirse's title | unknown | low | "Saoirse, our CTO" (invite) vs "Ronan Kehoe and Saoirse Doyle" (about) | Probably the same role described two ways | `[grounded]` both sources | What is your role as CTO, and how much of the product do you own? | unresolved |
| RR5 | Stated bar: one real project, pay and process given | positive_signal | — | "we would rather see one messy real project than a polished deck" | Transparent hiring; the bar is clear | `[grounded]` posting | What would a strong first project look like to you? | noted |

**Severe red flags:** none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Before the call, check the invite came from the fernquay.example address | Applications are routed there on the careers page, so the invite should come from that domain too | `[grounded]` careers page | for you |
| P2 | Send no money, deposit or bank details at any stage of this process | None is asked, and this is the rule to keep | `[grounded]` your message | none |
| P3 | Ask RR1–RR4 on the call | They decide whether the open risks are real | `[grounded]` register | for you |
| P4 | Prepare R9 and R7 from your own experience, with no new claims | The call will test these two rows | `[grounded]` R9, R7 | for you |

If you want to rehearse the 45-minute call, that is the mock-interview module; say so and I'll run it.

## Evidence status

Verified: none yet. Your background is still your own description, so every row sits at `medium` or below until a question is answered or an artifact is inspected.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea kayak surf schools" and "Fernquay careers Product Designer"; fetched fernquay.example/careers/product-designer and fernquay.example/about. Moved the employer check and the contradictions row: the posting is live and matches the pasted text |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3 years experience Galway", which returned Tillerby 2026 Ireland Design Salary Report (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row. No separate scope search ran |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned his LinkedIn profile (linkedin.example/in/ronan-kehoe). Moved the scope read: co-founder and CEO, previously product lead at a Galway travel-software company for five years |

## Upgrade menu

- A sanitized booking-flow artifact or the checkout case study you sent → R7 toward `high`, and evidence for R9.
- Your pay floor → R2 closes and the decision simplifies.
- One note from a B2B research call, even informal → R6 to `direct`.
- The equity terms and runway, from the employer → RR2 and RR3 close.
- Saoirse Doyle's public footprint → the CTO side of the call, if you want it.
- Deeper research on Fernquay (funding, leadership changes, public reviews; up to 5 more searches and 2 more fetches). Offered once; say the word and it runs.

I can also save this assessment as a tuesday-dossier.md you can keep and add to.

1. **R9 (G1):** Have you ever made design calls on your own, with no design peer to check them against? What did you decide, and how did you know it worked?
2. **R2:** What base salary would you need to take this role, and does €52,000–€60,000 work for you?
3. **R7 (G2):** Which steps of a booking flow did you own, from search or enquiry through to confirmation, and which did others own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.