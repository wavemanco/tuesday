**No. Don't go ahead, and don't send any money or details yet. Status: `no_go`.** The posting and the messages ask for things a real employer does not ask for before a job starts: a bank transfer to a third party for equipment, a cheque to deposit and partly forward, and bank, PPS and passport details before any offer. The whole process also runs in chat. I can't establish that Velloway Logistics exists from here, and I found no public trace of it.

- **Hard gates:** pay floor not established (R1 `unclear`). The posting's own figures don't reach €30,000 for most of its hour range.
- **Severe red flags:** RR1, RR2, RR3 and RR4 (all `severity: high`).
- **Opportunity:** the posting and messages carry several severe red flags and an unverified employer (RR5).
- **Fit:** your background fits the role's core tasks. The decision is driven by the opportunity, not your fit.

**Research tier: L1 — searches 2 of 5, fetches 0 of 2**

| Target | Status | Reason |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics": no results. Not established. |
| 2. Role-family sweep | yes | Searched the role's Ireland pay: Pennoral 2026 Ireland Customer Operations Pay Guide (pennoral.example), salaried roles only. Median €31,200; interquartile range €28,400–€34,100. |
| 3. Hiring manager's public footprint | n/a | No person's name was given, only the handle @VellowayHiring. |

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Pay as posted | "Up to €26 an hour", 15–30 hours a week, plus commission (rate unstated) | `[grounded]` posting |
| Pay range in hours | About €20,300–€40,600 a year before commission, at 52 weeks of paid hours | `[inferred]` from the posting's figures |
| Your floor | €30,000 needs about 22 paid hours every week, all year, at the "up to" rate | `[inferred]` from the posting's figures |
| Market band | Salaried order-processing and customer-operations coordinators: median €31,200 | `[generic]` Pennoral 2026; salaried only, so it excludes commission-only work |
| Contradiction | The posting says "no calls or video interviews", yet the messages promise a "chat interview" and then an "offer" by chat | `[grounded]` posting and messages |

**Evidence map** (your background as stated: Zendesk, about 60 tickets a day, two starters trained, an Excel tracker)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Your floor is your own statement. Whether the role meets it is unclear: the "up to" rate, the hours range and the unstated commission don't settle it | `[grounded]` your statement; `[inferred]` the hours arithmetic; `[generic]` the market band | Ask for guaranteed hours and the commission rate in writing, from the employer's own site |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. No file has been inspected | `[grounded]` your account | none |
| R3 | Strong attention to detail | must_have | direct | medium | none | Ticket work at about 60 a day; you trained two starters. Not inspected | `[grounded]` your account | none |
| R4 | Good written English | must_have | unclear | none | discovery | Nothing in the material shows it either way | `[grounded]` silence | none; not decision-relevant |
| R5 | A quiet place to work | must_have | unclear | none | discovery | You haven't said | `[grounded]` silence | none; not decision-relevant |
| R6 | Customer service and order processing | important | direct | medium | none | Three years as a parcel-courier customer service agent | `[grounded]` your account | none |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Verification question (to the employer) | Status |
|---|---|---|---|---|---|---|
| RR1 | Payment for equipment | red_flag | high (`severity: high`) | "Please pay €349 by bank transfer to our equipment partner" | Does Velloway ever ask new hires to pay for their own equipment, and if so, under what written policy? | confirmed |
| RR2 | Cheque to deposit and partly forward | red_flag | high (`severity: high`) | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 … transfer the rest to our equipment partner." | Does Velloway send cheques for new hires to deposit and forward to a third party? | confirmed |
| RR3 | Bank, PPS and passport details before any offer | red_flag | high (`severity: high`) | "please send your IBAN, your PPS number and a clear photo of your passport" | Will you send a written offer naming the role and pay, and only then request payroll details through your own portal? | confirmed |
| RR4 | Hiring process run wholly by chat | red_flag | high (`severity: high`) | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | Can you confirm the role on your own careers page and arrange a call with a named manager? | confirmed |
| RR5 | Employer not established | risk_signal | medium | "Velloway Logistics" | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Pay withheld against your floor | risk_signal | medium | "Up to €26 an hour plus commission" | What is the guaranteed minimum weekly pay, and what is the commission rate on each order? | unresolved |

RR1 to RR3 are the requests the material directs at you. This request is very likely a scam. Don't deposit the cheque, don't pay for equipment, and don't send your IBAN, PPS number or passport. The sender may not be who they claim to be. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**Application plan**: none advised until RR5 verifies through Velloway's own site. Don't apply through the Telegram handle.

**Upgrade menu**
- Velloway's own careers page, a company registration number, or a named contact on its website: clears or confirms RR5.
- Written pay terms (guaranteed hours and commission rate): settles R1 and RR6.
- Nothing else would change this decision.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.