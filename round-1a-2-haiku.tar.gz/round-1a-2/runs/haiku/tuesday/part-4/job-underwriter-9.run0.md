**Short answer: yes, asking for bank details, a PPS number and a passport check is normal once someone has made a real written offer. What matters is where you send them.** This offer names the role, the pay and the manager, and it follows two interviews at their office, so it reads as routine onboarding. Don't send any of it yet. Check the offer and the portal first, using the employer's own website.

**Status: `conditional_go`.** Apply the rest of your judgement to the offer, but accept only after the checks below.

**Fit ledger.**

- `hard_gate`: unclear: R1 (right to work in Ireland), R2 (two office days a week in Limerick), R3 (pay band against your floor)
- `must_have`: direct: R4 (2+ years running payroll), R7 (payroll-to-ledger reconciliation), R8 (strong Excel), R9 (payroll qualification); adjacent: R6 (pension changes); unclear: R5 (Irish PAYE, PRSI and USC)
- `important`: direct: R11 (starters and leavers); unclear: R10 (staff payroll queries)

R6 — a bridge, its limit named; R5 — the knowledge gap most likely to matter in interview; R1 to R3 — the gates you haven't answered yet.

**Opportunity ledger.** The in-person interviews and the concrete offer are positive signs (RR1). The request for bank, PPS and passport details before any portal is checked is unresolved (RR2). I could not check the employer from here, so it is unverified rather than shown to be missing (RR3).

- **Hard gates:** none failed (R1, R2 and R3 all `unclear`); unconfirmed: R1 (right to work in Ireland), R2 (two office days a week in Limerick), R3 (pay band against your floor); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the offer's sender and the onboarding portal are confirmed through the employer's own website; (2) right to work and the Limerick commute are confirmed by you; (3) the pension arrangements are confirmed before you accept.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, 240 staff | `[grounded]` posting |
| Mandate | Monthly payroll, starters and leavers, pension changes, payroll-to-GL reconciliation, staff queries | `[grounded]` posting |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer |
| Working pattern | Hybrid, two days a week in the Limerick office | `[grounded]` posting and offer |
| Pay | Posted €38k–€42k; offered €40k | `[grounded]` posting and offer |
| Market calibration | Not run. Web search was refused, so there is no sourced band for this title | — |
| Unknowns | Pension scheme terms, whether the post is permanent, budget line, start date, payroll cycle change (fortnightly to monthly, 90 to 240 staff) | — |
| Contradictions | None between the posting and the offer | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Right to work in Ireland | hard_gate | unclear | none | hard_gate | Your status isn't stated, so it isn't established. The offer's passport step only confirms it later | `[grounded]` offer; no candidate statement | Q2 below |
| R2 | Two office days a week in Limerick | hard_gate | unclear | low | hard_gate | Posted and offered. Your home location isn't given | `[grounded]` posting and offer | Q1 below |
| R3 | Pay in the €38k–€42k band | hard_gate | unclear | low | hard_gate | The €40k offer sits in the posted band. Your floor isn't stated | `[grounded]` posting and offer | Upgrade menu |
| R4 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff, self-reported. Cycle and scale both differ | `[grounded]` your account | none |
| R5 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your account doesn't say which jurisdiction the payroll ran under | `[grounded]` silence in your account | Q3 below |
| R6 | Pension changes (a stated responsibility, not a listed requirement) | must_have | adjacent | medium | transferability | Starters and leavers use the same payroll inputs. You have not processed pension changes; your manager did | `[inferred]` adjacency from starters and leavers | Gap queue G2 |
| R7 | Monthly payroll-to-GL reconciliation | must_have | direct | medium | none | Stated in your account, with no reconciliation inspected | `[grounded]` your account | none |
| R8 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables, XLOOKUP. No file inspected | `[grounded]` your account | none |
| R9 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024. Certificate not inspected | `[grounded]` your account | Upgrade menu |
| R10 | Answer staff payroll queries | important | unclear | low | discovery | Not in your account | `[grounded]` silence | Gap queue G3 |
| R11 | Process starters and leavers | important | direct | medium | none | Three years of it, stated | `[grounded]` your account | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish statutory payroll (R5, must_have) | discovery | Your account doesn't say which jurisdiction you ran payroll under | This is the core of the job. If it's Irish, the gap closes | PAYE, PRSI and USC calculations; RPN submissions to Revenue; year-end returns | A sanitised payslip or a description of the Revenue steps you ran | `[grounded]` silence in your account; `[generic]` that Irish employers expect these three |
| G2 | Pension changes (R6, must_have) | transferability | Starters and leavers done; pension changes handled by your manager | Pension steps need scheme-specific knowledge you haven't yet had | Enrolment or leaver contribution steps you watched or assisted with | The scheme's own process notes, asked for before accepting | `[inferred]` bridge from starters and leavers; `[generic]` that pension changes are scheme-specific |
| G3 | Staff payroll queries (R10, important) | discovery | Not in your account | Queries are daily work in a 240-person payroll | Answering queries about pay, deductions or payslips on a payroll you ran | Examples of queries you handled | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Concrete offer after in-person interviews | positive_signal | — | "delighted to offer you the permanent post … reporting to Declan Garvagh" | The role and manager are specific, and you have seen the office | `[grounded]` offer and your account | Which budget line does this post sit in, and what is the start date? | noted |
| RR2 | Bank, PPS and passport requested before any portal is checked | risk_signal | medium | "we will send you a link to our onboarding portal, where you add your bank details … your PPS number … a scan of your passport" | Routine after a credible offer, but the sender and the portal aren't checked yet. Hold the disclosure until they are | `[inferred]` from the offer's sequence; `[generic]` that onboarding requests like this are routine for real employers | Can you confirm this offer, and the web address of the onboarding portal? (Ask through contacts found on their own website.) | unresolved |
| RR3 | Employer not verified from here | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The footprint of a small or new employer is often thin. Here the search was refused, so the employer is unverified, not shown to be missing | `[generic]` pattern for employers of this size, not a claim about this one | Can you point me to the live post on your careers page, and confirm the People Team's direct contact? | unresolved |

RR3 caps the decision at `conditional_go`: verify before you invest in the acceptance.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Type the employer's web address yourself, find the People Team on it, and check the offer's domain matches | RR2, RR3 | `[grounded]` the offer's sender domain | for you to do |
| P2 | Send nothing containing bank, PPS or passport details until the portal address is confirmed on their site | RR2 | `[grounded]` the offer's sequence | hold |
| P3 | Before accepting, ask: start date, pension scheme, whether the post is permanent, budget line | R6, RR1 | `[inferred]` from the register | pending your approval |
| P4 | Ask for a short extension if you need one. The five-working-day deadline is theirs to set | offer text | `[grounded]` offer | pending your approval |

I haven't drafted the reply to the offer or any email to the employer. Those are outward-facing, so I'll draft them only if you ask.

## Evidence status

Verified: none yet. Everything above rests on your account at intake, which is the strength of a CV-level claim.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused in this session. It would have confirmed the employer, the live posting and the offer's domain. That is RR3 and the standing employer check |
| 2. Role-family sweep | unavailable | The search was refused. It would have set a sourced pay band for the title. R3 and the market calibration are therefore unfilled |
| 3. Hiring manager's public footprint | unavailable | You named Declan Garvagh, so this search could run. It was refused. It would have checked his Finance Manager role and how the post fits his team |

## Upgrade menu

- Allowing web search → targets 1 to 3 run. That moves RR3, the pay calibration and Declan Garvagh's public role.
- Your home location and your right-to-work status → R1 and R2 close.
- Your pay floor → R3 closes.
- A sanitised copy of your Payroll Technician certificate, or a reconciliation template you can describe → R9 and R7 to `high`.
- The employer's onboarding portal address, confirmed on their own site → RR2 closes.

I can save this as `tuesday-dossier.md` if you'd like to keep it.

## Questions

Q1 (R2): Can you get to the Limerick office two days a week? Where are you starting from?

Q2 (R1): Do you have permission to work in Ireland without needing sponsorship?

Q3 (R5): Which of these have you done yourself: PAYE, PRSI and USC calculations, RPN submissions to Revenue, or year-end returns?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.