## Posting 1: Operations Analyst, Duinvaart Cold Chain, Rotterdam

**Worth applying to, on two conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1
- `must_have`: direct: R2, R3, R4
- `important`: direct: R5 · unclear: R6, R7 · adjacent: R8
- `preferred`: adjacent: R9

R1 — the schedule is unsettled; R6 — no temperature-compliance evidence; R5 — strong evidence, not yet the lead story.

- **Hard gates:** none failed; unconfirmed: R1 (hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Rotterdam schedule is workable (R1); (2) the posting is confirmed on Duinvaart's own site (RR1, standing entry).

**Opportunity ledger.** Scope and outcomes are specified (RR3); pay is withheld (RR2); decision rights on route changes are unstated (RR4); the employer is not yet established from attributable sources (RR1).

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; runs a refrigerated fleet | `[grounded]` JD |
| Mandate | Track on-time delivery and temperature compliance; build weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Pay | Not stated | `[grounded]` JD silence |
| Scope read | An analyst role with dashboard ownership and depot liaison, not a manager role | `[inferred]` from the duty list |
| Market calibration | Not run; see evidence status | — |
| Unknowns | Pay; who decides route changes; how much cold-chain knowledge is expected | — |
| Contradictions | None; one source only | — |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | No constraint given, so the term is neither met nor failed | `[grounded]` JD; no candidate statement | Q1 |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as operations analyst at a parcel carrier; self-reported, not yet probed | `[grounded]` intake | none |
| R3 | Strong SQL | must_have | direct | medium | none | SQL daily in the current role; self-reported | `[grounded]` intake | none |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the depot on-time dashboard; self-reported | `[grounded]` intake | none |
| R5 | Track on-time delivery across the refrigerated fleet | important | direct | medium | presentation | The depot dashboard is the strongest evidence here, but the intake reads it as one duty among many | `[grounded]` intake | E1 |
| R6 | Track temperature compliance across the refrigerated fleet | important | unclear | none | discovery | Nothing in the intake on temperature data or cold-chain monitoring | `[grounded]` JD; intake silence | Q2 |
| R7 | Refrigerated-fleet operations knowledge (not a listed requirement) | important | unclear | low | discovery | Inferred from the fleet focus; the intake does not say whether the parcel network involved temperature control | `[inferred]` from the JD's fleet focus | Q2 |
| R8 | Work with depot managers on route changes | important | adjacent | medium | transferability | Ran the weekly route-performance review and the dashboard depot managers use. Limit: reviewed performance; the intake does not say the candidate changed routes | `[inferred]` adjacency from intake | RR4 |
| R9 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational, not fluent; limit is that it is not working Dutch | `[grounded]` intake | E2 |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature and cold-chain data (R6, R7) | discovery | Nothing in the intake on temperature compliance | An important duty the posting names first in its fleet line; likely the first interview probe | Any SLA or compliance report; a monitoring log reviewed; a check that carriers met a standard | A sanitized compliance report or dashboard column | `[grounded]` JD; `[generic]` that cold-chain roles are probed on monitoring |
| G2 | Route-change authority (R8) | transferability | Performance review and depot dashboard, not route decisions | Whether you advise or decide shapes the role's scope | Route or schedule changes proposed to a depot | A route-review deck or a dashboard view | `[inferred]` from the intake against the JD |

The queue holds no questions. G1's question is asked in the closing block.

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The employer may be too new or small to have a footprint, or the posting may be stale. Not checked: the search was refused | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay withheld | unknown | — | Salary not stated | Pay may sit below the market band, or be withheld as policy | `[grounded]` JD silence | What is the salary range for this role? | unresolved |
| RR3 | Outcomes and scope specified | positive_signal | — | "Track on-time delivery and temperature compliance" | Clear, measurable scope | `[grounded]` JD | Who reviews the weekly dashboards, and what do depot managers do with them? | noted |
| RR4 | Route-change decision rights unstated | unknown | — | "work with depot managers on route changes" | You may advise without deciding, or own changes outright | `[inferred]` from the JD's silence on authority | Who makes the final call on a route change: the analyst, the depot manager, or operations? | unresolved |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the summary with the depot on-time dashboard, the strongest evidence for R4 and R5 | see R5 | `[grounded]` intake | pending your approval |
| E2 | Describe Dutch as conversational, in your words, not as professional or working Dutch | see R9 | `[grounded]` intake | pending your approval |
| A1 | Confirm the posting on Duinvaart's own careers site before you apply | see RR1 | `[generic]` pattern | proposed |
| A2 | Ask the pay range and the route-change authority before the first interview | see RR2, RR4 | `[grounded]` register | proposed |

---

## Posting 2: Supply Planner, Kroonhaven Foods, Utrecht

**Not worth applying to now. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1
- `must_have`: absent: R2, R4 · unclear: R5 · adjacent: R6
- `important`: adjacent: R3

R2 — no planning history; R4 — no planning system named; R6 — conversational, not fluent; R3 — nearest work is delivery reporting, not capacity planning.

- **Hard gates:** none failed; unconfirmed: R1 (on-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a planning history that is not in your intake, such as a forecast or supply plan you owned. Two must-haves are absent, and no path closes them within this application.

**Opportunity ledger.** The scope is clear: you would own the 13-week plan and run S&OP (RR1). Nothing in the posting raises a red flag. The employer has not been checked (RR2, standing entry).

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready-meals | `[grounded]` JD |
| Mandate | Own the 13-week supply plan; balance production capacity against forecast; run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site, Utrecht | `[grounded]` JD |
| Pay | Not stated | `[grounded]` JD silence |
| Scope read | A planner of record, not analyst support, because of "own" | `[inferred]` from the verb |
| Market calibration | Not run; see evidence status | — |
| Unknowns | Who signs off the plan; pay | — |
| Contradictions | None; one source only | — |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No constraint given | `[grounded]` JD | Q1 |
| R2 | 3+ years supply or demand planning in FMCG | must_have | absent | medium | capability | You told me you have never worked in planning, and the intake shows no adjacent planning work. Closure takes years, not this application | `[grounded]` intake statement | Closure path in the application plan |
| R3 | Balance production capacity against forecast | important | adjacent | low | transferability | The route-performance review and delivery-volume reporting are the nearest work. The intake does not say you balanced capacity against a forecast. Limit: reporting, not planning | `[inferred]` from intake | none |
| R4 | SAP IBP or similar planning system | must_have | absent | none | capability | No planning system named | `[grounded]` intake silence | Closure path: a vendor course, not a substitute for planning hours |
| R5 | Advanced Excel | must_have | unclear | none | discovery | The intake names SQL and Power BI, not Excel | `[grounded]` intake silence | Ask your Excel level if this posting is reopened |
| R6 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent. Limit: a Dutch-language S&OP meeting would be hard | `[grounded]` intake | none |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Planning authority unclear | unknown | — | "Own the 13-week supply plan" | You may be the planner of record, or support a planning lead | `[inferred]` from the verb against silence on sign-off | Who signs off the 13-week plan, and who would I report to? | unresolved |
| RR2 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | As in RR1 of posting 1: not checked, since the search was refused | `[generic]` pattern for companies of this size | Can you point me at this role on your own careers site? | unresolved |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Skip this posting for now | see R2, R4 | `[grounded]` map | proposed |
| P2 | Target planning-analyst or demand-analyst roles in FMCG, where SQL and delivery reporting are the entry point | the realistic route into planning | `[generic]` pattern for junior planning routes | proposed |

---

## Evidence status

Verified: none yet. Every candidate claim above is your own statement in the intake; nothing has been inspected.

Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for both employers were refused permission in this session, so nothing was read. Would have checked that Duinvaart Cold Chain and Kroonhaven Foods exist as described and that both postings are live (RR1 in both registers). I did not retry the refused calls |
| 2. Role-family sweep | unavailable | Searches for both roles' pay and scope were refused permission, so nothing was read. Would have set the market calibration lines and the RR2 pay band |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Without the employer checks, both assessments stand as first passes. Posting 1's `conditional_go` is capped by the unverified employer, and posting 2's `no_go` does not depend on it.

Dossier offer: If you want these two assessments saved to a `tuesday-dossier.md` so they carry into later sessions, I can write it.

## Upgrade menu

- Permission for WebSearch would run the four checks in targets 1 and 2. That answers RR1 in both registers and sets the pay band behind RR2 and the market read.
- A sanitized screenshot or description of the depot on-time dashboard, with no customer or driver data, would raise R5 and R4 to `high`.
- Any temperature or cold-chain reporting, even one dashboard column, would address R6 and R7 on posting 1.
- Any forecast, capacity or production work, even inside a reporting role, would address R2 and R3 on posting 2. It would not close R2's three years on its own.
- Your answer on schedule (Q1) settles R1 on both postings.

## Questions

**Q1 (R1, both postings):** Is three days a week in the Rotterdam office workable for you, and would a full on-site role in Utrecht be?

**Q2 (R6, R7, posting 1):** Have you tracked, reported or acted on temperature or cold-chain compliance, even as one column in a dashboard? What did it measure, and who used it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.