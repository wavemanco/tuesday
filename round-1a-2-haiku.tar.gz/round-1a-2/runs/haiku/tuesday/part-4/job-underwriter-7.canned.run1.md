**Yes, worth applying, on three conditions.** Decision: `conditional_go`. Both hard gates (current NMC Adult registration and a full UK licence) are met on what you've stated, and the posting doesn't rule you out. The gap is caseload experience and clear written records, which you should be ready to speak to. I've also not used your National Insurance number, since nothing here needs it.

**Decision snapshot**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R5, R6, R8 · adjacent: R7, R11 · unclear: R4, R9, R10
- `important`: unclear: R12
- `preferred`: absent: R13

R7 (leg-ulcer care) and R11 (own caseload) are credible bridges with their limits named; R4 (written records), R9 (continence care), R10 (care planning) and R12 (end-of-life visits) are unclear and each has a question below.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Opportunity ledger:** RR1 (caseload size and support unstated) and RR2 (posting not yet confirmed on the employer's own careers page) are open; RR3 (pay stated) and RR4 (pool cars provided) read the other way.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your answer on written records (R4) holds up; (2) the post is confirmed on Calderbrook's careers page before you put effort into an application (RR2); (3) caseload size and support are clear by interview (RR1).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health: a CIC running adult community nursing under an NHS contract, about 410 staff across four hubs | `[grounded]` employer's About page, via search |
| Mandate | District nursing for housebound adults at home; wound, catheter, insulin, end-of-life care; own small caseload with senior-nurse support | `[grounded]` posting |
| Pay | £31,050–£37,800 plus mileage, pool cars provided | `[grounded]` posting |
| Market calibration | A 2026 survey of community staff nurses at Band 5 in England (n=1,240) puts median basic pay at £34,300, interquartile range £32,400–£36,600; 61% of respondents were paid mileage. The posted range brackets that median. | `[generic]` one vendor survey, method not checked |
| Scope read | Caseload ownership is the main change from your current role | `[inferred]` from the posting's caseload language against your CV |
| Unknowns | Caseload size, supervision, on-call, and whether the post is live on the employer's own careers page (that fetch returned nothing) | — |
| Contradictions | None found between the posting and the About page | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | Your CV states active Adult registration, revalidation March 2028; you confirm it by check | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B, stated | `[grounded]` CV | none |
| R3 | At least one year post-registration experience | must_have | direct | medium | none | Five years as staff nurse | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | CV silent on documentation; the posting asks for it explicitly | `[grounded]` CV silence | Question Q1 |
| R5 | Insulin administration | must_have | direct | medium | none | Stated in CV, no inspectable proof | `[grounded]` CV | none |
| R6 | Wound care (pressure and surgical) | must_have | direct | medium | none | Stated in CV | `[grounded]` CV | none |
| R7 | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound-care work carries over; leg ulcers and their compression care are not named. Limit: not evidenced | `[inferred]` from R6 | Question Q3 |
| R8 | Catheter care | must_have | direct | medium | none | Stated in CV | `[grounded]` CV | none |
| R9 | Continence care | must_have | unclear | low | discovery | Not in CV | `[grounded]` CV silence | Question Q3 |
| R10 | Care planning | must_have | unclear | low | discovery | CV doesn't say whether you planned visits or care for patients | `[grounded]` CV silence | Question Q2 |
| R11 | Own small caseload, supported by a senior nurse | must_have | adjacent | medium | transferability | Home visits in the discharge-to-assess role; you've never held a caseload. Limit: no caseload ownership | `[grounded]` CV; `[inferred]` bridge | Question Q2 |
| R12 | End-of-life visits | important | unclear | low | discovery | Not in CV | `[grounded]` CV silence | Upgrade menu |
| R13 | Doppler assessment for leg ulcers | preferred | absent | medium | transferability | You've never done one. Wound-assessment skills carry over; the Doppler skill itself is a closure path | `[grounded]` CV; `[generic]` closure path | Upgrade menu |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4) | discovery | Documentation not in CV | Essential, and the posting names electronic records | Any ward or discharge note-writing; handover; any time notes were audited | An anonymised template or a description of your system, with no patient identifiers | `[grounded]` posting; `[generic]` that records are reviewed |
| G2 | Caseload and care planning (R10, R11) | discovery | Home visits, but no record of who set visit frequency or the care plan | Decides whether the caseload bridge holds | Deciding a patient's next visit or what to do after one; a discharge plan you wrote | A plan you can describe without patient detail | `[inferred]` bridge from home visits |
| G3 | Leg ulcers and continence (R7, R9) | discovery | Wound care stated, leg ulcers and continence not | Two must-haves that the posting names | Compression or dressing decisions; continence assessments or catheter-related management | Anonymised care-plan description | `[grounded]` posting |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload size and support not stated | unknown | — | "You will hold a small caseload of your own, supported by a senior community nurse" | The caseload may be heavier, or supervision lighter, than "small" suggests | `[inferred]` from the posting's silence on numbers | How many patients would I hold at once, and how is a senior nurse available day to day? | unresolved |
| RR2 | Posting not confirmed on employer's own careers page | unknown | — | "For an informal chat about the role, contact Rhiannon Mabbott" | The post may be stale or aggregated | `[generic]` pattern; the fetch returned nothing | Is this post still open on your careers site? | unresolved |
| RR3 | Pay and mileage stated | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Transparent pay, in line with the survey median | `[grounded]` posting; `[generic]` survey | Where in the range do new starters usually land? | noted |
| RR4 | Pool cars provided | positive_signal | — | "pool cars are provided" | Lower vehicle cost to you | `[grounded]` posting | Are pool cars available on every shift? | noted |

Employer check: the employer is established from its own About page, so the standing "employer not established" entry does not apply. No severe red flags: the posting asks nothing of you financially.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the post on the employer's careers page, then ask about caseload size and supervision through the contact the posting gives | RR1, RR2 | `[grounded]` posting | pending your approval |
| A2 | Keep CV wording to what your sources support: insulin, wound care (pressure and surgical), catheter care, and home visits after discharge. Don't add "caseload", "leg ulcers", or "continence". | Keeps claims within your own evidence | `[grounded]` CV | resume_edits_pending_approval |
| A3 | Doppler: a training course, before or after an offer | Closes R13 | `[generic]` closure path | pending your approval |

**Evidence status**

Verified: none yet. Your CV claims stand at `medium`, the intake ceiling, until you confirm them specifically.

Research tier: L1 — searches 2 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and found the About page (calderbrookhealth.example/about), which confirms the employer. Fetching its careers page returned no page, so the post is unconfirmed (RR2). |
| 2. Role-family sweep | yes | Searched "community staff nurse Band 5 Agenda for Change pay 2026/27 pay scale"; fetched the Wardround 2026 pay guide (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration, `[generic]`. |
| 3. Hiring manager's public footprint | n/a | No name for the hiring manager was given. The team lead's name is in the posting, but no search was sent for them. |

**Upgrade menu**

- An anonymised note of how you recorded a visit electronically (no patient identifiers) → R4 moves toward `direct`.
- A description of a leg-ulcer or continence plan you've been part of → R7 and R9 get firmer.
- Confirmation from the employer on caseload size → RR1 closes.
- Doppler training, when you can book it → R13 closes.
- Please don't bring any patient-identifiable notes to the application or interview.

**Questions** (three, tagged to their rows)

Q1 (G1, R4): In your ward and discharge work, how did you record visits and notes electronically, and how soon after a visit did you write them up?

Q2 (G2, R10, R11): In the discharge-to-assess role, who decided how often you visited a patient and what the plan was after each visit: you, or the team?

Q3 (G3, R7, R9): Have you ever managed a leg ulcer's dressing or compression plan, or done a continence assessment, even as part of wider wound or catheter care?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.