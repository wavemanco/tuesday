**Decision snapshot**

I can't establish from here that Fernquay is legitimate. My web searches were refused permission, so the company and Ronan Kehoe are unchecked. Nothing you've shared asks you to pay, deposit money or give bank details, and the interview is a video call with an email invite, so the WhatsApp message is not a warning sign in itself. Worth applying to, once the employer checks out. Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R8 (pay, €52,000–€60,000)
- `must_have`: direct: R2, R3, R4, R6 · unclear: R7 (first designer, working without a design peer)
- `important`: adjacent: R5 (research calls with school owners)

R5 (`adjacent`): a credible bridge from consumer customers to school owners, with its limit named. R7 (`low`): you have never owned a product area with no other designer, so this is a question to answer, not a claim to make.

**Opportunity ledger.** Unverified rather than weak: RR1 (employer not established, because research was refused), RR3 (equity terms unstated) and RR4 (one designer owning booking end to end, no design peer named). RR2 is an unknown about the WhatsApp channel, not a risk signal. One entry runs the other way: RR5, a stated salary band, hybrid terms and named people.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R8 (pay, €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** conditions for `go` are (1) Fernquay verified from its own website or the Irish Companies Registration Office, with the invite sent from its domain (RR1, RR2); (2) your pay floor at or below €52,000 (R8); (3) a truthful answer on solo ownership (R7), or accepting it as a stated risk.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Six people in Galway making booking software for sea-kayak and surf schools; two engineers; co-founder Ronan Kehoe; CTO Saoirse named in the message | `[grounded]` posting and WhatsApp message |
| Role | First product designer: own the booking flow end to end, run school-owner research calls, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office, the rest remote | `[grounded]` posting |
| Pay and equity | €52,000–€60,000 plus 0.5–1% equity; form, vesting and strike not stated | `[grounded]` posting |
| Market calibration | Not run: the pay search was refused. No band is given here, and none is estimated from memory | — |
| Unknowns | Whether the employer exists and is live; equity form; who reviews design decisions; interview stages after the 45-minute call | — |
| Contradictions | None found in the material you shared | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work from the Galway office two days a week | hard_gate | direct | medium | none | You live in Galway; stated, not inspected | `[grounded]` your background | none |
| R2 | 3+ years of product design | must_have | direct | medium | none | Four years stated; not inspected | `[grounded]` your background | Share a portfolio artifact to raise to high |
| R3 | Strong Figma | must_have | direct | medium | none | Daily use stated; no file inspected | `[grounded]` your background | Share a Figma file or screen to raise to high |
| R4 | Has run own user research | must_have | direct | medium | none | Ran monthly usability sessions with customers | `[grounded]` your background | Ask for one session plan as an example |
| R5 | Research calls with school owners | important | adjacent | medium | transferability | Customer research carries over; school owners are a different audience and business | `[inferred]` from R4 against the posting's audience | G2 below |
| R6 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad stated | `[grounded]` your background | none |
| R7 | Ships as the first designer, without a design peer | must_have | unclear | low | discovery | You have never been the only designer; the checkout redesign was squad work, so your part is not established | `[grounded]` your statement | G1 below |
| R8 | Pay of €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | Your floor is not given, so the band cannot be checked against it | `[grounded]` posting; floor unknown | One question, closing block |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ships without a design peer (R7, must_have) | discovery | The CV shows squad work on the checkout redesign and no solo decisions | Interviewers will probe whether you can own decisions alone | Any product decision you made without a senior designer checking it; a flow you owned end to end | A brief or write-up of one such decision | `[grounded]` your statement; `[generic]` that this is probed |
| G2 | School-owner research (R5, important) | transferability | Customer usability sessions; no B2B or owner-operator research | The bridge needs a stated limit | Interviews with small-business owners at a previous job; any user group that ran its own operations | A session plan or interview guide | `[inferred]` from R4 |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software" | Research was refused, so this is an unchecked footprint, not evidence the company is fake; the company may be small, new or unlisted | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Hiring contact by WhatsApp | unknown | — | "Just shout here if the time does not suit" | The channel may be informal, or the sender may not be the company; the email invite is the check | `[inferred]` from the message and the invite | Can you confirm the invite came from your company email address? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | Equity may be options or shares with vesting that changes its value | `[inferred]` from the missing terms | What form is the equity, what is the vesting schedule, and what is the strike price? | unresolved |
| RR4 | One designer owns booking end to end | risk_signal | low | "You will work most closely with our co-founder" | Decision rights and design review may sit with the co-founder, with no design peer | `[inferred]` from the scope against the team size | Who signs off design decisions for the booking flow? | unresolved |
| RR5 | Stated pay band, hybrid terms and named people | positive_signal | — | "we would rather see one messy real project than a polished deck" | Transparent terms and named people are checkable signs | `[grounded]` posting and message | Who will I review my work with in the first month? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check Fernquay yourself: its own website, its entry on core.cro.ie, and whether the invite's domain matches the website | RR1, RR2 | `[inferred]` from RR1 | your action |
| P2 | Describe the checkout work as squad work you did, e.g. "redesigned checkout in a squad of four", not as solo ownership | R7, R6 | `[grounded]` your own sentences; reframing audit applied | pending your approval |
| P3 | Ask for the equity form and vesting before discussing any offer | RR3 | `[grounded]` posting | pending your approval |

The 45-minute call is mock-interview's job rather than this one's, and that module can build a prep pack for it.

**Evidence status**

Verified: none yet. Everything above is your self-report, not yet probed.

**Research tier: L1 — searches 4 of 5, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Fernquay and its careers page were refused permission. Would have moved RR1 and the employer-not-established entry |
| 2. Role-family sweep | unavailable | A search for Irish product-designer pay was refused permission. Would have moved R8 and RR3 |
| 3. Hiring manager's public footprint | unavailable | A search for Fernquay with Ronan Kehoe's name was refused permission. Would have moved the scope read and what to lead with |

**Upgrade menu**

The dossier offer, in one sentence: I can write this up as a `tuesday-dossier.md` you can keep and reopen after the call.

- Permission to run the web searches, plus up to two page fetches (Fernquay's own site and the careers page) → RR1 closes or sharpens, and R8 gets a market band.
- Your pay floor → R8 closes.
- A portfolio artifact or one Figma file → R2 and R3 move to `high`.
- A written example of one decision you owned alone, or a plan for one session → R7 and R5 move.
- A deeper research pass on Fernquay and Ronan Kehoe (funding, leadership, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

RR1 — Can you find Fernquay's website yourself, and does the invite's sender domain match it?

R8 — What is your pay floor, and is €52,000 above or below it?

G1 — Have you ever owned a product decision with no other designer to check it? If so, what did you decide, and what did the team decide?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.