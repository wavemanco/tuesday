## Fernquay: conditional go

Yes, it's worth applying for, and as far as I can check from here it's a real company. The posting matches Fernquay's own careers page, and the company has a site, a named co-founder and a stated location. I found no request for money, bank details or a deposit. The one thing I can't settle from here is the equity and pay terms, which the questions below would close.

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Fit ledger:**
  - `hard_gate` — direct: R1
  - `must_have` — direct: R2, R3, R4, R5 · adjacent: R6 (own the booking flow end to end)
  - `important` — adjacent: R7 (run research calls with school owners) · unclear: R8 (work as the only designer)

  R6 is a bridge from checkout to the full booking flow, with the limit named. R8 has no evidence yet, so it is the question that matters most.
- **Opportunity ledger:** The employer's own pages agree on the facts (RR1, a positive signal). The equity and the scope of one designer's ownership are unknowns to ask about (RR2, RR3). The WhatsApp scheduling is not a signal (RR4).
- **Conditions for `conditional_go`:** (1) your pay floor and the two Galway office days are confirmed against the terms (candidate constraints); (2) the 0.5–1% equity terms are given in writing (RR2); (3) the booking flow is confirmed as yours to own, with a named sign-off path (R6, RR3).
- **What would change this:** Equity terms that are only a promise, or a booking flow with no design input, would move it toward `hold_pending_answers`.

### Research

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software Galway sea-kayak surf schools" and "Fernquay Product Designer job Galway"; fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer) and "About Fernquay" (fernquay.example/about). Role reality: the careers page and the JD agree on pay, hybrid pattern and the first-designer role, so no contradiction. The about page confirms the company exists, six people in Galway. |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3 years experience", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Read from the search snippet only, not fetched. Market calibration `[generic]`. |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned a LinkedIn profile snippet (linkedin.example/in/ronan-kehoe). Scope read and positioning only, from public professional footprint. |

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: booking software (Kelproster) for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by customers | `[grounded]` about page |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` JD and careers page |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` JD and careers page |
| Pay and equity | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` JD and careers page |
| Market calibration | Tillerby 2026 (n=520, Ireland): product designers with 3–5 years, median base €57,000, interquartile range €51,500–€62,000. The posted band sits slightly below that median. | `[generic]` role-family sweep, read from snippet; `[grounded]` posted band |
| Unknowns | Equity share class, vesting and valuation; whether there is any design input above you; what the booking flow covers; whether Saoirse Doyle is the CTO (the about page says co-founder, the WhatsApp says CTO) | — |
| Contradictions | None between the JD and the careers page | `[grounded]` both pages fetched |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Based in Galway for two office days a week | hard_gate | direct | medium | none | You say you moved back to Galway last year. Prose self-report, not yet inspectable | `[grounded]` your background | none |
| R2 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer, stated, not probed | `[grounded]` your background | none |
| R3 | Strong Figma | must_have | direct | medium | none | Daily use, stated | `[grounded]` your background | none |
| R4 | Has run own user research | must_have | direct | medium | none | Ran monthly usability sessions with customers | `[grounded]` your background | none |
| R5 | Works directly with engineers | must_have | direct | medium | none | Four years in a squad with four engineers | `[grounded]` your background | none |
| R6 | Owns a booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a checkout flow, which is one section of a booking flow. Limit: you have not owned the whole flow from research to ship | `[grounded]` your checkout work; `[inferred]` that checkout is a section of a booking flow | see G1 |
| R7 | Runs research calls with school owners | important | adjacent | medium | transferability | Usability sessions with travel customers are the nearest match. Limit: consumers, not small business owners | `[grounded]` your sessions; `[generic]` that owners and consumers differ | see G3 |
| R8 | Works as the only designer | important | unclear | low | discovery | You say you have never been the only designer. Not yet known whether you can work without a design team | `[grounded]` your statement | see G2 |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own a booking flow end to end (R6) | transferability | Checkout redesign, confirmed by you; nothing yet from research through to ship on a full flow | R6 is a must-have and the likeliest thing to be probed | Any flow you took from brief to ship, even a smaller one | The checkout case study itself | `[grounded]` your background; `[inferred]` checkout as a section of a booking flow |
| G2 | Work as the only designer (R8) | discovery | No example of solo design decisions | Decides whether the first-designer scope is realistic for you | A flow you decided and shipped with no one to sign off | A brief, a decision note or a shipped screen with your name on the decision | `[grounded]` your statement |
| G3 | Research calls with school owners (R7) | transferability | Usability sessions with consumers | The posting's research is with a different user group | Merchant, supplier or small-business calls in any past work | A research plan or interview guide you used | `[grounded]` your sessions; `[generic]` owners differ from consumers |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer established from its own pages | positive_signal | — | "Six people, based in Galway" | Real, small, and funded by customers | `[grounded]` about and careers pages fetched | Which schools use Kelproster today, and are any in Galway? | noted |
| RR2 | Equity has no stated terms | unknown | — | "plus 0.5–1% equity" | Equity is worth something only at a valuation and vesting terms the posting does not give | `[inferred]` from the posting's silence on share class, vesting and valuation | What share class is the 0.5–1%, what is the vesting schedule, and what was the latest valuation? | unresolved |
| RR3 | First designer owns the flow alone | risk_signal | low | "own the booking flow end to end" | Scope may outrun one designer's support if no design lead sits above | `[generic]` pattern for first design hires at small companies, not a claim about this one | Who signs off the booking flow before it ships, and who reviews design decisions? | unresolved |
| RR4 | Scheduling over WhatsApp | unknown | — | "Just shout here if the time does not suit" | Chat is used for scheduling only; the interview is a video call with an emailed invite. Scheduling by chat is not a signal | `[grounded]` message text | Could you send the invite from the fernquay address on the careers page? | unresolved |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Describe checkout as your work: "Redesigned the checkout flow at a Dublin travel-booking company." Do not add "end to end" | see R6 | `[grounded]` your sentence | pending your approval |
| P2 | Describe your research as usability sessions with customers, and say plainly that you have not run owner interviews | see R7 | `[grounded]` your sessions; `[generic]` owners differ from consumers | pending your approval |
| P3 | Put the RR2 and RR3 questions to Ronan verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Ronan's public profile lists earlier product work at a Galway travel-software company, per the search snippet. That is the one public detail that could shape which story to lead with for this reader. It is not verified beyond the snippet.

### Evidence status

Verified: none yet.

Rejected inferences: none.

Unverified leads: none.

The research tier, the target accounting and the upgrade menu follow the questions below.

**Dossier offer:** If you want, I can write this up as a `tuesday-dossier.md` so the notes carry into interview prep later.

### Upgrade menu

- The full Tillerby report instead of its snippet tightens the market band (`[generic]`).
- The equity terms in writing (share class, vesting, latest valuation) close RR2.
- Your pay floor and whether two Galway office days a week suit you close the candidate-constraint checks in the snapshot.
- The checkout case study, attached, would raise R6's bridge evidence and its confidence.
- A deeper research pass on Fernquay (funding, customers, press, hiring pattern; up to 5 more searches and 2 more fetches). Say the word and it runs.

### Questions

G2 — In your own words, what did you decide alone on the checkout flow, and who had to sign it off?

G3 — Have you ever run calls with small-business owners in any past work, such as merchant or supplier calls? What from those transfers to school owners?

Constraint check — What is your pay floor, and do two office days a week in Galway suit you? Those two answers decide the hard-gate checks.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.