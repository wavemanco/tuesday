**Short answer: don't go ahead, and don't send anything.** This is very likely a scam. I can't confirm that Velloway Logistics exists from here, but the requests themselves are the problem.

**Decision: `no_go`.** Three confirmed severe red flags, each of which is enough on its own.

- **Payment for equipment.** The sender asks you to pay €349 by bank transfer to an "equipment partner" for a refund "with your first wages". This request is very likely a scam. Don't pay it.
- **Cheque deposit and transfer.** The sender says they are posting you a cheque for €2,850, asks you to keep €350, and transfer the rest to the equipment partner. This is the classic overpayment scam: the cheque bounces after the money you transfer has gone. This request is very likely a scam. Don't deposit the cheque.
- **Bank, PPS and passport details before any offer.** The sender asks for these before your chat interview. No real employer needs your passport and PPS number at the screening stage. Don't send your IBAN, PPS number or passport photo, to them or anyone else.

The whole process running on Telegram, with no calls or video, is a further warning sign. This job is very likely a scam overall. I'm not saying the firm or the person is a scam. The messages may not come from who they name.

**Fit ledger (your side, separate from the decision):** your background fits the role well. Spreadsheets (your weekly Excel tracker) and attention to detail (60 Zendesk tickets a day, two new starters trained) are `direct`, `medium`. Written English is `direct`, `medium`. A quiet place to work is `unclear`, `low`, because you haven't told me. Your pay floor is a hard gate and is `unclear`. The posting's rate is up to €26/hour for 15–30 hours a week, so about €20,000–€40,000 a year before commission. To reach €30,000 at the full rate you'd need about 22 hours a week, and commission isn't guaranteed.

**Hard gates:** none failed; unconfirmed: R1 (pay floor of €30,000 against the stated rate).

**Severe red flags:** RR1 (`severity: high`): pay for equipment. RR2 (`severity: high`): cheque deposit and transfer. RR3 (`severity: high`): bank, PPS and passport details before an offer. RR4 (`severity: high`): hiring run wholly by chat.

**Hold, before you reply or send anything:** I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**Research tier: L1 — searches 3 of 5, fetches 0 of 2**

| # | Target | Status | What it moved, or would have |
|---|---|---|---|
| 1 | Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers Remote Order Processing Coordinator". Both returned nothing, so the employer is not established. Standing entry: risk signal, medium. |
| 2 | Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland per hour". Pennoral 2026 Ireland Customer Operations Pay Guide (pennoral.example): median salaried base €31,200, interquartile range €28,400–€34,100. `[generic]`, and it excludes commission-only work. |
| 3 | Hiring manager's public footprint | n/a | No hiring manager was named. The only name is the sender's handle, which I didn't research. |

**Verified:** none yet. Your background is your own account and hasn't been probed.

**Dossier offer:** I can write a `tuesday-dossier.md` recording this assessment, if you want it kept.

**Upgrade menu:**
- A link to the live posting on the jobs site where you found it, and Velloway's own careers page. A verified employer and a live posting would clear the employer-not-established entry, but the three severe red flags would still stand.
- Written pay terms with the hours and how commission is calculated, to close R1.

**Questions:**
1. RR1–RR3: have you already paid anything, deposited anything, or sent your IBAN, PPS number or passport photo? If yes, contact your bank now and tell them about the transfer. Answer in text, or say skip.
2. Register: does the sender's address (velloway.hr@postmail.example) match a domain on the company's own website? The address is on a free-mail-style domain, so it doesn't look like the employer's own. Answer in text, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.