**Yes, asking for bank details, a PPS number and a passport scan after a written offer is normal onboarding.** Enter them only in Marrowgate's own portal, at the web address on their own website, not through the link in the email. `conditional_go`: accept on the conditions below.

**Fit ledger.**

- `hard_gate`: unclear: R1, R2, R3
- `must_have`: direct: R4, R6, R7 · unclear: R5 · absent: R8
- `important`: direct: R10 · unclear: R9
- `preferred`: direct: R11

R4, R6 and R7 — three years of fortnightly payroll, reconciliation and starters/leavers, all stated; R5 — Irish PAYE, PRSI and USC, not in your background; R8 — pension changes, which you say you have not done; R1–R3 — right to work, Limerick attendance and pay floor, none confirmed yet.

**Opportunity ledger.** Sound: the €40,000 offer sits inside the advertised €38–42k band, the post is permanent, and you had two in-person interviews at their office (RR4). Unknown: the domain the portal runs on (RR1), the pension scope (RR2), and the contract terms (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (UK-style right to work, here Irish right to work), R2 (Limerick office two days a week), R3 (pay floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for accepting:** (1) the portal address matches the domain on Marrowgate's own website (RR1); (2) you confirm R1 and R2; (3) your pay floor is at or below €40,000 (R3); (4) you receive written terms of employment (RR3).
- **What would change this:** if the portal asks for these details before you have a written offer or a verifiable employer domain, this moves to an unclear case and you should hold. A request for payment, or for details over chat only, would be a red flag.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a Limerick housing association, 240 staff | `[grounded]` job ad |
| Mandate | Monthly payroll, starters/leavers, pension changes, payroll-to-ledger reconciliation, staff queries | `[grounded]` job ad |
| Offer terms | Permanent, €40,000, hybrid two days in Limerick, reporting to Declan Garvagh, Finance Manager | `[grounded]` offer email |
| Onboarding | Bank, PPS and passport details collected in an employer portal after acceptance; original passport on day one | `[grounded]` offer email |
| Unknowns | Notice period, probation, hours, pension scheme, whether you hold right to work, whether you can attend Limerick | — |
| Contradictions | None between the ad and the offer | `[grounded]` both documents |
| Onboarding norm | Payroll and right-to-work checks after a written offer are routine; the original passport check on day one is standard practice | `[generic]` general Irish employment practice, not checked against any source |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Right to work in Ireland | hard_gate | unclear | none | hard_gate | Your status is not stated; the offer's passport check implies it is a gate | `[grounded]` offer | Q1 |
| R2 | Limerick office two days a week | hard_gate | unclear | none | hard_gate | Your location is not stated | `[grounded]` ad and offer | Q1 |
| R3 | Pay floor (€38–42k band) | hard_gate | unclear | none | hard_gate | The offer (€40k) is in band; your floor is not given | `[grounded]` ad and offer | Tell me your floor |
| R4 | Two or more years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff; self-reported, so expect a probe | `[grounded]` your background | Payslip-run or reference proof |
| R5 | Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background is silent on Irish statutory deductions specifically | `[inferred]` from the silence | Q3 |
| R6 | Monthly payroll-to-GL reconciliation | must_have | direct | medium | none | You ran it monthly | `[grounded]` your background | none |
| R7 | Starters and leavers | must_have | direct | medium | none | You ran it at the hotel group | `[grounded]` your background | none |
| R8 | Pension changes | must_have | absent | medium | transferability | You state you have not done pension changes; starter/leaver work may carry over, but that is not established | `[grounded]` your statement; `[inferred]` on the adjacency | Q2 |
| R9 | Answering staff payroll queries | important | unclear | low | discovery | Not stated in your background | `[inferred]` from the silence | Q2 or skip |
| R10 | Strong Excel | important | direct | medium | none | Pivot tables and XLOOKUP stated | `[grounded]` your background | none |
| R11 | Payroll qualification or working towards one | preferred | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish statutory deductions (R5, must_have) | discovery | Strong general payroll; no stated Irish PAYE/PRSI/USC work | A must-have; the first thing a payroll interviewer checks | Live Revenue submissions, USC calculations on a real run, a payroll certificate module covering Irish deductions | A payslip or Revenue return you ran, or the certificate syllabus | `[inferred]` that interviewers probe this |
| G2 | Pension changes (R8, must_have) | transferability | You have never executed pension changes; your manager did | Named in the ad as a duty | Starter enrolment or leaver deductions in your existing work | Your starter/leaver checklist | `[inferred]` adjacency |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer domain not yet verified | unknown | — | "people@marrowgatehousing.ie" | The offer is real, but the portal address must come from their own site | `[inferred]` from the sender domain, unchecked | Which web address does your onboarding portal use, and is it linked from your careers page? | unresolved |
| RR2 | Pension scope unknown | unknown | — | "pension changes" | The role may carry a volume you have not handled | `[inferred]` from the ad's wording | Which pension scheme does this role administer, and how many changes a month? | unresolved |
| RR3 | Contract terms not in the offer | unknown | — | "permanent post" | Notice, probation and hours are not yet written down | `[inferred]` from the offer's silence | Can you send the written statement of terms with the offer? | unresolved |
| RR4 | Pay and interviews consistent | positive_signal | — | "€40,000 a year" | The offer matches the advertised band, and you met them in person | `[grounded]` ad, offer, interviews | none needed | noted |

Nothing here is a red flag: the request follows a written offer that names the role and the pay.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Find Marrowgate's own website yourself; compare its careers page and portal domain with the offer email | RR1 | `[grounded]` RR1 | proposed |
| P2 | Ask for the written statement of terms before you accept | RR3 | `[grounded]` RR3 | proposed |
| P3 | Enter bank, PPS and passport details only in the portal; send the original passport on day one, not a scan by email | Onboarding norm | `[generic]` practice | proposed |
| P4 | Prepare an Irish PAYE/PRSI/USC example to talk through | R5 | `[inferred]` from G1 | proposed |
| P5 | Ask the pension questions before accepting | RR2, R8 | `[grounded]` RR2 | proposed |

Accepting is your call. You need not share any details before you accept; you can ask for terms and check the portal first.

## Evidence status

Verified: none yet. Everything above rests on what you have told me in this conversation and on the two documents you pasted, so it is your own word, not checked evidence.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Web search was refused by a permission prompt, so I could not check the employer's domain or whether the post is live; this would have moved RR1 |
| 2. Role-family sweep | unavailable | Same refusal; this would have set a Limerick payroll-administrator pay band against the €40k offer |
| 3. Hiring manager's public footprint | unavailable | Same refusal; this would have shaped how you present to Declan Garvagh |

## Upgrade menu

- Once search is permitted: the employer's own site and careers page, and a Limerick pay band → RR1 and the pay read close.
- The written statement of terms → RR3 closes and the decision may move to `go`.
- Pension detail from the employer, or an example of starter/leaver work touching enrolment → R8 moves up.
- A payslip or Revenue return you have run → R5 moves to `high`.
- A deeper research pass on Marrowgate (leadership, past reports, staff reviews; up to 5 more searches and 2 more fetches) — say the word and it runs once search is permitted.

If you want, I can turn this into a `tuesday-dossier.md` you can keep for the negotiation.

Questions (answer in text, paste a voice transcript, attach a document, drop a link, or say skip):

- **Q1 (R1, R2):** Do you have the right to work in Ireland without sponsorship, and is two days a week in Limerick workable for you?
- **Q2 (R8, R9):** Have you ever handled pension enrolment, contribution changes or leaver pension deductions, even if your manager did the final step? And have you answered staff payroll queries directly?
- **Q3 (R5):** Have you run Irish PAYE, PRSI or USC on a live payroll, or is that knowledge from the certificate?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.