**Yes, apply, on conditions.** Aoife, your NMC registration, full licence and five years' post-registration experience meet the essentials, and the employer checks out. Verdict: `conditional_go`.

**Fit ledger.**

- `hard_gate`: direct: R1, R2, R3
- `must_have`: direct: R4, R5a, R6a, R7a · adjacent: R5b (leg-ulcer care) · unclear: R7b (care planning), R9 (clear, timely written records)
- `important`: adjacent: R10 (own caseload) · unclear: R6b (continence care), R8 (end-of-life visits)
- `preferred`: absent: R11 (Doppler assessment)

R4, R5a, R6a and R7a are direct, and R5b is a credible bridge with its limit named. R9 and R7b are must-haves your CV does not evidence, so they are the interview risk.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger.** Sound: an established CIC with an NHS contract (RR3) and an in-house Doppler training path (RR4). Open: contract basis and live status (RR1), caseload size and on-call (RR2).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a CIC founded 2015 with 410 staff, running adult community nursing across Calderdale under an NHS contract | `[grounded]` About page, search snippet |
| Mandate | Home-based district nursing, own small caseload, senior nurse support, EPR records | `[grounded]` posting |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` posting |
| Market calibration | Wardround 2026 (n=1,240, England): median £34,300, IQR £32,400–£36,600; 61% paid mileage. The posting's midpoint sits near the median; its bottom is below the IQR | `[generic]` band, `[grounded]` survey |
| Contradictions | None; Halifax is within Calderdale | — |
| Unknowns | Contract basis, live status, caseload size, on-call | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | NMC registration, Adult | hard_gate | direct | medium | none | Stated in CV; registration active, revalidation March 2028 | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B stated; not inspected | `[grounded]` CV | none |
| R3 | Work base Halifax | hard_gate | direct | medium | none | You live in Halifax | `[grounded]` CV | none |
| R4 | ≥1 year post-registration | must_have | direct | medium | none | Five years as staff nurse | `[grounded]` CV | none |
| R5a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5b | Leg-ulcer care | must_have | adjacent | low | transferability | Wound care is general; leg ulcers not named | `[inferred]` from R5a | Bridge case, not a claim |
| R6a | Catheter care | must_have | direct | medium | none | Stated in CV | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | low | discovery | Not in CV | `[grounded]` CV silence | Question Q3 |
| R7a | Insulin administration | must_have | direct | medium | none | Stated in CV | `[grounded]` CV | none |
| R7b | Care planning | must_have | unclear | low | discovery | Discharge assessment may involve planning; not stated | `[inferred]` | Question Q2 |
| R8 | End-of-life visits | important | unclear | low | discovery | Not in CV | `[grounded]` CV silence | Question Q2 |
| R9 | Clear, timely written records; EPR | must_have | unclear | low | discovery | Not in CV | `[grounded]` CV silence | Question Q1 |
| R10 | Own caseload with senior support | important | adjacent | medium | transferability | Seconded home visits to patients in first week after discharge; no caseload held | `[grounded]` CV | Bridge, with limit stated |
| R11 | Doppler assessment | preferred | absent | none | capability | You have never done one | `[grounded]` CV | Training path, RR4 |

**Gap recovery queue** (the questions sit in the closing block)

| # | Gap (req) | Type | What I see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R5b) | transferability | General wound work; leg ulcers not named | Named in the posting's first clinical line | A leg-ulcer dressing or compression example | `[grounded]` CV |
| G2 | Records and EPR (R9) | discovery | No documentation evidence | Essential "clear, timely" records, and interviewers ask | An EPR name and a redacted note | `[grounded]` CV silence |
| G3 | Care planning (R7b) | discovery | Not stated | Must-have | A redacted care plan or handover | `[inferred]` |
| G4 | End-of-life, continence (R8, R6b) | discovery | Not stated | Named in the posting's list | Any relevant case | `[grounded]` CV silence |
| G5 | Caseload (R10) | transferability | Home visits, no caseload | Posting says "hold a small caseload" | Caseload-like examples | `[grounded]` CV |
| G6 | Doppler (R11) | capability | Never done | Preferred only | Training record, if any | `[grounded]` CV |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Live status and contract basis not confirmed | unknown | — | "Current vacancies are listed on our careers page" | The post may be fixed-term, or no longer live | `[inferred]` from the posting's silence and the search snippet | Is this Community Staff Nurse post live on your careers page, and is it permanent or fixed-term? | unresolved |
| RR2 | Caseload size and on-call not stated | unknown | — | "a small caseload of your own" | "Small" may be unquantified, and out-of-hours duty is unstated | `[inferred]` | What is the typical caseload for this post, and is there on-call or out-of-hours work? | unresolved |
| RR3 | Employer established | positive_signal | — | "adult community nursing … under an NHS contract"; 410 staff | An established employer with a stable contract base | `[grounded]` About page snippet | Who are the four locality hubs' nurse leads? | noted |
| RR4 | In-house Doppler training | positive_signal | — | "Doppler training for staff new to community work" | Doppler may be trainable in post | `[grounded]` public forum talk, Rhiannon Mabbott | Is Doppler training offered to new community staff, and when? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the post is live and its contract basis before applying | RR1 | `[grounded]` RR1 | pending your approval |
| P2 | Ask RR2's questions in the informal chat with Rhiannon Mabbott | RR2 | `[grounded]` RR2 | pending your approval |
| P3 | Gather a redacted record or care-plan example for R9 and R7b, if you have one | G2, G3 | `[grounded]` rows | pending your approval |
| P4 | Present home-visit work as the bridge to a caseload, and claim no caseload or leg-ulcer experience | R5b, R10 | `[grounded]` CV | pending your approval |

**Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and a careers query; found the About page (calderbrookhealth.example/about) from the snippet. Careers page not fetched, so RR1 stays open; RR3 rests on that snippet |
| 2. Role-family sweep | yes | Searched "community staff nurse band 5 district nursing salary UK 2026"; Wardround 2026 pay guide (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook"; forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). Used for RR4 and the team-lead footprint |

**Verified: none yet.** Your CV claims stand as leads until you confirm them in writing.

I can write this up as a `tuesday-dossier.md` you can reuse for interview prep.

**Upgrade menu**

- A redacted record, handover or care-plan example → R9 and R7b move from `low`.
- The careers-page link and the contract basis → RR1 closes.
- Any Doppler or leg-ulcer training record → R11 or R5b moves.
- A pay floor and contract preference → the hard-gate checks run against them.
- A deeper research pass on Calderbrook Community Health (funding, leadership changes, public staff and candidate reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

- Q1 (R9): Which electronic patient record have you documented in, and how did you record one home visit from start to finish?
- Q2 (R7b, R8): Have you owned a patient's care plan beyond the first week after discharge, or been with a patient at end of life at home?
- Q3 (R5b): Have you assessed or dressed a leg ulcer, and what would a Doppler assessment have changed in that care?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.