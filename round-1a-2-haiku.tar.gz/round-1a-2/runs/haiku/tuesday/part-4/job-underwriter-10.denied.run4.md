**Yes, it's worth going on, as a conditional go.** You've already applied, the role lines up with your strongest work, and the 45-minute call is the right next step. I could not check whether Fernquay is legitimate: the web-search permission wasn't granted in this session, so the only sources are the posting and the WhatsApp message. The posting asks you for nothing that would signal a scam: no fee, no deposit, no bank details.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (€52,000–€60,000 pay); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the role appears on Fernquay's own careers page and the company's registered name matches; (2) €52,000 clears your pay floor; (3) the equity terms are workable once stated.

**Fit ledger**
- `hard_gate` — direct: R1 · unclear: R2 (€52,000–€60,000 pay)
- `must_have` — direct: R3, R4, R5, R8 · adjacent: R6 (own the booking flow end to end), R7 (research calls with school owners)
- `important` — unclear: R9 (working as the only designer)

R6 — a checkout redesign, not end-to-end flow ownership; R7 — consumer usability sessions, not owner interviews; R9 — no evidence either way yet.

**Opportunity ledger.** The posting is specific about scope, pay, location and the first step (RR4). Three things are unverified: the employer (RR1), decision rights (RR2) and equity (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting's own claim, not verified |
| Mandate | First designer: own the booking flow, run research with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two days a week at the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Market calibration | Not run: the search was refused, so whether this band fits Galway product design is unchecked | — |
| Unknowns | Decision rights, equity terms, contract type | — |
| Contradictions | None inside the posting | `[grounded]` posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Galway-based hybrid, two office days | hard_gate | direct | medium | none | You moved back to Galway last year (stated, not inspected) | `[grounded]` your statement | none |
| R2 | Pay €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | No floor given | `[grounded]` posting | Ask your floor |
| R3 | 3+ years product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company | `[grounded]` your statement | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use, no artifact yet | `[grounded]` your statement | none |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers | `[grounded]` your statement | none |
| R6 | Own booking flow end to end | must_have | adjacent | medium | transferability | Redesigned checkout, part of the flow; ownership beyond it not stated | `[inferred]` from checkout work | Checkout case study as the artifact |
| R7 | Research calls with school owners | must_have | adjacent | medium | transferability | Customer research, but consumers, not small-business owners | `[inferred]` from consumer sessions | Ask for B2B experience |
| R8 | Works directly with engineers | must_have | direct | medium | none | Squad of four engineers | `[grounded]` your statement | none |
| R9 | Works as the only designer | important | unclear | medium | discovery | You have never been the only designer; no evidence either way beyond that | `[grounded]` your statement | Ask |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | Owner-facing research (R7, R6) | transferability | Consumer usability sessions; no owner interviews | Owner research is the core of the job | A session plan or summary from non-consumer users | `[inferred]` from your consumer work |
| G2 | Working without design peers (R9) | discovery | Squad experience; no sole-designer role | The posting says "first designer" | Any stint as the only designer, even short | `[grounded]` your statement |
| G3 | Pay against your floor (R2) | hard_gate | Band stated; floor unknown | Decides whether the role is viable | Your number | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "We are six people in Galway making booking software" | The company may be too new or small to have a web footprint, or the posting may be stale | `[generic]` pattern for companies this size, not a claim about this one | "Can you point me to this role on Fernquay's own careers page, and confirm the company's registered name?" | unresolved |
| RR2 | Accountable without decision rights | unknown | — | "own the booking flow end to end" | You may carry the flow without final say on product or engineering priorities | `[inferred]` from the scope language against silence on decision rights | "Which booking-flow decisions would I make alone, and which go to you or Saoirse?" | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | Vesting, strike price or conditions may change what the equity is worth | `[generic]` small-company equity usually carries terms | "What are the vesting schedule, cliff and exercise price, and is it options or shares?" | unresolved |
| RR4 | Pay and scope stated | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | Transparent pay and a defined first-year scope | `[grounded]` posting | "Is €52,000–€60,000 fixed, or does it depend on the level hired?" | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check Fernquay's careers page and the company's registered name before the call | RR1 | `[generic]` pattern | your action |
| A2 | Confirm the calendar invite comes from Fernquay's own domain | RR1 | `[generic]` standard check | your action |
| A3 | Put RR2 and RR3 to Ronan and Saoirse on the call | RR2, RR3 | `[grounded]` register | your action |
| A4 | Settle your pay floor against €52,000 before the call | R2 | `[grounded]` R2 | your action |

## Evidence status

Verified: none yet. Your background is still unprobed.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Fernquay Galway booking software sea kayak surf schools", "Fernquay Product Designer jobs Galway") were refused before returning anything. Would have checked that the company exists and the role is live, which RR1 depends on |
| 2. Role-family sweep | unavailable | One search ("product designer salary Ireland 3 years experience Galway") refused. Would have set market calibration for the pay band |
| 3. Hiring manager's public footprint | unavailable | One search ("Ronan Kehoe Fernquay co-founder") refused. Would have checked Ronan's public professional footprint |

The permission was declined in this session, so I did not retry.

Want me to save this as `tuesday-dossier.md`, so the register's questions travel with you into the call?

**Upgrade menu**
- Search permission granted → targets 1–3 run, and RR1 can clear or stay open on evidence.
- A live link to the posting → RR1 narrows.
- Your pay floor → R2 closes.
- A public link to the checkout case study → R6 can rise.
- A session plan from non-consumer research → R7 narrows.

**Questions**
- R2 — What's your pay floor, and does €52,000 clear it?
- R9 — Have you ever been the only designer on anything, even a contract or a short stint?
- R7 — Have you run research with small-business owners, even informally, and how did those sessions differ from the consumer ones?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.