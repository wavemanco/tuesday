**Worth going ahead with, and it looks like a real company. Status: `conditional_go`.** You fit the stated requirements R1–R4 on your own account. Your main gap is the one the posting itself implies: being the only designer (R5). Going into the call, check the three conditions below.

**Fit ledger.**

- `hard_gate`: unconfirmed: H1 (2 days a week at the Galway office), H2 (€52,000–€60,000 salary)
- `must_have`: direct: R1 (3+ years product design), R2 (strong Figma), R3 (ran own user research), R4 (works directly with engineers) · adjacent: R5 (own the booking flow end to end)
- `important`: adjacent: R6 (research calls with school owners)
- `preferred`: adjacent: R7 (booking-domain knowledge)

R5 — the first-designer scope, with no design peers, is the real gap. R3 (`medium`) — the usability sessions were with travel customers, not school owners.

**Opportunity ledger.** The employer is established: Fernquay's About page describes a six-person Galway company selling Kelproster to sea-kayak, surf and sailing schools (RR4). The posted pay sits inside the market band (RR5). Open questions: what the equity is worth (RR3), who sets product priorities (RR1), and I could not find the posting on a careers page (RR2).

- **Hard gates:** none failed; unconfirmed: H1 (2 days a week at Galway office), H2 (€52,000–€60,000 salary); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found. The posting and the WhatsApp message ask you for no money, no bank details, and no chat-only interview.
- **Conditions for go:** (1) RR2: the role is confirmed on Fernquay's own site or in the calendar invite's domain; (2) H1 and H2 both work for you; (3) RR1 and RR3 get concrete answers on the call.
- **What would change this:** a pay floor above €60,000, or a refusal to commit to the Galway office days, would move this to `no_go` on the gate.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, makes Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland, founded 2023 | `[grounded]` fernquay.example/about |
| Scope | First designer owning the booking flow, research with school owners, shipping with two engineers | `[inferred]` from "first designer" and "own the booking flow end to end" |
| Market calibration | Tillerby 2026 Ireland survey, 3–5 years: median €57,000, IQR €51,500–€62,000 (n=520). The posted €52,000–€60,000 sits inside it | `[generic]` role-family sweep; `[grounded]` posted range |
| Contract and equity | Equity of 0.5–1%, with no vesting, option type or share count stated | — |
| Contradictions | The WhatsApp message calls Saoirse "our CTO"; the About page names Saoirse Doyle as a co-founder with no title | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| H1 | 2 days a week at Galway office | hard_gate | unclear | medium | hard_gate | You say you moved back to Galway; you did not say whether two office days suit you | `[grounded]` your statement | Q2 below |
| H2 | €52,000–€60,000 salary | hard_gate | unclear | none | hard_gate | No pay floor was given, so the band cannot be checked | `[grounded]` posting | Q1 below |
| R1 | 3+ years product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, stated in prose, not yet inspected | `[grounded]` your statement | none |
| R2 | Strong Figma | must_have | direct | medium | none | Daily use, stated; a Figma link would raise this to `high` | `[grounded]` your statement | ask for a file link |
| R3 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers; these were travel customers, not school owners | `[grounded]` your statement | none |
| R4 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad, stated | `[grounded]` your statement | none |
| R5 | Owns a booking flow end to end, as the only designer | must_have | adjacent | medium | transferability | You redesigned the checkout flow, but never worked as the only designer. Limit: no experience setting the design process alone | `[inferred]` from "first designer" | a checkout case study showing which calls were yours |
| R6 | Research calls with school owners | important | adjacent | medium | transferability | Customer usability work carries over; B2B school owners are a different customer type | `[inferred]` from your usability work | prep one question set for school owners |
| R7 | Booking-domain knowledge | preferred | adjacent | medium | transferability | Travel booking is the nearest domain; sea-kayak and surf schools are different | `[inferred]` | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Sole designer (R5) | transferability | Checkout redesign is real; no time as the only designer | This is the objection most likely to come up on the call | A checkout case study with your own decisions marked, and the team's decisions marked separately | `[inferred]` from the posting; `[generic]` that a first-designer hire is probed on this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Decision rights for a sole designer | unknown | — | "You would be our first designer" | You may have to set process and priorities alone, with no design review | `[inferred]` from the posting's silence on decision rights | Who decides which parts of the booking flow I work on first, and who signs off a design before it ships? | unresolved |
| RR2 | Posting not confirmed live | unknown | — | "Product Designer — Fernquay" | I could not reach a careers page on the company's site (my guessed path returned nothing), so the posting is unverified, not shown to be fake | `[generic]` for small firms without an easy-to-find careers page | Can you point me to this role on Fernquay's own careers page? | unresolved |
| RR3 | Equity terms | unknown | — | "0.5–1% equity" | The equity could be worth little or a lot depending on share count and vesting | `[inferred]` from the missing terms | What does 0.5–1% mean: options or shares, fully diluted, with what vesting and strike price? | unresolved |
| RR4 | Title discrepancy | risk_signal | low | "Saoirse, our CTO" (WhatsApp) vs "Saoirse Doyle" as co-founder (About page) | Saoirse may hold both roles; the sources do not say | `[grounded]` both sources | What is Saoirse's role at Fernquay? | unresolved |
| RR5 | Pay inside market band | positive_signal | — | "€52,000–€60,000" | The posted pay is not below the typical band, so the risk is low | `[generic]` Tillerby 2026 band | Is there room in the range for someone with four years' experience? | noted |

The WhatsApp message itself is not a signal. Scheduling by chat is normal, Ronan Kehoe's name and role match a public LinkedIn profile as co-founder, and the invite should come from the company's own email domain. Check that before you join.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check the calendar invite's sender domain and ask for the posting link | see RR2, RR4 | `[grounded]` register | pending your approval |
| A2 | Prepare the checkout case study with your own decisions marked, separately from the team's | see G1, R5 | `[inferred]` from R5 | pending your approval |
| A3 | Ask RR1 and RR3 on the call, word for word | these are the open decision questions | `[grounded]` register | pending your approval |

For the call itself, the mock-interview module can prepare you for it if you ask.

## Evidence status

Verified (your own statements, not yet inspected): R1, R2, R3, R4, R5 (checkout redesign), R6, R7. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea kayak surf schools"; fetched fernquay.example/about (Kelproster, six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle). fernquay.example/careers returned no page. Moved: employer established; posting liveness unconfirmed (RR2) |
| 2. Role-family sweep | yes | Searched "Product Designer salary Ireland 3 years experience Dublin Galway 2026", which returned Tillerby 2026 Ireland Design Salary Report (tillerby.example/2026-ireland-design-salary-report): 3–5 years, median €57,000, IQR €51,500–€62,000. Moved: market calibration (RR5) |
| 3. Hiring manager's public footprint | yes | Searched "Fernquay Ronan Kehoe co-founder", which returned the LinkedIn profile linkedin.example/in/ronan-kehoe: co-founder and CEO at Fernquay, previously product lead at a Galway travel-software company for five years. Moved: confirms the WhatsApp sender's name and role |

**Questions** (answer in text, paste a voice transcript, attach a document, drop a link, or say skip):

- H2: Is there a pay floor below which this would be a no?
- H1: Does two days a week in the Galway office work for you?
- RR2: Can you send the link to this role on Fernquay's careers page?

**Upgrade menu:**

- The live posting link → RR2 closes.
- A Figma file or a checkout case study with your decisions marked → R2 and R5 move toward `high`.
- Your pay floor → H2 closes.
- Whether two office days suit you → H1 closes.
- A deeper research pass on Fernquay (funding, leadership, public reviews; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can save this as a `tuesday-dossier.md` for reuse.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.