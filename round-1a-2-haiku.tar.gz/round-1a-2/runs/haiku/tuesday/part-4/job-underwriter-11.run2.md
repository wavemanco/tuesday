**Duinvaart (Operations Analyst, Rotterdam): worth your time, once one question is answered. `hold_pending_answers`.** You meet the three must-haves on your stated background. The open point is whether you can commit to three office days a week in Rotterdam.

**Kroonhaven (Supply Planner, Utrecht): not worth your time now. `no_go`.** Two must-haves are absent from your background: 3+ years of FMCG planning (R2b) and SAP IBP or a similar planning system (R4). You've said you've never worked in planning, and neither gap closes in a single application cycle.

Research tier: L1, with the web searches refused, so no employer or salary check ran (see the evidence status below).

## Duinvaart: decision snapshot

- `hard_gate`: unclear: R1 (Rotterdam office, three days a week)
- `must_have`: direct: R2 (2+ years logistics or operations analysis), R3 (strong SQL), R4 (Power BI or Tableau)
- `important`: direct: R5a (on-time delivery tracking), R6 (weekly Power BI dashboards), R7 (route changes with depot managers) · unclear: R5b (temperature compliance)
- `preferred`: adjacent: R8 (Dutch a plus)

R2–R4 — your stated background covers them; R5b — the one requirement with no evidence yet; R8 — conversational Dutch against "a plus".

- **Hard gates:** none failed; unconfirmed: R1 (Rotterdam office, three days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** a yes on R1 moves this to `conditional_go`, conditional on the employer check in RR1.

## Duinvaart: role reality, evidence map, risks

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Rotterdam office, three days a week | hard_gate | unclear | none | hard_gate | No constraint stated by you, so nothing to grade | `[grounded]` posting | Q1 |
| R2 | 2+ years logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier, self-reported | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | Daily SQL use, self-reported | `[grounded]` your background | a sample query would raise to high |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use, self-reported | `[grounded]` your background | none |
| R5a | Track on-time delivery across the fleet | important | direct | medium | none | You built the on-time delivery dashboard depot managers use | `[grounded]` your background | none |
| R5b | Track temperature compliance across refrigerated fleet | important | unclear | none | discovery | Nothing in your background touches temperature data | `[inferred]` gap read from silence | Q2 |
| R6 | Weekly dashboards in Power BI | important | direct | medium | none | Same artefact type as your current dashboard | `[grounded]` your background | none |
| R7 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review | `[grounded]` your background | none |
| R8 | Dutch (a plus) | preferred | adjacent | medium | transferability | Conversational, not fluent. Limit: probably not enough for depot-manager conversations in Dutch | `[grounded]` self-report | minor risk |

**Gap queue (no questions here; they sit in the closing block):**
- G1 (R1, hard_gate): closes when you confirm whether three office days in Rotterdam are workable.
- G2 (R5b, discovery): closes with any temperature or cold-chain reporting you have built or used.
- G3 (R8, transferability): a short Dutch writing sample would show the real level.

**Risk register:**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established (not checked this turn) | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | Searches were refused, so the employer's existence and the posting's live status are unverified | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I interview with? | unresolved; caps the decision at `conditional_go` |
| RR2 | Salary not stated | unknown | — | "—" | The posting withholds the figure | `[grounded]` posting | What salary is budgeted for this role? | unresolved |
| RR3 | Contract type not stated | unknown | — | "—" | The posting is silent on permanent or fixed-term | `[grounded]` posting | Is this post permanent or fixed-term? | unresolved |
| RR4 | Concrete KPIs named | positive_signal | — | "Track on-time delivery and temperature compliance" | Scope is specific and measurable | `[grounded]` posting | Which of these two KPIs does this role own outright? | noted |

**Application plan (proposed; pending your approval):**
- E1: Lead your CV with the on-time delivery dashboard and the route-performance review (R5a, R7). `[grounded]` your background.
- A1: Check the posting on Duinvaart's own careers page before you apply (RR1). This one is yours to do.
- If you go ahead, resume-tailor can do the CV edit against this posting.

## Kroonhaven: decision snapshot

- `hard_gate`: unclear: R1 (on-site in Utrecht)
- `must_have`: adjacent: R2a (3+ years supply or demand planning), R5 (own the 13-week plan and run S&OP), R6 (fluent Dutch) · absent: R2b (3+ years in FMCG), R4 (SAP IBP or a similar planning system) · unclear: R3 (advanced Excel)

R2b and R4 — no evidence, and you've said you've never worked in planning; R2a and R5 — transferable from the route-performance review, but no forecast or capacity ownership; R6 — conversational against fluent; R3 — no Excel evidence in your background.

- **Hard gates:** none failed; unconfirmed: R1 (on-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** a different target. A planning-analyst or demand-planner post is the realistic next step; R2b and R4 can't be fixed by changing this application.

## Kroonhaven: evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Location term; no constraint stated by you | `[grounded]` posting | Q1 |
| R2a | 3+ years of supply or demand planning | must_have | adjacent | medium | transferability | Operations analysis and delivery performance at a carrier, not planning. Limit: no forecast, capacity or plan ownership | `[grounded]` your background; `[inferred]` adjacency | none |
| R2b | 3+ years in FMCG | must_have | absent | none | capability | No FMCG in your background | `[grounded]` your background | closure path: a planning role in a sector, measured in years |
| R3 | Advanced Excel | must_have | unclear | low | discovery | Not mentioned | `[inferred]` gap read from silence | Q3 |
| R4 | SAP IBP or similar planning system | must_have | absent | none | capability | No planning system in your background | `[grounded]` your background | closure path: a planning-system course or sandbox; not a short gap |
| R5 | 13-week plan, capacity vs forecast, weekly S&OP | must_have | adjacent | medium | transferability | Weekly cross-functional review and KPI work. Limit: no capacity or forecast ownership | `[grounded]` your background; `[inferred]` adjacency | none |
| R6 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, self-reported; the posting says fluent | `[grounded]` self-report | a Dutch work sample would show the real level |

**Gap queue:** G1 (R2b, capability), G2 (R4, capability), G3 (R3, discovery), G4 (R6, transferability). The questions for G1–G3 are in the closing block.

**Risk register:**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established (not checked this turn) | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Searches were refused, so the employer's existence and the posting's live status are unverified | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I interview with? | unresolved |
| RR2 | Salary not stated | unknown | — | "—" | The posting withholds the figure | `[grounded]` posting | What salary is budgeted for this role? | unresolved |
| RR3 | Forecast ownership unclear | unknown | — | "Own the 13-week supply plan" | You may own the plan but not the forecast it balances against | `[inferred]` from "own" against silence on forecast input | Who owns the demand forecast, and what decision rights come with the capacity balance? | unresolved |
| RR4 | Clear meeting cadence | positive_signal | — | "run the weekly S&OP meeting" | A defined recurring forum, so the role has a visible rhythm | `[grounded]` posting | — | noted |

**Application plan (proposed; pending your approval):**
- A2: Don't apply to this post now. Look for a demand or supply planning-analyst role, and check its requirements against R2b and R4 before you apply. `[inferred]` from R2b and R4 being absent.

## Evidence status

Verified: none yet. Everything above rests on your message, which is self-report and capped at `medium`. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches (Duinvaart Cold Chain Rotterdam; Kroonhaven Foods Utrecht) were refused because web search permission was not granted. Would have settled RR1 for both postings |
| 2. Role-family sweep | unavailable | Two salary searches (operations analyst, Rotterdam; FMCG supply planner, Utrecht) were refused. Would have set the market band for each title; no band is given from memory |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Web search access: the employer check and salary bands for both postings (RR1 and RR2 on each).
- A dashboard screenshot or a sanitised cold-chain report: R5b moves to `high` if it shows temperature compliance.
- A sanitised SQL query or Power BI screenshot: R2–R4 move from `medium` to `high`.
- A sample workbook showing your Excel work: R3 moves from `low`.
- A Dutch paragraph you've written: R6 (Kroonhaven) and R8 (Duinvaart) get a real level.
- The recruiter's answer on contract type and salary: RR2 and RR3 close.

If you want these two assessments kept as a `tuesday-dossier.md` you can reuse, say so and I'll write it.

1. **Q1 (R1, both postings):** Where are you based now, and can you commit to Rotterdam three days a week, or to Utrecht on site?
2. **Q2 (R5b, Duinvaart):** Have you handled temperature or cold-chain data, such as logger readings, excursion reports or a compliance KPI? A rough description is fine.
3. **Q3 (R3, Kroonhaven):** How would you rate your advanced Excel? Have you built forecast or capacity models with pivots, lookups or Power Query?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.