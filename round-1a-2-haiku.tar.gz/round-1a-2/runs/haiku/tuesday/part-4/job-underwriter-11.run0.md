## Short answer

- **Duinvaart Cold Chain (Operations Analyst): worth applying, conditionally.** Status `conditional_go`. Your core skills match, and the gaps are narrow.
- **Kroonhaven Foods (Supply Planner): not worth your application time now.** Status `no_go`. The role needs years of planning experience you've said you don't have.

Web search was refused in this session, so neither employer was checked on its own site and no salary band was set. Details below.

---

## Duinvaart Cold Chain, Operations Analyst, Rotterdam

**Status: `conditional_go`.** Apply if the three-day Rotterdam pattern works for you and the posting checks out on Duinvaart's own site.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, three days a week in Rotterdam office)
- `must_have`: direct: R2 (2+ years logistics or operations analysis), R3a (track on-time delivery), R4 (weekly dashboards in Power BI), R5 (strong SQL) · absent: R3b (track temperature compliance across refrigerated fleet)
- `important`: adjacent: R6 (work with depot managers on route changes)
- `preferred`: adjacent: R7 (Dutch a plus)

R3b — the temperature-compliance half of the cold-chain must-have, with no evidence stated; R6 — your route-performance review is near this, not the same thing; R1 — a gate the material does not settle.

**Opportunity ledger.** Concrete scope and named outputs (RR3, positive). Pay is not stated (RR2). The employer is not verified (RR1).

**Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown.

**Severe red flags:** none found.

**What would change this:**
- If R1 fails, the status becomes `no_go`, because a failed gate caps the decision.
- If the employer and posting verify on Duinvaart's own careers page (RR1), the status moves toward `go`.
- Answering R3b honestly as "no cold-chain experience" does not sink the application. Present it as a gap, not a skill.

**Role reality.** Organization: Duinvaart Cold Chain, Rotterdam, `[grounded]` from your posting only; not verified. Market calibration: not run, so there is no pay band. Contradictions: none visible in the material.

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, 3 days/week in Rotterdam office | hard_gate | unclear | none | hard_gate | Your home base and commute are not in the material | `[grounded]` posting | Q1 below |
| R2 | 2+ years logistics or ops analysis | must_have | direct | medium | none | 4 years as operations analyst at a parcel carrier; self-reported, no artifact yet | `[grounded]` your message | Offer a CV document |
| R3a | Track on-time delivery | must_have | direct | medium | none | Built and used the on-time dashboard depot managers rely on; self-reported | `[grounded]` your message | Same as R2 |
| R3b | Track temperature compliance, refrigerated fleet | must_have | absent | none | discovery | No temperature or cold-chain work stated | `[grounded]` silence in your message | Q2 below |
| R4 | Weekly dashboards in Power BI (or Tableau) | must_have | direct | medium | none | Power BI daily, including the on-time dashboard; confirm whether you built or maintained it | `[grounded]` your message | Confirm ownership |
| R5 | Strong SQL | must_have | direct | medium | none | SQL daily; "strong" is self-assessed | `[grounded]` your message | None |
| R6 | Work with depot managers on route changes | important | adjacent | medium | transferability | Ran the weekly route-performance review. Limit: no statement that you changed routes | `[inferred]` adjacency from the review | Say what the review changed, if anything |
| R7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational, not fluent | `[grounded]` your message | None |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified (search refused) | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The posting may be stale or aggregated, or the employer may not match its description | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | (no pay line in posting) | The role may pay within the usual band, or pay may be withheld | `[inferred]` from the posting's silence on pay | What salary is budgeted for this role? | unresolved |
| RR3 | Concrete scope and outputs | positive_signal | — | "build weekly Power BI dashboards" | Clear, measurable work with defined outputs | `[grounded]` posting | Which of the weekly dashboards already exist, and who owns them? | noted |

**Application plan (pending your approval).** Lead with the on-time dashboard depot managers used, in your own words, unchanged. Do not claim cold-chain or temperature work. Pending your approval.

---

## Kroonhaven Foods, Supply Planner, Utrecht

**Status: `no_go`.** Don't spend application effort on this one as it stands. Its core is 13-week planning and S&OP, and you've said you've never worked in planning.

**Fit ledger.**

- `hard_gate`: unclear: R1 (On-site in Utrecht)
- `must_have`: adjacent: R2 (fluent Dutch), R3 (3+ years supply or demand planning in FMCG), R5 (run the weekly S&OP meeting) · unclear: R6 (SAP IBP or a similar planning system) · absent: R4 (own the 13-week supply plan, balancing capacity against forecast)
- `important`: unclear: R7 (advanced Excel)

R4 — the core of the role, and you've said you've never worked in planning; R3 (`low`) — route-performance work is performance measurement, not forecasting or supply planning; R2 — conversational Dutch against a fluent requirement; R6 and R7 — not stated, so unclear.

**Opportunity ledger.** Clear scope and a defined horizon (RR1, positive). Pay not stated (RR3). Employer not verified (RR2). Whether the work runs in Dutch is unknown.

**Hard gates:** none failed; unconfirmed: R1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.

**Severe red flags:** none found.

**What would change this:**
- A planning track record (years of demand or supply planning) would move R3 and R4. A CV edit cannot supply that.
- The realistic route is a planning-analyst or junior-planner role, which asks for fewer planning years. `[generic]` pattern for this role family, not a claim about Kroonhaven.

**Role reality.** Organization: Kroonhaven Foods, Utrecht, `[grounded]` from your posting only; not verified. Market calibration: not run.

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your base and commute are not in the material | `[grounded]` posting | Q1 applies to location |
| R2 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent. Limit: a planning role may run in Dutch | `[grounded]` your message | Ask whether the work runs in Dutch (RR2) |
| R3 | 3+ years supply or demand planning, FMCG | must_have | adjacent | low | transferability | Delivery-performance analysis is near forecasting but has no planning horizon or FMCG work. Limit named | `[inferred]` from your message | None; years are not closable from a CV |
| R4 | Own the 13-week supply plan, balance capacity vs forecast | must_have | absent | medium | capability | You said you've never worked in planning | `[grounded]` your message | Closure path: planning-analyst role |
| R5 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | Ran a weekly route-performance review. Limit: not cross-functional demand, supply and production | `[inferred]` adjacency | None |
| R6 | SAP IBP or a similar planning system | must_have | unclear | none | discovery | No planning system mentioned | `[grounded]` silence in your message | Confirm any exposure |
| R7 | Advanced Excel | important | unclear | none | discovery | Excel not mentioned; SQL and Power BI are | `[grounded]` silence in your message | Confirm Excel level |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Clear scope and horizon | positive_signal | — | "own the 13-week supply plan" | Well-defined planning mandate | `[grounded]` posting | Which production lines and forecast horizons does this plan cover? | noted |
| RR2 | Working language may be Dutch | unknown | — | "fluent Dutch" | The planning work may run in Dutch throughout | `[inferred]` from the language requirement | Is the S&OP meeting and planning work run in Dutch? | unresolved |
| RR3 | Pay not stated | unknown | — | (no pay line in posting) | Pay may be withheld | `[inferred]` from the posting's silence on pay | What salary is budgeted for this role? | unresolved |
| RR4 | Employer not verified (search refused) | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The posting may be stale or aggregated, or the employer may not match its description | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |

---

## Evidence status

Verified: none yet. Your background is self-report, so every claim is a lead until you give an artifact.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page (both employers) | unavailable | Both calls were refused (permission not granted). Would have checked that each employer exists as described and each posting is live (RR1 and RR4) |
| 2. Role-family sweep (both titles) | unavailable | Both calls were refused. Would have set the pay band and scope norm for each title (RR2 and RR3; role reality) |
| 3. Hiring manager's public footprint | n/a | No name given |

I can write this up as a `tuesday-dossier.md` you keep and add to as answers come in, if you'd like.

**Upgrade menu.**
- Granting web search permission lets me retry targets 1 and 2. L1 has one search left of its five, so a deeper check would need your consent to L2. This verifies both employers and sets pay bands.
- The live posting links from each employer's own careers site would settle RR1 and RR4.
- A CV document, or a redacted screenshot of the on-time dashboard you built, would raise R2, R3a, R4 and R5 (Duinvaart) from `medium` toward `high`.
- Any temperature, cold-chain or compliance work would close R3b (Duinvaart).
- Any forecasting, planning, S&OP or Excel exposure would move R3–R7 (Kroonhaven).

**Questions.**
- **Q1 (R1, Duinvaart):** Can you work three days a week in Duinvaart's Rotterdam office from where you live now?
  Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- **Q2 (R3b, Duinvaart):** Have you ever tracked temperature-controlled deliveries, cold-chain excursions, or compliance checks, even as one part of a larger job?
  Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.