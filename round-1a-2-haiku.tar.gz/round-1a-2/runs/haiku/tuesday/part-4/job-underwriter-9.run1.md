**Short answer:** Asking for bank details, a PPS number and a passport scan after a written offer is routine onboarding for Irish employers `[generic]`. The thing to avoid is entering them through a link you haven't checked, or sending them by email. Nothing here asks for money or a cheque, and nothing is requested before the offer. Your two in-person interviews at their office also count for a lot. My recommendation is `conditional_go`: accept once the three checks below pass.

Research tier: L1, searches 1 of 5, fetches 0 of 2; user links read 0

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | The web search was refused by the host, so Marrowgate could not be checked online. |
| 2 | Role-family sweep (pay and scope) | unavailable | Same refusal. The €38k–€42k band is not checked against the market. |
| 3 | Hiring manager's public footprint (Declan Garvagh) | unavailable | Name given, but the search was refused. Not retried. |

**Decision snapshot**

- **Status:** `conditional_go`. Accept, once the employer checks pass.
- **Fit ledger:**
  - must_have: R1 `direct` (3 years of fortnightly payroll; medium, CV only). R3 `direct` (pivots, XLOOKUP; medium). R4 `direct` (Payroll Technician certificate 2024; medium, certificate not seen). R2 `unclear` (Irish PAYE, PRSI, USC; not stated in your background).
  - important: R6 `direct` (starters and leavers; medium). R8 `direct` (monthly ledger reconciliation; medium). R5 `adjacent` (240 staff monthly against your 90 fortnightly; medium). R7 `absent` (pension changes; you have not run them). R9 `unclear` (answering staff payroll queries; not in your background).
  - Gap rows R2, R5, R7 and R9 are the ones to close before you start.
- **Hard gates:** none failed (H2 `direct`, pay €40,000 within the advertised band). Unconfirmed: H1 (Limerick hybrid, two office days a week), H3 (right to work in Ireland). Candidate constraints not given, so checks against your salary floor and location are unknown.
- **Opportunity ledger:** Positive signals are the named role, the pay, the reporting line, the company-domain email and the in-person interviews. One standing entry is unresolved: RR1, the employer is not verified online (`risk_signal`, `medium`, `unresolved`). Its verification question for the People Team: "Can you confirm this role on your careers page, and that the onboarding portal sits on marrowgatehousing.ie?" Its hypothesis is that the employer could simply be small or hard to find. This is `[generic]`, not a finding about Marrowgate.
- **Severe red flags:** none found.
- **What would change this:** the conditions are (1) the employer checks out online or with the People Team, (2) the onboarding link is on Marrowgate's own domain, and (3) your Irish statutory knowledge and location and right-to-work checks hold.

**On the disclosure request, practically:**

- Do not reply to the offer email with any of these details. Replying to accept is fine.
- Find the onboarding portal yourself, starting from marrowgatehousing.ie, rather than clicking the emailed link. Check the address matches the site's own domain.
- Upload the passport scan only through that portal. Do not email it, and bring the original on day one as asked.
- If the link or domain looks different from the website, phone the number on their website before entering anything.

**Dossier offer:** I can save this assessment as `tuesday-dossier.md` to carry into interview prep later.

**Upgrade menu:**
- A web check of Marrowgate (their site, careers page, and the company and housing-body registers). This would settle RR1, and I could not run it here.
- Your Irish PAYE, PRSI and USC work or course detail. This would move R2 from `unclear`.
- Your home location and salary floor. This would close H1 and the pay check.

**Questions:**

1. (R2) Have you worked with Irish PAYE, PRSI and USC rates and returns yourself, or is that covered only by the certificate?
2. (H1, H3) Is two days a week in Limerick workable from where you live, and do you have the right to work in Ireland without sponsorship?
3. (R7) Have you seen a pension change processed end to end, even as a checker or reviewer?

Answer in text, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.