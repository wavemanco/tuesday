**Yes, take the call. The company checks out as far as the public record goes, and the WhatsApp contact is not a warning sign by itself.** Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: direct: H1 · unclear: H2 (salary €52,000–€60,000 against your floor)
- `must_have`: direct: R1 (3+ years of product design), R2 (strong Figma), R3 (has run own user research), R4 (working directly with engineers) · adjacent: R5 (own the booking flow end to end)
- `important`: adjacent: R6 (first designer, no design peers), R7 (research calls with school owners)

R5 — your checkout redesign is real booking-flow work, but not end-to-end ownership; R6 — you have never been the only designer; R7 — your research was with travel customers, not operators.

- **Hard gates:** none failed (H1 `direct`); unconfirmed: H2 (salary €52,000–€60,000 against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your pay floor sits at or below €52,000, or the gap is named before any offer; (2) the first-designer setup is concrete on the call (RR1); (3) you describe checkout as the bridge to the booking flow, not as ownership of it.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, making Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland; founded 2023 by Ronan Kehoe and Saoirse Doyle; customer-funded | `[grounded]` about page |
| Co-founder | Ronan Kehoe, co-founder and CEO; previously five years as product lead at a Galway travel-software company | `[grounded]` public profile (snippet) |
| Mandate | First designer: own the booking flow, run research with school owners, ship with two engineers | `[grounded]` posting and careers page |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting and careers page |
| Scope read | Broad for a first design hire: research, design and delivery in one role | `[inferred]` from the posting's responsibilities |
| Market calibration | Irish product designers with 3–5 years: median €57,000, interquartile range €51,500–€62,000. The €52,000–€60,000 range sits inside that interquartile range. The survey is national, not Galway-specific | `[generic]` Tillerby 2026 report (snippet); `[grounded]` posting figure |
| Unknowns | Runway, customer count, equity terms, Saoirse Doyle's title, your pay floor | — |
| Contradictions | None between the posting and the careers page. The recruiter calls Saoirse "our CTO"; the about page names them as co-founder and gives no title. Unconfirmed, not a contradiction | `[grounded]` about page, careers page |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| H1 | Two office days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year. Self-reported | `[grounded]` your background | Confirm two in-office days suit you |
| H2 | Salary €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | No floor given, so the check has not run | `[grounded]` posting; `[generic]` band | Question Q1 |
| R1 | 3+ years product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company. Self-reported, no artifact yet | `[grounded]` your background | A case study link would raise this |
| R2 | Strong Figma | must_have | direct | medium | none | "Figma daily." Self-reported | `[grounded]` your background | A Figma file link would raise this |
| R3 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers. The audience differs from R7 | `[grounded]` your background | None |
| R4 | Works directly with engineers | must_have | direct | medium | none | Squad of four engineers | `[grounded]` your background | None |
| R5 | Owns the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout. Limit: no stated ownership from research through shipping on the whole flow | `[inferred]` adjacency from the checkout work | Question Q2; gap G1 |
| R6 | Works as the only designer | important | adjacent | medium | transferability | Squad work with engineers, but never the only design voice. Limit: no design decisions taken without a design peer | `[grounded]` your background; `[inferred]` the adjacency | Question Q3; gap G2 |
| R7 | Research calls with school owners | important | adjacent | medium | transferability | Research with consumers, not operators | `[inferred]` from the audience difference | Gap G3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-to-end ownership (R5, must_have) | transferability | Checkout redesign confirmed. Nothing on the whole flow | A must-have at `adjacent` is the first objection | Any flow you shaped from first sketch to release; a feature you scoped, tested and shipped with engineers | A case study showing your decisions | `[inferred]` bridge from checkout work |
| G2 | Working alone on design (R6, important) | transferability | Never the only designer | The role is solo by design | A personal or freelance project where you made every design call | One real project you owned alone | `[grounded]` your statement |
| G3 | Operator research (R7, important) | transferability | Consumer usability sessions | The job's research is with school owners | Any interview with a non-consumer user | One interview guide or summary | `[inferred]` audience gap |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Design authority may sit with the founders | risk_signal | medium | "You would be our first designer" | The founders' product views may set design direction, leaving less authority than "own" implies | `[inferred]` from "first designer" against silence on decision rights | When a design call conflicts with Ronan's view of the product, who decides, and what happened on the last one? | unresolved |
| RR2 | One designer carries research, design and delivery | risk_signal | low | "own the booking flow end to end, run research calls … and ship" | Breadth can leave little time for any one job | `[generic]` pattern for first-designer roles at small companies, not a claim about this one | What does a typical week look like, and what share goes to research versus building? | unresolved |
| RR3 | Runway and customer count unknown | unknown | — | "funded by its customers" | Revenue may be thin; the company may still be healthy | `[inferred]` from the about page's wording; no financials found | How many schools pay for the product now, and how long is the runway? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The stake may be worth little without vesting or dilution terms | `[generic]` pattern for early-stage equity offers | What vesting schedule and strike price apply, and how many shares exist? | unresolved |
| RR5 | Saoirse's title and the invite's sender | unknown | — | "Saoirse, our CTO" | The title may be accurate; the invite should come from the company's own domain | `[grounded]` about page gives no title; the posting uses fernquay.example | Can you confirm Saoirse's title, and that the invite comes from the company address? | unresolved |
| RR6 | Pay, hybrid terms and posting are stated and consistent | positive_signal | — | "€52,000–€60,000 plus equity" | Terms are transparent and match the careers page | `[grounded]` posting and careers page | — | noted |

Contact by WhatsApp to schedule a video call is not a signal on its own. The request is for money, a deposit, or bank details, and none appears, so no severe entry is recorded. The employer-not-established entry is not triggered: the official site, careers page and co-founder's public profile all attribute the company to a real entity.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Walk the call through the checkout case study, saying what you decided and what the team decided | Keeps R5 honest and specific | `[grounded]` recruiter's message, R5 row | pending your approval |
| P2 | Positioning: lead with the checkout redesign and the monthly sessions. If asked about the whole booking flow, say what you owned on checkout and what you did not | Audit: "redesigned checkout" and "monthly usability sessions" are your sentences; no new scope added | `[grounded]` your background | pending your approval |
| P3 | Ask the RR1 and RR4 questions on the call, verbatim | The register doubles as call prep | `[grounded]` register | pending your approval |
| P4 | Before replying on WhatsApp, check the invite comes from fernquay.example and that the call is on video | Confirms RR5 without relying on the chat | `[grounded]` careers page domain | — |

**Evidence status**

Verified: none yet. Your background is self-report, so every row above is at `medium` at most.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea kayak surf schools" and "Fernquay careers product designer jobs". Fetched fernquay.example/about and fernquay.example/careers/product-designer. Employer established; posting live with the same salary, hybrid terms and Galway location |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway 3 years experience", which returned the Tillerby 2026 Ireland Design Salary Report (tillerby.example/2026-ireland-design-salary-report). Snippet only. Moved the market calibration, labeled `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Fernquay Ronan Kehoe co-founder", which returned Ronan Kehoe's public profile (linkedin.example/in/ronan-kehoe). Snippet only. Moved the scope read and the call positioning |

**Upgrade menu**

- Your pay floor → H2 closes, and the status moves to `go` or `no_go`.
- A Figma file or case study link → R1 and R2 rise to `high`.
- Equity terms in writing → RR4 closes.
- A deeper research pass on Fernquay (funding, customer reviews, Kelproster's public reviews; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can write this up as a `tuesday-dossier.md` so the register and the questions travel with you into the call.

Questions:

Q1 — H2: What is your base-pay floor, and is €52,000 below it?
Q2 — G1: Have you ever owned any part of a flow from research through to release? What was yours, and what did the team decide?
Q3 — G2: On any project, have you had to make design calls with no design peer to check them? What did you decide, and how did it go?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.