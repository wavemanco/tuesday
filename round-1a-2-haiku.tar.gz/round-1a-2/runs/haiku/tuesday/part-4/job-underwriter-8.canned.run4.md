**No. Don't go ahead, and don't send anything yet.** Status: `no_go`. The messages ask for money, a cheque deposit and bank, tax and identity details before any real interview or offer. This is very likely a scam.

**Fit (separate ledger, doesn't change the decision):** On paper your background matches the role's stated requirements well. Three years of ticket handling (about 60 Zendesk tickets a day), training two new starters and keeping a weekly Excel tracker all line up. Confidence is `medium` because it rests on your CV alone.

**Opportunity:** Severe red flags RR1, RR2 and RR3 (all `severity: high`, all confirmed from the messages you pasted).

- **Hard gates:** Your €30,000 floor is `unclear`. The posting gives "up to €26 an hour plus commission" for 15–30 hours a week. At the stated rate that is roughly €20,300–€40,600 a year before commission, and the posting doesn't say what's base pay. Commission is unquantified.

Research tier: L1, searches 3 of 5, fetches 0 of 2; user links read 0.

| Target | Status | What it moved |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics remote order processing coordinator jobs careers": no results. Employer not established from attributable sources. |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland €26 per hour". Found Pennoral's 2026 Ireland customer operations pay guide (pennoral.example, read from the search snippet only, not fetched): median base €31,200, interquartile range €28,400–€34,100 for salaried roles. Market calibration `[generic]`. |
| 3. Hiring manager's public footprint | n/a | No person's name was given; the handle @VellowayHiring isn't one. |

**Risk register (summary):**

- **RR1, pay for equipment:** "Please pay €349 by bank transfer to our equipment partner." `red_flag`, `high`, `confirmed`. Hold: pay nothing. Question for the employer: *Do you ever ask new hires to pay a third party for their equipment before they start?*
- **RR2, cheque deposit:** "We are posting you a cheque for €2,850 … keep €350 … and transfer the rest to our equipment partner." `red_flag`, `high`, `confirmed`. This is the overpayment pattern: you would be sending your own money to the sender. Hold: don't deposit it. Question for the employer: *Do you send cheques to new hires to be deposited and partly forwarded to third parties?*
- **RR3, details before any offer:** "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport." `red_flag`, `high`, `confirmed`. Hold: send none of it. Question for the employer: *At what stage do you collect bank and identity details, and do you do that through your own portal?*
- **RR4, hiring wholly by chat:** The posting says "no calls or video interviews" and the whole process runs on Telegram. `red_flag`, `high`, `confirmed`. This is a sign, not proof on its own.
- **Standing entry, employer not established:** `risk_signal`, `medium`, `unresolved`. I can't establish the firm from here. Velloway may be too small or new to have a footprint, but two searches found nothing.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**What to do now:**

1. **Send nothing.** Don't send your IBAN, PPS number or passport photo, don't pay anything, and don't deposit any cheque. Your IBAN is ready to paste, so keep it out of this chat and the Telegram chat.
2. **If you've already sent anything,** contact your bank now and ask about stopping payments or flagging the account. Report the chat and the jobs-site listing to the site, and report the scam to the Gardaí.
3. **If you still want to check the employer,** find Velloway's website yourself through a search, and use only the contact details listed there, not the Telegram handle or the HR email address they gave you.

Upgrade menu: a live posting on the employer's own careers page, which you find yourself, would resolve the standing entry. It wouldn't clear RR1–RR3. I can also put this into a dossier file if you want to keep a record.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.