**Short answer:** Duinvaart (Rotterdam) is worth your time, with conditions. Kroonhaven (Utrecht) is not worth it right now.

## Decision snapshot

**Duinvaart, Operations Analyst: `conditional_go`.** Apply once two gates check out: your right to work in the Netherlands and the three-day Rotterdam schedule. Also confirm the posting is live on their own careers site.

- **Fit ledger.**
  - `hard_gate` — unclear: D1 (Rotterdam office three days a week), D2 (right to work in the Netherlands)
  - `must_have` — direct: D3 (2+ years in logistics or ops analysis), D4 (strong SQL), D5 (Power BI or Tableau), D6a (on-time delivery tracking), D7 (weekly dashboards) · absent: D6b (temperature compliance across the refrigerated fleet)
  - `important` — direct: D8 (depot managers, route changes)
  - `preferred` — adjacent: D9 (Dutch, a plus)
  
  D6b is the one must-have your background doesn't touch. D1 and D2 are gates that nothing you've given me settles.
- **Opportunity ledger.** Scope is concrete and measurable (RR-D5). Two unknowns: who decides route changes (RR-D4) and what temperature data exists (RR-D3). The employer is unverified (RR-D1), because the search that would check it was refused this session.
- **Hard gates:** none failed; unconfirmed: D1 (Rotterdam office three days a week), D2 (right to work in the Netherlands); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** the conditions are (1) right to work confirmed (Q1), (2) the three-day Rotterdam schedule workable for you (Q2), (3) the posting verified (RR-D1). If Q2 comes back no, the status becomes `no_go` on that gate.

**Kroonhaven, Supply Planner: `no_go` (recommended).** Don't spend application effort on it now. The decision is yours.

- **Fit ledger.**
  - `hard_gate` — unclear: K1 (on-site in Utrecht), K2 (right to work in the Netherlands)
  - `must_have` — absent: K3 (3+ years planning in FMCG), K4 (SAP IBP or a similar planning system) · unclear: K5 (own the 13-week plan, balance capacity against forecast, run the weekly S&OP), K6 (advanced Excel) · adjacent: K7 (fluent Dutch)
  
  K3 and K4 are must-haves with no evidence and no credible closure within a job search. K5 is the only part with a possible bridge, and it depends on Q3.
- **Opportunity ledger.** The role is clearly scoped, but the employer is unverified (RR-K1) and pay is not stated (RR-K2).
- **Hard gates:** none failed; unconfirmed: K1 (on-site in Utrecht), K2 (right to work in the Netherlands); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** evidence that you forecast volumes or planned capacity over weeks or months (Q3). That could move K5 and may move K3 from absent. The status would then be re-run.

## Role reality

| Element | Duinvaart | Kroonhaven | Provenance |
|---|---|---|---|
| Organization | Cold-chain operator, Rotterdam | Food manufacturer, Utrecht | `[grounded]` posting headers; existence not checked |
| Scope | Weekly delivery and temperature reporting; depot route changes | Owns a 13-week supply plan for a chilled range; runs S&OP | `[grounded]` posting |
| Pay | Not stated | Not stated | `[grounded]` posting; no market band (search refused) |
| Unknowns | Route-change authority; temperature data; location | Planning tools; team; Excel level; location | — |
| Contradictions | None visible in the posting text | None visible in the posting text | `[grounded]` posting |

## Evidence map

Confidence is `medium` at most for everything here, because your background is self-reported prose and not yet probed.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | Rotterdam office, 3 days a week | hard_gate | unclear | none | hard_gate | Your location and commute aren't in what you've told me | `[grounded]` posting | Q2 |
| D2 | Right to work in NL without sponsorship | hard_gate | unclear | none | hard_gate | The posting is silent; checked because it gates any Dutch hire | `[inferred]` from the gate type | Q1 |
| D3 | 2+ years logistics or ops analysis | must_have | direct | medium | none | Four years as ops analyst at a parcel carrier | `[grounded]` your background, self-reported | none |
| D4 | Strong SQL | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your background | Sanitized query sample (upgrade menu) |
| D5 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily; the posting accepts either | `[grounded]` your background | none |
| D6a | On-time delivery tracking | must_have | direct | medium | none | You built the on-time dashboard depot managers use | `[grounded]` your background | Dashboard screenshot, client names removed |
| D6b | Temperature compliance, refrigerated fleet | must_have | absent | none | transferability | Nothing on temperature or cold chain. The bridge is parcel SLA tracking; the limit is that it isn't temperature data | `[grounded]` absence; `[inferred]` the bridge | Upgrade menu |
| D7 | Weekly dashboards in Power BI | must_have | direct | medium | none | You ran the weekly route-performance review | `[grounded]` your background | none |
| D8 | Work with depot managers on route changes | important | direct | medium | none | You ran that review with depot managers | `[grounded]` your background | none |
| D9 | Dutch (a plus) | preferred | adjacent | medium | transferability | Conversational, self-reported; short of fluent | `[grounded]` your statement | Upgrade menu |
| K1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your location and commute aren't in what you've told me | `[grounded]` posting | Q2 |
| K2 | Right to work in NL without sponsorship | hard_gate | unclear | none | hard_gate | As D2 | `[inferred]` from the gate type | Q1 |
| K3 | 3+ years supply or demand planning in FMCG | must_have | absent | medium | capability | You said you've never worked in planning; no FMCG history described | `[grounded]` your statement | Closure path below |
| K4 | SAP IBP or similar planning system | must_have | absent | none | capability | No planning-system use described | `[grounded]` absence | Course plus hands-on project; a material risk |
| K5 | Own the 13-week plan; balance capacity vs forecast; run S&OP | must_have | unclear | low | discovery | Parcel work described as route and performance review, not forecasting or capacity planning | `[grounded]` silence; `[inferred]` possible bridge | Q3 |
| K6 | Advanced Excel | must_have | unclear | none | discovery | Excel isn't in your background; SQL and Power BI are | `[grounded]` silence | Q3 |
| K7 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational against a fluent requirement; don't claim fluency | `[grounded]` your statement | Upgrade menu |

## Gap recovery queue

| # | Gap | Type | What would close it |
|---|---|---|---|
| D6b | Temperature compliance | transferability | Any temperature, cold-chain or SLA data you've handled. "None" is an answer too. |
| D9 | Dutch | transferability | Nothing short of fluency closes it; state the level honestly. |
| K3 | FMCG planning years | capability | No quick closure. A planning-analyst role at smaller scope would build the years. |
| K4 | SAP IBP | capability | A course plus a hands-on project; still a material risk for a planner role. |
| K5, K6 | Planning and Excel | discovery | Q3 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR-D1 | Employer not verified | unknown | — | "Duinvaart Cold Chain, Rotterdam" | The check did not run this session, so there's no finding either way. The standing entry caps the decision at `conditional_go` | `[grounded]` this session's refused searches | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR-D2 | Pay not stated | unknown | — | (no pay in posting) | Pay may be set low or withheld. No market band was checked | `[grounded]` posting | What is the budgeted salary range for this role? | unresolved |
| RR-D3 | Temperature-data scope | unknown | — | "temperature compliance across our refrigerated fleet" | The job may depend on sensor systems and compliance rules you haven't used | `[inferred]` from the scope line | What temperature data do the fleet's systems produce, and who owns the compliance rules? | unresolved |
| RR-D4 | Route-change authority | unknown | — | "work with depot managers on route changes" | "Work with" may mean advising rather than deciding | `[inferred]` from the wording | Which route changes does this role decide, and which stay with depot managers? | unresolved |
| RR-D5 | Defined deliverables | positive_signal | — | "build weekly dashboards in Power BI" | Scope is concrete and measurable | `[grounded]` posting | Who uses the weekly dashboards, and what decision does each one feed? | noted |
| RR-K1 | Employer not verified | unknown | — | "Kroonhaven Foods, Utrecht" | As RR-D1 | `[grounded]` this session's refused searches | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR-K2 | Pay not stated | unknown | — | (no pay in posting) | As RR-D2 | `[grounded]` posting | What is the budgeted salary range for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the Duinvaart posting on their careers site before you write anything | RR-D1 | `[grounded]` register | pending your approval |
| A2 | Answer Q1 and Q2 before you invest in either application | D1, D2 | `[grounded]` gate rows | pending your approval |
| A3 | Lead the Duinvaart application with the on-time dashboard (D6a). Say plainly you have no cold-chain work; "parcel SLA tracking" is not "temperature compliance", so don't claim the latter | D6a, D6b | `[grounded]` rows; reframing audit | pending your approval |
| A4 | Hold off on Kroonhaven | K3, K4 | `[grounded]` rows | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals". The host refused both, so neither employer's existence or live posting is checked. Would have moved RR-D1 and RR-K1 |
| 2. Role-family sweep | unavailable | Searched operations-analyst scope and pay for refrigerated logistics in the Netherlands. Refused. Would have set the market calibration and the pay band for RR-D2 and RR-K2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you want, I can save this as a `tuesday-dossier.md` to carry into later rounds.

## Upgrade menu

- Right-to-work status, one line → D2 and K2 close. This is the gate most likely to end the Duinvaart application.
- Where you live now and what commute you can manage → D1 and K1 close.
- A link to each live posting on the employer's own careers site → RR-D1 and RR-K1. Pasting a link you've read counts as a provided document, not research.
- A sanitized SQL query and a dashboard screenshot (client and depot names removed) → D4 and D6a move to `high`.
- Any temperature, cold-chain or SLA data you've handled → D6b moves from absent to adjacent. "None" is a valid answer.
- Allow web search in a later session → re-runs the employer checks and gives a pay band for both roles.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. **Q1 (D2, K2):** Do you have the right to work in the Netherlands without sponsorship?
2. **Q2 (D1, K1):** Where do you live now, and can you be in a Rotterdam office three days a week, or in Utrecht on-site every day?
3. **Q3 (K5, K6):** In your parcel work, did you forecast volumes or plan capacity over weeks or months, and how would you rate your Excel?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.