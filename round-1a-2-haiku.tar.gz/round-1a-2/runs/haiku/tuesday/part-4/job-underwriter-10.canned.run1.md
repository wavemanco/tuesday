**Yes, apply. The company checks out as far as I can verify from here: `go`.** Fernquay's own website describes the same company and role, and nothing in the posting or the WhatsApp message asks you for money or details. The open questions are about the scope of a solo design role and the equity terms, not about whether the job is real.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Pay €52,000–€60,000 against your floor)
- `must_have`: direct: R3, R4, R7 · adjacent: R5 (Running your own user research), R6 (Owning the booking flow end to end)
- `important`: adjacent: R8 (First designer, no design peer)

R5 and R6 are the two places where your history is real but doesn't yet match the wording of the role. R2 can't be checked because you haven't given a salary floor.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000 against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** The employer and posting are consistent across its own pages (RR4). Open items are the solo-designer scope (RR1), the equity terms (RR2) and the CTO's title (RR3).
- **What would change this:** If €52,000 is below your floor, R2 fails and the status becomes `no_go` on that gate. If the equity terms or the solo scope come back badly in the interview, reconsider.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, makes Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023, customer-funded | `[grounded]` fernquay.example/about |
| Mandate | First designer: own the booking flow, run research with school owners, ship with two engineers | `[grounded]` JD and careers page agree |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` JD and careers page |
| Market calibration | Tillerby's 2026 Ireland survey (n=520) puts product designers with 3–5 years at a median of €57,000 (interquartile range €51,500–€62,000). The posted range sits inside that band | `[generic]` one survey, not this employer's offer |
| Unknowns | Equity form and vesting; whether the role has any design review; Saoirse Doyle's title | — |
| Contradictions | The message calls Saoirse "our CTO". The about page calls her a co-founder and gives no title | `[grounded]` both sources, not resolved |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two office days in Galway | hard_gate | direct | medium | none | You moved back to Galway last year | `[grounded]` your statement | none |
| R2 | Pay €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | No floor given, so the check can't run | `[grounded]` JD figure | Q2 below |
| R3 | 3+ years product design | must_have | direct | medium | none | Four years stated; checkable only against a CV | `[grounded]` your statement | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use stated; no file to inspect yet | `[grounded]` your statement | Bring a file to the call |
| R5 | Has run own user research | must_have | adjacent | medium | transferability | Monthly usability sessions with travel-booking customers. The role wants calls with school owners, a smaller B2B population. Limit: no owner-side interviews stated | `[inferred]` from your background against the JD | Sketch how you'd run the first school-owner calls |
| R6 | Owns the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a checkout flow inside a squad. Ownership from research to shipping across the whole flow isn't stated | `[grounded]` your statement | Q3 below |
| R7 | Works directly with engineers | must_have | direct | medium | none | Worked in a squad of four engineers | `[grounded]` your statement | none |
| R8 | First designer, no design peer | important | adjacent | medium | transferability | You've never been the only designer. Squad design work is the nearest evidence. Limit: no one to review with day to day | `[inferred]` from the JD's "first designer" and your background | Q1 below |

**Gap recovery queue** (questions are in the closing block)

| # | Gap (req) | Type | What closes it |
|---|---|---|---|
| G1 | Pay against your floor (R2) | hard_gate | Your floor |
| G2 | Owner-side research (R5) | transferability | A sketch of how you'd approach school owners, or an example from your current work |
| G3 | End-to-end ownership (R6) | transferability | Which parts of the booking flow you owned, not just contributed to |
| G4 | Solo design scope (R8) | transferability | A self-directed project where you set direction without a design peer |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Sole design role with no design peer | risk_signal | medium | "You would be our first designer" | Design decisions may land on one person with no review | `[inferred]` from JD scope against no stated design support | Who would I review design decisions with each week, and which booking-flow decisions can I make without sign-off? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The percentage means little without the form, vesting, strike price or dilution terms | `[generic]` pattern for early-stage equity offers | Are these options or shares, what is the vesting schedule and strike price, and how is dilution handled? | unresolved |
| RR3 | Interviewer's title unconfirmed | unknown | — | "Saoirse, our CTO" (message) | The title may exist only in the message | `[grounded]` about page gives no title | Saoirse, what is your role here, and what will you cover on the call? | unresolved |
| RR4 | Pay and scope stated openly | positive_signal | — | "€52,000–€60,000 plus equity"; "our first designer" | Transparent pay and a defined scope | `[grounded]` JD and careers page agree | Who else would I work with in my first six months? | noted |

Severe red flags: none found. The WhatsApp message is not a signal. Scheduling by chat for a video call the employer has set up is normal, and the message asks for nothing from you.

**Application plan** (every row is proposed; nothing is sent)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before you join, check the invite came from an address on fernquay.example. Reply on WhatsApp only to confirm the time | The invite is the one check that matters here | `[grounded]` company domain from its own site | pending your approval |
| A2 | Bring one real project and a Figma file. Open with the checkout work, and say plainly where the booking flow went beyond it | The posting asks for one messy real project | `[grounded]` JD | pending your approval |
| A3 | Prepare the call with the mock-interview module | Its drills cover the interview itself | — | pending your approval |
| A4 | Ask Saoirse's title and the equity terms (RR2, RR3) | Both are unresolved | `[grounded]` register rows | pending your approval |

Positioning: say "I ran usability sessions with customers of a booking product", not "I have B2B research experience". Ronan's public profile lists a product role at a Galway travel-software company, so the travel-booking story is the one to lead with. Don't claim school-owner research you haven't done.

**Evidence status**

Verified: none yet. Everything above about you is your own statement, so the fit rows are provisional until you back them with a file or a confirmed answer.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software Galway sea-kayak surf schools" and "Fernquay careers Product Designer Galway". Fetched fernquay.example/careers/product-designer and fernquay.example/about. Moved the employer-exists check: the company matches the posting and the role is live. Surfaced the RR3 title contradiction |
| 2. Role-family sweep | yes | Searched "Product Designer salary Ireland 3 years experience", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Set the market calibration in role reality |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned his public LinkedIn profile (linkedin.example/in/ronan-kehoe). Read from the search snippet only, not fetched. Moved the positioning advice above |

A deeper pass would look at funding, leadership changes, and public employee or candidate reports on Fernquay (up to 5 more searches and 2 more fetches). That would test whether this is a stable company. I can run it if you want.

If you want, I can save this as `tuesday-dossier.md` so the verification questions carry into your call prep.

**Upgrade menu**

- Your salary floor → R2 closes, and the decision is settled on pay.
- One design file you can show, such as a checkout case or a sketch of a school-owner research plan → R4 and R5 move toward `high`.
- A deeper research pass on Fernquay (L2, as above) → tests whether the company is stable.

**Questions**

Q1 (R8): Have you ever been the only designer on something, even briefly? What did you do when nobody was there to review your work?
Q2 (R2): What's your lowest acceptable salary, and how do you weigh 0.5–1% equity against base pay?
Q3 (R6): At the travel company, which parts of the booking flow did you own from research to launch, and which did you only contribute to?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.