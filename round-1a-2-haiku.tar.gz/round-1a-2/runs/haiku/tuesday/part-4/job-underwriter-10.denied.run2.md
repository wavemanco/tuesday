**Worth applying? Yes, with conditions. Is it legit? I can't confirm it from here.**

I couldn't check Fernquay online. The web search was refused permission in this session, so I have no outside evidence about the company, Ronan, or Saoirse. That is a gap in my check, not a sign the company is fake. Nothing in the posting or the WhatsApp message asks you for money, bank details, or a chat-only hiring process, so no severe red flag is on the record. Your own checks, listed below, will settle the legitimacy question.

## Decision snapshot

**Status: `conditional_go`.** Take the 45-minute call once the company checks out. Your background fits the core of the role, and the open questions are about the employer and the terms.

- **Fit ledger.**
  - `hard_gate`: unclear: R1 (two office days a week in Galway), R2 (€52,000–€60,000 plus 0.5–1% equity)
  - `must_have`: direct: R3 (3+ years product design), R4 (strong Figma), R5 (ran your own user research), R8 (shipping alongside engineers); adjacent: R7 (owning the booking flow end to end)
  - `important`: adjacent: R6 (research calls with school owners), R9 (first designer, with no design colleagues)

  R3, R4, R5 and R8 are direct on your own account, at `medium` confidence. R7 is a checkout redesign, not yet the whole booking flow.

- **Opportunity ledger.** The employer is unverified (RR1), and it caps the decision at `conditional_go`. Authority over design decisions (RR3) and the equity and total package (RR4) are unstated. One entry runs the other way: the posting is explicit about the kind of project it wants (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (two office days a week in Galway), R2 (€52,000–€60,000 plus 0.5–1% equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the company and the invite are confirmed on its own domain (RR1, RR2); (2) you confirm two office days in Galway and the pay and equity meet your floor (R1, R2); (3) you are comfortable being the only designer, with decision rights clear (RR3, R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Six people in Galway making booking software for sea-kayak and surf schools | `[grounded]` posting's self-description, not checked |
| Role | First designer: own the booking flow end to end, run research with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office, otherwise wherever suits | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Market calibration | Not run; the search was refused, so the pay band cannot be checked | — |
| Interview | 45-minute video call with Ronan and Saoirse (CTO) | `[grounded]` WhatsApp message |
| Unknowns | Equity instrument and vesting; who sets design priorities; whether pay is the whole package; the team's funding | — |
| Contradictions | None visible between the posting and the WhatsApp message (Ronan is named as co-founder in both) | `[grounded]` both sources |

## Evidence map

Your statements are self-report, so `medium` is the ceiling for everything except the gate rows, where confidence grades your own statement of a constraint. You haven't stated one, so those rows are `none`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two office days a week, Galway | hard_gate | unclear | none | hard_gate | You live in Galway, but the material doesn't say whether you accept two office days a week | `[grounded]` posting; your Galway move | Q1 |
| R2 | €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | No pay floor or equity expectation given; the band can't be calibrated here | `[grounded]` posting | Q1 |
| R3 | 3+ years product design | must_have | direct | medium | none | Four years as product designer at a travel-booking company | `[grounded]` your account | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use | `[grounded]` your account | link a Figma file to raise to `high` |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers | `[grounded]` your account | none |
| R6 | Research calls with school owners | important | adjacent | medium | transferability | Customer research, but with travellers, not owners of small outdoor-sport businesses | `[inferred]` from your research work | G1 |
| R7 | Owns the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow; whether you owned it from research to launch is not stated | `[grounded]` your account; `[inferred]` the gap | G2 |
| R8 | Ships alongside engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your account | none |
| R9 | First designer, no design colleagues | important | adjacent | medium | transferability | You have never been the only designer; squad work is the nearest evidence | `[inferred]` from the posting's "first designer" | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | What would close it |
|---|---|---|---|---|---|
| G1 | School-owner research (R6) | transferability | Customer research with travellers | The posting asks for owner interviews, a different audience | Any owner-facing or small-business research you've run; or your plan for recruiting school owners |
| G2 | End-to-end booking ownership (R7) | transferability | Checkout redesign | "Own end to end" is the posting's core ask | The case study showing research, decisions and launch you personally drove |
| G3 | Sole-designer context (R9) | transferability | Squad work, never alone | The posting makes this the job's defining condition | Any time you made design calls without peer review, and how you got feedback |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer unverified (standing entry) | risk_signal | medium | "We are six people in Galway making booking software…" | Not checked: the search was refused, so this is not a finding that the company is absent | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Invite came by WhatsApp and email | unknown | — | "I have emailed you a calendar invite with the video link." | The invite's sender domain may not match the company's | `[grounded]` WhatsApp message | Which address on your company domain sends the invite? | unresolved |
| RR3 | First-designer authority unclear | unknown | — | "own the booking flow end to end" | Accountable for the flow, but design priorities and budget may sit with the founders | `[inferred]` from the posting's scope against its silence on authority | Who sets design priorities between me, Ronan and the engineers, and what research budget and tools are committed? | unresolved |
| RR4 | Equity and total package unstated | unknown | — | "plus 0.5–1% equity" | Equity terms and total package aren't given | `[grounded]` posting | What is the equity instrument, vesting schedule and strike price, and is €52,000–€60,000 the full package? | unresolved |
| RR5 | Explicit about the kind of work wanted | positive_signal | — | "we would rather see one messy real project than a polished deck" | Transparent about what they're hiring for | `[grounded]` posting | What is the messiest real project you'd want me to pick up first? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the invite's sender domain and find the role on the company's own site yourself | RR1, RR2 | `[grounded]` register | yours to do |
| A2 | Reply by email, not WhatsApp, once the domain checks out. Proposed text: "Hi Ronan, thanks, I'd be glad to do the 45 minutes with you and Saoirse. Could you point me to the role on your careers page? Thanks, Maeve." | Moves the scheduling off chat and asks for the verification | `[grounded]` RR1, RR2 | pending your approval |
| A3 | Send the checkout case study if you haven't. Check it says what you did, not what the team did | R7, R3 | `[grounded]` the WhatsApp message mentions it | pending your approval |

## Evidence status

Verified: none yet. Everything above is self-report from your message, so it is a lead until you confirm it.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Fernquay Galway booking software" and "Fernquay careers product designer" were refused permission and returned nothing. Would have moved RR1 and the posting's liveness |
| 2. Role-family sweep | unavailable | Search "product designer salary Ireland 3 years experience survey" was refused. Would have moved the pay calibration (R2, RR4) |
| 3. Hiring manager's public footprint | unavailable | Name given (Ronan Kehoe, co-founder); search "Ronan Kehoe Fernquay co-founder" was refused. Would have moved the scope read and the positioning for Ronan |

## Upgrade menu

- The company's own careers page or live posting link → RR1 closes; the decision could move to `go`.
- The invite's sender address → RR2 closes.
- Your pay floor and equity expectation → R2 resolves from unconfirmed to direct or `no_go`.
- The checkout case study, with what you owned and measured → R7 and R3 move toward `high`.
- If you allow web search in this session, I can run the three checks above.

If you want this kept, I can write it up as `tuesday-dossier.md`.

1. Would two office days a week in Galway work for you, and is there a pay or equity floor I should hold the role to? (R1, R2)
2. Would you be comfortable as the only designer, with no design colleague to review your work? (R9)
3. Have you applied to Fernquay, and did you send them the checkout case study? (A3)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.