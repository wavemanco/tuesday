**Is it normal to give bank, PPS and passport details before starting?** Yes, after a written offer. Collecting bank details, a PPS number and right-to-work documents is routine onboarding for Irish employers. [generic] The offer you've described names the role, salary, manager and hours, so the request itself isn't a warning sign. What matters is where you enter those details: only in a portal you reached yourself from the employer's own website. Don't enter them through a link in an email, and don't send them by email. `conditional_go`: accept only once the employer and portal are confirmed through its own channels.

- **Hard gates:** none failed; unconfirmed: R1 (Limerick office, two days a week), R2 (€40,000 against your pay floor), R3 (right to work for this role); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) employer and portal confirmed through its own website and switchboard (RR1, RR2); (2) R1–R3 checked against your own constraints; (3) pension changes (R9) discussed before you accept, since you haven't done them.

**Fit ledger**
- `hard_gate` — unclear: R1, R2, R3
- `must_have` — direct: R4, R6 · unclear: R5
- `important` — direct: R7, R8 · absent: R9, unclear: R10
- `preferred` — direct: R11

R1, R2, R3 — your constraints weren't given, so these stay open. R5 — Irish PAYE, PRSI and USC depth not yet shown. R9 — pension changes (never done). R10 — staff payroll queries (not in your background).

**Opportunity ledger.** The pay sits inside the advertised €38,000–€42,000 range (RR3). The employer itself is unverified from here (RR1): my searches were refused, so I could not check that it exists as described. The data request is routine after a credible offer, but the link route needs checking (RR2).

**Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would confirm Marrowgate Housing exists, the role is live, and the portal address. Searches refused. |
| 2. Role-family sweep | unavailable | Would set the market salary band for this role in Limerick. Searches refused. |
| 3. Hiring manager's public footprint | unavailable | Would check Declan Garvagh's public professional record. Search refused. |

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, Limerick housing association | `[grounded]` job ad; not verified from here |
| Scope | Payroll for 240 staff: monthly run, starters and leavers, pension changes, ledger reconciliation, staff queries | `[grounded]` job ad |
| Working pattern | Hybrid, two days a week in Limerick | `[grounded]` job ad and offer |
| Pay | €40,000 offered; advertised €38,000–€42,000 | `[grounded]` offer and ad |
| Market calibration | Not run; no salary band verified | — |
| Unknowns | Employer existence, portal address, start date, your pay floor | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Limerick office, two days a week | hard_gate | unclear | medium | hard_gate | Your constraint is not in the material | `[grounded]` job ad | Confirm you can commit to this |
| R2 | €40,000 against your floor | hard_gate | unclear | medium | hard_gate | Your floor is not in the material | `[grounded]` offer | Confirm the figure works for you |
| R3 | Right to work for this role | hard_gate | unclear | medium | hard_gate | Your status is not in the material | `[grounded]` offer | Confirm it is established |
| R4 | 2+ years running payroll | must_have | direct | medium | none | Three years fortnightly, 90 staff; self-reported | `[grounded]` your message | Keep an example ready |
| R5 | Working knowledge of PAYE, PRSI, USC | must_have | unclear | medium | discovery | Certificate in 2024; not shown whether Irish-specific | `[grounded]` your message | G3 |
| R6 | Strong Excel | must_have | direct | medium | none | Daily use; pivot tables, XLOOKUP; self-reported | `[grounded]` your message | Keep an example ready |
| R7 | Payroll-to-ledger reconciliation | important | direct | medium | none | Monthly reconciliation done | `[grounded]` your message | None |
| R8 | Starters and leavers | important | direct | medium | none | Done in the hotel job | `[grounded]` your message | None |
| R9 | Pension changes | important | absent | medium | transferability | Never done; your manager handled them | `[grounded]` your message | G1 |
| R10 | Answer staff payroll queries | important | unclear | low | discovery | Not in your background | `[grounded]` absence | G4 |
| R11 | Payroll qualification or working towards one | preferred | direct | medium | none | Payroll Technician certificate, 2024; not yet shown | `[grounded]` your message | Send a copy if asked |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R9) | transferability | You have never processed one; you may have handled pension deductions in payroll | A named gap in the duties | Any pension deduction or contribution change you input, checked, or queried | Scheme provider process notes, if any | `[inferred]` adjacency from payroll deductions |
| G2 | Monthly payroll cycle (R4, R5) | transferability | Your run was fortnightly for 90 staff | The role runs monthly for 240 | Monthly statutory returns or any monthly calendar work | A payroll calendar you ran | `[inferred]` adjacency from fortnightly work |
| G3 | PAYE, PRSI and USC depth (R5) | discovery | A certificate and daily payroll work, not shown in detail | This is a must-have | Calculating deductions, handling USC changes, Revenue queries | Certificate syllabus | `[grounded]` cert in your message |
| G4 | Staff payroll queries (R10) | discovery | Not mentioned | Part of the role | Answering queries on pay or deductions | Example of a query you resolved | `[grounded]` absence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified from here | unknown | — | "Marrowgate Housing, a housing association in Limerick" | The employer may be real and simply unchecked; my searches were refused | `[generic]` standing caveat, not a claim about this employer | "Can you confirm this role on your careers page, and give me the switchboard number for the People Team?" | unresolved |
| RR2 | Onboarding data request by portal link | unknown | — | "we will send you a link to our onboarding portal" | Routine if the link leads to the employer's own domain; a lookalike domain would change that | `[generic]` routine onboarding pattern | "What is the portal's exact web address, and how is my passport copy stored if I don't start?" | unresolved |
| RR3 | Pay within advertised range | positive_signal | — | "€40,000 a year" against "€38,000–€42,000" | The offer is consistent with the advert | `[grounded]` ad and offer | — | noted |

**Application plan (before you accept)**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Find the employer's website yourself; check the role is listed and the email domain matches it | RR1, RR2 | `[generic]` standard check | pending your approval |
| P2 | Phone the switchboard from that site; ask the People Team to confirm the offer and portal | RR1 | `[generic]` standard check | pending your approval |
| P3 | Enter bank and PPS details only in the portal reached from that site; send nothing by email | RR2 | `[generic]` standard check | pending your approval |
| P4 | Ask what the passport scan is for, and whether they will also want to view the original | RR2 | `[generic]` standard check | pending your approval |

**Evidence status.** Verified: none yet. Everything above is your own account, not yet confirmed.

If you'd like, I can save this as `tuesday-dossier.md` so it can be reused.

**Upgrade menu**
- Your Payroll Technician certificate → R11 to high, and R5 likely to medium-high once you show the syllabus.
- Your pay floor, Limerick commitment and right-to-work status → R1–R3 resolve, and the decision can move to `go` or `no_go`.
- The employer's careers page or switchboard number → RR1 closes.
- Web search, if you allow it → checks the employer, the live posting and the salary band. Refused this turn.

**Questions** (tagged to rows)
1. G2, G3: In the hotel job, did you run a monthly or fortnightly payroll, and how much of the PAYE, PRSI and USC calculation did you do yourself?
2. G1: Did you ever input, check or query pension deductions or contributions, even if your manager made the final change?
3. R1–R3: Do the two Limerick days, €40,000, and your right to work in Ireland all work for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.