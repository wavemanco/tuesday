**No. Don't go ahead, and don't send anything to this sender.** This job is very likely a scam. The three requests below are the reason, and each one is enough to stop.

**Decision: `no_go`.** Three confirmed severe red flags (RR1–RR3) are each a request to pay money or send sensitive details. RR4 is a severe process red flag.

- **Hard gates:** the posting states none. Unconfirmed: your €30,000 floor. The posting says "up to €26 an hour plus commission," not a salary.
- **Severe red flags:** RR1, RR2, RR3, RR4 (`severity: high`).
- **What would change this:** nothing in this chat. Only a verified employer, reached through its own website, asking for none of these things would change it.

**Fit ledger (your side, self-reported, so `medium` at most):**
- Spreadsheets: `direct`, medium. You keep a team Excel tracker.
- Order processing: `adjacent`, medium. Parcel-courier ticket work carries over, but not order processing itself.
- Attention to detail and written English: `unclear`. Nothing in what you've shared settles them.

**Opportunity ledger:** the requests are the decisive signals. The pay is also weak against your floor: at 52 weeks, €26 an hour gives about €20,300 at 15 hours a week and €40,600 at 30 hours, before an undefined commission. Reaching €30,000 needs about 22 hours a week all year. That arithmetic is mine, on the posting's own figures.

**Opportunity risk register**

- **RR1: Pay for equipment.** `red_flag`, `high`, `confirmed`. Quote: "Please pay €349 by bank transfer to our equipment partner". Hypothesis: you would pay before any job exists, and the refund is unverifiable. Verification question, to the employer through contact details you find on its own website, never in this chat: "Does Velloway require new hires to pay for equipment, and can you confirm this partner is your supplier?" Hold: pay nothing.
- **RR2: Cheque deposit and forwarding.** `red_flag`, `high`, `confirmed`. Quote: "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 … and transfer the rest to our equipment partner." Hypothesis: a cheque can be returned later, after the money you forwarded is gone. Question for the employer, same route: "Does Velloway ever send new hires a cheque to lodge and pass on to a third party?" Hold: don't lodge the cheque or transfer anything.
- **RR3: Bank and ID details before an offer.** `red_flag`, `high`, `confirmed`. Quote: "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up," sent before any written offer. Question for the employer, same route: "Do you collect bank and ID details through chat before an interview or written offer?" Hold: send none of it. Don't paste your IBAN into this chat.
- **RR4: Hiring run entirely by chat.** `red_flag`, `high`, `confirmed`. Quote: "Our whole hiring process runs on Telegram, so there are no calls or video interviews." This takes no verdict. It is a process sign.
- **RR5: Employer not established.** `risk_signal`, `medium`, `unresolved`. Hypothesis: `[generic]` pattern for employers of this kind, not a finding about this one. Question for the employer: "Can you point me to this role on your own careers page, and tell me who I would interview with?"
- **RR6: Pay not a salary.** `risk_signal`, `low`. Quote: "Earn up to €26 an hour plus commission." Question for the employer: "What is the guaranteed base pay per year, and how is commission calculated?"

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**Research tier: L0, no searches run this turn.** The verdict doesn't depend on research.
- Target 1, official site and careers page: `skipped`. The requests fix the decision whether or not the employer exists.
- Target 2, role-family pay sweep: `skipped`. Same ground.
- Target 3, hiring manager: `n/a`. No name was given.

**Next steps:**
- Don't reply with money, bank, tax or ID details, and don't lodge the cheque.
- If you already sent anything, contact your bank now and ask about the transfer, and report the messages to the jobs site and to the Gardaí.
- Find Velloway's own website through a search, not the link in the posting, and check whether this role appears there.

Want me to run the one-off research check on Velloway's own site (up to 5 searches and 2 fetches)? I can also draft a message to the employer's own contact, for you to send. Did the posting come from a link to the company's own careers page, or only from the jobs site?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.