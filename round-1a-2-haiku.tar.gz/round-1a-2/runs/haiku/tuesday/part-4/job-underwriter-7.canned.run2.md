**Yes, worth applying to, on one condition. Status: `conditional_go`.** Your registration, licence and post-registration years meet the essential requirements on what you've told me. The gaps are your own caseload, electronic records and Doppler, and none of them is a gate.

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4
- `important`: adjacent: R5, R6, R9 · direct: R7a, R8 · unclear: R7b, R10
- `preferred`: absent: R11

R5 — the caseload is the largest gap, and it's a transferable one, not an absent skill; R4 (`medium`) — unclear until you tell me about your records; R11 — never done, with a closure path.

**Opportunity ledger.** The employer is established and the pay is in line with the market, but the posting's live status is unverified (RR3), and the caseload size and on-call pattern are unstated (RR1, RR4). The pool cars, paid mileage and the offered informal chat all run in your favour (RR2).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is live on Calderbrook's own careers page (RR3); (2) the caseload size and support from the senior nurse are confirmed at the informal chat (RR1); (3) you describe your discharge-team work as home visits in the first week after discharge, never as caseload work (R5).

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organisation | Calderbrook Community Health CIC: adult community nursing across Calderdale under an NHS contract | `[grounded]` employer's about page, via web search |
| Mandate | Own small caseload of housebound adults, supported by a senior community nurse | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage; the posted range contains the 2026 England Band 5 community median of £34,300 | `[grounded]` advert; `[generic]` Wardround 2026 pay guide (n=1,240) |
| Unknowns | Caseload size, on-call and weekend pattern, which electronic record system, whether Doppler is needed from day one | — |
| Contradictions | None found between advert and the employer's about page | `[grounded]` |

**Evidence map.** Confidence is `medium` throughout: your CV is self-report and nothing has been inspected yet.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult | hard_gate | direct | medium | none | You state it is active; revalidation March 2028 | `[grounded]` CV | Check the NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Full licence, category B, stated | `[grounded]` CV | none |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years as a staff nurse | `[grounded]` CV | none |
| R4 | Clear, timely written records on an electronic record | must_have | unclear | low | discovery | The CV is silent on records or EPR | `[grounded]` CV silence | Q1 below |
| R5 | Holding a small caseload | important | adjacent | medium | transferability | Never held one; 18 months of home visits in the discharge team | `[inferred]` from CV | Q2 below |
| R6 | Wound care, including leg ulcers | important | adjacent | medium | transferability | Pressure and surgical wounds stated; leg ulcers not | `[grounded]` CV | none |
| R7a | Catheter care | important | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R7b | Continence care | important | unclear | low | discovery | Not on CV | `[grounded]` CV silence | Ask if you have done it |
| R8 | Insulin administration | important | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R9 | Care planning | important | adjacent | medium | transferability | Discharge planning stated; ongoing planning not | `[inferred]` from CV | none |
| R10 | End-of-life visits | important | unclear | low | discovery | Not on CV | `[grounded]` CV silence | Ask if you have done these |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | Never done; closure path below | `[grounded]` CV | Ask Rhiannon Mabbott about training |

**Gap recovery queue.**

| # | Gap (req) | Type | What I currently see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | No EPR experience on the CV | Could move the decision to `go` | An anonymised example note or handover | `[grounded]` CV silence |
| G2 | Caseload (R5, important) | transferability | Home visits, but no ongoing patients | The posting's main expectation | Any record of patients you followed over weeks | `[inferred]` bridge from CV |
| G3 | Doppler (R11, preferred) | capability | Not done | Closable: at the 2025 forum, Rhiannon Mabbott spoke on Doppler training for staff new to community work | A training record, if the team funds it | `[grounded]` public forum speaker page |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload size and support unstated | unknown | — | "hold a small caseload of your own, supported by a senior community nurse" | Caseload could be large or unsupported | `[inferred]` from the advert's silence | How many patients does a new caseload holder carry, and what support is in place in the first months? | unresolved |
| RR2 | Pay in band, mileage paid, pool cars | positive_signal | — | "pool cars are provided" | Role is costed sensibly | `[grounded]` advert; `[generic]` band | Is the mileage rate the standard NHS rate? | noted |
| RR3 | Posting live status unverified | unknown | — | Advert names a contact but no URL | The advert may be stale | `[generic]` pattern for adverts | Can you point me at this advert on Calderbrook's careers page? | unresolved |
| RR4 | On-call and weekend pattern unstated | unknown | — | Not stated | Community nursing often includes weekends | `[generic]` pattern for community roles | What is the on-call and weekend pattern for a caseload holder? | unresolved |

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Describe the discharge-team work as home visits to patients in the first week after discharge, not as caseload work | R5 | `[grounded]` CV | pending your approval |
| P2 | Check your NMC register entry and keep a copy | R1 | `[grounded]` | pending your approval |
| P3 | At the informal chat, ask about Doppler training for new community staff | R11, RR1 | `[grounded]` forum speaker page | pending your approval |

**Evidence status.** Verified: none yet. Everything on your CV is self-report until you confirm specifics.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read none

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched the employer's name with Halifax; result is its about page (calderbrookhealth.example/about): adult community nursing across Calderdale, founded 2015, 410 staff. Careers page not fetched, so RR3 stays open |
| 2. Role-family sweep | yes | Searched Band 5 community staff nurse pay; Wardround 2026 guide (wardround.example/2026-uk-community-nursing-pay-guide): England median £34,300, interquartile range £32,400–£36,600; market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched the named contact with the employer; result is a 2025 forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott): leads the Halifax district nursing team; spoke on leg-ulcer clinics and Doppler training. Public professional footprint only |

**Upgrade menu.**

- An NMC register screenshot or printout → R1 to `high`.
- A written example of an EPR entry, or a handover note, anonymised → R4 from `unclear`.
- A record of patients you followed over several weeks → R5 to `direct`.
- A Doppler or vascular training record → R11 closes.
- The live advert link → RR3 closes.
- A deeper research pass on Calderbrook (staffing, recent inspections; up to 5 more searches and 2 more fetches): say the word and it runs.

I can also save this assessment as a `tuesday-dossier.md` file for later use.

Three questions, all for you:

G1 (R4): Have you used an electronic patient record, and how did you keep your notes timely on home visits?

G2 (R5): Have you ever followed the same patients over several weeks, and what did you own in their plans?

Candidate constraint: Do you have a pay floor, a weekend or on-call limit, or any schedule constraint I should check this role against?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.