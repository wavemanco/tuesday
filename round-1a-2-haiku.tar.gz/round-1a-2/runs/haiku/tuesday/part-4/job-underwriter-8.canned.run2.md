**Short answer: no. Don't go ahead, and send nothing yet.** `no_go`. This job is very likely a scam. I can't establish the firm from here, and the requests in these messages are the kind that come before scams. Don't pay the €349, don't deposit the cheque, and don't send your IBAN, PPS number or passport photo. Don't paste the IBAN into this chat either.

**Decision snapshot**

- **Status:** Not worth applying to. `no_go`, because four confirmed severe red flags (RR1–RR4) each ask for money, a cheque deposit or bank and ID details before any offer, or run the whole process in chat.
- **Fit ledger:**
  - `hard_gate`: unclear: R1 (pay floor against "up to €26 an hour")
  - `must_have`: direct: R2 · adjacent: R3 (attention to detail) · unclear: R4 (written English)
  - `important`: unclear: R5 (quiet workspace)

  R2 — your Excel tracker, `medium`, confirmed but not inspected; R3 — ticket work as a bridge, its limit named; R1 — the gate the posting doesn't settle.
- **Opportunity ledger:** RR1–RR4 are confirmed red flags. RR5–RR7 are unresolved risk signals. Nothing in the posting is a positive signal.
- **Hard gates:** none failed; unconfirmed: R1 (pay floor against "up to €26 an hour, 15–30 hours a week"). Candidate constraints given: pay floor €30,000.
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** a written offer from the employer's own domain, naming the role and base pay, with the process moved off Telegram and none of these requests in it. Even then, R1 has to settle.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics; no web presence found | `[generic]` pattern for a firm this size; the search returned nothing |
| Role | Remote order processing coordinator, 15–30 h/week, "up to €26 an hour plus commission" | `[grounded]` posting |
| Pay arithmetic | At €26/h, full-year, the base is €20,280 at 15 h/week and €40,560 at 30 h/week, before commission | `[grounded]` arithmetic on the posting |
| Market | Salaried customer-operations coordinator roles in Ireland: median €31,200, IQR €28,400–€34,100 (n=1,140, commission-only roles excluded) | `[generic]` one 2026 pay guide |
| Process | Telegram only, no calls or video, chat "interview" before any offer | `[grounded]` posting and messages |
| Unknowns | Contract type, guaranteed hours, payroll, whether the equipment charge exists | — |

**Evidence map (your background)**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay floor €30,000 against the posting's pay | hard_gate | unclear | high | hard_gate | Your own stated floor is specific and confirmed. The posting gives only a ceiling and variable hours, which don't establish €30,000 | `[grounded]` posting; your constraint | Question 1 below |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly Excel tracker. Stated, not inspected | `[grounded]` your background | none |
| R3 | Strong attention to detail | must_have | adjacent | medium | transferability | About 60 Zendesk tickets a day. Limit: no accuracy measure, and it isn't order processing | `[inferred]` from the ticket work | a sanitised tracker sample would raise R2 |
| R4 | Good written English | must_have | unclear | low | discovery | No workplace writing sample; these messages aren't treated as evidence | `[grounded]` absence | none needed for the decision |
| R5 | Quiet place to work | important | unclear | low | discovery | Not stated | — | none needed for the decision |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Provenance |
|---|---|---|---|---|---|
| G1 | Pay floor (R1, hard_gate) | hard_gate | Only "up to €26 an hour plus commission" and 15–30 h/week | The gate is unsettled, and the sender has offered no guarantee | `[grounded]` posting |

G1 is a surfacing, not a recovery task. The only question it allows asks whether the gate is met.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equipment payment requested | red_flag | high | "pay €349 by bank transfer to our equipment partner" | Money asked before any pay is a known scam form; the sender's identity is unresolved | `[generic]` pattern | Does Velloway Logistics ask new hires to pay for their own equipment before their first wage? | confirmed |
| RR2 | Cheque deposit and transfer-back | red_flag | high | "posting you a cheque for €2,850 … transfer the rest to our equipment partner" | A cheque sent before any start, with the surplus sent on, is a standard overpayment fraud | `[generic]` pattern | Do you send new hires a cheque to deposit and then return part of it? | confirmed |
| RR3 | Bank, PPS and passport before offer | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport" "before your chat interview" | Asked before any offer, so it isn't routine onboarding | `[grounded]` message and the routine-onboarding rule | At what stage do you collect bank and PPS details, and through which portal? | confirmed |
| RR4 | Whole process in chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | Interview and offer both happen only in chat | `[grounded]` posting | Can I speak with a named manager on a call from your company number? | confirmed |
| RR5 | Employer not established | risk_signal | medium | "Velloway Logistics" | Two searches found nothing for the name. The entity may be too small or new, or may not be a hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Pay below the floor | risk_signal | medium | "Earn up to €26 an hour plus commission" | The base may not reach €30,000 at any hours the posting offers | `[grounded]` arithmetic; `[generic]` market median | What guaranteed base pay does this role pay per year at 15 h/week, and at 30? | unresolved |
| RR7 | Contact off the employer's domain | risk_signal | medium | "email velloway.hr@postmail.example" | The address is not on a domain the posting names | `[inferred]` from the address alone | Which domain do your HR emails come from, and where is it listed on your website? | unresolved |

**Hold:** Don't send the €349, don't deposit the cheque, and don't send your IBAN, PPS number or passport photo. RR1–RR4 hold those until you have confirmed the role with the employer. I couldn't identify the employer independently, so the sender's identity is unresolved. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**Application plan (proposed)**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Send no money, no cheque deposit, and no bank, PPS or passport details | RR1–RR4 | `[grounded]` the requests | proposed |
| P2 | If you have already sent any of these, contact your bank today and report it to An Garda Síochána | RR1–RR3 | `[generic]` standard practice | proposed |
| P3 | Find the role on the employer's own site yourself, and use only the contact details you find there, not Telegram | RR5, RR7 | `[generic]` | proposed |
| P4 | Target salaried postings that state a base; your Zendesk and tracker work is the bridge | R1, R2, R3 | `[inferred]` from the map and the `[generic]` median | proposed |

**Evidence status**

Verified: R2 and R3 claims, from your background in this conversation; no artifact inspected. Verified: none on the employer. Unverified: the employer's existence, and its pay, contract and equipment terms.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics remote order processing coordinator careers"; both returned no results. Employer not established (RR5) |
| 2. Role-family sweep | yes | Searched "order processing coordinator typical salary Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). Market calibration `[generic]` |
| 3. Hiring manager's public footprint | n/a | No person's name was given, so there was no query to form |

**Upgrade menu**

- The employer's own careers page or a live posting on its domain → RR5 closes or stays open.
- A written offer from the employer's domain, naming the role and base pay, with the process off Telegram → RR1–RR4 can be reassessed.
- A stated base pay figure → R1 settles, and RR6 closes.
- A sanitised sample of your tracker → R2 rises to `high`.

If you want, I can write the assessment to a `tuesday-dossier.md` so the verification questions carry into later conversations.

**Questions**

1. Has the employer given you a base pay figure in writing, or only "up to €26 an hour plus commission"? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip. (R1)
2. Have you sent any money, a cheque deposit, or any of the IBAN, PPS or passport details to this sender yet? (RR1–RR3)

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.