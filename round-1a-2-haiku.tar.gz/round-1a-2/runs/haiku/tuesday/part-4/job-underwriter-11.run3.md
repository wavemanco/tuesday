**Short answer:** Duinvaart (Rotterdam) is worth applying to, with conditions. Kroonhaven (Utrecht) is not worth your time right now. I could not check either employer online, because the search permission was refused, so both carry an unverified-employer entry.

## Posting 1: Operations Analyst, Duinvaart Cold Chain

**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Rotterdam office, three days a week)
- `must_have`: direct: R2 (2+ years logistics or operations analysis), R3 (strong SQL)
- `important`: direct: R4 (Power BI or Tableau), R5 (on-time delivery tracking), R7 (weekly dashboards), R8 (depot route changes); absent: R6 (temperature compliance)
- `preferred`: adjacent: R9 (Dutch a plus)

R1 is the one that can stop this. R6 is a gap you would have to explain. R9 is conversational Dutch against a "plus", so it costs little.

**Opportunity ledger.** The duties are concrete and the remit is defined (RR3, positive). The employer is not established (RR1, `severity: medium`), which caps the decision at `conditional_go`.

- **Hard gates:** none failed; unconfirmed: R1 (Rotterdam office, three days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the posting is confirmed on Duinvaart's own careers page (RR1); (2) the Amsterdam-to-Rotterdam schedule is workable (R1); (3) cold-chain data is framed as something you are learning, not something you have done (R6).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | `[grounded]` posting |
| Mandate | On-time and temperature tracking, weekly Power BI dashboards, route changes with depot managers | `[grounded]` posting |
| Pay | Not stated | `[grounded]` posting |
| Market calibration | Not run (search refused) | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Rotterdam office, 3 days/week | hard_gate | unclear | none | hard_gate | No schedule constraint given, so the gate cannot be checked | `[grounded]` posting | Q1 below |
| R2 | 2+ years logistics or ops analysis | must_have | direct | medium | none | Four years at a parcel carrier, self-reported | `[grounded]` CV | none |
| R3 | Strong SQL | must_have | direct | medium | none | Daily use, self-reported; no artifact yet | `[grounded]` CV | none |
| R4 | Power BI or Tableau | important | direct | medium | none | Daily Power BI use, self-reported | `[grounded]` CV | none |
| R5 | Track on-time delivery | important | direct | medium | none | Built the depot on-time dashboard | `[grounded]` CV | none |
| R6 | Temperature compliance, refrigerated fleet | important | absent | none | transferability | Delivery-timing tracking carries over; temperature data does not appear anywhere in your background | `[inferred]` from the posting against the CV | Q3 below |
| R7 | Weekly dashboards | important | direct | medium | none | Same as R4 | `[grounded]` CV | none |
| R8 | Work with depot managers on route changes | important | direct | medium | none | Ran the weekly route-performance review | `[grounded]` CV | none |
| R9 | Dutch | preferred | adjacent | medium | transferability | Conversational, below the level the posting describes as fluent-adjacent; a plus, not a requirement | `[grounded]` CV | Do not describe it as fluent |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The posting may be stale or aggregated, or the employer may be too small to have a footprint | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I interview with? | unresolved |
| RR2 | Source of temperature data unstated | unknown | — | "track temperature compliance across our refrigerated fleet" | The role may depend on a sensor feed owned by another team | `[inferred]` from the posting's silence on data sources | Which system holds the temperature logs, and does this role own that pipeline? | unresolved |
| RR3 | Concrete outputs stated | positive_signal | — | "build weekly dashboards … work with depot managers on route changes" | The scope is defined and measurable | `[grounded]` posting | Who consumes the weekly dashboards today? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Duinvaart's own careers page before applying | RR1 | `[generic]` pattern | pending your approval |

No résumé language is proposed in this turn. Any CV edit would come as a separate approval item.

## Posting 2: Supply Planner, Kroonhaven Foods

**Not worth your time right now. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (on-site in Utrecht)
- `must_have`: adjacent: R6 (fluent Dutch); unclear: R7 (advanced Excel); absent: R2 (3+ years supply or demand planning), R3 (owning the 13-week plan), R4 (running S&OP), R5 (SAP IBP or similar)

Four of the must-haves are absent, and two of those (R2 and R5) have no realistic short-term closure. The reason is the planning experience you do not have, not the posting. Your analytics work is adjacent to R3 and R4, but it does not stand in for them.

**Opportunity ledger.** The responsibilities are clearly defined, which is good (no red flag). The employer is not established (RR1, `severity: medium`).

- **Hard gates:** none failed; unconfirmed: R1 (on-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** a real planning-adjacent history (forecasting, production scheduling, an S&OP or planning meeting, or an IBP-type tool) that you have not yet told me about. Q2 below asks that directly.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready meals | `[grounded]` posting |
| Mandate | Owns the 13-week supply plan; balances capacity against forecast; runs weekly S&OP | `[grounded]` posting |
| Pay | Not stated | `[grounded]` posting |
| Market calibration | Not run (search refused) | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No location constraint given | `[grounded]` posting | Q1-style check, if you want it |
| R2 | 3+ years supply/demand planning, FMCG | must_have | absent | none | capability | No planning history; analytics adjacency does not count as years | `[grounded]` CV | none; closure is time |
| R3 | Own the 13-week supply plan | must_have | absent | none | capability | Never built a plan | `[grounded]` CV | Q2 below |
| R4 | Run the weekly S&OP meeting | must_have | absent | none | transferability | Ran a weekly route-performance review, a similar cadence | `[inferred]` from the CV | none |
| R5 | SAP IBP or similar planning system | must_have | absent | none | capability | No planning system in your history | `[grounded]` CV | none |
| R6 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational; short of fluent | `[grounded]` CV | Do not describe it as fluent |
| R7 | Advanced Excel | must_have | unclear | low | discovery | Excel is not mentioned in your CV | `[grounded]` CV silence | Q2 covers it |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same as Posting 1 | `[generic]` pattern | Can you point me to this role on your own careers site, and who would I interview with? | unresolved |

**Application plan.** Nothing to apply for now. If Q2 turns up planning-adjacent work, this moves to `hold_pending_answers` and I would reassess.

## Next steps

If you want this kept for later, I can write it to a `tuesday-dossier.md` file so the analysis carries into interview prep.

**Upgrade menu**

- Search access would let me verify both employers and set a market pay band for each role (the one set of searches refused above).
- Your schedule and location limits, plus any salary floor, would settle the R1 gate on Posting 1 and the on-site question on Posting 2.
- A cold-chain or temperature-data artifact, such as a dashboard you built with temperature inputs, would move R6 on Posting 1.
- A planning artifact, such as a forecast or S&OP deck, would be the only thing that moves R2 to R5 on Posting 2.

**Questions**

1. **R1 (Duinvaart):** Can you work in Rotterdam three days a week? Is the commute from Amsterdam workable for you?
2. **R3 and R7 (Kroonhaven):** Have you ever built a demand forecast, a production or supply plan, or joined an S&OP or planning meeting, even informally? And how would you rate your advanced Excel?
3. **R6 (Duinvaart):** Have you worked with temperature or cold-chain data, even as an input to your delivery reports?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Research tier: L1, searches 2 of 5, fetches 0 of 2; user links read 0.** Both searches were refused for lack of permission and counted against the budget.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page (both employers) | unavailable | Both searches were refused, so neither employer's existence or live posting is confirmed. This drives RR1 on both postings. |
| 2. Role-family sweep | unavailable | No call sent; the search permission was refused. It would have set the market pay band and checked role scope. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

**Evidence status.** Verified: none yet. Every CV claim above is self-report and sits at `medium` at most.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.