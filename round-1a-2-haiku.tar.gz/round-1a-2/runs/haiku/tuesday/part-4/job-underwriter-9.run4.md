**Watch-out check:** my research tools were refused, so nothing below about Marrowgate's existence, its pay norms or its portal is verified.

Asking for bank details, PPS and a passport scan after a written offer is normal Irish onboarding, so it isn't a red flag by itself. Accepting is reasonable once you've checked the portal address yourself, using Marrowgate's own website rather than the link in the email: **`conditional_go`**.

**Fit ledger**
- `hard_gate`: unconfirmed: R1 (Limerick hybrid, two days a week in office), R2 (€40,000 against your floor)
- `must_have`: direct: R3 (2+ years payroll), R5 (strong Excel), R6 (payroll qualification), R8 (starters and leavers), R9 (payroll-to-ledger reconciliation) · adjacent: R4 (PAYE, PRSI, USC), R7 (monthly run for 240 staff) · unclear: R10 (pension changes)
- `important`: unclear: R11 (answering staff payroll queries)

R10 is the largest gap: you've never run pension changes. R4 and R7 are adjacent, with their limits named.

**Opportunity ledger.** The €40,000 sits inside the posted €38,000–€42,000 band, the role is permanent, and the offer follows two interviews you can place. Against that, the onboarding route is unverified (RR1), and I have no market check on the pay (RR2).

**Hard gates:** none failed (no gate row is failed). Unconfirmed: R1 and R2, because your location, floor and notice period weren't given, so checks against them are unknown.

**Severe red flags:** none found.

**What would change this**
- Holds only if the portal address, domain or phone number can't be confirmed independently.
- Moves to `go` once R1 and R2 check out against your constraints and the pension scope is clear.
- Moves toward `hold` if the pension role turns out to be core and untrained.

**Role reality**
- Permanent Payroll Administrator, reporting to Declan Garvagh, Finance Manager, hybrid with two office days a week in Limerick [grounded, from the offer].
- Scale moves from 90 fortnightly to 240 monthly staff [grounded, comparing your CV with the ad].
- Market calibration of the pay: not checked.

**Evidence map**

| # | Priority | Fit | Confidence | Requirement | Note |
|---|---|---|---|---|---|
| R1 | hard_gate | unclear | — | Limerick hybrid, two days a week | Your location not given |
| R2 | hard_gate | unclear | — | €40,000 | Your floor not given |
| R3 | must_have | direct | medium | 2+ years running payroll | CV claim: 3 years |
| R4 | must_have | adjacent | medium | PAYE, PRSI, USC | Run fortnightly payroll; CV doesn't name the taxes |
| R5 | must_have | direct | medium | Strong Excel | Pivots, XLOOKUP |
| R6 | must_have | direct | medium | Payroll qualification | Payroll Technician certificate, 2024 |
| R7 | must_have | adjacent | medium | Monthly run, 240 staff | 90 staff, fortnightly |
| R8 | must_have | direct | medium | Starters and leavers | CV |
| R9 | must_have | direct | medium | Reconciliation to ledger | Monthly, CV |
| R10 | must_have | unclear | — | Pension changes | None on your CV |
| R11 | important | unclear | — | Staff payroll queries | Not on your CV |

**Gap recovery queue**
- R10: Did you see or help with pension changes at the hotel group, even as a second pair of eyes? That would move it to discovery.
- R4: Name the PAYE, PRSI and USC work you did. This is presentation, not new experience.
- R7: Transferable: the controls and cut-off steps carry over; the volume doesn't.
- R11: Ask whether you handled payroll queries directly.

**Opportunity risk register**
- **RR1.** Signal: onboarding request for bank, PPS and passport after offer. Class: `unknown`. Source quote: "add your bank details for salary payments, your PPS number for Revenue, and a scan of your passport". Hypothesis: routine onboarding after a credible offer, but the portal's ownership isn't verified. Provenance: `[generic]` for the pattern. Verification question: "Can you confirm the onboarding portal address, and show me where it's linked from your careers page?" Decision rule: enter nothing until the address matches Marrowgate's own site. Status: unresolved.
- **RR2.** Signal: pay not market-checked. Class: `unknown`. Source quote: "€40,000 a year". Hypothesis: the figure sits in the posted band, but I can't say whether that band fits payroll administrators in Limerick. Provenance: `[grounded]` for the band, nothing for the market. Verification question: "How was €40,000 set within the advertised range?" Decision rule: none needed unless you find it below your floor. Status: unresolved.

**Application plan**
1. Before accepting, find Marrowgate's careers page and phone number yourself, and check that the email domain and portal address match.
2. Ask the People Team what the pension changes involve in practice and whether you'd be trained.
3. Accept in writing inside five working days once checked.
4. Enter bank, PPS and passport details only in the portal at that verified address, never by email.
5. Standard, `[generic]`: an employer needs your PPS for Revenue, bank details for pay, and an original passport on day one for the right-to-work check.

**Evidence status**

Research tier: L1 — searches 4 of 5, fetches 0 of 2. Every search was refused, so no page was read.

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Marrowgate's official site and careers page | unavailable | Search refused; would confirm the employer, the live role and the portal |
| 2 | Role-family sweep: payroll administrator pay, Limerick | unavailable | Search refused; would calibrate €40,000 |
| 3 | Declan Garvagh's public footprint | unavailable | Search refused; name given, would check public professional footprint only |

**Upgrade menu**
- Allow web search, and I'll check Marrowgate's domain, careers page, portal and the pay band.
- Paste the job ad link, so I can confirm the wording.
- Tell me your floor, location and notice period, which settles R1 and R2.

**Questions** (answer in text, or say skip)
1. (R1, R2) What's your notice period, and what are your location and salary floors?
2. (RR1) Did you apply through Marrowgate's own careers page, or through a recruiter or job board?
3. (R10) Did you see or assist with any pension changes in your last job?

Want this saved as a `tuesday-dossier.md` to carry into later prep?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.