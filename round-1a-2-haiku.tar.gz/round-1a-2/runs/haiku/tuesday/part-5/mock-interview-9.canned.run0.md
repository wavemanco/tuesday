Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-5-rooms-case-9-canned-6a516487/d101fcc8-09ad-42bc-a5ee-e46f551460b3/scratchpad/Halvering_fourth_grade_teacher_interview_pack.md`. I built it from the invite, your resume, and your notes, since no job description was attached.

**What to prepare most:**
- **Fourth-grade experience (A1, A2).** This is the biggest objection. Say plainly that you haven't taught fourth grade, then give a concrete plan for learning it. Don't argue that third-grade experience makes you equivalent.
- **Leadership (A3).** You haven't been a team lead. Answer with the curriculum move you led in 2024, and don't stretch it into team leadership.
- **The district's three beliefs (B1–B3).** I fetched them from the district's own page: *Every Child a Reader*, *Families Are Partners*, and *Teach for Tomorrow, Not for the Test*. Your evidence fits the first two only partly. Your weekly family email is real evidence, but don't claim you speak with every family each term.
- **Principal Dolores Vantongeren.** A public forum profile says she has led Halvering since 2022 after nine years as a reading specialist, and gave a 2025 talk on weekly reading conferences in grades 3–5. Expect reading-practice questions, and use your third-grade reading work and the club as your strongest material. The pack includes a reverse question tied to that talk.

**Your SSN:** the resume text you pasted included your full Social Security number. I didn't use it or repeat it, and nothing in interview prep needs it. Remove it from any copy of your resume you send to the district.

Would you like me to run a drill? I can play the principal on A1, the question the pack names as highest-priority. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

1. Can you paste the job description or posting? It would let me check the pack's requirement coverage against the actual listing.
2. Which Thursday is the panel, and how much prep time do you have? Also, did the recruiter mention a demo lesson or any other written or presented component?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth_grade_teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. 45-minute panel: Principal Dolores Vantongeren, plus two fourth-grade team members (not named). Date: Thursday (exact date not given).

Assumption: no job description was supplied, so the requirements come from the invite and the district's published values. Answer slots name the practice only where a raising source names it.

## 1. How to use + type key

- Personas = how a question is asked. Types = what is being scored.
- VAL: behavioral / values alignment. EXP: work-experience deep-dive. JD: role requirements. CO: company knowledge. CASE: live problem.
- Guidance is scaffolding, not a script.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | high | [grounded] | none | Gate shown met. Nothing to bridge. |
| F2 | "Every Child a Reader: no student leaves third grade without a reading plan" — district values page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | presentation | Your material shows reading work, not reading plans for each student. Say the curriculum move and the club in those words. Any per-student plan you wrote is an answer slot below. |
| F3 | "Families Are Partners: each teacher speaks with every family each term" — district values page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | A weekly written email is adjacent to a termly conversation with every family. Name it as the email. Any direct conversations with families are an answer slot. |
| F4 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it" — district values page | none given | none given | [grounded] | discovery | Your material does not show how you used assessments. Answer slot: pick a time a result changed what you taught next; if none comes to mind, say so, then describe how you would use one. |
| F5 | Fourth-grade teaching experience (the panel's team is fourth grade) — invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | "I haven't taught fourth grade." Then how you would learn the grade, said as a plan, never as a past. |
| F6 | Team leadership (not a requirement in the invite; raised by your own note) — your message | "I've never been a team lead" — your message | none | [grounded] | capability | "I haven't been a team lead." Do not claim team leadership. Lead with the curriculum move as the nearest evidence. |

Routing note: F1 is a gate and the material shows it met, so it routes by its evidence cell as `none`. F5 and F6 are stated negatives, so they are `capability` with the candidate's own words.

## 3. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led the grade-level team | Inflated form of F2's quote | Your material says you led the curriculum move, not the team. Say the move in your own words. |
| Taught fourth grade | Negative you stated, F5 | "I haven't taught fourth grade." No slot. |
| Measured reading growth or per-student plans | Not in any quote | Not coached. Answer slots only ask what you did. |

## 4. Reading the interviewers (public footprint only)

- Principal Dolores Vantongeren: principal of Halvering Elementary since 2022, after nine years as a reading specialist. Her 2025 forum talk, "Small Groups, Big Readers," covered weekly reading conferences in grades 3 to 5 (ilprincipalsforum.example). Implication: she will likely probe reading practice in the grades nearest yours. Your third-grade reading work and the club are the strongest material.
- Team members: not named. No footprint.

## 5. Persona weights

| Member | Persona | Weight | Why |
|---|---|---|---|
| Principal | Case/Strategist | 3 | Hiring-manager prior; plus her reading-conference background |
| Principal | Skeptic | 4 | F5 and F6 are the objections |
| Team member 1 | Peer Evaluator | 3 | Peer prior; seams with fourth-grade planning |
| Team member 2 | Data-Driven Prober | 3 | Peer prior; probes what counts |
| Panel | Values/Behavioral | 3 | Public-sector archetype: competency framework is the values round; district values page supplies the names |

## 6. Question banks

### Skeptic (principal) — highest weight

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What would you need to learn first?" | JD | [grounded] "I've never taught fourth grade" — your message | Highest-ROI prep. Hold: "I haven't taught fourth grade." Then a learning plan: which fourth-grade standards you would read first, and who you would ask. Concede specifically, never fold on the claim that you can learn the grade. | F5 is the most likely objection. |
| A2 | "Why should we hire a third-grade teacher for fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV | Hold through two follow-ups: six years of third-grade reading instruction carries into fourth grade. Concede the grade's content is new. Answer slot: if you have worked with fourth-grade standards or colleagues, say so; if not, say so. | Second-strongest objection; the premise is the invite's. |
| A3 | "Tell me about a time you led colleagues." | EXP | [grounded] "Led our grade level's move to a new reading curriculum in 2024" — your CV | Open prompt. Story from the curriculum move: the decision, what you did, what the team did. If no such time comes to mind, say so plainly and give the curriculum move. Never claim team leadership. | F6 is the gap; this shows the nearest real evidence. |

### Values / Behavioral (panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Every Child a Reader means no student leaves third grade without a reading plan. What does a reading plan look like in your classroom?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" — your CV | Map to the curriculum move and the club, in your words. Answer slot: if you wrote reading plans for individual students, say what they contained; if you did not, say so and say what you would do. | F2 and the district's first belief. |
| B2 | "Families Are Partners: each teacher speaks with every family each term. How do you keep families informed?" | VAL | [grounded] "I write a weekly email to families" — your CV | Say the weekly email and what it covers, in those words. Answer slot: if you spoke directly with families this term, say who and how often; if you did not, say so. | F3. Never claim a conversation with every family. |
| B3 | "Teach for Tomorrow, Not for the Test: tell me about an assessment that changed a lesson you taught." | VAL | none (selection scaffold) | Pick a time a result changed what you taught next. Say what the assessment showed, what you changed, and what happened. If none comes to mind, say so, then describe how you would use one. | F4 is discovery; the open-prompt honest branch applies. |

### Peer Evaluator and Data-Driven Prober (team members)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the reading curriculum move was rolled out. What did you decide yourself?" | EXP | [grounded] "Led our grade level's move to a new reading curriculum in 2024" — your CV | Tell the move in your own words: what you decided, what the grade level decided. Answer slot: if you set the rollout steps, say which and how you decided; if you did not, say so and describe your part. | Prober question: the rollout steps are not in your material. |
| C2 | "How did you know the new curriculum was working?" | EXP | [grounded] "Led our grade level's move to a new reading curriculum in 2024" — your CV | Name what you looked at, if you looked at anything. Answer slot: if you tracked a measure, name it and say how it was counted; if you did not, say so and say what you would track first. | The data-driven prober's likely follow-up. |
| C3 | "Our fourth-grade team plans together. How would you bring what you know from third grade to that planning?" | CASE | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV | Name what carries forward from third grade, such as reading assessment and small-group work. Concede what you would need to learn about the fourth-grade sequence. | Peer seam: what you bring the team, not just what you need. |
| C4 | "A teammate wants a reading approach different from the one you prefer. What happens?" | CASE | [generic] | Structure: what you would ask, what evidence you would look at, how you would decide together, and what you would do if you still disagreed. Make no claim about your past. | Peer disagreement probe. |

### Conversational (any member)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about yourself." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" — your CV | A 90-second arc: where you teach, the curriculum move, the club, why fourth grade. Use only those three sentences. | Opener; scored even when casual. |

Requirement coverage:

| Requirement | Question IDs |
|---|---|
| Illinois PEL, elementary endorsement (F1) | none, and why: the gate is met; no question needed |
| Every Child a Reader (F2) | B1, C1 |
| Families Are Partners (F3) | B2 |
| Teach for Tomorrow (F4) | B3, C2 |
| Fourth-grade experience (F5) | A1, A2, C3 |
| Team leadership (F6) | A3 |

## 7. Reverse questions

1. "What does a strong first semester look like for this role?" Why it lands: shows you plan for the grade, not just the job.
2. "How does the fourth-grade team plan reading instruction together?" Why it lands: a peer question about the seam.
3. "Which part of the reading plan is hardest for the team right now?" Why it lands: invites an honest answer and shows you care about the work.
4. "How does the district support teachers new to a grade level?" Why it lands: addresses F5 without an apology.
5. "What could a new person do in the first month that would genuinely help your team?" Why it lands: the peer reciprocity question.
6. Tied to the principal's path: "Your 2025 talk covered weekly reading conferences in grades 3 to 5. What did you learn from those conferences that you would bring to fourth grade?" Why it lands: ties to her public footprint without flattery.

## 8. Values cheat sheet

Values round detected: public-sector competency framework (archetype fallback) with the district's own three beliefs.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Every Child a Reader | No student leaves third grade without a reading plan | Curriculum move; club (B1) |
| Families Are Partners | Each teacher speaks with every family each term | Weekly email (B2); your direct conversations are a slot |
| Teach for Tomorrow, Not for the Test | Assessments inform teaching and never replace it | Selection scaffold (B3) |

## 9. Sources

Provided documents: the invite; your resume; your notes.

Research tier: L1 — searches 2 of 6, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | Values cheat sheet: three beliefs by name, fetched from the district's own page |
| 2. Interview process, teacher panel | skipped | The invite fixes the session: one 45-minute panel with named members. No loop to detect |
| 3. Strategy / recent news | skipped | No company-strategy questions in a teacher panel; the district's values page supplies its priorities |
| 4. Principal Dolores Vantongeren | yes | Principal's public footprint: principal since 2022, nine years as reading specialist, 2025 talk on weekly reading conferences in grades 3 to 5 (reverse question 6, persona weights) |
| 5. Representative JD | skipped | The invite's requirements and the district's values fix the fit snapshot rows |

Queries sent: "Orrinsford Community School District values" (one result, the district's mission page, fetched); "Dolores Vantongeren principal Halvering Elementary Orrinsford" (one result, a forum speaker page).

## 10. Upgrade menu

- The job description text → turns the JD-derived rows from `[inferred]` into `[grounded]` and adds JD-tagged questions for any requirement not covered above.
- The team members' names and roles → assigns personas per member and adds a tailored reverse question.
- The recruiter's focus areas, process details, or any pre-declared demo lesson → coverage of that deliverable as its own build section.
- Your prep time before Thursday → sizes a prioritized schedule.
- A tuesday-dossier.md → carries verified evidence and gaps into this pack.
