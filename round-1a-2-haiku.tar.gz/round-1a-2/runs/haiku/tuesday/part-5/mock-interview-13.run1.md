Today is Thursday, so check whether Hannah's 2pm call is today or next week.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-5-rooms-case-13-denied-e1af0bd1/ec274deb-88e3-44b8-a9db-000ef708a5ed/scratchpad/quillmoor_operations_coordinator_interview_pack.md`. It has the full fit snapshot, persona table, 13 questions with guidance, six questions for Hannah, the prohibited-claims list and the upgrade menu. The web search I tried for Quillmoor was refused, so the pack has no company-specific material.

**Hannah's four topics, with what to say**

- **Pay:** "I'm hoping for £42,000." That sits inside the advert's £38,000–£44,000. Don't give a floor or range you haven't set.
- **Notice period:** You haven't given me a figure, so the pack leaves it as an instruction: give your actual notice period, in weeks. Don't estimate it.
- **Hybrid:** "Two days at Avonmouth is fine, and I wouldn't want more than three." Add nothing about the journey.
- **Reason for moving:** "Our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Say it once and stop. Don't guess why the office is closing.

**Where you're exposed**

- **Production scheduling is the biggest gap.** The advert asks you to coordinate production schedules across planning, the warehouse and QA. Your material shows scheduling deliveries for three depots. Prepare the honest answer first: if you touched a production or QA step, say which; if not, say so and describe how you sequenced deliveries. This is the question to rehearse most.
- **SAP:** say "I've never used SAP," then "we run our own in-house stock system." Don't call the in-house system an ERP. If asked how you'd learn SAP, give a plan, not a past.
- **Excel:** your material shows the stock-count rebuild but not your Excel level. Say what the rebuild involved, and rate yourself honestly.
- **Dispatch reporting:** the advert asks for a weekly on-time dispatch report. Nothing you've told me covers that. If you never reported on delivery timing, say so and say how you'd track it.
- **The "about a third" figure:** expect "how was that counted?" Say which part was yours, and say so if you don't know how it was counted.

**Questions to ask Hannah:** how planning, the warehouse and QA hand schedule changes to the coordinator; what the dispatch report measures and who reads it; which ERP the team uses day to day; how the hybrid pattern is set; what a good first three months looks like; and the team size and reporting line.

Offers, neither pushed:
- Say the word and I'll play the Skeptic on B2, the production-scheduling probe, and give feedback against its guidance.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations_coordinator_interview_pack.md -----
# Operations Coordinator, Quillmoor Diagnostics: recruiter screen prep

**Role:** Operations Coordinator, Quillmoor Diagnostics (hybrid, Avonmouth, Bristol)
**Interviewer:** Hannah Lowther, Talent Partner (recruiter)
**Round:** 30-minute phone screen, Thursday 2pm, on the mobile number on the application
**Candidate:** Sam

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Types used here: **EXP** (what you actually did) and **JD** (the advert's requirements and the recruiter's logistics terms). VAL, CO and CASE are not used in a recruiter screen. Guidance is scaffolding, not a script. Say only what is in quotes; everything else is an answer slot.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | No gap. Your message gives the years and the role, with no CV to inspect yet, so expect a probe on what the coordinating involved. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material says delivery scheduling across three depots. It does not say production scheduling, and planning, warehouse and QA links are not in it. Words: "I schedule deliveries for our three depots." Answer slot: if any of your scheduling touched a production or QA step, say which, in your own words; if none did, say so plainly and say how you sequenced deliveries across the three depots. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | medium | [grounded] | none | No gap. The quote reaches the requirement in its own terms. Say it as written. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | No gap. The quote reaches the requirement. The one-third has no record in the material, so it is the figure a probe will reach (C1). Say "about a third" as written. |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material is silent on dispatch reporting. Answer slot: if you reported on delivery timing, say what you measured and how often; if you didn't, say so and say how you'd track it. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | The spreadsheet work may touch Excel, but your material does not show your level. The link is this pack's derivation, so do not assert an Excel level. Answer slot: say what the rebuild involved, in your own words; name the Excel features you used if you can; then rate yourself and say why. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | medium | [grounded] | capability | A stated absence: you have not used SAP. The material does not describe the in-house system as an ERP. Words: "I've never used SAP. We run our own in-house stock system." Then how you would learn SAP, said as a plan and never as a past. |
| F8 | "£38,000–£44,000" (advert; pay, a gate) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Pay gate met on your stated expectation, which sits inside the band. It is an expectation, not a floor, and this pack does not set one. Say the figure in those words. |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert; schedule, a gate) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Met on your stated terms: two days, three at most. Say it in those words. Nothing to bridge. |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly opener, then pay, notice, location and the move asked in a casual register | High. The recruiter's own message sets this agenda: pay, notice, hybrid, reason for moving. | A 90-second background arc. Each logistics answer said once, plainly, in your own words. |
| Skeptic | "Why leave, why now", and the production and SAP lines of the advert set against your material | High, but light. The advert's production line and SAP plus are where your material is thinnest. | Rehearse B2 until it is dull. Bridge only from quotes, and say the gap plainly where there is one. |
| Data-Driven Prober | "How was the one-third counted?" | Medium-low. Only one headline figure in the material, and it has no record behind it. | C1: say what you know, and say when you do not know how it was counted. |
| Pressure / Stress | A 60-second challenge on why you over someone with SAP | Low. A 30-minute screen rarely turns hostile, but composure is still scored. | Pause and restate. Hold once through two follow-ups. Concede specifically. |
| Case, Values, Peer | Not weighted | Not weighted: no hiring-manager round, and no values round detected. | None needed for this screen. |

Weights: Conversational is top weight (5 questions). Skeptic is mid weight (4, one more than usual because the coverage rule gives the dispatch-report requirement its own question). Prober and Pressure are low weight (2 each). The total is 13, under the usual 18, because a 30-minute screen has four plausible personas and the recruiter has set the agenda.

**Highest-ROI prep: B2.** The advert's core line is production scheduling across planning, the warehouse and QA, and your material shows delivery scheduling. Expect it in some form.

## Question banks

### A. Conversational (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | Open with the first quote as written, then the depot work and the supplier chasing in the second, in the same words. About 90 seconds. Add no team size, volumes or outcomes that are not in the quotes. | F1 and F3 are the two requirements the screen checks first. The opener is scored for economy. |
| A2 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000" | Say: I'm hoping for £42,000. Give no floor and no range you have not set. If pushed on the band, go to D2. | Pay is the recruiter's first stated topic. £42,000 is inside the advert's £38,000–£44,000, so the pay gate reads as met (F8). |
| A3 | "What's your notice period?" | JD | [grounded] "your notice period" (recruiter's message) | Instruction: give your actual notice period, in weeks. Your material does not state one, so it is yours to give on the call. Do not estimate it. | Notice is on the recruiter's agenda and has no figure in the material. It is a logistics slot: an instruction, not a blank. |
| A4 | "How would the two days at Avonmouth work for you?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" | Say it in those words: two days at Avonmouth is fine, and you wouldn't want more than three. Add nothing about the journey that you have not stated. | F9. The location and schedule gate is met on your own limit, so this is a plain answer, not a slot. |
| A5 | "Tell me about a time you had to chase a supplier over a late order." | JD | [grounded] "chase suppliers when orders slip" | Story map from the quote: an order slipped, and you chased the supplier. Tell the beats in your own words. Answer slot: say what happened and how it ended; if you did not see the outcome, say so. | The advert's "chase late orders" line. An open prompt raised by the advert, so you choose the instance. |

### B. Skeptic (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say it once, in those words, and stop. Do not guess why the office is closing; your material does not say. Do not criticise the employer. | The recruiter's fourth stated topic. The reason is one you have stated, so the answer is plain and has no slot. |
| B2 | "The role coordinates production schedules across planning, the warehouse and QA. What's the nearest you've come to that?" | JD | [grounded] "I schedule deliveries for our three depots" | Hold: I schedule deliveries for our three depots, and say how. Answer slot: if any of your scheduling touched a production or QA step, say which, in your own words; if none did, say so plainly and say how you sequenced deliveries across the three depots. Hold through two follow-ups by returning to the depot scheduling. Concede a gap in your own words, never as a claim you cannot back. | The highest-ROI prep. F2 is a transferability gap on the advert's core line, and the most likely probe in some form. |
| B3 | "You rebuilt a stock-count spreadsheet. How confident are you in Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: say what the rebuild involved, in your own words; name the Excel features you used if you can; then rate yourself and say why. Do not claim an Excel level your material does not state. | F6. Excel is a stated requirement, and the spreadsheet work touches it without showing its reach. |
| B4 | "The role reports weekly on on-time dispatch. Have you produced a report like that?" | JD | [grounded] "report weekly on on-time dispatch" (advert) | Answer slot: if you reported on delivery timing, say what you measured and how often; if you didn't, say so and say how you'd track it. | F5. The material is silent on dispatch reporting, and the coverage rule gives every requirement a question. |

### C. Data-Driven Prober (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the discrepancy figure was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Answer slot: say which part of the count was yours; name the assumption behind the figure you would defend least, if you know one; if you don't know how it was counted, say so. Do not offer a method you cannot repeat. | F4's figure is the headline number, and a figure raises the defend-the-number slots. The one-third has no record in the material. |
| C2 | "Have you used SAP or a similar ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Say the plain acknowledgment: I've never used SAP. Then: we run our own in-house stock system. Do not call the in-house system an ERP. If asked how you would get up to speed, answer with a plan, never as a past. | F7. The advert makes ERP a plus, not a gate. The honest answer is the stated negative, plus a plan. |

### D. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has SAP?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year"; "Never used SAP — we run our own in-house stock system" | Pause and restate the question. Hold once: the stock-count work and the depot scheduling are what you bring. Hold through two follow-ups by returning to those two. Then concede specifically: I haven't used SAP. Do not claim SAP-like skill you cannot name. | Pressure is low weight on a screen, but composure is scored. The answer is one your quotes carry. |
| D2 | "£42,000 is the upper half of the band. Why that number?" | JD | [grounded] "I'm hoping for £42,000" | Hold the figure and tie it to the work your quotes carry: four years as a logistics coordinator. Hold through two follow-ups. If pushed on the band itself, concede plainly that you don't know the whole package yet. Do not cite market rates you have not checked. | Pay is the recruiter's first topic, and a pushed number is the one that folds. The hold is the one your material supports. |

**Requirement coverage**

| Requirement (advert) | Covered by |
|---|---|
| "2+ years in operations or logistics coordination" | A1 |
| "Coordinate production schedules between planning, the warehouse and QA" | B2 |
| "track supplier deliveries and chase late orders" | A1, A5 |
| "keep stock records accurate" | C1 |
| "report weekly on on-time dispatch" | B4 |
| "confident with Excel" | B3 |
| "ERP experience (SAP or similar) a plus" | C2 |
| "£38,000–£44,000" | A2, D2 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A4 |

## Reverse questions

| # | Question for Hannah | Why it lands |
|---|---|---|
| 1 | "How do planning, the warehouse and QA usually hand schedule changes to the coordinator?" | It probes the seam the advert names, and the answer shows where the job really sits. |
| 2 | "What does the weekly on-time dispatch report measure today, and who reads it?" | It shows you read the advert line by line. |
| 3 | "Which ERP does the team use day to day, and how much of the coordinator's work sits in it?" | It asks the SAP question without claiming the experience. |
| 4 | "How is the hybrid pattern set: which two days, and is it fixed or does it flex?" | Your three-day ceiling is a real term, and this shows whether there is room in it. |
| 5 | "What would a good first three months look like in this role?" | It shows you are planning to deliver, not only to join. |
| 6 | "How big is the team, and who would I report to?" | It gives Hannah the team section she has promised, and ends the call on your question. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I have ERP experience", or calling the in-house system an ERP | Inflated form of F7 | "We run our own in-house stock system", at its own scope. The pack's observation: your material does not say the in-house system is an ERP. |
| "I have production scheduling experience" | Inflated form of F2 | "I schedule deliveries for our three depots." The pack's observation: your material says deliveries, not production. |
| "I'm confident with Excel", or "advanced Excel" | Inflated form of F6 | "I rebuilt our stock-count spreadsheet." Your material does not state your Excel level. |
| "I cut discrepancies by a third" | Inflated form of F4: the verb and the sole credit both drift from "rebuilt" and "fell" | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The pack's observation: the material does not say the drop was yours alone. |
| "I reported on on-time dispatch every week" | Inflated form of F5 | None. Answer slot only (F5 and B4). |
| "£42,000 is the least I'd accept" | A stated hope turned into a floor | "I'm hoping for £42,000." The material gives no floor. |
| Any reason for leaving other than the closure | Entailed reason | "Our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." The material gives no other reason. |

Allowed, because it is a stated negative with its source: "I've never used SAP" (F7, C2).

## Sources

**Provided documents:** the advert as pasted; Hannah Lowther's LinkedIn message; your background, as written in your message.

**Searches sent:** "Quillmoor Diagnostics Avonmouth Bristol diagnostic test manufacturer" (standard). Returned: refused, since web search permission was not granted in this session.

**Research tier:** L1, searches 0 of 6 (1 refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | The "why Quillmoor" answer. No values round was detected, so no values section. The one search sent was refused. |
| 2. Quillmoor Diagnostics interview process operations | unavailable | Loop structure for the rounds after this screen. No call sent, because the refusal above removed the route. |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | One current, company-specific line for "why Quillmoor". No call sent. |
| 4. Hannah Lowther, Quillmoor | unavailable | Interviewer read from public professional footprint, and one tailored reverse question. No call sent. |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the requirement questions. |

## Upgrade menu

- Your notice period: A3 becomes your own figure, in your words, rather than an instruction.
- Your CV: F1, F3 and F4 move from "your message" to a document you can point to.
- The before and after figures from the stock-count spreadsheet: F4 moves toward high confidence, and C1 gets a record to defend.
- Web search permission, refused this session: one specific line for "why Quillmoor", from the company's published material.
- Hannah's public professional profile, if you want it researched: her persona weight and one tailored reverse question.
- A tuesday-dossier.md from an earlier session: F2 and F5 get verified text in place of silence.
