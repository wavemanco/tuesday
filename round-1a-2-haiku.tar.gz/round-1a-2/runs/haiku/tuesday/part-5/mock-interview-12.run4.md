Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview". It also says "Successful candidates receive a cheque for €1,850" and that you "deposit the cheque and send the balance on to the vendor". A fee before a job, documents before an offer, and a cheque you deposit and then pay part of back are a known scam pattern, and this invite is very likely a scam. Hold all of it: don't pay, deposit, send documents or send bank details until you have checked the invite with the employer, using a phone number or address from its own website or careers page, not anything in the invite. You can ask job-underwriter to check it as a separate request. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-5-rooms-case-12-denied-f47e8ec3/687283f3-a7bc-4883-9fc4-f804997dce3b/scratchpad/brennock_remote-administrative-assistant_interview_pack.md`. I built it for the 30-minute video call with the office manager, the only round the invite names.

On what to expect: the call will likely test whether you can do the four duties, and it will probe the two you haven't done, booking travel and processing supplier invoices. Name what you have done and what is new, and don't claim the new parts. Your highest-return prep is B1 in the pack.

Say the word and I'll run a drill on B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and I can convert the pack to Word if you'd like that.

Will the office manager be your direct manager, or is there someone else?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Round:** 30-minute video call with the office manager (the only round the invite names). Relationship: office manager, not confirmed as your direct manager.
**Built on:** your message (background and the duties as you summarised them). The invite's own wording is not included here. The pack is shorter than a full pack because the call is 30 minutes and the duties are four.

**Before using this pack:** verify the invite first (see the message that delivered this file). Everything below is prep for an admin interview in general and holds for any employer that is genuinely hiring.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only about what you actually did.

| Type | Meaning |
|---|---|
| EXP | Your experience: whether what you did survives follow-up |
| JD | The listed duties: can you do this job, including the parts you have not done |
| CASE | A live problem from the role, answered out loud |

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — your message | "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your material says the appointment book for four physios. Say it in those words: "I ran the appointment book for four physios." |
| F2 | "booking travel" — your message | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say what, for whom and how, in your own words; if you have not, say so plainly. |
| F3 | "preparing documents in Word" — your message | "I'm good with Word" — your message | low | [inferred] | discovery | "Good with Word" does not show what you have produced in it. Answer slot: name one document you prepared in Word, what it was for and who used it; if none comes to mind, say so and say how you would start. |
| F4 | "preparing documents in ... Excel" — your message | "okay with Excel" — your message | low | [inferred] | discovery | "Okay with Excel" does not show the level. Answer slot: say what you have actually used in Excel; if it is basic, say so and say how you would learn the rest. |
| F5 | "processing supplier invoices" — your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Chasing unpaid invoices is adjacent work: it is the other side of the invoice cycle from processing supplier invoices. Make that case and its limit: your material does not show you entered or approved supplier invoices. |

Confidence grades your evidence. Provenance grades what this pack wrote about it. F3 and F4 are low because the material is thin, so they are coached as answer slots, not as claims.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for an organisation's executives | Inflated form of F1 | F1's quote at its own scope: the appointment book for four physios |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: chased unpaid invoices |
| Expert in Word or Excel | Inflated form of F3 and F4 | The quotes at their own scope: good with Word, okay with Excel |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live admin problem from the role: a clash, a late change, a supplier query | High. An office manager is buying someone who can run the day-to-day, and a 30-minute call is enough time for one scenario | Clarify before you act; name what you would check first; say what you would tell the people affected |
| Skeptic | "Which parts of this have you done before?" | High. Four duties and a background in reception: the gap will be the first thing asked | Name the parts you have done, the parts that are new, and how you would learn the new ones. A plan is a plan, never a past |
| Conversational | A friendly opener about your background | Medium. Short calls often start this way and the opener is still scored | A 90-second arc: the clinic, the appointment book, the invoices, why admin |

Weighting: Case 4 questions, Skeptic 3, Conversational 2. The call is short and the duties are concrete, so the case and the gap questions carry the call.

## Question banks

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two directors have clashing meetings, and one is flying out early. What do you do first?" | CASE | [generic] | Structure it: confirm which commitments are fixed, ask who decides which one moves, check the travel times, then tell both people what changed and when. Make no claim about your past | A live problem from the calendar duty; a pattern for the problem, not a fact about this employer |
| A2 | "Walk me through booking travel for a visiting supplier, from the request to the confirmation." | JD | [generic] | Name the steps: the request, the budget and approval, the traveller's preferences, the booking, the confirmation sent to everyone. Ask the policy questions before booking. Say plainly if you have not booked travel before | F2 is the gap; the question scores the process, which you can describe without claiming experience |
| A3 | "Which Excel features have you used, and what did you use them for?" | JD | [inferred] "okay with Excel" | Answer slot: say what you have used, in your own words. If your use is basic, say so, and say how you would learn the rest. Do not list features you have not used | F4's thin bridge, rehearsed so the honest answer is ready |
| A4 | "What would you need to learn first for this job?" | CASE | [generic] | Name the two or three duties that are new to you, in order of how soon they come up. Give a learning plan as a plan. Never describe learning as done | The question invites the gap; this is the answer the Skeptic bank rehearses |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which of these duties have you done before, and which would be new?" | JD | [grounded] "ran the appointment book for four physios"; [grounded] "chased unpaid invoices" | Highest-ROI prep in this pack. Map the two quotes to the duties they touch: the appointment book to calendars, the unpaid invoices to the invoice cycle. Then name the new ones: travel booking, and processing supplier invoices from the start. Hold by returning to what you did. Do not claim the new ones | This is the likely objection: four duties, one background. Rehearse until it is calm |
| B2 | "Tell me about one document you prepared in Word. Who was it for?" | EXP | [inferred] "I'm good with Word" | Answer slot: name a document, what it was for and who read it. If none comes to mind, say so plainly and say how you would start | F3's thin bridge. A probe is likely because "good with Word" invites one |
| B3 | "Why admin, after a reception job?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Give your actual reason in your own words. Keep it to what you want from the work, not what you think they want to hear | Motivation is scored. The clinic is the fact the question rests on |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me about the clinic." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; [grounded] "ran the appointment book for four physios and chased unpaid invoices" | A 90-second arc: the clinic, the appointment book for four physios, the unpaid invoices you chased, what you liked about it. Use only those facts | A casual opener is still scored; the arc gives the interviewer your background in order |

## Reverse questions

Each one lands for a reason.

1. "Which of these duties would you want me to take on first?" Why it lands: it shows you are already thinking about the start.
2. "How do travel requests reach the office, and who approves them?" Why it lands: it shows you know travel booking depends on approval.
3. "How are supplier invoices checked before they are paid?" Why it lands: it shows you know payables has steps, and that you would learn them properly.
4. "What does a typical week look like, and how is it split between calendars, travel and documents?" Why it lands: it shows you want to know the real workload.
5. "What would make the first three months a success for this role?" Why it lands: it turns the interview toward the job and gives you the standard to work to.

## Upgrade menu

- The full text of the advert, as posted on the company's own website → the duties in the fit snapshot become quoted, and the question banks can rest on their exact words
- Whether the office manager is your direct manager → persona weights and reverse questions can be set for that relationship
- Two real examples of Word documents or Excel work you have done → F3 and F4 move from low confidence to medium, and the answer slots become claims you can rehearse
- Your employer's own contact details for the role, checked on its own website → the invite can be confirmed before any further prep is spent on it
- A tuesday-dossier.md → would add the gaps this prep exposed, so later sessions start from them

---

*Research tier: L0. No searches were run for this pack. The company and the role are taken from your message only.*
