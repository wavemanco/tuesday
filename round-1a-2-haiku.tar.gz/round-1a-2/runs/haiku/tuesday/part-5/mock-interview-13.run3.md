Your prep pack is saved as /var/tmp/tuesday-measure/1a2/runs/haiku/tuesday/part-5/rooms/case-13-denied-f8184710/quillmoor_operations-coordinator_interview_pack.md.

It covers the recruiter call, with a fit snapshot, the likely questions, and suggested answers that stick to what you've told me.

**Research didn't run.** All four web searches were refused because search permission isn't granted in this session. So there's nothing on Quillmoor's values, interview process, or recent news, and nothing on Hannah Lowther's background. Those gaps are listed in the pack's Sources section. Permission would let me fill them in.

**Where you stand against the advert:**
- **Strong:** your four years as a logistics coordinator, supplier chasing, and the stock-count rebuild. Your £42k target sits inside their band, and two days at Avonmouth works for you.
- **Thin:** production planning and QA coordination (your depot scheduling is the nearest match), weekly on-time dispatch reporting, and Excel. Your message says "spreadsheet," not Excel, so don't claim a specific level unless it's true.
- **SAP:** you've never used it. The pack has you say so plainly and talk about how you'd learn it.

**Most likely hard question:** the production-scheduling overlap (B1). Practise that one. The pack's answer is to point to the depot scheduling you actually did, and to say plainly if you've never worked with a planning or QA team.

**Two things to watch:**
- **The one-third figure.** Be ready to say how it was counted and which part was yours.
- **Notice period.** Your message doesn't give it, and the recruiter will ask. The pack leaves it open until you answer.

I could not check whether a `tuesday-dossier.md` already exists, because that directory check was refused, so the pack doesn't use one.

What's your notice period?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Prep pack: recruiter screen, Operations Coordinator, Quillmoor Diagnostics

**Interviewer:** Hannah Lowther, Talent Partner. **Round:** recruiter screen, 30-minute phone call, Thursday 2pm, to the mobile number on your application.
**Build:** session mode, built from the advert, your message and the recruiter's message. No research results were available (see Sources), so all company facts are absent and every bank is generic about the employer.

## How to use this pack

- **Personas** are how a question arrives. **Types** are what it scores. Type key: **EXP** is the work you did, tested for attribution. **JD** is the advert's stated requirement. **VAL** is company values, not present here. **CO** is company knowledge, not present here. **CASE** is a live problem, not present here.
- Guidance is scaffolding, not a script. Say things in your own words, and say only what you actually did.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | Say the four years and the wholesaler as written. Limited inspectable proof, so expect a probe on dates and scope. |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | Your words cover it: depot deliveries, and chasing when orders slip. Expect a probe on how often that happened. |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | Your words cover it, as written. The one third is a figure, so see D1 and D2. |
| F4 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | Your material says spreadsheet, not Excel. The link to Excel is this pack's inference, not your claim. Answer slot: if the count sheet was in Excel, say what you did in it; if it was another tool, name it and say what you did. |
| F5 | "production schedules between planning, warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | low | [inferred] | transferability | Depot delivery scheduling is the nearest thing your material carries, and it stays at that scope. Your material does not show production planning or QA work. Answer slot: if you have set or shared a schedule with a planning or quality team, say who and how; if not, say so and stay with the depots. |
| F6 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show on-time dispatch reporting. Answer slot: if you tracked on-time delivery, say what you counted and how often; if not, say so and say what you would track first. |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | Plain acknowledgment: "I haven't used SAP. We run our own in-house stock system." Then how you would learn it, stated as a plan and never as a past. |
| F8 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Say the figure as written. It sits inside the band the advert gives. |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Say it as written: two days is fine, and no more than three. |
| F10 | "your notice period" — recruiter's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period, and the material says nothing about it. The gate stays open until you answer the one question in this message. Words for the interview: give your actual notice period. |
| F11 | "what's prompting a move" — recruiter's message | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | high | [grounded] | none | Say it as written: the Bristol office closes next year, and the only offer is relocation to Reading, which you don't want. Add no further reason. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I have used SAP" or ERP work | Negative you stated (F7) | Plain acknowledgment only: "I haven't used SAP." No slot. |
| "I cut discrepancies by a third" | Inflated form of F3: your sentence says discrepancies fell; "I cut" moves the credit to you | F3's quote at its own scope. The limit is this pack's observation: your material does not say how much of the fall was yours. |
| "I scheduled production and worked with QA" | Inflated form of F5: your sentence says depot deliveries | F5's quote at its own scope. |
| "I'm open to relocating to Reading" | Contradicted by your own words (F11) | Your words: "which I don't want." |

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly walk-through; casual Excel and SAP asks; the notice question asked in passing | Weight 5, top. A recruiter screen's prior is conversational, and casual questions are still scored. | A 90-second arc from F1 and F2. Plain answers, and no unstated detail. |
| Skeptic | Why leave, the overlap with the production role, knockout checks | Weight 3, mid. The recruiter prior includes motivation and knockout checks. | Rehearse B1 until it is plain. Say the overlap your material carries, then the limit. |
| Pressure / Stress | Pushes on pay and on the three-day limit | Weight 2, low. A logistics push is common in screens, but it is not the main register. | Hold the position through two follow-ups. Concede only what you decide yourself. |
| Data-Driven Prober | Asks how the one-third figure was counted | Weight 2, low. The CV figure is a magnet, so the defend-the-number rule applies. | Say how it was counted, if you know; if you do not, say so. Name the weakest assumption before they do. |

Depth follows weight. The pack has 12 questions in total. That is below the usual session total of about 18, and it is deliberate: a 30-minute recruiter screen is mostly logistics, and the fit snapshot already covers each requirement.

## Question banks

### Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP, JD | [grounded] "4 years as logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip." | About 90 seconds: the wholesaler and the four years, then the three depots, then chasing suppliers when orders slip. Each beat is a clause your sentences state. | F1 and F2 are the opening's material and the likeliest first question. Covers the 2+ years and supplier-chasing requirements. |
| A2 | "Tell me about the stock records you've looked after." | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what you rebuilt and what fell, in those words. For the figure, see D1. | F3 is the answer to "keep stock records accurate." |
| A3 | "What are you playing with in Excel these days?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: if the count sheet was in Excel, say what you did in it; if it was another tool, name it and say what you did. Do not claim a level of Excel your material does not show. | F4 is a requirement your material does not name. The question's premise comes from the advert's "confident with Excel." |
| A4 | "Have you worked with SAP or a similar ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain acknowledgment: "I haven't used SAP. We run our own in-house stock system." No slot. | F7, the stated negative. The plus is not a hard requirement. |
| A5 | "What's your notice period?" | JD | [grounded] "your notice period" (recruiter's message) | Instruction: give your actual notice period. Your material does not state one. | F10, the gate the material leaves open. The one question in this message asks it of you. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates production schedules across planning, warehouse and QA. What's the closest you've come to that?" | JD | [grounded] "I schedule deliveries for our three depots" | The highest-ROI prep in this pack. The overlap your material carries: "I schedule deliveries for our three depots." Answer slot: if you have set or shared a schedule with a planning or quality team, say who and how, in your own words; if not, say so, stay with the depots, and say how you would learn the production side. Hold through two follow-ups by returning to the depots, never by adding to them. | F5 is the requirement your material does not carry. The question presupposes production scheduling, which the advert raises. This is the single most predictable objection. |
| B2 | "Have you reported on-time dispatch?" | JD | [grounded] (advert) "report weekly on on-time dispatch" | Answer slot: if you tracked on-time delivery, say what you counted and how often; if not, say so and say what you would track first. | F6, where the advert asks for a weekly report and your material is silent. |
| B3 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it as written: the Bristol office closes next year, and the only offer is relocation to Reading, which you don't want. Add no further reason. | F11. The recruiter named this topic, so it is a logistics slot your words already fill. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The band is £38,000 to £44,000. Why should it be at the top of that?" | JD | [grounded] "I'm hoping for £42,000." | Hold the figure through two follow-ups, as written. Concede only what you decide yourself, in your own words. Do not give a reason your material does not carry. | F8. The pay logistics slot is filled by your figure. |
| C2 | "Two days is the pattern. Could you do three every week?" | JD | [grounded] "I wouldn't want more than three." | Hold: two days is fine, and you would not want more than three. | F9. The location logistics slot is filled by your words. |

### Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the one-third drop in discrepancies was counted." | EXP | [grounded] "discrepancies fell by about a third over a year" | Defend-the-number slot: if you counted it, say how; if not, say so. Then say which part of the rebuild was yours to do. If the rebuild was a team's, say so. | The figure in F3 raises the defend-the-number slots, and only those. |
| D2 | "Which assumption behind that third would you defend least?" | EXP | [grounded] "discrepancies fell by about a third over a year" | Name, in your own words, the assumption you know of before they do. If you do not know how it was counted, say that plainly. | Weakest-assumption move for the figure in F3. |

### Coverage of the advert's requirements

| Requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Track supplier deliveries and chase late orders | A1 |
| Keep stock records accurate | A2 |
| Confident with Excel | A3 |
| ERP experience (SAP or similar) a plus | A4 |
| Production schedules between planning, warehouse and QA | B1 |
| Weekly on-time dispatch reporting | B2 |
| Pay (salary expectations) | C1 |
| Hybrid pattern | C2 |
| Notice period | A5 |
| Reason for leaving | B3 |

## Reverse questions

1. "What does a typical week look like for the person in this role, across planning, warehouse and QA?" Why it lands: it names the seams in the advert and asks about them directly.
2. "How is on-time dispatch measured today, and who reads the weekly report?" Why it lands: it shows you read the reporting line in the advert.
3. "Which systems do planning and the warehouse use for schedules and stock?" Why it lands: it connects the ERP line to a real question.
4. "What's the team's biggest source of late orders right now?" Why it lands: it points at the chasing work you have done.
5. "What happens after this call, and when would the team be in touch?" Why it lands: the recruiter said she would cover next steps, so this confirms them.
6. "How does the two-day pattern at Avonmouth usually work for the team?" Why it lands: it asks about the hybrid detail the recruiter raised.

## Sources

- Provided documents: the advert, your message about yourself, and the recruiter's message.
- Searches were sent for four targets. All four were refused, because search permission was not granted in this session, so nothing below comes from research. A check for an existing `tuesday-dossier.md` was also refused, so none was read.

**Research tier: L1 — searches 4 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Values cheat sheet (section 10). Refused: "Quillmoor Diagnostics values." No values section, and no values-style round is detected. |
| 2. Quillmoor Diagnostics interview process | unavailable | Loop structure. Refused: "Quillmoor Diagnostics interview process." The persona weights rest on the recruiter-screen prior alone. |
| 3. Quillmoor Diagnostics strategy / recent news | unavailable | Reverse questions and any CO questions. Refused: "Quillmoor Diagnostics strategy news." |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Interviewer read. Refused: "Hannah Lowther Quillmoor Diagnostics talent partner." Reverse questions stay role-generic. |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD questions. |

## Upgrade menu

- Your notice period → F10 becomes a stated term, and the gate closes.
- Search permission for company research → values, process and strategy targets run; a values section appears only if a values-style round is detected.
- Interviewer's public professional profile → an interviewer read, persona weights tuned to her path, and a tailored reverse question.
- The tool used for the stock count (Excel or other) → F4 moves from inferred to grounded.
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → company strategy brief and recent org context.
