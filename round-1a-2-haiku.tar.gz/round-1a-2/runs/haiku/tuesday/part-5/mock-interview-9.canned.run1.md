Your prep pack is saved as /var/tmp/tuesday-measure/1a2/runs/haiku/tuesday/part-5/rooms/case-9-canned-7377ee43/Halvering_Fourth_Grade_Teacher_interview_pack.md. I built it for a panel: the principal and two team members.

You included a Social Security number in your message. I haven't used it, and it isn't needed for interview prep, so keep it off anything you send for this application.

The pack's main points:

- **Fourth grade is the hardest question.** You've never taught it, and the principal will likely ask about it in some form. The pack's answer is your six years of third grade plus a concrete first-month plan. Practice that one first.
- **Your two sentences about leadership need reconciling in your own words.** You wrote that you led the grade-level move to a new reading curriculum in 2024, and also that you've never been a team lead. Expect "which was it?" Have a clear account of what you decided and what the team decided with you.
- **Your PEL covers grades 1–6,** so the license itself isn't an obstacle. Bring a copy.
- **The date:** the invite says Thursday, and today is Thursday, November 19. I've read it as November 26. Please confirm.

I ran no searches for this pack, so it has no values or school-specific material yet.

If you'd like, I can play the Skeptic on S1 and follow up on what you say. I can also save a tuesday-dossier.md recording the gaps this prep exposed, or convert the pack to Word.

Three questions:

1. Do you have the full job posting or position description? If not, I'll continue with the invite and your résumé.
2. Did HR mention a demo lesson, a sample assessment, or any other task for Thursday?
3. Should I run a research pass on Orrinsford CSD and Halvering's public pages (values, reading curriculum, strategy)?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_Fourth_Grade_Teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

- **Role:** Fourth Grade Teacher, Halvering Elementary School, Orrinsford Community School District
- **Interview:** 45-minute panel. Principal Dolores Vantongeren, plus two members of the fourth-grade team (not named in the invite).
- **Date:** the invite says Thursday. Today is Thursday, November 19, 2026, so this pack reads it as Thursday, November 26. Confirm the date.
- **Built on:** the invite text and your résumé as you pasted it. No job posting was supplied and no research was run.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Type key: JD = a role requirement; EXP = your past work; CASE = a live problem; VAL = values and behavior; CO = company knowledge (none in this pack). Guidance is scaffolding, not a script. Rehearse each answer aloud until it fits in 90 to 120 seconds.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | No gap. Words: "I hold an Illinois Professional Educator License with an Elementary Education (grades 1–6) endorsement, active through June 30, 2029." Your material shows the license and its dates, not the card itself, so bring a copy. |
| F2 | "Fourth Grade Teacher" (invite title) | "Six years teaching third grade at a public elementary school in Joliet." (your CV); "I've never taught fourth grade" (your message) | medium | [grounded] | transferability | Adjacent work only. Words: "I've taught third grade for six years in Joliet. I haven't taught fourth grade." Answer slot: say what you would read, observe or ask first, as a plan and never as a past. |
| F3 | Working with "two members of our fourth-grade team" (invite). The invite names no lead requirement. | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've never been a team lead" (your message) | low | [grounded] | capability | Your two sentences do not say what "led" covered, and the pack will not reconcile them for you. Words: "I haven't been a team lead. I led our grade level's move to a new reading curriculum in 2024." Answer slot: describe that move in your own words. |
| F4 | [generic] regular written communication with families | "I write a weekly email to families." (your CV) | medium | [generic] | none | Words: "I write a weekly email to families." |
| F5 | [generic] reading instruction beyond the school day | "I've run the after-school reading club for the last two years" (your CV) | medium | [generic] | none | Words: "I've run the after-school reading club for the last two years." |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated (F2) | "I haven't taught fourth grade." Plain acknowledgment; no slot |
| Has been a team lead | A negative you stated (F3) | "I haven't been a team lead." Plain acknowledgment; no slot |
| Chose or designed the reading curriculum | Inflated form of F3 | "I led our grade level's move to a new reading curriculum in 2024." The material says the move, not the choice of curriculum. Any answer stays inside the move. |
| Ran a school-wide reading program | Inflated form of F5 | "I've run the after-school reading club for the last two years." The material says one club, after school. |

## Persona weights

Panel: the principal is the hiring-manager type (Case/Strategist and Skeptic). The two team members are peers (Peer Evaluator and Data-Driven Prober). Conversational covers the opener.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | The principal probes the fourth-grade gap and the lead question | High. The principal is the buyer, and these two gaps are what a buyer probes first | Plain acknowledgment, the honest bridge, one plan (S1 to S5) |
| Peer Evaluator | Team members ask how you would plan and share work | High. Team members price the hire's load on their own work | Reciprocity, and seam principles over claimed history (P1 to P5) |
| Case / Strategist | The principal gives a live classroom problem | Medium. Live problems are how a principal tests planning | Clarify, then structure (C1 to C3) |
| Data-Driven Prober | Team members ask how you know something worked | Medium. The reading club and the 2024 move invite "how do you know?" | Name what you counted, and say plainly when you counted nothing (D1 to D3) |
| Conversational | A casual opener | Low to medium. Panels often open friendly, and the opener is still scored | A 90-second arc (R1, R2) |
| Values / Behavioral | Not weighted | Low. No published values are in hand; generic behavioral prompts sit in the peer bank | None |
| Pressure | Not banked separately | Low. Its hold-then-concede structure is in S2 | None |

## Question banks

### Skeptic (principal), top weight: 5 questions

Highest-ROI prep: **S1**. The fourth-grade gap is the title of the job, so some form of this question will come.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You've taught third grade for six years. What would your first month with fourth graders look like?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | Lead with what carries over from six years of third grade, in those words. Then give one plan: what you would read, observe or ask first, and who you would ask. Answer slot: if you have already looked at fourth-grade materials, name them; if you have not, say so plainly. | F2 is the requirement most likely to be probed. The answer is the adjacent grade and the plan, not a fourth-grade record. |
| S2 | "Have you ever led colleagues on a school initiative? Tell me about it." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've never been a team lead" (your message) | Open with the plain acknowledgment: "I haven't been a team lead." Then tell the 2024 move at its own scope, in your words. Answer slot: say what you decided and what the grade level decided with you; if others set the parts, say so plainly. Hold through two follow-ups by returning to the 2024 move. If pressed on the title, concede it plainly rather than arguing. | F3 is the second most likely probe. The open prompt asks you to pick an instance, and the honest "I haven't" comes first. |
| S3 | "Walk me through the 2024 reading curriculum move. What did you do, and what happened?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Tell the move in your own words, using only what the sentence carries: the grade-level move, the year, and your part in it. Answer slot: if you have a measure of how the move went, say what it measured; if you have none, say so plainly. | Premised on your CV sentence. The slot keeps the outcome at the scope you can state. |
| S4 | "A parent emails you upset about a grade. What do you do?" | CASE | [generic] | Structure it: what you would check first, who you would talk to, and what you would put in writing. If you have done this, say how; if not, describe how you would handle it. | F4 is the nearest real practice, a weekly email. A family conversation is a different practice, so do not stretch F4 into it. |
| S5 | "Why would you move from third grade to fourth?" | EXP | [generic] | Pick the real reason and say it in one sentence. If it is the grade, say what draws you to fourth. If it is the school, say what you know of it. If you have no reason yet, say so and say what you would find out. | A motivation probe. The material gives no reason, so the guidance does not supply one. |

### Peer Evaluator (team members), top weight: 5 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our team plans together every week. How do you take feedback on a lesson you planned alone?" | VAL | [generic] | Pick a real time someone gave you feedback on a plan or lesson, and say what changed. If you have none, say so, then give the nearest thing you do with feedback. | A collaboration probe. The material is silent on feedback, so the guidance asks rather than asserts. |
| P2 | "What would you need from us in your first month?" | VAL | [generic] | Give two concrete asks in your own words, such as the team's pacing or its assessments. Make no claims about past teams. | Reciprocity. Team members price the hire's load on their work. |
| P3 | "How have you shared planning with a grade-level colleague?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Use the 2024 move as the example, at its scope: what you shared, and who decided the materials. Answer slot: if you shared the planning on it, say what you shared; if others set those parts, say so plainly. | F3's evidence. The honest answer is the scope of the sentence. |
| P4 | "When have you disagreed with a colleague about how to teach something?" | VAL | [generic] | Pick a real disagreement: what each of you wanted, and what you did. If there was none, say so and give the nearest. | A turf probe. The open prompt asks for an instance and supplies none. |
| P5 | "Your reading club and your weekly family email: how would those fit with our team's work?" | JD | [grounded] "I've run the after-school reading club for the last two years" (your CV); "I write a weekly email to families." (your CV) | Name the overlap in your own words: the subject of the club, and the audience of the email. Do not claim you coordinated with a team you have not worked with. | F5 and F4 are the strongest reach points on your CV. A peer will ask how they transfer. |

### Case / Strategist (principal), middle weight: 3 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It's Monday, and three students in your fourth-grade class are reading well below grade level. What do you do this week?" | CASE | [generic] | Clarify first: what the reading data shows, and for which students. Then structure: a short plan for those three, what you would tell the team, and what you would check by Friday. Think aloud. | A live problem from the role. It makes no claim about your past. |
| C2 | "The team is adopting a unit you haven't taught before. How do you prepare?" | JD | [generic] | Structure it: read the unit, ask the team for its pacing and assessments, and plan one week before the first lesson. Say what you would ask first. | Covers F2 as a plan. The posting is not in the material, so this stays generic. |
| C3 | "You're planning six weeks of reading. What do you need to know before you start?" | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Use the 2024 move as the nearest case: name what you needed to know then, in your own words. Answer slot: if the move started from a student assessment, say which; if it did not, say so and say what you would check first. | Your reading experience carries here. The slot keeps the planning inside what you actually did. |

### Data-Driven Prober (team members), middle weight: 3 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How do you know a reading group is working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Say what you looked at, and how you would know if it were not working. Answer slot: if you counted anything, say what and how; if you did not count, say so plainly. Hold a follow-up by describing what you would change. | A probe on a two-year club. The material gives no measure, so the slot asks only what you counted. |
| D2 | "Which assessment data would you bring to a grade-level meeting?" | JD | [generic] | Name the kinds of data you have used, in your words. If you have used third-grade assessments, say which. Answer slot: if you have used none, say what you would bring first. | Team members weigh fit by their data habits. |
| D3 | "What's one number from your classroom you'd defend in front of this team?" | EXP | [generic] | Give a figure only if you have one. Say how it was counted, and the assumption you would defend least. If you have no figure, say so and name what you would count first. | The defend-the-number probe. No figure is in the material, so none is supplied. |

### Conversational (opener), low weight: 2 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk us through your six years in Joliet." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | A 90-second arc: where, which grade, what changed in your teaching, and why you are here. Use only what your CV carries. | Openers are scored in a casual register. |
| R2 | "What do you enjoy most about teaching?" | VAL | [generic] | One honest sentence, then one concrete moment from your own classroom. No abstractions. | A rapport opener. The moment is yours to choose. |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Valid Illinois PEL with an elementary endorsement (invite) | None, and why: your material says you hold it, active through June 30, 2029, and the endorsement covers grades 1–6. Bring a copy of the license. |
| Fourth Grade Teacher (invite title) | S1, C2, D2 |
| Working with "two members of our fourth-grade team" (invite) | P1, P2, P3, P4 |
| Leading work with a grade-level team (no requirement stated) | S2, S3 |
| Family communication [generic] | P5, S4 |
| Reading instruction [generic] | C1, D1, P5 |

## Reverse questions

No interviewer profile was given, so none of these is tied to an interviewer's path.

| Question | Why it lands |
|---|---|
| "What does a strong first semester look like for the fourth-grade teacher here?" | Shows you plan ahead, and the answer tells you what the panel scores. |
| "What reading materials is the fourth-grade team using now?" | Shows you are current with the team's work before you start. |
| "How does the team plan together, week to week?" | Asks how the team works, which is the peer members' own territory. |
| "What is the most useful thing a new teacher on this team could do in the first month?" | A reciprocity question for the peer members: it asks what you can bring to their work. |
| "How does the school keep in touch with families beyond report cards?" | Ties your weekly family email to the school's practice. |

## Sources

- Provided documents: the invite, quoted in the fit snapshot; and the résumé text in your message.
- Research tier: L0 — no searches.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford CSD or Halvering values | unavailable | Values cheat sheet (section omitted: no values page in hand). Not searched this pass. |
| 2. Orrinsford CSD interview process, panel | unavailable | Loop structure and persona weights. Not searched this pass. |
| 3. Orrinsford CSD strategy or recent news | unavailable | Grounding brief and company-knowledge bank (none in this pack). Not searched this pass. |
| 4. Dolores Vantongeren, Orrinsford CSD | unavailable | Interviewer read and a reverse question tied to the principal's path. Not searched this pass. |
| 5. Representative Fourth Grade Teacher JD | unavailable | Grounds F2 and the coverage table. Not searched this pass. |

All five show unavailable only because this pass ran at L0. The research question in the message would lift that.

## Upgrade menu

- The full posting text → F2 and the requirement cells become quoted rows, and the coverage table gains real requirement lines.
- A research pass on Orrinsford CSD's and Halvering's public pages → a values cheat sheet, a grounding brief, and company-knowledge questions.
- The two team members' names → a persona assignment for each member, and a sharper peer bank.
- The principal's public career path → an interviewer read and a reverse question tied to it.
- Any demo lesson or sample assessment HR mentioned → a build section for it.
- A tuesday-dossier.md, if you have one, would replace the inferred objection in S1 with the one it records.
