Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-5-rooms-case-13-denied-f0f74693/02c9e1d6-255a-4a91-b55b-6365328921bc/scratchpad/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. It is built only from the advert and your message. My web searches were refused, so nothing about Quillmoor's values, strategy or interview process is in it.

Three things to settle before Thursday:

- **Production scheduling is your biggest gap.** The advert asks for production schedules across planning, the warehouse and QA. Your closest material is scheduling deliveries across three depots. If you ever worked with planning, the warehouse or QA on what was produced, say so. If you didn't, say that plainly and stay with the deliveries. Hannah is likely to probe this one.
- **Give your notice period.** It isn't in your material, and she has said she will ask. Give the real figure; don't round it.
- **Keep the reason for leaving as you wrote it.** The Bristol office is closing next year, and the only offer is relocating to Reading, which you don't want. Don't criticise the company.

On the rest:

- **Pay:** £42,000 sits inside the £38,000–£44,000 band. Say it as your expectation and stop there.
- **Hybrid:** two days at Avonmouth works, and three is your limit. Say it once.
- **Dispatch reporting:** the advert asks for weekly on-time dispatch reporting, and your material doesn't show any. If you have reported on dispatch timing, say what and how often. If you haven't, say so and say what you would track first.
- **SAP:** say "I haven't used SAP. We ran our own in-house stock system." Don't call the in-house system ERP.
- **Excel:** your message says you rebuilt a stock-count spreadsheet but doesn't name the program. Be ready to say which one.
- **Discrepancy figure:** "about a third over a year" is the claim most likely to be probed. Be ready to say how it was counted, in your own words.

Ask Hannah about the first-month expectations, how the office days work across the team, and the next steps and timing. The pack has more questions with the reasons for each.

Drill offer: I can play Hannah and run the call with follow-ups, then give feedback on your answers to the pay, notice and A2 questions.

Dossier offer: I can save a `tuesday-dossier.md` recording the gaps this prep exposed, so they carry into later rounds.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Recruiter screen prep: Operations Coordinator, Quillmoor Diagnostics

**Interviewer:** Hannah Lowther, Talent Partner (recruiter)
**Format:** 30-minute phone call, Thursday 2pm. She calls the mobile number on the application.
**Her stated agenda:** salary expectations, notice period, hybrid pattern, reason for moving; then the team and next steps.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: JD (the listed job), EXP (your own record), CASE (a live problem), CO (company), VAL (values).
- Guidance is scaffolding for a spoken answer, not a script. Say it in your own words.
- Quoted sentences come from your message or the advert. Nothing here is a fact about your history that you did not write yourself.

## Fit snapshot

Advert requirements are quoted from the advert. Evidence is quoted from your message. Gap and bridge language follows what your material shows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | Met on the stated record. Say the four years and the job title in those words. No inspectable proof is attached, so expect a probe on the role's scope. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | low | [inferred] | transferability | Adjacent work only. Your material shows delivery scheduling across three depots, not production scheduling between planning, warehouse and QA. Say the delivery scheduling in those words. Whether you touched production planning is an answer slot (see A2). |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | none | Met in role terms. Say you chase suppliers when orders slip, and what you did when it happened. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | Met on the stated result. The figure is attached to the discrepancy count, not to accuracy in general. Expect a probe on how it was counted (see A4). |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show dispatch reporting. Answer slot in A9. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | transferability | Your message names a spreadsheet but not the program. Say what you built and in which tool, in your own words. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | Stated negative for SAP. Words: "I haven't used SAP. We ran our own in-house stock system." Adjacent stock-system work is real but is not ERP experience; do not call it ERP. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Gate met on your stated constraint. Two days works; three is the limit you set. |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Gate met on your stated expectation, which sits inside the advertised band. |

**Logistics slots (not gaps):**
- Notice period: not in your material. See A6.
- Location: "I live in north Bristol" (your message). Stated and not a gap.

## Prohibited list

These claims are not coached. Each has its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Has scheduled production | Inflated form of F2 | "I schedule deliveries for our three depots." Your material says deliveries, not production. |
| Has used SAP or ERP | Stated negative, F7 | "I haven't used SAP. We ran our own in-house stock system." |
| Owns stock control or dispatch reporting | Inflated form of F4 and F5 | "I rebuilt our stock-count spreadsheet." Nothing in your material shows you owned the stock process or dispatch reporting. |

## Persona weights

| Persona | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | High | A recruiter screen is friendly, but the questions are scored. | Give a 90-second career arc. Treat the casual question about the job's hard parts as scored. |
| Skeptic | High | Recruiter screens test knockouts and motivation consistency: pay, notice, hybrid, reason for leaving. | Answer each logistics question once, plainly. Do not add detail to make it sound better. |
| Data-Driven Prober | Medium | She may ask how the discrepancy figure was counted. | Say what you counted and what you would defend least, in your own words. |
| Pressure / Stress | Low | Unlikely in a screen. | Pause before answering; hold a stated position. |

## Question banks

### Conversational and Skeptic (weighted highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" · [grounded] "I schedule deliveries for our three depots" · [grounded] "chase suppliers when orders slip" | 90-second arc: the job title and years, then the three depots and the deliveries, then the supplier chasing. End on the stock-count result (A4). | F1, F2 and F3 are the arc; she is asking for the first two minutes of the call. |
| A2 | "This role coordinates production schedules between planning, the warehouse and QA. What is your experience there?" | JD | [grounded] "I schedule deliveries for our three depots" | Say the delivery scheduling in those words, and that it is the closest thing you have. Answer slot: if you ever worked with planning, the warehouse or QA on what was produced, say what that was and what part was yours. If you did not, say so plainly and stay with the deliveries. | F2 is the largest mismatch with the advert, and the likeliest probe. This is the highest-ROI prep in the pack: the answer is a limit stated truthfully, not a bridge. |
| A3 | "Have you used SAP or a similar ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | "I haven't used SAP. We ran our own in-house stock system, which I used for the stock-count work." Do not describe the in-house system as ERP. | F7 is a stated negative. The advert calls it a plus, so this is a screen question, not a deal-breaker. |
| A4 | "You mention discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "discrepancies fell by about a third over a year" | Say the count and the period in your own words. Name the assumption behind the figure you would defend least, before she does. Answer slot: if you counted the discrepancies yourself, say how; if the figure came from someone else's count, say so. | A figure you gave raises a defend-the-number slot. Do not invent a method. |
| A5 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot. Say £42,000 as your expectation. It sits inside the advertised band. Do not give a salary history you have not stated. | F9 fills the slot; no further detail is needed. |
| A6 | "What is your notice period?" | JD | none given | Logistics slot: give your actual notice period in your own words. Do not guess or round it. | Not in your material. This is an instruction for the call, not a question for this chat. |
| A7 | "How do you feel about two days a week at Avonmouth?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" · [grounded] "I live in north Bristol" | "Two days at Avonmouth is fine. I live in north Bristol. I would not want more than three." | F8 is a stated constraint. Say it once, plainly. |
| A8 | "What is prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say it as you stated it: the Bristol office is closing next year, and the only offer is relocating to Reading, which you do not want. Do not criticise the company. | The reason for leaving is a logistics slot. Your stated reason is the answer. |
| A9 | "Weekly on-time dispatch reporting is part of the role. Have you reported on dispatch performance?" | JD | none given | Answer slot: if you reported on dispatch timing, say what you reported and how often; if you did not, say so plainly and say what you would track first. | F5 is a discovery gap. Never describe dispatch reporting you did not do. |

### Logistics (recruiter's own agenda)

Covered by A5 through A8.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Coordinate production schedules between planning, warehouse and QA | A2 |
| Track supplier deliveries and chase late orders | A1 |
| Keep stock records accurate | A4 |
| Report weekly on on-time dispatch | A9 |
| Confident with Excel | none, and why: the call is unlikely to test the tool; if it does, the answer is your own (F6) |
| ERP (SAP or similar) a plus | A3 |
| Hybrid, two days at Avonmouth | A7 |
| Pay band £38,000–£44,000 | A5 |

## Reverse questions

Each has a line on why it lands.

1. "What does the first month look like for this role?" Why it lands: shows you are planning for the job, not just the offer.
2. "How are the two office days set across the team?" Why it lands: tests the hybrid pattern you named as a limit.
3. "How does planning share schedule changes with the warehouse and QA today?" Why it lands: asks about the exact gap in A2, from her side.
4. "What on-time dispatch figure does the team report weekly, and what is the target?" Why it lands: shows you read the advert's reporting line.
5. "What are the next steps and the usual timing after this call?" Why it lands: closes the screen cleanly and tells you when to expect the team conversation.

## Upgrade menu

- Notice period in your own words, once you have it → A6 becomes a stated logistics answer rather than an instruction.
- Whether you ever worked with planning, the warehouse or QA → A2's answer slot becomes a grounded answer.
- Which program the stock-count spreadsheet ran in → F6 moves from transferability to a stated fact.
- Whether you reported dispatch performance at all → A9's answer slot is resolved.
- Team or hiring-manager details, once Hannah shares them → a tailored reverse question for the next round.

## Sources

- Provided documents: the advert, and your message including Hannah's note.
- Research tier: L1 — searches 2 of 6, fetches 0 of 2. Both search calls were refused by the host, so no research result was used.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Refused. Would have moved a values cheat sheet, but this is a recruiter screen and no values round is detected. |
| 2. Quillmoor interview process | unavailable | Not sent, because search was refused. Would have moved persona weights for the rounds after this call. |
| 3. Quillmoor strategy / recent news | unavailable | Not sent. Would have moved the reverse questions and the context for the team conversation. |
| 4. Hannah Lowther, Talent Partner | unavailable | Not sent. The name was given, so the query could be formed. Would have added a public-footprint read of her role. |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the questions. |

Queries sent and refused: "Quillmoor Diagnostics values" and "Quillmoor Diagnostics Avonmouth Bristol site".

**Company facts used:** only the advert's own words and your message. Nothing about Quillmoor's values, strategy or interview process comes from outside them.
