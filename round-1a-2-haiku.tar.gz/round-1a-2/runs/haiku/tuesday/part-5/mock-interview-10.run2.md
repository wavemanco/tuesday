This invitation has some features that match common job scams: contact over Telegram, an interview and offer handled entirely in a chat, and no company email or video call. I'll check the posting and the recruiter before we prep, so you know whether to invest time in this one.
I'd hold off on the interview prep until you've checked this invitation. Your own condition was "if it looks legitimate," and it has a warning sign: the whole hiring process runs through a chat app, with the interview, the offer and onboarding all in Telegram. Legitimate remote employers rarely do that. Scammers use exactly this pattern, often to collect personal details, bank details or fees for "equipment" later.

**Before you reply to Marcus Hale:**

- **Check the job on Lumenvale's official website.** Open their careers page directly, not through a link in the Telegram message, and confirm the Customer Support Specialist role is listed there and matches the ad you applied to.
- **Check the recruiter.** Ask for a company email address, or a video call on Zoom, Teams or Google Meet with a named person. Look up the company's main site and contact details yourself, and compare them with what Marcus gave you.
- **Don't share anything yet.** Hold back your ID, bank details, tax or National Insurance numbers, and any address or payment information, until a real offer has been made through company channels. Never pay a fee, deposit a cheque or buy equipment for a job.
- **Ask for the interview on company email.** A legitimate employer will usually agree. If Marcus refuses or pushes you to move quickly, treat that as a strong warning sign.

To vet the posting and the recruiter properly, ask for a **job-underwriter** check. Send me the careers-page link or the full job ad, and what you have from Marcus, including his full name and any email address or domain he used. I can't run that check in this message.

Once the role checks out, I'll build the prep pack from your background, which is enough to start. It will cover Freshdesk and Zendesk-style ticketing, your refunds training of four starters, high-volume written communication, and escalation handling, plus questions for the team lead.