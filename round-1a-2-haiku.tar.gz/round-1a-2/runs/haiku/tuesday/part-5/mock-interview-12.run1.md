Before the prep, one thing in the invite: it asks you to pay the "€95 equipment registration fee" to a supplier's account before your slot is confirmed, to send "a photo of your passport and your bank details before the interview", and to deposit a "€1,850 cheque" and send "the balance on to the vendor". Requests like these, before any offer, are a known scam pattern, and this job is very likely a scam. Hold all three: the payment, the cheque, and sending your passport or bank details. Check the invite with the employer using a phone number or address from its own website or careers page, not from the email. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite checked as a separate request, job-underwriter can do that.

I couldn't run a web search on the company, so nothing below about Brennock is sourced. The prep is built from your message and the ad.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-5-rooms-case-12-denied-2e59a8e5/1efa7a0b-e81c-451e-9616-a29f5d0aae67/scratchpad/brennock_remote_admin_assistant_interview_pack.md.

**What to expect:** a 30-minute video call with an office manager. Expect a practical case, such as a supplier invoice that shows paid on the system but unpaid at the bank, and a probe on the gaps in your material: Excel, travel booking and invoice processing. Your strongest evidence is running the appointment book for four physios. Expect a "why hire someone with no admin-role experience?" challenge, and hold your position before conceding the specific gap.

**How to prepare:**
- Practise the appointment-book story in 90 seconds, in your own words.
- Decide how you'll answer the Excel and travel gaps honestly. Say what you've done, and say how you'd learn the rest.
- Describe the invoice work as you did it: you chased unpaid invoices. Don't claim you processed them.
- Prepare five or so questions for them, such as the first month and how invoices are approved.

Two offers, neither pushed: I can play the Skeptic on B1, the question the pack names as the highest-value prep, or save a `tuesday-dossier.md` recording the gaps this prep exposed.

Is the office manager your future manager, or someone who would work alongside you? The answer changes which questions are most likely.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote_admin_assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: office manager (name not given). Round: 30-minute video call. Relationship assumed: hiring manager.
Research tier: L0. No web search ran. The one company-name check was refused by permission, so nothing below about the employer is sourced.

## How to use this pack

- Personas are how a question is asked. Types are what it scores: EXP (your past), JD (the listed duties), CASE (a live problem), VAL (values; none detected), CO (company knowledge; none established).
- Guidance is scaffolding, not a script. Say only what you actually did, in your own words.

## Prep triage

With a 30-minute call, prepare in this order:
1. A1 (appointment book): say it in 90 seconds, in your own words.
2. B1 (weakest on day one): decide how you'll answer the Excel and invoice gap honestly.
3. C1 (why hire you without admin-role experience): hold your position, then concede specifically.
4. E1 (reverse questions): ask at least two.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (job ad, as you summarised it) | "ran the appointment book for four physios" (your message) | medium | [grounded] | none | No gap. Lead with the quote: you ran the appointment book for four physios. |
| F2 | "booking travel" (job ad, as you summarised it) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say what and for whom; if not, say so and say how you would learn the booking tool. |
| F3 | "preparing documents in Word" (job ad, as you summarised it) | "good with Word" (your message) | low | [grounded] | presentation | Your material says good with Word and nothing more. Say what you have produced in Word, and only what you actually made. |
| F4 | "preparing ... in Excel" (job ad, as you summarised it) | "okay with Excel" (your message) | low | [grounded] | discovery | Your material does not show Excel work. Answer slot: name one Excel task you have done, or say you have not and say what you would learn first. |
| F5 | "processing supplier invoices" (job ad, as you summarised it) | "chased unpaid invoices" (your message) | low | [grounded] | transferability | Chasing unpaid invoices is not processing them. Say what you did with the invoices, and stop there. |

Where I did not find a sentence in your material, I say so rather than fill the gap.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed executive or company calendars | Inflated form of F1 | You ran an appointment book for four physios. The limit is the pack's observation: your material shows appointments, not executive calendars. |
| Booked business travel | Silence in F2 | No claim. Answer slot only. |
| Processed supplier invoices | Inflated form of F5 | You chased unpaid invoices. Nothing more. |
| Expert in Excel | Inflated form of F4 | Okay with Excel, as you said. |

## Interviewer read

No interviewer name was given, so there is no public footprint to read. The upgrade menu says what a name would add.

## Persona weights

| Persona | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | high | Office-manager hiring round: they will test how you would handle a real admin problem | Think aloud; ask one clarifying question first |
| Skeptic | high | Your gaps (Excel, invoices, travel) are the obvious probes | Rehearse B1 until it is plain, not defensive |
| Pressure | medium | A 30-minute slot is short, so time-boxing is likely | Pause, restate, hold for two follow-ups |
| Conversational | medium | Opening small talk is common in these calls | Keep the 90-second arc ready |

## Question banks

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier invoice shows paid on the system, but the bank shows it unpaid. What do you do?" | CASE | [generic] | Structure it: check the payment record, check the bank reference, contact the supplier, log what you found, and tell the approver. The question needs no claim about your past | A live invoice problem drawn from the ad's invoice duty; generic because it is a pattern, not a fact about this employer |
| D2 | "How would you plan a diary for a manager with three back-to-back meetings and a flight?" | CASE | [generic] | Clarify priorities, check the flight time, protect buffers, confirm with attendees, and say what you would ask first. Do not claim a past instance | Tests calendars and travel together; generic because it asks about method |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "okay with Excel" | Highest-ROI prep. Name Excel as the weakest area and say how you would learn it in the first week. Answer slot: if you have built anything in Excel, say what; if not, say so plainly. Do not claim spreadsheet work you have not done | F4 is the thinnest evidence and the likeliest probe |
| B2 | "Have you booked travel for anyone? How would you handle it if you had not?" | JD | [generic] | Answer slot: if you have booked travel for anyone, say what and for whom; if not, say so and describe how you would learn the booking tool and check bookings | F2 is a silence in your material, not a stated negative, so the question asks rather than presumes |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we hire someone with no admin-role experience?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Pause. Restate the question. Hold the position: two years of front-desk work where you ran a booking system and followed up on payments. Hold through two follow-ups. Then concede specifically: you have not held this exact role | F1 and F5 are your strongest honest bridges, and the concession is the credibility move |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the appointment book you ran for the physios." | EXP | [grounded] "ran the appointment book for four physios" | Tell the beats your quote states: four physios, an appointment book, the run of it. Answer slot: if you set booking rules or handled clashes, say which and how you decided; if not, say so and describe how the book was run | F1 is your best evidence, and the probe is likely |
| A2 | "What else did the front desk handle?" | EXP | [grounded] "chased unpaid invoices" | Name the front-desk tasks you did. Keep invoice chasing at its own scope | Opening small talk that becomes a scored answer |

## Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| Managing calendars | A1, D2 | |
| Booking travel | B2, D2 | Answer slot only |
| Word and Excel documents | B1 | Excel probed; Word not separately probed |
| Supplier invoices | D1, A2 | |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| E1 | "What does a typical week look like for this role?" | Shows you want the detail, not just the title |
| E2 | "Which systems will I use for calendars, travel and invoices?" | Shows you are thinking about the work |
| E3 | "How is the first month structured, and who would I learn from?" | Shows you plan to get up to speed |
| E4 | "What would success look like at the end of the first three months?" | Makes the expectations concrete |
| E5 | "How are supplier invoices approved, and who signs off?" | Shows you understand the invoice path |

## Prohibited list reminder

No answer slot, hold or bridge in this pack asserts any claim in the prohibited table above.

## Upgrade menu

- The full job ad text → the fit snapshot rows become quoted, not summarised
- The office manager's name → a tailored reverse question and persona weights from public footprint
- The employer's own careers page, read or pasted → confirms the company and the round's format
- A recruiter email confirming the interview details → confirms the process
- `tuesday-dossier.md` from a prior session, if one exists → sharper objections and verified evidence
