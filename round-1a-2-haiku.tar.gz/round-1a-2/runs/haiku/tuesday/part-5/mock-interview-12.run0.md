Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." before your slot is confirmed. It asks you to "reply with a photo of your passport and your bank details before the interview." And for the €1,850 "cheque", it says "you deposit the cheque and send the balance on to the vendor." Paying a fee to hold a slot, depositing a cheque and forwarding the balance, and sending a passport and bank details before any offer are a known scam pattern. The fee request and the cheque request are very likely a scam. Hold all of these until you have checked the invite with the employer, using contact details from its own website or careers page, not anything in the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-5-rooms-case-12-denied-686e92e4/6fb75563-a968-400d-914a-ccfd12cd0b16/scratchpad/brennock_remote-administrative-assistant_interview_pack.md. It's built for a 30-minute video call with an office manager, from your summary of the ad and your background, with no outside research.

**What to expect:** a short call where the office manager tests the two duties your material doesn't show well: booking travel and processing supplier invoices. Expect a question on your Excel level, a short admin scenario, and a question on remote work. Your "chased unpaid invoices" is the strongest bridge to invoices, but it is the other side of the ledger, so say that plainly.

**How to prepare, in order:**
1. A3 (invoices). This is the highest-value rehearsal in the pack.
2. A2 (travel) and D2 (how much of the appointment book was yours).
3. B3 and B2, the short scenarios.
4. Then the rest of the file.

Only say what you actually did. If you haven't booked travel or processed an invoice, say so and explain how you'd learn it.

Say the word and I'll run a drill on A3. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two questions:
- Where is the role based, and could you work there? The invite doesn't say, and the pack can't assume it.
- Where did you see the ad: the company's own careers page or a jobs site?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Changelog: first version.

Built at research tier L0 (your message only). The job ad was supplied as your summary, not verbatim text, so requirements are unquoted. The interview is a 30-minute video call with an office manager. The pack is shorter than the usual 18–26 questions because a 30-minute call cannot take more rehearsal than this.

## How to use

Personas are how a question arrives. Types are what is being scored:

- **JD**: the job's stated duties
- **EXP**: what you actually did
- **CASE**: a live problem on the role
- **CO**: company knowledge (none here, because no research ran)
- **VAL**: values (none here, because no values were supplied)

Guidance is scaffolding, not a script. Say only what you did.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Manage calendars (your summary of the ad) | "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Words: "I ran the appointment book for four physios." The material shows an appointment book covering four physios, not executive calendars. Do not describe the scope as wider. Expect a probe on how many diaries you could change. |
| F2 | Book business travel (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: say whether you have booked travel for anyone, what you booked and with which tool. If you have not, say so plainly, then say how you would learn the company's booking process. |
| F3 | Prepare documents in Word (your summary of the ad) | "I'm good with Word" — your message | medium | [grounded] | presentation | Words: "I'm good with Word." Caveat: your material gives no example of a document you produced, so expect a probe on one. |
| F4 | Prepare documents in Excel (your summary of the ad) | "okay with Excel" — your message | low | [inferred] | discovery | Your material gives a self-rating and no task. Answer slot: name one thing you have done in Excel, in your own words. If you have done nothing yet, say so plainly and say what you would learn first. |
| F5 | Process supplier invoices (your summary of the ad) | "chased unpaid invoices" — your message | low | [inferred] | transferability | Adjacent work. Chasing money owed to the clinic is the other side of the ledger from checking and paying bills a supplier sends you. Words: "I chased unpaid invoices." Limit, as the pack's observation: the material does not show processing supplier invoices. Any wider step is an answer slot inside the quote's scope: if any part of the chasing involved checking an amount or an account, say which, in your own words. |
| F6 | Work remotely as an administrative assistant (job title) | none given | none | [grounded] | discovery | Your material shows a reception role and does not say whether it was on site or remote. Answer slot: say whether you have worked remotely and with which tools. If not, say so plainly and say what you would set up first. |

## Prohibited claims

Not coached, with the basis for each:

| Not coached | Basis | Honest form |
|---|---|---|
| Has processed supplier invoices | Inflated form of F5 | "I chased unpaid invoices." The material shows chasing money owed, not processing supplier invoices. A3's slot stays inside the quote. |
| Manages executives' calendars | Inflated form of F1 | "I ran the appointment book for four physios." The material shows an appointment book, not executive calendars. |
| Is expert in Excel | Inflated form of F4 | "okay with Excel", at its own scope. The Excel answer is A4's slot. |

## Persona weights

Prior: an office manager on a short screen is closest to a hiring-manager round, so Skeptic and Case lead. No interviewer profile was supplied, so there is no adjustment from it.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | "What have you done with travel and invoices?" | High. The two duties with the thinnest material are the first thing an office manager checks. | Rehearse A3 first. Answer from your quoted sentences and name the limit plainly. | 5 (top) |
| Case / Strategist | A live admin problem: a booking clash, a bill with no approval | Medium. Admin roles are often tested this way in short calls. | Clarify first, then say the steps aloud. | 3 |
| Conversational | A warm opener about your background | High, but cheap. Casual questions are still scored. | Use the 90-second arc in C1. | 2 |
| Pressure | "Why you over someone with experience?" | Low to medium in a 30-minute screen. | Hold the position, then concede the specific gap. | 2 |

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the appointment book you ran for four physios. What did a normal day involve?" | JD, EXP | [grounded] "ran the appointment book for four physios" | Tell the day in your own words: the bookings, the changes, the calls. Say which of those were yours to make. | F1 is the only evidence for the calendar duty. The question tests what was yours. |
| A2 | "Have you ever booked travel for someone else? Which tools did you use?" | JD | [grounded] the travel duty in the ad, your summary; no candidate sentence | Answer slot: if you have booked travel for anyone, say what you booked and with which tool, in your own words. If you have not, say so plainly, then say how you would learn the company's booking process. | F2 has no evidence. The travel duty is the likeliest gap probe. |
| A3 | "The role processes supplier invoices: checking them, coding them and getting them paid. What have you done with invoices like that?" | JD | [grounded] "chased unpaid invoices" | Highest-ROI rehearsal in this pack. Hold: "I chased unpaid invoices." Answer slot: if you checked or coded any bill a supplier sent you, say how. If not, say so plainly and say which part of chasing unpaid invoices carries over. Hold through two follow-ups by returning to what you chased. | F5 is where the duty and the material are furthest apart, so this objection will arrive in some form. The premise is the ad's duty, not a claim about you. |
| A4 | "How have you used Excel, and what would you need to learn for this role?" | JD | [inferred] "okay with Excel" | Answer slot: name one thing you have done in Excel, in your own words. If none, say so plainly and say what you would learn first. Do not rate yourself above "okay" in the interview. | F4 is low confidence, so the rehearsal is about giving the honest answer. |
| A5 | "Have you worked remotely before, and what tools did you use to stay in touch?" | JD | [grounded] the job title in the ad, your summary; no candidate sentence | Answer slot: say whether you have worked remotely and with which tools. If not, say so plainly and say what you would set up first. | F6 is discovery. Remote work is in the title, so expect the question. |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A director asks you to book flights and two hotels for a conference, with a tight budget. Talk me through your first five minutes." | CASE | [generic] | Clarify first: dates, budget ceiling, travel policy, who approves. Then say what you would book and what you would check before booking. Make no claim about past bookings. | A live problem from the travel duty. Generic, because it draws on no fact of yours. |
| B2 | "Two diaries clash with a 9am client call, and the director is in another time zone. What do you do?" | CASE | [generic] | Clarify who can move. Offer two options and say whom you would ask first. | A live problem from the calendar duty. |
| B3 | "An invoice arrives with no purchase order and a due date in two days. What do you do?" | CASE | [generic] | Say what you would check first (approval, the order), what you would not do (pay before approval), and whom you would escalate to. | A live problem from the invoice duty. A process question, so it makes no claim about you. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey to here." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | A 90-second arc: the clinic, the appointment book, the invoices you chased, and what you want next. Tell it in your own words and add nothing. | A biography opener, and scored for communication. |
| C2 | "What do you use Word for day to day?" | JD | [grounded] "I'm good with Word" | Answer slot: say one kind of document you have produced, in your own words. If you have not produced one, say so plainly. | F3 is medium, so a probe is likely. A rehearsed example beats an adjective. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone with supplier-invoice experience?" | JD | [grounded] "chased unpaid invoices" | Hold: the two years of reception work and the invoices you chased are what you bring. Then concede the gap in one specific sentence in your own words. If you have not processed supplier invoices, say so. | Hold, then concede. The question names another candidate, not a negative about you. |
| D2 | "Two years at a reception desk. How much of that appointment book was really you?" | EXP | [grounded] "ran the appointment book for four physios" | Hold the quote: "I ran the appointment book for four physios." Concede specifically. If others edited the book too, say who and what they did. If you did not decide the bookings, say so. | An attribution probe, the one most likely to be pressed. |

Session total is 12 questions, below the usual range, because the call is 30 minutes.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Manage calendars | A1, B2 |
| Book business travel | A2, B1 |
| Prepare documents in Word | C2 |
| Prepare documents in Excel | A4 |
| Process supplier invoices | A3, B3, D1 |
| Remote working | A5 |

## Reverse questions

| Question | Why it lands |
|---|---|
| What does a normal week look like for this role? | Shows you are thinking about the job, not only the offer. |
| How do you usually approve travel and invoices? | Shows you care about process and controls. |
| Which tools does the team use for calendars and invoices? | Signals you will learn them quickly. |
| What would a good first three months look like? | Gives you the success criteria. |
| What are the working hours, and how does the team stay in touch when people are remote? | Covers the remote and hours questions the ad leaves open. |
| What happens after this call? | Shows you are organised about next steps. |

## Sources

Provided documents: your message (the invite as you quoted it, your summary of the ad, your background). No outside research.

Research tier: L0. Searches 0 of 0, fetches 0 of 0.

| Target | Status | What it would have moved |
|---|---|---|
| 1. company values | unavailable | Values section, not included. Research tier L0; no consent given. |
| 2. company interview process | unavailable | Loop structure. The 30-minute call is taken from the invite. |
| 3. company strategy / recent news | unavailable | CO questions. None included. |
| 4. interviewer name and company | n/a | No name given, so no query could be formed. |
| 5. representative job ad | unavailable | Requirement wording. The ad summary fixes the rows. |

## Upgrade menu

- The full job ad text: the requirement rows can quote the ad, so they become verbatim [grounded] rows instead of your summary.
- Any travel booking or invoice processing you have actually done: F2 and F5 get your own words, and A2 and A3 get answers in place of slots.
- The interviewer's name: a tailored reverse question and persona weights from their public footprint.
- Research at the L1 tier, with your go-ahead: company values and the interview format.
