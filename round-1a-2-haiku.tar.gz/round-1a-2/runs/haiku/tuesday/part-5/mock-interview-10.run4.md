Before the prep, one thing in the invite. It says "our hiring process is fully remote and is carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well." A hiring process run wholly by chat, including the offer and onboarding, is a pattern scammers also use. That doesn't tell me this invite is one. Until you've checked it, send no documents, bank details or payments through the chat. Check Lumenvale through a phone number or address from its own website or the careers page where you applied, not any contact details in the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the posting and this invite checked, job-underwriter can do that as a separate request.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-5-rooms-case-10-denied-fa00d23a/14ff5937-0d91-4fbd-9328-20a9f6fc1a36/scratchpad/Lumenvale_customer-support-specialist_interview_pack.md`. I built it for a team-lead round and treated the team lead as a hiring manager. It's 11 questions, short of the usual range, because I only have your summary of the ad. The main thing to rehearse is S1, "You haven't worked for a software company." Say that plainly first, then bridge from Freshdesk and your daily volume.

Say the word and I'll play the Skeptic on S1 in a live drill.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

Is the team lead the person you'd report to, and is the chat a live session with a set time, or do they send any task beforehand?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Lumenvale_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

Round: text-chat interview with the support team lead (name not given). Treated as a hiring-manager round. Changes since the last version: none (first version).

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored: EXP (your past), JD (the listed job), CASE (a live problem), VAL (values; not used here).
- Guidance is scaffolding, not a script. Each guidance cell is written to be spoken in 90 to 120 seconds.
- Answer slots ("if you did X, say how…; if not, say so plainly") are instructions for the interview. They are not questions to me.

## Fit snapshot

Requirements are your own summary of the ad, since the full text was not pasted. Rows marked as gaps are the ones the material does not show.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | 2+ years in customer support (your summary of the ad) | "3 years as a customer service advisor at an energy supplier" — your message | high | [grounded] | none | No gap. Say the years and the role in those words. |
| F2 | Zendesk or a similar ticketing tool (your summary of the ad) | "I use Freshdesk every day" — your message | high | [grounded] | none | Freshdesk is a ticketing tool of the kind the ad names as "or similar". Say that you use it every day. Do not say you have used Zendesk; your material does not show it. |
| F3 | Clear written communication (your summary of the ad) | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Volume of emails does not show how clearly you wrote them. Answer slot: if any of those replies or your refund guidance could be shown as an example, say what it was and who saw it; if none could, say so and say how you would show your writing in the chat. |
| F4 | Confidence handling escalations (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not show escalations. Answer slot: if you handled escalations, say what kind and what you did, in your own words; if you did not, say so plainly and describe how you would decide what to do with one. |
| F5 | Trained others on process (not in the ad; in your message) | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | A strength to lead with. Say what you taught and how you checked it (see P3). |

## Prohibited claims

Built locally from the fit snapshot. These are claims a candidate reaches for under pressure, and the pack will not coach them.

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Inflated form of F2 | "I use Freshdesk every day." Your material shows Freshdesk, not Zendesk. |
| Designed or owned the refunds process | Inflated form of F5 | "I trained four new starters on our refunds process last year." Your material says trained, not designed. |
| Handled escalations | Silence on F4, so this is not a listed claim; it is an answer slot | Answer slot in F4 only. |

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Case / Strategist | A live support scenario from the team lead's queue | High: a team lead is buying handling ability; the ad names escalations | Clarify, then act: confirm the facts, check the policy, decide, then tell the customer what happens next | 4 (top weight) |
| Skeptic | "Why should we trust you without software experience?" | High: you named the gap yourself in your message | Say the gap plainly, then bridge only from what you stated | 3 |
| Data-Driven Prober | Asks how your 60-a-day figure was counted | Medium: a headline number you gave | Know what you can and cannot say about the figure; name the assumption you would defend least | 2 |
| Conversational / Rapport | Opens with "walk me through your background" | Medium: chat interviews open casually, and casual questions are still scored | A 90-second arc built from the three sentences you gave | 2 |

Totals: 11 questions. That is below the usual 18 to 26 because the full ad is missing. The upgrade menu says what the full ad adds.

## Question banks

### Case / Strategist (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A customer writes in: they were charged twice and want a refund today. Walk me through your first ten minutes." | CASE | [generic] | Clarify first: which charge, which account, what policy says. Then decide the refund path, tell the customer what happens and when, and say when you would escalate. Claim no past case here. | A live problem from the role. Generic because it names no fact about you. |
| C2 | "A customer escalates: an agent promised a refund we can't give. What do you do?" | CASE | [generic] | Structure: take ownership of the promise, check what was actually said, decide what you can offer, and say what the customer hears next. Raising source: "confidence handling escalations" — your summary of the ad. Answer slot (F4): if you have handled an escalation like this, say what it was and what you did; if not, say so plainly and describe your decision. | Tests F4, the requirement your material does not show. |
| C3 | "Write the reply you would send to a customer whose refund is a week late." | CASE | [generic] | Write it live: short, plain, one apology, one date, one next step. Test it on the page before you send it. | Tests the written-communication requirement (F3) directly. |
| C4 | "Our tool is Zendesk. How would you get up to speed in your first week?" | JD | [grounded] "I use Freshdesk every day" — your message | Say you use Freshdesk every day, in those words. Then describe how you would learn Zendesk: a plan, not a past. Answer slot: if you have used Zendesk, say so; if not, say so plainly. | Tests F2. The raising source is the ad's "Zendesk or similar" line. |
| C5 | "What would you do with a queue of 60 contacts a day that you could not finish?" | CASE | [grounded] "answering around 60 calls and emails a day" — your message | Say how you triage: what goes first, what waits, what you tell customers about waiting. Answer slot: if you had to do this, say how; if you did not, say so plainly and describe how you would prioritise. | Links the volume you gave to the job's pace. |

### Skeptic (weight: second)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You haven't worked for a software company. Why should we trust you with our product?" | EXP | [grounded] "I've never worked for a software company." — your message | Say it plainly first: "I've never worked for a software company." Then bridge only from what you stated: daily use of Freshdesk, and answering around 60 contacts a day. Answer slot: say how you would learn the product in your first month, in your own words. | The most predictable objection. Highest-ROI rehearsal in this pack. |
| S2 | "Why would you leave energy for a software company?" | EXP | [generic] | Give the reason in your own words. Name what in the ad draws you. Answer slot: if you have looked at Lumenvale's own site or product, say what you found; if not, say so plainly. | No reason is stated in your material, so none is put into your mouth. |
| S3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "confidence handling escalations" — your summary of the ad | Name escalations as the part your material does not show (F4), then say what you would do. Do not claim experience you have not stated. | A Skeptic's favourite question. Answering it first beats being caught. |
| S4 | "Support is mostly writing. Show me how you write a reply in this chat." | JD | [grounded] "clear written communication" — your summary of the ad | Write live, in the chat. Short sentences, no filler, one clear ask. | Tests F3 in the same medium the job uses. |

### Data-Driven Prober (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "You say about 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Say how you know the figure, in your own words. Name the assumption behind it you would defend least. Answer slot: if you do not know how it was counted, say so plainly. | Defend-the-number: the figure you gave is a magnet for probing. |
| P2 | "Of those 60, what share were ones you would call difficult?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Give a share only if you know it; otherwise say you do not know. Do not estimate in the room and present it as a count. | Same figure, second angle. Honest branch is "I don't know". |
| P3 | "How did you check that the four new starters had the refunds process right?" | EXP | [grounded] "I trained four new starters on our refunds process last year" — your message | Answer slot: if you checked their work, say how; if you did not, say so plainly and describe what you would do. | Tests F5's depth. The question presupposes a checking method only as a probe; the answer is yours. |

### Conversational / Rapport (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through your background." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" — your message; "I use Freshdesk every day" — your message; "I trained four new starters on our refunds process last year" — your message | A 90-second arc built only from those three sentences: the role and years, the daily tools, the training. Stop there. | An opener that is still scored. |
| R2 | "What part of support work do you most want to do more of?" | EXP | [generic] | Name a task you have actually done and want more of. Answer slot: if you have not done one yet, say what you would like to try first. | An open prompt with no source in the material. |
| R3 | "What would you change about how refunds are handled?" | EXP | [grounded] "I trained four new starters on our refunds process last year" — your message | Answer slot: say what you would change and why, based on what you saw; if you have no view, say so plainly. | Lets you show judgment about process without claiming you owned it. |

## Requirement coverage

| Requirement (your summary of the ad) | Covered by |
|---|---|
| 2+ years in customer support | R1 |
| Zendesk or a similar ticketing tool | C4, S3 |
| Clear written communication | C3, S4 |
| Confidence handling escalations | C2, S3 |

## Reverse questions

Each one has a why it lands. There is no interviewer profile, so none is tied to a career path.

1. "What does a good first 30 days look like for someone in this role?" Why it lands: it shows you are already planning the job.
2. "How do escalations move from the front line to the team lead, and how often does that happen?" Why it lands: it asks about F4 without you confessing to it.
3. "How many contacts a day does the team handle, and across which channels?" Why it lands: it makes your 60-a-day figure comparable.
4. "What does a good week look like for the support team?" Why it lands: it shows you want to be measured on the right thing.
5. "What happens after this chat, and who would I hear from next?" Why it lands: it finds out the process, which matters given how this one is run (see the message).

## Research tier and target accounting

No research was run. The inputs are your message and the invite text you pasted.

Research tier: L0. No searches or fetches.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Lumenvale values | unavailable | Values cheat sheet: not built |
| 2. Lumenvale interview process for customer support | unavailable | Loop structure and persona weights |
| 3. Lumenvale strategy and recent news | unavailable | Grounding brief and CO questions |
| 4. Interviewer name and profile | n/a | No name was given |
| 5. Representative Customer Support Specialist JD | unavailable | Fit rows' requirement text, [inferred] rows |

## Upgrade menu

- The full ad text → the requirement rows become quoted and [grounded], and the rest of the 18-question range can be filled.
- The team lead's name → a tailored reverse question, and persona weights from any public footprint.
- Lumenvale's values or interview process, researched at L1 → a values section and loop-specific questions.
- Any example of your written replies, anonymised → F3 moves from discovery toward a quoted line.
- `tuesday-dossier.md` → records the gaps this prep exposed, for later sessions.
