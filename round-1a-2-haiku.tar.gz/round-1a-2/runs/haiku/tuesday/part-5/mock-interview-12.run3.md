Before the prep, one thing in the invite: it asks you to transfer the "€95 equipment registration fee" to a supplier's account, to reply with "a photo of your passport and your bank details before the interview", and it describes a "cheque for €1,850" that you deposit before sending "the balance on to the vendor". Paying a fee for equipment, depositing a cheque and passing on the balance, and sending ID and bank details before any offer are a known scam pattern, and this invite is very likely a scam. Hold all of it: don't pay, deposit the cheque, or send your passport or bank details until you have checked the invite with the employer, using a phone number or address from the employer's own website or careers page, not from the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-5-rooms-case-12-denied-2e0aa546/756436e5-1688-4f71-9963-826ed06f4e16/scratchpad/brennock_remote-administrative-assistant_interview_pack.md`.

**What to expect:** a 30-minute video call with the office manager, probably first-round. Expect two lines of questions. The first checks the parts of the ad your background doesn't reach directly: calendars, travel booking and supplier invoices. The second checks your Word and Excel. Expect "why move from a clinic?" too.

**How to prepare:**
- Rehearse A1 and A2 aloud. They are the two gaps the call is most likely to press on. Answer with what you did: the appointment book, the invoices you chased. Say plainly what you haven't done.
- Be honest about Excel. "Okay" is fine if it's true, followed by one thing you have actually done in it.
- Practise a 90-second walk-through of your background (C1).
- Prepare three or four of the five reverse questions. Question 3, about who approves supplier invoices, is the one that tests the employer.

I can also run a drill where I play the Skeptic on A1. I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the full ad text? The four requirement rows are only as good as your summary of it.
2. Is the office manager the only person on the call, and is it the only interview step?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote-administrative-assistant_interview_pack.md -----
# Interview prep: Remote Administrative Assistant, Brennock Facilities Ltd

Interview: 30-minute video call with the office manager. Round type: first-round, hiring-side. Interviewer's name not given.

**Changed since last version:** not applicable (first version).

## How to use + type key

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- JD = the ad's requirement. EXP = your past work. CASE = a live problem. Provenance labels: [grounded] traces to your message; [inferred] is this pack's derivation from your words; [generic] is a pattern with no claim about you.
- Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

Requirements come from the ad as your message summarises it. Full ad text was not supplied, so these four lines are your summary, not the employer's wording.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (the ad, as your message summarises it) | "I ran the appointment book for four physios" (your message) | medium | [grounded] | transferability | Your material says an appointment book for four physios, not calendars for an office. Bridge at its own scope: "I ran the appointment book for four physios." Answer slot: if you moved, protected or resolved clashes in other people's diaries, say how you decided; if you did not, say so plainly and stay with the appointment book. |
| F2 | "booking travel" (the ad, as your message summarises it) | none given | none | [grounded] | discovery | Your material does not show travel booking, and you have not said you have none. Answer slot: if you have booked travel for anyone, say what and for whom; if you have not, say so plainly and say how you would learn the booking tools. |
| F3 | "preparing documents in Word" (the ad, as your message summarises it) | "I'm good with Word" (your message) | medium | [grounded] | none | Word reaches the requirement in role terms. The claim is self-reported, so expect a request for an example. Answer slot: name a document you have produced in Word, in your own words. |
| F4 | "preparing documents in Excel" (the ad, as your message summarises it) | "okay with Excel" (your message) | low | [inferred] | discovery | "Okay" is your own word and does not show what you did in Excel. Derivation: this pack's reading of your word, not a claim about your skill. Answer slot: if you have built or maintained a spreadsheet for others, name what it tracked; if not, say so plainly and say what you would practise first. |
| F5 | "processing supplier invoices" (the ad, as your message summarises it) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | Chasing is adjacent to processing, so the bridge stays at chasing. Bridge: "I chased unpaid invoices." Answer slot: if you entered, matched or approved any supplier invoices, say how; if you did not, say so plainly and describe the chasing you did. |

## Prohibited claims

Built locally from the fit snapshot. These are the stretched forms of your own sentences. No guidance below asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| "I manage executive calendars" | Inflated form of F1 | F1's quote at its own scope. The pack's observation, not words for you: your material says an appointment book for four physios. |
| "I process supplier invoices" | Inflated form of F5 | "I chased unpaid invoices", at its own scope. |
| "I am experienced in Excel" | Inflated form of F4 | "okay with Excel", at its own scope. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the requirements your material does not reach | Top weight (depth 4). A hiring-side first round for an admin job lists four duties; two of them are adjacent to your background, and the Skeptic tests the adjacency. | Rehearse the thinnest rows (F1, F2) until the honest branch is easy to say. Never stretch the bridge. |
| Case / Strategist | A live scheduling or invoice problem | Mid weight (depth 3). A hiring manager for an operations role often checks how you would handle the work itself. | Clarify before acting: who has priority, what is fixed, what can move. |
| Conversational | A friendly opener that is still scored | Low weight (depth 2). The call is 30 minutes, so the opener and the close carry more weight than usual. | Keep a 90-second arc ready. Treat every casual question as scored. |

## Question banks

### Skeptic (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The role manages executive calendars and books travel. Where does that show up in your background?" | JD | [grounded] "I ran the appointment book for four physios" | Say what you did with the appointment book, in those words. Answer slot: if you moved or resolved clashes in other people's diaries, say how you decided; if you did not, say so plainly and describe how you would learn the calendar tools in week one. Hold through two follow-ups by returning to the appointment book. | F1 and F2 are the thinnest rows and the highest-ROI rehearsal in this pack. This is the objection most likely to come up in some form. |
| A2 | "Supplier invoices are a big part of this job. What have you done with them?" | JD | [grounded] "chased unpaid invoices" | "I chased unpaid invoices." Say what the chasing involved, in your own words. Answer slot: if you entered, matched or approved any supplier invoices, say how; if not, say so plainly. | F5 is the requirement the ad lists last and the one your chasing line most nearly reaches. |
| A3 | "Why move from a clinic front desk into office administration?" | EXP | [generic] | Selection scaffold: pick the real reason, one you can say in a sentence and stand behind. If it is pay, hours or the remote setting, say that. Do not build a story about wanting admin work. | Skeptics test motive. No quoted sentence carries a motive, so the guidance asks for yours. |
| A4 | "This role is remote. How do you keep a diary and shared documents organised when no one is in the room?" | JD | [grounded] "Remote Administrative Assistant" (the title in your message) | Answer slot: if you have worked remotely, say how; if you have not, say so plainly and describe how you would keep track of diaries and files. | The title sets the setting, and the question asks how you would work in it. |

### Case / Strategist (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two directors need the same boardroom at the same time, and one of their flights has moved. What do you do?" | CASE | [generic] | Structure it: check the priority with both directors; check which commitment is fixed and which can move; rebook the flexible one; confirm in writing; record the change. Makes no claim about your past. | Calendars and travel are both named in the ad, so a live scheduling problem is a likely check. |
| B2 | "An invoice arrives with no purchase order, and the supplier is chasing you. What do you do?" | CASE | [generic] | Structure it: check the approval rule; find who owns the spend; do not release payment outside the approval route; reply to the supplier with what happens next; record it. | Invoice processing is named in the ad, and this is the live version of it. |

### Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios" | A 90-second arc: the clinic, the appointment book, the invoice chasing, then Word and Excel in your own words. Add nothing your message does not contain. | The opener is scored for economy and fit. |
| C2 | "What do you use day to day for documents?" | JD | [grounded] "I'm good with Word" | Name the kinds of document you produce, in your own words. Answer slot: if one example comes to mind, name it; if none does, say so plainly. | F3 is the only row with no gap, so this question is a chance to show it. |
| C3 | "How comfortable are you with Excel?" | JD | [inferred] "okay with Excel" | Answer honestly. If "okay" is the truth, say it, then say what you have actually done in Excel. Answer slot: name one spreadsheet task you have done, or say you have not done one. | F4 is the low-confidence row, so the honest answer is what the call tests. |

## Reverse questions

At least five, each with why it lands. Ask them in the call.

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a typical week look like, and how is the time split between calendars, travel and invoices?" | Shows you are pricing the work, not just applying for it. |
| 2 | "Which systems do you use for calendars, travel and supplier invoices?" | Shows you have thought about the tools before you start. |
| 3 | "Who approves supplier invoices, and what is the approval route?" | Checks the process. A real role has a real answer, and the reply tells you how payments are authorised. |
| 4 | "What would make the first three months a success?" | Turns the call into a conversation about the job, and gives you the office manager's own standard. |
| 5 | "What are the next steps after this call, and who will confirm the outcome to me?" | Clarifies the process and confirms who you will hear from, through what channel. |

## Target accounting in Sources

Provided documents: your message (the ad as you summarised it, the invite's wording, and your background).

Research tier: L0 — no searches; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Brennock Facilities Ltd values | unavailable | No search was run this turn. Would have moved a values section; none is in this pack. |
| 2. Brennock Facilities Ltd interview process, remote administrative role | unavailable | No search was run this turn. Would have moved the loop structure and persona weights. |
| 3. Interviewer name and company | n/a | No name was given, so there was no query to form. |
| 4. Representative ad for the title | skipped | The ad summary you supplied fixes the four requirement rows. |

## Upgrade menu

- The full ad text → the four requirement rows quote the employer's own wording, not your summary.
- The office manager's name → a tailored reverse question, and persona weights from their public footprint.
- A written copy of your CV → confirms the wording behind F1, F3 and F5 before the interview.
- What the 30-minute call covers, taken from the employer's own website or a phone number you find there → the round's coverage, so the banks match it.
