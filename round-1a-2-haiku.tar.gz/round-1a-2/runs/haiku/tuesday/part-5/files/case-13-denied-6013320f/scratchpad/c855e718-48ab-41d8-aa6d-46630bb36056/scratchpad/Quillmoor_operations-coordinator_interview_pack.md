# Quillmoor Diagnostics: Operations Coordinator, recruiter screen

**Interviewer:** Hannah Lowther, Talent Partner (recruiter screen, 30-minute phone call, Thursday 2pm)
**Pack type:** Session. Recruiter screen. Logistics first, then motivation.

## How to use + type key

- **Personas** = how the question is asked. **Types** = what is being scored.
- Types: **JD** (role requirement or logistics term), **EXP** (what you actually did or why you're moving), **CASE** (live problem), **VAL** (values), **CO** (company knowledge).
- Guidance is scaffolding, not a script. Say it in your own words.

## Prep triage

Hannah has said what she'll cover: pay, notice period, hybrid, reason for moving, then team and next steps. Spend your time on these, in order:

1. **Notice period.** Your material doesn't state it. Find your actual figure before the call (B-slot A3).
2. **Pay.** You've said £42,000. Know why, and say it plainly (A2).
3. **SAP.** Say "I've never used SAP" and give a learning plan, not a past (B2).
4. **The stock-count figure.** Know how the "about a third" was counted, and what was yours (B3).
5. **Production scheduling and dispatch reporting.** Know what you did and didn't do (B1, B4).

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | No gap. Say the four years and the employer type as stated. Expect a probe on what the four years covered. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | medium | [grounded] | transferability | Your material says deliveries to three depots, not production schedules, and nothing about QA. Make the transferable case at that scope: "I schedule deliveries for three depots." Answer slot: if you coordinated any production, planning or QA input, say what and how, in your own words; if you did not, say so plainly and say what you would do first. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | medium | [grounded] | none | Direct match. Say it in those terms: you schedule deliveries and chase suppliers when orders slip. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | The quote reaches the requirement. Verification caveat: the figure is yours and unverified, so expect defend-the-number probes (B3). |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none given | [grounded] | discovery | Your material says nothing about dispatch reporting. Answer slot: if you reported on delivery or dispatch timing, say what and how often; if you did not, say so plainly. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | A spreadsheet rebuild touches the requirement without showing your level. Answer slot: name the Excel features you used in your own words; if the rebuild used only basic entry and tables, say so. Do not rate yourself. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | none | [grounded] | capability | Stated negative. Words: "I've never used SAP." Adjacent limit, stated as your material shows it: you run an in-house stock system. Do not call that ERP experience. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" and "I live in north Bristol" (your message) | high | [grounded] | none | Your own constraint, stated and specific. Gate met. Say two days is fine and three is your limit. |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your own expectation sits inside the advertised band. Gate met. |
| F10 | Notice period (recruiter's agenda, Hannah's message) | none given | none given | [grounded] | discovery | Not in your material. Logistics slot: give your actual notice period. No figure is supplied here. |
| F11 | Reason for moving (recruiter's agenda, Hannah's message) | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | high | [grounded] | none | Stated in your own words. Say the closure and the relocation offer; add no other reason. |

**Research note:** Web search was refused in this session, so no company values, loop structure or strategy was established. Everything about Quillmoor below comes from the advert and Hannah's message only.

## Prohibited claims

Not coached, with basis and honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I coordinated production schedules" | Inflated form of F2. The material says deliveries to three depots. | "I schedule deliveries for our three depots." Your material shows deliveries, not production. |
| "I have ERP experience" or "I know SAP" | Stated negative (F7) | "I've never used SAP." Then the learning plan. |
| "I'm an Excel expert" or "advanced Excel" | Inflated form of F6. The material shows a rebuilt sheet, nothing about level. | "I rebuilt our stock-count spreadsheet." Name what you built. |
| "I report on on-time dispatch" | No source. Silence is not a claim. | Answer slot in F5 only. |
| "I cut discrepancies by a third by myself" | Inflated form of F4. The sentence says discrepancies fell about a third over a year after you rebuilt the sheet. | "I rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year." Do not say how much of that was yours unless you can name it. |

## Persona weights

| Persona | Weight | Why |
|---|---|---|
| Conversational / Rapport Builder | Top (4–5 questions) | Recruiter screen prior: friendly, logistics-led. Casual questions are still scored. |
| Skeptic | Mid (3 questions) | Recruiter screen prior: light Skeptic, knockout checks on requirements and motivation. |
| Pressure | Low (1 question) | Only if she probes the gap with a time limit. |
| Peer, Data-Driven Prober, Case, Values | Not weighted | Not the relationship or round a recruiter screen runs. Team and next steps come later. |

Weights are the relationship prior only. No interviewer profile or loop source exists, so no adjustment applies.

## Question banks

### A. Conversational (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "4 years as logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet" | A 90-second arc in your own words: the four years, the three depots, chasing suppliers, the stock sheet. Stop there. | An open opener. Scored for communication economy. F1, F3, F4 are the sentences it draws on. |
| A2 | "What are you looking for in salary?" | JD | [grounded] "I'm hoping for £42,000."; advertised band "£38,000–£44,000" | Give £42,000 as your expectation, in your own words. Say it once, then stop. The band is theirs; you do not need to argue it. | Pay is a logistics term. F9 fills the slot; no figure is added. |
| A3 | "What's your notice period?" | JD | none given | Logistics slot. Give your actual notice period, in your own words. Do not estimate it. Your material does not state it. | Notice is a logistics term. F10 is silent. |
| A4 | "The role is two days a week at Avonmouth. How would that work for you?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three"; "I live in north Bristol" | Say two days is fine, and that three is your limit. Keep it at that. | Hybrid is a logistics term. F8 fills the slot. |
| A5 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say the office closes next year and the only offer is relocation to Reading, which you don't want. Nothing else. Do not criticise the employer. | Reason for leaving is a logistics term. F11 is the answer. |
| A6 | "Anything else you'd like me to know?" | EXP | none given | Say what you want the next steps to be. If nothing comes to mind, say so briefly. | Closing rapport question. A short, clean close scores well. |

### B. Skeptic (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules across planning, the warehouse and QA. Your background is deliveries. How would you handle that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Say what you do schedule and how you chase late orders. Answer slot: if you coordinated any production, planning or QA input, say how, in your own words; if you did not, say so plainly and say what you would do first. | F2's transferability gap. The question raises the requirement from the advert. |
| B2 | "You've never used SAP. How would you get up to speed?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." Plain acknowledgment: "I've never used SAP." | Say "I've never used SAP." Then say how you would learn it: a plan, not a past. Name the in-house stock system as the nearest thing you have run. Do not claim any ERP knowledge. | Highest-ROI prep. The gap is stated by you, so the acknowledgment is exact. |
| B3 | "Your discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "discrepancies fell by about a third over a year" | Defend-the-number slot. Say how it was counted, in your own words. Name the assumption you would defend least. Say which part was yours. If you do not know how it was counted, say so. | F4 carries the figure. Probes on figures are likely. |
| B4 | "Do you report weekly on on-time dispatch?" | JD | none given | Answer slot: if you reported on delivery or dispatch timing, say what, how often and to whom. If you did not, say so plainly. | F5 is discovery. The advert raises it directly. |

### C. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What would make you turn down an offer?" | EXP | [grounded] "I wouldn't want more than three" (days); "I'm hoping for £42,000." | Hold the two terms you have stated: three days maximum and £42,000 as your expectation. Concede only what you can truthfully concede. | Tests whether you hold stated terms under a time limit. |

## Reverse questions

Each one has a reason it lands.

1. "What does the team day to day look like, and who would I work with most?" Hannah said she'd cover the team later. This keeps the conversation going.
2. "How is on-time dispatch reported at the moment?" This shows you read the advert. It also tests F5 without you having to claim anything.
3. "How does the planning, warehouse and QA handoff work week to week?" This shows you know the coordination the role is built around.
4. "Which SAP modules does the team use, and is there a stock-system change planned?" This tests the ERP gap without volunteering a claim, and shows you know the system matters.
5. "What are the next steps and roughly how long until a decision?" This closes the screen the way a recruiter expects.

## Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| 2+ years in operations or logistics coordination | A1, F1 | Covered |
| Coordinate production schedules across planning, warehouse and QA | B1 | Covered; answer slot |
| Track supplier deliveries and chase late orders | A1 | Covered |
| Keep stock records accurate | B3 | Covered; figure defend |
| Report weekly on on-time dispatch | B4 | Covered; answer slot |
| Confident with Excel | none, and why | Not asked by Hannah's agenda. Answer if asked: name what you built, not a rating. |
| ERP (SAP or similar) a plus | B2 | Covered |
| Hybrid, two days at Avonmouth | A4 | Covered |
| Salary £38,000–£44,000 | A2 | Covered |

## Logistics slots (not questions)

- **Notice period:** give your actual figure.
- **Pay:** £42,000, in your own words.
- **Hybrid:** two days fine, three the limit.
- **Reason for moving:** office closing next year, relocation to Reading offered, you don't want that.

## Sources

- Provided: the advert, Hannah Lowther's message, and your background.
- Research: web search was refused (permission not granted). Two calls were sent and refused: "Quillmoor Diagnostics values" and "Quillmoor Diagnostics Avonmouth Operations Coordinator".

**Research tier:** L1 — searches 2 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Values cheat sheet. Not applicable here: no values-style round is detected for a recruiter screen. Refused. |
| 2. `Quillmoor Diagnostics interview process operations` | unavailable | Loop structure and persona weights. Would have shown whether a later round is values-led. No call was sent for it: the search tool was refused, so the persona weights rest on the recruiter-screen prior alone. |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Grounding brief and CO questions. No call was sent; not established, so there are no CO questions. |
| 4. Interviewer footprint (Hannah Lowther) | unavailable | Would have moved the interviewer read and a reverse question tied to her path. No call was sent: the search tool was refused. |
| 5. Representative JD | skipped | The advert you supplied fixes the fit snapshot. |

## Upgrade menu

- The recruiter's own description of the team → the reverse questions and any later round get specific.
- Your actual notice period → A3 becomes a stated figure.
- Any production, planning or QA input you had, however small → F2 and B1 upgrade from transferability to grounded.
- How the "about a third" was counted → B3 becomes a defended figure.
- Dispatch reporting you did, if any → F5 and B4 upgrade from discovery.
- Interviewer or loop source, if research is allowed → persona weights rest on more than the screen prior.

## Watch-out

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.
