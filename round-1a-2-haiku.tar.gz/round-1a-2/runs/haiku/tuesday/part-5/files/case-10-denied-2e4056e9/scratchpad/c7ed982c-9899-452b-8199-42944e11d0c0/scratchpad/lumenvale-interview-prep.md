# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

Round: text-chat interview on Telegram with the support team lead (invite from Marcus Hale).
Built from: the job-ad requirements as you summarised them, and your background as you described it. No research was run, so the company's values, tooling and interview structure are unknown.

## 1. Fit snapshot

| JD requirement | Evidence (quoted from your own description) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| 2+ years customer support | "3 years as a customer service advisor at an energy supplier" | Strong | None | Direct match. State the role and the years plainly. |
| Zendesk or a similar ticketing tool | "I use Freshdesk every day" | Partial | Tool gap (adjacent) | Freshdesk is a ticketing tool of the same kind. Say you have not used Zendesk. Do not claim Zendesk. |
| Clear written communication | "answering around 60 calls and emails a day" | Partial | Evidence gap (no writing sample in the material) | Emails are a daily written channel. Chat is shorter and faster; say you would adapt. |
| Confidence handling escalations | "I trained four new starters on our refunds process last year" | Partial | Evidence gap (escalation not described) | Refund training shows process knowledge. Escalation experience is not in the material; answer with a real example only. |
| Software company background | "I've never worked for a software company" | None | Domain gap | Name it before they do. Bridge: energy supplier support uses the same ticket, account and refund flows. |

**Gap types used:** tool gap, evidence gap, domain gap.

## 2. Prohibited claims

This pack will not coach these, because the material does not support them:

- Any Zendesk experience, including "I've used similar tools" framed as Zendesk.
- Any software or SaaS product knowledge.
- Any escalation story beyond what you actually did. Do not invent one.
- Any numbers beyond the ones you gave (60 contacts a day, four trainees, three years).

## 3. Persona weights

- **Support team lead** (text chat). High weight on tone, clarity and how you handle a hard customer case. Medium weight on tool knowledge. Low weight on software domain unless they raise it.

## 4. Question bank

**Provenance: your own words** (quoted from your description)

1. *Tell me about your support experience.*
   Guidance: Lead with "3 years as a customer service advisor at an energy supplier, around 60 calls and emails a day." Then one concrete example of a contact you resolved well.
   Rationale: opener; leading with your strongest fact.

2. *You use Freshdesk, not Zendesk. How quickly would you pick up our tool?*
   Guidance: Freshdesk has the same core flow (tickets, statuses, replies, escalation). You have not used Zendesk; say you would learn it fast and name what you would check first.
   Rationale: direct tool-gap question. Answer with the gap, honestly.

3. *Describe a time you handled a difficult customer.*
   Guidance: One real example from energy support: the situation, what you did, the outcome. If you have no clear escalation example, say so and use your closest real case.
   Rationale: escalation probe; the honest branch is "here is my closest real case."

4. *You trained four new starters on refunds. How did you do it?*
   Guidance: The steps you took, what new starters got wrong first, how you checked readiness. Keep it to what you did yourself.
   Rationale: shows coaching; a likely follow-up is "how did you know they were ready?"

5. *Write a short reply to a customer angry about a delayed refund.*
   Guidance: Live drill. Acknowledge, state what you are doing, give a time frame, confirm the next step. Keep it short.
   Rationale: tests written communication directly; a text chat makes this likely.

**Provenance: generic** (not from your material)

6. *Why software support, and why this company?*
   Guidance: Give a real reason about the role. Do not praise products you have not used.
   Rationale: standard motivation; with no research, leave company detail out.

## 5. Delivery notes for the text chat

- Write full sentences; short paragraphs are fine.
- If you need time, say so in one line and reply later.
- Name the domain gap early and briefly. Do not wait to be asked.

## 6. Reverse questions

- "What does the first month look like for someone in this role?" Why it lands: shows you plan to ramp up.
- "Which tools does the team use, and how are escalations handled?" Why it lands: tests whether the tool gap matters, and shows you care about escalation.

## 7. Upgrade menu

- Full job-ad text: unlocks exact requirement quotes in the fit snapshot.
- Your CV: unlocks specific bullets for the evidence column.
- A real escalation example you handled: unlocks a stronger answer to question 3.
- The interviewer's name or public profile, if you have it: unlocks a tailored persona weight.
- Company research: not run here (web search was denied this turn).
