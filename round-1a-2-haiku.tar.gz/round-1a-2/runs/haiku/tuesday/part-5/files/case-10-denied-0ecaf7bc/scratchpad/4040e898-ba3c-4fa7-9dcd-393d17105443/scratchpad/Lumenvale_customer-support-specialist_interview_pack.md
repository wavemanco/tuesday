# Lumenvale Software: Customer Support Specialist, interview prep pack

**Role:** Customer Support Specialist (remote)
**Company:** Lumenvale Software
**Round:** Text-chat interview with the support team lead, run in Telegram
**Interviewer:** Support team lead, name not given (relationship: manager-type, so hiring-manager weights apply)
**Changelog:** First version.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored: CASE (live problem), JD (the ad's requirement), EXP (your own experience), VAL (values), CO (company).
- Guidance is scaffolding, not a script. Rehearse in your own words, and only what you actually did.
- **Text-chat format:** the interview is scored in the writing itself. Keep replies short, plain and specific. Answer the question asked, then stop.

## Fit snapshot

Requirements are your own summary of the ad, quoted from your message. Replace them with the ad's exact wording when you have it (see the upgrade menu).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your summary of the ad) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | none | No gap. Say it in your own words: three years as a customer service advisor at an energy supplier. Expect a check on whether that job was customer support in the sense the ad means. |
| F2 | "experience with Zendesk or a similar ticketing tool" (your summary of the ad) | "I use Freshdesk every day" (your message) | medium | [grounded] | presentation | Freshdesk is a similar ticketing tool, so the quote reaches the requirement in other terms. Bridge: "I use Freshdesk every day." Stay with daily use. Do not describe setup, admin or configuration, because nothing you have stated says you did those. |
| F3 | "clear written communication" (your summary of the ad) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Volume of emails is not evidence of writing quality. The interview itself is a written test, so this is judged in the chat. Answer slot: if a written reply of yours was checked or praised, say what it was and who checked it; if you have no such example, say so and describe how you write a customer reply. |
| F4 | "confidence handling escalations" (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not show escalations. Answer slot: describe the last case you passed to someone senior, if there was one, and what you did with it; if there was none, say so plainly and describe how you would decide what to escalate. |

**Not a listed requirement, but the first thing the team lead may raise:**

| # | Point (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F5 | Software company background (implied by the company's product; your message) | "I've never worked for a software company" (your message) | none | [grounded] | capability | A negative you stated, so the words are yours: "I haven't worked for a software company." Then name the daily support work that carries over, and nothing more. |

## Prohibited claims

Each entry is an inflated wording, or a negative you stated. The honest form is given beside it.

| Not coached | Basis | Honest form |
|---|---|---|
| "I designed the refunds process" | Inflated form of the refunds line. The verb changes from trained to designed. | "I trained four new starters on our refunds process last year." The material says you trained people on the process, not that you set it. |
| "I handled 60 tickets a day in Freshdesk" | Inflated form of the volume line. The number is calls and emails combined, and it is not stated as Freshdesk tickets. | "Around 60 calls and emails a day." Say calls and emails. |
| "I have software support experience" | Contradicted by your own statement. | F5's plain acknowledgment: "I haven't worked for a software company." |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live refund or escalation scenario in the chat | High: a team lead is buying the ability to handle the job, and the ad's escalation line is the obvious place to test it | Clarify first, then state the first action, then say when you would escalate. Think aloud in short messages. |
| Skeptic | "You haven't done X" about the software gap, escalations and written volume | High: three gaps are visible from your message alone | Say the plain acknowledgment, then the nearest real evidence, then a concrete ramp plan. Do not bluff. |
| Data-Driven Prober | Asks how the 60-a-day figure was counted | Medium: the figure is the headline number in your message | Say what is counted, and name the weakest assumption before they do. "I don't know how it was counted" is a valid answer. |
| Pressure | Challenges how much of the volume was yours | Medium: the volume line can read as team output | Hold your part through two follow-ups, then concede the team's share plainly. Do not fold to zero. |
| Conversational | A warm opener and a "why this role" question | Medium: chat openers feel safe and are still scored | Prepare a 90-second opener built from quoted sentences. |

Weights: Case 5, Skeptic 4, Prober 4, Pressure 2, Conversational 3.

**Highest-ROI prep:** B2. Escalations are the one requirement the ad names that your material does not show, so the objection is near-certain.

## Question banks

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer's refund has not arrived after ten working days and they are angry. What do you do first?" | CASE | [generic] | Structure: check the refund's status, confirm what was promised, say what you will do and by when, then decide whether it needs a senior. Keep each message short. | A live problem from the role. It asks about no past event. |
| A2 | "A customer asks for a refund that is outside policy. What do you reply?" | CASE | [generic] | Say what you can offer, say what you cannot and why in plain words, then name the next step. | A refusal is a written skill, so it is scored in the chat. |
| A3 | "Walk me through a customer reply you would write to a complaint about a bill going up." | CASE | [grounded] "confidence handling escalations" (your summary of the ad) | Write it in the chat, short and plain, with one clear ask and one clear next step. No claim about past replies is needed. | The written test the interview is built around. It draws on the ad's written line, not on any past reply. |
| A4 | "What is your approach when a case needs to go above your level?" | JD | [grounded] "confidence handling escalations" (your summary of the ad) | Open prompt. Answer slot: describe the last case you passed up, if there was one, and what you wrote when you passed it; if there was none, say so plainly and describe how you would decide. | F4's gap, rehearsed so the honest answer is ready before the probe. |
| A5 | "Which ticketing tools have you used, and what do you do in one of them each day?" | JD | [grounded] "I use Freshdesk every day" (your message); "experience with Zendesk or a similar ticketing tool" (your summary of the ad) | Say Freshdesk, and what you do in it daily, in those words. For Zendesk: say whether you have used it; if not, say so and name what carries over from Freshdesk. | F2's presentation, with the Zendesk requirement answered honestly. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked for a software company. Why would that be different here?" | JD | [grounded] "I've never worked for a software company" (your message) | Plain acknowledgment: "I haven't worked for a software company." Then name one daily part of the Freshdesk work that carries over. Do not claim software experience. | F5, asked as the team lead will ask it. |
| B2 | "Tell me about a time a case needed to go above your level. What was your part?" | JD | [grounded] "confidence handling escalations" (your summary of the ad) | Deepest rehearsal in the pack. Answer slot: if you passed a case up, say what made it go up, what you wrote, and what happened next, in your own words; if you did not, say so plainly and describe how you would decide. Hold through two follow-ups by returning to what you did, never by adding to it. | F4's gap is the highest-ROI objection. The ad names it, and your material does not show it. |
| B3 | "Where would you be weakest in this role on day one?" | JD | [generic] | Name one real gap from the fit snapshot, the one you can defend, and one concrete step to close it. Do not name a gap you have no evidence for. | Skeptic stems ask for the gap, and an honest, specific answer scores well. |
| B4 | "Your last three years were in customer service. What made you want to move?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | Give your real reason in your own words. Answer slot: if you have a reason for leaving the energy supplier, give it; if there is more than one, pick the one you would say to a manager. | Motivation consistency is a standard skeptic probe. The material states no reason, so none is supplied here. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around 60 calls and emails a day. How is that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Say what is counted, whether 60 is a daily average, and whether calls and emails are added together. Name the assumption you would defend least. "I don't know how it was counted" is an honest branch. | Headline number, so defend-the-number applies. The pack supplies no method or baseline. |
| C2 | "What was the hardest part of handling that volume?" | EXP | [generic] | Name one thing from your own experience. If you cannot name one, describe the nearest thing you did. | Open prompt. It asks for an instance from your work, and the pack supplies none. |
| C3 | "You trained four new starters on the refunds process. How did you know they had it?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Answer slot: if you checked their work, say how and what you looked at; if you only ran the training, say that. | The premise of "how did you know" is a check you have not stated, so the second branch must allow there was none. |
| C4 | "Walk me through what you look at first in Freshdesk each day." | JD | [grounded] "I use Freshdesk every day" (your message) | Say what you actually look at, in your words. Answer slot: if you have done anything else in it, say what; if not, stay with what you look at. | Tests whether daily use is real, in the tool the team may not use. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we trust your written replies when we only see them in this chat?" | JD | [generic] | Hold the position that your replies are short, plain and checkable. Do not overclaim. Concede, if asked again, that the chat is a sample. | Pressure stem about the written requirement. |
| E2 | "That's a lot of calls and emails. How much of it was actually you?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Hold your part, in your words, through two follow-ups. Then concede the team's share plainly. Do not fold to zero. | Attribution probe on the volume line. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me a bit about yourself." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); "I trained four new starters on our refunds process last year" (your message) | A 90-second arc: three years at an energy supplier, the daily volume, Freshdesk, and training new starters. Each beat is one of the quoted sentences. | Opener that frames the rest of the chat. |
| D2 | "What do you like about support work?" | EXP | [generic] | One specific moment from your own work. A general answer scores low. | Rapport question scored for specificity. |
| D3 | "Why this role, and why remote?" | EXP | [generic] | Give your reason in your own words. The material states none, so none is supplied here. | Motivation check. |

**Session total: 16 questions.** That is under the usual floor of 18. The material is thin on escalations, written work and software, so the pack adds no questions to fill it out.

## Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| 2+ years in customer support | D1, C1 | Covered by F1 |
| Zendesk or a similar ticketing tool | A5, C4 | Covered by F2 |
| Clear written communication | A1, A2, A3, E1 | Covered by F3 and the chat itself |
| Confidence handling escalations | A4, B2 | Covered by F4 |
| Software background (not in the ad) | B1 | Covered by F5 |

## Reverse questions

1. "What does a typical escalation look like here, and who decides when it goes up?" Why it lands: it shows you took the escalation line seriously.
2. "How does the team judge a good written reply?" Why it lands: it turns the written test into a shared standard.
3. "What does the first month look like for someone new on the team?" Why it lands: it signals you are planning to join, not just to be hired.
4. "Which tools sit alongside the ticketing system, and where do refunds get handled?" Why it lands: it shows you know refunds are part of the job.
5. "What would make someone in this role look excellent after three months?" Why it lands: it asks for the team's bar in their own terms.

## Sources

- Provided: your message, including the paraphrased ad and your background.
- Provided: the invite text as you pasted it (Marcus Hale, talent team).
- Research tier: L1. Searches 0 of 6 used (2 attempted, both refused by the host). Fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Would have checked whether a values cheat sheet applies. No values round is described, so none was built. Queries sent: "Lumenvale Software company", refused. |
| 2. Lumenvale interview process, customer support | skipped | The invite fixes the loop: one text chat with the team lead. |
| 3. Lumenvale strategy / recent news | unavailable | Would have checked that the company exists and is hiring for this role. Query sent: "Lumenvale Software careers Customer Support Specialist", refused. |
| 4. Interviewer name and Lumenvale | n/a | No name given. |
| 5. Representative Customer Support Specialist JD | skipped | Your summary of the ad fixes the requirements. |

## Upgrade menu

- The ad's exact wording, from the careers page → replaces the four `[grounded]` summary requirements with verbatim quotes, and may add requirements your summary left out.
- The team lead's name → a tailored reverse question, and persona weights read from any public footprint.
- A written reply you have sent to a customer, with names removed → could upgrade F3 from low, and gives A3 a real example to build on.
- A case you passed to a senior colleague → upgrades F4 from none given, and sharpens B2.
- `tuesday-dossier.md` → would record the gaps this prep exposed for later sessions.
