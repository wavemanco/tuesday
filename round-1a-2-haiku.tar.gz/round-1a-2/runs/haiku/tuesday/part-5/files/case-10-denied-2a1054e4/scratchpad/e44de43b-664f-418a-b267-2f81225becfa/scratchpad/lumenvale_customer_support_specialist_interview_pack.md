# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

**Round:** text-chat interview on Telegram with the support team lead (name not given). Relationship: likely hiring manager.
**Build note:** built at research tier L0 (your material only). Web search was not permitted in this session, so nothing about Lumenvale's values, interview process or strategy is in this pack.

## 1. How to use

- Personas = how the question is asked. Types = what is being scored.
- Type key: **JD** role/requirement fit · **EXP** what you actually did · **CASE** live problem · **VAL** values (none detected) · **CO** company knowledge (none, no research).
- Guidance is scaffolding, not a script. Rehearse in your own words.

## 2. Prep triage

Time available was not stated, so no schedule. In order of weight:

1. **B1 (escalations) and B2 (written reply)**: the two requirements with the least evidence and the most likely to be tested in a text chat.
2. **A3 (Freshdesk)**: easy, and it's the strongest match you have.
3. **C1 (never worked for software)**: the likeliest pressure point.
4. Everything else is insurance.

## 3. Fit snapshot

Requirements are taken from your summary of the ad. I have not seen the full posting, so wording here is paraphrase, not the ad's text.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | 2+ years in customer support (ad, your summary) | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | high | [grounded] | presentation | The years are in the quote. Say the role as you did it, in those words. |
| F2 | Zendesk or a similar ticketing tool (ad, your summary) | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Freshdesk is a named similar tool. Say what you did in it daily, in your words. Do not claim Zendesk experience. |
| F3 | Clear written communication (ad, your summary) | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Your material shows email volume, not writing quality. Answer slot: if you wrote replies others relied on, say what they were; if you did not track this, say so and describe how you write for a customer. |
| F4 | Confidence handling escalations (ad, your summary) | none given | none | [grounded] | discovery | Your material does not show escalations. Answer slot: if you handled escalations, say how, in your own words; if not, say so plainly and describe how you would handle one. |
| F5 | (not in ad) Training others | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Not a stated requirement, but a strong differentiator for a team-lead interview. |

Your material does not establish any software-company experience. The ad's silence on this is not a gap in the ad, but the team lead may raise it.

## 4. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Zendesk experience | Inflated form of F2 | Freshdesk, at its own scope |
| Handled escalations at scale | Inflated form of F4 | Answer slot only: "if you handled escalations, say how" |
| Wrote support macros, knowledge base articles or policies | Not in your material | None. Do not add these. |
| Software or product support experience | Your stated negative | "I've never worked for a software company." No claim beyond it. |

## 5. Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Hiring manager (support team lead) | Scenario and JD questions, text-based | High. The round is with the team lead, and the ad's requirements are the scoring sheet. | Answer in short paragraphs. Use one concrete example per answer. |
| Skeptic (software gap) | Probes the never-worked-for-software line | Medium. Your message says it plainly, so a team lead may test it. | Hold the transferable part, concede the learning curve. |
| Writing examiner | Asks for a written reply to a sample ticket | Medium-high. The round is text-only, so writing is itself the test. | Structure the reply: acknowledge, act, next step. |

## 6. Question banks

### Hiring manager (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about your customer support experience." | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Give the volume and channels in those words, then one example of a case you resolved from start to finish. Answer slot: if the example was yours to decide, say what you decided; if others made the call, say so. | F1 is the strongest evidence for the years requirement. EXP because it tests what was yours. |
| A2 | "How would you handle a customer whose refund was declined and who now asks for a manager?" | CASE | [generic] | Structure it: acknowledge, check the decline reason, explain what you can do within policy, offer an escalation path, and say when the customer will hear back. Do not invent a policy. | Escalation is a stated requirement (F4). The question needs no claim about your past. |
| A3 | "How do you use Freshdesk day to day?" | EXP | [grounded] "I use Freshdesk every day" — your message | Describe your routine in your words: queues, priorities, how you close a ticket. Answer slot: if you used any feature to manage volume, name it; if you did not, say so. | F2 is the match for the tool requirement. |
| A4 | "I'd like you to write a reply to an upset customer whose order is three weeks late. Go ahead." | CASE | [generic] | Write a short reply: apology, what you know, what you will do, when they will hear next. Keep it under 150 words. No promises you cannot keep. | The text-chat round makes writing the test. |
| A5 | "You trained four new starters on refunds. How did you do it?" | EXP | [grounded] "I trained four new starters on our refunds process last year" — your message | Say what you covered and how you checked understanding. Answer slot: if you tested them, say how; if you did not, say so. | F5 is a differentiator; the probe checks whether the training was yours. |

### Skeptic (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never worked for a software company. Why would you fit ours?" | JD | [grounded] "I've never worked for a software company." — your message | Hold: say what transfers (customer contact, ticketing, refunds, training others). Concede: the product and its terms are new to you. Hold through one follow-up without adding claims about software work. | The likeliest pressure point given your message. Hold-then-concede. |

### Writing examiner (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Reply to this customer in writing: they say their account was charged twice." | CASE | [generic] | Short reply: confirm, say what you will check, give a timeframe you can meet. Do not state the cause before checking. | Tests written communication (F3). |

**Highest-ROI prep:** A2 and D1 together. Escalation and written replies are the two requirements your material shows least, and both are tested live in a text chat.

## 7. Reverse questions (why they land)

1. "What does a good first 30 days look like for this role?" Lands because it shows you're planning the start, not just the offer.
2. "How does the team handle escalations between tiers?" Lands because it tests the F4 area from the other side.
3. "Which tools does the team use besides Freshdesk-type systems?" Lands because it sets up a Freshdesk-to-Zendesk path, if relevant.
4. "How is the first-month support shadowing handled?" Lands because you trained starters yourself.
5. "What would you most like the next hire to fix in the first quarter?" Lands because it asks for the team lead's own priorities.

## 8. Delivery notes

- Telegram text: write in short paragraphs and use bullets only where they help. Reply within the time the team lead asks for.
- Do not mention any assessment or outside coaching in the interview.

## 9. Sources

- Provided: your message, your summary of the ad.
- Research: not run. Web search was refused in this session (permission not granted). Target accounting: company values, interview process, strategy, the interviewer, representative JD: all `unavailable`.

## 10. Upgrade menu

- The full posting text → the requirement rows become quoted, not paraphrased.
- The team lead's name → persona weights and a tailored reverse question.
- Whether the round is one chat or several sessions → a per-session mini-pack.
- Web search access → company values and recent strategy for the grounding section.
