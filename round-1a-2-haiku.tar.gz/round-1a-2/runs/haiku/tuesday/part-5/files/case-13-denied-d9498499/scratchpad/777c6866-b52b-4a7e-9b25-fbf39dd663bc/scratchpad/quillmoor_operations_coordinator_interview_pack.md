# Prep pack: Operations Coordinator, Quillmoor Diagnostics (recruiter screen)

Recruiter screen with Hannah Lowther (Talent Partner), Thursday 2pm, 30-minute phone call. She will ring the mobile number on the application.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD (the advert's requirements), EXP (what you actually did), LOG (logistics: pay, notice, location, reason for leaving).
- Guidance is scaffolding, not a script. Say it in your own words.

## Type key

- **JD**: tests a stated requirement of the role.
- **EXP**: tests whether your record survives a follow-up.
- **LOG**: a logistics slot. The answer is yours to give; the pack does not supply it.

## Fit snapshot

Requirements are quoted from the advert. Evidence is quoted from your own messages.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | None. Say it as you wrote it. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | high | [grounded] | presentation | Your material already describes this work. Say it in those terms: you scheduled deliveries for three depots and chased suppliers when orders slipped. |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | presentation | Limited inspectable proof (a spreadsheet and a figure you gave), so expect a probe. Say what the spreadsheet did and the one-third figure, and how you would defend how it was counted. |
| F4 | "confident with Excel" (advert) | None. Your rebuilt spreadsheet is the nearest sentence. | none given | [grounded] | discovery | Your material does not show your Excel level. Answer slot: if you can say which functions or tools you used to build the stock-count spreadsheet, say so; if you have not used others, say so plainly. |
| F5 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | low | [inferred] | transferability | Delivery scheduling is adjacent to production scheduling, not the same work. Say what you scheduled, and keep the planning, warehouse and QA link as a question. |
| F6 | "ERP (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | A stated absence, and a plus rather than a gate. Words: "I haven't used SAP. We run our own in-house stock system." Then how you would learn it, said as a plan, never as a past. |
| F7 | "weekly report on on-time dispatch" (advert) | None. Your material is silent on dispatch reporting. | none given | [grounded] | discovery | Your material does not show whether you reported on dispatch. Answer slot: if you tracked on-time dispatch in any form, say what you counted; if you did not, say so and say what you would track first. |
| F8 | Hybrid: two days a week at Avonmouth (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Met as stated. Say two days is fine and three is your limit. Do not add flexibility beyond that. |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Your stated expectation sits inside the band. |
| F10 | Notice period (not in advert) | None. Your material is silent on notice. | none given | [grounded] | hard_gate | Not established by your material. The recruiter will ask. See the logistics slot in bank A. |

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Used SAP or an ERP system | Negative you stated (F6) | "I haven't used SAP. We run our own in-house stock system." No slot |
| Scheduled production | Inflated form of F2 and F5 | "I schedule deliveries for our three depots." The pack's observation: your material says deliveries, not production |
| Reported on dispatch | Silence (F7), not a claim | Not listed; the answer slot in F7 applies |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly opener, "talk me through your background" | High. Recruiter screens open this way | Ninety-second arc, your words |
| Skeptic | "Why leave, why here, why now?" and the logistics probes | High. Your reason for leaving is the main motivation check | Hold your position; say the reason once, plainly |

## Question bank: Conversational / Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" | Ninety-second arc: your role, the three depots, the supplier chasing, the stock-count work. Say it in your words | F1 and F3 carry the story |
| A2 | "What does your current role involve day to day?" | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Describe the scheduling and chasing as you did them | F2 is the closest match to the advert's supplier tracking |
| A3 | "What would you say is the hardest part of this kind of job?" | JD | [generic] | Name one real problem you handled, in your own words | Open; any answer should come from your own experience |

## Question bank: Skeptic / Logistics (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What are you hoping for in salary?" | LOG | [grounded] "I'm hoping for £42,000" | Say £42,000 first, in your words. Then ask what the band is, if you have not seen it. This figure sits inside the advert's band | F9 is your stated expectation; LOG |
| B2 | "What's your notice period?" | LOG | None given | Logistics slot: give your actual notice period in your own words. Your material does not state it | F10: a term the recruiter will ask. This is the single highest-ROI prep item |
| B3 | "The role is two days a week in Avonmouth. How do you feel about that?" | LOG | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" | Say two days is fine, and three is your limit. Do not offer more | F8 is the stated term; keep it exactly |
| B4 | "Why are you looking to move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say the office closure and the Reading offer, in those words. Give the reason once; do not dress it up | F10 is not involved; this is the motivation probe the Skeptic runs |
| B5 | "Why not relocate to Reading?" | EXP | None given | Say you do not want to relocate, in your own words. Hold the position if pressed, and do not invent a second reason | Pressure follow-up to B4 |

## Question bank: Operations-specific (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The role includes an on-time dispatch report. Have you done one?" | JD | None given | Answer slot: if you tracked on-time dispatch in any form, say what you counted. If not, say so and say what you would track first | F7 is silent, so this is an honest slot |
| C2 | "How comfortable are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Name the spreadsheet work, and only the functions you actually used | F4 is discovery. Do not claim more than you can show |
| C3 | "Have you worked with SAP or a similar system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | "I haven't used SAP. We run our own in-house stock system." Then how you would learn it | F6 is a stated absence, and the plain acknowledgment is the whole answer |

## Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Supplier deliveries and late orders | A2 |
| Stock records accurate | A2, C2 |
| Production schedules across planning, warehouse and QA | Not covered by a question. The fit snapshot at F5 is the only row |
| Confident with Excel | C2 |
| ERP (SAP or similar) | C3 |
| Weekly on-time dispatch report | C1 |
| Hybrid, two days at Avonmouth | B3 |
| Salary band | B1 |

## Reverse questions

Each one has a "why it lands."

1. "What does the on-time dispatch report look like week to week, and who reads it?" Why it lands: it shows you read the advert.
2. "How does planning, the warehouse and QA agree a production schedule when it changes?" Why it lands: it asks about the seam between teams.
3. "What stock system do you use day to day?" Why it lands: a practical question that follows up on the ERP line.
4. "What does the first month look like for someone in this role?" Why it lands: it signals you are planning to start.
5. "What are the next steps and rough timing?" Why it lands: a normal close that the recruiter will answer in her own process.

## Upgrade menu

- Your notice period → a complete logistics answer in bank B
- The advert's dispatch report details → F7 and C1 become grounded
- Any Excel or ERP experience beyond what you have said → F4 and F6 change

## Sources

Research tier: L0. Two searches were attempted and refused by the host. No fetches.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Values cheat sheet; the query was refused |
| 2. Quillmoor Diagnostics interview process | unavailable | Loop structure; not sent after the first two calls were refused |
| 3. Quillmoor Diagnostics strategy and news | unavailable | Grounding brief; not sent |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Interviewer read; not sent |
| 5. Representative JD | skipped | The advert you supplied fixes the fit snapshot |

Provided documents: the advert and your message.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.
