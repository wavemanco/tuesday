Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-5-rooms-case-9-canned-e36fbc6a/3d9be703-1a4a-4c95-91db-09e4d79869fb/scratchpad/halvering_fourth-grade-teacher_interview_pack.md. It has 15 questions, fewer than a full pack would, because I had no job posting to draw on.

Your resume includes your Social Security number. I haven't repeated it or used it, since nothing in this interview or application needs it. Keep it off any materials you share with the school.

The pack is built around the two things the panel will most likely press on: you have never taught fourth grade, and you have never been a team lead. Question A2 gets the most rehearsal. It asks you to hold your position for two follow-ups, then concede the fourth-grade gap in one plain sentence.

Three things would make the pack sharper:
- **Want a drill?** I can play the principal on A2 and push back on your answers.
- **Want a dossier?** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions.
- **Want a Word version?** I can convert the pack.

Do you have the job posting text? If you paste it, I'll rebuild the banks against its requirements.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District · 45-minute panel · Principal Dolores Vantongeren plus two fourth-grade team members (names not given)

Built from the invite and your CV, with no job description and no research run. The fit snapshot below is therefore thinner than a full pack; the upgrade menu says what would thicken it.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Types: **VAL** behavioral or values, **EXP** your own experience, deep-dived; **JD** the role's stated requirements; **CO** company knowledge; **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words, and only what you did.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | Met on your CV. Your material says the license is registered and active through June 30, 2029, with the grades 1–6 endorsement. Nothing in the material has been checked against a license record, so bring proof the panel can see (see the upgrade menu). |
| F2 | "Fourth Grade Teacher position" (invite) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | medium | [grounded] | transferability | Adjacent work: six years of elementary teaching one grade below. Words: "Six years teaching third grade at a public elementary school in Joliet," and "I've never taught fourth grade." Answer slot: the panel includes fourth-grade team members, so expect a probe on the move up a grade. If you can name something from third-grade teaching that carries into fourth, say what it is in your own words; if you cannot, say so plainly and describe how you would learn the fourth-grade content and sequence. |

The invite states only the license and the title as requirements. The panel composition (a principal and two fourth-grade team members) raises the probes below, but it is not a stated requirement, so it gets no fit row.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Fourth-grade teaching experience | Stated negative, your message | "I've never taught fourth grade." Plain acknowledgment, no slot. Say it as "I haven't taught fourth grade." |
| Team lead experience | Stated negative, your message | "I've never been a team lead." Plain acknowledgment, no slot. Say it as "I haven't been a team lead." |
| Led the grade team | Inflated form of "I led our grade level's move to a new reading curriculum in 2024" (your CV) | That sentence at its own scope. The material says you led the move to a curriculum, not the grade team. |
| Ran the reading program | Inflated form of "I've run the after-school reading club for the last two years" (your CV) | That sentence at its own scope. The material says a club, not a program. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Principal, asking about the move up a grade and the missing team-lead experience | High. A principal reading the CV sees the two stated absences first. Hiring-manager prior, weighted up because the invite is a panel to fill a specific grade. | Rehearse the grade-transition question until it is plain. Hold the third-grade record; concede the fourth-grade gap in one sentence. |
| Case/Strategist | Principal, a live first-month problem for a fourth-grade class | Medium. Hiring-manager prior; a principal tests how you would start. | Clarify what the problem is before proposing anything; say what you would check first. |
| Pressure | Principal, a time-boxed challenge on the 2024 credit | Medium-low. Panels of 45 minutes often include one sharp challenge; the register depends on the principal. | Pause, restate the question, anchor in the sentence you actually said, and hold for two follow-ups. |
| Peer Evaluator | Fourth-grade team members, on collaboration and disagreement | High. Team members are peers and will ask what the hire adds to their work. | Reciprocity framing: what you bring their team, not only what you need. |
| Data-Driven Prober | Team members, on the 2024 move and the reading club | Medium. Both are concrete CV items a peer will check for results. | Say what you tracked, and say plainly if you tracked nothing. |
| Conversational | Opening question from any panelist | Medium. Panel openers are often casual, and casual questions are still scored. | A 90-second arc: where you taught, what you did, why this role. |

## Question banks

### Principal: Skeptic and Case, then Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years. What makes you ready for fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Say the six years in those words, then the transfer. Answer slot: name what you would need to learn about fourth-grade content and the team's sequence first; if you have any fourth-grade contact to draw on, say what it was, and if you have none, say so plainly. | F2 is the likeliest opening probe for a principal. The question's premise is the CV's own fact. |
| A2 | "You've never taught fourth grade. Why should we hire you over someone who has?" | JD | [grounded] "I've never taught fourth grade" (your message) | The highest-ROI rehearsal in this pack. Hold the position through two follow-ups: you hold the grades 1–6 endorsement and six years of elementary teaching. Concede specifically: "I haven't taught fourth grade," and say how you would close that gap in the first term. Answer slot: if a third-grade practice carries over, name it in your own words; if none does, say so plainly. | F2 plus the stated negative make this the most predictable objection. The concession is the stated fact; the hold is the license and record, not an added claim. |
| A3 | "Tell me about a time you led a team." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV); [grounded] "I've never been a team lead" (your message) | Start with the stated fact: "I haven't been a team lead." Then the nearest thing your material carries: the 2024 curriculum move, in those words. Answer slot: say what you did to lead that move, in your own words. If the move was led by someone else and you took part, say that; if you were not leading it, say so plainly. | Panels probe absences the candidate states. The premise is a team-lead experience, which the candidate denies, so the honest branch is written in. |
| A4 | "Why this position?" | VAL | [generic] | Name the grade and what draws you to it, in your own words. Keep it to one reason you can defend in a follow-up. | Open motivation question; no claim about your past is needed. |
| A5 | "A group of fourth-graders is well below grade level in reading after the first quarter. What would you do in the first month?" | CASE | [generic] | Clarify what the data measures and how the students were assessed; talk to the grade team before changing anything; name one small step you would test first. The question needs no claim about your past, so the guidance makes none. | A live problem from the role, asked as a decision; the reading focus matches the CV's reading work. |
| A6 | "Walk us through your first month with this class." | CASE | [generic] | Structure it: learn the students and the team's plan; check what already runs; set one goal with the team; schedule a check-in. Make no claim about having done it. | A planning case for a new fourth-grade teacher, delivered live. |
| A7 | "Sixty seconds: why should we hire you over a candidate who has taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" (your message) | Pressure version of A2. Pause, restate the question in one line, then hold the grades 1–6 endorsement and six years of record for two follow-ups. Concede the gap in one plain sentence, then stop talking. | A time-boxed version of the most predictable objection; the hold-then-concede structure is the point. |
| A8 | "That 2024 curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Hold the sentence as written: you led the move. Concede the boundary plainly: say which parts you ran and which were the grade team's or the district's. Answer slot: if any part was yours to decide, say which and how; if the decision was not yours, say so plainly. | A pressure question on credit; it tests whether the claim survives the second follow-up. |

### Team members: Peer Evaluator and Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 2024 reading move was measured. What changed for students?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say what you led, in those words. Answer slot: if you tracked results, name the measure and who collected it; if no results were tracked, say so plainly and say what you would measure. | The team will check the one reading result the CV implies. The measure is not in your material, so it is a slot. |
| B2 | "How do you know the after-school reading club worked?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Describe the club in your own words: what you ran and for how long. Answer slot: if you saw any change in the students, say what you saw and how; if you did not measure it, say so plainly. | A peer prober tests the club's claim; the outcome is not in your material, so it is a slot. |
| B3 | "What reading routines from third grade would you carry into fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Name what you taught in your own words. If you have no routine you would carry over, say that and describe what you would adopt from the fourth-grade team. | A peer probe on the transfer; it asks for your own routines and allows none. |
| B4 | "How would you handle it if you disagreed with a grade-level partner about a unit?" | VAL | [generic] | Structure it: what you would ask first, how you would raise the disagreement in private, and how you would decide and then follow the agreed plan. Make no claim about a past disagreement. | A peer seam question; it is a pattern, not a fact about your history. |
| B5 | "You write a weekly email to families. What goes in it?" | EXP | [grounded] "I write a weekly email to families" (your CV) | Describe the email in your own words: what you put in it and why. Answer slot: if families replied or you tracked the email's reach, say so; if you did not, do not add it. | A peer checks the weekly habit; the response measure is not in your material, so it is a slot. |
| B6 | "So, walk us through how you came to teaching." | VAL | [generic] | A 90-second arc: where you started, how you came to the classroom, and one moment that shaped your teaching. | A conversational opener scored as one. |
| B7 | "Tell us about a time you asked a colleague for help." | VAL | [generic] | Pick a real time. If none comes to mind, say so plainly, then describe how you would ask a fourth-grade colleague for help. | A collaboration probe; the material holds no story for it, so the guidance is a selection scaffold. |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a strong first term look like for someone in this fourth-grade role?" | Frames success criteria and shows you plan to be measured. |
| "How does the fourth-grade team plan reading instruction across the year?" | Signals you want to fit their system, not replace it. |
| "What has the school decided about its reading curriculum going forward?" | Connects to the 2024 move and shows you follow the school's direction. |
| "What could a new person do in their first month that would genuinely help your team?" (peer reciprocity) | Turns the team members' evaluation into a partnership conversation. |
| "What would you want a new fourth-grade teacher to have worked out by the end of October?" | A concrete milestone the principal can answer in one line. |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Valid Illinois Professional Educator License with an elementary endorsement | none, and why: the gate is met on your CV, and the panel checks it on paper; bring proof (upgrade menu) |
| Fourth Grade Teacher position (grade-level fit) | A1, A2, A7, B3 |

## Sources

Provided documents: the invite text and your CV and message.

Research tier: L0, no search or fetch was run in this turn.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. school district values | unavailable | Values cheat sheet, section 10 (not built: no values were supplied) |
| 2. panel or interview process | unavailable | Loop structure; persona weights follow the panel as stated |
| 3. school or district strategy and recent news | unavailable | Grounding brief; would sharpen reverse questions about the reading curriculum |
| 4. named interviewer footprint | n/a | No interviewer names given, so there was no query to form |
| 5. representative fourth-grade teacher job description | unavailable | Would have labeled JD-derived questions as typical for the role |

## Upgrade menu

- The posting or job description text → rebuilds the requirement coverage line and the JD questions against its own wording
- The team members' names → personas assigned per panelist and a tailored reverse question
- Proof of your license (a printed license record) → F1 from medium to high confidence, and something to show on the day
- Deep research on the district and the reading curriculum (offered once; costs about six more searches and two page fetches) → grounding brief and sharper reverse questions
- A note on what your 2024 curriculum move measured → B1 and A8 gain a grounded answer in place of a slot
