Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-5-rooms-case-9-canned-86029a83/2d47c677-9f2d-4f97-906b-eca7ed338059/scratchpad/Halvering_fourth-grade-teacher_interview_pack.md`. I built it for a panel with the principal and two fourth-grade team members, and I treated the principal as your likely supervisor and the team members as peers. I didn't use or repeat the Social Security number in your message; it isn't needed for interview prep.

The two gaps the panel is most likely to probe are:

- **Fourth-grade experience.** You've taught third grade for six years. The pack gives you a plan for saying that directly and describing how you'd get up to speed in the first month. It's the highest-value thing to rehearse.
- **Team leadership.** The pack has you state that you haven't been a team lead, then describe the 2024 curriculum move with its real scope. Be ready to say who made the final decision on that move.

The pack also lists claims not to make, including fourth-grade experience, team-lead experience, and reading-score outcomes you can't state. It has question banks for each panel member, and reverse questions to ask them.

I didn't run any web research, so nothing in the pack about the school, district or the people on the panel is verified. The invite says "Thursday" without a date, and today is a Thursday, so confirm the date with HR.

Would you like me to run research on Halvering Elementary and Orrinsford's curriculum and values? I can also play the Skeptic on the fourth-grade question so you can rehearse it live.

Is Principal Vantongeren your future supervisor, or someone you'd work beside? That changes how I weight the questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview Prep Pack: Fourth Grade Teacher, Halvering Elementary School

**Round:** 45-minute panel, Principal Dolores Vantongeren plus two fourth-grade team members
**Date:** The invite says "Thursday." Confirm the exact date with HR before you prep the logistics.
**Research tier:** L0. Built only from your resume, your message and the invite. No web search was run, so nothing here about the school's curriculum, values or current strategy is verified.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Types: **VAL** behavioral/values; **EXP** experience deep-dive; **JD** role-driven; **CO** company knowledge; **CASE** live problem.
- Guidance is scaffolding, not a script. Rehearse out loud, in your own words, and only what you actually did.

## Fit snapshot

Requirements come from the invite's own words where it states one. Otherwise they are role-family requirements, marked `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | Met. Say it plainly: "I hold an Illinois PEL with an elementary endorsement, active through June 30, 2029." |
| F2 | Fourth-grade classroom teaching (role-family requirement) | "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | low | [grounded] | transferability | Your material shows adjacent work. Words: "For six years I taught third grade at a public elementary school in Joliet." Answer slot: if you have taught any fourth-grade content (a unit, a reading group, a shared lesson), name it. If not, say so, and say what you would do in the first month to learn the fourth-grade standards and pacing. |
| F3 | Leading or coordinating a grade-level team (role-family requirement) | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've never been a team lead" (your message) | medium | [grounded] | capability | Words: "I've never been a team lead." Then: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: what you decided, who you worked with, and who made the final call. Do not describe the 2024 move as team leadership. |
| F4 | Reading instruction (role-family requirement) | "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | none | Lead with it. Name what the club did, how many students, and how you chose the work. Only include numbers you can state. |
| F5 | Family communication (role-family requirement) | "I write a weekly email to families" (your CV) | medium | [grounded] | none | A concrete habit. Be ready to say what the email covers and how families respond. Answer slot: if you have no response data, say that. |

**Gap routing:** F2 is `transferability` because the adjacent work is real and its limit is stated. F3 is `capability` because the team-lead experience is the candidate's own stated negative. F1 is a gate and is met.

## Prohibited claims

These claims are not supported by the material. Do not make them in any form, including implied ones.

1. **Fourth-grade teaching experience.** Not in your material. Answer with third-grade experience and the adjacent skills.
2. **Team-lead or supervisory experience.** You stated you have never been a team lead. Do not describe the curriculum move, the reading club or anything else as leading a team.
3. **Outcomes you cannot state.** Do not give reading-score gains, growth percentages or student-outcome numbers for the curriculum move or the reading club unless you have them. If asked for results you do not have, say so.
4. **Ownership beyond what you did.** If the curriculum move was a group decision, say so. Do not claim sole authorship.

## Personas for this panel

A panel blends the top personas of each member's relationship. Principal Vantongeren is most likely to be a hiring manager (future supervisor). The two team members are most likely to be peers. Neither has a public profile in this pack; no interviewer research was run.

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Principal | Live scenarios about the grade's needs | High. A principal is buying capability and planning around gaps | Clarify first, then structure, then answer |
| Skeptic | Principal | Questions about the fourth-grade gap and the team-lead gap | High. These are the two gaps your resume shows | Rehearse the objection until it is plain. Name the gap, then the bridge, then the ramp plan |
| Peer Evaluator | Team members | Questions about how you would work alongside the team, share work and handle disagreement | High. Two team members on the panel | Reciprocity. Say what you bring to their team, not just what you need |
| Data-Driven Prober | Team members | Questions about how you know your reading work worked | Medium. Probes the club and the curriculum move | Say what you measured and what you did not. Do not invent numbers |
| Conversational | All | Casual openers ("walk us through your path") | Medium. Easy to underrate | Prepare a 90-second career arc |

## Question banks

Question counts follow the weights: the principal's Skeptic and Case questions get the most depth. The team members' Peer Evaluator gets the next most.

### Principal: Skeptic (top, deepest rehearsal)

**Highest-ROI prep in this pack:** B1. The fourth-grade gap is the most likely objection, and it should be rehearsed until it is boring.

| ID | Type | Question | Provenance | Guidance | Why it's included |
|---|---|---|---|---|---|
| B1 | JD, EXP | "You haven't taught fourth grade. Why should we hire you for this grade?" | [grounded]: "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | Say the gap first, in one sentence. Then the bridge: the six years, the reading work, and what transfers. Then the ramp plan: what you would do in the first 30 days, as a plan and not a past. Keep it under 90 seconds. | The principal is most likely to test this directly. |
| B2 | EXP | "You've never been a team lead. What would make you a good member of this team?" | [grounded]: "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | State the negative. Then the 2024 move as the closest example, with its real scope. Then what you would bring as a team member. | This is the second gap. |
| B3 | EXP | "Tell us about the curriculum move. How much of it was you?" | [grounded]: "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: say who decided what, what you did yourself, and what the group did. Keep "led" tied to what you actually led. | Tests attribution. Do not expand the role. |

### Principal: Case/Strategist

| ID | Type | Question | Provenance | Guidance | Why it's included |
|---|---|---|---|---|---|
| A1 | CASE | "A student enters fourth grade reading two years below level in October. How would you start?" | [generic]: a role-family scenario, not from your material | Clarify: which assessments exist, what the team already does. Then structure: diagnose, group, instruct, monitor. Name one concrete step from your reading club experience only if it fits. | A live problem from the actual role. |
| A2 | CASE | "The team wants a new family-communication routine. What would you propose in your first month?" | [grounded]: "I write a weekly email to families" | Lead with the weekly email as a starting point. Propose a small test, not a redesign. | Connects the family-communication habit to a real problem. |

### Team member: Peer Evaluator (top)

| ID | Type | Question | Provenance | Guidance | Why it's included |
|---|---|---|---|---|---|
| C1 | VAL | "How do you handle it when you disagree with a colleague about how to teach something?" | [generic]: a standard peer question, not from your material | Use a real disagreement. Show spine and tact together: say what you argued for, how you listened, and what you agreed to. | Peer fit is the question behind this one. |
| C2 | JD | "What would you need from us in your first month?" | [grounded]: "I've never taught fourth grade" | Name two specific needs: fourth-grade pacing and materials. Then say what you can offer the team in return. | Reciprocity. |
| C3 | EXP | "You ran a reading club for two years. What did you learn from it that would help our class?" | [grounded]: "I've run the after-school reading club for the last two years" | Name one thing you learned, and how you would use it. Do not claim outcomes you cannot state. | Ties the club to the role. |

### Team member: Data-Driven Prober (mid-weight)

| ID | Type | Question | Provenance | Guidance | Why it's included |
|---|---|---|---|---|---|
| D1 | EXP | "How do you know the reading club worked?" | [grounded]: "I've run the after-school reading club for the last two years" | Answer slot: say what you measured, what you did not measure, and what you would measure next. If you have no data, say so. | Tests whether the claim survives scrutiny. |
| D2 | EXP | "What did the reading curriculum change do to student results?" | [grounded]: "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: give the results you have, if any. If you have none, say you did not track them formally, and say what you would track. | Prohibited claim 3 applies here. |

### Team member: Conversational (low weight)

| ID | Type | Question | Provenance | Guidance | Why it's included |
|---|---|---|---|---|---|
| E1 | VAL | "Walk us through your path to teaching." | [grounded]: "Six years teaching third grade at a public elementary school in Joliet" | A 90-second arc: how you started, what drew you to elementary, the Joliet years, the move toward reading work. Practice it until it runs without notes. | Casual openers are scored. |

## Reverse questions

Ask one or two. Each has a reason it lands.

1. "What does a strong first semester look like for a new fourth-grade teacher here?" Why it lands: it shows you are planning for the gap, not hiding it.
2. "How does the fourth-grade team plan and share work across classrooms?" Why it lands: it tests whether you will fit the team's working style. This is a peer question.
3. "Which reading materials does fourth grade use now, and how were those decisions made?" Why it lands: it connects to your curriculum experience without claiming expertise you do not have.
4. "What do you expect from teachers in weekly family communication?" Why it lands: it shows you already do this, and it asks for the school's standard.
5. "Who would be my day-to-day point of contact in the first 90 days?" Why it lands: it signals you think about onboarding.
6. Reciprocity (peer): "What is one thing your team wishes a new member would bring?" Why it lands: it turns the interview into a peer conversation.

## Sources

- Provided documents: your resume (as pasted), your message, the Halvering invite.
- Searches run: none. Target accounting: L0. No research targets were run, so no school, district or interviewer information is included.
- Dossier: none present.

## Upgrade menu

- The job description text → turns the `[generic]` requirements into `[grounded]` rows and adds JD-tagged questions
- The exact interview date and any HR focus areas → tailored prep and an accurate schedule
- Whether Principal Vantongeren is your future supervisor → reweights the principal's personas
- Public information on the school and district (L1 research) → a grounded school-values section and better reverse questions
