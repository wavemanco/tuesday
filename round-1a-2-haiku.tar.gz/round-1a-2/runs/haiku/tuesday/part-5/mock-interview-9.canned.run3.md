Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-tuesday-part-5-rooms-case-9-canned-b9ab91cc/193efb5f-4064-4b11-9442-9b9bafb002d4/scratchpad/Halvering_fourth-grade-teacher_interview_pack.md`.

Your message included a Social Security number. Interview prep doesn't need it, so I didn't use it or put it in the pack. Keep it off anything you send to the district unless they ask for it through a formal application.

The pack is built on your message and CV only. I didn't run any research, so it doesn't cover the district's values, the panel format or recent news. The invite's only stated requirement is the license, and your CV meets it. The pack's main focus is the two gaps you named: you've never taught fourth grade and you've never been a team lead. Question A2 is the one to rehearse most. It's the objection the panel is most likely to press, and it's where a non-defensive answer helps most.

I can play the principal on A2 for a live drill, and I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

Two questions would sharpen it:
1. Do you have the full job posting? It would confirm whether anything beyond the license is required.
2. Should I run light research on the district and school (values, panel format, recent news)? It would add a grounding section and likely a values cheat sheet.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. 45-minute panel, Thursday (the invite gives no date). Panel: Principal Dolores Vantongeren, plus two fourth-grade team members (names not given).

Research tier: L0, no searches. Everything below comes from the invite and your message.

## How to use

Personas are how a question is asked. Types are what it scores: JD (the stated requirements), EXP (your past work, checked for attribution), VAL (values or teamwork), CASE (a live problem), and generic prompts. Guidance is scaffolding for a spoken answer, not a script. Say only what you did, in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | Met on your CV. Confirm it on the ISBE educator license lookup before the panel. The gate is met, so no workaround is needed. |
| F2 | "Fourth Grade Teacher position" (invite title) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | medium | [grounded] | transferability | Your material says six years of third grade and no fourth grade. Bridge only at that scope: "I haven't taught fourth grade. I have six years of third grade at a public elementary school." Answer slot: what you would do in the first month to learn the fourth-grade work, stated as a plan. |
| F3 | Grade-level team work, not stated in the invite ([generic] role pattern; the panel includes two team members) | "I've never been a team lead" (your message); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | none | [grounded] | capability | A gap you stated, so the words are yours: "I haven't been a team lead." The reading-curriculum move is adjacent and is quoted at its own scope, not as a leadership role. Do not stretch it. |

Requirement coverage: license, F1 (met); fourth-grade role, F2; team work, F3 and questions A3, B1 and B3. The posting itself was not supplied, so no other requirements are listed.

Gate note: the license requirement is met on your CV, so it carries no gate question.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Taught fourth grade | Negative you stated (your message) | "I haven't taught fourth grade." |
| Team lead or leading a team | Negative you stated (your message) | "I haven't been a team lead." |
| Chose or wrote the reading curriculum | Inflated form of "I led our grade level's move to a new reading curriculum in 2024" | The quote at its own scope. The pack's observation: your material says you led the move, not that you chose or wrote the curriculum. A4's slot asks which decisions were yours. |
| Student reading gains from the club or the curriculum move | Not in your material | The pack's observation: your material does not show results. D1 and D2 ask how you know, with a slot for whatever you did measure. |
| Family response to the weekly email | Not in your material | The pack's observation: your material says you write the email, not how families responded. D3 asks, with a slot. |

## Personas

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Principal | Probes the fourth-grade and team-lead gaps | High. A principal's panel prior is hiring-manager-like, and the two gaps are the obvious place to probe | Say the gap first, then your strongest real material, then a plan. Hold through two follow-ups, then concede specifically |
| Case / Strategist | Principal | Live problems from the fourth-grade room | Medium. Hiring-manager prior | Clarify before answering; say what you would check first |
| Peer Evaluator | Team members | Seams with their work; how you would fit in | High. Teammates price what a new hire adds to their load | Ask what they need; offer one concrete contribution |
| Data-Driven Prober | Team members | Asks how your CV claims were measured | Medium. The reading club and the curriculum move are the claims a prober would test | Say what you measured, if anything. If nothing, say so |
| Conversational | Panel opener and close | Friendly opener and a closing "any questions?" | Medium. Casual questions are still scored | Use a 90-second arc; ask a real question at the close |

Weights: Skeptic 5 questions, Case 3, Peer 4, Prober 4, Conversational 2. Total 18.

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What makes you the right person for this class?" | JD | [grounded] "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Say the gap in your words: "I haven't taught fourth grade." Then the six years of third grade, at their scope. Then one plan for the first month, stated as a plan. Do not claim fourth-grade experience or standards you have not taught. | F2 is the likeliest probe. The premise is your own stated gap, so the question is fair. |
| A2 | "Why should we hire someone who has never taught fourth grade over someone who has?" | JD | [grounded] "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Highest-ROI prep. Hold the position through two follow-ups: six years at grade three, with the gap named plainly. Concede specifically: you have not taught the fourth-grade standards, and you would learn them with the team first. Do not fold on the six years | The objection the fit snapshot points at. A rehearsed, non-defensive answer changes the panel's read. |
| A3 | "You've never been a team lead. What would you need from me to lead a grade-level team?" | JD | [grounded] "I've never been a team lead" (your message) | Plain acknowledgment: "I haven't been a team lead." Then what you would need from the principal, as your own answer. Answer slot: if you have led anything with a team, say what it was, in your words; if not, say so | F3 is a stated gap. The slot is the honest route to the rest of the answer. |
| A4 | "Tell me about the reading curriculum change. What did you decide, and what was decided for you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: say which decisions were yours and which the district or team made, in your words. If you did not choose the curriculum, say so and describe what you did carry. Never describe selecting or writing it | "Led" is the CV's most senior-sounding line, and probers test it. |
| A5 | "A student is reading two levels below grade in fourth grade. What do you do in the first week?" | CASE | [generic] | Structure it: assess the student, talk to the prior teacher and the team, plan small-group support, and say what you would check first. Make no claim about past students | A live problem from the role. It asks about no past, so the guidance makes no claim. |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk us through how you would join a fourth-grade team midway through the year." | CASE | [generic] | Clarify: the team's plan, calendar and what is working. Then one concrete contribution you could make in the first month | A case the principal would use for a new member |
| C2 | "Your team wants to change how it uses class time for reading. Where would you start?" | CASE | [generic] | Clarify the data and constraints first. Propose a small trial with a way to judge it | The reading focus of the role, asked as a problem. It needs no claim about your past |
| C3 | "Sketch your first 30 days in this class." | CASE | [grounded] "I write a weekly email to families" (your CV) | Plan what you would observe, how you would meet families, and when you would send the first email. Say the weekly email as you write it now | A plan question with one real anchor from your CV |

### Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What do you want from a new teammate on the fourth-grade team?" | JD | [generic] | Ask back. Propose the seams you would want to understand, such as who plans and who grades. Do not pretend to know their seams | Reciprocity: a peer prices what you add to their load |
| B2 | "If we disagree on a grade-level decision, how do you handle it?" | VAL | [generic] | Answer slot: if you have had a real disagreement with a colleague, say what it was and how it ended. If not, say what you would do first | Teamwork is the team-lead gap, asked from a peer's side |
| B3 | "How would you bring a new reading approach to a team that already has its own?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Tell the move in your words. Answer slot: whether the team was consulted and what changed; if you did not consult them, say so | A peer tests the move from the CV the way a team member would |
| B4 | "How do you handle credit when a grade-level project spans several teachers?" | VAL | [generic] | Name the colleagues who did their parts, then your own part. Only the parts you did | Credit probes are a common peer check |

### Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How do you know the reading club is working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Answer slot: if you measured anything, say what and how often, in your words. If not, say so and say what you would track. Never name a result | The CV says you ran it, and nothing more |
| D2 | "What evidence did you use to decide the curriculum change was needed?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: if data drove the decision, say what it was. If none did, say so and say what you would check first | Probers test the reason behind a change |
| D3 | "How do you know families find your weekly email useful?" | EXP | [grounded] "I write a weekly email to families" (your CV) | Answer slot: say what feedback you have had, if any, in your words. If none, say so | The email is the one family-facing claim on your CV |
| D4 | "Which reading assessments did you give your third graders, and how did you use the results?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Answer slot: if you used assessments, name them and how you used them. If you did not, say so | The question presumes assessments your material does not name, so the second branch must allow none |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk us through your path to teaching." | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've run the after-school reading club for the last two years" (your CV) | A 90-second arc: Joliet, third grade, the reading curriculum move, the reading club, and the family email. Only what your CV says | Casual openers are scored |
| E2 | "What's the part of this job you're most looking forward to?" | VAL | [generic] | Give one specific answer tied to reading or to the team. Keep it short | A friendly question that still scores communication |

## Reverse questions

1. "What does a typical week look like for the fourth-grade team?" Why it lands: it shows you are planning for the job, not only the interview.
2. "How does the team plan reading instruction across the grade?" Why it lands: it links to your reading work without claiming any of it.
3. "What would a good first semester look like for the new teacher?" Why it lands: it turns the gap into a shared success measure.
4. "How does the grade-level team make decisions about curriculum?" Why it lands: it shows you understand team decisions, which is the team-lead gap.
5. "What support does the district offer teachers new to a grade level?" Why it lands: it shows you plan to learn the fourth-grade work.
6. Peer reciprocity: "What could a new person do in their first month that would genuinely help your team?" Why it lands: it lets the team members name what they need.

## Sources

Provided documents only: the invite and your message and CV. No searches, no fetches, no user links read.

Research tier: L0, no searches. User links read: 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. District or school values | unavailable | Values cheat sheet, not produced; no values-style round was detected. Research was not run this turn |
| 2. Panel format and process | unavailable | Loop structure; the invite gives only "45-minute panel". Research was not run this turn |
| 3. Recent district or school news | unavailable | Grounding brief; not produced. Research was not run this turn |
| 4. Interviewer names | unavailable | Only Principal Dolores Vantongeren is named; the team members are not. Public footprint not searched this turn |
| 5. Representative fourth-grade JD | skipped | The invite's license requirement and title already fix F1 and F2 |

## Upgrade menu

- The full posting text → confirms or changes F2 and F3, which now rest on the invite's one requirement and your message
- The panel date and time → fixes which Thursday the pack is for
- The two team members' names → per-member persona weights and reverse questions
- Consent to run L1 research on the district and school → values, panel format and recent news, which would make the grounding brief and the values sections possible
- A tuesday-dossier.md → carries this pack's gaps forward into later sessions
