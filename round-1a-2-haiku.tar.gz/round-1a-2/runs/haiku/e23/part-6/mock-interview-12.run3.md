**Stop before you send anything.** This invitation has the usual markers of a recruitment scam:

- A €95 "equipment registration fee" paid before interview.
- A passport photo and bank details requested before you've met anyone.
- A €1,850 cheque to deposit, with the balance forwarded to a "vendor." The cheque is likely to bounce after you've sent real money.

Don't pay the fee, don't send ID or bank details, and don't deposit or forward money from that cheque. Before replying to anyone, check the company independently:

- Search the Companies Registration Office register (cro.ie) for Brennock Facilities Ltd and check the directors and registered address.
- Find the company's phone number and careers page from its own website, not from this email, and ask whether it sent this invitation.
- Check that the sender's email domain matches the company's real website.

If you've already sent money, bank details or ID, call your bank now.

If the company checks out, the interview prep is below. I've saved the full pack here: `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-e23-part-6-rooms-case-12-denied-56138990/b3fa860a-d9ba-4f80-bb7b-41f1bd2caf8a/scratchpad/brennock_remote_administrative_assistant_interview_pack.md`

**What to expect:** a 30-minute video call with the office manager, probably a hiring-manager-style conversation. Expect a sceptical first question about moving from physio reception to a facilities admin role, and expect the invoice question to come up, since the ad names it directly.

**Your honest position, from what you told me:**
- **Calendars:** you ran the appointment book for four physios. That's a shared book, not company calendars, so say it that way.
- **Travel:** nothing in your material shows you've booked travel. If you have, name it; if not, say so and describe how you'd learn the tools.
- **Word:** "good with Word" is your strongest documented skill. Be ready to describe a document you've produced.
- **Excel:** "okay" is self-rated and you'd be tested on it. Name one real task and give your honest level.
- **Invoices:** you chased unpaid invoices, which is adjacent to processing them. Say that plainly. Don't describe yourself as having processed invoices.

**Rehearse these first:**
1. **"Why should we trust you with this, given you've worked in a clinic?"** Name what carries over (the appointment book, following up on money), name the gap, and say how you'd get up to speed.
2. **"Have you processed supplier invoices, or only chased them?"** Say what you chased, from whom, and what happened. If you did any part of processing, say which part; if not, say so.
3. **A live scheduling problem**, such as three clashing meetings and a flight needed by tomorrow. Clarify priorities first, then propose a fix and confirm it.

**Questions to ask them:** what a typical week looks like; which of the four tasks takes the most time; who approves invoices and what the payment cycle is; what support you'd have when working remotely; and who you'd speak to after this call.

**Upgrade menu:** if you paste the full advert, each requirement becomes a quote rather than my summary of it. If you have the office manager's name, I can tailor the questions to them. If you have any example of travel booking or Excel work, the two weakest rows become grounded.

I didn't run any web searches, so the company's values and current news aren't covered.

Would you like a live practice round on the invoice question? I can play the sceptical interviewer. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

Two quick questions: have you already sent any money, passport photo, bank details or the cheque? And did you apply through a job board or directly on the company's website?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote_administrative_assistant_interview_pack.md -----
# Brennock Facilities Ltd: Remote Administrative Assistant, interview prep

**Before you use this pack:** the invitation asks for a €95 fee, a passport photo and bank details before interview, and a €1,850 cheque to deposit with the balance forwarded to a vendor. Those are common scam markers. Do not pay, do not send ID or bank details, and do not deposit or forward money on the strength of that cheque. Verify the company independently first (see the message that presents this pack).

Interviewer: the office manager (name not given). Round: 30-minute video call. Assumption: the office manager is the hiring manager for this role. Role requirements come from your summary of the ad, not the full text.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is scored: EXP (your experience), JD (the role), CASE (a live problem), CO (company), VAL (values).
- Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your note of the ad) | "ran the appointment book for four physios" (your message) | medium | [grounded] | presentation | Your material shows a shared appointment book for four people, not company calendars. Say it that way: "For two years I ran the appointment book for four physios." |
| F2 | "booking travel" (your note of the ad) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you booked travel for anyone, say what and for whom; if not, say so plainly and say how you would learn the tools. |
| F3 | "preparing documents in Word" (your note of the ad) | "good with Word" (your message) | medium | [grounded] | none | Quote already reaches the requirement, but it is self-rated. Expect a test: be ready to describe a document you have produced. |
| F4 | "preparing documents in Excel" (your note of the ad) | "okay with Excel" (your message) | low | [grounded] | discovery | The quote touches the requirement but does not show your level. Answer slot: name one task you did in Excel, and rate yourself honestly. |
| F5 | "processing supplier invoices" (your note of the ad) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | Chasing unpaid invoices is adjacent to processing them, not the same. Bridge: "I chased unpaid invoices." Answer slot: if you did any part of processing, say which; if none, say so plainly. |

Gap-and-bridge language is the pack's observation, not words for you to say, except where quoted.

## Prohibited claims

These are not to be coached, because they stretch your own sentences:

| Not coached | Basis | Honest form |
|---|---|---|
| "Processed supplier invoices" | Inflated form of F5 | "Chased unpaid invoices." The material says chasing, not processing. |
| "Advanced Excel" or "Excel expert" | Inflated form of F4 | "Okay with Excel," at your own level. |
| "Managed executive calendars" | Inflated form of F1 | "Ran the appointment book for four physios." |

## Persona weights

| Persona | Weight | How it shows up | Why | Counter-strategy |
|---|---|---|---|---|
| Skeptic | 5 (top) | Probes the gap between a physio reception role and an admin role for a facilities firm | Hiring manager prior: they are buying capability and checking gaps | Rehearse the invoice question until it is routine; name gaps plainly |
| Case / Strategist | 4 | A live scheduling or travel problem | Office manager will want to see how you prioritise | Clarify first, then structure, then act |
| Conversational | 3 | An opener about your journey, plus a casual question about Word or Excel | Short call; rapport still counts | 90-second arc; treat casual questions as scored |
| Data-Driven Prober | 2 | "How do you know that Excel is up to it?" | Light; the Excel claim is self-rated | Say your level and one example |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is a physiotherapy clinic. Why should we trust you with calendars and invoices for a facilities company?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | Say what the work shares: you kept an appointment book for four people. Name the gap: you have not worked in facilities. Then say how you would get up to speed. Do not claim facilities experience. | Highest-ROI prep. It is the most likely objection and comes from the mismatch in your background (F1, F5). |
| B2 | "Have you ever processed supplier invoices, or only chased unpaid ones?" | JD | [grounded] "chased unpaid invoices" (your message) | Say what you chased, from whom, and what happened. Answer slot: if you did any part of processing them, say which part in your own words; if none, say so plainly and do not stretch "chased" into "processed". | This is F5's gap, and the ad names invoice processing directly. |
| B3 | "The director's calendar has three clashing meetings and needs a flight to Cork tomorrow. What do you do?" | CASE | [generic] | Clarify priorities first, check with the director, then propose a fix and confirm. Make no claim about your past. | Calendars and travel are both in the ad (F1, F2), asked as a live problem. |
| B4 | "So, walk me through the journey to here." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | 90 seconds: the clinic, what you ran, what you chased, and why you are applying. Your reasons for applying are not in your material; say them in your own words. | Opener with a casual register that is still scored. |
| B5 | "How did you keep the appointment book for four physios organised?" | EXP | [grounded] "ran the appointment book for four physios" (your message) | Describe what you did to keep it accurate. Answer slot: if you had a specific method, name it; if the system handled it, say so plainly. | F1's evidence, tested for specifics. |
| B6 | "Show me how you'd build a supplier invoice tracker in Excel." | JD | [grounded] "okay with Excel" (your message) | Say what you would put in the tracker and how you would keep it up to date. Answer slot: name one Excel task you have done, and your honest level. | F4's gap. |
| B7 | "Tell me about a document you've produced in Word." | EXP | [grounded] "good with Word" (your message) | Name the document, its audience, and what you did to it. Answer slot: if you have no example, say so and describe how you would produce one. | F3's evidence. |

**Requirement coverage:** managing calendars: B1, B3, B5. Booking travel: B3 (answer slot only). Word: B7. Excel: B6. Processing supplier invoices: B2. Working remotely: none, and why: it is not in the ad summary you gave me.

## Reverse questions

1. "What does a typical week look like for whoever holds this role?" Why it lands: shows you are thinking about the actual job.
2. "Which of calendars, travel, documents and invoices takes the most time?" Why it lands: shows you want to focus on the real work.
3. "Who approves supplier invoices, and what is the payment cycle?" Why it lands: shows you understand the process end to end.
4. "What tools and support would I have when working remotely?" Why it lands: a practical question that suits a remote role.
5. "What would a good first 90 days look like?" Why it lands: asks for the success criteria.
6. "Could you confirm the next steps, and who I would speak to after this call?" Why it lands: a normal question, and a good way to confirm the process.

## Sources

Research tier: L0. No searches or fetches were run. Company values, the interview process and current news are not established here, and the interview is taken as the invite describes it.

## Upgrade menu

- The full text of the advertisement → each requirement becomes a quote instead of your summary.
- The office manager's name → reverse questions tailored to their path, and persona weights from their public profile.
- Any example of booking travel or of an Excel task → F2 and F4 move from answer slots to grounded rows.
