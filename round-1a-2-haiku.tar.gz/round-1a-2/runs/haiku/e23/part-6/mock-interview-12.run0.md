**Before you reply to this email, please don't send any money, passport photo, or bank details.** The message has several hallmarks of a job scam.

**Warning signs in the email**
- **Upfront fee.** Legitimate employers don't charge candidates for equipment registration or to confirm an interview slot. A €95 transfer to a "supplier" account is the payment the scam is after.
- **Identity documents and bank details before any interview.** Real employers request these only after a formal offer, through HR systems.
- **The cheque.** Depositing a €1,850 cheque and sending the "balance" to a vendor is the classic fake-cheque scam. Banks often make funds available within a day or two, before they find out the cheque is fraudulent. When it bounces, you owe the money, and anything you've already sent is gone.
- **Pressure wording.** "To speed up onboarding" and "before your interview slot can be confirmed" are designed to make you act before you check.
- **Contact details come from the email.** Don't rely on the address or any links in it.

**What to do now**
1. Find the company's phone number and website yourself, through a search, not through this email.
2. Check that Brennock Facilities Ltd is registered on the Companies Registration Office search (cro.ie).
3. Ask the job board or site where you saw the ad whether it was posted by this employer.
4. If you've already sent money, documents, or deposited a cheque, contact your bank immediately and report it to the Gardaí.

I haven't searched for Brennock or checked the company, so I can't tell you whether it's real. The steps above will settle that.

**Interview prep (useful for any admin role, and for this one if it turns out to be genuine)**

This is general prep, not based on research into Brennock.

**Your strongest bridges, in your own words**
- "Ran the appointment book for four physios" → managing several people's calendars and competing priorities. This is the core of the job.
- "Chased unpaid invoices" → the receivables side of invoice work. The job is the payables side. Say that you understand the process from the other direction, and that matching and following up on invoices is familiar.
- Word: good. Excel: okay. Be specific about what you use it for.

**Gaps, with honest bridges**
- **Travel booking.** You have no direct experience. Say so, then point to the scheduling parallel and say how you'd learn the company's booking tools and policies. Don't claim business travel experience you don't have.
- **Excel.** Before the call, practise the functions a job like this uses (SUM, IF, VLOOKUP or XLOOKUP, simple pivot tables) so you can name what you've done and what you'd check.

**Likely questions and how to answer them** (aim for about two minutes each, using a real example)
1. *Tell me about yourself.* Two years of reception and appointment management, then the admin skills you want to build on.
2. *How do you handle a diary with clashing demands?* Use a real example from the physio clinic: how you decided what moved, and how you told people.
3. *Tell me about chasing a late payment.* Describe how you stayed polite and firm, and what the outcome was.
4. *Have you booked travel before?* Answer honestly (see above).
5. *How would you rate your Excel?* Give a concrete example, and don't overstate it.
6. *How do you prioritise when everything is urgent?* Use one real example.
7. *How do you handle confidential information?* Describe how you kept patient details private at the clinic.

**Questions to ask them**
- What does a typical week look like, and how is the work split across the team?
- Which systems do you use for calendars, travel, and invoices?
- What would success look like after the first three months?

**Logistics:** test your camera and microphone, use a quiet room with a plain background, and have two or three examples written down.

**Upgrade menu:** if you share the full job ad, I can tailor the questions. If you tell me the company's real website and phone number, I can help you draft a verification email. I can also run a live rehearsal in which I play the office manager and ask follow-ups.

**Question:** Did you see the ad on a job board, and does the interview invitation come from an address on the company's real website?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.