**Please verify this employer before you prepare or send anything.** The email has several features of a job scam:

- **A €95 "registration fee"** paid to a supplier account. Real employers don't charge candidates to register.
- **A passport photo and bank details before any interview.** An interviewer doesn't need these yet.
- **A €1,850 cheque to deposit, with the balance forwarded to a vendor.** The cheque can be credited before it clears and then returned, leaving you out the money you sent.
- **Unverifiable details.** The contact is `hr@brennock.example`, and the IBAN's check digits are `00`, which fails the standard IBAN check.

Do not pay, do not send your passport or bank details, and do not deposit the cheque. To verify, search the Companies Registration Office for Brennock Facilities Ltd, find a phone number on the company's own website (not from this email), and ask whether they are interviewing for this role. If you have already sent money or details, contact your bank now and report it to the Gardaí and your bank's fraud line.

If verification succeeds, the prep pack is saved here: `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-e23-part-6-rooms-case-12-denied-d942f9a3/b92a6dc9-73dd-45c8-93ee-30259a8b209e/scratchpad/aoife-brennock-prep-pack.md`

It covers:
- **Fit snapshot.** Calendar management is your strongest match, from the appointment book for four physios. Booking travel has no evidence in your material. Word and Excel are a proficiency gap, and invoice processing is a scope gap, since you chased invoices rather than processing them.
- **Prohibited claims.** Don't claim travel booking, advanced Excel, or end-to-end invoice processing unless you have done them.
- **Seven likely questions** with answer guidance tied to your own words, including a skeptic question on travel and a precise answer on invoices.
- **Four reverse questions** for the interviewer.

**Upgrade menu:** a full job description would sharpen the questions. Confirmation of the interview details from the company's own contact would let me check the format and the office manager's name. A dossier, if you have one, would add verified evidence.

**Drill offer:** I can play the office manager and run any of these questions with follow-ups, then give feedback. **Dossier offer:** I can produce a `tuesday-dossier.md` from this pack if you want to carry it into other applications.

Three quick questions, once you've verified the company:
1. When you chased invoices, did you also enter them, get them approved, or record payments?
2. Which Excel functions do you use most, such as SUM, VLOOKUP, or pivot tables?
3. Where did you see the ad: the company's website, a job board, or an email from a recruiter?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: aoife-brennock-prep-pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Status: HOLD. Verify the employer before doing any of this.** See "Before you go further" below.

## Before you go further

The invitation contains four features that match known job-scam patterns:

1. **Fee before interview.** A €95 "equipment registration fee" paid to a "supplier" account. Legitimate employers do not charge candidates to register, and do not pay suppliers through candidates.
2. **Identity and bank details before interview.** A passport photo and bank details, requested before any interview. A real interviewer needs neither at this stage.
3. **Cheque to deposit and forward.** A €1,850 cheque for "laptop and desk", where you deposit it and send the balance to a vendor. Banks usually credit a cheque before it has cleared. When the cheque is later returned, the money you forwarded is gone and you are liable for it.
4. **Unverifiable contact.** The email comes from `hr@brennock.example`, and the IBAN's check digits are `00`, which fails the standard IBAN validity check.

**What to do now:**
- Do not pay the €95, do not send a passport photo or bank details, and do not deposit any cheque.
- Verify independently. Search the Companies Registration Office (CRO) for "Brennock Facilities Ltd" and check the registered address and directors. Find the company's phone number from its own website, not from this email, and ask them whether they are interviewing for this role.
- Check where the ad was posted. A real ad should appear on the company's own careers page or a reputable job board.
- If you already sent money or details, contact your bank now, and report to An Garda Síochána (or your local police) and to the Fraud Helpline for your bank.

If verification succeeds, the rest of this pack applies. Until then, treat it as on hold.

## Fit snapshot

| JD requirement (from ad) | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| Managing calendars | "I ran the appointment book for four physios" | High | None | Strong match: you managed competing diaries for several people. |
| Booking travel | Not in your material | Low | Experience gap | You have not booked travel in your material. Say so, and bridge with your scheduling and coordination work. |
| Preparing documents in Word | "good with Word" | Medium | Proficiency gap | Describe the documents you have produced in Word, and say how you would get up to speed on anything new. |
| Preparing documents in Excel | "okay with Excel" | Low | Proficiency gap | Be specific about the functions you use. Do not claim more than that. |
| Processing supplier invoices | "chased unpaid invoices" | Medium | Scope gap | Chasing invoices is not the same as processing them. Clarify what you did with the invoice records. |

**Confidence** reflects how directly the quote supports the requirement. **Gap type** is the kind of gap: experience, proficiency or scope.

## Prohibited claims

Do not claim any of the following in the interview:
- Experience booking business travel, unless you have done it.
- Advanced Excel (pivot tables, formulas beyond basics, macros), unless you use them.
- Processing supplier invoices end to end (entry, approval, payment), unless you did.

## Likely questions and answer guidance

### Experience (type: experience)

**Q1. Tell me about your background and why you're applying for this role.**
- *Guidance:* Lead with the appointment book for four physios, then the invoice chasing. Keep it to two minutes.
- *Provenance:* Candidate's own words. "I ran the appointment book for four physios" and "chased unpaid invoices."
- *Rationale:* An opener that sets up the calendar and invoice themes the rest of the interview will test.

**Q2. How do you manage a calendar when several people's diaries conflict?**
- *Guidance:* Describe how you set priorities, which bookings you moved and who you checked with before moving them. Use one real example.
- *Provenance:* Candidate's own words. "I ran the appointment book for four physios."
- *Rationale:* Tests the core duty in the ad, managing calendars.

**Q3. Have you ever processed invoices, or only chased them?**
- *Guidance:* Answer precisely. If you chased invoices and kept records of who had paid, say that. Do not stretch it into processing, approval or payment.
- *Provenance:* Candidate's own words. "chased unpaid invoices."
- *Rationale:* Checks the scope gap directly. Precision here is the honest answer and also the stronger one.

### Skills (type: skills)

**Q4. How would you rate your Word and Excel skills?**
- *Guidance:* Rate Word as good and Excel as working knowledge, then name the Excel functions you actually use. Offer to show what you can do.
- *Provenance:* Candidate's own words. "good with Word," "okay with Excel."
- *Rationale:* The interviewer will test the gap. An accurate self-rating with specifics beats an inflated one.

**Q5. Walk me through a document you prepared in Word.**
- *Guidance:* Pick a real document. Explain its purpose, its audience and the formatting you used.
- *Provenance:* Candidate's own words. "good with Word."
- *Rationale:* Turns a general claim into evidence the interviewer can judge.

### Behavioural (type: behavioural)

**Q6. Tell me about a time you had competing priorities with a deadline.**
- *Guidance:* Use the appointment book or invoice chasing. Describe the situation, what you chose to do first and why, and the result.
- *Provenance:* Candidate's own words, drawn from the appointment book and invoice chasing.
- *Rationale:* Standard behavioural question that tests judgment under pressure.

### Skeptic (type: skeptic)

**Q7. You've never booked travel. How would you handle it?**
- *Guidance:* Say you have not booked travel professionally. Describe how you would approach it: check the policy, compare options, confirm the booking in writing. Do not claim experience.
- *Provenance:* The gap is from the fit snapshot. No candidate sentence supports travel booking, so this is an answer slot.
- *Rationale:* Tests whether you can admit a gap and still show a plan.

## Reverse questions to ask the interviewer

1. "What does a typical week look like for this role?" *Why it lands:* Shows you care about the work, not just the offer.
2. "Who would I work with most closely, and how is the work divided?" *Why it lands:* Clarifies the role and how the office runs.
3. "How do you handle supplier invoices, and who approves them?" *Why it lands:* Probes the invoice scope directly, and shows you understand the process.
4. "How would you describe success in this role after six months?" *Why it lands:* Gives you a concrete target to measure yourself against.

## Delivery notes

- The interview is 30 minutes by video. Test your camera, microphone and connection beforehand.
- Keep answers to around two minutes. Use one example per question.
- Have one or two examples ready from the physiotherapy clinic.

## Upgrade menu

- **Full job description.** Unlocks questions specific to the duties and sharper gap analysis.
- **Confirmation of the interview details from the company's own contact.** Unlocks a check on the interview format and the office manager's name.
- **A `tuesday-dossier.md`, if you have one.** Adds verified evidence and strategy constraints.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.
