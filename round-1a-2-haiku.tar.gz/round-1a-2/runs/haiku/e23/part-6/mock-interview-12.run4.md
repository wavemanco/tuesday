**Stop before you pay or send anything. This email has the hallmarks of a recruitment scam, and the interview prep below only matters if the job is real.**

## Red-flag assessment

| What the email asks | Why it's a problem |
|---|---|
| €95 "equipment registration fee" before your interview slot is confirmed | Legitimate employers don't charge candidates to interview or register. Paying it gets you nothing and the money is gone. |
| Passport photo and bank details before the interview | No real employer needs these before you've met anyone. This is identity theft material. |
| €1,850 cheque: deposit it and send the balance to "the approved vendor" | This is the classic fake-cheque scam. The cheque looks real, your bank may show the funds as available within days, but it is later declared fraudulent. You've then sent your own real money to the scammer, and the bank will recover the cheque amount from you. |
| Urgency ("before your interview slot can be confirmed", "to speed up onboarding") | Pressure to act before you can check is a standard tactic. |
| Generic company details: a `.example` address and no way to verify it from the email | I can't confirm from here whether Brennock Facilities Ltd exists. Verify it yourself (see below). |

**What to do:**
1. **Don't pay the fee, don't send the photo or bank details, and don't deposit the cheque.**
2. **Verify independently.** Search the Companies Registration Office (CRO) register for Brennock Facilities Ltd, find the company's website through a search engine (not a link from this email), and phone the number you find there to ask whether they're recruiting for this role.
3. **Check where you saw the ad.** Did you apply through a known job board, or was it a message someone sent you? Reply to the email only after you've verified the company.
4. **If you've already sent money, cheque details or documents,** contact your bank now, then report to the Gardaí (or your local station) and to the Garda National Economic Crime Bureau. Report the email to the job board where you found the ad.

If the company checks out and the role is real, the interview is still worth preparing for. Here's the prep.

## Interview prep (assuming the role is genuine)

**Format:** 30-minute video call with the office manager, which is a single-interviewer, fairly informal round. Expect a mix of "tell me about yourself", situational questions about the job's duties, and a few questions about remote working.

**Likely focus:** the four duties in the ad (calendars, travel, Word/Excel documents, supplier invoices).

### Fit snapshot

| Job requirement | Your evidence (your words) | Gap type | Gap-and-bridge language |
|---|---|---|---|
| Managing calendars | "ran the appointment book for four physios" | Direct | Strong match. Say the number of people and how you handled clashes. |
| Processing supplier invoices | "chased unpaid invoices" | Adjacent | You chased invoices, which was receivables rather than supplier payables. Say so and explain the skill transfers. |
| Preparing documents in Word | "good with Word" | Direct | Name the specific things you produce. |
| Preparing documents in Excel | "okay with Excel" | Partial | Be specific about what you can do and don't claim more. |
| Booking travel | Not in your material | Gap | No direct experience. Say it plainly and bridge with scheduling and coordination. |

### Questions and answer guidance

**1. "Tell me about yourself."** *(Type: opener, general)*
- Guidance: two years as a receptionist at a physiotherapy clinic, running the appointment book for four physios and chasing unpaid invoices, then move to why you're interested in admin.
- Rationale: an easy opener; the answer should set up the calendar and invoice questions that follow.

**2. "How do you manage a busy calendar with competing demands?"** *(Type: behavioural, role-specific)*
- Guidance: describe how you ran the appointment book for four physios: how you handled double-bookings and cancellations, and what you did to keep the diary accurate.
- Rationale: this is the closest match to the job, so it's the answer to rehearse most.

**3. "Tell me about a time you had to chase payment or a difficult follow-up."** *(Type: behavioural, judgement)*
- Guidance: describe how you chased unpaid invoices: how you followed up, kept it professional, and what you did when a client didn't respond.
- Rationale: it shows the invoice skill transfers, though you'll need to explain it was receivables.

**4. "How comfortable are you with Excel? Walk me through something you've used it for."** *(Type: skills check)*
- Guidance: be honest about "okay". Name one or two things you have actually done and don't stretch beyond them.
- Rationale: they'll likely test this, so an overstatement is risky.

**5. "Have you booked travel before?"** *(Type: gap probe)*
- Guidance: say you haven't handled travel bookings, then bridge to the scheduling and coordination you did, and say you'd learn the company's booking tools quickly.
- Rationale: an honest gap answer is better than an inflated one.

**6. "How do you work when you're remote?"** *(Type: fit)*
- Guidance: describe your routine, how you stay in touch with colleagues, and how you keep track of tasks. Only claim habits you actually have.
- Rationale: the role is remote, so expect this.

### Reverse questions to ask
- "What does a typical week look like in this role?"
- "How does supplier invoice approval work here, and which systems are used?"
- "How is the team managed day to day when people are remote?"

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

## Upgrade menu

Adding any of these would sharpen the pack:
- **The full job description**, to replace the summary in the ad. It would show exactly which Excel and travel tasks are needed.
- **Where you found the ad**, so I can help you judge whether it's a legitimate listing.
- **Any messages from the company** beyond this email.

## Offers

- **Drill:** I can play the office manager and run you through the 30-minute call with follow-up questions, if the interview is confirmed through verified channels.
- **Dossier:** I can save this pack as a `tuesday-dossier.md` file to carry forward.

## Questions

1. Where did you see the ad, and did you apply to it or did the company contact you first?
2. Have you sent anything to this company yet (money, cheque details, documents)?
3. Can you check the CRO register and a phone number you find independently, and tell me what you find?