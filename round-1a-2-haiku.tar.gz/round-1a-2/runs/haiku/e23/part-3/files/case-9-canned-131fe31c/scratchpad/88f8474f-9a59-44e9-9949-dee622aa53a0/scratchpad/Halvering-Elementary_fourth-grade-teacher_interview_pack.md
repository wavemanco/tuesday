# Interview prep: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District (Illinois). 45-minute panel interview on Thursday with Principal Dolores Vantongeren and two members of the fourth-grade team (names not given).

Assumptions this pack is built on: the principal is the supervisor and the two team members are peers; no job posting text was supplied, so requirements come from the invite only; no research was run; prep time is unknown, so the full pack is given.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored. Type key: **JD** = stated job requirement; **EXP** = what you actually did; **VAL** = behavior and values; **CASE** = live problem.
- Guidance is scaffolding, not a script. Say it in your own words, and only the parts your own experience supports.

## Fit snapshot

Requirements come from the invite (quoted). Your evidence is quoted from your CV notes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | Met on your CV, so no gap and no answer slot. Share license details through the district's own application process, not in the interview. |
| F2 | "the Fourth Grade Teacher position" (invite) | "Six years teaching third grade at a public elementary school in Joliet" (your CV) | medium | [grounded] | transferability | Your material says third grade, not fourth. Words: "For six years I taught third grade at a public elementary school in Joliet." That quote's scope ends there. Answer slot: the panel may ask what carries over from third to fourth grade. If you can name something specific you did in third grade that you would do in fourth, say it in your own words; if not, say so. |
| F3 | "the Fourth Grade Teacher position" (invite) | "I've never taught fourth grade" (your CV) | none | [grounded] | capability | A gap you stated, and the pack will not make it smaller. Words: "I haven't taught fourth grade." Then how you would learn fourth-grade content, said as a plan and never as a past. |
| F4 | None in the invite. Team leadership is included because you named it as a gap. | "I've never been a team lead" (your CV) | none | [grounded] | capability | A gap you stated. Words: "I haven't been a team lead." Then, if asked, what you have led, in the terms of F5. |
| F5 | [generic] Works with a grade-level team | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | transferability | Adjacent work that does not reach a team-lead role. Words: "In 2024 I led our grade level's move to a new reading curriculum." Its scope ends there; do not call it team leadership. Answer slot: which decisions in that move were yours, and how colleagues took them. If you made them, say which; if the move was decided above you, say so and say what you did. |
| F6 | [generic] Reading instruction | "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | none | Reaches the requirement in role-relevant terms. Words: "For the last two years I've run the after-school reading club." |
| F7 | [generic] Communication with families | "I write a weekly email to families" (your CV) | medium | [grounded] | presentation | Your quote already reaches the requirement in other terms. Words: "I write a weekly email to families." Add no practice, figure or event. |

## Prohibited claims

These are not to be coached, whether they come from something you stated or from a stretched version of it.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have taught fourth grade" | Negative you stated (F3) | "I haven't taught fourth grade." No answer slot. |
| "I have been a team lead" | Negative you stated (F4) | "I haven't been a team lead." No answer slot. |
| "I led the fourth-grade team" or "I led a team" | Inflated form of F5 | F5's quote at its own scope. Your material shows a grade-level move, not a team. The answer slot stays inside that move. |
| "I ran the reading program" | Inflated form of F6 | F6's quote: the after-school reading club. |
| "I measured the reading curriculum's results" | Inflated form of F5; no measure is in your material | Your material does not show measured results. C1 asks only what you tracked, if anything. |

## Reading the panel

No interviewer profile was given beyond the principal's name, so there is no public-footprint read. Persona weights follow the panel rule: the principal leans Skeptic and Values, and the team members lean Peer Evaluator and Data-Driven Prober.

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Skeptic (principal, lead) | Presses on fourth grade and team lead, the two gaps you stated | High; the gaps are the first thing a panel checks | Plain acknowledgment, then the bridge, then a plan. Hold through two follow-ups. |
| Peer Evaluator (team members) | Seams between grades, credit, disagreement | High; this is how peers price a hire | Seams as principles, not invented facts. Reciprocity: what you bring their team. |
| Data-Driven Prober (team members) | "How do you know it worked?" | Medium; no figures appear in your materials | Say what you tracked, if anything. If nothing, say so and what you would measure first. |
| Values / Behavioral (principal) | Stories about families, colleagues, unpopular truths | Medium | Open-prompt stories, with an honest "nearest thing" if nothing comes to mind. |
| Case / Strategist | A live fourth-grade problem | Medium | Clarify, then structure, then answer. |
| Conversational | Opening "walk me through," closing "anything for us?" | Medium; casual questions are still scored | A 90-second arc; keep the reverse questions ready. |

Weights: Skeptic 5 questions; Peer Evaluator 3; Data-Driven Prober 3; Values / Behavioral 3; Case 2; Conversational 2. That is 18 questions.

## Question banks

**Highest-ROI prep: A3.** The panel is most likely to raise the fourth-grade gap in some form. Rehearse A3 until the hold-and-concede is automatic.

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years. Why should we hire you for fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; [grounded] "I've never taught fourth grade" | Start from the six years: "For six years I taught third grade at a public elementary school in Joliet." Then say plainly: "I haven't taught fourth grade." Then a first-30-days plan, said as what you would do, not what you have done. About 60 seconds. | F2 and F3. The question is premised on the stated gap, which you did state, so the honest acknowledgment is allowed here. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Name the fourth-grade content you have not taught, specifically, then the ramp you would use to learn it. Do not promise speed. | F3. A candid answer to a skeptic's standard question. |
| A3 | "Why hire a teacher who has never taught fourth grade over one who has?" | JD (Pressure) | [grounded] "I've never taught fourth grade"; [grounded] "I led our grade level's move to a new reading curriculum in 2024" | **Hold-then-concede.** Hold the record you can stand behind: six years of third grade, and the 2024 curriculum move. Concede the gap specifically: "I haven't taught fourth grade, and I won't pretend I have." Do not fold to "I can do it" without evidence. | F2 and F3. This is the objection to rehearse until it is boring. |
| A4 | "Have you led a team?" | JD | [grounded] "I've never been a team lead"; [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Plain acknowledgment first: "I haven't been a team lead." Then the bridge: "In 2024 I led our grade level's move to a new reading curriculum." Answer slot: which decisions in that move were yours, and how colleagues responded. If you made them, say which; if the move was decided above you, say so and say what you did. | F4 and F5. The question presupposes a team-lead role, which you stated you have not held, so the honest branch is allowed. |
| A5 | "That curriculum move: how much of it was actually you?" | EXP (Pressure) | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | **Hold-then-concede.** Name your part in your words, and do not stretch the word "led." If others made the final call, say so. Concede what you do not know about how the rest of the grade decided. | F5. A test of whether "led" survives a follow-up. |

### Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our team plans units together. Where's the seam between third-grade and fourth-grade work, and what happens when we disagree?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Two parts. Seam: say what you know about the third-to-fourth handoff, and say you would learn the rest from them. Disagreement: pick a time you disagreed with a colleague about a plan. If none comes to mind, say so, then give the nearest thing your material carries (the 2024 move). | F2. Peers ask this to see whether you will argue well and also take a call. |
| B2 | "How do you handle credit when a grade-level project spans teams?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Name who did what in the move, in your words, without putting names or roles into the answer that you do not know. Credit colleagues by what they did. Answer slot: if you were the one who made the call, say so; if not, say so. | F5 and F4. Peer credit probes test whether "led" sounds like "took." |
| B3 | "What would you bring to our team that we don't already have?" | JD | [grounded] "I've run the after-school reading club for the last two years" | Say what the reading club has given you that a grade team could use, in your own words. Keep it to what you ran and what it showed. | F6. Reciprocity: what you bring their team, not what you need from it. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How do you know the reading curriculum change worked?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot. If you tracked results, say what you tracked, from whom, and how you counted it. If you did not, say so, then say what you would measure first. Do not name a figure your material does not contain. | F5. No figure appears in your material, so the honest answer may be "I didn't measure it." |
| C2 | "How do you know the reading club helped the students who attended?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Same slot as C1. Name what you observed, and say whether anything was counted. If nothing was, say so. | F6. A prober checks whether "helped" is a claim you can defend. |
| C3 | "How do you know your weekly family emails reach the families who need them?" | EXP | [grounded] "I write a weekly email to families" | Answer slot. Say how you know, if you know, such as replies or conversations. If you do not know, say so, then what you would check. | F7. The email is real; whether it reaches anyone is not in your material. |

### Case / Strategist (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your fourth-grade team is midway through a new reading unit, and two students are far behind. What do you do?" | CASE | [generic] | Clarify first: what the assessment shows, what the team has tried, and what the students need. Then structure: the students, the unit, and the team. Think aloud. | A live problem from the role. It asks about no past, so it claims nothing about you. |
| D2 | "A parent emails that she disagrees with the new reading curriculum. How do you respond?" | CASE | [generic] | Structure it: what you would ask her first, what you would share and with whom, and how the team's decision stays intact. | A live problem about family communication. No claim about your past. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; [grounded] "I've run the after-school reading club for the last two years" | A 90-second arc: third grade, the 2024 curriculum move, the reading club, then why fourth grade. Say the "why fourth grade" in your own words; do not supply a motive you do not have. | Casual openers are scored. This sets up the whole panel. |
| E2 | "What's the part of teaching you most look forward to?" | VAL | [generic] | A genuine answer in one or two sentences. Do not describe a student or event you do not have. | A rapport question. Keep it short and real. |

### Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time a family was upset with you." | VAL | [grounded] "I write a weekly email to families" | Open prompt. If you have such a time, tell it with the weekly email as the channel. If none comes to mind, say so, then the nearest thing your material carries: the email itself. Do not invent an incident. | F7. The question is open, so you choose the instance. |
| F2 | "Tell me about a time you delivered an unpopular truth to a colleague or leader." | VAL | [generic] | Open prompt. Pick a real time. If none comes to mind, say so, then give how you would handle it. | A standard values probe. No claim about your past in the guidance. |
| F3 | "When did you put a student's need ahead of a curriculum or schedule?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Open prompt. If the 2024 move involved a time you chose a student over the plan, say so, in your words. If not, say so, then the nearest thing your material carries. | F5. The honest branch matters more than the story. |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Valid Illinois PEL with elementary endorsement (gate) | Met (F1). No question. |
| Fourth Grade Teacher position | A1, A2, A3, D1 |
| Team leadership (not in the invite; you named it) | A4, A5, B2 |
| Works with the fourth-grade team | B1, B3, F3 |
| Reading instruction [generic] | C2, E1 |
| Family communication [generic] | F1, C3, D2 |

## Reverse questions

Each one has a reason it lands. Ask them in the interview.

1. "What does a strong first semester look like for someone joining the fourth-grade team?" Lands because it shows you plan to succeed, not only to be hired.
2. "How does the team plan units together right now?" Lands because it shows you are asking how, not whether.
3. "Which reading curriculum does the fourth-grade team use, and what is working for them?" Lands because it connects to your 2024 move without claiming it.
4. "What would you want a new teacher to learn from the team in the first month?" Lands as reciprocity: it asks what they need from you.
5. "How does the team decide when two teachers disagree about a plan?" Lands because it tests the seam you may be asked about in B1.

## Sources

- Provided documents: the interview invite; your resume notes and message.
- Research tier: L0. No searches or fetches were run in this pass.

| Target | Status | What it would have moved |
|---|---|---|
| Halvering Elementary values | unavailable | Values cheat sheet (only if a values-style round is detected) |
| Orrinsford interview process, fourth-grade role | unavailable | Loop structure and persona weights |
| District strategy and recent news | unavailable | Grounding brief |
| Dolores Vantongeren (Orrinsford) | unavailable | Interviewer read and a tailored reverse question |
| Representative fourth-grade teacher JD | unavailable | Requirements beyond the invite; would turn the [generic] rows into [inferred] |

## Upgrade menu

- The full job posting → requirement rows become [grounded]; questions for each requirement get checked against it
- Whether the principal supervises this role, and the two team members' names → persona weights per panel member
- Your prep time before Thursday → a prep triage schedule
- Research at L1 (values, interview process, a representative JD) → grounding and values sections
- The district's recruiter email on focus areas or a pre-declared deliverable → a graded-deliverable section, if one is named
- Your answers to A4, A5, C1 and C3 → those rows upgrade from answer slots to story-mapped guidance, once you have said them outside a drill
