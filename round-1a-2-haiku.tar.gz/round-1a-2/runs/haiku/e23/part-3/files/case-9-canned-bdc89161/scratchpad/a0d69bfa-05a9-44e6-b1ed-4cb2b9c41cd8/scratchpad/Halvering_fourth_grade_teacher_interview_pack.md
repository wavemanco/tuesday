# Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District): interview prep pack

Round: 45-minute panel on Thursday (date not given). Principal Dolores Vantongeren plus two fourth-grade team members. Names of the team members not given.
Built on: the invite, your résumé, your two messages, the district's mission and hiring pages, and one public speaker profile for the principal. No job description was supplied, so the requirement list is the invite's license line plus the topics the district's hiring page says panels ask about.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: JD (the posting's requirements), EXP (your experience, and whether it holds up), CASE (a live problem from the job).
- The guidance is scaffolding, not a script. Rehearse the beats in your own words. Anything in square brackets is a provenance label: [grounded] traces to your inputs or a fetched page, [inferred] is derived, [generic] is a pattern for the role with no claim about you or the district.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | The gate is shown met by your CV. Say it first and plainly. Caveat: a CV line with nothing inspected behind it, so have your license status ready to show. |
| F2 | "Fourth Grade Teacher position" (invite) | "Six years teaching third grade at a public elementary school in Joliet." (your CV); "I've never taught fourth grade." (your message) | medium | [grounded] | transferability | Your material shows six years of third grade and no fourth-grade teaching. Say the third-grade years at their own scope, then say you have not taught fourth grade. Learning fourth grade is a plan, never a past. Answer slot: say what you would do first to learn the grade, in your own words. |
| F3 | Leading a grade-level team [generic] | "I've never been a team lead." (your message); "I led our grade level's move to a new reading curriculum in 2024." (your CV) | none | [grounded] | capability | The absence is one you stated: "I haven't been a team lead." Adjacent work, at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Do not turn the move into a lead role. |
| F4 | "how you work with families" (district hiring page) | "I write a weekly email to families." (your CV) | medium | [grounded] | none | No gap. A CV line with nothing inspected behind it, so expect a probe on what the email holds. Do not add counts or replies you have not recorded. |
| F5 | "reading instruction" (district hiring page) | "I led our grade level's move to a new reading curriculum in 2024." (your CV); "I've run the after-school reading club for the last two years." (your CV) | medium | [grounded] | none | Say the curriculum move and the club, each at its own scope. Caveat: both are CV lines with nothing inspected behind them; the probe will be how much was yours. |
| F6 | "classroom routines" (district hiring page) | none given | none | [grounded] | discovery | Your material does not show routines. Answer slot: if you set routines in a classroom, say which and how you decided, in your own words; if you have not set them in a fourth-grade room, say so plainly and describe how you would build them. |

## Prohibited claims

These are not coached in any answer, hold or bridge.

| Not coached | Basis | Honest form |
|---|---|---|
| Any fourth-grade teaching experience | Negative you stated, F2 | "I've never taught fourth grade." Plain acknowledgment, no slot. |
| Having been a team lead | Negative you stated, F3 | "I haven't been a team lead." Plain acknowledgment, no slot. |
| Having chosen the reading curriculum | Inflated form of F5 | Your material says you led the move, not that you chose the curriculum. The honest form is F5's quote at its own scope. |
| Having started the reading club | Inflated form of F5 | Your material says you have run it for two years. The honest form is that quote, at its own scope. |

## Persona weights

Panel: the principal is the hiring authority; the two team members are peers on the grade team. The loop is established by the district's own hiring page (one 45-minute building panel), so there is no archetype fallback.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | Probes the fourth-grade gap and the team-lead gap | High. The principal is buying capability and the gaps are the two you stated. | Name each gap once in your words, then the adjacent work at its own scope. Hold through two follow-ups. | 4 |
| Peer Evaluator | How you would plan with the team, how you would take direction | High. The panel is two grade-level teachers, and the hiring page says panels ask about reading instruction and families. | Describe the planning you did, not the planning you would like to do. | 4 |
| Case/Strategist | Live reading and routines problems | Medium-high. Reading instruction and classroom routines are named panel topics. | Clarify first, then one concrete first step, then how you would check it. | 4 |
| Pressure | Sixty-second challenges on the fourth-grade gap | Lower. Nothing in the material suggests a stress-style interviewer, but the two stated gaps are obvious pressure points. | Pause, restate the question, hold, then concede the specific gap. | 2 |
| Data-Driven Prober | What the reading club and the email actually did | Medium. The CV lines invite counting questions. | Say what you observed and what you did not track. | 2 |
| Conversational | The opening ask for your background | Medium. Panels often open with a background ask. | A ninety-second arc in your own words. | 2 |

## Reading the interviewer

**Dolores Vantongeren, principal** (public footprint only):
- Principal of Halvering Elementary since 2022, after nine years as a reading specialist (speaker profile).
- A 2025 forum talk, "Small Groups, Big Readers," on weekly reading conferences in grades 3 to 5.

Implications: expect reading questions with grade-level specifics. Your third-grade years are the bridge; say them concretely. Reading is the shared vocabulary, so use the district's own phrase "reading instruction" when you answer. The team members' names were not given, so there is no read on them.

## Question banks

Question IDs: S = Skeptic, P = Peer Evaluator, C = Case/Strategist, X = Pressure, D = Data-Driven Prober, R = Conversational.

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You have six years in third grade and are applying for fourth. What would you need to learn first?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." (your CV) | Say the six years at their own scope, then the first thing you would learn, as a plan. Hold through two follow-ups by returning to third grade and the plan. Answer slot: if you have studied the fourth-grade year or talked with a fourth-grade teacher, say so; if not, say so plainly and name what you would ask first. | F2 is the most likely first question. JD because it scores the Fourth Grade Teacher position. |
| S2 | "What would you change about how reading is taught between third and fourth grade?" | JD | [grounded] "reading instruction" (district hiring page) | Answer from your reading work: the curriculum move and the club, each at its own scope. Do not describe third-to-fourth transitions you have not seen. Answer slot: if you have looked at reading results carried from third to fourth, say what you saw; if not, say what you would look at first. | F5 is your evidence; the panel topic is on the district page. |
| S3 | "You haven't been a team lead. Who would you go to when a grade-level plan wasn't working?" | JD | [grounded] "I've never been a team lead." (your message) | Plain acknowledgment: "I haven't been a team lead." Then the adjacent work at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if you have brought a plan back to colleagues when it was not working, say what happened; if not, say so and say how you would raise it. | F3 is the second stated gap, and the principal may take it up. |
| S4 | "Why this district, after six years in Joliet?" | JD | [grounded] "Every Child a Reader: no student leaves third grade without a reading plan." (district mission page) | Answer from the district's own belief, in your words: which part matches reading work you have done, and what you would add. Do not repeat the slogan. | Motivation probe; the district's published belief is the raising source. |

### Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through a reading plan for a student who is behind in third grade. What do you check first?" | JD | [grounded] "no student leaves third grade without a reading plan" (district mission page) | Give your steps in your own words: what you check, how you group, when you reassess. State no results. Answer slot: if you have written a reading plan for a student, say what it held and what changed; if not, describe how you would build one and say so. | The district's belief is the raising source; JD because the panel asks about reading instruction. |
| P2 | "Families are partners here, with each teacher talking to every family each term. How does your weekly email fit that?" | EXP | [grounded] "I write a weekly email to families." (your CV); [grounded] "each teacher speaks with every family each term" (district mission page) | Say what the email holds, in your own words. If you have spoken with each family in a term, say so; if not, say what the email covers and how you would reach the rest. No counts or replies you have not recorded. | F4 is the evidence; the question presupposes only the district's belief. |
| P3 | "Our fourth-grade team plans together. How would you bring a new reading plan to colleagues?" | JD | [generic]; [grounded] "I led our grade level's move to a new reading curriculum in 2024." (your CV) | Describe the grade-level move in your words, at its own scope: how colleagues were involved and which decisions were yours. Answer slot: if colleagues decided together, say so; if you set the direction, say what and how you brought others along; if the move was decided above you, say so. Never claim a lead role. | F5 is the evidence; the team setting is the panel's own composition. |
| P4 | "What did the curriculum move look like day to day?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024." (your CV) | Walk through the move only as far as you did it. Answer slot: if you ran a training, a planning session or a rollout, say which and how; if not, say what your part was. | Attribution probe on F5 from a team member's seat. |

### Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student reads two levels below grade in your first week with a new class. What do you do?" | CASE | [generic] | Clarify what you know about the student, run a quick check, pick a small group, and set a plan you would review in two weeks. Say what you would do first and what you would not do. No claims about your past. | A generic live problem on the panel's reading topic. |
| C2 | "Assessments inform teaching and never replace it. How would you use one result in tomorrow's lesson?" | CASE | [grounded] "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." (district mission page) | Name one result type, what it changes tomorrow, and what you would not conclude from it. Make no claim about tests you have given unless you say so. | The district's belief is the raising source; CASE because the answer is a decision. |
| C3 | "A parent emails that their child's reading plan changed without warning. What is your reply?" | CASE | [generic] | Acknowledge, explain the reason in plain words, offer a time to talk, and say what the family gets next. No promises about outcomes. | Families is a panel topic; a generic live problem. |
| C4 | "Walk me through your first week of classroom routines with a fourth-grade class." | CASE | [grounded] "classroom routines" (district hiring page) | Name the routines you would set first and why. Answer slot: if you have set routines in a classroom before, say which and how you decided; if you have not set them in fourth grade, say so and describe how you would build them. | F6 is a discovery gap; this is the live-problem form of that panel topic. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| X1 | "Sixty seconds: why should we hire a teacher who has never taught fourth grade?" | JD | [grounded] "I've never taught fourth grade." (your message); [grounded] "Six years teaching third grade at a public elementary school in Joliet." (your CV) | Hold: you have not taught fourth grade, and the six years of third grade and the reading work are what you bring. Concede specifically: name the first step you would take in the first term. Do not argue the premise away. Hold through two follow-ups before any concession. | The most direct form of F2. Hold-then-concede. |
| X2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024." (your CV) | Hold the scope the sentence gives: you led the move. Name the parts that were yours, and concede the parts that were shared or decided above you. Answer slot: if you chose the curriculum, say how; if the choice was made elsewhere, say so plainly. | Attribution probe on F5. Hold-then-concede. |

### Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How do you know the reading club helped?" | EXP | [grounded] "I've run the after-school reading club for the last two years." (your CV) | Say what you observed, in your own words. Answer slot: if you tracked anything in the club, say what and how you recorded it; if you tracked nothing, say so plainly and say what you would track. Never name a result you did not record. | The question presupposes an effect the CV does not state. |
| D2 | "Which families did your weekly email reach, and how did you know it was read?" | EXP | [grounded] "I write a weekly email to families." (your CV) | Say what you know about reach, in your own words. Answer slot: if you tracked replies or opens, say what; if not, say so plainly. | Defend-the-practice probe on F4. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk us through your path to teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." (your CV); [grounded] "I've run the after-school reading club for the last two years." (your CV) | A ninety-second arc in your words: third grade, the reading work, the club, and where you are now. Keep each beat to what the quotes say. | Casual opener, scored as background. Sets up the gate in F1. |
| R2 | "What part of your week do you most look forward to?" | EXP | [grounded] "I've run the after-school reading club for the last two years." (your CV) | Answer with the club in concrete terms, using only what you run. If you have a real favourite moment, say it plainly; do not invent one. | Casual register, but a rapport-weighted signal about the reading work. |

## Coverage

| Requirement or topic | Source | Covered by |
|---|---|---|
| Valid Illinois PEL with elementary endorsement | invite | F1, R1; gate shown met, so no question |
| Fourth Grade Teacher position | invite | S1, X1 |
| Reading instruction | district hiring page | S2, P1, P3, P4 |
| Classroom routines | district hiring page | C4 |
| How you work with families | district hiring page | P2, C3, D2 |
| Team lead (stated gap, not in the invite) | your message | S3, X2 |
| Working on a grade-level team | [generic] | P3, P4 |

## Reverse questions

1. "You moved from reading specialist to principal in 2022. What from that work shapes how you run this building?" Why it lands: it is the principal's public path, and it turns a probe into a peer conversation.
2. "What does a strong first term look like for a fourth-grade teacher here?" Why it lands: it shows you are planning for the job, not for the interview.
3. "How do the weekly reading conferences for grades 3 to 5 work with the fourth-grade team?" Why it lands: it ties to the principal's 2025 talk on the same subject.
4. "Which families does the building find hardest to reach, and what is working?" Why it lands: it engages the district's belief that families are partners.
5. "What could a new teacher do in their first month that would genuinely help this team?" Why it lands: it is the reciprocity question for a peer panel.

## Research

Research tier: L1 — searches 3 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | Mission page fetched: three beliefs ("Every Child a Reader", "Families Are Partners", "Teach for Tomorrow, Not for the Test"). Feeds F4, P1, P2, C2, S4. No values round was detected, so there is no values cheat sheet. |
| 2. Interview process | yes | Hiring page fetched: one 45-minute building panel (principal and two grade-level teachers), topics reading instruction, classroom routines and families. Establishes the loop. |
| 3. Strategy and recent news | unavailable | Not sent in this run. Would have moved the case-and-strategy bank; no district-strategy questions are in the pack. Offered at L2. |
| 4. Principal's name | yes | Speaker profile (search snippet, not fetched): principal since 2022, nine years as a reading specialist before, 2025 talk on reading conferences in grades 3 to 5. Feeds the interviewer read and reverse question 2. |
| 5. Representative JD | unavailable | Not sent. Would have supplied requirement text beyond the invite. Named in the upgrade menu. |

Sources:
- Provided: the invite; your résumé; your two messages.
- Search, "Orrinsford Community School District values": returned the district's mission and beliefs page.
- Search, "Halvering Elementary School Orrinsford interview process teacher": returned the district's "How we hire teachers" page.
- Search, "Dolores Vantongeren principal Halvering Elementary": returned a speaker profile on an Illinois principals' forum site.
- Fetch: the mission and beliefs page; the "How we hire teachers" page.

## Upgrade menu

- Job description text → replaces the invite's license line and the district's topic list with the posting's own requirements; any new rows become [grounded].
- The two team members' names → per-member persona weights, and a reverse question about their own path if their public footprint supports one.
- Deeper research (L2): the district's strategy brief, the principal's talks and writing, team loop reports, recent district news. Up to 6 more searches and 2 more fetches, several more minutes. Offered once; say yes to run it.
- Recruiter's email → confirms panel format and whether a written piece, demo or follow-up is expected, so any graded deliverable gets its own section.
