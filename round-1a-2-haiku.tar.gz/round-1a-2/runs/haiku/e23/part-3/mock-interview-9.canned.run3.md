Your prep pack is saved as Halvering_fourth-grade-teacher_interview_pack.md, and I've attached it above. It covers the panel, your fit against the invite, 18 rehearsal questions, and the claims I won't help you overstate: you haven't taught fourth grade or been a team lead, so the pack has you say that plainly and then give a plan for learning it.

I left your SSN and license number out of the pack. Neither is needed for interview prep, so keep the SSN out of recruiter emails and interview materials. Share it only through the district's official HR process if they ask for it.

I also saw that today, November 19, is a Thursday. If the interview is next Thursday, November 26, nothing changes; if it's today, tell me and I'll adjust the prep order.

Three things would make the pack sharper:

- **Job description (one question):** Can you paste the posting? Without it, the pack works from your invite and the district's published beliefs. With it, I can turn the other requirements into sourced rows and add JD-specific questions.
- **Drill:** I can play the Skeptic and fire the highest-priority question (B2, "Why should we trust a third-grade teacher to carry fourth grade from day one?") with follow-ups, then give feedback.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

A Word version of the pack is also available if you want one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep: Fourth Grade Teacher, Halvering Elementary School

**Company:** Orrinsford Community School District (Halvering Elementary)
**Role:** Fourth Grade Teacher
**Round:** 45-minute panel, Thursday
**Panel:** Principal Dolores Vantongeren (manager-type) and two members of the fourth-grade team (peers)
**Built from:** your invite and your résumé message. No job description was supplied, so the fit snapshot draws its requirements from the invite and the district's published beliefs, and there are no JD-tagged questions yet.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored.

- **VAL**: values alignment, tested against the district's published beliefs
- **EXP**: your own experience and what you actually did
- **JD**: a stated requirement
- **CO**: company knowledge (none in this pack; research was limited)
- **CASE**: a live problem from the role

Guidance is scaffolding, not a script. Rehearse each answer out loud in 90 to 120 seconds.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "a valid Illinois Professional Educator License with an elementary endorsement" — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Gate met on your material. Have the license details ready to confirm it. |
| F2 | "Fourth Grade Teacher position" — invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [grounded] | transferability | Your material says third grade, six years. The bridge is adjacent: the same school stage, one grade below. Say third grade in those words. Do not describe fourth-grade work you have not done. |
| F3 | "Fourth Grade Teacher position" — invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | You stated this absence, so the words are yours: "I haven't taught fourth grade." Then how you would learn it, said as a plan, never as a past. |
| F4 | "a fourth-grade team" — invite | "Led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | Your material says you led the move for your grade level. It does not say you were a team lead. Keep the move in the sentence's own terms. Answer slot: say which part of the move was yours, in your own words. |
| F5 | "Families Are Partners: each teacher speaks with every family each term" — district beliefs page | "I write a weekly email to families." — your message | medium | [grounded] | presentation | The sentence reaches the belief in other terms: a weekly written contact, not a conversation with every family. Say the sentence as written and add nothing to it. |
| F6 | "Every Child a Reader: no student leaves third grade without a reading plan" — district beliefs page | "I've run the after-school reading club for the last two years." — your message | medium | [grounded] | presentation | The sentence reaches reading in other terms. Say it as written. It does not show that the club produced reading plans. |
| F7 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it" — district beliefs page | none given | none | [inferred] | discovery | The material does not show an assessment that changed your teaching. Answer slot: if a result changed what you taught, say which and how; if none did, say so plainly and say how you would use results. |

Notes on the table:

- The district's beliefs are quoted from its published page (fetched once). The invite is quoted as sent.
- Your CV and your message are the only sources for your own sentences.

## Prohibited claims

These are claims the pack will not coach. Each entry gives its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has been a team lead | Inflated form of F4: the sentence says you led a move, not a team | F4's quote at its own scope. You also stated it: "I haven't been a team lead." No slot needed. |
| Has taught fourth grade | Negative you stated (F3) | "I haven't taught fourth grade." |
| Chose the reading curriculum | Inflated form of F4: the sentence does not say who made the choice | F4's quote at its own scope. Whether you decided is an answer slot in D1. |
| Measured reading growth | Inflated form of F6: the sentence names a club, not an outcome | F6's quote at its own scope. The material does not show how the club was measured. |

## Persona table

The panel has three kinds of member. The principal's relationship prior is hiring manager (Case and Skeptic). Each teammate's prior is peer (Peer Evaluator and Prober). Depth follows weight.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Probes the fourth-grade gap and the team-lead gap | High | Your two stated gaps are the most predictable objections, and a principal-led panel is where they get asked | Plain acknowledgment, then the adjacent quote, then a plan |
| Values / Behavioral | Principal walks the district's three beliefs | High | The beliefs are published on the district page, and the principal is the likeliest person to score against them | Map one quoted sentence to each belief; use a selection scaffold where none carries a story |
| Peer Evaluator | Teammates probe collaboration, disagreement and the seam between grades | High | Peers price what a new person adds to their own load | Propose seam principles rather than claiming to know the seam |
| Prober | Asks how the curriculum change and the club were measured | Medium | Your CV names a decision and a club with no measure attached | Say what you counted, or say you counted nothing |
| Case / Strategist | A live fourth-grade reading problem | Medium | The principal's prior includes live problems | Clarify, then structure, then act; think aloud |
| Conversational | Opening "tell us about yourself" and the license check | Medium | Panels open casually, and casual openers are still scored | A ninety-second arc, prepared in advance |

## Question banks

### Skeptic bank (B). Weight: highest

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see fourth grade in your background. How would you handle the first months of a grade you haven't taught?" | JD | [grounded] "I've never taught fourth grade" — your message | Open with the plain acknowledgment: "I haven't taught fourth grade." Then the adjacent sentence: "Six years teaching third grade at a public elementary school in Joliet." Then a plan, as a plan: what you would study first and whom on the team you would ask. | F3 is the largest gap; the question presupposes the negative you stated, so the acknowledgment is lawful |
| B2 | "Your team teaches fourth grade. Why should we trust a third-grade teacher to carry it from day one?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV; [grounded] "I've never taught fourth grade" — your message | **Highest-ROI prep in this pack.** Concede in one clause: "I haven't taught fourth grade yet." Then the six years in your own words. Then the plan. Hold through two follow-ups by returning to the six years and the plan. Never claim day one is covered. | This is the objection the material most predicts, and it is aimed where your material is thinnest. The deepest rehearsal goes here |
| B3 | "You haven't been a team lead. What would you contribute to a team that already knows fourth grade?" | EXP | [grounded] "I've never been a team lead" — your message; [grounded] "Led our grade level's move to a new reading curriculum in 2024" — your CV | Plain acknowledgment: "I haven't been a team lead." Then the move, in the sentence's scope. Answer slot: name what you would bring from your own work, in your own words. Do not describe fourth-grade planning you have not done. | F4 is the only leadership sentence in your material; this probe tests whether you claim more |
| B4 | "Why leave a classroom you've been in for six years?" | EXP | [generic] | Answer slot: your material does not state a reason. Say why, in one honest sentence, in your own words, then tie it to fourth grade as a plan. | A motivation probe is standard for a move up a grade; no quoted sentence gives the answer, so the guidance supplies none |
| B5 | "What would you do if your first fourth-grade unit showed half the class behind?" | CASE | [generic] | Structure it: check what the assessment measured, reteach a small group, talk to the team, tell families. This is a plan, not a past. | A live problem from the role, and F7's assessment gap in the form of a decision |

### Values bank (A). Weight: high

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Families are partners here. Tell me about a time a family's engagement changed how you taught a child." | VAL | [grounded] "I write a weekly email to families." — your message | Start with the weekly email in its own words. Answer slot: if a family's reply changed what you did for a child, say what; if none did, say so and describe what the weekly email is for. | Raised by the district's Families Are Partners belief; F5 carries the only family sentence in your material |
| A2 | "Every child a reader. How do you tell when a child is behind in reading, and what changes next?" | VAL | [grounded] "I've run the after-school reading club for the last two years." — your message | Use the club only where you saw a child's reading change. Answer slot: name what you looked at and what you did; if the club did not measure it, say so. | Raised by the Every Child a Reader belief; F6 names the club but no outcome, so the guidance does not supply one |
| A3 | "Assessments inform teaching and never replace it. What did a result tell you to change?" | VAL | [generic] | Selection scaffold: pick a time a result changed what you taught. If none comes to mind, say so plainly, then describe how you would use a result. | Raised by the Teach for Tomorrow belief; F7 has no sentence, so the scaffold ends in its honest branch |

### Peer bank (C). Weight: high

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our team plans units together. What happens when you and a colleague disagree about a plan?" | VAL | [generic] | Scaffold: name one disagreement, what you argued, and what you did. If no such time comes to mind, say so plainly and describe how you would raise a concern. | Peer seam probe on disagreement style |
| C2 | "Where is the seam between third and fourth grade, and what would you need from us?" | JD | [generic] | Propose a seam principle rather than claiming to know the seam. Then ask what they would want from a new teacher. | Reciprocity: peers price what a new hire adds to their load |
| C3 | "How do you handle credit when a grade-level project spans classrooms?" | VAL | [generic] | Scaffold: name a shared piece and what you did with it. If none comes to mind, say so. | Peer credit-sharing probe |
| C4 | "What could a new person do in their first month that would genuinely help our team?" | JD | [generic] | Answer with one concrete offer, stated as a plan. Do not describe past team work you did not do. | Reciprocity question, which peers weight heavily |

### Prober bank (D). Weight: medium

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You led the move to a new reading curriculum. Walk us through the decision, and which part was yours." | EXP | [grounded] "Led our grade level's move to a new reading curriculum in 2024" — your CV | Say what the move was, in the sentence's terms. Answer slot: which part of the decision was yours. If you chose the curriculum, say how. If it was chosen above you, say so, and say what you did. | F4 is the sentence this probe tests; the second branch allows the decision was not yours |
| D2 | "How did you know the new curriculum was working?" | EXP | [generic] | Answer slot: if you counted anything, say what and from whom. If you counted nothing, say so, and say what you would count. | The material shows no measure, so the guidance supplies none |

### Case bank (E). Weight: medium

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A group of your fourth graders reads two levels below grade. What do you do in the first week?" | CASE | [generic] | Clarify first: which children, what the data shows, what the school already runs. Then small groups, the team, and families. A plan, not a past. | A fourth-grade live problem; no claim about your history is needed |
| E2 | "The fourth-grade team wants a shared reading block with your class. How would you propose it?" | CASE | [generic] | Structure: what each class needs, the schedule, a short trial, and how you would tell whether it worked. | Live collaboration problem from the team side |

### Conversational bank (F). Weight: medium

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk us through your journey." | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV; [grounded] "Led our grade level's move to a new reading curriculum in 2024" — your CV; [grounded] "I've run the after-school reading club for the last two years." — your message | A ninety-second arc: where you teach now, the reading move, the club, and the fourth-grade plan stated as a plan. Say each sentence as written. | Panel openers are scored; this arc uses only sentences you gave me |
| F2 | "Do you hold a valid Illinois Professional Educator License with an elementary endorsement?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | Yes, with the endorsement, its grades and its date. Have the details ready. | The invite's gate, met on your material |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Valid Illinois PEL with elementary endorsement | F2, F1 |
| Fourth-grade teaching | B1, B2, B5, E1 |
| Fourth-grade team work | B3, C1, C2, C3, C4, E2 |
| Families Are Partners | A1 |
| Every Child a Reader | A2 |
| Teach for Tomorrow, Not for the Test | A3, D2 |

Total questions: 18 across the banks. Peer and skeptic weights are doubled up deliberately because the panel is two peers and a principal.

## Values / principles cheat sheet

The district's three beliefs are published, and the panel is principal-led, so this section is included.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Every Child a Reader | No student leaves third grade without a reading plan | F6: "I've run the after-school reading club for the last two years." Use only what you saw change for a child. Otherwise say the club did not measure it. |
| Families Are Partners | Each teacher speaks with every family each term | F5: "I write a weekly email to families." The honest branch: it is written contact, not a conversation, so say that. |
| Teach for Tomorrow, Not for the Test | Assessments inform teaching and never replace it | No quoted sentence carries a story (F7). Pick a time a result changed what you taught. If none did, say so and describe how you would use a result. |

## Reverse questions

Each one lands for a reason, and none is generic.

1. "What does the fourth-grade team already have in place for a new teacher's first weeks?" Why it lands: it shows you plan to join, not just to be interviewed.
2. "How does the team divide planning, and who leads it?" Why it lands: it tests the team-lead gap from the other side.
3. "What have families said they need most this year?" Why it lands: it turns Families Are Partners into a question you can act on.
4. "How does the district measure reading progress, and how do teachers use the results?" Why it lands: it links the reading belief to the assessment belief.
5. "What does a strong first year look like in your building?" Why it lands: it asks the principal to define success in their own words.
6. "What could a new person do in their first month that would genuinely help your team?" Why it lands: reciprocity, which peers weight heavily.

No interviewer profile was provided, so no reverse question ties to an interviewer's own career path.

## Sources

**Provided documents:** your invite (quoted as sent); your résumé message and the CV sentences quoted above.

**Searches and fetches:**

- Search: "Orrinsford Community School District Halvering Elementary values" returned one result, the district's Mission and Beliefs page.
- Search: "Halvering Elementary School Orrinsford Illinois fourth grade" returned no results.
- Fetch: the Mission and Beliefs page, which returned the three beliefs quoted in this pack.

**Research tier:** L1, searches 2 of 6, fetches 1 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | Fit snapshot rows F5, F6, F7; the values cheat sheet and the A-bank |
| 2. Orrinsford interview process | skipped | The invite already fixes the panel's size and members, so the loop structure needs no search |
| 3. Orrinsford strategy / recent news | unavailable | Budget went to the values search and fetch first. Would have moved a company-knowledge (CO) question |
| 4. Dolores Vantongeren Orrinsford | unavailable | Budget went to the district searches first. Would have moved the interviewer read and the persona weights |
| 5. Representative fourth-grade teacher JD | unavailable | No JD was supplied. Would have made the requirement rows `[inferred]` and added JD-tagged questions |

## Upgrade menu

- A job description → rows beyond the license become `[grounded]`, and JD-tagged questions are added
- The principal's and teammates' public footprint → persona weights for each panel member, and a tailored reverse question
- A line from the recruiter on what the panel scores → confirms whether the beliefs are the scoring frame, which sets how hard the values bank is weighted
- Any assessment or count you kept from the reading club or the curriculum move → sharpens A2, D1 and D2, replacing a slot with a sourced answer
- Your prep time before Thursday → a prioritized schedule, which this pack does not have yet
- Deep research (L2): the district's strategy brief, panel reports and recent district news. It needs six more searches and two more fetches, and it adds a grounding brief and CO questions
