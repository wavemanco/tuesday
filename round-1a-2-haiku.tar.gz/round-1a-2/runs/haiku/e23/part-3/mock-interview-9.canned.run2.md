Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-e23-part-3-rooms-case-9-canned-b7e9f8dc/ad34c56e-9773-499e-8fbf-8194b9a745c2/scratchpad/Halvering_Elementary_fourth-grade-teacher_interview_pack.md`. I built it from your invitation, your résumé and your note, with no job posting and no web research.

The two gaps you named are the ones the panel will press hardest. **Question A1** ("You've spent six years on third grade. What would you do in your first weeks with a fourth-grade class?") is the highest-value thing to rehearse. Lead with the plain fact, then give a plan for learning fourth-grade expectations, and don't describe fourth-grade work as if you'd done it. The pack also covers team lead (A2), the reading club, the curriculum move, a live classroom case, and a 60-second pressure question.

I left your Social Security number and license number out of the pack, since an interview doesn't need them. Don't put your SSN in anything you send to the school.

Offers, neither pushed:
- Say "drill" and I'll play the Skeptic on A1 and give feedback against that question's guidance.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.

Two questions that would sharpen the pack:
1. Do you have the full job posting? Its duties would let me check every question against the listed requirements.
2. Do you want me to run research on the district's posted expectations and Principal Vantongeren's public background? It would tune the question weights and add a tailored reverse question.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_Elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep: Fourth Grade Teacher, Halvering Elementary School

**Orrinsford Community School District** · 45-minute panel · Thursday
**Panel:** Principal Dolores Vantongeren, plus two members of the fourth-grade team (names not yet given)

*Built from your invitation, your résumé and your note. No job posting and no research yet, so this is a provided-documents-only pack (research tier L0).*

## 1. How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key:
  - **VAL**: behavioral and values alignment
  - **EXP**: your own experience, checked for accuracy
  - **JD**: the role's requirements
  - **CO**: company knowledge (none in this pack, since no research ran)
  - **CASE**: a live problem from the job
- Guidance is scaffolding, not a script. Say it in your own words, and stop wherever your real experience runs out.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap, and no question. Your material states the license is active through June 30, 2029. Have your license details ready to verify if asked. |
| F2 | "Fourth Grade Teacher position" (invitation) | "I've never taught fourth grade" (your message) | none | [grounded] | capability | Words: "I haven't taught fourth grade." Then how you would learn the fourth-grade expectations, said as a plan and never as a past. Answer slot: if you have any fourth-grade experience outside your job, such as a substitute or placement, say when. |
| F3 | Working on a grade-level team (role-family, no source quote) | "I've never been a team lead" (your message) | none | [grounded] | capability | Words: "I haven't been a team lead." Do not go on to describe leading anything. |
| F4 | Teaching reading with a school's adopted curriculum (role-family, no source quote) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | presentation | Reword only the quote: "I led our grade level's move to a new reading curriculum in 2024." It already reaches the requirement, so it needs no added practice or result. |
| F5 | Communicating with families (role-family, no source quote) | "I write a weekly email to families" (your CV) | medium | [grounded] | none | Quote covers it: "I write a weekly email to families." |
| F6 | Reading support beyond the core lesson (role-family, no source quote) | "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | transferability | Words: "For two years I've run the after-school reading club." Answer slot: what you did in it that carries into a fourth-grade day, in your own words. |
| F7 | Elementary classroom experience (role-family, no source quote) | "Six years teaching third grade at a public elementary school in Joliet" (your CV) | high | [grounded] | none | Quote covers it at its own scope: six years, third grade, a public elementary school in Joliet. |

**Gap read:** your material is strong on the license, on classroom years and on reading work. The two real gaps are the ones you named yourself: fourth grade and team lead. The panel will likely test both, so they get the deepest rehearsal.

## 3. Persona weights

Panel: the principal's relationship prior is **hiring manager** (Case/Strategist and Skeptic), and the two team members' prior is **peer** (Peer Evaluator and Data-Driven Prober). No public interviewer information was available to adjust these, so the weights below are priors.

| Persona | Weight | How it shows up here | Why this weight | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Top, 5 questions | "You've never taught fourth grade. How will you handle that?" | Two stated gaps, both aimed at the role itself | Rehearse the single most likely objection until it is plain. Name the gap in one sentence, then give a concrete plan. Don't bluff. |
| Peer Evaluator | 3 | "What would you need from us? How do you handle disagreement?" | Two team members are on the panel | Turn the conversation to what you would bring to their planning, not only what you need. |
| Data-Driven Prober | 3 | "How did you know it was working?" | Your reading work has outcomes you may not have tracked | Say what you measured, and say plainly when you did not. Don't invent a figure. |
| Case/Strategist | 3 | A student reading two grades below level, or a 30-minute reading block | Principal's hiring-manager prior and a classroom-based role | Clarify first, then structure, then name the first step. |
| Conversational | 2 | "Walk us through your journey." | Usually an opener | Have a 90-second arc ready. Casual questions are still scored. |
| Pressure | 2 | "Why you over someone who has taught fourth grade?" | Stress test on the first gap | Pause, hold your position through one follow-up, then concede the specific gap. Don't fold on the core claim. |

## 4. Question banks

**Highest-ROI prep:** **A1**. The panel will almost certainly ask about moving from third to fourth grade, and a clear, non-defensive answer does more for you than any other single answer in this pack.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've spent six years on third grade. What would you do in your first weeks with a fourth-grade class?" | JD, CASE delivery | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; [grounded] "I've never taught fourth grade" | Start with the fact, in those words: "I haven't taught fourth grade. I've taught third grade for six years." Then your plan for learning the fourth-grade expectations: what you would read, whom on this team you would ask, what you would check in week one. Say it as a plan, never as something already done. Answer slot: if you have any fourth-grade experience outside your job, say when. If not, say so plainly and give the plan. | F2 is the largest gap, and this is the question it invites. JD because it tests whether the role itself is within reach. |
| A2 | "You haven't led a team. Why should we trust you with a grade-level team's work?" | JD, Pressure | [grounded] "I've never been a team lead"; [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold: "I haven't been a team lead." Then say what the curriculum move involved in your own words, using the quote's scope. Concede specifically: name what you'd need to learn, such as running a planning meeting or deciding who does what, as a plan. Answer slot: if any part of the curriculum move meant making decisions for other people, say which. If none did, say so and stay with what you did. | F3's gap is the second place a panel will press. The hold-then-concede structure keeps you from overclaiming. |
| A3 | "Why move from third grade to fourth?" | JD | [generic] | Selection scaffold: give your real reason in your own words. If it is about the fourth-grade work itself, say what draws you to it. Don't describe fourth-grade experience you don't have. If the reason is about the school or team, name only what the invitation tells you. | A motivation probe that the role makes likely. The premise, moving grades, is the application's own. |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade"; [grounded] "I've never been a team lead" | Name one, plainly, from those two gaps. Give the one you think is most real and how you would close it. Don't list both as if they were a menu. | A calibrated answer beats bluffing. Naming one clearly is stronger than naming none. |
| A5 | "Your reading club is after school. What, if anything, have you taken from it into class?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Name one concrete practice you actually used in the club, in your own words. If you did not carry anything over, say so and say what you would try first. Answer slot: if you did carry something over, say what, and where you saw it work. | F6's transferability gap. A probe on whether the club is more than an extra. |

### B. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We plan together across the grade. What would you need from us to be useful in your first month?" | JD | [generic] | Ask for specifics: planning time, the shared unit calendar, the assessment schedule, who to go to for what. Phrase each as a need, not as a claim about how you work with teams. | Reciprocity. Team members on the panel are checking whether they would want to plan with you. |
| B2 | "Tell us about a time you disagreed with a colleague about how to teach something." | VAL | [generic] open prompt; [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Selection scaffold: pick a time with a real disagreement, the question you disagreed on, how it was settled and what you did. If the curriculum move involved real disagreement, you can use it, but only if it did. If none comes to mind, say so plainly and give the nearest thing your material does carry. | F4 is the nearest thing in your material. Disagreement is not in the quote, so the guidance doesn't claim it. |
| B3 | "Two of us teach reading blocks side by side. How would you keep your block consistent with ours?" | JD | [generic] | Say how you would find out what is shared: pacing, assessments, materials. Then ask. Don't claim you have done this before. | A peer's seam question. Asking shows you respect the shared work. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you know the reading club was working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Say what you saw and how you knew, in your own words. Answer slot: if you tracked anything, such as attendance or what students could read, name it and how often. If you did not track it, say so plainly and say what you would track. Don't name a result you cannot point to. | F6. A prober asks for the denominator. Your material has no figure, so the honest answer is the one that names the measure. |
| C2 | "How did you judge whether the 2024 curriculum move was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if you looked at results yourself, say which and how you know. If you did not judge it, say so, and say what you would look at. Don't assert an improvement. | F4. The question presumes a judgment the quote does not state, so the second branch must allow that there wasn't one. |
| C3 | "Which reading data do you use to form groups?" | JD | [generic] | Name the data you have actually used. If you can't name a specific measure, say which kind you would use first and why. | A data question the fourth-grade team will likely ask, since reading groups are a shared decision. |

### D. Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A student reads at a second-grade level in a fourth-grade room. What do you do in the first two weeks?" | CASE | [generic] | Clarify first: what the assessment shows and what the curriculum expects. Then the objective, a short diagnosis, a first step (small-group time or a reading check), and the team and family as partners. Keep it to 90–120 seconds. Don't claim a method you have not used. | A live problem from the role. The structure matters more than the answer. |
| D2 | "You have a 30-minute reading block and half the class is below grade level. Walk me through it." | CASE | [generic] | Structure: a short whole-group anchor, then small-group rotation, and what the other students do while you work with a group. Name the trade-off you'd watch for. | A classroom case. It tests whether you can plan a block, not whether you know a particular program. |
| D3 | "A family writes, upset about their child's reading placement. How do you respond?" | CASE | [grounded] "I write a weekly email to families" | Say how you'd explain the placement and offer a meeting. Use your family-communication practice only as far as the quote carries it. Answer slot: if you have had this exact conversation with a family, say how it went. If not, say so and describe how you'd handle it. | F5, the family-communication requirement. The answer must not claim a past conversation the material doesn't show. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through your journey into teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | A 90-second arc: how you started, the six years, and why you are here now. Fill the middle with true details you know; don't invent them. | An opener scored on economy and clarity. |
| E2 | "Tell us about the reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Describe what the club is and what a session looks like, one sentence each. Don't add results you cannot point to. | F6. A warm question that is still a probe. |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why should we choose you over someone who has taught fourth grade?" | JD, Pressure | [grounded] "I've never taught fourth grade"; [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Pause. Restate in your head what is being asked. Hold: "Fourth-grade experience is a real difference, and I haven't got it. What I bring is six years of third-grade teaching and a reading curriculum move I led." Don't say the other candidate is weaker. | F2 under pressure. The hold is your own quoted record, not more than it. |
| F2 | Follow-up to F1: "That sounds like a non-answer. Why does your experience outweigh that gap?" | JD, Pressure | [grounded] "I've never taught fourth grade" | Hold through this one: restate your third-grade years and the reading work. Then concede the specific cost: "I'd need to learn the fourth-grade standards quickly, and that is what I'd have to earn." Don't fold on the claim that the classroom years count. | The second follow-up is where a pack's hold is tested. Hold, then concede the cost, not the claim. |

## 5. Requirement coverage

No job posting was provided, so the table below covers the invitation's stated requirement and the role-family requirements in the fit snapshot.

| Requirement | Covered by |
|---|---|
| Valid Illinois PEL with elementary endorsement | None, and why: stated in your material as active through June 30, 2029, so no question is needed |
| Fourth Grade Teacher position (teaching fourth grade) | A1, A4, F1, F2 |
| Working on a grade-level team / team lead | A2, A4, B1, B3 |
| Reading instruction with an adopted curriculum | B2, C2, C3, D1, D2 |
| Family communication | D3 |
| Reading support beyond the core lesson | A5, C1, E2 |
| Elementary classroom experience | E1, F1 |

## 6. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the fourth-grade reading block look like from week to week?" | Shows you want the real work, not the job title. |
| R2 | "What would help a new teacher succeed on this team in the first semester?" | Ties directly to A1 and A4 and lets the panel describe the support they offer. |
| R3 | "How does the team decide on materials or curriculum changes?" | Connects to your curriculum move and shows you expect shared decisions. |
| R4 | "What do families here most often ask the team about?" | Connects to your weekly family email and signals you plan to communicate well. |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for the two peers on the panel. It turns the close into a peer conversation. |

## 7. Prohibited claims

These are the claims this pack will not coach, because the material does not support them.

| Not coached | Basis | Honest form |
|---|---|---|
| Having taught fourth grade | Stated negative: "I've never taught fourth grade" | "I haven't taught fourth grade." No slot here. |
| Having been a team lead | Stated negative: "I've never been a team lead" | "I haven't been a team lead." No slot here. |
| Leading the grade level, or leading a team, in general | Inflated form of "I led our grade level's move to a new reading curriculum in 2024" | The quote at its own scope: you led the move to the new reading curriculum. Your material says the move, not a role. |
| Designing or building the reading curriculum | Inflated form of "I led our grade level's move to a new reading curriculum in 2024" | The quote's scope: you led the move. Your material does not say who chose or wrote the curriculum. |
| Measured improvement from the reading club or curriculum | Inflated form of C1 and C2 | Your material names no results. The honest answer is the measure you tracked, or that you did not track one. |

## 8. Sources

- **Provided documents:** the panel invitation text, your résumé (pasted), and your note about the two gaps.
- **Searches and fetches:** none. Research was not consented to, so the pack runs at tier L0.

**Research tier: L0** (searches 0 of 0, fetches 0 of 0)

| Target | Status | What it would have moved |
|---|---|---|
| 1. District or school values | unavailable | Would add a values section if published values exist. |
| 2. Interview process for the role | unavailable | Would confirm the panel format and weight personas to the process. |
| 3. Current district strategy or news | unavailable | Would add a grounding section and CO questions. |
| 4. Principal Dolores Vantongeren, public footprint | unavailable | Would adjust persona weights and add a tailored reverse question. |
| 5. Representative fourth-grade teacher posting | unavailable | Would add JD-tagged questions and label them as typical, not as this school's posting. |

## 9. Upgrade menu

- The full job posting → the `[generic]` rows become `[grounded]`, and the JD questions can be checked against the listed duties.
- Research at tier L1 (consent needed) → the district's posted expectations and the principal's public profile → persona weights tuned to the principal and a tailored reverse question.
- The two team members' names → per-member persona assignment.
- Any recruiter guidance on the panel's focus areas or a demo lesson → coverage of anything the panel has said it will test.
- Any fourth-grade experience, even substitute work or a placement → upgrades the answer slots in A1 and A4.
- Any informal team-leading, such as running a planning meeting → upgrades the answer slots in A2 and A5.
