Here's your prep pack. I built it from what you've told me, without web research, so it relies on your own material and the job-ad summary. Before the pack, one thing to check first.

## Verify the hiring process before you share anything

A recruitment process that runs entirely on Telegram, including the offer and onboarding, is a pattern that job scams use. That doesn't mean this one is a scam, but verify it before you continue:

- **Check the job itself.** Confirm the Customer Support Specialist role is still listed on Lumenvale's official careers page, and note the application reference or email address it gives.
- **Check the recruiter.** Look up Marcus Hale on Lumenvale's official website or LinkedIn and confirm he works in talent or HR there. Compare the Telegram account with what the company publishes.
- **Ask through the official channel.** Send a short note to the address on the careers page asking whether the Telegram interview is genuine.
- **Share nothing sensitive yet.** Don't send your passport, ID, bank details, National Insurance or tax numbers, or photos of documents in chat. A legitimate employer won't ask you to pay for equipment, training, or a "starter kit" in chat.

Use the pack below only after you're satisfied the contact is real.

---

## Prep pack: Customer Support Specialist, Lumenvale Software (text-chat interview)

**Assumptions:** The interview is a written chat with the support team lead. You've given me a summary of the job-ad requirements, not the full text. Company values and product details are unknown, so the values section is omitted.

### 1. Fit snapshot

| JD requirement | Your evidence (your words) | Status | Gap type | Bridge language |
|---|---|---|---|---|
| 2+ years in customer support | "3 years as a customer service advisor at an energy supplier" | Met | None | "I have three years of customer support in a high-volume setting." |
| Zendesk or similar ticketing tool | "I use Freshdesk every day" | Partial | Tool gap | "I haven't used Zendesk, but I use Freshdesk daily, and the ticket workflow is the same." |
| Clear written communication | "answering around 60 calls and emails a day" | Partial | Evidence gap | No writing sample yet. Draft a short written answer as your sample (see drill). |
| Confidence handling escalations | Not stated | Gap | Evidence gap (answer slot) | Needs a real example from you. See Section 2. |
| Software-company context | "I've never worked for a software company" | Gap | Domain gap | "I haven't worked in software, but I've supported customers of a product-led business every day." |
| Training or onboarding others | "I trained four new starters on our refunds process last year" | Met | None | Use this as a strength, not just a line on your CV. |

**Confidence key:** Met = your statement clearly covers the requirement. Partial = adjacent evidence that needs a bridge. Gap = nothing in the material yet.

### 2. Prohibited claims

These are claims I won't write into any answer, because your material doesn't support them:

- Don't say you have used Zendesk, or that you know its features. You've used Freshdesk.
- Don't say you've worked in software, SaaS, or a tech company.
- Don't describe any escalation handling as your own unless you did it. Use your real example or leave the slot empty.
- Don't add metrics you haven't given me, such as satisfaction scores, resolution times, or ticket counts.
- Don't call the refunds training a "programme you designed" unless you did. "I trained four new starters on the refunds process" is what you've told me.

### 3. Likely questions and answer guidance

**Question types:** Experience (E), Skills and tools (S), Situational (Sit), Skeptic (Sk). Each question is marked by type.

**Team-lead persona (process and experience)**

1. **(E) Walk me through your customer support experience.**
   - *Guidance:* Lead with the three years, the energy supplier, and the volume of around 60 calls and emails a day. Then name Freshdesk. Keep it under 150 words.
   - *Provenance:* Your words: "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day."
   - *Rationale:* A standard opener. It sets your scale early.

2. **(S) What ticketing tools have you used, and how did you use them?**
   - *Guidance:* Say you use Freshdesk daily. Describe what you do in it (triage, updates, notes, closing tickets). Only describe steps you actually take.
   - *Provenance:* Your words: "I use Freshdesk every day."
   - *Rationale:* Tool questions usually come up in written screens. Be specific about your workflow.

3. **(Sit) Tell me about a time you had to explain a refund or policy decision to a customer who wasn't happy.**
   - *Guidance:* Give a real case. Use this structure: what the customer asked, what policy applied, what you explained, what happened next. Keep it short. Slot: if you have no such case, pick a time you explained a process to someone who disagreed with it.
   - *Provenance:* Answer slot. Your material mentions refunds but no specific case.
   - *Rationale:* The refunds link is your strongest domain connection.

4. **(Sit) How would you handle a customer complaint you can't resolve yourself?**
   - *Guidance:* Name the steps: confirm the facts, state what you can and can't do, escalate with a clear summary, and tell the customer what happens next. Don't invent an escalation history.
   - *Provenance:* Answer slot. No escalation example in your material.
   - *Rationale:* The JD asks for confidence with escalations, which is currently a gap.

**Skeptic persona (the likely objection)**

5. **(Sk) You haven't worked in a software company or used Zendesk. Why should we think you'll ramp up quickly?**
   - *Guidance:* This is the most likely objection and the one to rehearse most. Concede plainly: "That's correct. I haven't." Then bridge: three years of ticket work in Freshdesk, the same customer-facing skills, and a refunds process you trained others on. Finish with a concrete step: "In my first weeks I'd learn your product and the Zendesk workflow first." Don't overclaim how fast you'll be.
   - *Provenance:* Your words: "I use Freshdesk every day," and "I've never worked for a software company."
   - *Rationale:* This is the highest-return prep in the pack. Hold the concession and the bridge together.

6. **(Sk) Your background is in energy. How will you handle product questions about a software product?**
   - *Guidance:* Acknowledge the difference. Then show how you learn unfamiliar products: ask questions, read the docs, check with the team lead before answering. Don't claim you already know their product.
   - *Provenance:* Your words: "I've never worked for a software company."
   - *Rationale:* A common follow-up to the objection above.

**Written-communication check (chat-specific)**

7. **(S) In a short written reply, explain to a customer why a refund will take five working days.**
   - *Guidance:* Keep it to three or four sentences. Give the timeframe, the reason, and the next step. Use plain language and no jargon. Practise this as an exercise.
   - *Provenance:* Your background involves refunds, but no example in your material.
   - *Rationale:* A written sample helps address the "clear written communication" requirement.

### 4. Reverse questions for you to ask

- "What does a typical day look like for someone in this role, and how much of it is ticket work versus other tasks?" (Shows you're thinking about the job, not just the offer.)
- "What's the support tool stack, and how much training do new starters get on it?" (Tests the Zendesk gap directly.)
- "How do you handle escalations, and who takes them?" (Tells you how much judgement the role carries.)

### 5. What I still need from you

**Upgrade menu** (each one improves the pack):
- **Full job-ad text:** lets me check every requirement against the wording, not my summary.
- **Team-lead name and the chat format or length**, if the company has shared them: helps tune the question balance.
- **A real escalation example**, if you have one: fills the gap in Section 3, question 4.
- **A `tuesday-dossier.md` from job-underwriter**, if you have one: adds verified evidence and stricter claim limits.

**Offers:**
- **Drill:** I can play the team lead and run any question above with follow-ups, then give feedback against that question's guidance. Say the word and I'll start.
- **Dossier:** I can write a `tuesday-dossier.md` file from this pack for future rounds. Not started unless you ask.

**Questions:**
1. Do you have the full job-ad text, or should I work from the summary?
2. Has the company said how long the chat will last, or whether there's a written exercise?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.