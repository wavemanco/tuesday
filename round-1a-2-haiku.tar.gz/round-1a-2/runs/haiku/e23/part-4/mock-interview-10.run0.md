Before the prep, one thing to check. A company that runs the whole process in Telegram, including the offer and onboarding, matches a common recruitment-scam pattern. I couldn't verify Lumenvale or Marcus Hale from here, since I ran no searches. Before you share ID, bank details or anything personal, check the role on Lumenvale's own careers page and confirm Marcus Hale is listed there. Ask for the interview by email from a company address or on a video call. Never pay for equipment, training or a "verification" fee.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-e23-part-4-rooms-case-10-denied-f2727584/4f5645fd-4844-4236-a1f2-0909f7938eac/scratchpad/lumenvale_customer-support-specialist_interview_pack.md`. I built it from your message alone, so it uses the ad's requirements as you summarised them, not the full ad text.

# Lumenvale Software: Customer Support Specialist (remote), interview prep for Imani

Round: text interview in Telegram chat with the support team lead (name not given). Contact: Marcus Hale, talent team.

## 1. How to use this pack and type key

Personas are how a question is asked. Types are what is being scored. Guidance is scaffolding, not a script.

- **EXP**: work-experience deep-dive. Tests whether what you did is what you say you did.
- **JD**: role-driven. Tests the ad's requirements, including the gaps.
- **CASE**: live problem. Tests structure and judgement on a problem from the job.
- VAL and CO are not used: no company values or research were in hand.

Chat-specific: answer one question per message, keep replies short, and write every reply in your own words. Don't paste a prepared text you couldn't defend aloud.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (job ad, as you summarised it) | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" (your message) | medium | [grounded] | presentation | Your material says customer service advisor, not customer support by title. Say the role and years in those words: "For three years I was a customer service advisor at an energy supplier." |
| F2 | "experience with Zendesk or a similar ticketing tool" (job ad, as you summarised it) | "I use Freshdesk every day" (your message) | high | [grounded] | none | The ad says "or a similar ticketing tool", so Freshdesk reaches it. Say "I use Freshdesk every day." Don't say you know Zendesk; you haven't said so. |
| F3 | "clear written communication" (job ad, as you summarised it) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Your material shows email volume, not writing quality, and the bridge isn't stretched to fill that. Answer slot: if you've written something you were proud of, say what it was for and how you made it clear. If none comes to mind, say so and describe how you check a reply before sending. |
| F4 | "confidence handling escalations" (job ad, as you summarised it) | "I trained four new starters on our refunds process last year" (your message) | low | [inferred] | discovery | Training four starters on refunds isn't handling escalations. Answer slot: if you've handled an escalation, say what happened and what you did first. If not, say so plainly, then name the hardest refund or complaint you did handle. |
| F5 | Not in the ad as you summarised it: software-company background (your own raised gap) | "I've never worked for a software company." (your message) | none | [grounded] | capability | Your stated negative: "I haven't worked for a software company." Nothing added to make it smaller. |

## 3. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | "I use Freshdesk every day." Your material says Freshdesk, not Zendesk. |
| Owned the refunds process | Inflated form of the refunds quote in F4 and question E2 | "I trained four new starters on our refunds process last year." The material says you trained others on it, not that you set it. |
| Worked in a software company | Contradicted by your stated negative (F5) | "I've never worked for a software company." |

## 4. Persona weights

No interviewer profile was given, so there is no interviewer read. Weights start from a hiring-manager-style prior (Case plus Skeptic), adjusted by your stated gap.

| Persona | Weight | How it shows up in chat | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | 5 (top) | Pointed questions on the software gap, Zendesk and escalations | Your stated gap is the most likely objection | Rehearse the biggest objection until it's plain. Bridge only from what you stated. |
| Case/Strategist | 5 | Short live scenarios, scored on structure and clarity | Customer work suits a scenario test | Clarify, give the first step, then the message to the customer |
| Conversational | 4 | Friendly openers; casual questions still count | Chat rounds often open with a scored easy question | Have a 90-second arc ready |
| Data-Driven Prober | 2 | Follow-ups on your volume figure | The one number in your material | Say how you know it, or that it's an estimate |
| Pressure | 2 | Short, blunt follow-ups | Text makes pressure brief | Hold a position through two follow-ups |

## 5. Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. Why should we take that risk on you over someone who has?" | JD | [grounded] "I've never worked for a software company." | Plain acknowledgment: "I haven't worked for a software company." Then what your support work did cover: "For three years I was a customer service advisor at an energy supplier." Then a plan, said as a plan: how you'd learn the product and their tickets. Hold through two follow-ups. Concede the real cost plainly: a new sector takes time. **Highest-ROI prep in this pack:** this is the objection most likely to come up in some form. | F5 is the stated gap and the most predictable objection. |
| B2 | "The ad names Zendesk. You've used Freshdesk. How quickly could you work in a tool you haven't used?" | JD | [grounded] "I use Freshdesk every day" | Say what carries over: "I use Freshdesk every day," and what you do in it. Answer slot: if you've used Zendesk, say where and how much. If not, say so plainly and say what you'd do in your first week. Don't describe a ramp period as a past. | F2 has no Zendesk quote. The ad's "or a similar" is the bridge. |
| B3 | "When did you last hand a customer problem to someone more senior, and what did you do before you did?" | JD | [inferred] "I trained four new starters on our refunds process last year" | Open prompt: pick the nearest real instance and tell it in order. If none comes to mind, say so, and give the nearest case you handled without claiming you escalated it. | F4 is thin. The quoted line is the nearest sentence; the link is this pack's inference. |
| B4 | "Sixty contacts a day is a lot of writing. How did you decide how much care each reply got?" | JD | [grounded] "answering around 60 calls and emails a day" | Answer slot: if you had a way of deciding, say what it was. If there was no such way, or it wasn't yours, say so plainly and describe how you handled the emails. | F3 is the clear-writing gap. The question presumes a decision the quote doesn't carry. |
| B5 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one honest weakness, then the ramp plan. Make no claim about your past. | Skeptic stem; asks about the role only. |

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A customer writes: 'My refund was approved last week and I still don't have the money.' What's your first step?" | CASE | [generic] | Clarify: which order, and what the approved status says. Check the record for where it stopped. Tell the customer what you found and when they'll hear next. Don't promise a date you can't see. | Live problem; no claim about your past. |
| C2 | "Write me the reply you'd send that customer, in two or three sentences." | CASE | [generic] | Typed under time pressure. Lead with what you'll do, then how long, then how they hear back. | Tests clear written communication in the chat itself. |
| C3 | "A customer says they'll cancel and post a bad review unless you approve a refund you can't approve. What's your next message?" | CASE | [generic] | Acknowledge the frustration without agreeing to the demand. State the escalation route and what it checks. Don't promise an outcome you don't control. | The hard form of the ad's escalation line. |
| C4 | "A customer says a colleague told them something different yesterday. What do you do?" | CASE | [generic] | Check the record first. Don't blame the colleague or guess. Escalate the contradiction if it changes the outcome. | Judgement when a customer's word and the record disagree. |
| C5 | "You're starting on a ticketing tool and a product you haven't used. What do you need to know in your first week?" | CASE | [generic] | Three things in order: the views for your queue, the product's common issues, and who handles escalations. | A ramp question, answered as a plan. |

### Conversational (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through how you got into customer service." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | A 90-second arc, shorter in chat: the supplier and role, the volume in the quote's words, daily Freshdesk use, refunds training, why this role. | Scored casually; the quote is the arc's only past. |
| D2 | "What do you actually do in Freshdesk day to day?" | JD | [grounded] "I use Freshdesk every day" | Name what you do, and stop where your use stops. Answer slot: if you've used a feature you'd call advanced, name it. | Casual version of the tool requirement. |
| D3 | "What drew you to apply to a software company when you haven't worked in one?" | JD | [grounded] "I've never worked for a software company." | Give the reason in your own terms, without running down your current sector. Link it to the customer side of the role. Don't claim you know their product. | Your negative is the premise, not the reason. |
| D4 | "How do you handle a queue when there are a lot of messages waiting?" | EXP | [grounded] "answering around 60 calls and emails a day" | Story-map the volume in its own words. Answer slot: if you had an order for taking messages, say what it was. If not, say so. | A prioritisation method is the practice asked about, so it's a slot. |

### Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "How did you arrive at around 60 a day?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: if you counted, say how and over what period. If it's an estimate, say so and what it's based on. Keep "around". | Defend-the-number slot. |
| A2 | "What did you do to check that your four new starters had the refunds process right?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Answer slot: if you checked their work, say how. If not, say so and say what you'd check next time. | Presumes a check the quote doesn't carry. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds, in text: why should we pick you over someone with software support experience?" | JD | [grounded] "I've never worked for a software company."; "answering around 60 calls and emails a day"; "I trained four new starters on our refunds process last year" | Hold through two follow-ups. The case rests on volume and refunds training, in the quotes' words, plus a plan to learn the product. Concede the specific cost. Never fold on the volume. | The hold is what the quotes carry, not more. |
| E2 | "Be honest: did you design the refunds process, or follow it?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Answer slot: if you had a say in any part, say which and why. If you followed it, say so plainly, then say you trained others on it. | Presumes a design role the quote doesn't carry. |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| 2+ years in customer support | D1, A1 |
| Zendesk or a similar ticketing tool | B2, D2 |
| Clear written communication | B4, C2 |
| Confidence handling escalations | B3, C3 |
| Software-company background (your raised gap) | B1, D3, E1 |

## 6. Reverse questions

1. "What does a typical week of contacts look like, and which channel takes the most time?" Why it lands: it shows you're thinking about load.
2. "How do new hires learn the ticketing tool, and what do the first two weeks look like?" Why it lands: it turns your software gap into a ramp question.
3. "When a ticket escalates, who decides, and how long does the answer usually take?" Why it lands: it asks about the ad's escalation line.
4. "What does a good support outcome look like on your team, in a week you'd call a win?" Why it lands: it asks what they score you on.
5. "What would you want someone new to have learned by the end of the first month?" Why it lands: it sounds like someone planning to do the job.
6. "What's the next step after this chat, and is there a written task?" Why it lands: it sets the round's shape without guessing.

## 7. Sources

Provided documents: the Telegram message, the ad requirements as you summarised them, and your background. No searches or fetches were run in this pass.

Research tier: L0, no searches or fetches in this pass.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Values cheat sheet, not included: not run in this pass |
| 2. Lumenvale interview process, customer support | unavailable | Loop structure and persona weights: not run in this pass |
| 3. Lumenvale strategy / recent news | skipped | Company-knowledge questions only; the chat's content is set by the ad |
| 4. Team lead name | n/a | No name given; Marcus Hale is the recruiter |
| 5. Representative customer-support JD | skipped | Your requirements fix the fit snapshot |

## 8. Upgrade menu

- Full job-ad text → the requirement lines become quoted, and F3 and F4 can be re-graded
- The team lead's name → a tailored reverse question and persona weights
- Any written task or time limit → a build section for it
- Research, once you've checked the company → a values cheat sheet and the team's interview process
- An escalation you've handled, in your words → upgrades B3 from a scaffold to a story
- Any Zendesk use, even a trial → upgrades the answer slot in B2 to a story

---

Two offers, neither pressed:
- **Drill:** I can play the Skeptic on B1, the highest-ROI question, in a live chat-style rehearsal, then give feedback against its guidance.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

Questions:
1. Did Marcus or the team say how long the chat runs, or whether there's a written task?
2. Have you ever used Zendesk, even in a trial?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer-support-specialist_interview_pack.md -----
# Lumenvale Software: Customer Support Specialist (remote), interview prep for Imani

Role: Customer Support Specialist, remote. Company: Lumenvale Software. Round: text interview in Telegram chat with the support team lead (name not given). Contact: Marcus Hale, talent team.
First pack. No earlier version to change.

## 1. How to use this pack and type key

Personas are how a question is asked. Types are what is being scored. Guidance is scaffolding, not a script.

- **EXP**: work-experience deep-dive. Tests whether what you did is what you say you did.
- **JD**: role-driven. Tests the ad's requirements, including the gaps.
- **CASE**: live problem. Tests structure and judgement on a problem from the job.
- **VAL** and **CO** are not used in this pack: no company values or research were in hand.

Chat-specific: the interview is typed, so answer one question per message, keep replies short, and write every reply in your own words. Do not paste a prepared text you could not defend aloud.

## 2. Fit snapshot

Requirements are the ad as you summarised it in your message, not the full ad text. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (job ad, as you summarised it) | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" (your message) | medium | [grounded] | presentation | Your material says customer service advisor, not customer support by title. Say the role and the years in those words: "For three years I was a customer service advisor at an energy supplier." |
| F2 | "experience with Zendesk or a similar ticketing tool" (job ad, as you summarised it) | "I use Freshdesk every day" (your message) | high | [grounded] | none | The ad says "or a similar ticketing tool", so Freshdesk reaches it. Say "I use Freshdesk every day." Do not say you know Zendesk; you have not said so. |
| F3 | "clear written communication" (job ad, as you summarised it) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Your material shows email volume, not the quality of your writing, and the bridge is not stretched to fill that. Answer slot: if you have written something you were proud of, say what it was for and how you made it clear. If none comes to mind, say so plainly and describe how you check a reply before you send it. |
| F4 | "confidence handling escalations" (job ad, as you summarised it) | "I trained four new starters on our refunds process last year" (your message) | low | [inferred] | discovery | Training four starters on refunds is not handling escalations, and the bridge must not treat it as one. Answer slot: if you have handled an escalation, say what happened and what you did first. If you have not handled one as an escalation, say so plainly, then name the hardest refund or complaint you did handle. |
| F5 | Not in the ad as you summarised it: software-company background (your own raised gap) | "I've never worked for a software company." (your message) | none | [grounded] | capability | Your stated negative, so the pack can say it back: "I haven't worked for a software company." Nothing is added to make it smaller. |

Gap type is set by the evidence cell. F5 is a capability gap only because you stated the absence yourself.

## 3. Prohibited claims

Built locally from the fit snapshot: the wording a candidate reaches for under pressure. Nothing here is coached.

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | "I use Freshdesk every day." Limit in the pack's analysis: your material says Freshdesk, not Zendesk. |
| Owned the refunds process | Inflated form of the refunds-training quote in F4 and the question E2 | "I trained four new starters on our refunds process last year." Limit in the pack's analysis: the material says you trained others on it, not that you set it. |
| Worked in a software company | Contradicted by your stated negative (F5) | "I've never worked for a software company." |

## 4. Persona weights

No interviewer profile was given, so there is no interviewer read. Weights start from the relationship prior for a hiring-manager-style round (Case/Strategist plus Skeptic) and are adjusted by the one fact that matters most here: a stated gap (F5) that a team lead is likely to test.

| Persona | Weight | How it shows up in a chat | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | 5 (top) | Pointed questions about the software gap, Zendesk and escalations | Your own stated gap is the most likely objection, and the ad's requirements are a scoring sheet | Rehearse the single biggest objection until it is plain. Bridge only from what you stated. Say the limit plainly. |
| Case/Strategist | 5 | Short live scenarios typed into the chat, scored on structure and clarity | The role is customer work, so a scenario test is the natural format | Clarify first, then give the first step, then the message to the customer |
| Conversational | 4 | Friendly openers; casual questions still count | A chat round often opens with an easy question that is scored | Have a 90-second arc ready and treat casual questions about the tool as scored |
| Data-Driven Prober | 2 | Follow-ups on your volume figure | Your figure of around 60 a day is the one number in the material | Say how you know it, or say it is an estimate |
| Pressure | 2 | Short, blunt follow-ups in text | Text makes pressure brief rather than loud | Hold a position through two follow-ups before you concede anything |

Depth follows weight. Every persona is touched at least twice.

## 5. Question banks

Type key as in section 1. Provenance carries every sentence the guidance rests on.

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. Why should we take that risk on you over someone who has?" | JD | [grounded] "I've never worked for a software company." | Plain acknowledgment: "I haven't worked for a software company." Then what your support work did cover, in the quote's words: "For three years I was a customer service advisor at an energy supplier." Then a plan, said as a plan: how you would learn the product and their tickets in your first weeks. Hold through two follow-ups. Concede the real cost plainly: a new sector takes time. Highest-ROI prep in this pack: this is the objection most likely to come up in some form. | F5 is the stated gap and the most predictable objection. JD because the ad's requirements are the scoring sheet. |
| B2 | "The ad names Zendesk. You've used Freshdesk. How quickly could you work in a tool you haven't used?" | JD | [grounded] "I use Freshdesk every day" | Say what carries over: "I use Freshdesk every day," and what you do in it day to day, in your words. Then the Zendesk branch, which is an answer slot: if you have used Zendesk, say where and how much. If you have not, say so plainly and say what you would do in your first week. Do not describe a ramp period as a past. | F2 has no Zendesk quote. The ad's "or a similar" is the bridge, so Freshdesk is named and Zendesk is not claimed. |
| B3 | "When did you last hand a customer problem to someone more senior, and what did you do before you did?" | JD | [inferred] "I trained four new starters on our refunds process last year" | Open prompt: pick the nearest real instance. If an escalation comes to mind, tell it in order: what the customer needed, what you could decide, what you passed up, and what you told the customer while they waited. If none comes to mind in those words, say so, and give the nearest case you handled, the refund cases your training covered, without claiming you escalated them. | F4 is thin. The ad raises escalations; the quoted line is the nearest sentence, and the link to it is this pack's inference, so it is labelled inferred. |
| B4 | "Sixty contacts a day is a lot of writing. How did you decide how much care each reply got?" | JD | [grounded] "answering around 60 calls and emails a day" | Answer slot: if you had a way of deciding how much care a reply needed, say what it was, in your own words. If there was no such way, or it was not yours, say so plainly and describe how you handled the emails. Keep the volume in the quote's words: around 60 calls and emails a day. | F3 is the clear-writing gap. The question presumes a decision the quote does not carry, so its second branch allows that there was none. |
| B5 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Calibrated candour. Name one honest weakness, then the ramp plan. Make no claim about your past, and do not say you have no weaknesses. | Skeptic stem. It asks about the role, so it carries no claim about your history. |

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A customer writes: 'My refund was approved last week and I still don't have the money.' What's your first step?" | CASE | [generic] | Clarify first: which order and which refund, and what the approved status says. Check the record for where it stopped. Then tell the customer what you found and when they will hear next. Do not promise a date you cannot see. | Live problem from refund work. It makes no claim about your past; F4 is the nearest row and is not relied on. |
| C2 | "Write me the reply you'd send that customer, in two or three sentences." | CASE | [generic] | Typed under time pressure. Lead with what you have done or will do, then how long it will take, then how the customer hears back. Read it once for anything you would have to apologise for later. | Tests clear written communication in the interview's own medium, which is the chat. |
| C3 | "A customer says they'll cancel and post a bad review unless you approve a refund you can't approve. What's your next message?" | CASE | [generic] | Acknowledge the frustration without agreeing to the demand. State what you can do: the escalation route and what it will check. Do not promise an outcome you do not control. | The hard form of the escalation line in the ad. It asks for a decision, not a record. |
| C4 | "A customer says a colleague told them something different yesterday. What do you do?" | CASE | [generic] | Check the record first. Do not blame the colleague or guess. Tell the customer what you can confirm, and escalate the contradiction if it changes the outcome. | Tests judgement when a customer's word and the record disagree. |
| C5 | "You're starting on a ticketing tool and a product you haven't used. What do you need to know in your first week?" | CASE | [generic] | List three things, in order: the views and filters for your queue, the product's common issues, and who to ask about escalations. Keep to what you would need, not what you know. | A ramp question, answered as a plan. It makes no claim about past tools. |

### Conversational (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through how you got into customer service." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | A 90-second arc, shorter in chat: the energy supplier and the role, the volume in the quote's words, your daily Freshdesk use, the refunds training, and why you want this role. Keep each clause to what you did. | Biography in a casual register. It is scored, and the quote is the arc's only past. Covers the 2+ years line in F1. |
| D2 | "What do you actually do in Freshdesk day to day?" | JD | [grounded] "I use Freshdesk every day" | Name what you do in it, in your own words, and stop where your use stops. Answer slot: if you have used a feature you would call advanced, name it. If not, say what you use it for. | A casual question about the tool the ad asks for. Scored against the Zendesk-or-similar line. |
| D3 | "What drew you to apply to a software company when you haven't worked in one?" | JD | [grounded] "I've never worked for a software company." | Give the reason in your own terms, without running down your current sector. Then link it to the work: the customer side of the role. Do not claim you know their product. | A casual version of the software gap. Your negative is the premise, not the reason. |
| D4 | "How do you handle a queue when there are a lot of messages waiting?" | EXP | [grounded] "answering around 60 calls and emails a day" | Story-map on the volume: the daily number in its own words. Answer slot: if you had an order for taking messages, say what it was. If you took them as they came, say so. | Volume is your strongest quote. A prioritisation method is the practice the question asks about, so it is a slot. |

### Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "How did you arrive at around 60 a day?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: if you counted, say how and over what period. If it was an estimate, say so and say what it is based on. Keep the word "around". | A figure is a magnet for follow-ups. This is a defend-the-number slot. |
| A2 | "What did you do to check that your four new starters had the refunds process right?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Answer slot: if you checked their work, say how, in your own words. If you did not check it, say so plainly and say what you would check next time. | The question presumes a check the quote does not carry. Its second branch allows that there was none. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds, in text: why should we pick you over someone with software support experience?" | JD | [grounded] "I've never worked for a software company."; "answering around 60 calls and emails a day"; "I trained four new starters on our refunds process last year" | Hold through two follow-ups. The case rests on the volume and the refunds training, in the quotes' words, plus a plan to learn the product. Concede the specific cost: you are new to the sector, and that takes time. Never fold on the volume. | In text, pressure is short and blunt. The hold is what the quotes carry, not more. |
| E2 | "Be honest: did you design the refunds process, or follow it?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Answer slot: if you had a say in any part of the process, say which part and why. If you followed it, say so plainly, then say you trained others on it. | The question presumes a design role the quote does not carry. The honest branch is "I followed it." |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| 2+ years in customer support | D1, A1 |
| Zendesk or a similar ticketing tool | B2, D2 |
| Clear written communication | B4, C2 |
| Confidence handling escalations | B3, C3 |
| Software-company background (your raised gap, not in the ad summary) | B1, D3, E1 |

Every stated requirement has at least one question.

## 6. Reverse questions

Ask at least one, and one near the end. Each has why it lands.

1. "What does a typical week of contacts look like, and which channel takes the most time?" Why it lands: it shows you are thinking about load, and the answer tells you the real volume.
2. "How do new hires learn the ticketing tool, and what does the first two weeks look like?" Why it lands: it turns your software gap into a ramp question they can answer.
3. "When a ticket escalates, who decides, and how long does the answer usually take?" Why it lands: it asks about the ad's escalation line directly.
4. "What does a good support outcome look like on your team, in a week you'd call a win?" Why it lands: it asks what they score you on.
5. "What would you want someone new to have learned by the end of the first month?" Why it lands: it sounds like someone planning to do the job.
6. "What's the next step after this chat, and is there a written task?" Why it lands: it sets the shape of the round without you guessing.

## 7. Sources

Provided documents: the Telegram message from Marcus Hale; the job-ad requirements as you summarised them; your background as you described it. No searches or fetches were run in this pass.

Research tier: L0, no searches or fetches in this pass

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Values cheat sheet (not included): not run in this pass, and no values page is in hand |
| 2. Lumenvale interview process, customer support | unavailable | Loop structure and persona weights: not run in this pass |
| 3. Lumenvale strategy / recent news | skipped | Would have moved only company-knowledge questions, and the chat round's content is set by the ad |
| 4. Team lead name | n/a | No name given. Marcus Hale is the recruiter, not the interviewer |
| 5. Representative customer-support JD | skipped | The requirements you supplied fix the fit snapshot |

## 8. Upgrade menu

- Full job-ad text → the requirement lines become quoted, and F3 and F4 can be re-graded
- The team lead's name → a tailored reverse question and persona weights from their public footprint
- Any written task or time limit from the team → a build section for it
- Research at the default tier, after you have checked the company (see the caution in the message) → a values cheat sheet and the team's interview process
- An escalation you have handled, described in your words → upgrades B3 from a scaffold to a story map
- Any Zendesk use, even a trial → upgrades the Zendesk answer slot in B2 to a story
