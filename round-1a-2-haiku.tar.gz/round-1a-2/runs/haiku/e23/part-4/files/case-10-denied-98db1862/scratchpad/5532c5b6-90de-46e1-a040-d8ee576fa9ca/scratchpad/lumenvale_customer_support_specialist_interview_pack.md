# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software, for Imani

Built at L0: provided material only. Web search was not permitted in this session, so nothing about the company, its values, its tools or its interview loop has been checked. Assumptions: round = text-chat interview with the support team lead (hiring-manager relationship); the job requirements are your summary, not the full ad.

## Before you reply to the recruiter: verify first

This process has several recognised signs of a recruitment scam:

- The whole process is on Telegram: a text-chat interview, then the offer and onboarding in the same chat. A real employer normally moves to a company email address, a video call and a formal offer letter.
- The first contact was an unsolicited message, with generic praise ("impressed by your CV").

Before you share anything or reply with a time:

1. Find the role and the recruiter on Lumenvale's official website or careers page, not through the Telegram message. Check that Marcus Hale and this role are listed.
2. Check the application confirmation email. Does it mention Telegram, and which address did it come from?
3. Do not send ID, bank or tax details, or photos of documents, until a formal offer comes through a company email address that you have verified.
4. Never pay for equipment, training, "background checks" or software. A real employer will not ask you to.

If any of these checks fail, stop. The prep below is still valid for any real interview, but do not reply to the chat.

## Fit snapshot

Requirements are quoted from your summary, not from the ad, so they are not verbatim. Candidate evidence is quoted from what you told me.

| # | Requirement (source: your summary) | Evidence, verbatim (source: your words) | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | 2+ years in customer support | "3 years as customer service advisor at an energy supplier" | high | [grounded] | none | Meets the requirement. Describe the role's volume, not a bigger title. |
| F2 | Zendesk or a similar ticketing tool | "I use Freshdesk every day" | medium | [grounded] | presentation | Freshdesk is a similar ticketing tool, used daily. Say that you have not shown Zendesk experience, and that the daily ticket workflow is the transferable part. |
| F3 | Clear written communication | No written sample in the material. | none | [generic] | discovery | Answer slot: if you have anonymised examples of written replies, bring them. Otherwise say what you do to keep written replies clear. |
| F4 | Confidence handling escalations | "answering around 60 calls and emails a day"; "I trained four new starters on our refunds process last year" | low | [inferred] | discovery | The material shows high volume and refund training, but not escalations. Answer slot: if you have escalated cases, say what, how and why. If not, say so and give the nearest case you have. |
| F5 | (Not in the ad, but relevant) Software company experience | "I've never worked for a software company." | high | [grounded] | transferability | Say it plainly. Bridge: you know how a support queue works. Do not claim product knowledge. |

Gate rows: the material does not settle whether you are eligible to work for Lumenvale from your location. See question Q2 below.

## Prohibited claims

These claims must not be coached or implied in any answer, even under pressure.

- **P1 (inflated form, Zendesk):** "I have Zendesk experience." Your sentence is "I use Freshdesk every day." Honest form: name Freshdesk and say you have not shown Zendesk.
- **P2 (inflated form, escalations):** "I handle escalations." Your sentences describe volume and refund training, not escalations. Honest form: answer the open prompt in S4.
- **P3 (sourced entry, software):** "I know how software products work from the inside." Your sentence says you have never worked for a software company. Honest form: plain acknowledgment and the support-queue bridge.
- **P4 (inflated form, process ownership):** "I designed the refunds process." Your sentence is "I trained four new starters on our refunds process." Honest form: you trained people on it. Do not claim you wrote it.

## Persona weights

Relationship prior: hiring manager (team lead) → Case/Strategist + Skeptic.

| Persona | Weight | Why |
|---|---|---|
| Skeptic | 5 (top) | The team lead will test the software gap and the Zendesk gap first |
| Case/Strategist | 4 | Live support scenarios are the usual way to test a support role |
| Conversational | 3 | Text-chat openers look casual but are scored |
| Pressure | 2 | Only if the lead pushes back in the chat |
| Data-Driven Prober | 2 | Your 60-a-day figure will get asked about |
| Values/Behavioral | 0 | No company values were available to check (research not run). The values cheat sheet is omitted for that reason. |

## Question banks

Every question carries a type: VAL, EXP, JD, CO or CASE. The guidance is spoken aloud in 90 to 120 seconds.

### Skeptic (weight 5)

**S1 · JD · "You've never worked for a software company. What would you need to learn first?"**
- Guidance: say plainly that you have not. Name what you have seen from the customer side (the questions customers ask about tools and products). Answer slot: if you have used this product or a similar one as a customer, say so.
- Provenance: [grounded] "I've never worked for a software company."
- Rationale: F5 is the most visible gap. It is likely to come up in the first question.

**S2 · JD · "You've only used Freshdesk. This team runs Zendesk. Why should we expect you to ramp up quickly?"** (deepest rehearsal: the most likely objection)
- Guidance: Hold: the daily ticket workflow transfers. Concede: you have not used Zendesk. Name the specific features you would check in week one. Answer slot: if you have used other tool features, name them. If you have not used Zendesk, say so. Do not claim any Zendesk experience.
- Provenance: [grounded] "I use Freshdesk every day"
- Rationale: F2 is the requirement the team lead is most likely to test. This is the highest-value prep in the pack.

**S3 · EXP · "Your work was energy calls. How does that translate to software customers?"**
- Guidance: say what carries over: volume, written replies and the refund process. Say what does not: product knowledge.
- Provenance: [grounded] "answering around 60 calls and emails a day"
- Rationale: F1 and F5 together.

**S4 · EXP · "Tell me about a time you had to escalate a customer issue."** (open prompt)
- Guidance: selection scaffold: pick a case that you took to a manager or another team and that needed a decision you did not own. If no such case comes to mind, say so plainly, then give the nearest case you have (a refund you could not approve, for example), and how you handled it.
- Provenance: [generic] scaffold. No quoted sentence carries escalations.
- Rationale: F4 is low confidence, and this is the question most likely to expose P2.

**S5 · VAL · "Why leave the energy sector for a software company?"**
- Guidance: give your real reason in one sentence, then the bridge: what you want from the next role. Do not invent a reason.
- Provenance: [generic]
- Rationale: The motivation probe is standard for a sector switch.

### Case/Strategist (weight 4)

**C1 · CASE · "A customer says the export button fails every time. Walk me through your first 15 minutes."**
- Guidance: clarify (which browser, which account, when it started), reproduce, check the known-issues list, give a workaround if one exists, then escalate with the steps and evidence. Ask the lead how their escalation path works.
- Provenance: [generic]
- Rationale: Tests structure on a real support problem. You do not know this product, so do not pretend to.

**C2 · CASE · "Five customers report the same error after yesterday's release. What do you do?"**
- Guidance: spot the pattern, group the tickets, tell the team lead and the owning team with the evidence, and keep customers updated with an honest holding reply.
- Provenance: [generic]
- Rationale: Tests the escalation mindset (F4) in a live form.

**C3 · JD · "Reply to a customer whose refund is a week late." (written test)**
- Guidance: short, clear, accurate reply: apologise once, give the status, give the next date, and do not promise anything you cannot check. Use the refund process you trained on as the basis, but do not claim the company's refund policy.
- Provenance: [grounded] "I trained four new starters on our refunds process last year"
- Rationale: Tests F3 (written communication) directly.

**C4 · CO · "What do you know about Lumenvale?"**
- Guidance: answer only from what you checked on the official website, using the verification steps above. If you have not checked, say so and ask a question.
- Provenance: [generic]
- Rationale: Checks whether you have done your homework. Research was not run for this pack.

### Conversational (weight 3)

**V1 · EXP · "So, walk me through your journey into support."**
- Guidance: 90-second arc: the energy role (volume), the daily Freshdesk work, the refund training, and why you want to move to software support.
- Provenance: [grounded] "3 years as customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year"
- Rationale: The casual opener is scored. It will set the tone for the chat.

**V2 · JD · "What's your experience with ticketing tools?"**
- Guidance: name Freshdesk, say how you use it every day, and say you have not used Zendesk.
- Provenance: [grounded] "I use Freshdesk every day"
- Rationale: F2, asked casually.

**V3 · EXP · "How did you train the four new starters?"** (premised question)
- Guidance: you trained four starters on the refunds process. The method is an answer slot: if you used a method, describe it in your own words. If you did not have a method, say so plainly and return to the fact that you trained them.
- Provenance: [grounded] "I trained four new starters on our refunds process last year"
- Rationale: Shows teaching ability, which the team lead may value.

### Data-Driven Prober (weight 2)

**D1 · EXP · "Your 60 calls and emails a day. How was that counted, and is that your number alone?"** (defend-the-number)
- Guidance: answer in your own words: how you counted it (or that it is an estimate), what the figure is sensitive to, the assumption you would defend least, and which part was yours. If you did not count it, say so.
- Provenance: [grounded] "answering around 60 calls and emails a day"
- Rationale: The figure invites a probe. Answer slot: the pack does not supply a counting method.

**D2 · EXP · "How did you measure whether the four starters were ready?"** (premised question)
- Guidance: answer slot: if you measured readiness, say how. If there was no measure, say so plainly, then return to: you trained four new starters on the refunds process.
- Provenance: [grounded] "I trained four new starters on our refunds process last year"
- Rationale: Tests the claim behind F4.

### Pressure (weight 2)

**R1 · JD · "Sixty seconds: why you over a candidate with software experience?"**
- Guidance: hold: you bring customer-facing volume and a daily ticketing workflow. Concede: they have product experience you do not. Do not fold on the first follow-up, and do not claim the product knowledge.
- Provenance: [grounded] "3 years as customer service advisor at an energy supplier"; "I've never worked for a software company."
- Rationale: Pressure test of F5.

**R2 · JD · "That was an energy company. This is a different job. Convince me."**
- Guidance: hold the volume and the refund training. Concede the domain. Answer slot: name one thing about the energy role that is not domain-specific (for example, handling upset customers).
- Provenance: [grounded] "answering around 60 calls and emails a day"
- Rationale: Pressure on the sector switch.

## Requirement coverage

| Requirement (your summary) | Question IDs | Note |
|---|---|---|
| 2+ years in customer support | V1, S3 | Met (F1) |
| Zendesk or a similar ticketing tool | S2, V2 | Freshdesk bridge only (F2) |
| Clear written communication | C3 | Answer slot; no sample in material (F3) |
| Confidence handling escalations | S4, C1, C2, D2 | Low confidence (F4) |
| (Not in the ad) software background | S1, R1 | Gap (F5) |

## Reverse questions

1. "What does a new support specialist's first 30 days look like?" Why it lands: it shows you are planning, not just applying.
2. "Which ticketing tools does the team use day to day?" Why it lands: it tests the Zendesk gap from the other side.
3. "How do you decide what gets escalated, and to whom?" Why it lands: it shows you know escalation is a skill.
4. "What do customers most often come to you about, and what should a new hire learn first?" Why it lands: it asks the team lead to talk about their own work.
5. "Could you confirm the official channels you use for offers and onboarding documents?" Why it lands: a legitimate team can answer it at once, and the answer tells you whether this is real.
6. "Would you rather get feedback on written replies before or after they go out?" Why it lands: it shows you take written quality seriously.

## Upgrade menu

- **Full job ad text**: turns the requirement rows from your summary into quoted rows, and removes the [inferred] labels.
- **Any written test or assignment details**: lets C3 be rehearsed against the real format.
- **Anonymised examples of your written replies**: moves F3 from answer slot to [grounded].
- **Escalation examples from your job**: would upgrade F4 and S4 from scaffold to story-mapped answers.
- **Team lead's name and public profile**: would unlock a tailored interviewer read and reverse questions.
