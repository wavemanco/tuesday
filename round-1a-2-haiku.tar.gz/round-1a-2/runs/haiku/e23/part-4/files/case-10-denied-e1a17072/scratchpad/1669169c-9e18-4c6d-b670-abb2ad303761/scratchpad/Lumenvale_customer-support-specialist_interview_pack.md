# Lumenvale Software — Customer Support Specialist (remote) — Interview Prep Pack

**Role:** Customer Support Specialist, remote · **Company:** Lumenvale Software · **Interviewer:** support team lead (name not given) · **Round:** text interview on Telegram · **Set-up:** built from your message only; no research run (L0)

## 1. How to use this pack and type key

Personas are how a question arrives. Types are what is being scored.

- **JD**: the job ad's stated requirement
- **EXP**: a deep-dive on something you did
- **CASE**: a live customer problem from the role, answered in the moment
- **VAL**: a values question (none detected here)
- **CO**: company knowledge (none, because no research was run)

Guidance is scaffolding, not a script. Use your own words.

**Format for a text chat:** aim for 80–150 words per answer. Lead with the direct answer in the first sentence. Use short paragraphs, and at most one example. Chat answers get read on a screen, so a wall of text reads as evasion. If you need longer, split it into two messages and say "continuing" at the start of the second.

## 2. Fit snapshot

Requirements come from your message's summary of the ad, not the ad itself. Evidence cells quote only your sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — your message | "3 years as a customer service advisor at an energy supplier" — your message | high | [grounded] | presentation | Your sentence already reaches the requirement in other words. Use it as written: "three years as a customer service advisor at an energy supplier." Add nothing to it. |
| F2 | "Zendesk or similar ticketing tool" — your message | "I use Freshdesk every day" — your message | high | [grounded] | none | "Similar tool" is covered by your quote. The name Zendesk is the risk, see A1. |
| F3 | "clear written communication" — your message | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Your material shows the volume of written contact, not how clear it was. Answer slot: if you have a written example, or a comment on how your emails were judged, say what it was. If not, say so, and say how you check a reply before it goes out. |
| F4 | "confidence handling escalations" — your message | "trained four new starters on our refunds process last year" — your message | low | [inferred] | discovery | Your material shows refunds training, not escalations. Answer slot: if you passed a case up, or one was passed to you, say what and how you handled it. If not, say so plainly, and say how you would decide what to escalate. |
| F5 | Familiarity with a software product (role-family requirement, not quoted from the ad) — [generic] | "I've never worked for a software company." — your message | none | [grounded] | capability | The words are your own: "I haven't worked for a software company." No slot. Then how you would learn the product, said as a plan, never as a past. |

**Coverage line:** 2+ years → D1, F1 · Zendesk or similar → A1, F2 · clear written communication → B1, B3, F3 · confidence handling escalations → A3, B2, B4, F4 · software background → A2, A5, F5

**Gates:** none identified in the material.

## 3. Prohibited claims

These are not coached anywhere in this pack. Each entry gives its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've used Zendesk" | Inflated form of F2 | "I use Freshdesk every day." |
| "I designed the refunds process" | Inflated form of the refunds-training quote | "I trained four new starters on our refunds process last year." |
| "I handled 60 tickets a day" | Inflated form of the volume quote; calls and emails are not tickets | "answering around 60 calls and emails a day." |
| "I've worked in software support" | Negative you stated (F5) | "I haven't worked for a software company." |

## 4. Persona table

| Persona | How it shows up in this chat | Likelihood, with reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| A. Skeptic | Questions on Zendesk, the software gap, and escalations | High. A team lead is checking whether you can do the job and what gaps you bring. Your message has two visible gaps: Zendesk and software. | Give the plain fact first, then your bridge. Hold a position through two follow-ups before conceding anything. | 5 (A1–A5) |
| B. Case / Strategist | A live customer problem typed out in full | Medium-high. Support leads often run a written scenario, and it tests the escalation requirement. | Read the case, state your first reply, then say what you'd do next. | 4 (B1–B4) |
| C. Data-Driven Prober | Questions on how the 60 a day was counted, and what you did in Freshdesk | Medium. Your volume figure is the most likely target for a follow-up. | Say what the figure counts and what it doesn't. Say plainly when you don't know. | 2 (C1–C2) |
| D. Conversational | A friendly opener, a "why us" question, a casual question on your background | Likely as the opener. Casual questions are still scored. | Keep a 90-second arc ready. Answer the "why" in your own words. | 3 (D1–D3) |

## 5. Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our team works in Zendesk. Have you used it?" | JD | [grounded] "I use Freshdesk every day" — your message | Answer first: "I use Freshdesk every day." If you have used Zendesk, say when and for what. If you haven't: "I haven't used Zendesk." Then name the Freshdesk work you did, in your own words. Answer slot: the ad names Zendesk, so a probe is likely. Your honest branch is the Freshdesk one. Don't claim Zendesk. | F2 is the requirement most likely to be probed by name. This is the most predictable objection, rehearsed here too. |
| A2 (highest-ROI) | "You haven't worked for a software company. Why should we take a chance on you?" | EXP | [grounded] "I've never worked for a software company." — your message; [grounded] "answering around 60 calls and emails a day" — your message | Plain acknowledgment first: "I haven't worked for a software company." Hold it. Bridge with the volume: "I've been answering around 60 calls and emails a day." Name one thing you'd learn first about the product. Hold through two follow-ups, then concede the ramp-up time. Never claim product knowledge. | F5 is the gap a team lead will most likely press. This is the single most predictable objection, so it gets the deepest rehearsal. |
| A3 | "Tell me about a time a customer asked for a manager. What did you do?" | EXP | [generic] — open prompt, theme from the ad's escalation requirement | Story selection: pick a real complaint you handled that went up the chain, or one you passed up. Say what you did, in your own words. Answer slot: if no such case comes to mind, say so plainly, then describe how you would handle it: acknowledge, state the next step, pass it up with context. | F4 has no quote to map from. This prompt asks you to choose an instance. |
| A4 | "You trained new starters on refunds. What did you teach them?" | EXP | [grounded] "trained four new starters on our refunds process last year" — your message | Beats: four new starters, the refunds process, last year. Say what the process covered in your own words. Answer slot: if you checked whether the training worked, say how. If you didn't, say so. | Your strongest transferable evidence for clear written communication and onboarding. |
| A5 | "Why would you do better than someone who has worked at a software company?" | JD | [grounded] "I've never worked for a software company." — your message | Plain acknowledgment: "I haven't worked for a software company." Then name what transfers from your own work, from your sentences only. Don't claim you'd outperform. | Same gap as A2, asked as a comparison. Ask this once you have the first answer rehearsed. |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes: 'My refund was due in 3 days and it's been 10. I want my money now and I'm reporting you.' Write your first reply." | CASE | [generic] | Structure: acknowledge the wait without arguing, say what you can check now, give a time you can keep, and name the next step. Keep it under 120 words. Make no promise you can't keep. | A live problem from the role. It needs no claim about your past. |
| B2 | "A customer asks for a refund outside policy. Reply." | CASE | [generic] | Structure: say what policy allows, say what you can do, and say who decides exceptions and that you'll pass it to them with context. Don't promise an exception. | Tests the escalation requirement (F4) as a decision. |
| B3 | "A customer has waited weeks for a bug fix with no date. Write a two-line update." | CASE | [generic] | Structure: what you know, what you don't, and when they'll hear next. Two lines. | Tests the clear-writing requirement (F3) under a constraint. |
| B4 | "A customer has been passed between two teams for a week. What do you do?" | CASE | [generic] | Structure: take one owner, say what you'll do next and by when, and tell the customer, not just the internal team. | Tests ownership, which the escalation requirement depends on. |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around 60 calls and emails a day. How many did you resolve yourself, and how was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | The weakest-assumption move: name what "around" hides, and that the figure is calls and emails together, not tickets. Answer slot: if you can say how it was counted, say how. If you don't know, say so. Don't turn it into "tickets." | The figure is your headline number. It is the likeliest target for a follow-up. |
| C2 | "What did you actually do in Freshdesk day to day?" | EXP | [grounded] "I use Freshdesk every day" — your message | Name only the tasks you did yourself. Answer slot: if you ran reports, macros or views, say which. If not, say so and list what you did do. | Tests whether the tool experience is real. Ties to A1. |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me a bit about yourself." | JD | [grounded] "3 years as a customer service advisor at an energy supplier" — your message | 90-second arc: where you work now, the volume, the refunds training, then why this role. Use only those sentences. | A chat opener is still scored. This is the first impression. |
| D2 | "Why this role at Lumenvale?" | JD | [generic] | Name one thing in the ad you want to do, and say why in your own words. Don't claim knowledge of Lumenvale's product, since no research was run. | Motivation is scored even when casual. |
| D3 | "Tell me about the most frustrating customer you've handled." | EXP | [generic] — open prompt, persona stem | Selection scaffold: pick a real case with a clear stake and a clear outcome. If no such case comes to mind, say so plainly, then give the nearest one your material carries. | Open prompt in the Conversational register. Choose one case and say it short. |

## 6. Reverse questions

Each has a reason it lands.

1. "What does a typical first week look like for someone starting on your support queue?" — shows you're thinking about onboarding, not just hiring.
2. "Which ticketing tool does the team use day to day, and how is it set up?" — gives you a Zendesk answer in their words, not yours.
3. "How are escalations handed off, and who owns a ticket once it leaves first line?" — tests the escalation requirement from the other side.
4. "What does a good first 90 days look like here?" — shows you want a measurable target.
5. "Which measures matter most for support quality on your team?" — shows you know support is measured.

## 7. Sources

- **Provided documents:** your message (your background, and your summary of the job ad). No full ad text was provided.
- **Research tier:** L0. No searches or fetches were run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Values cheat sheet; no values-style round is detected, so it stays out. L0 sent no search. |
| 2. Lumenvale interview process | unavailable | Loop structure; this is one text session, so the weights are set from the round type. |
| 3. Lumenvale strategy / recent news | unavailable | CO bank. L0 sent no search. |
| 4. Interviewer name | n/a | No name given for the support team lead. |
| 5. Representative Customer Support Specialist JD | skipped | Your summary fixes the requirements, and the fit snapshot is built from them. |

## 8. Upgrade menu

- The full job-ad text → the requirements become verbatim [grounded] quotes, and the question set can be checked against every line of the ad.
- The support team lead's name → a tailored reverse question, and persona weights from their public footprint.
- Lumenvale's public material (values, product, recent news), at L1 → a company-vocabulary section and a current-company question for the CO bank. It also checks that the company's public footprint matches what you have been sent.
- Any Zendesk use, any escalations you handled or passed up, and any written example → A1, A3, B3 and F3 become stories rather than answer slots.
- A drill on any question → feedback against that question's guidance.
