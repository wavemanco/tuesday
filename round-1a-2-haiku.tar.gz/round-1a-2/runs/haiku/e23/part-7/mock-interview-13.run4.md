Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-e23-part-7-rooms-case-13-denied-2de33bb6/ab294c61-5183-4da6-a485-c4fada3e3dbd/scratchpad/Quillmoor_operations-coordinator_interview_pack.md`. I built it for a recruiter screen, which is what Hannah's message describes. Web search was refused in this session, so the pack has no company research and its sources are your message and the advert.

# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

**Role:** Operations Coordinator, Quillmoor Diagnostics. Hybrid, two days a week at Avonmouth, Bristol.
**Interviewer:** Hannah Lowther, Talent Partner. Recruiter screen, 30 minutes by phone, Thursday 2pm, on the mobile number on your application.
**Built from:** the advert and your message. No CV text was supplied. No research ran: web search was refused in this session, so company-level content is absent.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored:

- **VAL**: values alignment. None in this pack.
- **EXP**: your experience, and what you actually did.
- **JD**: the advert's stated requirements.
- **CO**: company knowledge. None in this pack, because no research ran.
- **CASE**: a live problem. None in this pack, because a recruiter screen does not usually run one.

Guidance is scaffolding, not a script. Say things in your own words.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | Reaches the requirement in its own terms. Your message shows the years and the role, not the depth of operations work behind them, so expect a probe on scope. Answer it from the quote. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Delivery scheduling across three depots is adjacent work. It does not reach production scheduling, planning or QA. Bridge at its own scope: "I schedule deliveries for our three depots." Answer slot: if you coordinated with anyone beyond depot delivery, say who and how; if you did not, say that the scheduling is the nearest thing you have done. |
| F3 | "track supplier deliveries" (advert) | none given | none | [grounded] | discovery | Your message does not show tracking. Answer slot: if you tracked supplier deliveries, say what you tracked and how; if you did not, say what you did when an order slipped. |
| F4 | "chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | none | Reaches the requirement in role terms. Say it as you said it: chase suppliers when orders slip. |
| F5 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | Reaches the requirement. The quote holds two claims: you rebuilt the sheet, and discrepancies fell by about a third over a year. Keep them as two sentences. The message does not say the sheet caused the fall. |
| F6 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your message does not show any dispatch reporting. Answer slot: if you reported on delivery timing, say what it covered and how often; if you did not report weekly, say so, and name the nearest thing you did track. |
| F7 | "Confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | The nearest quote is a spreadsheet rebuild. Your message does not show Excel itself, or how far you took it. This bridge is the pack's inference, so it is not asserted as your story. Answer slot: say which tools the stock-count sheet was built in, and which parts you built yourself. |
| F8 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | medium | [grounded] | transferability | Your in-house stock system is adjacent work, and your message does not say it is an ERP. Plain acknowledgment: "I haven't used SAP." Then the system in your message's terms: we run our own in-house stock system. The requirement is a plus, not a gate. |
| G1 | Hybrid: "two days a week at our Avonmouth site in Bristol" (advert, schedule gate) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Met for two days, which is the advert's pattern. Your words: two days is fine; three is the most you would want. Do not soften this to flexible. |
| G2 | "£38,000–£44,000" (advert, pay gate) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Your figure sits inside the advert's range. The pack cannot say an offer will land there. |
| G3 | Notice period (recruiter's own words: "I'd like to cover … your notice period") | none given | none | [grounded] | hard_gate | Your message does not establish a notice period. The pack gives no words for it. The one question it allows is asked at the foot of this message. |

## The prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| "I ran our in-house stock system" | Inflated form of your sentence "we run our own in-house stock system" | "we run our own in-house stock system," at its own scope |
| "My spreadsheet cut discrepancies by a third" | Inflated causal form of F5's quote | The two sentences as said. C2's slot covers how much was yours |
| "I'm confident with Excel" | Inflated form of F7's quote | The spreadsheet rebuild at its own scope. Pack observation: your message does not show Excel itself |
| "I have used SAP" or "I have ERP experience" | Negative you stated, F8 | Plain acknowledgment: "I haven't used SAP." |
| "I'd consider relocating to Reading" | Softened form of "which I don't want" | "the only offer is relocating to Reading, which I don't want." |
| "Three days a week would be fine" | Softened form of "I wouldn't want more than three" | "two days at Avonmouth is fine, but I wouldn't want more than three." |

## Reading the interviewer

Hannah's message is the only interviewer information. It names the agenda: salary expectations, notice period, the hybrid pattern, and reason for moving, then the team and next steps. No public footprint was checked, so there is no career-path read and no shared jump to mirror.

Implications: answer the four named topics in the order she gives them. Treat the team and next-steps part as information, not a test.

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport (weight 5, six questions) | Friendly opener, then her four named topics. | Highest. The relationship prior for a recruiter screen is conversational, and her message names these topics. Casual questions are still scored. | Give short, plain answers in the order she raises them. Stay with what your message says. |
| Skeptic (weight 3, five questions) | "Why this, from building supplies?", the SAP gap, Excel, and why not Reading. | High on SAP and Excel, because the advert lists both. A light Skeptic is the prior for a recruiter screen. | Rehearse the SAP answer until it is plain. Hold each position as your message states it. |
| Pressure (light, three questions) | A short challenge on pay or the discrepancy figure. | Medium-low. Recruiter screens rarely press, so this is light. | Pause, restate, and hold the sentence you said before conceding anything. |
| Data-Driven Prober (light, three questions) | "How was the third counted?" | Medium. The one-third figure is the only number in your message, so it will be checked if anyone checks. | Name what you can and cannot say about the count, in your own words. |
| Values / behavioral | None. | Not weighted. No values round was detected, and she named no values. | None. |

Depth is shorter than the usual session total of 18 to 26 questions. A 30-minute screen covers four named topics, and the depth sits in the Skeptic bank.

## Question banks

### Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background, briefly." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip." | About 90 seconds: the four years, the role, the three depots, the supplier chasing. Close on the stock-count result, using its own sentence: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Opens the call and is scored. Draws on F1, F2, F4 and F5. |
| A2 | "What's your notice period?" | JD | [grounded] recruiter's own words: "your notice period" | Give the figure you know, and any date it sets, in your own words. The pack has no notice period for you, so it supplies none. | G3 is a hard gate. This is the knockout check on the agenda she named. |
| A3 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000" (your message) | Say £42,000 once, plainly. Add a range only if you have one. The pack has none. | G2. £42,000 sits inside the advert's range. |
| A4 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | State two days as fine, and three as the most you would want, in those words. Do not turn "wouldn't want more than three" into "happy to do three" or "flexible". | G1 is met. The logical form of your sentence must survive the call. |
| A5 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | Say the office is closing next year, and that the only offer is relocating to Reading, which you do not want. Stop there. No criticism of the employer, and no detail about a wider search, because your message gives none. | This is her named topic. The Skeptic will check it against A6. |
| A6 | "Would you consider relocating to Reading?" | EXP | [grounded] "which I don't want" (your message) | "I don't want to relocate to Reading," as stated. Do not move to "would consider". | Consistency check on A5. The answer must match the reason you gave for moving. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role lists ERP experience, SAP or similar, as a plus. Have you used an ERP system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." (your message); raising source: the advert's line "ERP experience (SAP or similar) a plus" | **Highest-ROI prep in this pack.** Open with "I haven't used SAP." Then describe the in-house stock system in your message's terms. Hold: it is the nearest thing you have used, and you do not call it an ERP. Follow-up one: say what you do in it. Follow-up two: hold, and say how you would learn SAP, as a plan and never as a past. Concede specifically: "I haven't used SAP, and I don't know how close our system is to one." | F8. This is the objection most likely to come up. Rehearse until the first sentence is automatic. |
| B2 | "Rate your Excel, and show me what you have built in it." | JD | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | Answer slot: if you built the stock-count sheet, say which parts you built and what they do. If it was built by someone else, say so, and say what you did in it. | F7. The bridge is an inference, so the answer must come from your own experience. |
| B3 | "The role reports weekly on on-time dispatch. What have you reported weekly?" | JD | [grounded] none. Raising source: the advert's line "report weekly on on-time dispatch" | Answer slot: if you reported on delivery timing or discrepancies in a regular report, say what it covered and who received it. If you did not report weekly, say so plainly, and name the nearest figure you did track. | F6. The question presupposes a weekly report that your message does not show, so the second branch is the honest one. |
| B4 | "Tell me about a time you coordinated work across more than one function." | JD | [grounded] "I schedule deliveries for our three depots" (your message); raising source: the advert's line "Coordinate production schedules between planning, the warehouse and QA" | Open prompt. The story you have is depot scheduling; describe it in your own words. Answer slot: if you coordinated with planning, a warehouse team or quality, say who and how. If no such time comes to mind, say so plainly, and give the depot scheduling. | F2. The advert's three functions are the gap, so the pack does not name a story for them. |
| B5 | "Why would this role suit someone from building supplies?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message); raising source: the advert's line "Coordinate production schedules between planning, the warehouse and QA" | Say what carries over, using the sentences you already have: scheduling, chasing suppliers, the stock records. Then name the parts of the role that are new to you. | F1 and F2. Expect this question if the SAP and production gaps come up. |

### Pressure (light, weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we move you forward over someone who has used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." (your message) | Hold: "I haven't used SAP." Then return to the scheduling and stock-count work in your message. Hold through two follow-ups by returning to that work. Concede only what is true: the SAP gap is real. | F8. Pressure version of B1. Hold, then concede specifically. |
| C2 | "That discrepancy figure: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | Hold the sentence as said: you rebuilt the sheet, and the figure is about a third over a year. Answer slot: say what part of the fall you can attribute to the rebuild, and what you did not measure. If you do not know how much was yours, say so plainly. | F5. The answer must not turn the two sentences into one claim. |
| C3 | "You want £42,000. Why should it be that and not less?" | JD | [grounded] "I'm hoping for £42,000" (your message) | Answer slot: if the figure rests on something you can name, say what, in your own words. If it is simply your number, say so. | G2. Pressure on pay. |

### Data-Driven Prober (light, weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that about-a-third was counted." | EXP | [grounded] "discrepancies fell by about a third over a year" (your message) | Answer in four parts, in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you did not track how it was counted, say so. | F5. The one number in your message, so the most likely to be checked. |
| D2 | "Which stock records did you keep accurate, and how did you check them?" | JD | [grounded] raising source: the advert's line "keep stock records accurate"; your quote: "I rebuilt our stock-count spreadsheet" (your message) | Answer slot: if you checked the records, say how. If you did not check them against anything, say so, and say what the sheet did. | F5 and F6. Asks about a practice your message does not state, so the second branch is honest. |
| D3 | "What does on-time mean in your depot schedule?" | JD | [grounded] raising source: the advert's phrase "on-time dispatch" | Answer slot: if your schedule had an on-time measure, say what counted as on time. If it did not, say so. | F6. Tests the weekly-reporting requirement from the other side. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1, F1 |
| Coordinate production schedules between planning, the warehouse and QA | B4, B5 |
| Track supplier deliveries | Fit snapshot F3 only. No question of its own: your message does not show tracking, so the answer is the slot in F3 |
| Chase late orders | A1 |
| Keep stock records accurate | A1, C2, D2 |
| Report weekly on on-time dispatch | B3, D3 |
| Confident with Excel | B2 |
| ERP (SAP or similar) a plus | B1, C1 |
| £38,000–£44,000 | A3, C3 |
| Hybrid: two days a week at Avonmouth | A4 |
| Notice period (her agenda) | A2 |
| Reason for moving (her agenda) | A5, A6 |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time dispatch measured today, and who sees the weekly report?" | Shows you read the advert. It tests whether the weekly report is a live task. |
| R2 | "Which system holds stock records for planning and the warehouse, and is SAP in use?" | Shows you care whether the SAP gap matters, before the hiring manager asks. |
| R3 | "Who would I work with most day to day across planning, the warehouse and QA?" | Maps the three-way coordination in the advert onto a real team. |
| R4 | "Which two days do people on the Avonmouth team usually work on site?" | Confirms the hybrid pattern without asking to flex it. |
| R5 | "What would make someone successful in the first three months?" | Asks for the role's real expectations. It lands in any round, and it is the question to close on. |

## Upgrade menu

- Your CV text → turns your message's sentences into CV quotes, so rows marked [grounded] from your message can be checked against a document.
- Your notice period → closes G3, so A2 becomes a plain answer rather than a slot.
- Hannah's public professional profile, if you have a link → an interviewer read, and a reverse question tied to her path.
- Web search, if it is allowed in a later session → company values and the Avonmouth site, with a grounded company line and a reverse question tied to the company's current position.

---

Two other things, neither pushed:
- **Drill:** I can play Hannah's Skeptic on B1, the SAP question the pack names as the highest-ROI prep, and give feedback against that question's guidance.
- **Dossier and Word:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to a .docx if you want it.

Two questions, both about the gaps the pack could not close:

1. What is your notice period? Hannah will ask, and the pack has no figure for it.
2. Can you paste your CV text? If not, the pack works from your message alone.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quillmoor_operations-coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

**Role:** Operations Coordinator, Quillmoor Diagnostics. Hybrid, two days a week at Avonmouth, Bristol.
**Interviewer:** Hannah Lowther, Talent Partner. Recruiter screen, 30 minutes by phone, Thursday 2pm, on the mobile number on your application.
**Built from:** the advert and your message. No CV text was supplied. No research ran: web search was refused in this session, so company-level content is absent.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored:

- **VAL**: values alignment. None in this pack.
- **EXP**: your experience, and what you actually did.
- **JD**: the advert's stated requirements.
- **CO**: company knowledge. None in this pack, because no research ran.
- **CASE**: a live problem. None in this pack, because a recruiter screen does not usually run one.

Guidance is scaffolding, not a script. Say things in your own words.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | Reaches the requirement in its own terms. Your message shows the years and the role, not the depth of operations work behind them, so expect a probe on scope. Answer it from the quote. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Delivery scheduling across three depots is adjacent work. It does not reach production scheduling, planning or QA. Bridge at its own scope: "I schedule deliveries for our three depots." Answer slot: if you coordinated with anyone beyond depot delivery, say who and how; if you did not, say that the scheduling is the nearest thing you have done. |
| F3 | "track supplier deliveries" (advert) | none given | none | [grounded] | discovery | Your message does not show tracking. Answer slot: if you tracked supplier deliveries, say what you tracked and how; if you did not, say what you did when an order slipped. |
| F4 | "chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | none | Reaches the requirement in role terms. Say it as you said it: chase suppliers when orders slip. |
| F5 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | Reaches the requirement. The quote holds two claims: you rebuilt the sheet, and discrepancies fell by about a third over a year. Keep them as two sentences. The message does not say the sheet caused the fall. |
| F6 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your message does not show any dispatch reporting. Answer slot: if you reported on delivery timing, say what it covered and how often; if you did not report weekly, say so, and name the nearest thing you did track. |
| F7 | "Confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | The nearest quote is a spreadsheet rebuild. Your message does not show Excel itself, or how far you took it. This bridge is the pack's inference, so it is not asserted as your story. Answer slot: say which tools the stock-count sheet was built in, and which parts you built yourself. |
| F8 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | medium | [grounded] | transferability | Your in-house stock system is adjacent work, and your message does not say it is an ERP. Plain acknowledgment: "I haven't used SAP." Then the system in your message's terms: we run our own in-house stock system. The requirement is a plus, not a gate. |
| G1 | Hybrid: "two days a week at our Avonmouth site in Bristol" (advert, schedule gate) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Met for two days, which is the advert's pattern. Your words: two days is fine; three is the most you would want. Do not soften this to flexible. |
| G2 | "£38,000–£44,000" (advert, pay gate) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Your figure sits inside the advert's range. The pack cannot say an offer will land there. |
| G3 | Notice period (recruiter's own words: "I'd like to cover … your notice period") | none given | none | [grounded] | hard_gate | Your message does not establish a notice period. The pack gives no words for it. The one question it allows is asked at the foot of this message. |

## The prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| "I ran our in-house stock system" | Inflated form of your sentence "we run our own in-house stock system" | "we run our own in-house stock system," at its own scope |
| "My spreadsheet cut discrepancies by a third" | Inflated causal form of F5's quote | The two sentences as said. C2's slot covers how much was yours |
| "I'm confident with Excel" | Inflated form of F7's quote | The spreadsheet rebuild at its own scope. Pack observation: your message does not show Excel itself |
| "I have used SAP" or "I have ERP experience" | Negative you stated, F8 | Plain acknowledgment: "I haven't used SAP." |
| "I'd consider relocating to Reading" | Softened form of "which I don't want" | "the only offer is relocating to Reading, which I don't want." |
| "Three days a week would be fine" | Softened form of "I wouldn't want more than three" | "two days at Avonmouth is fine, but I wouldn't want more than three." |

## Reading the interviewer

Hannah's message is the only interviewer information. It names the agenda: salary expectations, notice period, the hybrid pattern, and reason for moving, then the team and next steps. No public footprint was checked, so there is no career-path read and no shared jump to mirror.

Implications: answer the four named topics in the order she gives them. Treat the team and next-steps part as information, not a test.

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport (weight 5, six questions) | Friendly opener, then her four named topics. | Highest. The relationship prior for a recruiter screen is conversational, and her message names these topics. Casual questions are still scored. | Give short, plain answers in the order she raises them. Stay with what your message says. |
| Skeptic (weight 3, five questions) | "Why this, from building supplies?", the SAP gap, Excel, and why not Reading. | High on SAP and Excel, because the advert lists both. A light Skeptic is the prior for a recruiter screen. | Rehearse the SAP answer until it is plain. Hold each position as your message states it. |
| Pressure (light, three questions) | A short challenge on pay or the discrepancy figure. | Medium-low. Recruiter screens rarely press, so this is light. | Pause, restate, and hold the sentence you said before conceding anything. |
| Data-Driven Prober (light, three questions) | "How was the third counted?" | Medium. The one-third figure is the only number in your message, so it will be checked if anyone checks. | Name what you can and cannot say about the count, in your own words. |
| Values / behavioral | None. | Not weighted. No values round was detected, and she named no values. | None. |

Depth is shorter than the usual session total of 18 to 26 questions. A 30-minute screen covers four named topics, and the depth sits in the Skeptic bank.

## Question banks

### Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background, briefly." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip." | About 90 seconds: the four years, the role, the three depots, the supplier chasing. Close on the stock-count result, using its own sentence: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Opens the call and is scored. Draws on F1, F2, F4 and F5. |
| A2 | "What's your notice period?" | JD | [grounded] recruiter's own words: "your notice period" | Give the figure you know, and any date it sets, in your own words. The pack has no notice period for you, so it supplies none. | G3 is a hard gate. This is the knockout check on the agenda she named. |
| A3 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000" (your message) | Say £42,000 once, plainly. Add a range only if you have one. The pack has none. | G2. £42,000 sits inside the advert's range. |
| A4 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | State two days as fine, and three as the most you would want, in those words. Do not turn "wouldn't want more than three" into "happy to do three" or "flexible". | G1 is met. The logical form of your sentence must survive the call. |
| A5 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | Say the office is closing next year, and that the only offer is relocating to Reading, which you do not want. Stop there. No criticism of the employer, and no detail about a wider search, because your message gives none. | This is her named topic. The Skeptic will check it against A6. |
| A6 | "Would you consider relocating to Reading?" | EXP | [grounded] "which I don't want" (your message) | "I don't want to relocate to Reading," as stated. Do not move to "would consider". | Consistency check on A5. The answer must match the reason you gave for moving. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role lists ERP experience, SAP or similar, as a plus. Have you used an ERP system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." (your message); raising source: the advert's line "ERP experience (SAP or similar) a plus" | **Highest-ROI prep in this pack.** Open with "I haven't used SAP." Then describe the in-house stock system in your message's terms. Hold: it is the nearest thing you have used, and you do not call it an ERP. Follow-up one: say what you do in it. Follow-up two: hold, and say how you would learn SAP, as a plan and never as a past. Concede specifically: "I haven't used SAP, and I don't know how close our system is to one." | F8. This is the objection most likely to come up. Rehearse until the first sentence is automatic. |
| B2 | "Rate your Excel, and show me what you have built in it." | JD | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | Answer slot: if you built the stock-count sheet, say which parts you built and what they do. If it was built by someone else, say so, and say what you did in it. | F7. The bridge is an inference, so the answer must come from your own experience. |
| B3 | "The role reports weekly on on-time dispatch. What have you reported weekly?" | JD | [grounded] none. Raising source: the advert's line "report weekly on on-time dispatch" | Answer slot: if you reported on delivery timing or discrepancies in a regular report, say what it covered and who received it. If you did not report weekly, say so plainly, and name the nearest figure you did track. | F6. The question presupposes a weekly report that your message does not show, so the second branch is the honest one. |
| B4 | "Tell me about a time you coordinated work across more than one function." | JD | [grounded] "I schedule deliveries for our three depots" (your message); raising source: the advert's line "Coordinate production schedules between planning, the warehouse and QA" | Open prompt. The story you have is depot scheduling; describe it in your own words. Answer slot: if you coordinated with planning, a warehouse team or quality, say who and how. If no such time comes to mind, say so plainly, and give the depot scheduling. | F2. The advert's three functions are the gap, so the pack does not name a story for them. |
| B5 | "Why would this role suit someone from building supplies?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message); raising source: the advert's line "Coordinate production schedules between planning, the warehouse and QA" | Say what carries over, using the sentences you already have: scheduling, chasing suppliers, the stock records. Then name the parts of the role that are new to you. | F1 and F2. Expect this question if the SAP and production gaps come up. |

### Pressure (light, weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we move you forward over someone who has used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." (your message) | Hold: "I haven't used SAP." Then return to the scheduling and stock-count work in your message. Hold through two follow-ups by returning to that work. Concede only what is true: the SAP gap is real. | F8. Pressure version of B1. Hold, then concede specifically. |
| C2 | "That discrepancy figure: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | Hold the sentence as said: you rebuilt the sheet, and the figure is about a third over a year. Answer slot: say what part of the fall you can attribute to the rebuild, and what you did not measure. If you do not know how much was yours, say so plainly. | F5. The answer must not turn the two sentences into one claim. |
| C3 | "You want £42,000. Why should it be that and not less?" | JD | [grounded] "I'm hoping for £42,000" (your message) | Answer slot: if the figure rests on something you can name, say what, in your own words. If it is simply your number, say so. | G2. Pressure on pay. |

### Data-Driven Prober (light, weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that about-a-third was counted." | EXP | [grounded] "discrepancies fell by about a third over a year" (your message) | Answer in four parts, in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you did not track how it was counted, say so. | F5. The one number in your message, so the most likely to be checked. |
| D2 | "Which stock records did you keep accurate, and how did you check them?" | JD | [grounded] raising source: the advert's line "keep stock records accurate"; your quote: "I rebuilt our stock-count spreadsheet" (your message) | Answer slot: if you checked the records, say how. If you did not check them against anything, say so, and say what the sheet did. | F5 and F6. Asks about a practice your message does not state, so the second branch is honest. |
| D3 | "What does on-time mean in your depot schedule?" | JD | [grounded] raising source: the advert's phrase "on-time dispatch" | Answer slot: if your schedule had an on-time measure, say what counted as on time. If it did not, say so. | F6. Tests the weekly-reporting requirement from the other side. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1, F1 |
| Coordinate production schedules between planning, the warehouse and QA | B4, B5 |
| Track supplier deliveries | Fit snapshot F3 only. No question of its own: your message does not show tracking, so the answer is the slot in F3 |
| Chase late orders | A1 |
| Keep stock records accurate | A1, C2, D2 |
| Report weekly on on-time dispatch | B3, D3 |
| Confident with Excel | B2 |
| ERP (SAP or similar) a plus | B1, C1 |
| £38,000–£44,000 | A3, C3 |
| Hybrid: two days a week at Avonmouth | A4 |
| Notice period (her agenda) | A2 |
| Reason for moving (her agenda) | A5, A6 |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time dispatch measured today, and who sees the weekly report?" | Shows you read the advert. It tests whether the weekly report is a live task. |
| R2 | "Which system holds stock records for planning and the warehouse, and is SAP in use?" | Shows you care whether the SAP gap matters, before the hiring manager asks. |
| R3 | "Who would I work with most day to day across planning, the warehouse and QA?" | Maps the three-way coordination in the advert onto a real team. |
| R4 | "Which two days do people on the Avonmouth team usually work on site?" | Confirms the hybrid pattern without asking to flex it. |
| R5 | "What would make someone successful in the first three months?" | Asks for the role's real expectations. It lands in any round, and it is the question to close on. |

## Upgrade menu

- Your CV text → turns your message's sentences into CV quotes, so rows marked [grounded] from your message can be checked against a document.
- Your notice period → closes G3, so A2 becomes a plain answer rather than a slot.
- Hannah's public professional profile, if you have a link → an interviewer read, and a reverse question tied to her path.
- Web search, if it is allowed in a later session → company values and the Avonmouth site, with a grounded company line and a reverse question tied to the company's current position.
