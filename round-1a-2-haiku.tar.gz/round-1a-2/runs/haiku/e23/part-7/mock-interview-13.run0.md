Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-e23-part-7-rooms-case-13-denied-c4a8e41c/490a5a95-1ce1-461d-b23e-e025f90596c9/scratchpad/quillmoor_operations_coordinator_interview_pack.md. Here are the parts you need for Thursday.

**Salary (S1):** Say "I'm hoping for £42,000" once and don't justify it. If they counter lower, hold the number and ask what range they have in mind for the role. The advert's range is £38,000 to £44,000.

**Notice period (S2):** It isn't in what you sent me, so I haven't written an answer. Say it plainly, as it applies to you.

**Hybrid (S3):** "Two days at Avonmouth is fine. Three is my limit."

**Why you're moving (S4):** Say the Bristol office is closing next year and you want to stay in Bristol. Don't criticise the company. If they ask about Reading: "I don't want to relocate to Reading."

**SAP (S5):** "I haven't used SAP. We run our own in-house stock system." Don't describe learning SAP as past experience. If asked how you'd get up to speed, present it as a plan.

**Production scheduling (S6):** What you can say is that you schedule deliveries for three depots and chase suppliers when orders slip. Don't claim production, planning, warehouse or QA scheduling. If you did have any part in those, say what it was. If not, say so plainly.

**"About a third" (S7):** Expect "how was that counted?" Be ready to say how the count was taken, what it's sensitive to, and which part was yours. If you don't know how it was counted, say that.

**Weekly dispatch reporting (S8):** Your material doesn't show this. If you haven't done it, say so and say how you'd learn it.

**Questions to ask (team and next steps):**
- What does the weekly on-time dispatch report look like, and who reads it?
- How do planning, the warehouse and QA set the production schedule day to day?
- What stock or ERP system does the team use today, and is SAP planned?
- Which two days would be on site, and how is the pattern set?
- What are the next steps, and roughly when would you decide?

**Research:** I ran no web searches. The pack uses only your message, Hannah's message and the advert.

**Upgrade menu:**
- Your notice period → I'll write S2 in your words.
- A light public search on Quillmoor → a "why Quillmoor" line and a check on the team questions.
- Typical Bristol pay for this role → shows whether £42,000 is market-realistic, not just within the advert's range.

I can play Hannah's skeptic side on S1 and S4 if you want to rehearse them out loud. I can also save a tuesday-dossier.md recording the gaps this prep exposed, and convert the pack to Word if you'd like it that way.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations_coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

Recruiter screen, Thursday 2pm, 30 min phone call with Hannah Lowther (Talent Partner). Covers salary, notice period, hybrid pattern, reason for moving, then team and next steps.

**Research tier: L0.** No searches were run. This pack uses only your message, Hannah's message and the advert.

## How to use this

Personas describe how a question arrives. Types describe what is being scored: **JD** (a role requirement), **EXP** (your own experience, checked). Guidance is scaffolding, not a script. Say things in your own words.

## Persona weights

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Conversational / rapport | Opens with "walk me through your background" | High | Recruiter screens open this way | 90-second arc, no new facts |
| Skeptic | Salary, hybrid, SAP, production gap, "why now" | High | The advert's gaps and her call list are the likely probes | Say the quoted fact; plain acknowledgment; answer slot where needed |
| Prober | Asks how the 'one third' figure was counted | Medium | Your one headline number sits in your CV line | Say what you know and say plainly what you don't |
| Pressure | Pushes back on salary | Low to medium | Screens rarely push hard | Hold the number once; ask what the range is |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | Meets it on your account. Say the four years and the role, nothing added. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | high | [grounded] | none | Your words cover the chasing directly and the tracking through depot scheduling. Use those terms. |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | none | The fall is a figure you gave; the cause is not stated. Say the spreadsheet, the year, and "about a third" as you said it. Answer slot in S7. |
| F4 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | low | [grounded] | transferability | Depot delivery scheduling is adjacent to production scheduling, not the same thing. Words: "I schedule deliveries for our three depots." Answer slot in S6. |
| F5 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | presentation | A spreadsheet rebuild reaches Excel in other terms. Words: "I rebuilt our stock-count spreadsheet." Your material does not show advanced functions, so do not claim them. |
| F6 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | high | [grounded] | capability | The stated negative: "I haven't used SAP." Then your own description: "we run our own in-house stock system." No claim of ERP work. |
| F7 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material is silent on dispatch reporting. Answer slot in S8. |
| F8 | "two days a week at our Avonmouth site in Bristol" (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Meets it. Two days is fine; three is your ceiling. |

## Prohibited claims

Not coached, with the basis for each.

| Not coached | Basis | Honest form |
|---|---|---|
| Hands-on SAP or ERP experience | Negative you stated (F6) | "I haven't used SAP." |
| Coordinating production schedules, or working with planning, warehouse or QA on them | Inflated form of F4 | F4's quote at its own scope: "I schedule deliveries for our three depots." Your material shows depot delivery scheduling, not production. |
| That the one-third fall in discrepancies was all your doing | Inflated form of F3 | The figure at its own scope: "discrepancies fell by about a third over a year." Cause not established; see S7. |
| That you would consider Reading | Negative you stated | "I don't want to relocate to Reading." |

## Question banks

### Conversational (mid-high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip." | 90-second arc: the role and four years; the three depots and chasing suppliers; the stock spreadsheet. Stop there. No new facts. | The likeliest opener on a recruiter screen. Draws on F1 and F2. |

### Skeptic (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Say the number once, as you wrote it: "I'm hoping for £42,000." Don't justify it. If they counter lower, hold it and ask what the range is for the role. | The advert gives £38,000 to £44,000, so this is a knockout check. The figure is yours. |
| S2 | "What's your notice period?" | EXP | [generic] none given | Answer slot: your notice period is not in the material, so say it in your own words, exactly as it applies to you. | A logistics check; no quote carries the number. Upgrade menu. |
| S3 | "The role is two days a week at Avonmouth. Is that workable?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three." | Yes, two days works; three is your limit. Say it that way. | The hybrid pattern is in the advert, and the answer is yours. |
| S4 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say the closure and that you want to stay in Bristol. Don't criticise the company. Plain acknowledgment: "I don't want to relocate to Reading." If asked whether you'd reconsider Reading, say no plainly and stop. | Motivation consistency is the skeptic's first probe. Fully sourced. |
| S5 | "The advert lists SAP as a plus. Have you used it?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | "I haven't used SAP. We run our own in-house stock system." Do not describe learning SAP as past experience; if asked, give it as a plan. | F6: a capability gap you stated, so the plain acknowledgment is the honest answer. |
| S6 | "The role coordinates production schedules across planning, the warehouse and QA. What's your experience with that?" | JD | [grounded] "I schedule deliveries for our three depots" | Answer slot: if you had any part in production, planning, warehouse or QA scheduling, say what and how, in your own words. If not, say so plainly and describe depot delivery scheduling: "I schedule deliveries for our three depots." Do not extend it. | F4. The question presumes the advert's production scope; the second branch allows that it was never yours. |
| S7 | "Discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: say how the count was taken, what it is sensitive to, the assumption you'd defend least, and which part was yours. If you don't know how it was counted, say so plainly. | The defend-the-number slot for your one headline figure. Probers go straight here. |
| S8 | "The role reports weekly on on-time dispatch. Have you reported on dispatch?" | JD | [grounded] none given; the advert raises it | Answer slot: if you have reported on dispatch, say what you reported and how often. If not, say so plainly and say how you'd learn the weekly report. | F7. No quote supports dispatch reporting, so none is implied. |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | C1 |
| Coordinate production schedules (planning, warehouse, QA) | S6 |
| Track supplier deliveries and chase late orders | C1 |
| Keep stock records accurate | S7 |
| Report weekly on on-time dispatch | S8 |
| Confident with Excel | None, and why: F5 is a presentation-only match; S7 covers the spreadsheet indirectly |
| ERP experience (SAP or similar) a plus | S5 |
| Hybrid, two days at Avonmouth | S3 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does the weekly on-time dispatch report look like, and who reads it?" | Shows you read the advert and want the real scope |
| "How do planning, the warehouse and QA set the production schedule day to day?" | Points at the seam you would have to hold |
| "What stock or ERP system does the team use today, and is SAP planned?" | Tests whether the gap matters to them |
| "Which two days would be on site, and how is the pattern set?" | Settles the hybrid question in practice |
| "What are the next steps, and roughly when would you decide?" | Closes on timing |

## Sources

Provided documents: your message, Hannah's message, the advert.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | unavailable | Values cheat sheet; not run at L0 |
| 2. Interview process | unavailable | Loop structure; not run at L0. Hannah's message already describes this screen |
| 3. Strategy / recent news | unavailable | Context for a "why Quillmoor" answer; not run at L0 |
| 4. Recruiter's public profile | unavailable | Nothing on the candidate side; not run at L0 |
| 5. Representative JD | skipped | The advert fixes the fit snapshot |

## Upgrade menu

- Your notice period → S2 written in your own words, with what it means for a start date
- Quillmoor's public profile (one research pass) → a "why Quillmoor" line and a check on the team questions
- Typical Bristol pay for an Operations Coordinator → checks whether £42,000 sits in the market, not only in the advert
