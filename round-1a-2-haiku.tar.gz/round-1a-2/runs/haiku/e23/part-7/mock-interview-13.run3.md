Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-e23-part-7-rooms-case-13-denied-d09867f5/b6501d4b-9ec4-4bbf-8a98-c06a22f6aaef/scratchpad/quillmoor_operations-coordinator_interview_pack.md`. I built it for a recruiter screen, since that's what Hannah's message describes. Web search was refused, so it runs on your brief and the advert only.

# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

Recruiter screen, Thursday 2pm, 30 minutes by phone. Interviewer: Hannah Lowther, Talent Partner (recruiter).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored: **VAL** values/behaviour, **EXP** your own history, **JD** the advert's requirements, **CO** company knowledge, **CASE** a live problem. The guidance is scaffolding, not a script. Answer in your own words.

Left out on purpose: values cheat sheet (no company values were fetched or pasted), interviewer read (the recruiter's message sets the agenda), graded deliverables (none declared), delivery coaching (no assessment given).

## Fit snapshot

"Your message" is your brief. "Advert" and "recruiter's message" are the text you pasted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler." (your message) | medium | [grounded] | none | Your sentence already gives the years and the title. Nothing inspectable is attached, so expect a probe on the scope of the role. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [inferred] | transferability | Your material shows delivery scheduling across three depots. It does not show production scheduling, planning or QA. Keep the bridge at the scope of the quote. Answer slot: if you have scheduled work across a planning, production or QA team, say how; if not, say so and stay with the depot deliveries. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | none | Your sentence reaches this in close terms. Expect a probe on how often orders slip and what you did. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | none | Your sentence reaches the requirement. The figure is a claim you made, so it raises the defend-the-number slots in S10. |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show any regular reporting. Answer slot: see S9. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | low | [grounded] | discovery | The quote touches a spreadsheet but does not show whether it was Excel or how deep your skills go. Answer slot: see S7. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | low | [grounded] | capability | You have stated the absence of SAP. Words: "I've never used SAP." The in-house system is quoted at its own scope. The pack does not call it an ERP. |
| G1 | Pay: "£38,000–£44,000" (advert) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your figure sits inside the advert's range. It is a stated expectation, not a floor, and the pack does not supply a floor. |
| G2 | "Hybrid: two days a week at the Avonmouth site in Bristol." (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Met on the stated pattern. Your ceiling of three is your own constraint. |
| G3 | "your notice period" (recruiter's message) | none given | none | [grounded] | hard_gate | Your material does not establish your notice period, so the pack does not supply one. Answer slot: see S6. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I have SAP or ERP experience" | Negative you stated (F7) | "I've never used SAP." Nothing added. |
| "I coordinated production schedules across planning, the warehouse and QA" | Inflated form of F2 | "I schedule deliveries for our three depots." Pack's observation: the material shows delivery scheduling, not production scheduling. |
| "The drop in discrepancies was down to the spreadsheet alone" | Inflated form of F4 | "discrepancies fell by about a third over a year" after the rebuild, at that quote's scope. Pack's observation: the material does not show what else changed. |

## Persona weights

| Persona | How it shows up in this call | Likelihood | Counter-strategy |
|---|---|---|---|
| Skeptic / knockout checks | Asks the four topics you were told about (pay, notice, days, why you're leaving) as checks, and probes the SAP and production gaps | High. The recruiter named the four topics, and the gaps are visible on your CV | Answer each knockout in one or two sentences. For gaps, say the plain thing first, then the nearest real evidence |
| Conversational / rapport | Opens with your journey and a question about a late order | High. The register is friendly and the call is short | 90-second arc from your own sentences; a plain answer about late orders |
| Pressure | Not in the bank | Low for a recruiter screen | Not rehearsed here |

Reasoning: the usual prior for a recruiter screen is conversational with a light skeptic. The recruiter's four topics are all knockout checks, so the skeptic bank carries most of the weight. The pack is shorter than a full pack on purpose, because the call is 30 minutes.

## Question banks

### Skeptic / knockout checks (weight: heavy)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Your experience is in building supplies. What makes you think you'd fit a diagnostics manufacturer?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." | Start with the four years and the work in them: you schedule deliveries for three depots and chase suppliers when orders slip. These are the nearest parts of the advert. Answer slot: if you have worked with a planning, production or QA team, say how; if not, say so plainly and say the sector is new to you. | F1 meets the first requirement. The sector gap is the probe a skeptic will make. JD because it scores the advert's headline line. |
| S2 | "Do you have SAP or ERP experience?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say the plain thing first: "I've never used SAP." Then the in-house system at its own scope. Then how you would learn it, as a plan for your first weeks, not as something you have done. Do not call the in-house system an ERP. | F7 is a capability gap, and the advert makes it a plus. An honest answer costs less than a bluff. |
| S3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Give the figure, £42,000. It sits inside the advert's £38,000–£44,000. Do not add a range unless asked. Answer slot: if you have a lowest figure you would accept, decide it before Thursday; if not, say only the hope. | G1: pay is a knockout. The material gives a hope, not a floor, so the pack does not supply one. |
| S4 | "How do you feel about the hybrid pattern, two days in Avonmouth?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three." | Say two days is fine. If asked about a ceiling, say three is the most you would want. Do not add commute reasons; the material contains none. | G2 is your own constraint, so it is high confidence. The recruiter named the hybrid pattern as a topic. |
| S5 | "What's prompting you to look for a move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say the office is closing next year, and the only offer is relocating to Reading, which you don't want. Then stop. Do not add a reason, such as growth, that the material does not carry. | The recruiter asked directly. The honest reason is clean and needs no embellishment. |
| S6 | "What's your notice period, and when could you start?" | JD | [grounded] "your notice period" (recruiter's message) | Answer slot: state your notice period in your own words, then when you could start. Your material establishes neither, so the pack supplies neither. | G3 is a gate the material is silent on. It is asked of you in this message. |
| S7 | "How confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: name the spreadsheet you rebuilt and what you used it for, in your own words. If you can name specific functions, say them. If the spreadsheet was not Excel, say what it was. | F6: the advert asks for Excel, and your material shows a spreadsheet but not the tool or depth. The pack asks rather than asserts. |
| S8 | "This role coordinates production schedules across planning, the warehouse and QA. What's your experience there?" | JD | [grounded] "I schedule deliveries for our three depots." | Name the delivery scheduling you do, across three depots. Answer slot: if you have scheduled work across planning, production or QA, say how, in your own words; if not, say so plainly and stay with the deliveries. | F2 is the largest gap, and the advert puts it first. **Highest-ROI prep in this pack:** this is the objection most likely to come up in some form. |
| S9 | "The role reports weekly on on-time dispatch. Have you done that kind of reporting?" | JD | [grounded] the advert's line, "report weekly on on-time dispatch" | Answer slot: if you produced a regular report on deliveries or dispatch, say what it measured and who read it. If not, say so and say what you would report first. | F5 has no quote, so the pack writes no claim about reporting. |
| S10 | "Discrepancies fell by about a third. How did you measure that?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: say how the discrepancies were counted, in your own words. Name the assumption behind the figure you would defend least, before they ask. If you cannot say how it was counted, say so, and say you would want the figures before you quote them. | F4: a figure on your own history is a probe target. Nothing in the material gives a baseline, so the pack does not supply one. |

### Conversational / rapport (weight: light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you got into logistics coordination." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." | A story from your sentences, about 90 seconds: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip; rebuilding the stock-count spreadsheet. Your own words. | The rapport opener. Casual questions are still scored, so keep it short and factual. |
| C2 | "What do you do when an order is running late?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Say what you do first when an order slips, then what you do with the supplier, in your own words. If you'd rather describe your usual routine than one case, say so. | Covers the advert's "chase late orders" line (F3). |

## Requirement coverage

| Advert requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | F1, S1 |
| Coordinate production schedules between planning, the warehouse and QA | F2, S8 |
| Track supplier deliveries and chase late orders | F3, C2 |
| Keep stock records accurate | F4, S10 |
| Report weekly on on-time dispatch | F5, S9 |
| Confident with Excel | F6, S7 |
| ERP experience (SAP or similar) a plus | F7, S2 |
| Pay, hybrid pattern, notice period (recruiter's topics) | G1 and S3; G2 and S4; G3 and S6 |
| Reason for move (recruiter's topic) | S5 |

## Reverse questions

1. "What would a strong first three months look like in this role?" Why it lands: it asks about the role's scope, which is the question behind S1 and S8.
2. "Which systems does the team use day to day for stock and production, and is there training on them?" Why it lands: it asks about the SAP gap without raising it yourself.
3. "How is on-time dispatch measured today, and who reads the weekly report?" Why it lands: it asks about F5 in the recruiter's own terms.
4. "Who would I work with most closely between planning, the warehouse and QA?" Why it lands: it tests the team shape she said she would describe.
5. "What happens after this call, and roughly when would I hear?" Why it lands: it covers the next steps she said she would give.

## Sources

- Provided documents: the recruiter's message; the advert; your background, positions and reason for moving, from your brief.
- Search "Quillmoor Diagnostics values": refused (search permission was not granted).
- Search "Quillmoor Diagnostics Avonmouth site operations": refused (search permission was not granted).
- Research tier: L1, searches 0 of 6 (2 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Would have moved the values cheat sheet, which is left out. Refused. |
| 2. Quillmoor interview process, operations coordinator | unavailable | Would have moved the loop structure and persona weights. No call was sent, because search is not available. |
| 3. Quillmoor strategy / recent news | unavailable | Would have moved a grounding brief. The screen does not need one, but search is not available. |
| 4. Hannah Lowther, Quillmoor | skipped | The recruiter's message fixes the agenda. No interviewer read is built for a recruiter. |
| 5. Representative operations coordinator JD | skipped | The advert you supplied fixes the fit snapshot. |

## Upgrade menu

- Your notice period, in your own words → the notice-period row (G3) and bank S6 stop being an answer slot.
- Any work that touched planning, production or QA → F2 and S8 get a sourced sentence.
- How "about a third" was counted, if you know → S10 and F4 get a sourced sentence.
- Search access, or the Quillmoor values page pasted → the values cheat sheet and a grounding brief.
- Your CV → F4 and F6 move from your message to the CV, where a probe can check them.
- A tuesday-dossier.md from job-underwriter → verified evidence and prohibited claims for this pack.

---

Want a live rehearsal? I can play Hannah and push back on the production-scheduling question (S8), since that's the gap most likely to come up.

I can also save a tuesday-dossier.md recording what this prep exposed, for carrying into later sessions.

What's your notice period?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

Recruiter screen, Thursday 2pm, 30 minutes by phone. Interviewer: Hannah Lowther, Talent Partner (recruiter). First version, so no changelog.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored: **VAL** values/behaviour, **EXP** your own history, **JD** the advert's requirements, **CO** company knowledge, **CASE** a live problem. The guidance is scaffolding, not a script. Answer in your own words.

Sections left out on purpose: values cheat sheet (no company values were fetched or pasted, and the round is not values-style), interviewer read (the recruiter's own message sets the agenda), graded deliverables (none declared), delivery coaching (no assessment given).

## Fit snapshot

Sources: "your message" is what you wrote in your brief; "advert" and "recruiter's message" are the text you pasted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler." (your message) | medium | [grounded] | none | Your sentence already gives the years and the title. Nothing inspectable is attached, so expect a probe on the scope of the role. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [inferred] | transferability | Your material shows delivery scheduling across three depots. It does not show production scheduling, planning or QA. Keep the bridge at the scope of the quote. Answer slot: if you have scheduled work across a planning, production or QA team, say how, in your own words; if you have not, say so and stay with the depot deliveries. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | none | Your sentence reaches this in close terms. Expect a probe on how often orders slip and what you did about it. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | none | Your sentence reaches the requirement. The figure is a claim you made, so it raises the defend-the-number slots in S10. |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show any regular reporting. Answer slot: see S9. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | low | [grounded] | discovery | The quote touches a spreadsheet but does not show whether it was Excel or how deep your skills go. Answer slot: see S7. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | low | [grounded] | capability | You have stated the absence of SAP. Words: "I've never used SAP." The in-house stock system is quoted at its own scope. The pack does not call it an ERP. A plus, not a requirement. |
| G1 | Pay: "£38,000–£44,000" (advert) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your figure sits inside the advert's range. This is a stated expectation, not a floor, and the pack does not supply a floor. |
| G2 | "Hybrid: two days a week at the Avonmouth site in Bristol." (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Met on the stated pattern. Your ceiling of three is your own constraint. |
| G3 | "your notice period" (recruiter's message) | none given | none | [grounded] | hard_gate | Your material does not establish your notice period, so the pack does not supply one. Answer slot: see S6. |

## Prohibited claims

Not coached, with the basis for each. Each entry gives its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have SAP or ERP experience" | Negative you stated (F7) | "I've never used SAP." Nothing added. |
| "I coordinated production schedules across planning, the warehouse and QA" | Inflated form of F2 | "I schedule deliveries for our three depots." Pack's observation: the material shows delivery scheduling, not production scheduling. |
| "The drop in discrepancies was down to the spreadsheet alone" | Inflated form of F4 | "discrepancies fell by about a third over a year" after the rebuild, at that quote's scope. Pack's observation: the material does not show what else changed. |

## Persona weights

| Persona | How it shows up in this call | Likelihood | Counter-strategy |
|---|---|---|---|
| Skeptic / knockout checks | Asks the four topics you were told about (pay, notice, days, why you're leaving) as checks, and probes the SAP and production gaps | High. The recruiter named the four topics, and the gaps are visible on your CV | Answer each knockout in one or two sentences. For gaps, say the plain thing first, then the nearest real evidence |
| Conversational / rapport | Opens with your journey and a question about a late order | High. The register is friendly and the call is short | 90-second arc from your own sentences; a plain answer about late orders |
| Pressure | Not in the bank | Low for a recruiter screen | Not rehearsed here |

Reasoning: the relationship prior for a recruiter screen is conversational with a light skeptic. The recruiter's four topics are all knockout checks, so the skeptic bank carries most of the weight. The pack is shorter than a full pack on purpose, because the call is 30 minutes.

## Question banks

### Skeptic / knockout checks (weight: heavy)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Your experience is in building supplies. What makes you think you'd fit a diagnostics manufacturer?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." | Start with the four years and the work in them: you schedule deliveries for three depots and chase suppliers when orders slip. These are the nearest parts of the advert. Answer slot: if you have worked with a planning, production or QA team, say how; if you have not, say so plainly and say the sector is new to you. | F1 meets the first requirement. The sector gap is the probe a skeptic will make. JD because it scores the advert's headline line. |
| S2 | "Do you have SAP or ERP experience?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say the plain thing first: "I've never used SAP." Then the in-house stock system at its own scope. Then how you would learn it, as a plan for your first weeks, not as something you have done. Do not call the in-house system an ERP. | F7 is a capability gap and the advert makes it a plus. An honest answer costs less than a bluff. JD because it scores the advert's ERP line. |
| S3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Give the figure, £42,000. It sits inside the advert's £38,000–£44,000. Do not add a range unless asked. Answer slot: if you have a lowest figure you would accept, decide it before Thursday; if you have not, say only the hope. | G1: pay is a knockout. The number is your own stated constraint. The material gives a hope, not a floor, so the pack does not supply one. |
| S4 | "How do you feel about the hybrid pattern, two days in Avonmouth?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three." | Say two days is fine. If asked about a ceiling, say three is the most you would want. Do not add commute reasons; the material does not contain any. | G2 is your own constraint, so it is high confidence. The recruiter named the hybrid pattern as a topic. |
| S5 | "What's prompting you to look for a move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say the office is closing next year, and the only offer is relocating to Reading, which you don't want. Then stop. Do not add a reason, such as growth, that the material does not carry. | The recruiter asked directly. The honest reason is clean and needs no embellishment. EXP because it is your own history. |
| S6 | "What's your notice period, and when could you start?" | JD | [grounded] "your notice period" (recruiter's message) | Answer slot: state your notice period in your own words, then when you could start. Your material does not establish either, so the pack supplies neither. | G3 is a gate the material is silent on. It is asked of you in this message. |
| S7 | "How confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: name the spreadsheet you rebuilt and what you used it for, in your own words. If you can name specific functions you used, say them. If the spreadsheet was not Excel, say what it was. | F6: the advert asks for Excel and your material shows a spreadsheet but not the tool or depth. The pack asks rather than asserts. |
| S8 | "This role coordinates production schedules across planning, the warehouse and QA. What's your experience there?" | JD | [grounded] "I schedule deliveries for our three depots." | Name the delivery scheduling you do, across three depots. Answer slot: if you have scheduled work across planning, production or QA, say how, in your own words; if not, say so plainly and stay with the deliveries. | F2 is the largest gap and the advert puts it first. **Highest-ROI prep in this pack:** this objection is the most likely to be asked in some form. |
| S9 | "The role reports weekly on on-time dispatch. Have you done that kind of reporting?" | JD | [grounded] the advert's line, "report weekly on on-time dispatch" | Answer slot: if you produced a regular report on deliveries or dispatch, say what it measured and who read it. If you did not, say so and say what you would report first. | F5 has no quote, so the pack writes no claim about reporting. |
| S10 | "Discrepancies fell by about a third. How did you measure that?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: say how the discrepancies were counted, in your own words. Name the assumption behind the figure you would defend least, before they ask. If you cannot say how it was counted, say so, and say you would want the figures before you quote them. | F4: a figure on your own history is a probe target. Nothing in the material gives a baseline, so the pack does not supply one. |

### Conversational / rapport (weight: light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you got into logistics coordination." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." | Story from your sentence, about 90 seconds: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip; rebuilding the stock-count spreadsheet. Use your own words. | The rapport opener. Casual questions are still scored, so keep it short and factual. |
| C2 | "What do you do when an order is running late?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Say what you do first when an order slips, then what you do with the supplier, in your own words. If you prefer to describe your usual routine rather than one case, say so. | Covers the advert's "chase late orders" line (F3). |

## Requirement coverage

| Advert requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | F1, S1 |
| Coordinate production schedules between planning, the warehouse and QA | F2, S8 |
| Track supplier deliveries and chase late orders | F3, C2 |
| Keep stock records accurate | F4, S10 |
| Report weekly on on-time dispatch | F5, S9 |
| Confident with Excel | F6, S7 |
| ERP experience (SAP or similar) a plus | F7, S2 |
| Pay, hybrid pattern, notice period (recruiter's topics) | G1, S3; G2, S4; G3, S6 |
| Reason for move (recruiter's topic) | S5 |

## Reverse questions

Ask two or three. Each is there for a reason.

1. "What would a strong first three months look like in this role?" Why it lands: it asks what the role's scope is, which is the question behind S1 and S8.
2. "Which systems does the team use day to day for stock and production, and is there training on them?" Why it lands: it asks about the SAP gap without raising it yourself.
3. "How is on-time dispatch measured today, and who reads the weekly report?" Why it lands: it asks about F5 in the recruiter's own terms.
4. "Who would I work with most closely between planning, the warehouse and QA?" Why it lands: it tests the team shape the recruiter said she would describe.
5. "What happens after this call, and roughly when would I hear?" Why it lands: it covers the next steps she said she would give, and it closes the call cleanly.

## Sources

- Provided documents: the recruiter's message; the advert; your background, positions and reason for moving, from your brief.
- Search "Quillmoor Diagnostics values": refused (search permission was not granted).
- Search "Quillmoor Diagnostics Avonmouth site operations": refused (search permission was not granted).
- Research tier: L1, searches 0 of 6 (2 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Would have moved the values cheat sheet, which is left out. Refused. |
| 2. Quillmoor interview process, operations coordinator | unavailable | Would have moved the loop structure and persona weights. No call was sent, because search is not available. |
| 3. Quillmoor strategy / recent news | unavailable | Would have moved a grounding brief. The screen does not need one, but search is not available. |
| 4. Hannah Lowther Quillmoor | skipped | The recruiter's message fixes the agenda. No interviewer read is built for a recruiter. |
| 5. Representative operations coordinator JD | skipped | The advert you supplied fixes the fit snapshot. |

## Upgrade menu

- Your notice period, in your own words → the notice-period row (G3) and bank S6 stop being an answer slot.
- Any work that touched planning, production or QA → F2 and S8 get a sourced sentence.
- How "about a third" was counted, if you know → S10 and F4 get a sourced sentence.
- Search access, or the Quillmoor values page pasted → the values cheat sheet and a grounding brief.
- Your CV → F4 and F6 move from your message to the CV, where a probe can check them.
- A tuesday-dossier.md from job-underwriter → verified evidence and prohibited claims for this pack.
