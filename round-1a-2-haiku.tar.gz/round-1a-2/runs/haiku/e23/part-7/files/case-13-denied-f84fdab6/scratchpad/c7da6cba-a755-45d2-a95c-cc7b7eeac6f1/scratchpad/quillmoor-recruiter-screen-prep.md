# Recruiter screen prep: Operations Coordinator, Quillmoor Diagnostics

**Call:** Thursday 2pm, 30 minutes by phone, with Hannah Lowther (Talent Partner). She will ring the mobile number on your application.
**Built from:** the job advert and your background as you described it. No web research was run (tier L0), so nothing here is about Quillmoor beyond the advert.

## Fit snapshot

| Requirement (advert) | Your evidence (quoted from your notes) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| 2+ years in operations or logistics coordination | "4 years as a logistics coordinator at a building-supplies wholesaler" | High | None | Meets it directly. |
| Coordinate production schedules between planning, the warehouse and QA | "I schedule deliveries for our three depots" | Medium | Domain gap | "My scheduling covers deliveries across three depots. I haven't scheduled production or worked alongside QA, but I've coordinated across sites with competing timings." |
| Track supplier deliveries and chase late orders | "I chase suppliers when orders slip" | High | None | Meets it directly. |
| Keep stock records accurate | "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year" | High | None | Strongest match. Say what you did and what changed. |
| Weekly on-time dispatch report | Not in your notes | Unknown | Evidence gap | "I haven't owned a weekly dispatch report." Only say this if true. Ask what it involves before you claim anything. |
| Confident with Excel | "I rebuilt our stock-count spreadsheet" | Medium | Evidence gap | The spreadsheet work supports this. Your own level of Excel (formulas, lookups, pivots) is not in your notes. |
| ERP (SAP or similar) a plus | "Never used SAP. We run our own in-house stock system." | Medium | Tool gap | "I haven't used SAP. I've worked in our in-house stock system, so I know how stock records and orders flow through one." |

**Prohibited claims (this pack will not coach these):**
- Any SAP or other ERP experience.
- Any production planning, QA or manufacturing experience.
- Any owned weekly dispatch reporting, unless you confirm it.
- Crediting the stock improvement to anyone but you, or claiming the full one-third reduction as yours alone. Say "I rebuilt the spreadsheet, and discrepancies fell by about a third over a year."

## Answer guidance for the four topics

**1. Salary expectations**
- Likely question: "What are you looking for?"
- Suggested answer: "I'm hoping for around £42,000."
- Why: the advert's band is £38,000–£44,000, so £42,000 sits in the upper half.
- If she pushes back: "Is there flexibility within the band?" Don't go below £38,000 unless you've decided that.
- Not covered: your current salary. If asked, decide your answer before the call.

**2. Notice period**
- Likely question: "What's your notice period?"
- Your notes don't include this. Answer it from your contract before Thursday.

**3. Hybrid pattern**
- Likely question: "The role is two days a week at Avonmouth. How does that work for you?"
- Suggested answer: "Two days at Avonmouth works. I'm in north Bristol, so it's a practical commute. I'd want to stay at no more than three days a week."
- Why: this states your real limit as a clear boundary, not a complaint.

**4. What's prompting the move**
- Likely question: "Why are you looking to move?"
- Suggested answer: "Our Bristol office is closing next year. The only option offered is relocating to Reading, which doesn't work for me. I'm looking for a role in Bristol."
- Why: it is true, brief, and doesn't criticise your employer. Don't add more than this.

## "Tell me about yourself"

"I've spent four years as a logistics coordinator at a building-supplies wholesaler. I schedule deliveries for three depots and chase suppliers when orders slip. The part I'm proudest of is rebuilding our stock-count spreadsheet: discrepancies fell by about a third over a year. I'm looking for an operations role in Bristol where I can keep stock and orders accurate and coordinate across teams."

Keep this to about 60 seconds. Change any sentence that isn't true for you.

## Handling the gaps

- **No SAP:** "I haven't used SAP. I've used our in-house stock system, and I'm comfortable learning another system." (Only say "comfortable learning" if you are.)
- **No production planning or QA:** "I haven't worked in production planning or QA. What I do bring is scheduling across sites and keeping stock records accurate, which I think overlaps with what you described."

## Questions to ask Hannah

1. "What does the weekly on-time dispatch report involve, and who owns it today?"
2. "Which system does the team use for stock and orders, and is there training for it?"
3. "Who would I work with day to day, and what's the next step after this call?"

## Upgrade menu

- **Notice period** (unlocks the notice answer).
- **Current salary and how you'd answer if asked** (unlocks a prepared answer).
- **Your Excel level** (unlocks a specific Excel claim).
- **Any dispatch-report experience** (unlocks a bridge for the dispatch line).
- **Company research on Quillmoor** (deep research offer, not run; would cover recent news, the team, and any published values).
