# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

**Role:** Operations Coordinator, Quillmoor Diagnostics (Avonmouth, Bristol; hybrid, two days a week)
**Interviewer:** Hannah Lowther, Talent Partner (recruiter). Relationship: recruiter screen, 30 minutes by phone, Thursday 2pm.
**Changelog:** first version.

## 2. How to use + type key

Personas are how a question is asked. Types are what it scores.

- **EXP**: whether what you did is what you say you did.
- **JD**: whether you meet the listed requirements, including the gaps.
- **VAL**: values fit. Not used here (see section 6 note).
- **CO**: company knowledge. Not used here (no research ran).
- **CASE**: a live problem. Not used here.

This guidance is scaffolding, not a script. Say it in your own words.

## 4. Fit snapshot

Requirements come from the advert, quoted. Evidence comes from your message, quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | No gap. Say it as written: four years as a logistics coordinator. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | transferability | Your material shows scheduling deliveries across three depots, not production schedules, and not QA. Say the deliveries, in those words. Answer slot: if you have set or changed schedules for production or QA, say how, in your own words; if not, say so plainly and stay with the depot deliveries. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | high | [grounded] | none | Reaches the requirement in role terms. Say it as written. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | none | The quote reaches the requirement. Say what you rebuilt and what the discrepancy figure was. Your material does not show how the figure was counted. |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show a dispatch measure or regular report. Answer slot: if you have reported any delivery or dispatch measure on a regular basis, say what it measured; if you have not, say so and say what you would report first. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | discovery | The quote touches the requirement without showing whether it reaches it. Answer slot: say which Excel features you used to build it, in your own words; if you are rating your own confidence, say so. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | You stated the absence. Plain acknowledgment: "Never used SAP." Your material describes an in-house stock system you run; it does not say whether that counts as an ERP. |

Gate rows: the advert names no eligibility gate. Location and hybrid days are stated as met in your message ("two days at Avonmouth is fine"). Right to work and notice period are not in the advert; see the upgrade menu.

Pack's own observation (analysis, not words for you): your material shows deliveries and supplier chasing, a stock-count rebuild, and four years of coordination. It does not show production scheduling, QA, dispatch reporting or ERP use.

## Section 13. Prohibited claims

Built locally from the fit snapshot. Claims a candidate tends to reach for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed production schedules | Inflated form of F2 | "I schedule deliveries for our three depots." Limit as analysis: the material shows deliveries, not production. |
| Has ERP or SAP experience | Negative you stated, F7 | "Never used SAP." No slot on SAP itself. |
| Cut discrepancies by a third | Inflated form of F4 | "Discrepancies fell by about a third over a year" after you rebuilt the sheet. The sentence does not say the rebuild was the only cause. |

## Section 8. Persona table

| Persona | How it shows up here | Likelihood (reasoning) | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Opens with "tell me about yourself", then moves to salary, notice and hybrid | Heavy. Recruiter screens are logistics and knockout checks in a friendly register. Weight 5. | Prepare a 90-second arc; treat casual questions about the advert as scored. |
| Skeptic (light) | Probes the SAP gap, the production gap and why you are moving | Moderate. The advert's plus-list and your stated gap are the likely probes. Weight 3. | Hold the SAP answer through two follow-ups; concede the gap plainly. |

Weights are shown reasoning, not a hidden score. Depth follows weight. The pack is shorter than the usual session-pack target (about 18 questions) because a 30-minute recruiter screen covers logistics. If you want more coverage, send the notice and any other topics Hannah plans.

## Section 9. Question banks

### Bank A: Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me a bit about your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip." | Ninety-second arc: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for three depots; you chase suppliers when orders slip; you rebuilt the stock-count sheet. Say it in your own words. | F1 and F3 are the opening evidence. Open prompt; no event is supplied. |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Give the figure first: "I'm hoping for £42,000." Then ask what band the role sits in. The advert says £38,000–£44,000. | Knockout logistics question for this round. JD type because the advert sets the band. |
| A3 | "What's your notice period?" | JD | [generic] (no candidate sentence in your material) | Answer slot: say your contractual notice period in your own words. Your material does not give it. | Logistics check. Upgrade menu asks for it. |
| A4 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine" | Two days at Avonmouth is fine. Say it as written. Do not add commute times; your material gives none. | Hybrid is a stated requirement; your sentence meets it. |
| A5 | "What's prompting you to look for a move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say the office is closing next year and the only offer is a move to Reading, which you do not want. Stop there. Do not criticise the employer. | Motivation check. The sentence is the whole answer. |
| A6 | "The advert asks for SAP or similar. Have you used either?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain: "Never used SAP." Then describe the in-house stock system in your own words. Answer slot: if you have used any other ERP module, say which; if not, say so and move to what you would do. | F7. This is the probe most likely to be asked. |
| A7 | "How confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Name the spreadsheet you rebuilt. Answer slot: say which Excel features you used, in your own words; if you are rating yourself, say so. | F6. Do not claim features your material does not show. |
| A8 | "The role sits between planning, the warehouse and QA. Have you coordinated production schedules?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Nearest is scheduling deliveries across three depots. Answer slot: if you have set or changed production or QA schedules, say how; if not, say so and stay with deliveries. | F2. The question presupposes a practice the quote does not carry, so the second branch is required. |
| A9 | "Have you reported on-time dispatch to anyone?" | JD | [generic] (no candidate sentence in your material) | Answer slot: if you have reported a delivery or dispatch measure regularly, say what it measured; if not, say so and say what you would report first. | F5. Silence in the material, so this is a slot. |

### Bank B: Skeptic, light (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is delivery scheduling at building depots. What's the link to a diagnostics plant?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Name the shared mechanic: dates, suppliers and chasing late orders. Answer slot: if you have worked to a regulated or QA process, say so; if not, say you are learning it. | F2. Tests whether you overstate the link. |
| B2 | "The role needs ERP experience and you haven't used SAP. What would you do in your first 90 days?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | **Highest-ROI prep in this pack.** Hold: "Never used SAP." Then describe the plan as a plan: learn the system's stock and order screens, and shadow someone who runs it. Hold through two follow-ups by returning to the plan. Concede specifically: you would be learning ERP from scratch. | F7 and the likeliest probe. The plan is future tense; never describe past SAP work. |
| B3 | "The band is £38,000–£44,000. Is £42,000 firm?" | JD | [grounded] "I'm hoping for £42,000." | Say it is your target. Answer slot: if there is a figure below £42,000 you would accept, say it yourself; your material does not give one. | Pressure on salary. Do not invent a floor. |
| B4 | "Could you manage three days a week at Avonmouth?" | JD | [grounded] "I wouldn't want more than three." | Two is fine; three is your ceiling. Say it plainly. | Tests the hybrid limit you stated; the question goes past A4. |
| B5 | "Where would you want to be in two years?" | EXP | [generic] (no candidate sentence in your material) | Answer slot: say what you want from the next role in your own words. Your material does not show it. | Motivation consistency. |

## Section 11. Reverse questions

1. "What does a typical week look like for this role, across planning, the warehouse and QA?" Why it lands: shows you read the production-scheduling line in the advert.
2. "How is on-time dispatch measured today, and what does the weekly report get used for?" Why it lands: links to the weekly report requirement.
3. "Which stock or ERP system does the team use day to day, and how do new starters learn it?" Why it lands: turns the SAP gap into a question about onboarding.
4. "How does the hybrid pattern work in practice: which two days, and is that fixed?" Why it lands: checks your stated two-day limit against the real pattern.
5. "What happens after this call, and who would I meet next?" Why it lands: covers next steps, which Hannah said she would give you.

## Section 14. Sources

Provided documents:
- The advert for Operations Coordinator, Quillmoor Diagnostics (text in your message).
- Hannah Lowther's LinkedIn message confirming the call (text in your message).
- Your background note (text in your message).

Searches: two were sent, `Quillmoor Diagnostics values` and `Quillmoor Diagnostics interview process operations coordinator`. Both were refused: the search tool needs permission, and none was granted. No results came back.

**Research tier: L1, attempted; 0 of 6 searches returned results, 0 of 2 fetches.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Would have moved the values section. No values section is in this pack; no values round is established. |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Would have confirmed the loop. The pack uses the round Hannah described, a recruiter screen. |
| 3. `Quillmoor Diagnostics strategy` / recent news | skipped | No competitive-strategy questions were needed for a recruiter screen. |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Search refused, so no query ran. Would have moved the interviewer read, which is omitted. |
| 5. representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot. |

Unattributed results: none. Nothing from memory about Quillmoor's values, loop or strategy has been used.

## Upgrade menu

- Your notice period → fills question A3 and its logistics check.
- Your right to work status in the UK → confirms it is not a gate. The advert is silent on it; Hannah may ask.
- Permission to run web search, or the text of Quillmoor's careers or values page → company values, the interview loop, and a values section if one is established.
- Your Excel details (which features, what the sheet does) → upgrades F6 from a slot to a grounded answer.
- Any dispatch or delivery measure you have reported (even informally) → upgrades F5 and A9.
- Hannah's pre-call email with any pre-declared exercise → coverage of that exercise. None has been stated.
- A deeper research pass would need search permission first. Same caps as before: up to six more searches and two more fetches, several minutes. Want it once search is granted?
