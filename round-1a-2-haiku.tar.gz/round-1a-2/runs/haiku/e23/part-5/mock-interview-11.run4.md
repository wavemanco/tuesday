I haven't built the prep pack yet. This message has several signs of a recruitment scam, and I'd rather flag that before you spend time preparing or share anything.

**Why this looks suspicious**

- **Unsolicited contact from an unknown number**, with a vague "found your profile online" and no company named.
- **The whole process runs over WhatsApp, with no calls or video.** Legitimate recruiters almost always use email or phone, and usually a video interview.
- **Fast-tracked to an interview tomorrow**, with no earlier screening.
- **"Remote, flexible hours" plus "through to your contract" on WhatsApp** is a common pattern for scams. They move quickly so you don't have time to check.

Applying for lots of jobs does make a message like this more plausible. But a real agency consultant will name the company and the role, and will be fine with you checking them out.

**Before you share anything or prepare further**

1. **Ask Jess for the company name, the job title, the agency name, and the job reference.** Don't accept "I can't say yet."
2. **Check the company independently.** Find its official website yourself, not from the message, and look for the role on its careers page. Call its main switchboard from the official site if you're unsure.
3. **Check Jess.** Search for the name and agency on LinkedIn and the agency's official site. Look at how long the profile has existed and whether the agency is real.
4. **Don't send ID, passport, bank details, National Insurance or SSN numbers, or a photo of documents** until you've verified everything through official channels.
5. **Never pay anything.** That includes training fees, equipment or "onboarding" costs, and "placement" fees. Also refuse requests to buy gift cards or crypto, to receive and forward parcels or money, or to deposit a cheque.
6. **Don't sign a contract** that hasn't come from a verified company through its official process.

**If it checks out, I can build the prep pack.** I need:

- **The company and the exact job title** (the skill can't run without them)
- **The job advert or description**, if you have it, and **your CV or a short summary of your background**
- **Whether this is a screening call with the consultant or an interview with the hiring manager**, and whether the agency has given any focus areas or tasks

Send me the company name and role title first. If Jess can't or won't name the company, I'd treat that as a reason to decline the interview.