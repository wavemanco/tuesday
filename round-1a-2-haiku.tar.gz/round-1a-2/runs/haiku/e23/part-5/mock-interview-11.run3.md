I haven't started the mock-interview prep yet. This message has several hallmarks of a recruitment scam, so I'd check it before you spend time rehearsing.

**Red flags:**
- **Interview only over WhatsApp, with no call or video.** Legitimate recruiters almost always do at least a phone or video screen, especially for a remote role.
- **Unsolicited contact from an unknown number,** with generic flattery ("we found your profile online") and no named company or job title.
- **Fast-tracking:** an interview tomorrow, and the whole hiring process, including the contract, handled in chat.
- **"Flexible hours" and "remote" with no details** about the work, pay, or employer.

Scammers often use this setup to collect ID documents, bank details, or personal data, or to ask you to pay for "training", equipment, or a background check. Don't send any of those.

**Checks you can do today:**
1. **Ask Jess** for the company name, the job title, the job posting link, and a phone or video call before tomorrow. A real recruiter will answer these readily. Evasion or pressure to stay on WhatsApp is a bad sign.
2. **Check whether you actually applied.** Look through your application history on the job boards you used. If the role isn't there, be wary.
3. **Verify the company yourself.** Find its official website and phone number through a search, not through the message, and ask whether it's hiring for this role and whether it uses an outside recruiter called Jess.
4. **Search the phone number** and the phrase "Jess recruitment consultant WhatsApp interview" to see if others have reported the same pattern.
5. **Check the recruiter on LinkedIn.** Look at how long the profile has existed, its connections, and whether it's linked to the company.

If Jess can't give you a company name you can verify, or won't do a call or video, I'd treat this as a scam and not reply with personal details.

If it checks out, send me the job advert or description, the company name, and your CV, and I'll run the mock-interview prep: likely questions, answer guidance, and some practice rounds in which I play the interviewer.