Before we prep, I'd check this recruiter first. The message has several common job-scam markers:

- **Unsolicited contact** from an unknown number, citing a profile "found online," with no role or company named.
- **Remote work with flexible hours**, a standard lure in these scams.
- **The whole process on WhatsApp**, including the contract, with no call or video. Real employers almost always use email and a company domain.
- **A next-day interview** booked without you having chosen a time.

Scammers in this pattern often later ask for ID or bank details "for payroll," or for money for equipment or training. Don't send any of that until you've verified the company.

To check it:

1. **Ask Jess for the company's full legal name, the exact job title, and the job-board link** where the role was posted. A real recruiter can answer this at once.
2. **Look up the company yourself**: find its official website and its registered entry (Companies House in the UK, or your national equivalent). Contact them through the details on that official site, not through the WhatsApp number.
3. **Check the recruitment firm** by searching its name with "scam" or "reviews," and confirm the consultant on LinkedIn.

If the company checks out, reply and we'll build the prep pack. The pack needs at least the company and role title. Then I'd like three things:

1. **The company and exact role title**, plus the job-posting link or the full job description if you have it.
2. **Your CV or a few bullet points on your recent work**, so the answers are built on what you actually did.
3. **Who the interview is with and what kind it is**, for example a recruiter screen or a hiring-manager call. If you don't know, say so and I'll assume a first-round screen.

If the company can't be verified, I'd suggest not going to the interview. I can still help you draft a polite reply that asks for the details above.