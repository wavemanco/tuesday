Before we prep, I'd check this message carefully. It has several common signs of a recruitment scam:

- **Unsolicited contact** from an unknown number, saying they "found your profile online."
- **Vague job details**: "remote position with flexible hours," and no company name or role title.
- **Interview and contract entirely over WhatsApp**, with no calls or video. A real employer will usually do at least one call or video interview.
- **Urgency**: an interview "tomorrow at 11am."

Scammers use this pattern to collect personal data (passport, bank details, National Insurance or tax numbers) for identity theft, to get you to pay "training," equipment, or background-check fees, or to recruit you into moving money through your account. Your applications may have been posted to job boards that scammers also trawl, so this could still be a real lead, but treat it as unverified until you've checked.

**Before you reply or share anything, you could:**

1. **Ask for the company's full legal name, the role title, and the job posting link.** A real consultant will answer readily.
2. **Verify the company independently.** Look up its website and official contact details yourself, not the ones in the message. In the UK, check Companies House; elsewhere, use the relevant business registry.
3. **Check the consultant.** Search their name with the agency name on LinkedIn, and see whether the agency has a real website and history.
4. **Reply on your own terms.** Ask for a video or phone call through a company email address before tomorrow. If they refuse, or you're asked to pay anything or send ID or bank details, stop.
5. **Never send** money, bank details, or copies of ID or documents before you've verified the employer and have a written offer.

If you can tell me the company name, the role, and where you saw the job advertised, I can help you check what's findable and then prep you properly. For the prep itself, I'll use the mock-interview skill with your CV and the job description. Once you've confirmed this is a real role, it's worth sharing those, along with the questions you expect them to ask, so the prep matches the actual interview.