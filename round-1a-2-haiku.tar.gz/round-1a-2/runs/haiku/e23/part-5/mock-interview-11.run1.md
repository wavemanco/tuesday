I'd hold off on the interview. Several things in that message match common job scams, and I haven't run the prep skill yet because a useful prep pack needs the company, the role, and your CV.

**Why it looks like a scam:**
- **No calls or video at all.** Legitimate recruiters almost always do at least a phone or video screen, and usually a company video interview.
- **Everything through to the contract on WhatsApp.** Real contracts come from a company email or HR system, not a chat app.
- **Vague details.** She doesn't name the company, the agency, the job title, or the pay.
- **"Found your profile online" plus a fast interview** the next day is a common opener. Applying to lots of jobs doesn't mean this is one of them.
- **Remote, flexible hours, and a good offer** is the typical bait.

Scams like this often go on to ask for your ID, bank details, or National Insurance/Social Security number early. They may also ask you to pay for equipment or training, deposit a cheque and send back part of it, or buy gift cards or crypto.

**What I'd do:**
1. **Don't send personal or financial details, click links, or pay anything** until you've verified her.
2. **Ask for specifics:** the company name, the job title and reference number, the agency name, and where she saw your application.
3. **Check independently.** Look up the company and agency yourself (official website, LinkedIn, the registry for the company). Don't use the contacts she gave you. Check whether the job is on the company's careers page, and confirm she works there.
4. **Ask for a call or video** with the company's own email address.
5. **If it's a scam, block the number and report it** in WhatsApp, and report it to your local fraud service (in the UK, Action Fraud; in the US, reportfraud.ftc.gov).

Here's a reply you could send her:

> "Thanks, Jess. Before I go further, could you send me the company name, the job title and reference, and the agency you work for? I'd also like a short video or phone call with someone from the company, and I'll need to confirm the role through their official careers page."

If the company and role check out, send me the job description and your CV, and I'll run the full mock-interview prep. I can also start with general practice questions for a remote role now if that would help.