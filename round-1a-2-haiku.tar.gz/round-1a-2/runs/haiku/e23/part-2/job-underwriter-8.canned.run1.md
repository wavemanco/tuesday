**Verdict: don't apply, and send nothing. This is a scam.** Stop replying to @VellowayHiring.

**Why**

- **Payment for a job.** Legitimate employers don't ask you to pay for your own work equipment, and "refunded with your first wages" is a common lure.
- **Fake cheque.** Sending you a €2,850 cheque, asking you to keep €350 and forward the rest to a third party is a classic overpayment scam. The cheque would likely bounce after you'd already sent real money, and you would owe the bank the difference.
- **Sensitive documents before any interview.** Asking for your IBAN, PPS number and passport photo at the screening stage gives someone enough to commit identity fraud. A real employer asks for these only after an offer, through its own HR system.
- **Telegram-only hiring with no calls or video**, and a contact address that isn't tied to a named company domain.
- **Pay that doesn't add up.** "Up to €26/hour" is a ceiling, and the commission is unspecified. At €26/hour you'd need about 22 hours a week to reach €30,000 a year, and only with no commission and no unpaid gaps. At 15 hours it's roughly €20,000.

**Your fit.** Your background (60 Zendesk tickets a day, training new starters, an Excel tracker) matches real remote ops and support roles well. That's also why a posting like this may target you. Look for roles at €30,000+ with a named employer, a salary range and a normal interview process.

**What to do now**

1. **Send nothing.** No IBAN, PPS number, passport photo or money. Don't lodge any cheque.
2. **If you've already sent anything,** contact your bank now, tell them it's a suspected fraud, and watch your accounts. If you shared your PPS number or passport, consider reporting to the Gardaí and monitoring for identity misuse.
3. **Report the listing** to the job site and block the Telegram account.
4. **Find real openings** through employers' own career pages, and verify any recruiter through the company's official site or a phone number you look up yourself.

Research tier: L0, no searches. I haven't checked whether Velloway Logistics exists. The verdict doesn't depend on that. If you want, I can look for its official site or company registration next (one search, within the limits you've set).

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.