**Decision: no-go. Don't apply further, and don't send anything to @VellowayHiring.**

This is a fake-job scam. The pattern is one of the best-documented ones.

- **The cheque.** You'd deposit €2,850, keep €350, and send the rest to a "partner." The cheque is almost certainly fake. Banks often credit a deposited cheque provisionally, then reverse it when it bounces, and the money you forwarded is gone and debited from your account. You'd also be the person moving the money, which is the money-mule risk.
- **The €349 "equipment" payment.** Legitimate employers supply their own equipment. Requiring a payment before the first wage is the hallmark of advance-fee fraud, and the promised refund is the bait.
- **The IBAN, PPS number and passport.** Asking for these before any interview, over Telegram, is identity theft in progress. A real employer collects them later, through a formal contract and onboarding, not in a chat.
- **The process.** No calls, no video, Telegram only, "passed the screening" within days, and an unverified email domain (postmail.example is not a company domain). "No experience needed" plus unusually high pay for the work is another common lure.
- **The pay.** Even taken at face value, €26/hour for 15–30 hours a week is €20,280–€40,560 a year before commission. Reaching your €30,000 floor needs about 23 hours a week at full rate, and the posting doesn't say what commission would be.

**Before you do anything else:**
- Don't paste your IBAN or send your PPS number or passport anywhere in this conversation.
- If you've already sent any of those details or paid anything, call your bank's fraud line now. Ask them to flag the account and check any recent transfers.
- Report the posting and the Telegram account to the Gardaí (or the Garda National Cyber Crime Bureau) and to the jobs site.

**What I checked:** I worked only from what you pasted. I ran no web searches on Velloway Logistics, so I haven't confirmed whether the company exists. The verdict doesn't depend on that, since the payment and cheque requests alone are disqualifying.

**Your background** fits roles like this well: Zendesk volume, parcel-courier operations, training new starters, and Excel trackers. Those skills are worth pointing at real postings on sites where you can verify the employer. If you paste one, I can run the same check on it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.