**No, this isn't a legitimate job. Don't send anything, and don't paste your IBAN.** I didn't run any web checks. This assessment rests on the posting and messages you pasted, but the pattern is a well-known scam.

**Red flags:**
- **Telegram-only hiring, with no call or video.** A real employer's recruitment can be done on Telegram, but no interview at all is a warning sign.
- **Requests for your IBAN, PPS number and passport before any interview.** Nobody legitimate needs these to start a conversation. They are enough to commit identity fraud and to take money from your account.
- **Paying €349 for "equipment" that you'd be refunded from wages.** Real employers supply equipment. Asking a new hire to pay a third party is the classic setup.
- **The cheque.** They send you €2,850, you deposit it, keep €350, and transfer the rest to their "equipment partner." Cheques can take days to be flagged as fraudulent, and you're liable for the money you've sent out. You would end up owing the bank the full amount.
- **A generic HR email address** (velloway.hr@postmail.example), a free-mail-style domain, and no verifiable company presence in what you've shown me.

**What to do now:**
1. **Don't send anything else.** Don't send the IBAN, PPS number, passport photo, or any money, and don't deposit any cheque.
2. **Stop replying** and block or mute @VellowayHiring. You don't owe them an explanation.
3. **If you've already sent details**, contact your bank's fraud line now and ask about monitoring or closing the account. If you shared your PPS number, you can also tell the Department of Social Protection. Report the scam to the Gardaí, either at a station or through their online reporting.

**For your job search:** your background is a good fit for legitimate customer service and operations roles. You have three years of Zendesk-based ticket handling at volume, you've trained new starters, and you maintain a tracker in Excel. A real employer will:
- Use a company email domain and let you verify it on their website
- Interview by video or phone
- Pay you, not ask you to pay them
- Be happy to answer questions about the role, pay and contract before any personal documents are shared

If you paste a job you're considering, I can assess the role and fit properly, and check it against those signs.