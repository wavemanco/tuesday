**Decision snapshot: `no_go`.** Do not send your IBAN, PPS number, passport photo, or any money. This posting has the hallmarks of a recruitment scam that uses fake job offers to take your bank details and to recruit people to move stolen money.

**Hard gates:** None of the role's terms can be verified as legitimate. The pre-hire requests for banking, tax and identity documents are the failed gate. [grounded: the messages request these before any job exists.]

**Fit ledger (secondary, since the employer is unverified):** Your background matches the posted requirements well. Zendesk at about 60 tickets a day, training two starters, and keeping a weekly Excel tracker map onto "attention to detail", "confident with spreadsheets" and "no experience needed" in the posting. [grounded from your account; CV-only, so these are leads, not verified evidence.] Written English and a quiet workspace are not evidenced either way.

**Research tier: L0, no searches.** I have not checked whether Velloway Logistics exists. The analysis below rests only on the posting and messages you pasted.

**Evidence status**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | skipped | No search run; research not yet consented |
| 2 | Role-family sweep (pay and scope for this seniority) | skipped | No search run; research not yet consented |
| 3 | Hiring manager's public footprint | n/a | Only a Telegram handle was given; no person's name |

**Risk register (opportunity ledger)**

| Class | Severity | Finding |
|---|---|---|
| Red flag | Critical | Asks for IBAN, PPS number and passport photo before any interview or offer. [grounded] |
| Red flag | Critical | Asks you to pay €349 for equipment to a third party, with a refund promised later. [grounded] |
| Red flag | Critical | Sends a €2,850 cheque, asks you to deposit it, keep €350, and forward the rest to a "partner" before the cheque clears. This is the classic overpayment scam. Cheques can take days to clear and are often returned as fraudulent, after the money you sent has gone. [inferred] |
| Red flag | High | Hiring runs only on Telegram, with no calls or video, and the "interview" was a chat. [grounded] |
| Red flag | High | Contact is a generic mail domain (`postmail.example`), not a company domain. [grounded] |
| Mismatch | Medium | "Up to €26/hour" at 15–30 hours a week gives €390–€780 a week before commission. Reaching your €30,000 floor needs about 22 paid hours a week at the top rate, and the commission is unquantified. [grounded arithmetic from the posting; the commission and whether any rate is paid are unknown] |

**Application plan:** Don't apply through this channel. If you want to keep looking, use the employer's own careers page or a reputable job board, and treat any "pay first" or "forward the money" step as a stop sign.

**What to do now**

1. Don't send anything to @VellowayHiring or to velloway.hr@postmail.example, and don't paste your IBAN into the chat.
2. Don't deposit the cheque or move any money if one arrives. Tell your bank before you do anything with it.
3. Report the Telegram account to Telegram, and report the listing to the job site.
4. If you've already sent details, contact your bank now to flag the account and ask about a payment recall. Report the incident to the Gardaí (non-emergency 101, or your local station).

**Dossier offer:** At the end of the engagement I can write a `tuesday-dossier.md` file with this assessment, if you want it for your records.

**Upgrade menu (what more input would add)**

- A link to the live posting or the company's own careers page would let me test whether Velloway Logistics exists as described (needs L1 research).
- A check on typical pay for an entry-level remote customer-operations role in Ireland would turn the €26/hour figure into a real comparison (L1 role-family sweep).
- The recruiter's full name, if you have it, would support the hiring-manager check. Only public professional information would be used.

**Questions**

- Would you like me to run the L1 research now (up to 5 searches and 2 page fetches) to check whether Velloway Logistics exists?
- Would you like help drafting a short reply that declines the offer and asks for a company email and a verifiable address?

You can answer either question, or skip them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.