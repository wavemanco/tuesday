**Decision: no_go.** Don't send anything to @VellowayHiring. That means no IBAN, no PPS number, no passport photo, no €349 payment, and no cheque deposit or onward transfer. This is a fake-job scam with a fake-cheque step, and Ciara's real qualifications are the reason it's convincing.

**Decision snapshot**
- Fit (candidate ledger): strong. The customer service, Zendesk volume, training and Excel experience match the posting's requirements. [grounded: from Ciara's stated background]
- Opportunity (opportunity ledger): no_go. The process itself is the problem, not the role.
- Hard gates: none stated for the role. Pay is unclear: "up to €26/hr plus commission" with 15–30 hours is not a salary you can rely on. [inferred]
- Research tier: L0, no searches. I could not verify that Velloway Logistics exists or that this posting is genuine.

**Red flags in the posting and messages** [grounded: from the text you pasted]
1. **Telegram only, no calls or video.** Real employers almost always have a verifiable interview step.
2. **Personal data before any interview.** They asked for IBAN, PPS number and passport photo before the "chat interview". No legitimate employer needs these before an offer, and a passport photo is never needed at that stage.
3. **Pay them for "equipment".** A €349 transfer to an "equipment partner", refunded later, is advance-fee fraud.
4. **The cheque step.** Depositing a cheque and sending most of it on to a third party is a fake-cheque scam. Banks often show funds as available before a cheque clears. When it bounces, you owe the bank the money you sent on, and any personal details you have given can be used against you.
5. **Offer after a chat.** "The job is yours" with no real assessment.
6. **Commission on "orders" for a no-experience role.** Processing orders for commission is a common cover for money-mule or reshipping schemes, which can make you liable in a criminal case. [inferred]
7. **Contact address.** The address given, velloway.hr@postmail.example, is not a company domain. A real employer would use its own domain.

**Pay check** [inferred, arithmetic only]: at €26/hr, 15 to 30 hours a week is roughly €390 to €780 gross a week, about €20k to €40k a year before tax and before any commission. So the pay figure alone does not rule it out. The structure does.

**Application plan (what to do instead)**
- Don't paste your IBAN, PPS number or passport anywhere in this chat or to them.
- Don't pay anything or deposit the cheque if one arrives.
- If you have already sent any of those details: contact your bank now and ask them to flag the account. Ask them about the cheque too if one has been sent. Consider reporting to the Gardaí, and to Telegram (report the account) and the jobs site (report the listing).
- Look for legitimate roles through the company's own careers page, or the Companies Registration Office (CRO) register if you want to check a named employer. A real customer service, operations or support role at €30k+ fits Ciara's background well.

**Dossier offer:** I can write a short `tuesday-dossier.md` to keep this analysis for later.

**Upgrade menu**
- A link to the original listing on the jobs site, or Velloway's own careers page. This would let me check the posting's consistency. [would need L1 research: up to 5 searches and 2 page fetches]
- Confirmation of whether any of your details have already been sent. This decides the urgent steps above.

**Questions**
1. Have you sent @VellowayHiring anything yet, including your IBAN, PPS number, passport photo, or any money? [Answer this first, because it decides what you need to do today.]
2. Do you want me to run L1 research on Velloway Logistics (up to 5 searches and 2 page fetches) to check whether the company exists?
3. Do you want help building a search for legitimate €30k+ customer service, operations or support roles that use Zendesk and Excel?

**Evidence status**
| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company's official site and careers page | skipped | L0: no searches consented |
| 2 | Role-family sweep (pay and scope for this seniority) | skipped | L0: no searches consented |
| 3 | Hiring manager's public footprint | n/a | No name given |

Research tier: L0 — no searches

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.