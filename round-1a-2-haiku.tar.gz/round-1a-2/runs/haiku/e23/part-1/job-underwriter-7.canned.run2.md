## Decision snapshot

**Yes, apply, once the post checks out. Status: `conditional_go`.** Your registration, licence, Halifax base and experience (R1, R2, R3, R4) are met, and your catheter and insulin work (R7a, R9) is direct evidence. The weak rows are the caseload itself (R11), end-of-life visits (R8), Doppler (R13) and the leg-ulcer specifics (R6).

**Fit ledger.**

- `hard_gate`: direct: R1, R2, R3
- `must_have`: direct: R4 · unclear: R5 (clear, timely written records)
- `important`: direct: R7a, R9 · adjacent: R6 (wound care, leg-ulcer care), R7b (continence care), R11 (holding a small caseload) · unclear: R8 (end-of-life visits), R10 (care planning), R12 (electronic patient record)
- `preferred`: absent: R13 (Doppler assessment for leg ulcers)

Matters most: R11, the caseload, where the bridge has a limit; R5, written records, with nothing in the CV; R8, end-of-life visits, with nothing in the CV; R6, the leg-ulcer specifics, where the bridge has a limit.

**Opportunity ledger.** Clear on scope and open about process, but under-specified: the employer is not checked (RR1), the pay basis is unstated (RR2), caseload size is undefined (RR3), and training for end-of-life and Doppler is not mentioned (RR4). One entry runs the other way: the advert offers a direct informal chat before you apply (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the conditions for `go` are (1) the post is live on Calderbrook's own careers page and matches the advert (RR1); (2) the pay basis and a realistic caseload size hold up at the chat (RR2, RR3); (3) you are comfortable learning end-of-life and Doppler in post, or training is confirmed (RR4, R8, R13).

## Role reality

Stage assumed: evaluating.

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, Halifax | `[grounded]` JD header |
| Mandate | District nursing for housebound adults in their own homes; small personal caseload with senior nurse support | `[grounded]` JD |
| Working pattern | Home visits; pool cars provided; mileage paid | `[grounded]` JD |
| Scope read | A small personal caseload with senior support is a normal scope for a Band 5 community post | `[generic]` pattern for the title |
| Pay | £31,050–£37,800 a year plus mileage | `[grounded]` JD |
| Market calibration | Not run at L0. The pay band is not calibrated here, and it is not established whether it is the Band 5 scale | — |
| Unknowns | Caseload size; senior support model; training for end-of-life and Doppler; EPR system; patch area; schedule and on-call; contract type | — |
| Contradictions | None found within the advert | `[grounded]` JD read alone |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Adult registration, active, revalidation March 2028. Self-reported; the register entry is checkable but not yet checked | `[grounded]` CV | Check your register entry before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Full licence, category B; stated, not inspected. Pool cars are provided | `[grounded]` CV | none |
| R3 | Role base in Halifax | hard_gate | direct | medium | none | You live in Halifax. The patch the role covers is not stated | `[grounded]` CV, JD header | none |
| R4 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse, ward then discharge team | `[grounded]` CV | none |
| R5 | Clear, timely written records | must_have | unclear | none | discovery | The CV says nothing about records | `[grounded]` CV silence; `[inferred]` that discharge work involved documentation | Gap queue, R5 |
| R6 | Wound care, including leg-ulcer care | important | adjacent | medium | transferability | Pressure-ulcer and surgical-wound care are direct. Leg ulcers are not named | `[grounded]` CV; `[inferred]` that leg ulcers need their own assessment skills | Gap queue, R6 |
| R7a | Catheter care | important | direct | medium | none | Stated, not inspected | `[grounded]` CV | none |
| R7b | Continence care | important | adjacent | low | transferability | No continence work stated; catheter care is the nearest bridge | `[grounded]` CV; `[inferred]` adjacency from catheter care | Gap queue, R7b |
| R8 | End-of-life visits | important | unclear | none | discovery | Nothing in the CV on end-of-life or palliative care | `[grounded]` CV silence | Gap queue, R8 |
| R9 | Insulin administration | important | direct | medium | none | Stated, not inspected | `[grounded]` CV | none |
| R10 | Care planning | important | unclear | low | discovery | Discharge visits assessed home needs; whether you wrote and owned a plan is not stated | `[grounded]` CV; `[inferred]` that discharge assessment fed a plan | Gap queue, R10 |
| R11 | Holding a small caseload of your own, with senior support | important | adjacent | medium | transferability | You have never held your own caseload (your statement). Bridge: first-week home visits after discharge | `[grounded]` your statement; `[inferred]` discharge visits as the bridge | Gap queue, R11 |
| R12 | Electronic patient record | important | unclear | none | discovery | No EPR system named | `[grounded]` CV silence | Gap queue, R12 |
| R13 | Doppler assessment for leg ulcers | preferred | absent | none | capability | Never done (your statement); no adjacent vascular assessment in the CV | `[grounded]` your statement | Gap queue, R13 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R5 | Written records (R5, must_have) | discovery | Nothing on records in the CV | Essential; the advert says "clear, timely" | A handover or note you wrote under time pressure; a discharge summary you completed | An anonymised note sample, within your employer's rules | `[grounded]` CV silence |
| R6 | Leg-ulcer care (R6, important) | transferability | Pressure and surgical wounds only | Leg ulcers are the core of the caseload | Any venous or leg wound you dressed or assessed; wound-care training | A training certificate or a case you can describe | `[inferred]` leg ulcers need distinct skills |
| R7b | Continence care (R7b, important) | transferability | Catheter care only | Named in the advert alongside catheters | Continence assessments; bladder or bowel care on the ward | A care-plan excerpt | `[inferred]` adjacency |
| R8 | End-of-life visits (R8, important) | discovery | Nothing in the CV | Named responsibility; no training stated | Any end-of-life or palliative contact on the ward or in discharge visits | Training, or an anonymised example | `[grounded]` CV silence |
| R10 | Care planning (R10, important) | discovery | Discharge visits only | The caseload is run through plans | Any plan you wrote or updated after a home visit | An anonymised plan | `[inferred]` |
| R11 | Caseload (R11, important) | transferability | Never held one; first-week home visits | The core of the job; the bridge has a limit | Visits you led from first contact to handover | Visit numbers and what you arranged | `[grounded]` your statement |
| R12 | EPR (R12, important) | discovery | No system named | The advert states all work is recorded on EPR | Any electronic record you used | The system name | `[grounded]` CV silence |
| R13 | Doppler (R13, preferred) | capability | Never done | Desirable, not essential | Any vascular or ABPI assessment | Training, if you have any | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not checked | unknown | — | "Calderbrook Community Health CIC, Halifax" | The post may not be live on the employer's own site; not checked at L0 | `[generic]` pattern for listings of this kind, not a claim about Calderbrook | Can you confirm this post is live on your careers page, and who I would be interviewing with? | unresolved |
| RR2 | Pay basis unstated | unknown | — | "£31,050–£37,800 a year plus mileage" | The range may or may not be the Band 5 scale; not calibrated here | `[inferred]` from the title against an unstated scale | Is this range the Band 5 scale, and where does a new caseload nurse start in it? | unresolved |
| RR3 | Caseload size undefined | unknown | — | "a small caseload of your own" | "Small" has no number, and senior support may vary | `[inferred]` from "small" with no figure given | What is a typical caseload in the first six months, and what does senior support look like week to week? | unresolved |
| RR4 | Training for end-of-life and Doppler not stated | unknown | — | "end-of-life visits"; "Desirable: Doppler assessment" | The role may expect end-of-life competence from the start, with Doppler learned in post | `[inferred]` from responsibilities against no training stated | What training and supervision is given for end-of-life visits and Doppler assessment? | unresolved |
| RR5 | Open route to ask before applying | positive_signal | — | "For an informal chat about the role, contact Rhiannon Mabbott" | The employer offers a direct route to questions before you commit | `[grounded]` advert wording | What does a successful first three months look like for this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check your NMC register entry yourself | see R1 | `[grounded]` CV gives the PIN, which is checkable | proposed |
| P2 | Confirm the post on Calderbrook's own careers page before you apply | see RR1 | `[generic]` a cheap check that prevents effort on a stale post | proposed |
| P3 | Ask RR1, RR2, RR3 and RR4 at the informal chat with Rhiannon Mabbott | the register doubles as interview preparation | `[grounded]` the register | proposed |
| P4 | CV edit: describe your discharge-to-assess home visits in plain terms: visits a week, what you assessed, what you arranged. Use numbers only if you have them | see R11, R10 | `[grounded]` CV | pending your approval |
| P5 | Application wording: use "wound care, including pressure ulcers and surgical wounds", "catheter care" and "insulin administration" as written. Do not mention leg-ulcer work, a caseload or Doppler | see R6, R11, R13 | `[grounded]` CV; reframing audit finds no added claim | pending your approval |
| P6 | Before paying for a Doppler course, check whether Calderbrook trains it in post | see R13 | `[generic]` community employers often train in post | proposed |
| P7 | If you are shortlisted, mock-interview can rehearse the caseload and end-of-life questions | see R8, R11 | sibling skill, named once | proposed |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L0 — no searches; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would have shown whether the employer exists as described and the post is live: RR1 and the first condition for `go`. No lookups were requested |
| 2. Role-family sweep | unavailable | Would have set the Band 5 pay and caseload norms as `[generic]`: RR2 and RR3 |
| 3. Hiring manager's public footprint | unavailable | A name was given (Rhiannon Mabbott, Community Nursing Team Lead). Would have informed positioning only |

## Upgrade menu

I can write this up as `tuesday-dossier.md` if you want to keep it.

- A copy of your NMC register entry, with the PIN redacted if you prefer → R1 to `high`.
- A wound-care training record, or a leg-ulcer case you can describe, anonymised within your employer's rules → R6 moves toward direct.
- Any training record for Doppler or ABPI → R13 moves from absent.
- An anonymised example of a discharge plan you wrote → R10 and R11.
- Your pay floor and schedule limits → the pay and schedule checks the snapshot currently flags as unknown.
- Research at L1: Calderbrook's own careers page and the published Band 5 scale → RR1 and RR2 could resolve. Up to 5 searches and 2 fetches, if you want them.

**Questions**

- **Constraints:** What is the lowest pay you would accept, and are there schedule limits (on-call, weekends, a start date) I should know about?
- **R5:** Give one example of a note, handover or discharge summary you wrote under time pressure. What did it contain, and how long did it take? Leave out anything that identifies a patient.
- **R11:** In your discharge-to-assess work, did you ever follow a patient from first visit to handover? How many visits a week did you carry, and who set your priorities?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.