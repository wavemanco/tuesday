**Yes, worth applying for, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R5, R7 · adjacent: R4, R8, R10 · unclear: R6, R9, R11
- `preferred`: absent: R12

What matters: R4, R8 and R10 are credible bridges with their limits named; R6, R9 and R11 are discovery gaps the CV is silent on; R12 (Doppler) is a desirable skill she has not done.

**Opportunity ledger.** Sound on its posted terms: a community interest company running adult community nursing under an NHS contract, with a named contact and a published pay range. Open points are RR1 (the posting is not confirmed live), RR2 (caseload support is undefined) and RR3 (contract basis is unstated). No severe red flags.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the posting is confirmed live and the post is permanent or fixed-term, stated (RR1, RR3); (2) she can evidence clear, timely written records in interview (R11).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; 410 staff, four locality hubs | `[grounded]` about page, calderbrookhealth.example/about |
| Role | Band 5 community staff nurse in a district nursing team: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, electronic patient record; a small personal caseload with senior-nurse support | `[grounded]` advert |
| Working pattern | Housebound adults in their own homes; pool cars provided; mileage paid | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` advert |
| Market calibration | Community staff nurse, Band 5, England (n=1,240): median £34,300, interquartile range £32,400–£36,600; 61% paid mileage, 24% with a pool or lease car. The advertised range sits around that middle | `[generic]` Wardround 2026 pay guide, wardround.example/2026-uk-community-nursing-pay-guide |
| Unknowns | Caseload size, supervision model, contract basis, whether the posting is still open | — |
| Contradictions | None found between the advert and the employer's about page; the careers page was not reached | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | high | none | PIN 19F4417X, Adult, registration active, revalidation March 2028. Confidence is high on your own confirmed statement; the NMC register is the check | `[grounded]` CV | Optional: check the register entry |
| R2 | Full UK driving licence | hard_gate | direct | high | none | Full licence, category B | `[grounded]` CV | none |
| R3 | At least one year post-registration experience | must_have | direct | high | none | Five years as a staff nurse, acute medical ward. This is a length-of-experience requirement, so it is graded as a must-have, not a gate | `[grounded]` CV | none |
| R4 | Wound and leg-ulcer care | must_have | adjacent | medium | transferability | Pressure ulcers and surgical wounds are direct. Leg ulcers are not stated, so the leg-ulcer part is adjacent only | `[grounded]` CV; `[inferred]` adjacency | Interview probe; do not claim leg-ulcer experience |
| R5 | Catheter care | must_have | direct | medium | none | Stated in CV; the setting is acute, not community | `[grounded]` CV | none |
| R6 | Continence care | must_have | unclear | low | discovery | Not in CV | `[grounded]` CV silence | Gap queue; no claim until asked |
| R7 | Insulin administration | must_have | direct | medium | none | Stated in CV | `[grounded]` CV | none |
| R8 | Care planning | must_have | adjacent | medium | transferability | Home assessments in the discharge-to-assess role are close to care planning; written care plans are not stated | `[inferred]` from the CV | Describe the assessments in interview |
| R9 | End-of-life visits | must_have | unclear | low | discovery | Not in CV; an acute medical ward plausibly includes end-of-life care, but she has not said so | `[grounded]` CV silence | Gap queue |
| R10 | Holding a small caseload with senior-nurse support | must_have | adjacent | medium | transferability | She has never held her own caseload. Home visits with a senior team are the nearest evidence | `[grounded]` CV; `[inferred]` adjacency | Be explicit that the caseload is new |
| R11 | Clear, timely written records; electronic patient record | must_have | unclear | low | discovery | No evidence of records quality or EPR use in CV | `[grounded]` CV silence | Question Q3 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | Never done. Formal training is the usual closure path | `[generic]` closure path | Carried as a minor risk |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R4) | transferability | Pressure and surgical wounds stated; no leg ulcers | Leg-ulcer care is named first in the advert | Any leg-ulcer dressing or compression work on the ward or in the discharge visits | A redacted wound plan or a ward audit entry | `[grounded]` CV |
| G2 | Continence and end-of-life (R6, R9) | discovery | Not stated | Both are must-haves in the advert | Catheter and continence work on the ward; end-of-life care for dying patients on the medical ward | A ward case summary | `[grounded]` CV silence |
| G3 | Written records and EPR (R11) | discovery | Not stated | An essential criterion | Any audited records, handover documentation, or EPR use | A redacted record or audit sheet | `[grounded]` advert |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live; the careers page was not reached | unknown | — | "Current vacancies are listed on our careers page" | The advert may have closed, or its link may be out of date | `[inferred]` from the about page's pointer to the careers page | Can you send the link to the live posting? | unresolved |
| RR2 | Caseload size and supervision undefined | unknown | — | "a small caseload of your own, supported by a senior community nurse" | Support may be thin for a first caseload | `[inferred]` from the advert's silence on numbers | How many patients would the caseload be, and what does the senior nurse's support look like week to week? | unresolved |
| RR3 | Contract basis unstated | unknown | — | Advert silent on permanent or fixed-term | The post may be fixed-term | `[inferred]` from the advert's silence | Is this post permanent or fixed-term? | unresolved |
| RR4 | Pay within market range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Pay is in line with the survey's middle | `[generic]` survey against `[grounded]` advert | None needed | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your NMC register entry and confirm it is active | R1 is the one gate with no artifact but your PIN | `[grounded]` CV | pending your approval |
| A2 | Confirm the posting is live via the careers page, or ask the contact for the link, before applying | RR1 | `[grounded]` about page | pending your approval |
| A3 | Ask the team lead, in the informal chat, about caseload size, supervision, contract basis and records expectations | RR2, RR3, R11 | `[generic]` informal chat practice | pending your approval |
| A4 | Lead with the 18-month discharge-to-assess home visits, then wound care, catheter care and insulin. Say the caseload is new to you | Strongest true story for this role | `[grounded]` CV | pending your approval |
| A5 | Proposed CV line, resume_edits_pending_approval: "Visited patients at home in their first week after discharge as part of the discharge-to-assess team (18 months)." Every clause traces to your CV sentence | Makes the home-visit experience visible | `[grounded]` CV | resume_edits_pending_approval |
| A6 | Treat Doppler as a closure path, not a claim. Look for formal training | R12 | `[generic]` | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). The entity exists as described: a CIC running adult community nursing in Calderdale under an NHS contract. The careers page was not reached, so the posting is not confirmed live (RR1) |
| 2. Role-family sweep | yes | Searched "NHS Agenda for Change band 5 pay scale 2026 staff nurse", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). This gives the market calibration and RR4. The official NHS pay scale was not checked |
| 3. Hiring manager's public footprint | skipped | The name given is the team lead for an informal chat, not confirmed as the hiring manager. The posting and CV already set the scope read and positioning, so no search was run |

## Upgrade menu

- The careers-page link or the recruiter's email domain → RR1 closes
- The contract basis → RR3 closes
- Caseload size and supervision → RR2 and R10 firm up
- A redacted record or ward audit → R11 rises from `low` toward `medium` or `high`
- Ward case examples of catheter, continence or end-of-life work → R6 and R9 move off `unclear`
- The official NHS Agenda for Change band 5 pay point → confirms the survey calibration
- A deeper pass on the employer (leadership, past vacancies, contract history; up to 5 more searches and 2 more fetches) — say the word and it runs

If you want this kept for later, I can save it as `tuesday-dossier.md` for the mock-interview step.

1. **RR1:** Can you send the link to the live posting, or the careers-page route to it?
2. **RR3:** Is this post permanent or fixed-term?
3. **R11:** Can you describe a time your written records were audited, praised, or checked, or share a redacted example?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.