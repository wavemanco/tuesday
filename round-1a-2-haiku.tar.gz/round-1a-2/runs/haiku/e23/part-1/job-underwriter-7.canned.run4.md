**Decision: `conditional_go`.** Apply, once the employer and the posting check out. On the evidence you've given me, the registration, licence and post-registration requirements are met, and your home-visiting and wound, catheter and insulin work matches much of the role. The gaps are your own caseload, end-of-life visits, and Doppler. Those are the things to prepare for, not reasons to skip the application.

**Research tier: L0, no searches.** This first pass used only the advert and your CV. Nothing about the employer has been checked yet.

## Decision snapshot

- **Status:** `conditional_go`. Your core clinical fit is sound (R4, R5a, R6a, R7a), and the decision holds only if the employer verifies (RR1). Gaps R8, R9 and R13 are real but do not block applying.
- **Fit ledger:**
  - **hard_gate:** direct R1, R2, R3
  - **must_have:** direct R4, R5a, R6a, R7a; adjacent R5b (leg-ulcer), R9 (own caseload), R12 (home visits); unclear R6b (continence), R7b (care planning), R10 (written records); absent R8 (end-of-life)
  - **important:** unclear R11 (electronic patient record)
  - **preferred:** absent R13 (Doppler)
- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against pay, schedule and mileage unknown.
- **Opportunity ledger:** RR1 (employer not established) is open at medium severity and caps the decision. RR2 and RR3 are unknowns about caseload and pay. PS1 is a positive signal: the advert names a contact for an informal chat, a senior nurse for support, and pool cars.
- **Severe red flags:** none found.
- **What would change this:** RR1 verifies (the live posting appears on Calderbrook's own careers page, and the employer is real). If RR1 fails, the decision becomes `hold_pending_answers`.

## Role reality

- **Role:** Community Staff Nurse, Band 5, Calderbrook Community Health CIC, Halifax. Home visits to housebound adults, with a personal caseload and a senior community nurse for support. Electronic patient record.
- **Scope:** Wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, and written records. [grounded] from the advert.
- **Pay:** £31,050–£37,800 plus mileage, as posted [grounded]. I have not checked that band against the public pay scale, so I have no market calibration. [generic] comparison would need L1.
- **Unknowns:** caseload size, lone-working and out-of-hours arrangements, on-call expectations, and whether the Doppler training is provided.

## Evidence map

CV claims are [grounded] in your CV; fit calls are my reading of them.

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult | hard_gate | direct | high | — | NMC PIN, active, revalidation due March 2028 |
| R2 | Full UK driving licence | hard_gate | direct | high | — | Full licence, category B |
| R3 | Based in or near Halifax | hard_gate | direct | high | — | You live in Halifax |
| R4 | At least one year post-registration | must_have | direct | high | — | Five years as a staff nurse |
| R5a | Wound care | must_have | direct | high | — | Pressure ulcers, surgical wounds |
| R5b | Leg-ulcer care (Adult) | must_have | adjacent | medium | capability | General wound care; no leg-ulcer work stated (transferability) |
| R6a | Catheter care | must_have | direct | high | — | Catheter care |
| R6b | Continence care | must_have | unclear | low | discovery | Not mentioned |
| R7a | Insulin administration | must_have | direct | high | — | Insulin administration |
| R7b | Care planning | must_have | unclear | low | discovery | Not mentioned as an own task |
| R8 | End-of-life visits | must_have | absent | high | capability | Not mentioned |
| R9 | Own small caseload with senior support | must_have | adjacent | medium | capability | Individual home visits, but never held a caseload |
| R10 | Clear, timely written records | must_have | unclear | low | discovery | Not described |
| R11 | Electronic patient record | important | unclear | low | discovery | Not stated |
| R12 | Visiting patients in their own homes | must_have | adjacent | medium | transferability | Home visits in the first week after discharge, not housebound long-term care |
| R13 | Doppler assessment for leg ulcers | preferred | absent | high | capability | Not mentioned |

## Gap recovery queue

- **G1 (R9):** No caseload. Closes with an example of planning your own visits and following patients through without a senior on the phone, from discharge-to-assess.
- **G2 (R8):** No end-of-life work stated. Closes with any ward or home end-of-life experience.
- **G3 (R13):** No Doppler. Closes with a course, or an employer commitment to train.
- **G4 (R5b):** No leg-ulcer work stated. Closes with any compression or leg-ulcer exposure.
- **G5 (R6b, R7b, R10, R11):** Continence, care planning, written records and the EPR are not stated. Each closes with a line in your CV or an example.

## Opportunity risk register

```yaml
signal: "Employer not established from attributable sources"
class: risk_signal
severity: medium
source_quote: "Calderbrook Community Health CIC, Halifax"
hypothesis: "Research has not run, so the employer's existence and this posting are unverified. A small CIC may simply have a thin online footprint."
provenance: "[generic] standing check; not a claim about this employer"
verification_question: "Is this post on Calderbrook's own careers page, and who would I be interviewing with?"
decision_rule: "Verify the employer and the live posting before investing application effort."
status: unresolved
```

```yaml
signal: "Caseload size and lone working unknown"
class: unknown
source_quote: "You will hold a small caseload of your own"
hypothesis: "'Small' is undefined, and the advert is silent on lone working and out-of-hours cover. Both matter for a newly self-managed caseload."
provenance: "[inferred] from the advert's silence on caseload size and cover"
verification_question: "What is the typical caseload for this post, and how are lone working and out-of-hours cover handled?"
decision_rule: "Proceed if the caseload is manageable and the support arrangements are concrete."
status: unresolved
```

```yaml
signal: "Pay and mileage against personal floor unknown"
class: unknown
source_quote: "£31,050–£37,800 a year plus mileage"
hypothesis: "Your floor was not given, so I cannot tell whether the range and mileage meet it."
provenance: "[grounded] from the advert; the comparison is not yet made"
verification_question: "How is mileage calculated, and where on the range does a candidate with five years' experience usually start?"
decision_rule: "Confirm the pay and mileage terms before accepting any offer."
status: unresolved
```

```yaml
signal: "Named contact and stated support"
class: positive_signal
source_quote: "For an informal chat about the role, contact Rhiannon Mabbott, Community Nursing Team Lead"
hypothesis: "The advert offers an informal conversation, names a senior contact, and describes senior nurse support and pool cars. That is transparency about the role."
provenance: "[grounded] from the advert"
verification_question: "What would support look like in my first three months on the caseload?"
decision_rule: "Test this in the informal chat."
status: unresolved
```

## Application plan

- **Lead with:** home visits in discharge-to-assess, wound care (pressure ulcers and surgical wounds), catheter care, and insulin administration, since these match R5a, R6a, R7a and R12.
- **Do not claim:** your own caseload, end-of-life work, Doppler, or community-nursing experience. Claiming any of them would be inflation, and the interview would expose it.
- **Before applying:** verify the posting (RR1). Ask about caseload and support in the informal chat.
- **CV wording:** I have not drafted any. Any wording goes to you for approval first.

## Evidence status

| Target | Status | Reason |
|---|---|---|
| 1. Company official site and careers page | skipped | Research not run in this first pass (L0) |
| 2. Role-family sweep (scope, title, pay for Band 5) | skipped | Research not run in this first pass (L0) |
| 3. Hiring manager's public footprint | n/a | No hiring manager named |

Research tier: L0, no searches.

Dossier offer: I can save this assessment as `tuesday-dossier.md` for later use.

**Upgrade menu:**
- **L1 research** (up to 5 searches and 2 page fetches) would check whether Calderbrook exists and whether the posting is live, and would give a Band 5 pay calibration.
- **Link to the live posting**, or the careers-page address, would resolve RR1 directly.
- **Any end-of-life, continence or leg-ulcer work**, or a Doppler course, would raise R8, R6b, R5b or R13.

**Questions:**
- **R9:** In discharge-to-assess, did you ever plan a patient's visits, or follow one through to discharge, without a senior on the phone?
- **R8 and R6b:** Have you done any end-of-life or continence work, on the ward or in discharge-to-assess?
- **Candidate constraints:** What is your floor for pay and mileage, and are there schedule limits, such as no weekends or on-call?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.