**Yes, worth applying, on conditions. Status: `conditional_go`.** You meet all three essential terms (NMC registration, full UK licence, Halifax) and most of the clinical list. The gaps are owning a caseload, leg-ulcer work, and written records, and an interview can probe each of them. The posting also isn't confirmed live yet.

**Fit ledger.**

- `hard_gate` — direct: R1, R2, R3
- `must_have` — direct: R4, R5a, R6a, R7 · unclear: R5b (leg-ulcer care), R10 (clear, timely written records)
- `important` — adjacent: R8 (care planning), R9 (holding own caseload) · unclear: R6b (continence care), R11 (end-of-life visits)
- `preferred` — absent: R12 (Doppler assessment)

R5b and R10 are the two must-haves below `direct`. R9 is adjacent, with its limit named. R12 has no evidence yet.

**Opportunity ledger.** The employer is established and the pay is stated, with a named team lead to contact. The posting itself is not yet confirmed live (RR1). No red flags. Pay sits near the community Band 5 median (RR2).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against your pay floor, schedule and contract type are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting confirmed live, on Calderbrook's careers page or by Rhiannon Mabbott (RR1); (2) your answers on leg ulcers and records hold up (R5b, R10); (3) the caseload gap framed as adjacent, not as held-caseload experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, adult community nursing under an NHS contract in Calderdale; founded 2015, 410 staff, four locality hubs | `[grounded]` employer's About page |
| Role | District nursing caseload in people's homes; small own caseload with a senior community nurse; EPR documentation | `[grounded]` JD |
| Working pattern | Halifax; pool cars provided; mileage paid | `[grounded]` JD |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` JD |
| Market calibration | Band 5 community staff nurse median £34,300, interquartile range £32,400–£36,600; the posted range's midpoint (£34,425) sits at the median | `[generic]` Wardround 2026 pay guide (n=1,240, England); `[grounded]` JD for the posted range |
| Unknowns | Contract type; caseload size; out-of-hours expectations | — |
| Contradictions | None found between the JD and the About page; the careers page could not be opened, so the posting is unchecked | `[grounded]` research result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | NMC registration as Adult Nurse | hard_gate | direct | high | none | PIN and active status stated; the register entry is the inspectable artifact | `[grounded]` CV and your confirmation | Check your entry on the NMC register before applying |
| R2 | Full UK driving licence | hard_gate | direct | high | none | Category B stated; pool cars cover the vehicle | `[grounded]` your statement | none |
| R3 | Based in Halifax | hard_gate | direct | high | none | You live in Halifax; role is Halifax | `[grounded]` your statement | none |
| R4 | At least one year post-registration | must_have | direct | medium | none | Five years as staff nurse; CV only | `[grounded]` CV | none |
| R5a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds stated | `[grounded]` CV | none |
| R5b | Leg-ulcer care | must_have | unclear | low | discovery | Leg ulcers not named; general wound work is the nearest evidence | `[grounded]` CV silence | Question G1 |
| R6a | Catheter care | must_have | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | low | discovery | Not on CV | `[grounded]` CV silence | Upgrade menu |
| R7 | Insulin administration | must_have | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R8 | Care planning | important | adjacent | medium | transferability | Discharge-to-assess planning is adjacent; longer-term caseload planning is not evidenced | `[inferred]` from the seconded role | Prepare one planning example |
| R9 | Holding own caseload | important | adjacent | medium | transferability | Autonomous home visits in discharge-to-assess; no held caseload | `[grounded]` CV plus your statement | Frame honestly (see G5) |
| R10 | Clear, timely written records | must_have | unclear | low | discovery | CV silent; home visits imply documentation; EPR use not stated | `[grounded]` CV silence | Question G3 |
| R11 | End-of-life visits | important | unclear | low | discovery | Not on CV | `[grounded]` CV silence | Question G4 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No evidence; never done | `[grounded]` your statement | Closure path below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R5b, must_have) | discovery | General wound work is on the CV; leg ulcers are not | A must-have; one example likely moves it to adjacent or direct | An example from discharge visits or ward work | `[grounded]` CV silence |
| G2 | Continence care (R6b, important) | discovery | Not on the CV | Named in the JD's core list | One line if true | `[grounded]` CV silence |
| G3 | Written records (R10, must_have) | discovery | Silent on documentation | Essential term; interviewers probe timeliness | An anonymised example of home-visit notes | `[grounded]` CV silence |
| G4 | End-of-life visits (R11, important) | discovery | Not on the CV | Core to the team's remit | Any palliative or end-of-life work | `[grounded]` CV silence |
| G5 | Caseload (R9, important) | transferability | Autonomous visits, no held caseload | The job is a caseload; the bridge needs a stated limit | Frame as adjacent and name the limit | `[inferred]` bridge from the seconded role |
| G6 | Doppler (R12, preferred) | capability | No evidence | Preferred only | Structured training before or after appointment; ask the team about it | `[generic]` that structured training is the usual route |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | risk_signal | low | "Current vacancies are listed on our careers page" | The advert may have closed or not be listed; the address I tried returned nothing | `[inferred]` from a failed fetch of a guessed address | Is this post open on your careers page now, and what is the closing date? | unresolved |
| RR2 | Pay sits near market median | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Pay looks in line with the community Band 5 median | `[generic]` median from the pay guide; `[grounded]` posted range | What is the starting point on the band, and the mileage rate? | noted |
| RR3 | Named team lead, public standing | positive_signal | — | "contact Rhiannon Mabbott" | The informal chat is a real route; the lead has spoken publicly on leg-ulcer clinics and Doppler training | `[grounded]` conference speaker page | How is caseload allocated across the Halifax team? | noted |
| RR4 | Contract type unstated | unknown | — | Not stated in the advert | The post could be fixed-term | `[inferred]` from the advert's silence | Is this a permanent post or fixed-term? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check your NMC register entry before applying | R1 | `[grounded]` the gate row | proposed |
| P2 | Confirm the advert is live, then contact Rhiannon Mabbott for the informal chat | RR1, RR3 | `[grounded]` register | proposed |
| P3 | Lead with wound, catheter and insulin work; describe discharge-to-assess visits as the nearest caseload work, with its limit | R5a, R7, R9 | `[grounded]` map | proposed, pending your approval |
| P4 | Prepare honest answers on leg ulcers and records, using only examples you can back | R5b, R10 | `[grounded]` map | proposed, pending your approval |

Nothing here is drafted as CV or outreach text yet; that waits for your approval.

## Evidence status

Verified: R1, R2, R3 (your confirmation in this message), plus R4, R5a, R6a, R7 from your CV. Verification is about the claim, not the fit. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax"; the About page (calderbrookhealth.example/about) attributes the employer: adult community nursing under an NHS contract in Calderdale, founded 2015, 410 staff, four hubs. A fetch of a guessed careers address (calderbrookhealth.example/careers) returned no page, so the posting is unverified (RR1) |
| 2. Role-family sweep | yes | Searched "Band 5 staff nurse pay 2026/27 Agenda for Change £31,049"; the Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide) gave the Band 5 median and interquartile range. Feeds the market calibration line |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead"; the speaker page (communitynursingforum.example/speakers/rhiannon-mabbott) gives her role and 2025 talk topics. Public professional footprint only. Feeds RR3 |

## Dossier offer

If you want, I can write this up as a `tuesday-dossier.md` file to keep alongside the application.

## Upgrade menu

- An anonymised leg-ulcer example from discharge visits or ward work → R5b to `medium`.
- An anonymised home-visit record, or a description of how you documented visits → R10 to `medium`.
- Any continence care you have done → R6b.
- The advert's live link or closing date → RR1 closes.
- Your pay floor, schedule and contract preferences → the hard-gate checks against them can run.
- A deeper research pass on Calderbrook (up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G1 — Have you dressed or managed leg ulcers, on the ward or on discharge visits? If so, what was the typical treatment, and was it documented?

G3 — How did you document home visits: which system, how quickly did notes get completed, and how was handover handled? Could you share an anonymised example?

G4 — Have you been involved in end-of-life care at home or on the ward? What did you do, and who did you work with?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.