**Yes, worth applying for, on conditions: `conditional_go`.** On the essentials you meet the two hard gates and the one-year requirement directly. What's open is caseload ownership and end-of-life work, which the advert treats as core. The posting itself is also unconfirmed as live.

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R5, R7 · adjacent: R4, R9, R10 · unclear: R6, R11 · absent: R8
- `important` — adjacent: R14 · unclear: R12
- `preferred` — absent: R13

Adjacent reads: R4 (leg-ulcer wound care) is a bridge from pressure-ulcer and surgical wound work; R9 (care planning) is a bridge from discharge planning; R10 (own caseload) is a bridge from home visits that you did not run as a caseload; R14 (home-based working) is a bridge from first-week home visits to longer-term housebound care.

**Opportunity ledger.** The role is clearly defined, with a named caseload model and senior support (RR1). The posting's liveness is unconfirmed (RR2), and the level of clinical autonomy from the start is unstated (RR3).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown. Your National Insurance number isn't needed for this assessment and I haven't used it.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed open (RR2); (2) the caseload build-up and clinical sign-off in the first months are confirmed (RR3); (3) your CV frames home-visit work as home visiting, never as a caseload, end-of-life work, or Doppler.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, Calderdale; adult community nursing under an NHS contract, founded 2015, 410 staff | `[grounded]` company About page |
| Role | Band 5 community staff nurse: home-based district nursing for housebound adults, own small caseload, senior community nurse support | `[grounded]` advert |
| Scope read | Caseload-holding at Band 5 with supervision is a normal scope for the title | `[generic]` role-family pattern |
| Market calibration | Wardround 2026 survey for community staff nurses, England (n=1,240): median £34,300, interquartile range £32,400–£36,600; 61% paid mileage. The advert's £31,050–£37,800 sits across that range. This is a pattern, not this employer's offer | `[generic]` role-family sweep; `[grounded]` advert's band |
| Unknowns | Contract type; caseload build-up; clinical sign-off; whether leg-ulcer work is the core of the caseload; whether Doppler is trained | — |
| Contradictions | None found between the advert and the company's About page. Advertised vacancies live on a careers page, which I could not reach | `[grounded]` About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | NMC registration as Adult Nurse | hard_gate | direct | medium | none | CV states Adult registration, PIN and active status. Checkable on the NMC register | `[grounded]` CV | Check the register entry before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B full licence stated. Self-reported | `[grounded]` CV | none |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years as staff nurse | `[grounded]` CV | none |
| R4 | Wound and leg-ulcer care | must_have | adjacent | medium | transferability | Pressure ulcers and surgical wounds are stated. Leg ulcers are not | `[inferred]` from wound types listed | Ask about leg-ulcer exposure in the interview |
| R5 | Catheter care | must_have | direct | medium | none | Stated | `[grounded]` CV | none |
| R6 | Continence care | must_have | unclear | low | discovery | Not stated | `[grounded]` CV silence | Q1-linked check |
| R7 | Insulin administration | must_have | direct | medium | none | Stated | `[grounded]` CV | none |
| R8 | End-of-life visits | must_have | absent | none | capability | Nothing in the CV covers end-of-life care | `[grounded]` CV silence | Q2 |
| R9 | Care planning | must_have | adjacent | low | transferability | Discharge planning in the first week after discharge is implied. Not named | `[inferred]` | Q1 |
| R10 | Holding a small caseload | must_have | adjacent | low | capability | Home visits in discharge-to-assess, not a caseload you owned | `[grounded]` CV; `[inferred]` bridge | Q1 |
| R11 | Clear, timely written records | must_have | unclear | low | discovery | CV is silent on documentation | `[grounded]` CV silence | Q3 |
| R12 | Electronic patient record | important | unclear | low | discovery | Not stated; the advert's system is unknown to you | `[grounded]` CV silence | Q3 |
| R13 | Doppler assessment for leg ulcers | preferred | absent | none | capability | Not done | `[grounded]` CV | Upgrade menu |
| R14 | Home-based working | important | adjacent | medium | transferability | First-week home visits; the advert's population is longer-term housebound | `[grounded]` CV; `[inferred]` | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Holding a caseload (R10, must_have) | capability | Home visits as a seconded team member; no caseload owned | The advert's core model; the largest objection | Any patient you followed through from first visit to discharge with a plan you made; any ward-level care-plan ownership | Anonymised care plan or handover you wrote | `[inferred]` bridge |
| G2 | End-of-life care (R8, must_have) | capability | Nothing stated | The advert names end-of-life visits | Dying-patient care on the ward; family communication at discharge | Any training certificate or an example of your part | `[grounded]` CV silence |
| G3 | Records and EPR (R11, R12) | discovery | Nothing stated | The advert names clear records as essential | Ward documentation and discharge summaries | An anonymised note you wrote | `[grounded]` CV silence |
| G4 | Leg-ulcer care and Doppler (R4, R13) | transferability / capability | Pressure and surgical wounds; no Doppler | Doppler is desirable; leg-ulcer care is core | Wound assessment and dressing choice on the ward | Training record | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Clear caseload model with senior support | positive_signal | — | "hold a small caseload of your own, supported by a senior community nurse" | Scope is defined and supported | `[grounded]` advert | How many patients does a new caseload holder start with, and how is support structured? | noted |
| RR2 | Posting liveness unconfirmed | risk_signal | low | "Current vacancies are listed on our careers page" | The careers page is not at the address I guessed, so the advert may be stale | `[generic]` pattern; `[grounded]` the employer exists | Is this post open now, and when does it close? | unresolved |
| RR3 | Clinical autonomy at start unstated | unknown | — | "hold a small caseload of your own" | Caseload holders may be expected to decide alone from the start | `[inferred]` from the advert's silence on sign-off | How is a new caseload holder's clinical sign-off handled in the first months? | unresolved |

No severity applies to RR1 or RR3. No `severity: high` entries.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your entry on the NMC register shows Adult and the March 2028 revalidation | Hard gate R1 | `[grounded]` CV | pending your approval |
| A2 | Use the invited informal chat with Rhiannon Mabbott to ask Q1 and the Doppler question | RR3, R13 | `[grounded]` advert | pending your approval |
| A3 | Lead CV language with home-visit discharge work, wound care, catheter and insulin | R4, R5, R7, R14 | `[grounded]` CV | pending your approval |
| A4 | Do not claim a caseload, end-of-life work or Doppler in any document | R8, R10, R13 | `[grounded]` CV | pending your approval |
| A5 | Confirm the post is open before investing an application | RR2 | `[generic]` | pending your approval |

For A2: the named contact has a public talk on Doppler training for staff new to community work. That suggests the team may train for it, but the talk is not evidence of this team's training policy. `[inferred]`

## Evidence status

Verified: none yet. Your CV claims are leads until checked against the NMC register or an artifact.

Research tier: L1 — searches 3 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax"; fetched calderbrookhealth.example/about. Employer established. Careers page not found at the guessed address, so RR2 stays open |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse NHS pay scale 2026 district nursing", which returned the Wardround 2026 UK Community Nursing Pay Guide. Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Named contact Rhiannon Mabbott (Community Nursing Team Lead). Searched her name with the role and company; a speaker page at communitynursingforum.example reports her leading the Halifax district nursing team and speaking on Doppler training for staff new to community work. Moved the positioning in A2 |

## Upgrade menu

- An answer on caseload build-up and sign-off → RR3 closes; `go` becomes likely.
- The live advert or careers page → RR2 closes.
- An anonymised care plan or record you wrote → R10 and R11 rise from `low`.
- Any end-of-life training or an example → R8 rises from `none`.
- A Doppler training record → R13 rises from `none`.
- A deeper research pass on the employer (leadership, past recruitment, staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. (RR3, R10) Tell me about a patient you managed from first contact to discharge, deciding the plan yourself without a nurse signing off each step. Answer in text, paste a voice transcript, attach a document, or say skip.
2. (R8) Have you cared for patients at end of life, at home or on a ward? What was your part?
3. (R11, R12) What electronic record system did you use, and can you describe one visit note you wrote, anonymised?

Dossier offer: I can save this analysis as a `tuesday-dossier.md` file on request.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.