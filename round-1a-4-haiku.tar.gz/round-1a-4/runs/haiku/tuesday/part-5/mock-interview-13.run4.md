Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-5-rooms-case-13-denied-9663b1e7/2f061e39-a3f5-407f-bc02-a674aa6a3180/scratchpad/quillmoor_operations-coordinator_interview_pack.md. I built it for a recruiter screen with Hannah Lowther.

Three things to get right on Thursday:

- **Pay:** say "I'm hoping for £42,000," which sits inside the advertised band, and then stop or ask for the band. Don't explain how you got the figure.
- **Reason for moving:** hold the sentence you gave me, word for word, through a follow-up. Don't add to it.
- **SAP:** say "I haven't used SAP" plainly, then describe your in-house stock system in your own words.

Your notice period isn't in the material, so the pack can't fill that slot. The call's biggest gap is production scheduling across planning, warehouse and QA. Your depot scheduling is the closest thing you've described, and the pack says so.

Web search was refused in this session, so the pack has no information about Quillmoor's values, interview process or recent news. It also has no read of Hannah's public profile. Those are listed in the upgrade menu if you want them later.

Say the word and I'll play the Skeptic on B2, the question the pack names as its highest-ROI prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

What's your notice period?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

**Round:** Recruiter screen, 30 minutes, by phone to the mobile number on your application. Thursday, 2pm.
**Interviewer:** Hannah Lowther, Talent Partner (recruiter).
**Changelog:** first version.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored: **JD** (the listed job's terms), **EXP** (what you actually did), **CASE** (a live problem). Guidance is scaffolding for a spoken answer, not a script. Use your own words, and say only what your quoted sentences say.

## Fit snapshot

Requirements are quoted from the advert or from the recruiter's message. Your own statements are quoted from your message to me.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | No gap. Say it in those words. Caveat: this is your own account with nothing inspected behind it, so expect a probe on scope and dates. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Depot delivery scheduling is adjacent work. Your material does not show planning, warehouse or QA coordination. Words: "I schedule deliveries for our three depots." Answer slot: if you coordinated a schedule involving planning or quality, say which and how; if not, say so and stay with the depot work. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots" (your message); "chase suppliers when orders slip" (your message) | medium | [grounded] | none | The chasing sentence reaches the requirement directly. Words: "I chase suppliers when orders slip." |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | none | No gap. Caveat: a headline figure with nothing inspected behind it, so it draws the defend-the-number probes in D1 and C2. |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show any dispatch reporting. Answer slot: if you tracked on-time delivery and reported it, say what you measured and how often; if you did not, say so and say what you would track first. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | The material shows a spreadsheet, not Excel by name, and does not say which functions you used. Answer slot: name the tools you used for the stock-count spreadsheet and what they did; if you have not used Excel for it, say so and say how you would get up to speed. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "I haven't used SAP" (your message, as "Never used SAP"); "we run our own in-house stock system" (your message) | medium | [grounded] | transferability | Your in-house stock system is adjacent to an ERP, and SAP is absent. Words: "I haven't used SAP. We run our own in-house stock system." The pack does not show whether that system works like an ERP. Answer slot: describe what the in-house system does, in your own words. |
| F8 | "£38,000–£44,000" (advert, pay band) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your figure sits inside the advertised band. Words: "I'm hoping for £42,000." |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Met. Two days is inside the three you named. Words: "Two days at Avonmouth is fine." |
| F10 | Notice period (recruiter's message: "I'd like to cover … your notice period") | none given | none | [grounded] | hard_gate | Your material does not establish your notice period, and the call will ask for it. Give your actual notice period. This pack does not supply one. |
| F11 | What is prompting a move (recruiter's message: "what's prompting a move") | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message) | high | [grounded] | none | Your reason is stated in your own words. Words: "Our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Coordinate production schedules across planning, warehouse and QA | B2 |
| Track supplier deliveries and chase late orders | A2 |
| Keep stock records accurate | D1, C2 |
| Report weekly on on-time dispatch | B3 |
| Confident with Excel | D2 |
| ERP experience (SAP or similar), a plus | B1 |
| Salary, £38,000–£44,000 | A3 |
| Hybrid, two days at Avonmouth | A5 |
| Notice period (recruiter's topic, not in the advert) | A4 |
| Reason for leaving (recruiter's topic) | C1 |

## Prohibited list

Claims this pack will not coach, each with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I coordinated production schedules across planning, the warehouse and QA" | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." The material says depot deliveries. B2's answer stays inside that work. |
| "I manage supplier performance across the business" | Inflated form of F3 | F3's quote at its own scope: "chase suppliers when orders slip." |
| "The spreadsheet alone cut discrepancies by a third" | Inflated form of F4 | F4's quote at its own scope. The material says you rebuilt the sheet and discrepancies fell; it does not say how much of the fall the sheet caused. D1 asks which part was yours. |
| "I have used SAP" | Negative you stated (F7) | Plain acknowledgment: "I haven't used SAP." |

## Persona weights

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport builder (weight 5) | A friendly walk through your background, then pay, notice, the hybrid pattern and why you are moving | Most likely. A recruiter screen's standard prior. The four logistics topics are asked in a relaxed register, but they are scored | Say each logistics answer in your own words, once, and move on |
| Light skeptic (weight 3) | Probes on the gaps: production scheduling (F2), dispatch reporting (F5), SAP (F7) | Likely. These are the three places the advert asks for something your material does not show | Give the adjacent work in your own words, then the limit, then how you would close it |
| Pressure / stress (weight 2) | Pushes on your reason for leaving and on the one headline figure | Possible. A short screen may test composure on the move, and on whether the figure is yours | Hold the sentence you stated through two follow-ups; concede only what the material does not show |
| Data-driven prober (weight 2) | Asks how the discrepancy figure was counted and which Excel functions you used | Possible. The figure and the Excel line are the two places a recruiter who has read the CV closely would ask | Say how it was counted, in your words; if you do not know, say so plainly; name the weakest assumption you know of |

Values/behavioral, case and peer personas are not weighted: this is a recruiter screen, the recruiter has not announced a values round or a live problem, and there is no team interviewer yet. Totals: 12 questions (5, 3, 2, 2). That is below the usual 18 to 26 for a full loop, deliberately: a 30-minute screen covers logistics and a few substantive questions, and padding would teach you to skim.

## Question banks

### A. Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me a bit about your background in logistics coordination." | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (F1); "I schedule deliveries for our three depots" (F2) | Open prompt. Give about 90 seconds: the four years, the three depots, and the chasing, each in the words quoted. Say what you did and not what the role would call it. | F1 is the experience line. This is the first thing a recruiter checks against the advert. |
| A2 | "What's your experience chasing late orders?" | JD | [grounded] "chase suppliers when orders slip" (F3) | Say you chase suppliers when orders slip, in those words. Then describe one occasion you actually handled. Answer slot: if you tracked deliveries against their due dates, say how; if you did not, say so. | F3 is the advert's chasing requirement. It is covered directly, so keep it short. |
| A3 | "What are your salary expectations?" | JD (pay) | [grounded] "I'm hoping for £42,000." (F8) | Logistics slot. Say your figure in your words: "I'm hoping for £42,000." Then stop, or ask what band the role carries before you go further. Do not explain how you arrived at the figure, and do not offer a range or a lower number unless you decide to. | Pay is a logistics slot. The figure sits inside the advertised £38,000–£44,000 (F8). Nothing in this pack asks why that figure, or what you earn now. |
| A4 | "What's your notice period?" | JD (notice) | [grounded] "your notice period" (the recruiter's message) | Logistics slot. Give your actual notice period, in the terms your contract uses. This pack does not supply one, because your material does not contain one. | F10 is a hard gate that the material does not establish. The recruiter has said she will ask. |
| A5 | "How do you feel about two days a week at Avonmouth?" | JD (location) | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (F9) | Logistics slot. Say it in your words: "Two days at Avonmouth is fine." If asked about more days, your own words were: "I wouldn't want more than three." | F9 is met. Your quote gives the limit and the reason, and nothing more. |

### B. Light skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked with SAP. How would you get up to speed on an ERP like that?" | JD | [grounded] "I haven't used SAP." (F7, your stated negative); "we run our own in-house stock system" (F7) | Plain acknowledgment: "I haven't used SAP." Then describe the in-house stock system in your own words, meaning what it does. Answer slot: if you have used any ERP-style system, say which; if not, say so and say how you would learn one. | F7 is a plus, not a requirement, but it is the one a recruiter is most likely to mention. |
| B2 | "Production schedules here span planning, the warehouse and QA. Have you coordinated across those?" | JD | [grounded] "I schedule deliveries for our three depots" (F2) | Highest-ROI prep in this pack. Say what you schedule and where: "I schedule deliveries for our three depots." Answer slot: if you coordinated across a planning or quality team, say which team and how; if you did not, say so and say how the depot scheduling is the closest thing you have done. Hold through two follow-ups by returning to the depot work. | F2 is the advert's headline line, and it is adjacent rather than direct. A skeptic presses here. |
| B3 | "Have you reported on delivery performance, weekly, on on-time dispatch?" | JD | [grounded] (the advert's requirement, "report weekly on on-time dispatch") | Answer slot: if you tracked on-time delivery and reported it, say what you measured and how often; if you did not, say so and say what you would track first. | F5 is the advert's requirement with nothing in your material to show it. |

### C. Pressure / stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your office is closing next year, so why not take the Reading move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (F11) | Logistics slot for the reason you are moving. Hold the sentence you stated: "the only offer is relocating to Reading, which I don't want." Hold through two follow-ups. Do not add a reason you did not give. This pack cannot supply a concession, so do not invent one. | F11 is your stated reason. This question checks that you hold it, and that you do not add to it under pressure. |
| C2 | "That figure, about a third: how much of that was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (F4) | Hold-then-concede. Say what you did, in the quote's own scope: "I rebuilt our stock-count spreadsheet, and discrepancies fell by about a third over a year." Hold through two follow-ups. Concede where the quote ends: if you cannot say how much of the fall the spreadsheet caused, say so. | F4 is the headline figure. Pressure probes it on attribution, and the honest answer is the limit. |

### D. Data-driven prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you counted discrepancies. What counted as one?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (F4) | Defend-the-number. Answer slot: say how the discrepancies were counted, in your own words. If you do not know how the figure was counted, say so plainly. Name the weakest assumption you know of before they do, and say which part of the work was yours. | A figure you gave raises these four slots, and the advert asks for accurate stock records (F4). |
| D2 | "Which tools did you use to build the stock-count spreadsheet, and how confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet" (F6) | Answer slot: name the tools and what they did, in your own words. If the spreadsheet was not Excel, say what it was. If you have not used Excel for it, say so and say how you would get up to speed. | F6 is low confidence. The advert asks for Excel, and your material says spreadsheet. |

## Reading the interviewer

Not included. No public profile of the recruiter was checked, because web search was not available. The upgrade menu says what checking it would add.

## Reverse questions

1. "What does a normal week look like between planning, the warehouse and QA?" Why it lands: it tests the advert's headline line from the recruiter's side, and it gives you the real shape of the production schedule.
2. "How is on-time dispatch reported today, and who reads the report?" Why it lands: it shows you read the weekly reporting line as a requirement, not a footnote.
3. "Which system would I be working in day to day? Is it SAP?" Why it lands: it asks the ERP question directly, so you learn whether the plus matters.
4. "Is Avonmouth the long-term base for this role, or could the site plan change?" Why it lands: you are agreeing to two days there, and this checks that the site will still be there.
5. "What happens after this call, and what's the timeline?" Why it lands: it lets the recruiter cover the next steps she said she would describe, and it shows you are paying attention.

## Sources

**Provided documents:** the recruiter's LinkedIn message (Hannah Lowther, Talent Partner); the advert as pasted; your background as pasted.

**Searches sent:**
1. "Quillmoor Diagnostics values": refused (search permission not granted).
2. "Quillmoor Diagnostics interview process recruiter screen": refused (search permission not granted).
3. "Quillmoor Diagnostics Avonmouth news strategy": refused (search permission not granted).

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | unavailable | Values cheat sheet, and values-linked reverse questions. Every call was refused, so none is in this pack. |
| 2. Quillmoor interview process, recruiter screen | unavailable | Loop structure; persona weights follow the round types. Refused, so the weights above use the recruiter-screen prior. |
| 3. Quillmoor strategy and recent news | unavailable | Current priorities for the reverse questions. Refused, so the reverse questions are role-generic. |
| 4. Recruiter's public footprint (Hannah Lowther) | unavailable | One reverse question tied to her own path, and the interviewer read. No call was sent: search permission had already been refused. |
| 5. Representative advert | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Your notice period → A4 becomes a figure in your own words, and F10 becomes grounded.
- Quillmoor's published values page, pasted → a values cheat sheet, and reverse questions tied to the published values.
- Web search permission granted, then a later run → targets 1 to 4 above: values, process, recent news, and the recruiter's public footprint.
- The recruiter's public profile, pasted → one reverse question tied to her own path, and a persona read.
