Your prep pack is saved at `/var/tmp/tuesday-measure/1a4/runs/haiku/tuesday/part-5/rooms/case-13-denied-7f35eee6/quillmoor_operations_coordinator_interview_pack.md`. I built it for a recruiter screen with Hannah Lowther. Company research didn't run because web search was refused, so the pack has no company values or interview-process detail.

Say the word and I'll play the Skeptic on B1, the SAP question. The pack names it as your highest-return prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and I can convert the pack to Word if you'd like.

Your notice period is the one thing the material doesn't give me, and it changes the logistics answer. What is it?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations_coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

Recruiter screen, 30-minute phone call, Thursday 2pm, with Hannah Lowther (Talent Partner). Candidate: Sam.

## How to use

Personas describe how a question is asked; types describe what is being scored. Type key: **JD** = the advert's own requirement; **EXP** = what you actually did. Guidance is scaffolding, not a script. Quotes in the tables are your own sentences, and the answers are yours to say in your own words.

This pack has 15 questions. That is below the usual 18 to 26 because it is a 30-minute recruiter call, and the depth went to the logistics questions and the most likely objection (B1).

No company research ran (see Sources), so there are no company-values or strategy questions.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | The quote reaches the requirement. Medium because it is your own sentence with nothing inspected behind it, so expect a question on it. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material shows delivery scheduling across three depots, not production scheduling across planning, the warehouse and QA. Keep the bridge at that scope: "I schedule deliveries for our three depots." Answer slot: if you have coordinated work between production, planning or QA, say what and how, in your own words; if not, say so plainly and stay with the depot scheduling. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | none | The quote reaches the requirement. Words: "I chase suppliers when orders slip." |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | The quote reaches the requirement. The "about a third" is your figure, so it draws the defend-the-number questions in C1 and C2. |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show any dispatch reporting. Answer slot: if you have reported on dispatch timing on any regular basis, say what you reported and how often; if you have not, say so plainly and say how you would set such a report up. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | transferability | Your material names a spreadsheet, not Excel. Keep the bridge at that scope: "I rebuilt our stock-count spreadsheet." Answer slot: which spreadsheet software it was and what the rebuild involved, in your own words. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | high | [grounded] | capability | You stated the SAP absence, so the words are the plain acknowledgment: "I haven't used SAP." Then how you would learn it, said as a plan and never as a past. Do not describe the in-house stock system as ERP experience. |
| F8 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your figure sits inside the advertised band. Your own figure is the only pay content in the pack. |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Met by your own stated limit. |
| F10 | "your notice period" (Hannah Lowther's message) | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. Surfaced, not bridged: give your actual notice period. The Step 1 question below asks for it. |

## Persona table

| Persona | How it shows up | Likelihood, and why | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly walk-through, then the logistics: pay, notice, location, reason for moving | Top weight. A recruiter screen is logistics in a friendly register, and each logistics topic is scored | Say each logistics answer once, in your own words, and stop |
| Skeptic | Quiet probing of the SAP gap, production scheduling, dispatch reporting and Excel | Mid weight. The advert's requirements that your material does not reach (F2, F5, F6, F7) are where a recruiter checks first | Hold the quoted sentence; name the gap plainly; describe how you would close it, as a plan |
| Data-Driven Prober | Asks how the "about a third" was counted and what you did yourself | Mid weight. The figure is the one number in your material | Say what you know about how it was counted, and say plainly what you do not know |
| Pressure / Stress | Time-boxed challenge on fit against someone with SAP | Low weight for a recruiter, but one likely test | Hold the position on your depot and stock-count work through two follow-ups; concede the SAP gap specifically |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Production scheduling across planning, the warehouse and QA | Inflated form of F2 | "I schedule deliveries for our three depots." Your material says delivery scheduling, not production scheduling. |
| Any SAP or ERP experience, or calling the in-house stock system an ERP | You stated the SAP absence (F7) | "I haven't used SAP." Describe the in-house system as what it is. |
| Advanced Excel | Inflated form of F6 | "I rebuilt our stock-count spreadsheet." |
| Owning the stock-control process | Inflated form of F4 | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." |
| A pay range, a floor, flexibility or a counter-offer | You gave one figure only (F8) | "I'm hoping for £42,000." |

## Question banks

### A. Conversational / Rapport (weight: 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me a bit about your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | A 90-second arc: the four years, the three depots, what you schedule, and the chasing, in that order and in your words. | F1, F2 and F3 are the first things a recruiter checks, and the arc sets them up. |
| A2 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say it in those words. Add no further reasons and no comment on your employer beyond the quote. | Reason for leaving is a logistics topic. Its slot is the quote, kept whole. |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Say it in those words. Do not add commute details, and do not offer a different pattern. | F9 is the logistics slot for location and the advert's own pattern. |
| A4 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say the figure in your words: "I'm hoping for £42,000." If pressed for more, you can ask what band is budgeted for the role first, or decline to name a lower figure. Add no range, floor or flexibility. | F8 is the pay slot. Your one figure fills it; nothing asks why it is that figure or what you would take. |
| A5 | "What's your notice period?" | JD | [grounded] "your notice period" (Hannah Lowther's message) | Give your actual notice period. Your material does not give one, so this slot is an instruction, not a figure. | F10 is a hard gate your material does not establish. Answer it plainly. |

### B. Skeptic (weight: 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What's your experience with SAP or a similar ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | **Highest-ROI prep in this pack.** Hold: "I haven't used SAP." Then say what your in-house stock system does, in your words, and how you would learn SAP, as a plan. Hold through two follow-ups by returning to the in-house system; never claim ERP experience. Concede the gap specifically, not in general. | F7 is the gap the advert names as a plus, and the likeliest objection. It will come in some form. |
| B2 | "The role coordinates production across planning, the warehouse and QA. Where have you done that?" | JD | [grounded] "I schedule deliveries for our three depots" | Say that you schedule deliveries across three depots. Answer slot: if you have coordinated work between production, planning or QA, say what and how, in your own words; if not, say so plainly and stay with the depot scheduling. | F2 is transferability. The honest answer is the adjacent work and its limits. |
| B3 | "The role reports weekly on on-time dispatch. Have you produced a report like that?" | JD | [grounded] "report weekly on on-time dispatch" (advert) | Answer slot: if you have reported on dispatch timing on any regular basis, say what and how often; if you have not, say so plainly and say how you would set the report up. | F5 is discovery: your material is silent on this. |
| B4 | "The advert asks you to be confident with Excel. What did you build in the spreadsheet?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Say what you rebuilt, in those words. Answer slot: which spreadsheet software it was. Do not describe any Excel skill your material does not show. | F6 is transferability. The spreadsheet is yours; the Excel label is the advert's. |

### C. Data-Driven Prober (weight: 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was the discrepancy figure counted, and over what base?" | EXP | [grounded] "discrepancies fell by about a third over a year" | Answer slot: say how the discrepancies were counted, which assumption behind the figure you would defend least, and which part was yours. If you do not know how it was counted, say so. | F4 carries the figure, so it is the likeliest place to be probed. The slot asks only about the figure. |
| C2 | "Which of the stock-count changes did you make yourself?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet" | Say which parts you did yourself. If others made some of the calls, say so. | F4 again. Attribution is the question. |
| C3 | "How many deliveries a week does your scheduling cover?" | EXP | [grounded] "I schedule deliveries for our three depots" | Say the number if you know it. If you do not, say that you do not know. | A denominator for F2. Guidance gives no number. |
| C4 | "When an order slips, what do you do first?" | EXP | [grounded] "chase suppliers when orders slip" | Describe the chase in your own words. Say only what you actually do. | F3 is the late-orders requirement, asked in practice. |

### D. Pressure / Stress (weight: 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we consider you over someone with SAP?" | JD | [grounded] "I haven't used SAP" (F7); "I schedule deliveries for our three depots" (F2) | Hold on your depot scheduling and stock-count work, in those quotes. Concede the SAP gap specifically. Do not claim SAP or invent a strength. | A time-boxed version of B1. Hold the position through two follow-ups before you concede the gap. |
| D2 | "You've been a logistics coordinator for four years. What makes this step up?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" | Answer from your own material: the depot work and the stock-count work. Do not add ambitions or claims you have not stated. | A step-up question. The answer is the quotes at their own scope. |

## Reverse questions

Each one has a "why it lands" line. Use three or four.

1. "What does the handoff between planning, the warehouse and QA look like day to day?" Why it lands: it shows you are thinking about the seams the role sits on.
2. "How is on-time dispatch measured and reported at the moment?" Why it lands: it leads straight into B3 from your side.
3. "Which system holds production and stock data today?" Why it lands: it asks about SAP directly, and the answer tells you what to learn.
4. "How is the Avonmouth pattern set, and which days does the team work on site?" Why it lands: it shows you have thought about the hybrid pattern in practice.
5. "What happens after this call, and when would you expect to hear from the team?" Why it lands: Hannah said she would cover next steps, so this asks for them.
6. "What would a strong first three months look like in this role?" Why it lands: it gives you the team's own standard.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1, D2 |
| Coordinate production schedules between planning, the warehouse and QA | B2, D1 |
| Track supplier deliveries and chase late orders | A1, C4 |
| Keep stock records accurate | C1, C2 |
| Report weekly on on-time dispatch | B3 |
| Confident with Excel | B4 |
| ERP experience (SAP or similar) a plus | B1, D1 |
| £38,000–£44,000 | A4 |
| Hybrid: two days a week at Avonmouth | A3 |

## Sources

- Provided: Hannah Lowther's LinkedIn messages (arrangements and the list of topics for the call); the job advert as pasted; your background as described in your message.
- Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Searched "Quillmoor Diagnostics values": refused. Would have moved the values section, which a recruiter screen does not normally need. |
| 2. Quillmoor Diagnostics interview process, operations coordinator | unavailable | Searched "Quillmoor Diagnostics Avonmouth interview process operations coordinator": refused. Would have moved the persona weights for the later rounds. |
| 3. Quillmoor Diagnostics strategy / recent news | skipped | No company-strategy question is in this pack, and a recruiter screen does not turn on strategy. |
| 4. Hannah Lowther Quillmoor Diagnostics | unavailable | Not sent once search was refused. Would have moved the interviewer read and the reverse questions. |
| 5. Representative operations coordinator JD | skipped | The advert was supplied, and it fixes the fit snapshot. |

## Upgrade menu

- Your notice period (Step 1 question) → answers the hard-gate row F10 and fills logistics slot A5 in your own words.
- Your CV → rows F1 to F4 and F6 quote your CV line instead of your message, so they can be read as your CV.
- A note from Hannah on any test or deliverable she declares before the call → a build section for it.
- Search permission granted → the two company searches (values and interview process) rerun, adding the values and loop sections if they establish anything.
