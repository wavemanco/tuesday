# Brennock Facilities Ltd: Remote Administrative Assistant interview prep pack

- **Role:** Remote Administrative Assistant
- **Company:** Brennock Facilities Ltd
- **Interviewer:** the office manager (name not given). Relationship: hiring-manager prior.
- **Round:** 30-minute video call
- **Built from:** your message only (the invite, your summary of the ad, your background). No research has run.
- **Regeneration:** none. This is the first version.

## How to use

Personas describe how a question is asked. Types describe what it is scoring. The guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

Type key:

- **VAL**: values alignment. Not used this round.
- **EXP**: your own past work, checked for accuracy and attribution.
- **JD**: the duties listed in the ad.
- **CO**: company knowledge. Not used, because no research has run.
- **CASE**: a live problem from the role, answered as it happens.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your message) | "I ran the appointment book for four physios, as a receptionist at a physiotherapy clinic" (your message) | medium | [grounded] | transferability | Bridge: "I ran the appointment book for four physios, as a receptionist at a physiotherapy clinic." Your material says an appointment book for four physios, not calendars for people beyond the clinic. That limit is this pack's observation, not words for you. Answer slot: if you managed bookings for anyone beyond the clinic, say who and how; if not, stay with the book. |
| F2 | "booking travel" (your message) | none given | none | [grounded] | discovery | Answer slot: if you have booked travel for anyone, say what, for whom and how. If you have not, say so plainly, and say how you would learn the company's booking tools. Nothing in your material shows travel booking. |
| F3 | "preparing documents in Word and Excel" (your message), Word part | "I'm good with Word" (your message) | medium | [grounded] | none | Bridge: "I'm good with Word." It is a self-rating, so expect a probe. If you have prepared a document you can name, have it ready. |
| F4 | "preparing documents in Word and Excel" (your message), Excel part | "okay with Excel" (your message) | low | [inferred] | discovery | No bridge claim. "Okay" is the most your material says, and a low-confidence claim is not asserted as your story. Answer slot: if you have used Excel for a specific task, name it; if not, say what you would learn first. Derived from the "okay with Excel" sentence. |
| F5 | "processing supplier invoices" (your message) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | Bridge: "I chased unpaid invoices." This pack's observation: chasing payment is not the same as processing an invoice. Answer slot: if you entered, checked or approved supplier invoices, say how; if not, say what chasing involved and how you would learn the approval steps. |
| F6 | Right to work and work location for the role (role-family requirement, not from your inputs) | none given | none | [generic] | hard_gate | Your material does not establish either. Surfaced here, not bridged. The one question this gate allows is asked in the message that presents this pack, not in this file. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed executive calendars | Inflated form of F1 | "I ran the appointment book for four physios, as a receptionist at a physiotherapy clinic." The quote at its own scope. Your material says the book, not executive calendars. |
| Processed supplier invoices | Inflated form of F5 | "I chased unpaid invoices." The quote at its own scope. Chasing is not processing. |
| Expert in Excel | Inflated form of F4 | "okay with Excel." The quote at its own scope. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight and depth |
|---|---|---|---|---|
| Case / Strategist | Live problems from the role: rooms, travel, invoices, a Word document | High. An office manager is the closest prior to a hiring manager, who buys capability and checks for gaps. Every duty in the ad is practical, so scenarios are the natural format. | Clarify, structure, then speak the steps aloud. Do not claim a past event to support a step. | Top weight. 5 questions (B1 to B5). |
| Skeptic | Probes on the gaps: travel, invoices, Excel | High. Three of the five duties have no evidence or thin evidence (F2, F4, F5). | Rehearse A2 until the honest answer is boring. State limits plainly. | Top weight. 5 questions (A1 to A5). |
| Data-driven prober | Asks how the work was done, and for figures | Medium. Your process at the clinic is the one place a follow-up goes deeper. | Describe your process in your own words. Name the part you are least sure of. | Mid weight. 3 questions (C1 to C3). |
| Conversational / Rapport | A warm opener and a casual question | Medium. A 30-minute call starts with rapport, and casual questions are still scored. | A 90-second background arc, ready to go. | Mid weight. 3 questions (D1 to D3). |
| Pressure / Stress | A short challenge to your fit | Low. Thirty minutes is short, and this is an admin role. | Hold your position through two follow-ups, then concede the specific part that is true. | Low weight. 2 questions (E1 and E2). |

## Question banks

### Bank A: Skeptic (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This job is calendars, travel and documents. Your background is a physiotherapy clinic. What is your case for it?" | JD, EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message); "I ran the appointment book for four physios" (your message) | Say the two quoted facts in your own words, then the one closest to the job: the appointment book. Do not stretch it into calendars for people beyond the clinic. | F1 is the fit case, and the question presumes the background gap the quotes already state. |
| A2 | "Tell me about a time you booked travel for someone." | JD, EXP | [grounded] "booking travel" (your message, the ad's line) | Answer slot: if you booked travel for anyone, say what you booked, for whom and how. If you did not, say so plainly, and say how you would learn the company's booking tools in your first week. Hold through two follow-ups by returning to the bookings you can name, never by adding travel to them. | F2 has no evidence, so this is the probe most likely to land where your material is thinnest. This is the highest-ROI prep in the pack. |
| A3 | "Supplier invoices come in and need checking before payment. What have you done with them?" | JD, EXP | [grounded] "chased unpaid invoices" (your message) | Start with the line: "I chased unpaid invoices." If you entered, checked or approved supplier invoices, say how. If you did not, say what chasing involved and how you would learn the approval steps here. | F5. Chasing payment is not processing, and the answer keeps the two apart. |
| A4 | "You say you're okay with Excel. What would you build in Excel for this job?" | JD, CASE | [grounded] "okay with Excel" (your message) | Keep to "okay." Answer slot: name a sheet you have made, if you have. If not, say what you would build first and how you would learn it. Do not describe a formula you have not used. | F4 is low confidence, so "okay" is the most you can claim. |
| A5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "managing calendars, booking travel, preparing documents in Word and Excel, and processing supplier invoices" (your message) | Name the part you have least evidence for, in your own words, then a plan for your first two weeks. A plan is not a past. | The Skeptic's stock stem. F2 and F4 are where it lands. The answer is a plan, not a claim. |

### Bank B: Case / Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A director's flight is cancelled the morning of a board meeting. Walk me through what you do." | CASE | [generic] | Structure: clarify the new time and the options, rebook, tell the people affected, record what changed. Say the steps aloud. Make no claim about a past event. | Travel booking has no evidence (F2), so this tests the thinking the job needs. |
| B2 | "Two supplier invoices arrive for the same amount on the same day. What do you do?" | CASE | [generic] | Structure: check for a duplicate, hold both, confirm with the supplier, record the decision. | F5 is thin, so a live problem tests the process. |
| B3 | "Your manager needs a three-page proposal in Word by Friday. You have two days. Plan it." | CASE | [generic] | Structure: what the document must do, the outline, who signs it off, the time for each stage. | Covers the Word line in F3. |
| B4 | "Two senior people need the same meeting room at 10am. How do you decide?" | CASE | [generic] | Structure: who has priority by role, whether either can move, what you send and to whom. | Covers managing calendars (F1). |
| B5 | "Show me how you'd set up a simple tracker in Excel for invoices due this month." | CASE | [generic] | Structure: the columns you need, how you would flag overdue rows, how you would check the total. Describe the design; do not claim you have built one. | Covers the Excel line, where F4 is low. |

### Bank C: Data-driven prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Describe how you kept the appointment book up to date for four physios." | EXP | [grounded] "I ran the appointment book for four physios" (your message) | Describe what you did, in your own words, including what you used if you can say. Name the part of that process you would be least sure of. | A prober scores whether the process you describe is yours. F1 is the quote it rests on. |
| C2 | "How many unpaid invoices did you chase, and how did you track them?" | EXP | [grounded] "chased unpaid invoices" (your message) | Give a figure only if you counted it, and say what it counts. If you did not keep a count, say so plainly. | F5. A figure you cannot defend is worse than none. |
| C3 | "What is the most complicated thing you have done in Excel?" | EXP | [grounded] "okay with Excel" (your message) | Answer slot: name it if you have done it. If the most you have done is simpler, say so and name that. Do not describe a formula you have not used. | F4 again. The probe asks for the depth "okay" does not show. |

### Bank D: Conversational / Rapport (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message); "chased unpaid invoices" (your message) | A 90-second arc: the clinic, the appointment book, the invoices, and what you want next. Stop before you name anything you did not say. | A casual opener is scored. This one carries your strongest quoted facts. |
| D2 | "What part of admin work do you enjoy most?" | EXP | [generic] | Name one task you liked and why, from your own experience. | A rapport question scored on whether your interest matches the job. |
| D3 | "How do you keep your work organised when you're not in an office?" | JD | [generic] | Answer slot: describe the routines you actually use. If you have none yet, say what you would set up. | The role is remote, so an honest routine is the test. Covers remote working. |

### Bank E: Pressure / Stress (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone with direct admin experience?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | Hold: state the two years and the appointment book. Through two follow-ups, hold the position. Then concede specifically the part of the job you have least evidence for, and say how you would learn it. | Pressure tests composure. The concession is the part that is true. |
| E2 | "That's one job on a CV. How much of that was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" (your message) | Say which parts you ran yourself, in your own words. Do not extend the sentence to the clinic's wider work. | An attribution probe. The quote sets the limit. |

## Coverage

| Requirement (from your message) | Questions |
|---|---|
| managing calendars | A1, B4, C1 |
| booking travel | A2, A5, B1 |
| preparing documents in Word and Excel | A4, B3, B5, C3 |
| processing supplier invoices | A3, B2, C2 |
| remote working (the role is remote) | D3 |

Session total: 18 questions.

## Reverse questions

Five questions to ask the office manager. Each has a reason it lands. None asks about the invite, its fee, its cheque or its document requests.

1. "Is the 30-minute call the only stage, or is a second conversation planned?" Why it lands: it tells you how much prep the next stage needs.
2. "Which travel booking tools would someone in this role use day to day?" Why it lands: it turns the booking-travel gap into a concrete question about the real work.
3. "How are supplier invoices checked and approved here, and who signs off?" Why it lands: it shows whether the job is entry, checking or approval, which decides how you answer A3.
4. "What does a typical week look like for whoever holds this role?" Why it lands: it maps F1 and F3 to the real work.
5. "What would someone in this role need to have done by the end of their first month?" Why it lands: it shows you are thinking about delivery, not only about getting the job.

## Sources

- **Provided documents:** your message (the invite, your summary of the ad, your background). No job description text was supplied, so requirement quotes are the words of your summary.
- **Searches and fetches:** none run.

Research tier: L0. No searches or fetches have run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Brennock Facilities Ltd values | unavailable | Would have moved the values cheat sheet, which this round does not need. No research consent given yet. |
| 2. Brennock Facilities Ltd interview process, administrative roles | unavailable | Would have moved the loop structure and the persona weights. No research consent given yet. |
| 3. Brennock Facilities Ltd strategy and recent news | unavailable | Would have moved the grounding brief. No research consent given yet. |
| 4. Office manager's name | n/a | No name was given, so there is no query to form. |
| 5. Representative job description for the title | skipped | Your summary of the ad fixes the fit snapshot's requirements. |

## Upgrade menu

- The full ad text → the requirement rows quote the ad's own words instead of your summary.
- The office manager's name, from the company's own careers page → persona weights and a tailored reverse question.
- Your work location and right-to-work status → clears the F6 gate row.
- One real example of booking travel, handling invoices, or making a Word or Excel document → F2, F4 or F5 gets a grounded bridge.
- Consent to default research → the values, interview process and strategy rows.
- A tuesday-dossier.md → would carry any verified evidence and prohibited-claim limits into this pack.
