# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

Round: text-chat interview with the support team lead, on Telegram. Built on a team-lead (hiring-manager) prior: the team lead buys capability and checks the gaps.
Research: none run. Web search was refused in this session, so company values, process and strategy are not established here (see Sources).

## How to use this pack

Personas are how a question arrives. Types are what is being scored: JD (the ad's requirements), EXP (your past work), CASE (a live problem), VAL (values; none detected here), CO (company knowledge; none run).
Guidance is scaffolding, not a script. In a text chat you have time to write, so write your answer as you would send it, then check every sentence against the quotes in its row.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (job ad, as you summarised it) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | none | Your material gives the title customer service advisor, not customer support. Say the title and the three years in those words. Expect a probe on whether energy-supplier service work is the same job. |
| F2 | "experience with Zendesk or a similar ticketing tool" (job ad, as you summarised it) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | Freshdesk is the similar tool the ad names. Zendesk is not in your material, so do not claim it. Say you use Freshdesk every day, and describe what you do in it. |
| F3 | "clear written communication" (job ad, as you summarised it) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Volume of replies is not the same as clarity, and your material does not show how any reply of yours was judged. Answer slot: if a reply of yours was checked, praised or complained about, say which and what happened. If none was, say so plainly and describe how you would keep a written reply clear. |
| F4 | "confidence handling escalations" (job ad, as you summarised it) | "I trained four new starters on our refunds process last year" (your message) | low | [inferred] | discovery | Training four people on refunds touches the requirement without showing it. Your material does not show you took escalations. Answer slot: if a case you could not settle at first contact was yours to pass on or take, say what it was and what you did. If none was, say so plainly and describe how you would decide when to escalate. |
| F5 | Working for a software company or on a software product (role-family prior, not in the ad as you summarised it) [generic] | "I've never worked for a software company" (your message) | none | [grounded] | capability | Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan, never as a past. Add nothing to make the gap feel smaller. |
| F6 | "remote Customer Support Specialist" (your message) | none given. Your material does not establish where you can work from, or whether you can work for this employer from there. | none | [grounded] | hard_gate | Surfaced, not bridged. Your material says nothing on this gate. The one question about it is in the closing questions. |

Gap types follow the routing rule: F1 and F2 are none because a quote reaches the requirement; F3 and F4 are discovery because the evidence touches the requirement without showing it; F5 is capability because you stated the absence; F6 is a gate the material does not settle.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| "I have handled escalations" | Inflated form of F4 | The refunds-training quote at its own scope. The limit is the pack's observation: your material says training, not escalations. |
| "I know Zendesk" or "I have used Zendesk" | Inflated form of F2 | "I use Freshdesk every day." Zendesk is not in your material. |
| "I designed the refunds process" | Inflated form of F4's quote | "I trained four new starters on our refunds process last year." Training is not designing. |
| "I know how software products work" or "I have worked in software support" | Negative you stated, F5 | Plain acknowledgment: "I haven't worked for a software company." No slot. |
| "I handled 60 contacts a day with clear, high-quality replies" | Inflated form of F3 | "Answering around 60 calls and emails a day," with the limit stated as the pack's observation. |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy | Weight and depth |
|---|---|---|---|---|
| Skeptic | Asks about the software gap and the missing Zendesk, in the team lead's own words | Highest. A team lead hiring a support specialist checks the gap first (F5, F2). | Say the gap before they do, in plain words. Then the sentence you can back. | 5 questions (top) |
| Case / Strategist | A live support scenario typed into the chat, scored on the reply itself | High. A text chat is a written test (F3, F4). | Clarify, acknowledge, check the facts, state the next step and when the customer will hear back. | 4 questions |
| Pressure | Time-boxed challenge on why you over an internal candidate, and on escalations | Medium-high. Escalations are one of the four requirements (F4). | Hold a position through two follow-ups. Concede the software gap specifically. Do not fold on what you do. | 4 questions |
| Data-Driven Prober | Asks how the 60-a-day figure breaks down and what you did in Freshdesk | Medium. A single headline figure is the usual probe (F3). | Give only the split and the counting method you know. Say when you do not know. | 3 questions |
| Conversational | A friendly opener in the chat, scored as casually as the rest | Low to medium. Casual openers are still scored. | Use a short arc: where you started, the three years, the tool, the training you gave. | 2 questions |

## Question banks

Coverage: every stated requirement has at least one JD-tagged question, or a stated reason it does not.

| Requirement | Covered by |
|---|---|
| 2+ years in customer support | F1: A4, E1 |
| Zendesk or a similar ticketing tool | F2: A3, D2 |
| Clear written communication | F3: B1, B3, C3 |
| Confidence handling escalations | F4: B2, B3, B4, C4 |
| Remote working and right to work | F6: none, and why: the gate is for the closing questions, not a bank question |

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't worked for a software company. What would make you effective on our product in the first month?" | JD | [grounded] "I've never worked for a software company" (your message) | Plain acknowledgment: "I haven't worked for a software company." Then say what you would learn first and how you would check that you have learned it, in your own words. This is a plan, never a past. Hold through two follow-ups by returning to the plan. | F5 is the most predictable objection and the one most likely to be asked in some form. This is the highest-ROI rehearsal in the pack. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" (your message); [grounded] "I use Freshdesk every day" (your message) | Name the software gap first, then the sentence you can back: "I use Freshdesk every day." Do not add a weakness you have not stated. | F5 and F2 are the two rows an interviewer will weigh together. |
| A3 | "I don't see Zendesk in your background. How would you handle it in this role?" | JD | [grounded] "I use Freshdesk every day" (your message) | Say you use Freshdesk every day, and that it is a similar tool. Answer slot: if you have used any other ticketing tool, name it and what you did with it; if not, say so plainly and say how you would learn Zendesk. | F2 is the similar-tool match, and the question is a direct probe on the Zendesk line. |
| A4 | "You have three years in energy-supplier customer service. What carries over to support for a software company?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | Name the overlap in your own words: the three years of advisor work and the daily ticketing tool. Say what does not carry over. | F1 and F5: the transferable part at its own scope, with its limit stated. |
| A5 | "Why are you leaving energy customer service?" | JD | [generic] | Give your own reason in your own words. Your material does not give one, so this guidance supplies none. | A motivation probe every team lead asks; no claim about your past is made here. |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes that they were charged twice and is angry. Reply to them here, then tell me what you would do next." | CASE | [generic] | Write the reply as you would send it: acknowledge, say what you will check, and say when they will hear back. Then state the next step in one sentence. | A live written test in the text chat (F3). It presupposes nothing about your past. |
| B2 | "A ticket has sat for five days. The target is twenty-four hours. What do you do?" | CASE | [generic] | Structure it: what you check first, who you tell, what you say to the customer, and when you would escalate. | Escalation is a stated requirement (F4), tested as a live problem. |
| B3 | "You need to pass a case to a product engineer. Write the note in two sentences." | CASE | [generic] | Two sentences: what the customer needs and what you have already checked. | Escalation written down, scored on clarity (F3 and F4). |
| B4 | "A customer asks you to bend the refund policy. What do you say?" | CASE | [grounded] "I trained four new starters on our refunds process last year" (your message) | You can draw on the refunds process you trained others on, without saying what it contains. If you are unsure of a rule, say you would check it before offering anything. | F4 adjacency: the question is about policy, so the answer does not claim you set it. |

### C. Pressure (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we hire someone without a software background over an internal candidate?" | JD | [grounded] "I've never worked for a software company" (your message); [grounded] "I use Freshdesk every day" (your message) | Pause, then restate the question. Hold the position on the daily ticket work you do. Concede the software gap specifically, without folding on the rest. | F5 under pressure, with F2 as the position held. |
| C2 | "That's about 60 contacts a day. How many of them did you resolve yourself?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Give the number you can stand behind, in your own words. If you do not know how many were resolved, say so. | F3's figure: a defend-the-number slot, and the honest branch is a stated limit. |
| C3 | "Which of your written replies would you defend most, and why?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Choose one reply you can describe in detail. If none stands out, say so and describe your usual approach to a written reply. | Open prompt on F3's written-volume evidence; it supplies no reply. |
| C4 | "The refunds process you trained others on: how much of it was actually yours?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Say what you did: the training you ran. If the process itself was not yours to set, say so plainly. | F4 under pressure: it separates training from ownership. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How many of your 60 a day were calls, and how many were emails?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Give the split only if you know it. If you do not, say so. | F3's figure: a defend-the-number question on the same quote. |
| D2 | "What do you use Freshdesk for every day?" | JD | [grounded] "I use Freshdesk every day" (your message) | Say what you do in it, in your own words. If your use is narrower than the question suggests, say so. | F2: the tool match, tested for depth. |
| D3 | "Which assumption behind that 60-a-day figure would you defend least?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Name, in your own words, the assumption behind the figure that you would defend least. If you do not know how it was counted, say so. | The weakest-assumption move for a headline figure. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, tell me about your journey into support work." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); [grounded] "I trained four new starters on our refunds process last year" (your message) | A 90-second arc: where you started, the three years, the tool, the training you gave. Each beat is a clause the quoted sentence carries. Nothing else. | F1 and F4 as the arc. |
| E2 | "What would you want to be doing in six months?" | JD | [generic] | Answer in your own words. Your material does not say what you want, so this guidance supplies none. | Casual and scored: a stated interest the team lead will test. |

Totals: 18 questions (A5, B4, C4, D3, E2).

## Reverse questions

Each one is a question for the interviewer about the job. None checks the invite or asks for contact details.

1. "What does a typical first week look like for someone starting here?" Why it lands: it shows you are planning the start.
2. "What would make a first month here clearly successful?" Why it lands: it asks for the standard you will be measured against.
3. "How do escalations move between the support team and the product team?" Why it lands: it tests F4 and shows you know escalation matters.
4. "What does the team use for ticketing today?" Why it lets you connect F2 to their tool.
5. "Is there a call or video step after this chat?" Why it lands: it tells you how much prep the next step needs. This is a process question with a prep reason.

## Sources

Provided documents: your message (the invite, your background, your summary of the job ad).

Research tier: L1, searches 2 of 6, fetches 0 of 2. Both searches were refused by the host, so they count against the budget.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Two search calls were refused: "Lumenvale Software careers Customer Support Specialist" and "Lumenvale Software company values interview process". Would have moved the values cheat sheet, which is not included. |
| 2. Lumenvale Software interview process, customer support | unavailable | Same refused calls as target 1. Would have moved the loop structure and the persona weights. The persona weights here rest on a team-lead prior, not on a documented process. |
| 3. Lumenvale Software strategy or recent news | unavailable | No call sent. Would have moved any company-context question; none is in the pack. |
| 4. Interviewer name and Lumenvale Software | n/a | No name was given, so there was no query to form. |
| 5. Representative Customer Support Specialist job ad | skipped | Your summary of the ad fixes the requirement rows and the questions built on them. |

## Upgrade menu

- The full job ad text → the four requirement quotes become exact wording, and A2 and A3 sharpen.
- Lumenvale's careers page text, read or pasted → the values and interview-process targets become available, and the reverse questions can be tied to the company.
- Any ticketing tool you have used besides Freshdesk, or any escalation you handled → F3, F4 and A3 move from answer slots to stories.
- A tuesday-dossier.md would carry the gaps this prep exposed into later sessions.
