# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Panel interview, 45 minutes, Thursday, with Principal Dolores Vantongeren and two members of the fourth-grade team. Built on your résumé, your message, the invite, and public material from the district and a public speaker profile. No job description was supplied, so the requirements below come from the district's own hiring page and a representative listing.

## How to use this pack

- **Personas** describe how a question will arrive. **Types** describe what is being scored: VAL (values), EXP (your past work), JD (the job's stated duties), CO (the district's current direction), CASE (a live problem).
- Guidance is scaffolding for a spoken answer of 90 to 120 seconds, not a script. Use your own words. Where a slot says "answer slot," the honest answer is either branch, and both are acceptable.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Gate shown met by your CV. Bring the license or its ISBE record to the panel's first question about credentials; that document is what raises this to high. |
| F2 | "reading instruction" — district hiring page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | none | Reaches the requirement in role terms. Say the move and the club in those words. Do not add what the curriculum did for students; the material does not say. |
| F3 | "classroom routines" — district hiring page | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [grounded] | discovery | Your material places you in a classroom for six years but does not show routines. Answer slot: describe a routine you set up and how you taught it, in your own words; if you did not set one up yourself, say so and say how you would learn this grade's routines first. |
| F4 | "how you work with families" — district hiring page | "I write a weekly email to families" — your CV | medium | [grounded] | none | Reaches the requirement in a written channel. Name the channel as written. |
| F5 | "each teacher speaks with every family each term" — district beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | Adjacent work: written contact, not conversation. Words: "I write a weekly email to families." Answer slot: if you have spoken with families each term, say how often and how, in your own words; if you have not, say so and say how you would reach every family. |
| F6 | "Fourth Grade Teacher" — invite title | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't taught fourth grade." Then the closure path, as a plan and never as a past. The adjacent work is F3's quote, which is third grade, not fourth. |
| F7 | "work with the grade-level team" — representative listing (K12 Jobs Board) | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | transferability | Team curriculum work reaches the listing's team line only at the scope of that move. Answer slot: if you did this as a member of the team, say what the team decided and what you did; if the decisions were not yours, say so plainly. |
| F8 | "differentiate instruction using assessment data" — representative listing (K12 Jobs Board) | none given | none | [inferred] | discovery | No material shows assessment-based grouping. Answer slot: if you have used assessment data to group students, say which data and how; if you have not, say so and name the first data you would pull for a child who is behind. |

**Confidence and Provenance differ.** Confidence grades your evidence. Provenance grades what this pack says about it. F7 and F8 are [inferred] because they come from a representative listing, not from the district.

**Team lead is not in the material as a requirement.** The panel has two team members, so a leadership probe is likely, and you have stated the absence. It is handled in the prohibited list and in question B2.

## Reading the interviewer

**Dolores Vantongeren, Principal.** Public footprint only. Her profile says she has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist. A 2025 forum talk, "Small Groups, Big Readers," covered weekly reading conferences in grades 3 to 5. (Read from search results; the pages were not opened.)

Practical implications:
- Expect the reading questions to come first, and expect reading to be the lens for the other two topics.
- She will probably ask how you would run reading in a fourth-grade room, not only what you have done.
- Mirror opportunity, a shared professional path: the reading club and the curriculum move sit on the same ground as her work. Use them in your own words, with no claim to her expertise.

**Two fourth-grade team members.** No names or profiles were given, so no interviewer read is built for them. They are weighted as peers.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario questions tied to the district's three beliefs | High. The district's beliefs page says the three beliefs "guide every hire." That is the values detection that applies here. | Map each belief to one quoted sentence where one exists; use a selection scaffold with an honest branch where none does. |
| Skeptic | "You haven't taught fourth grade," "You've never led a team" | High. Principal and team both see the gaps on your CV and in your message. | Rehearse the single most likely objection until it is plain. Say the absence first, then the adjacent evidence, then a concrete plan. |
| Case / Strategist | Live reading or routines problem for a fourth-grade room | Medium-high. Principal, reading specialist background, panel's first topic is reading. | Clarify, then structure, then state a plan with a check at the end. Name what you would need to know. |
| Peer Evaluator | Seams with the team, what you need from them, credit | Medium. Two team members are on the panel. | Reciprocity: what you bring the team, and the seam principles you would propose. |
| Data-Driven Prober | Which assessment data, how you knew a group was working | Medium-low. Listing asks for assessment-based differentiation; your material shows none. | Name what you did measure, if anything; say plainly when you did not track it. |
| Pressure | Time-boxed "why you" and "how much was yours" | Medium. Two panelists are likely to test composure. | Hold the position your quotes carry. Concede the gap plainly and do not fold on the core. |
| Conversational | "Walk us through your journey" | Medium. Opening questions are usually friendly and still scored. | A 90-second arc built only from your quoted sentences. |

## Question banks

Requirement coverage. The invite names one requirement. The hiring page names three topics, and the representative listing adds three more.

| Requirement | Covered by |
|---|---|
| Illinois PEL with elementary endorsement (invite) | F1; not a question, a document check |
| Reading instruction (district page) | A1, C1, P1 |
| Classroom routines (district page) | C2 |
| How you work with families (district page) | A3 |
| Each teacher speaks with every family each term (district beliefs page) | A3, prohibited list |
| Fourth-grade teaching (invite title) | B1 |
| Team work (invite; listing) | B2, D1, D2 |
| Assessment data (listing) | P2 |
| Current district direction (search snippet only) | none, and why: the board's literacy plan was seen only as a search snippet, not opened, so no question presupposes it (see Sources) |

### A. Values, weight 4 (district's three beliefs)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about a time you changed how your grade level taught reading." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on F2: the move, and 2024. Tell the move in your own words. Answer slot: if you saw what the move did for students, say what you saw; if you have not measured it, say so. | Likely from the panel's first topic and the "Every Child a Reader" belief. The question asks for a choice of occasion; the guidance supplies none. |
| A2 | "Tell me how you would make sure a child who is behind in reading does not leave your class without a plan." | VAL | [inferred] from the district's belief "no student leaves third grade without a reading plan" (district beliefs page) | Live problem, not a past claim. Say what you would do first, what you would check, and when you would change it. If you have written plans for individual students, say so; if you have not, say so and describe what you did for struggling readers. | The district names the belief; the question asks for your approach. |
| A3 | "Tell me about a time a family questioned something you had written to them." | VAL | [grounded] "I write a weekly email to families" | Open prompt. Story-mapped on F4: the weekly email. Answer slot: if a family did question something, tell it in your own words; if none did, say so and say what you do when a family writes back. | The "Families Are Partners" belief and the district's family topic; no event is supplied. |
| A4 | "Tell me about a time a check of learning changed a lesson you taught the next day." | VAL | [inferred] from the district's belief "assessments inform teaching and never replace it" (district beliefs page) | Selection scaffold: pick a check of learning that changed a lesson — name the check, the change, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the after-school reading club, and only what you did in it. | Theme comes from the district's third belief; none of your quoted sentences carries an assessment story. |

### B. Skeptic, weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't taught fourth grade. What would you do in your first month?" | JD | [grounded] "I've never taught fourth grade" | Highest-ROI rehearsal in this pack. Say it first: "I haven't taught fourth grade." Then the plan: which fourth-grade material you would learn first, from whom, and how you would check your pacing by week four. Adjacent work: "Six years teaching third grade at a public elementary school in Joliet" as the base, not as a fourth-grade claim. Hold through two follow-ups by returning to the plan, never by adding experience. Concede exactly what you do not know yet. | F6 is the gap they will test. The objection will come in some form, and a calm, specific first answer changes the interview. |
| B2 | "You've never been a team lead. Why would this team trust you to plan with them?" | JD | [grounded] "I've never been a team lead" | Plain acknowledgment: "I haven't been a team lead." Answer slot: if you have planned with colleagues or run a meeting, say what you did and whose decision it was; if not, say what you would bring to shared planning and what you would ask for. | The team is on the panel; this probe is likely from the team members. |
| B3 | "Sixty seconds: why you over a teacher who already teaches fourth grade?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" and [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Pressure form. Hold the base your quotes carry: six years in a classroom and the reading move. Concede fourth-grade experience plainly; do not claim it. | Scored as a motivation probe. The hold is the base and the reading work only. |
| B4 | "That reading curriculum move. How much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Premised on the quote. Hold: "I led the move." Answer slot: if a decision was the team's or the district's, say which and what part you carried; do not claim any choice the material does not show. | Attribution probe on your strongest quoted claim. Answer what you led and say whose decision each step was. |

### C. Case / Strategist, weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Half your fourth graders read two levels below grade on the fall check. What do you do on Monday?" | CASE | none, a live problem | Clarify first: which check, which skills. Objective. Group by skill, not by level. Plan the first two weeks. What you would check by Friday. No past claim. | The panel's reading topic as a live problem; presupposes nothing about you. |
| C2 | "How would you set up classroom routines for a fourth-grade class that is new to you?" | CASE | [generic] role-family pattern | Structure it: the first three routines you would teach, how you would teach one, and how you would know it held. Say what you would take from your third-grade room and what you would test first. | Covers F3, the routines topic on the hiring page. [generic] because it is a pattern, not a fact about this school. |
| C3 | "What would a weekly reading conference look like in fourth grade?" | CASE | [inferred] from the principal's public talk title and summary (search result) | Structure it: length, who attends, what the student brings, what you record. No claim about your past. If you have held reading conferences, say so and what you recorded; if you have not, say what you would start with. | Her public talk covers weekly conferences in grades 3 to 5. Read from a search result, so the label is inferred. |

### D. Peer Evaluator, weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our two rooms share a planning block. Where's the seam between your class and ours, and what happens when we disagree?" | JD | none, a persona stem | Propose seam principles, not facts about their rooms. Disagreement: a story only if one exists in your material; if none does, say so and name the principle you would use. | Peer persona. No quote carries a disagreement story. |
| D2 | "What would you need from us in your first month?" | JD | [grounded] "I've run the after-school reading club for the last two years" | Reciprocity: name what you need (schedule, shared units, their assessments), then what you bring their team: the club's routines, in your words. | Peer persona's reciprocity probe. The club is the one thing your material says you bring. |
| D3 | "How do you handle credit when a unit spans two teams?" | JD | none, a persona stem | Selection scaffold: pick a time work was shared. Name who did what, and say so if any credit was not yours. If none comes to mind, say so and give the principle you use. | Peer persona. Not quoted from your material. |

### P. Data-Driven Prober, weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "How did you know the reading club was working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Premised on the club, and the material does not say how you knew. Answer slot: if you tracked anything, say what and how often; if you did not track it, say so plainly and say what you would track. | Probes the claim behind F2. No outcome is supplied. |
| P2 | "Which assessment data would you pull first for a fourth grader who is behind?" | JD | [inferred] from the representative listing's "differentiate instruction using assessment data" | Answer slot: if you have grouped students with assessment data, say which and how; if you have not, say so and name the first data you would pull. | F8, the listing's assessment requirement. No material shows it, so the honest branch is ready. |

### E. Pressure, weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We have a choice of applicants this month. Give me one reason you should be the one." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Pause. Restate the question. Hold the base: six years in a classroom, and the reading work. After the first follow-up, concede the fourth-grade gap plainly. Do not fold on the base. | Pressure persona. The hold is one your quotes carry, and nothing beyond them. |
| E2 | "Your reading move in 2024. Was it a success?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold the fact of the move. Answer slot: if you saw results, say what and how you know; if you did not measure them, say so plainly. | Pressure persona, testing whether you claim an outcome you cannot show. |

### G. Conversational, weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk us through your journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; [grounded] "I led our grade level's move to a new reading curriculum in 2024"; [grounded] "I've run the after-school reading club for the last two years"; [grounded] "I write a weekly email to families" | A 90-second arc in this order: Joliet and third grade, the reading move, the club, the family email. Use only these sentences. | The casual opener is scored. |
| G2 | "Tell us about the after-school club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | What it is, how long, and what you do in it, in your words. No outcomes unless you have them. | Same quote as D2 and P1; a different register. |

## Values cheat sheet

Detected: the district's beliefs page says three beliefs "guide every hire," which a loop source documents as a values assessment. Page: https://orrinsfordschools.example/about/mission-and-beliefs

| Value (official name) | Working meaning (paraphrased from the page) | Your story |
|---|---|---|
| Every Child a Reader | No student leaves third grade without a reading plan | F2: "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years." Answer slot: if you wrote reading plans for individual students, say so; if not, say so and describe what you did for students who were behind. |
| Families Are Partners | Each teacher speaks with every family each term | F4 and F5: "I write a weekly email to families." Honest branch: you write it weekly; if you have spoken with families each term, say how; if not, say so and say how you would reach every family. |
| Teach for Tomorrow, Not for the Test | Assessments inform teaching and never replace it | No quoted sentence carries this. Selection scaffold ending in its honest branch: pick a check of learning that changed a lesson, name the change, and what happened next. If none comes to mind, say so plainly, then give the nearest thing your material does carry, the reading club, and only what you did in it. |

## Reverse questions

Each ends the panel on your initiative. Ask two or three; the rest are backup.

1. **"What did the reading specialist years teach you that you look for in a classroom now?"** Why it lands: it ties to her public path, nine years as a reading specialist before she became principal in 2022, and turns the panel into a conversation with a reading professional.
2. **"How do weekly reading conferences work in grades 3 to 5, and how do they carry into fourth grade?"** Why it lands: it names her 2025 talk, shows you read it, and asks how the team uses it.
3. **"What could a new teacher do in the first month that would genuinely help this team?"** Why it lands: it is the reciprocity question a peer panel expects, and it asks what they need rather than what you need.
4. **"Which of the three beliefs shows up most in fourth-grade planning?"** Why it lands: it asks the team to show the values the district says guide every hire.
5. **"What happens after the panel: is there a second conversation, and how are references taken up?"** Why it lands: it is a process question, and the district's page says references come after the panel.
6. **"What is the first thing you would want a new fourth-grade teacher to have learned by week four?"** Why it lands: it invites a practical picture of the job and shows you are planning to succeed in it.

## Prohibited claims

The claims this pack will not coach, each with its basis and honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have been a team lead" or "I have led a team" | Negative you stated: "I've never been a team lead" | "I haven't been a team lead." No slot. |
| "I have taught fourth grade" | Negative you stated: "I've never taught fourth grade" | "I haven't taught fourth grade." Then the plan, as a plan. |
| "I chose the reading curriculum" or "I set the grade's reading plan" | Inflated form of F2: your sentence says the move, not the choice | "I led our grade level's move to a new reading curriculum in 2024." Limit, as the pack's observation: your material says the move, not who chose the curriculum or set the plan. |
| "The club or the curriculum produced measured reading gains" | Inflated form of F2: your sentences give no outcome | Quote the club and the move at their own scope. Limit, as the pack's observation: your material gives no outcome figure. |
| "I speak with every family each term" | Inflated form of F5: your sentence is written and weekly | "I write a weekly email to families." |

## Sources

Provided documents: your résumé and message; the panel invite.

Searches and fetches, with what came back:
- Search, "Halvering Elementary School Orrinsford Community School District": no results.
- Search, "Orrinsford Community School District teacher interview process panel values": returned https://orrinsfordschools.example/careers/how-we-hire-teachers and https://orrinsfordschools.example/about/mission-and-beliefs.
- Fetch, https://orrinsfordschools.example/careers/how-we-hire-teachers: opened. Panel format and topics.
- Fetch, https://orrinsfordschools.example/about/mission-and-beliefs: opened. Three beliefs.
- Search, "Dolores Vantongeren principal Orrinsford": returned https://ilprincipalsforum.example/speakers/dolores-vantongeren (search snippet only; not opened).
- Search, "Orrinsford Community School District strategy priorities news 2026": returned https://orrinsfordschools.example/news/board-adopts-literacy-plan (search snippet only; not opened, and not used to build any question).
- Search, "Illinois fourth grade teacher job posting elementary endorsement requirements": returned https://k12jobsboard.example/listings/fourth-grade-teacher (search snippet only; a representative listing, used for [inferred] rows F7, F8 and P2).

Research tier: L1 — searches 5 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | yes | Values cheat sheet, detected from the district's beliefs page (fetched). Search returned no results for the school name, so the values are attributed to the district that runs it. |
| 2. Interview process | yes | Panel format and topics from the hiring page (fetched); persona weights. |
| 3. Strategy / recent news | yes | One search, snippet only. The board's literacy plan (August 2026) was seen but not opened, so it could not be used as a raising source. The CO bank stays generic. A fetched page would move it. |
| 4. Interviewer name and company | yes | Interviewer read and reverse questions C3 and reverse questions 1 and 2. Public footprint only; read from a search snippet. |
| 5. Representative JD | yes | Representative listing (snippet only) supplied the [inferred] requirements F7, F8 and P2, because no JD was supplied. |

## Upgrade menu

- The job posting or description you were sent → the invite gave no requirements beyond the license; with it, F7 and F8 become [grounded], and the requirement coverage table quotes exact text.
- Names of the two fourth-grade team members → per-member persona weights, and a reverse question about their roles.
- The district's board literacy plan, opened or pasted → a strategy question on the grades 3 to 5 reading curriculum set for fall 2027. The plan is seen only in a search snippet, so no question uses it yet.
- Your license document or ISBE record → F1 moves from medium to high confidence.
- Prep time before Thursday → a prioritized prep schedule, which I did not include.
- Any assessment or grouping you have actually used, in your own words → F8 and P2 move from discovery to a story.
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes. Want it? (Offered once.)
