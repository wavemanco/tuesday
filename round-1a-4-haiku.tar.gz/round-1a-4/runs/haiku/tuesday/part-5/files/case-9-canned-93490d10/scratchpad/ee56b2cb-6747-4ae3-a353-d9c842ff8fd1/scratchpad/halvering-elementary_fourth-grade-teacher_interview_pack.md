# Halvering Elementary School: Fourth Grade Teacher panel interview prep

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Format:** 45-minute panel on Thursday
**Panel:** Principal Dolores Vantongeren, plus two members of the fourth-grade team (names not given)
**Mode:** Session. First pack for this interview.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

Type key:

- **VAL**: values alignment. Not used here, because no published values were supplied.
- **EXP**: work-experience deep-dive. Tests whether the CV's claims hold up and what you actually did.
- **JD**: role-driven. Tests the stated requirements, including the gaps.
- **CO**: company knowledge. Not used here, because no company research has run.
- **CASE**: live problem. Tests structure and reasoning on a problem from the role.

Guidance is scaffolding, not a script. Each cell is written to be spoken in 90 to 120 seconds.

## Fit snapshot

No job description was supplied, so the requirements below are the invite's own lines. Every requirement is quoted from the invite, and every piece of evidence is quoted from your CV or message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (the invite) | "registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | Your material states the license, the elementary endorsement and the expiry date, which covers the requirement. The license itself has not been inspected here, so confirm the endorsement and expiry against the document before Thursday. |
| F2 | "Fourth Grade Teacher position" (the invite) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your CV) | medium | [grounded] | transferability | Your material carries adjacent work: third grade for six years. It does not reach fourth grade. The words are the quote at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Plain acknowledgment, which you stated: "I haven't taught fourth grade." Any wider step is an answer slot (see A1). |

Pack observation, in analysis and not as words for you: the invite does not ask for team leadership, so no requirement row carries it. Your CV says you have not been a team lead, and that claim is on the prohibited list below.

## Prohibited claims

Not coached in any answer, hold, bridge or rationale in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Sourced: your stated negative, "I've never taught fourth grade" (your CV) | "I haven't taught fourth grade." |
| Has been a team lead, or led the fourth-grade team | Sourced: your stated negative, "I've never been a team lead" (your CV) | "I haven't been a team lead." |
| Led the grade level | Inflated form of "I led our grade level's move to a new reading curriculum in 2024" (your CV) | The move, at its own scope: "I led our grade level's move to a new reading curriculum in 2024." |
| Runs the school's reading program | Inflated form of "I've run the after-school reading club for the last two years" (your CV) | The club, at its own scope: "I've run the after-school reading club for the last two years." |

## Persona table

Weights follow the relationship priors. The principal is read as the hiring-manager relationship, and the two team members as peers. No interviewer profile was available, so these weights are priors only, not read from anything about the people themselves.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Principal presses on the fourth-grade gap and the team-lead gap | High. Hiring-manager prior: they are buying capability and checking gaps | Plain acknowledgment, then the nearest quote at its own scope, then a ramp step as a plan |
| Case / Strategist | A live reading problem for a new class | Medium. Hiring-manager prior: live problems on the actual role | Clarify first, then the objective, a first step, and a way to check it |
| Peer Evaluator | Team members ask about seams, planning and credit | High. Peer prior, and two team members are on the panel | Describe joint work as joint, and state principles rather than claiming a solved seam |
| Data-Driven Prober | Asks for counts, outcomes and how something was known | Medium. Peer prior. The CV gives three claims a prober can check | Say the count you know, or say you did not count |
| Pressure | Short, time-boxed challenge to one claim | Low to medium. No style signal, so included because every plausible persona gets coverage | Pause, restate, hold the claim through two follow-ups, then concede the specific gap |
| Conversational | Warm opener, scored as casually as any other question | Low weight. Every pack touches it | A 90-second arc that uses only what your CV states |

## Question banks

Question IDs are letter by persona. Ordered by weight.

### A. Skeptic (5 questions, highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. What makes you right for this class?" | JD | [grounded] "I've never taught fourth grade" (your CV); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Plain acknowledgment: "I haven't taught fourth grade." Then the nearest quote at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: if you have prepared for fourth-grade content in any setting, say what you did; if you have not, say so plainly and say what you would do first. Hold through two follow-ups by returning to the third-grade quote, never by adding to it. | F2 is the likeliest objection in this panel, so it gets the deepest rehearsal. The question presupposes the absence you stated, so the plain acknowledgment is allowed. |
| A2 | "You've never been a team lead. What would you bring to a team that already has one?" | JD | [grounded] "I've never been a team lead" (your CV); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Plain acknowledgment: "I haven't been a team lead." Then the move, at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Say what the move involved in your own words, and stop at the move. Answer slot: if you did any work on the move that a team lead would usually do, say which work and how you decided; if you did not, say so and name the part you did. | The invite does not name leadership, so this is a probe you may meet, not one the invite raises. The team-lead gap is stated by you and cannot be closed by wording. |
| A3 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the fourth-grade content first, as the honest answer, using A1's plain acknowledgment. Then name one step you would take in the first week, said as a plan. Do not claim the gap is closed. | A persona stem. The answer is the same gap as F2, so it is rehearsed from the same place. |
| A4 | "What would the first six weeks look like with a fourth-grade class?" | CASE | [generic] | Structure it: what you would check first about the class and its reading, what you would learn from the team in the first two weeks, and what you would change only after that. The guidance makes no claim about your past. | A live problem from the role, asked as a plan. Generic because it is a pattern for the problem, not a fact about this school. |
| A5 | "Why fourth grade, and what made you apply here?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Your CV gives no reason for applying. Give your own reason in your own words, one you can repeat under a second follow-up. Do not build it from the posting. | Motivation consistency is the Skeptic's core test. EXP because it tests whether the choice is yours. |

### B. Case / Strategist (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A child arrives in September reading two levels below the class. What do you do first?" | CASE | [generic] | Clarify first: what the child's reading is measured on and what that shows. Then the objective, the first step, and how you would check whether it works. If you want an example from your material, the nearest is the club: "I've run the after-school reading club for the last two years." Say what the club involved and what you saw in your own words. If you did not check anything, say so. | Reading is the one area your CV supports, so this case lands on it. Generic because the scenario is a pattern for the problem. |
| B2 | "The fourth-grade team wants a new reading block next fall. How would you decide whether it works?" | CASE | [generic] | Name the measure you would use first, the baseline you would need, and what you would do if the result is unclear. Answer slot: did you measure anything when your grade moved to the new reading curriculum in 2024? If you did, say what and how. If you did not, say so and say what you would measure. | A decision method, not a past claim. The slot is the probe the 2024 move would raise. |
| B3 | "How would you explain a new reading program to a parent who wants something different?" | JD | [grounded] "I write a weekly email to families" (your CV) | Use your weekly email as the nearest real practice, in your own words: how you would write to that parent and what you would ask them. Do not claim the email has changed any parent's mind. | The question asks about family communication. The weekly email is the only parent-facing practice your CV states. |

### C. Peer Evaluator (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our team plans together. How would you plan with a team you have just joined?" | JD | [inferred] "two members of our fourth-grade team" (the invite) | Say how you would start: what you would ask for, what you would offer, and what you would bring to their planning. State it as a plan, not as a past. | Peer prior. The team is named in the invite; the assumption that it plans together is a derivation, so it is labelled inferred. |
| C2 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | State a principle for the seam and for disagreement, not a claim that you have solved either. If you have had a disagreement with a colleague, say what happened in your own words and which part was yours. If you have not, say so and give the principle. | A persona stem for peer seams. Principles are safer than a claimed history. |
| C3 | "A grade-level project spans people. How do you handle credit?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Name who did which part of the move, in the terms you know. If the move was shared, the answer is the shares, not the word "led." If you cannot name the shares, say so. | Credit-sharing is the Peer's test. The CV line says "led," so the answer must show what that covered. |

### D. Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How many students came to the reading club, and how did you know it helped?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Say the count you know, in your own words. If you did not count, say so plainly and say what you saw. Do not state a figure you cannot repeat under a second question. | The Prober asks for denominators. The club is the one practice on your CV that could draw that probe. |
| D2 | "Did you track an outcome after the 2024 move? If so, what, and how was it counted?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: if you tracked an outcome, name it, say how it was counted, and name the assumption you would defend least. If you did not track one, say so plainly. | No quote carries a count or an outcome. The second branch allows that nothing was tracked. |
| D3 | "How do you know families read your weekly email?" | EXP | [grounded] "I write a weekly email to families" (your CV) | Say what you can see: replies, the questions parents ask, or nothing. If you cannot see whether it is read, say that plainly. | The weekly email is the one family-facing practice your CV states, and a prober asks whether it reaches anyone. |

### E. Pressure (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has taught fourth grade for years?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your CV) | Pause, then restate the question in your own words. Hold the position your quotes carry: six years of third-grade teaching and two years of the reading club. Concede the gap in the words you have: "I haven't taught fourth grade." Do not fold on the reading work. | The hold-then-concede test. The question presupposes only the candidate and the gap your quotes already state. |
| E2 | "That reading club: how much of its results were actually you?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Answer what you ran: the club, its sessions and what you did in them. If there were results, say which part was yours. If you do not know the results, say so plainly. Hold once, then concede any part that was shared. | An attribution probe. "Ran" is your word, and no results are stated, so the answer is about attribution, not a count. |

### F. Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your CV); "I write a weekly email to families" (your CV) | A 90-second arc in this order: third grade in Joliet, the 2024 curriculum move, the reading club, the weekly email, then why fourth grade in your own words. Each beat says only what its quote says. | Rapport openers are still scored. The arc uses only what your CV states. |
| F2 | "What part of this job are you looking forward to?" | JD | [generic] | One or two sentences, tied to the fourth-grade team or to the reading work your CV states. Keep it short. | A casual question about the role, scored as any other. |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Valid Illinois Professional Educator License with an elementary endorsement | None, and why: your CV states it, and F1 shows it met. The invite raises no probe on it. |
| Fourth Grade Teacher position | A1, A3, A4, A5, E1 |
| Work with the fourth-grade team | C1, C2, C3 |
| Team leadership (not in the invite) | A2: a probe you may meet, not a requirement the invite sets |

## Reverse questions

At least five, each with why it lands. No interviewer profile was available, so none is tied to an interviewer's own path.

1. To the principal: "What do you hope the next fourth-grade teacher will bring to the school's reading work?" Why it lands: it asks for the principal's priority and lets you connect it to the reading work your CV states.
2. "What does the fourth-grade team need most in the first semester?" Why it lands: it shows you are planning for their need, not your own.
3. "How does the team plan together across the grade?" Why it lands: it shows interest in joint work and lets you hear the seam the peers will describe.
4. Peer reciprocity, to the team members: "What could a new teacher do in the first month that would genuinely help your team?" Why it lands: it turns the peers from judges into collaborators, and their answer shows what they need.
5. "What does a successful first year look like in this role?" Why it lands: it asks for the success criteria, which you can then answer against in the close.
6. "Who would I work most closely with outside the grade team?" Why it lands: it shows you are thinking about the whole school, not only the classroom.

## Sources

Provided documents: the invite (your message); your résumé (your CV).

**Research tier:** L0, no searches. Research has not been consented to.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering values | unavailable | Values cheat sheet, section 10. Not built, because no values were in hand and research is not consented. |
| 2. Halvering interview process | unavailable | Loop structure and panel format |
| 3. Halvering and district strategy or recent news | unavailable | Grounding brief, section 6. Not built. |
| 4. Principal Dolores Vantongeren, Halvering | unavailable | Reading the interviewer, and the principal's persona weight |
| 5. Representative Fourth Grade Teacher JD | unavailable | JD-tagged questions and coverage of mid-list requirements |

## Upgrade menu

- The job posting or full JD text: the three requirement rows become grounded in the posting, and mid-list requirements can get their own questions.
- HR's note on whether a demonstration lesson or written task is part of the panel: a graded deliverable section.
- The two team members' names: personas assigned per member, and a reverse question tied to each person's public path.
- Permission for L1 research on Halvering and the district (about six searches and two page fetches): school values, reading-curriculum context and any published panel format, where they exist.
