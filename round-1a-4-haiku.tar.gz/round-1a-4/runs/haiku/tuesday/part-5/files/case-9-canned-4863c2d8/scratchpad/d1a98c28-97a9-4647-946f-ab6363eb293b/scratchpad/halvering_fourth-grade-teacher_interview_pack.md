# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Built for a 45-minute panel: Principal Dolores Vantongeren plus two fourth-grade team members. Built from your message and the invite, with public research at the L1 tier. Assumption: the two team members are peers and the principal is the hiring authority. Names of the team members were not given, so their personas are set by relationship, not by person.

## How to use + type key

- Personas describe how a question arrives. Types describe what is being scored.
- Type tags: **JD** = the posting's stated responsibilities; **EXP** = what you actually did; **VAL** = the district's published beliefs; **CASE** = a live problem; **CO** = company knowledge (no CO question is included; the research did not establish one the panel would use).
- Guidance is scaffolding, not a script. Speak it in your own words, in about 90 to 120 seconds.

## Prep triage

Prep time was not stated, so no schedule is given. Start with **A1**, then **A2**, then **C1**. Those three cover the two gaps the panel is most likely to press and the peer seam. Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | Gate shown met. Say it plainly and give the expiry date if asked. The panel may check it; that check is yours to have ready. |
| F2 | "Panels ask about reading instruction, classroom routines and how you work with families." (district careers page, fetched) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | none | The quote reaches reading instruction in role terms. Limit: one CV line with nothing inspected behind it, so expect a probe on what you decided. |
| F3 | Fourth-grade content, grades 3 to 5 (representative listing, [inferred]: plan and teach reading, writing, math, science and social studies) | "Six years teaching third grade at a public elementary school in Joliet" (your CV) | medium | [inferred] | transferability | Third grade is the year before. Say what your third graders carry into fourth grade. Never describe fourth-grade work as a past. |
| F4 | Fourth-grade teaching experience (the role itself) | "I've never taught fourth grade" (your message) | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn it, as a plan. |
| F5 | Team leadership (not posted; the panel's grade-level members will weigh it) | "I've never been a team lead" (your message) | none | [grounded] | capability | Words: "I haven't been a team lead." Then how you would work with a team that already has routines. |
| F6 | "Families Are Partners: each teacher speaks with every family each term." (district beliefs, fetched) | "I write a weekly email to families." (your CV) | medium | [grounded] | none | The email reaches the family-communication belief in role terms. Limit: the belief names every family each term; say what the weekly email reaches and what it does not. |
| F7 | "Every Child a Reader: no student leaves third grade without a reading plan." (district beliefs, fetched) | "I've run the after-school reading club for the last two years." (your CV) | medium | [grounded] | presentation | Reading-club work is adjacent to the belief. Reword only what the quote says: you ran the club. Do not add a plan or a result. |

**Your material does not establish** a fourth-grade schedule, a team-lead decision, or any measure of the reading curriculum's effect. Those are the three places a probe lands. The answer slots in A and D cover them.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "Chose the new reading curriculum" | Inflated form of F2: your material says you led the grade level's move, not that you picked the curriculum | F2's quote at its own scope. Who chose the curriculum is an answer slot in D1 |
| Fourth-grade experience of any kind | Negative you stated, F4 | "I've never taught fourth grade." No slot |
| Team-lead experience of any kind | Negative you stated, F5 | "I've never been a team lead." No slot |

## Persona table

Panel: the principal is the hiring authority, so the hiring-manager priors apply (Case/Strategist and Skeptic). The two grade-level members are peers, so the peer priors apply (Peer Evaluator and Data-Driven Prober). The research page confirms this is a panel with those three members. The research also shows the panel's questions cover reading, routines and families, which raises the three themes.

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Principal | "You've never taught fourth grade. Why you?" | High. F4 and F5 are the two gaps the material states plainly, and a principal hiring for a grade she has not taught will press them. Weight: 4 questions | Hold the plain acknowledgment, then bridge only with a plan. Concede the gap in one sentence and stop |
| Case / Strategist | Principal | A live problem: a student two years behind in reading | High. A hiring manager scores how you structure a problem, not a past fact. Weight: 3 questions | Clarify, then assess, then small groups, then family contact. Think aloud |
| Peer Evaluator | Grade-level members | Where your work seams with theirs; credit; disagreement | High. Peers price what you cost their team. Weight: 4 questions | Reciprocity first. Propose seam principles rather than pretending to know their seam |
| Data-Driven Prober | Grade-level members | "How did you know the curriculum worked?" | Medium. F2 is a CV line with nothing inspected behind it. Weight: 3 questions | Say what you measured, if anything. If nothing, say so and name what you would measure first |
| Values / Behavioral | Panel, as the district's own beliefs | How your work matches the three beliefs | Medium. The district publishes three beliefs, and the panel's page says the panel asks about reading and families. Weight: 3 questions | Map a story only where a quoted sentence carries one. Otherwise give the selection scaffold and its honest branch |

## Question banks

Provenance comes before guidance. Every quote is taken from your message, your CV, or the district's fetched pages.

### Skeptic (principal), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. Why should we hire you for it?" | JD | [grounded] "I've never taught fourth grade" (your message); [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Hold the plain acknowledgment: "I haven't taught fourth grade." Then the nearest thing your material carries: six years of third grade in Joliet. Then a plan for the first month, said as a plan. Hold through two follow-ups by returning to third grade and to the plan. Concede in one sentence if pressed past that | This is the highest-ROI prep in the pack. F4 is the gap most likely to be raised, and the answer is its honest form. The question presupposes a negative you stated, so it is allowed |
| A2 | "You've never been a team lead. How would you run the grade team's planning?" | JD | [grounded] "I've never been a team lead" (your message) | Plain acknowledgment: "I haven't been a team lead." Answer slot: if you led any part of a shared task, say what you decided, in your own words; if you did not, say so plainly and describe how you would work with a team that already has its routines | F5. The second branch allows that you have not led a team, not only that someone else did |
| A3 | "What changes for students between third and fourth grade, and how does your practice adjust?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Story-map from the quote: third grade, six years. Name one change you would expect at fourth grade and how you would plan for it. Do not claim fourth-grade results | F3. Open question about the transfer, not a claim about your past |
| A4 | "Panels ask about reading instruction. Tell us about the reading curriculum change you led." | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say what you did in the move, in your words, using "led" only as your CV does. If a choice was made above you, say so. Do not add a timeline or a result | F2. The question names the CV line, so it presupposes only what the quote states |

### Case / Strategist (principal), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A student reads two years below grade level by October. What do you do in week one?" | CASE | [generic] | Clarify: what the reading assessment shows and what the student can already do. Then small-group work, then family contact. Think aloud. Name the first step before the plan | Live problem from the posting's reading responsibility. It presupposes nothing about your past |
| B2 | "How would you keep the classroom running on a day you are out?" | JD | [grounded] "Panels ask about reading instruction, classroom routines and how you work with families." (district careers page) | Describe routines you would set, as a plan. If you have a routine that has worked, name it in your own words. Do not claim a past substitute plan | The panel names routines as a theme. The question asks for a method, not a claim |
| B3 | "How do you reach families who are hard to reach?" | VAL | [grounded] "I write a weekly email to families." (your CV) | Say what your weekly email does. If you know whether families respond, say how. If you do not track responses, say so and name what you would track | F6. The Families Are Partners belief is the theme; the email is the only sentence the answer rests on |

### Peer Evaluator (grade-level members), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our two teachers share the fourth-grade team. Where does your work seam with ours?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | The seam you know is the third-to-fourth handoff. Say what your third graders carry into fourth grade, in your words. Propose a seam principle, such as shared assessment dates, rather than claiming to know their seam | Peers ask where you plug in. Your third-grade years are the only sentence that places you at that seam |
| C2 | "What would you need from us in your first month?" | JD | [grounded] "I've never taught fourth grade" (your message) | Name two things you would ask for, as questions. Say what you do not yet know about fourth grade, in your own words | A reciprocity probe. The gap is stated, so it is allowed |
| C3 | "Tell me about a time you disagreed with a colleague about instruction." | VAL | [generic] | Open prompt. If a time comes to mind, use the STAR shape and your own words. If none does, say so plainly, then give the nearest thing your material carries: the grade-level move, or how you would handle it | A peer stem. The question picks an instance, so it presupposes nothing |
| C4 | "When work spans teams, how do you handle credit?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say "our grade level" for shared work and "I" for your own contribution. Use only what the CV line states | Credit is a peer probe. The quote is the only story you have on it |

### Data-Driven Prober (grade-level members), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you tell whether the new reading curriculum worked?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: if you measured anything about the curriculum, say what and with which students. If you did not, say so plainly and say what you would measure first. If someone else chose the curriculum, say so | F2. Your CV does not say what was measured, so the honest branch is the answer |
| D2 | "Which assumption behind your reading club's results would you defend least?" | EXP | [grounded] "I've run the after-school reading club for the last two years." (your CV) | If you have a result from the club, name its weakest assumption first. If you do not have a result, say that. Do not invent one | F7. Quantified claims are magnets for probers; you have none on the CV |
| D3 | "How do you know a family email reached the families it was meant for?" | EXP | [grounded] "I write a weekly email to families." (your CV) | Answer slot: if you check delivery or replies, say how. If you do not, say so and say what you would check | F6. Precise attribution of what the email does |

### Values / Behavioral (district beliefs), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Every Child a Reader says no student leaves third grade without a reading plan. Tell us about one student's plan." | VAL | [grounded] "Every Child a Reader: no student leaves third grade without a reading plan." (district beliefs, fetched) | Open prompt. If you wrote or changed a student's reading plan, tell it in STAR shape in your own words. If not, say so plainly and describe how you would build one | F7. The belief is the raising source; the plan is not in your quotes, so the honest branch is required |
| E2 | "Families Are Partners says each teacher speaks with every family each term. How have you done that?" | VAL | [grounded] "I write a weekly email to families." (your CV) | Describe the weekly email. Do not claim the term-level conversations unless you have had them. If you have not, say what you would add | F6. Your weekly email exceeds the belief's bar in frequency, but speaks to families in writing, not in person |
| E3 | "Teach for Tomorrow, Not for the Test says assessments inform teaching. Tell us about an assessment that changed what you taught." | VAL | [grounded] "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." (district beliefs, fetched) | Open prompt. Give one assessment and one change, in your words. If you cannot name one, say so and describe how you would use one | Raising source: the belief. Your quotes do not carry an assessment story, so the honest branch is the answer |

## Reverse questions

Five, each with why it lands.

1. **To the principal:** "You moved from reading specialist to principal. What from that work do you want a fourth-grade teacher here to carry?" Why it lands: she is a reading specialist turned principal (public profile), so the question converts a probe into a conversation about her own path.
2. **To the principal:** "How do weekly reading conferences in grades 3 to 5 fit with the literacy plan the board adopted in August 2026?" Why it lands: it shows you read her 2025 forum talk and the district's news. Both were found by search; neither was fetched.
3. **To the grade-level members:** "What could a new person do in the first month that would genuinely help your team?" Why it lands: the reciprocity question peers weight heavily.
4. **To the grade-level members:** "How does the grade team split planning, and where would you want that split to change?" Why it lands: it asks about their work and shows you will fit the team's structure.
5. **To any member:** "What does a strong first-year fourth-grade teacher here look like by the end of October?" Why it lands: it asks for the standard, and your answer shows you plan against it.

## Requirement coverage

| Requirement | Source | Questions |
|---|---|---|
| Valid Illinois PEL, elementary endorsement | Invite | None, and why: gate shown met on your CV (F1). The panel will verify it |
| Reading instruction | Careers page, fetched | A4, B1, D1 |
| Classroom routines | Careers page, fetched | B2 |
| Working with families | Careers page, fetched | B3, D3, E2 |
| Grade-level team work | Representative listing, [inferred] | C1, C2, C4 |
| Every Child a Reader | Beliefs page, fetched | E1, D2 |
| Families Are Partners | Beliefs page, fetched | B3, E2 |
| Teach for Tomorrow, Not for the Test | Beliefs page, fetched | E3 |
| Fourth-grade experience | Your message (stated absence) | A1, C2 |
| Team leadership | Your message (stated absence) | A2 |

## Sources

Research tier: L1 — searches 5 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | Three published beliefs (named in E1 to E3 and the family row F6). Values cheat sheet dropped: not detected, since the loop source names no values round |
| 2. Interview process | yes | One 45-minute building panel: principal plus two grade-level teachers, asking about reading, routines and families. Established the loop, so no archetype fallback |
| 3. Strategy / recent news | yes | Board's August 2026 literacy plan (reverse question 2). Found by search, not fetched |
| 4. Interviewer (Dolores Vantongeren) | yes | Principal since 2022 after nine years as reading specialist; 2025 forum talk on weekly reading conferences in grades 3 to 5. Public professional footprint only |
| 5. Representative fourth-grade JD | yes | Typical duties (reading, writing, math, science, social studies; grade-level team; families). Labeled [inferred]; search snippet only, not fetched |

Queries sent: "Orrinsford Community School District values" (returned the beliefs page, fetched); "Orrinsford Community School District teacher interview process panel" (returned the hiring page, fetched); "Dolores Vantongeren principal Halvering Elementary" (returned one forum profile); "Orrinsford Community School District news 2026 strategic plan" (returned the board's literacy plan); "fourth grade teacher job posting Illinois elementary PEL elementary endorsement" (returned one listing).

Provided documents: your message (invite and personal resume).

## Interviewer read

- **Dolores Vantongeren, principal:** reading specialist for nine years, principal since 2022. Her 2025 talk focused on weekly reading conferences in grades 3 to 5. Implication: expect reading questions, and expect her to test whether you know what a reading conference looks like.
- **Grade-level members:** not named, so no read. Personas are set by relationship.
- No shared professional path with the principal was found, so none is offered.

## Upgrade menu

- The posting's full text → turns F3 and the team row from `[inferred]` to `[grounded]`, and tightens the JD-tagged questions.
- The panel's focus areas or a question list from HR → reweights the banks to the named themes.
- The team members' names → per-member persona weights in the interviewer read.
- Your grade-level and fourth-grade plan, in your own words → an answer for A1 and A2 that is yours rather than a slot.
- Any assessment of your working style → delivery coaching, if you choose to share one.
- `tuesday-dossier.md` → would carry the gaps this prep exposed into later sessions.
