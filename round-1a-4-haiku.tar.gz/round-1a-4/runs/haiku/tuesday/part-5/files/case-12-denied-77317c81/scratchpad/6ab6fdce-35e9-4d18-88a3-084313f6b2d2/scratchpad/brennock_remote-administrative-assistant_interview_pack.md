# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Round: 30-minute video call with the office manager. Treated as a hiring-manager round until you say otherwise. Research was not available for this pack (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what it scores:

- **VAL**: values alignment (not used here, no published values)
- **EXP**: your experience, and whether it holds up under scrutiny
- **JD**: the role's stated requirements
- **CO**: company knowledge (not used here, no research)
- **CASE**: a live problem from the job

Guidance is scaffolding, not a script. Say each answer in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your summary of the ad) | "ran the appointment book for four physios" (your message) | medium | [grounded] | presentation | Your words are the appointment book for four physios; say that. Answer slot: the ad's calendar work makes a probe on clashes likely. If you set how double-bookings were resolved, say how; if someone else set it, say so and describe your part. |
| F2 | "booking travel" (your summary of the ad) | none given | none | [grounded] | discovery | Answer slot: have you booked travel for anyone? If yes, say what, for whom and through which tool. If not, say so plainly and say how you would learn the company's booking tool. |
| F3 | "preparing documents in Word and Excel" (your summary of the ad) | "good with Word" (your message) | low | [inferred] | discovery | Your message says good with Word and nothing about documents you produced. Answer slot: name one document you prepared in Word, who it was for and what you did in it. If none, say so plainly and say what you would check first. |
| F4 | "preparing documents in Word and Excel" (your summary of the ad) | "okay with Excel" (your message) | low | [inferred] | discovery | Answer slot: name what you did in Excel and the most involved task. If it was lists or simple sums, say so plainly. |
| F5 | "processing supplier invoices" (your summary of the ad) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | Chasing unpaid invoices is collecting money in; processing supplier invoices is paying them out. The bridge is the adjacent case, with its limit. Answer slot: if you entered, matched or approved any supplier invoice, say which; if you only chased them, say so plainly and describe the chasing. |
| F6 | Remote Administrative Assistant (role title, your message) | none given | none | [grounded] | discovery | Answer slot: if you have worked remotely, say how you kept a shared calendar and inbox in order; if not, say so plainly and describe your setup and how you would check in. |

Gate check: nothing in what you have shared is a gate (a term you either meet or do not). Remote working is F6, a discovery gap.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live admin problems: a calendar clash, an invoice with no purchase order | High. The ad is a list of tasks, and a manager hiring for tasks tests how you would do them | Clarify first, order the steps, say what you would confirm with whom |
| Skeptic | "I don't see travel booking in your background" | High. F2 and F5 are the gaps a manager will see on your CV | Hold to what your material says; concede the gap by name |
| Conversational / Rapport | An open "walk me through your journey" | Medium. A 30-minute call opens with rapport, and the opener is scored | A 90-second arc built on the clinic sentence |
| Data-Driven Prober | "Roughly how big was that book, and how did you count?" | Medium. The appointment book and the invoice chase invite a probe on your part | Say what you know; say plainly when you do not |
| Pressure / Stress | "Why choose you over someone with direct admin experience?" | Low to medium | Hold the position through two follow-ups, then concede specifically |

Weights: Case 5 questions, Skeptic 4, Conversational 3, Prober 3, Pressure 2.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed executive calendars | Inflated form of F1 | "ran the appointment book for four physios". Your material says a clinic's appointment book, not executive calendars. |
| Advanced Excel | Inflated form of F4 | "okay with Excel" |
| Processed supplier invoices for payment | Inflated form of F5 | "chased unpaid invoices". Your material shows chasing, not processing. |
| Produced Word reports | Inflated form of F3 | "good with Word" |

## Question banks

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Three of your calendars clash on Thursday and one executive's flight changes. Walk me through your first five minutes." | CASE | [generic] | Clarify what is fixed (external meetings, the traveller's must-haves), move the flexible items first, confirm with the people affected, then record the changes. Makes no claim about your past. | Calendar and travel work from the ad, as a live problem. Generic because it is a pattern for the problem, not a fact about this employer. |
| A2 | "A supplier invoice arrives with no purchase order. What happens next?" | CASE | [generic] | Check it against the approval rule, ask the budget holder before paying, and record where it sits. | Invoice processing from the ad, as a live problem. |
| A3 | "You have a messy Excel sheet and need a clean Word document by tomorrow. How do you approach it?" | CASE | [generic] | Clarify the audience and format, build the table first, check the numbers against the source, then write the document. | Word and Excel documents from the ad. |
| A4 | "An executive needs Dublin on Tuesday and London on Thursday under a set budget. What do you check first?" | CASE | [generic] | Dates and time windows, the budget cap, the traveller's preferences, then compare two or three options. | Travel booking from the ad. |
| A5 | "What would you do on day one to learn how this office's calendars actually run?" | JD | [generic] | Ask the calendar owners for their recurring commitments, check who has access, and list what must not move. | F1 is where calendar management presses. The question is about learning, so it assumes nothing about your past. |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see travel booking in your background. How would you handle that from day one?" | JD | [grounded] "ran the appointment book for four physios" (your message) | Answer slot: if you have booked travel or supported someone at that level, say how; if not, say so plainly, then describe how you would learn their tool and approval rules. | F2 is the gap. The premise is the interviewer's; the second branch lets it be true. |
| B2 | "You chased unpaid invoices. Have you ever processed supplier invoices for payment?" | JD | [grounded] "chased unpaid invoices" (your message) | Answer slot: if you entered, matched or approved any supplier invoice, say which; if you only chased them, say so plainly. Hold to the chasing; do not stretch it. | F5 is the most likely objection, so this is the highest-return rehearsal in the pack. |
| B3 | "Excel is on the job description. What is the most involved thing you have done in it?" | JD | [grounded] "okay with Excel" (your message) | Answer slot: say what you did and what it was for. If it was lists or basic sums, say so plainly. | F4, low confidence. |
| B4 | "This role is remote. How would you keep a shared calendar and inbox in order without someone next to you?" | JD | [generic] | Answer slot: if you have worked remotely, say how; if not, say so plainly, then describe your setup and how you would check in with the office manager. | F6. |

### Conversational / Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | A 90-second arc: the clinic, what you ran, what you chased, why you want admin work remotely. Use your words, and do not add a role you did not have. | The opener is scored, even when casual. |
| C2 | "What part of admin work do you enjoy most?" | EXP | [grounded] "ran the appointment book for four physios" (your message) | Name the part you would choose and give the example from the quoted sentence. | Tests whether your answer is specific. |
| C3 | "Is there anything in the ad you're wondering about?" | CO | [generic] | Pick one reverse question from the list below. Never answer "I think you've covered everything." | The reverse-question slot is weighted heavily as a preparation signal. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Roughly how big was that appointment book, and how did you keep it accurate?" | EXP | [grounded] "ran the appointment book for four physios" (your message) | Give your own number if you know it; if you do not, say so. Do not estimate on the spot. Answer slot: if a method or check was yours, say which; if none was, say so plainly. | A prober will ask for a figure. The pack does not supply one. |
| D2 | "When you chased unpaid invoices, how did you know which were overdue?" | EXP | [grounded] "chased unpaid invoices" (your message) | Answer slot: if you kept a list or report, say what it was; if you worked from memory or the inbox, say so. | The likely follow-up to B2. |
| D3 | "Which Word or Excel output would you check most carefully before it goes out, and what would you check?" | JD | [grounded] "good with Word" (your message) | Name one output and the check you would run, in your own words. If you have not produced one, say so plainly and name the check you would use. | Tests F3 without assuming it. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why choose you over someone with direct admin experience?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | Hold on the two things your message says: the appointment book and the invoice chase. Concede the travel gap by name; do not fold on the core. | Hold through two follow-ups, then concede specifically. |
| E2 | "That appointment book: how much of the running of it was actually you?" | EXP | [grounded] "ran the appointment book for four physios" (your message) | Say what you did, in order. If the physios set the rules, say so. A precise share beats a grand one. | Attribution probe. Rehearse precision. |

### Coverage of the requirements

| JD requirement (your summary) | Questions |
|---|---|
| managing calendars | A1, A5 |
| booking travel | A4, B1 |
| preparing documents in Word and Excel | A3, B3, D3 |
| processing supplier invoices | A2, B2, D2 |
| remote working (role title) | B4 |

### Reverse questions

1. "What does a typical week of calendar and travel bookings look like?" Why it lands: tells you which of A1 and A4 to rehearse hardest.
2. "Which documents do you prepare in Word and Excel most often?" Why it lands: sets the rehearsal for B3 and D3.
3. "How do supplier invoices move from receipt to payment here?" Why it lands: shows whether the process is clear, and tests B2.
4. "Will the office manager be your day-to-day manager, or someone you would work alongside?" Why it lands: changes the persona weights. If they are a peer, the pack shifts.
5. "Is this 30-minute call the only step, or is there another round?" Why it lands: sets how much prep the next round needs.

## Sources

- Provided: your message (the ad summary, the invite's wording as you quoted it, and your background).
- Searches sent: "Brennock Facilities Ltd" and "Brennock Facilities Ltd Remote Administrative Assistant interview process". Both were refused by the host's permission settings, so nothing came back.

Research tier: L1, searches 2 of 6, fetches 0 of 2. User links read: 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Brennock values | unavailable | Values cheat sheet, not built. Refused. |
| 2. Brennock interview process, role family | unavailable | Would have set the loop structure and the persona weights. Refused. Weights use the hiring-manager prior. |
| 3. Brennock strategy / recent news | unavailable | Would have fed the CO questions. No call sent, since the host refused search. |
| 4. Interviewer name + company | n/a | No name given, so there is no query to form. |
| 5. Representative role JD | unavailable | Your ad summary is not full JD text. A representative JD would have made some rows [inferred]. |

## Upgrade menu

- The full ad text → turns the summary-based requirements (F1 to F6) into quoted lines, and sharpens the coverage table.
- Whether the office manager will be your manager or a colleague → changes the persona weights (manager or peer).
- One anonymised document you prepared in Word or Excel → can move F3 and F4 from low toward medium, since an inspectable artifact is what raises the band.
- Any remote working experience or setup → closes the F6 discovery gap.
- `tuesday-dossier.md` from an earlier session → would add verified evidence and weak-area strategies.
