# Quillmoor Diagnostics: Operations Coordinator, recruiter screen

**Interviewer:** Hannah Lowther, Talent Partner (recruiter)
**Round:** 30-minute phone call, Thursday 2pm, to the mobile number on your application
**Built on:** the advert, your background as you described it, and the recruiter's message. No prior changes.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: EXP (your experience), JD (the listed job's terms), VAL (values), CO (company knowledge), CASE (a live problem).
- The guidance is scaffolding, not a script. Say it in your own words.
- Each guidance cell rests on your own sentences, quoted in the Provenance column. If a cell says something your quote does not, cut it.

## Fit snapshot

Requirements are quoted from the advert. Your evidence is quoted from your own message. Gate rows (G) are terms; the rest are requirements (F).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | No gap. Your sentence already reaches the requirement, with no inspectable proof behind it, so expect a question on it. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material shows delivery scheduling across three depots. It does not show production scheduling, planning or QA. Make the delivery case at its own scope; any wider step is an answer slot (B2). |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | none | Your sentence covers chasing late orders. Tracking deliveries is closest to "I schedule deliveries for our three depots", quoted at its own scope. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet" (your message), "discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | Both quotes are yours. Say them as they are. The figure is covered in C1. |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show weekly reporting of any kind. The answer is an honest slot (B3), not a claim. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [grounded] | discovery | The spreadsheet shows you built one. It does not show how far your Excel goes. Name what you used (C2). |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP" (your message), "we run our own in-house stock system" (your message) | none | [grounded] | capability | You stated the absence. The words you can use: "I haven't used SAP." Then what you run now, and how you would get up to speed as a plan, never as past experience. |
| F8 | Notice period (recruiter's message: "your notice period") | none given | none | [grounded] | discovery | Your material gives no notice period. Give yours in your own words (A3). |
| G1 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Gate met on your own stated constraint. Your statement is the strongest evidence for it. |
| G2 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Gate met on your own figure, which sits inside the advert's band. |
| G3 | Right to work in the UK (not in the advert or the recruiter's message) | none given | none | [grounded] | hard_gate | Your material does not establish this. The pack cannot close it. You are asked one question in the message. |

## Persona table

No loop source establishes more than the recruiter's own description of this call, so the weights are the recruiter-screen prior, not an archetype. There is no interviewer profile, so no interviewer read is included.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly opener, "walk me through", logistics asked casually | High. Her message sets the agenda in a friendly register: pay, notice, hybrid, reason for leaving. Weight 5 questions. | A 90-second background arc. Answer each logistics item in one or two sentences. |
| Skeptic (light) | Knockout checks, motivation, the visible gaps | Medium. The SAP and production gaps are visible in the material. Weight 4 questions. | Plain acknowledgment for SAP. Answer slot for production and reporting. |
| Data-Driven Prober | Asks how the one figure on your CV was counted | Lower in a recruiter screen, but the "about a third" figure invites it. Weight 3 questions. | Say how it was counted, what it is sensitive to, and what was yours. Say so plainly if you do not know. |

## Prohibited claims

The claims this pack will not coach. Each has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules | Inflated form of F2. The advert's wording, not your sentence | "I schedule deliveries for our three depots", at its own scope. Limit, as the pack's own observation: your material says deliveries, not production planning |
| Chased every supplier across the business | Inflated form of F3 | "chase suppliers when orders slip" |
| Excel expert, or built advanced models | Inflated form of F6 | "I rebuilt our stock-count spreadsheet" |
| Credited with cutting discrepancies by a third | Inflated form of F4. Your sentences do not say what else changed | "I rebuilt our stock-count spreadsheet", "discrepancies fell by about a third over a year", said as two facts |
| Has worked with SAP or an ERP | Negative you stated, F7 | "I haven't used SAP." No slot |

## Question banks

### A. Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Thanks for making time. Can you walk me through your background?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | Ninety-second arc. Give the job and its length, then what it involved: scheduling deliveries for three depots and chasing suppliers when orders slip. Use only those. | Opener. F1, F2 and F3 are the first facts a recruiter checks against the advert. |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" (your message) | Say your figure in your own words: "I'm hoping for £42,000." If she mentions the range, the advert says £38,000–£44,000. Say nothing beyond that. Do not give your current pay. | Pay is one of four logistics items. The figure is yours and needs no defence in this call. |
| A3 | "What's your notice period?" | JD | [grounded] "your notice period" (Hannah's message) | Give your actual notice period in your own words. The material does not give one, so fill it in before Thursday. | Notice is a logistics item. No figure was given, so none is supplied here. |
| A4 | "How would the hybrid pattern work for you?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" (your message), "I live in north Bristol" (your message) | Say two days at Avonmouth is fine and you would not want more than three. If the commute comes up, say you live in north Bristol. | The gate is met on your own constraint (G1). Your reply restates it. |
| A5 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | Say the closure in your words, then that the only offer is a move to Reading and you don't want that. Stop there. No criticism of the employer. | Reason for leaving is a logistics item. Your reason is stated whole and needs no addition. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role works with SAP or a similar ERP. What's your experience there?" | JD | [grounded] "Never used SAP" (your message), "we run our own in-house stock system" (your message) | Plain acknowledgment: "I haven't used SAP." Then say what you run: "we run our own in-house stock system." Then, as a plan only, how you would get up to speed. | F7: a stated negative. No claim of ERP work is made or implied. |
| B2 | "Production planning is a big part of this role. What's the closest you've come to it?" | JD | [grounded] "I schedule deliveries for our three depots" (your message) | Answer slot: if any production-facing scheduling was yours, say which and how you decided. If none was, or it was not yours, say so plainly and stay with the deliveries across three depots. | F2. The premise comes from the advert's "Coordinate production schedules", so it is a fair probe. |
| B3 | "The role reports weekly on on-time dispatch. What's your experience with that?" | JD | [grounded] "report weekly on on-time dispatch" (advert) | Answer slot: if you tracked delivery timing or reported on it, say what you counted and how often. If you did not, say so plainly and say how you track dispatch now. | F5: silence in the material. The question asks for no claim about your past. |
| B4 | "Why this role, rather than staying in logistics coordination where you are?" | EXP | [grounded] "I live in north Bristol" (your message) | Selection scaffold: say what draws you to this role, in your own words. If the main reason is staying in Bristol, say that. Do not invent a reason about the company. | Motivation check. Your material does not show why this employer, so the answer is yours. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "discrepancies fell by about a third over a year" (your message) | Defend the number. Say how the discrepancies were counted, what the figure is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you counted it yourself, say how. If you did not, say so plainly. Do not explain a method you cannot repeat. | F4. A figure you gave raises these slots. |
| C2 | "How confident are you in Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | Name the spreadsheet you rebuilt and what it does. Name any functions you used. If you used basic entry and totals only, say so. Do not claim advanced skills. | F6: low confidence. The advert asks for Excel confidence. |
| C3 | "Walk me through how you rebuilt the spreadsheet." | EXP | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | Say what you started from and what you built. Answer slot: if the design was yours, say so. If it was a team's, say whose part was yours. | F4: the figure in C1 depends on the spreadsheet, so expect the follow-up. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like for someone in this role?" | Shows you are thinking about the job, not only the pay. |
| R2 | "How does the Avonmouth hybrid pattern run across planning, the warehouse and QA?" | Tests the advert's hybrid detail and gives you the answer to A4 in her terms. |
| R3 | "What is the next step after this call, and who would I meet?" | She asked for team and next steps, so this closes her agenda. |
| R4 | "How is on-time dispatch reported today?" | Connects to the weekly reporting line (F5) and shows you read the advert. |
| R5 | "What systems does the team use for stock and production planning?" | Shows you know the SAP gap is real. Her answer tells you how much ERP is needed on day one. |

## Coverage

| Requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1 (F1) |
| Coordinate production schedules | B2 (F2) |
| Track supplier deliveries and chase late orders | A1 (F3) |
| Keep stock records accurate | C1, C3 (F4) |
| Report weekly on on-time dispatch | B3 (F5) |
| Confident with Excel | C2 (F6) |
| ERP (SAP or similar) a plus | B1 (F7) |
| Salary £38,000–£44,000 | A2 (G2) |
| Hybrid, two days at Avonmouth | A4 (G1) |
| Notice period | A3 (F8) |
| Reason for leaving | A5 |
| Right to work | G3: asked in the message, not in a bank |

## Sources

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Search refused on this host ("Quillmoor Diagnostics values"). A values round is not detected for a recruiter screen, so the cheat sheet stays out. It would have fed reverse questions. |
| 2. Quillmoor Diagnostics interview process, operations coordinator | unavailable | Search refused on this host ("Quillmoor Diagnostics interview process operations coordinator"). Her message already describes this call. It would have confirmed later rounds. |
| 3. Quillmoor Diagnostics strategy and news | unavailable | Search refused on this host ("Quillmoor Diagnostics strategy news"). It would have fed reverse questions on current priorities. |
| 4. Recruiter public footprint (Hannah Lowther) | unavailable | No call sent. The first three searches were already refused on this host. It would have moved the persona weights for her, not much. |
| 5. Representative operations coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions. |

Provided documents: the advert and your background, as given in your message; the recruiter's message.

## Upgrade menu

- Your right-to-work answer → G3 moves from surfaced to met or unmet. Nothing else changes.
- Your notice period → A3 gets your own figure in your own words, so you rehearse it, not improvise it.
- Search access on this host → targets 1 to 3 could be sourced. Values and recent news would feed reverse questions and the company's current context. This run's searches were refused.
- Her prep email, if she sends one → any process detail or test she names gets its own coverage.
- A `tuesday-dossier.md` from a previous session → the gaps this prep exposes, carried forward. None is on file.
