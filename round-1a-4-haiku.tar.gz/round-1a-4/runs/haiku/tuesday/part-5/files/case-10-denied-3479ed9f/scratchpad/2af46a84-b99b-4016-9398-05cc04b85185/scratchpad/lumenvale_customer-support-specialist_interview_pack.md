# Interview prep: Customer Support Specialist (remote), Lumenvale Software

**Interviewer:** support team lead (name not given). Relationship: hiring manager. Round: text-chat interview on Telegram.
**Built from:** your message and your summary of the job ad. No full ad text was provided and no research was run (Research tier: L0).

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored.

| Tag | Name | Meaning here |
|---|---|---|
| **CASE** | Live problem | A customer situation you answer in writing, as you would send it |
| **EXP** | Experience deep-dive | Whether what you did, and how you know it, survives a probe |
| **JD** | Role-driven | The ad's own requirements |
| **CO** | Company knowledge | Not covered: no research run |
| **VAL** | Values | Not covered: no published values in hand |

Guidance is scaffolding, not a script. Answer in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | 2+ years in customer support (your summary of the ad) | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | Your material gives three years in customer service at an energy supplier. Expect a check on whether that is the same kind of work as support. Say what the role involved, in your own words. |
| F2 | Zendesk or a similar ticketing tool (your summary of the ad) | "I use Freshdesk every day" — your message | medium | [grounded] | none | Freshdesk is a ticketing tool, and you use it daily; say it in those terms. Expect a probe on Zendesk itself. Answer slot: say whether you have used Zendesk; if you have not, say so, and name the Freshdesk features you use every day. |
| F3 | Clear written communication (your summary of the ad) | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Volume is not writing quality, so the bridge does not stretch it. Answer slot: if any of your written replies were checked, reused or fed back to you, say what; if none were, say so and describe how you write for a customer. |
| F4 | Confidence handling escalations (your summary of the ad) | "I trained four new starters on our refunds process last year" — your message | low | [inferred] | discovery | Refund training is adjacent to escalations, not the same thing. Answer slot: if any case went above you, say what you took up and what you decided yourself; if none did, say so. |

Your message also says "I've never worked for a software company." That is a negative you stated, so it is used as a plain acknowledgment in B2, not as a fit row.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I have Zendesk experience" | Inflated form of F2; you said Freshdesk | "I use Freshdesk every day." |
| "I led the refunds process" | Inflated form of F4; you said you trained others on it | "I trained four new starters on our refunds process last year." |
| "I have worked in software" | Negative you stated | "I've never worked for a software company." |

Your material says the refunds training, not a refunds process you ran. Escalations are not claimed anywhere in this pack; the slots in B1 and F4 cover them.

## Persona weights

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Customer scenarios to answer in writing | **Top.** A hiring manager buys capability, and in a text chat your written reply is the thing being scored | Structure the reply: acknowledge, act, say what happens next |
| Skeptic | Pushes on escalations and Zendesk | **High.** F4 and F2 are the ad's requirements you can show least directly | Rehearse the escalation answer until it is plain; hold, then concede the specific gap |
| Data-driven prober | Asks how the 60-a-day figure was counted | **Medium.** A headline number on your CV-style summary gets probed | Say how you know the figure, and what you would not defend |
| Conversational | Opening "tell me about yourself" in chat | **Low weight, always present** | A 90-second arc: energy supplier, daily volume, Freshdesk, training |

## Question banks

### A. Case / Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes that their refund has not arrived after ten days. Write me your first reply." | CASE | [generic] | Write it as you would send it: short, plain, no jargon. Acknowledge the wait, say what you are checking, say when they will hear next. | A live problem from the refunds work. The chat makes this a writing test too. Nearest evidence is F4. |
| A2 | "They reply: 'This is the third time I've written.' What do you do next?" | CASE | [generic] | Own the repeat contact without blame. Name the one thing you would change. Hand over with a summary so the customer does not repeat themselves. Answer slot: if you have handed a case up before, say how you wrote the handover; if you have not, say how you would write it. | Tests the escalation requirement from the ad, in a live form. |
| A3 | "Our team works in Zendesk. How quickly could you be productive in it?" | JD | [grounded] "I use Freshdesk every day" | Say what you use daily in Freshdesk, then give a learning plan as a plan, not a past: what you would learn first and how you would check you had it. | F2's gap is Zendesk itself. The plan is the honest answer. |
| A4 | "A customer asks for a refund outside policy. What do you do?" | JD | [grounded] "I trained four new starters on our refunds process last year" | Use the training as your base: the process you taught. Say what you would check and who you would take the decision to. Answer slot: if you have decided an out-of-policy refund yourself, say what you decided and who signed off; if you have not, say so and describe what you would do. | F4 is the nearest evidence. The second branch lets the honest answer be "I haven't done that". |

### B. Skeptic (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | **Highest-ROI prep.** "Tell me about a time you escalated a case. What did you decide yourself?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Open prompt. If an escalation comes to mind, tell it in order: what the problem was, what you decided, who you took it to. If none comes to mind, say so plainly, then give the nearest thing your material carries: the refunds process you trained four new starters on, in your own words. | The ad asks for confidence handling escalations, and F4 is your thinnest evidence. Expect this in some form. Rehearse the plain "I haven't" as much as the story. |
| B2 | "You've never worked for a software company. Why should we take a chance on you?" | JD | [grounded] "I've never worked for a software company." | Plain acknowledgment: say you have not worked for a software company. Then what carries across, in your own words: daily ticketing work and the volume you handled. Add nothing. | The Skeptic's core objection. Calm acknowledgment beats a defence. |
| B3 | "You're being interviewed by text. What in your written replies would show me you are clear?" | JD | [generic] | Point to one written artifact you can share, if you have one, such as a reply you wrote. If you have none, describe how you check a reply before sending it. Do not offer a sample you do not have. | F3's gap is writing quality. Typing is the test here, so the answer should be a method. |
| B4 | "Sixty seconds: why this role over someone who already uses Zendesk?" | JD | [grounded] "I use Freshdesk every day" | Hold the position: you use a ticketing tool every day, and you would learn Zendesk fast. Hold through one follow-up, then concede the specific gap (Zendesk, today) without folding on the rest. | Pressure framing of F2. The hold-then-concede shape is the rehearsal. |

### C. Data-driven prober (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You handled around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say where the figure came from: a system report, a rough estimate, or a daily average. Answer slot: if you can say how it was counted, say so; if it is an estimate, say that. Then say which part of the 60 was yours to answer. | The figure is a headline number. Defend it by its source, not by a method you did not use. |
| C2 | "What counts as 'resolved' in that figure?" | EXP | [grounded] "answering around 60 calls and emails a day" | Name your own definition, or say you did not have one and describe how you would check it. Name the assumption you would defend least before they ask. | The weakest-assumption move. Good prep for any number on your CV. |
| C3 | "How do you know the four people you trained got the refunds process right?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Say what you checked, if anything. If you did not check, say so. Do not claim an outcome you did not see. | Prober on training outcomes. The honest answer is the one you can repeat. |

### D. Conversational (low weight, always present)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey into customer service." | JD | [grounded] "3 years as a customer service advisor at an energy supplier" | A 90-second arc: the energy supplier, the daily volume, the move into daily ticketing work, the training. Keep it in the order it happened. | An open opener in chat is still scored. |
| D2 | "What are you using day to day in support tools these days?" | JD | [grounded] "I use Freshdesk every day" | Name Freshdesk and what you use in it every day. Say Zendesk is the one you would learn. | A casual question on the ad's tool requirement. |

## Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in customer support | D1, B2 |
| Zendesk or a similar ticketing tool | A3, B4, D2 |
| Clear written communication | A1, A2, B3 |
| Confidence handling escalations | B1, A2, C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the escalation path look like, from first line to the team lead?" | The ad asks for escalation confidence; the answer tells you what you would own |
| R2 | "Which ticketing tool does the team use, and what would I need to learn first?" | Covers the Zendesk gap; the answer sets your learning plan |
| R3 | "How does the refunds process work here, and who approves exceptions?" | Your strongest training link; shows you know where refunds are decided |
| R4 | "Is the whole process, including the offer and onboarding, handled in this chat, or is there a call or video step?" | Changes what to prepare for; a process question, not a check on the sender |
| R5 | "What would a new hire be measured on in the first 90 days?" | Shows you plan to be measured, and tells you the targets |

## Sources

- Provided: your message (your background and the invite) and your summary of the job ad.
- No dossier present. No `tuesday-dossier.md` in context.
- Research tier: L0 — no searches.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Values cheat sheet (section 10). Not run; it runs only with your consent (see the questions in the message) |
| 2. Lumenvale interview process, support roles | unavailable | Loop structure and persona weights. Not run; same condition |
| 3. Lumenvale strategy / recent news | skipped | Not needed for a support-specialist pack at this depth |
| 4. Interviewer name + Lumenvale | n/a | No name given; the Telegram sender is not the team lead |
| 5. Representative JD | skipped | Your ad summary fixes the fit snapshot; a full ad text would replace it |

## Upgrade menu

- The full job ad text → F1–F4 quote the ad's own words, and the coverage table can check every line of it
- Your CV → evidence cells can quote it, and F1 and F2 can move from quoted summary to the CV itself
- A written reply you have sent to a customer → an artifact for F3 and B3
- Your consent to a light research pass on Lumenvale's values and process → a values cheat sheet and the loop structure
- The team lead's name → a tailored reverse question
- `tuesday-dossier.md` → one line: it would carry the escalation and Zendesk gaps from this prep into later sessions
