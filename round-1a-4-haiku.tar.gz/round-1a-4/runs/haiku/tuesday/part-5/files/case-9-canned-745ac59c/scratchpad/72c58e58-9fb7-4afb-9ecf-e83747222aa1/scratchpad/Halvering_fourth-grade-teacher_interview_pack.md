# Halvering Elementary School: Fourth Grade Teacher, panel interview prep

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Round:** 45-minute panel, Thursday. Principal Dolores Vantongeren (hiring-manager relationship) plus two fourth-grade team members (peer relationship).
**Built from:** the invite, your resume, and your message. No web research was run, so this pack has no school values, no district interview process, and no interviewer profiles.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: EXP (your experience), JD (the role), CASE (a live problem), VAL (values), CO (company knowledge).
- Guidance is scaffolding, not a script. Each guidance cell is speakable in about 90 to 120 seconds.
- Quoted sentences come from your resume or your message. Nothing in this pack describes a practice you did not state.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. Your license matches the invite's requirement. Bring a copy or the registry confirmation so the panel has nothing to check. |
| F2 | Fourth Grade Teacher position (invite) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | medium | [grounded] | transferability | Your material shows elementary teaching at third grade, not fourth. Plain acknowledgment, from your own words: "I've never taught fourth grade." Answer slot: if you have looked at the fourth-grade standards or materials, say what you looked at; if not, say so and say how you would learn them before September. |
| F3 | Working within a grade-level team (role family, no posting text) [generic] | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | presentation | This quote is your strongest team evidence. Say it at its own scope: the move, in 2024, that your grade level made. It does not show a team lead role, and you have said so. |
| F4 | Communicating with families (role family, no posting text) [generic] | "I write a weekly email to families" (your CV) | medium | [grounded] | none | No gap. Use the sentence as written. |
| F5 | Teaching reading to a class (role family, no posting text) [generic] | "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | transferability | The club is after-school, not a classroom block. Say what the club was, in those words. Answer slot: if you tracked anything about the club's results, say what; if you did not, say so. |

Confidence grades your evidence. Provenance grades what this pack wrote about it. Rows F3 to F5 use role-family requirements, not posting text, because the invite does not include a job description. Requirements labeled [generic] raise no answer slot of their own.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Your stated negative (F2) | Plain acknowledgment: "I've never taught fourth grade." |
| Has been a team lead | Your stated negative (F3) | Plain acknowledgment: "I've never been a team lead." |
| Selected the reading curriculum | Inflated form of F3 | F3's quote at its own scope. The material says you led the move, not that you chose the curriculum. If the choice came from others, say so. |
| Led a grade-level team | Inflated form of F3 | F3's quote at its own scope. A team lead is not in your material. |

## Persona weights

| Interviewer | Dominant personas | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Principal Dolores Vantongeren | Skeptic (high), Case/Strategist (medium) | The principal is the decision-maker and will check the gaps in F2 and F3 directly. A live problem is likely. | Hold one honest position through two follow-ups. Say what you would do first, not what you have done. |
| Fourth-grade team member 1 | Peer Evaluator (high), Data-Driven Prober (medium) | Peers price what the hire costs their work. They will ask about seams between your third-grade work and their fourth-grade plans, and about how you know things worked. | Offer reciprocity: what you bring their team, not only what you need. Say how you check a claim. |
| Fourth-grade team member 2 | Data-Driven Prober (high), Peer Evaluator (medium) | Same as member 1, with more probing of the figures and the reading club. | Name the weakest assumption before they do. |

Weights are relationship priors. The invite gives no individual roles beyond the titles, so the per-member split above is a judgment, not a finding.

## Question banks

### Skeptic (principal), 5 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This is a fourth-grade position. What is your experience at that grade?" | EXP | [grounded] "I've never taught fourth grade" | Say it plainly: "I've never taught fourth grade." Then bridge from "Six years teaching third grade at a public elementary school in Joliet." Answer slot: if you have looked at the fourth-grade standards or materials, say what you looked at; if not, say so and say how you would learn them. | F2 is the most likely objection. Rehearse the plain answer until it is calm. |
| A2 | "Why fourth grade, and why now?" | VAL | [generic] | Your material does not say why fourth grade. Give your own reason in your own words, one sentence, then one example from your teaching that fits it. | Motivation probes are standard for a Skeptic. The answer has to come from you. |
| A3 | "You haven't led a team. What would you do the first time a colleague disagreed with your plan?" | EXP | [grounded] "I've never been a team lead" | Acknowledge it: "I've never been a team lead." Then describe how you would handle the disagreement. Answer slot: if you have had a colleague disagree with a plan you proposed, say what happened and what you did, in your own words; if not, say so and describe what you would do. | Pressure to show leadership without a lead role. Hold the acknowledgment, then answer the question. |
| A4 | "Your resume says you led a curriculum move. What did you decide, and what was decided for you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Stay at the quote's scope: the move, in 2024. Answer slot: which decisions were yours to make, and which were made by others. If the choice of curriculum was not yours, say so plainly. | F3 is the strongest team evidence and the likeliest place to be probed. |
| A5 | "Tell me about a plan you proposed that was turned down." | EXP | [generic] | Open prompt. Pick a real instance. If no such time comes to mind, say so plainly, then describe the nearest thing your experience does carry. | Tests whether you can take a no without becoming defensive. |

### Case/Strategist (principal), 4 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A student who read at grade level in third grade is struggling with fourth-grade informational text. What do you do in the first week?" | CASE | [generic] | Clarify first: what you know about the student, what the assessment shows, and who on the team you would ask. Then one or two steps you would take, and how you would check whether they worked. | Live problem from the role. No claim about your past. |
| B2 | "How would you bring the fourth-grade team's reading plan into your own classroom?" | CASE | [generic] | Name what you would ask the team first, what you would keep, and what you would adapt. | Tests whether you can fit into an existing plan. |
| B3 | "A parent emails upset about a grade. Walk us through your first steps." | CASE | [generic] | Acknowledge the concern. Check the facts. Respond within a set time. Bring in the team or the principal if needed. | Common question for a principal. No past claim needed. |
| B4 | "What would you want to know about our fourth-grade program before your first week?" | CASE | [generic] | Name two or three specific questions. This is also a chance to ask the principal about the team's plan. | Shows you have thought about the role. |

### Peer Evaluator (team members), 4 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Where does your third-grade work meet what our fourth-grade team does, and what would you need from us?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Describe the handoff from third grade to fourth grade in your own words. Then name what you would need from the team in your first month. | Peers ask about seams. Your third-grade years are the natural bridge. |
| C2 | "How would you share a reading plan with teammates who disagree with it?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use the curriculum move at its own scope. Say how you listened, what you changed, and what you kept. Answer slot: if you have done this, say how; if not, say so and describe your approach. | Peers test disagreement style with equals. |
| C3 | "How would you split planning time with the team?" | CASE | [generic] | Describe a split by task, not by person. Name what you would take first. | Tests how you fit into shared work. |
| C4 | "What would you bring to our team that we don't already have?" | JD | [generic] | Answer from what you have. Name one strength and one thing you would learn from them. | Reciprocity question. Keep it specific. |

### Data-Driven Prober (team members), 4 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you know your reading club was working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Say what you saw, in your own words. Answer slot: if you tracked anything about the club, say what was counted; if not, say so and say what you would measure next. | Probers ask for evidence. Do not invent a measure. |
| D2 | "How did you measure the results of the reading curriculum move?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if you measured results, say what and how; if you did not, say so plainly and say what you would measure. | F3 presses hardest on results. Do not add a figure. |
| D3 | "Which thing you've run would you show us first, and how did you check it?" | EXP | [generic] | Open prompt. Pick one thing you ran and say how you knew it worked. | Tests your own judgment of your work. |
| D4 | "What would tell you a reading block is working in fourth grade?" | CASE | [generic] | Name two signals you would look for and how you would check them. | Probers want the measure, not the feeling. |

### Conversational opener, 2 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk us through your path to teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | A 90-second arc: where you started, the third-grade years, the reading club, and why you are here. Use your own words. | Openers are scored. Keep it short. |
| E2 | "How do you keep families informed when a child is struggling?" | EXP | [grounded] "I write a weekly email to families" | Describe what the weekly email covers. Answer slot: if you have a specific case of a family's concern, say what you did; if not, describe how you would handle one. | Families are a real part of the job. |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Illinois PEL with elementary endorsement (F1) | None needed. Met, and you have stated it. |
| Fourth-grade experience (F2) | A1, B1, B2, D4 |
| Working within a grade-level team (F3) | A3, A4, C1, C2, C3, C4 |
| Communicating with families (F4) | E2 |
| Reading instruction (F5) | D1, D2, D3 |

## Reverse questions

1. "What does the fourth-grade team plan to do with the reading program this year?" Why it lands: it shows you want to join the work already in progress.
2. "What would a new teammate do in the first month that would genuinely help the team?" Why it lands: a reciprocity question to the peers. It shows you are thinking about their load, not only yours.
3. "What does success look like for this position in the first year?" Why it lands: it asks the principal what the job is for, and shows you plan around it.
4. "How does the team split planning and assessment?" Why it lands: it shows you want to learn how the team works before you join it.
5. "What is the most important thing a new fourth-grade teacher should know about this school?" Why it lands: it shows you are listening for what matters locally.

## Upgrade menu

- The full job posting → the [generic] requirement rows (F3, F4, F5) become quoted requirements, and the coverage table checks against the real list.
- The panel members' names and roles → persona weights per member, and a tailored reverse question.
- The fourth-grade standards or curriculum the school uses → sharper answers to A1 and B2.
- Research on the district's values and interview process → a values section and the loop's structure.
