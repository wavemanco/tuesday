# Interview prep pack: Customer Support Specialist, Lumenvale Software (remote)

**Interviewer:** support team lead (name not given). **Relationship:** hiring manager. **Format:** text chat on Telegram.
**Loop:** not established by any source. Persona weights rest on the hiring-manager relationship prior and the Generic archetype, not on this company's documented process.

## How to use

Personas describe how a question arrives. Types describe what is being scored: **VAL** values, **EXP** experience deep-dive, **JD** role requirement, **CO** company knowledge, **CASE** live problem. Guidance is scaffolding, not a script. Answer slots are instructions for the interview, not questions to answer here.

## Fit snapshot

Requirements are quoted from your summary of the ad, since no full ad text was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your summary of the ad) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | none | Say it in your words: "I've spent three years as a customer service advisor at an energy supplier." Limit: that is advisor work at an energy supplier, not support work at a software company. |
| F2 | "Zendesk or a similar ticketing tool" (your summary of the ad) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | Freshdesk is a similar ticketing tool, and the requirement says "or a similar". Say: "I use Freshdesk every day." Do not describe Zendesk experience. |
| F3 | "clear written communication" (your summary of the ad) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Your material shows email volume, not how clear your writing was to a reader. Answer slot: if any written replies were ones you would point to, say what they handled; if you have no such example, say so and say how you check a reply before you send it. |
| F4 | "confidence handling escalations" (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not show escalations. Answer slot: if you have escalated a case, say what, to whom, and what you decided; if you have not, say so plainly and say how you would handle a case you could not resolve yourself. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Zendesk experience | Inflated form of F2: Freshdesk widened to the named tool | F2's quote at its own scope: "I use Freshdesk every day." |
| Ran new-starter training as a programme, or owned onboarding | Inflated form of "I trained four new starters on our refunds process last year" | The quote at its own scope: "I trained four new starters on our refunds process last year." |
| Software-company experience | Negative you stated: "I've never worked for a software company" | Plain acknowledgment, no slot: "I've never worked for a software company." |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live customer scenario, written out in the chat | High. A hiring manager buys capability and tests it on the actual job | Clarify first, then structure: what you can resolve, when you escalate, what the customer hears next |
| Skeptic | "Never worked for a software company" and "escalations" as the probes | High. Your two gaps are the ones this interviewer will test | Plain acknowledgment, then how you would learn; no bluffing a competency you have not shown |
| Data-Driven Prober | "How did you count 60 calls and emails a day?" | Medium. A figure you gave is the first thing a careful reader checks | Know how the figure was counted, say which part was yours, and name the weakest assumption before it is named for you |
| Pressure | Short, time-boxed replies in a chat thread | Low. Chat limits time pressure, but short replies can read as pressure | Hold a position through two follow-ups, then concede the uncertain part specifically |
| Conversational | "Walk me through your background" | Low. Casual openers are still scored | A 90-second arc built only from your own sentences |

## Question banks

### Case / Strategist (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A customer says they were charged twice and will cancel. Walk me through what you would do first." | CASE | [generic] "I trained four new starters on our refunds process last year" (your message) | Restate the problem, confirm the account facts, check the refund path, then decide what you can resolve yourself and when you escalate. Answer slot: if the refunds process you trained others on covers this case, say which step it covers; if not, say which step you would check first. | A live problem from the ad's support work. The refunds sentence is the only candidate fact the guidance touches |
| C2 | "Tell me about a time you escalated a case, or decided not to." | JD | [grounded] "confidence handling escalations" (your summary of the ad) | Open prompt. Answer slot: if you escalated a case, say what, to whom, and why; if you did not, say so plainly and describe how you decided what you could resolve yourself. | F4 is the gap; the ad raises escalations, so an instance is likely to be asked for |
| C3 | "You join and the product changes every month. How do you stay current with it?" | CASE | [grounded] "I've never worked for a software company" (your message) | State the plain acknowledgment, then a learning plan you would follow. Do not describe software work you have not done | The question's premise is a software context you have not worked in, so the guidance names it honestly rather than hiding it |
| C4 | "Zendesk is our main tool. How quickly could you work in it?" | JD | [grounded] "I use Freshdesk every day" (your message) | Say what you do in Freshdesk every day, in your words. For Zendesk, say you have not used it and describe how you would learn it | F2 reaches the tool family, not the named tool |
| C5 | "A customer has waited a week for a reply. Write the first line of your response." | CASE | [generic] | Structure: acknowledge the wait, state the next step and when it will happen, name one owner. This is a live writing task, so no past claim is made | Tests the ad's written-communication requirement as a live exercise |

### Skeptic (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You have never worked for a software company. Why would this role suit you?" | JD | [grounded] "I've never worked for a software company" (your message) | Plain acknowledgment: "I've never worked for a software company." Answer slot: say in your own words what drew you to the role and what you would need to learn first | The gap is stated by you, so the acknowledgment needs no slot. The motivation is yours to give |
| S2 | "You use Freshdesk. Why will that be enough here?" | JD | [grounded] "I use Freshdesk every day" (your message) | Say what you do in Freshdesk every day, in your words. Do not claim Zendesk, and do not say Freshdesk is the same tool | F2 is a similar tool, not the named one |
| S3 | "Escalations are a core part of this role. Where have you handled them?" | JD | [grounded] "confidence handling escalations" (your summary of the ad) | **The highest-ROI prep in this pack.** Honest branch: if you have handled escalations, say how, in your own words; if you have not, say so plainly and say how you would learn. Hold through two follow-ups by returning to what you do handle, never by adding to it | F4 is the biggest gap and the likeliest probe. The objection is aimed where your material is thinnest |
| S4 | "Three years as an advisor at an energy supplier. What did you do there that a support role would not need?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | Describe the work in those words and name any difference from support work you can see. Do not add to the role | Tests the ad's 2+ years requirement against your material. Its scope stays at advisor work |
| S5 | "Show me how you would reply to a customer in this chat, in a few lines." | JD | [grounded] "clear written communication" (your summary of the ad) | Write the reply live, short and plain. No past claim is made | Tests the written-communication requirement directly, which F3 leaves open |

### Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "How did you count 60 calls and emails a day? Which part of that number was yours?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Defend-the-number slot. Answer slot: say how you know the figure, whether from a report, a log, or an estimate, and name the assumption you would defend least. If you do not know how it was counted, say so | A figure you gave is a magnet for probing. The guidance supplies no counting method |
| P2 | "Is 60 a daily average, a peak, or a target?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Answer slot: say which it is, if you know. If you do not know, say so plainly | The same figure, probed from another side |
| P3 | "You trained four new starters. How did you tell they were ready?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Answer slot: say what you checked, if anything, and what you would check next time. If you did not measure readiness, say so | Tests the training claim without assuming a measure existed |
| P4 | "What single measure would you use to tell whether a support agent is doing well, and how would you check it?" | JD | [generic] | Name one measure and the check you would run on it. No claim about your past | Mid-weight prober question with no candidate claim |

### Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Sixty seconds: why hire someone with no software background over a candidate who has one?" | JD | [grounded] "I've never worked for a software company" (your message); "I use Freshdesk every day" (your message) | Hold: anchor in the daily ticketing work and the volume you handled. Concede plainly after two follow-ups: "I haven't worked in software." Never claim software experience | Hold-then-concede on the stated gap |
| R2 | "Your answers so far sound rehearsed. Give me one thing you would do differently." | CO | [generic] | Name one change in your delivery, not in your history. No claim about your past | Tests composure when a chat answer is challenged |

### Conversational / Rapport (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So, walk me through your background." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); "I trained four new starters on our refunds process last year" (your message) | A 90-second arc using only those two sentences, in your own words | The casual opener is scored. The arc draws on nothing you did not state |
| V2 | "What part of support work do you enjoy most?" | JD | [generic] | Answer slot: say what you actually enjoy; if nothing comes to mind, say so | Rapport question, scored for genuine interest |

**Requirement coverage:** "2+ years in customer support": S4. "Zendesk or a similar ticketing tool": C4, S2. "clear written communication": S5, and F3's bridge. "confidence handling escalations": C2, S3.

## Reverse questions

1. "Which ticketing tool does the team use day to day, and how do tickets reach escalation?" Why it lands: it asks about the tool and the escalation route together, which are the ad's two most specific requirements.
2. "What does a new support specialist usually get wrong in the first month?" Why it lands: it shows you are thinking about the hard parts of the job, not only the offer.
3. "Is there a video, phone, or in-person step after this chat, or is the chat the whole interview?" Why it lands: it tells you how much to prepare for the next step.
4. "What would make someone in this role clearly successful at six months?" Why it lands: it asks for the success criteria in the team lead's own words.
5. "How do you give feedback on written replies to new starters?" Why it lands: it links directly to the written-communication requirement and shows how quality is judged.

## Sources

- Provided: your message (background, Freshdesk use, training, volume); your summary of the job ad; the Telegram invite, as quoted in your message.
- Search: "Lumenvale Software customer support careers" → refused.

Research tier: L1 — searches 1 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Values cheat sheet, section 10. Not produced: the Generic fallback reads no values-style round, and the values page was not retrieved |
| 2. Lumenvale Software interview process, customer support | unavailable | Loop structure. Persona weights fall back to the hiring-manager prior and the Generic archetype, as stated above |
| 3. Lumenvale Software strategy / recent news | unavailable | Grounding brief and CO questions. CO coverage is limited to R2 |
| 4. Interviewer name and Lumenvale Software | n/a | No name was given, so there was no query to form |
| 5. Representative customer support JD | unavailable | Would have fixed the fit rows at [inferred] where no full ad was supplied. Your summary of the ad stands in for it |

## Upgrade menu

- The full ad text → the four fit rows quote the ad's own words, and the JD-tagged questions use its exact wording.
- How many interview sessions there are, and in what format → the loop becomes established, and persona weights can be set per session.
- Web search allowed for this session → the company's values, interview process, and recent news, each marked [grounded] if found. Web search was refused for this run, so no company facts are in this pack.
- The team lead's name → a reverse question tied to their public career path, and persona weights from their public footprint.
- A deeper research pass, if search is allowed → company strategy and recent organisation changes, for the CO questions. Several more minutes.
