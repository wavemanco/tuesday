# Interview prep: Customer Support Specialist, Lumenvale Software

Interviewer: the support team lead (name not given). Round: text-chat interview on Telegram. Built at research tier L0: your message and the invite only. No web research has run.

## How to use

Personas describe how a question arrives. Types describe what is being scored: **VAL** values, **EXP** your experience, **JD** the job ad, **CO** company knowledge, **CASE** a live problem. The guidance is scaffolding, not a script. In a chat, write the answer out and read it back before you send it.

## Fit snapshot

Requirements are from the job ad as you summarised it. Quotes are from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (job ad, your summary) | "Three years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | none | No gap. Say the years and the setting in those words. Confidence is medium: a CV line with little to inspect, so expect a probe on what the work involved. |
| F2 | "experience with Zendesk or a similar ticketing tool" (job ad, your summary) | "I use Freshdesk every day" (your message) | medium | [grounded] | presentation | Your material reaches the requirement in other terms, since Freshdesk is a similar ticketing tool. Bridge: "I use Freshdesk every day." Do not claim Zendesk experience. Answer slot: if you have used Zendesk, say where and how; if you have not, say so plainly and say how you would learn it. |
| F3 | "clear written communication" (job ad, your summary) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Volume shows output, not written quality, and this chat is itself the test. Answer slot: name one written reply you are proud of, in your own words; if none comes to mind, say how you check a reply before you send it. |
| F4 | "confidence handling escalations" (job ad, your summary) | none given | none | [grounded] | discovery | Your material is silent on escalations. Answer slot: if you handled escalations, say which and what you decided; if you passed them on, say so and say what you did for the customer in the meantime. |
| F5 | [inferred] likely probe: no software-company background | "I've never worked for a software company" (your message) | medium | [grounded] | transferability | Adjacent work is the three years of support at an energy supplier. Say the negative plainly, then say what carries over: the calls and emails, the ticketing tool, the refunds process. |

No gate rows. The material says nothing about pay, notice, location or start date, and the invite asks nothing about them yet.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has Zendesk experience | Inflated form of F2 | "I use Freshdesk every day." Pack observation: your material shows Freshdesk, not Zendesk. |
| Has handled escalations | Inflated form of F4 | No quote exists. Answer slot only (F4). |
| Set the refunds process | Inflated form of your refunds quote | "I trained four new starters on our refunds process last year." Pack observation: your material says you trained people on it, not that you set it. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live refund or escalation scenario, typed out | High. A support team lead usually tests the job itself. | Structure aloud before answering: acknowledge, check, decide, next step. |
| Skeptic | "Software company" and "Zendesk" probes | High. F2 and F5 are the visible gaps. | Hold the position through two follow-ups, then concede the real limit. |
| Conversational / Written clarity | A casual opener, then a request to explain something in two sentences | Medium. Casual chat questions are still scored. | A 90-second spoken arc, then the shortest clear version. |

## Question banks

Persona weights: Case 3 questions, Skeptic 3, Conversational / Written clarity 4.

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in angry: their bill is wrong and they say they have waited a week. What do you write back?" | CASE | [generic] | Acknowledge the wait in one line, say what you will check, give a time for the next update, and say what you will not promise yet. No claim about your past. | A live problem from the escalations requirement (F4). |
| A2 | "A customer wants a refund your policy does not cover. What do you tell them, and who do you escalate to?" | CASE | [generic] | Say what policy allows, state the decision, and pass on the facts so the next person does not ask again. | F4 is the escalation requirement; this tests the decision, not your record. |
| A3 | "Tell me about a time a customer's problem went past what you could settle alone." | EXP | [grounded] "confidence handling escalations" (job ad, your summary) | Open prompt. Selection scaffold: pick a case that went beyond your authority; if you passed it on, say to whom and what you did for the customer meanwhile; if you did not face one, say so plainly and describe the nearest case you did handle. | F4 has no quote, so this stays a scaffold, not a story. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never worked for a software company. Why would this work for you?" | JD | [grounded] "I've never worked for a software company" (your message) | Highest-ROI prep. Hold: "I've never worked for a software company." Then the adjacent evidence: "Three years as a customer service advisor at an energy supplier." Then what carries over, in your words. Concede a real limit: you do not yet know this product, and you would learn it in the first weeks. Hold through two follow-ups by returning to the support work. | F5 is the most predictable objection to this candidate. |
| B2 | "What do you know about our product that matters for support?" | JD | none given. Premised question: a product the material does not describe | Answer slot: if you have used the product or read its help pages, say what you saw; if not, say so plainly and say what you would look at first. Do not describe the product. | The premise is the interviewer's, not yours. The honest answer is what you have seen, or nothing yet. |
| B3 | "You use Freshdesk. We use a similar tool. How quickly would you be productive?" | JD | [grounded] "I use Freshdesk every day" (your message) | Bridge: "I use Freshdesk every day." Then a learning plan, said as a plan, not a past. If you have not used the interviewer's tool, say so plainly. | F2 is the Zendesk-or-similar requirement, in its presentation form. |

### Conversational / Written clarity

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you keep a customer calm in a chat when you cannot give them the answer yet?" | JD | [grounded] "clear written communication" (job ad, your summary) | Say what you would write: acknowledge, say what you are doing, give a time for the next message. No claim about your past. | The chat is the written-communication test. |
| C2 | "Explain a refund decision to a customer in two sentences." | CASE | [generic] | Decision, reason, next step. Keep it to two sentences in the chat. | Tests written clarity directly, in the same medium as the interview. |
| C3 | "What did the refunds training you ran involve?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Say the training in your own words. Answer slot: if you wrote any of the process, say which part; if it was set for you, say so. | Tests attribution. Your quote says you trained them, not that you set the process. |
| C4 | "You handle a lot of contacts. How do you keep quality up at that volume?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Give the volume in those words. Answer slot: if you tracked quality, say what was counted; if you did not, say so and say how you checked your own replies. | F3 is the thin evidence for written clarity; this shows how the volume was handled. |

Requirement coverage: 2+ years, C4 and A3. Zendesk or similar, B3. Clear written communication, C1 and C2. Escalations, A1, A2 and A3. Software company (not in the ad), B1 and B2.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week of escalations look like for your team?" | Shows you are asking about the work, not just the title. |
| R2 | "How does a new support hire learn the product in the first month?" | Shows you plan to learn it and asks how it is done. |
| R3 | "Which ticketing tool do you use, and how are escalations routed in it?" | Shows you will learn their tool rather than assume it. |
| R4 | "What is hardest for someone new in this role in the first 90 days?" | Lets the lead name the real gap and gives you a chance to answer it. |
| R5 | "Is there a call or video stage after this chat, or is the chat the whole interview?" | A process question with a prep reason: you need to know what to prepare for. |

No peer reciprocity question: the interviewer is a team lead, not a peer.

## Sources

- Provided: your message and the text of the Telegram invite.
- Research tier: L0. No search was run. You have not yet agreed to research (see the questions in the message).
- Target accounting:
  1. Company values: unavailable (research not consented).
  2. Interview process: unavailable (research not consented).
  3. Company strategy and news: unavailable (research not consented).
  4. Interviewer footprint: n/a (no interviewer name given).
  5. Representative job ad: skipped (the ad you summarised fixes the fit snapshot).

## Upgrade menu

- The job ad, pasted in full → F1 to F4 become [grounded] from the ad's own words, and the requirement quotes are exact.
- The support team lead's name → persona weights from their public footprint, and a tailored reverse question.
- Public research at L1 on Lumenvale's support setup and values → a grounding section and questions tied to their current products.
- One written reply you sent to a customer, names removed → F3 moves from a discovery gap to a quote you can rehearse.
- The round's format from the recruiter, if they say more than the invite → reweights the banks.
