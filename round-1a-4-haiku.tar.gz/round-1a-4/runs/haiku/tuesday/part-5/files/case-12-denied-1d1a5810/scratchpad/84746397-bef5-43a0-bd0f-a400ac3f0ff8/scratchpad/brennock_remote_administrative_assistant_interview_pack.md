# Brennock Facilities Ltd: Remote Administrative Assistant, interview prep pack

Round: first-round 30-minute video call with the office manager (as the invite describes it). Relationship: office manager. First version, so no changelog.

## How to use and type key

Personas are how the question is asked. Types are what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only about what you actually did.

- **EXP**: work-experience deep-dive. Tests whether what you say about your past holds up.
- **JD**: role-driven. Tests whether you can do the listed work, gaps included.
- **CASE**: a live problem from the role, answered out loud.

No values round, company-strategy round or peer round is detected, so there is no values cheat sheet, no strategy questions and no reciprocity question.

## Fit snapshot

Requirements come from your summary of the ad, so they are quoted from your message. Quotes are only your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your summary of the ad) | "ran the appointment book for four physios" (your message) | medium | [grounded] | presentation | Your material says an appointment book for four physios. Bridge, in your words: "I ran the appointment book for four physios." Adds no executive calendars and no booking software that you did not name. |
| F2 | "booking travel" (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel or arranged trips for anyone, say what you booked and for whom. If you have not, say so plainly, then say how you would learn the booking tools the team uses. |
| F3 | "preparing documents in Word" (your summary of the ad) | "good with Word" (your message) | low | [inferred] | none | Self-rated, and no document you prepared has been shown. The quote reaches the Word part of the requirement in general terms. Bridge: "I'm good with Word." If asked for proof, name one document you prepared in Word, in your own words. |
| F4 | "preparing documents in Excel" (your summary of the ad) | "okay with Excel" (your message) | low | [inferred] | discovery | The quote touches the requirement without showing whether it reaches it. Answer slot: if you have used Excel for something specific, say what it was. If not, say so plainly and say what you would learn first. |
| F5 | "processing supplier invoices" (your summary of the ad) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | Adjacent work: chasing money owed to the clinic is not the same as processing bills the company pays out. Bridge, at its own scope: "I chased unpaid invoices." Say the difference yourself if asked. |
| F6 | Remote working, as the title says (the invite) | none given | none | [grounded] | hard_gate | Your material does not establish whether you can work remotely in the hours and place the role needs. Surfaced here, not bridged. |

Confidence grades your evidence. Provenance grades what this pack wrote about it. F3 and F4 are low because "good with" and "okay with" are self-ratings with nothing inspected behind them.

## Prohibited claims

These are not to be coached, because they say more than what you told us.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed executive calendars | Inflated form of F1 | F1's quote at its own scope. The material says an appointment book for four physios, not executive diaries. |
| Has processed supplier invoices | Inflated form of F5 | "I chased unpaid invoices." The material says money owed to the clinic, not supplier bills paid out. |
| Is an expert in Word or Excel | Inflated form of F3 and F4 | "I'm good with Word" and "okay with Excel", in those words. |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | Quiet probing of the gaps: travel, invoices, Excel, "why this move" | Highest. A hiring-side call usually checks the skills the ad lists that the CV does not show (F2, F4, F5). | Rehearse the one predictable objection until it is plain. Say what you have, say what you have not, then say how you would learn. | 5 questions |
| Data-Driven Prober | Asks you to walk through the work and what a step actually involved | Medium. Your receptionist work is concrete, so expect a request to walk through it. | Describe what you did, step by step, in your own words. Say plainly where you do not know. | 3 questions |
| Conversational | Friendly opener, casual questions about Word and Excel | Medium. A 30-minute call often opens this way, and the casual questions are still scored. | A 90-second version of your path, told plainly. | 3 questions |
| Case / Strategist | A small live problem from the role | Lower. The call is short and the role is administrative, so expect one or two practical problems. | Clarify the situation first, then say your steps out loud. | 2 questions |

This pack has 13 questions, below the usual 18 to 26. That is deliberate: a 30-minute call has room for about this many, and a longer list would not be rehearsed.

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the part you have least evidence for, then say how you would learn it in the first week. Keep it short and plain; do not reassure. | Persona stem. Asked about the role, not your record. F2 and F4 are the weakest rows. |
| S2 | "How would you handle supplier invoices in this role?" | JD | [grounded] "chased unpaid invoices" (your message) | Answer slot: if you have handled any bill or payment for someone else, say which and how. If you have not, say so plainly, then give the nearest thing you did: chasing unpaid invoices, in those words. Then say how you would learn the company's supplier process. | F5 is the requirement with the least evidence behind it, and this is where the call is most likely to press. |
| S3 | "Why are you looking to move from reception into admin?" | EXP | [generic] | Give your real reason, in your own words. The pack does not supply one. Keep it to what you want from this role. | Motivation probe. No claim about your past is made here. |
| S4 | "Sixty seconds: why should we hire you over someone with office admin experience?" | JD | [generic] | Hold on the two things you did run: the appointment book for four physios, and the invoices you chased. Answer slot: if you have not held an admin job, say so plainly before you say anything else. | Pressure stem. The interviewer is testing whether you hold a position without bluffing. |
| S5 | "When you chased unpaid invoices, how much of that money did you get back?" | EXP | [grounded] "chased unpaid invoices" (your message) | Answer slot: if you know the figure and how you know it, say it. If you did not track it, say so plainly. Do not estimate. | Defend-the-number probe. The figure is the interviewer's, not yours, so the guidance does not supply one. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "ran the appointment book for four physios" (your message) | Tell it in order: the book, the four physios, the two years. Answer slot: if you set any rule for resolving bookings or cancellations, say which and how you decided. If none was yours to set, say so and describe how the book was run. | F1 is the calendar evidence and the likeliest place to be probed. |
| P2 | "Show me in words how you would build a simple spreadsheet to track invoices." | CASE | [generic] | Name the columns you would use, such as supplier, invoice number, date, amount, status and approver. Say what you would check first. | Tests F4 without inventing Excel experience. |
| P3 | "Walk me through how you would process a supplier invoice, from receipt to payment." | JD | [generic] | Say the steps in order: receive, check against the order, approve, record, pay, file. Say which of these you have done. If none, say so plainly. | Tests F5 at the role's own scope. |

### Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey to here." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | A 90-second arc: the clinic, the appointment book, the invoices, and why you want admin. Add nothing you have not said. | Openers are scored casually. |
| C2 | "What part of the receptionist job did you enjoy most?" | EXP | [grounded] "ran the appointment book for four physios" (your message) | Answer in your own words. The pack does not supply an answer. | Keeps the answer tied to what you did. |
| C3 | "Anything you're playing with in Word or Excel these days?" | JD | [grounded] "good with Word" and "okay with Excel" (your message) | Name what you use each for. If you are still learning Excel, say so. | Plus-skill asked casually. |

### Case / Strategist (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "A director asks for their meetings next week to be moved and a flight booked. Walk me through your first hour." | CASE | [generic] | Clarify first: which meetings, what the constraints are, what the booking rules are. Then check conflicts, confirm with the director, and record the changes. | Covers calendars and travel, which F1 and F2 touch. |
| K2 | "A supplier invoice has no purchase order. What do you do?" | CASE | [generic] | Check the process, find out who approves, do not pay until it is checked, and record what you did. | Tests the invoice requirement as a decision. |

### Coverage

| Requirement | Question IDs |
|---|---|
| Managing calendars | P1, K1 |
| Booking travel | K1, S1; F2 has an answer slot |
| Word documents | C3 |
| Excel documents | P2, C3 |
| Supplier invoices | S2, P3, K2 |

## Reverse questions

Each one is for you to ask, and each has a reason it lands.

1. "What would a good first month look like for whoever holds this role?" Why it lands: shows you are planning the work, not just listing skills.
2. "Which calendar and booking tools does the team use day to day?" Why it lands: lets you name the tools you have used and the ones you would learn, without guessing.
3. "How is the admin work split between you and the rest of the team?" Why it lands: shows you are asking where the real edges of the role are.
4. "What comes after this call, and who would be involved?" Why it lands: a process question that helps you prepare for the next stage.
5. "Where does the invoice process cause the most trouble at the moment?" Why it lands: names the invoice requirement and invites the interviewer to say where the pressure is.

## Prep notes

- Practise S2 and S4 aloud, because they are the most likely to press. Say what you have, say what you have not, and stop.
- Practise P1 once, in order, without adding a detail you did not live through.
- Bring one example of a Word document you prepared, if you have one.

## Sources

Provided documents: your message, which contains the invite's text, your summary of the ad and your background. No research was run in this pack.

Research tier: L0, no searches.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Brennock Facilities values | unavailable | Would have produced a values cheat sheet. Not run: no research was requested. |
| 2. Brennock Facilities interview process for admin roles | unavailable | Would have set the loop structure and persona weights. Not run: no research was requested. |
| 3. Company strategy and recent news | skipped | Nothing in the questions depends on company strategy for a first call. |
| 4. Interviewer name and profile | n/a | No name was given. |
| 5. Representative admin job description | skipped | Your summary of the ad fixes the requirements. |

## Upgrade menu

- The full ad text, pasted → F2 and F6 become quotes of the ad's own words, and the requirement column stops reading as your summary.
- Whether the role is remote-only, and its hours and country → F6 can be marked met or not met.
- The interviewer's name and title → persona weights and a tailored reverse question.
- Your prep time → a prioritised schedule.
- A tuesday-dossier.md → the gaps this prep exposes would carry forward to later sessions.
