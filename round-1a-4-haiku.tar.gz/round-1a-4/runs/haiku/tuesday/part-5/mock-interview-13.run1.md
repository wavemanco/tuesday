Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-5-rooms-case-13-denied-cf783c75/aa9daa16-81ed-4142-a966-64fcca8ab1d7/scratchpad/quillmoor_operations-coordinator_interview_pack.md. I built it for a recruiter screen, since Hannah's message sets the agenda.

The pack is built around her four topics. Every logistics answer uses your own words, quoted from your message:
- **Pay:** "I'm hoping for £42,000." Say it, then stop. Don't explain it, say whether it's firm, or offer a range.
- **Hybrid:** "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three."
- **Reason for moving:** the Bristol closure and the Reading offer, as you wrote them.

The highest-risk gap is production scheduling across planning, the warehouse and QA. Your material covers depot deliveries, not that. The pack has you state the delivery work exactly and say plainly if none of the production scheduling was yours. The SAP gap is handled the same way: you say you've never used it and describe how you'd learn.

I did no web research. Her message already sets the call's structure, so the pack says so in its Sources section.

Say the word and I'll play Hannah on the scheduling question, which the pack names as your highest-ROI prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed, and convert the pack to Word if you want it.

What's your notice period? It's the one term your material doesn't establish, so the pack leaves that slot for you.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator, recruiter screen

**Role:** Operations Coordinator, Quillmoor Diagnostics (diagnostic-test manufacturer, about 400 staff). Hybrid, two days a week at Avonmouth, Bristol. Advertised £38,000–£44,000.
**Interviewer:** Hannah Lowther, Talent Partner (recruiter).
**Round:** Recruiter phone screen, Thursday 2pm, 30 minutes. She rings the mobile number on your application.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Type key: **JD** = the advert's own requirements; **EXP** = what you actually did; **VAL** = values; **CO** = company knowledge; **CASE** = live problem. This pack uses JD and EXP only, because the material shows no values round, case or company-strategy question.

Guidance is scaffolding, not a script. Say only what your own sentences, quoted in the Provenance column, say.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | No gap. Your four years are at one employer with nothing inspected behind them, so expect a probe. Say the four years in those words. |
| F2 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | low | [grounded] | discovery | Your material shows a spreadsheet rebuilt, not a skill level, so the level is unknown. Answer slot: say what the rebuild involved, in your own words. If you would not call yourself confident with Excel, say so plainly. |
| F3 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | transferability | Adjacent work: deliveries across three depots, not production schedules across planning, the warehouse and QA. Say the deliveries in those words. Answer slot: if any of your scheduling touched a planning or QA step, say which. If none did, say so and stay with the depot deliveries. |
| F4 | "Track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | presentation | Your quote already covers chasing suppliers when orders slip; the advert calls the same work chasing late orders. Say it as the quote does. Do not claim a tracking system, because your material does not show one. |
| F5 | "Keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: stock-count discrepancies. Say it at its own scope: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Claim no sole credit (see the prohibited list). |
| F6 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show a dispatch report. Answer slot: if you produced a regular report on on-time delivery, say what it covered. If you did not, say so and say how you would set one up. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | You stated the absence, so the words come from your negative: "Never used SAP — we run our own in-house stock system." Then say how you would learn an ERP, as a plan, never as a past. |
| F8 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your own stated figure, and it sits inside the advertised band. Logistics slot: say the figure in your own words. No reason, floor, range or flexibility is given here. |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol." (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Two days is inside the limit you stated: no more than three. Logistics slot: say it in your own words. |
| F10 | "your notice period" (recruiter's message) | none given: your material does not establish your notice period. | none | [grounded] | hard_gate | Surfaced, not bridged. The one question for you sits in the message that presents this pack, not in this cell. |
| F11 | "what's prompting a move" (recruiter's message) | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message) | high | [grounded] | none | Your own reason, stated. Logistics slot: say it in your words, at this scope. The Reading offer is your stated negative, so keep it as you said it. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Her stated agenda: pay, notice, hybrid, reason for moving, then team and next steps | High. Her message names the agenda, so the logistics answers come first. Weight: top, 5 questions | Say each logistics answer once, in your own words, then stop. Treat the casual questions as scored. |
| Skeptic | Probes the gaps: SAP, production scheduling, Excel, dispatch reporting, the Reading offer | High for the two gaps the advert names first (scheduling and SAP). Weight: top, 5 questions | Rehearse the most predictable objection (B2) until it is routine. Say each limit plainly, and do not bluff a skill. |
| Data-driven prober | Asks how the one-third figure was counted | Medium: one headline number on your CV. Weight: mid, 3 questions | Say what you know about how the figure was counted, and say plainly when you do not know. |
| Pressure / stress | Challenges your reason for moving or your three-day limit | Low to medium. Weight: low, 2 questions | Hold through two follow-ups, then concede only the uncertainty you actually have. |

Values/Behavioral, Case/Strategist and Peer personas carry no weight here: the material shows no values round, case or peer interview.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B2 |
| Track supplier deliveries and chase late orders | A5, C4 |
| Keep stock records accurate | C1, C2 |
| Report weekly on on-time dispatch | B5 |
| 2+ years in operations or logistics coordination | A5 |
| Confident with Excel | B4 |
| ERP (SAP or similar) a plus | B1 |
| £38,000–£44,000 (pay, her first topic) | A1 |
| Hybrid, two days a week at Avonmouth | A3, D2 |
| Notice period (her topic) | A2 |
| Reason for leaving (her topic) | A4, B3, D1 |
| Team and next steps (her topic) | none, and why: she covers them in the call. R1 and R2 are the questions to ask about the team. |

## Question banks

### Conversational / rapport (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations for this role?" | JD | [grounded] "I'm hoping for £42,000." (your message) | Logistics slot, filled by your own figure: say "I'm hoping for £42,000." then stop. Do not explain the figure, say whether it is firm, or offer a range, floor or flexibility. If asked for your current pay, you may decline: "I'd rather keep to the role's terms." | Pay is her first topic. F8 shows the figure sits inside the advertised £38,000–£44,000, so the number is the answer. |
| A2 | "What's your notice period?" | JD | [grounded] "your notice period" (recruiter's message) | Instruction for the interview: give your actual notice period, in your own words. The pack has no figure for it and offers none. | F10: your material does not establish the notice period, so the slot is left for you. |
| A3 | "How would two days a week at our Avonmouth site work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | Logistics slot: say it in your own words, as quoted. If asked about the commute, your own words were: "I live in north Bristol." Do not describe a route, a time or a means of travel. | F9: two days is inside the limit you stated. |
| A4 | "What's prompting the move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message) | Logistics slot: give your reason in those words. Add no reason, timing or detail the quote does not carry. | F11: her topic, answered with your stated reason. |
| A5 | "Walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message); "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message); "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | Open prompt, a 90-second arc in your own words: the four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip; rebuilding the stock-count spreadsheet. Use those beats and nothing else. | F1, F3 and F5 are the arc's beats. Likely to open the screen. |

### Skeptic (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." (your message) | Plain acknowledgment, in your words: "Never used SAP — we run our own in-house stock system." Then say how you would learn an ERP, in the future tense. Never claim SAP or ERP work. | F7: the advert lists ERP as a plus, and your material shows the absence you stated. |
| B2 | "The advert's first requirement is production scheduling across planning, the warehouse and QA. Have you done that?" | JD | [grounded] "Coordinate production schedules between planning, the warehouse and QA" (advert); "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | Transferability: "I schedule deliveries for our three depots." Answer slot: if any of your scheduling touched a planning or QA step, say which and what you did. If none did, say so and stay with the depot deliveries. Hold: do not widen deliveries into production, even under a second probe. | F3, the gap most likely to be tested. **Highest-ROI prep in this pack:** rehearse with two follow-ups. |
| B3 | "You said the only offer is relocating to Reading. Would you consider it?" | EXP | [grounded] "the only offer is relocating to Reading, which I don't want." (your message) | Say it in your words: "which I don't want." Hold through two follow-ups. Do not add conditions or flexibility you did not state. | F11: motivation consistency. Your own negative is the answer. |
| B4 | "How confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | Answer slot: say what the rebuild involved, in your own words. If you would not call yourself confident with Excel, say so plainly. Name no functions or skills the material does not state. | F2: a skill level is not shown; the rebuild is. |
| B5 | "Have you reported on on-time dispatch before?" | JD | [grounded] "report weekly on on-time dispatch" (advert) | Answer slot: if you produced a regular report on on-time delivery, say what it covered. If you did not, say so and say how you would set one up. | F6: a requirement the advert names and your material does not show. |

### Data-driven prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that number was counted." | EXP | [grounded] "discrepancies fell by about a third over a year" (your message) | Answer slot: say how the figure was counted, in your own words, and what it is sensitive to. If you know the assumption you would defend least, name it. If you do not know how it was counted, say so. | The defend-the-number slot the one-third figure raises. No counting method is supplied. |
| C2 | "What else changed in that year?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | Say what the drop followed. If you know of other changes, say what they were and what part was yours. Do not claim the rebuild caused the whole fall. | F5: an attribution probe. Your sentence shows sequence, not sole cause. |
| C3 | "How many deliveries a week did those three depots take?" | EXP | [grounded] "I schedule deliveries for our three depots" (your message) | Say the volume if you know it. If you do not have the figure, say so. Estimate nothing. | F3: a denominator probe on the adjacent work. |

### Also in the prober's reach: open prompt

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C4 | "Tell me about an order that slipped and how you chased it." | EXP | [grounded] "chase suppliers when orders slip" (your message) | Open prompt: choose one instance and tell it in your own words. If none comes to mind, say so plainly, then say how you would handle a slipped order. | F4: presentation of the chasing you already do. |

### Pressure / stress (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your office is closing. What makes this role the right one for you?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year" (your message) | Answer slot: if you have a reason for this role beyond the closure, say it in your own words. If the closure is the reason, say so plainly. | F11: the pressure stem. Your stated reason is the closure. |
| D2 | "What would make you accept more than three days a week?" | JD | [grounded] "I wouldn't want more than three." (your message) | Hold: "I wouldn't want more than three." Hold through two follow-ups. If pushed past that, concede only the uncertainty you actually have, and add no flexibility you did not state. | F9: your stated limit is the position you hold. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like for whoever holds this role?" | Shows you are picturing the job, not only the offer. |
| R2 | "Which of planning, the warehouse or QA causes the most late orders today?" | Names the seam the advert's first requirement sits on. The answer shows where to start. |
| R3 | "How is the weekly on-time dispatch report used?" | Picks up a line of the advert and asks what it drives. |
| R4 | "Which stock system does the team run on day to day?" | A tools question that ties to the ERP line without claiming the answer. |
| R5 | "Is the two-day hybrid pattern set for the team, or can it change?" | Asks the pattern question you need answered, without asserting a limit on her side. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "Coordinated production schedules across planning, the warehouse and QA" | Inflated form of F3 | The quote at its own scope: "I schedule deliveries for our three depots." The pack's observation: your material says deliveries, not production. |
| "Advanced Excel" or "expert in Excel" | Inflated form of F2 | "I rebuilt our stock-count spreadsheet," at that scope. |
| "I cut discrepancies by a third" as your sole achievement | Inflated form of F5 (attribution) | "Discrepancies fell by about a third over a year," with the rebuild at its own scope. The pack's observation: your material does not show the rebuild as the only cause. |
| "I have SAP or ERP experience" | Negative you stated (F7) | "Never used SAP — we run our own in-house stock system." Plain acknowledgment, no slot. |
| "I'd relocate to Reading" or "I'd accept more than three days" | Your stated negatives (F9, F11) | "which I don't want." and "I wouldn't want more than three." Plain acknowledgments, no slot. |

No cell states, estimates or asks for your current pay, and none offers a range, floor or counter-offer you did not give.

## Sources

**Provided documents:** the advert text you pasted; Hannah Lowther's LinkedIn message as quoted in your note; your background and position as you wrote them.

**Searches and fetches sent:** none.

**Research tier: L1 — searches 0 of 6, fetches 0 of 2**
**User links read:** 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | skipped | No values section: the material detects no values-style round. |
| 2. Quillmoor Diagnostics interview process, operations coordinator | skipped | Her message fixes the call: 30 minutes by phone, four named topics, then team and next steps. |
| 3. Quillmoor Diagnostics strategy / recent news | skipped | Would have fed only a company-strategy bank or a reverse question. This screen carries neither, and the reverse questions are built from the advert. |
| 4. Hannah Lowther with Quillmoor Diagnostics | skipped | Her public footprint would not move a persona weight here. Her message fixes the call's agenda. |
| 5. Representative operations coordinator JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Your notice period → F10 moves from a gap the material does not establish to a stated term, and A2 carries your own figure. (Asked in the message that presents this pack.)
- Your CV → F1 and F3 can be quoted from the document, and their medium bands can be checked against it.
- A stock-count record or a dispatch report you produced → F5 and B5 gain an inspectable artifact, and C1 can carry the actual figure.
- The full posting, if the advert you pasted is shortened → requirement rows can be quoted from the complete text.
- A deeper research pass on Quillmoor Diagnostics (strategy brief, up to 6 more searches and 2 more fetches, several minutes) → reverse questions R1 to R5 gain current company context. Offered once; say if you want it.
