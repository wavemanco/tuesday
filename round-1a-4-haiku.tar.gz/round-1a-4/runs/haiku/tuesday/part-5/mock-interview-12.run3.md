**Before the prep, one thing in the invite:** it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview," and it says "you deposit the cheque and send the balance on to the vendor." Requests like these, for a fee, a cheque deposit, and ID or bank details before any offer, are a known scam pattern. This job is very likely a scam. Don't pay, deposit anything, or send documents or bank details until you've checked the invite with the employer through a phone number or address from its own website or careers page, not from the email. Job-underwriter can check the posting if you ask. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-5-rooms-case-12-denied-ee38224a/83153272-66dd-4b1a-91dc-8ff08298ead9/scratchpad/Brennock_remote-administrative-assistant_interview_pack.md`. It's built on the interview being real. Most of it still helps for any admin interview.

# Brennock Facilities Ltd: Remote Administrative Assistant interview prep pack

**Round:** 30-minute video call with the office manager, per the invite. Built from the invite text, your summary of the ad, and your background. No research was run.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your summary of the ad) | "ran the appointment book for four physios" (your message) | medium | [grounded] | presentation | "I was a receptionist at a physiotherapy clinic for two years, and I ran the appointment book for four physios." Keep it at four physios. |
| F2 | "booking travel" (your summary of the ad) | none given | none | [grounded] | discovery | Answer slot: if you have booked travel for anyone, say what and how. If not, say so plainly, then say how you'd learn the tools and policy. |
| F3 | "preparing documents in Word and Excel," Word part | "good with Word" (your message) | medium | [grounded] | presentation | "I'm good with Word." Nothing added. |
| F4 | "preparing documents in Word and Excel," Excel part | "okay with Excel" (your message) | low | [grounded] | discovery | Answer slot: if you've used Excel for a task, name it. If not, say so plainly and name the one Excel skill you'd practise first. |
| F5 | "processing supplier invoices" (your summary of the ad) | "chased unpaid invoices" (your message) | low | [grounded] | transferability | "I chased unpaid invoices." Your quote doesn't say which side of an invoice you handled. Answer slot: say which direction those ran, or say plainly you haven't processed supplier invoices. |

## Persona table

| Persona | How it shows up | Weight, and why | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: travel, Excel level, invoices | 5. A 30-minute office-manager call for a remote admin role leans hiring-manager, so Skeptic and Case | Name the gaps yourself, then say how you'd learn them |
| Conversational | Opens with "walk me through" | 3 | A 90-second arc from your own sentences |
| Case / Strategist | A small admin problem | 3 | Clarify first, then order the steps aloud |
| Data-driven prober | "How many? How did you count?" | 2 | Say what you know; say when you don't |
| Pressure | Time-boxed challenge to your fit | 2 | Hold through two follow-ups, then concede the specific gap |

## Question banks

**Skeptic (weight 5)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the appointment book you ran. What did it involve?" | EXP | [grounded] "ran the appointment book for four physios" (your message) | Describe what you did with it, in your words. Answer slot: if you made scheduling decisions yourself, say which. If the clinic set the rules, say so. | F1 is the calendar evidence |
| A2 | "How would you book a flight and hotel for an executive you'd never booked for?" | JD | [grounded] "booking travel" (your summary of the ad) | Structure it: confirm dates, budget, approvals; book; send the itinerary. Answer slot: if you've booked travel, say what. If not, say so and describe how you'd learn the tool and policy. | F2 is your least-evidenced requirement. Highest-value rehearsal |
| A3 | "Show me how you'd set up a simple spreadsheet to track supplier invoices." | CASE | [generic] | Columns first: invoice number, supplier, date, amount, due date, status. Then how you'd keep it current. No claim about your past. | A live problem, so it needs no claim about you |
| A4 | "You said you're okay with Excel. What have you done in it?" | EXP | [grounded] "okay with Excel" (your message) | Answer with what you've done. Answer slot: name the task if there was one; say so if you've only used lists, or not at all. | F4 is the thinnest evidence on the ad's list |
| A5 | "Which side of an invoice did you deal with, and what did it involve?" | JD | [grounded] "chased unpaid invoices" (your message) | Say which side and what the work was. Answer slot: if you haven't processed supplier invoices, say so and describe how you'd learn the approval and payment steps. | F5 is transferability; the question asks for your quote's scope |

**Conversational (weight 3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "So, walk me through your background." | VAL | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | 90-second arc: clinic, appointment book, invoices, Word and Excel, why this role | The opener is scored |
| B2 | "What part of the job suits you most?" | VAL | [generic] | Pick one part from the ad and tie it to a sentence you can back | Shows fit without a claim you can't back |
| B3 | "What are you looking for in your next role?" | VAL | [generic] | Stay with what the ad describes | Tests whether you've read the ad |

**Case / Strategist (weight 3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A director needs a meeting room, a flight and a hotel on the same morning. What first?" | CASE | [generic] | Clarify the deadline and priority, order the three tasks, say what you'd confirm with the director | Tests triage |
| C2 | "Two meetings clash on a manager's calendar. How do you decide?" | CASE | [generic] | Clarify who each matters to, move the lower-priority one, tell both people | Tests calendar judgement |
| C3 | "A supplier invoice shows paid, but the bank shows nothing. What now?" | CASE | [generic] | Check the payment record, then the bank record, then contact the supplier; name who you'd escalate to | Tests the invoice process |

**Data-driven prober (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How many appointments did that book cover in a week?" | EXP | [grounded] "ran the appointment book for four physios" (your message) | Give a number only if you know it. Answer slot: if you give one, say how you knew it and which part you'd be least sure of. | F1; a figure is the first thing a prober asks for |
| D2 | "How did you know an invoice was unpaid? What did you check?" | EXP | [grounded] "chased unpaid invoices" (your message) | Say what you checked. If someone else kept that record, say so. | F5 |

**Pressure (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You've only done reception work. Why should this be your next role?" | VAL | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | Hold through two follow-ups on what the reception work covered. Then concede the specific gap, travel or invoices, and say how you'd close it. | Hold-then-concede |
| E2 | "Honestly, you haven't done this job. Why should I hire you?" | JD | [grounded] "booking travel" (your summary of the ad) | Hold on the appointment book, the invoices you chased, Word. Concede plainly you haven't booked travel for a company, and give your plan to learn it. | F2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like in this role?" | Shows you're planning for the real workload |
| R2 | "Which of the four parts of the job takes most of the time?" | Tells you where to focus prep |
| R3 | "Which tools do you use for travel booking and invoices?" | Lets you name tools to learn |
| R4 | "How is someone supported in their first month?" | Shows you want to start well |
| R5 | "What does the process look like from here?" | A process question, not a check on the invite. Shows whether another round follows |

## The prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Managed company-wide calendars | Inflated form of F1 | "ran the appointment book for four physios." Your material shows one book for four physios |
| Advanced or fluent in Excel | Inflated form of F4 | "okay with Excel" |
| Processed supplier invoices, or ran accounts payable | Inflated form of F5 | "chased unpaid invoices," at its own scope |

## Upgrade menu

- The full ad text → the requirement quotes become the ad's own sentences, not your summary
- Confirmation of the role and interview from the company's own website or careers page → the pack can name the company's own process. Check this through contact details you find yourself

**Drill:** I can run a live rehearsal of A2 (the travel question, your biggest gap) with follow-ups, and score it against that question's guidance.
**Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

Two questions so I can tighten the pack:
1. Can you paste the full ad text?
2. How did the invite reach you: from a company email address, a job board, or a video-call platform?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock_remote-administrative-assistant_interview_pack.md -----
# Brennock Facilities Ltd: Remote Administrative Assistant interview prep pack

**Role:** Remote Administrative Assistant
**Company:** Brennock Facilities Ltd, as named in the invite. Not checked.
**Round:** 30-minute video call with the office manager, per the invite
**Built from:** the invite text, your summary of the ad, and your message about your background. No research was run.

## How to use

Personas describe how a question is asked. Types describe what is being scored:

- **VAL**: behavioural or values alignment
- **EXP**: your experience, and whether it holds up to questions
- **JD**: the job's own requirements
- **CO**: knowledge of the company (none here; the company was not researched)
- **CASE**: a small live problem

Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your summary of the ad) | "ran the appointment book for four physios" (your message) | medium | [grounded] | presentation | Your words already reach this: "I was a receptionist at a physiotherapy clinic for two years, and I ran the appointment book for four physios." Keep it at four physios. |
| F2 | "booking travel" (your summary of the ad) | none given | none | [grounded] | discovery | Answer slot: if you have booked travel for anyone, say what you booked and how. If you have not, say so plainly, then say how you would learn the booking tools and the company's policy. |
| F3 | "preparing documents in Word and Excel" (your summary of the ad), Word part | "good with Word" (your message) | medium | [grounded] | presentation | "I'm good with Word." Nothing added to it. |
| F4 | "preparing documents in Word and Excel" (your summary of the ad), Excel part | "okay with Excel" (your message) | low | [grounded] | discovery | Your material says "okay" with no example. Answer slot: if you have used Excel for a task, name the task. If you have not used it for work, say so plainly, and name the one Excel skill you would practise first. |
| F5 | "processing supplier invoices" (your summary of the ad) | "chased unpaid invoices" (your message) | low | [grounded] | transferability | Your quote is about chasing payment. It does not say which side of an invoice you handled, so the bridge stays at that scope: "I chased unpaid invoices." Answer slot: say which direction those invoices ran, in your own words. If you have not processed supplier invoices, say so plainly. |

Gap types here follow the routing rule: `presentation` where a quote already reaches the requirement in other terms, `transferability` where adjacent work does not reach it, and `discovery` where the material does not show the evidence.

## Persona table

| Persona | How it shows up | Weight, and why | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: travel, the level of your Excel, supplier invoices | 5. A 30-minute call with an office manager for a remote admin role is a hiring-manager round, and that prior leans to Skeptic and Case | Rehearse the gaps until they are plain. Name them yourself, then say how you would learn them |
| Conversational | Opens with an unstructured "walk me through" | 3. Casual questions are still scored | Have a 90-second arc ready: your role, the appointment book, invoices, Word and Excel, and why this job |
| Case / Strategist | A small admin problem from the job | 3. Tests how you structure a task | Clarify first, then order the steps out loud |
| Data-driven prober | Asks how a number was counted | 2. Applies to the appointment book | Say what you know, and say plainly when you do not know |
| Pressure | A time-boxed challenge to your fit | 2. Tests composure | Hold your position through two follow-ups, then concede the specific gap |

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the appointment book you ran. What did it involve?" | EXP | [grounded] "ran the appointment book for four physios" (your message) | Describe what you did with the book, in your own words. Answer slot: if you made scheduling decisions yourself, such as moving bookings or handling clashes, say which. If the clinic set those rules, say so. | F1 is the evidence for calendars. EXP because it tests what was yours |
| A2 | "How would you book a flight and a hotel for an executive you had not booked for before?" | JD | [grounded] "booking travel" (your summary of the ad) | Structure it: confirm dates, budget and approvals first, then book, then send the itinerary. Answer slot: if you have booked travel for anyone, say what you booked. If not, say so plainly and describe how you would learn the company's tool and policy. | F2 is the gap. This is the highest-value rehearsal in the pack, because it is the requirement you have the least to show for |
| A3 | "Show me how you would set up a simple spreadsheet to track supplier invoices." | CASE | [generic] | Name the columns first: invoice number, supplier, date, amount, due date, status. Then say how you would keep it current. Make no claim about your past. | F4 and F5 are where this probe lands. The question is a live problem, so it needs no claim about you |
| A4 | "You said you are okay with Excel. What have you done in it?" | EXP | [grounded] "okay with Excel" (your message) | Answer with what you have actually done, in your own words. Answer slot: if you used it for a task, name the task. If you have only used it for lists, say so. If not at all, say so plainly. | F4 is the thinnest evidence on the ad's list, so expect this probe |
| A5 | "Which side of an invoice did you deal with, and what did that involve?" | JD | [grounded] "chased unpaid invoices" (your message) | Say which side you handled and what the work was. Answer slot: if you have not processed supplier invoices, say so and describe how you would learn the approval and payment steps. | F5 is a transferability row. The question asks for the scope of your quote, not more |

### Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "So, walk me through your background." | VAL | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | A 90-second arc: the clinic, the appointment book, invoice chasing, Word and Excel, why this role. Use your own words for each. | The opener is scored. The arc is built from your quoted sentences only |
| B2 | "What part of the job do you think suits you most?" | VAL | [generic] | Pick one part from the ad, such as calendars or documents, and tie it to a sentence you can back from your background. | Lets you show fit without claiming anything you have not done |
| B3 | "What are you looking for in your next role?" | VAL | [generic] | Keep it to what the ad describes. Do not promise anything you have not done. | A low-stakes question that still tests whether you have read the ad |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A director needs a meeting room, a flight and a hotel on the same morning. What do you do first?" | CASE | [generic] | Clarify the deadline and the priority first, then order the three tasks, then say what you would confirm with the director. | Tests triage, which the job needs. No claim about your past |
| C2 | "Two meetings on a manager's calendar clash, and you are asked to fix it. How do you decide?" | CASE | [generic] | Clarify who the meetings matter to, then move the lower-priority one, then tell both people. | Tests calendar judgement, which the ad asks for |
| C3 | "A supplier invoice shows as paid, but the bank shows nothing. What do you do?" | CASE | [generic] | Check the payment record, then the bank record, then contact the supplier. Say who you would escalate to. | Tests the invoice process without any claim about your experience |

### Data-driven prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How many appointments did that book cover in a week?" | EXP | [grounded] "ran the appointment book for four physios" (your message) | Give a number only if you know it. If you did not count, say so plainly. Answer slot: if you give a figure, say how you knew it and which part of it you would be least sure of. | F1 is the calendar evidence, and a figure is the first thing a prober asks for |
| D2 | "How did you know an invoice was unpaid? What did you check?" | EXP | [grounded] "chased unpaid invoices" (your message) | Say what you checked, in your own words. If someone else kept that record, say so. | F5 is the invoice evidence. The question asks how you knew, not what the process was |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You have only done reception work. Why should this be your next role?" | VAL | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | Hold: say what the reception work covered, in your own words. Hold through two follow-ups. Then concede the specific gap, travel or supplier invoices, and say how you would close it. | The challenge is to your fit, so hold and concede exactly |
| E2 | "Honestly, you have not done this job. Why should I hire you?" | JD | [grounded] "booking travel" (your summary of the ad) | Hold on what the quotes carry: the appointment book, the invoices you chased, Word. Concede plainly that you have not booked travel for a company. Give your plan to learn it. | F2 is the gap. Hold-then-concede keeps you from overclaiming under pressure |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like for the person in this role?" | Shows you are planning for the real workload |
| R2 | "Which of the four parts of the job takes most of the time?" | Tells you where to focus your prep |
| R3 | "Which tools do you use for travel booking and for invoices?" | Lets you name the tools you need to learn |
| R4 | "How is someone supported in their first month?" | Shows you want to start well |
| R5 | "What does the process look like from here?" | A process question, not a check on the invite. It tells you whether another round follows |

## The prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for a company or its executives | Inflated form of F1 | "ran the appointment book for four physios." The limit is this pack's observation: your material shows one appointment book for four physios, not company-wide calendars |
| Advanced or fluent in Excel | Inflated form of F4 | "okay with Excel" |
| Processed supplier invoices, or ran accounts payable | Inflated form of F5 | "chased unpaid invoices," at its own scope |

## Sources

- Provided documents: the invite text, your summary of the ad, and your message about your background.
- Research tier: L0. No searches or fetches were run.

## Upgrade menu

- The full ad text → each requirement's quote becomes the ad's own sentence, not your summary
- Confirmation of the role and interview from the company's own website or careers page → the pack can name the company's own process. Check this through contact details you find yourself, not those in the invite
