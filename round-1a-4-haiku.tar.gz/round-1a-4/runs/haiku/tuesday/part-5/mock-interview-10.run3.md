Before the prep, one thing in the invite: it says "Our hiring process is fully remote and is carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well." A hiring process run wholly by chat is a known scam pattern, and a chat alone does not show who you are dealing with. Until you have checked the invite, send no money, documents or bank details through Telegram. Check it with Lumenvale Software through contact details from its own website or careers page, not through this chat. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-5-rooms-case-10-denied-299c4c46/b81253e1-de4d-49f6-a1b9-58870ed6c4f1/scratchpad/lumenvale_customer-support-specialist_interview_pack.md. I built it for a team-lead round, since the team lead will run the chat. It has 18 questions. The first thing to rehearse is B1, the question about never having worked for a software company, because it's the most likely objection.

Say the word and I'll play the Skeptic on B1. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Could you paste the full job ad? My version is your summary, so the exact wording of the requirements is missing.

Did Marcus or the team lead say what the chat covers, such as a scenario, a written task or a time limit?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer-support-specialist_interview_pack.md -----
# Lumenvale Software: Customer Support Specialist interview prep pack

**Role:** Customer Support Specialist (remote)
**Company:** Lumenvale Software
**Interviewer:** support team lead (name not given)
**Round:** text-chat interview on Telegram, relationship: hiring manager (the team lead runs the chat)
**Changes:** first version

## How to use + type key

Personas are how a question is asked. Types are what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only about what you actually did.

- **CASE**: a live problem from the role, delivered now
- **EXP**: a question about something you did in your current job
- **JD**: a question about a requirement in the job ad

## Fit snapshot

The requirements below are your own summary of the ad. A full copy of the ad would sharpen the wording (see the upgrade menu).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your summary of the ad) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | presentation | Your material says customer service advisor, not customer support, at an energy supplier. Say the title and the three years in those words: "For three years I was a customer service advisor at an energy supplier." |
| F2 | "experience with Zendesk or a similar ticketing tool" (your summary of the ad) | "I use Freshdesk every day" (your message) | high | [grounded] | none | Your quote already reaches the requirement, because Freshdesk is a ticketing tool. Say Freshdesk, and do not say Zendesk: your material does not show it. |
| F3 | "clear written communication" (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not show this yet. Answer slot: think of one written reply you sent that a customer had to act on. Say what you put in it and how you checked it was clear. If none comes to mind, say so plainly, then describe the written work you did in the advisor role. |
| F4 | "confidence handling escalations" (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not show this yet. Answer slot: if any call or email in your advisor role went to a supervisor or another team, say what it was, what you did first, and what you handed on. If none did, say so plainly, then describe the hardest contact you did handle yourself. |

**Coverage:** F1 is covered by B4 and D1. F2 is covered by A4, C3 and D2. F3 is covered by A3 and B3. F4 is covered by A2, B2 and E2.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | "I use Freshdesk every day." Your material shows Freshdesk, not Zendesk. |
| Designed or set the refunds process | Inflated form of "I trained four new starters on our refunds process last year" | "I trained four new starters on our refunds process last year." |
| Has worked in a software company | Negative you stated: "I've never worked for a software company" | "I've never worked for a software company." |

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live support scenarios from the role: a refund, a bug, a backlog | 5. A team lead running a support round usually tests how you handle live tickets | Clarify first, then say what you would do in order |
| Skeptic | Probes the gaps: software background, escalations, written communication | 4. The team lead is the one who will feel these gaps day to day | Say the gap plainly, then give the first step you would take |
| Data-Driven Prober | Asks how your figures were counted | 3. "around 60 calls and emails a day" and four trainees are figures that get asked about | Say what you know and how you know it; say so when you do not know how it was counted |
| Conversational | Friendly opener and casual questions in the chat | 3. Text openers are still scored | A 90-second arc for the opener; treat casual questions as scored |
| Pressure | Short, time-boxed follow-ups in the chat | 3. Text replies can be pushed fast | Hold your position through two follow-ups, then concede what is real |

## Question banks

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer has waited two weeks for a refund and is angry. What do you do first, and what do you tell them?" | CASE | [generic] | Check where the refund is stuck and what the customer was told. Reply with what you know and when they will hear next. Say what is yours to fix and what goes to someone else. | A live problem from the role. No claim about your past. |
| A2 | "A colleague escalates a ticket to you as urgent, but you cannot reproduce the bug. What do you do?" | CASE | [generic] | Re-read the ticket. Ask the customer for exact steps and what they were using. Set their expectations, then hand on a clear summary to the right team. | Tests the escalations requirement (F4). No claim about your past. |
| A3 | "How would you reply to a customer who is furious about a bug that is not yours to fix?" | JD | [generic] | Acknowledge the problem in one sentence. Say what you can do now and what you cannot. Give a date for the next update, and keep it. | Tests clear written communication (F3). No claim about your past. |
| A4 | "How would you set up a view or a reply template for a new kind of ticket?" | JD | [grounded] "I use Freshdesk every day" | Describe the steps in general terms, then name the Freshdesk features you have used. Say plainly that you have not used Zendesk if you have not. | Tests the ticketing requirement (F2). The guidance claims only the quote's tool. |
| A5 | "You have 40 open tickets and 30 minutes. How do you choose what to work on?" | CASE | [generic] | Sort by what is urgent for the customer, then by what is blocking others. Say what you would leave open and tell the customer why. | A live prioritisation problem. No claim about your past. |

### Skeptic (weight 4): highest-ROI prep

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never worked in a software company. What would take you longest to learn here?" | JD | [grounded] "I've never worked for a software company" | Plain acknowledgment: "I've never worked for a software company." Then name the part you would learn first, as a plan for the future and not a claim about the past. Hold this line; do not claim software experience. | This is the most predictable objection for this candidate, so it gets the deepest rehearsal. |
| B2 | "Tell me about a time you had to escalate something. What did you decide?" | CASE | [generic] | Open prompt. If you have a real example, tell it in your own words. If none comes to mind, say so plainly, then give the nearest thing your advisor role carries, or how you would handle it. | Open prompt on F4. No claim about your past. |
| B3 | "How do you check that a written reply is clear before it goes out?" | JD | [generic] | Name the checks you actually run. If you run none, say so, then say what you would start doing. | Open prompt on F3. |
| B4 | "Two years is the bar, and you have three in a different sector. Why should we believe the work transfers?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" | Say the work in the quote's own terms, then the volume: "answering around 60 calls and emails a day." Name what you would still need to learn about a software product. | Addresses F1 directly. The guidance stays inside the quote's scope. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You answered around 60 calls and emails a day. How was that split between what you closed and what you passed on?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say the figure in your words. Name its weakest assumption: it is an estimate, and "around" is part of it. If you do not know the split, say so. | Defend-the-number slot on the volume figure. |
| C2 | "You trained four new starters. How did you know when they were ready?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Answer slot: if you checked readiness in any way, say how. If you did not measure it, say so, then say what you would check next time. | Probes the one figure about training. |
| C3 | "How do you tell whether you are closing tickets on time?" | JD | [grounded] "I use Freshdesk every day" | Name the Freshdesk views or reports you actually look at. If you do not track a time figure, say so. | Tests the ticketing requirement with a question about method, not a figure. |

### Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through how you got into customer support." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | A 90-second arc: the job, the volume, the training you gave, and why you are applying. Keep it to what you did. | The opener is scored. Your quote carries the arc. |
| D2 | "What do you use day to day for tickets?" | JD | [grounded] "I use Freshdesk every day" | Name Freshdesk and one thing you do in it. Do not name Zendesk. | Casual question on F2. |
| D3 | "What part of the job are you most looking forward to?" | CASE | [generic] | Name one part in your own words. If it connects to your material, use the sentence that carries it. | A casual question that is still scored for interest. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone with software support experience?" | JD | [grounded] "I've never worked for a software company" | Hold: do not argue the software point. Say what you did do, using only the quotes: "answering around 60 calls and emails a day" and "I trained four new starters on our refunds process last year." Hold through two follow-ups, then concede what is real. | Time-boxed and pointed. Holding a true position is the skill being tested. |
| E2 | "The ad asks for confidence with escalations. How have you shown that?" | JD | [grounded] "confidence handling escalations" (your summary of the ad) | Answer slot: if you can name an escalation you handled, say it in your words. If you cannot, say so plainly, then say what you would do first. | Tests F4 under pressure. |
| E3 | "Why are you moving from energy to software?" | EXP | [grounded] "I've never worked for a software company" | Give your own reason in your own words. Your material does not give one, so the pack does not supply one. | Motivation probe. The pack has no reason on record for you. |

## Reverse questions

1. "What does a new person's first month look like on this team?" Why it lands: shows you are planning ahead for the work.
2. "Is the chat a single exchange, or do several rounds follow?" Why it lands: a process question that helps you plan your prep.
3. "What does an escalated ticket look like here, and who takes it?" Why it lands: goes straight to F4.
4. "Which ticketing tools does the team use, and how are macros shared?" Why it lands: goes straight to F2.
5. "What would make someone in this role excellent after six months?" Why it lands: shows you care about the outcome, not only the offer.

## Sources

- Provided documents: your message with your background and the summary of the ad; the invite text you pasted.
- No search or fetch was run in this turn.

Research tier: L0 (none run)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Would give a values cheat sheet; no consent to research yet |
| 2. Lumenvale Software interview process | unavailable | Would confirm the loop structure; no consent to research yet |
| 3. Lumenvale Software strategy / recent news | unavailable | Would add company context; no consent to research yet |
| 4. Interviewer name and company | n/a | No name given |
| 5. Representative Customer Support Specialist JD | skipped | Your summary of the ad already fixes the requirements in the fit snapshot |

## Upgrade menu

- The full job ad text → exact wording for F1 to F4, and any requirements your summary left out
- Your consent to a light research pass on Lumenvale's public support process → an interview format, and any published values to map your stories to
- One written reply you sent that a customer acted on → an answer for the F3 slot and for B3
- Any escalation you handled, even a small one → an answer for the F4 slot, for B2 and for E2
- A tuesday-dossier.md, if you have one → sharper rehearsal of the objection in B1
