Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-5-rooms-case-13-denied-872f6e8a/d814bac8-228b-4f23-a0d5-46dd9a45f965/scratchpad/quillmoor_operations-coordinator_interview_pack.md. It has 14 questions, a fit snapshot against the advert, and a prohibited list. Web search was refused in this session, so it uses only your advert, Hannah's message and your notes, with no outside research on Quillmoor.

The biggest prep item is the Reading question (C1). Hannah will likely ask whether you'd consider relocating, and your answer should stay with what you've already said: the office is closing and you don't want Reading.

Say the word and I'll run that question as a live drill. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.

What is your actual notice period? Hannah will ask, and I left that line open in the pack until you tell me.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator, recruiter screen

Talent Partner: Hannah Lowther. Thursday 2pm, 30-minute phone call, on the mobile number in your application.

## How to use this pack

Personas are how a question is asked. Types are what it is scoring. Guidance is scaffolding for a spoken answer, not a script. Everything in quotation marks is your own words, from your message or the advert, and nothing in the pack adds to them.

Type key:
- **EXP**: what you actually did, and whether your claims survive a follow-up.
- **JD**: whether you can do what the advert lists, including the parts you cannot yet.
- **VAL**, **CO**, **CASE**: not used. A screen has no values round, no strategy questions and no live problem.

This is a 30-minute logistics screen, so the pack is short: 14 questions. Its job is to make your pay, notice, location and reason answers consistent and easy to say.

## Fit snapshot

Requirements come from the advert, your message, or Hannah's message, as named in each row. Confidence is how well your own words support the claim. Provenance is what this pack wrote on top of them. Gap type is what the material shows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | No gap. Say it in those words. Nothing has been inspected, so expect a question on what the job covered. |
| F2 | "coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | low | [inferred] | transferability | Your material shows delivery scheduling for three depots. It does not show production scheduling, planning, the warehouse or QA. Answer slot: if you have coordinated work between planning, a warehouse or a quality team, say what it was and what part was yours. If you have not, say so plainly and say which part of the deliveries work is closest. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | medium | [grounded] | none | No gap. Say it in those words. Nothing has been inspected. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | presentation | Your words already reach stock records: the spreadsheet, and the discrepancy figure. Keep both at their own scope: the spreadsheet, and discrepancies down about a third over a year. Expect a probe on how the figure was counted (D1). |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Answer slot: if you have reported on delivery timing or dispatch, say what you reported and how often. If you have not, say so plainly. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | Your material mentions a spreadsheet and does not say which tool it was. Answer slot: if you built it in Excel, say what it does, in your own words. If it was another tool, say that plainly. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | low | [grounded] | capability | You stated the absence, so the plain acknowledgment is "Never used SAP." The in-house system is named only at its own scope: a system you run, not ERP experience. Any account of what you did in it is your own to give, and the plan for learning SAP is said as a plan, never as a past. |
| F8 | "two days a week at our Avonmouth site in Bristol" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | No gap. This is your own stated limit. Say it in those words. Add no commute plan. |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | No gap. The figure sits inside the advert's band. Say it in your own words, with nothing added. |
| F10 | "your notice period" (Hannah's message) | none given | none | [grounded] | hard_gate | Your material does not establish your notice period, so nothing here assumes one. The one question in this message asks for it. |
| F11 | "what's prompting a move" (Hannah's message) | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | high | [grounded] | none | No gap. Say the facts in the quote, as they are. |

Your message gives the facts behind F11. Nothing here adds a reason.

## Persona table

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly logistics: background, notice, pay, hybrid and the move | 5 questions, the top weight. A recruiter screen's prior is logistics in a friendly register, and casual questions are still scored | Say your quoted words in your own voice. Treat the easy questions as scored. |
| Skeptic | The move against the Reading offer, SAP, Excel, dispatch reporting | 4 questions. The prior is knockout checks and motivation consistency | Know the Reading answer by heart. Say the SAP acknowledgment plainly. |
| Data-Driven Prober | The "about a third" figure; depot scheduling; the production scope | 3 questions. Your one headline figure gets the defend-the-number slots | Say how the figure was counted, or say you do not know. |
| Pressure / Stress | A timed "why this role" and the SAP challenge | 2 questions, light, because a screen is friendly. Included as a composure check | Pause, restate the question, and hold through two follow-ups before you concede anything. |
| Case / Strategist | None | Not weighted. A screen has no live problem | Not applicable |
| Values / Behavioral | None | Not detected. No loop source documents a values round | Not applicable |

Loop: the recruiter's own message establishes this one call and what it covers, so no archetype fallback is used.

## Question banks

### Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Talk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | A 90-second arc: the four years, the wholesaler, the three depots, and the supplier chasing, in those words. Stop there. | F1 and F3 are the evidence. The opener sets the tone for a scored screen. |
| B2 | "What's your notice period?" | JD | [grounded] Hannah: "your notice period" | Give your actual notice period, in your own terms. Nothing else is needed. | F10 is a gate the material leaves open. This is Hannah's own logistics line. |
| B3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | Say "I'm hoping for £42,000." That is the whole answer. If asked for a range, a floor, or what you earn now, you can say you would like to hear the role's band first. | F9 is the figure. The pack gives no reason, floor, range or current pay. |
| B4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Say it in those words. Add no commute plan. If asked about the commute, your own words were: "I live in north Bristol". | F8 is your stated limit. |
| B5 | "What's prompting a move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say the facts in the quote, as they are. Nothing more. | F11 is the listed topic. Its answer must match C1. |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Would you consider relocating to Reading?" | JD | [grounded] "the only offer is relocating to Reading, which I don't want" | Highest-ROI prep in this pack. Hold: "I don't want to relocate to Reading." Hold through two follow-ups by returning to the quote's fact, that the office closes next year. Add no new reason. | This is where a motivation check lands hardest, and where an unrehearsed answer costs most. The hold is one you stated. |
| C2 | "This role lists SAP or a similar ERP as a plus. What's your experience there?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Say "Never used SAP." Then, if you worked directly in the in-house stock system, say what you did in it, in your own words. If you only saw its output, say so. | F7 is a stated absence, so this is a plain acknowledgment. The in-house system stays at its own scope. |
| C3 | "How confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: if you built the spreadsheet in Excel, say what it does, in your own words. If it was another tool, say so plainly. | F6 is discovery. The advert asks about Excel as a screening check. |
| C4 | "This role reports weekly on on-time dispatch. Have you reported on that?" | JD | [grounded] advert: "report weekly on on-time dispatch" | Answer slot: if you have reported on delivery timing or dispatch, say what you reported and how often. If not, say so plainly. | F5 has nothing in your material, so the pack has nothing to say for you. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How was the 'about a third' counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say how it was counted, in your own words. Name the assumption you would defend least, before it is asked. The material does not say which that is. If you did not do the counting yourself, say so. | F4 is the figure. The defend-the-number slots are how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. |
| D2 | "What did you decide when you scheduled deliveries for the three depots?" | EXP | [grounded] "I schedule deliveries for our three depots" | Say what you decided, in your own words. If anything was set for you, say so. | F2's limit: the material shows scheduling at depot level, not production scope. |
| D3 | "Production scheduling across planning, the warehouse and QA: have you done that?" | JD | [grounded] advert: "coordinate production schedules between planning, the warehouse and QA" | Answer slot: if you have coordinated work across planning, a warehouse or a quality team, say what it was and what part you held. If not, say so plainly and say which part of the deliveries work is closest. | F2. This is the advert's first duty, and the likeliest JD probe. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Thirty seconds: why this role?" | EXP | [grounded] Hannah: "what's prompting a move" | Start from the quote's fact. Then name one thing about this role that the advert shows, in your own words. If nothing beyond the move comes to mind, say so plainly, and give the nearest thing your material carries: the deliveries and the stock-count work. | A composure check. The open prompt's theme comes from Hannah's own line. |
| E2 | "Your answer is 'never used SAP'. Why should we consider you for a role that lists it?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Hold: "Never used SAP." Hold through two follow-ups by returning to what your material carries: the in-house stock system, at its own scope. Concede what is true: you have not used SAP. Say how you would learn it, as a plan, never as a past. | The defensive answer shows here. F7's plain acknowledgment and its plan are the whole answer. |

## Reverse questions

1. **"What does the first month look like for whoever takes this role?"** Why it lands: it shows you are thinking about the job, not only the offer.
2. **"How is the hybrid pattern set, and which days are expected at Avonmouth?"** Why it lands: it ties to B4 and shows you are planning the schedule.
3. **"Does the team mostly work with planning, the warehouse or QA?"** Why it lands: it resolves F2, and tells you where production scheduling sits.
4. **"Which systems hold the production and stock records today?"** Why it lands: it gives you the SAP picture before C2 is asked again.
5. **"How is on-time dispatch reported now?"** Why it lands: it pairs with C4 and shows you know the advert's reporting line.
6. **"What are the next steps after this call, and who would I speak to?"** Why it lands: Hannah said she would cover next steps, and the answer sets your timing.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| "Has SAP experience" | Inflated form of F7: the in-house system stretched into ERP experience | "Never used SAP." Plus the in-house quote at its own scope. |
| "Ran production scheduling across planning, the warehouse and QA" | Inflated form of F2 | "I schedule deliveries for our three depots," at its own scope. D3's slot stays on what was yours. |
| "Excel expert" or "advanced Excel" | Inflated form of F6 | "I rebuilt our stock-count spreadsheet," at its own scope. C3's slot. |
| "The one-third drop came from my work alone" | Inflated form of F4 | "discrepancies fell by about a third over a year," with D1's slot on how it was counted. |
| Any pay floor, range or flexibility | You gave one figure, as a hope. No range or floor was stated | "I'm hoping for £42,000." |

## Requirement coverage

| Requirement (advert or Hannah) | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | B1 |
| Coordinate production schedules between planning, the warehouse and QA | D3 |
| Track supplier deliveries and chase late orders | B1, D2 |
| Keep stock records accurate | D1 |
| Report weekly on on-time dispatch | C4 |
| Confident with Excel | C3 |
| ERP experience (SAP or similar) a plus | C2, E2 |
| Hybrid: two days a week at Avonmouth | B4 |
| £38,000–£44,000 | B3 |
| Notice period (Hannah) | B2 |
| What's prompting a move (Hannah) | B5, E1 |

## Sources

Provided documents: the advert, as pasted; Hannah Lowther's LinkedIn message; your background and your notes on the move.

Queries sent:
- "Quillmoor Diagnostics values Avonmouth": refused. Web search permission was not granted in this session.

Research tier: L1 — searches 1 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Would have checked the company's published values for vocabulary. No values round is detected for this screen, so nothing was lost in the pack. |
| 2. Quillmoor interview process | unavailable | Would have named any round after this call. Hannah's message already establishes the call and what it covers. |
| 3. Strategy or recent news | unavailable | Would have fed company questions. None are used in a screen. |
| 4. Interviewer name | unavailable | Would have read Hannah's public footprint. The recruiter is not the hiring manager, so the read would not change the weights. |
| 5. Representative JD | skipped | The advert you supplied fixes the fit snapshot and the JD questions. |

## Upgrade menu

- Your notice period, in your own words → B2 and F10 become a stated figure, and the notice line stops being open.
- The hiring manager's name, once Hannah shares it → an interviewer read and team-level reverse questions for the next round.
- Web search permission → the values and process checks (targets 1 and 2) would run, and the values vocabulary would be checked against the company's own page.
- A deeper research pass, up to 6 more searches and 2 more fetches, several minutes → company strategy and recent news for a later round. Not needed for Thursday. Say if you want it.
