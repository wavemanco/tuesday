Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-5-rooms-case-9-canned-8c799dda/dd160e8b-36b9-415e-ac04-5fb6d1aaa9c5/scratchpad/Halvering_Elementary_fourth-grade-teacher_interview_pack.md. I built it for the Thursday panel, using the invite, your résumé and the district's published "Mission and Beliefs" page.

Your Social Security number isn't needed for this interview or this prep, so I haven't repeated it or used it. Keep it off your résumé and out of application material unless a specific form requires it.

The two gaps the panel will most likely press on are fourth grade and team lead. The pack rehearses the first one hardest: "I've never taught fourth grade," followed by what you did teach and how you'd learn the standards. For team lead, it keeps you to "I led our grade level's move to a new reading curriculum in 2024" and does not stretch that into a leadership claim.

Two things would sharpen it:
- Can you paste the job posting? Right now the JD-tagged questions come only from the invite's wording.
- Did the panel say whether it wants a demo lesson or any other deliverable? If so, I'll add a build section for it.

Offers, not pushed:
- Say the word and I'll play the principal's Skeptic on S1, the question the pack names as highest-return prep.
- I can save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_Elementary_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary (Orrinsford Community School District)

Panel interview, 45 minutes, Thursday. Panel: Principal Dolores Vantongeren, plus two members of the fourth-grade team (names not given).
Built from: the HR invite, your résumé and message, and one fetched page (Orrinsford "Mission and Beliefs"). No job description was supplied; JD-tagged rows are built from the invite's own words.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** behavioral and values; **EXP** your own work, probed for attribution; **JD** the role as posted; **CO** company knowledge; **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words, and only the parts you did.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (HR invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" – your CV | medium | [grounded] | none | Met on your material. Expect them to check it: have the license and its expiry date ready. Your material does not show the license document itself. |
| F2 | "two members of our fourth-grade team" (HR invite) | "Six years teaching third grade at a public elementary school in Joliet" – your CV | medium | [grounded] | transferability | Adjacent work, not fourth grade. Your words: "I've never taught fourth grade." Bridge only from the six years: "I taught third grade for six years." Answer slot: name one thing from third grade that carries into fourth-grade content, if one does; if you cannot name one, say so and say how you would learn the fourth-grade standards. |
| F3 | Fourth-grade team collaboration (HR invite, panel composition) | "I led our grade level's move to a new reading curriculum in 2024" – your CV | medium | [grounded] | transferability | Your material says you led a curriculum move for your grade level. It does not show team leadership, and you have told me you have never been a team lead. Keep the bridge at the move: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: what you did to bring colleagues along, in your own words; if the move was decided above you, say so. |
| F4 | "Families Are Partners: each teacher speaks with every family each term." (Orrinsford Mission and Beliefs, fetched) | "I write a weekly email to families" – your CV | medium | [grounded] | transferability | Written family contact is adjacent to the district's term conversations, not the same thing. Bridge from the quote at its own scope: "I write a weekly email to families." Answer slot: if you have held a family conversation, say how it went; if your contact has been email, say that and what you would add. |
| F5 | "Every Child a Reader: no student leaves third grade without a reading plan." (Orrinsford Mission and Beliefs, fetched) | "I've run the after-school reading club for the last two years" – your CV; "I led our grade level's move to a new reading curriculum in 2024" – your CV | medium | [grounded] | presentation | Your reading work reaches this belief in other terms. Reword only the quotes: reading club for two years; grade-level reading curriculum move in 2024. Do not add a reading plan you did not write. Answer slot: if you have built a reading plan for a child or a class, say what it contained; if not, say so and describe how you would start one. |
| F6 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." (Orrinsford Mission and Beliefs, fetched) | none given | none | [inferred] | discovery | Your material does not show how assessment shaped your teaching. Answer slot: if assessment results changed what you taught in the reading move, say what changed; if they did not, say so and say what you would check first. |
| F7 | Fourth-grade role as posted: "Fourth Grade Teacher position" (HR invite) | "I've never taught fourth grade." – your message | none | [grounded] | capability | Stated by you. Plain acknowledgment: "I've never taught fourth grade." Then how you would prepare, said as a plan, never as a past. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Team lead, or led the grade-level team | Inflated form of F3; your message says "I've never been a team lead" | F3's quote at its own scope. Plain acknowledgment: "I've never been a team lead." |
| Taught fourth grade | Stated negative (F7) | "I've never taught fourth grade." No slot. |
| Ran the reading curriculum across the school | Inflated form of F3 and F5; the material says your grade level | "I led our grade level's move to a new reading curriculum in 2024." |
| A reading plan you wrote for students | Not in your material (F5) | Answer slot only, as F5 gives it. |

## Persona weights

The invite names a principal and two fourth-grade teachers, so the panel blends a manager and two peers.

| Persona | Who | Likelihood | Why | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Principal | high | Fourth grade and team lead are your two stated gaps | Hold through two follow-ups; concede the gap plainly, then return to what you did |
| Case / Strategist | Principal | medium | Panels for a grade-level opening often include a lesson-planning or reading-data scenario | Clarify the grade's standards and students first, then state your first step |
| Peer Evaluator | Fourth-grade teachers | high | They will ask how you would work beside them and what you would take on | Name what you would bring to their team, not only what you need |
| Data-Driven Prober | Fourth-grade teachers | medium | Reading assessments are a common topic | Say what you tracked, what you did not, and which assumption you would check first |

Depth: the Skeptic and Peer Evaluator banks get the most questions.

## Question banks

### Skeptic (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You have never taught fourth grade. Why should we hire you for this grade?" | JD | [grounded] "I've never taught fourth grade." | Plain acknowledgment, then your transfer: "I taught third grade for six years." Name one piece of third-grade work that carries forward, from F2's slot. If you cannot name one, say how you would learn the standards before September. Hold through two follow-ups by returning to what you taught. | This is the single most likely objection and the highest-return rehearsal in this pack. F2 and F7 are the source. |
| S2 | "Have you ever led a team?" | EXP | [grounded] "I've never been a team lead." | Answer with the stated negative. Then: "I led our grade level's move to a new reading curriculum in 2024," at that scope. Do not add a title or a team you did not lead. | F3 is the evidence; the inflated form is on the prohibited list. |
| S3 | "Tell me about the reading curriculum move. How much of it was yours?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Walk through the move in your own words. Answer slot: which parts were yours to decide and which were decided above you; say which plainly. | F3's bridge; the attribution probe. |

### Peer Evaluator (fourth-grade team)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "What would you need from us in your first month?" | JD | none; the question is open and names no event | Ask for the team's unit calendar, shared assessments and planning routine. Then say what you would bring: reading club experience and family writing practice (F4, F5). | Reciprocity framing is the peer's native question. |
| P2 | "Our team plans together every week. How do you work with colleagues who teach it differently?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Map a story only from the curriculum move, at that scope. Answer slot: what disagreements came up and how you resolved them; if none came up, say so. | F3 is the only sentence about working with colleagues; do not invent a conflict. |
| P3 | "How do you know whether a reading intervention is working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Describe what the club measured, in those words. Answer slot: if you tracked results, name the measure and the assumption behind it; if you did not, say so and say what you would track first. | F5's club quote; defend-the-number applies only to figures you gave, and you gave none. |
| P4 | "How do you talk to families when a child is struggling?" | VAL | [grounded] "I write a weekly email to families" | Bridge from the weekly email. Answer slot: if you have had a family conversation about a child, say what you did; if not, say how you would open one. | F4; the district's term conversations are the raising source. |

## Values cheat sheet

Section 10 applies: the district publishes three beliefs, fetched from its own page.

| Value (official name) | Working meaning | Your story |
|---|---|---|
| Every Child a Reader | Every student has a reading plan by third grade | F5: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: what the plan contained. |
| Families Are Partners | Each teacher speaks with every family each term | F4: "I write a weekly email to families." Answer slot: a family conversation, if you have had one. |
| Teach for Tomorrow, Not for the Test | Assessments inform teaching and never replace it | F6: no quote. Selection scaffold: pick a time assessment changed your teaching; if none comes to mind, say so plainly, then give how you would check. |

## Reverse questions

Each one lands for a reason:

1. "What does a strong first year look like on this fourth-grade team?" Lands because it shows you are planning, not only interviewing.
2. "Which reading program or assessment does the fourth grade use this year?" Lands because it lets you speak to their actual tools.
3. "What could a new person do in their first month that would genuinely help your team?" Lands as the peer reciprocity question.
4. "How does the team share planning time across grade levels?" Lands because it shows you understand a team is a schedule.
5. "What would make you say in June that this hire worked?" Lands because it asks the principal to name the bar.

## Sources

- Provided: the HR invite, your résumé and your message.
- Search: "Orrinsford Community School District Halvering Elementary" returned no results.
- Search: "Orrinsford Community School District values mission" returned one page.
- Fetch: https://orrinsfordschools.example/about/mission-and-beliefs (three beliefs, quoted above).

Research tier: L1, searches 2 of 6, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | Values cheat sheet; F5 and F6 |
| 2. Interview process for fourth-grade teacher | skipped | The invite fixes the format: a 45-minute panel with a principal and two team members |
| 3. Recent strategy or news | skipped | Not sent; the district page covers the beliefs the pack needs |
| 4. Panel member names | n/a | Team members are not named, and the principal's footprint was not searched |
| 5. Representative JD | skipped | No JD supplied; JD rows use the invite's own words |

## Upgrade menu

- The job posting → JD-tagged questions and a full requirement-coverage table
- The panel's stated focus, or any lesson or demo requirement → a build section for that deliverable
- The team members' names → persona weights for each member
- A tuesday-dossier.md from an earlier job-underwriter run → verified evidence in place of quotes you have not checked
