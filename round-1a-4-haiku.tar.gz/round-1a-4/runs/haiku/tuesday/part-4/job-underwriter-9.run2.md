**Yes, that's normal. Asking for bank details, a PPS number and passport ID after a written offer is routine onboarding, not a warning sign. The one thing to check is that you enter those details only in the portal at the address on Marrowgate's own website.** Decision: `conditional_go`, with the conditions below.

- **Hard gates:** candidate constraints not given (you didn't mention your home location or notice terms), so checks against them are unknown. The posting's Limerick hybrid pattern is the one to test against where you live.
- **Severe red flags:** none found. The bank, PPS and passport requests come after a credible written offer that names the role and the pay, so they are routine and get no register entry.
- **Opportunity ledger:** the offer names the role, salary, reporting line and start process, and the in-person interviews at their office are your own evidence that the employer is real. Company and salary checks did not run (see research below), so the employer is not independently verified.
- **What would change this:** the conditions below, or any sign the portal address or sender doesn't match Marrowgate's own website.

**Conditions for applying (accepting):**
1. Before you enter anything, check that people@marrowgatehousing.ie and the portal link match the domain and contact details on Marrowgate's own website. Use the website's contact details, not the email, if they differ.
2. Ask what the passport scan is used for and where it is stored. Keep the original for the day-one check rather than sending a copy if you can.
3. Confirm the offer in writing: permanent, notice period, start date, pension terms.

**Fit (fit ledger, from what you gave):**
- Direct: 2+ years payroll (3 years, 90 staff); starters and leavers; monthly payroll-to-ledger reconciliation; Excel (pivot tables, XLOOKUP); payroll qualification (Payroll Technician certificate, 2024).
- Adjacent: Irish PAYE, PRSI and USC, through hotel-group fortnightly payroll. Confidence is `medium` because you describe it but nothing shows the rules were applied to Irish law specifically.
- Gap: pension changes (you've never done them yourself). This is an `important` requirement, not a hard gate. Raise it in the interview and ask how the scheme is administered.
- Salary: €40,000 is inside the advertised €38,000–€42,000 band. I could not check it against the market.

**Research tier: L1 — searches 2 of 5, fetches 0 of 2**; the two searches were refused by permission, so no pages were read.

| Target | Status | Reason |
|---|---|---|
| 1. Company's official site and careers page | unavailable | Search refused by permission; could not confirm Marrowgate exists or that the posting is live |
| 2. Role-family sweep (payroll administrator pay, Limerick) | unavailable | Search refused by permission; the €38k–€42k band is not checked |
| 3. Hiring manager's public footprint (Declan Garvagh) | unavailable | Search refused by permission; not attempted in the required form |

Enabling web search for this session would move targets 1 and 2 first: it would confirm the company and its careers page, and place the salary against market norms.

**Risk register (standing entry):**
- Signal: employer not established from attributable sources. Class: `risk_signal`, severity `medium`, status `unresolved`. This is because research could not run, not because the employer looks suspicious. Your in-person interviews at their office are real evidence; the remaining check is their own careers page. Question for the employer: "Can you point me to this role on your careers site, and who would I report to day to day?"

**Application plan:** do the three conditions above before replying. Prepare a pension-changes answer for the interview: what you have seen done, how you'd learn the scheme, and what you'd check first.

**Dossier offer:** I can write a `tuesday-dossier.md` with this assessment so you can keep it with the offer.

**Upgrade menu:**
- Your home location and notice period: confirms or clears the hybrid and location gate.
- The live posting link or Marrowgate's careers page: confirms the employer and role.
- Web search enabled: checks the company's existence and the salary band.
- Details of the pension scheme (provider, employee changes handled per year): sizes the pension gap.

**Questions:**
1. Where do you live, and how far is the Limerick office from there?
2. Does the offer's sender address match the domain on Marrowgate's own website?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.