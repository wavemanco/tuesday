**Yes, that request is routine.** After a written offer that names the role, the pay and the manager, asking for bank details, a PPS number and a passport check for right-to-work is standard onboarding. The thing to watch is where you enter them. Use only the portal at the address on Marrowgate's own website, not a link you were sent separately. Full answer and the one open check are in the rest of this report. Status: `conditional_go`.

## Decision snapshot

**Worth accepting, on one condition: the offer's pay, days and start date must fit your own limits. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (right to work in Ireland), R2 (hybrid, two days in Limerick), R3 (€40,000 salary)
- `must_have`: direct: R4 (2+ years running payroll), R8 (starters, leavers, payroll-to-ledger reconciliation) · adjacent: R9 (pension changes) · unclear: R5 (Irish PAYE, PRSI and USC)
- `important`: direct: R6 (strong Excel), R7 (payroll qualification) · unclear: R10 (answering staff payroll queries)

R9 (`adjacent`, `low`) carries the one honest gap: you ran the payroll side of starters and leavers, but you have not done pension changes yourself. R5 is unclaimed rather than missing. Nothing in what you've shared settles it either way.

**Opportunity ledger.** The offer is specific and consistent with the ad: the role, reporting line, Limerick days and salary band all match (RR2, RR4). Two things are still open: whether this post is on Marrowgate's own careers page, which I could not check (RR1), and who administers the pension scheme (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (right to work in Ireland), R2 (hybrid, two days in Limerick), R3 (€40,000 salary); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the offer's €40,000, two Limerick days and start date fit your own limits (R1–R3); (2) your answer on pension changes (R9, RR3) turns out adequate, or Marrowgate confirms what the role covers.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, 240 staff | `[grounded]` job ad |
| Mandate | Monthly payroll, starters, leavers, pension changes, ledger reconciliation, staff queries | `[grounded]` job ad |
| Working pattern | Hybrid, two days a week in the Limerick office | `[grounded]` job ad and offer |
| Pay | €38,000–€42,000 advertised; €40,000 offered | `[grounded]` job ad and offer |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer |
| Market calibration | Not run: the role-family search was refused (see Evidence status) | — |
| Unknowns | Pension scheme and administrator; how PAYE/PRSI/USC work is handled in-house; team size in payroll | — |
| Contradictions | None between the ad and the offer | `[grounded]` both documents |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Right to work in Ireland (offer requires a check) | hard_gate | unclear | none | hard_gate | Your status is not in what you've shared; the offer's check is routine | `[grounded]` offer | Confirm your status against the check |
| R2 | Hybrid, two days a week in Limerick | hard_gate | unclear | none | hard_gate | Role terms state it; your limit is not given | `[grounded]` job ad | Check against your limit (Question 1) |
| R3 | €40,000 salary | hard_gate | unclear | none | hard_gate | Offer is inside the advertised band; your floor is not given | `[grounded]` job ad and offer | Check against your floor (Question 1) |
| R4 | 2+ years running payroll | must_have | direct | medium | none | Three years fortnightly for 90 staff; self-reported, not yet probed | `[grounded]` your intake | Bring a payroll schedule or reconciliation, names removed |
| R5 | Working knowledge of PAYE, PRSI and USC | must_have | unclear | low | discovery | Not in your background; the hotel payroll may have used these, unconfirmed | `[grounded]` absence in your intake | Question 3 |
| R8 | Starters, leavers, payroll-to-ledger reconciliation | must_have | direct | medium | none | You ran both monthly; self-reported | `[grounded]` your intake | Bring a reconciliation sample, names removed |
| R9 | Pension changes | must_have | adjacent | low | transferability | Starters and leavers touch the same payroll; you have not done pension changes | `[grounded]` your intake; `[inferred]` adjacency from starters and leavers | Question 2; ask Marrowgate what the role covers |
| R6 | Strong Excel | important | direct | medium | none | Daily use, pivot tables, XLOOKUP; self-reported | `[grounded]` your intake | Bring a workbook sample |
| R7 | Payroll qualification or working towards one | important | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your intake | Keep a copy of the certificate ready |
| R10 | Answering staff payroll queries | important | unclear | low | discovery | Not in your intake | `[grounded]` absence | Ask about it in your own terms before you accept |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R9, must_have) | transferability | Starters, leavers and reconciliations; no pension changes | A must-have, and the one adjacent row | Any time you checked a deduction, enrolment or opt-out, even on a checklist | The scheme's change process, or a sanitized checklist | `[inferred]` bridge from starters and leavers |
| G2 | PAYE, PRSI, USC (R5, must_have) | discovery | Not mentioned | Irish statutory deductions are the core of the role | Any calculation or check of these, in any job | A payslip or deduction report, names removed | `[grounded]` absence |
| G3 | Staff payroll queries (R10, important) | discovery | Not mentioned | Day-to-day part of the role | Answering colleagues' pay questions, however informal | Any query log or FAQ you wrote | `[grounded]` absence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not checked from here | unknown | — | "Marrowgate Housing, a housing association in Limerick" | The post may be on Marrowgate's careers page; I could not confirm it | `[inferred]` from the refused checks | Is this post on your own careers page, and who would I be interviewing with? | unresolved |
| RR2 | Two in-person interviews; offer names manager, hours and start terms | positive_signal | — | "reporting to Declan Garvagh, Finance Manager" | The offer follows interviews you can place, which is what a real hiring process looks like | `[grounded]` your intake and offer | — | noted |
| RR3 | Pension scheme administrator not named | unknown | — | "pension changes" | The pension duty may sit with a scheme administrator, not in-house | `[inferred]` from the ad's silence on the scheme | Which pension scheme and administrator do the changes go through, and what would my first three months of that duty involve? | unresolved |
| RR4 | Offer inside advertised band | positive_signal | — | "€40,000 a year" | The figure sits in the ad's €38,000–€42,000 range | `[grounded]` job ad and offer | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before accepting, compare the offer's pay, Limerick days and start date with your own limits | Your limits were not given, so R1–R3 stay unconfirmed | `[grounded]` R1–R3 | pending your approval |
| A2 | Check that the offer's sender domain matches the one on Marrowgate's own website, and that the post is on its careers page | Advice: this is the one check I could not run | `[generic]` standard practice | pending your approval |
| A3 | Enter bank, PPS and passport-check details only in the portal at the address Marrowgate's own website gives; bring the original passport on day one | The offer names these steps; the portal route is where the check belongs | `[grounded]` offer; `[generic]` practice | pending your approval |
| A4 | Ask the People Team which pension scheme and administrator the role uses, before you accept | RR3 and R9 | `[grounded]` RR3 | pending your approval |
| A5 | Write your PAYE, PRSI and USC answer using only what you have actually done | R5 | `[grounded]` R5 row | pending your approval |

## Evidence status

Verified: none yet. Your background is your own account, and no claim has been checked against an artifact.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches were refused by the host's permission check. This would have settled whether the employer exists as described and whether the post is live (RR1). Check it by hand: Marrowgate's own website |
| 2. Role-family sweep | unavailable | Would have calibrated €40,000 against Limerick payroll roles. Not run, so no market band is stated |
| 3. Hiring manager's public footprint | unavailable | A name was given (Declan Garvagh). Would have checked his public professional footprint only |

## Upgrade menu

- Permission to run the web searches → targets 1–3 run, which settles RR1 and gives a market band for R3.
- Your own pay floor, Limerick days and start-date limits → R1–R3 move from `unclear` to `direct` or `hard_gate_fail`.
- A copy of the Payroll Technician certificate → R7 supported by a document.
- A sanitized payroll schedule or reconciliation, names removed → R4, R6 and R8 move to `high` confidence.
- Any pension deduction or enrolment work, even a checklist → R9 moves up from `adjacent`.

I can write this up as `tuesday-dossier.md`, with the full report and envelope, if you want to keep it.

1. **R1–R3:** Do the €40,000 salary, two days a week in Limerick and your right to work in Ireland all fit your situation, and can you start on the date you'd agree?
2. **R9:** Have you ever checked, entered or reviewed a pension contribution or enrolment change, even on a checklist or as a second check? If not, what do you know about how contributions run through a payroll?
3. **R5:** Have you calculated or checked PAYE, PRSI and USC deductions yourself, and with which tool?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.