**No. Don't send anything, don't pay, and don't deposit the cheque. Status: `no_go`.** The messages ask for money and bank details before any offer, and the rest of the process only runs in chat. I can't establish the firm from here, but these requests are very likely a scam whoever sent them.

**Fit ledger.** Your fit is reasonable. The problem is the opportunity, not your experience.

- `hard_gate`: unconfirmed: pay floor (€30,000 a year against "up to €26 an hour" at 15–30 hours a week, which works out to roughly €20k–€40k before tax and without commission)
- `must_have`: direct: R2 (attention to detail, Zendesk volume and the team tracker), R3 (spreadsheets, your team's Excel tracker); unclear: R4 (good written English, nothing in what you've shared settles it)
- `important`: adjacent: R5 (order processing, from parcel-courier work); unclear: R6 (a quiet place to work, which you'd know, not me)

R2 and R3 are `medium` because you've stated them and nothing inspectable is attached yet.

**Opportunity ledger.** Four confirmed severe red flags (RR1–RR4) carry the decision. The posting's own text makes the hiring-by-chat signal: "Our whole hiring process runs on Telegram, so there are no calls or video interviews." The employer can't be verified from what you've shared (RR5).

- **Hard gates:** unconfirmed: pay floor (see above); candidate constraints given: yes; no gate failed on the posting's own terms.
- **Severe red flags:** RR1, RR2, RR3, RR4 (`severity: high`)
- **What would change this:** nothing in these messages. A role you can verify on the employer's own site, with no payment or bank or ID request before a written offer, would be a different case.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics, as named in the posting; not verified | `[grounded]` posting; unverified |
| Pay | "Up to €26 an hour plus commission", 15–30 hours a week | `[grounded]` posting |
| Process | Entirely on Telegram; no calls or video | `[grounded]` posting and messages |
| Equipment | Asked to pay €349 for a laptop and headset kit | `[grounded]` message |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay for equipment before any start | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | This request is very likely a scam. Don't pay it. | `[inferred]` from the message's wording | "Does your company ask new hires to pay for equipment, and do you have a payment arrangement with an equipment partner?" (asked through contact details on your own site, not the chat) | confirmed |
| RR2 | Cheque deposit and forwarding money | red_flag | high | "we are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner" | This request is very likely a scam. Don't deposit the cheque or send any money. | `[inferred]` from the message's wording | "Do you send cheques to new hires to deposit and forward money elsewhere?" (same route as RR1) | confirmed |
| RR3 | Bank, PPS and passport before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport" | This request is very likely a scam. Don't send these details in chat. | `[inferred]` from the message's wording | "Do you collect bank, PPS or passport details before a written offer?" (same route as RR1) | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | The interviews and the offer happen only in chat, which doesn't match a usual hiring process. | `[inferred]` from the posting and messages | "Where can I see a live posting, and who would I interview with, on your careers page?" | confirmed |
| RR5 | Employer not established | risk_signal | medium | "Velloway Logistics" | The employer may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. The contact email given is not the employer's own domain. | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at the role on your own careers site?" | unresolved |

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send no IBAN, PPS number or passport photo, and pay nothing | RR1–RR3 | `[inferred]` from the messages | advice |
| A2 | If you find a real posting on the employer's own site, check it there with contact details from that site, not the chat | RR1–RR5 | `[generic]` how verification usually works | advice |
| A3 | Report these messages to the jobs site where you found the posting, and keep screenshots | the posting is still live | `[generic]` standard practice | advice |
| A4 | If you've already shared any of those details, contact your bank now | a precaution only; you say you haven't sent anything | `[generic]` standard practice | advice |
| A5 | Put your effort into other openings from employers you can verify on their own sites | your background fits roles like this, with a verifiable employer | `[grounded]` your background | advice |

**Evidence status.** Verified: none yet. Your background (customer service, Zendesk, team tracker) is what you've told me, so it's self-reported. It's a fair basis for applying elsewhere, not proof.

Research tier: L1 — searches 0 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | The decision is `no_go` on the messages alone. A check of the employer's own site would move only RR5, which caps a `go` and cannot lift the decision. |
| 2. Role-family sweep | skipped | Your pay floor is your own figure, so a market band wouldn't change the call. |
| 3. Hiring manager's public footprint | n/a | No name was given, only a handle. |

Dossier offer: I can write this up as `tuesday-dossier.md` if you want a file to keep.

Upgrade menu:
- A link to the live posting on Velloway's own careers page → would move RR5 (employer established or not). It does not reverse `no_go`.
- A written offer from an address on the employer's own domain, with no payment or bank requests before it → would address RR1–RR4 only if the employer confirms these requests were not theirs.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.