**Yes, with conditions. Status: `conditional_go`.** Your CV meets both hard gates and the Essential list on paper. The open questions are whether you'll be trusted to run a caseload on your own and whether you have any end-of-life experience. Those can only be answered in conversation.

- **Fit ledger.**
  - `hard_gate`: direct: R1, R2
  - `must_have`: direct: R3 · unclear: R4
  - `important`: direct: R6a, R7 · adjacent: R5, R8, R10 · unclear: R6b, R9
  - `preferred`: absent: R11

  R5 — leg-ulcer care, the nearest bridge is pressure and surgical wounds, with leg ulcers not on the CV; R10 — caseload ownership, bridged by discharge-to-assess visits, limit: you have not held a caseload; R9 — end-of-life visits, nothing on the CV.
- **Opportunity ledger.** Sound, with unknowns to close: the employer is established by its own site (RR5), and the posted pay sits within the role-family band (RR3). Still open: caseload support and autonomy (RR1), end-of-life support (RR2), and whether the post is still live (RR4).
- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm your NMC register entry and driving licence status yourself before applying; (2) the caseload and end-of-life answers hold up in the informal chat; (3) the post is confirmed open.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health: a CIC founded 2015, 410 staff, adult community nursing under an NHS contract across Calderdale | `[grounded]` company site, fetched |
| Role | Band 5 community staff nurse, district nursing for housebound adults, a small own caseload supported by a senior community nurse | `[grounded]` JD |
| Pay | £31,050–£37,800 a year plus mileage; pool cars provided | `[grounded]` JD |
| Market calibration | Wardround 2026 (n=1,240), community staff nurse Band 5 in England: median £34,300, interquartile range £32,400–£36,600. The posted range sits around that band. | `[generic]` role-family sweep, this month |
| Unknowns | Caseload size and how much of each plan you own; end-of-life support; contract basis, hours, mileage rate; whether the post is still open | — |
| Contradictions | None between the JD and the company's own description | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | CV states active Adult registration, revalidation March 2028. Stated, not checked. | `[grounded]` CV | You check your NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states full licence, category B. Stated, not checked. | `[grounded]` CV | You check your licence status |
| R3 | One year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse, acute medical ward. CV only. | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | CV is silent on record quality or EPR use | `[grounded]` CV silence | Ask for an example of your documentation practice (G3) |
| R5 | Wound and leg-ulcer care | important | adjacent | medium | transferability | Pressure ulcers and surgical wounds are on the CV. Leg ulcers are not named. Limit: no Doppler, no leg-ulcer work stated. | `[grounded]` CV; `[inferred]` adjacency | Name any leg-ulcer work you've done |
| R6a | Catheter care | important | direct | medium | none | Catheter care on the CV | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | low | discovery | Not on the CV | `[grounded]` CV silence | Ask whether you've done continence assessment or management |
| R7 | Insulin administration | important | direct | medium | none | Insulin administration on the CV | `[grounded]` CV | none |
| R8 | Care planning for housebound adults | important | adjacent | medium | transferability | Discharge-to-assess visits involve planning at home. Limit: not a standing care plan over time. | `[inferred]` from the discharge role | Use the discharge work to show planning |
| R9 | End-of-life visits | important | unclear | low | discovery | Nothing on the CV | `[grounded]` CV silence | Ask (G2) |
| R10 | Holding your own caseload | important | adjacent | medium | transferability | Never held a caseload. Discharge-to-assess visits were self-directed, first-week home visits. Limit: no ongoing caseload responsibility. | `[inferred]` from the discharge role | Ask (G1) |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No evidence on the CV | `[grounded]` CV | Ask the employer about training (see the application plan) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload (R10) | transferability | Discharge-to-assess visits, self-directed, first week after discharge; no ongoing caseload | The role is built around a caseload. The bridge is strong but has a visible limit. | Planning a patient's next steps on your own judgement; deciding when to escalate to the senior nurse | A sanitised visit note or discharge plan, if your trust permits | `[inferred]` bridge from the discharge role |
| G2 | End-of-life visits (R9) | discovery | Nothing on the CV | Listed as a duty, so it will come up in interview | Last-offices or end-of-life care on the ward; family support at home; pain or symptom management | Any end-of-life training certificate | `[grounded]` CV silence |
| G3 | Written records (R4) | discovery | CV is silent | Listed as Essential | Documentation on the ward and in discharge work | An anonymised example of your documentation | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload support unclear | unknown | — | "supported by a senior community nurse" | Autonomy and caseload size may vary, and day-one support is not described | `[inferred]` from the JD's silence on caseload size | How many patients would I hold on day one, and how much of each plan would I own myself? | unresolved |
| RR2 | End-of-life visits without stated support | unknown | — | "end-of-life visits" | Training and supervision for end-of-life work are not described | `[inferred]` from the JD's silence | What training or supervision do community nurses get for end-of-life visits? | unresolved |
| RR3 | Pay and mileage stated | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Transparent pay, within the Band 5 range | `[grounded]` JD; calibration `[generic]` | Which pay point does a Band 5 start on, and how is mileage calculated? | noted |
| RR4 | Posting not confirmed live | unknown | — | "for an informal chat… contact Rhiannon Mabbott" | The careers page was not located, so the post's status is unverified | `[grounded]` | Is this post still open, and what is the vacancy reference? | unresolved |
| RR5 | Named contact with a public footprint | positive_signal | — | "Rhiannon Mabbott, Community Nursing Team Lead" | The contact leads the Halifax district nursing team | `[grounded]` forum speaker page | none needed (the contact is the verifier) | noted |

Standing entry: not triggered. Research attributed the employer to its own site, so employer-not-established does not apply.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your NMC register entry and driving licence status before you apply | R1, R2 are stated, not checked | `[grounded]` gate rows | proposed (your action) |
| A2 | Find the company's careers page and confirm the post is open; note the vacancy reference | RR4 | `[grounded]` RR4 | proposed (your action) |
| A3 | Position on discharge-to-assess home visits, catheter and insulin work, and self-directed planning. Don't claim caseload or leg-ulcer experience. | R6a, R7, R8, R10 | `[grounded]` CV | pending your approval |
| A4 | At the informal chat, ask about Doppler training and end-of-life supervision | RR2, R11. Rhiannon Mabbott spoke at a 2025 forum on Doppler training for staff new to community work. That shows the subject, not what this employer provides. | `[grounded]` forum page; `[inferred]` that this is a route to Doppler | pending your approval |

## Evidence status

Verified: none yet. Every claim above is your CV, which is self-report.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read none

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). The company exists, runs adult community nursing under an NHS contract, and says vacancies are on its careers page. The careers page was not located, so the post's status is unconfirmed (RR4). |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 pay scale 2026/27 England", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Calibrates the pay band `[generic]`. |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Halifax", which returned "Rhiannon Mabbott — Community Nursing Team Lead" (communitynursingforum.example/speakers/rhiannon-mabbott). Informs the application plan (A4). |

## Upgrade menu

- Your own NMC register check, or a licence status confirmation you've done yourself → R1 and R2 move from stated to checked.
- An anonymised discharge-to-assess visit note or care plan, if your trust's policy allows → R8 and R10 to `high`.
- Any leg-ulcer dressing or compression experience → R5 to direct.
- Any end-of-life or palliative training certificate → R9 to direct.
- A deeper research pass on Calderbrook (leadership, staffing, past recruitment; up to 5 more searches and 2 more fetches). Say the word and it runs.
- I can also save this assessment as a `tuesday-dossier.md` so later modules can read it.

Questions:

G1 — In discharge-to-assess, did you decide each patient's next steps yourself, or with a senior nurse on the visit? What did you decide alone?
G2 — Have you cared for anyone at the end of life, at home or on the ward? What did you do, and what support did you have?
Constraints — What's your pay floor, and would you walk away over mileage or travel time?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.