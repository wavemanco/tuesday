**Yes, worth applying for, on conditions. Status: `conditional_go`.** Apply once the posting is confirmed open and two terms are clear: the caseload model and the mileage arrangements.

**Fit ledger.**

- `hard_gate`: direct: R1, R2, R3
- `must_have`: direct: R4, R7a, R8a, R9 · adjacent: R5, R6 · unclear: R7b, R8b, R10
- `important`: unclear: R11
- `preferred`: absent: R12

R5 (caseload and care planning) is bridged by discharge planning, not held. R6 (housebound home visits) is covered only at discharge stage. R7b (leg-ulcer care), R8b (continence care) and R10 (end-of-life visits) aren't in the CV, so they are open questions, not gaps you've confirmed. R11 (electronic records) is unstated. R12 (Doppler) is absent.

**Opportunity ledger.** The employer checks out: an NHS-contracted CIC with 410 staff, and a named team lead who speaks publicly on the leg-ulcer work this role involves (RR1 is positive). Two items are open: the posting's live status (RR2) and how mileage works with pool cars (RR3).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); R1 and R2 are your stated status, not checked. Candidate constraints not given (no pay floor or schedule stated), so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed open (RR2); (2) the caseload and senior-support model is confirmed in the chat (R5, RR1); (3) mileage and pool-car terms are stated (RR3).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing across Calderdale under an NHS contract; founded 2015; 410 staff; four locality hubs | `[grounded]` calderbrookhealth.example/about, fetched |
| Mandate | Small own caseload of housebound adults at home, supported by a senior community nurse | `[grounded]` JD |
| Contact | Rhiannon Mabbott leads the Halifax district nursing team | `[grounded]` communitynursingforum.example speaker page |
| Pay | £31,050–£37,800 plus mileage; the band is stated | `[grounded]` JD |
| Market calibration | Wardround 2026 survey, Band 5 community staff nurse, England, n=1,240: median £34,300, middle half £32,400–£36,600; 61% paid mileage; 24% had a pool or lease car. The advert's band brackets that middle half | `[generic]` role-family survey, not this employer's offer |
| Unknowns | Caseload size; senior support day to day; out-of-hours; mileage with pool cars; end-of-life volume; posting status | — |
| Contradictions | None found between the JD and the About page. The careers page was not located | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | Stated on CV, registration active; not checked by anyone else | `[grounded]` CV | Check your own NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated on CV, category B; not checked | `[grounded]` CV | Check your licence record |
| R3 | Work in Halifax | hard_gate | direct | medium | none | You live in Halifax; the role is in Halifax | `[grounded]` JD, CV | none |
| R4 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as staff nurse; a length requirement, so graded, not a gate | `[grounded]` CV | none |
| R5 | Own caseload, care planning | must_have | adjacent | medium | transferability | Discharge planning in the discharge-to-assess role; no caseload ever held | `[inferred]` from the discharge role | Question G1 |
| R6 | Care of housebound adults in their own homes | must_have | adjacent | medium | transferability | Home visits in the first week after discharge; not long-term caseload work | `[grounded]` CV | Lead with these visits (A5) |
| R7a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds on CV | `[grounded]` CV | none |
| R7b | Leg-ulcer care | must_have | unclear | low | discovery | Wound care is on CV; leg ulcers are not named | `[grounded]` CV silence | Question G3 |
| R8a | Catheter care | must_have | direct | medium | none | On CV | `[grounded]` CV | none |
| R8b | Continence care | must_have | unclear | low | discovery | Not on CV | `[grounded]` CV silence | Upgrade menu |
| R9 | Insulin administration | must_have | direct | medium | none | On CV | `[grounded]` CV | none |
| R10 | End-of-life visits | must_have | unclear | low | discovery | Not on CV; acute ward work may include it | `[grounded]` CV silence | Question G2 |
| R11 | Electronic patient record; clear, timely written records | important | unclear | low | discovery | Records are assumed in acute work; the EPR system is unstated | `[grounded]` CV silence | Upgrade menu |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No evidence on CV | `[grounded]` CV | Closure path: A4 |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Caseload and care planning (R5, must_have) | transferability | Discharge planning, no caseload held | The advert's core role; a stronger bridge narrows it | Care plans you set or reviewed for patients you saw; decisions you owned with a senior's sign-off | A redacted care plan or discharge summary | `[inferred]` bridge from discharge work; `[generic]` that caseload is the likeliest objection |
| G2 | End-of-life visits (R10, must_have) | discovery | Not on CV | Must-have, so it can move the decision | Anticipatory care, last-days planning, family conversations on the ward or at discharge | A care-plan example | `[grounded]` CV silence |
| G3 | Leg-ulcer care (R7b, must_have) | discovery | Wound care on CV; leg ulcers not named | Must-have; the advert names it | Dressing, compression, or venous ulcer assessment | Wound-care protocol, or a redacted example | `[grounded]` CV silence |
| G4 | Continence care (R8b, must_have) | discovery | Not on CV | Must-have | Catheter-adjacent continence work, bladder or bowel assessment | Protocol or record sample | `[grounded]` CV silence |
| G5 | Electronic records (R11, important) | discovery | EPR not named | Important, and the advert says it's central | Any EPR you used on the ward | Redacted note or record sample | `[grounded]` CV silence |
| G6 | Doppler (R12, preferred) | capability | No evidence | Preferred; a closure path exists | Any ABPI or vascular training | Course certificate, or none | `[grounded]` CV |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload comes with senior support | positive_signal | — | "supported by a senior community nurse" | Written-in support lowers the risk of taking on a first caseload | `[inferred]` from the JD's own wording | What does senior support look like day to day, and how are caseloads sized? | noted |
| RR2 | Posting status not confirmed | unknown | — | "Current vacancies are listed on our careers page" | The careers page was not located, so the post's open status is unverified | `[grounded]` About page; careers URL returned no page | Is this post open now, and who would I be interviewing with? | unresolved |
| RR3 | Mileage with pool cars | unknown | — | "plus mileage"; "pool cars are provided" | How mileage applies when a pool car is used is not stated | `[grounded]` JD | When would I use a pool car, and what mileage is paid on my own car? | unresolved |

No standing failed-attribution entry: the employer is attributed.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your NMC register entry and driving licence yourself before applying | R1, R2 are stated, not checked | `[grounded]` gate rows | your action |
| A2 | Confirm the post is open on the careers page, or ask in A3 | RR2 | `[grounded]` About page | your action |
| A3 | Ask Rhiannon Mabbott for the informal chat the advert invites; put RR1–RR3 to her in your own words | Named contact in the JD | `[grounded]` JD | outreach text, pending your approval |
| A4 | Ask in that chat whether Doppler training is given in post | R12 closure path | `[inferred]` from her 2025 talk on Doppler training for staff new to community work; not a claim about what the employer offers | pending your approval |
| A5 | Positioning: lead with the home visits and the wound, catheter and insulin work; say plainly you haven't held a caseload or done Doppler | R5, R6, R12 | `[grounded]` CV | positioning advice, pending your approval |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned calderbrookhealth.example/about, fetched: NHS-contracted CIC, Calderdale, founded 2015, 410 staff. Searched "Calderbrook Community Health CIC careers Community Staff Nurse Band 5"; fetched calderbrookhealth.example/careers, which returned no page. Moved: employer established, so no standing entry; posting status unconfirmed (RR2) |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse salary 2026 NHS pay scale district nursing", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: market calibration `[generic]`; the advert's band brackets the survey's middle half |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned a forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: scope read; leads the Halifax district nursing team, 11 years as a district nurse; 2025 talk on leg-ulcer clinics and Doppler training. Feeds A3 and A4 |

**Upgrade menu**

- A redacted care plan or discharge summary you wrote → G1 and R5 move toward `high`
- A redacted record sample → R11 moves toward `medium`
- Your own NMC register and driving-licence checks, reported back → R1 and R2 move from stated to checked
- Confirmation the post is open → RR2 closes
- Your pay floor and schedule constraints → hard-gate checks against them become possible
- An example of end-of-life or continence care → R10 and R8b move off `unclear`
- Deeper research on the employer (leadership, past recruitment, reports; up to 5 more searches and 2 more fetches) → say the word and it runs

If you want, I can save this as a `tuesday-dossier.md` that other job-search modules can read.

**Questions**

G1 — In discharge-to-assess, did you set or review the care plan for the patients you saw, or hand it on? What did you decide, and who signed it off?

G2 — Have you been involved in end-of-life or anticipatory care, on the ward or at discharge? What did you do, and who was involved?

G3 — Which leg-ulcer dressings or compression regimens have you applied or supervised, and how did you assess the leg first?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.