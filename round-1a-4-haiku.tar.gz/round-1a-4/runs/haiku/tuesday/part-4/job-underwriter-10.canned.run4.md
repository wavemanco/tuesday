**Yes, take the call. Fernquay checks out on its own pages, and the WhatsApp message is a normal scheduling step, not a warning sign.** Status: `conditional_go`.

**Fit ledger**
- `hard_gate`: direct: R1 · unclear: R2 (Pay €52,000–€60,000 against your floor)
- `must_have`: direct: R3, R4, R5, R6
- `important`: adjacent: R7 (Own the booking flow end to end) · unclear: R8 (Working as the only designer)
- `preferred`: adjacent: R9 (Research with school owners)

R7 is a bridge with its limit named: the checkout redesign is real, but it isn't the whole booking flow. R8 has no evidence either way. R2 is a hard gate waiting on your pay floor.

**Opportunity ledger.** The employer is established on its own careers and about pages, so the existence check is clear (RR4, positive). Two items are open: the equity terms are unstated (RR1, unknown), and a first-designer role may have no design critique (RR2, medium).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000 against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) €52,000 meets your floor (R2); (2) equity terms are stated in writing (RR1); (3) the solo-design question has a concrete answer (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: founded 2023, six people in Galway, makes Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland, funded by its customers | `[grounded]` fernquay.example/about |
| Mandate | First designer: own the booking flow, run research with school owners, ship with two engineers | `[grounded]` posting, matches careers page |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` posting and careers page |
| Compensation | €52,000–€60,000 plus 0.5–1% equity, no vesting or strike terms given | `[grounded]` posting |
| Market calibration | Irish product designers with 3–5 years: median €57,000, interquartile range €51,500–€62,000. Your posting's range sits inside that band. | `[generic]` Tillerby 2026 Ireland salary report (n=520, Ireland-wide, not Galway-specific) |
| Scope read | A solo design role at a six-person company. Ownership of the booking flow is stated; success measures are not. | `[inferred]` from "first designer" against a six-person team |
| Unknowns | Equity terms, pay floor fit, what research budget and time you'd get, what success looks like in year one | — |
| Contradictions | None material. The about page adds sailing schools and Scotland, which widens the posting's scope without conflicting with it. Saoirse Doyle is named as a co-founder; the CTO title in Ronan's message isn't on either page. | `[grounded]` both pages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year; stated, not inspectable | `[grounded]` your statement | none |
| R2 | Pay €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | Your floor was not given, so the gate is not established | `[grounded]` posting | G3 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company | `[grounded]` your intake | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your intake | none |
| R5 | Runs own user research | must_have | direct | medium | none | Monthly usability sessions with customers | `[grounded]` your intake | none |
| R6 | Works directly with engineers | must_have | direct | medium | none | Four years in a squad with four engineers | `[grounded]` your intake | none |
| R7 | Owns the booking flow end to end | important | adjacent | medium | transferability | You redesigned checkout, one part of a booking flow; end-to-end ownership is untested | `[inferred]` from your checkout work | G1 |
| R8 | Works as the only designer | important | unclear | medium | discovery | You've never been the only designer; no evidence either way about working without peers | `[grounded]` your statement | G2 |
| R9 | Research with school owners | preferred | adjacent | medium | transferability | Customer research transfers from travel booking; school owners are a different customer | `[inferred]` from your intake | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-to-end booking ownership (R7, important) | transferability | Checkout redesign in a squad; nothing beyond it | Interviewers will test whether you owned more than checkout | Any part of a purchase or booking flow you chose the direction for, from research to release | The checkout case study Ronan liked | `[grounded]` intake; `[generic]` that interviewers probe this |
| G2 | Working alone as design (R8, important) | discovery | No solo-design evidence | Decides whether RR2 is real for you | Any stretch without a design peer; any critique you got from engineers or product | A short note on how you handled critique | `[grounded]` intake |
| G3 | Pay floor (R2, hard_gate) | hard_gate | The gate is unknown | Decides whether this is a go | — | — | `[grounded]` posting |
| G4 | School-owner research (R9, preferred) | transferability | Travel-booking customer research | Minor; the bridge is real but limited | Any research with small business owners | — | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity terms unstated | unknown | — | "0.5–1% equity" | The equity may carry vesting, strike or dilution terms that change its value | `[inferred]` from the posting's silence on terms | "What vesting schedule, strike price and share class go with the 0.5–1%?" | unresolved |
| RR2 | Solo design role | risk_signal | medium | "You would be our first designer" | There may be no design critique or mentor, and product calls may go unreviewed | `[inferred]` from "first designer" in a six-person team | "Who reviews design decisions day to day, and what research budget and time do I get?" | unresolved |
| RR3 | Year-one success undefined | unknown | — | "own the booking flow end to end" | Accountability may have no stated measure of success | `[inferred]` from the posting's silence on measures | "What does success look like at six and twelve months?" | unresolved |
| RR4 | Employer established, scope realistic | positive_signal | — | "funded by its customers" | Stable, customer-funded company with a live, specific posting | `[grounded]` about page and careers page | — | noted |

The standing "employer not established" entry is cleared: the careers page, about page and Ronan's profile all attribute the posting to a real company. It is not carried.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Describe the checkout work in your own words, as "I redesigned our checkout flow," and don't say "end to end" for the booking flow | Keeps R7 honest | `[grounded]` your intake; reframing audit | pending your approval |
| P2 | Before the call, check the calendar invite comes from a fernquay address and the video link matches. Ronan's WhatsApp message is routine scheduling; this is advice only. | The careers page lists jobs@fernquay.example | `[grounded]` careers page | your call |
| P3 | On the call, ask RR1, RR2 and RR3 verbatim | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Everything you've told me is your own statement, not yet probed.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software Galway" and "Fernquay jobs Product Designer"; fetched fernquay.example/careers/product-designer and fernquay.example/about. The entity exists as described, and the posting is live and matches the JD. |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland €52,000 €60,000 Galway" and got Tillerby 2026 Ireland Design Salary Report (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration. Scope was not searched separately. |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder" and got Ronan's LinkedIn profile (linkedin.example/in/ronan-kehoe): co-founder and CEO, previously five years as product lead at a Galway travel-software company. Moved the positioning, not the decision. |

## Upgrade menu

- Your pay floor → R2 closes and the decision moves to `go` or `no_go`.
- The checkout case study you sent Ronan → R3 to R7 claims can move toward `high`, and R7 gets an inspectable artifact.
- Equity terms in writing → RR1 closes.
- A deeper research pass on Fernquay (funding, leadership changes, public staff reviews; up to 5 more searches and 2 more fetches). Say the word and it runs.

I can save this as `tuesday-dossier.md` if you'd like a file to keep.

**G1** — Beyond the checkout redesign, did you own any other part of a booking or purchase flow, from research through to release?
**G2** — Have you ever been the only designer on a product, or gone without design critique for a stretch?
**G3** — Does €52,000 at the bottom of the range meet your floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.