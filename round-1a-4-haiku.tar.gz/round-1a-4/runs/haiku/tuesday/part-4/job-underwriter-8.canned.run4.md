**Decision: don't go ahead. Send nothing, and don't paste your IBAN anywhere.** Status: `no_go`.

Your background fits the role's stated requirements well, but the process asks you to pay, deposit a cheque and hand over bank and ID details before any employer-verified offer exists. Those requests decide it.

**Decision snapshot**

- **Status: `no_go`.** Your fit is strong on the posting's own terms, but the requests in these messages are confirmed severe red flags, and a confirmed severe red flag is a `no_go`.
- **Hard gates:** the posting states none. Against your pay floor (€30,000), the check is unconfirmed: "up to €26 an hour" with unstated commission, at 15–30 hours a week, is roughly €20,000–€40,000 before commission.
- **Severe red flags:** RR1, RR2, RR3 (`severity: high`).

**Evidence map (your fit, separate from the opportunity)**

| # | Requirement | Fit | Basis |
|---|---|---|---|
| R1 | Attention to detail, customer handling | direct | Three years of Zendesk work at about 60 tickets a day `[grounded]` your account |
| R2 | Confident with spreadsheets | direct | You keep the team's weekly Excel tracker `[grounded]` |
| R3 | Order processing | adjacent | Parcel-courier customer service is close, not the same work `[inferred]` |
| R4 | Good written English, quiet workspace | unclear | You haven't said either `[grounded]` the gap in your message |

**Opportunity ledger (risk register)**

- **RR1** `red_flag`, `severity: high`, `confirmed`. Source quote: "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." This request is very likely a scam. Don't pay. Verification question: "Which employer entity buys and supplies this equipment, and why would a new hire pay for it?"
- **RR2** `red_flag`, `severity: high`, `confirmed`. Source quote: "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." This request is very likely a scam. Don't deposit the cheque. Verification question: "Is this payment scheme part of your standard onboarding, and who issues the cheque?"
- **RR3** `red_flag`, `severity: high`, `confirmed`. Source quote: "please send your IBAN, your PPS number and a clear photo of your passport" (sent before any offer). This request is very likely a scam. Don't send any of it. Verification question: "Can you confirm, from your own careers page, the role and who is hiring?"
- **RR4** `risk_signal`, `severity: medium`, standing. Employer not established from attributable sources. Possible reasons, none ranked as likely: too new or small, a stale posting, or not a real hiring employer. `[generic]`, not a claim about this company. Verification question: "Can you point me at this role on your own careers site, and who would I interview with?"
- **RR5** `risk_signal`, `severity: medium`. The whole process runs on Telegram, with no call or video interview with a named person. Verification question: "Who would I speak to by video before any offer?"

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**Application plan**

1. Don't send your IBAN, PPS number or passport, and don't pay for equipment.
2. If a cheque arrives, don't deposit it.
3. Find the company through its own website or a directory you trust, and use contact details from there, not the Telegram account.
4. If the employer's own site confirms the role, the requests should be re-checked with them before anything else.

**Research tier: L1 — searches 2 of 5, fetches 0 of 2**

| Target | Status | What it moved |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics remote order processing coordinator jobs". Both returned no results, so the employer is not established (RR4). No careers page was found to fetch. |
| 2. Role-family sweep | skipped | The no_go rests on the requests in hand. The pay band would not change the status. |
| 3. Hiring manager's footprint | n/a | No name was given. |

**Dossier offer:** I can write a `tuesday-dossier.md` from this assessment so the register's questions carry into any real opening you pursue.

**Upgrade menu**

- A link to the live posting or the company's own careers page → RR4 can be reduced or cleared.
- A named employer whose contact details you find on its own website → RR1–RR3 can be checked with them.
- A full pay breakdown with commission → the pay-floor check can be settled.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.