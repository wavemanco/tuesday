**Yes, it's worth applying.** The status is `conditional_go`: apply, with the three conditions below. You meet both essential hard gates on your stated credentials, your five years of acute medical and discharge-to-assess work covers most of the clinical duties, and the employer checks out. The open questions are caseload ownership, end-of-life work and written records. Doppler is the one desirable skill you don't have.

## Decision snapshot

**Worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (clear, timely written records)
- `important`: direct: R5a, R6a, R7 · adjacent: R5b (leg-ulcer care), R8 (own caseload), R10 (care planning) · unclear: R9 (end-of-life visits), R11 (continence care)
- `preferred`: absent: R12 (Doppler assessment)

Items: R8 — adjacent home-visit work, its limit named; R9 — no evidence yet, the question is below; R4 — the records claim is untested; R12 — no evidence, closure path named.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`)
- **Severe red flags:** none found
- **Opportunity ledger:** The employer is established, the posting is clear about scope and pay, and it names a contact. The unknowns are the caseload size and how much senior support you get (RR1); the careers listing was not seen in this check (RR2). The pay range sits around the market median (RR3, positive).

**Conditions for `go`:**
1. Your caseload and care-planning examples hold up at interview (R8, RR1).
2. You have a real end-of-life example, or you accept that gap for the role (R9).
3. You can show written records that were timely and accurate (R4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing under an NHS contract across Calderdale; about 410 staff in four locality hubs | `[grounded]` employer's about page |
| Role | Community Staff Nurse, Band 5: housebound adults at home, a small personal caseload, supported by a senior community nurse | `[grounded]` posting |
| Pay and terms | £31,050–£37,800 a year plus mileage; pool cars provided | `[grounded]` posting |
| Market calibration | Wardround 2026 survey (n=1,240): Band 5 community staff nurse median basic pay £34,300, interquartile range £32,400–£36,600; 61% of respondents paid mileage. The advert's range sits around that median, and the posting's mileage matches the common pattern | `[generic]` survey, not this employer's offer |
| Contact | Rhiannon Mabbott, Community Nursing Team Lead; a 2025 forum speaker bio gives the same role at Calderbrook | `[grounded]` posting; `[inferred]` the bio corroborates the title only |
| Unknowns | Caseload size; senior nurse review frequency; whether Doppler training is provided; pool car access | — |
| Contradictions | None found between the posting and the employer's about page. The careers listing was not fetched, so the posting's live status is not confirmed | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | Stated active, revalidation March 2028; the register, not the CV, settles it | `[grounded]` user-stated, not checked | Check your NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B stated; pool cars are provided, so the licence is the working requirement | `[grounded]` user-stated, not checked | Check your DVLA record |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years as a staff nurse, stated on the CV | `[grounded]` CV | none |
| R4 | Clear, timely written records (incl. EPR) | must_have | unclear | low | discovery | Recording is implied in your ward and discharge work but not evidenced; no record example on the CV | `[grounded]` CV silence | Q3 below |
| R5a | Wound care | important | direct | medium | none | Pressure ulcers and surgical wounds on the CV | `[grounded]` CV | none |
| R5b | Leg-ulcer care | important | adjacent | medium | transferability | Wound care transfers; leg ulcers were not named. Limit: no leg-ulcer work on the CV | `[inferred]` adjacency from wound care | Name the limit at interview |
| R6a | Catheter care | important | direct | medium | none | Catheter care on the CV | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | low | discovery | Not on the CV | `[grounded]` CV silence | Ask at interview |
| R7 | Insulin administration | important | direct | medium | none | Insulin administration on the CV | `[grounded]` CV | none |
| R8 | Holding a small caseload | important | adjacent | medium | transferability | Seconded discharge-to-assess home visits cover the home setting. Limit: you have never held a caseload or run ongoing care for a housebound patient. Strengthener: an example of a plan you owned from first visit to discharge | `[inferred]` from the secondment | Q1 below |
| R9 | End-of-life visits | important | unclear | low | discovery | Not on the CV; discharge visits may have touched it | `[grounded]` CV silence | Q2 below |
| R10 | Care planning | important | adjacent | medium | transferability | Discharge-to-assess planning is the nearest match. Limit: community plans run over months | `[inferred]` from the secondment | Q1 below |
| R11 | Continence care | important | unclear | low | discovery | Not on the CV | `[grounded]` CV silence | Ask at interview |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No evidence. Closure path: ask whether the employer trains staff in Doppler, or take a course | `[grounded]` CV and posting | Ask at interview |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Caseload and care planning (R8, R10) | transferability | Home visits in the first week after discharge; no owned caseload | This is the duty the advert foregrounds; a clear example narrows it | Any plan you wrote and reviewed yourself across more than one visit; handover notes; a discharge plan you followed up | A sanitised care plan, or a discharge summary with your name on it | `[inferred]` the caseload is the posting's own emphasis |
| G2 | End-of-life visits (R9) | discovery | No mention on the CV | The advert lists it as a core duty | Palliative or end-of-life care on the ward; a home visit to a dying patient; discharge planning for end-of-life | A reference or a service note | `[grounded]` posting |
| G3 | Written records (R4) | discovery | Not evidenced | It is an essential, not a desirable | Notes you wrote on a visit or ward shift; an audit or a feedback item on your records | A sanitised note, with patient details removed | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload size and senior support unstated | unknown | — | "a small caseload of your own, supported by a senior community nurse" | The first caseload may be heavy, or the support may be informal | `[inferred]` from the posting's silence on numbers | How many patients would I hold in my first three months, and how often does the senior nurse review them? | unresolved |
| RR2 | Posting's live status not confirmed | unknown | — | "For an informal chat about the role, contact Rhiannon Mabbott" | The listing may be stale, though the employer is established | `[grounded]` careers page not fetched | Can you confirm the post is open, on the careers page? | unresolved |
| RR3 | Pay sits around the market median | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range is a normal Band 5 range for this kind of role | `[generic]` survey median £34,300 | How does the salary move up the range, and where does a new starter start? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your NMC register entry and DVLA record before you apply | R1, R2 are stated, not checked | `[grounded]` the gate rows | advice, no approval needed |
| A2 | Prepare one caseload example (G1) and one end-of-life example if you have one (G2) | R8, R9 | `[grounded]` the gap rows | advice |
| A3 | Use your secondment's home-visit work in the CV, as you describe it. Don't claim a caseload or leg-ulcer work | Truthful positioning | `[grounded]` CV | proposed; needs your approval before any CV edit |
| A4 | Ask Rhiannon Mabbott in the informal chat about caseload size and Doppler training (RR1, R12) | The advert offers the chat for exactly this | `[grounded]` posting | advice |

## Evidence status

Verified: R1, R2, R3, R5a, R6a, R7 (stated on the CV or by you; none inspected). R1 and R2 are checkable on the register and your DVLA record. Verified is about the claim, not the fit.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health careers community staff nurse vacancy"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). Confirmed the employer exists as a CIC under an NHS contract, with 410 staff across four hubs. The careers listing did not come up, so the posting's live status is open (RR2) |
| 2. Role-family sweep | yes | Searched "Agenda for Change band 5 nurse pay scale 2026/27 community nurse", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration `[generic]`; sets RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned a 2025 speaker bio (communitynursingforum.example/speakers/rhiannon-mabbott). Confirms the title and the Halifax team; it moved only the contact line, not the decision |

## Upgrade menu

- A sanitised care plan or a discharge summary with your name on it → R8 and R10 move from adjacent to direct, and the caseload condition gets easier.
- A sanitised patient note or an audit item → R4 moves from unclear to direct.
- Any end-of-life or palliative example → R9 moves from unclear to direct.
- The employer's answer on Doppler training → R12 closes, or becomes a course to plan.
- The live posting on the careers page → RR2 closes.
- A deeper research pass on Calderbrook (inspection reports, leadership changes, staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you'd like, I can save this as a `tuesday-dossier.md` to take into the interview.

Three questions, each tied to its row:

- **R8 / R10 (G1):** On the discharge-to-assess visits, did you write the plan yourself and review it, or follow a plan someone else set? Give one example from first visit to discharge.
- **R9 (G2):** Have you been part of care for someone dying at home or on the ward? Briefly, what was your role?
- **R4 (G3):** Which patient record systems have you used, and how do you keep notes timely on a visit day?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.