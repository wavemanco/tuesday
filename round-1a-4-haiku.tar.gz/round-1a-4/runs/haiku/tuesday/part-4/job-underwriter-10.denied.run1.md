**Worth taking the call, not yet worth more effort until the company checks out. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (salary €52,000–€60,000 against your floor)
- `must_have`: direct: R3 (3+ years product design), R4 (strong Figma), R5 (running your own research), R7 (shipping alongside engineers) · adjacent: R6 (owning the booking flow end to end, as first designer)
- `important`: adjacent: R8 (research with school owners)

R6 — your checkout work was done inside a squad; owning a flow with no design peer is the gap. R2 — the posted band is stated, your floor is not.

**Opportunity ledger.** The employer is not established from anything I could check (RR1, `risk_signal`, `severity: medium`). The first-designer scope and the equity terms are unexplained (RR2, RR4). The recruiter message asks nothing of you except a call, so it is not a concern on its own (see the application plan). One positive: the scope and outcomes are concrete (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (salary €52,000–€60,000 against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the company verifies on its own site and register, and the invite comes from its domain (RR1); (2) someone is named who reviews design decisions, so you are not the only voice on the flow (RR2); (3) the pay and equity hold against your floor (R2, RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, described as six people in Galway making booking software for sea-kayak and surf schools | `[grounded]` posting; not verified (RR1) |
| Scope read | Owns the booking flow alone, runs research with school owners, ships with two engineers | `[inferred]` from the posting's scope against its silence on design review |
| Market calibration | Not established. The salary search was refused, so I have no band to compare €52,000–€60,000 against | — |
| Unknowns | Design review and sign-off, design budget, equity share class and vesting, your pay floor | — |
| Contradictions | None found between the posting and the recruiter message | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two office days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway; your own schedule limits were not given | `[grounded]` your background | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | medium | hard_gate | The figure is stated; your floor was not given | `[grounded]` posting | Q2 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer, stated; no artifact reviewed yet | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily Figma use, stated | `[grounded]` your background | none |
| R5 | Running your own user research | must_have | direct | medium | none | Monthly usability sessions with customers, stated | `[grounded]` your background | none |
| R6 | Owning the booking flow end to end, as first designer | must_have | adjacent | medium | transferability | You redesigned a checkout flow inside a squad of four engineers. You have never been the only designer, so solo ownership is unexercised | `[inferred]` bridge from the checkout work | G1 |
| R7 | Shipping alongside two engineers | must_have | direct | medium | none | Squad of four engineers, stated | `[grounded]` your background | none |
| R8 | Research calls with school owners | important | adjacent | medium | transferability | Your research method carries over; your customers were travel consumers, not small-business owners | `[inferred]` | Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Solo ownership of a flow (R6, must_have) | transferability | Checkout redesign in a squad; whether designers reviewed your decisions is not established | "First designer" is the posting's main risk, and it decides whether this is a role you can do | Deciding a flow's structure and defending it to engineers; settling a disagreement with your own usability sessions; a checkout call you made without a crit partner | The checkout case study you already sent, or a note of the decisions you owned | `[inferred]` bridge from the checkout work; `[generic]` that first-designer roles usually lack review |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Fernquay's own careers page, and what is the company's registered name? | unresolved |
| RR2 | Design decisions and sign-off not stated | unknown | — | "You would be our first designer: own the booking flow end to end" | Design sign-off may sit with the CTO or the co-founder, with no design review | `[inferred]` from the scope against silence on review | Who reviews design decisions, and who signs off the booking flow? | unresolved |
| RR3 | Salary band not checked against the market | unknown | — | "Salary €52,000–€60,000" | The band may sit below or within normal range; the search that would show it did not run | `[grounded]` posting figure; band not established | Is €52,000–€60,000 the approved budget for this role, and is there room within it? | unresolved |
| RR4 | Equity terms unexplained | unknown | — | "plus 0.5–1% equity" | The equity may be worth little or a lot, depending on share class, vesting and valuation | `[inferred]` from the missing terms | What share class, vesting schedule and current valuation sit behind the 0.5–1%? | unresolved |
| RR5 | Concrete scope and outcomes | positive_signal | — | "own the booking flow end to end, run research calls with school owners" | The role is defined, and you would know what success looks like | `[grounded]` posting | What would a good first six months on the booking flow look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take the 45-minute call with Ronan and Saoirse | Scheduling and a video call are routine; the invite was emailed | `[grounded]` the WhatsApp message and the invite it names | pending your approval |
| A2 | Before the call, check Fernquay yourself: its own website, its careers page, and the public company register, searching for the name. Check that the invite came from the company's domain. Do this through sites you find yourself, not the chat | Covers RR1 | `[generic]` standard check for small companies | pending your approval |
| A3 | Put RR2, RR3 and RR4 to the company on the call, using the verification questions as written | The register doubles as prep for the call | `[grounded]` register | pending your approval |
| A4 | Hold back the checkout case study until the company is verified | Limits what you share before RR1 is answered | `[inferred]` from RR1 | pending your approval |

On the WhatsApp message: it asks for a call and a reply about timing. Nothing in it asks you to pay, deposit, or give bank or ID details, so it is not a warning sign. Your doubt is about the employer, and A2 is how to resolve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches (Fernquay booking software, and Fernquay product designer jobs) were refused: web search permission was not granted this session. Would have moved RR1 and whether the role is live on the company's own site |
| 2. Role-family sweep | unavailable | One search (product designer salary, Ireland) was refused. Would have moved RR3 and the market calibration for the band |
| 3. Hiring manager's public footprint | unavailable | One search (Ronan Kehoe, Fernquay) was refused. Would have moved the scope read and how to position for this reader |

## Upgrade menu

- The live posting link, the careers page address, and the email domain the invite came from → RR1 can close, and it is the one check that could move this to `go`.
- The checkout case study, shared for this review → R3, R5 and R7 could move to `high`, and R6's bridge gets stronger.
- Your pay floor and any schedule limits → R2 and R1 close.
- Web search permission for the company and salary checks → RR1 and RR3 get researched instead of asked.

Dossier offer: I can save this as `tuesday-dossier.md` so a later session can pick it up.

**Questions:**

G1 — Have you ever decided a flow's design without another designer reviewing it? What did you own, and how did you make the call?

Q1 — Have you spoken to any small-business owners, such as school owners, about their software? If so, how did you find them?

Q2 — What is your pay floor, and what schedule or in-office limits would you not accept?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.