**Answer: it looks legitimate, and it's worth pursuing on conditions. Status: `conditional_go`.** The company checks out on its own site, the posting matches its careers page, and no hard gate fails. The open questions are whether a solo first-designer role fits your experience, what your pay floor is, and what the equity is worth.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary range against your floor); candidate constraints not given, so checks against them are unknown.
- **Fit ledger.**
  - `hard_gate`: direct: R1 · unclear: R2 (Salary range against your floor)
  - `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
  - `important`: unclear: R8 (First designer, sole ownership)
  - R7 — the checkout work is the bridge, its limit named (you never owned a product area alone); R8 — no sole-owner evidence yet, a discovery question; R2 — your pay floor is yours to set.
- **Opportunity ledger.** The employer is established (RR4) and the stated range sits inside the survey band (RR3). Two entries are open: the solo design scope (RR1) and unstated equity terms (RR2).
- **Severe red flags:** none found.
- **Conditions for go:** (1) the solo-designer scope holds up in the call (RR1, R8); (2) €52,000 clears your floor (R2); (3) the equity comes back as concrete terms (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, which makes Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people in Galway, founded 2023 | `[grounded]` company About page |
| Mandate | First designer: own the booking flow, run research with school owners, ship with two engineers | `[grounded]` JD |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` careers page and JD |
| Scope read | A first design hire at a six-person company. Ownership is wide and no design peer is named | `[inferred]` from "first designer" against the two-engineer team |
| Market calibration | For 3–5 years' experience, the 2026 Ireland survey gives a median of €57,000 and an interquartile range of €51,500–€62,000. The stated range sits inside it. This is one survey (n=520), not Galway-specific, and never this employer's offer | `[generic]` Tillerby 2026 salary report |
| Unknowns | Pay floor (yours); equity terms; who reviews design decisions day to day | — |
| Contradictions | None between the JD and the careers page. The About page names Saoirse as a co-founder; the WhatsApp message calls Saoirse CTO. That is not a contradiction, but confirm the title in the call | `[grounded]` About page, WhatsApp message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year. Self-stated, with no artifact | `[grounded]` your intake | none |
| R2 | Salary €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | Your floor has not been given, so the gate is not settled | `[grounded]` JD range | G2 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company. Length of experience, so graded on fit, not as a gate | `[grounded]` your intake | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily Figma use, self-reported | `[grounded]` your intake | none |
| R5 | Has run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. The JD asks for research with school owners, a B2B audience you have not described working with | `[grounded]` your intake; `[inferred]` the audience gap | none |
| R6 | Works directly with engineers | must_have | direct | medium | none | Four years in a squad with four engineers | `[grounded]` your intake | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | The checkout redesign is adjacent: you owned part of a flow inside a squad, not the whole product area | `[inferred]` from the checkout work you described | G3 |
| R8 | Work as the first and only designer | important | unclear | low | discovery | You have never been the only designer. Nothing shows how you handled decisions with no second opinion | `[grounded]` your intake | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | First-designer ownership (R8, important) | discovery | Strong team-level design work; no record of owning decisions alone | This is the central fit question for the role. It could move the status to `go` | Calls you made when the team was split; a decision you took to the engineers and held; a flow you shipped with the squad's agreement but your reasoning | A decision log, a design rationale doc, a retrospective | `[grounded]` your intake; `[generic]` that first-design hires are judged on this |
| G2 | Pay floor (R2, hard_gate) | hard_gate | The range is stated; your floor is not | The one gate that can't be settled from here | Your own number | none needed | `[grounded]` JD and your constraint |
| G3 | Booking-flow bridge (R7, must_have) | transferability | Checkout redesign and monthly usability work | Would tighten the adjacent-to-direct gap | The checkout case study Ronan praised, and its outcome metrics | The case study itself | `[inferred]` bridge from the checkout work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Solo design scope with no named design peer | risk_signal | medium | "You would be our first designer" | Design decisions may sit with you alone, with no review. | `[generic]` pattern for first design hires at small companies, not a claim about this one | Who reviews design decisions day to day, and what does success look like at six months? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | The value depends on vesting, share class and valuation. None is given. | `[inferred]` from the posting's silence on terms | What vesting schedule and share class apply to the 0.5–1% range? | unresolved |
| RR3 | Stated range inside the survey band | positive_signal | — | "€52,000–€60,000" | The range is in line with the survey. It is not this employer's budget. | `[grounded]` posting figure against `[generic]` survey band | Is the range flexible for someone with four years of product design? | noted |
| RR4 | Employer established | positive_signal | — | "Six people, based in Galway" | Company page, careers page and co-founder profile agree on size, product and role. | `[grounded]` About page, careers page, LinkedIn result | Which co-founder would I work with day to day, and what is the CTO's remit? | noted |

Scheduling the call by WhatsApp and sending the invite by email are routine steps for an interview held elsewhere, so they get no entry.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Prepare the 45-minute call around the checkout case study. Say which decisions were yours inside the squad | See R7, R8 | `[grounded]` checkout work | pending your approval |
| P2 | Ask RR1 and RR2 in the call, verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P3 | Settle your pay floor before the call | See R2 | `[grounded]` your constraint | pending your approval |
| P4 | Check the calendar invite comes from the company's own domain before you accept it | Advice only | `[inferred]` from the company's listed domain | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report until it is probed or shown.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea kayak surf schools" and "Fernquay product designer job Galway". Fetched fernquay.example/careers/product-designer and fernquay.example/about. Entity established; the posting is live and matches the JD on range, hybrid and team size |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3 years experience Galway". Returned tillerby.example/2026-ireland-design-salary-report: 3–5 years, median €57,000, IQR €51,500–€62,000. Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder". Returned linkedin.example/in/ronan-kehoe (snippet, not fetched): co-founder and CEO, previously product lead at a Galway travel-software company for five years. Moved the positioning for the call: lead with product decisions, not craft alone |

## Upgrade menu

- Your checkout case study, or a screenshot set from it → R7 to `high` and a usable bridge in the call.
- A decision log or design rationale from a squad project → R8 moves toward `direct` or settles as `absent`.
- Your pay floor → R2 closes and the range is checked against it.
- The equity terms from the company → RR2 closes.
- A deeper research pass on Fernquay (funding, leadership, past hires; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you want this, I can also write a prep pack for the 45-minute call with the `mock-interview` module, which handles rehearsal.

Would you like to add a dossier to this review? I can emit a `tuesday-dossier.md` for it whenever you want.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. **G1 (R8):** Have you ever owned a design decision with no other designer to check it? If not, what did you do when a call needed a second opinion?
2. **G2 (R2):** Is €52,000 above your floor, and is there any part of the range you would not accept?
3. **G3 (R7):** Can you share the checkout case study, or screenshots from it, and tell me which decisions were yours inside the four-engineer squad?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.