**Don't go ahead with this. Send nothing: no payment, no cheque lodgement, and no IBAN, PPS number or passport photo.**

**Decision snapshot**
- **Status: `no_go`.** Four severe red flags (RR1–RR4) are confirmed by the messages' own wording. Your fit for the day-to-day work is reasonable, but that doesn't offset the requests.
- **Fit ledger**
  - `hard_gate`: unclear: R1 (pay at least €30,000 a year)
  - `must_have`: direct: R2, R3; adjacent: R4 (attention to detail)
  - `important`: unclear: R5 (good written English), R6 (quiet place to work)
  - R2 and R3 rest on what you told me, not on documents. R1 is the pay gap, and it matters more than fit here.
- **Hard gates:** none failed; unconfirmed: R1 (pay at least €30,000 a year). Your €30,000 floor is stated; the role's pay is not.
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the payment, cheque and early-details requests would have to be withdrawn, and the role confirmed through contact details on the employer's own website. Those requests are confirmed, so the status stays `no_go` until then.

**Evidence map** (your background is stated, not checked)

| # | Priority | Fit | Confidence | Requirement | Reasoning |
|---|---|---|---|---|---|
| R1 | hard_gate | unclear | low | Pay at least €30,000 a year | Posting says "up to €26 an hour plus commission". At 15–30 hours a week, that is roughly €20,300–€40,600 a year before commission and tax `[inferred]` from the posting's own figure. €30,000 needs about 22 hours a week every week at €26 with no commission. Hours are not guaranteed. |
| R2 | must_have | direct | medium | High-volume ticket handling | Three years at a parcel courier, about 60 Zendesk tickets a day (stated). |
| R3 | must_have | direct | medium | Confident with spreadsheets | Keeps the team's weekly Excel tracker (stated). |
| R4 | must_have | adjacent | medium | Strong attention to detail | Tracker upkeep and training two starters. No accuracy evidence. |
| R5 | important | unclear | low | Good written English | No writing sample provided. |
| R6 | important | unclear | low | A quiet place to work | Not stated. |

**Opportunity risk register**

- **RR1 · red_flag · `severity: high` · confirmed**
  - Quote: "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages."
  - Hypothesis: Paying for equipment is a request made of you, not an onboarding step `[generic]`.
  - Verification question: "Does Velloway Logistics ask new hires to pay an equipment partner before they start?"
  - Decision rule: Pay nothing until the employer confirms this through contact details found on its own website.
  - Status: confirmed.

- **RR2 · red_flag · `severity: high` · confirmed**
  - Quote: "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner."
  - Hypothesis: Depositing a cheque and sending money back before clearance is a known pattern for fraud that uses your account `[generic]`. This request is very likely a scam. Don't deposit the cheque.
  - Verification question: "Does Velloway Logistics send new hires cheques to deposit and pass on part of the money?"
  - Decision rule: Don't deposit any cheque until the employer confirms this through its own website's contact details.
  - Status: confirmed.

- **RR3 · red_flag · `severity: high` · confirmed**
  - Quote: "Before your chat interview, please send your IBAN ..., your PPS number and a clear photo of your passport so payroll can set you up."
  - Hypothesis: Bank, tax and ID details requested before any written offer `[generic]`. Routine onboarding comes after a credible written offer, and none has been made.
  - Verification question: "Will you send a written offer naming the role and pay before you ask for bank or ID details?"
  - Decision rule: Share nothing until a written offer arrives and the employer's contact details are confirmed independently.
  - Status: confirmed.

- **RR4 · red_flag · `severity: high` · confirmed**
  - Quote: "Our whole hiring process runs on Telegram, so there are no calls or video interviews."
  - Hypothesis: The interview and the offer happen only in chat `[grounded]`. That is a sign, not proof of anything about the employer.
  - Verification question: "Can you point me to this role on your own careers page and set up a call with a named hiring manager?"
  - Decision rule: Don't proceed unless the process moves to a call or video interview with a named contact.
  - Status: confirmed.

- **RR5 · risk_signal · `severity: medium` · unresolved** (standing entry)
  - Signal: Employer not established from attributable sources. I did not search this turn.
  - Hypothesis: The employer may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. None is ranked as likely `[generic]`.
  - Verification question: "Can you point me at the role on your own careers site, and who would I be interviewing with?"
  - Decision rule: Verify the employer exists and the posting is live before spending application effort.

- **RR6 · risk_signal · `severity: low` · unresolved**
  - Signal: Pay is "up to €26 an hour plus commission", with no guaranteed hours `[grounded]`.
  - Verification question: "What are the guaranteed weekly hours and the base pay before commission?"
  - Decision rule: Accept only if guaranteed hours and base pay reach your floor in writing.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**Gap recovery queue**
- R1: closes only if the employer states base pay and guaranteed hours in a written offer.
- R5: closes with a short writing sample you choose to share.
- R6: a fact about your home; you know it already.

**Application plan**
1. Don't reply with any bank, tax or ID details, pay anything, or deposit the cheque. Don't paste your IBAN into a chat.
2. Check the employer through contact details on Velloway's own website, not the Telegram handle or the email address in these messages.
3. If you still want this type of role (remote order processing or coordination, with Zendesk and Excel), apply through a listing on the employer's own site where the interview is a call.

**Evidence status**

Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | `unavailable` | No search sent this turn; L0 used. |
| 2 | Role-family sweep for pay and scope | `unavailable` | No search sent this turn; L0 used. |
| 3 | Hiring manager's public footprint | `n/a` | No name was given. |

This is a dossier offer: I can save this analysis as `tuesday-dossier.md` for later sessions.

**Upgrade menu**
- The live job listing link: unlocks a check on RR5 and whether the pay is stated.
- An L1 check of Velloway's own website (up to 5 searches and 2 page fetches): unlocks RR5 and the pay-band comparison.
- A short writing sample: unlocks R5 with evidence.

**Questions**
1. Have you sent any details, or paid or deposited anything yet?
2. Can you share the link to the listing you found?
3. Should I run the L1 check on Velloway's own website?

Answer in text, or say skip for any of these.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.