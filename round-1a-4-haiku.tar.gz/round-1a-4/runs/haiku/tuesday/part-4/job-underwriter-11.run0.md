## Posting 1: Operations Analyst, Duinvaart Cold Chain (Rotterdam)

Yes, on conditions. Status: `conditional_go`.

**Fit ledger**

- `hard_gate`: unclear: D-R1 (hybrid, three days a week in Rotterdam)
- `must_have`: direct: D-R2 (2+ years in logistics or operations analysis), D-R3 (strong SQL), D-R4 (Power BI or Tableau), D-R5 (track on-time delivery) · adjacent: D-R6 (track temperature compliance)
- `important`: direct: D-R7 (work with depot managers) · adjacent: D-R8 (route changes)
- `preferred`: adjacent: D-R9 (Dutch a plus)

Your SQL, Power BI and on-time dashboard work covers D-R2 to D-R5 directly. D-R6 is adjacent: dashboard-building transfers, but there's no cold-chain data in your background. D-R8 is adjacent: you ran the route-performance review, which isn't the same as approving route changes.

**Opportunity ledger.** The posting is specific and states its schedule plainly (D-RR3, positive). It doesn't state pay (D-RR1), and it doesn't say who approves route changes (D-RR2).

- **Hard gates:** none failed; unconfirmed: D-R1 (hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) D-R1: you can do three Rotterdam days a week; (2) D-RR2: route-change authority is concrete; (3) D-R6: you can show temperature or cold-chain work, or a credible way to learn it.

**Role reality**

- Scope: tracking, weekly Power BI dashboards, and route work with depot managers. `[grounded]` posting.
- Scope read: a standard analyst remit for the title. `[inferred]` from those three responsibilities.
- Pay: not stated. `[grounded]` posting silence. No market band checked (no research run).

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D-R1 | Hybrid, 3 days/week, Rotterdam | hard_gate | unclear | none | hard_gate | No statement from you on location or schedule limits | `[grounded]` posting | Q1 |
| D-R2 | 2+ yrs logistics/ops analysis | must_have | direct | medium | none | 4 yrs as operations analyst at a parcel carrier; intake prose caps at medium | `[grounded]` your background | none |
| D-R3 | Strong SQL | must_have | direct | medium | none | SQL daily, stated; no artifact yet | `[grounded]` your background | none |
| D-R4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the depot dashboard | `[grounded]` your background | none |
| D-R5 | Track on-time delivery | must_have | direct | medium | none | You built the on-time dashboard depot managers use | `[grounded]` your background | upgrade menu: a sanitized screenshot would raise to high |
| D-R6 | Track temperature compliance, refrigerated fleet | must_have | adjacent | medium | transferability | KPI-dashboard work transfers; temperature data does not appear. Limit: no cold-chain metrics | `[inferred]` from D-R5's dashboard work | Q3 |
| D-R7 | Work with depot managers | important | direct | medium | none | Depot managers use your dashboard and attended your route review | `[grounded]` your background | none |
| D-R8 | Route changes with depot managers | important | adjacent | medium | transferability | You ran the route-performance review. Limit: no stated authority over route changes | `[inferred]` | RR2's question |
| D-R9 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational, not fluent | `[grounded]` your background | none |

**Gap recovery queue.** D-R6 is the one real gap. A temperature or cold-chain example would narrow it. D-R8 closes with the route-authority answer in D-RR2.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| D-RR1 | Pay not stated | unknown | — | (no salary line) | Pay may sit below your expectations, or simply isn't published | `[inferred]` from the posting's silence | What is the salary range for this role? | unresolved |
| D-RR2 | Route-change authority unclear | unknown | — | "work with depot managers on route changes" | You could be accountable for route outcomes without approval rights | `[inferred]` from the posting's silence on authority | Which route changes does this role approve itself, and which go to depot managers? | unresolved |
| D-RR3 | Schedule stated plainly | positive_signal | — | "Hybrid, three days a week in our Rotterdam office" | No hidden schedule expectations | `[grounded]` posting | — | noted |

**Application plan**

- E1: Lead your CV summary with "SQL and Power BI daily, including the on-time delivery dashboard depot managers use." Your own words; nothing added. `resume_edits_pending_approval`.

## Posting 2: Supply Planner, Kroonhaven Foods (Utrecht)

No, not now. Status: `no_go`.

The core requirements are planning experience, which you don't have, and a 13-week supply plan, which you haven't done. Those can't be closed in weeks. The planning tools and Excel are unknown until you answer Q2. Fluent Dutch is short too.

**Fit ledger**

- `hard_gate`: unclear: K-R1 (on-site in Utrecht)
- `must_have`: adjacent: K-R7 (fluent Dutch) · unclear: K-R5 (advanced Excel), K-R6 (SAP IBP or similar) · absent: K-R2 (3+ years planning in FMCG), K-R4 (13-week supply plan)
- `important`: adjacent: K-R3 (weekly S&OP meeting)

K-R2 and K-R4 are absent. K-R5 and K-R6 are unknown until Q2. K-R7 is conversational against a fluent requirement. K-R3 is your best bridge: the route-review meeting.

**Opportunity ledger.** The responsibilities are clear and well scoped (K-RR2, positive). Pay isn't stated (K-RR1).

- **Hard gates:** none failed; unconfirmed: K-R1 (on-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** planning experience in FMCG (K-R2) is the fact that would move it to `conditional_go`. Q2 could settle K-R5 and K-R6, but it won't change the status by itself.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K-R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No statement from you on location | `[grounded]` posting | Q1 |
| K-R2 | 3+ yrs supply/demand planning, FMCG | must_have | absent | medium | transferability | You've never worked in planning. Closest adjacent work is operations analysis | `[grounded]` your statement; `[inferred]` adjacency | none |
| K-R3 | Run weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: no supply or demand decisions | `[inferred]` | none |
| K-R4 | Own 13-week plan; balance capacity vs forecast | must_have | absent | medium | transferability | No planning or capacity work. SQL and dashboards are the transferable tools | `[inferred]` | none |
| K-R5 | Advanced Excel | must_have | unclear | low | discovery | Not stated in your background | `[grounded]` absence | Q2 |
| K-R6 | SAP IBP or similar planning system | must_have | unclear | low | discovery | Not stated; the posting names one | `[grounded]` absence | Q2 |
| K-R7 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent | `[grounded]` your background | none |

**Gap recovery queue.** K-R2 and K-R4 need time and real planning exposure. Nothing in a CV edit closes them. K-R5 and K-R6 are the only gaps that a single answer could move.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| K-RR1 | Pay not stated | unknown | — | (no salary line) | Pay may be below your expectations, or simply unpublished | `[inferred]` from silence | What is the salary range for this role? | unresolved |
| K-RR2 | Clear scope | positive_signal | — | "Own the 13-week supply plan … run the weekly S&OP meeting" | Responsibilities are specific and measurable | `[grounded]` posting | — | noted |

**Application plan.** No application actions proposed. The status is `no_go`, and the next step is only Q2, if you want to rule Excel or a planning tool in or out.

## Evidence status

Research tier: L0 — no searches; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Not run at first pass. Would confirm both employers exist and both postings are live |
| 2. Role-family sweep | unavailable | Not run. Would give pay bands for both titles, since neither posting states pay |
| 3. Hiring manager's public footprint | n/a | No name given |

Verified: none yet. Both assessments rest on your background as you described it, which is self-report and caps at `medium`.

## Upgrade menu

- Dossier offer: I can save both assessments as a `tuesday-dossier.md` if you want to keep them.
- Your hard limits (location, schedule, pay floor) close D-R1 and K-R1, the two gates that are still open.
- Any Excel model or planning-tool work moves K-R5 and K-R6 from unknown.
- Any temperature or cold-chain data moves D-R6 toward direct.
- A sanitized screenshot of your on-time dashboard raises D-R5 to `high`.
- L1 research (up to 5 searches, 2 fetches) would confirm both employers and live postings, and calibrate pay against role-family bands. Say the word and it runs.

## Questions

1. D-R1 and K-R1: Can you work hybrid three days a week in Rotterdam, and on-site in Utrecht? Is there a pay floor I should check against?
2. K-R5 and K-R6: Have you built forecasts in Excel, or used a planning tool such as SAP IBP, even on a small scale?
3. D-R6: Have you ever tracked temperature or cold-chain compliance, such as reefer logs, HACCP checks or sensor alerts?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.