**Yes, it's worth applying to, and the company checks out. Status: `conditional_go`.** The company, the role and the recruiter's name all match public pages, and the posting has no payment or bank-detail requests. The conditions are about the booking-flow ownership story and the unknowns in the role.

**Fit ledger.**

- `hard_gate` — direct: R1
- `must_have` — direct: R2, R3, R4, R5 · adjacent: R6 (own the booking flow end to end)
- `important` — adjacent: R7 (research calls with school owners) · unclear: R8 (first designer with no design peers)

R6 — checkout is a real slice of a booking flow, but end-to-end ownership isn't shown yet; R7 — your research was with travel customers, not school owners; R8 — untested, and the role leans on it.

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given — checks against pay, contract and schedule are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can tell a booking-flow story where you owned the outcome, not only the checkout screens (R6, G1); (2) the call answers who makes design decisions and what the equity terms are (RR2, RR3); (3) you have a pay floor, and the €52k–€60k range clears it.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organisation | Fernquay: booking software (Kelproster) for sea-kayak, surf and sailing schools in Ireland and Scotland; six people; Galway; founded 2023 | `[grounded]` fernquay.example/about |
| Role | First designer; owns the booking flow end to end; research with school owners; ships with two engineers | `[grounded]` posting, matches careers page |
| Pay and equity | €52,000–€60,000 plus 0.5–1% equity; terms of the equity not given | `[grounded]` posting |
| Market calibration | Tillerby 2026 Ireland report, product designers with 3–5 years: median €57,000, IQR €51,500–€62,000 (n=520). The posted range sits inside the IQR, in its lower half | `[generic]` role-family sweep; the band is not this employer's offer |
| Hiring manager | Ronan Kehoe: co-founder and CEO; previously product lead at a Galway travel-software company for five years | `[grounded]` public LinkedIn profile only |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` posting |
| Unknowns | Equity vesting and strike price; how design decisions are made; team beyond the two engineers | — |
| Contradictions | None between the posting, the careers page and the about page. The about page names Saoirse Doyle as co-founder; the recruiter calls her CTO, which is consistent | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You stated you moved back to Galway last year; intake prose, no artifact | `[grounded]` your intake message | none |
| R2 | 3+ years of product design | must_have | direct | medium | none | Four years stated at a Dublin travel-booking company | `[grounded]` your intake message | none |
| R3 | Strong Figma | must_have | direct | medium | none | Daily use stated | `[grounded]` your intake message | none |
| R4 | Has run own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers | `[grounded]` your intake message | none |
| R5 | Happy working directly with engineers | must_have | direct | medium | none | Four years in a squad with four engineers | `[grounded]` your intake message | none |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout, one stage of a booking flow; ownership from research to launch is not stated. Limit: checkout inside a squad | `[inferred]` from the checkout work you described | see G1 |
| R7 | Research calls with school owners | important | adjacent | medium | transferability | Your research was with travel customers; the audience differs (operators running small businesses). Limit: no operator-side research stated | `[inferred]` adjacency from the usability work | see G2 |
| R8 | Working as the only designer | important | unclear | low | discovery | You said you have never been the only designer; nothing in the material shows how you worked without design peers | `[grounded]` your intake message, which is silent on it | question 2 below |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking-flow ownership (R6, must_have) | transferability | Checkout redesign inside a squad; no stated ownership of discovery or launch across the flow | Moves R6 to `direct` if you owned more than screens | Deciding which checkout states to fix first; the booking-to-payment handoff; a launch you drove with engineers | A case-study page, a launch note, or your own write-up of the flow | `[inferred]` bridge from the checkout work; `[generic]` that interviewers probe end-to-end ownership |
| G2 | Research with operators (R7, important) | transferability | Consumer usability sessions; no B2B or operator research stated | The job's research is with school owners, a different audience | Any interview or observation with small-business owners; a support-desk review; a supplier or partner study | A research readout or interview guide | `[inferred]` adjacency; `[generic]` that operator interviews differ from consumer ones |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary range, founders and role scope are published and consistent across pages | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The company is open about pay and roles | `[grounded]` posting, careers and about pages | What is the next step in the process, and who decides? | noted |
| RR2 | First designer with no design peers, owning the flow end to end | risk_signal | low | "You would be our first designer" | You may carry design decisions with no review partner | `[inferred]` from "first designer" against the silence on design decision rights | Who reviews design decisions, and who decides when Ronan and Saoirse disagree? | unresolved |
| RR3 | Equity terms not stated | unknown | — | "plus 0.5–1% equity" | The equity may be worth less than it looks without vesting or strike terms | `[grounded]` posting states the range only | What vesting schedule, strike price and option type come with the 0.5–1%? | unresolved |

Severe red flags: none found. No entry for the WhatsApp outreach: the invite came by email and the messages only schedule a call, which is routine.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before joining the call, check that the invite came from a fernquay.example address and the video link is on that domain | Routine check; the outreach was on WhatsApp | `[grounded]` the invite as you described it | pending your approval |
| A2 | Write a one-page walk-through of the checkout work, separating what you owned from what the squad owned | Answers G1 and makes R6 checkable | `[grounded]` R6 row | pending your approval |
| A3 | Ask RR2, RR3 and RR1's question on the call | The register doubles as interview prep | `[grounded]` register | pending your approval |

The hiring-manager positioning: you and Ronan both come from travel booking. Lead with checkout outcomes you can show, in plain terms. Don't describe the work as owning the flow. Claims in A2 are for you to check against what you did before you use them.

**Evidence status**

Verified: R1–R5 as you stated them in your message (medium, no artifact yet). The equity and team terms are unverified. Standing "employer not established" entry: not triggered, since the company's own pages and a public founder profile attribute the posting to a real employer.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers"; fetched fernquay.example/careers/product-designer and fernquay.example/about. Company exists as described; the posting is live and consistent with the posting you pasted |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3 years experience booking software startup", which returned Tillerby 2026 Ireland Design Salary Report (tillerby.example/2026-ireland-design-salary-report). Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned his public profile (linkedin.example/in/ronan-kehoe). Scope read and positioning only |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` you can keep and add to later.

**Upgrade menu**

- A case-study page or launch note for checkout → R6 to `direct`, and A2 gets its artifact.
- The equity's vesting and strike terms, from the employer → RR3 closes.
- Your pay floor, if you give it → the hard-gate line can be checked, not left unknown.
- A deeper research pass on Fernquay (funding, past hires, public reviews; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

1. G1 — On the checkout work, which parts did you own from research to launch, and which did your squad own?
2. R8 — Have you ever worked with no other designer nearby? If not, how would you structure feedback and decisions on your own?
3. What is the lowest salary you would accept for this role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

For the call with Ronan and Saoirse, `mock-interview` can prepare you. I haven't run it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.