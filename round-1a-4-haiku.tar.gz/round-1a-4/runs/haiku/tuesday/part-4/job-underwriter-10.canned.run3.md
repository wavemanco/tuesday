**Yes, it's a real company, and the call is worth taking.** Fernquay's own website matches the posting, its founders are public, and I found nothing in the posting or the WhatsApp message that is a red flag. Two things are open: the pay, and what "first designer" will mean day to day.

**Decision snapshot**

**Worth taking the call. Status: `conditional_go`.** Conditions: confirm pay against your floor, confirm employment type and equity terms, and find out who reviews design decisions.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Base salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6
- `important`: adjacent: R7 (Own the booking flow end to end), R8 (First designer, no design team)

R2 — pay is unconfirmed until your floor is known; R7 — your checkout work is the nearest match, but the booking flow is wider; R8 — you have worked in a squad, never alone.

**Opportunity ledger.** Mostly sound. The company's public footprint is consistent (RR4). One real risk is scope: one designer covering the booking flow, research and shipping (RR1). Employment type and equity terms are unstated (RR2, RR3).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Base salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** conditions for go: (1) your pay floor sits at or under €52,000 (R2); (2) RR1 answered in the call: a named person reviews design, and the scope is realistic; (3) RR2 and RR3 answered: permanent or contract, and equity terms stated.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, founded 2023; sells Kelproster booking software to sea-kayak, surf and sailing schools in Ireland and Scotland; funded by its customers | `[grounded]` fernquay.example/about, fetched |
| Founders | Ronan Kehoe and Saoirse Doyle named on the about page. Ronan's public profile says co-founder and CEO, previously product lead at a Galway travel-software company | `[grounded]` about page; `[grounded]` LinkedIn search snippet, not fetched |
| Posting | Careers page matches the posting: title, hybrid terms, €52,000–€60,000 plus equity, same apply address | `[grounded]` careers page, fetched |
| Mandate | First design hire; own the booking flow, run research with school owners, ship with two engineers | `[grounded]` posting |
| Market calibration | Tillerby 2026 Ireland design salary report (n=520): product designers with 3–5 years, median €57,000, interquartile range €51,500–€62,000. Their range sits inside that band | `[generic]` role-family sweep, search snippet only |
| Unknowns | Employment type; equity vesting and share class; who reviews design; how much research time is set aside | — |
| Contradictions | None between the posting, the careers page and the about page. Saoirse's CTO title is in the WhatsApp message; the pages I read don't state it | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year; stated, not inspected | `[grounded]` intake prose | none |
| R2 | Base salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | No pay floor was given, so the fit can't be judged | `[grounded]` posting | G1 |
| R3 | 3+ years product design | must_have | direct | medium | none | Four years stated; no portfolio inspected yet | `[grounded]` intake prose | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use stated | `[grounded]` intake prose | none |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions stated. Your customers were travel-booking users, not school owners; the method transfers, the audience is new | `[grounded]` intake; `[inferred]` on the audience gap | none |
| R6 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad stated | `[grounded]` intake prose | none |
| R7 | Owns the booking flow end to end | important | adjacent | medium | transferability | You redesigned checkout, the end of a booking flow. Limit: you didn't own discovery or the flow's start | `[inferred]` from the checkout work described | G2 |
| R8 | Works as the only designer (implied by "first designer") | important | adjacent | medium | transferability | Squad experience carries over; limit: no design peer ever to review your work | `[inferred]` from the posting's "first designer" | G2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay (R2, hard_gate) | hard_gate | The posted range is stated; your floor is not | Decides whether the pay gate is met | Your current or past salary, and what you'd need after tax | Your own figure | `[grounded]` posting; your answer decides it |
| G2 | Working alone (R7, R8, transferability) | transferability | You have owned checkout inside a squad, never a whole product area alone | The likely hard question for this role | Checkout decisions you made with four engineers and no design lead; research you ran without a second designer | The checkout case study, or a usability session summary | `[inferred]` from the squad history; `[generic]` that solo-designer roles test this directly |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope for one designer | risk_signal | medium | "own the booking flow end to end … ship alongside our two engineers" | One designer may carry product, research and delivery with no design review | `[inferred]` from the posting's scope against a six-person team | Who reviews design decisions day to day, and what does the designer's first six months look like? | unresolved |
| RR2 | Employment type not stated | unknown | — | (posting silent) | Could be permanent or contract; the posting doesn't say | `[grounded]` posting silence | Is this a permanent contract, and is there a probation period? | unresolved |
| RR3 | Equity terms not stated | unknown | — | "plus 0.5–1% equity" | Value depends on vesting, share class and the company's valuation; equity at a customer-funded company of this size is usually illiquid | `[generic]` for the illiquidity pattern; `[grounded]` posting figure | What is the vesting schedule and share class for this grant? | unresolved |
| RR4 | Consistent public footprint | positive_signal | — | "six people in Galway" (posting) matches about page | Transparency is good; the employer is established from its own pages | `[grounded]` fernquay.example, fetched | Who sets the booking-flow roadmap today? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Ask RR1–RR3 in the 45-minute call | These are the three open questions | `[grounded]` register | ready to use |
| P2 | Check the call invite comes from a fernquay.example address before joining | Routine step: the WhatsApp scheduling is routine; the invite should come from the company's own domain | `[grounded]` careers page apply address | advice |
| P3 | Bring the checkout case study to the call | Ronan has already seen it and said they liked it | `[grounded]` WhatsApp message | advice |

**Evidence status**

Verified: none yet. Your background is self-report at intake, so every claim is medium at most until you confirm specifics or share an artifact.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea kayak surf schools" and "Fernquay jobs Product Designer Galway"; fetched fernquay.example/careers/product-designer and fernquay.example/about. Moved the organization row, the contradictions row, and cleared the employer-not-established check: the company exists as described, and the posting is live |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway 3 years experience", which returned the Tillerby 2026 report (tillerby.example/2026-ireland-design-salary-report, snippet only). Moved the market calibration |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned a LinkedIn profile snippet (linkedin.example/in/ronan-kehoe). Moved the scope read; not fetched |

**Upgrade menu**

- Your pay floor → R2 closes and the decision becomes go or no_go on pay.
- A copy of the checkout case study, to check what you owned → R7 and R3 to high.
- A usability session summary → R5 to high.
- The employer's answers on employment type, equity and design ownership → RR1–RR3 close.
- A deeper pass on Fernquay (funding, hiring history, public employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

I can write this up as a `tuesday-dossier.md` you can keep and bring to the call.

**Questions**

G1 — What's the lowest base salary you'd accept?
G2 — Have you ever made design decisions on a flow or a research study with no other designer reviewing them? Examples to test your memory: a checkout or booking change you shipped and defended alone; a usability study you designed and ran without a second designer; a prototype you handed to engineers with no design lead.
G2 — Could you share the checkout case study Ronan mentioned, or a summary of one usability session?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

If you want to rehearse the 45-minute call, mock-interview can build that prep.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.