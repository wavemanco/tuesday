**Short answer:** Posting 1 (Duinvaart, Rotterdam) is worth applying to once you've confirmed the company is real. Posting 2 (Kroonhaven, Utrecht) isn't worth your time right now. I couldn't check either company online, because the web search was declined, so the company checks are still open.

## Posting 1: Operations Analyst, Duinvaart Cold Chain

**Decision: `conditional_go`. Apply once the employer checks out.**

**Fit ledger.**

- `hard_gate`: unclear: R8 (hybrid, three days a week in the Rotterdam office)
- `must_have`: direct: R1, R2, R3
- `important`: direct: R6 · unclear: R5 (temperature compliance)
- `preferred`: adjacent: R7 (Dutch)

R1–R3 and R6 are your strongest ground, and R5 is the one real gap. Your on-time dashboard work carries across directly. Temperature tracking doesn't appear anywhere in your background.

- **Hard gates:** none failed; unconfirmed: R8 (hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** the employer is unverified (RR1); no pay is stated (RR2); the scope of the temperature work is unclear (RR3).

**Evidence map** (your background is self-reported, so confidence tops out at `medium`)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier. A length requirement, so it's graded on fit, not treated as a gate | `[grounded]` your background | none |
| R2 | Strong SQL | must_have | direct | medium | none | SQL daily in your current role | `[grounded]` your background | none |
| R3 | Power BI or Tableau; weekly dashboards | must_have | direct | medium | none | Power BI daily; you built the on-time delivery dashboard depot managers use | `[grounded]` your background | none |
| R5 | Temperature compliance across the refrigerated fleet | important | unclear | none | discovery | Nothing in your background covers temperature data | `[grounded]` silence in your background | Question 2 |
| R6 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review, which depot managers used | `[grounded]` your background | none |
| R7 | Dutch (a plus) | preferred | adjacent | medium | transferability | Conversational, not fluent. Limit: you can't yet work in Dutch fluently | `[grounded]` your self-description | state it as conversational |
| R8 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | No constraint given yet | `[grounded]` the posting | Question 1 |

**Register.**

- **RR1 (employer not established, `severity: medium`, `status: unresolved`):** the search was declined, so I couldn't confirm this company exists as described. The pattern for companies this size is that a thin online footprint is common, and the posting is not a claim about this company. Verification question: "Can you point me at this role on Duinvaart's own careers page, and who would I be interviewing with?" Decision rule: verify before you spend application effort on it.
- **RR2 (pay not stated, `unknown`):** verification question: "What salary range is budgeted for this role?"
- **RR3 (temperature scope, `unknown`):** verification question: "What does temperature compliance involve day to day: sensor monitoring, reporting, or corrective action on the vehicles?"

**Research tier: L1 — searches 2 of 5, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was declined. Company existence and whether the posting is live are unchecked, so RR1 stays open |
| 2. Role-family sweep | unavailable | The search was declined. No salary or scope band, so RR2 has no benchmark |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Posting 2: Supply Planner, Kroonhaven Foods

**Decision: `no_go` as posted.**

**Fit ledger.**

- `hard_gate`: unclear: R7 (on-site in Utrecht)
- `must_have`: absent: R1, R2, R5 · adjacent: R4, R6 · unclear: R3

The reason is not the employer. Three of the must-haves (three years of planning, SAP IBP or a similar system, and capacity balancing) are absent from your background, and the posting asks for all three from day one. Fluent Dutch is also beyond your current level. Closing those gaps means a planning-adjacent role first, not a faster application.

- **Hard gates:** none failed; unconfirmed: R7 (on-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** the scope is clear and the responsibilities are well defined (RR2). The employer is unverified (RR1), the same as Posting 1.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You told me you've never worked in planning | `[grounded]` your statement | Closure path: a demand or planning analyst role |
| R2 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning-system use stated | `[grounded]` your background | Closure path: learn a planning tool on the job |
| R3 | Advanced Excel | must_have | unclear | none | discovery | Your Excel level isn't stated | `[grounded]` silence in your background | Question 3 |
| R4 | Own a 13-week plan and run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran the weekly route-performance review, a recurring cross-team review. Limit: no supply or production inputs, and no plan ownership | `[grounded]` your background; `[inferred]` the adjacency | Make the bridge and state its limit |
| R5 | Balance production capacity against forecast | must_have | absent | none | capability | No capacity or production work stated | `[grounded]` your background | Closure path: a planning analyst role |
| R6 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent | `[grounded]` your self-description | state it as conversational |
| R7 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No constraint given yet | `[grounded]` the posting | Question 1 |

**Register.** RR1 (employer not established) applies here too, with the same verification question: "Can you point me at this role on Kroonhaven's own careers page, and who would I be interviewing with?" RR2 is positive: the scope is well defined, and the posting names a 13-week horizon and a weekly S&OP cadence.

**Research tier: L1 — searches 2 of 5, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was declined. Company existence is unchecked |
| 2. Role-family sweep | unavailable | The search was declined. No salary or scope band |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier offer

If you want these two write-ups kept in one file you can reuse, I can build a `tuesday-dossier.md` from them.

## Upgrade menu

- Careers-page links, or the recruiter's email domain, for both companies → closes RR1 for each, and the decision can firm up.
- Any temperature, cold-chain, or food-safety records from the parcel carrier → R5 on Posting 1 moves off unclear.
- Your Excel level (pivot tables, lookups, basic forecasting) → R3 on Posting 2 resolves.
- Your commute limit or relocation range → R8 and R7 close for both postings.
- A salary range you need → RR2 on Posting 1 and the pay check for both postings.
- Re-running the company and salary searches once search permission is granted → unlocks both standing checks and the market bands.

## Questions

1. Where are you based, and how far can you commute? Three days a week in Rotterdam (Posting 1) and on-site in Utrecht (Posting 2) both depend on the answer.
2. At the parcel carrier, did you ever work with temperature, cold-chain, or food-safety data, even indirectly?
3. How comfortable are you with Excel: pivot tables, lookups, and basic forecasting?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.