**Decision snapshot**

Worth a call, not yet worth more: `conditional_go`. The fit is strong on the must-haves, but I could not check whether Fernquay is real and hiring, because web search was refused in this run. Nothing you pasted asks you for money or bank details, and the WhatsApp scheduling is routine.

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — unclear: R8 (First designer)

R7 — a bridge from checkout to the full flow, its limit named; R2 — a pay gate nobody has checked against your minimum; R8 (`low`) — open until you answer the first-designer question.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 — Fernquay confirmed on its own website and the company register, and the invite's sender domain matches it; (2) R2 — your minimum base salary is at or below €52,000; (3) R8 — you can answer the first-designer question concretely.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` the posting's own description; not checked |
| Mandate | Own the booking flow, run research calls with school owners, ship with two engineers | `[grounded]` JD |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` JD |
| Scope read | One designer across a whole booking flow with two engineers, and no design peers named | `[inferred]` from the JD's scope against a six-person headcount |
| Market calibration | Not run; no band for salary or equity | — (research unavailable) |
| Unknowns | Who sets product priorities; how the €52k–€60k and 0.5–1% equity were set; whether the flow is new or existing; the CTO's role in design | — |
| Contradictions | None visible between the posting and the WhatsApp message | `[grounded]` both texts |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway and moved back last year. Your own limits on office days are not stated, so this rests on location alone | `[grounded]` your background; JD | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | No minimum given, so the gate cannot be checked. The band itself is not calibrated | `[grounded]` JD figure; your floor not given | Question 1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a travel-booking company. CV-level, not probed | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily Figma use. No portfolio seen | `[grounded]` your background | Share a Figma link if you have one |
| R5 | Has run their own user research | must_have | direct | medium | none | Ran monthly usability sessions with customers. The audience differs (school owners), which is a limit to name, not a gap | `[grounded]` your background | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Owns the booking flow end to end | must_have | adjacent | medium | transferability | Redesigned the checkout flow, the nearest work you have. Checkout is one stage of a booking flow, and end-to-end ownership is not stated | `[inferred]` adjacency from the checkout work you described | Gloop-in G1 |
| R8 | Designs alone, as first designer, with no other designer to check work | important | unclear | low | discovery | Inferred from "you would be our first designer". You have never been the only designer; no design peers are described on your squad | `[inferred]` from the JD's "first designer" | Question 2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning the whole booking flow (R7, must_have) | transferability | Checkout redesign at a travel-booking company; nothing on search, availability or confirmation | This is the must-have the posting leans on hardest, and the one most likely to be probed | Any stage of a booking flow beyond checkout: search, date or availability rules, confirmation, cancellations | The checkout case study you sent the recruiter, with a line on what you did not own | `[grounded]` your background; `[inferred]` that this stage is probed |
| G2 | Designing without a design peer (R8, important) | discovery | Squad experience with engineers; no design peers described | The posting describes a role with no design colleague, which is a different working life | A feature you decided on alone; a usability study you acted on without review | A project write-up or the decision record | `[inferred]` from the JD's "first designer" |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources; research did not run, and your own search found little | risk_signal | medium | "We are six people in Galway" | Not checked here. A company this size may be young or small, or the posting may be stale | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the live posting on your careers page, and who would I be interviewing with? | unresolved |
| RR2 | Pay band not calibrated | unknown | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | The range may sit above or below what this title usually earns in Ireland; not checked here | `[grounded]` JD figure; band unchecked | How was the salary range set, and what does the equity cover? | unresolved |
| RR3 | Decision rights over the booking flow unknown | unknown | — | "own the booking flow end to end" | You may carry the flow's outcomes without setting its priorities or signing off design decisions | `[inferred]` from the scope language against the silence on decision rights | Who sets product priorities, and who signs off design decisions: you, Ronan, or Saoirse? | unresolved |
| RR4 | Specific, candid posting | positive_signal | — | "we would rather see one messy real project than a polished deck" | The scope is concrete, and the posting names the work and the interview panel | `[grounded]` JD | What does a typical week of research calls with school owners look like? | noted |

The WhatsApp scheduling and the emailed invite are routine and take no entry.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before replying, check Fernquay on its own website and the Companies Registration Office register, and check the invite's sender domain matches the company's | RR1 | Advice; no claim about the employer | for you to do |
| A2 | Reply to Ronan with a time, once A1 is done | RR1 | `[grounded]` the recruiter's message | pending your approval |
| A3 | On the call, lead with the checkout redesign and the monthly usability sessions. Describe the booking flow as adjacent to your checkout work, not as owned end to end | R5, R7 | `[grounded]` your background | pending your approval |
| A4 | Prepare an honest answer on being the only designer: what you would decide alone, and what you would want from the CTO | R8 | `[inferred]` from the JD | pending your approval |
| A5 | When the call is booked, the mock-interview module can prepare you for the 45 minutes | the call | — | — |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would have checked that Fernquay exists as described and that the posting is live (RR1). Web search was refused for this run |
| 2. Role-family sweep | unavailable | Would have set the market band for salary and equity (RR2). Web search was refused for this run |
| 3. Hiring manager's public footprint | unavailable | Would have checked Ronan Kehoe's public professional footprint before the call. Web search was refused for this run |

**Dossier offer:** I can emit a `tuesday-dossier.md` for this role when you want one to carry into the call prep.

**Upgrade menu**

- Your minimum base salary → R2 closes to `direct` or `hard_gate_fail`, and the status moves to `go` or `no_go`.
- Search access, if you allow it on a later turn → the three research targets above, which would settle RR1 and RR2 and let me check Ronan Kehoe's public footprint.
- A link to the checkout case study → R7's evidence becomes inspectable. It would still stop short of end-to-end ownership.
- A link or screenshot of a flow you designed alone → R8 closes, or stays a named gap.

1. Q for G2 / R8: Think of a time you owned a design decision with no other designer to review it. What did you decide, who did you check it with, and how did it turn out?
2. Q for G1 / R2: What is your minimum base salary, and does €52,000 meet it?
3. Q for RR1: Where did you see the posting, and which domain did the calendar invite come from?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.