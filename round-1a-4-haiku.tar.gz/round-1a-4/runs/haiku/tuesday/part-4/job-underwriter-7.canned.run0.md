**Yes, apply, on conditions.** The status is `conditional_go`: the clinical core matches well, the main gap is that you have never held a caseload, and two named skills (leg-ulcer care and Doppler) need a short check before interview.

## Decision snapshot

**Worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2, R3
- `must_have`: direct: R4, R5, R7, R9 · adjacent: R11, R12 · unclear: R6, R8, R10, R13
- `preferred`: absent: R14

R11 (own caseload) — transferability, the largest real gap; R6 (leg-ulcer care), R8 (continence care), R10 (end-of-life visits), R13 (written records and the electronic record) — not shown in the CV, so unverified; R14 (Doppler) — preferred only, closure path named.

**Opportunity ledger.** Well specified: pay is stated (RR1), caseload and senior support are described (RR2), and a named contact is offered (RR3). The employer is established by search (RR4, reduced). Open: contract type, hours, on-call and mileage (RR5), and leg-ulcer and Doppler exposure (RR6).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`). NMC registration and driving licence are stated, not checked; checking them is yours.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can show, in interview, a credible route to your own caseload with senior review (R11, RR2); (2) the leg-ulcer and Doppler position is clear (R6, R14, RR6); (3) contract type is confirmed as permanent or fixed-term, and the terms are known (RR5).
- **Candidate constraints:** not given. Checks against them are unknown.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, Halifax; adult community nursing under an NHS contract, four locality hubs, about 410 staff | `[grounded]` search result, calderbrookhealth.example/about (snippet read, page not opened) |
| Mandate | Caseload of housebound adults in their homes: wounds, catheters, continence, insulin, end-of-life, care planning, on the electronic record | `[grounded]` posting |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` posting |
| Market calibration | A 2026 survey of community staff nurses in England (n=1,240) puts median basic pay at £34,300 and the middle half at £32,400–£36,600. The posted range spans that middle half. | `[generic]` role-family survey, one source, not checked against official NHS pay tables |
| Working pattern | Caseload with senior community nurse support | `[grounded]` posting |
| Unknowns | Contract type, hours, on-call, mileage rate, electronic record system | — |
| Contradictions | None found between the posting and the company page | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | Stated on CV, active, revalidation March 2028; not checked | `[grounded]` CV | You check the NMC register |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated, category B; licence number not used | `[grounded]` CV | You check your licence status |
| R3 | Based in Halifax | hard_gate | direct | medium | none | Lives in Halifax; employer is in Halifax; visit area not stated | `[grounded]` CV and posting header | Ask area covered |
| R4 | At least one year post-registration | must_have | direct | medium | none | Five years as staff nurse | `[grounded]` CV | none |
| R5 | Wound care, including pressure ulcers and surgical wounds | must_have | direct | medium | none | Stated on CV; limited inspectable proof | `[grounded]` CV | none |
| R6 | Leg-ulcer care | must_have | unclear | low | discovery | Leg ulcers not named on CV | `[grounded]` CV silence | Q2 below |
| R7 | Catheter care | must_have | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R8 | Continence care | must_have | unclear | low | discovery | Not named on CV | `[grounded]` CV silence | Upgrade menu |
| R9 | Insulin administration | must_have | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R10 | End-of-life visits | must_have | unclear | low | discovery | Not named on CV; acute ward work may include it | `[grounded]` CV silence; `[generic]` acute-ward patterns | Upgrade menu |
| R11 | Care planning and holding own caseload | must_have | adjacent | medium | transferability | Discharge-to-assess visits give planning across the first week; no caseload held | `[inferred]` from CV | Q1 below |
| R12 | Home visits to housebound adults | must_have | adjacent | medium | transferability | Home visits in first week after discharge, 18 months; not ongoing housebound care | `[grounded]` CV | Upgrade menu |
| R13 | Clear, timely written records; electronic record | must_have | unclear | low | discovery | CV silent on records and electronic record system | `[grounded]` CV silence | Q3 below |
| R14 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No evidence on CV | `[grounded]` CV | Closure path in gap queue |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload (R11) | transferability | Discharge-to-assess visits; no caseload held end to end | Central to the role; likely probe | Any patient you followed beyond the first week; any plan you wrote and reviewed | Caseload description, a sanitised care plan | `[inferred]` from CV |
| G2 | Community home visits (R12) | transferability | Visits to patients in first week after discharge | Shows home practice, limited to short-term | Ongoing visits to patients at home, however brief | Visit log extract | `[grounded]` CV |
| G3 | Leg-ulcer care (R6) | discovery | Wound care on ward; leg ulcers not named | Named in posting; likely interview topic | Dressing, compression, or review of leg ulcers on any ward | Training record, competency sign-off | `[grounded]` CV; `[generic]` leg-ulcer work is common in community caseloads |
| G4 | Continence care (R8) | discovery | Catheter care shown; continence not named | Named in posting | Continence assessment, catheter review, bowel or bladder care | Competency record | `[grounded]` CV silence |
| G5 | End-of-life visits (R10) | discovery | Not named | Named in posting | Palliative or end-of-life care on the ward | Ward experience statement | `[grounded]` CV silence |
| G6 | Records and electronic record (R13) | discovery | Not named | Named as essential practice | Electronic record use on the ward | System name, audit example | `[grounded]` CV silence |
| G7 | Doppler (R14) | capability | None | Preferred only | Any Doppler training or use | Certificate if held | `[grounded]` CV; closure path `[generic]`: short courses are common |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and inside the survey's middle half | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Pay is transparent for this band | `[grounded]` posting; `[generic]` survey | Is the salary point fixed within the range, and how is mileage paid? | noted |
| RR2 | Caseload with senior support | positive_signal | — | "supported by a senior community nurse" | Structured start is likely | `[grounded]` posting | Who reviews my plans in the first months? | noted |
| RR3 | Named contact for informal chat | positive_signal | — | "contact Rhiannon Mabbott" | Open door before application | `[grounded]` posting | — | noted |
| RR4 | Employer not established | risk_signal | medium | "Calderbrook Community Health CIC" | Search attributed a real NHS-contract CIC; posting itself not checked against their careers page | `[grounded]` search snippet | Can you point me to this advert on your careers page? | reduced |
| RR5 | Contract type, hours, on-call, mileage not stated | unknown | — | (absent) | Terms may sit in the job pack | `[inferred]` from posting silence | Is this post permanent, what hours and on-call cover apply, and what is the mileage rate? | unresolved |
| RR6 | Team lead's public talks cover leg-ulcer clinics and Doppler | risk_signal | medium | Search result: 2025 forum talk on nurse-led leg-ulcer clinics and Doppler training | Interview likely probes both, and the lead may run them | `[inferred]` from published talk topics; `[generic]` probes follow posted skills | How is leg-ulcer assessment and Doppler training given to nurses new to community work? | unresolved |
| RR7 | Electronic record system and training not stated | unknown | — | (absent) | Training may be provided | `[inferred]` from posting silence | Which electronic patient record is used, and what training is given? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Keep the home-visit line near the top of your experience, in your words: "Seconded 18 months to discharge-to-assess team, visiting patients at home in their first week after discharge" | R12, G2 | `[grounded]` CV | resume_edits_pending_approval |
| E2 | Don't write "community nursing experience". Your work is first-week discharge visits, not a caseload. | Kind-shift risk on the reframing audit | `[grounded]` CV; audit | pending your approval |
| E3 | Interview line for the caseload gap: "I haven't held my own caseload. What I have done is visit patients at home in their first week after discharge, and I'd want senior support while I build one." Every clause traces to your CV or the posting. | G1, RR2 | `[grounded]` CV and posting | pending your approval |
| E4 | Chat with the team lead: ask about leg-ulcer training, Doppler, contract and electronic record | RR5, RR6, RR7 | `[grounded]` posting; `[inferred]` from talk topics | pending your approval |
| E5 | Check your NMC registration and licence status yourself before applying | R1, R2 | `[grounded]` CV | advice |

## Evidence status

Verified: none yet. Your CV claims stand at `medium`; the chat and any certificates would move them.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax"; the About page at calderbrookhealth.example/about came up (snippet read, page not opened). Moved the employer-established check (RR4). No careers page was found, so the posting is not confirmed live. |
| 2. Role-family sweep | yes | Searched "NHS Agenda for Change Band 5 pay scale 2026/27 annual salary range"; result was the Wardround 2026 community nursing pay guide. Moved the market calibration (RR1). |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook"; result was a forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). Moved RR6 and the chat questions in E4. |

## Upgrade menu

- Your NMC register entry and licence status, checked by you → R1 and R2 move from stated to confirmed.
- A leg-ulcer or wound competency record, or training certificate → R6 moves up, and R14 gets a real path.
- An end-of-life or continence example from the ward → R8 and R10 move from unclear.
- The electronic record system you used → R13 closes.
- The team's careers page link and the full job pack → RR4 closes; RR5 answered.
- A deeper research pass on Calderbrook (inspection reports, staff reviews; up to 5 more searches and 2 more fetches) — say the word and it runs.

Would you like a `tuesday-dossier.md` file of this assessment to keep?

1. Can you describe your secondment's patient contact beyond the first week: did you ever follow a patient over several visits and own their plan, or did someone else hold it?
2. Have you dressed, compressed or reviewed leg ulcers on any ward? Give the setting and what you did.
3. Which electronic patient record have you used, and how did you write up visits?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.