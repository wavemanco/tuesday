**Short answer:** Yes, asking for bank details, a PPS number and a passport scan is normal, but only after you've accepted a written offer. This offer does that in the right order: it names the role, the pay and the reporting line, and it asks you to accept first. Its onboarding details are routine. The one thing I could not check is that the company exists as described, because web search was refused in this session. Decision: `conditional_go`. Accept only after you've confirmed the company and the portal address through its own website.

**Fit ledger** (candidate fit, separate from the opportunity check)
- `must_have`: 2+ years payroll: R1 `direct` (3 years fortnightly, 90 staff). Payroll qualification: R2 `direct` (Payroll Technician 2024). Strong Excel: R3 `direct` (pivots, XLOOKUP).
- `must_have`: Irish PAYE, PRSI and USC: R4 `unclear` (your certificate is listed, but the regime it covers isn't stated).
- `important`: starters and leavers: R5 `direct`. Payroll-to-ledger reconciliation: R6 `direct`. Pension changes: R7 `absent` (your manager handled these).
- `important`: scale: R8 `adjacent` (240 staff against 90).

**Hard gates**
- `unconfirmed`: R9 (hybrid, two days a week in the Limerick office). Your home location isn't given.
- `met`: R10 pay in the stated band (`direct`, `[grounded]` from the posting, €40,000 within €38,000–€42,000). Your salary floor isn't given.
- Candidate constraints not given — checks against them unknown.

**Opportunity ledger.** Positive: a named role, a named manager, a stated salary, and two in-person interviews at the office. Open: the employer is unverified (RR1).

**Risk register**
- **RR1: Employer not verified** — `risk_signal`, `severity: medium`, `status: unresolved`. Provenance: `[generic]`. Hypothesis: the company may be too new or small to have much of an online footprint, the posting may be stale or aggregated, or it may not be a live hiring employer. I couldn't check any of these. Verification question: "Can you confirm this role is live on your careers page, and that people@marrowgatehousing.ie is your address?" Decision rule: confirm before you accept or enter anything.
- **RR2: Pension changes untested** — `unknown`, `status: unresolved`. Provenance: `[inferred]` from your CV. Verification question: "What pension process would I run in my first six months, and is there training or a handover?"

**Routine onboarding (no register entry):** the portal, bank details, PPS number and passport check. Enter details only in the portal at the address on the company's own website, not a link that arrived by email. Send a passport scan only through that portal, and keep the original for day one.

**Research tier: L1 — searches 2 of 5, fetches 0 of 2**

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | unavailable | Both searches were refused for permission this session. |
| 2. Role-family pay sweep | unavailable | Same refusal. |
| 3. Hiring manager's public footprint | unavailable | Search refused, so not sent. |

**Application plan.** You don't need to decide yet. Before accepting, reply to confirm the start date and ask for the portal address. Once you accept, use the address on the company's website to fill in the portal.

**Dossier offer:** If you'd like, I can write this into a `tuesday-dossier.md` for your records.

**Upgrade menu**
- Allow web search, and I'll check the company's site and the pay band (this moves RR1 and R10).
- Your home location, relative to Limerick (resolves R9).
- Your salary floor and notice period (completes the hard-gate checks and sets the start date).
- Your certificate's module list (shows whether R4 covers Irish PAYE, PRSI and USC).

**Questions**
1. Where do you live, and can you commute to Limerick two days a week?
2. What's your minimum salary, and what's your notice period?
3. Does your Payroll Technician certificate cover Irish PAYE, PRSI and USC?

Answer in text, paste the certificate's module list, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.