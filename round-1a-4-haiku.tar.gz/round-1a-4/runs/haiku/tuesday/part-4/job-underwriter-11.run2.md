## 1. Operations Analyst, Duinvaart Cold Chain (Rotterdam)

### Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.** Your SQL, Power BI and on-time delivery work match most of the list, and the posting is specific. The open items are the Rotterdam office schedule, which I can't check without your location, and the unstated salary.

**Fit ledger.**

- `hard_gate` — unclear: R1 (hybrid, three days a week in the Rotterdam office)
- `must_have` — direct: R2, R3, R4, R5, R7; adjacent: R6 (temperature compliance)
- `important` — adjacent: R8 (route changes)
- `preferred` — adjacent: R9 (Dutch)

R2–R5 and R7 are direct on your stated experience, at `medium` because nothing is inspected yet. R6 is adjacent: your KPI tracking carries over, but cold-chain temperature work isn't in your background. R8 and R9 are adjacent with their limits named in the map.

**Opportunity ledger.** The posting is clear on scope and outcomes (RA4), but it gives no salary (RA1) and doesn't say whether the analyst decides route changes or advises the depot managers who do (RA2). Employer existence is unverified (RA3); the web checks were refused, so that check did not run.

- **Hard gates:** unconfirmed: R1 (hybrid, three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the three-day Rotterdam office schedule works for you (R1, see G1 below); (2) the role's route-change authority is concrete when you ask (RA2); (3) the salary range is stated and acceptable (RA1); (4) the posting is confirmed on Duinvaart's own careers page (RA3).

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | `[grounded]` posting |
| Mandate | Track on-time delivery and temperature compliance; build weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | An analyst role with a defined KPI set; it doesn't say the analyst owns the fleet's routes | `[inferred]` from the verbs "track", "build", "work with" |
| Market calibration | Not run: the salary and role-family searches were refused | — |
| Unknowns | Salary; route-change decision rights; whether temperature data is in your tools today | — |
| Contradictions | None between the posting's sections | `[grounded]` posting |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | Your location and schedule limits weren't given, so this isn't settled | `[grounded]` posting | Ask G1 |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; self-reported | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | SQL used daily; no query shown yet | `[grounded]` your background | Upgrade menu: SQL sample |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Power BI used daily; no dashboard shown yet | `[grounded]` your background | Upgrade menu: screenshot |
| R5 | Track on-time delivery | must_have | direct | medium | none | You built the on-time dashboard depot managers used | `[grounded]` your background | none |
| R6 | Track temperature compliance across a refrigerated fleet | must_have | adjacent | low | transferability | KPI tracking carries over; cold-chain temperature data doesn't appear in your background. Limit: no claimed cold-chain exposure | `[inferred]` adjacency from KPI tracking | Upgrade menu: any temperature or sensor data work |
| R7 | Build weekly dashboards in Power BI | must_have | direct | medium | none | Dashboards for depot managers are in your background | `[grounded]` your background | none |
| R8 | Work with depot managers on route changes | important | adjacent | medium | transferability | You ran the weekly route-performance review; the posting's role changes routes, which you haven't said you did. Limit: review, not changes | `[inferred]` from the review and the posting | Upgrade menu: a route change your review drove |
| R9 | Dutch (a plus) | preferred | adjacent | medium | transferability | Conversational, not fluent; state it as conversational | `[grounded]` your background | none |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| GA1 | Temperature compliance (R6, must_have) | transferability | KPI tracking is clear; cold-chain temperature work isn't | The one must-have without a direct match; a closer bridge narrows it | A temperature or sensor dataset you analysed, or a cold-chain course | `[inferred]` bridge from your KPI work |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RA1 | Salary not stated | unknown | — | (no salary in posting) | The figure may sit outside the band you expect, or the employer may not publish it | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RA2 | Route-change authority unclear | unknown | — | "work with depot managers on route changes" | The analyst may advise on route changes rather than decide them | `[inferred]` from the verb "work with" | Which route changes does this role decide itself, and which go to depot managers? | unresolved |
| RA3 | Employer not established | risk_signal | medium | (posting's own identifying language) | Pattern for companies of this size: too new or small for a footprint, a stale posting, or not a live hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this posting on Duinvaart's own careers page, and who would I interview with? | unresolved |
| RA4 | Clear scope and named measures | positive_signal | — | "Track on-time delivery and temperature compliance" | The role's success is measurable from day one | `[grounded]` posting | How are on-time and temperature results reviewed today, and by whom? | noted |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter for the salary range before the first interview | RA1 | `[grounded]` RA1 | pending your approval |
| A2 | Confirm the posting on Duinvaart's careers page before applying | RA3 | `[generic]` standing entry | pending your approval |
| A3 | Put your on-time dashboard work first in your CV, with only figures you can confirm | R5, R7 | `[grounded]` your background | pending your approval |

### Evidence status

Verified: none yet. Every claim above is self-reported and `medium` at best until you show an artifact.

---

## 2. Supply Planner, Kroonhaven Foods (Utrecht)

### Decision snapshot

**Not worth your time right now. Status: `no_go`.** The role needs 3+ years of FMCG planning and an SAP IBP-type system, and your background has neither. Your analytics and meeting experience are real but don't close those requirements. Your Dutch is adjacent, not fluent, and the posting says fluent.

**Fit ledger.**

- `hard_gate` — unclear: R1 (on-site in Utrecht)
- `must_have` — adjacent: R5 (fluent Dutch); unclear: R3 (advanced Excel); absent: R2 (3+ years FMCG planning), R4 (SAP IBP or similar)
- `important` — adjacent: R6 (13-week supply plan, capacity against forecast), R7 (weekly S&OP meeting)

R2 and R4 are absent. R3 is unclear because Excel isn't in your background. R5 is adjacent: conversational Dutch against a fluent requirement. R6 and R7 are adjacent: forecasting and running a weekly review are near the work, but not the work itself.

**Opportunity ledger.** The posting is clear about the job (RB2), but it doesn't say whether a planning-experienced hire is required from day one, and it gives no salary (RB3). Employer existence is unverified (RB1); the check was refused.

- **Hard gates:** unconfirmed: R1 (on-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** three years of supply or demand planning, or hands-on time in a planning system such as SAP IBP. Neither can be gained in time for this application.

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your location wasn't given | `[grounded]` posting | Ask G1 |
| R2 | 3+ years of FMCG supply or demand planning | must_have | absent | medium | transferability | You've never worked in planning (stated). Adjacent analytics work exists, but it isn't planning | `[grounded]` your statement | Upgrade menu: any forecasting or capacity work |
| R3 | Advanced Excel | must_have | unclear | low | discovery | Not mentioned in your background | `[grounded]` CV silence | Ask G2 |
| R4 | SAP IBP or similar planning system | must_have | absent | medium | capability | No planning system in your background | `[grounded]` CV silence and your statement | none: closure would take time |
| R5 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent | `[grounded]` your statement | none; state it as conversational |
| R6 | Own the 13-week supply plan; balance capacity against forecast | important | adjacent | low | transferability | Ops analysis and forecasting-adjacent work; no planning ownership. Limit: analysis, not decisions | `[inferred]` from the route-performance work | Upgrade menu: a planning or capacity example |
| R7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran the weekly route-performance review | `[grounded]` your background | none |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| GB1 | Planning experience (R2, must_have) | transferability | Analytics and meeting work exist; no planning | Decides the application | A planning-adjacent project: forecast accuracy, a capacity model, or an S&OP pack | `[generic]` that planning hires screen for direct planning experience |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RB1 | Employer not established | risk_signal | medium | (posting's own identifying language) | Pattern for companies of this size: footprint too thin, a stale posting, or not a live employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this posting on Kroonhaven's careers page, and who would I interview with? | unresolved |
| RB2 | Owner role from day one | unknown | — | "Own the 13-week supply plan" | The role may expect a ramp-up, or may not | `[inferred]` from "own" against the 3+ years requirement | Is this a hands-on planning owner from the start, or is there a ramp-up? | unresolved |
| RB3 | Salary not stated | unknown | — | (no salary in posting) | The figure may not be published | `[inferred]` from posting silence | What salary range is budgeted for this role? | unresolved |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| B1 | Spend this week's application effort on roles that match your analytics background | R2, R4 | `[generic]` role-family pattern | pending your approval |
| B2 | If a planning-adjacent role comes up, apply to that first | R2, R6 | `[inferred]` from the gap queue | pending your approval |

### Evidence status

Verified: none yet. Both roles' employer checks and salary calibrations were refused, so nothing about either employer is established.

**Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page (both employers) | unavailable | Every search was refused (web search permission not granted). Would have confirmed both employers and the postings. RA3 and RB1 stay unresolved |
| 2. Role-family sweep (both roles) | unavailable | Every search was refused. Would have set the salary bands in RA1 and RB3 |
| 3. Hiring manager's public footprint | n/a | No name given, so there was no query to form |

---

### Upgrade menu

- A screenshot of your Power BI on-time dashboard, with identifying details removed, or a SQL query you wrote → R3 and R4 move to `high`, and it helps for role 1.
- Confirmed Rotterdam or Utrecht commute → R1 closes for both roles.
- A temperature or sensor data example, or a cold-chain course → R6 (role 1) moves.
- A forecasting or capacity example, even outside your job → R2 and R6 (role 2) move.
- Web search permission → the employer, posting and salary checks run for both roles (up to 5 searches and 2 fetches). After that, a deeper pass is available (up to 5 more searches and 2 more fetches).

Would you like me to write these two assessments into a `tuesday-dossier.md` you can keep for your prep?

**Questions**

- G1 (R1, role 1): Where do you live, and is three days a week in the Rotterdam office workable? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- G2 (R2, R3, role 2): Have you ever done demand, supply or capacity planning, even part of a job, such as forecasting, capacity work, running a planning meeting, or using a planning tool? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- Pay (RA1, RB3): What's the lowest salary you'd consider? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.