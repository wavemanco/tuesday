**Worth taking the call: `conditional_go`.** Your stated experience matches most of the requirements. The open risks are that you would be the only designer, and that I could not verify that Fernquay exists. Web search was refused in this session, so I did not check the company, the live posting, or Ronan Kehoe's public footprint.

**Fit ledger**

- `hard_gate`: none stated by the posting. Your constraints were not given, so checks against them are unknown.
- `must_have`: direct R1, R2, R3, R4 · adjacent R5 (own the booking flow end to end)
- `important`: unclear R6 (first and only designer) · adjacent R7 (school-owner research)
- `preferred`: adjacent R8 (booking software domain)

R5 — checkout is one step of a booking flow, not the whole flow. R6 — you have only ever worked in a squad. R7 — your research was with end customers, not business owners.

**Opportunity ledger.** The posting shows no red flags. Pay and equity are stated, the hybrid pattern is stated, and nothing asks for money or bank details. Unknowns: equity terms (vesting, strike price, share count), whether the €52–60k sits within the Galway market (not checked), and the company's funding. The standing employer-not-established entry (OR1) applies because nothing could be verified here. It caps the decision at `conditional_go`.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay and the role verify on its own website; (2) the equity terms are concrete; (3) you are comfortable being the only designer, which the call should test.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people, Galway, booking software for sea-kayak and surf schools | `[grounded]` posting, unverified |
| Mandate | First designer: own the booking flow, run school-owner research, ship with two engineers | `[grounded]` posting |
| Working pattern | Two office days in Galway (where you live), otherwise remote | `[grounded]` posting and your statement |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Market calibration | Not run; research refused | — |
| Contacts | Recruiter-side call via WhatsApp, then a calendar invite with a video link; CTO Saoirse on the call | `[grounded]` message |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Next action |
|---|---|---|---|---|---|---|---|
| R1 | 3+ years product design | must_have | direct | medium | none | Four years at a travel-booking company, self-reported, no artifact inspected | none |
| R2 | Strong Figma | must_have | direct | medium | none | Daily use, self-reported | none |
| R3 | Ran own user research | must_have | direct | medium | none | Monthly usability sessions with customers | Share a sanitised research plan |
| R4 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad | none |
| R5 | Owns booking flow end to end | must_have | adjacent | medium | transferability | Redesigned checkout only; no end-to-end ownership | Sanitised case covering the whole flow |
| R6 | Sole designer, sets direction alone | important | unclear | low | discovery | Never the only designer | Question G1 |
| R7 | School-owner (B2B) research | important | adjacent | low | transferability | Customer research, not owner research | Question G3 |
| R8 | Booking software domain | preferred | adjacent | medium | transferability | Travel booking carries over; schools differ | none |

**Gap recovery queue**

- **G1 (R6, discovery):** No evidence of solo direction-setting. Closes with one concrete example.
- **G2 (R5, transferability):** Checkout is one step. The limit is that you have not owned a whole flow. The strengthener is a sanitised case covering the full booking path.
- **G3 (R7, transferability):** Customer research carries over; owner research does not yet show.

**Risk register**

| # | Signal | Class | Severity | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|
| OR1 | Employer not established from attributable sources | risk_signal | medium | The company may be too new or small to have a footprint, the posting may be stale, or it may not be a hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to the role on your own careers page, and who would I be interviewing with? | unresolved |
| OR2 | Equity terms unstated | unknown | — | Equity may be options with vesting and a strike price, or may be worth little | `[inferred]` from the posting's silence on terms | What type of equity is this, what is the vesting schedule, and how many shares are in the pool? | unresolved |
| OR3 | Solo role with no design peer | unknown | — | You would carry the product's design decisions alone | `[inferred]` from "first designer" | Who reviews design decisions, and what has the team shipped without a designer? | unresolved |

**Application plan (proposed, pending your approval)**

- Before the call, find Fernquay's own website and check that the role appears on its careers page. Check that the calendar invite comes from the company's domain and that the video link goes to a known platform. Check that Ronan and Saoirse's names match the company's own pages or public LinkedIn profiles. This is advice, not a finding about anyone.
- On the call, ask OR2 and OR3.
- Share only a sanitised case study. Do not send ID, bank details or your PPS number before a written offer, and enter any onboarding details only in the employer's own portal.

**Evidence status.** Verified: none yet. Your background is self-report until an artifact is inspected.

**Research tier: L1 — searches 4 of 5, fetches 0 of 2; all calls refused**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Fernquay were refused. Would have checked that the company exists and the role is live. |
| 2. Role-family sweep | unavailable | The salary and scope search was refused. Pay is uncalibrated. |
| 3. Hiring manager's public footprint | unavailable | The search for Ronan Kehoe was refused. Saoirse has no surname given, so she was not searched. |

I did not retry after the refusal or look for another route.

**Upgrade menu**

- Search access granted: targets 1–3 run. This confirms the company and posting, calibrates the €52–60k, and checks Ronan's public professional footprint.
- Equity terms in writing: OR2 closes or becomes a question for the call.
- Your constraints (pay floor, office days, contract type): the hard-gate checks run.
- A sanitised whole-flow work sample: R5 moves from `adjacent` toward `direct`.

If you want, I can write this into a `tuesday-dossier.md` for the interview prep.

1. **G1:** Have you ever made a product direction call with no design peer to check it? What was it, and what happened?
2. **G2:** What are your floors on pay, office days and contract type? Without them, the hard-gate checks stay unknown.
3. **G3:** Have you ever interviewed business owners rather than end customers? If so, how many, and about what?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.