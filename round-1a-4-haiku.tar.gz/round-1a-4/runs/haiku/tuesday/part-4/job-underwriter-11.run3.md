**Short answer:** Duinvaart is worth applying to, with conditions. Kroonhaven isn't worth your time right now.

**Duinvaart Cold Chain (Operations Analyst): `conditional_go`.** Your core experience matches the role closely.
**Kroonhaven Foods (Supply Planner): `no_go`.** Two must-have requirements are planning experience you don't have, and the gap can't be closed quickly.

Web search was refused on this run, so I couldn't check either employer exists or find pay bands. Both are open items below.

---

## Duinvaart Cold Chain, Operations Analyst

### Decision snapshot

**Status: `conditional_go`.** Apply, once you've confirmed the Rotterdam schedule works for you and the employer checks out.

**Fit ledger**
- `hard_gate`: unclear: D-R1 (three days a week in the Rotterdam office)
- `must_have`: direct: D-R2 (2+ years in logistics or operations analysis), D-R3 (strong SQL), D-R4 (Power BI or Tableau, weekly dashboards)
- `important`: direct: D-R5 (on-time delivery tracking), D-R7 (working with depot managers); adjacent: D-R6 (temperature compliance), D-R8 (route changes)
- `preferred`: adjacent: D-R9 (Dutch)

D-R2, D-R3 and D-R4 are confirmed, but only by your own account. D-R6 is a credible bridge with its limit named. D-R8 is also a bridge, from the route-performance review.

- **Hard gates:** none failed; unconfirmed: D-R1 (three days a week in the Rotterdam office); candidate constraints not given. Checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) D-R1 holds: the three-day Rotterdam schedule is workable for you. (2) RR2 clears: you confirm the role on Duinvaart's own careers page. (3) D-R6 is framed as threshold-KPI experience, never as cold-chain experience.
- **What would change this:** a no on D-R1 makes this `no_go`, since a failed gate is not a judgment call. A confirmed salary below your floor would also change the picture, but none is stated.

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam. The posting is the only source; the employer was not checked | `[grounded]` JD; employer check refused |
| Mandate | Track on-time delivery and temperature compliance across a refrigerated fleet, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in Rotterdam | `[grounded]` JD |
| Pay and contract | Not stated | `[grounded]` JD silence |
| Market calibration | Not done. The role-family pay search was refused, so there's no band | — |
| Unknowns | Salary; contract type; whether the cold-chain measures are owned by this role or by depot managers | `[grounded]` JD silence |
| Contradictions | None checkable from one source | — |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D-R1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | Schedule and location are gate terms. Your constraints weren't given, so this can't be checked | `[grounded]` JD; you're silent | Q1 |
| D-R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier. Self-reported, no artifact yet | `[grounded]` your background | none |
| D-R3 | Strong SQL | must_have | direct | medium | none | Daily SQL use. "Strong" is the claim an interviewer will probe | `[grounded]` your background | Prepare a SQL example from your work |
| D-R4 | Power BI or Tableau; weekly dashboards | must_have | direct | medium | none | Daily Power BI use, including the on-time dashboard depot managers used | `[grounded]` your background | none |
| D-R5 | Track on-time delivery | important | direct | medium | none | You built and ran this dashboard | `[grounded]` your background | none |
| D-R6 | Temperature compliance across a refrigerated fleet | important | adjacent | medium | transferability | Transferable: monitoring delivery KPIs against thresholds. Limit: no temperature or cold-chain data in your background | `[inferred]` bridge from your parcel KPI work | Bridge case: threshold KPIs, not cold-chain experience; Q3 |
| D-R7 | Working with depot managers | important | direct | medium | none | Depot managers used your dashboard | `[grounded]` your background | none |
| D-R8 | Route changes | important | adjacent | medium | transferability | You ran the weekly route-performance review. Your background doesn't show you proposed or made route changes | `[inferred]` from the review you ran | Note whether route changes were yours to propose; if so, give an example |
| D-R9 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational, not fluent. Preferred, so not a gate | `[grounded]` your background | State it as conversational |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | What would close it | Provenance |
|---|---|---|---|---|---|
| G-D1 | Schedule (D-R1, hard_gate) | hard_gate | Schedule is a gate term; your constraints weren't given | Your answer to Q1 | `[grounded]` JD |
| G-D2 | Temperature compliance (D-R6) | transferability | Threshold-KPI work; no temperature or cold-chain data | A temperature or threshold report you've seen or worked with; Q3 | `[inferred]` bridge |
| G-D3 | Route changes (D-R8) | transferability | Review work; no stated decision rights over routes | A route change you proposed and what happened | `[inferred]` bridge |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| D-RR1 | Salary and contract type not stated | unknown | — | "Hybrid, three days a week in our Rotterdam office." | Pay and contract terms are missing, so there's no band to check against | `[grounded]` JD silence | "What is the salary range and contract type for this role?" | unresolved |
| D-RR2 | Employer not verified | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | `[generic]` pattern for companies of this size, not a claim about this one. The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | — | "Can you point me to this role on your own careers site, and who would I be interviewing with?" | unresolved |
| D-RR3 | Cold-chain scope not evidenced | unknown | — | "Track on-time delivery and temperature compliance across our refrigerated fleet" | The role may own cold-chain monitoring that your background doesn't cover | `[inferred]` from the JD's scope against your background | "What temperature data does this role own today, and what happens when a vehicle goes out of range?" | unresolved |
| D-RR4 | Concrete scope with named measures | positive_signal | — | "build weekly dashboards in Power BI" | The role is measurable, not a vague mandate | `[grounded]` JD | "Which of these measures does this role own alone, and which go to depot managers?" | noted |

D-RR2 is the standing entry. It caps the decision at `conditional_go`: verify the employer before you invest in the application.

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| D-A1 | Check the live posting on Duinvaart's own careers site before applying | D-RR2 | `[grounded]` the standing entry | pending your approval |
| D-A2 | Lead your CV with the on-time dashboard and the route-performance review | D-R4, D-R5, D-R8 | `[grounded]` your background | pending your approval |
| D-A3 | Describe cold-chain as "tracked delivery KPIs against thresholds", not as cold-chain experience | D-R6 | `[grounded]` your background; the reframing audit rules out a stronger claim | pending your approval |
| D-A4 | Describe Dutch as conversational on the CV and in the interview | D-R9 | `[grounded]` your background | pending your approval |

---

## Kroonhaven Foods, Supply Planner

### Decision snapshot

**Status: `no_go`.** Not now. The gaps are in the core of the role, and closing them takes years, not a course.

**Fit ledger**
- `hard_gate`: unclear: K-R1 (on-site in Utrecht)
- `must_have`: adjacent: K-R4 (weekly S&OP meeting), K-R7 (fluent Dutch); unclear: K-R6 (advanced Excel); absent: K-R2 (3+ years FMCG planning), K-R3 (13-week plan and capacity balancing)
- `important`: absent: K-R5 (SAP IBP or similar planning system)

K-R2 and K-R3 are capability gaps: you have no planning history to build on. K-R4 is a bridge from the weekly route-performance review, with its limit named. K-R7 is conversational Dutch against a fluent bar.

- **Hard gates:** none failed; unconfirmed: K-R1 (on-site in Utrecht); candidate constraints not given. Checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** you have forecasting or capacity-planning ownership that isn't in your background. The employer accepts a planning-adjacent background instead of 3+ years. Either would move the decision to `hold_pending_answers`.

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht. Employer not checked | `[grounded]` JD; employer check refused |
| Mandate | Own the 13-week supply plan for chilled ready meals, balance capacity against the forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Pay | Not stated | `[grounded]` JD silence |
| Market calibration | Not done; the pay search was refused | — |
| Unknowns | Salary; language of the S&OP meeting | `[grounded]` JD silence |
| Contradictions | None checkable from one source | — |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K-R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Location is a gate term. Your constraints weren't given | `[grounded]` JD | Q1 |
| K-R2 | 3+ years FMCG supply or demand planning | must_have | absent | medium | capability | You've said you have no planning experience, and nothing in your background is planning work. Closure path: planning-adjacent roles first (demand analyst, S&OP coordinator) | `[grounded]` your statement; the closure path is `[generic]` | none for this posting |
| K-R3 | 13-week supply plan; balancing capacity against forecast | must_have | absent | medium | capability | Not in your background. SQL and dashboards aren't planning work | `[grounded]` your statement | none for this posting |
| K-R4 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: no supply or production side, and no demand decisions | `[inferred]` bridge from the review | State the limit plainly |
| K-R5 | SAP IBP or similar planning system | important | absent | none | capability | No planning system in your background. Closure: a course gets you basic use, not the planning judgment | `[grounded]` your background | none for this posting |
| K-R6 | Advanced Excel | must_have | unclear | none | discovery | Your background names SQL and Power BI, not Excel | `[grounded]` your background | Q2 |
| K-R7 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent. Limit: running a meeting or planning in Dutch | `[grounded]` your background | State it as conversational |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | What would close it | Provenance |
|---|---|---|---|---|---|
| G-K1 | Planning experience (K-R2, K-R3) | capability | No planning history | Planning-adjacent work for a year or more, then this role | `[grounded]` your statement; `[generic]` the path |
| G-K2 | Excel (K-R6) | discovery | Not stated | Your answer to Q2 | `[grounded]` your background |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| K-RR1 | Salary not stated | unknown | — | (the posting states no salary) | No band to check against | `[grounded]` JD silence | "What is the salary range for this role?" | unresolved |
| K-RR2 | Employer not verified | risk_signal | medium | "Kroonhaven Foods, Utrecht" | `[generic]` pattern for companies of this size, not a claim about this one. The entity may be too new or small, the posting may be stale or aggregated, or it may not be a real hiring employer | — | "Can you point me to this role on your own careers site, and who would I be interviewing with?" | unresolved |
| K-RR3 | Working language of the S&OP meeting | unknown | — | "run the weekly S&OP meeting" with "fluent Dutch" required | The meeting may run in Dutch, which would make the Dutch gap a working problem | `[inferred]` from the Dutch requirement against the meeting | "Is the S&OP meeting run in Dutch, and how much of the planning material is in Dutch?" | unresolved |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| K-A1 | Don't apply to this role now | K-R2, K-R3 | `[grounded]` the rows above | pending your approval |
| K-A2 | Target planning-adjacent roles first (demand analyst, S&OP coordinator, supply analyst), then return to planner roles | K-R2, K-R3 | `[generic]` the usual path into planning | pending your approval |

---

## Shared

**Evidence status**
Verified: none yet. Everything about your background is self-reported and hasn't been probed. Unverified leads: none. Rejected inferences: none.

**Research tier:** L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for both employers were refused, so neither employer's existence nor the live postings are checked. Would have moved D-RR2 and K-RR2 |
| 2. Role-family sweep | unavailable | The pay searches were refused, so there's no market band for either role. Would have set the calibration and pay expectations |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you want the employer checks and the pay bands, grant web search and I'll run them on the next pass.

I can write this assessment out as a `tuesday-dossier.md` you can keep and reopen.

**Upgrade menu**
- A live posting link or careers-page listing for Duinvaart → D-RR2 clears or stays open.
- A live posting link or careers-page listing for Kroonhaven → K-RR2 clears or stays open.
- A pay range or budget for each role → D-RR1 and K-RR1 close, and the pay can be set against a band.
- Your home area and commute limit → D-R1 and K-R1 move from `unclear` to met or failed.
- A temperature or threshold report you've worked with, even a screenshot → D-R6 moves from `medium` toward `high`.
- An example of an Excel forecast or pivot model you built → K-R6 becomes direct or adjacent.

**Questions**

1. **D-R1 and K-R1:** Can you work from the Rotterdam office three days a week and on-site in Utrecht? Where are you starting from?
2. **K-R6:** How would you rate your advanced Excel? Could you build a forecast with lookups, pivot tables and scenario tables without help?
3. **D-R6:** Have you worked with temperature, cold-chain or threshold-compliance data, even in a vehicle or depot setting?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.