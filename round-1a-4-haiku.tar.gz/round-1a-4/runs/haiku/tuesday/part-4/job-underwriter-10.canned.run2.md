**Yes, apply. Fernquay looks like a real, small company, and its own site matches the posting. Status: `conditional_go`.** The WhatsApp message is ordinary for a six-person team arranging a call, and it asks nothing of you.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea kayak surf schools" and "Fernquay Product Designer careers"; fetched fernquay.example/careers/product-designer and fernquay.example/about. Employer exists as described; posting is live and matches the posting you pasted |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3 years experience startup", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Sets the market calibration |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned his profile (linkedin.example/in/ronan-kehoe). Sets the scope read and positioning |

## Decision snapshot

**Fit ledger**
- `hard_gate`: direct R8; unclear R9 (pay floor against €52,000–€60,000)
- `must_have`: direct R1 (3+ years product design), R3a (own user research), R4 (working directly with engineers); adjacent R5 (own the booking flow end to end)
- `important`: direct R2 (strong Figma); adjacent R3b (research with school owners); absent R6 (working as the only designer)
- `preferred`: adjacent R7 (booking software for activity operators)

R5 is adjacent: checkout is one stage of the flow. R6 is absent: you have not been the only designer. R9 is open because your pay floor isn't in the material.

- **Hard gates:** none failed (R8 `direct`); unconfirmed: R9 (pay floor against the posted band); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** the employer is established from its own site, and the pay and scope are stated plainly, which counts in its favour. Open items are the equity terms (RR1) and a design seat with no design peers (RR2).
- **What would change this:** conditions for `conditional_go`: (1) booking-flow ownership holds beyond checkout (R5); (2) you can work without design peers (R6, RR2); (3) the equity and pay terms are acceptable to you (RR1, R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, makes Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland; founded 2023 | [grounded] about page, fetched |
| Mandate | First design hire: own the booking flow, run research with school owners, ship with two engineers | [grounded] posting; careers page matches |
| Working pattern | Hybrid, two days a week in Galway | [grounded] posting; careers page matches |
| Pay | €52,000–€60,000 plus 0.5–1% equity | [grounded] posting; careers page matches |
| Market calibration | Product designers with 3–5 years in Ireland: median €57,000, interquartile range €51,500–€62,000 (one 2026 report, n=520). The posted band sits in the middle of that range | [generic] role-family sweep; [grounded] posting figure |
| Unknowns | Equity instrument, vesting and strike price; the team's budget for research and tools | — |
| Contradictions | The about page names Saoirse Doyle as co-founder; your note calls her CTO. Both can be true, so confirm on the call | [grounded] about page |

Ronan's public profile lists him as co-founder and CEO, previously product lead for five years at a Galway travel-software company [grounded] profile.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product design | must_have | direct | medium | none | Four years stated in prose; no CV seen, so medium is the ceiling | [grounded] your statement | Send the CV to confirm titles and dates |
| R2 | Strong Figma | important | direct | medium | none | Daily use stated; no file to inspect | [grounded] your statement | Attach one Figma file if you can |
| R3a | Own user research | must_have | direct | medium | none | Monthly usability sessions with customers | [grounded] your statement | none |
| R3b | Research calls with school owners | important | adjacent | medium | transferability | Same method, different customer: operators rather than travellers | [inferred] from your travel-booking work | Name any operator or B2B customer you interviewed |
| R4 | Working directly with engineers | must_have | direct | medium | none | Four-engineer squad | [grounded] your statement | none |
| R5 | Own the booking flow end to end | must_have | adjacent | medium | transferability | Checkout redesign is one stage; end-to-end ownership not stated; limit: consumer checkout, not operator booking | [grounded] checkout work; [inferred] that end-to-end ownership is the gap | Q2 |
| R6 | Work as the only designer ("first designer") | important | absent | medium | transferability | You have never been the only designer; squad work carries over, but peer review and sole priority-setting do not | [inferred] from the posting's "first designer" | Q1 |
| R7 | Booking software for activity operators | preferred | adjacent | medium | transferability | Travel booking is the nearest match, not the same domain | [inferred] from your background | none |
| R8 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year | [grounded] your statement | none |
| R9 | Pay against your floor (€52,000–€60,000) | hard_gate | unclear | none | hard_gate | Your floor isn't given, so the check is open | [grounded] posting | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Booking flow end to end (R5, must_have) | transferability | Checkout redesign only | A case study of the full flow, or a clear account of which stages you owned | [grounded] your checkout work |
| G2 | Working without design peers (R6, important) | transferability | Squad of engineers; no stated design peers or sole-designer work | An account of who reviewed your design decisions, and what you decided alone | [inferred] from the posting's "first designer" |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity terms unstated | unknown | — | "0.5–1% equity" | The value of 0.5–1% can't be judged without the instrument, vesting and strike price | [inferred] from the posting's silence on these | What instrument is the equity, what is the vesting schedule and strike price, and what happens to unvested equity if I leave? | unresolved |
| RR2 | Sole design seat | risk_signal | low | "our first designer" | You may carry design alone, with no design peer review, and priorities may come from two engineers and a co-founder | [inferred] from team size against the scope listed | Who sets the design team's priorities, and who reviews design decisions? | unresolved |
| RR3 | Terms match across sources | positive_signal | — | "€52,000–€60,000 plus equity" | The posting and the careers page state the same terms, and the pay sits mid-band | [grounded] posting and careers page; [generic] band | What does the first year look like for the first design hire? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the checkout redesign and the monthly usability sessions; present checkout as the first slice of the booking flow, not the whole flow | see R3a, R5 | [grounded] your background | pending your approval |
| E2 | Pick one real project to send with your application, and name exactly which part was yours | the careers page asks for one real project | [grounded] careers page | pending your approval |
| E3 | Ask RR1 and RR2 verbatim on the call | the register doubles as interview prep | [grounded] register | pending your approval |
| E4 | Check that the calendar invite came from a fernquay address; this is advice only, and the chat message itself is routine scheduling | the careers page uses fernquay.example | [grounded] careers page | pending your approval |

Once the call is booked, mock-interview can prepare you for the 45 minutes with Ronan and Saoirse.

## Evidence status

Verified: none yet. Your background is prose, so it counts as self-report until you confirm specifics.

## Upgrade menu

- Your CV, or the checkout case study Ronan mentioned, with the flow's full scope → R1, R3a and R5 move toward `high`.
- The equity terms and the pay band in writing → RR1 and R9 close.
- Deeper research on Fernquay (funding, past customers, staff reports; up to 5 more searches and 2 more fetches) → say the word and it runs.
- If you want this as a file to keep, I can write it up as a tuesday-dossier.md.

## Questions

R6 — Did you ever have design peers on your squad, and who reviewed your design decisions?

R5 — Did you own the booking flow beyond checkout, such as search, selection or confirmation?

R9 — What is your pay floor? If it's above €52,000, what would change that?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.