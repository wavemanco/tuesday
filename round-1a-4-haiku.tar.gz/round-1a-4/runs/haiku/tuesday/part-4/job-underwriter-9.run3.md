**Yes, that's normal.** After a written offer that names the role and pay, Irish employers routinely collect bank details for salary, PPS for Revenue, and a passport or right-to-work check. What matters is where you enter them. **Status: `conditional_go`**: accept once you've confirmed the offer comes from Marrowgate and the portal is theirs.

**Fit ledger** (`must_have` / `hard_gate` rows, read off the map below)
- `hard_gate`: unclear: R8 (Limerick office, two days a week)
- `must_have`: direct: R1, R3, R4, R5, R6 · unclear: R2 (Irish PAYE, PRSI, USC)
- `important`: adjacent: R7 (Pension changes)

R1, R3, R4, R5 and R6 are direct. R7 is where you're weakest: you've never run pension changes.

**Hard gates:** none failed; unconfirmed: R8 (Limerick office, two days a week); candidate constraints not given, so checks against them are unknown.

**Opportunity ledger:** The offer is specific: role, pay, reporting line, location, and a named People Team sender. Your two in-person visits to their office are good evidence they're a real employer. Severe red flags: none found. The bank, PPS and passport request is a routine step after a credible written offer, so it takes no risk entry.

**Role reality**
| Element | What it is | Provenance |
|---|---|---|
| Pay | €40,000, inside the ad's €38,000–€42,000 | `[grounded]` offer and ad |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer |
| Market calibration | Not run: the web search was refused | — |

**Evidence map**
| # | Requirement | Priority | Fit | Confidence | Gap | Provenance |
|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | `[grounded]` your stated 3 years, fortnightly, 90 staff |
| R2 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | low | evidence | Your hotel payroll's jurisdiction isn't stated |
| R3 | Starters and leavers | must_have | direct | medium | none | `[grounded]` your background |
| R4 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | `[grounded]` your background |
| R5 | Strong Excel | must_have | direct | medium | none | `[grounded]` your stated use: pivots, XLOOKUP |
| R6 | Payroll qualification | must_have | direct | high | none | `[grounded]` Payroll Technician certificate, 2024 |
| R7 | Pension changes | important | adjacent | low | capability | You've never run them; you've handled the payroll deductions around them |
| R8 | Limerick office, two days a week | hard_gate | unclear | low | — | Your location isn't stated |

**Opportunity risk register**
| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pension responsibility without stated training | unknown | — | "reconcile payroll… process starters, leavers and pension changes" | You may be expected to run pensions from day one | `[inferred]` from the ad's list against your background | Will I be trained on the pension scheme, and who covers pension changes in my first month? | unresolved |

**Application plan**
| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Search "Marrowgate Housing" yourself and check that marrowgatehousing.ie is the domain on their site and that the job is listed | Confirms the email's domain before you give any details | `[generic]` standard check | pending your action |
| P2 | Enter bank, PPS and passport scan only in the portal, at the address their own website gives. If the link goes elsewhere, phone the number from their site and ask People Team | Keeps those details with the employer | `[generic]` onboarding practice | pending your action |
| P3 | Bring the original passport on day one | Standard right-to-work check | `[grounded]` offer | pending your action |

**Evidence status**
Verified: none yet. Your background is taken from what you told me; nothing has been checked against a document.

Research tier: L1 — searches 2 of 5, fetches 0 of 2
| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused. It would have confirmed the employer and the live posting, which is P1 |
| 2. Role-family sweep | unavailable | Would have set a market band for pay. Not sent after the refusal |
| 3. Hiring manager's public footprint | unavailable | Declan Garvagh is named in the offer, so a search was possible. Would have checked the reporting-line claim |

**Dossier offer:** I can save this as `tuesday-dossier.md` if you want it kept with the offer.

**Upgrade menu**
- A link to the live posting or their careers page → confirms the employer; the conditional clears.
- Your payroll jurisdiction (Irish, or elsewhere) → R2 moves to direct or is closed.
- Your location, or your willingness to commute → R8 is settled.
- Search access granted → the market band for pay and the employer check.

**Questions**
1. Could you attend the Limerick office two days a week from where you live? (R8)
2. Was your hotel payroll run under Irish PAYE, PRSI and USC? (R2)
3. Will you be trained on pension changes, or are you expected to run them from day one? (RR1)

Answer in text, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.