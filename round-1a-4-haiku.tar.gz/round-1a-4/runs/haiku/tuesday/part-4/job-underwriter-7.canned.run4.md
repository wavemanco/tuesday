**Worth applying for, on conditions: `conditional_go`.** The gates you state are met on your CV and the caseload model is a stretch you can argue. The main unknowns are whether the post is still open and whether it expects Doppler or continence work.

Research tier: L1 — searches 5 of 5, fetches 1 of 2; user links read 0

**Decision snapshot**

**Fit ledger.**

- `hard_gate` — direct: R1, R2, R12
- `must_have` — direct: R3 · unclear: R10
- `important` — direct: R4a, R5a, R6 · adjacent: R4b, R9 · unclear: R5b, R7, R8
- `preferred` — absent: R11

R4b — leg-ulcer care is adjacent to your pressure-ulcer and surgical wound work; R9 — no caseload held yet, but seconded home visits are the nearest match; R10 — records are not mentioned on your CV.

**Opportunity ledger.** The employer is established (RR3), and the pay range is within the generic Band 5 band (RR2). The post itself is not confirmed live (RR1), and Doppler training provision is unknown (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R12 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed open on the employer's careers page (RR1); (2) you check your NMC register entry and driving licence yourself, since those are stated, not checked; (3) you answer the caseload question (G1) honestly, framing it as home-visit experience rather than caseload experience.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing under an NHS contract in Calderdale; 410 staff across four locality hubs | `[grounded]` calderbrookhealth.example/about |
| Role | Band 5 district nursing; a small caseload with senior community nurse support | `[grounded]` JD |
| Pay and terms | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` JD |
| Market calibration | England community staff nurse Band 5, 2026 survey: median £34,300, interquartile range £32,400–£36,600; 61% of respondents paid mileage. Self-selected sample | `[generic]` wardround.example pay guide |
| Hiring manager | Rhiannon Mabbott leads the Halifax district nursing team; spoke at the 2025 forum on nurse-led leg-ulcer clinics and Doppler training for staff new to community work | `[grounded]` communitynursingforum.example speaker page |
| Unknowns | Whether the post is open now; caseload size and supervision; whether continence, end-of-life and Doppler training are part of the role | — |
| Contradictions | None found between the JD and the employer's About page | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | Stated, active, revalidation March 2028; not checked | `[grounded]` CV | You check the NMC register |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated, category B; not checked | `[grounded]` CV | You confirm it is valid |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years as staff nurse | `[grounded]` CV | none |
| R4a | Wound care (general) | important | direct | medium | none | Pressure ulcers and surgical wounds stated | `[grounded]` CV | none |
| R4b | Leg-ulcer care | important | adjacent | medium | transferability | Wound work carries over; no leg-ulcer work stated | `[inferred]` from R4a | G5 |
| R5a | Catheter care | important | direct | medium | none | Stated | `[grounded]` CV | none |
| R5b | Continence care | important | unclear | low | discovery | CV silent | `[grounded]` CV silence | G3 |
| R6 | Insulin administration and care planning | important | direct | medium | none | Insulin stated; care planning not separately stated, so care-planning is handled in R8 | `[grounded]` CV | none |
| R7 | End-of-life visits | important | unclear | low | discovery | CV silent | `[grounded]` CV silence | G2 |
| R8 | Care planning | important | unclear | low | discovery | CV silent on ownership of plans | `[grounded]` CV silence | G2 |
| R9 | Holding a small caseload with senior support | important | adjacent | medium | transferability | Home visits in the first week after discharge; no caseload held | `[inferred]` from CV | G1 |
| R10 | Clear, timely written records on an EPR | must_have | unclear | low | discovery | CV silent on records or EPR | `[grounded]` CV silence | G4 |
| R11 | Doppler assessment (desirable) | preferred | absent | none | capability | You say you have never done one | `[grounded]` user statement | G5 |
| R12 | Work location Halifax | hard_gate | direct | medium | none | You live in Halifax | `[grounded]` CV | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Caseload (R9, important) | transferability | Home visits after discharge; no ownership of a caseload stated | Likely the first interview probe | Ongoing follow-up you arranged for patients; a list of patients you visited and chased | Referral or handover note; a sanitised visit log | `[inferred]` from CV |
| G2 | End-of-life and care planning (R7, R8) | discovery | CV silent | Two important rows unresolved | Discharge planning with end-of-life patients; care plans you wrote or updated | Care-plan template; a sanitised example | `[grounded]` CV silence |
| G3 | Continence care (R5b) | discovery | CV silent | Core to the role's duties | Catheter-related continence assessments; referrals to continence services | Continence assessment form or pathway | `[grounded]` CV silence |
| G4 | Written records (R10) | discovery | CV silent | Essential requirement | EPR systems used; documentation standard you audited | Sanitised note example | `[grounded]` CV silence |
| G5 | Leg-ulcer and Doppler (R4b, R11) | transferability / capability | Wound work carries over; no Doppler | Desirable; the team lead talks about it publicly | Leg-ulcer dressing work if any; Doppler training you could book | Training certificate, once booked | `[inferred]` |

The queue holds no questions. The questions are in the closing block.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Post not confirmed live | unknown | — | Posting text; careers search returned no listing | The post may be closed or not yet listed | `[grounded]` search and fetch | Is this post open on your careers page, and when does it close? | unresolved |
| RR2 | Pay within generic band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Pay sits inside the Band 5 interquartile range | `[generic]` survey | Does the post carry a Band 5 pay step, and how is mileage paid? | noted |
| RR3 | Employer established | positive_signal | — | "adult community nursing … under an NHS contract" | Real, sized employer with four hubs | `[grounded]` About page | How many caseloads per nurse, and who supervises a new starter? | noted |
| RR4 | Doppler training unknown | unknown | — | "Doppler assessment for leg ulcers" (desirable) | Training may or may not be provided for new starters | `[inferred]` from the team lead's forum talk | Does the post include Doppler training, and how is it delivered? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the post is live on the careers page before writing anything | RR1 | `[grounded]` search | pending your approval |
| A2 | Check your NMC register entry and driving licence yourself | R1, R2 | `[grounded]` CV | pending your approval |
| A3 | Positioning: lead with discharge-to-assess home visits and wound/catheter/insulin work; say plainly you have not held a caseload or done Doppler | R9, R11 | `[grounded]` CV | pending your approval |
| A4 | If you apply, mention the leg-ulcer and Doppler interest only as learning intent | R4b, R11 | `[generic]` pattern for applications like this | pending your approval |

**Evidence status**

Verified: none yet. Your CV claims are `cv` source, not confirmed by you in writing.

Research tier: L1 — searches 5 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and a careers-vacancies query; fetched calderbrookhealth.example/about. Employer established. The post was not found in search, so RR1 stays open |
| 2. Role-family sweep | yes | Searched "Band 5 NHS Agenda for Change pay scale 2026 …", which returned Wardround 2026 UK Community Nursing Pay Guide. Market calibration `[generic]`, from one survey of 1,240 respondents |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned the communitynursingforum.example speaker page. Moved the positioning in A3 and the Doppler question in RR4 |

**Upgrade menu**

- Your NMC register entry and driving licence checked by you → R1 and R2 move from `medium` to `high` once you confirm them.
- A sanitised handover note or visit log from the discharge-to-assess role → R9 moves from transferability toward direct.
- A care-plan or end-of-life example, even anonymised → R7 and R8 resolve.
- Your pay floor → R12-style constraint check; the pay range is then set against it.
- A deeper research pass on Calderbrook (leadership, staff reports, past reviews; up to 5 more searches and 2 more fetches) — say the word and it runs.

Want me to write this up as a `tuesday-dossier.md` you can keep and reuse?

Questions, tagged to their rows:

1. R9 (caseload): Have you ever owned a patient's ongoing follow-up, even partly, such as a discharge list you chased? What did you own, and what happened?
2. Pay (constraint): Is £31,050 plus mileage above the floor you'd accept?
3. R7/R8 (end-of-life and care planning): Have you written or updated a care plan, or led an end-of-life visit, in hospital or at home? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.