## Duinvaart Cold Chain (Operations Analyst): apply, on conditions

**Status: `conditional_go`.** The core of the job matches your background. Two things are open: the Rotterdam commute, and temperature compliance, which nothing you've given me touches.

**Fit ledger.**

- `hard_gate`: unclear: D1 (Rotterdam office, three days a week)
- `must_have`: direct: D2, D3, D4, D5 · unclear: D6 (temperature compliance)
- `important`: direct: D7 · adjacent: D8 (route changes)
- `preferred`: adjacent: D9 (Dutch)

D6 is the gap. D8 is a review of route performance with depot managers, not route changes.

**Opportunity ledger.** The posting is concrete (DR3, positive). Pay and contract type are unstated (DR2, unknown). The employer and posting are unchecked (DR1, unknown).

- **Hard gates:** none failed; unconfirmed: D1 (Rotterdam office, hybrid, three days a week); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) D1: you can work three office days a week in Rotterdam (question 1). (2) D6: you have a real temperature or cold-chain example (question 2). If not, the application says so and doesn't imply it. (3) DR1: you find this role on Duinvaart's own careers page before you invest effort. I could not run that check (see Evidence status).
- **What would change this:** a "no" on D1 makes it a failed gate and `no_go`. A "no" on D6 keeps it a named risk but doesn't change the status.

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; existence and live posting not checked | `[grounded]` posting header; existence unverified |
| Mandate | Track on-time delivery and temperature compliance across a refrigerated fleet; weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Pay | Not stated | — |
| Scope read | Monitoring and advisory analyst role | `[inferred]` from the listed duties |
| Market calibration | Not run; no salary band | — |
| Unknowns | Pay; contract type; whether the role sets routes or advises on them | — |
| Contradictions | None within the posting | `[grounded]` posting |

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | Rotterdam office, hybrid, three days a week | hard_gate | unclear | none | hard_gate | Your location and commute weren't given, so the gate isn't established | `[grounded]` posting | Question 1 |
| D2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as operations analyst at a parcel carrier; self-reported, not yet inspected | `[grounded]` your background | none |
| D3 | Strong SQL | must_have | direct | medium | none | Daily use | `[grounded]` your background | none |
| D4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use | `[grounded]` your background | none |
| D5 | Track on-time delivery | must_have | direct | medium | none | Your on-time dashboard, used by depot managers | `[grounded]` your background | none |
| D6 | Track temperature compliance across a refrigerated fleet | must_have | unclear | none | discovery | Nothing given on temperature, cold chain or refrigerated vehicles; a parcel carrier may have such work, and you haven't said | `[grounded]` absence from your background | Question 2 |
| D7 | Build weekly dashboards in Power BI | important | direct | medium | none | You built a dashboard in use; the weekly cadence isn't stated | `[grounded]` your background | none |
| D8 | Work with depot managers on route changes | important | adjacent | medium | transferability | You ran the weekly route-performance review; you didn't say you set routes | `[grounded]` your background | DG2 |
| D9 | Dutch (a plus) | preferred | adjacent | medium | transferability | Conversational, self-stated; below fluent, and not a bar here | `[grounded]` your statement | none |

**Gap recovery queue.**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| DG1 | Temperature compliance (D6, must_have) | discovery | Nothing on temperature or cold chain in your background | Resolving it moves the status between `conditional_go` and a named risk | Any temperature-sensitive or special-handling parcels; any handling or compliance reporting, even within the on-time work | A dashboard screenshot, a report excerpt, or an SOP you worked to | `[grounded]` absence from your background |
| DG2 | Route changes (D8, important) | transferability | You reviewed route performance with depot managers | The bridge is strong but stops short of setting routes | Any route change you proposed or made, and its outcome | A review deck, or a before-and-after route change | `[inferred]` bridge from the review you ran |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DR1 | Employer and posting not checked | unknown | — | "Duinvaart Cold Chain, Rotterdam" | The posting may not be live, or the employer may not match. This is not a finding that the employer is missing: web search was refused, so nothing was checked | Not checked in this session | Can you point me to this role on Duinvaart's own careers page, and who would I interview with? | unresolved |
| DR2 | Pay and contract type not stated | unknown | — | (posting silent) | Pay may be withheld until late in the process, or may sit below what you expect | `[inferred]` from the posting's silence | What is the salary band and contract type for this role? | unresolved |
| DR3 | Concrete scope and tools | positive_signal | — | "build weekly dashboards in Power BI" | The duties are defined and measurable | `[grounded]` posting | What would a strong first quarter look like in this role? | noted |

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with the on-time dashboard used by depot managers | D5, D7 | `[grounded]` your background | resume_edits_pending_approval |
| E2 | Don't claim temperature or cold-chain work unless question 2 turns up an example | D6 | `[grounded]` D6 | pending your approval |
| E3 | Check the posting on Duinvaart's careers page before applying | DR1 | `[grounded]` DR1 | your action |
| E4 | Ask DR2's question in the first screen | DR2 | `[grounded]` DR2 | pending your approval |

---

## Kroonhaven Foods (Supply Planner): not worth your time now

**Status: `no_go`.** No gate fails. The reason is that K1 (three years of FMCG planning) and K3 (planning-system use) don't close in weeks, and K4 (fluent Dutch) is short of the bar.

**Fit ledger.**

- `hard_gate`: unclear: K5 (on-site in Utrecht)
- `must_have`: adjacent: K4 (fluent Dutch) · unclear: K2 (advanced Excel) · absent: K1 (three years of FMCG planning), K3 (SAP IBP or a similar system)

K1 has only performance analytics as a bridge, with no forecasting, capacity or S&OP. K3 can be partly closed with a course. K4 is conversational, not fluent. K2 is not yet established.

- **Hard gates:** none failed; unconfirmed: K5 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger.** The scope is concrete (KR2, positive). Pay and contract type are unstated (KR1, unknown). The employer is unchecked (KR3, unknown).
- **What would change this:** K1 and K3 would both have to differ, meaning about three years of FMCG supply or demand planning, or a planning-system background. K4 would also have to be fluent Dutch.

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; existence and live posting not checked | `[grounded]` posting header; existence unverified |
| Mandate | Owns the 13-week supply plan for chilled ready meals; balances production capacity against the forecast; runs the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht; office days not stated | `[grounded]` posting |
| Pay and contract | Not stated | — |
| Scope read | Planner role with ownership of the plan and the meeting | `[inferred]` from the listed duties |
| Market calibration | Not run | — |
| Contradictions | None within the posting | `[grounded]` posting |

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | No planning work on your record; the nearest is operational performance analytics | `[grounded]` your statement | KG1 |
| K2 | Advanced Excel | must_have | unclear | none | discovery | Excel isn't in what you gave me; SQL and Power BI are | `[grounded]` absence | Your Excel level and an example of what you built |
| K3 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning-system use recorded | `[grounded]` absence | KG1 |
| K4 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, self-stated; "fluent" is the bar, not met | `[grounded]` your statement | Dutch test or Dutch work sample; don't claim fluency |
| K5 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your location and commute weren't given | `[grounded]` posting | Question 1 |

**Gap recovery queue.**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| KG1 | Planning years and planning systems (K1, K3) | capability | Performance analytics only | These are the core of the role; no realistic closure in weeks | A course or sandbox in a named planning tool narrows K3 but doesn't add years to K1 | A course certificate, or a sandbox exercise | `[grounded]` absence; `[generic]` that course-based closure narrows tool gaps only |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| KR1 | Pay and contract type not stated | unknown | — | (posting silent) | May be withheld, or below what you expect | `[inferred]` from the posting's silence | What is the salary band and contract type for this role? | unresolved |
| KR2 | Concrete scope | positive_signal | — | "Own the 13-week supply plan" | The accountability is defined | `[grounded]` posting | What does a good first quarter look like in this role? | noted |
| KR3 | Employer and posting not checked | unknown | — | "Kroonhaven Foods, Utrecht" | Same as DR1: unchecked, not a finding | Not checked in this session | Can you point me to this role on Kroonhaven's careers page, and who would I interview with? | unresolved |

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E5 | Don't apply now; put effort into Duinvaart | K1, K3 | `[grounded]` the no_go reasoning | your decision |
| E6 | If you apply anyway, don't claim planning years or fluent Dutch; name the analytics bridge and its limit | K1, K4 | `[grounded]` K1, K4 | pending your approval |
| E7 | Look for analyst roles where SQL and Power BI are the bar and forecasting is one part of the job | K1 | `[generic]` role-family pattern; not checked for these employers | your judgment |

---

## Evidence status

Verified: none yet. Nothing you've told me is confirmed, so every claim above is self-reported.

Web search was refused permission in this session, and I did not retry it. So neither company was checked, and neither salary band was researched.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for both companies were refused. Existence and live postings are unchecked (DR1, KR3). |
| 2. Role-family sweep | unavailable | Two salary searches were refused. No market band, so pay is unbenchmarked for both roles. |
| 3. Hiring manager's public footprint | n/a | No name given |

**Dossier offer.** I can write `tuesday-dossier.md` with both maps, the registers and a handoff for mock-interview if you get a call.

**Upgrade menu.**

- Permission to run web search: confirms both companies and postings, and sets both salary bands against market. At L1 that's up to 5 searches and 2 fetches.
- Question 1's answer closes D1 and K5.
- Question 2's answer closes D6, or leaves it as a named risk.
- Your Excel level closes K2.
- The pay and contract details from the careers page close DR2 and KR1.
- A planning-system course or sandbox partly closes K3. K1 stays open.
- A Dutch certificate or work sample in Dutch raises K4.

**Questions.**

D1 and K5: Can you work in the Rotterdam office three days a week, and be on-site in Utrecht? If either wouldn't work, say which.

D6: Have you worked on temperature-sensitive or cold-chain parcels, or tracked any temperature or handling compliance, even as part of the on-time work?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.