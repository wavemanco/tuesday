**Worth taking the call, but legitimacy isn't established yet: `conditional_go`.** The material shows no red flags: nobody asks you for money, a deposit or bank details. The open question is whether Fernquay exists as described. Web search was not permitted, so I couldn't check that.

**Fit ledger.**
- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000 against your floor)
- `must_have`: direct: R4, R5, R6, R7 · adjacent: R3 (Own the booking flow end to end)
- `important`: adjacent: R8 (You would be our first designer)

R3 is adjacent because checkout is one stage of a booking flow. R8 is adjacent because you have never been the only designer. R2 is unclear because your floor is not stated.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 base); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** RR1 (employer not established, unresolved) caps the decision at `conditional_go`. RR2 (solo first-designer role) and RR3 (who decides on the flow) are open. RR4 (a brief that asks for a real project) reads the other way.
- **Conditions for go:** (1) Fernquay is confirmed on its own website and in the public company register before you share anything beyond the call; (2) the base salary sits within your floor; (3) on the call, RR2 gets a concrete answer about design critique.
- **What would change this:** if Fernquay doesn't check out on its own site, pause before the call. If your floor is above €60,000, R2 fails and the status becomes `no_go`.

**Routine, not a risk.** A co-founder messaging on WhatsApp to arrange a video call, with an invite emailed, is routine scheduling. It gets no register entry. Check that the invite came from an address on Fernquay's own domain (see A1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting |
| Entity | Not established. Search was not permitted, so this is unchecked, not found missing | — |
| Mandate | Own the booking flow end to end, run research with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office | `[grounded]` posting |
| Compensation | €52,000–€60,000 base plus 0.5–1% equity | `[grounded]` posting |
| Market calibration | Not run. The role-family sweep was not permitted, so the salary is uncalibrated | — |
| Unknowns | Whether the company exists as described; who decides on the flow; design practice; contract type | — |
| Contradictions | None between the posting and the WhatsApp message. The match with the named co-founder is by name only | `[grounded]` both messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days are reachable. Your own view of the days is not stated | `[grounded]` your intake | none |
| R2 | Base €52,000–€60,000 | hard_gate | unclear | none | hard_gate | Your floor is not given, so the posting's figure can't be tested | `[grounded]` posting | Q1 |
| R3 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow, one stage of a booking flow. Ownership of the other stages is not in your account | `[grounded]` intake; `[inferred]` that checkout is one stage | G1 |
| R4 | Run your own user research, including with customers | must_have | direct | medium | none | Monthly usability sessions with customers. Your segment was consumer travel, not small businesses | `[grounded]` intake | none |
| R5 | Strong Figma | must_have | direct | medium | none | Daily use, self-reported. No file inspected | `[grounded]` intake | share one file |
| R6 | 3+ years of product design | must_have | direct | medium | none | Four years, stated. Experience length is not a gate | `[grounded]` intake | none |
| R7 | Ship alongside engineers | must_have | direct | medium | none | Four years in a squad with four engineers | `[grounded]` intake | none |
| R8 | "You would be our first designer" | important | adjacent | medium | transferability | Squad work is adjacent. You have never set design direction with no design colleague | `[grounded]` intake; `[inferred]` squad work as adjacent | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning the whole booking flow (R3) | transferability | Checkout redesign confirmed; the other stages are not in your account | "End to end" is the posting's first duty | Search, pricing, confirmation or account steps you changed with engineers | The checkout case study, and a flow map if you have one | `[grounded]` intake; `[inferred]` that the bridge is checkout |
| G2 | Working as the only designer (R8) | transferability | Squad work with four engineers; never the only designer | With no design peer, critique falls to you | Calls you made with engineers but no design colleague; research you ran alone | A case study where you made a call alone | `[grounded]` intake; `[generic]` that solo designers lean on engineers' review |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "six people in Galway making booking software" | The company may be too new or small for a web footprint, the posting may be stale, or it may not be a hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Solo design role with no design peer | risk_signal | medium | "You would be our first designer" | Design critique and direction may fall to you alone | `[inferred]` from the first-designer wording against a six-person team | Who reviews design work day to day, and what would critique look like in the first 90 days? | unresolved |
| RR3 | Who decides on the booking flow is not stated | unknown | — | "own the booking flow end to end", "work most closely with our co-founder" | Flow decisions may sit with the co-founder | `[inferred]` from the posting's silence on decision rights | Which flow decisions are mine alone, and which go to Ronan? | unresolved |
| RR4 | Real project over polished deck | positive_signal | — | "we would rather see one messy real project than a polished deck" | The team values work shown over presentation | `[grounded]` posting | What real project would you most like to see from me? | noted |

RR1 records that I could not check the company. It does not say the company is absent.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, look up Fernquay on its own website and in the public company register. Check that the invite's sender address is on Fernquay's own domain | RR1. This is a check on the invite, not a requirement | `[generic]` public registers exist; `[grounded]` RR1 | advice |
| A2 | For the checkout case study, use your own words: "I redesigned the checkout flow with a squad of four engineers." Do not say you owned the booking flow | R3. Your evidence supports "redesigned checkout", not end-to-end ownership | `[grounded]` intake | pending your approval |
| A3 | On the call, put RR2 and RR3 to Ronan and Saoirse as written | The register doubles as interview prep | `[grounded]` register | advice |
| A4 | Settle your base floor before you name a number | R2 | `[grounded]` posting | advice |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused by the permission prompt, so no result came back. Would have tested RR1 and whether the role is posted |
| 2. Role-family sweep | unavailable | One search refused. Would have set the market calibration for R2 |
| 3. Hiring manager's public footprint | unavailable | One search refused. Would have confirmed the co-founder's public role, the second half of RR1 |

I did not retry the refused searches.

## Upgrade menu

- Permission for web search: runs the three L1 targets above. Would move RR1 and the R2 calibration.
- Your base floor: R2 closes, and the pay gate becomes met or failed.
- The checkout case study, or a Figma file you can share: R3 and R5 move to `high`.
- The domain of the invite's sender, pasted alone: a partial check on RR1.

If you want this kept, I can write it up as `tuesday-dossier.md` so you can add to it after the call.

**Questions**
- R2: What is the lowest base salary you would accept for this role, and would equity change that number?
- G2: Did you ever make design calls mostly alone, even inside a squad? Which were they, and how did you know they worked?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.