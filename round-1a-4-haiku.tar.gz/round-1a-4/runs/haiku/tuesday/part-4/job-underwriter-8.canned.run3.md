**Decision: don't go ahead.** Don't send your IBAN, PPS number or passport photo, don't pay the "equipment partner", and don't deposit or forward any cheque.

Research tier: L0, no searches. The verdict rests on what's in the posting and messages, so it doesn't need outside checks.

**Decision snapshot**
- **Opportunity:** no_go. The hiring process asks for things that a real job offer doesn't need.
- **Candidate fit:** good on the listed skills. Your customer service, Zendesk, training and Excel experience match the posting. That doesn't change the decision.
- **Hard gates:** pay floor not met. The posting gives no base salary, only "up to €26 an hour plus commission" for 15–30 hours a week. That works out to roughly €20k–€40k a year, with nothing guaranteed, below your €30k minimum at the low end.

**Red flags (quoted from the messages)**
1. **Hired wholly by chat, no call or video**: "Our whole hiring process runs on Telegram, so there are no calls or video interviews."
2. **Bank, tax and ID details before any offer**: "send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up."
3. **Paying to start work**: "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages."
4. **Cheque, keep some, forward the rest**: "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner."
5. **Contact is a generic mail domain**: velloway.hr@postmail.example. Nothing in the posting links to a company website or a careers page.

Step 4 of the playbook calls for an offer to make a dossier. It's a file of this assessment you can keep: say the word and I'll write `tuesday-dossier.md`.

**Upgrade menu.** Nothing you could add would make the payment or cheque requests reasonable. The only thing that would change the picture is the employer's own careers page, which you can check yourself. Search for Velloway Logistics on its official website, not from a link in the message, and look for this role there.

**Questions**
- Have you already sent your IBAN, PPS number or passport photo to anyone in this process? If so, contact your bank now and report it to the Gardaí. Keep the chat records.

*Response mode: I can answer this in one line, or go on to the dossier or a list of safer ways to find remote roles.*

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.