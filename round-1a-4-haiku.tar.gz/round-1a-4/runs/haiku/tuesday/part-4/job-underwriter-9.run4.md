**Yes, asking for bank details, PPS number and a passport scan is normal for a written offer like this one.** The offer follows two in-person interviews at the office, names the role, pay and reporting line, and asks for the details only after you accept. Enter them only in the portal at the address on Marrowgate's own website, and don't send them by email. Status: `conditional_go`. I couldn't check that the employer exists, so accept once you've confirmed it yourself.

**Fit ledger.**

- `hard_gate`: unclear: R9 (Limerick hybrid, two days a week in office), R10 (pay, €40,000 offered)
- `must_have`: direct: R1 (2+ years running payroll), R3 (Excel), R4 (payroll qualification) · unclear: R2 (Irish PAYE, PRSI and USC)
- `important`: direct: R5 (starters and leavers), R6 (payroll-to-ledger reconciliation) · adjacent: R7 (pension changes) · unclear: R8 (staff payroll queries)

R7 — a bridge from starters, leavers and payroll changes, with the limit that you've never run pension changes. R2 — not stated in your background. R8 — not in your background. R9, R10 — your location and pay floor weren't given.

**Opportunity ledger.** The offer shows no red flags. The bank, PPS and passport steps are routine onboarding (RR1). The employer couldn't be checked from here, because the search tool was refused, so that check is still open.

- **Hard gates:** none failed; unconfirmed: R9 (Limerick hybrid, two days a week in office), R10 (pay, €40,000 offered); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) you confirm the employer and the offer's email domain on Marrowgate's own website; (2) you confirm R9 and R10; (3) you have a plan for R7 (pension changes) before you start.

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, Limerick housing association, about 240 staff | `[grounded]` job ad |
| Mandate | Monthly payroll, starters, leavers, pension changes, ledger reconciliation, staff queries | `[grounded]` job ad |
| Terms | Permanent, €40,000 offered (ad band €38,000–€42,000), hybrid, two days a week in the Limerick office | `[grounded]` offer email, job ad |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer email |
| Market calibration | Not run; no search completed | — |
| Unknowns | Whether the employer is established; which pension scheme applies; your start date | — |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff, self-reported in prose; no artifact yet | `[grounded]` your background | none |
| R2 | Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | A payroll role implies it; your background doesn't say it | `[grounded]` absence in your background | Q1 |
| R3 | Strong Excel | must_have | direct | medium | none | Pivot tables and XLOOKUP named; "strong" is self-assessed | `[grounded]` your background | none |
| R4 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024; no copy seen yet | `[grounded]` your background | keep a copy ready |
| R5 | Starters and leavers | important | direct | medium | none | Done in your current role | `[grounded]` your background | none |
| R6 | Monthly payroll-to-ledger reconciliation | important | direct | medium | none | Done monthly in your current role | `[grounded]` your background | none |
| R7 | Pension changes | important | adjacent | medium | transferability | Starter, leaver and payroll-change work carries over; no pension scheme administration. You said your manager handled pensions | `[inferred]` bridge from R5 and R6 | G2 |
| R8 | Answer staff payroll queries | important | unclear | low | discovery | Not in your background | `[grounded]` absence | Q3 |
| R9 | Limerick office, hybrid two days a week | hard_gate | unclear | none | hard_gate | Constraint not given, so the fit can't be read | `[grounded]` constraint not given | Q2 |
| R10 | Pay, €40,000 offered | hard_gate | unclear | none | hard_gate | Your pay floor not given | `[grounded]` constraint not given | Q2 |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI and USC (R2) | discovery | Payroll runs are in your background; the tax rules aren't named | A must-have; a clear answer moves R2 to direct | Calculating USC bands or PRSI class changes; reconciling Revenue returns | Payslip sample or payroll-run summary | `[grounded]` background |
| G2 | Pension changes (R7) | transferability | Starter and leaver changes done; no pension admin | The most likely interview objection | Enrolment or opt-out changes handled alongside starters | Ask Declan which scheme and provider apply | `[inferred]` bridge; limit named |
| G3 | Payroll queries (R8) | discovery | Not stated | Part of the job every week | Answering colleagues' pay queries in your current role | Any query log or FAQ you wrote | `[grounded]` absence |
| G4 | Location and pay (R9, R10) | hard_gate | Not given | Decides whether the role works for you | — | Your own answer | `[grounded]` constraints not given |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Offer follows in-person interviews and names role, pay and reporting line | positive_signal | — | "we are delighted to offer you the permanent post … at €40,000 a year, reporting to Declan Garvagh" | The stated terms are specific and the process was in person | `[grounded]` your account and the offer | "Can you confirm the post on your own careers page?" | noted |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Find Marrowgate's website through a search you run yourself. Check the role and that the email domain matches it | Confirms the employer; the search tool was refused, so this check is still open | `[generic]` standard check for any offer | your action |
| P2 | Reply to accept within five working days of the offer, once P1 is done | The offer's deadline | `[grounded]` offer email | your action |
| P3 | Enter bank, PPS and passport details only in the portal at the address on Marrowgate's website. Don't email them | Protects the details | `[generic]` routine onboarding practice | your action |
| P4 | Ask Declan which pension scheme and provider apply, and what the change process looks like | Closes G2 | `[inferred]` from R7 | your action |
| P5 | Bring the original passport on day one, as they asked, and a copy of your certificate | Right-to-work check; supports R4 | `[grounded]` offer email | your action |

### Evidence status

Verified: none checked against documents. Self-reported: R1, R3, R4, R5, R6, R7 (medium at most until you show an artifact). Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2 (both searches refused)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would confirm the employer and the live posting, moving RR-level employer check and the conditions for go. Refused; you can check it with P1 |
| 2. Role-family sweep | unavailable | Would have placed the €40,000 offer against the usual band for this role. Not run |
| 3. Hiring manager's public footprint | unavailable | Would have checked Declan Garvagh's public role. Not run |

**Dossier offer:** I can save this as `tuesday-dossier.md` for your records.

**Upgrade menu**

- Confirmation of the employer on its own careers page, and the live posting → the employer check closes and the status could move to `go`.
- Pension scheme details from Declan → R7 moves toward direct.
- A copy of the Payroll Technician certificate → R4 moves to high.
- A payslip sample or payroll-run summary from your hotel role → R1 and R2 are firmer.

**Questions**

- G1 (R2): Did your hotel-group payroll cover PAYE, PRSI and USC calculations yourself, and on which system?
- G4 (R9, R10): Are the Limerick hybrid pattern and €40,000 both workable for you?
- G2 and G3 (R7, R8): Have you ever handled pension deductions, remittances or enrolments, or answered staff pay queries?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.