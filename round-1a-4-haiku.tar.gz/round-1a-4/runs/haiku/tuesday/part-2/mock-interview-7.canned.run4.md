Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-2-rooms-case-7-canned-c489bcf2/ab0de84e-ff06-447a-b743-a961f6b4df1b/scratchpad/saltmarsh_live-operations-producer_interview_pack.md`. I built it on the assumption that Tobias is your hiring manager, since the company's careers page puts the 60-minute hiring-manager interview here.

Two findings change the prep:

- **The round is a live-incident tabletop, not a Q&A.** Saltmarsh's careers page describes the 60-minute "Outage Hour" as a simulated outage during a live event, followed by a values conversation. Practise running an incident out loud: clarify first, then decide, then say what you'd tell players and the teams.
- **A company news item is worth raising.** Saltmarsh's Project Larkspur (September 2026) moves two titles to a season-pass model on one shared events calendar from February 2027. Your material has no in-app purchase experience, so don't claim any. I couldn't fetch the page, so those details come from a search snippet. Check them against the page before you cite them.

The pack's highest-value rehearsal is B1: "You've never led a team, and this role coordinates four of them on every update." Hold your position, lean on the calendar and the checklist, and concede precisely on the third follow-up.

I left one thing out on purpose. A search on Tobias's name returned a talk by him, but the link is on a domain I couldn't verify, so the pack doesn't use it. If you want his angle, find his public talks yourself before Friday.

Would you like me to run the B1 drill with you? Say which persona or question you want, and I'll play it and give feedback. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, and is the Outage Hour the only interview before the offer stage? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager (assumed; the careers page places the hiring-manager interview here, and the one question below confirms it).
**Round:** the Outage Hour, one 60-minute interview: a live-incident tabletop, then a values conversation. Per the careers page.
**Pack basis:** your message (JD and background) plus the company's own careers and values pages.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and stop where your material stops.

Type key:

- **CASE**: a live problem from the role, delivered live. Structure and reasoning count more than a right answer.
- **JD**: a requirement from the posting. Can you do the listed job, gaps included?
- **EXP**: a claim from your past. Does it survive a close look, and what was actually yours?
- **VAL**: a values question. Past behaviour against the published values.
- **CO**: company and strategy knowledge. Homework depth.

## Fit snapshot

Your material, quoted, against each requirement. Sources: JD means the posting you sent; your message means what you wrote in this conversation.

No gate rows. The JD's length line ("3+ years") is not a gate under the suite's definition, and no location, pay, schedule or credential is stated.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one title's content-drop calendar, for two years. Say it in those words. Two titles and live events are not in it, so do not stretch it. Answer slot: if you have planned more than one title's calendar, say how, in your own words; if not, say so plainly and say how you would plan two. |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | The material shows QA working from your checklist. It does not show coordination across four teams, so the words are an answer slot, not a claim. Answer slot: name the teams whose inputs you coordinated on one release and what each needed from you; if the only team was QA, say so plainly. |
| F3 | "own the post-event review" — JD | none given | none | [grounded] | discovery | Your material does not show a post-event review. Words for you: an answer slot. Answer slot: if you have run or written one, say what it covered; if not, say so plainly and say what you would put in the first one. |
| F4 | "the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented retention numbers monthly. It does not say you chose the KPIs. Say it in those words. Answer slot: if you chose which KPIs were reported, say which and why; if not, say so. |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | Your sentence reaches this line in its own terms. Lead with the checklist, and let "still uses" carry it. A named artifact beats an adjective. |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | presentation | The years are there. The live-service term is not in your words, but weekly content drops are what the term describes. Bridge, in your words only: "I was an associate producer at a puzzle-game studio for four years, and for the last two I ran its weekly content drops." Adds no practice. |
| F7 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | Your sentence reaches the requirement directly. Say it in those words. |
| F8 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | Your sentence reaches the requirement in role terms. Say what you presented, how often, and to whom. How the figure was counted is a defend-the-number slot in the banks, not a claim here. |
| F9 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Your sentence reaches the requirement in other terms: a written artifact other people use daily. Bridge, adding no practice: say what the checklist is for, in those words, and let its use speak. |
| F10 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | none | [grounded] | capability | A gap you stated, and the pack gives back only your words: "I've never led a team." Then how you would learn to, said as a plan and never as a past. Nothing added to make the gap smaller. |

Requirement rows F3 and F4 split one JD line into two claims of different strength, so each keeps its own confidence.

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. Your material says one title's content-drop calendar, not live events. |
| Coordinated design, art, engineering and community on each update | Inflated form of F2 | "Wrote the release checklist our QA team still uses." Your material shows QA, not four teams. |
| Owned the post-event review and the KPIs | Inflated form of F3 and F4 | "Presented the monthly retention numbers to the studio head." No claim to a review or to choosing KPIs. |
| Has led a team | Negative you stated, F10 | "I've never led a team." No slot. |
| Has worked on a game with in-app purchases, or on a season-pass model | Negative you stated | "I've never worked on a game with in-app purchases." No slot. The JD does not ask for it, so no row, but do not claim it. |

## Persona table

Hiring-manager priors (persona reference: a hiring manager buys capability and derisks gaps), adjusted by the loop. The careers page names a 60-minute tabletop and a values conversation, so the case and values weights are higher than a plain hiring-manager round.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Case / Strategist | A live incident to run, then a live product decision | High. The careers page names the live-incident tabletop as the format of this round | Clarify, then decide, then say what you would tell players and teams | 5 |
| Skeptic | The gaps, asked directly: leading, the post-event review, the monetisation side | High. F10 and F2 are the thinnest evidence against the JD's coordination ask, and a hiring manager is derisking exactly there | Hold the stated position through two follow-ups, then concede precisely | 4 |
| Values / Behavioral | A values conversation after the tabletop, mapped to the three published values | High. The careers page names a values conversation | One story per value where your quotes carry one, otherwise a selection scaffold | 3 |
| Data-Driven Prober | Your retention number, then the calendar's sign-off | Medium. Two CV-style lines a prober will read closely | Say how each figure was counted, or say you do not know; name the weakest assumption first | 2 |
| Pressure | A time-boxed challenge to a single answer | Medium. A 60-minute slot invites time boxes | Pause, restate, hold through two follow-ups | 2 |
| Conversational | An opener and a close, both scored | Low to medium. Opening and closing questions are where a rapport-builder sits | Keep a 90-second arc ready; treat every casual question as scored | 2 |

## Question banks

Question IDs are letter-by-persona. Provenance comes before guidance. A question about your past uses only the quotes in its own row.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event goes wrong an hour in: the reward claim fails for a slice of players. Walk me through the first fifteen minutes." | CASE | [grounded] "a live-incident tabletop on a simulated outage during a live event" — careers page | Clarify first: what is broken, how many players, what state the event is in, who you would page. Then decide between stop, roll back and hold. Then say what you would tell players and the teams. Close with what you would check before re-enabling. Speakable in ninety seconds. | The careers page names this format; this is the likeliest opening question |
| A2 | "A title's live event is ten days out and the content is not ready. Ship, move or cut?" | CASE | [grounded] "Ship the Patch Not the Promise: we announce what is built, not what is hoped." — values page | Name what each option costs players and the calendar. Say what you would announce, and when. Then name the one assumption that decides it. | The live-calendar trade-off is the role's core; the values line gives the vocabulary |
| A3 | "Larkspur puts both titles on one shared calendar from February. What breaks first?" | CO | [grounded] "one shared events calendar from February 2027" — Saltmarsh news page, from a search result | Name two or three seams a single calendar creates: release cadence across two titles, the single live-ops queue, and QA sign-off timing. Ask one question back about which the team has seen. | The newest company fact found; it changes the job the posting describes |
| A4 | "Sketch how you would run the post-event review for a live event that missed its retention target." | CASE | [grounded] "own the post-event review and the KPIs it reports" — JD | Name the KPI first, then the cut you would examine (cohort, day, event), then what you would call cause and what you would not. Name the assumption you would defend least. Your material has no review to draw on, so do not reach for one. | F3's gap, asked as a live problem, which needs no past claim |
| A5 | "The QA team says the build is not ready and the community team has already announced the event. What is your call?" | CASE | [grounded] "manage the release checklist with QA" and "coordinate design, art, engineering and community teams on each update" — JD | Decide by the checklist's gates first, then by who decides. Say what you would tell the community team and when. Use no past claim. | A live problem from the JD's own lines; a decision, not a record |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never led a team, and this role coordinates four of them on every update. Why would that work?" | JD | [grounded] "Never led a team" — your message; "coordinate design, art, engineering and community teams on each update" — JD | **Highest-ROI prep in this pack.** Hold the stated position: "I've never led a team." Hold through two follow-ups by returning to what your material carries: "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." Concede precisely on the third follow-up: name the teams you have not led, and say how you would learn to, as a plan. Answer slot: if you coordinated any team's inputs to a drop, name it; if none, say so plainly. | F10 and F2 are where the posting's ask meets your thinnest evidence. This is the most predictable objection, and it will come in some form |
| B2 | "Two titles, one calendar. Your experience is one title. What is different about two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Say the one title, in those words, and stop there. Concede that two is different without inventing an example. Answer slot: if you have planned another title's calendar, say how; if not, say how you would plan two. | F1's transferability gap, at its own scope |
| B3 | "Of the retention report you presented monthly, which part was yours to decide?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Say what you presented and how often, in those words. Answer slot: if you chose which numbers went in, say which and why; if the report was set for you, say so plainly. | F4: the premise is open, so the second branch must be allowed |
| B4 | "Where are you weakest on this posting on day one?" | JD | [grounded] "own the post-event review and the KPIs it reports" and "coordinate design, art, engineering and community teams on each update" — JD | Name the post-event review and the cross-team coordination, in that order. Say what a first ninety days would look like, as a plan. Make no past claim to cover either. | The Skeptic's stock question; answering it first is cheaper than being caught by it |

### C. Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Players Before Plans: when the calendar and the players disagree, the players win." — values page | Selection scaffold: a moment when a drop's timing and what players needed pulled apart. If you can name one, say what you did, in your own words. If no such moment comes to mind, say so plainly, then give the nearest thing your calendar carries, or how you would handle it. | F7 carries the calendar; the value gives the question its theme |
| C2 | "When have you had to hold a date or a feature back?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." — your message | Selection scaffold: the checklist is where a gate sits. If the checklist has held a release, say what it caught. If no such time comes to mind, say so plainly, then say what the checklist requires before anything is announced, in your own words. | F5; the checklist is the one thing your material shows gating a release |
| C3 | "Name a process you left better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." — your message | Your strongest line is "still uses": the checklist outlived your time on the team. Say it. If you have a second process you improved, say it; if not, do not invent one. | "Leave the Build Greener" maps to the checklist's durability; no improvement story is claimed |

### D. Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How was the monthly retention figure counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Defend-the-number slot: say how the figure was counted, in your words. Name the assumption you would defend least. Say which part was yours. Answer slot: if you do not know how it was counted, say so. | F8 is the source; every headline figure gets this question |
| D2 | "Walk me through the weekly content-drop calendar: who signed off each drop?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Say what you ran and who you worked with, in those words. Answer slot: if you did not set the sign-off, say so plainly. | The calendar's sign-off is a practice your sentence does not state, so the second branch must be allowed |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has led a team?" | JD | [grounded] "Never led a team" — your message | Pause, then restate. Hold the position: two years running the calendar and the checklist. Concede precisely: you have not led a team. Do not argue the concession. | Pressure version of B1, timed |
| E2 | "That retention result: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Hold: you presented them, monthly. Concede exactly what you did not produce, if you know it. If you do not know, say that. | Pressure version of D1 |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message | A ninety-second arc using only your quoted sentences: the studio, the four years, the calendar, the checklist, the retention report. Nothing added. | The opener is scored; it should not be improvised |
| F2 | "What are you playing right now, and what would you change about it?" | CO | [generic] | No claim about your past. Name a game you actually play and one live decision in it that you would question. Ask about theirs. | Casual register, scored all the same |

Count: 18 questions. Requirement coverage:

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A2, B2 |
| Coordinate design, art, engineering and community teams on each update | A5, B1, B4 |
| Own the post-event review and the KPIs it reports | A4, B3, D1 |
| Manage the release checklist with QA | A5, C2 |
| 3+ years producing live-service games or apps | none, and why: covered by F6 in the fit snapshot; the length line is not a separate question |
| Experience running a content calendar | B2, D2 |
| Comfortable with player-retention metrics | D1, E2 |
| Clear written communication | none, and why: F9 carries it; add a question if the interviewer raises it |

## Values cheat sheet

The loop source (careers page) documents a values conversation, so this section applies. Published values from the values page, named exactly.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | F7: "I ran the weekly content-drop calendar for our main title for the last two years." Selection scaffold ending in its honest branch (C1). |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | F5: "Wrote the release checklist our QA team still uses." Selection scaffold ending in its honest branch (C2). |
| Leave the Build Greener | Every release leaves the codebase and the checklist better | F5: "Wrote the release checklist our QA team still uses." Story is the checklist's durability (C3). |

## Reading the interviewer

Absent. The one search on his name returned a result whose link I could not verify, so I used nothing from it. Your own check, if you want one: his public talks or writing, read yourself, before Friday.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good post-event review look like to you, and how often do you want one?" | Opens the KPI conversation on his terms |
| R2 | "When the calendar and a release disagree, who makes the call?" | Tests the seam between live-ops and QA, which is your checklist's ground |
| R3 | "What does one shared calendar change first for the two titles in this role?" | Shows you read the Larkspur news; asks for his view, not a claim |
| R4 | "What would a strong first ninety days look like for you?" | Standard, but it gives you the plan the Skeptic bank asks for |
| R5 | "How has the Outage Hour changed what your team actually catches?" | Shows you read the careers page, and asks what the format is for |

## Sources

Provided: the job description and your background, as sent in this conversation.

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read: none.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. saltmarshgames.com values | yes | Values cheat sheet: three values named exactly from the fetched page |
| 2. Saltmarsh interview process, live operations producer | yes | Round structure: one 60-minute hiring-manager interview, the Outage Hour (careers page, fetched); it establishes the loop, so no archetype fallback. It also makes the values section apply |
| 3. Saltmarsh strategy / recent news | yes | CO question A3 and reverse question R3, from the Larkspur news page (search snippet only; not fetched) |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Not established. One result, on a domain I could not verify; nothing from it used |
| 5. representative live operations producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries and returns:

- "Saltmarsh Games values": saltmarshgames.com/values, fetched.
- "Saltmarsh Games interview process live operations producer": saltmarshgames.com/careers/interviewing, fetched.
- "Tobias Wrenfield Saltmarsh Games": one result, not used (see Reading the interviewer).
- "Saltmarsh Games live events 2026 mobile game news": saltmarshgames.com/news/project-larkspur, from the search snippet only. The fetch budget was spent on the two pages above, so the Larkspur details are the snippet's words.

## Upgrade menu

- Confirm the round: is the Outage Hour the only session, and is Tobias the hiring manager? → persona weights and the case bank get confirmed or reweighted.
- Tobias's public talks or writing, read by you → an interviewer read and a mirror opportunity in the reverse questions.
- The teams you coordinated on one release, in your own words → F2 moves from an answer slot to a grounded row, and B1's third branch gets stronger.
- The release checklist itself, redacted, if you can share it → F5's confidence moves to high, with an inspectable artifact.
- How the retention figure was counted, in a note → D1 gets a grounded answer, not a slot.
- A deeper research pass (up to six more searches and two more fetches, several minutes): a full read of the Larkspur page, a strategy brief, and loop reports → A3 and R3 become fully grounded.
