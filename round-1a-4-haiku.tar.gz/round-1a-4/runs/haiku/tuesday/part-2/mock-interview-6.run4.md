Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-2-rooms-case-6-denied-3662c85f/d75d1305-4449-4d58-9fbc-70939e795013/scratchpad/Larkfield_Systems_engineering-manager_interview_pack.md. It has a shared fit snapshot and a separate mini-pack for each round: the Director on Tuesday, the panel on Thursday, and the VP on Monday.

Web research didn't run. Every search was refused, so the pack has no Larkfield values, interview process or strategy. It is built from your message alone, and the values round rests on the recruiter's "values and leadership philosophy" wording.

The highest-return prep is A2, the question about partnering with hardware on the roadmap when you've never owned one. The Director will likely press it, and the panel may come back to it at B3.

Say the word and I'll play the Skeptic on A2. I can also save a tuesday-dossier.md recording the gaps this prep exposed, and I can convert the pack to Word if you'd like it.

Two questions:
1. Could you paste the full job description and your CV? Without them, the pack quotes only your message, so the requirement and evidence quotes stay thin.
2. Does the role's location or onsite pattern work for you? The material doesn't settle that, and it's the one gate the pack can't resolve.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield_Systems_engineering-manager_interview_pack.md -----
# Larkfield Systems: Engineering Manager, three-round prep pack

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people)
**Rounds:**
- Round 1, Tuesday: 45 min, hiring manager (Director of Engineering). Name not given.
- Round 2, Thursday after: 60 min panel, two staff engineers and a product manager. Names not given.
- Round 3, the following Monday: 30 min, VP Engineering. Recruiter describes it as "values and leadership philosophy."

This is a first version. Research did not run (see Sources), and the pack is built from your message only.

---

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral and values, **EXP** your own work history, **JD** the role's stated requirements, **CO** company and strategy knowledge, **CASE** a live problem.
- Guidance is scaffolding, not a script. Each answer should be speakable in about 90 to 120 seconds, in your own words.
- Provenance column: `[grounded]` traces to your message. `[inferred]` is this pack's derivation. `[generic]` is a pattern for the role with no claim about you or Larkfield.
- Question IDs are letter-by-round: A1 to A9 for Round 1, B1 to B9 for Round 2, C1 to C9 for Round 3.

---

## 2. Fit snapshot (shared across all three rounds)

Requirements come from the role description in your message, which is a summary, not full JD text. Evidence comes only from your message. Nothing about your CV is quoted yet, because none was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your message | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your words say a team of six, and "3" is not defined. Say what it counts before you say it aloud. Your material does not show two squads or device management. Words: "3 as a team lead of 6." Answer slot: if you have split a team or run two at once, say how and what you decided; if not, say so and give your plan for the split. |
| F2 | "own delivery, hiring and growth for 11 engineers" — your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | This is one team's reliability quarter, not delivery across eleven engineers in two squads. Keep the claim at that scope: the quarter, the pressure, the drop. How you would run delivery for eleven is a plan, not a record. |
| F3 | "own delivery, hiring and growth for 11 engineers" — your message (hiring element) | "I run our hiring loop for backend roles" — your message, and "about 40 interviews last year" — your message | medium | [grounded] | presentation | Your sentence reaches hiring in other terms: the loop for backend roles. Bridge rewords only that: "I run our hiring loop for backend roles." It adds no figure and no event. |
| F4 | "own delivery, hiring and growth for 11 engineers" — your message (growth element) | none given | none | [grounded] | discovery | Your material does not show growing engineers. Answer slot: if you grew someone on your team, name the person's step and what you did; if no such step was yours, say so plainly and say how you would start. |
| F5 | "partner with hardware and product on roadmap" — your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | You stated the absence. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F6 | Managing managers: role-family prose, not in your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | You stated the absence. Words: "I've never managed managers." Then a ramp plan. The requirement is not in your text, so if the role has a manager layer, the JD should confirm it. |
| F7 | "Lead two squads building device-management services" — your message (domain element) | "currently at a payments company." — your message | low | [inferred] | transferability | Work at a payments company is adjacent to device-management services, not the same domain. Evidence is thin, so this is a clarify-strategy note only. Answer slot: what you expect to carry over from payments and what you do not know about device management, in your own words. |
| G1 | Location or onsite pattern: not in your message; a gate if the posting sets one | none given | none | [generic] | hard_gate | Your material does not establish the role's location or onsite pattern. Surfaced here, not bridged. The one question about it is in the message that delivers this pack. |

**Gap rules the table follows.** Confidence grades your evidence. Provenance grades what this pack wrote. Gap type says what kind of gap each row is. F5 and F6 are `capability` because you stated the absence. F4 is `discovery` because the material is silent, not because you lack the skill.

---

## 3. Prohibited claims (not coached in any round)

Each entry gives its basis and its honest form. No answer, hold, bridge or question in any round asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a hardware-adjacent roadmap, or any hardware roadmap | Negative you stated (F5) | "I've never owned a hardware-adjacent roadmap." Plain acknowledgment, no slot. |
| Managed managers | Negative you stated (F6) | "I've never managed managers." Plain acknowledgment, no slot. |
| Led two squads | Inflated form of F1: the requirement's wording, not your sentence | "3 as a team lead of 6," at its own scope. The limit is this pack's observation: your material says one team of six, not two squads. |
| The 60% drop was yours alone | Inflated form of F2: your sentence says the drop came after you pushed the quarter through, not that you caused it alone | Your sentence, at its own scope. The limit is this pack's observation: your material says the drop followed your push. Attribution slots in A7, B4 and C5 ask what was yours. |
| Ran hiring across the whole organisation | Inflated form of F3: your sentence says the loop for backend roles | "I run our hiring loop for backend roles." |

---

## 4. Round 1: hiring manager (Director of Engineering), 45 min

### Persona weights

| Persona | Questions | Why |
|---|---|---|
| Skeptic | 4 (top) | The hiring manager is buying capability and derisking gaps. Your two stated absences, managing managers and the hardware roadmap, are the first things they will test. |
| Case / Strategist | 2 | Live problems on the role's actual work: device-management services and a roadmap shared with hardware. |
| Data-Driven Prober | 2 | Your 60% figure and your 40 interviews are both headline numbers. |
| Conversational | 1 | Opener. Casual questions are still scored. |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see experience managing managers in your background. How would you handle that part of this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Say the acknowledgment in your words: "I've never managed managers." Then a ramp plan: what you would do in the first 90 days to learn it, and who you would ask. Say it as a plan, never as a past. Hold through two follow-ups by returning to the plan. | F6. The objection is in the role's silence on managers, so this is the premise the Director is most likely to press. |
| A2 | "You've never owned a hardware-adjacent roadmap. What would you do in your first month partnering with hardware?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | **Highest-ROI prep in this pack.** Say "I've never owned a hardware-adjacent roadmap," then what you would do: who you would meet, what you would ask, what you would decide in month one. Hold through two follow-ups. Concede specifically: name the part you do not know, and do not claim familiarity. | F5. The role names hardware on the roadmap, and you stated the absence, so this is the single most likely objection. Deepest rehearsal goes here. |
| A3 | "You've led one team of six. What changes when there are two squads?" | JD | [grounded] "3 as a team lead of 6" | Say what you expect to change, in your words. Answer slot: if you have split a team or run two at once, say how and what you decided; if not, say so and give your plan for the split. | F1. The jump from one team to two squads is the first thing a Director will check. |
| A4 | "Walk me through how you would grow the engineers you manage, starting with one of them." | JD | [grounded] "own delivery, hiring and growth for 11 engineers" | Answer slot: if you grew someone on your team, name the person's step and what you did, in your own words; if no such step was yours, say so plainly and say how you would start. | F4. Growth is the requirement with no quote behind it. Say which of those is true before the probe. |
| A5 | "A hardware team's firmware release slips two weeks and your software release depends on it. What do you do this week?" | CASE | [generic] | Clarify what the slip affects, then the objective, then the options: re-plan, ship without the dependency, or split the release. Name the metric you would watch. Do not claim past experience of this. | A live problem from the hardware-roadmap requirement. It needs no claim about your past. |
| A6 | "How would you plan a first quarter for two squads building device-management services? What do you need to know first?" | CASE | [generic] | Clarify first: the squads' current scope, the hardware dependencies and the release cadence. Then structure the plan and name the risks. Use only what they tell you in the room. | A live problem from the role's named work. Generic because no research ran, so you have no sourced view of Larkfield's device-management roadmap. |
| A7 | "Walk me through how the on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the quoted sentence: the reliability quarter, the roadmap pressure, the 60% drop. Answer slot: how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so. Name the weakest assumption before they do. | F2. A headline metric gets a defend-the-number slot. Do not supply a baseline or a counting method you cannot repeat. |
| A8 | "You ran the hiring loop for about 40 interviews. How did you know the loop was producing good hires?" | EXP | [grounded] "I run our hiring loop for backend roles" and "about 40 interviews last year" | Answer slot: if you measured hire quality, say what you measured; if you did not, say so and say what you would measure first. Keep the 40 at its own scope: interviews, not hires. | F3. The 40 is a figure you gave, so it raises a defend-the-number slot. |
| A9 | "So, walk me through the last few years." | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | A 90-second arc from those three beats only: nine years in engineering, three as a team lead of six, now at a payments company. Do not add a title, a team name or an outcome you did not state. | Opener, scored for communication economy. |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What would a strong first 90 days look like for the two squads?" | Shows you are already planning the job. It also tells you what they will test. |
| "Where does a roadmap decision get made when hardware and product disagree?" | Turns the hardware gap into a question about how the decision works, not about your history. |
| "What has the last person in this role found hardest?" | Surfaces the real friction without asking them to defend the job. |
| "What would make you say in a year that this hire was a mistake?" | Gives you the criteria the Director will judge by. |
| "What would you need from me in week one that you're not getting now?" | Shows you are thinking about what they need, not only what you need. |

No interviewer profile exists, so no reverse question ties to their career path.

---

## 5. Round 2: panel (two staff engineers and a product manager), 60 min

### Persona weights

| Persona | Questions | Why |
|---|---|---|
| Peer Evaluator | 3 | Two staff engineers judge whether you would be a partner to them. The product manager tests the seam with product. |
| Data-Driven Prober | 3 | Staff engineers will check your numbers and your interview practice. |
| Case / Strategist | 2 | The product manager's roadmap questions. |
| Skeptic | 1 | One question on the weakest part of the role for you on day one. |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between your squads and the hardware team, and what happens when you disagree?" | JD | [generic] | Propose seam principles, not a seam you have not seen. Say how you would decide who owns a disagreement, and what you would bring to the hardware team, not only what you would need from it. | Peer seam probe. The raising source is the role's own hardware partnership. |
| B2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Give a principle, then one case where you did it. Answer slot: if the case was yours, say what you did; if it was your team's, say which part was yours. | Peer probe on turf and credit, asked collegially. |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Name the hardware roadmap first, in your words: "I've never owned a hardware-adjacent roadmap." Then the ramp you would use. Hold position through two follow-ups. Do not offer a second weak area to look balanced. | Skeptic stem. It lets you answer the highest-ROI objection a second time, from the panel. |
| B4 | "Which part of the on-call drop would have happened without the reliability quarter?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Name the weakest assumption in the 60%: what you cannot separate from your push. Say what you would need to show the counterfactual, and say plainly if you cannot. | F2. The staff engineers are the likeliest people to press the attribution. |
| B5 | "How did you know the interview loop was producing good hires? What did you measure?" | EXP | [grounded] "about 40 interviews last year" | Answer slot: if you measured hire outcomes, say what you measured and over what period; if you did not, say so and say what you would measure first. | F3. The loop's output is a number you gave, so the measure raises a defend-the-number slot. |
| B6 | "How does device management differ from payments backend work, and where does your experience stop applying?" | JD | [grounded] "currently at a payments company." | Name the difference you actually know and the point where your experience stops applying. Say what you do not know about device management, in your words. | F7. The transfer question is the one the staff engineers will ask about domain. |
| B7 | "A hardware team wants a firmware change that breaks device-management API compatibility. Walk me through your decision." | CASE | [generic] | Clarify first: who depends on the API, what breaks, and what the timeline is. Then options, a recommendation, and the risk you would accept. | Live problem from the hardware partnership. No claim about your past. |
| B8 | "A customer asks for a feature the hardware roadmap cannot support this half. What do you tell the product manager?" | CASE | [generic] | Clarify the customer need first, then the cost of each option. Give a recommendation to the PM, not a promise to the customer. | Product-facing case. Generic because no research ran. |
| B9 | "What's the first roadmap trade-off you would bring to me?" | JD | [generic] | Name a trade-off type you would expect in two squads: scope against reliability, or hardware dates against software dates. Say how you would decide, and say which decision you would want the PM to own. | Product partnership, asked directly by the PM. |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer panel. It shows you think about what you bring, not only what you need. |
| "Where do the staff engineers spend most of their time that the managers don't see?" | Opens a peer conversation about how the work really runs. |
| "How does the product manager and the hardware lead settle a disagreement today?" | Surfaces the seam the panel is most likely to test you on. |
| "What does a good disagreement look like here?" | Gives you their standard for the peer probe. |

---

## 6. Round 3: VP Engineering, 30 min, "values and leadership philosophy"

This round is values-style: the recruiter's own words name it as one, so a values-style round is detected. Published company values are not in hand, so there is no values cheat sheet. Each VAL question below draws on the recruiter's phrase and on your own sentences, not on a Larkfield value.

### Persona weights

| Persona | Questions | Why |
|---|---|---|
| Values / Behavioral | 4 (top) | The recruiter named this round as values and leadership. |
| Pressure | 3 | A VP tests composure on your claims. Your reliability quarter is a candidate story for this round. |
| Case / Strategist | 2 | Altitude questions on the device-management roadmap. |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you pushed a decision through against pressure from above." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the quoted sentence: the reliability quarter, the roadmap pressure, and the push through. Answer slot: if you pushed it through, say what you did; if the decision was not yours alone, say which part was yours. If the stakes were a different time, give that time, and say plainly if no such time comes to mind. | F2. The open prompt's theme is one your sentence carries. |
| C2 | "What is your leadership philosophy, in your own words?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Build a 60-second answer from those beats only: nine years in engineering, three as a team lead, a team of six. Name the one principle you would test in a new role. If you have no written philosophy, say so, then describe how you ran the team of six. | Recruiter's named theme. Open prompt, so it rests on your own history, not a framework. |
| C3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time when a customer outcome and an internal metric pulled apart. It needs a named stake, the decision you made, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing you did, or how you would handle it. | Values probe. Your material carries no customer story, so the honest branch matters. |
| C4 | "Sixty seconds: why should we give this to someone who has never managed managers?" | Pressure | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Say the acknowledgment in your words: "I've never managed managers." Then your ramp plan in 20 seconds. Hold through two follow-ups. Do not argue that you are ready. | F6. Time-boxed challenge on your gap. |
| C5 | "That 60% result: how much of it was actually you?" | Pressure | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the part you did: the push, and the decision to push. Concede the uncertainty specifically: name the part of the 60% you cannot separate from others' work. Do not fold on the push itself. | F2. Attribution is the probe the pack is built to rehearse honestly. |
| C6 | "You pushed a quarter through against roadmap pressure. Who did you disagree with, and what did they say?" | Pressure | [grounded] "I pushed a reliability quarter through against roadmap pressure." | Selection scaffold: name the stake, the person, and the relationship at the end. If the relationship ended badly, say so, then say what you did about it. If no disagreement was recorded, say so plainly. | F2. The honest branch covers the case where no named disagreement happened. |
| C7 | "How would you weigh a hardware schedule against software reliability for device-management services?" | CASE | [generic] | Clarify what the hardware schedule commits and what reliability costs. Then a decision rule, a recommendation, and the risk you would accept. | Altitude case on the roadmap partnership. |
| C8 | "What would you need to see in your first 90 days to tell whether the two squads were healthy?" | CASE | [generic] | Name the measures you would watch: delivery, on-call load, hiring, and people retention. Say what each would tell you and what you would do if it went red. | Altitude question tied to the 90-day plan. |
| C9 | "How do you decide when to hold a delivery date and when to move it?" | VAL | [generic] | Give a decision rule and one example from your own work, if you have one. If not, say so and give the rule you would use. | Values-style judgment question, scored on the principle behind the decision. |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What does good leadership look like here, in one sentence?" | Asks for their standard in their own words. It also tells you what a VP actually measures. |
| "Which value, in practice, did a decision here last quarter turn on?" | Converts a values slogan into a real decision. |
| "Where does a product-versus-hardware decision get made, and who has the final say?" | Shows you have thought about the seam and wants their view of it. |
| "What would make you say in a year that this hire was the right call?" | Gives you the criteria a VP judges by. |
| "What is the one thing you would want the next manager here to fix first?" | Opens the conversation to their priorities without asking for a review of the company. |

---

## 7. Requirement coverage

| Requirement | Question IDs | Note |
|---|---|---|
| Lead two squads building device-management services | A3, A6, B6, C7 | F1, F7 |
| Own delivery | A7, B4, C1, C5 | F2 |
| Hiring | A8, B5 | F3 |
| Growth for 11 engineers | A4 | F4. No other question covers growth, which is a gap in the bank. |
| Partner with hardware and product on roadmap | A2, A5, B1, B3, B7, B8, B9, C7 | F5 |
| Managing managers (role-family prose) | A1, C4 | F6 |
| Location or onsite pattern | none, and why: a gate the material is silent on, asked in the delivery message, not in a bank | G1 |

---

## 8. Sources and research

Provided documents: your message only. No CV, no JD text, no interviewer names.

Web research was attempted at tier L1 and every call was refused, so no sourced values, process or strategy exists in this pack.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet dropped. Round 3's VAL questions rest on the recruiter's phrase and your own sentences instead. |
| 2. Larkfield Systems interview process, engineering manager | unavailable | The loop is built from the three rounds you described, which establish it. The archetype fallback does not apply, but the round structure has no source beyond your message. |
| 3. Larkfield Systems strategy and recent news | unavailable | CO questions are absent. CASE questions in Rounds 2 and 3 are generic. |
| 4. Interviewer name and Larkfield Systems | n/a | No names given, so no query could be formed. The interviewer read is absent. |
| 5. Representative engineering manager JD (device management, industrial IoT) | unavailable | With no JD supplied, the fit snapshot rests on the role description in your message, not on a JD. The JD-tagged questions are not checked against a posting. |

Calls sent, all refused:
- "Larkfield Systems values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems strategy recent news": refused
- "engineering manager device management industrial IoT job description": refused

---

## 9. Upgrade menu

- Full job description text → the requirement quotes in section 2 become JD quotes, and the JD-tagged questions get checked against the posting. Six or more rows currently rest on your summary.
- Your CV → the evidence column can quote your CV as well as your message, which lets F1 and F2 be checked against a document. Confidence can rise if there is an inspectable artifact.
- Interviewer names for Rounds 1 to 3 → persona weights from their public footprint, and a reverse question tied to their career path.
- Larkfield's published values page, pasted → the values cheat sheet for Round 3, and the VAL questions cite the named values.
- The recruiter's note on Round 3 focus areas, if any → sharpens the values bank.
- Web research permission for this session → company values, the interview process and current strategy, and CO questions. A deeper pass, up to 6 more searches and 2 more fetches, several minutes, is also available on request. Research needs permission before it can run.
- A `tuesday-dossier.md` from an earlier session would add the verified evidence and the objection this pack names as highest-ROI.
