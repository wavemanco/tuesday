# Kelverton Rail: Senior Partnerships Manager, second-round panel

**Interviewers:** Deepa (VP Partnerships, future manager) and Ross (Commercial Director). Panel, 60 minutes: a 15-minute spoken POV with no slides, then Q&A. Ross will push on commercials.

## 2. How to use this pack

Personas are how a question is asked. Types are what it scores.

- **EXP**: what you actually did, and whether it survives scrutiny.
- **JD**: the requirements the panel is scoring against.
- **CASE**: a live problem, structured aloud.
- **CO** and **VAL**: none in this pack. Research did not run, and no values page is in hand.

Guidance is scaffolding, not a script. Where a row says "answer slot", you answer from your own experience, or say plainly that the practice wasn't yours.

## 3. Prep triage (about four hours)

1. **The POV, about 75 minutes (section 5).** Write three theses, each with its concession. Speak the 15 minutes aloud twice against a timer. This is the graded deliverable and the one thing to get right.
2. **Ross's commercial pressure, about 60 minutes.** B1 first: say the hold, then the concession, aloud, three times. Then B2 and B3 on the £4M figure.
3. **Deepa's skeptic and case questions, about 45 minutes.** A3, A4 and A7 aloud. A1 is your POV again.
4. **Operator-side check, about 30 minutes.** List the rail terms you don't use yet, such as buying process and change windows. For each, write one honest sentence on whether you know it.
5. **Reverse questions and logistics, about 20 minutes.** Pick five from section 11 that you'd ask out loud.

Everything else is insurance.

## 4. Fit snapshot

No job description was supplied. The requirements below are the recruiter's own lines, as you quoted them, plus one role-family expectation marked `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email, quoted by you | "bus and light rail network planning, so I know the operator world from the other side" — your message | medium | [grounded] | transferability | Your material shows the operator world from the planning side, not operator partnerships. Bridge: "For five years I did bus and light rail network planning, so I know the operator world from the other side." Limit: that is not operator partnership work. Answer slot: say whose side the network planning work was on, and what it showed you about how operators decide. If you did not work on the operator side, say so and say what you would check first. |
| F2 | "Ross will push on commercials." — recruiter's email, quoted by you | "roughly £4M of influenced revenue" — your message | medium | [grounded] | presentation | The figure is yours and reaches the commercial ask in influence terms. Bridge: "The channel I ran influenced roughly £4M of revenue." Limit: influenced, not closed. The figure raises the defend-the-number slots in B2 and B3. |
| F3 | "Ross will push on commercials." — recruiter's email, quoted by you | "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | capability | Stated absence: direct quota. Words: "I haven't carried a direct quota. My revenue was influenced revenue." Then how you would take on a quota, said as a plan and never as a past. |
| F4 | Rail or operator-side selling: a role-family expectation, not quoted from the posting `[generic]` | "Never sold into rail specifically" — your message | medium | [grounded] | capability | Stated absence: rail selling. Words: "I haven't sold into rail specifically." Then how you would learn the buying process, said as a plan. |
| F5 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email, quoted by you | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Partner-channel growth at a payments company, not operator partnerships. Bridge: "At the payments company I took the ISV channel from 6 partners to 40." Limit: ISV partners are not operators, and you should say so. Answer slot: which of those partner decisions were yours to set, and how you decided. |
| F6 | "Please land on what it means for the operators themselves." — recruiter's email, quoted by you | none given for operator outcomes; "9 years in partnerships" — your message, which does not reach them | none | [grounded] | discovery | Your material does not show an operator's outcome moving because of a partnership you ran. Answer slot: if you have seen one, say what moved and how you know. If you have not, say so, and say how you would find out what operators measure. |

## 5. Graded deliverable: the 15-minute POV

The brief, as you quoted it: "a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

**Facts to build on** (each traces to a fit-snapshot row):

- F5: "took it from 6 partners to 40, roughly £4M of influenced revenue". Partner growth at a payments company, not operators.
- F1: "bus and light rail network planning, so I know the operator world from the other side". The planning side, not the partnership side.
- F3: "never carried a direct quota, only influenced revenue".

**Three theses, each with its mandatory concession:**

- **T1. The bottleneck is the handoff from a planning change to the systems that carry it.** Partners such as integrators and consultancies are how scheduling change reaches an operator's timetable. *Concession:* the real bottleneck may be the operator's own procurement and regulatory cadence, and I have no operator-side partnership record to test it against.
- **T2. Partnerships should move from resale to shared outcomes,** with a measure such as punctuality or change lead time that both sides own. *Concession:* outcome-linked terms need operator data that Kelverton does not control, and they move commercial risk onto us. I would want that data before committing.
- **T3. The anti-pick: do not chase every train operator.** Pick three where planning change is largest, and say no to the rest for now. *Concession:* fewer operators means a smaller pipeline in the short term, and that cost falls first on the commercial side.

**Differentiation strategy.** The consensus answer for a scheduling vendor's operator strategy is `[generic]`: more integrations, more operators on one platform, and AI-assisted timetabling. It is a prior about the market, not a fact about Kelverton. Your strategy team's report probably holds Kelverton's own consensus list, which I have not seen, so this strategy is provisional until you paste it. Bring one item from that consensus to show you have read it, then lead with T2 or T3 as the divergence, with reasons. Do not recite the report back.

**The requested close: what it means for the operators themselves.** These are priors about operators, not research on Kelverton's customers, so label them as your view. For a planning team, a scheduling change moves faster from decision to running timetable when there are fewer manual handoffs, and when a partner can carry the change into the operator's own systems. Your planning background covers bus and light rail, not train operating companies. Say which parts you know from that work and which you are inferring.

**Spoken outline, 15 minutes:**

- 0:00 to 2:00: the operator's problem, in the planning team's terms.
- 2:00 to 5:00: T1 and its concession.
- 5:00 to 8:00: T2 and its concession.
- 8:00 to 10:00: T3, the anti-pick, and what you would say no to.
- 10:00 to 13:00: what it means for operators, the close.
- 13:00 to 15:00: hand back. "That's where I'd start. I'd want to test T2 against your operators first."

## 7. Reading the interviewers

Only titles are known, and no public footprint was retrieved, so career pattern and style are unknown. Deepa is the hiring manager and future manager. Ross is the commercial executive. Tilt accordingly: Deepa runs the case, Ross tests the numbers. Nothing here reads personality.

## 8. Persona table

| Member | Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Deepa | Case/Strategist | Live problems on operator partnerships, using the company's own vocabulary | Top weight. A hiring manager buys capability and tests it on the live roadmap. | Clarify, then structure, then the plan. Say the framework aloud once. |
| Deepa | Skeptic | Probes the rail gap and the motivation for rail | Second. The CV has no rail line, and this is the likeliest objection. | Plain acknowledgment first, then the plan. No adjacent win to hide behind. |
| Deepa | Conversational | Friendly opener, then scored questions | Low. Casual openers are still scored. | A 90-second arc, rehearsed. |
| Ross | Pressure | Interrupts on quota and commercial results, time-boxes answers | Top weight. Ross said they would push on commercials, and the quota gap is the easiest target. | Pause, restate, hold through two follow-ups, then concede specifically. |
| Ross | Data-Driven Prober | Asks how the £4M was counted and what was yours | Second. A single headline number gets probed. | Name the weakest assumption before Ross does. Say plainly where you don't know. |
| Ross | Case/Strategist (commercial) | Pricing and renewal problems | Third. Commercials is the stated push. | Structure the trade-off aloud, give no invented price points. |

**Weights.** Each member's depth follows their weight: the top persona gets four questions, the middle one three, the low one two. Deepa gets nine questions and Ross gets nine.

## 9. Question banks

### Deepa (hiring manager, future manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you take our operator partnerships over the next 18 months?" | CASE, JD | [grounded] "where you'd take our operator partnerships over the next 18 months" — recruiter's email, quoted by you | This is the POV (section 5). Open with the operator's problem, not your CV. Hold three theses and don't add a fourth. | The panel's own ask. The recruiter's line is its raising source. |
| A2 | "What would an operator's planning team need from a partner that it doesn't get today?" | CASE | [grounded] "bus and light rail network planning, so I know the operator world from the other side" — your message | Structure it: who decides (planning, operations, commercial, procurement), what their cycle is, and what you would need to learn before recommending anything. Use the planning work as your lens, and say aloud that train operating work differs from bus and light rail. | Covers "what it means for the operators themselves". The question is generic; the lens is yours. |
| A3 | "Which part of this would you be weakest at on day one?" | JD (Skeptic) | [grounded] "Never sold into rail specifically" — your message | Say it first, plainly: "I haven't sold into rail specifically." Then the plan: learn how operators buy, from the people who already sell to them. Don't defend the gap with adjacent wins. | F4. A plain acknowledgment from your own words, then a plan, which is the only honest bridge. |
| A4 | "I don't see rail in your background. How would you handle a train operator's buying committee?" | JD (Skeptic) | [grounded] "Never sold into rail specifically" — your message; "bus and light rail network planning, so I know the operator world from the other side" — your message | Acknowledge the negative in your own words, then the nearest thing your material carries: the planning work, quoted above. Answer slot: if you have had direct contact with a train operator's buying process, say what and when. If not, say so and give the plan. | F4 and F1 together. Likely, because rail is absent from the CV. |
| A5 | "You ran a partner channel at a payments company. Which of that carries over to a train operator?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | Name two or three habits that carry over, such as recruiting, enabling and measuring partners, in your words. Name one that doesn't. | F5's transfer. The limit is the pack's observation, not a claim for you to make. |
| A6 | "Walk me through how the channel went from 6 partners to 40. Which of those moves were yours?" | EXP (Skeptic) | [grounded] "took it from 6 partners to 40" — your message | Give three or four moves in your own words. For each, say whether it was yours to set and how you decided. If one was someone else's, say so. Hold the number; attribution is where the probe goes. Answer slot: if a move was yours to decide, say how you decided. If it was not, or none was, say so. | F5. The number is the strongest thing in the pack, so the attribution is where a prober goes next. |
| A7 | "What brings you to rail, given you've never sold into it?" | JD (Skeptic) | [grounded] "Never sold into rail specifically" — your message; "bus and light rail network planning, so I know the operator world from the other side" — your message | Give your reason in your own words, tied to the planning work quoted. Say the rail gap in the same breath, not after it. Don't claim a long-standing interest you cannot show. | Motivation probe. F1 and F4 together. The reason is yours to give; the pack does not supply it. |
| A8 | "So, walk us through the journey." | EXP (Conversational) | [grounded] "9 years in partnerships" — your message; "bus and light rail network planning" — your message | A 90-second arc: nine years in partnerships, five years of transport consulting, the last four running a payments channel, and why operators. Cut anything past 90 seconds. | Casual openers are scored. A rehearsed arc stops the rambling. |
| A9 | "What do you know about how an operator changes a timetable?" | CASE (Conversational) | [grounded] "bus and light rail network planning" — your message | Answer slot: say what your bus and light rail planning work showed you about change cycles and sign-off, in your words. If it didn't show you a sign-off step, say what you would ask. Then say what you expect to differ for trains, as a question. | A plus-skill asked casually. Limited to the planning work you quoted. |

### Ross (Commercial Director)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a direct quota. Why would we hire you into a commercial role?" | JD, EXP (Pressure) | [grounded] "never carried a direct quota, only influenced revenue" — your message | **Hold:** "I haven't carried a direct quota. My revenue was influenced revenue, roughly £4M, from the channel." Hold through two follow-ups by returning to what you did to influence it, in your words. **Concede:** "a direct number is new to me," then the plan: how you would take on a quota in the first 90 days, said as a plan. Never say you have carried one. | **Highest-ROI prep in this pack.** Ross has said they will push on commercials, and this is the most predictable hit. The hold is only what the quote carries. |
| B2 | "£4M of influenced revenue. How did you count it, and what would you defend least?" | EXP (Prober) | [grounded] "roughly £4M of influenced revenue" — your message | Say how you counted it, in your own words. If you don't know the method, say so plainly. Name the weakest assumption before Ross does. Say which part was yours. Answer slot: if there was a counting rule, say what it was. If there was none, say so. | The figure raises only the defend-the-number slots. No method is supplied here. |
| B3 | "How much of that £4M would you say closed, and how do you know?" | EXP (Prober) | [grounded] "roughly £4M of influenced revenue" — your message | Say what you can tie to closed business and what you cannot. If you have no closed figure, say the influenced figure is what you carry, and say what closed figure you would want to see in the first month. | Influenced against closed is the gap Ross will test. No closed figure is in the material. |
| B4 | "How would you price an operator partnership: per seat, per timetable change, or on outcomes?" | CASE, JD | [generic] | Name the three structures and the data each needs from the operator first. Say what you would test first, and why outcome pricing carries risk. Give no price points; you have none for this market. | The commercial push. No research ran, so no Kelverton pricing is assumed. |
| B5 | "On a partner deal, who keeps the margin, and what do you set?" | EXP (Prober) | [grounded] "running the ISV channel" — your message | Answer slot: if you set partner terms or margin, say which and how you decided. If you did not, say so, and say what you would look at first. | The quote says running the channel, not setting its terms. |
| B6 | "Of the partners you took from 6 to 40, how many are still active?" | EXP (Prober) | [grounded] "took it from 6 partners to 40" — your message | Answer slot: if you have the retention figure, say it and how it was counted. If you don't, say so. | The defend-the-number slot for a partner count. |
| B7 | "Give me a reason we shouldn't hire you. Sixty seconds." | JD (Pressure) | [grounded] "never carried a direct quota, only influenced revenue" — your message; "took it from 6 partners to 40" — your message | Say the gap plainly in the first ten seconds: no rail, no direct quota. Then the case for the hire, in your words, from the channel growth. No spin. | Pressure stem. Hold the honest version under time pressure. |
| B8 | "Our largest operator account renews in six months and the sponsor has gone quiet. What do you do this week?" | CASE | [generic] | Clarify before you plan: who holds the renewal, what has changed, what you know. Name your first call, and the first thing you would not do. No account facts are given, so do not invent any. | Live problem, asked as a decision. It makes no claim about your past. |
| B9 | "Which two operators do you approach first, and why?" | CASE | [generic] | Criteria: scale of planning change, willingness to co-develop, timing. Say what data would change the choice. Include the no-go for the rest. | The anti-pick from T3 applied live. |

**Coverage.** The commercial push is in B1 to B5 and B7. The POV is in A1 and D1. Rail is in A3, A4 and A7.

## 11. Reverse questions

Each one has a "why it lands" line.

- **"What have your operator partners asked for in the last year that the product didn't do?"** Why it lands: it shows you are asking about operators, not only pitching.
- **"How do the partnerships and commercial teams split a deal with a train operator today?"** Why it lands: Ross will hear commercial awareness in it.
- **"What would working look like for an operator partnership at month 18?"** Why it lands: it ties back to the POV and asks them to define the success you were arguing for.
- **"What has been tried with operator partnerships that didn't land?"** Why it lands: it shows you want the real history, and it invites candour.
- **"What does the commercial number for this role look like in year one?"** Why it lands: it sets up the commercial conversation on their terms.

## 13. Prohibited claims

These are the claims this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have sold into rail." | A negative you stated, F4. | "I haven't sold into rail specifically." No slot. |
| "I have carried a quota." or "I owned a revenue number." | A negative you stated, F3, and an inflated form of your influenced revenue. | "I never carried a direct quota, only influenced revenue." |
| "I built operator partnerships." | An inflated form of F5, which is partner growth at a payments company. | "I took the ISV channel from 6 partners to 40." |
| "I know how operators make decisions." | An inflated form of F1, which is planning work. | "I know the operator world from the other side." Quoted at its own scope. |
| "That £4M was closed revenue." | An inflated form of F2, which is influenced revenue. | "Roughly £4M of influenced revenue." |

## 14. Sources

- **Provided documents:** your message, including your background and the recruiter's lines quoted in it. The internal market report you mentioned was not pasted into this session, so nothing from it is used.
- **Research tier:** L1, searches 3 of 6 (all refused), fetches 0 of 2. No search returned a result; this session refused web search permission.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Refused. The values cheat sheet is absent and no values round is detected. |
| 2. Kelverton Rail interview process | unavailable | Refused. The loop is established by the recruiter's words instead: a 60-minute panel with a 15-minute POV first. |
| 3. Kelverton Rail strategy or recent news | unavailable | Refused. Would have fed the grounding brief and the CO questions, both absent. |
| 4. Deepa or Ross public footprint | unavailable | No search sent. Would have moved persona weights and one tailored reverse question. |
| 5. Representative Senior Partnerships Manager JD | unavailable | No search sent. The JD was not supplied, so the fit snapshot rests on the recruiter's lines. |

Searches sent: "Kelverton Rail values" (refused); "Kelverton Rail interview process partnerships manager" (refused); "Kelverton Rail strategy news train operators scheduling software" (refused).

## 15. Upgrade menu

- A job description, pasted → the fit rows gain JD-quoted requirements. F4 becomes grounded or drops, and the commercial line may change.
- The strategy team's report, headline or consensus list, pasted → the differentiation check in section 5 runs against Kelverton's real consensus, not the generic one.
- Web search permission for this session → the three refused targets run (values, interview process, strategy). The interview process would confirm the loop rather than change it.
- Public talks or posts by Deepa or Ross → persona weights, and one reverse question tied to their own path.
- Whether the transport consulting work was for operators or for agencies → settles the answer slots in A2, A4 and F1.
- `tuesday-dossier.md`: one line on what it would add. It would record the gaps this prep exposed, for later sessions.
