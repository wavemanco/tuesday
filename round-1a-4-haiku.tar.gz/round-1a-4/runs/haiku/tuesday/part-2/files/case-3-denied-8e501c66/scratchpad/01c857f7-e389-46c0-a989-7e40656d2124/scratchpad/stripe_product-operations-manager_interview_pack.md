# Stripe, Product Operations Manager: final-round prep pack

First version. Built from the company and role you gave. No CV, job description, interviewer name or round details were supplied, and web research was not available this session, so nothing about Stripe's values, interview loop or strategy is in this pack.

## How to use

- Personas are how a question is asked. Types are what it scores.
- Type key: **VAL** behavioral and values, **EXP** your own experience, **JD** the role's stated work, **CO** company and strategy, **CASE** a live problem.
- Guidance is scaffolding for a spoken answer, not a script. Rehearse only what you actually did, in your own words.
- Provenance: every question here is `[generic]`, a pattern for product operations roles, not a fact about Stripe or about you.

## Fit snapshot (worksheet variant)

No JD, CV or recruiter wording was supplied, so the requirements below are role-family patterns. None is quoted from a source, and every evidence cell is `none given`. Each row becomes a story map once your CV or your own sentences arrive.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run a cross-functional process or launch from start to finish (role-family pattern) | none given | none | [generic] | discovery | Answer slot: pick one process or launch you took part in. Say what it was for, who else was in it, and how it ended. If no such one comes to mind, say so plainly, then give the nearest thing you ran, or how you would run one |
| F2 | Define and track metrics for an operating process (role-family pattern) | none given | none | [generic] | discovery | Answer slot: name a number you tracked for a process, what it counted, and the assumption behind it you would defend least. If you tracked none, say so, then say what you would measure first |
| F3 | Prioritise competing requests across teams (role-family pattern) | none given | none | [generic] | discovery | Answer slot: pick a time two teams wanted different things from you. Say what you did, and which part of the decision was not yours |
| F4 | Work with engineering, finance, legal or operations partners (role-family pattern) | none given | none | [generic] | discovery | Answer slot: a partnership where you did not own the outcome. Name the disagreement and what you did about it |
| F5 | Improve a process or tool so the change holds (role-family pattern) | none given | none | [generic] | discovery | Answer slot: a change you proposed. Say what you can show is still in use, and what you cannot show |
| F6 | Write and present clearly to senior people (role-family pattern) | none given | none | [generic] | discovery | Answer slot: a document or update you sent a senior reader. Say what it asked them to decide |

Your material does not show any of these yet. That is an observation about the pack, not a claim about you.

## Persona table

Round type and relationship are unknown, and no loop source establishes a loop. So the weights are flat, and each persona gets three questions. Every persona appears so you do not meet a style for the first time live.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live product-ops problem, scored on structure | Flat. No round type given, so this is an assumption | Clarify, then structure, then name a metric and a risk |
| Data-Driven Prober | Pushes on how a number was counted | Flat. Likely for any ops role that reports metrics | Say how you counted, and your weakest assumption, before they ask |
| Pressure / Stress | Interrupts and challenges your motive or impact | Flat. Unknown without the interviewer's style | Pause, restate, hold through two follow-ups, concede a specific point only |
| Skeptic | Probes the gap between the role and your background | Flat. Likely, because no CV is in the pack yet | Rehearse the objection until it is plain; say what you have not done |
| Peer Evaluator | Seams between teams; credit and disagreement | Flat. Likely if a cross-functional partner is in the panel | Propose seam principles; do not claim to know their seam |
| Conversational / Rapport | Casual openers that are still scored | Flat. Common in a final round, and treated as scored | 90-second arc; treat casual questions about the role as scored |
| Values / Behavioral | Past-behavior questions, STAR-shaped | Flat. No values round is assumed, since the company's values were not checked | Stories by the same method; no company value is mapped |

## Question banks

Coverage line: F1 is covered by A1, A3 and G3. F2 by A2, B1 and B2. F3 by A1 and E2. F4 by E1, E2 and E3. F5 by A3 and G3. F6 by C1 and F1.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch approval process is taking three weeks, and two teams blame each other. How would you approach it?" | CASE | [generic] | Clarify first: which launches, where the three weeks go, where the handoffs sit. Diagnose before you fix. Name the metric you would use to check the fix | Live problem from the role's own work. Asks about no past, so it presupposes nothing about you |
| A2 | "Which metric would tell you this process is working, and what would it miss?" | CASE | [generic] | Name one primary metric and one guardrail. Say what the primary metric could hide | Tests metric judgement, and the likeliest place for a Prober to follow up |
| A3 | "You have a month and one analyst for an operations problem you do not yet understand. What do you do in week one?" | CASE | [generic] | Scope it: talk to the people who run the process, map it, then size the largest bottleneck. Say what you would not do | Tests scope under ambiguity |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a metric you have used to run something. How was it counted?" | EXP | [generic] | Pick one metric you used. Say what it counted, where the data came from, and the assumption you would defend least. Answer slot: if you used none, say so plainly and say which one you would use | Persona stem. Probers test attribution, so the answer has to be one you can repeat under a second question |
| B2 | "When you report a number, which assumption behind it is hardest to defend?" | EXP | [generic] | Name the assumption in your own words. If you do not report numbers yet, say what you would name first | Persona stem as an open prompt. It asks for a choice, not a figure |
| B3 | "A dashboard shows a 20% drop. What do you check before you believe it?" | JD | [generic] | Check the definition, a change in data collection, timing and sampling, then the business cause. Say the order aloud | Typical ops-metrics probe. Hypothetical, so no past claim |

### C. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we hire you over someone who has done this exact job?" | JD | [generic] | Pause, then restate the question. Give the strongest point you can stand behind. Hold through two follow-ups. If the honest answer is that you have not done this exact job, say so, then give the closest work you have done and how you would close the gap. Concede one specific uncertainty without folding on the core | Persona stem. Hold-then-concede is the structure this persona scores |
| C2 | "That sounds like a small part of the result. How much of it was actually you?" | EXP | [generic] | Name what you did in your own words, what others did, and where you were not decisive. Claim no credit you cannot describe. Hold the position through two follow-ups | Persona stem. Tests attribution honesty |
| C3 | "Why this kind of work, and why now?" | EXP | [generic] | Give one honest reason, then one tied to the role's work. Drop adjectives such as "passionate" | Motivation probe that Pressure interviewers press on |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one part plainly. Give a ramp plan. Do not claim a competence you lack | Persona stem. Calibrated candor scores better than bluffing |
| D2 | "I do not see much operations experience in your background. How would you handle that?" | EXP | [generic] | Say what you have not done, plainly. Then give the closest work you have done and your plan for the gap. Answer slot: the pack has no CV, so it cannot say what the closest work is. Say it yourself | Persona stem. This is the highest-ROI rehearsal in this pack: the objection is the most predictable, and the honest answer is the one that holds |
| D3 | "Why leave where you are, and why would this role keep you?" | EXP | [generic] | Give your real reason in one sentence. Keep it about the work, not about the employer you are leaving | Motive question. Answers that criticise a former employer tend to backfire |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our engineers would be the ones changing the tools. Where does product ops end and their work begin?" | JD | [generic] | Propose seam principles: who decides scope, who owns tool changes, how a disagreement is settled. Do not pretend to know their seam | Persona stem. Peers price what a hire adds to their work |
| E2 | "Tell me about a time two teams disagreed about a process. How did you handle it?" | EXP | [generic] | Pick a time you were in the room. Say what each side wanted and what you did. Answer slot: if you were not in the room, or it was not yours to handle, say so plainly and describe how you would handle it | Open prompt. Theme from the Peer stem |
| E3 | "How do you give credit when work spans teams?" | EXP | [generic] | Name a practice you use. Say what you do when credit is contested | Persona stem. Tests collegiality |

### F. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through how you got into this kind of work." | EXP | [generic] | A 90-second arc: the path, the work you did, why this role now. Answer slot: pick the three moments that changed the kind of work you did. If none changed it, say so, then describe the path as it was | Biography opener. Scored, even though it sounds casual |
| F2 | "What are you playing with in operations tooling these days?" | JD | [generic] | Name the tools you have actually used and in what capacity. If you have only read about one, say so and say how you would learn it | Casual question on a JD topic. Treat as scored |
| F3 | "Anything you want to know about the team?" | CO | [generic] | Ask one of the reverse questions below. Never answer "I think you have covered everything" | Rapport interviewers weight the closing slot heavily |

### G. Values / Behavioral (no company value mapped)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [generic] | Pick a time the message landed. Say what the truth was, who you told, and what happened after. Answer slot: if none comes to mind, say so plainly, then give the nearest one, or how you would handle it | Open prompt. Behavioral, not mapped to a company value, because the values were not checked |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time you chose the customer's outcome over a number. Say what the number was and what you did. Same honest branch as G1 | Open prompt. Common in ops interviews |
| G3 | "Describe a process you improved that people still use." | EXP | [generic] | Name the process, what changed, who uses it now, and how you know. Answer slot: if you do not know whether it persists, say so | Tests whether a change held, which the role needs |

Session total: 21 questions, seven personas at three each. The pack does not name which personas the round will use.

## Reverse questions

Each has a "why it lands" line. No interviewer profile exists, so none is tied to a career path, and the round is not known to be peer-level, so no reciprocity question is included.

1. "What would a strong first 90 days look like for this role?" Why it lands: you are planning for the job, not the title.
2. "Which operating process here most needs attention right now, and what has been tried?" Why it lands: you learn the state of the work, and ops interviewers respect that question.
3. "How do product ops and the product and engineering teams decide what changes?" Why it lands: this is the seam question, and it shows you think about decision rights.
4. "How is success in this role measured, and who decides that?" Why it lands: you learn how you will be scored.
5. "What has changed about this role in the last year?" Why it lands: it shows you want the current role, not last year's.
6. "What is the hardest tradeoff this team is living with right now?" Why it lands: it invites candor, and you can answer it back later.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any figure, outcome, team size or result from your past that you did not give in your own words | Truthfulness core. No quoted sentence exists yet | Only what you say in your own words. This pack supplies none |

No inflated-form entry exists yet, because no sentence of yours is quoted. The list fills once your CV or your own sentences arrive.

## Sources

Provided documents: the company name and the role title in your message. Nothing else.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet. Search refused (permission not granted), so no values page was read. The cheat sheet is absent and no value names appear in this pack |
| 2. Stripe interview process, product operations | unavailable | Loop structure and persona weights. Search refused, so the loop is unestablished and weights are flat |
| 3. Stripe strategy and recent news | unavailable | CO and CASE questions grounded in current strategy. Search refused, so those questions are generic |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Fit snapshot requirements and JD-tagged questions. No search was sent, so the fit rows stay generic |

Queries sent, all refused: "Stripe company values operating principles" (target 1); "Stripe interview process final round Product Operations Manager" (target 2); "Stripe strategy recent news 2026" (target 3). No page was fetched.

No loop source establishes the loop. Under the generic archetype, no values round is assumed, and the persona weights are flat.

## Upgrade menu

- JD text → the six `[generic]` fit rows become `[grounded]` and quote the posting; JD-tagged questions are retuned to its own words
- Your CV, or your own sentences about past work → the fit rows gain quoted evidence, and the answer slots become story maps wherever a sentence carries one
- Recruiter's note on focus areas, or any take-home or presentation → coverage of any declared deliverable
- Interviewer's name → persona weights from their public footprint, and a reverse question tied to their path
- Web search allowed for this session → values, loop structure and strategy become `[grounded]`, and the values cheat sheet and CO questions appear
- `tuesday-dossier.md` from an earlier session → gaps it records would feed the Skeptic and Pressure banks
