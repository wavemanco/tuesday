# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: 45-minute conversation with the hiring manager, Thursday 26 November 2026. Interviewer: not named. Relationship: hiring manager, session mode (one session, as you described it).

Built from your underwriting dossier (generated 2026-08-14). Its `role_profile` stands in for the job description and its `verified_candidate_evidence` for your CV. No CV or posting text was pasted, and no web research ran (see Sources).

## How to use + type key

Personas describe how a question arrives. Types describe what it scores.

- **VAL**: behavioral / values alignment
- **EXP**: work-experience deep-dive; whether your claims survive scrutiny
- **JD**: role and JD-driven; whether you can do the listed job, gaps included
- **CO**: company and strategy knowledge (none in this pack; see Sources)
- **CASE**: live problem, delivered in the room

Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview: it asks for no reply here, and it names a practice only where the posting raises it.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [inferred] derived from the dossier's transferability entry for R1 | transferability | Your material shows integration work at its own scope, from scoping to go-live. It does not show product management or a PM title, so the bridge stays at that scope. Name the limit yourself before it is asked. Answer slot: if you set the order or scope of any integration, say which and how you decided; if someone else set it, say so plainly. |
| F2 | "Shipped API or platform products" (dossier role_profile R2, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | The quote is integration work on the vendor's APIs for clients. The dossier does not list R2 as weak; this pack grades it transferability because the verified entry is integrations, not a product you shipped. Answer slot: if you shipped something clients or partners used as a product of your own, say what and what your part was; if the work was integrating the vendor's APIs, say so plainly. |
| F3 | "Technical fluency: API docs, schemas" (dossier role_profile R3, important) | "Wrote the internal integration playbook her team uses" — dossier V2 | high | [grounded] | discovery | The playbook is documentation work you can inspect. Nothing in the material shows API schemas. Answer slot: if you wrote, reviewed or changed API schemas, say which and what you checked; if you did not, say so, and say how you would learn the schema side of this role. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [grounded] confirmed, limited inspectable proof; expect a probe | transferability | The sessions reach clients and product. They do not reach engineering or sales. Volunteer that limit before it is extracted. Answer slot: if you managed engineering or sales stakeholders on a decision, say which and what you did; if not, say so, and say how you would bring them in. |
| F5 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [inferred] derived from the dossier's discovery entry for R5 | discovery | Nothing in the material shows Agile delivery. The interviewer's probe is the requirement's own wording; the honest answer is an answer slot, not a bridge. |
| F6 | "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibilities) | none given | none | [grounded] dossier uncertain_or_weak_areas, acknowledge_gap | capability | Your roadmap ownership and prioritization are a stated gap. Words: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then how you would learn it, as a plan and never as a past. |
| F7 | "Define and track adoption metrics" (dossier role_profile responsibilities) | none given | low | [inferred] derived from the dossier's open risk on adoption baseline | discovery | Nothing in the material shows adoption measurement. Answer slot: if you tracked whether a partner or client took up an integration, say what you counted; if not, say so, and say what you would measure first. |

Two notes. The dossier's `evidence_map` and `risk_register` are absent from the file you carried, so the grades above come from `role_profile` and `handoff_to_mock_interview` alone. F2's grade differs from the dossier's silence on it, and that is this pack's call to correct with the dossier's owner, not an edit to the dossier.

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gaps: the PM record, the roadmap, the day-one weakness | 5. Hiring-manager prior is Skeptic plus Case. The dossier's gaps (F1, F6) are where it will press | Rehearse A1 until it is boring. Bridge only from quoted work. Acknowledge the roadmap plainly |
| Case / Strategist | Live problems from the role: partner requests, adoption, delivery across two squads | 4. Second prior. The posting's discovery and adoption responsibilities give it material | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud |
| Data-Driven Prober | Depth on the headline number and on what it measures | 3. Not a prior for this relationship, but the 30+ figure (F2) raises the defend-the-number slots | Know how the figure was counted, or say you do not. Name the weakest assumption before it is named for you |
| Pressure | Interrupts, time-boxes, questions motive | 3. Not a prior, but a 45-minute slot with a hiring manager can be time-boxed | Pause, restate, hold two follow-ups, then concede specifically |
| Conversational | Openers and casual questions that are still scored | 3. Openers set the tone, and the JD's tooling question is asked casually | Have a 90-second arc ready. Never answer a reverse-question slot with "you've covered everything" |

Values / Behavioral is not weighted. The loop is the one session you described, and nothing establishes a values round, so no values-style round is detected.

## Question banks

Session total: 18 questions. Each row's Provenance lists the candidate sentences the guidance rests on.

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); dossier prohibited_claims: "Having held a product manager title or role"; "Having owned a product roadmap" | Highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't held the product manager title, and I haven't owned a roadmap." Then the bridge at its own scope: "What I bring is the integration work: I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live." Concede the track-record point in your own words: a PM with three years has the record and you do not. Then the ramp, as a plan: which decisions you would take first and what you would learn before taking them. Hold through two follow-ups before conceding anything more | The dossier named this objection, so it gets the deepest rehearsal. Its negatives are the dossier's prohibited claims, so they are sourced. Built on F1 and F6 |
| A2 | "Walk me through the last integration you led, from scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Story-mapped on F2. The beats the quote states are scoping, requirements, architecture, UAT and go-live; tell them in your own words and in that order. Answer slot: if you set scope or architecture on it, say which and how you decided; if someone else set it, say so plainly | F2 is the requirement this occasion tests; EXP because it asks what you did on one occasion |
| A3 | "On the integrations you led, who had the final say on scope?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Answer slot: name who had the final say and what you contributed to it. If you had it, say what you decided; if you did not, say so plainly and name who did. Do not add a decision the quote does not carry | F1 is where decision authority presses. The question presupposes a scope decision the quote does not name, so the second branch allows that others set it |
| A4 | "In a delivery with two engineering squads, where would your authority stop?" | JD | [grounded] dossier prohibited_claims: "Having set prioritization for an engineering squad" | Plain acknowledgment: "I haven't set prioritization for an engineering squad." Then the edge of your authority in your own words: you can describe what you did on the integrations; squad priorities are not yet yours; say how you would learn where the line sits | F6 and the posting's "drive delivery with two engineering squads". The answer names the edge of authority, never a squad's priorities |
| A5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] dossier uncertain_or_weak_areas, acknowledge_gap: "Owning a roadmap and prioritization authority" | Name the roadmap and prioritization part first, in plain words, then the ramp: whom you would learn the decision rights from in your first weeks. Then stop. Do not add a second weakness unless asked | A persona stem. It lets you name the gap before the objection does |

### B. Case / Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner asks for a webhook for a feature you suspect few of their peers use. Walk me through how you'd decide whether to build it." | CASE | [generic] | Clarify what the partner needs and how many partners ask. State the objective, segment the partners, then approach: check the request against adoption of similar features before any build decision. Name the metrics and risks. Think aloud | The posting's "Run discovery with integration partners" makes this the likely live problem. A pattern, not a fact about this team, so it carries no past claim |
| B2 | "Adoption of the partner API has been flat for a quarter. How would you diagnose it?" | CASE | [generic] | Ask first what adoption is measured by and what the baseline is. The dossier's open risk names no baseline, so do not propose a number as if one exists. Then segment and approach | The posting's "Define and track adoption metrics" and the dossier's open baseline risk. The guidance asks for the baseline rather than assuming one |
| B3 | "How would you set the delivery cadence for two squads on one platform roadmap?" | JD, CASE | [grounded] "Agile delivery experience" (dossier role_profile R5) | Clarify the delivery model the squads already use, then propose a cadence with their input. Answer slot: if you have delivered work in an Agile way, say which and what your part was; if you have not, say so, and say what you would want to confirm about how this team defines Agile delivery | F5's clarify strategy. The answer slot names the requirement's own wording as the probe |
| B4 | "If you had to decide which roadmap items the two squads take this quarter, what would you need to see first?" | CASE | [grounded] dossier uncertain_or_weak_areas, acknowledge_gap: "Owning a roadmap and prioritization authority" | Name the inputs first: partner evidence, squad capacity, and who holds the final call. Say plainly that you have not set priorities for a squad, then answer as a plan | Covers R4 (engineering, sales, customers) through the inputs. It does not present a prioritization record |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you count the 30+ integrations?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Answer slot, defend-the-number. Say how the 30+ was counted, in your own words. Say what it is sensitive to. Name the assumption behind it you would defend least. Say which part of the 30+ was yours. If you do not know how it was counted, say so | The figure raises the defend-the-number slots. The pack supplies no counting method, and an explanation you cannot repeat under a second question is worse than none |
| C2 | "What did UAT catch on those integrations, and how did you record it?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Answer slot: say what UAT caught and how you recorded it, in your own words. If nothing was recorded, or someone else ran UAT, say so plainly | UAT is a beat the quote states; the question presupposes findings and records, so the second branch lets them not exist |
| C3 | "Walk me through how you would check an API schema change before a partner sees it." | JD | [generic] | Structure it: what changes, who consumes it, how you would version and test it, how partners learn of it. Describe the process you would run and claim nothing about your past. Answer slot: if you have checked a schema change yourself, say how; if not, say how you would learn the process | F3's gap. Generic because the scenario is the role's pattern, not this team's practice |

### D. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate who has done the PM job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); dossier prohibited_claims: "Having held a product manager title or role" | Pause. Restate the question in your own words. Hold the bridge: the integration work is what you bring, at its own scope. Concede the track-record point once, specifically. Hold through two follow-ups before conceding anything more | Tests composure. The held position is the quoted work, never a PM record |
| D2 | "That 30+ figure — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Hold: say which parts of the integrations you led, in your own words. If you cannot split the work cleanly, say that rather than guessing a split | Attribution pressure on the same figure as C1. Hold, then concede the part you cannot separate |
| D3 | "You ran roadmap-input sessions. That is not owning a roadmap, is it?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3); dossier uncertain_or_weak_areas, acknowledge_gap: "Owning a roadmap and prioritization authority" | Hold once: the sessions fed client evidence to product, and that is all they did. Concede on the second follow-up: "No, I haven't owned a roadmap." Do not extend the sessions to decisions | Hold-then-concede. The honest concession is the other half of the hold |

### E. Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey to here." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); "Wrote the internal integration playbook her team uses" (dossier V2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | A 90-second arc in your own words: the integrations, then the playbook, then the input sessions, then why this role. The "why this role" is yours to say; the pack does not supply it | A rapport opener that is still scored for economy. The arc uses only the three quoted sentences |
| E2 | "What are you actually playing with in partner-facing APIs these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" (dossier V2) | Answer slot: name the API tooling you have actually used, and for each, what you did with it. If you have not used a tool the role names, say so | F3's fluency probe, asked casually and still scored |
| E3 | "What made you apply for this one?" | JD | [generic] | Answer in your own words, in under two minutes. Make no claim about the role's content beyond what the posting says | Motivation consistency for the move into product. No quoted sentence carries it, so the guidance gives a shape only |

**Requirement coverage**

| Requirement | Questions |
|---|---|
| R1, 3+ years product management | A1, A2, A3, A5, D1 |
| R2, shipped API or platform products | A2, C1, C2 |
| R3, API docs and schemas | C3, E2 |
| R4, stakeholder management | A4, B4, D3 |
| R5, Agile delivery | B3 |
| Responsibility: own the roadmap | A1, A4, A5, B4, D3 |
| Responsibility: define and track adoption metrics | B2 |
| Responsibility: run discovery with partners | B1 |
| Responsibility: write specs and drive delivery | A4, B3 |

## Reverse questions

Five, each with why it lands. None is tied to an interviewer's path, since there is no profile. Each rests on a dossier entry.

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" — The posting does not show decision authority against the squads, and you need the answer before accepting.
2. "How is partner API adoption measured today, and what is the current baseline?" — No baseline is stated. The answer tells you whether the adoption work builds a measure or runs one.
3. "When a partner's request conflicts with the roadmap, where does that call get made?" — It tests the seam between sales, customers and engineering, and it reads as diligence.
4. "How does delivery run across the two squads today — is there a cadence, and who owns it?" — The posting names Agile delivery as preferred without showing how it is run.
5. "What would make you say at six months that this hire was the right one?" — It surfaces the success criteria before you are measured against them.

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Held a product manager title or role | dossier prohibited_claims: "Having held a product manager title or role" | "I haven't held the product manager title." The adjacent quote at its own scope (V1) |
| Owned a product roadmap | dossier prohibited_claims: "Having owned a product roadmap"; uncertain_or_weak_areas, acknowledge_gap | "I haven't owned a product roadmap." |
| Set prioritization for an engineering squad | dossier prohibited_claims: "Having set prioritization for an engineering squad" | "I haven't set prioritization for an engineering squad." |
| Shipped an API product (inflated form of F2) | Wording stretched beyond V1, which is integration work | V1 at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs". The limit is this pack's observation, in analysis |
| Ran discovery with integration partners (inflated form of V3) | Wording widens "Ran quarterly roadmap-input sessions feeding client evidence to product" | V3 at its own scope. The sessions fed client evidence to product |

## Sources

**Provided documents.** Your underwriting dossier, pasted into this conversation and read under the 1.x rules. Sections consumed: `role_profile`, `handoff_to_mock_interview`. Section read for context only: `decision` (conditional_go, with positioning discipline as the condition). Not present: `evidence_map`, `risk_register`, `evidence_state`, `candidate_constraints`. V1 to V3 are the three `verified_candidate_evidence` entries in the order the dossier gives them. The dossier is dated 2026-08-14, about three months before the interview, so its unknowns and risks predate any change to the posting.

**Research tier: L1 — searches 3 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet. Not built, and no values-style round is detected, so no VAL questions are written. Every search sent was refused |
| 2. Quartzline interview process, product manager platform APIs | unavailable | Loop structure. Not needed for the round itself, since you described it; it would have shown whether other rounds follow. Every search sent was refused |
| 3. Quartzline strategy / recent news | unavailable | CO bank. Not built. Every search sent was refused |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative product manager JD | skipped | The dossier's `role_profile` fixes the requirements |

Searches sent, all refused:
- "Quartzline values": refused
- "Quartzline interview process product manager platform APIs": refused
- "Quartzline strategy news": refused

## Upgrade menu

- Web search permission granted → the three refused searches run. Values would add a values cheat sheet, and strategy would add CO questions.
- Quartzline's values page, or the recruiter's note on the round's format, pasted → a values section if a values round is named, and confirmation of whether the 45 minutes is the whole loop step.
- The interviewer's name → a tailored reverse question, and persona weights from public footprint.
- The current posting text, if it has changed since August → the `role_profile` lines become checked against the live posting, and the open unknowns get answered or sharpened.
- Your CV → F1, F5 and F7 can move from `[inferred]` to `[grounded]`, and the stories behind the dossier's claims become mappable to the quoted sentences.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes, run only with your consent. Its strategy brief would feed the CO bank.
