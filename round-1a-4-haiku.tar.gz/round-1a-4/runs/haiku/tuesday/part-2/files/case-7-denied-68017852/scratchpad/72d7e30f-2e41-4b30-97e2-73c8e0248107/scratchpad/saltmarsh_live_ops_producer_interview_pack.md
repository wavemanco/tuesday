# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship and round type not stated; built as a hiring-manager round (assumption, see Persona table). Format: 60 minutes.

Research: the web search tool was refused in this session, so no company, interviewer or process facts are established. Everything about Saltmarsh and Tobias is absent or labeled `[generic]`.

## How to use

- **Personas** = how a question arrives. **Types** = what is being scored: JD (the listed job), EXP (your experience, attribution), CASE (live problem), VAL (values; not detected here), CO (company knowledge; not researched here).
- Guidance is scaffolding, not a script. Rehearse out loud, in your own words.
- Answer slots (sentences starting "if ... say so") are instructions for the interview, not questions for you.

## Fit snapshot

Requirements are quoted from the JD you supplied. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title and content drops, not live events across two titles. Say it at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the two-title scope makes a probe on how you would scale likely. If you ran events, or worked across a second title, say which; if not, say what you would do first. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating these teams. The JD's verb is coordinate, and you said "Never led a team", so keep those apart. Answer slot: if you coordinated any of these teams on a drop, say which and how; if not, say so and describe how you would run it. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | low | [inferred] | transferability | Your material says you presented retention numbers, not that you owned the KPIs or ran post-event reviews. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which numbers went in that presentation, say so; if you did not, say so and say what you would review first after an event. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | Direct match. Expect a probe on how much was yours alone, since it is one line with little inspectable proof. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | low | [inferred] | transferability | Four years meets the length. Your material does not say whether the puzzle title was live-service. Answer slot: if it ran ongoing content for an active player base, say how you know; if it was a release with no ongoing updates, say so plainly. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | Direct match, two years. Expect a probe on how the calendar was run day to day. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Say it in those terms and no more. Expect a probe on how the retention figure was defined. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | The checklist is a written document others use daily. Keep the claim to the document; the requirement is wider than one artifact. |

**Gate check.** No requirement is a gate in the sense of a legal or credential bar. The JD's "3+ years" is a length, graded on fit like the rest (F5).

## Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| Live-events calendar, two titles | A1, A3, B2, C1 | |
| Coordinate design, art, engineering, community | A4, D3 | No question on your coordination record; F2 is a discovery gap |
| Post-event review and KPIs | A5, C4 | |
| Release checklist with QA | C3 | |
| 3+ years live-service | B5 | |
| Content calendar | C1, E1 | |
| Player-retention metrics | C2, A2 | |
| Clear written communication | D2 | Also shown in the reverse questions |
| In-app purchases (not in the JD) | B4 | Included because you flagged it as a gap |

## Prohibited list

Claims this pack will not coach, each with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Your stated negative: "Never led a team" | Plain acknowledgment: "I haven't led a team." No claim of leadership in any answer. |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. Observation, not words for you: the material shows one title and content drops. |
| Owns the post-event review and its KPIs | Inflated form of F3 | F3's quote: "Presented the monthly retention numbers to the studio head." |
| Coordinated design, art, engineering and community | Inflated form of F4: a QA checklist stretched to four teams | The checklist quote at its own scope only. |
| Has live-service experience | Inflated form of F5 | F5's quote at its own scope; liveness is not established. |
| Has worked on a game with in-app purchases | Your stated negative: "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems on the two titles' calendars | Highest weight. Hiring-manager priors: they buy capability and test the calendar for the role | Clarify, then structure, then metrics. Say the framework once, briefly |
| Skeptic | The leadership gap, the two-title scope, the IAP gap | High. Your gaps are stated by you (leadership, IAP) and visible on the page (two titles, liveness) | Rehearse the leadership question until it is plain. Hold, then concede specifically |
| Data-Driven Prober | Retention figures, KPIs, how the checklist is proven | High. The JD leans on KPIs; the CV has one retention line | Name the weakest assumption yourself; say "I don't know" where true |
| Pressure | Time-boxed "why you over a team leader" | Medium. Your stated lack of team leadership is the obvious hook | Hold your delivery record; concede leadership directly |
| Conversational | Journey question, what you play | Low weight; still scored on the JD's plus-points | Prepare a 90-second arc from quotes only |

**Assumption:** the weights above are the hiring-manager prior. If Tobias is a skip-level or a panel member, the weights change (see upgrade menu).

## Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A big update is planned for one title, and two teams want the same slot. How would you plan the next six weeks?" | CASE | [generic] | Clarify first: what is shipping, the KPI it must move, the dependencies on design, art, engineering, community and QA. Then the calendar, the risks, the metric you would watch. Speakable in 90 seconds. | A live problem from the role's calendar; it asks about no past, so it claims nothing about you. |
| A2 | "Retention on one title dropped 15% week over week. Diagnose it." | CASE | [generic] | Ask what changed: last release, events, store, outages. Split by cohort before blaming content. | Retention is a JD requirement; the question presupposes nothing about you. |
| A3 | "What would you need to know about our two titles before you planned their calendars?" | JD | [generic] | List your inputs: monetization model, event cadence, team capacity, the last 90 days of KPIs. | Covers the two-title requirement (F1) as a question about method. |
| A4 | "The community team flags an event reward as confusing, and engineering says the fix is two weeks out. What do you do?" | CASE | [generic] | Decide what to ship now, what to communicate, what to move. Name who you would tell and in what order. | Covers coordination across teams (F2) as a decision, not a record. |
| A5 | "How would you run a post-event review?" | JD | [generic] | Define the question the review answers, the KPIs against plan, the cohorts, the decision it feeds, and the owner of each follow-up. | Covers the post-event review (F3) as method. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see team leadership in your background. How would you handle that in this role?" | JD | [grounded] "Never led a team" (your message) | **Highest-ROI prep in this pack.** Hold: "I haven't led a team." Then the coordination you can describe at its own scope, quoted: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you coordinated people without managing them, say what that involved; if you did not, say so, then how you would ramp. Hold through two follow-ups by returning to the calendar, not by adding to it. | F2 and the prohibited list make this the likeliest objection. Deepest rehearsal, because the material is thin exactly here. |
| B2 | "You've run a content calendar, not a live-events one. Which part would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Name one part honestly, then how you would learn it in the first month. Do not claim you have done live events. | F1 is the transferability gap; this is where the requirement presses. |
| B3 | "Your four years were at a puzzle studio. Was that title live-service in the sense we mean?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Honest branch: if it ran ongoing content for an active player base, say how you know. If it was a release with no ongoing updates, say so plainly, then point to the content-drop work at its own scope. | F5 is unestablished; a premised question about liveness must allow it was not. |
| B4 | "Have you worked on a game with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | "I haven't worked on a game with in-app purchases." Then how you would learn their monetization, stated as a plan. | Stated negative; not in the JD, but a likely probe for a mobile studio. |
| B5 | "What would a live-service team expect from its producer that a premium-release team would not?" | JD | [generic] | Name cadence, player feedback loops, live metrics, and the release checklist as a live tool. Keep it to the role, not your history. | Tests the live-service bar the JD states without premising anything about you. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What did the content-drop calendar change in player behaviour?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Answer slot: if you measured an effect, name the metric and how you knew it moved. If you did not measure it, say so. Never assert cause. | A probe for attribution; the material shows the calendar, not an effect. |
| C2 | "Which part of the retention figures you presented was yours, and which came from elsewhere?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Say which part you did (presenting, choosing, computing) in your own words. If you did not compute them, say so. | Attribution honesty on a headline line. |
| C3 | "How do you know the release checklist works?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Say what you can show: QA still uses it. If you tracked defects against it, say so. If not, say it is used, not measured. | The fact is usage, not effectiveness. |
| C4 | "What KPIs would you report after a live event, and what would count as a miss?" | JD | [generic] | Define the KPI, its baseline, the threshold for a miss, and what you would do with a miss. | The JD's KPI line, asked as method. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has led a team?" | EXP | [grounded] "Never led a team" (your message); [grounded] "Wrote the release checklist our QA team still uses" (your message) | Hold: the calendar and the checklist are the case. Concede plainly: "I haven't led a team." Do not argue leadership in. | Hold-then-concede on the core gap. |
| D2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Hold: you wrote it. Answer slot: if others shaped it, say who and what they changed; if you wrote it alone, say so. | Attribution probe on a single CV line. |
| D3 | "We'd put you on two titles from week one. What do you drop?" | CASE | [generic] | Name what you would deprioritize and why. Hold it under a second follow-up. | Time-boxed pressure on the two-title scope. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | A 90-second arc from quotes only: the studio, the content-drop calendar, the checklist, the retention presentation, why this role. | Casual register, still scored. |
| E2 | "What are you playing at the moment, and what would you change in it?" | JD | [generic] | Pick a live title, name one live-ops change you would make and why. | Rapport question about the JD's world. |

## Reverse questions

1. "What would a strong first 90 days look like for the person in this role?" Why it lands: shows you think about calendar ownership, not just the title.
2. "How are the two titles' calendars planned today, and where does the community team come in?" Why it lands: tests your coordination model against theirs.
3. "Which KPIs does the studio head review after an event, and what counts as a miss?" Why it lands: shows you care about the post-event review.
4. "How is the release checklist owned today, and how does QA sign off?" Why it lands: a partnership question with a concrete reference.
5. "Do both titles use in-app purchases, and how do events interact with the store?" Why it lands: shows you know the IAP gap matters, without assuming their model.

No interviewer-path question: there is no interviewer profile, since research was refused.

## Sources

Provided documents: the JD and your background, as stated in your message.

Research tier: L0. Two searches were sent and refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | No call sent; the values cheat sheet would have been built from it. No values round detected, so nothing moved. |
| 2. `{company} interview process {role family}` | unavailable | Call sent, refused. Would have set the loop structure and persona weights. |
| 3. `{company} strategy` / recent news | unavailable | No call sent. Would have moved the CO bank. |
| 4. `{interviewer name} {company}` | unavailable | Call sent, refused. Would have given the interviewer read and a tailored reverse question. |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot. |

Queries sent and refused: "Saltmarsh Games mobile game studio"; "Tobias Wrenfield Head of Live Operations Saltmarsh Games".

## Upgrade menu

- Search access, or a pasted Saltmarsh values page or recent article → specific CO questions and a checked loop structure.
- Tobias's public profile or a pasted bio → a tailored reverse question and persona weights from his path.
- Round format from your recruiter (one session or a panel; whether Tobias is your manager) → reweights every bank.
- Whether the puzzle title was live-service → upgrades F5 from `[inferred]` to `[grounded]`.
- Any coordination story beyond QA → upgrades F2 from `discovery`.
- What the two titles are and whether either uses in-app purchases → sharpens B2, B4 and reverse question 5.
