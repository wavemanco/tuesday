# Kelverton Rail: Senior Partnerships Manager, second-round panel prep

**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: about 15 minutes of spoken POV on operator partnerships over the next 18 months, then about 45 minutes of Q&A, with Ross pressing on commercials.
**Build:** first build. No regeneration.
**Research:** web search was refused in this session. The pack holds no Kelverton values, interview-process or strategy facts, and no interviewer profiles. Every company-specific claim is either a quote from your message or the recruiter's email, or labelled `[generic]`.

## How to use + type key

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding, not a script.

- **EXP**: whether your record survives scrutiny and what you actually did
- **JD**: the role's stated responsibilities, including its gaps
- **CASE**: a live problem, structured aloud
- **VAL** and **CO** are not used. No values round was detected, and research did not run.

## Prep triage (about 4 hours)

1. **60 min, the POV (Section 5).** Write the spine and the operator close as sentences you can say aloud. Time yourself. Aim for 12 minutes, which leaves room for interruption.
2. **60 min, the two objections (B1, B4).** No rail selling and no direct quota, said together, is the risk. Rehearse B4 until the hold and the concession come out without notes.
3. **45 min, the numbers (P1 to P3).** Write how the £4M and the 6-to-40 were counted, in your own words. Where you do not know, write "I don't know how it was counted" and stop there.
4. **30 min, commercials (P4, S4).** Three terms you would set first for an operator partner. No margin figure you do not have.
5. **30 min, reverse questions and one timed run of the whole hour.**

Everything else is insurance.

## Fit snapshot

No JD was supplied. Requirements are the recruiter's own words, quoted where they exist. Everything else is role-family prose, labelled `[generic]`, and raises no answer slot. Sources for every quote are in the Sources section.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter's email) | "so I know the operator world from the other side" (your message) | medium | [grounded] | presentation | Your material says you know the operator world from the other side, through bus and light rail network planning. It does not show a view of where operator partnerships should go. The POV has to supply that view, in your own words. |
| F2 | "Please land on what it means for the operators themselves." (recruiter's email) | none given | none | [grounded] | discovery | Your material shows no operator-facing outcome you have measured. Answer slot: if you have seen an operator outcome measured, name it and say how. If you have not, say which outcome you would measure first and how you would know it moved. |
| F3 | Partner channel at scale (role family) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | none | The quote reaches the requirement directly. Confidence is medium because it is self-reported and no inspectable artefact is named. Lead with the counts: 6 to 40. |
| F4 | Selling into rail or to train operating companies (role family) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan and never as a past. No claim to rail selling. Nothing added to make the gap smaller. |
| F5 | Carrying a direct sales quota (role family) | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | Words: "I've never carried a direct quota." The revenue you have been credited with is influenced revenue, and the pack says it in those words only. |
| F6 | Commercial terms for operator deals: "Ross will push on commercials." (recruiter's email) | "roughly £4M of influenced revenue" (your message) | medium | [grounded] | discovery | Your material shows the influenced figure, not any pricing, margin or contract term. Answer slot: if you set or negotiated any partner commercial terms, say what they were and what you decided. If you did not, say so, and say how you would work out operator terms. |
| F7 | Location and office pattern (role family; no JD) | none given | none | [generic] | hard_gate | The material does not establish the role's office pattern or location. It is a gate the JD may settle. The one question allowed asks whether it is met. Nothing else in the pack bridges it. |

## Prohibited claims

Built locally from the fit snapshot. Each entry names its basis and its honest form. No answer slot, hold or bridge in this pack asserts, softens or implies a listed claim.

| Not coached | Basis | Honest form |
|---|---|---|
| Any rail selling experience | Negative you stated (F4) | "I've never sold into rail specifically." No slot. |
| Any direct quota | Negative you stated (F5) | "I've never carried a direct quota." No slot. |
| Owned or drove the £4M | Inflated form of F3 and F6: "influenced" widened to "owned" | "roughly £4M of influenced revenue", at its own scope. The limit is the pack's own observation: your material says influenced, not sourced or closed. |
| Built the 40-partner channel | Inflated form of F3: "took it from 6 partners to 40" widened to who recruited them | The count, at its own scope. The material does not say how many you recruited. P2 asks that. |
| Has operator customers or relationships with train operators | Inflated form of F1: "so I know the operator world from the other side" widened to relationships | Operator-side knowledge from network planning, at its own scope. |

## Persona table

The panel rule applies: blend the top two personas of each member's relationship. There is no interviewer profile, so no interviewer signals adjust the weights.

| Persona | Member | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Deepa | Quiet probing of the gaps: rail, quota, the transfer from ISV channels | **High.** She is the hiring manager and her relationship prior is the Skeptic plus Case. The gaps in F4 and F5 are the ones a manager has to price | Plain acknowledgment, then the plan. Hold through two follow-ups |
| Data-Driven Prober | Ross | Defends or tests the £4M and the 6-to-40 | **High.** A commercial director's prior is Prober plus Pressure, and the recruiter said Ross will push on commercials | Name the weakest assumption before he does. Say "I don't know" where you don't |
| Case / Strategist | Deepa and Ross | The POV itself is a case; live problems follow it | **High** for the POV. The panel asked for a talk-through, so structure is scored from the first minute | Clarify, then structure, then answer. Say the framework aloud once |
| Pressure | Ross | Time-boxed challenges on the quota and the figure | **Medium.** A commercial director is the likeliest to time-box | Pause, restate, hold, then concede only the uncertainty |
| Conversational | Either | An opening "walk me through" | **Low.** The POV opens the session and sets the register | A 90-second arc from quoted sentences |

Depth follows weight. Skeptic and Prober get five and four questions. Case gets four, because the POV is itself a case. Pressure gets three, and Conversational gets two.

## POV build (D1, the 15-minute spoken POV)

The recruiter asked for a short talk, no slides. Guidance below is for the first 12 minutes.

**Grounded facts to build on:** F1, "so I know the operator world from the other side". F3, "took it from 6 partners to 40, roughly £4M of influenced revenue".

**Spine: operator partnerships should be judged by what changes in an operator's own year, not by how many partners resell.** Three theses, pick two.

- **Thesis 1: partner the planning cycle, not the sales cycle.** The argument: operator decisions cluster around planning and renewal windows `[generic]` rail pattern, to verify. Partnerships should be ready at those windows. Concession, said aloud: "I don't know this company's renewal calendar. The pattern is generic, and I would test it first." Differentiation: the obvious answer is more partners or more channel. This one is about timing.
- **Thesis 2: the planning consultancies are the operator channel.** Built on F1's quote. Concession: consultancies may see a software product as a threat to their own billable work, and I have not seen that resolved in a rail setting `[generic]`. Differentiation: recruit from the planning side, not the reseller side. Planners keep their own modelling method and the partner helps them adopt the tool without a rebuild `[generic]` hypothesis.
- **Thesis 3: measure partnerships by operator outcomes.** Concession: attribution is hard, the software is one input among many, and operators may not share their data `[generic]`. Differentiation: the consensus measure is partner count or influenced revenue. This is an operator's own measure. Anti-pick, and say it as a view: I would say no to a broad reseller marketplace for operators, because operator buying usually runs through a small number of decision-makers at renewal `[generic]`, to verify.

**The close: what it means for operators.** Three sentences, in your voice, each flagged as a hypothesis to test:
- The change window for their planning team gets shorter `[generic]`.
- Fewer manual rework loops at each change point `[generic]`.
- One accountable partner for implementation, not three `[generic]`.

**Limit:** the market report was not available to me, so I could not check the differentiation against it. Bring the report's shortlist into the POV and depart from it with reasons. Reciting it scores as homework.

## Question banks

Provenance sits before the guidance. Every quoted sentence in the Provenance column is exact and from your message or the recruiter's email.

### Skeptic (Deepa): B1 to B5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail. What would you do in your first 90 days to change that?" | JD | [grounded] "Never sold into rail specifically" | Plain acknowledgment: "I've never sold into rail specifically." Then the plan, in two or three concrete steps. Answer slot: if you have sold into any operator-type buyer, say which and how it was bought; if none, say so and give the plan | F4 is the gap, and the question is the likeliest form of it |
| B2 | "Your channel sold to software companies. Why would operators buy the same way?" | JD | [grounded] "running the ISV channel" | Say where the method transfers: partner recruitment logic, enablement. Say where it stops: buying cycles and procurement. Do not claim operators buy the same way | F2 and F1 meet here. The transfer is the probe |
| B3 | "What is the riskiest assumption in the operator plan you've just described?" | CASE | [generic] | Name the assumption you would test first, stated as your view | Open prompt. Supplies no past event |
| B4 | "You've never carried a direct quota and never sold into rail. Why should we give you operator revenue?" | EXP | [grounded] "never carried a direct quota, only influenced revenue"; [grounded] "Never sold into rail specifically" | **Highest-ROI prep in this pack.** The predictable objection is the two gaps together. Hold the record at its own scope: "took it from 6 partners to 40, roughly £4M of influenced revenue". Concede: "I haven't carried a quota or sold into rail, so the first months are learning, and here is what I'd measure." Hold through two follow-ups by returning to the record, never by adding to it | Pressure-form objection the fit snapshot predicts. The deepest rehearsal goes here |
| B5 | "What does the operator outcome look like in twelve months, and how would you know it worked?" | CASE | [generic] | Name one outcome and its measure, as a hypothesis | Ties the POV close to a test |

### Case / Strategist (Deepa and Ross): A1 to A4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you'd test whether an operator would pay for a partner-delivered change service. What do you need to know first?" | CASE | [generic] | Clarify, then structure: the buyer, the change event, the cost of the current method, the test | Live problem for the POV's close. Asks for no past |
| A2 | "An operator's planning team says the software slows them down. Diagnose it." | CASE | [generic] | Structure: what slows them, for whom, and what they would give up to fix it | Tests the Thesis 2 concession |
| A3 | "Which two operators would you approach first, and what would you ask each?" | CASE | [generic] | Name the selection criteria before any names. Ask about the change calendar and the decision-makers | Strategy-altitude question. No claim about any named operator |
| A4 | "A partner says the operator is interested but has stalled at procurement. What do you do this week?" | CASE | [generic] | Structure the week: who holds the decision, what the stall is, what you would ask the partner | Tests how the candidate reads a stall |

### Data-Driven Prober (Ross): P1 to P4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how that £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: say how it was counted, what it is most sensitive to, and which part was yours. If you cannot say how it was counted, say so | Defend-the-number slot. The figure is the one Ross will check first |
| P2 | "Of the 40 partners, how many did you recruit yourself?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: if you can split the 40, say how many and how you knew. If you cannot, say so | The honest answer sits between recruited and inherited. Do not claim the whole channel |
| P3 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" | Name the weakest assumption in your own words before he does. Answer slot: if you do not know the weakest assumption, say so | Weakest-assumption move. The pack does not name the assumption |
| P4 | "What would your operator partner agreement's pricing and margin look like?" | CASE | [generic] | Name the three terms you would set first and why. No margin figure you do not have | Commercial push the recruiter flagged. Asks for no figure |

### Pressure (Ross): S1 to S3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Sixty seconds: why would you beat an internal candidate?" | JD | [generic] | Pause. Restate the question. Anchor in the record: "took it from 6 partners to 40, roughly £4M of influenced revenue". Hold one follow-up, then concede any real gap | Stress-form question. No premise |
| S2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Hold the figure in its own terms: "roughly £4M of influenced revenue." Answer slot: if you can separate your share, say how. If you cannot, concede that plainly | Hold-then-concede on the attribution probe |
| S3 | "You're asking us to pay for operator revenue you haven't closed. Convince me." | JD | [grounded] "never carried a direct quota, only influenced revenue" | Hold the position that the partner-led record is relevant, at its own scope. Concede the quota gap plainly. Do not argue the quota is unimportant | Pressure on the quota gap. Same structure as B4, shorter |

### Conversational: V1 to V2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So, walk me through the journey." | EXP | [grounded] "bus and light rail network planning"; [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | A 90-second arc: the planning years, then the channel years, in the quoted words. No added beats | Low-weight opener. Scored, so the arc must match the record |
| V2 | "What's on your reading about the rail sector right now?" | CO-style | [generic] | Name only what you have read. If you have read nothing recent, say so | Casual register on a hot topic. Scored |

**Totals:** 18 questions across five personas.

## Requirement coverage

| Requirement | Question IDs and sections | Notes |
|---|---|---|
| Operator partnership plan over 18 months (recruiter) | D1 POV, A1 to A4, B5 | |
| What it means for the operators (recruiter) | D1 close, B5 | F2 has an answer slot, not a question |
| Commercials (recruiter) | P4, S3, F6 | — no pricing-model question beyond P4 |
| Selling into rail (role family) | B1, B2, B4 | |
| Direct sales quota (role family) | B4, S3 | |
| Partner channel at scale (role family) | P1 to P3, V1 | |
| Operator-side knowledge (role family) | V1, D1 Thesis 2 | |
| Location and office pattern (role family) | none, and why: no JD was supplied. The one question for it is in the message | |

## Reverse questions

Each has a line on why it lands. No interviewer profile exists, so none ties to a career path, and none is a peer question.

1. **To Deepa:** "What would the first 90 days need to show for you to call this hire a good one?" *Makes the success test explicit.*
2. **To Ross:** "Which operator conversations have moved commercial terms recently, and what held them up?" *Tests whether the commercial picture is current.*
3. **To Deepa:** "How much of the 18-month plan is already committed, and where is the operator pipeline today?" *Shows you want the real starting point.*
4. **To Ross:** "Where should partner-led delivery sit against the in-house product teams?" *A seam question. It tells Ross you have thought about the internal shape.*
5. **To Deepa:** "What did the last operator partnership that stalled teach the team?" *Asks for their own lessons, not a sales pitch.*

## Sources

**Provided documents:**
- Your message: the candidate background, and the recruiter's email as you quoted it.
- The market report from Kelverton's strategy team: read by you, not pasted to me. Nothing from it is used in this pack.
- No `tuesday-dossier.md` was present.

**Searches and fetches sent:**
- "Kelverton Rail values": refused
- "Kelverton Rail interview process partnerships": refused
- "Kelverton Rail strategy news": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Ross Commercial Director Kelverton Rail": refused

No fetches were sent. No user links were read.

**Research tier: L1 — searches 5 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have moved the values cheat sheet (section 10). Not built, as no values round is detected. Every call refused |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Would have set loop structure and persona weights. Persona weights rest on the panel rule. Every call refused |
| 3. `Kelverton Rail strategy news` | unavailable | Would have moved the grounding brief (section 6) and CO questions. Every call refused. The market report was not pasted to me |
| 4. `Deepa VP Partnerships Kelverton Rail` and `Ross Commercial Director Kelverton Rail` | unavailable | Would have moved the interviewer read (section 7) and reverse questions tied to their paths. Every call refused |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Would have turned the role-family rows into quoted requirements and JD-tagged questions. No search sent, because the host refused every search |

## Upgrade menu

- **The JD text** → F7's gate can be settled. The role-family rows F4 to F6 become quoted requirements, and the JD-tagged questions are re-tuned.
- **The market report's headline points (paste them)** → a differentiation section for the POV. Right now the POV cannot be checked against it.
- **Search access, retried** → the values cheat sheet, loop structure, a grounding brief, and an interviewer read for Deepa and Ross. Each would also tune the reverse questions.
- **Your own answer to P1 to P3, once you have written them** → the next regeneration can make the Prober bank sharper, with only what you have said.
- **Confirm the round's format** → the POV length and whether Ross or Deepa speaks first.
