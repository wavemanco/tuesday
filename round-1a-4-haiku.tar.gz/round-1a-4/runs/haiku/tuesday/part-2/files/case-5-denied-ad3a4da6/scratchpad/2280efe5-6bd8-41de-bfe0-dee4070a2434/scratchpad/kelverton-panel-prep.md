# Kelverton Rail — Senior Partnerships Manager — Panel prep (round 2)

Round: panel, 60 min. Deepa (VP Partnerships, future manager) and Ross (Commercial Director).
Structure: 15 min spoken POV (no slides) on operator partnerships over 18 months, landing on what it means for the operators. Remaining ~45 min Q&A; Ross pushes on commercials.

Basis of this pack: your message only (no JD, no CV, no market report text, no web research). Web research was not run (search permission was declined), and I have not seen the strategy team's market report or a JD. Anything about Kelverton's current strategy or rail policy below is marked [unverified] and must be checked against the report before you rely on it.

## 1. Fit snapshot (self-assessment worksheet — no JD supplied)

| Requirement (inferred, [inferred]) | Your evidence (your words) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| Build and run partner programmes at scale | "took it from 6 partners to 40" (payments ISV channel) | High | None | Strong, quantifiable, lead with it |
| Revenue impact through partners | "roughly £4M of influenced revenue" | Medium — influenced, not owned | Attribution | "I influenced ~£4M; I did not carry a quota. Here is how I would make partner revenue attributable at Kelverton." |
| Knowledge of the operator customer | "5 years in transport consulting (bus and light rail network planning)" | Medium — adjacent, not mainline TOC | Domain | "I know how transport operators plan networks from the operator side, though bus and light rail rather than mainline TOCs." |
| Sell into rail / TOCs | None stated | Low | Domain + direct sales | "I have not sold into rail. My sales experience is channel-led; here is how I would learn the operator buying cycle quickly." |
| Carry a direct quota | None | Low | Experience | Do not claim one. Answer with how you would be measured and what you would take on. |

Gap types: attribution, domain, and direct-sales experience. These are the gaps Ross will go for.

## 2. Prohibited claims (do not say, imply, or soften into these)

- That you have sold into rail, to a TOC, or to a train operator.
- That you carried a quota or owned revenue targets.
- That bus or light-rail planning equals mainline train-operating-company experience.
- That the £4M was yours alone. Say "influenced".
- Any knowledge of Kelverton's internal strategy beyond what the recruiter and report say. The report is not in this pack.

## 3. Interviewer read

No profiles supplied. Working priors only:

- **Deepa (future manager):** will test whether you can build an operator-facing proposition, and whether you would make her team's job easier. Likely to ask about how you would structure a partner model and how you work with a commercial team.
- **Ross (Commercial Director):** will test whether partnerships produce revenue that Finance will believe. Expect pressure on margin, pipeline, forecasting, channel conflict with direct sales, and what happens in year one before anything closes.

## 4. Persona weights

- Deepa: high on strategy, operator empathy, and team leadership. Weight 0.6.
- Ross: high on commercials and proof. Weight 0.4 at first, but he sets the tone of the Q&A.

## 5. The POV (15 min) — build order

1. **The operator's position in 18 months.** What changes for a train operator: planning cycles, cost pressure, performance regimes, and whatever the report says is shifting [unverified]. Keep it to three forces.
2. **Where partnerships create operator value.** Not "more reach for Kelverton" but operator outcomes: faster timetable change, fewer planning errors, better disruption recovery, and less manual work for planning teams. Pick two and explain how a partner model would deliver them.
3. **How the partnership model changes.** Co-delivery with operators' own planning teams, implementation partners, and shared outcome metrics rather than licence sales alone. Transfer from the ISV work: an ecosystem where partners carry delivery.
4. **What it means for the operators themselves.** Say this explicitly, in plain terms, in the final two minutes. The brief asks for it.
5. **First 90 days and how you would measure it.** One metric for operators, one for Kelverton. This is your bridge into the commercial questions.

Rehearsal rule: practise it spoken, timed at 12–13 minutes so there is room for interruptions. Do not write it out and read it.

## 6. Likely questions and answer guidance

**Deepa**
- "Why do you want to move from payments into rail?" Answer with the operator-side knowledge from transport consulting. Do not oversell it.
- "How would you build trust with an operator who has never bought from a partner?" Answer with co-design and pilot logic. Real example from the ISV work where you can name it.
- "What would you do differently from what the team already does?" Ask them first, if the report leaves it open.

**Ross**
- "You have never carried a quota. Why should we believe partner revenue will land?" Answer: say plainly you have not carried one, then show how influenced revenue was tracked, what conversion looked like, and how you would make it attributable.
- "How do you avoid channel conflict with direct sales?" Answer with deal registration and clear partner/direct territory rules, and say how you handled it at the payments company.
- "What is your year-one pipeline?" Give a method, not a number you cannot defend. Show the funnel logic and the assumptions.
- "How would you think about margin on a rev-share?" Answer with the trade-off between partner margin and operator outcomes. Be clear on what you do not know yet about rail contract economics.

## 7. Reverse questions (for you to ask)

- "Which operators are the current priority partnerships, and what would success look like for them in 18 months?" Why it lands: shows you think in operator outcomes.
- "How is the partner revenue number expected to be attributed between partnerships and direct sales?" Why it lands: shows commercial seriousness, and Ross will answer it.
- "What did the last person in this role get right, and what did they miss?" Why it lands: useful and honest.

## 8. Delivery notes

No assessment provided. Speak to the POV, then pause for questions. Concede the gaps once, plainly, then move on.

## 9. Prep plan (about 4 hours)

1. 60 min: write the five POV beats in your own words; check each against the report.
2. 60 min: spoken POV, timed, twice. Record one run.
3. 45 min: Ross drill — the four commercial questions, out loud, shortest honest answer first.
4. 30 min: Deepa drill — the three questions above.
5. 30 min: reverse questions and your three "what I have not done" lines.
6. 15 min: skim the report for anything that contradicts the POV.

## Upgrade menu

- **Job description** — builds a real fit snapshot against stated requirements and sharpens the gaps.
- **CV** — replaces the worksheet with story-mapped answers.
- **Market report key points** — checks every [unverified] claim in the POV.
- **Interviewer profiles (Deepa, Ross)** — sharpens persona weights.
- **Deep research (L2)** — strategy brief, interviewer talks, recent Kelverton context. Costs more searches and time; available on request.
