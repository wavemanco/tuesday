# Larkfield Systems, Engineering Manager: loop prep (three rounds)

**Rounds.** R1, hiring manager (Director of Engineering), 45 min, Tuesday. R2, panel of two staff engineers and a product manager, 60 min, Thursday. R3, VP Engineering, 30 min, the following Monday, "values and leadership philosophy." No interviewer names were given.

**Research.** The three web searches were refused in this session, so no company values, interview structure or strategy is in this pack. Everything about Larkfield comes from your message and the role summary in it.

**Dropped sections.** Prep triage (prep time not given), grounding brief (no strategy research), reading the interviewer (no names), values cheat sheet (no published values in hand), graded deliverables (none declared), delivery coaching (no assessment provided).

## How to use

Personas describe how a question arrives. Types describe what is scored: **VAL** behavioral and values, **EXP** work-experience deep-dive, **JD** role requirement, **CO** company and strategy, **CASE** live problem. An **answer slot** is an instruction for the interview, not a question to me. Guidance is scaffolding, not a script.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role summary, your message) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material has one team of six, not two squads. Bridge at its own scope: "For three years I was a team lead of six." Answer slot: if you have led more than one group at a time, say how many and what each did; if not, say so and say how you would split two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role summary, your message), hiring part | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | none | No gap on hiring, but a count with nothing inspected behind it, so expect a probe on what the 40 showed. Say it in those words. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role summary, your message), delivery part | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | A reliability quarter you pushed through is adjacent to owning delivery across squads, and does not show it. Bridge at its own scope: "I pushed a reliability quarter through against roadmap pressure." Do not widen it to delivery ownership. |
| F4 | "own delivery, hiring and growth for 11 engineers" (role summary, your message), growth part | none given | none | [grounded] | discovery | Your material is silent on growing people. Answer slot: if you have grown an engineer into a bigger role, say who and what you did; if not, say so and say what you would do first. |
| F5 | "partner with hardware and product on roadmap" (role summary, your message), hardware part | "never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | A gap you stated, so the words are yours: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F6 | "partner with hardware and product on roadmap" (role summary, your message), product part | "I pushed a reliability quarter through against roadmap pressure." (your message) | low | [inferred] | transferability | The quarter shows you holding a roadmap line under pressure, not partnering on one. Bridge only that, at its own scope. Answer slot: how you would bring product into a roadmap call. |
| G1 | Office or location pattern (role family pattern, not in your message) | your material does not establish this | none | [generic] | hard_gate | Surfaced, not bridged. Your message says nothing about location or office days. The one question below asks whether it is met. |

Requirement source: the role summary in your message, which is not a full JD. F1 to F6 are its own words, quoted.

## Prohibited list (shared)

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a hardware-adjacent roadmap | Negative you stated: "never owned a hardware-adjacent roadmap" (your message) | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." No slot. |
| Has managed managers | Negative you stated: "I've never managed managers" (your message) | "I've never managed managers." Used only if a question raises it. |
| Led two squads | Inflated form of F1, "3 as a team lead of 6" | Three years as a team lead of six, at its own scope. |
| Owned delivery for 11 engineers | Inflated form of F3 | "I pushed a reliability quarter through against roadmap pressure." |
| A counting method for the 60% | A figure you gave, with no method in your material | Not coached. Answer slot only (A7). |

---

## Round 1: Hiring manager (Director of Engineering), Tuesday, 45 min

**Persona weights**

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probes on the gaps: hardware roadmap, managing managers, why now | 4 questions. A hiring manager is buying capability and derisking gaps (relationship prior). | Concede the absence in your own words, then give the plan. Don't bluff. |
| Case / Strategist | Live problem from the device-management roadmap | 2 questions. Hiring managers pose live problems on their actual roadmap. | Clarify, then structure, then challenge one premise. |
| Data-Driven Prober | Asks how the 60% was counted | 2 questions. The headline CV figure will be probed. | Say what you can and cannot say about the count. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | Name the gap first, in your words: "I haven't owned a hardware-adjacent roadmap." Then say what you would do first to learn it, as a plan, never as something you have done. | F5 is the most predictable objection. It will come up in some form in every round. This is the highest-ROI prep in the pack. JD because it scores the partnership requirement. |
| A2 | "I don't see hardware or roadmap ownership in your background. How would you handle that here?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message); [grounded] "I pushed a reliability quarter through against roadmap pressure." (your message) | Concede the absence in the same words. Then describe your nearest roadmap work at its own scope: "I pushed a reliability quarter through against roadmap pressure." Do not stretch that into roadmap ownership. | F5 (capability) and F6 (transferability). The question presupposes only the absence you stated. |
| A3 | "You've led six people. What makes you ready for two squads?" | JD | [grounded] "3 as a team lead of 6" (your message) | Say what you have: three years as a team lead of six, in those words. Answer slot: if you have led more than one group at a time, say how many and what each did; if not, say so and say how you would split two squads. | F1. The two-squad claim is not in your material, so the answer stays inside the six. |
| A4 | "Why this role, and why now?" | EXP | [generic] | Give the reason you actually have, in your own words, and tie it to what the role asks. Do not claim a hardware interest you have not stated. | A standard motivation probe from a skeptic. The answer is yours, so the guidance adds no claim about your past. |
| A5 | "Two squads, one shared device-management service, and hardware wants a firmware change next quarter. How do you plan it?" | CASE | [generic] | Clarify what is fixed and who decides. Name what you need from hardware and product before you plan: the change, the date, the owner. Then lay out options and their risks, out loud. | A live problem from the partnership line. It makes no claim about your past. |
| A6 | "Two squads both need the same engineer next quarter. How do you decide?" | CASE | [generic] | Ask what each squad's commitment is and what slips if you say no. Structure the options, then state your decision rule, and say what you would tell the squad that loses. | Tests roadmap judgment at manager altitude. Generic by design. |
| A7 | "Walk me through how that 60% on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Answer slot: the counting method is not in your material. If you know what was counted and over what period, say it in your own words. If you don't, say so plainly ("I don't know how it was counted"), and name the assumption you would defend least before they ask. | The headline CV number is a magnet for probers. The pack supplies no method, because an explanation you cannot repeat under a second question is worse than none. |
| A8 | "Which part of that reliability quarter was yours to decide?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure." (your message) | Say the part you decided, in your words: you pushed it through. Answer slot: if the scope or the timing was set by someone else, say so. Do not add a decision your sentence doesn't carry. | An attribution probe. The honest answer is one of two branches. |

**Reverse questions**

- "What would make someone clearly successful in the first ninety days in this role?" Why it lands: it frames you as planning the job, not auditioning for it.
- "Where do the device-management squads and the hardware team disagree most right now?" Why it lands: it shows you already see the seam you would be inheriting.
- "How are the two squads' scopes split today?" Why it lands: it tests whether the two-squad question is real before you answer it.

---

## Round 2: Panel (two staff engineers, one product manager), Thursday, 60 min

No names were given, so personas are blended across the panel rather than assigned per member.

**Persona weights**

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Staff engineers go one level below each answer | 3 questions. Staff engineers are technical-depth verifiers, so the prober prior applies. | Name the weakest assumption you know of before they do. |
| Peer Evaluator | Product seam and what the hire costs the PM's roadmap | 2 questions. The PM prices the hire against their own work. | Offer seam principles, not a made-up seam. Show disagreement with tact. |
| Case / Strategist | Roadmap trade-offs, product-side | 2 questions. | Clarify, then structure, then challenge one premise. |
| Pressure | One staff engineer tests composure on a claim | 1 question. | Hold through two follow-ups before any concession. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through the reliability quarter you pushed through." | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure." (your message) | Story-mapped on that sentence: the quarter, the pressure, the push. Stay on those beats. Answer slot: if you set what the quarter covered, say how you decided; if its scope was set for you, say so. | Premised on your own quote. Expect a staff engineer to go one level deeper than your answer. |
| B2 | "What's the assumption behind the 60% you would defend least?" | EXP | [grounded] "My team's on-call burden dropped 60%" (your message) | Weakest-assumption slot: name, in your words, the assumption you would defend least, before they do. If you can't name one, say you don't know how the figure was counted. Do not offer a method. | A prober's standard move on a headline figure. |
| B3 | "What did the about 40 interviews you ran last year tell you about the loop?" | EXP | [grounded] "about 40 interviews last year" (your message) | Say what you counted and what you changed because of it, in your words. Answer slot: if you did not measure the loop, say so and say what you would measure. | A hiring claim with no inspectable proof. Expect a probe on what the count shows. |
| B4 | "Sixty seconds: how much of that 60% was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through" (your message) | Hold: you pushed the quarter through, and that part is yours. Hold through two follow-ups. Then concede specifically the part you cannot separate from the rest of the team's work, in your words, without naming a cause your material does not give. | Pressure persona. Hold, then concede the exact thing. |
| B5 | "What would you need from product before committing a device-side roadmap item?" | JD | [grounded] "partner with hardware and product on roadmap" (role summary, your message) | Plan, not past: name what you would want in writing, which is the decision owner, the dependency and the date. Do not claim device-side commitments you have made. | The raising source is the role line. Product seam. |
| B6 | "Where is the seam between our services and hardware, and what happens when you disagree with them?" | JD | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Propose seam principles rather than pretending to know theirs. Your disagreement story is the quarter: you pushed it through against pressure. Do not claim a hardware disagreement. | Peer seam probe, with a reciprocity angle. |
| B7 | "Product wants a feature that adds two weeks to a firmware release, and the error budget is thin. What do you do?" | CASE | [generic] | Clarify the objective and what the two weeks buy. Name the options and what each costs. Challenge one premise out loud, then give your call. | A live roadmap trade-off. No claim about your past. |
| B8 | "A device fleet's update failures rose after last week's rollout. What do you check first?" | CASE | [generic] | Check the rollout's scope and the rollback path before anything else, then what is in your control this week. Do not present this as an incident you have handled. | Generic incident-triage case, labeled as such. |

**Reverse questions**

- "Where have recent roadmap calls between hardware and software gone wrong here?" Why it lands: a candid answer shows how the seam really works.
- "What would you want the new engineering manager to own in the first quarter that the team doesn't do today?" Why it lands: it tests whether the delivery and growth asks are real.
- "How do the staff engineers split review work across the device-management services?" Why it lands: it shows you are thinking about the technical load on your leads.

---

## Round 3: VP Engineering, following Monday, 30 min

**Persona weights**

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes for "values and leadership philosophy," expecting STAR-shaped stories | 4 questions. The round is named by you as a values round, so this dominates. | Map one story per question where your material carries one. Otherwise, use a selection scaffold. |
| Pressure | Altitude test: composure and a hard "why you" | 2 questions. Skip-level prior. | Hold a position through two follow-ups. |
| Conversational | Opener that is still scored | 1 question. | Use a pre-scripted 90-second arc. |
| Case / Strategist | Altitude question on what the organisation needs | 1 question. | Name what you would listen for first. |

Values cheat sheet: not included. No published Larkfield values are in hand, and the values page was not retrieved. Paste it (see upgrade menu) and this round gets a values section.

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure." (your message) | Open prompt. If it fits, the story is the reliability quarter, with the beats the sentence states: the pressure and the push-through. Answer slot: if the truth landed with leadership, say what they said; if it did not land, say so. If none fits, say so plainly, then give the nearest thing your material carries. | A persona stem. Your one story with a stated pressure. |
| C2 | "Tell me about a decision where you put the team's health ahead of a delivery date." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through" (your message) | Premised on your quote. Beats: the quarter, and the drop in on-call burden. Answer slot: what the quarter cost in delivery, in your words; if you can name no cost, say so. | The same story from the other side of the trade-off. |
| C3 | "What is your leadership philosophy for growing engineers?" | VAL | [grounded] "I run our hiring loop for backend roles" (your message) | Give your own philosophy in your words, anchored in what you actually run: the backend hiring loop. Answer slot: if you have grown someone into a bigger role, name who and what you did; if not, say so and say what you would do first. | Leadership-philosophy round. The philosophy is yours; the anchor is quoted. |
| C4 | "Sixty seconds: why should we trust a team lead of six with two squads?" | JD | [grounded] "3 as a team lead of 6" (your message); [grounded] "never owned a hardware-adjacent roadmap" (your message) | Hold: three years as a team lead of six, in those words. Hold through two follow-ups. Then concede the gap plainly: "I haven't owned a hardware-adjacent roadmap." | Pressure at VP altitude. |
| C5 | "What is the hardest thing this role requires that you haven't done?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then the plan for learning it, as a plan. | The same gap as A1, in the VP's register. |
| C6 | "What does this organisation need from an engineering manager that it doesn't get today?" | CASE | [generic] | Name what you would listen for first: how device-management decisions get made and where they stall. Do not claim knowledge of their current gaps. | An altitude question. It makes no claim about your past. |
| C7 | "Walk me through your journey in ninety seconds." | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." (your message) | Pre-scripted: nine years in engineering, three as a team lead of six, now at a payments company, and you run the backend hiring loop, about 40 interviews last year. Use those words. | A rapport opener that is still scored. |
| C8 | "Tell me about a disagreement where you changed your mind." | VAL | [generic] | Selection scaffold: pick a time you changed course because someone made a better case. If none comes to mind, say so plainly, then give the nearest thing you have. | Your material carries no such sentence, so this is a scaffold with its honest branch. |

**Reverse questions**

- "What did the last hard reliability or roadmap call teach leadership here?" Why it lands: it invites the hard truth they value.
- "What does this VP want an engineering manager to own, and what should they escalate?" Why it lands: it sets the altitude for the first quarter.
- "What would good look like at the ninety-day mark for this group?" Why it lands: it is a planning frame, and it makes no claim.

---

## Sources

- **Provided documents:** your message, which holds the role summary, your background and the round schedule. No full JD, no interviewer profile and no recruiter note.
- **Searches sent (all refused):** "Larkfield Systems values"; "Larkfield Systems interview process engineering manager"; "Larkfield Systems industrial IoT strategy news."

**Research tier: L1, searches 3 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet, dropped (no published values in hand). Would have moved Round 3. |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Loop structure. Your own words already name the three sessions, so the persona weights do not depend on it. It would have checked them. |
| 3. Larkfield Systems strategy and recent news | unavailable | The company-strategy (CO) questions. None are written, so the CASE questions stay generic. |
| 4. Interviewer name and company | n/a | No interviewer names were given. |
| 5. Representative engineering manager JD | unavailable | The JD-tagged rows rest on your role summary, not a full JD. |

## Upgrade menu

- Full JD text → turns the role-summary rows from your message into JD-quoted lines and sharpens the JD questions.
- Whether the two squads have their own leads who report to you → a managing-managers row and questions, if they do.
- Larkfield's published values page, pasted → the Round 3 values cheat sheet, mapping each value to one of your stories.
- Interviewer names → per-interviewer persona weights for Rounds 1 and 2, and reverse questions tied to their career paths.
- The recruiter's note on round focus or any deliverable → graded-deliverable sections, if one is declared.
- Prep hours available → a prioritized prep triage.
- Search access in a later session → a grounding brief and strategy-based company questions.
- A tuesday-dossier.md, if you have one → verified evidence for the gap rows.
