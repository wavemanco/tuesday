# Ashgrove Credit Union: Member Experience Lead

Interview prep pack, loop mode. Three rounds on 3 December 2026. Prepared 24 November 2026.

Interviewers: the recruiter (not named), the Head of Member Services (your future manager, not named), and a panel of two branch managers (not named). Persona weights rest on the relationship of each round, not on anyone's profile.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: **VAL** values and behaviour, **EXP** your own work, **JD** a stated job requirement, **CO** company and strategy, **CASE** a live problem.
- Guidance is scaffolding, not a script. Rehearse it aloud until your own words carry it.
- **Answer slots** are instructions for the interview: they say what to answer in your own experience, and the honest branch to take when the answer is no.
- Provenance labels: **[grounded]** traces to your message, the JD text, or the values and strategy you pasted; **[inferred]** derives from a source; **[generic]** is a pattern, not a fact about Ashgrove.
- Question IDs read round, then persona letter, then number. Letters: A conversational, B skeptic, C case, E peer, L logistics, P prober, V values and behaviour, X pressure.

## Prep triage

You have nine days, 24 November to 3 December. All three rounds fall on 3 December, so the panel is the last round of a long day. Work in this order:

1. **24 to 25 November.** Write the two plain acknowledgments in your own words and say them aloud until they are plain: "I've never worked in a contact centre." and "I've never presented to anyone above regional level." Then write the first-week plan and the presenting plan that follow each one (B1, B2 in round 2).
2. **26 to 27 November.** Round 3's 20-minute case (C1). Say the six steps aloud twice, timed.
3. **28 to 29 November.** Values: for each of the four values, one story from your own log, or the honest answer that you have none (values cheat sheet).
4. **30 November to 1 December.** Round 2's behavioural questions (V1 to V4) and the regulated-log answer (B3).
5. **2 December.** Write the four logistics answers in your own words (pay, notice, location, reason for leaving). Ask the recruiter which hub the role sits in. Drill B1 once more.
6. **3 December.** Nothing new. Re-read the two acknowledgments and the case steps only.

Everything else is insurance.

## The fit snapshot

Requirements are quoted from the JD text in your message. Your evidence is quoted from your message. No requirement here is a gate; the 4+ years is graded on fit.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | presentation | Your sentence reaches the requirement in other terms. The bridge only reorders it: "I've spent six years in retail banking, the last three as a branch supervisor." Do not turn it into contact-centre or operations-team experience; F6 is the limit. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Bridge: "I handled the branch's formal complaints log." Your sentence says formal, not regulated. Answer slot: if the log ran to rules or deadlines, name them and how you worked to them; if it ran to none, say so and say what it did run to. |
| F3 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Your words: "I've never presented to anyone above regional level." No slot for the past. Then a plan, said as a plan and never as a record: what you would practise first, and with whom. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | Bridge reorders only: "I built the monthly complaints spreadsheet our regional manager uses." Your sentence says spreadsheet, not Excel. Do not name tools, formulas or features it did not mention. |
| F5 | "Own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Adjacent work: one branch's log. Bridge: "I handled the branch's formal complaints log." Answer slot: "end to end" is not in your sentence. If you owned a step beyond the log, such as resolution or the reply to the member, say which and how you decided; if you did not, say so and stay with the log. |
| F6 | "and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your words: "I've never worked in a contact centre." Then a plan: how you would learn the contact-centre side first, said as a plan. |
| F7 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | discovery | Your sentence says monthly, not volumes or resolution times. Answer slot: if the spreadsheet counted volumes or resolution times, say which and how they were counted; if it did not, say so and say what you would add first. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message); "the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | Adjacent work: you trained tellers on the escalation script and were a branch supervisor. Bridge: "I trained new tellers on our escalation script, and I was a branch supervisor for the last three years." Coaching other supervisors is not in your sentence. Answer slot: if you have coached a supervisor on an escalation, say what you did; if not, say so and say how you would start. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if you have worked with a digital or IT team on a customer-facing change, say what and your part in it; if you have not, say so and say how you would start. |

## Prohibited claims

The pack will not coach these. Each has a basis and the honest form to use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have owned the complaints process end to end" | Inflated form of F5 | F5's quote at its own scope: the branch's formal complaints log. Limit, in the pack's analysis: your material says the log, not the process end to end. |
| "I have worked in, or run, a contact centre" | Negative you stated, F6 | "I've never worked in a contact centre." Plain acknowledgment, no slot. |
| "I have presented to senior leaders" | Negative you stated, F3 | "I've never presented to anyone above regional level." Plain acknowledgment, no slot. |
| "I have coached branch supervisors on escalations" | Inflated form of F8 | "I trained new tellers on our escalation script." Limit, in the pack's analysis: your material says tellers. |
| "I have handled regulated complaints to set rules or deadlines" | Inflated form of F2 | F2's quote at its own scope: the formal complaints log. The rules question is an answer slot, not an assertion. |
| "I built resolution-time reporting in Excel" | Inflated form of F4 and F7 | F4's quote at its own scope: the monthly spreadsheet your regional manager uses. Limit: your material does not say it held resolution times or was Excel. |

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| 4+ years in financial-services customer operations | R1 A1 |
| experience handling regulated complaints | R2 B3, R3 C1 |
| confident presenting to senior leaders | R2 B2, R3 X1 |
| comfortable with Excel reporting | R2 P1, R2 P2 |
| Own the member complaints process end to end across branches and the contact centre | R2 B1, R3 C1 |
| report monthly on complaint volumes and resolution times | R2 P1, R2 P2 |
| coach branch supervisors on escalations | R3 C2 |
| work with digital teams on self-service journeys | R1 A2, R2 C1 |

## Grounding brief

You gave me the strategy as a summary of the July 2026 brief, so these are the brief's terms. Use them as the interviewer's terms, not as facts you have checked. The brief is under six months old, so it is current enough to use.

- **Digital:** move 40% of member service to digital channels by 2028.
- **Branches:** consolidate eight branches into five hubs over 2027.
- **Lending:** launch a small-business lending product in Q1 2027.
- **Competition:** the main pressure is app-only banks.

The branch consolidation is the sharpest tension for this role. The values say every branch is part of its town; the plan closes three of the eight. Expect that to come up in round 3.

## Round 1: Recruiter screen (30 minutes)

The recruiter's description: a 30-minute conversation with the recruiter. Weights follow the recruiter-screen prior: conversational, with a light skeptic. The four logistics rows are fixed by the screen's rule (pay, notice, location, reason for leaving) and sit outside the persona weights.

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly opener, "walk me through" | 2 questions: a screen runs on rapport and a 90-second arc | Pre-script the six-year arc from your own sentences |
| Skeptic | Light probes on the gaps | 2 questions: the recruiter will note the contact-centre gap | Plain acknowledgment, then the plan |
| Logistics | Pay, notice, location, reason | 4 rows: fixed by the screen's rule | Give your own answer in your own words |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the last six years." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." (your message) | A 90-second arc with only these beats: six years in retail banking; the last three as a branch supervisor; the complaints log and the teller training; the spreadsheet your regional manager uses. Close with why this role, in one sentence, without a claim about its scope. | An opener and consistency check. The arc puts F1, F4, F5 and F8 in one breath. EXP because every beat is one of your sentences. |
| A2 | "The role works with digital teams on self-service journeys. Have you?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Yes or no first. Answer slot: if you have worked with a digital or IT team on a customer-facing change, say what and your part in it; if you have not, say so and say how you would start. | F9 is silent in your material. The screen is where a gap like this gets noted. |
| B1 | "You've never worked in a contact centre. What's the case for you?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" (your message) | Plain acknowledgment: "I've never worked in a contact centre." Then what carries across, in your words: "I handled the branch's formal complaints log." Then the plan, said as a plan: how you would learn the contact-centre side first. | F6 is the stated gap. Round 2 probes the same gap harder (B1 there is the highest-ROI rehearsal in the pack). |
| B2 | "Why this role, and why now?" | EXP | [generic] motivation pattern; JD "Own the member complaints process end to end across branches and the contact centre" (JD) | Give the true reason in your own words. Your material does not yet state one, so there is no fact to rehearse. The structure: what you want to do in the role, tied to that JD line, then the closest thing you have done, at F5's scope. Do not claim the contact-centre part. | A skeptic checks motivation consistency. EXP because the answer is yours. |
| L1 | "What pay are you looking for?" | JD | [generic] logistics slot; no figure in your material | Give your own figure, or ask for the role's band first. If asked for your current pay, you can decline that question and say so. Do not estimate it. | Pay is one of the four logistics slots the screen requires. A slot, not a blank. |
| L2 | "What's your notice period?" | JD | [generic] logistics slot; none given | Give your actual notice period. | Notice is one of the four logistics slots. |
| L3 | "Where would you be based, and how often on site?" | JD | [generic] logistics slot; none given | Give your own answer: where you can work, and how often. The JD does not state a base. If the base is one of the five hubs, ask the recruiter which one before you answer. | Location is a live question while branches consolidate into hubs. |
| L4 | "Why are you looking to move on from your current role?" | EXP | [generic] logistics slot; none given | Give your own reason, in your words. Do not borrow one from the job description. | Reason for leaving is one of the four logistics slots. |

**Reverse questions**

1. "How are the four values scored, and does each value have its own scorer?" Why it lands: it tells you whether the panel scores separately, and shows you expect to be scored.
2. "Which of the five hubs would this role sit in, and when?" Why it lands: it fixes the location answer (L3) and ties your questions to the strategy the recruiter sent.

## Round 2: Head of Member Services (45 minutes, mostly behavioural)

Your future manager. Priors for a hiring manager are case and skeptic. The recruiter describes this round as mostly behavioural, so values and behaviour lead.

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Scenario prompts, STAR-shaped stories | 4 questions: top weight, because the round is mostly behavioural | Stories from your own sentences; "I" for your part; say plainly when no story comes |
| Skeptic | Probes the two stated gaps and the regulated-log question | 3 questions: your manager weighs what you cannot yet show | Plain acknowledgment, then the plan, held |
| Data-Driven Prober | Asks how the spreadsheet counted | 2 questions: the spreadsheet is a magnet, and the JD names resolution times | Name the weakest assumption before they do; "I don't know how it was counted" is an honest branch |
| Case / Strategist | The 40% digital move | 1 question at manager altitude | Clarify first, then structure aloud |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a complaint where the member's side of the counter changed what you did." | VAL | [grounded] "I handled the branch's formal complaints log" (your message), the nearest sentence; no sentence of yours carries a member-led decision | Pick one complaint where you decided from the member's side. Say what you did and what it cost you. If none comes to mind, say so plainly, then give the nearest thing your material carries: the log you handled. Do not add a member outcome you did not see. | Members First, Always. An open prompt; the theme is the published value. |
| V2 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Pick one you carried to a close. If you passed one on, say who held it after you. If none comes to mind, say so, then give the log you handled. | Own the Fix. An open prompt. |
| V3 | "Tell me about a time a member needed something explained twice." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Pick the time, and say what you changed in how you explained it. Nearest: the escalation script you taught tellers, if you changed how it was taught. If neither, say so. | Plain Words. An open prompt. |
| V4 | "Tell me about a time you delivered an unpopular truth to a manager." | VAL | [generic] persona stem; no sentence in your material carries it | Pick a time you said something a manager did not want to hear, and say what happened next. If none comes to mind, say so plainly, then say how you would handle it, as a plan. | A behavioural stem no sentence of yours carries, so the answer is a selection scaffold. |
| B1 | "You've never worked in a contact centre. This role runs across branches and the contact centre. What do you do in the first week?" | JD | [grounded] "Never worked in a contact centre" (your message); "Own the member complaints process end to end across branches and the contact centre" (JD) | Plain acknowledgment: "I've never worked in a contact centre." Then the first-week plan, said as a plan: listen to contact-centre complaint calls; sit with the team that logs them; trace one branch complaint from the branch to the contact centre and back. Hold the plan through two follow-ups. Do not describe contact-centre work you have not done. | Highest-ROI prep in the pack. The gap is in the JD's own line, so it will be asked in some form. Hold the plan; concede the gap. |
| B2 | "The role means presenting to senior leaders. What's your experience of that?" | JD | [grounded] "I've never presented to anyone above regional level." (your message) | Plain acknowledgment, no slot: "I've never presented to anyone above regional level." Then the plan: how you would build to it, for example presenting the monthly figures to your own manager first and asking what to cut. Do not describe a presentation you have not given. | A stated capability gap. The acknowledgment needs no slot; only the plan looks forward. |
| B3 | "Which rules did the branch's formal complaints log have to meet?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Answer slot: if the log ran to rules or deadlines, name them and how you worked to them; if it ran to none, say so and say what it did run to. Do not name a rule, regulator or timeframe the log did not carry. | F2. The JD asks for regulated complaints; your sentence says formal. The second branch lets the premise be false. |
| C1 | "The strategy moves 40% of member service to digital channels by 2028. What happens to the complaints that come with that?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy summary, your message) | Structure aloud: which complaints start in a digital channel; who takes the ones that do not; what you would watch in the first quarter. Use the brief's terms as the interviewer's. For your own digital experience, use the F9 slot. | CO content, CASE delivery: the one strategy question in this round, at manager altitude. |
| P1 | "Walk me through how the monthly complaints spreadsheet counts what it counts." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Say what it counts, in your words. Name the weakest assumption you know of before they do. If you do not know how a figure was counted, say so. Answer slot: if it held resolution times, say how they were counted; if it did not, say so and say what you would add first. | F4 and F7. Metric questions get the weakest-assumption move; the resolution-time branch is the honest one. |
| P2 | "The role reports monthly on volumes and resolution times. What would you measure first, and why?" | JD | [grounded] "report monthly on complaint volumes and resolution times" (JD) | Name volume and time-to-resolve in plain words, then the one definition to pin down before trusting a resolution time: when the clock starts and stops. No past claim, no figure. | F7 and the JD line. Tests what you would measure, not what you measured. |

**Reverse questions**

1. "When branches consolidate in 2027, who owns a complaint that starts in a branch that is closing?" Why it lands: it tests the seam between consolidation and complaints, and the answer tells you whether this role owns it.
2. "How much of the 40% digital target sits with this team?" Why it lands: you learn the scope before you are asked about it.
3. "What would success look like for this role at six months?" Why it lands: it lets you answer in your manager's terms.

## Round 3: Panel of two branch managers (60 minutes, values round, 20-minute case)

The recruiter's description: the panel scores against the four values, so this is the values-style round. The recruiter's words make it a loop source, which establishes the round and its values scoring. Members are not named. The panel blends values and case as the lead personas, with peer and pressure following.

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Scored against each of the four values | 4 questions: top weight, one per value | A story per value from your own sentences; the honest branch where none |
| Case / Strategist | The 20-minute escalation case | 2 questions: the case is the round's largest block | Clarify, then the member, then ownership, log, prevention |
| Peer Evaluator | Branch managers, the seam, disagreement | 2 questions: branch managers sit beside this role | Reciprocity; seam principles as proposals |
| Pressure | Time-boxed challenge to the core claim | 1 question: a panel of two can press on a stated gap | Hold; concede the gap specifically |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time a rule and a member pulled in different directions." | VAL | [grounded] "Members First, Always: we decide from the member's side of the counter" (published values, as you pasted); "I handled the branch's formal complaints log" (your message), nearest | Pick the time, and say which side you decided from and why. If none comes to mind, say so plainly, then give the log you handled and how you handled one complaint in it. | Members First, Always. An open prompt. |
| V2 | "Tell me about a time a member couldn't follow what you had told them." | VAL | [grounded] "Plain Words: if a member needs it explained twice, we wrote it wrong" (published values, as you pasted); "trained new tellers on our escalation script" (your message) | Pick a time, say what you changed in the explanation, and what the member did next. Nearest: the escalation script you taught tellers, if you changed how it was taught. If neither, say so. | Plain Words. An open prompt. |
| V3 | "The strategy consolidates eight branches into five hubs over 2027. A member in one of the closing towns asks what it means for them. What do you tell them?" | CO | [grounded] "Neighbours, Not Numbers: every branch is part of its town" (published values, as you pasted); "consolidate eight branches into five hubs over 2027" (strategy summary, your message) | Plain words to the member first: what is known, what is not, who they call, when they will hear. Then the value: track that town's complaints as their own line, not folded into a hub figure. Do not claim to know the plan's local effects; the brief does not name towns. Answer slot: if you have been through a branch change, say what you did; if not, say so and say how you would track it. | Neighbours, Not Numbers is the value the consolidation tests. CO content, VAL scoring. |
| V4 | "Tell me about a time you found a problem nobody had been assigned to fix. What did you do?" | VAL | [grounded] "Own the Fix: whoever finds the problem keeps hold of it until it is solved" (published values, as you pasted); "I handled the branch's formal complaints log" (your message), nearest | Pick one you took on and kept hold of until it was solved. If you handed it on, say who held it after you. If none comes to mind, say so plainly, then give the log you handled. | Own the Fix. An open prompt, with a different angle from round 2's V2. |
| C1 | Example case, since the panel's own case is not in hand: "A member's fee complaint has sat with the branch for three weeks with no reply. They have called the contact centre twice and been told to try the branch. They want it sorted by Friday, and say they will go to the regulator if they do not hear. You are the escalation point. Walk us through the first hour and the first week." | CASE | [generic] case pattern; [grounded] "trained new tellers on our escalation script" (your message); "I handled the branch's formal complaints log" (your message) | About two minutes, six steps. (1) Clarify before acting: what the complaint is, what has been done, the deadline, who holds it now. (2) The member first: one plain-words call back today, saying what they will hear and when. (3) Own it: name yourself as holder until it is closed; say whom you would bring in, such as the branch supervisor or the contact-centre lead, and what you would ask of them. (4) Log it the way you kept the branch's formal complaints log, so the month's figures show it. (5) Close the loop: tell the member the outcome in plain words. (6) Prevent: one change to the script. Answer slot: the escalation script you taught has a step where a complaint moves up; say which step this case hits and what you would do there. If the script had no such step, say so. | The 20-minute block and the largest share of the round's scoring. [generic] because the panel's case will differ; the six steps carry over. Replace the example once the recruiter shares the format. |
| C2 | "A branch supervisor brings you an escalation they can't close. How do you coach them through it?" | JD | [grounded] "coach branch supervisors on escalations" (JD); "trained new tellers on our escalation script" (your message) | Coaching structure: ask what they have tried; agree the next step with them, not for them; check the outcome with them afterwards. Answer slot: you trained tellers on a script; say how you would adapt it for supervisors. If you have coached a supervisor through an escalation, say what you did; if not, say so and say how you would start. | F8. Coaching supervisors is a step beyond your sentence. JD because it scores the coaching requirement, delivered as a case. |
| E1 | "What would you need from our branches to make complaints work?" | JD | [grounded] "coach branch supervisors on escalations" (JD) | Name what you would give their teams before what you need: the monthly figures back to them, a clear route for escalations, and the turnaround you would be measured on. No claims about your past; the plan carries it. | Peer Evaluator, reciprocity: what you bring their teams, not only what you need. |
| E2 | "Where's the seam between a branch and the contact centre, and what happens when we disagree?" | EXP | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment first: "I've never worked in a contact centre." Then seam principles, proposed and not claimed: one owner per complaint at a time, named in the log; disagreements go to a named manager within a fixed time. Ask where the seam currently breaks. Do not pretend to know their seam. | Peer Evaluator: turf and disagreement. The principles are proposals about this process, not claims about the panel's. |
| X1 | "Sixty seconds: why should this panel trust a branch supervisor with 900 staff?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "Never worked in a contact centre" (your message) | Pause and restate the question in your words. Hold on the record: six years in retail banking, the last three as a branch supervisor, and the complaints log you handled. Hold through two follow-ups. Concede specifically: you have never worked in a contact centre and have never presented above regional level. Do not fold on what you did. | Pressure: hold, then concede. The position is what your sentences carry, and no more. |

**Reverse questions**

1. "What could a new Member Experience Lead do in the first month that would genuinely help your branches?" Why it lands: a peer's reciprocity question. The answer becomes your first-month list.
2. "Where does an escalation from a branch usually get stuck?" Why it lands: it asks for the seam, so you can show you would look for the break, not the blame.

**Values cheat sheet** (this round is the values round)

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No sentence of yours carries a member-led decision. Selection scaffold, V1 above; honest branch: give the complaints log you handled. |
| Plain Words | If a member needs it explained twice, it was written wrong | F8's sentence, at its scope: you trained tellers on the escalation script. The explained-twice moment is yours to pick; if none, say so. |
| Neighbours, Not Numbers | Every branch is part of its town | No sentence of yours carries a town story. Selection scaffold, V3 above; honest branch: say how you would track a closing town's members, as a plan. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F5's sentence at its scope: you handled the branch's formal complaints log. Selection scaffold, V4 above; honest branch: give the log. |

**Highest-ROI prep:** the contact-centre objection (B1 in round 2, also B1 in round 1). It is stated in your own words, it sits in the JD's own line, and it will be asked.

## Sources

- **Provided documents:** your message (the JD text, your background, the four values as copied from ashgrovecu.org/about/values on 24 November 2026, the strategy summary, and the recruiter's description of the three rounds).
- **Searches and fetches sent:** none.

**Research tier: L1, searches 0 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values as pasted on 24 November 2026 fix the values cheat sheet. |
| 2. Ashgrove interview process, Member Experience Lead | skipped | The recruiter's description names the three rounds, their length, who runs each, and the values scoring. That is a loop source that establishes the loop. |
| 3. Ashgrove strategy and recent news | skipped | The summary of the July 2026 brief, under six months old, fixes current priorities. The brief itself is not in hand, so the CO bank uses only the four facts you gave. |
| 4. Interviewer name and Ashgrove | n/a | No interviewer is named, so there was no query to form. The reading of the interviewer is absent; the upgrade menu says what a name would unlock. |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The panel's case, or its format from the recruiter → replaces the example in round 3's C1 with a grounded case, and tells you whether the case is written or given live.
- The interviewers' names → reading of each interviewer, and per-person persona weights for rounds 2 and 3.
- Whether your complaints spreadsheet counted volumes or resolution times, in one line → F7 moves from discovery to grounded either way.
- Whether the formal complaints log ran to rules or deadlines → F2 resolves, and B3 becomes a plain answer.
- Any digital or IT change you worked on → F9 becomes a grounded row, and A2, C1 and the round 2 digital answers get a real example.
- Column headings of the complaints spreadsheet, with no member data, if your employer allows sharing → F4 and F7 become an inspectable artifact. Check the sharing rules first.
- Which hub the role sits in, from the recruiter → answers L3 directly, and sharpens V3.
- The full strategy brief, not the summary → a fuller grounding brief and a deeper CO bank. A deeper research pass is available: up to 6 more searches and 2 more fetches, several minutes. Say the word if you want it.
