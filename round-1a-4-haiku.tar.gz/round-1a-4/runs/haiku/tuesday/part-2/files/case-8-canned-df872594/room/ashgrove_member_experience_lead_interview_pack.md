# Ashgrove Credit Union: Member Experience Lead interview prep pack

**Role:** Member Experience Lead, Ashgrove Credit Union
**Mode:** Loop. Three rounds on 3 December 2026, each with its own mini-pack below.
**Interviewers:** Recruiter (name not given). Head of Member Services, your future manager (name not given). Panel of two branch managers (names not given).

## How to use this pack, and the type key

Personas describe how a question is asked. Types describe what is being scored.

- **VAL**: values alignment, against Ashgrove's four published values
- **EXP**: your own experience, and whether the detail survives follow-up
- **JD**: the listed job, including its gaps
- **CO**: company and strategy knowledge
- **CASE**: a live problem, reasoned aloud

Guidance is scaffolding, not a script. Answer slots are instructions for the interview itself, not questions for you to answer here. Every claim about your past is one of your own sentences, quoted.

## Prep triage

Prep time: nine days, 24 November to 3 December. All three rounds fall on 3 December, so rehearse in the order you will meet them.

1. **R2-S1, the contact-centre gap.** This is the most predictable objection and the highest-return rehearsal in the pack. Say it aloud with the two follow-ups until the concession is short and specific.
2. **R3-K1, the 20-minute escalation case.** Practise a twenty-minute walk-through out loud, timed, with the first ten minutes' decisions said first.
3. **R2-V2, R3-V3 and R2-V1: your values stories.** Build one real story each for Own the Fix and Members First. Where you have none, the honest answer is shorter and says so.
4. **R1-C2 to R1-C5: your logistics answers.** Decide your own notice period, location and office pattern, and write them down in your own words. Decide on a pay figure only if you have one.
5. **R1-S2 and R3-P1: the presenting gap.** Rehearse the plain acknowledgment and one sentence of plan, so it comes out calm.

Everything else is insurance.

## Fit snapshot

Requirements are the job description's own words, quoted. Duties from the JD's role description are included, since the panel scores them. No requirement in the JD or recruiter email is a term or credential gate, so no row is `hard_gate`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | Words: "For six years I worked in retail banking, the last three as a branch supervisor." Your material shows branch work. It does not show contact-centre or customer-operations management, so do not describe it as either. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material shows a formal log, not whether any rule governed it. Answer slot: if a deadline or a regulator's rule governed the log, say which and how you tracked against it. If none did, say so plainly and say what the log was for. |
| F3 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Words: "I haven't presented to anyone above regional level." Then how you would prepare for a senior presentation, said as a plan and never as a past. |
| F4 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Words: "For the branch, I handled the formal complaints log." Answer slot: which steps from first contact to close were yours to set. If none were, say so, and say what you would do first across more than one branch. |
| F5 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Words: "I've never worked in a contact centre." Then how you would learn the contact-centre side, said as a plan and never as a past. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Words: "I trained new tellers on our escalation script." Answer slot: if you coached any supervisor on an escalation, say how. If you did not, say so and say how you would start. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show digital or self-service work. Answer slot: if you worked with any digital or self-service team, say who and what you did. If you did not, say so plainly. |
| F8 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | transferability | Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: whether it tracked how long complaints took to resolve. If it did, say what it counted. If not, say so. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | Your material says spreadsheet, not Excel. The pack does not say Excel for you. Words: "I built the monthly complaints spreadsheet our regional manager uses." |

**Confidence bands in this table:** F1, F2, F4, F6, F8 and F9 are medium because your claims are specific and yours, but nothing has been inspected. F3 and F5 are none because they are stated absences. F7 is none because nothing is given.

## Prohibited claims

Built from the fit snapshot before any question was written. None of these will be coached.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F4 | The quote at its own scope: "I handled the branch's formal complaints log." Observation for you, not words to say: your material describes the branch log, not the process across branches and the contact centre. R2-S3 stays inside the log. |
| Worked in a contact centre | Negative you stated (F5) | "I've never worked in a contact centre." No answer slot. |
| Presented to senior leaders | Negative you stated (F3) | "I haven't presented to anyone above regional level." No answer slot. |
| Coached branch supervisors on escalations | Inflated form of F6 | The quote at its own scope: "trained new tellers on our escalation script." Observation: the coaching you describe is tellers, not supervisors. R3-K3 stays inside that. |
| Excel reporting | Inflated form of F9 | "I built the monthly complaints spreadsheet our regional manager uses." The tool is named only if you name it. |
| Regulated complaints | Inflated form of F2 | "I handled the branch's formal complaints log." Whether it was regulated is an answer slot (R2-S4), not an assertion. |

## Grounding brief

Provided by you. I have not seen the strategy brief itself, only your summary of it. Treat the figures below as your summary.

- **Values, official names as published:** Members First, Always. Plain Words. Neighbours, Not Numbers. Own the Fix.
- **Strategy, July 2026 brief as you summarised it:** move 40% of member service to digital channels by 2028. Consolidate eight branches into five hubs over 2027. Launch a small-business lending product in Q1 2027. Name app-only banks as the main competitive pressure.
- **Vocabulary to use:** member service, branch, hub, contact centre, digital channels. The recruiter's email and the JD supply the rest.
- **Stale framings:** none identified in your inputs.

---

## Round 1: Recruiter screen, 30 minutes, 3 December

**Persona weights**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | A friendly walk through your background, then logistics in a chatty register | Top weight. Screens are mostly logistics and motivation. The four logistics rows are the screen's fixed part, so this persona carries six rows, more than the usual four to five | A ninety-second arc for the biography. Answer logistics in your own words. Treat the digital question as scored |
| Skeptic | Asks about the contact-centre and presenting gaps early | Light weight, two items. Recruiters screen for knockouts, and these two gaps are the likeliest knockouts | Plain acknowledgment, then one sentence of plan. Nothing more |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-C1 | "Walk me through your journey so far." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses." | Ninety-second arc in your own words, in the order your material gives it: the six years, the last three as a branch supervisor, then the complaints log, then the spreadsheet. Stop there. The contact-centre point comes from the panel. | Covers the years requirement (F1). The question is an opener, scored for economy. The JD tag is the years requirement the arc answers. |
| R1-C2 | "What are your pay expectations for this role?" | JD | [generic] screen pattern; no pay figure given by you | Logistics slot: give your own figure in your own words, if you have decided one. If you have not, say you would like the band first. Do not give a range, floor or flexibility you have not set. | Logistics row under the recruiter-screen rule. Your inputs contain no pay figure, so the pack supplies none. |
| R1-C3 | "When could you start, and what notice do you owe?" | JD | [generic] screen pattern; no notice period given by you | Logistics slot: give your actual notice period in your own words. Your inputs state none, so the pack supplies none. | Logistics row. A notice figure is yours to state. |
| R1-C4 | "Where are you based, and how often can you be in an office?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief, as you summarised it) | Logistics slot: give your own location and office pattern in your own words. Your inputs state neither, so the pack supplies neither. | The hub consolidation is why office pattern may come up. The screen asks for your terms, not the plan's. |
| R1-C5 | "Why are you leaving your current role?" | EXP | [generic] screen pattern; no reason given by you | Logistics slot: give your own reason in one or two sentences, in your own words. Keep it about your move, not your employer. Your inputs state no reason, so the pack supplies none. | Logistics row. The reason is not coached. |
| R1-C6 | "What are you playing with in digital and self-service work these days?" | JD | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief, as you summarised it) | Answer slot: if you worked with a digital or self-service team, say who and what you did. If you did not, say so plainly. Then say what you would want to learn first, as a plan. | F7 is discovery. The question is casual but scored, and the 40% goal is why it will come up. |
| R1-S1 | "You've never worked in a contact centre. What's your read on that?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then one sentence on how you would start learning it, as a plan. Nothing about contact-centre work from your past. | F5 is capability. The screen gets the short version. Round 2 gets the deep one. |
| R1-S2 | "Would you be comfortable presenting to our senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then one sentence on how you would prepare for a first senior presentation, as a plan. | F3 is capability. The screen's Skeptic probe. Round 3 goes deeper. |

**Reverse questions**

- "How much of today's complaint load starts in the contact centre rather than at a branch?" Why it lands: you have looked at the scope of the job before the next round.
- "How will complaints from branches being consolidated into hubs be handled during the move?" Why it lands: it ties to the 2027 plan and shows you read the brief at its altitude.
- "What would you most want the Member Experience Lead to have changed by the first review?" Why it lands: it asks for the outcome, not the process.

---

## Round 2: Head of Member Services, 45 minutes, mostly behavioural

**Persona weights**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the contact-centre gap, the day-one weakness, the branch-to-end-to-end step, and the rules on regulated complaints | Top weight, four items. A hiring manager is buying capability and derisking the gaps. Follow-ups are most likely here | Plain acknowledgment, then a plan. Hold through two follow-ups. Concede in one specific sentence |
| Values / Behavioral | STAR-shaped prompts on three of the four values | Mid weight, three items. The round is mostly behavioural, and the values scoring comes at round three, so these are practice for it | Use "we" for context and "I" for what you did. Map a story only where one of your quoted sentences carries it. Otherwise give the honest branch |
| Case / Strategist | One practical question about the monthly report | Low weight, one item. It tests how you would report on the job, which the JD names | Say what you would measure, and name only the tools you have used |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-S1 | "You've never worked in a contact centre. How would you run a complaints process that starts there?" | JD | [grounded] "Never worked in a contact centre"; the JD's "Own the member complaints process end to end across branches and the contact centre" | **Highest-return prep in this pack.** Hold the plain acknowledgment: "I've never worked in a contact centre." Then the plan: what you would learn first, in what order, and from whom. Hold through two follow-ups by returning to the plan. Concede in one specific sentence, naming one part of the contact-centre process you do not yet know. Never describe contact-centre work from your past. | F5 is the stated gap on the scope line the job is built on, so it is the most predictable objection. Rehearse both follow-ups aloud and the concession wording until they are short. |
| R2-S2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level" | Name one requirement in the JD's own words. The presenting requirement is the one your inputs state. Then a one-sentence ramp plan for the first month, as a plan. Do not name a strength to soften it. | Skeptic stem. The answer that works is one specific gap with a plan. |
| R2-S3 | "Your complaints work was at branch level. What changes when it has to run end to end across branches and the contact centre?" | EXP | [grounded] "I handled the branch's formal complaints log" | Tell the branch log in your own words, at its own scope. Answer slot: which steps from first contact to close were yours to set, and how you decided. If none were yours, say so plainly and describe how the log ran. Then what changes at scale, as a plan. | F4 is transferability. The honest form stays inside the log. |
| R2-S4 | "Which rules, if any, governed the formal complaints log you handled?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: if a deadline or a regulator's rule governed the log, name it and how you tracked against it. If none did, say so plainly and say what the log was for. Use the word "regulated" only if you can say what it meant in your log. | F2 is discovery. The JD's "regulated complaints" is the raising line, and the honest answer is whatever the log actually was. |
| R2-V1 | "Tell me about a time you decided something from the member's side of the counter when the branch process pointed the other way." | VAL | [grounded] "I handled the branch's formal complaints log" | Scaffold: pick a time a member's side pulled against process, with a named stake, the decision you made and what happened. If none comes to mind, say so plainly. Then give the nearest thing: the log, in its own terms, and only if you handled a member's case through it. Do not borrow someone else's decision. | Members First, Always. The quote carries no decision, so the guidance has no story to map. |
| R2-V2 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Scaffold: a complaint you held to resolution, with the stake and the ending named. If none ran to resolution in your hands, say so plainly, then describe the log's nearest case in its own terms. | Own the Fix. The honest-branch form is the one your material supports. |
| R2-V3 | "What did you learn from training new tellers on the escalation script?" | VAL | [grounded] "trained new tellers on our escalation script" | Answer slot: if you changed the script after seeing what tellers did not follow, say what changed and why. If you did not change it, say so plainly and say what you would check first. | Plain Words. The training is the quote's scope. The question asks what it taught, not what it did for members. |
| R2-K1 | "What would you put on the monthly complaints report for this role, including volumes and resolution times, and which tools would you build it in?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Presentation: the spreadsheet you built is the base of your answer, in those words. Answer slot: if it tracked how long complaints took to resolve, say what it counted. If not, say so and say what you would measure first. Name only the tools you used. | F8 and F9. The material says spreadsheet, not Excel, and the pack does not say Excel. |

**Reverse questions**

- "Which monthly complaints measure would you most want changed first?" Why it lands: it shows you would report on outcomes, not just produce the spreadsheet.
- "How will the move to digital channels change where complaints come from?" Why it lands: it ties to the 40% goal and shows you think about where the job is going.
- "What would you want a new person to have done in their first thirty days?" Why it lands: it signals you plan for the job, not only for the interview.

---

## Round 3: Panel of two branch managers, 60 minutes, 3 December

The panel also scores the four values. The 20-minute case is a complaint escalation. Persona weights come from the panel's remit, since their members' names are not given.

**Persona weights**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scored questions on each of the four values | Top weight, four items. The recruiter says the panel scores against the values | Map a story only where one of your quoted sentences carries it. Otherwise give the honest branch, and say it plainly |
| Case / Strategist | The 20-minute escalation case, a digital-strategy question, and coaching a supervisor | Mid weight, three items. The case is announced, and the other two are the panel's own practical questions | Clarify, then structure, then decide what to do first. Keep the first ten minutes' decisions in view |
| Pressure | A sixty-second "what do you bring" | Low weight, one item. The panel's composure test is less likely than the values test, so this is one item rather than two | Hold what your quotes carry. Concede the contact-centre gap in one sentence |
| Skeptic | Your last formal complaint, from first contact to close, and the first month before changing a route | Low weight, two items. A panel of branch managers will test whether your story survives cross-examination | Answer only from your quotes. Where none carries the step, say so |

**Values cheat sheet**

Each value is listed with its working meaning and the story it maps to, or the honest branch where no story is in your material.

| Value (official name) | Working meaning | Mapped story | Selection scaffold and honest branch |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | None of your quoted sentences carries a member-side decision. The nearest is F4: "I handled the branch's formal complaints log" | Pick a decision where a member's side pulled against process, with a named stake. If none, say so plainly and describe the nearest thing in the log's own terms. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | F6: "trained new tellers on our escalation script" carries training on a script, not clarity for members | Pick a time a member did not understand a decision the first time. If you changed how it was explained, say what and why. If you did not, say so. |
| Neighbours, Not Numbers | Every branch is part of its town | F8 and F9: "I built the monthly complaints spreadsheet our regional manager uses" is a numbers story | Pick a place you knew, and a member or branch situation you dealt with as local. If your only story is the report, say so and do not dress it as a town story. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F4: "I handled the branch's formal complaints log" carries handling, not holding a problem to solved | Pick a problem you found, with the stake and the ending named. If it did not end in your hands, say where it ended and say so. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-V1 | "When did you put a member ahead of an internal metric?" | VAL | [grounded] "I handled the branch's formal complaints log" | Scaffold: a time a member's interest beat a branch number, with the stake, the call you made and the ending. If none, say so plainly and give the nearest thing in the log's own terms. Do not turn the log into a member story it does not show. | Members First, Always. The honest branch is the form your material supports. |
| R3-V2 | "Tell me about a time you treated a branch as part of its town rather than as a number." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Scaffold: a place you knew, or a member or branch situation you dealt with as local. If your story is about the report, say so plainly. The spreadsheet is a numbers story and stays one. | Neighbours, Not Numbers. The quote is numbers, so it is the honest-branch example, not a town story. |
| R3-V3 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Scaffold: a problem you found, not one handed to you. Name the stake, the ending, and who else was in it. If it did not end in your hands, say so and say where it ended. | Own the Fix. The second branch covers a story that did not finish with you. |
| R3-V4 | "Tell me about a time you explained a decision a member did not like, so that they understood it the first time." | VAL | [grounded] "trained new tellers on our escalation script" | Scaffold: a decision a member disliked and the words you used. If it needed a second explanation, say so and what you changed. If you have no such time, say so plainly, then say what the script training taught you. | Plain Words. The training quote is about teaching staff, so the scaffold asks for the member-facing moment. |
| R3-K1 | "A member says the branch promised them a refund. The contact centre says there is no record of it. It is the third complaint from this member. Walk me through the first twenty minutes." | CASE | [generic] role-family case pattern; no claim about you | Structure, do not script. (1) Clarify the facts: what was promised, by whom, what record exists, what the member wants and by when. (2) Name one owner today, and say who holds it until it is solved. (3) Decide what the member hears in the next hour, in plain words. (4) Treat the third complaint as a pattern, not a single case. (5) Say what you would record and where. Give the panel the first ten minutes' decisions, not the full answer. | The panel's twenty-minute case. The values hooks are Members First (decide from the member's side), Plain Words (the message) and Own the Fix (the named owner). The case is a pattern, so it asserts nothing about you. |
| R3-K2 | "Digital channels are meant to carry 40% of member service by 2028. What happens to the complaints from members who still come into a branch?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief, as you summarised it) | Think at the plan's altitude: who still comes in, which complaints change with the channel, and what the hub moves do to branch members. Name the two member groups and what each complaint costs them. Do not claim anything about the bank's plan beyond the sentence. | The company-strategy question the coverage rule requires. It makes no claim about your past. |
| R3-K3 | "A branch supervisor sends you every complaint escalation a day late. How do you coach them?" | JD | [grounded] "trained new tellers on our escalation script" | Scaffold: start with what is happening and why, agree a threshold, practise on one real case, then check back. Answer slot: if you coached a supervisor on escalations, say how. If you did not, say so and say how you would start. The coaching you have described is the tellers' script training. | F6. Coach branch supervisors on escalations is in the JD. The honest branch carries this answer. |
| R3-P1 | "Sixty seconds: what do you bring that a branch manager on this panel doesn't already have?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "Never worked in a contact centre" | Hold: the branch supervision and the complaints log, in those words. Hold through two follow-ups by returning to the branch view. Concede in one sentence: the contact centre. Add no senior-presentation claim. | Pressure. The hold must be what your quotes carry. The concession is the gap the panel will already know about. |
| R3-S1 | "What would you need to see in your first month before you changed an escalation route?" | JD | [generic] open question on how a new lead decides | Name what you would look at first and what would make you hold a change. No past claims. Do not describe an escalation route you have changed. | A plan question. It tests whether you change process without evidence. |
| R3-S2 | "Walk me through the last formal complaint you handled, from first contact to close." | EXP | [grounded] "I handled the branch's formal complaints log"; the JD's "Own the member complaints process end to end" | Answer slot: if you ran steps from first contact to close, say which were yours and how you decided. If none were yours, say so plainly and describe how the log carried the complaint. | F4. The premise is the JD's end-to-end line. The answer stays inside the quote's scope. |

**Reverse questions**

- "What does a good escalation look like from a branch manager's side?" Why it lands: you are thinking from the side of the people who send them.
- "Which of the four values is hardest to apply in a live complaint in your branches?" Why it lands: it invites a candid picture and shows you have read the values.
- "When the small-business lending product launches in Q1 2027, who owns a complaint about it?" Why it lands: it ties the launch to ownership and shows you think about what comes next.

---

## Requirement coverage

Each JD requirement, and the questions that cover it.

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | R1-C1 |
| experience handling regulated complaints | R2-S4, R3-S2 |
| confident presenting to senior leaders | R1-S2, R2-S2, R3-P1 |
| comfortable with Excel reporting | R2-K1 |
| Own the member complaints process end to end across branches and the contact centre | R1-S1, R2-S1, R2-S3, R3-S2 |
| report monthly on complaint volumes and resolution times | R2-K1 |
| coach branch supervisors on escalations | R3-K3 |
| work with digital teams on self-service journeys | R1-C6, R3-K2 |

Values coverage: Members First, Always is covered by R2-V1 and R3-V1. Plain Words by R2-V3 and R3-V4. Neighbours, Not Numbers by R3-V2. Own the Fix by R2-V2 and R3-V3.

Session totals: 8 questions in Round 1, 8 in Round 2, 10 in Round 3. Twenty-six in all.

---

## Sources

**Provided documents:**
- The job description, as you pasted it
- Ashgrove's four values, as you pasted them from ashgrovecu.org/about/values, copied 24 November 2026
- The recruiter's email on the round structure
- The July 2026 strategy brief, as you summarised it in your message (I have not seen the document itself)
- Your background, from your message

**Searches and fetches sent:** none.

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text you pasted fixes the values cheat sheet and the VAL rows |
| 2. Ashgrove interview process, Member Experience | skipped | The recruiter's email fixes the three rounds, their lengths and the panel's values scoring, so the loop and persona weights rest on it |
| 3. Ashgrove strategy and recent news | skipped | The strategy brief summary you pasted fixes the grounding brief and the CO question. News after July 2026 could move R3-K2, and it is an L2 item in the upgrade menu |
| 4. Interviewer name and Ashgrove | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Research tier: L0, no searches.

---

## Upgrade menu

- **Head of Member Services' name, and the panel's names** → persona weights read from their public footprint, and reverse questions tied to their career paths.
- **Whether the panel gives the 20-minute case in advance or on the day** → R3-K1 is replaced by the actual scenario.
- **Your own notice period, location and office pattern, written in your own words** → R1-C3 and R1-C4 carry your answers rather than instructions.
- **A pay figure you have decided on** → R1-C2 carries your own answer, not an instruction. Without one, it stays an instruction.
- **An anonymised sample of the monthly complaints spreadsheet, with member details removed** → F8 and F9 rise from medium to high, with the artifact named as the thing you can show.
- **Any recruiter note on the case format or the values scoring** → R3-K1 and the values cheat sheet take the panel's own words.
- **A deeper research pass, L2: the strategy brief itself, interviewer public talks, loop reports, recent leadership changes** → up to six further searches and two further fetches, several minutes of run time, run only on your yes. The grounding brief and R3-K2 move from your summary to cited sources.
- **An existing tuesday-dossier.md, if you have one** → I would read it and sharpen R2-S1 and R3-S2 with anything it has verified.
