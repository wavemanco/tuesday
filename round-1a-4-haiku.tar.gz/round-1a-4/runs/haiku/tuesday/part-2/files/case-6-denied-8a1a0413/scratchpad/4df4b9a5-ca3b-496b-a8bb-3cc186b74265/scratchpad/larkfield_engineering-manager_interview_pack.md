# Larkfield Systems, Engineering Manager: interview prep pack (loop)

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, about 600 people)
**Interviewers:** (1) Director of Engineering, hiring manager, 45 min, Tuesday. (2) Panel of two staff engineers and a product manager, 60 min, Thursday. (3) VP Engineering, 30 min, the following Monday, described by the recruiter as "values and leadership philosophy".
**Changes in this version:** first version. Research did not run (search permission was refused), so the values, loop-structure and strategy facts are not established.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values and behavior), EXP (your experience, under scrutiny), JD (the role's stated requirements), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding for a spoken answer, not a script. Rehearse only what you actually did, in your own words.
- Provenance cells quote the sentence each claim rests on. `[grounded]` means traceable to your message or the role text you gave me. `[inferred]` means derived. `[generic]` means a pattern for this kind of question, with no claim about you or Larkfield.

## Loop structure

Your message names three sessions, who runs each, and their length. That establishes the loop, so no archetype fallback applies. The VP round is described by the recruiter as values-style, which makes a values round detected. Published Larkfield values are not in hand, so the values cheat sheet is not included.

## Shared fit snapshot

Requirements come from the role description you gave me (a summary, not the full JD). Evidence comes from your message (no CV was provided). Every evidence cell quotes your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role text | "9 years engineering, 3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material shows one team of six, not two squads. Keep the bridge at that scope: "For three years I led a team of six." Answer slot: if you have coordinated work across two streams, say what each was and what you decided in each. If you have not, say so, and say how you would split the two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" — role text | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | presentation | Hiring is reached in other terms. Reword only the quote: "I run our hiring loop for backend roles, about 40 interviews last year." Add no practice, figure or event. |
| F3 | "own delivery, hiring and growth for 11 engineers" — role text | none given | none | [grounded] | discovery | Growth is not shown by any sentence you gave me. Answer slot: if you have grown someone into a bigger role, say who and how. If not, say so, and say what you would do first. |
| F4 | "own delivery, hiring and growth for 11 engineers" — role text | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | This is reliability work, not delivery throughput. Bridge at its own scope: "I pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60%." The headline figure raises defend-the-number slots (H8, P4). |
| F5 | "partner with hardware and product on roadmap" — role text | "I've never owned a hardware-adjacent roadmap." — your message | high | [grounded] | capability | A gap you stated. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F6 | "partner with hardware and product on roadmap" — role text | none given | none | [grounded] | discovery | Your material says nothing about working with product on a roadmap. Answer slot: if you have set a roadmap with a product partner, say what you agreed and what you decided. If not, say so, and say how you would start. |

**Your own gap, not a listed requirement:** "I've never managed managers" (your message). It is not in the role text, so it gets no row. It is the basis for V8 and P8.

Confidence grades your evidence. Provenance grades this pack's statement. Gap type is a separate call.

## Prohibited claims

Built locally from the snapshot. These are the claims a candidate reaches for under pressure. None of the guidance below asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers | Stated negative, "I've never managed managers", plus an inflated form of F1 | Plain acknowledgment: "I've never managed managers." Team lead of six is the quote's scope. No slot. |
| Owned a hardware-adjacent roadmap | Stated negative, F5 | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then a plan. |
| Built the hiring loop | Inflated form of F2 ("I run our hiring loop") | Quote at its scope: "I run our hiring loop for backend roles." The pack's observation: your material says you run the loop, not that you designed it. |
| Set the org's reliability strategy | Inflated form of F4 ("pushed a reliability quarter through") | Quote at its scope. The 60 percent is your team's on-call burden. |
| Owned delivery for eleven engineers | Inflated form of F1 and F4 (team of six) | Team of six is the scope. |

## Persona weights per round

**Round 1: Director of Engineering (hiring manager), 45 min.** Relationship prior: Case/Strategist and Skeptic. They are buying capability and derisking gaps, and expect live problems on the roadmap.

| Persona | Weight | Reasoning |
|---|---|---|
| Skeptic | 4 questions | Your gaps (F1, F5) are the main risk. Expect them to be tested directly. |
| Case/Strategist | 3 questions | Live roadmap problems are the stated purpose of the round. |
| Data-Driven Prober | 2 questions | Your 60 percent and 40-interview figures will be probed. |
| Pressure | 1 question | Composure check on the scope objection. |
| Conversational | 1 question | Opening biography. Scored despite the casual register. |

**Round 2: panel (two staff engineers and a product manager), 60 min.** Blend by member. The two staff engineers lean Peer Evaluator and Data-Driven Prober. The product manager leans Case/Strategist and Peer Evaluator. Names are not known, so the blend is by role.

| Persona | Weight | Reasoning |
|---|---|---|
| Peer Evaluator | 4 questions | Two of three members are peers in the function. They price partnership and seams. |
| Data-Driven Prober | 2 questions | Staff engineers read your figures closely. |
| Case/Strategist | 2 questions | The product manager's question is roadmap-shaped. |
| Skeptic | 1 question | The seam between teams is where the gap shows. |

**Round 3: VP Engineering, 30 min.** Relationship prior: Values/Behavioral and Pressure. The recruiter's "values and leadership philosophy" makes this a values round. Published values are not in hand, so the VAL questions use selection scaffolds and their honest branches.

| Persona | Weight | Reasoning |
|---|---|---|
| Values/Behavioral | 4 questions | Stated purpose of the round. |
| Pressure | 2 questions | Executive altitude and composure. |
| Case/Strategist | 1 question | Strategy questions are generic here; research did not run. |
| Skeptic | 1 question | Your stated gap, tested at the leadership level. |

## Question banks

### Round 1: Director of Engineering (hiring manager)

Highest-ROI prep for this round: **H2**, the scope objection. Its follow-ups go two levels deep.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Walk me through your path from engineer to team lead." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6" — your message | A 90-second arc in your own words: nine years, three as a team lead of six, now at a payments company. Keep the team's scope exactly as stated. | F1 is the opening fact. This is the conversational opener scored as EXP. |
| H2 | "Two squads is a bigger job than one team of six. Where would you be weakest on day one?" | JD | [grounded] "Lead two squads building device-management services" — role text; [grounded] "3 as a team lead of 6" — your message | Hold: "I've led one team of six, not two squads." Concede specifically: you have no two-squad history. Then give a plan for the first 30 days. Hold through two follow-ups by returning to the team of six. Never claim two-squad experience. | F1 is the objection most likely to come up in some form, so it gets the deepest rehearsal here. |
| H3 | "You've never owned a hardware-adjacent roadmap. How would you handle a roadmap with hardware in the room?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." — your message | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then a plan: what you would ask the hardware lead first and how you would learn their release constraints. Present the plan as a plan. | F5 is a stated gap. The honest answer is the acknowledgment plus a plan. |
| H4 | "Why this role, when you haven't managed managers or owned a hardware roadmap?" | EXP | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | Say what you would bring (the reliability record and the hiring loop), then what you would grow into. Do not describe the gaps as small. | Skeptic motivation probe. Built on F1 and F5. |
| H5 | "A device fleet: a fifth of gateways report stale telemetry after a firmware push. Walk me through this week." | CASE | [generic] | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise, respectfully. | Live problem from the role. No claim about your past. |
| H6 | "Hardware wants to delay a release and product wants the Q3 date. How do you decide?" | CASE | [generic] | Name the trade, the people who hold each side, and what you would need to know. Do not give a verdict before the facts. | Roadmap-partnering problem from the role. No claim about your past. |
| H7 | "What would your first 90 days look like with two squads and 11 engineers?" | JD | [grounded] "Lead two squads building device-management services" — role text; [grounded] "own delivery, hiring and growth for 11 engineers" — role text | A plan, not a past. Say what you would listen for in the first month and the first decision you would make. | Covers the squad and headcount requirements as a plan. |
| H8 | "Walk me through how the 60 percent on-call drop was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Defend the number in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you do not know how it was counted, say so plainly. Name the weakest assumption before they do. | F4's headline figure. Prober probes the figure, and the honest "I don't know how it was counted" is a valid branch. |
| H9 | "Of the 40 interviews, how many loop stages did you design, and how many did you run?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Defend the number in your own words. Answer slot: if you designed any stage, say which and how you decided. If you only ran a loop someone else designed, say so. | F2's figure. Defend-the-number slots apply. |
| H10 | "That's a one-team story. Why wouldn't two squads break you?" | Pressure | [grounded] "3 as a team lead of 6" — your message | Hold the position you can back: one team of six, with the reliability record. Concede specifically: you have not run two squads. Do not fold on the core claim to restore harmony. | Hold-then-concede on F1. A held position you cannot back is the one the second follow-up breaks. |

**Round 1 reverse questions** (at least five):
1. "What does the roadmap for the first squad look like over the next two quarters?" — Shows you are planning against the live problem.
2. "Where has the hardware partnership broken down before?" — Surfaces the seam you will be working on.
3. "How do you measure a manager's success in the first six months?" — Tells you the success criteria before you are judged on them.
4. "What would make the first 90 days an obvious win for you?" — Same, from the hiring side.
5. "Which part of the hiring loop do you most want the new manager to own?" — Connects the loop to their priorities, not yours.

*Interviewer path:* not included. No name was given, so there is no profile to tie a question to.

### Round 2: panel (two staff engineers and a product manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our two teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [grounded] "partner with hardware and product on roadmap" — role text | Propose seam principles, not a map of their seam. Say how you would decide a disagreement and who you would take it to. Do not claim the seam from experience. | Peer Evaluator probe built on F6. |
| P2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" — your message | Use "we" for the team outcome and "I" for the decision you made. Describe the reliability quarter in those terms. | Credit-sharing probe. Built on F4 at its own scope. |
| P3 | "When a staff engineer disagrees with a roadmap call, what do you do?" | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" — your message | Selection scaffold: pick a time you disagreed with a peer over a call. It needs a stake, your position and an outcome. If none comes to mind, say so, then give the nearest thing your material carries: the reliability quarter, and what you did when roadmap pressure came. | Peer disagreement style. Honest branch is required. |
| P4 | "Walk me through the 60 percent: which measure, and over what period?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Defend the number in your own words: which measure, over what period, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you do not know the period or the measure, say so plainly. | Prober on the same figure as H8, aimed at the measure and the period. |
| P5 | "Your team of six: what did each of you own, and what did you own?" | EXP | [grounded] "3 as a team lead of 6" — your message | Separate team from individual. "We" for context, "I" for your contribution. Answer slot: if you set the team's priorities, say how. If you did not, say so. | Attribution probe on F1. |
| P6 | "A hardware partner says firmware cannot ship before the Q3 launch. What are your options?" | CASE | [generic] | Clarify, then list options, trade-offs, stakeholders, and what you would check first. No past claim. | Live roadmap problem for the product manager. |
| P7 | "What would your first roadmap conversation with product look like for the device-management backlog?" | JD | [grounded] "partner with hardware and product on roadmap" — role text | A plan, not a past. Say what you would bring to the first conversation and what you would ask. | Covers the roadmap partnership requirement as a plan. |
| P8 | "What is the part of this job you are least ready for?" | EXP | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | Plain acknowledgment of the stated gaps, then the plan for each. | Skeptic probe. Answer uses your own negatives only. |
| P9 | "So, what do you do in your job that you would bring here?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | 90-second arc: the hiring loop, the backend roles, and one other thing you are proud of, if you have one. | Conversational opener. Scored despite the casual tone. |

**Round 2 persona table.** Counts: Peer Evaluator 4 (P1, P2, P3, P9-like peer framing), Data-Driven Prober 2 (P4, P5), Case/Strategist 2 (P6, P7), Skeptic 1 (P8). Persona weights are as listed above.

**Round 2 reverse questions** (at least five):
1. "What does a good week between your team and the product manager look like?" — Shows you are planning on their actual cadence.
2. "Where do you and the staff engineers disagree most about the platform?" — Finds the live disagreement.
3. "What would a new manager do in the first month that would genuinely help your team?" — Reciprocity question, appropriate for a peer panel.
4. "What has the roadmap got wrong recently?" — Invites candor about the product process.
5. "When a disagreement goes to the wrong level, what happens?" — Tests how decisions are escalated here.

### Round 3: VP Engineering (values and leadership philosophy)

Values cheat sheet: not included. Published values are not in hand. The VAL questions below are open prompts with selection scaffolds and honest branches.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered a hard truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" — your message | Selection scaffold: pick a time you took a position against a senior push. It needs a named stake, a moment you did not fold, and an intact relationship at the end. Your nearest material is the reliability quarter. If you did not tell leadership a hard truth, say so plainly, then describe how you pushed back on roadmap pressure. | Open prompt. The quote carries pushback on roadmap pressure, not a confrontation with leadership, so the guidance does not supply one. |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a moment you chose a customer or product outcome over a team metric. If none comes to mind, say so, then say how you would handle the choice now. | Open prompt. Your material does not carry a customer story, so the honest branch is required. |
| V3 | "How do you develop the people you lead?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Answer slot: if you have grown someone into a bigger role, say who and how. If your material is only hiring, say that, then describe how you would start with growth. | F3 is the growth gap. The honest branch is the hiring work plus a plan. |
| V4 | "A leader calls the reliability work gold-plating. How do you hold your position?" | Pressure | [grounded] "pushed a reliability quarter through against roadmap pressure" — your message | Hold: the on-call record you have. Concede specifically: what you cannot yet show, such as a counterfactual. Hold through two follow-ups. | Pressure on F4 with the hold-then-concede structure. |
| V5 | "You run one team of six. Why would your approach scale to eleven?" | Pressure | [grounded] "3 as a team lead of 6" — your message; [grounded] "own delivery, hiring and growth for 11 engineers" — role text | Hold: what you can say about the team of six. Concede: you have not run eleven, and the scale question is a plan, not a record. | Scale objection built on F1. |
| V6 | "Where does a device-management service create the most value for an industrial customer?" | CO | [generic] | Frame the answer around the customer's operating problem, without claims about Larkfield's market position. Say what you would need to know. | Strategy question. Research did not run, so it stays generic. |
| V7 | "Describe your leadership philosophy in one sentence, then give one example." | VAL | [generic] | Scaffold: one sentence, then one example from your material, the reliability quarter or the hiring loop. Say the example first if it sounds more natural. | Open prompt. Scaffold is honest because no value is named. |
| V8 | "You have never managed managers. What is the first sign you would see that you are failing at it?" | JD | [grounded] "I've never managed managers" — your message | Plain acknowledgment: "I haven't managed managers." Then the signs you would watch for, as a plan. | Skeptic probe on the stated gap. |

**Round 3 reverse questions** (at least five):
1. "What does leadership philosophy look like when it gets tested here?" — Shows you want to see the values in practice.
2. "What did the company change after the last hard reliability or outage call?" — Surfaces real decisions behind the stated values.
3. "Which of the company's values do managers most often miss?" — Candid and useful.
4. "What would make you confident in a manager of managers here?" — Tells you the bar before you are judged against it.
5. "What is the hardest trade-off leadership has made this year?" — Gets you into their altitude.

## Requirement coverage

| Stated requirement | Questions |
|---|---|
| Lead two squads building device-management services | H2, H7, V5 |
| Own delivery for 11 engineers | H8, P4 (delivery shown by reliability only) |
| Own hiring for 11 engineers | H9, V3 |
| Own growth for 11 engineers | V3 (the material shows hiring only, and F3 gap stands) |
| Partner with hardware and product on roadmap | H3, H6, P1, P6, P7 |
| Not a listed requirement: managing managers | V8, P8, H4 |

## Sources

- Provided documents: your role description (company, role, the three rounds) and your background message. No JD text, no CV.
- Research calls sent: three searches, all refused with permission not granted. "Larkfield Systems values"; "Larkfield Systems interview process engineering manager"; "Larkfield Systems strategy news industrial IoT device management".

**Research tier: L1, searches 3 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet (not included) and the VAL questions' story maps. All three searches were refused. |
| 2. Larkfield Systems interview process | unavailable | Loop structure. Your message already establishes it, so no archetype fallback. |
| 3. Larkfield Systems strategy | unavailable | CO bank. V6 is generic. |
| 4. Interviewer name | n/a | No name for the Director of Engineering or the panel. |
| 5. Representative JD | skipped | Your role description supplies the fit snapshot's requirements. |

## Upgrade menu

- JD text → the role rows become sourced JD lines, quoted verbatim, and the questions that cite them move from `[grounded]` role text to full JD text.
- Your CV → F1 to F4 quote CV lines beside your message, and the banks gain CV-sourced rows.
- Research permission (WebSearch) → the values, loop and strategy checks. These would turn V6 from `[generic]` to sourced, and would add a values cheat sheet if Larkfield publishes values.
- The Director's name → a profile for the interviewer read, persona weights from their public footprint, and a reverse question on their own path.
- Panel members' names → per-member persona weights in round 2.
- Any figures you can document for the 60 percent and the 40 interviews → the defend-the-number answers in H8, H9, P4 can be rehearsed with the actual record.
