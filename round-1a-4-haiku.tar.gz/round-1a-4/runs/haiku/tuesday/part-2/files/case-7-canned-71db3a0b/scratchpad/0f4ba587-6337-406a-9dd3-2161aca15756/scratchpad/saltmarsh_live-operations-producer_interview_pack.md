# Saltmarsh Games: Live Operations Producer, interview prep pack

**Role:** Live Operations Producer, Saltmarsh Games
**Round:** The Outage Hour, a single 60-minute session with the hiring manager (per the company's interviewing page): a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Session mode.** The careers page is a loop source that establishes this loop: one session, run by the hiring manager, holding the tabletop and the values conversation. No values round is hidden elsewhere in it.

---

## 2. How to use this pack and the type key

Personas describe how a question arrives. Types describe what it is scoring. Guidance is scaffolding, not a script: rehearse the shape, then say it in your own words.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows Saltmarsh's three published values |
| EXP | Experience deep-dive | Whether your claims survive scrutiny, and what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy | Whether you know Saltmarsh's current direction |
| CASE | Live problem | Structure and reasoning on a problem from the role, asked live |

Answer slots are instructions for the interview, not questions to answer here. Where a slot gives two branches, use the one that is true.

---

## 4. Fit snapshot

Requirements are the JD's own lines, quoted. Evidence is your own sentences, quoted from your message or CV. Nothing in the Evidence column is a summary.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title and a weekly content-drop calendar. Bridge stays at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD asks for two titles and live events, so expect a probe on how you would hold two calendars. If you have planned anything across two titles, say so; if not, say so and describe how you would split the calendar. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Caveat: no artifact is attached yet, so expect a probe on the calendar's contents. |
| F3 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | discovery | Presenting numbers is not the same as building or interrogating them, and the bridge should not stretch it. The label is inferred from this quote, not a claim about your analysis. Answer slot: say where the monthly figures came from and how they were counted, in your own words. If you did not build them, say whose they were. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | none given | none | [grounded] | discovery | Your material does not show a post-event review or a KPI report beyond the retention presentation. Answer slot: if you ran a review after an event or a drop, say what it reported; if you did not, say so plainly and say what you would report first. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Keep "wrote" and "still uses" as they are. Do not add "owns the release process". Caveat: the checklist is an inspectable artifact you can point to, so offer to show a redacted copy if it is shareable. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating any of these four teams. Answer slot: if you coordinated any of them on a drop, say which and how; if none of it was yours, say so plainly and describe how you would set up those handoffs, as a plan. |
| F7 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | discovery | The years are met on the count. Your material does not say whether the puzzle title was live-service. Answer slot: say in your own words what kind of game it was and what live content it ran, if any. Do not assume the answer from the calendar. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: a written artifact that another team uses. Bridge rewords only this quote and adds no practice. |
| F9 | Leading people or a team (role-family prose; not quoted from the JD, but the JD's "own" and "coordinate" carry the scope) | "Never led a team" (your message) | none | [grounded] | capability | This is a gap you stated. Words: "I haven't led a team." Then how you would coordinate four functions without direct authority, said as a plan and never as a past. |
| F10 | Experience with in-app purchases (role-family prose; not in the JD text) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked on a game with in-app purchases." Then what you would check first, as a plan. |

Gap types in use: F1 transferability, F2 none, F3 discovery, F4 discovery, F5 none, F6 discovery, F7 discovery, F8 presentation, F9 capability, F10 capability.

---

## 7. Reading the interviewer

Public footprint only.

- **Career pattern.** One search result describes Tobias Wrenfield as Head of Live Operations at Saltmarsh Games and previously a QA lead at a console studio. This is a search snippet from an unfetched listing. Confirm it before you use it in the room.
- **Published talk.** "Patch Notes Are a Promise" (GDC 2026). Its argument, per the listing: a live team is judged by how often its patch notes describe what actually shipped.

Implications:

1. Expect questions on the gap between what you announce and what shipped (A4, C2).
2. Your release-checklist work is the closest thing you have to his own territory. Describe it precisely, with no inflation.
3. Retention numbers will be probed. Know how yours were counted (D1, D2).
4. The Larkspur restructure is the live context of this role. He will expect you to have read it (A2, A3, R2).

**Mirror opportunity.** A shared professional path, not a shared identity: his QA-lead background (snippet-sourced, see above) sits beside your own sentence, "Wrote the release checklist our QA team still uses." Use it only once the career line is confirmed.

---

## 8. Persona table

Relationship prior for a hiring manager: Case/Strategist and Skeptic dominant. The loop source adds a values conversation, so Values/Behavioral is guaranteed in this session.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The 60-minute tabletop on a live outage (the careers page names it) | Top weight. The format is loop-sourced, so this is the most certain part of the session | Clarify, then objective, then who you bring in, then decisions in order, then what you tell players, then metrics and risks. Think aloud |
| Skeptic | "You've never led a team" against a role that coordinates four functions | High. Stated gaps F9 and F10 are the material it will test | Concede plainly, then describe what you did in your own words, then a plan. Never claim a team or a title you did not hold |
| Values/Behavioral | The values conversation in the same 60 minutes | Mid-high. A loop source documents it, so each published value gets at least one question | One story per value where a quote carries it; a selection scaffold with its honest branch where none does |
| Data-Driven Prober | "Presented the monthly retention numbers" invites "how was it counted" | Mid. Your figures are the only numbers in the material, and they have no quoted figure | Name the weakest assumption before he does. Say plainly when you do not know how a number was counted |
| Pressure | 60 minutes, time-boxed answers, one senior interviewer | Mid. Relationship prior is low, but the session is time-boxed | Pause, restate, hold a position through two follow-ups, concede only what is true |
| Conversational | The opener and the closing "anything else?" | Low. Still scored: treat casual questions about the role as scored | A 90-second arc, and a real answer to the reverse-question slot |

Total in banks: 20 questions (A 5, B 4, C 3, D 3, E 3, F 2). Plus 5 reverse questions.

---

## 9. Question banks

Ordered by weight. Provenance precedes guidance.

### A. Case/Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event is running. Forty minutes in, a reward bug hands double currency to every player who opens the shop. Walk me through the first fifteen minutes." | CASE | [generic] | Clarify what is broken and who is affected. State the objective: stop the bleed first, then fix. Bring in design, engineering, QA and community in that order and say why. Decide stop versus fix. Decide what players see and when. Name the metrics you watch during the incident and the risk of each action. Say it in 90 seconds. This scenario is generic. It is not a fact about Saltmarsh's systems | The careers page names the tabletop as the first half of the Outage Hour. The scenario is a pattern for the format, not a claim about this company |
| A2 | "Two titles, one live calendar: how would you plan a month of events across both?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Clarify the audience and goal of each title. Set a rule for which event gets the slot when two collide. Name one metric per title and say what you would bump first. This question makes no claim about your past | The JD raises the two-title requirement. Larkspur, reported in September 2026, moves both named titles onto one calendar from February 2027, so the question is current |
| A3 | "Larkspur moves both titles to season passes on one calendar from February. What do you protect first?" | CO | [grounded] "moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027" (Saltmarsh news, September 2026, search snippet) | Name the trade-off between events that move revenue and events that protect retention. Pick one metric you would defend and say what you do not yet know about season-pass economics. No claims about your past | Current strategy from a source under six months old. The snippet was not fetched, so check the page before quoting it |
| A4 | "A patch note went out and the bug is still live. Who gets told what, and in what order?" | CASE | [grounded] "a live team is judged by how often its patch notes describe what actually shipped" (Tobias Wrenfield talk listing, search snippet) | Order: stop the bleed, tell players what is true now, correct the note, then review. Say what you would not announce until it is confirmed. No claims about your past | Tied to his published theme. It is a live problem, so it asks about no past |
| A5 | "What would you need to know in week one before you planned anything?" | JD | [generic] | List the inputs: the current calendar, the release checklist, the retention baseline, the team calendars. Say which you would ask for first and why | A standard first-week question for a planning role. Generic |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never led a team. This role coordinates four functions on every update. Why would design, art, engineering and community follow you?" | JD | [grounded] "Never led a team" (your message); [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | **Highest-ROI prep in this pack.** Hold: "I haven't led a team." Concede that specifically. Then describe what you did on the content-drop calendar, in the quote's own words. Answer slot: if you coordinated any of the four teams on a drop, say which and how; if none of that was yours, say so plainly and describe how you would set up the handoffs, as a plan. Hold through two follow-ups. Do not fold on "I can lead". Do not add a team you did not run | F9 is the stated gap. F6 is where the requirement presses. The objection is likely in some form, and a non-defensive rehearsed answer changes the interview |
| B2 | "Tell me about a time you ran a review after an event and what it reported." | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Open prompt. Pick a time an event or drop was reviewed. Say what the review reported, in your own words. Answer slot: if you ran no review, say so plainly and say what you would report first | F4 has no quote. The answer slot is the honest form. Never describe a review or a KPI you did not run |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Concede: "I haven't worked on a game with in-app purchases." Then say, as a plan, what you would check first: the spend and offer data, and who owns monetisation. Do not describe monetisation work you did not do | F10 is the stated gap. The question is open and presupposes nothing about your past |
| B4 | "A single live-ops group replaces per-title teams from February. Where does a producer with one title's calendar fit?" | JD | [grounded] "retires per-title event teams in favour of a single live-ops group" (Saltmarsh news, September 2026, search snippet); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Say what you bring from one calendar, in your own words, and where you would need the group's context. Do not claim a multi-title record | F1 is the transferability row. Larkspur is the live context. Motivation consistency probe |

### C. Values/Behavioral

Each published value gets one question, as the values round requires.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "when the calendar and the players disagree, the players win" (Saltmarsh values page, fetched) | Selection scaffold: pick a time a date or slot was contested by what players needed. Name the stake. Say what you chose and what you gave up. Honest branch: if no such time comes to mind, say so plainly, then give the nearest thing your material does carry: the weekly content-drop calendar you ran for two years (F1) | Players Before Plans. No quoted sentence carries a story for it, so this is a scaffold |
| C2 | "When have you announced something before it was built? What happened?" | VAL | [grounded] "we announce what is built, not what is hoped" (Saltmarsh values page, fetched); [grounded] "Wrote the release checklist our QA team still uses." (your message) | Selection scaffold: pick a time a release note or announcement needed correcting. If none comes to mind, say so plainly. Then describe, in your own words, what the release checklist covers before a release. If it does not cover announcements, say so | Ship the Patch Not the Promise. The checklist is the nearest quote. It does not show it has ever gated an announcement, so that is not claimed |
| C3 | "Tell me about a time you made a release process better for the next release." | VAL | [grounded] "every release leaves the codebase and the checklist better than it found them" (Saltmarsh values page, fetched); [grounded] "Wrote the release checklist our QA team still uses." (your message) | Story-map the quote: you wrote the release checklist, and QA still uses it. Answer slot: if it replaced an earlier checklist, say what it fixed and how you know. If there was no earlier one, say so, and say what you would leave better | Leave the Build Greener. The quote does not say it replaced anything, so the replacement is a slot, not a claim |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented: where they came from and how they were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: say where the figures came from and how they were counted, in your own words. If you did not build them, say whose they were and what was yours in the presentation. Do not invent a method | F3 is discovery. No figure is quoted, so the defend-the-number slot applies |
| D2 | "Which of your retention numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name the weakest assumption you know of before he does. If you do not know how a figure was counted, say so. Do not produce an assumption you did not hold | The probe is on the same row as D1. Give the weakest-assumption move |
| D3 | "A drop moves day-seven retention by a few points. How would you tell whether the drop caused it?" | JD | [generic] | Separate the drop from other changes. Compare cohorts that did and did not get it. Say what you would check first and what would change your mind. No claim about your past | A metric diagnosis from the retention requirement. Generic pattern |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we pick you over someone who has led a team?" | JD | [grounded] "Never led a team" (your message) | Pause. Restate the question. Hold: "I haven't led a team." Concede that specifically. Then the one thing your material carries: you ran a weekly content-drop calendar for two years. Hold through two follow-ups. Do not fold on a claim you have not made | F9 is the most likely challenge. A held position you cannot back is the one the second follow-up breaks |
| E2 | "That release checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Hold: "I wrote it, and QA still uses it." Answer slot: if QA wrote or changed sections, say which. If you wrote all of it, say so. Do not say QA co-owned it unless you know it | F5 is medium confidence. The probe tests attribution |
| E3 | "Larkspur retires per-title event teams. Why would this role still need a producer?" | CO | [grounded] "retires per-title event teams in favour of a single live-ops group" (Saltmarsh news, September 2026, search snippet) | Hold: the calendar is the job, and one calendar is what Larkspur says it is building. Concede that you do not know the group's staffing. Ask about it rather than guess | Pressure on the role's future. Current strategy |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Pre-scripted 90-second arc: the puzzle studio and four years; the weekly calendar for two years; the release checklist; the retention presentation; why this role. Use only those sentences | An opener that is scored. Keep it to your own facts |
| F2 | "What are you playing right now, and what would you change in it?" | JD | [generic] | Name a live game you actually play, and one change you would make to its event calendar. Never name a game you have not played | A casual question about the role's territory. It is scored |

---

## 10. Values cheat sheet

Values are Saltmarsh's own published names, from the values page fetched for this pack.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quoted sentence carries a story. Selection scaffold in C1, with its honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quoted sentence carries a story. Scaffold in C2. The release checklist is the nearest quote, and it does not show it gated an announcement |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F5's quote is the nearest. Replacement is a slot, not a claim. Scaffold in C3 |

---

## 11. Reverse questions

Each has a "why it lands". R1 is tied to the interviewer's own path. Not a peer round, so no reciprocity question.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You went from QA lead to running live operations. What from the QA years does the calendar still depend on?" | Ties to his own career path, which turns the interview into a peer conversation. Snippet-sourced, so confirm the career line first |
| R2 | "How will the single live-ops group split ownership of the shared calendar across the two titles?" | Shows you read Larkspur, and asks the question the restructure leaves open |
| R3 | "What does a good first ninety days look like for whoever runs this calendar?" | Standard, but it asks for the bar, and it tells you what he is buying |
| R4 | "After a post-event review, what changes in the next drop?" | Shows you think a review should change something. Tests whether post-event review is a real practice here |
| R5 | "The values page says players win when the calendar and players disagree. What is the last call you saw go that way?" | Asks for an example of the value in use, which shows you took the values seriously |

---

## 13. Prohibited claims

Built locally from the fit snapshot. Nothing from a dossier was supplied. Each entry names its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns the post-event review or the KPIs it reports | Inflated form of the JD line in F4; no quote supports it | The pack's own observation: your material does not show a post-event review. B2's slot asks only what you ran |
| Coordinated design, art, engineering and community teams | Inflated form of F6; no quote carries it | The pack's observation: your material does not show it. B1's slot asks only what was yours |
| Ran two titles' calendars, or planned across two | Inflated form of F1, which says one title | F1's quote at its own scope. A2's slot asks how you would hold two |
| Led a team or managed people | F9, a negative you stated | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases | F10, a negative you stated | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| The release checklist replaced an earlier one, or that you wrote it alone | Inflated form of F5, which says "wrote" and "still uses" only | F5's quote at its own scope. E2's slot asks what QA did |
| The puzzle title was live-service | F7 is discovery; the material does not say | The pack's observation: your material does not say. F7's slot asks you to answer in your own words |
| The retention figures' method or any figure | No figure is quoted; the method is not in the material | D1 and D2's slots. Nothing is supplied |

---

## 14. Sources

**Research tier:** Research tier: L1 — searches 4 of 6, fetches 2 of 2

**Provided documents:** Your message (background and gaps); the JD as pasted.

**Searches sent, with what came back:**

1. "Saltmarsh Games values": https://saltmarshgames.com/values (Saltmarsh's three values)
2. "Saltmarsh Games interview process Live Operations Producer": https://saltmarshgames.com/careers/interviewing (the Outage Hour)
3. "Saltmarsh Games mobile studio strategy news": https://saltmarshgames.com/news/project-larkspur (September 2026; snippet only, not fetched)
4. "Tobias Wrenfield Saltmarsh Games Head of Live Operations": https://talks.gdconf.example/2026/patch-notes-are-a-promise (talk listing; snippet only, not fetched; the domain is a placeholder-style host, so treat the career line as unconfirmed)

**Fetches sent:**

1. https://saltmarshgames.com/values: returned the three values and their working text
2. https://saltmarshgames.com/careers/interviewing: returned the loop description

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet, section 10: three values by name; C1 to C3 |
| 2. `Saltmarsh Games interview process Live Operations Producer` | yes | Loop structure: a single 60-minute hiring-manager session with a tabletop and a values conversation. Session mode, values round detected, persona weights follow |
| 3. `Saltmarsh Games strategy` / recent news | yes | The Larkspur restructure, September 2026. Moved A2, A3, B4, E3, R2. Snippet only, so check the page before quoting it |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read, the talk theme, and one mirror. The career line rests on one unfetched listing and is unconfirmed |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Retention figures you presented, and how they were counted → D1 and D2 get a defend-the-number answer you can rehearse; F3 moves off low confidence
- A redacted copy of the release checklist, if shareable → F5 gets an inspectable artifact; E2 and C3 sharpen
- A time you coordinated design, art, engineering or community on a drop → F6 moves off discovery; B1 gets its first grounded answer
- Whether the puzzle title was live-service, and what live content it ran → F7 is settled
- A time you ran a review after an event → F4 and B2 become rehearsable from your own words
- The recruiter's note on whether the values conversation is a separate section of the 60 minutes → timing for C1 to C3
- Confirmation of Tobias Wrenfield's career line from his own page or the talk page → R1 and the mirror rest on a source you can cite
- A tuesday-dossier.md, if one exists → its prohibited claims and objections would replace the locally built list in section 13
