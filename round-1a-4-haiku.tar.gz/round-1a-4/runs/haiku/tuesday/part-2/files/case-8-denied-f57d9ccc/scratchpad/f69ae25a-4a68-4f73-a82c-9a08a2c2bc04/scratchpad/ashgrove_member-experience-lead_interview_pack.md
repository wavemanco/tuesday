# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Role:** Member Experience Lead (member-owned credit union, about 900 staff)
**Mode:** Loop mode, three rounds on 3 December 2026
- Round 1: recruiter screen, 30 minutes, the recruiter
- Round 2: behavioural, 45 minutes, Head of Member Services (your future manager)
- Round 3: panel, 60 minutes, two branch managers, including a 20-minute complaint-escalation case; the panel also scores the four values

Interviewer names are not yet assigned, so persona weights use round-type priors only.

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Guidance is scaffolding for a spoken answer, not a script. Each answer should be 90 to 120 seconds.
- Every claim about your past is one of your own sentences, quoted in the Provenance column. If a sentence is not quoted, do not say it.

Type key:
- **VAL**: behavioural and values alignment, scored against the published values
- **EXP**: work-experience deep-dive; whether your claims survive scrutiny
- **JD**: a stated responsibility or requirement
- **CO**: company and strategy knowledge
- **CASE**: a live problem from the role

## 2. Fit snapshot (shared across all rounds)

Requirements are quoted from the job description. Evidence is quoted from your own message, which is the only candidate source in hand; no CV was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Words: "For six years I worked in retail banking, the last three as a branch supervisor." The years line is met; "customer operations" is the JD's phrase, so use your own words for the work. Length of experience is not a gate. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | presentation | Words: "I handled the branch's formal complaints log." Your material says formal, not regulated. The word regulated is not yours to add. |
| F3 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Words: "I've never presented to anyone above regional level." Then how you would prepare, as a plan and never as a past. |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | none | Words: "I built the monthly complaints spreadsheet our regional manager uses." Say spreadsheet, and say Excel only if it was Excel. |
| F5 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Words: "For one branch, I handled the formal complaints log." End-to-end scope across branches is not in your material. Answer slot: if you ran any step beyond the log, such as intake, decision or closure, say which and how you decided, in your own words. If you did not, say so plainly and say how you would run it across branches. |
| F6 | "Own the member complaints process end to end across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | Words: "I haven't worked in a contact centre." Then what you would do first, as a plan. |
| F7 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Volumes are reached by the quote. Resolution times are not in your material. Answer slot: if the spreadsheet tracked how long complaints took to resolve, say what and how you counted; if it did not, say so and say what you would track first. |
| F8 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Words: "I trained new tellers on our escalation script." Tellers, not supervisors. Answer slot: if you coached other supervisors on escalations, say how; if not, say so and say how you would coach one. |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Answer slot: if you worked with anyone on a digital or self-service change, say what and what part was yours; if not, say so. |

Notes on the gate check: none of the JD's requirements is a gate in the sense of a licence, a location term or a legal bar, so no gate rows are raised. The "4+ years" line is a length of experience and is graded like the others.

## 3. Grounding brief: the strategy

Source: your message, which summarises the July 2026 brief. I have the points, not the brief's text. Check the wording against the PDF before you quote any of it in the room. The live check failed (see Sources), so these points are unverified.

- "move 40% of member service to digital channels by 2028"
- "consolidate eight branches into five hubs over 2027"
- "launch a small-business lending product in Q1 2027"
- "the main competitive pressure is app-only banks"

Stale framings: none can be checked without the brief. Do not correct the interviewer on wording; use the brief's terms if the interviewer uses them.

## 4. Prohibited claims

These will not be coached in any answer, slot, hold or drill.

| Not coached | Basis | Honest form |
|---|---|---|
| Handled regulated complaints | Inflated form of F2; the word regulated is not in your material | F2's quote at its own scope: "I handled the branch's formal complaints log." Pack observation, not words for you: your material says formal. |
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F5 and F6 | F5's quote at its own scope. Plain acknowledgment from F6: "I haven't worked in a contact centre." |
| Confident presenting to senior leaders | Negative you stated, F3 | Plain acknowledgment: "I've never presented to anyone above regional level." No slot asks you to claim it. |
| Trained or coached branch supervisors on escalations | Inflated form of F8; your sentence says tellers | F8's quote at its own scope: "I trained new tellers on our escalation script." |
| Tracked resolution times | Inflated form of F7; your sentence says the spreadsheet, not what it counted | F7's quote. The slot asks only what was counted. |
| Used Excel for complaints reporting | Inflated form of F4; your sentence says spreadsheet | F4's quote: "I built the monthly complaints spreadsheet our regional manager uses." |

## 5. Round 1: recruiter screen (30 minutes)

**Persona weights:** The recruiter screen runs on priors. Conversational is dominant (3 questions plus 4 logistics rows, since logistics sit with the recruiter's own check). Light Skeptic gets 2. One Values question is light.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly opener, then logistics | High. The recruiter screen is where pay, notice, location and reason for leaving are checked. These are scored even when casual. | Say the 90-second arc. Answer logistics in your own words, once. |
| Skeptic (light) | "You've never worked in a contact centre" | High for this JD, since F6 is the biggest gap | Plain acknowledgment, then the adjacent evidence you actually have, then a ramp plan. |
| Values (light) | "What makes a complaint handled well?" | Medium | Use Own the Fix, with the honest branch if no story comes to mind. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message; "I handled the branch's formal complaints log" — your message | A 90-second arc using only those sentences: six years in retail banking, the last three as a branch supervisor, then the formal complaints log. Use your own words for each beat. | F1 and F2 are where the opener starts; this is the arc you will repeat in every round. |
| A2 | "What are you actually doing with reporting these days?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Say what the spreadsheet is and who uses it. Answer slot: if it tracked how long complaints took to resolve, say what and how you counted; if it did not, say so and say what you would track first. | F4 and F7: the JD's reporting line, asked as an open question. |
| A3 | "What drew you to a member-owned credit union?" | VAL | [grounded] "member-owned" — JD | Give one honest reason, tied to what you have seen across the counter. Do not claim knowledge of Ashgrove's model that you lack. | Motivation check; the phrase comes from the JD. |
| L1 | "What are your pay expectations?" | JD | [generic] | Logistics slot. Give your own figure, or ask what the band is first. Your material gives no figure, so there is nothing to quote. | Recruiter-screen logistics. An instruction, not a question for this conversation. |
| L2 | "What is your notice period?" | JD | [generic] | Logistics slot. Give the notice you actually owe. Your material gives none, so state it yourself. | Recruiter-screen logistics. |
| L3 | "Where are you based, and which days can you work in an office?" | JD | [generic] | Logistics slot. Give the place and the days as they actually are. | The branch and hub pattern is part of the strategy; do not guess how it touches you. |
| L4 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot. Give your real reason in one sentence, then what you want next. Your material gives no reason, so the reason is yours to state. | The reason for leaving is a recruiter-screen check. |
| B1 | "You've never worked in a contact centre. What makes you the one to own complaints across it?" | JD | [grounded] "Never worked in a contact centre" — your message; "I handled the branch's formal complaints log" — your message | Plain acknowledgment: "I haven't worked in a contact centre." Then the adjacent evidence you actually have: the formal complaints log. Then what you would do first, as a plan. Hold through two follow-ups by returning to the log and the plan. Concede specifically if pressed: say what you do not know about contact-centre volumes. | Highest-ROI prep in this pack. This is the objection most likely to be asked, because it is the biggest gap against a JD that names the contact centre. |
| B2 | "You've never presented above regional level. How will you present to the senior team?" | JD | [grounded] "I've never presented to anyone above regional level" — your message | Plain acknowledgment: "I've never presented to anyone above regional level." Then how you would prepare, as a plan. Do not claim a presentation you have not made. | F3, the JD's "confident presenting to senior leaders". |
| C1 | "What makes a member complaint get handled well, in your view?" | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved" — values page (your copy); "trained new tellers on our escalation script" — your message | Answer from experience. Answer slot: if no story comes to mind, say so plainly, then give the nearest thing you have: the escalation script you taught. | Values-light question for a screen; the script is your nearest sentence. |

**Reverse questions (round 1)**

1. "What does the next step look like after this call?" Why it lands: it signals you are planning the rest of the process.
2. "Which part of this role are you hiring for most urgently?" Why it lands: it asks the recruiter to rank the JD, which you can then answer in round 2.
3. "How is the panel put together?" Why it lands: it shows you know the panel is also the values round.
4. "What have members been saying about the app?" Why it lands: it ties to the strategy's point that app-only banks are the main pressure.
5. "What does Ashgrove most need to hear from a candidate for this role?" Why it lands: it gets the recruiter's view in their own words.

## 6. Round 2: Head of Member Services (45 minutes, behavioural, future manager)

**Persona weights:** Values/Behavioral is dominant, since the round is "mostly behavioural". Skeptic is a close second, because this is the person you would be working for and will test the gaps. Case/Strategist is lighter.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | STAR-shaped prompts on escalation and members | High. "Mostly behavioural" is the recruiter's word. | Use the selection scaffold for each prompt, with the honest branch where no story exists. |
| Skeptic | "Why would this role suit you?" and "Which part would you be weakest at?" | High. The manager is buying capability and checking the gaps. | Deepest rehearsal on E1, with three follow-ups. |
| Case/Strategist | Strategy-altitude questions on digital and hubs | Medium. Strategy fluency matters for a manager. | Clarify, structure, then answer. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you had to escalate a complaint you thought was being handled badly." | VAL | [grounded] "I handled the branch's formal complaints log" — your message; "trained new tellers on our escalation script" — your message | Selection scaffold: pick a time a complaint needed escalating. Use the log and the script as the beats they are. Any escalation itself must be one you actually made. If no such time comes to mind, say so plainly, then give the nearest thing you have: the escalation script you taught. | The JD's escalation line, asked as a behavioural prompt. |
| D2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you delivered news a manager did not want. None of your sentences carries this. If none comes to mind, say so plainly. Do not invent a leadership moment. | Persona stem; no quote in your material carries this story. |
| D3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a branch figure or target had to give way for a member. If none comes to mind, say so plainly, then give the nearest thing: the complaints log you handled. | Persona stem for Members First; honest branch required. |
| D4 | "How would you coach a branch supervisor who is escalating everything to you?" | JD | [grounded] "trained new tellers on our escalation script" — your message | Answer slot: if you coached other supervisors on escalations, say how; if not, say so and say how you would coach one. Your sentence covers tellers only. | F8, the JD's coaching line. |
| E1 | "You haven't worked in a contact centre. Why would this role suit you across it?" | JD | [grounded] "Never worked in a contact centre" — your message | Plain acknowledgment: "I haven't worked in a contact centre." Then the adjacent evidence you have: the formal complaints log and the escalation script you taught. Then a ramp plan, as a plan. Hold through two follow-ups; concede specifically on what you do not know. This is the deepest rehearsal in the pack: practise it to three follow-ups. | Highest-ROI objection, asked again by the person you would report to. |
| E2 | "Why would you leave a branch supervisor role for this one?" | EXP | [generic] | Give your real reason in one sentence, then what you want next. Do not claim a reason your material does not give. | Skeptic on motivation; the answer must match the recruiter screen. |
| E3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level" — your message; "Never worked in a contact centre" — your message | Name the gap in your own words. The two your material shows are presenting above regional level and the contact centre. Say which you would ramp on first and how, as a plan. | Stem from the Skeptic persona, using only the two negatives you stated. |
| G1 | "The digital plan moves 40% of member service to digital channels by 2028. What would you protect in the complaints process while that happens?" | CO | [grounded] "move 40% of member service to digital channels by 2028" — your message (summary of the brief) | Clarify what protect means. Structure: complaint volumes by channel, members who cannot use digital, the escalation route, and one risk. Answer slot for F9: if you worked with digital teams on a self-service change, say what and what part was yours; if not, say so. | CO bank from the strategy; F9 is the JD line with no quote. |
| G2 | "Two branches are merging into one hub, and complaints rise for six months. What do you do first?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" — your message (summary of the brief) | Clarify, then objective, then segmentation, then approach, then metrics, then risks. Ask which complaint types rose before you propose anything. Make no claim about your own past. | Live problem from the strategy; asks about no past. |

**Reverse questions (round 2)**

1. "What does a good first 90 days look like for this role?" Why it lands: it tells you the manager is planning with you.
2. "Which complaint decisions would you most like this role to change?" Why it lands: it shows you want to fix the process, not just run it.
3. "How do branch supervisors hear about escalation outcomes today?" Why it lands: it shows you already think about the supervisor layer.
4. "How does the complaints process fit the hub plan?" Why it lands: it links your round to the strategy.
5. "What would make you say this hire worked, a year on?" Why it lands: it gets the success measures in their own words.

## 7. Round 3: panel of two branch managers (60 minutes, values round, with a 20-minute case)

**Persona weights:** Values/Behavioral is dominant, because the panel scores the four values. Peer Evaluator is next, since branch managers will judge seams and disagreement. Case/Strategist covers the 20-minute escalation case. Each member is read as a blend of these, since the panel's members are not named.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scored against Members First, Plain Words, Neighbours, Not Numbers and Own the Fix | Guaranteed. The recruiter says the panel is the values round. | Use the values cheat sheet below: one story per value, or the honest branch. |
| Peer Evaluator | "Where's the seam, and what happens when we disagree?" | High. The panel are branch managers, the people whose supervisors you would coach. | Seam principles, not pretended knowledge; a disagreement story with spine and tact. |
| Case/Strategist | The 20-minute escalation case | High. The recruiter named it. | Clarify, structure, then answer, and say the structure aloud. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you put a member's side of the counter ahead of the process." | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Members First. Selection scaffold: pick a time you decided from the member's side. If none comes to mind, say so plainly, then give the nearest thing: the log you handled. | Values round; the scoring is against Members First. |
| H2 | "Tell me about a time you had to explain something to a member twice." | VAL | [grounded] "trained new tellers on our escalation script" — your message | Plain Words. Selection scaffold: pick a time an explanation had to be rewritten. If none comes to mind, say so plainly, then give the nearest thing: the script you taught tellers to use. | Plain Words is scored by whether the explanation worked. |
| H3 | "Tell me about a time a number hid something about a branch's community." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Neighbours, Not Numbers. Selection scaffold: pick a time a figure missed a local story. If none comes to mind, say so plainly, then say what the spreadsheet does not show. | The spreadsheet is your nearest sentence, and the honest answer is what it does not show. |
| H4 | "Tell me about a complaint you kept hold of until it was closed." | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Own the Fix. Selection scaffold: pick a complaint you kept until it was solved. Do not claim a fix you did not see through. If none comes to mind, say so plainly. | The values round's hardest one; the honest branch is stronger than a claimed fix. |
| P1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [grounded] "across branches and the contact centre" — JD | Give seam principles, not a pretended knowledge of their seam. For disagreement, use a scaffold: pick a time you disagreed with a peer and both of you kept working. If none comes to mind, say so. | Peer stem; F5 and F6 scope is the seam. |
| P2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a shared piece of work and say who did what, in your own words. If none comes to mind, say so plainly. | Peer Evaluator stem; no quote carries a shared-work story. |
| P3 | "Walk me through how you would ask a branch supervisor to change how they escalate." | JD | [grounded] "coach branch supervisors on escalations" — JD | Answer slot: if you have asked a supervisor to change how they escalate, say how; if not, say so and walk through how you would do it. | F8 again, asked by peers who supervise supervisors. |
| K1 | 20-minute case: "A member's complaint about a charge has been escalated twice. Their branch supervisor says the charge was correct. The member says they will leave. What do you do, and what do you need to know first?" | CASE | [generic] | Clarify what the charge was and what the member needs. Objective: keep the member and close the complaint. Segment by reason. Approach. Metrics. Risks. Say the structure aloud. Make no claim about your past. | Live escalation case, as the recruiter described. Scenario is generic. |
| K2 | "Escalations doubled in one quarter. Diagnose it." | CASE | [generic] | Clarify what counts as an escalation. Ask for the breakdown by branch and reason before any hypothesis. Name one risk. | Case/Strategist follow-up; the diagnosis is the structure, not a number. |

**Reverse questions (round 3)**

1. "What would a good escalation look like to you, on a bad day?" Why it lands: it invites the panel to show how they think about escalation.
2. "Where do branch supervisors most need help today?" Why it lands: it shows you want to coach, not inspect.
3. "What do the best branch managers here do that the others do not?" Why it lands: it asks the panel for their own standard.
4. "What could a new person do in their first month that would genuinely help your branch teams?" Why it lands: the reciprocity question for a peer panel; it shows you are asking what you can give.
5. "Which of the four values is hardest to live by in a branch day?" Why it lands: it gets the panel's honest view on the values.

## 8. Values cheat sheet (round 3)

The panel is the values round, so the values are scored here. No value has a story in your material that carries the full decision, so every row is a selection scaffold ending in the honest branch. Upgrade menu line: two stories from your branch with what you saw happen.

| Value (official name) | Working meaning | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | Scaffold, honest branch. Pick a time you decided from the member's side. If none comes to mind, say so plainly, then give the nearest thing you have: "I handled the branch's formal complaints log." (H1) |
| Plain Words | If a member needs it explained twice, the wording was wrong. | Scaffold, honest branch. Pick a time an explanation was rewritten. If none comes to mind, the nearest thing is "trained new tellers on our escalation script." (H2) |
| Neighbours, Not Numbers | Every branch is part of its town. | Scaffold, honest branch. Pick a time a number hid a local story. The nearest thing is "I built the monthly complaints spreadsheet our regional manager uses"; say what it does not show. (H3) |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Scaffold, honest branch. Pick a complaint you kept until it was solved. Do not claim a fix you did not see through. (H4) |

## 9. Requirement coverage

| JD line | Questions covering it |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| experience handling regulated complaints | A1, D1 (regulated is not claimed; formal is the word) |
| confident presenting to senior leaders | B2, E3 (gap, stated) |
| comfortable with Excel reporting | A2 |
| Own the member complaints process end to end across branches and the contact centre | B1, E1, P1 |
| report monthly on complaint volumes and resolution times | A2, G1 (resolution times is an answer slot) |
| coach branch supervisors on escalations | D4, P3 |
| work with digital teams on self-service journeys | G1 (answer slot, no quote) |

## 10. Sources

- **Provided documents:** the job description text; the values page as copied on 24 November 2026; the recruiter's email on the three rounds; your message on your background; your summary of the July 2026 strategy brief (not its text).
- **Research tier:** Research tier: L1 — searches 1 of 6, fetches 0 of 2.
- **Calls sent:** one search, "Ashgrove Credit Union 2026 strategy digital channels branch hubs small business lending". Refused: the search permission was not granted, so no results came back.

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text is in hand, copied from the company's own page this morning. The values cheat sheet (section 8) rests on it. |
| 2. Interview process | skipped | The recruiter's email fixes the three rounds and the panel's values role. Loop structure rests on it. |
| 3. Strategy and recent news | unavailable | Would have checked the four strategy points in section 3 against the brief and recent news, and moved the CO bank (G1, G2). The one search was refused. |
| 4. Interviewer name | n/a | No names have been assigned, so there was no query to form. The interviewer read is absent. |
| 5. Representative JD | skipped | The job description is supplied, and it fixes the fit snapshot and the JD-tagged questions. |

## 11. Upgrade menu

- The names of the Head of Member Services and the two branch managers → persona weights from public footprint, and a reverse question tied to their own career path.
- A CV or a reference for the six years in retail banking → F1 moves from medium to high.
- An anonymised sample of the monthly complaints spreadsheet, with no member data → F4 and F7 can be shown rather than described, and the column headings answer what it counted.
- A summary of the formal complaints log, with no member names → F2 and F5 gain an artifact to point to.
- Two stories from your branch, with what you saw happen → the four values rows in section 8 move from scaffold to mapped.
- The wording of the strategy brief, checked against the PDF → G1 and G2 quote the brief, not your summary.
- Search permission, if you want the strategy check run → target 3 can be verified.
- Deep research (L2), offered once: checks the brief's wording and public loop reports. Cost: up to six further searches and two page fetches.
