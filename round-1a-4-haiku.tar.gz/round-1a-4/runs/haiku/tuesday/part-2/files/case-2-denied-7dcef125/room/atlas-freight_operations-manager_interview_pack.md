# Atlas Freight: Operations Manager interview prep pack

Company: Atlas Freight (regional logistics, 800 employees). Role: Operations Manager. Interviewer: not given. Round: not given, so this pack is built for a hiring-manager round. Research: not run (L0, only what you gave me).

## How to use

- **Personas** describe how a question arrives. **Types** describe what is scored: VAL (values), EXP (your experience, attribution), JD (the listed requirements), CO (company knowledge), CASE (live problem).
- Guidance is scaffolding for a spoken answer, not a script. Rehearse only what you actually did, in your own words.
- **Answer slot** means your material does not show that part. The pack gives you the honest branch for both cases: if it was yours, say how; if it wasn't, or didn't happen, say so plainly.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own daily terminal operations across 4 sites" (JD) | "currently a senior shift manager over 3 supervisors" (your message); "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material describes one site and a shift over three supervisors. It doesn't show four sites or daily terminal operations. Answer slot: if you ran anything across more than one site, say what and how; if not, say so, and say how you would spend the first 90 days. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors, an adjacent step toward twelve, not the number itself. Say how you lead the three day to day. For the twelve, answer slot: if you have led more than three people through supervisors or managers, say whose and how; if not, say so and say how you would structure the first month. |
| F3 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | medium | [grounded] | discovery | Length of experience is not a gate, so this is a fit question. Your material shows seven years of operations work and does not say how long you have led people. Answer slot: state the years you have held a people-leading role, in your own words; if fewer than five, say so plainly. |
| F4 | "drive on-time performance" (JD) | none given | none | [grounded] | discovery | Your material does not show on-time performance tracked or moved. Answer slot: if you have tracked or changed it, say the figure and how it was counted; if not, say so, and name the data you would pull first. |
| F5 | "cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows a process change that cut mis-picks, not a cost line. Answer slot: if the redesign changed labour or cost and you measured it, say how; if you did not, say so and say what you would measure first. |
| F6 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | low | [grounded] | discovery | Excel is solid by your word, but the quote is about the tool, not reporting built in it. Answer slot: if you have built reporting others used in Excel, say what it was and who used it; if not, say what you have built with it. |
| F7 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never used Power BI." Then how you would learn it, said as a plan, never as a past. No claim to Power BI work. |
| F8 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | Quote reaches the requirement. Say it as you hold it: Green Belt certified. Expect a probe on what you applied it to (B4), since the certificate alone has nothing inspected behind it. |

## Persona table

Weights are a shown judgment. Relationship prior: hiring manager, which tilts toward Case and Skeptic. Your material's gaps are the most visible mismatches against the JD, so the Skeptic and Prober carry the depth.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Case/Strategist | Live problems on four sites and on-time performance | High: hiring managers test structure on the actual roadmap | Clarify the metric, segment, name two hypotheses, say what would change your mind | 4 (A1 to A4) |
| Skeptic | The twelve-supervisor span, the leadership years, Power BI | High: these are the three largest gaps against the JD | Hold what you have, concede the gap specifically, bridge only from quotes | 4 (B1 to B4) |
| Data-Driven Prober | The 40% figure, the surge plan's result, reporting | High: headline numbers attract probes | Say how it was counted, name the weakest assumption before they do | 4 (C1 to C4) |
| Pressure | "How much of that was actually you?" | Medium: composure is scored on headline claims | Hold through two follow-ups, concede the smaller share | 3 (D1 to D3) |
| Conversational | Opener, and a casual question on reporting | Low to medium: the first five minutes are scored too | Pre-scripted 90-second arc; treat casual questions on the JD as scored | 2 (E1, E2) |
| Peer Evaluator | Seams with planning and other sites | Low: a hiring manager tests collaboration less directly | Propose seam principles, don't claim a seam you have not worked | 2 (G1, G2) |

## Question banks

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've got four sites and one daily terminal rhythm. Where do you start in the first week, and what do you need to know first?" | CASE | [generic] | Structure: clarify what on-time performance and cost per shipment are measured against; list the data needed per site; choose which site to see first and why; name the first two decisions, not the fix. No claim about your past | Live problem from the role's first line. A pattern for the problem, not a fact about the company |
| A2 | "On-time performance dropped six points at one of your sites last month. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify the on-time definition (cut-off, where it is measured) before any cause. Segment by shift, lane, carrier and volume. Name two hypotheses to test first and what would change your mind. No claim about your past | The on-time requirement tested as a diagnosis; no answer needs past data, and F4 has none |
| A3 | "Cost per shipment rose eight percent after peak. What would you look at, in what order?" | CASE | [generic] | Denominator first: how volume was counted, peak against base. Then labour, overtime, rework. Then the one lever you would test on a single site before rolling it out. Plan language only | The cost-per-shipment requirement; asks for an ordered approach, which the role needs |
| A4 | "Walk me through the pick-path redesign: what you changed, and what you'd check before taking it to a second site." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Story-mapped on the quote: the redesign and the 40% are the beats it states; tell them in your own words. Answer slot: if you made the design choices, say which and why; if someone else set the design, say what you did. The second-site check is a plan, said as one | F5's bridge; the natural link to cost and to the second-site question. EXP because who designed the change is yours to state |

### Skeptic (highest-ROI prep: B1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You lead three supervisors today, and this role has twelve across four sites. What in your experience gets you there?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); [grounded] "lead a team of 12 supervisors" (JD) | Hold, then concede, in that order: "I lead three supervisors now; that's the number." Then how you lead the three, day to day, in your words. For the twelve, answer slot: if you have led more than three people through supervisors or managers, say whose and how; if not, say so plainly and say how you would structure the first month. Hold through two follow-ups. Never say "I can do it" without a case | F2 is the largest gap and the most likely objection. Deepest rehearsal in the pack |
| B2 | "The role needs five years of operations leadership. How many years have you been leading people, as opposed to working in operations?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Answer with the years you have led people, from your own record. The pack gives no figure. Answer slot: if fewer than five, say so plainly and say what you bring for the years you have; if five or more, name the roles that count. Do not count years of operations work as leadership | F3. The premise is the JD's and the guidance does not adopt it. Length of experience is a fit question, not a gate |
| B3 | "Your Excel is solid, but this role builds reporting in Power BI. How soon would you be productive on it?" | JD | [grounded] "solid Excel" (your message); [grounded] "never used Power BI" (your message) | Hold the gap in your words: "I've never used Power BI." Then the plan: what you would learn first and by when, said as a plan. Answer slot on Excel: if you built reporting others used in Excel, say what and who; if not, say so. Do not stretch Excel into Power BI | F6 and F7. A capability gap you stated, so the acknowledgment has its source in your own words |
| B4 | "Lean and Six Sigma is a plus here. What did your Green Belt change in how you run a shift?" | JD | [grounded] "green belt certified" (your message) | Answer slot: name the project or tool you applied, if you did. If nothing changed, or the certification is all there is, say so plainly. Do not name a project the material does not carry | F8, medium confidence. The probe is whether the certificate was applied |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was that 40% mis-pick reduction counted? Give me the baseline, the period and the definition of a mis-pick." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Defend-the-number, in your own words. The pack supplies no baseline, period or definition. Answer slot: if you measured it, name the count, period and source; if a system or a team produced it, say so and what you checked. Name the assumption you would defend least before they ask | Headline metric on your material. This probe is near-certain |
| C2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the assumption in your own words, before they find it. If you don't know the assumptions, say so and name what you would check. The pack names no assumption: none is in your quote | Follow-up on C1's figure. Turns a gotcha into a credibility gain |
| C3 | "The role reports on on-time performance and cost per shipment. Which number would you show the VP first, and where does it come from today?" | JD | [grounded] "build reporting in Excel/Power BI" (JD); [grounded] "solid Excel" (your message) | Name a number you have tracked and its source, in Excel terms. Answer slot: if you have tracked on-time performance or cost per shipment, say the figure, the source and how it was counted; if not, say so and name the data you would pull first. Do not name a system you have not used | F4 and F6. A probe on a figure you don't own is the risk |
| C4 | "Your surge plan ran two years running. What did you measure to know it worked?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Story-mapped on the quote: the plan and the two years. Answer slot: if you measured the plan's result, name the measure, how you counted it and what changed; if not, say so and what you would measure now. "Ran" is not "set": if you wrote the plan, say which parts; if others set it, say so | The quote carries no measure, so the pack cannot supply one. Attribution probe |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who's run four sites?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Hold the position you can back: seven years and the surge plan, in your words. Concede specifically on the scope: "four sites is the part I haven't done." Hold through two follow-ups; don't fold on the rest | Composure test on the span gap |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold what the quote carries: the result and the redesign. Answer slot: if you led the redesign, say which decisions; if it was a team's or the site's, say what you contributed. If your share was smaller than the headline, say so rather than defend a larger one | Attribution pressure on the headline metric |
| D3 | "Four sites is a different job from one. What's the first thing that breaks?" | CASE | [generic] | Name the likely first failure (handoffs between sites, supervisor consistency, data definitions) as analysis, not as a past. Concede the risk and say how you would find it first | Pressure on scope. Asks for judgment and presupposes nothing about you |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through your background, in two minutes." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); [grounded] "currently a senior shift manager over 3 supervisors" (your message); [grounded] "ran the site's peak-season surge plan two years running" (your message) | A pre-scripted 90-second arc: seven years, the shift role over three supervisors, the surge plan, the pick path result. Use the quoted sentences and add nothing | The opener is scored. A clean arc is the answer to "what did you do" |
| E2 | "What are you playing with in reporting at the moment?" | JD | [grounded] "never used Power BI" (your message) | Say the gap in your words: "I've never used Power BI." Then what you use now and your plan. Don't treat it as small talk | Casual register, scored. F7 |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our sites and network planning argue over the same shipments. Where's the seam, and what happens when you disagree?" | JD | [generic] | Propose seam principles, not a seam you have not worked: what should be written down between sites and planning, and how you would settle a disagreement with an equal. No past disagreement claimed | Peer collegiality probe |
| G2 | "Tell me about a time credit went to someone else for work you drove." | EXP | [generic] | Open prompt. If you have such a time, tell what you did and who did what. If none comes to mind, say so plainly, then give the nearest thing your material carries, the surge plan's two years, or how you would handle it | Peer credit probe. No past claim supplied |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| own daily terminal operations across 4 sites | A1, B1, D3 |
| drive on-time performance down | A2, C3 |
| cost-per-shipment down | A3, A4, C3 |
| lead a team of 12 supervisors | B1 |
| 5+ years operations leadership | B2 |
| build reporting in Excel/Power BI | B3, C3, E2 |
| Lean/Six Sigma a plus | B4 |

## Reverse questions

1. What does success look like for this role at six months, and how is it different at three? Why it lands: tests the first-year target before you commit to one.
2. How is on-time performance defined across the four sites: the cut-off, and where it is measured? Why it lands: shows you check the number before you chase it.
3. What is the current cost-per-shipment baseline, and what has already been tried? Why it lands: the analyst's reflex, and it gets you the data picture.
4. How are the twelve supervisors split across the four sites today? Why it lands: turns the span gap into a design question you can answer.
5. Which Power BI reporting already exists, and who owns it? Why it lands: raises the tool gap on your terms before they do.
6. What would you need from me in the first 90 days to count it a good start? Why it lands: signals ownership of the outcome.

## Prohibited claims

Not coached in any answer, slot, hold or bridge in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran four-site operations | Inflated form of F1 | "ran the site's peak-season surge plan two years running," at its own scope. The material shows one site |
| Has led twelve supervisors | Inflated form of F2 | "currently a senior shift manager over 3 supervisors." Twelve is an answer slot, never a claim |
| Five years of operations leadership | Inflated form of F3 | "7 years in warehouse and distribution ops." Leadership years are an answer slot |
| Built reporting in Power BI | Negative you stated (F7) | "I've never used Power BI." No slot |
| Designed the pick-path redesign, or set the surge plan | Inflated form of the quotes | "by redesigning the pick path" and "ran," at their own scope. Who designed what is an answer slot |
| Cut cost per shipment | Inflated form of F5 | The mis-pick quote at its own scope |

## Sources

- Provided documents: your message, containing the JD as you summarised it and your background. The JD you gave is a summary; the full text would upgrade the JD rows.
- Searches and fetches: none. The pack runs at L0.

Research tier: L0, no searches, no fetches. Research is offered in the reply.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet, which is not included: no values round is detected. Research not run at L0 |
| 2. Atlas Freight interview process, operations | unavailable | Loop structure; persona weights would follow the named rounds. Research not run at L0 |
| 3. Atlas Freight strategy and recent news | unavailable | Grounding brief and CO questions. Research not run at L0 |
| 4. Interviewer name and company | n/a | No name given, so there is no query to form |
| 5. Representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full JD text → the six requirement lines become verbatim quotes, and the rest of the JD gets fit rows
- The round type and who you are meeting → persona weights recomputed from the actual round; a hiring-manager round is assumed now
- Research at L1 (up to six searches, two page fetches) → company values, interview structure and recent strategy, and CO questions grounded in them
- Your leadership years and the largest team you have led directly → resolves the answer slots in B1 and B2
- The baseline, period and count behind the 40% → turns the answer slots in C1 and C2 into answers you can say
- The interviewer's name → a tailored reverse question and persona weights from their public footprint
