# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager (JD as you pasted it)
**Company:** Atlas Freight (regional logistics, 800 employees)
**Interviewer:** not given
**Round type and relationship:** not given. Built as a full-loop pack with flat persona weights, which is weaker than a pack built on a known round. Company research was refused on this host, so nothing about Atlas Freight's values, interview rounds or strategy is established here.

---

## How to use this pack

- **Personas** describe how a question will be asked. **Types** describe what is being scored.
- Type tags: **EXP** work-experience deep-dive. **JD** role and JD-driven. **CASE** live problem. **CO** company and strategy: none written, because research did not run. **VAL** behavioral and values: none written, because no values round is documented.
- Guidance is scaffolding, not a script. Say it in your own words. An **answer slot** is an instruction for the interview: answer whichever branch is true for you. "I did not do this" is always a valid answer.

---

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message. Only your sentences appear in the evidence column.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "currently a senior shift manager over 3 supervisors" (your message); "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material refers to one site and shows a shift-manager role over 3 supervisors. It does not show daily operations across more than one site. Bridge: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have run work across more than one site, say what it was and your part in it; if not, say so and stay with the site you ran. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material has an accuracy result, a mis-pick rate. It has no on-time or cost-per-shipment figure. Bridge: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time performance or cost per shipment, say what it was and your part; if not, say so plainly and name the measure you would start with. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows 3 supervisors. The requirement is 12. Bridge: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have led a larger group of supervisors, say how many and when; if not, say so plainly and say how you would build a team of twelve. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | medium | [grounded] | discovery | Your material gives seven years of operations work. It does not say how many of those years were in a leading role. Length of experience is not a gate, so this row is graded on fit. Answer slot: if you have led people for five years or more, say when that began and what you led; if less, say so plainly and give the year your first leading role began. |
| F5 | "build reporting in Excel/Power BI" (JD), Excel half | "solid Excel" (your message) | medium | [grounded] | none | Your material reaches the Excel half in role terms. It is a self-rating with nothing inspected behind it, so expect a probe asking for a report you built. Your words are "solid Excel"; a named report says more than the adjective. |
| F6 | "build reporting in Excel/Power BI" (JD), Power BI half | "never used Power BI" (your message) | none | [grounded] | capability | This is a gap you stated. Words for the interview: "I've never used Power BI." Then how you would learn it, said as a plan with the first report you would build, never as a past. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote reaches the requirement. A certification with no inspected proof is medium; a copy of the certificate, with issuer and date, would make it high. |
| F8 | "Own daily terminal operations across 4 sites", read as on-site presence at all four sites | none given | none | [inferred] | hard_gate | Your material does not establish whether you can work on-site at all four sites day to day. Location is a gate term. The one question for it is in the message that presents this pack. |

**Confidence** grades your evidence. **Provenance** grades what this pack wrote. F8's provenance is inferred because the JD says "across 4 sites" and does not say on-site; that reading is this pack's.

---

## Persona table

No round type, relationship or interviewer is known, so no relationship prior tilts the weights. The generic fallback archetype is flat, and this pack says so. Each persona gets three questions, for 21 in total.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | Reads the CV line by line; asks for denominators and assumptions | High for the one measured figure you gave. The 40% in F2 is the number most likely to be checked | Know how the 40% was counted, or say plainly that you do not know. Name the weakest assumption before they do |
| B. Pressure / Stress | Interrupts, time-boxes answers, questions motive | Medium. The Power BI gap (F6) and the scope gap (F1, F3) are the natural places to press | Pause, restate the question, hold a position through two follow-ups, concede specifically |
| C. Values / Behavioral | Open "tell me about a time" prompts | Medium. No values round is documented, but open behavioral prompts can come in any panel | Pick one real instance, say what you did, and say plainly when there is no instance |
| D. Case / Strategist | Live problems in the JD's own terms | Medium. The four sites and cost per shipment are the obvious live problems | Clarify, then segment (by site), then approach, measures, and risks. Think aloud |
| E. Skeptic | Quiet, persistent probing of scope and tool gaps | High. The scope gap, F1 and F3, is the most predictable objection to this profile. E1 is the highest-return rehearsal in the pack | Rehearse the objection until it is routine. Concede in the terms your own sentences carry, then give your ramp plan as a plan |
| F. Conversational / Rapport | Friendly walk-through opener; casual questions still scored | Medium. A "walk me through it" opener is the usual start | A 90-second arc built only from sentences you actually gave |
| G. Peer Evaluator | Seams between teams, disagreement, credit | Low to medium. Relevant only if the interviewer is a peer. Kept at flat weight because the round is unknown | Reciprocity: say what you bring their team. Propose seam principles rather than pretending to know the seam |

---

## Question banks

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the mis-pick rate figure was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: say how the 40% was counted, in your own words. If you do not know how it was counted, say so plainly. Then name the assumption behind it that you would defend least, and which part of the redesign was yours. | F2 is the only measured result you gave, and the prober's first move is the denominator. |
| A2 | "The role is measured on on-time performance and cost per shipment. Which of those have you tracked, and how?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: if you tracked on-time performance or cost per shipment, say what it was, how it was counted, and your part. If you did not, say so plainly, then name the measure you did track and how you would start on these two. | F2 is the requirement's nearest evidence. The JD raises both measures; the material does not show either. |
| A3 | "What daily measure tells you a terminal is running well?" | JD | [generic] | Name the measures you actually watch day to day, in your own words. If you do not use a daily measure, say so and name the one you would put in front of a shift. | The JD raises daily terminal operations. This question makes no claim about your past. |

### B. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why would we hire someone who has never used Power BI to build our reporting?" | JD | [grounded] "never used Power BI" (your message); "solid Excel" (your message) | Pause, then restate the question in your own words. Hold on the Excel reporting you can name. Concede the Power BI gap in plain words: "I've never used Power BI." Then the route to learning it, as a plan. Hold through two follow-ups by returning to Excel and the plan, not to Power BI experience. | F6 is a stated gap and the most likely pressure point. The stress interviewer is testing whether you fold or bluff. |
| B2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold on what you did: you redesigned the pick path. Say, in your own words, what you decided yourself and what was set or agreed with others. If part of it was set by others, say so in those terms. Hold through two follow-ups by returning to the redesign. | F2's figure is the one a pressure interviewer will test for ownership. |
| B3 | "Your peak-season plan — did it land on time, or did you just get through it?" | EXP, JD | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Answer slot: if you have the on-time result for the peak plan, say it and how it was counted. If you do not, say so plainly, then say what you ran and what you would measure next. The question presupposes an on-time measure, which the JD raises and your material does not show. | F1 has the peak plan as its only operating story. Pressure here tests whether you invent a result under time pressure. |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you led a team through a peak period." | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Story-mapped on the sentence you gave: the surge plan, the two years, and your part in it. Answer slot: say what the plan covered and which decisions were yours. If it was set elsewhere, say so and what you did inside it. | F3 and F1 both point at the supervisor team. The peak plan is the story you can actually tell. |
| C2 | "Tell me about a time you had to tell a team something they did not want to hear." | VAL | [generic] | Pick a time you delivered a hard message to supervisors or a shift. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | An open prompt with no claim about your past. The scaffold has an honest branch. |
| C3 | "Tell me about a change you made that did not go to plan at first." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Pick a change you made. If the pick-path redesign had a rough start, say what happened first. If it went to plan first time, say that and what you watched. If no change of yours went off plan, say so plainly and give the nearest change you made. | F2 is the change in your material. The question asks for an honest account, not a success story. |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Four sites, with on-time performance and cost per shipment to drive down. What do you need to know in your first two weeks?" | CASE | [generic] | Clarify first: what each site's measures are, and how they are counted. Then segment by site, state your approach, name the measures, and name the risks. Think aloud, and challenge one premise respectfully. | The JD raises the four sites and both measures. This is a live problem and asks nothing about your past. |
| D2 | "Cost per shipment has risen at one of your four sites and not at the others. Where do you start?" | CASE | [generic] | Segment first: what differs at that site from the others. State a hypothesis, then the one measure you would check first, and why. | A live problem drawn from the JD's cost-per-shipment line. It makes no claim about you. |
| D3 | "Your first reporting deliverable is due in three weeks, and you have never used Power BI. What do you do?" | CASE, JD | [grounded] "never used Power BI" (your message) | Say the gap in your words: "I've never used Power BI." Then the first deliverable in Excel, and the route to Power BI as a plan with its steps and timing. Do not describe Power BI experience. | F6 is the stated gap. The case tests how you plan around it. |

### E. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You run one site with three supervisors. This role is four sites and twelve supervisors. What makes you the one?" | JD, EXP | [grounded] "currently a senior shift manager over 3 supervisors" (your message); [grounded] "ran the site's peak-season surge plan two years running" (your message) | **Highest-return rehearsal in this pack.** Hold: say your current scope in your own sentences, "I'm currently a senior shift manager over 3 supervisors." Follow-up one: return to "I ran the site's peak-season surge plan two years running." Follow-up two: return to the same sentences and add no scope. Concede the size of what you have run in the quote's terms, then give your ramp plan as a plan, never as a past. Hold through two follow-ups; do not add a figure, a site or a team you did not give. | F1 and F3 are the scope gap. The most likely objection to this profile is that the scope is smaller than the role's. Expect it in some form. |
| E2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" (your message) | Name the Power BI gap plainly: "I've never used Power BI." Then the Excel reporting you can show, and the first step as a plan. | F6 is a stated gap, which is safe to say plainly. |
| E3 | "How many years have you led people in operations?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message) | Answer slot: if you have led people for five years or more, say when that began and what you led. If less, say so plainly and give the year your first leading role began. The material gives seven years of operations work and does not say how long you have led. | F4's leadership-years figure is the one thing your material leaves open. |

### F. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message); "cut mis-pick rate 40% by redesigning the pick path" (your message); "green belt certified" (your message) | A 90-second arc, in this order: the seven years, the senior shift manager role, the pick-path redesign and its result, and the Green Belt. Each beat is a sentence you gave. Add nothing that is not in them. | F4, F1, F2 and F7 together make the walk-through. The arc has to fit the sentences you actually have. |
| F2 | "What are you actually doing in Excel these days?" | JD | [grounded] "solid Excel" (your message) | Name one report or model you built in Excel: what it tracked and who used it. Answer slot: if you have built one, say what it tracked and who used it; if you have not, say so plainly and name the report you would build first. | F5 is the Excel half of the reporting requirement. A named report is stronger than "solid". |
| F3 | "What was the Green Belt project?" | JD | [grounded] "green belt certified" (your message) | Answer slot: if the Green Belt involved a project, say what it was and your part in it. If the certification was not tied to a project, say so plainly. | F7 is a certification. The question presupposes a project your material does not name. The honest second branch covers that. |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam. Name what you would need from the other team to make it work, and how you would handle a disagreement with them. | Peer probes on seams. Kept at flat weight because the round is unknown. |
| G2 | "How do you handle credit when a change spans teams?" | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say what you decided and what others did, in those terms. Where you do not know another team's part, say so. | F2's redesign is the change most likely to be used as the example. |
| G3 | "Tell me about a disagreement with a peer that changed how you worked." | VAL | [generic] | Pick a disagreement with an equal where either you or they changed approach. If none comes to mind, say so plainly, then say how you would handle one now. | An open prompt with no claim about your past. |

**Requirement coverage**

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | D1, E1 |
| Drive on-time performance and cost-per-shipment down | A2, B3, D2 |
| Lead a team of 12 supervisors | C1, E1 |
| Build reporting in Excel/Power BI | F2, B1, D3, E2 |
| 5+ years operations leadership required | E3, F1 |
| Lean/Six Sigma a plus | F3 |
| Headline metric, the 40% mis-pick figure (defend the number) | A1, B2 |

**Reverse questions**

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would you need from this role in the first 90 days to call it a good start?" | It shows you are thinking in the role's terms, not the company's brochure. |
| R2 | "How are on-time performance and cost per shipment measured across the four sites today?" | It asks how the measures are counted, which is where this role will live, and whether the sites use one definition. |
| R3 | "What reporting does this role owe the leadership team, and what is already built in Power BI?" | It pins down how much Power BI matters on day one. That is the gap F6 states. |
| R4 | "How has the team of supervisors changed in the last year, and what is the biggest open issue in it?" | It shows you are asking about people as well as numbers, and the answer tells you what twelve supervisors need. |
| R5 | "What does a strong first year look like for the person in this role?" | A standard close that gives you their scorecard. |
| R6 | "What could a new person in this role do in their first month that would genuinely help your team?" | Reciprocity. It is useful if the interviewer turns out to be a peer, and it costs nothing if not. |

---

## Prohibited claims

Built here from the fit snapshot, because no dossier is present. None of these may be coached, in any answer slot, hold, bridge or drill.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've led 12 supervisors" or "I've run four sites" | Inflated form of F1 and F3 | Your quotes at their own scope: "currently a senior shift manager over 3 supervisors." Pack observation, not words for you: your material refers to one site and three supervisors. |
| "I have five years of operations leadership" | Inflated form of F4 | "7 years in warehouse and distribution ops" at its own scope. The leadership years are not in your material. E3 asks for them. |
| "I've used Power BI" or "I built dashboards in Power BI" | Negative you stated, F6 | "I've never used Power BI." |
| "I brought down on-time performance or cost per shipment" | Inflated form of F2 | The 40% mis-pick quote at its own scope. A2 asks about the two measures. |
| "I ran the pick-path redesign as a Lean Six Sigma project" | Inflated form of F2 and F7: two separate sentences, with no link between them in your material | Each quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path" and "green belt certified." Claim the link only if you can say it in your own words. |

---

## Sources

- **Provided documents:** your message, containing the JD text and your background. No attachments, and no dossier.
- **Searches sent:** three. All three were refused by the host (permission not granted), and no page was fetched. None was retried.
  - "Atlas Freight regional logistics company values": refused
  - "Atlas Freight interview process operations manager": refused
  - "Atlas Freight logistics strategy news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Would have set the value names for a values cheat sheet. None is built, since no values round is documented. Company values are not established. |
| 2. Atlas Freight interview process, operations manager | unavailable | Would have set the loop structure and any persona tilt. Weights stay flat because no loop is established. |
| 3. Atlas Freight strategy and recent news | unavailable | Would have fed company-strategy (CO) questions. None is written; the case questions are generic and labeled [generic]. |
| 4. Interviewer name and Atlas Freight | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

---

## Upgrade menu

- The round type and who you are meeting → persona weights from the relationship priors, and a tailored reverse question. The pack is flat until this is known.
- Whether you can work on-site at all four sites day to day → resolves gate row F8. Until it is answered, the gate stays open.
- The recruiter's note on focus areas or a pre-declared deliverable → coverage of any deliverable the recruiter names.
- Atlas Freight's published values, or the recruiter's process email → a values cheat sheet and a loop structure. Until pasted, the company's values and process are not established.
- The interviewer's name → a tailored reverse question, and persona weights from their public professional footprint.
- The Green Belt certificate, with issuer and date → F7 moves from medium to high.
- How the 40% was counted, in your own notes → A1 and B2 get their grounded beats, and the defend-the-number answer slot gets a sentence you can stand behind.
- A `tuesday-dossier.md` file → would carry the verified evidence and the objections this pack exposed into any later session.
