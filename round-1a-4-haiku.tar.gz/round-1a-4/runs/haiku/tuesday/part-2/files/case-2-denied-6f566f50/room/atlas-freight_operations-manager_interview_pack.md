# Operations Manager, Atlas Freight: interview prep pack

Round: not yet known. Interviewer: not known. Persona weights: flat, because the round is unknown (see the persona table). This pack is weaker than one built for a known relationship.

## How to use

Personas describe how a question will arrive. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script.

Type key:
- **VAL**: behavioural or values alignment
- **EXP**: your past work, probed for what was actually yours
- **JD**: the listed job's requirements
- **CASE**: a live problem set in the role
- **CO**: company and strategy knowledge. None is written here, because web search was refused, so no company material could be checked

## The fit snapshot

Each row quotes your own sentences and grades how far they reach the JD line beside them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own daily terminal operations across 4 sites" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Adjacent work: running a shift at a site, not terminal operations across four. Words: "I'm currently a senior shift manager over 3 supervisors." Answer slot: describe a daily operating rhythm you ran and how far it reached. If you have run more than one site, say which. If you have not, say so and say how you would take on the second. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | The span is 3 supervisors, not 12. Words: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have led a wider span, say how many and over what. If not, say so and say how you would structure a span of 12. |
| F3 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | The quote is accuracy, not on-time performance or cost per shipment. Words: "I cut mis-pick rate 40% by redesigning the pick path." Expect a probe on how the 40% was counted. Answer slot: if you tracked on-time or cost per shipment, say what, over what period, and what was yours to change. If you did not, say so and say what you would measure first. |
| F4 | "build reporting in Excel/Power BI" (JD, Excel part) | "solid Excel" (your message) | low | [inferred] | discovery | "Solid Excel" names a tool, not a report, so reporting in Excel is not asserted as your work. Derivation: a tool skill is evidence of reporting only where a report exists. Answer slot: name a report you built in Excel, what it reported and who used it. If you have not built one, say so. |
| F5 | "build reporting in Excel/Power BI" (JD, Power BI part) | "never used Power BI" (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Never claim Power BI work. |
| F6 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message), "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | presentation | Both quotes reach the requirement in other terms: seven years of operations work and a senior shift role. Words: "I have 7 years in warehouse and distribution operations, and I'm currently a senior shift manager over 3 supervisors." Length of experience is not a gate, so this row is graded on fit. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote reaches the requirement. Words: "I'm green belt certified." No issuer or date was given and the certificate has not been inspected, so expect a probe. |
| F8 | Not a JD line; peak-season planning (generic) | "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | none | Not a stated requirement, but your stories draw on it. Words: "I ran the site's peak-season surge plan two years running." Expect a probe on what the plan was and who was in it. |

No gate rows. The pasted JD states no location, pay, schedule, licence or credential term.

## The prohibited list

Claims this pack will not coach, each with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran daily terminal operations across four sites | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material shows a shift at one site, not terminal operations across four. |
| Leads or led 12 supervisors | Inflated form of F2 | F2's quote. The material shows a span of 3. |
| Drove on-time performance or cost per shipment down | Inflated form of F3 | F3's quote. The material shows mis-pick rate. |
| Built reporting in Excel | Inflated form of F4 | The tool, as "solid Excel". The material shows the tool, not a report. |
| Has used Power BI | Negative you stated, F5 | "I haven't used Power BI." No slot. |
| Led Six Sigma projects | Inflated form of F7 | "green belt certified" at its own scope. A belt is not a project. |

## Persona table

| Persona | How it shows up here | Likelihood | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Asks how the 40% was counted and what report it came from | Flat, 3 questions. Round unknown, so no prior applies | Know what you can and cannot say about the count. Name the weakest assumption before they do. |
| Pressure / Stress | Challenges your scale against the job's scale, and whether the 40% was really yours | Flat, 3 questions | Pause, restate, anchor in what you stated, hold through two follow-ups, concede only what is specific. |
| Values / Behavioral | Scenario prompts about hard truths and process change | Flat, 3 questions. No values round detected, so these are generic | Choose a real instance. Where none comes to mind, say so and give the nearest one. |
| Case / Strategist | Live problems on mis-picks, peak, and four-site on-time performance | Flat, 3 questions | Clarify, then structure, then state metrics and risks. Think aloud. |
| Skeptic | Probes the span gap and the missing Power BI, the likeliest objections | Flat, 3 questions. The span gap is the most predictable objection | Rehearse it until it is plain. Bridge only from what you stated. Calibrated candour over bluffing. |
| Conversational / Rapport | Friendly openers on your journey and motives, then the tools question | Flat, 3 questions | Pre-script a 90-second journey. Treat the casual Power BI question as scored. |
| Peer Evaluator | Seams with other teams, disagreement, credit, and what they would need from you | Flat, 3 questions | Frame reciprocity: what you bring their team, not only what you need. |

## Question banks

Provenance is one label, then your quoted sentences the guidance rests on. Question types are one token each.

### A: Data-Driven Prober (flat, 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you counted the 40% mis-pick reduction." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (F3) | Say how the figure was counted, in your own words. Name what it is most sensitive to and the assumption you would defend least. Say which part was yours. If you do not know how it was counted, say so plainly. | F3 is your headline number and the likeliest probe. EXP because it tests attribution. |
| A2 | "What would you need to show me to prove the 40%?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (F3) | Answer slot: if you have the report or sheet the figure came from, name it and what it holds. If you do not, say so plainly. | A follow-up to A1. It probes for an artifact, which is what would raise F3's confidence. |
| A3 | "Tell me about a report you've built and what it counted." | JD | [inferred] "solid Excel" (F4). Derivation: the JD's reporting line raises it, and a tool skill is not a report. | Scaffold: pick a report you produced or maintained and say what it counted. If none comes to mind, say so plainly, then give the nearest thing you have done with Excel data and how far it went. | The JD's Excel and reporting line, asked as a story. The guidance asserts no report, because F4 is low confidence. |

### B: Pressure / Stress (flat, 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: you're a senior shift manager over 3 supervisors. Why should we trust you with four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors", "7 years in warehouse and distribution ops" (F6) | Pause and restate. Hold the two facts as stated. Answer slot: if four sites is new territory for you, say so and say what carries over. If not, say what you ran. Do not argue the scale. | F1 and F6 are where the scope gap is loudest. Pressure tests composure, not the number. |
| B2 | "That result. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (F3) | Hold: you cut it by redesigning the pick path, and that holds through two follow-ups. Concede specifically on any part a team did, and never fold on the redesign. | Hold-then-concede on your strongest claim. |
| B3 | "Power BI is on the list and you haven't used it. What makes you a safe bet on reporting?" | JD | [grounded] "never used Power BI" (F5) | Plain acknowledgment: "I haven't used Power BI." Then the first step you would take and how you would know it worked, as a plan. Do not claim Excel reporting beyond what you can name. | F5 is a stated absence, so the acknowledgment is yours to give. |

### C: Values / Behavioral (flat, 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you told someone senior something they didn't want to hear." | VAL | [generic] | Scaffold: pick a time you raised a hard truth with someone senior. Name the stake, what you said, and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it. | A persona stem, not a JD line. No values round is detected, so no value is mapped. |
| C2 | "On-time performance is a promise to customers. When did you put it ahead of an internal metric?" | VAL | [generic] | Scaffold: pick a case where a customer commitment and an internal number pulled apart. Say what you chose and why. If none comes to mind, say so and give the nearest case. | The JD's on-time line raises the theme. Generic because no company value is established. |
| C3 | "Tell me about a time you used a Lean or Six Sigma tool to change how work got done." | EXP | [grounded] "green belt certified" (F7) | Scaffold: name the tool, the process it was used on, and what changed. The belt is what your quote states, so say nothing about projects. If no such time comes to mind, say so and say what you would reach for first. | Covers the Lean/Six Sigma line. The guidance describes only the certificate. |

### D: Case / Strategist (flat, 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Mis-pick rates have crept back up over a month at one site. Diagnose it." | CASE | [generic] | Clarify the scope and the target. Structure by shift, zone, pick type, and new starters. State metrics and risks. Think aloud. | A live problem in your own domain. It asks about no past of yours. |
| D2 | "Peak is three weeks away, the forecast is 25% above last year, and a site is two supervisors short. What's your plan?" | CASE | [generic] | Clarify headcount, cover, and the cost of each option. Sequence the first 72 hours. Name the risks. | A scenario built on the surge work in F8. Generic because it is a pattern, not a fact about this employer. |
| D3 | "A terminal runs on-time performance at 88% against a target of 95%, across four sites. What do you need to know first?" | CASE | [generic] | Clarify what counts as on time, per site and per shift. Ask what drives the gap. Structure the diagnosis before the fix. | Covers the four-site and on-time requirements. The figures are a scenario. |

### E: Skeptic (flat, 3). Highest-ROI prep

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You're a senior shift manager over 3 supervisors, and this role leads 12 across four sites. What's the gap, and what would you do about it?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (F1, F2) | Hold the three as fact: "I'm currently a senior shift manager over 3 supervisors." Concede the span in your own words, specifically. Answer slot: say what from the three-supervisor work carries to twelve and what does not. Hold through two follow-ups. Never fold on the three. | This is the most predictable objection. The scope gap is where your material is thinnest, so it gets the deepest rehearsal. |
| E2 | "I don't see Power BI anywhere in your background. How would you handle the reporting side on day one?" | JD | [grounded] "never used Power BI" (F5) | Plain acknowledgment: "I haven't used Power BI." Then a plan with a first step. Answer slot: say what reporting you have built in Excel, if any. If none, say so. | F5 is the stated gap, and the Excel branch stays inside F4's limit. |
| E3 | "You've run the peak plan twice. Why isn't that one good result, not a pattern?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (F8) | Hold the two years as stated, through two follow-ups. Concede specifically on whether the results were the same each year. Never claim a trend you did not state. | F8 is the strongest pattern claim you have. A probe will test whether it is a pattern. |

### F: Conversational / Rapport (flat, 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors", "cut mis-pick rate 40% by redesigning the pick path", "green belt certified" (F6, F1, F3, F7) | A 90-second arc with one beat per quoted sentence, in that order, in your words. Do not add a beat your quotes do not carry. | Casual-register questions are still scored. A pre-scripted arc is the fix. |
| F2 | "What are you actually playing with in the reporting side these days?" | JD | [grounded] "never used Power BI" (F5) | Say the Power BI gap plainly, then the plan. Answer slot: what reporting you have built in Excel, if any. | The casual form of the reporting requirement. |
| F3 | "What made you pick operations over the other paths?" | EXP | [grounded] "7 years in warehouse and distribution ops" (F6) | Give your motive in your own words. The quote gives only the years. Do not add a reason you did not state. | Motive is asked casually and scored for consistency. |

### G: Peer Evaluator (flat, 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam with your work, and what happens when we disagree?" | VAL | [generic] | Name the seam as a principle, not as knowledge you lack. For disagreement, scaffold: pick a time you disagreed with an equal and resolved it. If none comes to mind, say so and give the nearest. | Peer probes come collegially. Generic because no team structure is known. |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Scaffold: pick a time work crossed teams and say how credit was handled. If none, say so and give the nearest. | Credit-sharing is a standard peer probe. |
| G3 | "On-time performance depends on what other teams do. What would you need from my team to hold it?" | JD | [generic] | Name what you would need, then what you would bring to their team. Reciprocity, not only a request. | The on-time requirement, asked from a peer's side. |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| own daily terminal operations across 4 sites | E1, D3, reverse question R3 |
| drive on-time performance and cost-per-shipment down | D3, G3, reverse question R2 |
| lead a team of 12 supervisors | E1, reverse question R5 |
| build reporting in Excel/Power BI | A3, B3, E2, F2, reverse question R4 |
| 5+ years operations leadership required | B1, E1, F1 |
| Lean/Six Sigma a plus | C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the first 90 days look like for someone in this role?" | Shows you are planning against the scored requirements. |
| R2 | "How is on-time performance measured across the four sites, and who owns that number?" | Shows you read the scoring line. The answer tells you what the number really is. |
| R3 | "Which of the four sites is hardest to run right now, and why?" | Shows you think about each site, not the company as a whole. |
| R4 | "What reporting do the leaders use today, and what is missing from it?" | Points at the Excel and Power BI requirement from their side. |
| R5 | "How are the twelve supervisors split across the four sites?" | Tests the span question directly and shows you are thinking about structure. |

## Sources

Provided documents: your message, which holds the JD as you pasted it and your background as you described it. The JD is a condensed paste, not the posting, so quotes use its wording. No CV document was provided.

Research tier: L1, searches 3 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet. The three searches below were refused, so no values page was established and the cheat sheet is dropped. |
| 2. Atlas Freight interview process | unavailable | Loop structure. Refused, so no loop source establishes the loop. Persona weights are flat as a result. |
| 3. Atlas Freight strategy and recent news | unavailable | The CO bank and the CASE questions would have had company grounding. Refused, so they stay generic. |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. |
| 5. Representative Operations Manager JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

Queries sent, all refused:
1. "Atlas Freight regional logistics company values": refused.
2. "Atlas Freight interview process operations manager": refused.
3. "Atlas Freight logistics news strategy 2026": refused.

## Upgrade menu

- The round and who runs it → persona weights and reverse questions become specific. (Asked in the message.)
- The full posting, not the pasted lines → the quotes are checked against the whole JD, and any requirement the paste left out gets a fit row.
- Atlas Freight's values page, as a link or pasted text → a values cheat sheet, if the interview names a values round.
- The interview steps from the recruiter → loop structure and persona weights; any scheduled assignment gets its own build section.
- Web search turned on → targets 1 to 3 can run, and the generic CO and CASE questions can take company grounding. A deeper strategy pass is also available: up to 6 more searches and 2 more fetches, several more minutes. Say if you want it.
- Your Green Belt certificate → F7 moves from medium to high.
- The report or sheet behind the 40% → F3 moves from medium to high, and A1 and A2 get an artifact to walk through.
- A sample Excel report you built, with the data removed → F4 can move from low to medium.
- The interviewer's name → persona weights from their public footprint, and a reverse question tied to their path.
- How many days you have to prepare → a prep triage schedule, sized to that time.
