# Ashgrove Credit Union: Member Experience Lead

Interview prep pack, three rounds on 3 December 2026 (loop mode). Prepared 24 November 2026 for Dara.

- Round 1: recruiter screen, 30 minutes, with the recruiter.
- Round 2: behavioural, 45 minutes, with the Head of Member Services (your future manager). Names not yet given.
- Round 3: panel, 60 minutes, with two branch managers. Includes a 20-minute complaint-escalation case. Scored against the four values. Names not yet given.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored: **VAL** behavioural and values, **EXP** work-experience deep-dive, **JD** role requirement, **CO** company and strategy, **CASE** live problem.
- Guidance is scaffolding, not a script. Each guidance cell should be speakable in 90 to 120 seconds.
- **Answer slots** are instructions for the interview: "if you did this, say how; if not, say so plainly." They are not questions to answer here.
- **Provenance** shows the sentences each guidance cell rests on. Every quote is a sentence you wrote in this conversation, unless it is marked `[generic]`, which is a pattern with no claim about you.
- Question IDs: A for round 1, B for round 2, C for round 3. F is the fit snapshot.

## Loop shape

| Round | Who | Persona weights (reasoning in each round's section) | Bank |
|---|---|---|---|
| 1. Recruiter screen | Recruiter | Conversational 4, Skeptic 2 | A1 to A8 |
| 2. Behavioural | Head of Member Services | Values/Behavioral 4, Skeptic 3, Case 2, Prober 2, Pressure 1 | B1 to B12 |
| 3. Panel | Two branch managers | Values/Behavioral 4, Case 4, Peer Evaluator 3 | C1 to C11 |

## Fit snapshot (shared across all three rounds)

Requirements come from the job description you pasted. Quotes are your sentences from this conversation.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | No gap. Say it in those words. It is a CV-level claim with nothing inspected behind it, so expect the dates to be checked. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material says formal complaints log. It does not show whether the log ran to a regulatory timescale. Answer slot: if it did, say how it was tracked and what you did when a case came near its limit; if it did not, say so and describe how the log was kept. Do not call your own log "regulated" unless you can say what made it so. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The log is one branch's, and the material shows no step beyond it. Bridge at its own scope: "For the branch's formal complaints log, I handled it." Answer slot: which steps from first contact to close were yours to run; if a step was run by someone else, or the complaint closed within the branch only, say so and say how you would extend it. |
| F4 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | You trained tellers, not supervisors. Say exactly that. Do not stretch it to coaching supervisors. Answer slot: if you have coached a supervisor or team lead on an escalation, say what you did; if not, say so and say how you would start. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | Monthly complaints reporting is shown. Your message does not say what the spreadsheet counted, and resolution times are not mentioned. Answer slot: name what it counted each month; if resolution times were among the figures, say how they were measured; if not, say so. |
| F6 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Reword only that sentence and add no tool. Your message says spreadsheet, not Excel. Name the tool only if you know it. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. No senior presenting is claimed in any form. |
| F8 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Plain acknowledgment: "I've never worked in a contact centre." Then how you would learn the contact-centre side, as a plan. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Silence, not a stated absence. Answer slot: if you have changed a customer's route through a self-service channel, name it and your part; if not, say so and say how you would learn the journey from the member's side. The July 2026 brief (your summary) makes digital central: 40% of member service by 2028. |

**Hard gates: none.** The posting names no location, schedule, licence or credential. The four-year requirement is a length-of-experience requirement, graded on fit like the rest.

## Grounding brief

From your copy of the values (24 November 2026) and your summary of the July 2026 strategy brief. The brief itself is not in this conversation, so check every figure against it before you quote one.

- **Values, by official name:** Members First, Always. Plain Words. Neighbours, Not Numbers. Own the Fix.
- **Digital:** move 40% of member service to digital channels by 2028.
- **Network:** consolidate eight branches into five hubs over 2027.
- **Lending:** launch a small-business lending product in Q1 2027.
- **Competitive frame:** the main pressure is app-only banks.
- **Vocabulary to use back:** member service, digital channels, hubs, member's side of the counter.
- **Observation (analysis, not a claim about you):** on the page, the hub plan and "every branch is part of its town" pull against each other. Expect the panel to raise it. Rehearse C9 with it in mind.

## Prohibited claims

These are the claims this pack will not coach. Each one is stretched beyond what you wrote, or is a negative you stated. The list is built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns the complaints process end to end across branches and the contact centre | Inflated form of F3 | "For the branch's formal complaints log, I handled it." The limit is the pack's observation: your material shows one branch's log, not the process across branches. |
| Handles regulated complaints, or says your log was regulated | Inflated form of F2 | "I handled the branch's formal complaints log." The regulatory question is an answer slot only. |
| Coaches branch supervisors on escalations | Inflated form of F4 | "I trained new tellers on our escalation script." |
| Reports resolution times | Inflated form of F5 | Name the figures the spreadsheet counted. Resolution times only if they were in it. |
| Names Excel as the tool | Inflated form of F6 | "The monthly complaints spreadsheet," unless you know the tool. |
| Presents to senior leaders | Negative you stated (F7) | "I haven't presented to anyone above regional level." |
| Has worked in a contact centre | Negative you stated (F8) | "I've never worked in a contact centre." |
| Any complaint volume, percentage, time or team size | No figure in your material | No figure is coached. A number is yours to give only if it is yours. |

## Round 1: Recruiter screen (30 minutes)

**Persona weights.** The relationship prior for a recruiter screen is conversational, with a light skeptic. Conversational gets 4 because the opening is biography and motivation, which are scored in a friendly register. Skeptic gets 2 because the screen checks the two gaps the posting names: the contact centre and senior presenting.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Friendly biography, motivation, logistics | High. A screen's prior. Every A question is scored | Script a 90-second arc (A1). Keep logistics as stated facts |
| Skeptic (light) | Checks what the posting asks that your CV does not show | Medium. Contact centre (F8) and senior presenting (F7) are the named gaps | Plain acknowledgment, then how you would learn it. No bluffing |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background in a couple of minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | Ninety seconds: six years in retail banking, the last three as a branch supervisor. Then the formal complaints log and the escalation-script training, in those words. No extra roles, no figures. | F1 is the first credential a screen checks. It reads as small talk but is scored. |
| A2 | "What drew you to member complaints work?" | JD | [generic] | Answer in your own words, from the member's side of the work. No motivation is coached here. | Motivation is always asked in a screen. Your material holds no sentence about motivation, so the pack writes none. |
| A3 | "What about this role is new to you?" | JD | [grounded] "Never worked in a contact centre" | Say the contact-centre part plainly: "I've never worked in a contact centre." Then what you would do to learn it, as a plan. | F8 is the first thing a screen checks against the posting. The plain line is the one your material supports. |
| A4 | "How did the formal complaints log run day to day?" | EXP | [grounded] "I handled the branch's formal complaints log" | Describe what you did with the log, in your own words, no more. Answer slot: if it was kept to a regulatory timescale, say so and how it was tracked; if not, say so and describe how it was kept. | F2 is the regulated-complaints requirement, at medium confidence. The screen tests whether the log was regulated in practice. |
| A5 | "What are your pay expectations for this role?" | JD | [generic] | A logistics slot. Give your own figure, or ask for the band first. No figure is in your material, so none is supplied. | Pay is the screen's first logistics question. The answer is your number, in your words. |
| A6 | "What notice would you need to give, and when could you start?" | JD | [generic] | A logistics slot. Give your actual notice period. If you do not know it, say so and say what you would check. | Notice sets the start date. It is a fact you hold, not one the pack supplies. |
| A7 | "Where would you need to be based?" | JD | [generic] | A logistics slot. Name the base you would work from and the commute you would accept. If you know how the hub plan affects your base, say so. | The brief consolidates eight branches into five hubs in 2027, so base may matter to the screen. |
| A8 | "Why are you leaving your current role?" | EXP | [generic] | A logistics slot. Give your own reason in a sentence or two. None is in your material, so none is supplied. Do not criticise your employer. | This is the one screen question with no quote behind it. The answer has to be yours. |

**Reverse questions (round 1)**

| Question | Why it lands |
|---|---|
| "What does the complaints team look like in the first ninety days?" | Shows you think about the start of the work, not the title. |
| "How will the eight-to-five hub plan change the complaints work?" | Shows you read the July brief. The answer shows where the team is heading. |
| "How do the digital teams and the complaints team work together on a self-service journey today?" | The posting asks you to work with them. The answer shows the current seam. |
| "What makes someone succeed in this role at six months?" | Asks the screener for the scoring criteria, which the manager will reuse. |
| "What comes after the three rounds?" | Logistics, and a sign you are planning ahead. |

## Round 2: Behavioural with the Head of Member Services (45 minutes)

**Persona weights.** The hiring-manager prior is Case and Skeptic. The recruiter says the round is mostly behavioural, so Values/Behavioral takes the top weight of 4. Skeptic gets 3 because the three gaps in your material (contact centre, senior presenting, one branch against many) are what a future manager will test. Case gets 2 for the strategy questions. Prober gets 2 because the posting names reporting and your spreadsheet is a figure. Pressure gets 1 because the manager prior does not favour it, though B12 can land as a challenge.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario questions on the four values, STAR-shaped | Highest. Mostly behavioural round | One story per value where your material carries one; selection scaffold where it does not |
| Skeptic | Probes the three gaps | High. These are the predictable objections | Plain acknowledgment, then a plan. Hold through two follow-ups |
| Case / Strategist | Live problems from the hub and digital plans | Medium. Manager's strategy interest | Clarify, then structure, then the complaint's first step |
| Prober | Asks how a figure was counted, and what was yours | Medium. The spreadsheet is the figure | Name what it counted and the assumption you would defend least |
| Pressure | Challenges your right to a supervisor-coaching role | Low | Hold the supervisor record. Concede exactly what your material does not show |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you decided a member's case from the member's side when the process pointed the other way." | VAL | [generic]; "trained new tellers on our escalation script" (honest branch only) | Selection scaffold: pick a case where the member's need and the process pulled apart; name the process and the need; say what you chose and what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the escalation script you taught from. | Members First, Always has no quoted story, so the scaffold keeps the honest branch. |
| B2 | "Tell me about a time a member needed something explained twice." | VAL | [grounded] "trained new tellers on our escalation script" | The script story, in your words: what you taught and how you checked it landed. Answer slot: if you rewrote or simplified the script, say what and why; if you taught it as written, say so and say how you checked a teller had understood it, if you did. | Plain Words. The quote carries teaching the script, not writing it. |
| B3 | "When did a number point one way and a branch's customers point the other?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: if a figure you built met a branch's reality, say what the figure showed, what the branch said, and what you did. If it never did, say so and say how you would keep the figures and the town in view together. | Neighbours, Not Numbers. Your quoted sentence is the numbers side, so the pack gives no story from it, only the question and the honest branch. |
| B4 | "Tell me about a complaint you stayed with until it was fixed." | VAL | [grounded] "I handled the branch's formal complaints log" | Pick a complaint you carried to resolution and say what held it with you. Answer slot: if you handed it on before it was fixed, say to whom and why. If you carried none to resolution, say so and say what you did with the log entries. | Own the Fix. The quote carries handling, not holding to resolution, so the answer must be your own case. |
| B5 | "You've never worked in a contact centre. How would you run the first month?" | JD | [grounded] "Never worked in a contact centre" | Plain line first: "I've never worked in a contact centre." Then a plan for the first month, as a plan. | F8 is a stated gap. The plain line and a plan are all your material supports. |
| B6 | "The role presents to senior leaders. You haven't presented above regional level. What happens when you're in that room?" | JD | [grounded] "I've never presented to anyone above regional level." | **The highest-ROI prep in this pack.** Say the plain line once: "I haven't presented to anyone above regional level." Then how you would prepare, as a plan: the walk-through, the one-page summary, a dry run with your manager. Hold through two follow-ups by returning to the plan. Concede exactly what is missing in one sentence. Do not add a past presentation. | F7 is the requirement most likely to be probed, and the gap that cannot be bridged. Rehearsal decides whether the non-defensive answer lands. |
| B7 | "Your log was one branch. What would you do across eight?" | JD | [grounded] "I handled the branch's formal complaints log"; the eight branches are from the brief (your summary) | Honest branch. Your log was one branch. Say what carried over and what did not. If you have run nothing across branches, say so and say how you would set the log up across them. | F3. The premise is the strategy's eight branches, which the brief supplies. It is not a claim about your past. |
| B8 | "Eight branches become five hubs during 2027. Walk me through the complaints work before, during and after." | CASE | [generic] | Structure: clarify which members move and when; open complaints at each closing branch; one owner for each open case; what the member hears; what you would measure monthly. No claim about your past. | A strategy case from the brief. The manager will test structure more than the answer. |
| B9 | "Forty per cent of member service is moving to digital by 2028. Which complaints should move with it, and which should stay with a person?" | CO | [generic] | Structure: segment by member need, vulnerability and complexity; what a digital route must still allow; how you would test it before it goes wide. | The digital target is from the brief. The segmentation is structure, not a claim. |
| B10 | "Walk me through how the spreadsheet counted what it counted." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what it counted, in your words, each figure at its scope. Name the weakest assumption behind the figure you would defend least, if you know one. Answer slot: if it carried resolution times, say how they were measured; if not, say so. Do not define a method you did not use. | F5 and F6. You gave no figure, so the slots ask only what the spreadsheet counted. |
| B11 | "Which part of the log was yours, and which was the branch's?" | EXP | [grounded] "I handled the branch's formal complaints log" | Attribution in your words: what you did with the log, and what the branch or the process did. Answer slot: if any part of the process was set by someone else, say so. If you set part of it, say which part and how you decided. | The attribution probe for F2 and F3. The honest branch is the answer. |
| B12 | "Sixty seconds: why you over a supervisor who has coached their peers for years?" | Pressure | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "trained new tellers on our escalation script" | Hold the record: you were a branch supervisor for the last three years, and you trained tellers on escalation. Hold through two follow-ups. Concede in one sentence exactly what your material does not show: coaching supervisors. Answer slot: if you have coached a peer supervisor, say what you did; if not, say so and say what you would do first. | Pressure is low-weight here, but this is the line a manager uses to test a supervisor-coaching role. |

**Reverse questions (round 2)**

| Question | Why it lands |
|---|---|
| "What would you need from me in the first ninety days to call the move a good one?" | Asks the manager for the scoring, which you will then be measured on. |
| "Which of the escalations that reach you would you hand a new lead first?" | Shows you want the hard work. The answer shows the seam. |
| "How do you want to hear about a trend in complaints: in the monthly figures, or in person?" | Reveals the reporting preference the posting asks you to meet. |
| "Where do the branch side and the digital side disagree most about a member's complaint?" | Names the seam. The manager will answer honestly. |
| "How will you know a branch supervisor is escalating well?" | Brings up the coaching requirement. The answer is the rubric. |

## Round 3: Panel of two branch managers (60 minutes, with a 20-minute case)

**Persona weights.** The two branch managers' relationship to you is not established, so the panel prior blends the top two personas of each member's likely relationship. Values/Behavioral gets 4, one question per value, because the recruiter says the panel scores against the four values. Case gets 4 because the 20-minute escalation case, plus the two strategy cases, is live. Peer Evaluator gets 3 because the seam between branches and the contact centre is where branch managers will test whether you add to their load. Pressure is dropped: the panel prior does not carry it. Assign personas per member once names are known.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scored against each value | Highest. The recruiter names this round as the values round | One story per value where your material carries one; a scaffold where it does not |
| Case / Strategist | The 20-minute escalation case, then the strategy cases | High. Live problem with a clock | Clarify, state the first step, name one owner, then the plain-words message to the member |
| Peer Evaluator | Seam, disagreement and credit | Medium. Branch managers test load and turf | Give a principle, not a history you do not have. Reciprocity: what you bring to their team |

**Values cheat sheet (section 10).** The panel is a values round by the recruiter's own words, so the cheat sheet applies.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a story. C1 is a scaffold. Honest branch: if none comes to mind, say so plainly, then give the nearest thing your material carries: the escalation script you taught from |
| Plain Words | If a member needs it explained twice, it was written wrong | "trained new tellers on our escalation script" (F4). The story is the teaching: what you taught, how you checked it landed. Answer slot: rewrote or taught as written |
| Neighbours, Not Numbers | Every branch is part of its town | "I built the monthly complaints spreadsheet our regional manager uses" (F5). This is the numbers side. Scaffold (C3): a case where a figure met the town. Honest branch: say so and say how you would keep both in view |
| Own the Fix | Keep hold of a problem until it is solved | "I handled the branch's formal complaints log" (F3). The quote carries handling, not holding to resolution. Scaffold (C4). Honest branch: if you handed it on, say so and why |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "When did you decide a member's case differently from what the procedure said?" | VAL | [generic]; "trained new tellers on our escalation script" (honest branch only) | Selection scaffold: pick a case where the member's need and the procedure pulled apart; name the procedure and the need; say what you chose. If none comes to mind, say so plainly, then give the nearest thing your material carries: the escalation script you taught from. | Members First, Always. A variant of B1, so the answer is not rehearsed word for word. |
| C2 | "When did something you wrote or said have to be explained twice?" | VAL | [grounded] "trained new tellers on our escalation script" | The script story: what you taught and how you checked it landed. Answer slot: if you rewrote or simplified the script, say what and why; if you taught it as written, say so. | Plain Words. The quote carries teaching, not writing. |
| C3 | "Tell me about a figure that said one thing and the town said another." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: if a figure you built met a branch's reality, say what the figure said, what the branch said, and what you did. If it did not, say so and say how you would keep both in view. | Neighbours, Not Numbers. The quote is the numbers side. The branch case must be yours. |
| C4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Pick one you carried to resolution and say what held it with you. Honest branch: if you handed it on, say to whom and why; if you carried none, say so and say what you did with the log entries. | Own the Fix. The quote carries handling, not holding to resolution. |
| C5 | "Where does the branch's work stop and the contact centre's start, on a member's complaint?" | JD | [grounded] "Never worked in a contact centre" | Name the seam as a principle: who owns the case at each handover, and who tells the member. Plain line: "I've never worked in a contact centre." Then what you would need to learn about the other side. | F3 and F8. The answer names a principle, not a history you do not have. |
| C6 | "When you and a branch manager disagree about an escalation, what happens?" | Peer | [generic] | Name the principle you would use to settle it. If you have had such a disagreement, say what you did; if not, say so. | Disagreement is a peer probe. Your material has no disagreement story, so the honest branch is written in. |
| C7 | "On a complaint that spans two teams, who gets the credit?" | Peer | [generic] | Name the principle: credit the people who did the work, and say who you would tell. No credit story is in your material, so none is given here. | Credit-sharing is a peer probe. Until you have a case, the answer is a principle. |
| C8 | "A member has been passed between the branch and the contact centre three times and now asks for it to go to the regulator. Walk us through it." | CASE | [generic] | The 20-minute case. Structure: clarify the facts and dates; stop the handover loop by naming one owner; contact the member in plain words; check the timeline and what has been promised; decide the escalation route; record it. | The case is live and asks about no past. Members First and Own the Fix are the values it tests. |
| C9 | "Eight branches become five hubs in 2027. Walk us through the complaints work around the change." | CASE | [generic] | Structure: which members move, and when; open complaints at each closing branch; one owner for each open case; what the member hears; what you would measure monthly; what the town needs to hear. | The hub plan is from the brief. The tension with "part of its town" is what the panel is likely to press. |
| C10 | "Forty per cent of member service is moving to digital by 2028. Which complaints move, and which stay with a person?" | CO | [generic] | Structure: segment by member need, vulnerability and complexity; what a digital route must still allow; how you would test it before it goes wide. Answer slot: if you have changed a self-service route, say your part; if not, say so. | The digital target is from the brief. The self-service requirement is F9. |
| C11 | "App-only banks are the main pressure. What can a member reasonably expect from a complaint, that you would have to match?" | CO | [generic] | Structure: response time, plain words, one owner, and a person who can decide. Keep to what members can reasonably expect. | The competitive frame is from the brief. The answer should be the member's view, not a claim about app-only banks. |

**Reverse questions (round 3)**

| Question | Why it lands |
|---|---|
| "What does a branch do well with its complaints that the others don't?" | Asks them to name a practice. Shows you want to learn from the branches. |
| "When a complaint sits between a branch and the contact centre, who decides?" | The seam is your biggest question. The answer shows the current ownership. |
| "What is one thing a new complaints lead should not change in your branches?" | Shows restraint. The answer shows what they value in "neighbours". |
| "How does a branch's town show up in the complaints you see?" | Links to the value and invites a story from them. |
| "What would make complaints work across the hubs still feel like it belongs to each town?" | Puts the consolidation tension in their words. |
| Reciprocity (peer): "What could a new person do in their first month that would genuinely help your team?" | Reciprocity framing. Their answer shows their load. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the complaints process end to end across branches and the contact centre | B5, B7, C5, C8 |
| Report monthly on complaint volumes and resolution times | B10 |
| Coach branch supervisors on escalations | B12 |
| Work with digital teams on self-service journeys | C10; round 1 reverse question on digital teams |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | A4, B11 |
| Confident presenting to senior leaders | B6 |
| Comfortable with Excel reporting | B10 |
| Strategy: digital channels, hubs, lending, app-only competitors | B8, B9, C9, C10, C11. Lending launch: none, and why: it is not a requirement of this role |

## Graded deliverables and interviewer read

Dropped. The recruiter names a 20-minute case, which is a live problem, not a pre-declared deliverable (no POV, presentation or take-home). If the recruiter sends case material, it becomes a build section. No interviewer profiles were given, so the interviewer read is absent.

## Sources

**Provided documents:** the job description (your message); your background (your message); the recruiter's email (as you pasted it); the values copy (your message, 24 November 2026); your summary of the July 2026 strategy brief (the brief is not attached).

**Research tier: L1, searches 0 of 6, fetches 0 of 2.**

| Target | Status | What it moved |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values copy fixes the four official names and their working meanings. Section on values and grounding brief. |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes three rounds, their lengths, the panel's values scoring and the 20-minute case. |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief is about four months old, under six months. It fixes the CO questions. |
| 4. Interviewer name and Ashgrove | n/a | No names were given for the Head of Member Services or the panel. |
| 5. Representative JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- **Your prep time before 3 December** → a prioritised schedule across the three rounds, starting with B6 and the values cheat sheet.
- **Names of the Head of Member Services and the two branch managers** → per-member persona assignment on the panel, and tailored reverse questions.
- **The recruiter's prep note, if one exists** → coverage of anything the recruiter declares for the rounds, and a build section if the case comes with material.
- **The July 2026 brief itself** → the grounding brief quoted from the document, not from your summary.
- **Your CV, if it differs from your message** → moves quotes from your message to your CV. An anonymised extract of the complaints log, or the spreadsheet's column headings, would give the panel something to inspect and would lift F2, F3 and F5 from medium toward high. Remove any member details first.
- **Your pay figure, notice period, base and reason for leaving** → fills logistics slots A5 to A8 in your own words.
- **A deeper research pass (L2)**: up to 6 more searches and 2 more fetches, several minutes. It would cover loop reports for Ashgrove and recent leadership or reorganisation news. Want it?
