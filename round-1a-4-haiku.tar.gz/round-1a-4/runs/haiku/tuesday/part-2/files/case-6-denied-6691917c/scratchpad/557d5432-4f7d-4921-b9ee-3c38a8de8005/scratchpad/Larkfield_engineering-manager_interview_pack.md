# Interview prep pack: Engineering Manager, Larkfield Systems (loop of three)

Role: Engineering Manager, Larkfield Systems (industrial IoT, ~600 people). Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap.
Candidate: Yusuf.
Rounds: (1) Tuesday, 45 min, hiring manager (Director of Engineering). (2) Thursday of the following week, 60 min panel: two staff engineers and a product manager. (3) Following Monday, 30 min, VP Engineering, framed by the recruiter as "values and leadership philosophy."

Interviewer names are not known, so no interviewer read is included.

## 1. How to use + type key

Personas are how a question arrives. Types are what is being scored.

| Type | Meaning |
|---|---|
| VAL | Behavioral / values alignment: whether past behavior shows the values the round names |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny |
| JD | Role / JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack; see section 13) |
| CASE | Hypothetical / live problem from the role |

Guidance is scaffolding, not a script. Rehearse the beats in your own words. Where guidance says "answer slot," the honest answer is either branch the slot gives you.

## 2. Prep triage

Prep time is not stated, so this order is by round and by weight.

1. **Before Tuesday:** A4 (the hardware-roadmap objection), A6 (the 60% figure), A9 (the "how much was actually you" probe). These are the three most likely to be asked, and the ones where an unrehearsed answer costs the most.
2. **Before Thursday:** B1 and B2 (the counting probes), B3 (the seam question), B6 (the hardware objection, asked by product).
3. **Before Monday:** C1 (the unpopular-truth story), C5 (hiring attribution), C7 (the leadership-philosophy question).

Everything else is insurance.

## 3. Shared fit snapshot

Requirements come from the role description you pasted, quoted exactly. Evidence comes from your own sentences, quoted exactly. No JD was supplied, so the requirement column is the role description, not a posting.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role description you pasted) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material says one team of six, not two squads. Bridge: "For three years I was team lead of six." Answer slot: if you set any part of how the work was split across two groups, say which and how; if not, say so and stay with the team of six. |
| F2 | "own ... hiring ... for 11 engineers" (role description you pasted) | "I run our hiring loop for backend roles — about 40 interviews last year" (your message) | medium | [grounded] | transferability | Your hiring is backend-only and the material shows no team of 11. Bridge: "I run our hiring loop for backend roles." Answer slot: if you owned any decision in the loop beyond running it, say which. |
| F3 | "own ... delivery" (role description you pasted) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on the figure. Keep it at its own scope: the 60% followed a quarter you pushed through. |
| F4 | "own ... growth for 11 engineers" (role description you pasted) | "none given" | none given | [grounded] | discovery | Your material does not show growing people. Answer slot: if you have developed engineers to a next level, say what you did and who; if not, say so and say how you would start. |
| F5 | "partner with hardware and product on roadmap" (role description you pasted) | "pushed a reliability quarter through against roadmap pressure" (your message) | low | [inferred] | transferability | Your material shows you held a roadmap against pressure, not partnership with hardware. Bridge limit: the roadmap pressure came from the roadmap side. Do not extend the quote to hardware partnership. |
| F6 | Hardware-adjacent roadmap ownership (implied by "partner with hardware ... on roadmap") | "I've never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Stated negative. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F7 | People who manage managers (implied by "lead two squads" and "11 engineers"; whether there are leads under you is not stated) | "I've never managed managers." (your message) | none | [grounded] | capability | Stated negative. Words: "I haven't managed managers." Then how you would work with leads, said as a plan. Pending your answer to question 3 below. |
| F8 | "device-management services" (role description you pasted) | "currently at a payments company" (your message) | low | [inferred] | transferability | Payments backend is adjacent work. Your material shows no device work. Bridge limit: payments is adjacent, not device. |
| F9 | Location, on-site days, travel (not in the role description; the material says nothing about it) | "none given" | none given | [generic] | hard_gate | Your material does not establish this gate. The one question allowed is question 1 below. |

Seven rules: confidence, provenance and gap type hold one token each; evidence is your words only; the gate in F9 is surfaced, never bridged.

## 4. Prohibited claims

These are not to be coached. Each entry has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "Led two squads" | Inflated form of F1 | "For three years I was team lead of six." Limit (pack's own observation): the material says one team of six. |
| "Managed 11 engineers" or "grew managers" | Inflated form of F2 and F4 | F2's quote at its own scope. F4's answer slot. |
| "Owned a hardware roadmap" | Stated negative, F6 | "I haven't owned a hardware-adjacent roadmap." |
| "Managed managers" | Stated negative, F7 | "I haven't managed managers." |
| "The 60% was all mine" | Inflated form of F3 | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Limit: the material does not say which parts of the quarter were yours. Answer slot in A9. |

## 5. Round 1: hiring manager (Tuesday, 45 min)

**Persona weights.** Relationship prior for a hiring manager is Case/Strategist plus Skeptic. They are buying capability and derisking the gaps in F6 and F7. Weights: Skeptic 40, Case/Strategist 35, Pressure 15, Conversational 10 (the opener only).

**Highest-ROI prep in the pack:** A4, the hardware-roadmap objection (F6). It will almost certainly be asked. The rehearsed answer is a plain acknowledgment and a plan, not a claim.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about the team you've led for three years." | EXP | [grounded] "3 as a team lead of 6" (your message) | Team of six, three years, in those words. Name the one thing that team delivered that you can describe end to end. Answer slot: if you cannot name one, name the reliability quarter, which is your sentence. | Opener. F1 is the evidence. |
| A2 | "Two squads, both building device-management services. What do you do in the first 90 days?" | CASE | [grounded] "Lead two squads building device-management services" (role description you pasted) | Clarify first: what each squad owns, what is committed, who you depend on. Structure before answering. Make no claim about your past. | A live problem from the role. [grounded] for the requirement quote. |
| A3 | "Hardware ships a gateway next quarter and firmware is late. Product wants the device-management API anyway. How do you decide?" | CASE | [generic] | Structure it: what each side is committed to, what the dependency is, the options, the one you would test first. Make no claim about your past. | Tests the hardware partnership the role names. [generic] because it is a pattern, not a fact about this team. |
| A4 | "You've never owned a hardware-adjacent roadmap. Why would this go well?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." (your message) | Hold: "I haven't owned a hardware-adjacent roadmap." Then how you would learn the domain, as a plan. Hold through two follow-ups by returning to the plan. Concede the gap plainly if pressed. Never describe hardware experience. | F6 is the stated negative and the likeliest probe. Plain acknowledgment, no slot. |
| A5 | "Your note says you've never managed managers. Where does that show up in this role?" | JD | [grounded] "I've never managed managers." (your message) | Acknowledge: "I haven't managed managers." Then how you would work with leads, as a plan. Do not describe managing leads. | F7. The question presupposes the negative you stated, so it is sourced. |
| A6 | "Your team's on-call burden dropped 60%. How was that counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Defend the number. Say how it was counted, in your words. Name the assumption you would defend least before they do. Answer slot: which part of the quarter was yours to set, and which was the team's. If you do not know how it was counted, say so. | F3. A figure you gave raises these four defend-the-number slots and no others. |
| A7 | "You ran the backend hiring loop, about 40 interviews last year. What part was yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" (your message) | Say what you ran and what you decided, in your words. Answer slot: which decisions were yours (the scorecard, the bar, the offers) and which were set by others; if you did not set one, say so. | F2. Do not turn "run the loop" into "designed the process." |
| A8 | "The role owns growth for 11 engineers. How would you grow people you have not yet managed?" | JD | [grounded] "own ... growth for 11 engineers" (role description you pasted) | Plan language only. Describe how you would find out what each person needs and how you would check progress. | F4. The question presupposes a requirement from the role description, which is a raising source. |
| A9 | "That result — how much of it was actually you?" | Pressure stem | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Hold-then-concede. Hold: you pushed the quarter through. Two follow-ups later, concede specifically: name the parts that were the team's, not yours. Do not fold on the core claim to restore harmony. | Pressure persona, on F3. The rehearsal is precision under pushback. |

**Requirement coverage for round 1:** "Lead two squads" → A2, F1; "own hiring" → A7; "own delivery" → A6, A9; "own growth for 11 engineers" → A8; "partner with hardware and product" → A3, A4.

**Reverse questions (at least 5).**
1. "What does reliability look like on these two squads today?" — It lets you return to the 60% result from your own material.
2. "Where does the boundary between hardware and the squads sit right now?" — It shows you have looked at the hardware dependency.
3. "What would you need from an engineering manager in the first 90 days that you are not getting now?" — It turns the gap into a plan.
4. "How is roadmap decided between hardware, product and the squads?" — It is the question an EM in this role needs answered.
5. "What would success look like for these two squads at the end of year one?" — It names the outcome they are scoring.

## 6. Round 2: panel (Thursday, 60 min)

**Persona weights, by member.** Names are not known, so weights are blended by relationship. Staff engineers are Peer Evaluator plus Data-Driven Prober. The product manager is Peer Evaluator plus Case/Strategist. Overall weights: Peer Evaluator 40, Data-Driven Prober 25, Case/Strategist 20, Conversational 15.

Reciprocity question is required: a panel with peers.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 60% on-call drop was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Say the count in your words. Name the weakest assumption. Answer slot: which parts of the count were yours. | F3, probed by the staff engineer. |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Name the assumption in one sentence. If you have no list of assumptions, say the figure is from your team's own count and say which one you are least sure of. | Prober stem on the same figure. |
| B3 | "Our teams sit side by side — where's the seam, and what happens when we disagree?" | Peer | [generic] | Propose seam principles, not facts about their team. Answer slot: a disagreement you had with a peer, in your words, and how it ended. If you have none, say so. | Peer Evaluator stem. [generic] because it is a pattern. |
| B4 | "How do you handle credit when work spans teams?" | Peer | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Describe what you did, not what the result proves. Say whose work the reliability quarter was, in your words. | Peer stem, on F3. |
| B5 | "Product wants a feature the hardware team can't commit to this quarter. What do you do first?" | CASE | [generic] | Structure: what each side is committed to, the constraint, the options. Make no claim about past roadmaps. | Product's live problem. |
| B6 | "You've never owned a hardware-adjacent roadmap — which decisions would you need product to carry?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." (your message) | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then the decisions you would need from product, as a plan. | F6, asked by product. |
| B7 | "Tell me about a time roadmap pressure and reliability pulled in opposite directions." | JD | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt. Story-map the quote: roadmap pressure, the reliability quarter, the outcome in the 60%. Answer slot: what the roadmap side said, if you can say it, and what you did about it. | F5. The theme comes from the role's roadmap partnership. |
| B8 | "Telemetry is going stale for one customer's sites. Diagnose it." | CASE | [generic] | Clarify the symptom, scope and timing first. Structure the hypotheses. Make no claim about past incidents. | A live problem in device management. |
| B9 | "How did your hiring loop decide?" | Prober | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" (your message) | Describe the decision process you ran. Answer slot: if you set how interview signals were scored, say so; if not, say so and say who did. | F2. "Decide" is the probe. Do not assume a scorecard existed. |

**Requirement coverage for round 2:** "Lead two squads" → B5, B8; "own hiring" → B9; "own delivery" → B1, B2; "partner with hardware and product" → B5, B6, B7; "growth for 11 engineers" → none in this round, and why: covered in round 1 (A8).

**Reverse questions (at least 5, including one reciprocity).**
1. "What could a new person do in their first month that would genuinely help your team?" — Reciprocity. It asks what you bring to their work, not only what you need.
2. "Where do the two squads' work and yours collide today?" — It shows you looked for the seam.
3. "How do you decide when reliability work and a feature compete for the same engineers?" — It is the question your 60% result answers.
4. "What is the hardest product-hardware trade-off you have made this year?" — It asks the PM directly.
5. "How do the staff engineers want to be involved in roadmap decisions?" — It maps their load.

## 7. Round 3: VP Engineering (Monday, 30 min)

**Values-style round.** The recruiter's words, "values and leadership philosophy," document a values round, so VAL questions are in scope.

**Values cheat sheet: not included.** No published values page was read. The search for it was refused (see section 13), so the cheat sheet's condition does not hold. Upgrade: send the published values.

**Persona weights.** Values/Behavioral 50, Pressure 30 (skip-level), Case/Strategist 20 (altitude).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt. Pick the instance that fits. Story-map the quote: the pressure, the quarter, the result. Answer slot: what leadership said and what you did next, in your words. If no unpopular truth comes to mind, say so plainly, then give the reliability quarter and say what was hard about it. | F3 is the nearest sentence you have. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer outcome and an internal number pulled apart. If none comes to mind, say so plainly, then describe the nearest thing your material carries: the reliability quarter. | Values pattern. No claim about a customer you did not state. |
| C3 | "What is the leadership philosophy you'd bring to two squads?" | VAL | [grounded] "Lead two squads building device-management services" (role description you pasted) | Say the philosophy in one sentence, then point to one decision that shows it, from your own material. If none does, say so. Do not borrow a philosophy the material does not carry. | The recruiter named this round. |
| C4 | "Sixty seconds: why you over an internal candidate?" | Pressure stem | [grounded] "3 as a team lead of 6" (your message) | Hold: the team you led and the years. Do not compare yourself to an internal candidate you have not met. | Pressure stem. Hold on the stated fact. |
| C5 | "Your hiring loop — how much of it was actually you?" | Pressure | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" (your message) | Hold: you run the loop. Two follow-ups later, concede the parts others set. Answer slot: which decisions were yours. | F2, Pressure persona. |
| C6 | "Two squads disagree whether to cut scope to protect hardware dates. How do you lead it?" | CASE | [generic] | Structure: what each side needs, the date and its cost, the options, the decision owner. Make no claim about your past. | Altitude question on the role's hardware dependency. |
| C7 | "Describe the leadership philosophy you hold when a senior engineer and product disagree about scope." | VAL | [grounded] "partner with hardware and product on roadmap" (role description you pasted) | Selection scaffold. Name one time you held a scope line with a senior peer; if none, say so, then describe how you would handle it. | The recruiter's "leadership philosophy" frame. |
| C8 | "Tell me about a time your values and a business decision pulled apart." | VAL | [generic] | Selection scaffold: pick a value you held and a decision that tested it. If none comes to mind, say so plainly, then describe the nearest one your material carries. | Values pattern. |

**Requirement coverage for round 3:** "Lead two squads" → C3, C6; "own hiring" → C5; "own delivery" → C1; "partner with hardware and product" → C6, C7; "growth for 11 engineers" → C8 is a values prompt, not growth; none for growth in this round, and why: covered in round 1 (A8).

**Reverse questions (at least 5).**
1. "What does this organisation value in its engineering managers that it is not yet getting?" — It asks where they are short.
2. "How do you want leadership philosophy to show up in an EM's first quarter?" — It makes the philosophy concrete.
3. "What did the last EM in this role get right, and what would you change?" — It asks for their candour.
4. "Where do you want the two squads in twelve months?" — It keeps you at their altitude.
5. "What would make you say in six months that the hire was a mistake?" — It asks for their risk.

## 8. Sources

Provided documents: the role description and background in your message. No JD, no published values page, no interview guide, no interviewer name.

| Query | Result |
|---|---|
| "Larkfield Systems values" | refused |
| "Larkfield Systems interview process engineering manager" | refused |
| "Larkfield Systems industrial IoT news strategy" | refused |

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Values cheat sheet, section 10; search refused, so nothing was used |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Loop structure. Round order here comes from your message, not a loop source |
| 3. `Larkfield Systems strategy` / recent news | unavailable | CO questions. None included |
| 4. `{interviewer name} Larkfield Systems` | n/a | No name given |
| 5. representative `engineering manager` JD | skipped | The role description you pasted fixes the requirement rows |

## 9. Upgrade menu

- The full job posting → every requirement becomes a quoted, `[grounded]` row, not a summary
- Interviewer names → per-member persona weights, an interviewer read, and tailored reverse questions
- Recruiter's note on the panel's focus areas or any take-home or presentation → a graded-deliverable section
- The published values page → a values cheat sheet and sharper VP questions
- Any company strategy brief or recent news you have → CO questions in rounds 1 and 3
- Answer to question 1 (site, hybrid or remote, and travel) → resolves gate row F9
- Answer to question 3 (whether there are leads under you) → resolves F7 and adds leadership questions to round 1
