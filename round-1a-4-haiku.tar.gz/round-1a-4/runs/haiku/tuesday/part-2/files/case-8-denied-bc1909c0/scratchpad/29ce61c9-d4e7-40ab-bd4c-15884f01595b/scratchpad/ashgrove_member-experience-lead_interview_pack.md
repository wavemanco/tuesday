# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Rounds:** 3 December 2026. Recruiter screen (30 min); Head of Member Services, who would be your manager (45 min, mostly behavioural); panel of two branch managers (60 min, including a 20-minute complaint-escalation case, scored against the four values).
**Interviewers:** not yet assigned beyond the roles above.
**Built on:** the job description, the recruiter's round outline, the four values as you copied them from ashgrovecu.org on 24 November 2026, your summary of the July 2026 strategy brief, and your background as you described it. Your CV was not provided, so all candidate evidence below comes from your message.

## 1. How to use this pack and the type key

Personas are how a question will arrive. Types are what it is scoring.

- **VAL**: values alignment. Does past behaviour show one of the four published values?
- **EXP**: your own experience. Do your claims hold up when someone asks about them?
- **JD**: the job's stated requirements. Can you do the listed job, gaps included?
- **CO**: Ashgrove's current strategy and context.
- **CASE**: a live problem set in the role, worked through out loud.

Guidance is scaffolding for a spoken answer, not a script. Where a row says "answer slot", the honest answer is part of the answer. Give it in your own words.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as branch supervisor" — your message | medium | [grounded] | none | No gap. Say the years and the branch role in your own words. Your message is the only source so far, so expect a request for your CV to check dates. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material shows formal complaints, not the rules they had to meet. Answer slot: if the log carried set timelines or rules, name them and how you tracked them; if it did not, or you were not the one who tracked them, say so, and say how you would find out what applies at Ashgrove. |
| F3 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Words: "I haven't presented to anyone above regional level." Then the plan, said as a plan and never as a past: what you would prepare and whom you would rehearse with. Never claim presenting experience above regional level, and add nothing to make the gap feel smaller. |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you built a spreadsheet a manager uses monthly. Say "spreadsheet", and say "Excel" only if that is what it was. Add no formulas or macros you did not build. The measures under it belong to D1, not this row. |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote touches monthly reporting without showing whether it carried volumes or resolution times. Answer slot: if it carried either, say which and how each was counted; if it carried neither, say so and say what you would add first. |
| F6 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Adjacent work: one branch's log, not the process end to end across branches. Words: "I handled the branch's formal complaints log." The limit is the pack's observation: your material shows one branch. Answer slot: which parts of the process beyond the log you would take on from day one. |
| F7 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | Words: "I haven't worked in a contact centre." Then the plan for learning the contact-centre side of the process, said as a plan. |
| F8 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | low | [inferred] | transferability | Training tellers is adjacent to coaching supervisors. Your material does not show coaching anyone on escalations. Answer slot: if you coached a colleague on an escalation, say how; if not, say so and say how you would coach a supervisor on one. |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | No material shows digital or self-service work. Answer slot: if you worked with a digital or self-service team, say what you did; if not, say so and say what you would look at first in a member's complaint about the app. |

The snapshot's rules are in `references/output-template.md`: one token per enum cell, verbatim quotes only, and gap types chosen by the routing rule there.

## 3. Prohibited claims

These are the claims this pack will not coach. Each entry gives its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Presented to senior leaders | Negative you stated, F3 | "I haven't presented to anyone above regional level." No slot. |
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F6 and F7 | F6's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's own observation: your material shows one branch and no contact centre. |
| Knew which rules the complaints log had to meet | Inflated form of F2 | F2's quote at its own scope. Answer slot only. |
| Tracked resolution times in the spreadsheet | Inflated form of F5 | The spreadsheet quote at its own scope. Answer slot only. |
| Coached branch supervisors on escalations | Inflated form of F8 | F8's quote at its own scope. Answer slot only. |

## 4. Values cheat sheet

The panel scores against the four values (recruiter's email), so this section is included. The values are the wording you copied from the site.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | None of your quoted sentences carries a member decision. Selection scaffold, with its honest branch, in bank A1. Nearest material: F6, "I handled the branch's formal complaints log." |
| Plain Words | If a member needs it explained twice, the wording was wrong. | None carries a plain-words story. Selection scaffold in bank A2. Nearest material: F8, "trained new tellers on our escalation script." |
| Neighbours, Not Numbers | Every branch is part of its town. | None carries a local-branch story. Selection scaffold in bank A3. Nearest material: F4, "I built the monthly complaints spreadsheet our regional manager uses." |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Partly carried by F6, "I handled the branch's formal complaints log." The end point is an answer slot in bank A4. |

## 5. Grounding brief

Source: your summary of the July 2026 strategy brief (I have not read the brief itself). Live research was refused this session (Section 9), so nothing here is checked against outside sources.

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- The main competitive pressure is app-only banks.

Use the company's own terms, such as "member service" and "hubs". Be careful with any framing about the branch network: the brief is about consolidating branches, and that sits next to the value "Neighbours, Not Numbers" in the panel.

## 6. Persona table

Round weights, from the recruiter's outline and the relationship priors in `references/personas.md`:

- **Round 1, recruiter (30 min):** conversational, with a light skeptic. The logistics questions (pay, notice, location, reason for leaving) get the recruiter's own form. Give your actual figures and reasons, in your own words.
- **Round 2, Head of Member Services (45 min):** values and behavioural, with a skeptic. The recruiter said mostly behavioural, so I weighted the case persona below its usual prior.
- **Round 3, panel (60 min):** values and behavioural (scored), case (the 20-minute escalation), peer (branch managers, the seam with the contact centre), and pressure (managers probing your numbers).

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (A) | Scenario probes mapped to the four values; STAR-shaped answers expected. | Top weight. The panel scores the values, and the Head of Member Services round is mostly behavioural. | One story per value where the material carries one; a selection scaffold with its honest branch where it does not. "We" for context, "I" for what you did. |
| Skeptic (B) | Quiet, persistent probing of the gaps: presenting above regional level, contact centre, digital work, regulated rules. | Weight raised above the mid tier, because F2, F3, F7 and F9 are the JD's biggest gaps. | Rehearse the presenting question until it is plain. Say the stated limit once, then your plan. |
| Case / Strategist (C) | A live escalation problem, plus strategy questions tied to the brief. | Mid weight. The 20-minute case is in round 3, and the strategy questions are likely in round 2. | Clarify, then structure. Think aloud. Use the company's own vocabulary. |
| Pressure (D) | Probing the spreadsheet's numbers and your part in them; holding a position under follow-ups. | Mid weight. The panel of branch managers is where numbers get checked. | Defend what you built. Name the weakest assumption before they do. Concede what you cannot say. |
| Conversational (E) | Friendly openers: "walk me through the journey", "what draws you here". | Low weight in the panel and manager rounds, but the recruiter round runs on it. Casual questions are still scored. | A 90-second arc for the journey. Treat the "why" question as scored. |
| Peer Evaluator (F) | Seam questions between branches and the contact centre; disagreement with equals. | Low weight. The panel branch managers are your likely peers. | Propose seam principles rather than pretending to know the seam. Show reciprocity. |

## 7. Question banks

Each row's Provenance lists the sentences its guidance rests on. A question that says "answer slot" asks for an honest answer in the interview, not a reply here.

### A. Values / Behavioral (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about a time you put a member's outcome ahead of the process." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a time a member's situation did not fit the procedure and you chose what was fair within your authority. Say what the member had before and after. Answer slot: if no such time comes to mind, say so plainly, then give the nearest thing your material carries, the complaints log, and say which cases were yours to decide. | Members First, Always. Nothing you have stated carries a member decision yet, so the honest branch is the expected answer. |
| A2 | "Tell me about a time an explanation you gave had to be heard twice. What did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a time your first explanation did not land and what you changed in the wording. Answer slot: if no such time comes to mind, say so, then say what the escalation script asked tellers to say and whether you checked they had it right. Say only what you did. | Plain Words. Nothing you have stated carries a plain-wording story. |
| A3 | "When did a number you were reporting hide something about a branch or a member?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if the spreadsheet's numbers ever hid a branch's local situation, say what they hid and what you did. If they did not, say so and say what the numbers could not show. | Neighbours, Not Numbers. Use the spreadsheet as the link to a real answer. |
| A4 | "Tell me about a complaint you kept hold of until it was solved. What did solved mean?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on the log: you handled it. Answer slot: whether a case stayed with you to the end or passed on at a step. If it passed, say to whom and what you stayed responsible for. If it stayed, say what the end point was and how you confirmed it. | Own the Fix. The log is the story's setting; the end point is the part you have not stated. |
| A5 | "When did you take a number to your regional manager that they did not want to hear?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if you did, say what it showed and how they responded. If the spreadsheet never showed anything they did not want, say so and describe the nearest time you raised a problem upward. | Behavioural probe on the value Own the Fix, aimed at your manager's view of the numbers. |

### B. Skeptic (weight: above mid, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never presented above regional level. What would you do the first time you presented to a senior leadership team?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan, said as a plan: what you would prepare, whom you would rehearse with, and what the first slide would say. Hold the plan through two follow-ups. Do not claim presenting experience above regional level. | This is the highest-return prep in the pack. F3 is the largest gap, and the JD asks for presenting to senior leaders. Expect it in some form. |
| B2 | "The job covers branches and the contact centre. What do you know about the work in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I haven't worked in a contact centre." Then what you would learn first, said as a plan. Answer slot: if you have had any contact with contact-centre work, say what it was; if not, say so. | F7. The JD names the contact centre, and you stated the absence. |
| B3 | "The job works with digital teams on self-service journeys. Where has your work touched a digital or self-service channel?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Answer slot: if any of your work touched a digital or self-service channel, say what and what you did. If none did, say so, and say what you would look at first in a member's complaint about the app. | F9. No material shows digital work, so the honest branch is the expected answer. |
| B4 | "The job is about regulated complaints. What did the complaints log have to meet, and how did you know you had met it?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: if the log carried set timelines or rules, name them and how you tracked them. If it did not, or you were not the one who tracked them, say so, and say how you would find out what applies at Ashgrove. | F2. The question presupposes rules your material does not state, so the second branch is allowed. |

### C. Case / Strategist (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member's complaint about a disputed charge has been escalated for a second time. The branch says the charge was right; the member says they were misled. You have twenty minutes. What do you do?" | CASE | [generic] | Structure: clarify what the file shows, what was said at each stage, and which deadlines apply, confirmed rather than assumed. Objective: the member's outcome, a fix that holds, and what the branch learns. Segmentation: one case, or a pattern? Check other escalations on the same charge. Approach: who decides, what the branch manager owns, how you explain the outcome plainly to the member. Metrics: time to resolution, repeat escalations. Risks: member harm, a wrong answer that repeats, regulatory exposure. This is a generic practice case; the panel's real case may differ. | The round 3 case. A problem set in the role, so it claims nothing about your past. |
| C2 | "Ashgrove plans to move 40% of member service to digital channels by 2028. How do complaints change when that happens?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the brief) | Name which complaints move with the channel, which members still come to a branch, and what must stay human. Name one measure you would watch. No claim about your past. | The brief is the company's stated direction, so the question is fair to ask. |
| C3 | "Eight branches are consolidating into five hubs over 2027. Where does complaint handling sit for a member whose branch closes?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the brief) | Open cases follow the member, not the building. Name the handover of open complaints, the member's new route, and how "Neighbours, Not Numbers" holds in a town that loses its branch. No claim about your past. | The branch network is the sharpest strategy question for someone who has run a branch. |

### D. Pressure (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That spreadsheet your regional manager uses: which measures did it carry, and how were they counted?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Defend the number in your own words, four slots: how it was counted; what it is sensitive to; the assumption you would defend least; which part was yours. Hold what you built. Concede what you cannot say. Answer slot: if the spreadsheet carried resolution times, say how they were counted; if not, say so and say what you would add. | JD content (monthly reporting, Excel reporting), pressure delivery. Covers F4 and F5. |
| D2 | "You trained tellers on the escalation script. How did you know it worked?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: if you measured whether tellers used the script correctly, or whether escalations changed, say what and how. If you did not measure it, say so and say what you would measure now. | EXP because it tests what you actually saw. The question presupposes a result your material does not state. |
| D3 | "You trained tellers on the escalation script, and you spent three years as a branch supervisor. The job asks you to coach supervisors on escalations. What is different, and how would you do it?" | JD | [grounded] "6 years in retail banking, the last 3 as branch supervisor" and "trained new tellers on our escalation script" | Answer slot: if you coached a colleague on an escalation, say how. If not, say so, and say how you would coach a supervisor on one. Do not describe coaching you did not do. | F8. JD content, pressure delivery. |

### E. Conversational (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "6 years in retail banking, the last 3 as branch supervisor" | A 90-second arc: the six years, the last three as supervisor, the complaints log, then why this role. Each beat is a clause the quoted sentence states. | JD content (customer operations years), conversational delivery. Scored even though casual. |
| E2 | "What draws you to a member-owned credit union?" | CO | [grounded] "member-owned" (JD) | Answer from your own reason. If the reason rests on your experience, say which part; if not, say what draws you without claiming more. | The recruiter round tests the why. "Member-owned" is in the JD. |

### F. Peer Evaluator (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Branch managers and the contact centre sit side by side. Where's the seam between a branch complaint and a contact-centre complaint, and what happens when we disagree?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD) | Propose seam principles rather than pretending to know the seam. Reciprocity: what you would bring to their teams. Answer slot: if a manager disagreed with you about a complaint's outcome, say how it ended. If none, describe how you would settle it and what you would put in writing. | F6 and F7. The panel's branch managers are likely peers. |
| F2 | "When a fix needs a branch to change how it works, how do you get that done without it becoming your fight?" | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a time a fix needed another team to change. Say what you asked for, who decided, and who got the credit. Answer slot: if none comes to mind, say so, then say how you would make the request to a branch manager. | Own the Fix, with credit-sharing. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | E1 |
| Experience handling regulated complaints | B4 |
| Confident presenting to senior leaders | B1 |
| Comfortable with Excel reporting | D1 |
| Monthly reporting on volumes and resolution times | D1 |
| Own the complaints process across branches and the contact centre | B2, F1 |
| Coach branch supervisors on escalations | D3 |
| Work with digital teams on self-service journeys | B3 |

Session total: 19 questions.

## 8. Reverse questions

1. "What does a good first ninety days look like on complaint volumes?" Why it lands: it shows you are already planning around the monthly report.
2. "Which of the four values do candidates most often struggle to show in the escalation case?" Why it lands: it shows you have read the scoring basis.
3. "When a branch joins a hub, how do its open complaints move?" Why it lands: it ties the consolidation to the work, and shows you read the brief.
4. "What could a new person do in their first month that would genuinely help your team?" Why it lands: reciprocity, aimed at the branch managers in round 3.
5. "How many of the escalations you see reach a second stage, and what usually causes that?" Why it lands: it asks about the work itself, which is what the case is about.

## 9. Sources

**Provided documents**
- The job description, as you pasted it.
- The recruiter's email, as you pasted it: three rounds, 3 December 2026, the panel scores against the four values.
- The four values, as you copied them from ashgrovecu.org on 24 November 2026. Not checked against the live site.
- Your summary of the July 2026 strategy brief. I have not read the brief itself.
- Your background, from your message.

**Research tier:** L1 — searches 2 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | unavailable | Would have checked the pasted values against the live site. Both searches were refused (see below), so the values are as you copied them. |
| 2. Interview process | skipped | The recruiter's outline already fixes the rounds and the panel's scoring, so no search was sent. |
| 3. Strategy / recent news | unavailable | Would have checked the brief summary for recent moves. Its call was refused. |
| 4. Interviewer name | n/a | No names were given, so there was no query to form. |
| 5. Representative JD | skipped | The job description you supplied fixes the fit snapshot and the JD-tagged questions. |

Queries sent:
- "Ashgrove Credit Union values member complaints digital branch hubs 2026": refused.
- "Ashgrove Credit Union strategy 2026 small business lending branch consolidation": refused.

## 10. Upgrade menu

- The names of the Head of Member Services and the two panel branch managers → personas weighted per interviewer, and reverse questions tailored to each person's public record.
- Your CV → the medium-confidence rows F1, F2, F4, F5 and F6 can move up or stay, and the dates in F1 can be checked.
- The 20-minute case's subject, if the recruiter will name it → C1 becomes a specific case, not a generic one.
- The answer to F5 (did the spreadsheet carry volumes or resolution times, and how were they counted) → D1 and F5 become answered.
- A live research pass on Ashgrove's recent news and the public interview process (this session's searches were refused) → C2 and C3 can be checked against recent statements, and the loop can be confirmed beyond the recruiter's outline.
- Deep research (L2) on the strategy talks, interviewer writing and recent loop reports, if you want it → needs the search permission above as well.
- `tuesday-dossier.md`, if you keep one from earlier prep sessions → it would carry any gaps this pack exposed into later sessions.
