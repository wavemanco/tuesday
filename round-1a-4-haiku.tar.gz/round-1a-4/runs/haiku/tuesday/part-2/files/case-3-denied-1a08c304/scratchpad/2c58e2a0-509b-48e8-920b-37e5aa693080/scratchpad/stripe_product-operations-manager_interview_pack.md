# Stripe: Product Operations Manager, final round. Interview pack (first version)

Role: Product Operations Manager. Company: Stripe. Interviewer: not named. Round: final round, format and relationship not yet stated. Built from the role title alone, with no posting, no CV and no research (see Sources). Every requirement below is a role-family pattern, so every provenance label is `[generic]` unless noted.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values), EXP (your past work), JD (the listed job), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Where the guidance says "if none comes to mind, say so," that is a real option. Use it.
- Nothing below says what you have done. Where a question asks about your past, the guidance gives a selection scaffold, and you fill it from your own experience.

## Fit snapshot

No posting and no CV were supplied, so this is the worksheet variant. Each row is a role-family requirement, not a Stripe requirement. Your evidence cells are empty until you paste your materials.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Running cross-functional processes end to end (role family) | none given | none | [generic] | discovery | Answer slot: name one process you ran across teams from start to finish. Say which steps were yours to set and which were set for you. If you have not run one end to end, say so, and name the nearest step you did own. |
| F2 | Designing or changing an operating process that people adopt (role family) | none given | none | [generic] | discovery | Answer slot: name one process you changed and what made people use it or resist it. If you have not changed one, say so, and describe how you would approach the first one. |
| F3 | Metrics, dashboards and measuring whether a change worked (role family) | none given | none | [generic] | discovery | Answer slot: name one measure you tracked and how you would know if it was misleading. If you did not track a measure, say so, and say what you would measure first. |
| F4 | Prioritizing competing requests from several stakeholders (role family) | none given | none | [generic] | discovery | Answer slot: describe one time you chose between competing requests. Say who decided, and what you did when the decision was not yours. |
| F5 | Launch and rollout readiness (role family) | none given | none | [generic] | discovery | Answer slot: name one launch or rollout you helped run. Say what you checked before it went live, and what you would have rolled back on. |
| F6 | Location, work authorization, on-site schedule (posting, not yet seen) | your material does not establish this | none | [generic] | hard_gate | Surfaced, not bridged. Confirm these against the posting before the interview. |

Gate row F6 is a placeholder. Once the posting is pasted, its actual gates replace it.

## Persona weights

No relationship is stated, so the weights are flat with the archetype tilt below. A final round usually bundles several conversations, so no single persona dominates.

| Persona | Weight | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Highest (5 questions) | Live operational problems | High. Product ops is judged on structure under live problems. | Clarify before you structure. State the decision owner, then the approach. |
| Values / Behavioral | High (4 questions) | Open "tell me about a time" prompts | High if a values-style round exists. This is the archetype fallback, not a documented Stripe loop. | Use "we" for context and "I" for what you did. Choose a time when the hard part landed. |
| Data-Driven Prober | Mid (3 questions) | Follow-ups on any number you name | Medium. Depends on whether you quote figures. | Name the weakest assumption before they do. Say plainly what you do not know. |
| Skeptic | Mid (3 questions) | "Why ops, why here, why now" and the gaps | Medium. Common in final rounds. | Rehearse the single predictable objection until it is calm. |
| Peer Evaluator | Low (2 questions) | Seam questions from a PM or engineering lead | Conditional. Only if a peer sits on the panel. | Propose seam principles. Do not pretend to know the seam. |
| Conversational | Low (2 questions) | Casual opener, "walk me through your journey" | Medium. Treat casual questions as scored. | Have a 90-second arc ready. |

Weights rest on the role archetype (big-tech structured loop, in the fallback table of the research reference), not on a documented Stripe loop. That is the honest status of these weights.

## Question banks

Provenance is `[generic]` throughout because no candidate sentence was supplied. No row claims anything about your past.

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch you're running goes live Monday, and on-call flags a rising error rate in one region. What do you do?" | CASE | [generic] | Clarify severity, scope and who makes the go/no-go call. Name the rollback criterion before you discuss a fix. Say who gets told, and when. | Launch-readiness is a core ops problem; structure and decision rights are what it scores. |
| A2 | "Two product teams want the same engineering quarter. How do you decide?" | CASE | [generic] | Name the decision owner first. Then the criteria, the stakeholders you would consult, and the tradeoff you would write down. | Prioritization across teams is a usual part of the job family. |
| A3 | "A metric your team tracks dropped 20% in a week. Walk me through diagnosing it." | CASE | [generic] | Segment before you hypothesize. Check whether the metric itself changed before you chase a cause. | Diagnosis under ambiguity is the usual shape of a live case. |
| A4 | "How would you design an intake process for product requests coming from ten teams?" | CASE | [generic] | Ask about volume, what is urgent, and who triages. Then propose one process, with a way to tell whether it works. | Intake design is a common ops-design prompt. |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time your view went against the plan. Name the stake, the moment you did not fold, and whether the relationship held. If none comes to mind, say so, then give the nearest case you have. | Open prompt on a common behavioral theme. |
| B2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time a customer outcome and an internal number pulled in different directions. Say which you chose, and what you gave up. If you have not faced this, say so, then describe how you would weigh it. | Stated as a stem in the persona reference. |
| B3 | "Tell me about a process you changed that people resisted." | VAL | [generic] | Name the resistance in their words. Say what you did about it: talked to people, changed the process, or dropped it. | Process change is the core of the job family. |
| B4 | "Tell me about a project you coordinated that slipped. What did you do next?" | VAL | [generic] | Say what slipped, when you found out, and what you told people. The recovery is the part they score. | Slippage is common. How people respond to it is scored. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you measure whether a process change actually worked?" | EXP | [generic] | Name the metric, the baseline, and the comparison group. Name the assumption you would defend least. | Measurement is part of the role. |
| C2 | "Pick a number you have reported in past work. How was it counted?" | EXP | [generic] | Pick a figure you can explain. Say how it was counted and what it is sensitive to. If you cannot say how it was counted, say so plainly. | Open prompt. Any figure you give raises this follow-up. |
| C3 | "How would you know your ops dashboard was misleading you?" | JD | [generic] | Name a check: a second source, a sanity range, a known blind spot. | Dashboards are a common ops deliverable. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the weakest area you can find in the posting once you have it. Say what you would do about it in the first month. Do not claim strength you have not shown. | The predictable objection for someone without a PM or ops title, once it is confirmed. |
| D2 | "Why operations rather than a product manager role?" | EXP | [generic] | Answer with the work you want, not the title you want to leave. If the reason is not fully formed, say what you want to learn. | Motivation question, common in final rounds. |

### Peer Evaluator (only if a peer sits on the panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our PMs and engineering leads disagree on priorities. How do you work with them?" | VAL | [generic] | Name how you would find where the disagreement actually sits. Propose a principle for the seam rather than a tidy answer. | Seam questions are how peers test partnership. |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name the credit you would give, and how you would make the contribution visible. | Common peer probe. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your journey into operations." | EXP | [generic] | A 90-second arc: the work, the turning point, and why this role. Keep it to what you did. | Casual openers are scored. |

## Values / principles cheat sheet

Dropped. Stripe's published values were not in hand: web search was refused this session, and the rule is that values come from research or documents, not memory. Paste the values page and this section can be built.

## Prohibited claims

Built from the fit snapshot. The snapshot holds no candidate sentences, so there are no inflated forms to list yet. The pack will not coach any claim about your past until you supply material. The one standing limit is the one the whole pack rests on: rehearse only what you did, in your own words.

## Reverse questions

Each question has a "why it lands" line.

1. "What does a strong first six months look like in this role?" Why it lands: it shows you are planning to own outcomes, not waiting for direction.
2. "Which cross-functional process here is most often the bottleneck?" Why it lands: it shows you think in processes, and it gives you a real problem to discuss.
3. "How does the team decide whether ops work is prioritized or handled ad hoc?" Why it lands: it surfaces how much of the role is planned versus reactive.
4. "How is success measured for this role, and which numbers would you look at first?" Why it lands: it asks them to name their scorecard, which sets up your measurement answers.
5. "What did the last person in this role leave behind that the team still relies on?" Why it lands: it invites an honest picture of the job's history and what they value.
6. Conditional. If your interviewer is a peer: "What could a new person do in their first month that would genuinely help your team?" Why it lands: it turns the conversation into a reciprocal one.

No interviewer-career-path question: no interviewer was named.

## Sources

No provided documents. Web search was refused by a permission prompt in this session, so no research was run.

Research tier: L1, searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet, section 10. Call refused: "Stripe company values operating principles". |
| 2. Stripe interview process, product operations | unavailable | Loop structure and persona weights. The call was refused, so the weights above rest on the archetype fallback. |
| 3. Stripe strategy or recent news | unavailable | CO bank and the strategy-grounded CASE question. No call sent; the host refused search after the first two calls. |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative Product Operations Manager JD | unavailable | Would have grounded the fit snapshot in a representative posting. No call sent; the host refused search. |

Two search calls were sent, and both were refused: "Stripe company values operating principles" (target 1) and "Stripe interview process final round product operations manager" (target 2). Both are counted in the tier line above.

## Upgrade menu

- The posting for this role → replaces the placeholder gate row F6 and the `[generic]` requirements with quoted `[grounded]` rows, and checks location, work authorization and schedule against what it actually says
- Your CV → turns the worksheet into a fit snapshot with quoted evidence, and lets the defend-the-number and story-mapped answers draw on your own sentences
- The interviewer's name, or a recruiter note on the final round's format → a tailored reverse question, persona weights from the interviewer's public footprint, and whether the round is one conversation or several sessions
- Stripe's values page, pasted → the values cheat sheet, and VAL questions mapped to your stories
- Web search allowed in this session → loop structure, recent strategy, and CO questions, all sourced rather than generic
- A deeper research pass, if you want it → up to 6 more searches and 2 more fetches, several minutes. Offered once.
