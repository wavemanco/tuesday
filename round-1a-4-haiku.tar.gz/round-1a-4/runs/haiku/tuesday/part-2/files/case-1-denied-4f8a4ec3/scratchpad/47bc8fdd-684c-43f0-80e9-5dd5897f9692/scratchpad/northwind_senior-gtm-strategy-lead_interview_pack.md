# Northwind Data: Senior GTM Strategy Lead, Emerging Products

Candidate: Priya. Interviewer: Dan Kovac, Director of Sales Strategy. He is a peer who reports to the same VP. Round: one 60-minute conversation. Session mode, first version.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script.

| Tag | Name | Scores |
|---|---|---|
| VAL | Behavioral / values | Past behavior against published values. None detected for this round. |
| EXP | Work-experience deep-dive | Whether your material's claims survive scrutiny, and what you actually did |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy | Homework depth and altitude on Northwind's priorities |
| CASE | Live problem | Structure and reasoning on a problem from the role. Asks nothing about your past. |

Labels: `[grounded]` traces to your message or research note. `[inferred]` is a derivation, named. `[generic]` is a role-family pattern with no claim about Priya or Northwind.

## Fit snapshot

The JD you supplied is highlights only. Its requirements are quoted from those highlights. No hard gate is stated in your material, so the gate question is in the upgrade menu.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "9 at a large consumer-tech company in product strategy & ops" (your message) | medium | [grounded] | transferability | Product strategy and ops is adjacent to owning launch GTM. Your material shows no go-to-market decisions for a launch, so the words stay at the scope of the quote. Answer slot: if you made go-to-market decisions for any launch, say which and how you decided. If you did not, say so and describe the nearest product-strategy work, in your own words. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | low | [inferred] (derivation: an ARR uplift is not a map of whitespace by stage) | discovery | The material shows an ARR uplift, not a map of land, adopt, expand or renew, so do not present it as whitespace work. Answer slot: if you sized where that uplift came from by stage or segment, say how. If you did not, say so and say how you would find whitespace first. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (your message) | medium | [grounded] | presentation | Reword only: you work in SQL and Tableau. The material does not show independence, so expect a probe on who framed the question and who checked the answer. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | Partner-level economics for carrier negotiations is adjacent to designing a partner motion. The material shows the model, not partner terms or channel mechanics you designed. Answer slot: if you designed partner incentives, terms or channel mechanics, say which. If you did not, say what the model did and stop there. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Lead with the consensus in the quote's own words. Expect a probe on how it was reached, which is a slot, not a claim. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (your message) | medium | [grounded] | transferability | Daily use of AI tools is adjacent to AI product experience. The material does not show AI features you built or launched. Name the tools and the tasks, nothing more. |

Note on F2: the confidence is `low` because the quote is about ARR, not about whitespace by stage, so it is a lead, not a claim.

## Grounding brief

Source: your research note. Web searches were refused in this run (see Sources), so nothing here is verified against Northwind's own material, and its currency is unchecked.

- Stated priorities: "enterprise expansion", "an AI copilot launch ('Compass')", "reaching profitability".
- Competitive frame: "bundling by a much larger platform vendor".
- Use this vocabulary. Do not coach Priya to correct the interviewer if the framing is stale.

## Reading the interviewer

Source: the profile note you gave, not web research. Public footprint only.

- Career pattern: pricing and monetization, plus one early-stage startup chapter. Self-description: "relentlessly data-driven".
- Relationship: a peer, reporting to the same VP. Peers price what a hire costs and contributes to their own work.

Practical implications:

1. Expect every metric to be probed to its assumptions. Prepare the defend-the-number slots first.
2. Tilt case questions toward pricing, packaging and unit economics. That is his native language.
3. Monetization vocabulary is the honest mirror. The revenue-model quote (F4) is the strongest shared ground, because it is a shared domain, not a shared identity.
4. The startup chapter is his. Priya has none in the material, so do not claim one or invite a comparison.

Mirror opportunities: shared vocabulary only (monetization, revenue model). No shared career jump is in the material, so none is offered.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Data-Driven Prober | Asks for denominators and assumptions, two levels deep | High. His self-description is "relentlessly data-driven", and the headline figure invites probes. | Name the weakest assumption before he does. Say plainly what you do not know about how a figure was counted. | 5 (A) |
| Peer Evaluator | Seam questions, credit-sharing, what he would need from you | High. Peer relationship, same VP, and his team's load is at stake. | Reciprocity: what you bring his team. Propose seam principles rather than pretending to know the seam. | 4 (B) |
| Case / Strategist | Live whitespace and launch problems | Medium. The JD's two product lines and whitespace requirement are live problems. | Clarify, then structure, using pricing as a lens. Challenge one premise. | 3 (C) |
| Skeptic | Probes the launch-GTM gap and the sales-ops gap | Medium. F1 and the stated sales-ops negative are the likeliest objections. | Rehearse the single predictable objection until it is plain. Calibrated candor, not bluffing. | 3 (D) |
| Pressure / Stress | Time-boxed challenge to the figure and to the fit | Low for a peer, but one or two composure probes are plausible. | Pause, restate, hold through two follow-ups, then concede the specific gap. | 2 (E) |
| Conversational / Rapport | Friendly opener, a casual question on AI | Low to medium. Casual questions are still scored. | A 90-second arc. Treat the AI question as scored. | 2 (F) |
| Values / Behavioral | None | Zero. No values-style round is established, and no published values were read. | Values probes, if any, come through the Peer bank. | 0 |

## Question banks

Guidance cells are speakable in 90 to 120 seconds. Each row's guidance rests on the quoted provenance shown in its row.

### A: Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Figure slot. Answer slot: if you counted or modelled the uplift, say how, in your own words. If someone else measured it, say who, and what you contributed. If you do not know how it was counted, say so plainly. Then name the assumption you would defend least before he asks. | F2 is the evidence for whitespace, and this figure is its only quantified claim. Probers test the headline figure, so it gets the defend-the-number slots. |
| A2 | "Which assumption behind that uplift would you defend least, and which part of the change was yours?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Second-level follow-up. Answer slot: name the assumption, in your own words, if you know one. If you do not know how it was counted, say so and keep the claim at "proposed". Hold the proposal and do not widen it to "drove". | The prober goes two levels deep. A2 is the second level of A1 and the "which part was yours" slot the figure raises. |
| A3 | "Tell me about an analysis you ran end to end in SQL or Tableau. What did you check before you trusted it?" | JD | [grounded] "skilled in SQL/Tableau" | Open prompt: pick one analysis you ran yourself. Name the question, the data, and one check you made. Answer slot: if you did not run one end to end, say so and name the nearest piece you did run. Do not claim independence the quote does not show. | F3 is the requirement's evidence. This is an open prompt, with its theme taken from the JD's SQL and Tableau line. |
| A4 | "Walk me through the partner-level revenue model you built for the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped: built, then used in the negotiations. Those are the beats the sentence states. Answer slot: name the two assumptions you would defend least, if you know them. If you did not set the assumptions, say whose they were. Also answer slot on partner motion: if you designed partner terms or channel mechanics, say which. If not, say the model stopped there. | F4 is the partner-motion requirement's evidence. The question's premise is the quoted sentence itself. |
| A5 | "Who had to agree on the annual volume target, and what did each of them need from it?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Premised on the quote: name the functions and the need each one stated. Answer slot: if there was real disagreement, say what it was and how it ended. If there was none, say so plainly. | F5 is the evidence. This probes the consensus the quote claims, and does not assume a fight. |

### B: Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where's the seam between your land-and-expand work and mine, and what happens when we disagree?" | JD | [grounded] "strong cross-functional influence" (JD highlights) | Propose seam principles: who owns the handoff, how disagreement is escalated. Answer slot: if you have disagreed with an equal across a seam, say what you did. If not, say how you would surface a disagreement early. Then reciprocity: what you bring his team. | The peer stem. The requirement is the raising source. |
| B2 | "How do you handle credit when GTM work spans sales and product?" | JD | [grounded] "strong cross-functional influence" (JD highlights) | Open prompt: pick one instance where credit was shared, and say how it was split. Answer slot: if no credit was shared, say so and name how you would handle it. | A peer stem. The theme comes from the JD's influence line. |
| B3 | "What would you need from my team in the first 90 days?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights) | Reciprocity. Name what you would need and what you would bring to his team. Claim no past work. | Tests how she plans the role, in the JD's own words. |
| B4 | "What pricing or packaging question would you want my team to answer for the two new lines?" | CO | [inferred] derivation: his pricing and monetization career, from the profile note | Name one question and why it matters to the launch. Do not assume his team's pricing history. | His native language, and a seam question that hands him a problem. Tagged CO because it tests Northwind-level altitude. |

### C: Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two new product lines, no launch history. How would you pick the first go-to-market motion for each?" | CASE | [generic] | Clarify, then objective, segmentation, approach, metrics, risks. Use pricing and packaging as a lens. Challenge one premise respectfully. Claim no past work. | A live problem from the JD's first line. Presupposes nothing about Priya's history. |
| C2 | "Compass is launching, and a much larger platform vendor can bundle. Where do you look for whitespace against that bundle?" | CO | [grounded] "an AI copilot launch ('Compass')"; "bundling by a much larger platform vendor" (your research note) | Use the research note's frame. Say what you would need to know about the bundle, then state the whitespace question in land, adopt, expand and renew terms. Do not claim facts past the note. | Uses the note's priorities and the competitive threat, so it tests altitude. |
| C3 | "Find whitespace across land, adopt, expand and renew for a product with no history. Where do you start?" | CASE | [generic] | Decompose by stage. Name the data you would need for each stage. Avoid any claim of prior whitespace work. | A live problem from the JD's whitespace line. F2 is thin, so this is a scaffold, not a story. |

### D: Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The role owns GTM for two new product lines. Which part would you be weakest at on day one?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights) | Highest-ROI prep in this pack. Name the specific gap at the quote's scope, then a ramp plan. Answer slot: if you made go-to-market calls for a launch, name them. If not, say so and name the nearest product-strategy work, in your own words. Rehearse three follow-up levels: the gap, the ramp, and the plan's first 30 days. | The most predictable objection is F1's gap. Expect it in some form, and rehearse a calm, specific answer. |
| D2 | "Your background has no classic sales-ops or quota-setting experience. What would you need to learn first?" | EXP | [grounded] "No classic sales-ops or quota-setting experience." (your message) | Plain acknowledgment: "I haven't done classic sales-ops or quota-setting work." Then a learning plan, said as a plan, never as past work. Claim no sales-ops work. | The negative is stated, so the question may name it. The guidance gives the words back and nothing more. |
| D3 | "Which assumption in a revenue model would you test first before trusting it?" | JD | [generic] | Name one generic check, such as a denominator, a churn assumption or the mix of carriers. If your own model is the example, use only the words in A4's slot. | Dan's pricing spine. A generic question, so it does not presume anything about the candidate's model. |

### E: Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you for a GTM strategy role?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops"; "2 years strategy consulting at a top firm" (your message) | Pause and restate. Anchor in the two quoted beats. Hold through two follow-ups. Concede the specific gap, launch GTM, and do not fold on the rest. | Pressure register. The hold is what the quotes carry, nothing stronger. |
| E2 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Hold: "I proposed the change, and it is credited with the uplift." Concede precisely where the material is silent: how it was measured, if she does not know. Then the A1 slot. | A stress version of A1. It tests whether she can hold a claim without inflating it. |

### F: Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops" (your message) | A 90-second arc. Consulting, then product strategy and ops at scale. Each beat is a clause the quotes state. Add no event. | The opener is scored. A pre-scripted arc avoids a freeze. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message) | Name the tools and one task. Do not claim you built AI features. | Casual, but it scores the JD's AI-plus line. F6 is the evidence. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| own GTM strategy for two new product lines | D1, C1, B3 |
| identify whitespace across land/adopt/expand/renew | C3, C2 |
| run independent analysis in SQL and Tableau | A3 |
| partner-motion design experience required | A4 |
| strong cross-functional influence | B1, B2, A5 |
| AI experience a plus | F2 |

Every requirement has at least one question. Defend-the-number slots for the one headline figure: A1, A2, E2. Session total: 19 questions, inside the 18 to 26 range.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came up through pricing and monetization before sales strategy. What did that change about how you decide a number is real?" | Ties to his own path. It turns his probing into a peer conversation about his data habits. |
| R2 | "What could a new peer do in the first month that would genuinely help your team?" | Reciprocity. Signals that she plans for the seam, not only for herself. |
| R3 | "When enterprise expansion and Compass compete for the same sales capacity, how does your team decide what gets it?" | Uses the priorities from your research note. Shows she has researched the company, and surfaces the seam. |
| R4 | "Which whitespace question has your team wanted answered and not had time for?" | Positions her as the person who can answer it, in her own terms. |
| R5 | "How do pricing and sales strategy hand off on a new line today, and where does that usually break?" | Asks about the seam in the terms of his career. Invites a candid answer about the team's own gaps. |

## Prohibited claims

Built locally from the fit snapshot, since no dossier was supplied. Nothing in any guidance cell may assert, soften or imply these.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran GTM strategy for launched product lines | Inflated form of F1 | The quote at its own scope: "9 at a large consumer-tech company in product strategy & ops". The limit is the pack's own observation: the material shows product strategy and ops, not launch GTM. D1's slot stays inside that scope. |
| Designed the partner motion | Inflated form of F4 | "built a partner-level revenue model used in carrier negotiations". A4's slot asks only which partner terms she designed, if any. |
| Mapped whitespace across land, adopt, expand and renew | Inflated form of F2 | The quote at its own scope: "proposed a store-surface change credited with a ~$400M ARR uplift". The limit is the pack's observation: an uplift is not a whitespace map. |
| Drove the ~$400M ARR alone | Inflated form of the figure's "credited with" | The quote at its own scope: "proposed a store-surface change credited with a ~$400M ARR uplift". A1 and E2 ask how it was counted and which part was hers. |
| Built AI products | Inflated form of F6 | "uses AI tools daily". F2 and F6 name the tools and tasks only. |
| Sales-ops or quota-setting experience | Negative stated by you | "No classic sales-ops or quota-setting experience." Plain acknowledgment: "I haven't done classic sales-ops or quota-setting work." No slot. |

## Sources

Provided documents: your message. It holds the JD highlights (not the full posting), the candidate summary, the interviewer's profile note, and the research note on priorities and the competitive threat.

Searches sent in this run. All three were refused, because web search permission was not granted:

- "Northwind Data company values": refused
- "Northwind Data interview process sales strategy": refused
- "Dan Kovac Director of Sales Strategy Northwind": refused

No page fetches were sent.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Every call refused. Would have supplied official value names. Section 10 is not triggered, because no values-style round is established. No value names are used. |
| 2. Northwind Data interview process | unavailable | Every call refused. Would have supplied loop structure. The loop is established by your own words: one 60-minute peer conversation. |
| 3. Northwind strategy / recent news | skipped | Your research note already fixes the priorities and competitive frame, which the CO bank draws on. |
| 4. Interviewer public footprint | unavailable | Refused. Would have added talks or posts as likely question themes. The interviewer read uses only your profile note. |
| 5. Representative JD | skipped | A JD was supplied (highlights only). The fit snapshot rests on it. |

## Upgrade menu

- The full JD text → the six highlight-based requirements become attributable to the posting, and the location, travel and start-date gates can be checked. Asked in chat.
- Your CV as a document → the evidence quotes move from your message to a CV line, which sharpens the evidence column.
- A re-run of the three refused searches, once permission is granted → Northwind's official values, the interview process, and Dan's public footprint. The values section appears only if a values-style round is documented.
- The recruiter's note on the round → confirms the format. It would replace the loop line and could surface a values round.
- Your answers to the A1, A4 and E2 slots, in your own words → they become quoted material and upgrade F2 and F4 from answer slots to story-mapped answers.
- A deeper research pass (L2, consent-gated; up to 6 more searches and 2 more fetches, several minutes). Offered once, and only on your consent → a strategy brief for the C2 and differentiator bank.
