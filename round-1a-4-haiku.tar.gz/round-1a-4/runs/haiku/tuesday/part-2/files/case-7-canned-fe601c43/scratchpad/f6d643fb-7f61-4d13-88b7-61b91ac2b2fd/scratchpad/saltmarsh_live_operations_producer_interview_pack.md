# Interview pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations (hiring manager, per the company's interviewing page). Round: 60 minutes on Friday. Format: the Outage Hour (see Sources). Changes since the last version: none. This is the first version.

## How to use

Personas are how a question arrives. Types are what it scores:

- **CASE**: a live problem from the role, solved aloud.
- **EXP**: a question about something you did.
- **JD**: a requirement from the job description.
- **CO**: company knowledge, here the Larkspur announcement.
- **VAL**: a published company value, asked as a story.

Guidance is scaffolding, not a script. Say it in your own words. Where a cell says "answer slot", the interviewer's likely probe is named and you answer with what you actually did or say plainly that it was not yours or did not happen.

## Prep triage

Prep time is about three days. Do these in order:

1. **A1 and A2**: rehearse the live-incident tabletop out loud twice. The Outage Hour is a tabletop, so this is the highest-weight persona.
2. **C1 and C2**: learn the two plain acknowledgments word for word. C1 is the highest-ROI rehearsal in this pack (see below).
3. **D1 and D2**: decide now how you would answer "how was retention counted" if you do not know. Honest "I don't know" is an allowed answer.
4. **B1 to B3**: the values scaffolds. Pick one real moment each, or the honest branch.
5. **A4**: read the Larkspur announcement once more. It changes what "your two titles" means.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the job description, the company's interviewing page (F8) or the company's news and values pages (F10, F11), each source named. Requirements marked `[generic]` are plain prose, not quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title and weekly content drops, not two titles. Say the calendar you ran, at that scope. Answer slot: if you planned against a second title's schedule, say how; if you did not, say you ran one. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement. Lead with it in its own terms. Limited inspectable proof, so expect a probe on how the calendar was run. |
| F3 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Reword only: you wrote the checklist and QA still uses it. Do not add that you manage the release. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | You presented the numbers. The material does not show that you defined or counted them. Answer slot: how they were counted, in your words; if you do not know, say so. |
| F5 | "own the post-event review and the KPIs it reports" (JD) | none given | none | [grounded] | discovery | Your material does not show a post-event review or a KPI you reported. Answer slot: if you ran a review after any event, say what it covered; if you did not, say so and say how you would set one up. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating those teams. Answer slot: if you coordinated across teams on a drop, say which and how; if someone else did it, say so. |
| F7 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | The length is a near fit, not a gate. The quote does not say whether the title was live-service in this role's sense. Answer slot: if it was, say what live meant there; if it was not, say so. |
| F8 | "a live-incident tabletop on a simulated outage during a live event" (company interviewing page) | none given | none | [grounded] | discovery | Your material does not show incident work during a live event. Answer slot: if you have been part of a live incident, say what you did; if not, say so and say how you would approach one. |
| F9 | Team leadership (no JD line; [generic] prose) | "Never led a team" (your message) | none | [grounded] | capability | You stated the absence. The plain acknowledgment is "I haven't led a team." No claim of leadership in any form. |
| F10 | Monetisation in the season-pass model (company news, Larkspur) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | You stated the absence. The plain acknowledgment is "I haven't worked on a game with in-app purchases." Then how you would learn it, as a plan, not a past. |
| F11 | "Ship the Patch Not the Promise: we announce what is built, not what is hoped" (company values page) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The checklist is the nearest sentence. It is not a story about patch notes. Use it only for B2 with the honest branch. |

### Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the calendar for two titles | Inflated form of F1 | The quote at its own scope: one main title, weekly drops. |
| Led a team, or managed people | Negative you stated (F9) | "I haven't led a team." No slot. |
| Owned the retention metrics or the KPIs | Inflated form of F4 | "Presented the monthly retention numbers to the studio head." D1's slot asks only how they were counted. |
| Owned the release process | Inflated form of F3 | "Wrote the release checklist our QA team still uses." |
| Worked on a game with in-app purchases | Negative you stated (F10) | "I haven't worked on a game with in-app purchases." No slot. |

## Reading the interviewer

Public footprint only.

- **Career pattern.** A GDC 2026 talk listing names Tobias Wrenfield as Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio. This came from a search result, not an opened page. Confirm it before you cite it in the room.
- **Self-described argument.** The talk is titled "Patch Notes Are a Promise". The listing says a live team is judged by how often its patch notes describe what actually shipped.
- **Implications.** Expect probes on whether what you announce matches what shipped. Expect the release checklist to get attention, since he came from QA. Expect the Outage Hour's tabletop to be built around this idea.
- **Mirror opportunity.** A shared professional path, not a shared jump: QA-adjacent release work. The sentence is F3's quote: "Wrote the release checklist our QA team still uses." Use it only if he raises QA.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live incident and calendar problems from the role. Weight 5. | High. The company's page says the Outage Hour is a live-incident tabletop, and the hiring manager runs it. | Clarify, then stop the bleed, then decide on player comms and the calendar, then review. Say the structure aloud. |
| Values / Behavioral | Three published values asked as stories. Weight 4. | High. The same page says the Outage Hour ends with a values conversation. | One story per value where a quote carries one; the honest branch where none does. |
| Skeptic | Gap probes: leadership, in-app purchases, three years of live-service. Weight 3. | Medium-high. Your three gaps are the obvious ones. | Rehearse the plain acknowledgments until they are boring. Then give the nearest real thing. |
| Data-Driven Prober | How was retention counted; which assumption would you defend least. Weight 2. | Medium. You presented retention numbers, which invites a count question. | Say how it was counted if you know. If you do not, say so and name the assumption you would check first. |
| Pressure | Sixty-second challenges; "how much was actually you". Weight 2. | Low-medium. The format is a tabletop, so pressure comes from the scenario, not the interviewer. | Hold a claim through two follow-ups. Concede specifically. Do not fold on the core claim. |
| Conversational | A journey opener, then a casual question on what you enjoy. Weight 2. | Medium. Interviewers open this way and score the answer anyway. | A ninety-second arc. Never answer "I think you've covered everything" to the closing question. |

Weights: Case 5, Values 4, Skeptic 3, Prober 2, Pressure 2, Conversational 2. Reasoning: the Outage Hour is a tabletop plus a values talk, and the rest follows the candidate's gaps.

## Question banks

Eighteen questions in total. Provenance is the first column that matters: it lists every sentence the guidance rests on.

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Live event, mid-session: the reward service starts returning errors and players are reporting it. Walk me through the first fifteen minutes." | CASE | [grounded] "a live-incident tabletop on a simulated outage during a live event" (company interviewing page) | Clarify first: what the event is, what players see, who is on call, whether a rollback exists. Then decide: pause or roll back the next drop; set what players are told. Speak the order aloud. No claim about your past. | The Outage Hour is this tabletop. CASE because it is a live problem from the role. |
| A2 | "Players are angry about a bug in a reward the calendar promised. Engineering says the fix ships in three days. What do you tell the players, and what happens to the calendar?" | CASE | [grounded] "Ship the Patch Not the Promise: we announce what is built, not what is hoped" (company values page) | Separate what is built from what is hoped. Announce the fix only when it ships. Decide the calendar in the order players are affected. Name the trade-off. No claim about your past. | Tests the company's published value under pressure. CASE because it is a live problem. |
| A3 | "A new event's week-one retention is down twelve percent on plan. What do you check first?" | CASE | [generic] | Start with the count, not the cause: was the metric defined the same way as the plan, then the cohort, then the event's timing. Name the assumption you would check first. | A live metric problem on the role's KPIs. Generic; the figure is hypothetical. |
| A4 | "Saltmarsh has announced one shared events calendar from February. What would you need to know before planning the first quarter on it?" | CO | [grounded] "retires per-title event teams in favour of a single live-ops group" (company news, Larkspur) | Ask about ownership, the season-pass model's cadence, and what the single group inherits. Do not claim to know the plan. | The company's own announcement; the differentiator question most candidates miss. CO because it is strategy. |
| A5 | "Walk me through how you ran the weekly content-drop calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Tell the two years in your words, from the calendar's start to its shape now. Answer slot: the interviewer will probe coordination across design, art, engineering and community. If you coordinated those teams on a drop, say which and how; if someone else did it, say so. | F1 and F6. EXP because it tests what was yours. |

### Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Players Before Plans. Open prompt: pick a moment a dated item conflicted with what players needed. If none comes to mind, say so plainly, then give the nearest thing your calendar work carries, and how you would handle it. | The company's first value. No candidate sentence carries that story, so this is a scaffold. |
| B2 | "Tell me about a release where what shipped differed from what was announced." | VAL | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Ship the Patch Not the Promise. Open prompt. If no such release comes to mind, say so, then describe how the checklist is meant to stop it. Do not claim any release went wrong. | The second value. The checklist is the nearest sentence. |
| B3 | "Tell me about a process you left better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Leave the Build Greener. Say what you wrote and that the team still uses it. Do not claim it improved anything beyond that. | The third value. The checklist is the nearest sentence. |
| B4 | "Tell me about a time you put a player ahead of an internal metric." | VAL | [generic] | Open prompt. If no such time comes to mind, say so plainly, then describe how you would decide between a metric and a player in a live event. | A values prompt with no candidate sentence behind it. Scaffold only. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't led a team. How would you coordinate design, art, engineering and community without authority over them?" | JD | [grounded] "Never led a team" (your message); "coordinate design, art, engineering and community teams on each update" (JD) | Say the plain acknowledgment first: "I haven't led a team." Then the coordination answer slot: if you coordinated across teams on a drop, say which and how; if not, say so and describe how you would run a weekly sync and own the decisions. | The highest-ROI rehearsal in this pack. The probe is likely, and it hits the one stated absence that the role's coordination line speaks to. |
| C2 | "You haven't worked on a game with in-app purchases. How would you plan around monetisation?" | Skeptic | [grounded] "never worked on a game with in-app purchases" (your message); "season-pass model" (company news, Larkspur) | Say: "I haven't worked on a game with in-app purchases." Then what you would learn first: how a season pass changes the calendar. A plan, not a past. | The company's news names the model; the gap is stated. |
| C3 | "Four years at a puzzle studio. Was your main title live-service in the sense this role means?" | Skeptic | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message) | Say the four years and the studio. Answer slot: if the title ran content drops in the live-service sense, say what live meant there; if it did not, say so. | F7's near fit. The probe is about whether the length means the same thing. |

### Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented the monthly retention numbers to the studio head. How was retention counted, and which assumption would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: if you know how it was counted, say it in your own words and name the assumption you would defend least. If you do not know, say so plainly. No figure is supplied here. | F4. The defend-the-number slot. "I do not know how it was counted" is an honest answer. |
| D2 | "The role owns the post-event review and the KPIs it reports. What is the first KPI you would report after a live event?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | No claim about your past. Name the event's goal, the one metric you would report, and the assumption behind it. | F5 is a discovery gap. This is the requirement asked as a plan. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why hire someone who has never led a team?" | Pressure | [grounded] "Never led a team" (your message) | Hold: name the calendar and the checklist as what you did. Concede specifically: "I haven't led a team." Hold through two follow-ups. Do not claim leadership to win. | F9. Hold-then-concede on a stated absence. |
| E2 | "That checklist. How much of it was actually you?" | Pressure | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Hold: you wrote it, and QA still uses it. Concede: name where QA changed it, if they did. If you do not know, say so. | F3. Attribution pressure on the one artifact you have. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message) | A ninety-second arc: the studio, the calendar, the checklist, and why live ops now. Say it in your words. | An opener that is scored. |
| F-2 | "What do you enjoy most about live work?" | JD | [generic] | Pick one part of the job and say why. Keep it to the role, not the company's history. | A casual question with a real score. Generic. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two titles | A5, A4 |
| Coordinate design, art, engineering and community teams | C1, A5 |
| Own the post-event review and the KPIs | D2 |
| Manage the release checklist with QA | E2, B2 |
| 3+ years live-service | C3 |
| Experience running a content calendar | A5 |
| Comfortable with player-retention metrics | D1 |
| Clear written communication | none, and why: not testable in a spoken interview; use the reverse questions to show it |

## Values and principles cheat sheet

Detected: the Outage Hour ends with a values conversation (company interviewing page). Values are from the company's values page.

| Value | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | No candidate sentence carries it. Scaffold: B1. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | The nearest sentence is "Wrote the release checklist our QA team still uses." Scaffold: B2. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | The nearest sentence is "Wrote the release checklist our QA team still uses." Scaffold: B3. Do not claim it improved anything beyond what you wrote. |

## Reverse questions

Five, each with why it lands.

1. "With Larkspur moving both titles onto one shared calendar from February, where does this role sit?" Why it lands: it shows you read the announcement, and it asks him to say the role's shape.
2. "Your talk argues a live team is judged by how often its patch notes describe what shipped. What would that look like in a first ninety days?" Why it lands: it ties to his public argument and asks for his standard. Only ask if the talk is confirmed.
3. "What would a strong post-event review look like to you?" Why it lands: it turns the JD's KPI line into his expectation.
4. "Which of the three values is hardest to hold during a live event?" Why it lands: it shows you know the values by name and asks for his view.
5. "How does the release checklist work with QA now, and where would you want it to go?" Why it lands: it ties to his QA background and to your own checklist work.

## Sources

Provided documents: the role's job description and your background, from your message.

Research tier: L1, searches 4 of 6, fetches 2 of 2; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values section and the cheat sheet. Fetched the values page: three values, names and meanings. |
| 2. Saltmarsh Games interview process, live operations producer | yes | Loop: a recruiter call, then the Outage Hour, one 60-minute interview with the hiring manager, a tabletop and a values conversation. Fetched the interviewing page. This establishes the loop. |
| 3. Saltmarsh Games strategy and news | yes | A4, C2 and reverse question 1. Found the Larkspur announcement (September 2026). Read from the search result, not an opened page. |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Reading the interviewer. Found one GDC 2026 talk listing. Read from the search result, not an opened page. |
| 5. Representative live operations producer JD | skipped | The job description you supplied fixes the fit snapshot. |

Search queries: "Saltmarsh Games values"; "Saltmarsh Games interview process live operations producer"; "Saltmarsh Games strategy news"; "Tobias Wrenfield Saltmarsh Games". Fetches: saltmarshgames.com/careers/interviewing; saltmarshgames.com/values.

## Upgrade menu

- Friday's invite or agenda → confirms whether the 60 minutes is the whole Outage Hour, and whether anyone else joins.
- Any post-event review or KPI report you ran → upgrades F5 and D2 from discovery to grounded.
- The retention numbers and how they were counted → upgrades D1 from a slot to a rehearsed answer.
- The release checklist, if you can share it → upgrades F3 and B2 from a quoted sentence to something you can point to.
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → adds the strategy brief, interviewer talks and posts, and loop reports. Want it?
