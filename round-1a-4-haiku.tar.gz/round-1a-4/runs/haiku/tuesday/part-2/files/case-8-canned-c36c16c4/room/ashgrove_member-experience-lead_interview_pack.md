# Ashgrove Credit Union: Member Experience Lead, interview prep pack

**Role:** Member Experience Lead, Ashgrove Credit Union
**Loop:** three rounds on 3 December 2026 (nine days from 24 November)
- Round 1: recruiter, 30 minutes
- Round 2: Head of Member Services, your future manager, 45 minutes, mostly behavioural (interviewer not yet named)
- Round 3: panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case, scored against the four values (interviewers not yet named)

Loop mode: one shared fit snapshot and source list, then a mini-pack for each round.

---

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** = behavioural and values alignment. **EXP** = work-experience deep-dive. **JD** = a requirement or duty the posting states. **CO** = company and strategy knowledge. **CASE** = a live problem.
- Guidance is scaffolding, not a script. Say it in your own words.
- **Answer slots** are instructions for the interview. Answer from what you actually did. Where you did not do the thing, say so plainly. The pack never supplies a specific you did not give it.
- Provenance labels: **[grounded]** traces to your own sentences or a document you gave me. **[inferred]** is my derivation from them. **[generic]** is a pattern for this kind of interview, with no claim about you or Ashgrove.

---

## Fit snapshot (shared across all three rounds)

Requirements come from the JD you pasted and its duties. Evidence is quoted from your message. The posting names no licence, location, schedule, pay or travel term, so no row is a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | No gap on years. Words: "6 years in retail banking, the last 3 as a branch supervisor." Expect a probe on what the customer side of that work involved, because nothing has been inspected. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | Your words reach the requirement in other terms: "formal", not "regulated". Words: "I handled the branch's formal complaints log." Answer slot: if the log carried regulatory deadlines or external reporting, say which and what you did with them; if it did not, say so and stay with the log. |
| F3 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Your stated absence, kept at its own scope. Words: "I haven't presented to anyone above regional level." Then how you would learn it, said as a plan and never as a past. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Your words reach reporting. "Excel" is not in them. Words: "I built the monthly complaints spreadsheet our regional manager uses." Do not name Excel features you have not used. The spreadsheet's headers would raise this row (upgrade menu). |
| F5 | "Own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Adjacent work at one branch's scope. The process across branches is not in your words. Words: "For the branch, I handled the formal complaints log." Answer slot: if you set any part of how a complaint moved beyond the branch, say which and how you decided; if you did not, say so and stay with the branch log. |
| F6 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your stated absence. Words: "I haven't worked in a contact centre." Then how you would learn the floor, said as a plan. |
| F7 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | Derivation: a monthly report exists. The material does not say what it counted. Answer slot: if it tracked volumes or resolution times, say how each was counted; if it did not, say so and say what the regional manager used it for. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Training tellers is adjacent to coaching supervisors, at a narrower scope. Words: "I trained new tellers on our escalation script." Answer slot: if you coached a supervisor on an escalation, say what the case was and what you did; if you did not, say so. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent. Answer slot: if you worked with any team on a self-service or app journey, say what it was and what you did; if you did not, say so and say how you would start. Silence is not a claim either way. |

**Note on confidence:** everything is medium or lower because nothing has been inspected. A CV, or the spreadsheet's headers, would give F1, F2, F4 and F5 something to check.

### Requirement coverage

| Requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | A5, B6 |
| experience handling regulated complaints | B6 |
| confident presenting to senior leaders | B2, B7 |
| comfortable with Excel reporting | B6 |
| Own the member complaints process end to end across branches | C5 |
| ...and the contact centre | A7, B1 |
| report monthly on complaint volumes and resolution times | B6 |
| coach branch supervisors on escalations | C1, C6 |
| work with digital teams on self-service journeys | A8, C7 |

---

## Prohibited claims (not coached in any round)

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process across branches and the contact centre | Inflated form of F5 and F6 | F5's quote at its own scope: "I handled the branch's formal complaints log." My observation, not words for you: your material shows one branch's log, and the contact centre is your stated absence. |
| Handled regulated complaints | Inflated form of F2 | "I handled the branch's formal complaints log." |
| Coached branch supervisors on escalations | Inflated form of F8 | "trained new tellers on our escalation script" |
| Built Excel reports with formulas or pivots | Inflated form of F4 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Tracked complaint volumes and resolution times | Inflated form of F7 | Nothing written. The F7 answer slot asks what the spreadsheet counted. |
| Any figure for volumes or timescales | No figure in your material | Nothing written. No slot supplies one; the F7 slot asks how any count was made. |
| Presented to senior leaders | Negative you stated (F3) | "I haven't presented to anyone above regional level." |
| Worked in a contact centre | Negative you stated (F6) | "I haven't worked in a contact centre." |

---

## Strategy grounding (from your summary of the July 2026 brief)

I have not read the brief itself, so use its own wording, not mine. Your summary gives these points:

- "move 40% of member service to digital channels by 2028"
- "consolidate eight branches into five hubs over 2027"
- "launch a small-business lending product in Q1 2027"
- Main competitive pressure: app-only banks.

The brief is four months old, inside the six-month window. I found no stale framing in what you gave me.

Why it matters: the hub move touches the branches a Member Experience Lead coaches, and the digital target shifts the channel your F9 row has no evidence for.

---

## Persona weights

| Persona | Round 1 (recruiter) | Round 2 (Head of Member Services) | Round 3 (panel) | How it shows up | Counter-strategy |
|---|---|---|---|---|---|
| Logistics (recruiter knockouts) | 4 | 0 | 0 | Pay, notice, location, reason for leaving | Your own words, once |
| Conversational | 3 | 0 | 0 | Friendly openers; casual questions are still scored | 90-second arcs; treat casual questions as scored |
| Values / Behavioral | 0 | 3 | 3 | Scenario probes on the four values | A quoted story, or the honest branch |
| Skeptic | 1 | 2 | 0 | Persistent probing of the gaps | State the limit first, then the plan |
| Pressure | 0 | 1 | 1 | Interrupts, tests whether a position holds | Hold through two follow-ups; concede specifically |
| Data-Driven Prober | 0 | 1 | 0 | Asks how the spreadsheet counted things | Say what it counted; name the weakest assumption |
| Case / Strategist | 0 | 1 | 2 | The escalation case; the hub plan | Clarify, structure, then answer; think aloud |
| Peer Evaluator | 0 | 0 | 2 | Seams between branch and contact centre; credit and disagreement | Principles first; name the limit |

**Reasoning:**
- **Round 1:** the recruiter's round is a screen, so Conversational leads, with Logistics fixed at four items because the screen covers them. One Skeptic item is light.
- **Round 2:** you were told it is mostly behavioural, so Values carries the most weight. The hiring-manager prior puts Skeptic and Case up, so Skeptic gets two items. B1 is the deepest rehearsal in the pack.
- **Round 3:** the email says the panel scores against the four values, so Values leads. The escalation case brings Case, and the two branch managers give Peer and one Pressure item. Interviewers are not named, so there is no per-person adjustment.

---

## Round 1: recruiter screen (30 minutes)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations for this role?" | JD | [generic] | Logistics slot. Give your own figure, chosen before the call, or ask first what band the role carries. Give no figure you have not chosen. | Pay is a screen knockout. The pattern is the screen's, not a fact about Ashgrove. |
| A2 | "What is your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period in your own words. If you are unsure of the contract term, say you will confirm it. | Notice is a knockout check. The only safe answer is yours. |
| A3 | "Where are you based, and which site could you work from?" | JD | [generic] | Logistics slot. Say where you live and which site you could reach, in your own words. If you do not know which site the role sits in, ask (R1). | The posting names no location, and the hub plan makes it worth asking. |
| A4 | "Why are you looking to move on from your current role?" | EXP | [generic] | Logistics slot. Give your own reason, in your own words. No reason of yours appears in the material, so supply none. | Reason for leaving is a screen logistic, and round 2 will ask it again. |
| A5 | "Walk me through your background in ninety seconds." | EXP / JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Three beats, each in your words: six years in retail banking, the last three as a branch supervisor; the formal complaints log you handled; the monthly spreadsheet your regional manager uses. Then stop. | Covers F1, F2 and F4 inside a minute. Type JD because it lands the 4+ years requirement. |
| A6 | "Why this role, at a credit union, now?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief, your summary) | Your reason, in your words. You may anchor it in one fact from the strategy. Do not claim a view you have not formed. | Motivation. The strategy fact is the brief's; the reason is yours. |
| A7 | "What part of this role is furthest from your current work?" | JD | [grounded] "Never worked in a contact centre" (your message) | Name it in those words: "I haven't worked in a contact centre." Then one sentence on how you would learn it, as a plan. Do not describe contact-centre work as if you had done it. | The gap a screener hears first. The full rehearsal is B1. |
| A8 | "Which self-service journey have you used most recently, at any bank or service, and what made it easy or hard?" | JD | [generic] | Answer as a user, in your own words: one journey, what worked, what did not. If you have not used one, say so. Make no claim about work you did on one. | Casual register, but it scores the JD's self-service requirement. |

---

## Round 2: Head of Member Services (45 minutes, mostly behavioural)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked in a contact centre. How would you lead one that answers to you?" | JD | [grounded] "Never worked in a contact centre" (your message) | **Deepest rehearsal.** Open with the limit before it is asked for: "I haven't worked in a contact centre." Then the nearest thing you did, in your words: "trained new tellers on our escalation script." Then the plan: listen to live calls, sit with the team leads, and agree the escalation route with them first. Follow-up one, "Why would a team trust you?": say what you would do first, not what you know. Follow-up two, "What would you get wrong?": concede the specific gap, which measures the floor runs on, and say how you would find out. | The single most predictable objection to you. The role runs a contact centre and you have never worked in one (F6). Highest-return prep in this pack. |
| B2 | "Have you ever presented to anyone above regional level? The role needs confidence presenting to senior leaders." | JD | [grounded] "I've never presented to anyone above regional level" (your message); "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the adjacent sentence: the spreadsheet your regional manager uses. Then the plan: what you would ask to present first, and to whom in your first 90 days. Do not claim senior presenting you have not done. | Skeptic on F3. The acknowledgment is yours; the plan is a commitment they can hold you to. |
| B3 | "Tell me about a time you put a member's view ahead of a process rule." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt: choose a real case. Name the rule, the member's situation, what you decided and why. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, handling the formal log, and what you would do the next time. | Members First, Always. The scaffold stands because no sentence of yours carries a member-side decision. |
| B4 | "Tell me about a time you had to explain something more than once." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | The sentence states training tellers on a script. If a teller did not follow it the first time and you changed how you explained it, say what you changed. If you did not, say so and keep to the training. | Plain Words: a value tested by re-explaining. The re-explaining is yours to supply or to leave out. |
| B5 | "When has a branch decision landed on the people in its town?" | VAL | [generic] | Open prompt: pick a real decision that touched local customers. If none comes to mind, say so, and say what you saw of it from the supervisor's chair, and nothing more. | Neighbours, Not Numbers. [generic] because no sentence of yours carries a town. |
| B6 | "Walk me through the formal complaints log and the monthly spreadsheet. What did each count, and which parts were regulated?" | EXP / JD | [grounded] "I handled the branch's formal complaints log" (your message); "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot on each. Log: what it recorded, and whether any step had a regulatory deadline or external reporting. Spreadsheet: what it counted, and whether it tracked volumes or resolution times. If you did this, say how, in your words. If a part was not regulated, not counted or not yours, say so plainly. Name the weakest assumption behind any number you can describe. | Premised question. The JD raises "regulated" and "volumes and resolution times", which no quote carries, so the second branch allows that neither was tracked. Covers F2, F4 and F7. |
| B7 | "Sixty seconds: why would a senior leader trust you to present on complaints?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message); "I've never presented to anyone above regional level" (your message) | Pressure. Hold: say what you built and who uses it, in those words. Hold through two follow-ups. Concede explicitly: "I haven't presented to anyone above regional level, so my first one would be a plan you could check." Do not fold on the spreadsheet. | Pressure on F3. Hold-then-concede. |
| B8 | "The plan takes eight branches to five hubs over 2027. What happens to complaints from a branch that closes?" | CO / CASE | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief, your summary) | Clarify first: which branches, which hub, what members are told. Then structure: open cases, records, the owner, the member's contact route. Name the one metric you would watch in the first quarter. Say what you do not know about Ashgrove's plan. | Case, on the hiring-manager prior. The hub move is the strategy's most direct effect on a complaints process. Do not claim knowledge of their plan. |

---

## Round 3: panel of two branch managers (60 minutes, including the 20-minute escalation case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | **Escalation case:** "A member has been in twice about a fee. The second time they say they will take it to the ombudsman. The teller escalated it once and heard nothing. Walk us through your first hour." | CASE | [generic] | Live problem, no claim about your past. Clarify first: which fee, what the record shows, whether the escalation was logged and to whom. Then the objective: a decision the member can follow, and one owner who keeps hold until it is solved. Then approach, one metric, and the risks. Think aloud, and name one premise you would challenge. | The case the email names. Own the Fix should be audible in the first hour. |
| C2 | "You said 'escalate'. Why not just refund it and move on?" | CASE | [generic] | Pressure within the case. Hold through two follow-ups: the refund depends on whether the fee was wrong, and you would check that first. Concede specifically if they are right about any part: "If the fee was wrong, the refund is the answer." Do not fold on the process. | Pressure in the case. Hold-then-concede. |
| C3 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt: choose a real case. If you kept a case until it was closed, say which, and what closed it. If cases passed to someone else at a point, say where and why. If no case fits, say so plainly and say what you handled from the log. | Own the Fix. The sentence carries handling. Closure is an answer slot. |
| C4 | "Tell me about a time a number pointed one way and a branch's customers pointed the other." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Open prompt. Your sentence is numbers-led, so do not lead with it. If you have such a time, say the number, what it missed, and what you did for the customers. If you do not, say so, and say how you would decide which to trust. | Neighbours, Not Numbers. The panel will test it with this spreadsheet. |
| C5 | "Where is the seam between a branch and the contact centre, and what happens when they disagree about a complaint?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD); "Never worked in a contact centre" (your message) | Propose principles, not a seam you have not seen. One owner holds a member's complaint whichever side answers. A disagreement is settled by the member's outcome, then by the record. Say plainly that you haven't worked in a contact centre, so you would agree the seam with its leads first. | Peer Evaluator. The seam is theirs; the principles are yours to defend. |
| C6 | "When your coaching of a supervisor and a branch target disagree, which wins?" | JD | [grounded] "coach branch supervisors on escalations" (JD) | Principle first: weigh the member's outcome and the supervisor's capacity, then the target, which you would raise with the branch manager. Say what the branch gets from you. Make no claim about a case you have not handled. | Peer Evaluator. A branch manager's target is their own turf. |
| C7 | "Our customers are moving to the app. What would you change first in a self-service complaint journey?" | CO / CASE | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief, your summary); "work with digital teams on self-service journeys" (JD) | Name the one thing you would look at first: where members give up in the app and call or come in instead. Say what you would take to the digital team. If you have worked with a digital team on a journey, say what it was and what you did. If not, say so. | Case. F9 is silent, so the honest branch is part of the answer. |
| C8 | "Why should we believe you know what a member needs when they call?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message); "Never worked in a contact centre" (your message) | Hold: the log is a record of member complaints you handled. Say that and stop. Concede specifically: "I don't yet know how a call differs from the branch conversation." Do not claim phone experience. | Members First, Always, under a trust test. Hold one claim, concede one. |

---

## Values cheat sheet (round 3 lives here: the email says this is the values round)

Values are the official names you copied on 24 November 2026.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted story carries a member-side decision. Nearest sentence, F2: "I handled the branch's formal complaints log." Scaffold in B3 and C8. If no such time comes to mind, say so. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | F8: "trained new tellers on our escalation script". The beats are the quoted clause. The re-explaining is the B4 slot. |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted story carries a town. Scaffold in B5 and C4. If no such time comes to mind, say so. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F5: "I handled the branch's formal complaints log." The story is the log you handled. "Until solved" is the C3 slot. |

---

## Reverse questions

**Round 1 (recruiter):**
- "Which site would this role be based at, and is that set yet?" *Why it lands:* the posting names no location, and the hub plan may change it. The answer is what A3 needs.
- "What happens after the three rounds, and who makes the decision?" *Why it lands:* shows you are planning, and tells you whether the panel's view is final.

**Round 2 (Head of Member Services):**
- "How will the monthly complaints report change once the eight-branch-to-five-hub move lands?" *Why it lands:* ties your reporting work to the 2027 plan and asks what they need from it.
- "What would you need to see in my first 90 days to know the role is working?" *Why it lands:* makes success measurable in their terms. Then you can hold them to it.

**Round 3 (panel):**
- "How do the branches and the contact centre agree who owns a complaint once it is escalated?" *Why it lands:* tests the seam the panel knows well. Their answer shows where your first conversation should go.
- "What could a new Member Experience Lead do in the first month that would help your branches?" *Why it lands:* a reciprocity question. It asks the panel what they need, which the seam round rewards.

---

## Sources

- **Provided, in your message:** your background; the JD text; the recruiter's email, as you quoted it; the values, copied from ashgrovecu.org/about/values on 24 November 2026; your summary of the July 2026 strategy brief.
- **Research tier:** L1. Searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values you copied fix the values section. A fetch would repeat them. |
| 2. Interview process | skipped | The recruiter's email fixes the three rounds and which one is the values round. |
| 3. Strategy and recent news | skipped | Your summary of the July 2026 brief fixes the CO questions. I have not read the brief itself. |
| 4. Interviewer name | n/a | No names yet for rounds 2 and 3. |
| 5. Representative JD | skipped | Your JD fixes the fit snapshot and the JD tags. |

No dossier was consumed.

---

## Upgrade menu

- **Round 2 interviewer's name:** persona weights from their public footprint, and a reverse question tied to their own path.
- **Round 3 branch managers' names:** one persona set per person, and the seam questions made specific to their branches.
- **The recruiter confirms where the role sits and whether it includes contact-centre work:** A3 and the first reverse question get a grounded answer, and the posting's silence on location is closed.
- **The spreadsheet's column headers, with no data:** F4 moves from medium toward high, and F7 can be answered from what it counted.
- **Your CV:** F1, F2 and F5 get a document to check, and their bands can be raised.
- **A case you kept to closure:** C3 becomes a story map, not a slot.
- **Any digital project or team work:** F9 and C7 leave the slot.
- **Deep research (L2):** the strategy brief itself, the role's loop reports, and recent news on the hub timing and leadership. Up to 6 more searches and 2 more fetches, several minutes. Want it?
- **Prep time, in days:** adds a triage section that orders the rehearsal.
- **A `tuesday-dossier.md`:** would add verified evidence and a prohibited-claims list from a prior check of this role. Optional.
