# Interview prep pack: Product Operations Manager, Stripe

Session mode. Final round; interviewer and format not yet known, so persona weights are blended across the likely relationships.

## How to use

Personas describe how a question arrives. Types describe what is being scored.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values alignment |
| EXP | Work-experience deep-dive |
| JD | Role-driven: can you do the listed job |
| CO | Company and strategy knowledge |
| CASE | Live problem from the role, solved aloud |

Guidance is scaffolding, not a script. Nothing here is a claim about your past. Where a guidance cell asks you to say what you did, the words are yours to fill from your own experience.

## Fit snapshot (worksheet variant)

No job description, CV or background has been shared, so every evidence cell is `none given`. The requirements below are role-family patterns, not quotes from Stripe's posting, so they are `[generic]` and raise no answer slots. Fill the evidence column once you share your CV or the JD.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Running cross-functional programs end to end across product, engineering and go-to-market — role-family pattern | none given | none | [generic] | discovery | Selection scaffold: pick a time you drove work across two or more teams to a finished outcome. If no such time comes to mind, say so plainly, then give the nearest one you have. |
| F2 | Designing planning, review and decision cadences — role-family pattern | none given | none | [generic] | discovery | Selection scaffold: pick a process you set up or changed, and what it replaced. If you have not designed one, say so and describe how you would start. |
| F3 | Metrics and analysis that inform operational decisions — role-family pattern | none given | none | [generic] | discovery | Selection scaffold: pick a number you used to make a call. Name how it was counted and which assumption you would defend least. If you have not used one, say so. |
| F4 | Clear written and spoken synthesis for executives — role-family pattern | none given | none | [generic] | discovery | Selection scaffold: pick a recommendation you wrote or presented to someone senior. Say what they decided and what you would do differently. |
| F5 | Prioritizing across competing stakeholders with limited capacity — role-family pattern | none given | none | [generic] | discovery | Selection scaffold: pick a time you had to say no or defer. Name the criteria you used. If none comes to mind, say so plainly. |
| F6 | Building lightweight tools or workflows that teams adopt — role-family pattern | none given | none | [generic] | discovery | Selection scaffold: pick a workflow you automated or simplified, and who used it afterwards. If you have not done this, say so and describe how you would start. |

## Prohibited claims

None built. There are no sentences of yours in this conversation yet, so there is nothing to inflate. The standing rule applies: nothing in a rehearsed answer should describe work you have not told me about. Where a guidance cell asks for your experience, the honest branch is always available.

## Persona table

| Persona | How it shows up | Likelihood (reasoning) | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live operational problem, such as slipping launches or competing requests | High. Final rounds for operations roles often include a live problem; the role-family pattern points this way, not a known loop | Clarify, then structure, then one metric, then one risk. Think aloud |
| Skeptic | Probes the weakest point of the candidate story and the motivation | High. Final rounds test whether the motivation holds up | Rehearse the single predictable objection until it is calm. Concede a gap plainly, then give the ramp |
| Peer Evaluator | Seam questions between operations and the peer's team | Medium. Depends on whether a peer is in the loop | Propose seam principles, not a made-up history. Show what you bring to their team |
| Pressure | Time-boxed challenge to a position | Low to medium. Unknown until the format is confirmed | Pause, restate, hold a position through two follow-ups, then concede a specific point |
| Data-Driven Prober | Asks how a number was counted | Medium. Operations roles lean on metrics | Name the weakest assumption before being asked |
| Values / Behavioral | Scenario probes about how you act | Low weight, kept as insurance. No values-style round is confirmed for this loop | Use the selection scaffolds above. Choose a true example, even if the ending is imperfect |

## Question banks

Blended weights: Case 4 questions, Skeptic 2, Pressure 3, Peer 3, Prober 2, Values 2 (plus one extra Case and one Pressure, for 18 total).

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product team's launch dates keep slipping, and nobody can say why. How would you find out?" | CASE | [generic] | Clarify what counts as slipping and over what period. Structure: stages, handoffs, causes. Name one metric that would show the cause. Name one risk to your own diagnosis | Role-family live problem; makes no claim about your past |
| A2 | "Three teams want the same analyst's time next quarter. Walk me through how you'd decide." | CASE | [generic] | Set the decision criteria first, then the stakeholders, then the rule you would apply. Say what you would decline and how you would tell them | Tests prioritization under constraint |
| A3 | "Our internal review meeting takes too long and people stop attending. How would you assess it?" | CASE | [generic] | Clarify the goal of the meeting. Measure attendance and decisions made per meeting. Propose one change and how you would test it | Process design, the most common operations case |
| A4 | "What would you measure in your first thirty days in this role?" | JD | [generic] | Name three baseline measures and the question each one answers. Say how you would check the measures themselves | Tests whether you think in measures, not activity |
| A5 | "How would you know whether a change to our internal process actually worked?" | CASE | [generic] | Define success before the change, then a comparison group or a before-and-after window. Name the most likely way the result misleads you | Metrics judgment, asked as a decision |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why operations, and what would make you leave a role like this within a year?" | VAL | [generic] | Give the honest reason you want this kind of work, in your own words. Say what would make it not work for you. Interviewers test whether the answer is stable under follow-up | Highest-ROI prep in this pack. Motivation probes come in every final round, and an unrehearsed answer is the most likely one to wobble |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the area you know least about. Give the ramp: how you would learn it, from whom, by when. If you have done this kind of work before, say where. If not, say so plainly | Skeptic stem; a gap named honestly beats a bluff |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you for this role?" | VAL | [generic] | Pause. Give three reasons, each in one sentence. When pushed, hold the strongest one and concede the weakest specifically, not generally | Pressure stem; tests composure more than content |
| C2 | "Pick a result you're proud of. How much of it was actually you?" | EXP | [generic] | Name the result in your own words. Separate what you decided, what you did and what others did. Hold the split under a second follow-up | Open prompt. Tests attribution honesty |
| C3 | "Tell me about a time your plan was overruled. What did you do next?" | VAL | [generic] | Pick a real instance. Say what you argued and what you did once the decision was made. If none comes to mind, say so, then give the nearest one | Tests whether you disagree and commit |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where's the seam between operations and product, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam: who decides what, and how disagreements get escalated. Do not claim knowledge of their team's history | Peer stem; tests partnership fit |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name how you credit contributors. Say what you do when credit is unclear. Keep the answer about practice, not about a story you have not told me | Peer stem |
| D3 | "What would you need from my team to be effective in the first month?" | JD | [generic] | Name two or three specific needs and what you would offer in return. Reciprocity shows partnership | Peer reciprocity |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a metric you've used to judge a process. How was it counted?" | EXP | [generic] | Name the metric. Say the denominator, the assumption you would defend least, and which part of the counting was yours. If you have not used one, say so and describe how you would choose one | Open prompt; prober stem |
| E2 | "Which assumption behind the metric you'd use here would you defend least?" | EXP | [generic] | Name the assumption before the interviewer does. If you cannot name one, say so plainly | Prober stem; converts a gotcha into a credibility point |

### Values / Behavioral (insurance)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a real instance with a stake and an outcome. Say what you actually said. If none comes to mind, say so plainly, then give the nearest one | Values stem; kept low because no values round is confirmed |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a real instance. Say what the metric was and what you did instead. If none comes to mind, say so, then describe how you would decide | Values stem |

## Reverse questions

Each one lands for a reason, so you can reuse the reason if the question is rephrased.

1. "What does a strong first quarter look like for this role?" Why it lands: it shows you are planning for the outcome, not the title.
2. "Where do product and operations decisions most often stall today?" Why it lands: it asks for the real friction, which interviewers rarely volunteer.
3. "How is success measured for this team, and who decides when it has been met?" Why it lands: it shows you think in measures and owners.
4. "What is the hardest tradeoff this team faces in the next six months?" Why it lands: it shows you are already thinking about the work.
5. "What has worked well in this team's operating cadence, and what would you change?" Why it lands: it asks for a judgment, not a list.
6. Reciprocity, if a peer is in the room: "What could a new person do in their first month that would genuinely help your team?" Why it lands: it turns the conversation into partnership.

## Sources

No search was available to this run. Two search calls were sent and refused by the host, and no fetches were made.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Every call refused. Queries: "Stripe values operating principles" (refused). Values cheat sheet not built, since no values page was read |
| 2. Stripe interview process, product operations | unavailable | Every call refused. Queries: "Stripe interview process final round product operations manager" (refused). Loop structure unknown; persona weights are blended, not loop-derived |
| 3. Stripe strategy / recent news | unavailable | No call sent: this host offers no search. Would have moved the CO bank, which is absent, and the differentiator questions |
| 4. Interviewer name and company | n/a | No interviewer name was given |
| 5. Representative Product Operations Manager JD | unavailable | No call sent: this host offers no search. Would have grounded the coverage line and the JD-tagged questions |

Provided documents: none. No JD, CV, recruiter email or interviewer profile was shared. All content is role-family pattern, labeled `[generic]`.

## Upgrade menu

- The job description text → the six `[generic]` fit rows become `[grounded]` quotes, and the coverage line can be filled in
- Your CV → the worksheet becomes a fit snapshot, and the selection scaffolds become story maps with your own quotes
- The round format and who is interviewing → persona weights are set for that relationship, and the values round is confirmed or dropped
- The recruiter's email on format or any exercise → sections for any pre-declared deliverable
- The interviewer's name → a reading of their public path and a tailored reverse question
- Company research, once search is available → the values page, the loop structure and a strategy pass, which unlock the values cheat sheet and the CO bank. A deeper pass is also possible once search works: up to six more searches and two more fetches, several minutes
