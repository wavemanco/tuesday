# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager. Company: Atlas Freight (regional logistics, 800 employees). Interviewer: not named. Round: not stated. Built for a hiring-manager round, since that is the most common shape for this role. Persona weights below rest on that assumption.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: JD (the listed job), EXP (your own record), CASE (a live problem), VAL (values; not detected here), CO (company knowledge; not researched).
- Guidance is scaffolding, not a script. Speak it in your own words. Each guidance cell is meant to be said aloud in 90 to 120 seconds.
- Anything in quotation marks is your own sentence from your message, or a sentence from the job description you gave me. Nothing else is quoted.

## Fit snapshot

The JD you gave is a summary in your own words, not the posting as written. Quotes below are exact to your text. The job does not say where the four sites are. Location is a gate term, so it is asked in the closing questions rather than assumed.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own daily terminal operations across 4 sites" — JD | "senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material shows one site: a senior shift manager role and a peak-season plan there. It does not show daily oversight across several sites. Words for you: "I'm senior shift manager over three supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: if you have run daily operations beyond that site, say which sites and what you were accountable for; if you have not, say so plainly and stay with the site you ran. |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material is about pick accuracy, not on-time performance. Words for you: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if you have measured on-time performance anywhere, say which measure and how it moved; if you have not, say so and name the on-time measure you would look at first. |
| F3 | "drive on-time performance and cost-per-shipment down" — JD | none given | none | [grounded] | discovery | Your material says nothing about cost per shipment. Answer slot: if you have moved a cost-per-unit or cost-per-order figure, say what it was and what you did; if you have not, say so plainly and say what you would measure first. |
| F4 | "lead a team of 12 supervisors" — JD | "senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows three supervisors, not twelve. Words for you: "I'm senior shift manager over three supervisors." Answer slot: if you have led a larger group or a management layer above supervisors, say how many and how; if not, say so and say how you would structure twelve supervisors across four sites. |
| F5 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Your material shows seven years in operations; it does not say how long you have led people. The bridge is my derivation from those two sentences, so it is a clarify note, not a claim. Answer slot: count from the first role where people reported to you, state that number of years, and say whether the years were leadership or operations alone. This is not a gate (the JD's experience line is graded on fit), so it is not a yes or no. |
| F6 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | Your material says Excel is solid. It does not show a report you built or maintained. The bridge is my derivation from that phrase. Answer slot: name one report you built or maintained in Excel, who read it, and where its data came from; if you have not built one, say so and say what you have used Excel for. |
| F7 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap you stated and the pack cannot close. Words for you: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work. |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | Met on the credential. Caveat: the certificate has not been inspected, so expect a probe on a project. Words for you: "I'm Green Belt certified." |

Gate rows: none established by the material. Location of the four sites is not stated anywhere in the job description or your message; see the closing questions.

## Prohibited claims

Claims this pack will not coach, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I run daily operations across four sites" | Inflated form of F1. Your material says one site. | F1's quote at its own scope: "I'm senior shift manager over three supervisors, and I ran the site's peak-season surge plan two years running." Limit, in the pack's analysis: the material shows one site. |
| "I lead twelve supervisors" or "I've led at this scale" | Inflated form of F4. Your material says three. | "I'm senior shift manager over three supervisors." |
| "I've owned on-time performance" | Inflated form of F2. Your material says pick accuracy. | F2's quote at its own scope. |
| "I've built Power BI reporting" | Negative you stated, F7. | "I haven't used Power BI." No slot. |

Silence is not listed. Cost per shipment (F3) and your years of leadership (F5) are answer slots, not prohibited claims, because your material is silent on them rather than contrary.

## Persona table

Hiring-manager prior: they are buying capability and derisking gaps, so live problems on the role lead. No interviewer profile exists, so no interviewer adjustments apply. No loop source establishes the rounds, so persona weights rest on the archetype for a generic loop.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems on on-time and cost per shipment, and a 12-supervisor, four-site setup | High. Hiring-manager prior; the JD is full of operational problems to solve | Clarify, then structure: define the metric, segment by site, then choose the first action |
| Skeptic | "Where is the twelve?", "Where are the five years?", "Power BI?" | High. These are the three gaps the fit snapshot found, and the most likely objections | Rehearse the leadership-scale answer until it is plain. Use the bridges built from what you stated, and the limit said plainly |
| Data-Driven Prober | Probes the 40% number and the Excel reporting | Medium to high. The JD names reporting, and the 40% is the headline figure on your record | Know how the 40% was counted, or say you do not. Name the weakest assumption before they do |
| Pressure | Challenges how much of a result was yours | Medium, but lower than the others. A hiring manager does not usually push hard on a first interview; it is included because one panel member may | Hold the position through two follow-ups, then concede only what you cannot show |
| Conversational | Opens with "walk me through the journey" and "why this role" | Medium. Casual openers still score | A 90-second arc built from your own sentences |

Persona depth: Case/Strategist 5 questions, Skeptic 4, Prober 4, Pressure 2, Conversational 3.

## Question banks

Provenance comes before guidance. Every candidate sentence a guidance cell draws on is quoted in its own row.

### Case/Strategist (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "How would you get a single view of on-time performance across four sites?" | CASE | [generic] | Clarify first: what counts as on time, measured where and over what window. Then segment by site and by shift before you pick a site. Name the first two things you would check and why. | A live problem drawn from the JD's on-time line. It asks about no past of yours, so it carries no quote. |
| A2 | "Cost per shipment has risen for two quarters. Walk me through how you'd find out why." | CASE | [generic] | Define cost per shipment and its parts. Split by site, lane, shift and volume before deciding. Say what you would need from finance, and which single cost you would look at first and what would change your mind. | Live problem from the JD's cost line. Hypothetical, so no claim about your past. |
| A3 | "Peak season starts in six weeks and volume is forecast to double. What do you do in the first two weeks?" | CASE | [generic] | Sequence it: confirm the forecast and its basis, size the staffing gap per site, name the decisions that cannot wait, then the escalation path. Say which pieces you would hand to supervisors. | Live problem from the daily-operations line. Peak season is in your record (F1), but this question asks about the future, so no quote is needed. |
| A4 | "You'd lead twelve supervisors across four sites. How would you set them up in the first quarter?" | CASE | [generic] | Say how you would structure the group, what each supervisor owns, how you would check that the four sites run the same way, and what you would stop doing before you start. | Live problem from the JD's team line. The guidance makes no claim about the team you have led; it is a plan. |
| A5 | "What would you measure in your first week, and what would you leave alone?" | CASE | [generic] | Name the two or three measures you would look at first, where each comes from, and one thing you would deliberately not change until you understood it. | A probe for judgment rather than knowledge. No claim about your past. |

### Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You lead three supervisors today. This role leads twelve across four sites. Where does that gap show up for you?" | JD | [grounded] "senior shift manager over 3 supervisors" — your message | Say what your three-supervisor role covers, in your own words. Then name the part of twelve across four sites you have not done, and how you would close it. Answer slot: if you have led more people than three, or across more than one site, say so; if you have not, say so plainly. | F4 is the largest structural gap. The question presupposes only your three-supervisor sentence and the JD's twelve. |
| B2 | "The role asks for five-plus years of operations leadership. Where does your leadership time start?" | JD | [grounded] "7 years in warehouse and distribution ops" — your message; [grounded] "senior shift manager over 3 supervisors" — your message | **Highest-ROI prep in this pack.** Give the start date of your first role where people reported to you, from your own records, and say the number of years. If it is under five, say so plainly, then give the seven years in operations and the senior shift manager role as the nearest thing your material carries. Hold through two follow-ups by returning to what you ran; never round the years up. | F5 is the most likely objection in this loop, and the JD names it outright. The answer can be honest and still strong if it is rehearsed. |
| B3 | "Your reporting runs in Power BI. How quickly could you be useful in it?" | JD | [grounded] "never used Power BI" — your message | Plain acknowledgment: "I haven't used Power BI." Then a plan with a specific first step and a date. No claim of any Power BI work. | F7. The negative is yours, so the acknowledgment is sourced. |
| B4 | "Why would a 40% fix at one site carry over to four?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Say what the redesign changed at the site you ran it, in your own words. Name one condition at the other sites you would check before expecting the same result. Answer slot: if you have seen a change carry over anywhere, say where; if not, say so plainly. | F2 and F1 together. The question tests whether you know the number has a boundary. |

### Prober (weight: medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Defend the number: the period it compares, what counted as a mis-pick, and the volume behind it. Answer slot: if you did not set the counting method, say so plainly and say who did. If you do not remember how it was counted, say that. Do not supply a baseline. | The headline figure on your record. A figure you gave raises the defend-the-number slots, and no other. |
| C2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Name the assumption you are least sure of, in your own words. If you do not know what the assumptions were, say so. Naming it first converts a gotcha into a credibility point. | The weakest-assumption move. The pack supplies no assumption because none is quoted. |
| C3 | "What reporting have you built in Excel, and where did its data come from?" | EXP | [inferred] "solid Excel" — your message | Answer slot: name one report you built or maintained in Excel, who read it, and where its data came from. If you have not built one, say so and say what you have used Excel for. | F6. Low confidence, so the pack asks rather than asserts. |
| C4 | "How would you build a weekly on-time report that four site leaders would trust?" | JD | [generic] | Name the definition of on time first, the source of the timestamps, the owner at each site, the review cadence, and what would change the metric. Say which part you would build in Excel first and which later. | The JD's reporting line, asked as a plan. This is not a claim about a report you built. |

### Pressure (weight: lower)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Hold: say what you did, the redesign, in your own words. Hold through two follow-ups. Concede only what you cannot show, and say specifically what it is. Never fold on the redesign itself. | Attribution pressure on your headline figure. The hold-then-concede structure is the rehearsal. |
| D2 | "How much of the peak-season plan was actually yours?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" — your message | Hold: "I ran the site's peak-season surge plan two years running." Then say which parts you set and which you ran from someone else's design, in your own words. Concede the parts you cannot show, specifically. | Attribution pressure on the second headline item. The question does not presuppose a negative; it asks for the split. |

### Conversational (weight: lower)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" — your message; [grounded] "senior shift manager over 3 supervisors" — your message | A 90-second arc in your words: the seven years, the shift manager role, the pick path redesign, the surge plan. Stop at the sentences your material carries. | Opener. Casual, but scored for communication economy. |
| E2 | "What's your view on Lean in a distribution site?" | JD | [grounded] "green belt certified" — your message | Say the Green Belt in your own words. Name one project you ran, or say that your Green Belt work was not a project you ran. Answer slot: if you have applied the method beyond your Green Belt work, say where; if not, say so. | F8. Lean is "a plus" in the JD, so this is a scored question asked casually. |
| E3 | "Why operations leadership, and why now?" | JD | [generic] | Answer from your own reasons, in your own words. The pack supplies none. Keep it to two or three sentences, and end on what you want the role to do. | Motivation probe. No claim about your past. |

**Requirement coverage**

| JD requirement | Questions |
|---|---|
| own daily terminal operations across 4 sites | A1, B1, B4 |
| drive on-time performance and cost-per-shipment down | A1, A2, C4 |
| lead a team of 12 supervisors | A4, B1 |
| build reporting in Excel/Power BI | C3, C4, B3 |
| 5+ years operations leadership required | B2 |
| Lean/Six Sigma a plus | E2 |

Nothing uncovered. Total questions: 18.

## Reverse questions

Five or more, each with a why it lands. No interviewer profile exists, so none is tied to a career path. The round is assumed to be a hiring-manager round, so no peer reciprocity question is included.

1. "How are on-time results reported across the four sites today, and which site would you want fixed first?" Why it lands: it shows you are thinking in their measures, not generic ones.
2. "What does the reporting look like now: which system, and who reads it?" Why it lands: it surfaces the Power BI question directly, on your terms, and tells you what the role actually runs on.
3. "How is the supervisor layer split across the four sites today?" Why it lands: it tests the twelve-across-four gap with real numbers, so you know what B1 is really asking.
4. "What did the last person in this role leave undone?" Why it lands: it signals you are planning for continuity, not for a blank slate.
5. "What would make you say six months from now that this was the right hire?" Why it lands: it asks for their success criteria, which you can then build your first 90 days around.

## Sources

- Provided documents: your message, including the job description summary and your background.
- Research tier: L1, searches 2 of 6, fetches 0 of 2. Both searches were refused by the host, so nothing was looked up.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet (section not included). Both calls were refused. |
| 2. Atlas Freight interview process, operations manager | unavailable | Loop structure; persona weights would follow the named rounds. Both calls were refused. |
| 3. Atlas Freight strategy and recent news | unavailable | Company-strategy bank (CO questions, not included). No call was sent; search is blocked on this host. |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD you gave fixes the fit snapshot and the JD-tagged questions. |

Queries sent: "Atlas Freight regional logistics company values"; "Atlas Freight operations manager interview process". Both returned a permission refusal.

## Upgrade menu

- The full job posting, as written → the requirement quotes in the fit snapshot become exact, not summary.
- The interviewer's name → persona weights from their public footprint, and a reverse question tied to their career path.
- The round type and whether it is a panel → the persona weights are confirmed or reweighted.
- The four sites' locations and your willingness to work across them → the location gate is settled rather than assumed.
- Atlas Freight's published values and its interview process → a values cheat sheet and a loop structure, both currently missing because search was refused.
- Any company strategy or recent news → a company-strategy bank (CO and CASE questions grounded in current facts).
- Your leadership start date → F5 moves from low confidence to grounded, and B2 becomes a fact rather than a slot.
- A deeper research pass (up to 6 more searches and 2 more fetches, several minutes) once search is allowed → it would test the company and loop claims above.
