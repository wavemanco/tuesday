# Prep pack: Product Manager, Platform APIs at Quartzline

Hiring-manager conversation, 45 minutes, Thursday. Interviewer not named. Built from your underwriting dossier (`tuesday-dossier.md`, decision: conditional_go). Web search was refused in this session, so there are no Quartzline values, loop structure or strategy in this pack.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

- **Case** (CASE): a live problem from the role
- **Experience** (EXP): what you actually did, and how far it goes
- **JD**: whether you can do the listed job, gaps included
- **Company** (CO): not built here, since research was refused

Guidance is scaffolding for a spoken answer, not a script. Every guidance line about your past rests on a sentence quoted in the row, or on a plain acknowledgment the dossier supports. Where the material is silent, the line is an answer slot: you give the honest branch in your own words.

## Prep triage

Two days, so the order matters.

1. **Tuesday, tonight:** say A1 aloud twice, ending on the plain acknowledgment. Then D2 once.
2. **Wednesday:** B1 and B3 with a three-minute timer each. Work through A4's answer slot in your own words. Write RQ1 and RQ2 on a card.
3. **Thursday, before the call:** reread A1, A4 and C1 only.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row (verified_candidate_evidence 1); "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row (verified_candidate_evidence 3) | low | [inferred] | transferability | The integration work is adjacent to product management, and the bridge stays there. Say the quote at its own scope: "I led 30+ end-to-end client integrations, from scoping to go-live." Name the limit yourself: this is adjacent work, not product management experience. |
| F2 | "Shipped API or platform products" — dossier role_profile R2 (must_have) | None that reaches it. Nearest: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row (verified_candidate_evidence 1) | none | [inferred] | discovery | The dossier grades no row for this must-have, so the pack cannot say whether it is met. Answer slot: if you shipped something others built on, say what and your part in it. If the work was integrations of the vendor's REST APIs, say so plainly and return to the integrations you led. |
| F3 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row (verified_candidate_evidence 1); "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row (verified_candidate_evidence 3) | medium | [grounded] | transferability | The quotes reach customers and product. They do not show engineering or sales. Say the customer side as quoted, and name the limit: the material shows client-facing work, not engineering or sales stakeholders. |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 (important) | "Wrote the internal integration playbook her team uses" — dossier row (verified_candidate_evidence 2) | low | [inferred] | discovery | The playbook is about integration work. The material does not show whether it covers API docs or schemas. Answer slot: if you wrote or read docs and schemas for those integrations, name the artifact. If the playbook does not cover them, say so. |
| F5 | "Agile delivery experience" — dossier role_profile R5 (preferred) | none given | low | [inferred] | discovery | The dossier's clarify strategy applies: no verified entry speaks to agile delivery inside a product org. Answer slot: if you ran that cadence, say what it was and your part in it. If you never worked that way, say so, and say what you would want to confirm about how this team defines it. |
| F6 | "Owning a roadmap and prioritization authority" — dossier uncertain_or_weak_areas (R1 sub-claim) | none given; the dossier records this as acknowledge_gap | none | [grounded] | capability | Plain acknowledgment, sourced to the dossier's acknowledge_gap area and prohibited_claims: "I haven't owned a product roadmap, and I haven't set priorities for an engineering squad." Then your ramp plan, said as a plan, never as a past. No bridge, no slot. |

Reading the table: F2 is the row the dossier does not grade. A must-have with no verified row is the probe most likely to arrive unrehearsed. Ask the underwriter to grade it before Thursday. Until then the pack treats it as discovery, and A4 carries it.

## Prohibited claims

These are not coached in any cell of this pack. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "Having held a product manager title or role" | dossier prohibited_claims | Plain acknowledgment: "I haven't held a product manager title." |
| "Having owned a product roadmap" | dossier prohibited_claims and acknowledge_gap (F6) | Plain acknowledgment: "I haven't owned a product roadmap." |
| "Having set prioritization for an engineering squad" | dossier prohibited_claims | Plain acknowledgment: "I haven't set priorities for an engineering squad." |
| Led the integration roadmap | Inflated form of F1: "Led 30+ end-to-end client integrations" | F1's quote at its own scope. The limit is the pack's observation: your material says integrations, not a roadmap. |
| Wrote the team's standards | Inflated form of F4: "Wrote the internal integration playbook" | F4's quote at its own scope. The limit is the pack's observation: your material says a playbook. |

## Persona table

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live roadmap and partner problems (B1 to B5) | High: the hiring-manager prior | Clarify first, then structure aloud |
| Skeptic | The objection and the gap probes (A1 to A5) | High: the hiring-manager prior, and the dossier names the objection | Concede the plain acknowledgment cleanly, then hold the quoted work |
| Data-Driven Prober | Figures and artifacts (C1 to C3) | Medium | Name the counting basis you know; say plainly when you don't |
| Pressure | The headline claim pushed (D1 to D3) | Medium | Hold through two follow-ups, concede specifically |
| Conversational | The opener and the closing "any questions" (E1, E2) | Low | A 90-second arc, reverse questions ready |

Reasoning: weights rest on the hiring-manager relationship prior alone. There is no interviewer profile, no loop source and no company research. Case and Skeptic carry 5 questions each, Prober and Pressure 3 each, Conversational 2, for 18 in all. Values/Behavioral: not detected. No loop source documents a values round, and no archetype is named.

## Question banks

### A. Skeptic (highest weight)

A1 is the highest-ROI prep in this pack. The underwriter named this objection.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1); "Wrote the internal integration playbook her team uses" (dossier row 2). Acknowledgments sourced to dossier prohibited_claims and acknowledge_gap | Pause and restate the question. Concede first, in these words: "I haven't held a product manager title, and I haven't owned a product roadmap." Then answer from the two quotes, in their words. Name the adjacency once, as the dossier frames it: adjacent work, not PM experience. Then the ramp plan, as a plan. Hold through two follow-ups by returning to the quotes, never by adding to them. | The underwriter named this as the likeliest objection. It targets F1 and F6, where the material is thinnest. Saying the concession cleanly, out loud, matters most. |
| A2 | "What would you do in your first 90 days owning the partner API roadmap?" | JD | [generic] Own the roadmap for the partner-facing API platform (dossier role_profile responsibility) | A plan, not a past. Say what you would learn first: how adoption is measured today, who decides roadmap calls, and the partner discovery you would run. Do not describe any roadmap you have run. | The ramp plan the acknowledgment in A1 promised. Covers F6 and F1 without claiming either. |
| A3 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Name the weak parts before the interviewer does: roadmap ownership first (F6, plain acknowledgment), then agile delivery inside a product org (F5). For F5, answer slot: if you ran that cadence, say what it was and your part; if you never worked that way, say so and what you would confirm about how this team defines it. | A persona stem. Shows the honest weakest areas and puts the ramp after them. |
| A4 | "Tell me about an API or platform product you shipped." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1) | An open prompt, with its theme from R2, "Shipped API or platform products" (JD line). Answer slot: if you shipped something others built on, say what and your part in it. If the work was integrations of the vendor's REST APIs, say so plainly and stay with the integrations you led, from scoping to go-live. Do not call integrations a shipped product. | R2 is a must-have the dossier does not grade (F2). The probe the material does not answer is the one most likely to come, so the honest answer should be ready. |
| A5 | "Tell me about a time an engineering team and a client disagreed on scope — what happened?" | JD | [grounded] "scoping, requirements" from "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1); theme from R4 (JD line) | An open prompt. Story from the client side of the integrations: scoping and requirements, as quoted. Answer slot: if you negotiated scope with an engineering team, say how. If you did not, or it was not yours, say so plainly and stay with the client-side scoping. Do not describe an engineering negotiation you did not have. | R4 is important. The material shows only client-side work, so the honest answer names that limit. |

### B. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you'd approach the partner API roadmap — what do you need to know first?" | CASE | [generic] Own the roadmap for the partner-facing API platform; Run discovery with integration partners (dossier role_profile responsibilities) | Clarify, then objective, segmentation (which partners, which integration paths), approach, metrics, risks. Lead with the questions: how adoption is measured today, and who decides roadmap calls. Say the framework aloud. | A live problem on the role's own roadmap. This is where the hiring manager is buying capability. |
| B2 | "Partner API adoption fell after a release — diagnose it." | CASE | [generic] | Clarify the metric first. The dossier records that how adoption is measured today is unknown, so ask for the definition before any diagnosis. Then segment by partner, release and integration path, and name your weakest assumption about the data. Do not claim a diagnosis you have run. | Tests the adoption-metrics risk. The first move is a question you need answered anyway. |
| B3 | "Two engineering squads want different priorities for the same quarter. How do you decide?" | CASE | [generic] Write specs and drive delivery with two engineering squads (dossier role_profile responsibility) | Ask first who holds the call between squads, because the answer changes the approach. If the squad leads decide, bring the evidence and the trade-off. If you decide, state your criteria. Do not claim a past prioritization decision for a squad. | Decision authority is the dossier's top unknown. The answer shows judgment without claiming authority. |
| B4 | "A partner's integration fails in production on a release you scoped. What's your first hour?" | CASE | [generic] | Confirm the scope of the failure. Decide rollback or hotfix with the squad that owns the release. Send one message to the partner. Name an owner. Speakable in 90 seconds. Do not describe a production incident you have handled, since nothing in your material shows one. | Tests cross-team response under pressure. |
| B5 | "The partner roadmap has 30 open requests. How do you cut it?" | CASE | [generic] | Name the criteria before the framework: partner value, effort, and fit with the platform. Then how you would check them with the squad leads. Name one adoption metric you would want to see. Keep the framework short and say it aloud. | Live prioritization. The answer must not claim a real roadmap was prioritized. |

### C. Data-Driven Prober (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1) | Defend the number in your own words: what counted as one integration, whether 30+ was a count you kept or an estimate, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you know the counting basis, say it. If you do not, say so plainly. | The quote gives the number and nothing about how it was counted. The pack supplies no counting method. |
| C2 | "Show me the playbook. What does it cover, and how do you know it's used?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" (dossier row 2) | Say what the playbook covers, and point to the document itself. The dossier records it as inspectable, so offer to walk through it. Do not claim more adoption than the quote states. | Inspectable proof is the strongest thing this material has. Use it. |
| C3 | "Tell me about the quarterly roadmap-input sessions: what went in, and what came out?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row 3) | Lead with the limit. This is the medium-confidence item, with limited inspectable proof. Say what went in (client evidence) and what you can show of what came out. If you can show nothing, say so. Do not claim any roadmap change the sessions caused. | Medium confidence. The dossier expects a probe, so volunteer the limit before it is extracted. |

### D. Pressure (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 30+ figure — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1) | Hold "led" as the quote states it, through two follow-ups. Say which phases were yours, in those words. Concede only where the work was not yours, and name the others' share plainly. Never fold on "led" just to restore comfort. | A pressure stem on the headline claim. The hold-then-concede rehearses honest attribution. |
| D2 | "You want to own a roadmap you've never owned. Why shouldn't I expect a year of ramp?" | JD | [grounded] plain acknowledgment sourced to dossier acknowledge_gap (F6) | Concede the premise first: "I haven't owned a product roadmap." Then hold on what you can stand behind: the integration work and the roadmap-input sessions (dossier rows 1 and 3). Do not promise a shorter ramp. Say what you would test first. | Concede cleanly. Do not fold on the work you did, and make no timeline claim. |
| D3 | "This is a platform product role and your background is client integrations. Why isn't that a lateral move?" | JD | [inferred] derivation: this role's responsibilities set against dossier row 1 | Hold the adjacency with its limit. The integrations were client-side work on the vendor's APIs. Say it is adjacent, not product management experience. Concede the lateral part plainly if pressed. | The question challenges the transferability limit directly. The pack's line is adjacency, with the limit named. |

### E. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1); "Wrote the internal integration playbook her team uses" (dossier row 2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row 3) | A 90-second arc: the integration work, the playbook, the roadmap-input sessions, then where you want to go and why this role. Stop at the three quotes. The arc names the adjacency and nothing more. | Casual, but scored. A clean arc is the first thing the hiring manager hears. |
| E2 | "What are you hands-on with in API docs and schemas these days?" | JD | [inferred] derivation: R3, "Technical fluency: API docs, schemas" (dossier role_profile) | Name only what your material carries: the REST API integrations and the playbook (dossier rows 1 and 2). Say what you have read or reviewed, not what you have built. Do not name tools you have not used. | Casual, but it is R3. Answer with the material you have. |

## Requirement coverage

| Requirement or responsibility | Covered by |
|---|---|
| R1: 3+ years product management experience | A1, A2, A3, D2, D3 |
| R2: Shipped API or platform products | A4 |
| R3: Technical fluency: API docs, schemas | E2, C2 |
| R4: Stakeholder management across engineering, sales, customers | A5, B3 |
| R5: Agile delivery experience | A3 (answer slot) |
| Own the roadmap for the partner-facing API platform | A2, B1 |
| Run discovery with integration partners | B1, B2 |
| Write specs and drive delivery with two engineering squads | B3 |
| Define and track adoption metrics | B2, RQ2 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Resolves the decision-authority question the underwriter flagged. The JD asserts the authority but nothing evidences it. | [grounded] dossier questions_for_employer |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | Asks for the baseline the JD names but nothing states. The answer also shows you what B2 will look like. | [grounded] dossier questions_for_employer |
| RQ3 | "What would make the first six months in this role a clear success?" | Gives you the success criteria the 90-day plan in A2 should answer to. | [generic] |
| RQ4 | "Where do the two engineering squads and partner discovery hand work to each other?" | Tests the seam, and shows whether discovery is yours to run. | [generic] |
| RQ5 | "What has been tried on partner adoption before, and what did it teach the team?" | Shows you are not repeating a failed effort, and surfaces the baseline the team already holds. | [generic] |

## Sources

- **Dossier consumed:** `tuesday-dossier.md`, version 1.1. Sections supplied: `role_profile` (the JD tier: requirements, responsibilities, unknowns), `handoff_to_mock_interview` (the CV tier, weak areas, the named objection, risks, employer questions, prohibited claims) and `decision` (context only). Everything in the fit snapshot about your past rests on the dossier's verified entries. The pack's own inference is marked [inferred].
- **Round type:** from your message: hiring-manager conversation, 45 minutes. No interviewer profile was given.
- **Research tier:** L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet, section 10. Not built. |
| 2. Quartzline interview process, product manager | unavailable | Loop structure. Persona weights stay on the hiring-manager prior. |
| 3. Quartzline strategy, recent news | unavailable | Grounding brief and CO bank. Not built. |
| 4. Interviewer name with Quartzline | n/a | No name was given. |
| 5. Representative Product Manager JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD questions. |

Queries sent, all refused by the host (web search permission was not granted):
- "Quartzline company values principles": refused
- "Quartzline interview process product manager platform APIs": refused
- "Quartzline strategy recent news": refused

## Upgrade menu

- The interviewer's name → a public-footprint read, persona weights tuned to it, and a reverse question tied to their own path
- A recruiter's note on the loop (how many sessions, who runs each) → the loop established, persona weights retuned, and a values round checked for
- Quartzline's values page, pasted → the values cheat sheet, mapping each value to a story from your quoted sentences
- Web search enabled, then the three L1 searches above rerun → the values, loop and strategy targets filled, if they return attributable sources
- The integration playbook, if you can share it → you could name it by title in A1, C2 and E1, as the inspectable artifact the dossier records
- Your CV, pasted → quotes from your own sentences in place of the dossier's wording
