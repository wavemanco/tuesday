# Operations Manager, Atlas Freight: interview prep pack

Interviewer: not known. Round: assumed to be a hiring-manager round, since the note did not say who you are meeting. Every bank is weighted on that assumption.

Not included, because no input sits behind them: prep triage (prep time not given), values cheat sheet (no published values in hand), interviewer read (no name), graded deliverables (none declared), delivery coaching (no assessment).

## How to use this pack

Personas are how a question is asked. Types are what it scores:

- **EXP**: work-experience deep-dive. Tests whether what is on your record holds up under questions.
- **JD**: role-driven. Tests whether you can do what the posting lists, including the gaps.
- **CASE**: live problem. Tests structure and reasoning on a problem from the job.
- **VAL**: values. Not used here, since no values round was detected.
- **CO**: company knowledge. Not used here, since company research did not run.

Guidance is scaffolding, not a script. Rehearse your own words.

## Fit snapshot

Requirements are quoted from the job description you gave. Your evidence is quoted from your own message. "Five-plus years of operations leadership" is a length requirement, not a legal or credential gate, so it is graded like any other row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows operations at one site, through a shift role, not four terminals. Words: "I've worked seven years in warehouse and distribution operations." Answer slot: if you set a daily routine you would carry across four sites, describe it in your own words; if you did not, say so and say how you would set one up across four. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors, not twelve. Words: "I'm a senior shift manager over three supervisors." Answer slot: if you have led a group larger than three, say how it was set up; if you have not, say so plainly and say what you would put in place first. |
| F3 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | low | [inferred] | discovery | Your material gives seven years of operations work. It does not say how many were in a leadership role, and this pack will not assume a number. Answer slot: count the years you held a leadership role and give that count; if you cannot count them, give the years you can stand behind, in your own words. |
| F4a | "build reporting in Excel/Power BI" (JD), Excel half | "solid Excel" (your message) | medium | [grounded] | presentation | The quote reaches the Excel half in other terms. Words: "I'm solid in Excel." No claim about reports built is in the material. |
| F4b | "build reporting in Excel/Power BI" (JD), Power BI half | "never used Power BI" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't used Power BI." Then a plan, said as a plan and never as a past: how you would learn it and how fast. |
| F5 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | No gap: the quote reaches the requirement. Say it as you said it: "Green Belt certified." Expect a probe on how you applied it (P4). |
| F6 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows a measured quality result, the mis-pick rate. It does not show on-time performance or cost per shipment. Words: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if you measured on-time performance or cost per shipment, name the figure and how it was counted; if you did not, say so and name the measure you would start with. |

Confidence is about your evidence. Provenance is about what this pack wrote. A medium band means the claim is yours but nothing has been inspected. Upgrading it needs an artifact (see the upgrade menu).

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic | Probes the gaps: scale, supervisors, leadership years, Power BI | High. Hiring-manager prior, and F1 to F4b are the rows the posting presses hardest | Rehearse S2 until it is boring. Say each limit plainly, then say what you would do | 5 (S1 to S5) |
| Data-Driven Prober | Asks how the 40% was counted, what the reporting is, which metric you measured | High. The posting names cost per shipment and reporting; the 40% is the figure most likely to be questioned | Defend the number in your own words; name the weakest assumption before they do | 5 (P1 to P5) |
| Case/Strategist | Live problems from the job: a drop in on-time performance, peak planning, staffing | Medium to high. Hiring managers often test on live problems | Clarify, segment, measure, then decide. Say the assumptions aloud | 4 (C1 to C4) |
| Pressure | Interrupts on the three-supervisor gap; time-boxes the answer | Medium. The twelve-supervisor gap invites a stress probe | Pause, restate, hold the position you can back through two follow-ups, then concede exactly what you cannot | 2 (PR1, PR2) |
| Conversational | A casual opener that is still scored | Medium. Openers are often the first scored question | Keep a ninety-second arc built only from your own sentences | 2 (CV1, CV2) |

## Question banks

Provenance comes first in each row. It holds the sentences the guidance rests on, quoted from your message or the job description.

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Four sites, every day. Where would you start?" | CASE | [grounded] "7 years in warehouse and distribution ops" | Start with what you know from your own work: the daily routine, the people who run it, the numbers you watch. Answer slot: if you set a routine you would carry across four sites, describe it in your own words; if you did not, say so and say how you would set one up. | Live version of F1. A case, so it asks for no claim about your past. |
| S2 | "You have run three supervisors. Twelve is four times that. What changes?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | **Highest-ROI prep in this pack.** Hold: "I'm a senior shift manager over three supervisors." Answer slot: if you have led a larger group, describe how it was set up; if not, say so plainly and say what you would put in place first. Hold through two follow-ups by returning to the three you lead. | F2 is the largest gap and the most predictable objection. The rehearsal is the honest answer, rehearsed. |
| S3 | "Five years of operations leadership is required here. How many of your years were in leadership?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer slot: count the years in a leadership role and give that count; if you cannot count them, give the years you can stand behind. The pack supplies no number. | F3. The requirement is a length, so the answer is a count, not a claim. |
| S4 | "Your background is warehouse work. Why this role, and why now?" | EXP | [grounded] "7 years in warehouse and distribution ops" | Selection scaffold: say what this role asks that your current site does not, in terms you can defend. If no such reason comes to mind, say so plainly, then give the nearest thing your material does carry: seven years of distribution operations. | Motivation probe. The material gives no reason for moving, so the reason is yours to supply. |
| S5 | "Power BI is part of the reporting here. What have you built in it?" | JD | [grounded] "never used Power BI" | Plain acknowledgment: "I haven't used Power BI." Then a plan: what you would learn first and how you would show progress. No claim of Power BI work. | F4b, a gap you stated. The honest answer is the acknowledgment plus a plan. |

### Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Defend-the-number: say what the rate measured, over what period, against what starting point, in your own words. Weakest-assumption move: name the assumption behind the 40% you would defend least, before they do. Answer slot: if you know the starting point and the period, state them; if you do not know how it was counted, say so plainly. | The headline figure on the record gets a defend-the-number question. The pack supplies no baseline, method or period. |
| P2 | "Which of on-time performance and cost per shipment have you measured yourself?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you measured either, name it and how it was counted; if neither, say so and describe the mis-pick measure as the nearest thing you measured. | F6. Tests the gap between the posting's metrics and your record. |
| P3 | "Show me a report you built in Excel. What did it track, and who used it?" | EXP | [grounded] "solid Excel" | Answer slot: if you built a report others used, describe what it tracked and who used it, in your own words; if you did not build one, say what you did in Excel and say so plainly. | F4a. The posting names reporting; the material shows Excel skill, not a report. |
| P4 | "Green Belt. How did you use it on the pick path?" | EXP | [grounded] "green belt certified" and "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if a Green Belt method shaped the redesign, name which method and what it showed; if it did not, say so, and describe the redesign as you did it. | F5. The Lean or Six Sigma plus is probed by asking whether the certification was used. |
| P5 | "What is cost per shipment at your site today, and how has it moved?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you know the figure and its trend, give them in your own words; if you do not, say so and say how you would find it. | F6 again, on the posting's own metric. |

### Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "On-time performance drops ten points at one site in a week. What do you check first?" | CASE | [generic] | Clarify what changed, then segment by shift, lane and dock, then decide what to act on. No claim about your past. | A live problem from the posting's own metric. |
| C2 | "Peak season is six weeks out and volume is up 30 percent. Walk me through the plan." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Story map: the plan, and the two seasons it was run, which are the beats the quote states. Answer slot: if you set the staffing and volume decisions, say how you made them; if you did not, say so and describe your part. | The closest thing in your material to a live plan. |
| C3 | "What would you measure in the first month, and what would you change first?" | CASE | [generic] | Clarify the baseline, pick two measures, agree targets with the site leads. No claim about your past. | Tests judgment about a new role, not your record. |
| C4 | "Two sites disagree about how to staff peak. How do you decide?" | CASE | [generic] | Name the decision rule first, then the data you would check, then who decides. No claim about your past. | Tests judgment across sites, which the posting asks for. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| PR1 | "You have three people. Why should I believe you can lead twelve?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Pause, then restate: "I'm a senior shift manager over three supervisors." Hold through two follow-ups by returning to what you lead now. Concede specifically: if the honest answer is that twelve is more than you have led, say that plainly and name what you would do first. | F2 under pressure: hold what you can back, concede exactly what you cannot. |
| PR2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you did the redesign, say which parts you designed, in your own words; if it was a team's, say your part and nothing more. Hold your part; concede shared credit specifically. | The pressure form of P1: an attribution probe. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| CV1 | "So, walk me through how you got here." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path" | A ninety-second arc whose beats are those three quotes, in that order: where you started, what you run now, one measured result. Nothing added. | Casual openers are scored. The arc is your sentences, in order. |
| CV2 | "What part of operations do you enjoy most?" | EXP | [generic] | Selection scaffold: name the part you would choose and why, in your own words. If none comes to mind, say so plainly, then name the part of your record you would most want to talk about. | Rapport question with a real answer behind it. |

**Requirement coverage.** Every stated requirement maps to a question:

- Own daily terminal operations across 4 sites: S1, C4
- Drive on-time performance and cost-per-shipment down: C1, P2, P5
- Lead a team of 12 supervisors: S2, PR1
- Build reporting in Excel/Power BI: P3, S5
- 5+ years operations leadership: S3
- Lean/Six Sigma a plus: P4

## Reverse questions

Each has a one-line reason it lands.

1. "What would a new person need in place in the first 90 days across the four sites?" Lands because it shows you are thinking at the scale of the job.
2. "Which site is furthest behind on on-time performance right now, and what is the cause?" Lands because it names the real problem before they do.
3. "How is cost per shipment calculated today, and who owns that number?" Lands because it is the question a data-minded manager expects.
4. "What reporting do site leads use each day, and where does it fall short?" Lands because it engages the reporting requirement without assuming a tool.
5. "How will success in this role be measured in the first year?" Lands because it mirrors the posting's two targets.

## Prohibited claims

What this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across four sites | Inflated form of F1. The material shows one site through a shift role. | "I've worked seven years in warehouse and distribution operations." The limit is the pack's observation: your material does not show four sites. |
| Leads twelve supervisors | Inflated form of F2 | "I'm a senior shift manager over three supervisors." |
| Seven years of operations leadership | Inflated form of F3. The material gives years of operations, not leadership years. | "I've worked seven years in warehouse and distribution operations." Leadership years are answered by S3's slot. |
| Built reporting in Excel or Power BI | Inflated form of F4a; a negative you stated for F4b | "I'm solid in Excel." "I haven't used Power BI." |
| Drove on-time performance or cost per shipment down | Inflated form of F6 | "I cut the mis-pick rate 40% by redesigning the pick path." |

## Sources

Provided documents: your message (your background, the gaps you named, the job description summary you gave).

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet, not included: no values round detected. Call sent: "Atlas Freight regional logistics company values". Refused. |
| 2. Atlas Freight interview process, operations manager | unavailable | Loop structure. Persona weights fall back to a generic hiring-manager prior, said plainly. Call sent: "Atlas Freight interview process operations manager". Refused. |
| 3. Atlas Freight strategy and recent news | unavailable | Company-strategy (CO) questions, not written. Call sent: "Atlas Freight logistics strategy news". Refused. |
| 4. Interviewer name | n/a | No name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The job description you supplied fixes the fit snapshot and JD questions. |

No tuesday-dossier.md was in this conversation. A check of the file system for one was not permitted, so none was read.

## Upgrade menu

- Who you are meeting, and whether they are your future manager, a peer, or above you → persona weights for the actual round (asked below)
- The interviewer's name → a tailored reverse question, and persona weights from their public professional footprint (search was not permitted here, so this needs search access or pasted material)
- Atlas Freight's values page, or the recruiter's note on focus areas → a values cheat sheet if values are published, and a loop structure
- How many of your years were in a leadership role → S3 gets a count, and F3 moves from discovery to grounded
- Your Green Belt certificate → F5's confidence moves from medium to high
- An Excel report you built: what it tracked, who used it → F4a and P3 get a real example to rehearse
- How the 40% was counted, if you have it written down → P1 can rehearse your own method instead of a question about it
- A deeper research pass on the company, up to 6 more searches and 2 more fetches, several more minutes → strategy-anchored CASE questions and CO questions. Needs search access.
