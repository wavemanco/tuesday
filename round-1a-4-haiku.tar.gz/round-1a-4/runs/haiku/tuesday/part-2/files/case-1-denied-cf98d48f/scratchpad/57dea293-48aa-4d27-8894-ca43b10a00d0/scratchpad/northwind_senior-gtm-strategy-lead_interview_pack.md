# Interview prep pack: Senior GTM Strategy Lead, Emerging Products

**Company:** Northwind Data
**Interviewer:** Dan Kovac, Director of Sales Strategy. Peer, same VP.
**Round:** 60-minute conversation, one session.
**Built on:** your message only. Web research was refused by the host, so every outside fact is absent or labeled.

## How to use this pack

- **Personas** describe how a question will be asked: its tone and pressure.
- **Types** describe what the question is scoring. Tags used here:
  - **EXP**: work-experience deep-dive. Tests whether what she did survives scrutiny.
  - **JD**: role and JD-driven. Tests whether she can do the listed job, gaps included.
  - **CO**: company and strategy knowledge.
  - **CASE**: live problem from the role, structured on the spot.
  - **VAL** is not used. No values-style round was detected, because no loop source was read.
- Guidance is scaffolding, not a script. Rehearse the shape, then say it in her own words.
- Every candidate sentence the guidance rests on is quoted in full, with its source named.

## Fit snapshot

Requirements are quoted from your JD highlights. Candidate evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights, your message) | "built a partner-level revenue model used in carrier negotiations" (your message); "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | medium | [grounded] | transferability | Your material shows product strategy and a pricing-adjacent model. It does not show GTM ownership of a product line. Say the model at its own scope. Answer slot: if you owned any part of a go-to-market plan, say which part and how you decided it. If you did not, say that and describe the product strategy work you did. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights, your message) | none given. Adjacent only: "set annual volume targets with cross-org consensus" (your message) | low | [inferred] | discovery | Volume targets are not whitespace. The material is silent on lifecycle-stage sizing. Answer slot: if you have sized opportunity across any of land, adopt, expand or renew, say which and how. If you have not, say so and describe how you would start. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights, your message) | "skilled in SQL/Tableau" (your message) | low | [inferred] | discovery | The tools are stated. Independent analysis is not shown: no artifact, no question answered. Answer slot: name one analysis you ran yourself, the question it answered, and the tool. If you did not run one independently, say so. |
| F4 | "partner-motion design experience required" (JD highlights, your message) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | Partner economics are adjacent. Partner-motion design is not shown. Say the partner model at its own scope, and say the economics are what you bring. Answer slot: if you designed any part of a partner motion, say which part. If not, say so. |
| F5 | "strong cross-functional influence" (JD highlights, your message) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | presentation | The quote already reaches cross-org influence in other terms. Reword only that quote: "I set annual volume targets with cross-org consensus." Add no forum, stakeholder or outcome. |
| F6 | "AI experience a plus" (JD highlights, your message) | "uses AI tools daily" (your message) | low | [inferred] | transferability | Daily use is not building AI products or features. Say the use concretely, and do not stretch it toward building. |
| F7 | Not in JD highlights. Raised by your message's own absence statement. | "No classic sales-ops or quota-setting experience." (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't done classic sales-ops or quota-setting work." Then the adjacent quote at its own scope: "set annual volume targets with cross-org consensus." No slot. This is the row that most needs rehearsal (see D1). |

**Gates.** No row is a gate. The highlights state no location, work-pattern, authorization or pay term. Full JD text might add one (see the upgrade menu).

## Reading the interviewer

Source: your message only. Public footprint was not checked.

- **Career pattern.** Pricing and monetization roles, with one early-stage startup chapter.
- **Self-described style.** "relentlessly data-driven".
- **Practical implications:**
  1. He will probe every number to its assumptions. Expect the Prober's follow-ups to go two levels deep.
  2. Case questions should lean toward pricing, packaging and unit economics. That is his native language.
  3. Builder stories from the startup-era part of her career would land well, if she has any. Her material shows none, so do not invent one.
  4. The startup chapter suggests he may test big-company pace. Be ready to describe how a large company's process still gets a new line to market.
- **Mirror opportunities.** None offered. No quoted sentence carries her side of a career jump like his, so none is claimed.

## Persona table

Relationship prior: peer. Peer Evaluator and Data-Driven Prober dominate. The signals below raise the Prober and tilt cases toward pricing. No documented Northwind loop was read, so these weights rest on the peer prior, not on Northwind's process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (A) | Seam-splitting between pricing and GTM, disagreement style, credit-sharing | High. A peer is pricing what the hire costs his team. Peer prior, plus the JD's cross-functional line | Propose seam principles rather than claiming to know his team's seam. Reciprocity framing. Disagreement story with spine and tact |
| Data-Driven Prober (B) | Asks for denominators, counting method, validation, and the weakest assumption | High. Self-described "relentlessly data-driven". Peer prior also favors it | Know what she can say about each number and say plainly when she does not know. Name the weakest assumption before he does |
| Case / Strategist (C) | Live pricing, bundling and whitespace problems | Medium. Pricing spine tilts cases. Strategy questions raised by the research note | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud |
| Skeptic (D) | Probes the no-sales-ops, no-quota gap and the partner-motion gap | Medium. The stated absence in F7 is the likeliest objection from someone who runs sales strategy | Rehearse the F7 objection until it is plain. Bridges from adjacent evidence only. Calibrated candor |
| Pressure (E) | Time-boxed challenge on the $400M and on her standing against an internal candidate | Low. Peer relationship makes pressure less likely, but his probing can feel like it | Pause, restate, hold a claim through two follow-ups, concede specifically |
| Conversational (F) | Casual opener and a casual JD-plus question | Low. Opening only; still scored | 90-second arc. Treat casual AI questions as scored |

## Question banks

Coverage is the first table. Each requirement maps to question IDs. Questions raised by the absence in your message are marked as such.

| Requirement or raised topic | Covered by |
|---|---|
| own GTM strategy for two new product lines | A5 |
| identify whitespace across land/adopt/expand/renew | B5, D3 |
| run independent analysis in SQL and Tableau | B4 |
| partner-motion design experience required | A4, D2 |
| strong cross-functional influence | A1, A2 |
| AI experience a plus | F2, C3 |
| No classic sales-ops or quota-setting experience (raised by your message, not the JD) | D1 |
| Strategy priorities and bundling threat (your research note) | C2, C3, R4, R5, R6 |

Total: 20 questions. Depth follows persona weight: 5, 5, 3, 3, 2, 2.

### A. Peer Evaluator (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [grounded] "strong cross-functional influence" (JD highlights, your message); "set annual volume targets with cross-org consensus" (your message) | Name the cross-org forum where the volume targets were agreed, using her quote's words. Propose seam principles: one forum for pricing and GTM calls on a new line. Answer slot: if a disagreement came up, say how it was resolved, in your own words. If none did, say so, then describe how you would raise one early | Scores the JD's influence requirement in collegial packaging. Covers F5 |
| A2 | "How do you handle credit when work spans teams?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Use the word "credited": she proposed the change, and the uplift was credited to it. Say whose work the rest of the result was, if she knows. Answer slot: name the people who did the analysis, if she was not one of them | Credit probe. The sentence's verb is "proposed", so keep it there |
| A3 | "Pricing and go-to-market get tangled on a new line. Where have you seen those decisions split badly?" | JD | [generic] | Name one principle: a single decision log with named owners for price and for motion. Make no claim about his team or any past split | Tests seam awareness. Pure principle, so no candidate claim |
| A4 | "You've built partner economics. How would you design a partner motion when the partner is also a channel you compete through?" | JD | [grounded] "partner-motion design experience required" (JD highlights, your message); "built a partner-level revenue model used in carrier negotiations" (your message) | Describe the partner-level revenue model at its scope: what it priced, who used it in carrier negotiations. Then reason through the motion as a plan. Answer slot: if the model changed a term in a negotiation, say which term. If it only informed the talks, say that. If she designed no partner motion, say so, then say what the economics would tell her first | F4 gap. The motion design is the part she has not shown |
| A5 | "Where would you draw the line between a product-strategy call and a GTM call on a new line?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights, your message); "proposed a store-surface change" (your message) | Describe decision rights, not ownership she lacks. Answer slot: if she set any GTM call herself, name it. If not, say that and describe where she would draw the line | F1 gap. Tests whether she knows where her current scope stops |

### B. Data-Driven Prober (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that $400M figure was counted." | EXP | [grounded] "credited with a ~$400M ARR uplift" (your message) | Say what the uplift was measured against and who counted it, if she knows. Answer slot: if she does not know how it was counted, say so plainly. Never supply a method | Headline metric, defend-the-number slot. He will test the counting first |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Name the assumption she knows is weakest, in her words, before he does. Answer slot: if she cannot name one, say that plainly and say what she would check first. No assumption is supplied here | Weakest-assumption move. This is the Prober's native question |
| B3 | "Which inputs in the partner-level revenue model would you have changed first, and why?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Name the inputs she set and any she inherited. Answer slot: if she did not choose the inputs, say whose they were. Never say the model was validated unless she can say how | Premised question on the quoted model. The premise is only that the model exists |
| B4 | "Tell me about an analysis you ran in SQL or Tableau that nobody handed you." | EXP | [grounded] "skilled in SQL/Tableau" (your message); "run independent analysis in SQL and Tableau" (JD highlights, your message) | Selection scaffold: pick one analysis she ran herself. Name the question it answered, the data, and one place it could be wrong. Answer slot: if no analysis of that kind comes to mind, say so plainly, then give the nearest one she did | F3 gap. The open prompt chooses an instance; the guidance supplies none |
| B5 | "Whitespace across land, adopt, expand and renew. What would you measure first, and what would make the number misleading?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights, your message) | Structure it: define the unit (accounts, not dollars, or the reverse), name the data, name the weakest assumption. No candidate claim | Tests the JD's whitespace requirement with no past claim. F2 gap |

### C. Case / Strategist (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your first new line needs partner pricing. What would you test first?" | CASE | [generic] | Clarify the objective, then segment partners by how they would use the line, then the approach, the metrics, and the risk to margin. Think aloud. Challenge one premise he gives | Pricing-native case. No past claim |
| C2 | "A much larger platform vendor bundles a competing feature into its suite. How would you respond for an emerging line?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | Do not recite a consensus list. Segment where bundling loses, price the value it cannot match, choose a partner channel, and name one divergence you would bet on. Caveat: the note's date is unknown; confirm it is current before the interview | Competitive frame from your note. Differentiate, do not recite |
| C3 | "Compass is the copilot launch. Where does an emerging line sell into it, and what would you decline to sell?" | CO | [grounded] "an AI copilot launch ('Compass')" (your research note); "AI experience a plus" (JD highlights, your message) | Propose one attach point for an emerging line. Name one segment you would decline, since saying no is part of the role. Make no claim about Northwind's internal plans | AI priority from your note. Also covers F6 |

### D. Skeptic (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have no sales-ops or quota-setting background. Why should my team trust targets you set?" | EXP | [grounded] "No classic sales-ops or quota-setting experience." (your message); "set annual volume targets with cross-org consensus" (your message) | Highest-ROI rehearsal in this pack. Hold: "I haven't done classic sales-ops or quota-setting work." Then the adjacent quote at its own scope: "set annual volume targets with cross-org consensus". Answer slot: say how the targets were agreed and who signed them off. If she did not set them alone, say so. Hold through two follow-ups by returning to the volume-target quote. Concede specifically if pressed: "I haven't owned quota design. I would want your team's process before I touched it" | F7, the stated absence. Predictable from a sales-strategy peer. The guidance never turns "volume targets" into "quotas" |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" (JD highlights, your message) | Name partner-motion design as the weakest part, and say why. Answer slot: if she has designed any part of a partner motion, say which part. If not, say the partner economics are what she brings, and the motion design is what she would learn first | F4. Names a gap she can own honestly |
| D3 | "I don't see whitespace work in your background. How would you handle land, adopt, expand and renew?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights, your message) | Answer as a plan, not a past. Answer slot: if she has sized opportunity across any of those motions, say which. If not, say so and describe the first two steps | F2. The probe is an observation, so she answers the plan, not the claim |

### E. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should this seat be yours over someone already on the team?" | EXP | [generic] | Pause. Restate the question. Hold a position built from her strongest sentences: "built a partner-level revenue model used in carrier negotiations" (your message). Hold through two follow-ups. Concede specifically on quota design only (see D1) | Composure test. The held position is quoted, not stronger |
| E2 | "That result. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Say what she proposed. Say what others did, in her words. Answer slot: name the parts of the result she did not produce | Attribution pressure. Same discipline as A2 and B1 |

### F. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting" (your message); "9 at a large consumer-tech company in product strategy & ops" (your message) | 90-second arc: consulting, then product strategy and ops, then the partner revenue work, then why this seat. Each beat is a clause the quotes state | Opener, scored for economy. Pre-scripted arc |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message); "AI experience a plus" (JD highlights, your message) | Name one tool and one task she does with it. Do not expand daily use into building AI features | F6. Casual register is still scored |

## Reverse questions

Each one is for him. Premises about his path come from your message and are not publicly checked.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your path has included pricing and monetization, plus a startup chapter. Which of those is closest to what a new emerging line needs from this seat?" | Ties to his own path. Turns the conversation into a peer's. Provenance: [grounded] "pricing and monetization roles" (your message) |
| R2 | "Which pricing or packaging call on a new line has been hardest to reverse?" | Speaks to his native language. Invites a data-driven answer |
| R3 | "What could a new person do in the first month that would genuinely help your team?" | Reciprocity question, required for a peer. Shows she is planning to help, not only to be assessed |
| R4 | "Where is the bundling threat most real for the company, and where is it overstated?" | Uses the competitive frame from your note. Provenance: [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) |
| R5 | "Over the next two quarters, how does Compass change where sales strategy spends its time?" | Shows she has read the priorities. Provenance: [grounded] "an AI copilot launch ('Compass')" (your research note) |
| R6 | "How do the profitability targets show up in the decisions for a new line?" | Ties to the third priority. Provenance: [grounded] "reaching profitability" (your research note) |

## Prohibited claims

Built locally from the fit snapshot. These claims will not be coached, in any answer, slot, hold or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1. The material shows product strategy and a partner model | The partner model at its own scope. Your material says the model, not GTM ownership |
| Set quotas, or designed sales comp | Stated absence (F7): "No classic sales-ops or quota-setting experience." | "I haven't done classic sales-ops or quota-setting work." No answer slot here |
| Owned the $400M | Inflated attribution of "credited with a ~$400M ARR uplift" | "proposed a store-surface change credited with a ~$400M ARR uplift." Your material says credited, not produced |
| Designed partner motions | Inflated form of F4, from the partner model | The partner model at its own scope. The motion design stays an answer slot |
| Built or shipped AI products | Inflated form of F6, from "uses AI tools daily" | "uses AI tools daily", said concretely |

## Sources

**Provided documents:** your message (JD highlights; candidate summary; Northwind research note; interviewer description). No CV text, full JD or dossier was provided.

**Searches and fetches sent.** Each was refused by the host's permission check. None returned a result, and no page was fetched.

| Query sent | Outcome |
|---|---|
| Northwind Data company values | refused |
| Northwind Data interview process sales strategy | refused |
| Northwind Data Compass AI copilot launch | refused |
| Dan Kovac Director of Sales Strategy Northwind Data | refused |

**Research tier: L1, searches 4 of 6, fetches 0 of 2.** The four calls were sent and refused. Counted against the budget.

**Target accounting**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Would have settled whether a values-style round exists, which decides whether a values section is built. Currently none |
| 2. Northwind interview process, sales strategy | unavailable | Would have named Northwind's loop. Persona weights rest on the peer prior until it does |
| 3. Northwind strategy / recent news | unavailable | C2, C3, R4, R5 and R6 rest on your research note. Its date is unknown, and a search would have dated it |
| 4. Dan Kovac, Northwind | unavailable | The interviewer section rests on your description alone. A search would have checked his career pattern and any published talks |
| 5. Representative JD | skipped | Your JD highlights fix the requirements in the fit snapshot and the JD-tagged questions |

**Not run:** L2 deep research. It needs web search, which the host refused, so it was not offered as runnable.

## Upgrade menu

- **Full JD text** → the highlights become full requirements, and any location, work-pattern or authorization term appears as a gate row
- **Northwind's published values page** → checks whether a values-style round exists and, if one does, builds the values cheat sheet
- **Web search permission** → runs targets 1 to 4, dates the research note and grounds the strategy questions. A deeper pass would add up to 6 more searches and 2 more fetches, several more minutes, if you want it after that
- **Her CV or résumé bullets, quoted exactly** → turns the `[grounded]` rows from your summary into sentences she can be checked against, and may raise the confidence of F1 and F4
- **Any pre-declared case or take-home from Dan or the recruiter** → adds a graded-deliverable section
- **A tuesday-dossier.md** → would add verified evidence and any dossier-named objection to the pack
