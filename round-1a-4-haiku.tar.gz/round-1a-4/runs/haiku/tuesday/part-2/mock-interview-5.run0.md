Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-2-rooms-case-5-denied-983398e4/9c5bc4e1-f533-45aa-a7fe-17bf007303e3/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md. Web search was refused in this session, so nothing about Kelverton is researched. Everything company-specific is labelled `[generic]`, and the pack's upgrade menu lists what would ground it.

The part most worth your four hours is the B1 objection ("I don't see rail operator sales in your background") and the £4M defend-the-number questions (C1 to C3). The 15-minute POV has three theses, each with a concession, and it ends on the operator-side outcome Deepa and Ross asked for.

Say the word and I'll play the Skeptic on B1 as a drill. I can also save a tuesday-dossier.md recording the gaps this prep exposed. A Word version of the pack is available if you want one.

Two things would sharpen the pack:
1. Can you paste the job description and the market report's headline points? Without the report I can't tell you where to differentiate from the consensus answer Kelverton's team will expect.
2. For the transport consulting, did your clients sit on the operator side or the authority side? The "I know the operator world from the other side" line depends on it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second-round panel, 60 minutes. First 15 minutes: a spoken point of view (no slides) on where to take operator partnerships over 18 months, landing on what it means for the operators. Remaining 45 minutes: Q&A, with commercials pressed.
**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director).
**Built on:** your message and the recruiter's email as you quoted it. No job description, no Kelverton values page, no content from the internal market report, and no web research (every search this session was refused). Everything company-specific is therefore labelled `[generic]` and nothing here is a fact about Kelverton.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script.

- **CASE**: a live problem set in the role.
- **EXP**: your past work, and whether it survives scrutiny.
- **JD**: a requirement the role needs, including the gaps.
- **CO**: company and market knowledge.
- **VAL**: none. No values-style round is detected for this loop (see Sources).

## Prep triage (about 4 hours)

1. **POV draft, 60 min.** Pick one thesis from the build section. Write three spoken beats, ending on an operator-side outcome. Say it aloud twice and time it. Aim for 11–12 minutes so the Q&A has room.
2. **Defend-the-numbers, 45 min.** C1, C2, C5 and D3. Write your answer in your own words, including the assumption you would defend least and which part was yours.
3. **Highest-ROI objection, 45 min.** B1. Say "I haven't sold into rail specifically" aloud, then the planning-side answer, then the first-90-days plan. Rehearse the hold and the concession.
4. **Quota objection, 20 min.** D1. The first sentence is the acknowledgment; the second is what you did carry.
5. **Market report, 40 min.** Read it once more. Choose one point Kelverton's own team would likely make, and one place you would depart from it, with your reason.
6. **Openers and reverse questions, 20 min.** E1, then the five reverse questions below.

Everything else is insurance.

## Fit snapshot

Requirements come from the recruiter's words (quoted from your message). No JD was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message; "9 years in partnerships" — your message | medium | [grounded] | transferability | Your material shows partner growth in a payments ISV channel, not with rail operators. Words: "I took it from 6 partners to 40." The partner work is the transferable part; the operator part is not in the material. Answer slot: if a partner decision of yours would carry to operators, name it and how you made it; if the growth came from elsewhere, say so and say what you would do first with operators. |
| F2 | "what it means for the operators themselves" — recruiter's email | "bus and light rail network planning" — your message; "so I know the operator world from the other side" — your message | medium | [grounded] | transferability | The quote is planning work, on the side of the table you may have sat on. It does not show operator-side commercial decisions. Words: "bus and light rail network planning." Answer slot: which side of the table that consulting work sat on, and what it showed you about how operators plan, in your own words. |
| F3 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message; "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | capability | The influence figure is real but indirect; the absence of a direct quota is your own statement. Words: "I haven't carried a direct quota." Then the figure at its own scope: "roughly £4M of influenced revenue." |
| F4 | "sells scheduling software to train operating companies" — your message | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't sold into rail specifically." Then the adjacent work in F2 at its own scope, and a plan for the first months. Never a claim to rail sales. |

## Graded deliverable: the 15-minute POV

The recruiter pre-declared this, so it is graded.

**Facts to build on** (each from a row above):
- F1: "took it from 6 partners to 40, roughly £4M of influenced revenue"
- F2: "bus and light rail network planning"

**Three theses**, each with a mandatory concession. All are `[generic]`: patterns for rail partnerships, not claims about Kelverton's operators or strategy.

- **Thesis 1: measure operator partnerships by an operator's own service outcome, not by licences signed.** Example measure: days from a change request to a published timetable. Concession: this is slower to prove, and operators must share operational data before it works.
- **Thesis 2: co-design deployments with two or three operators over 18 months, and say no to the rest.** Concession: a smaller reference base and slower logo growth. This is the anti-pick, and it is the one to choose if you want the differentiation to show judgment.
- **Thesis 3: route part of the partnership through integrators rather than only direct.** Concession: margin and control of the operator relationship.

**Differentiation.** The consensus answer is probably the shortlist in the internal report, which the pack has not seen. Answer slot: once you have read it, name one point the room will expect and one place you would depart from it, with your reason. Do not recite the report.

**The requested close** (what it means for the operators): end on one operator-side change you can defend. The example above is a form, not a claim. Swap in the measure you believe in.

## Reading the interviewer

Dropped. No public footprint was researched for Deepa or Ross, so there is no career pattern or self-described style to read. The upgrade menu says what their public material would add.

## Persona table

The panel rule blends the top two personas of each member's relationship.

| Persona | Who | How it shows up | Weight | Why | Counter-strategy |
|---|---|---|---|---|---|
| Case/Strategist | Deepa | Live problems from the POV and the role; "what would you do first" | 5 | A hiring manager is buying capability, and a POV invites live problems | Clarify, then structure, then pick one thesis and defend its concession |
| Skeptic | Deepa | Quiet probing of the rail gap and the reason for the move | 3 | The rail gap is the most predictable objection | Acknowledge the gap in its own words, then bridge only from stated evidence |
| Data-Driven Prober | Ross | Denominators, counting, and what "influenced" means | 4 | Recruiter says Ross will push on commercials; the headline figure invites a count question | Name how the figure was counted if you know; say plainly if you do not; name your weakest assumption |
| Pressure | Ross | Interrupts, time-boxes, challenges the quota gap | 3 | Commercial pressure is what the recruiter flagged | Hold the stated position through two follow-ups; concede the specific uncertainty, not the core claim |
| Conversational | Both | Opening "walk me through" | 2 | Panels often open this way; casual questions are still scored | A 90-second arc from your own sentences |

Ross's mapping to Prober and Pressure is `[inferred]`, from the recruiter's line about commercials and the usual pattern for a commercial director. It is not from anything known about Ross.

## Question banks

Question counts: Case 5, Skeptic 3, Prober 5, Pressure 3, Conversational 2. Total 18.

### Deepa: Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which operator would you approach first, and what would you need to know about them before the first call?" | CASE | [generic] | Clarify first: which operator, how it is measured, how it plans changes today. Then the first ask. No claim about your past. | The POV invites this; a live problem from the role. |
| A2 | "You have three theses. Which would you drop if you only had budget for one?" | CASE | [generic] | Pick the one whose outcome an operator would notice in its own numbers. Say what you would stop doing. | Tests prioritisation under constraint. |
| A3 | "Your idea assumes operators will share operational data. What if they won't?" | CASE | [generic] | Name a fallback: narrower data scope, or a contract clause. Do not assert a past case. | Challenges the premise of Thesis 1. |
| A4 | "How would you know by month six that an operator partnership is working, and what would tell you to stop?" | CASE | [generic] | One leading and one lagging measure, from the operator's side. Name a stop condition. | Connects the POV to the "what it means for operators" requirement (F1). |
| A5 | "Our product team owns the scheduling engine. Where does partnerships end and product begin?" | CASE | [generic] | Propose a principle for the seam, not a fact about how Kelverton splits it. | As future manager, Deepa will test cross-team seams. |

### Deepa: Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see rail operator sales in your background. How would you handle the first six months with a train operator?" | JD | [grounded] "Never sold into rail specifically" — your message; [grounded] "bus and light rail network planning" — your message | **Highest-ROI rehearsal in this pack.** Open with the acknowledgment: "I haven't sold into rail specifically." Then the planning side, in the quote's words, and what that work showed you about how operators plan (answer slot: say it in your own words). Then the first-90-days plan, said as a plan, not a past. Hold through two follow-ups by returning to planning knowledge, not to rail sales. Concede specifically: the first deals will be slower. Name the limit before it is asked for. | F4 is the capability gap and the most likely objection. Deepest rehearsal because it is the one most likely to be asked in some form. |
| B2 | "How do train operators make buying decisions, and what would you need to learn to change that picture?" | JD | [generic] | Name who you would expect to be involved, and say you would verify it with an operator, not assume it. | A JD-level question about buying; no past claim. |
| B3 | "Why partnerships, and why leave a payments company now?" | EXP | [grounded] "took it from 6 partners to 40" — your message | Answer slot: give your reason in your own words. Your material does not contain one, so say it plainly and keep it short. | Motivation check. |

### Ross: Data-Driven Prober (weight 4 to 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" — your message | Defend the number in your own words: how it was counted, the assumption you would defend least, and which part was yours. Answer slot: if you know the counting method, say it; if you do not, say so plainly. Do not reconstruct a method you cannot repeat. | The headline figure; the likeliest probe. |
| C2 | "The 6-to-40 growth: how much of that was you, and how much was the company's motion?" | EXP | [grounded] "took it from 6 partners to 40" — your message | Give the share you can defend. Answer slot: if you made a call that moved partner numbers, say what and how; if the motion was the company's, say so and describe your part. | Attribution is the probe; F1 is the evidence. |
| C3 | "Which number in your partner work would you show us first, and what would make it misleading?" | EXP | [grounded] "roughly £4M of influenced revenue" — your message | Name the figure, then the input it is most sensitive to. This is the weakest-assumption move, stated before they ask. | Metric questions carry the weakest-assumption move. |
| C4 | "Our market report gives operator figures. Which would you challenge first?" | CO | [generic] | Pick one figure and challenge its denominator or its counting logic. The pack has not seen the report; do not cite any number from it. | Tests whether you read the report critically. |
| C5 | "What does a partner mean in your data, and how would you count one at an operator?" | EXP | [grounded] "took it from 6 partners to 40" — your message | Give the definition you used. Answer slot: if you did not define one, say so. Then how you would define an operator partner, as a plan. | Partner counts are a common place for inflation. |

### Ross: Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've never carried a direct quota. Why should we believe you can hit an operator commercial target?" | JD | [grounded] "never carried a direct quota, only influenced revenue" — your message | Open with the acknowledgment: "I haven't carried a direct quota." Then what you did carry: "only influenced revenue," at its own scope. Hold through two follow-ups by returning to influenced revenue. Concede specifically: the first year on a direct target is a learning curve; say what your plan for it is. Never claim quota history. | F3 is the capability gap; Ross is the one most likely to press it. |
| D2 | "Operators run on thin margins and long contracts. Would you give up margin to win one?" | CO | [generic] | Concede with a boundary: say what you would give up and what you would not trade. No past claim. | Commercial pressure in Ross's register. |
| D3 | "Influenced revenue is a flattering number. Agree?" | EXP | [grounded] "roughly £4M of influenced revenue" — your message | Hold the figure as the one you can state. Concede the specific point: it is influenced, not booked. Answer slot: if you tracked a split of influenced and direct, say so; if not, say so. | Hold-then-concede on the figure. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | A 90-second arc using only your sentences: partnerships, then the payments ISV channel, then 6 to 40, then the transport consulting. No embellishment. | Panels open this way; casual openers are scored. |
| E2 | "What's the most useful thing you learned on the planning side of transport?" | EXP | [grounded] "so I know the operator world from the other side" — your message | Name one specific thing from the planning work. If you cannot name one, say so and give the nearest one you can. | Bridges the operator-side claim to something concrete. |

**Requirement coverage.** No JD was supplied, so these are the recruiter's own requirements:
- "where you'd take our operator partnerships over the next 18 months": A1, A4, POV build.
- "what it means for the operators themselves": A4, E2, the POV close.
- "Ross will push on commercials": C1 to C5, D1 to D3.
- Rail sales (from your message, not the recruiter's words): B1, B2.

## Prohibited claims

Built locally from the fit snapshot. Each entry is a wording the pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| "I know the operators' planning problems from the inside" | Inflated form of F2 | F2's quote at its own scope. The material says planning consulting, not operator-side work. |
| "I built the ISV channel" or "I recruited the 40 partners" | Inflated form of F1 | F1's quote. The material says "took it from 6 partners to 40," not who recruited them. |
| "I delivered £4M of revenue" | Inflated form of F3 | The figure as influenced revenue, at its own scope. |
| "I've carried a quota" | Negative you stated, F3 | "I haven't carried a direct quota." No slot. |
| "I've sold into rail" | Negative you stated, F4 | "I haven't sold into rail specifically." No slot. |

## Reverse questions

None is tied to an interviewer's path, because no public footprint was researched.

1. **To Deepa:** "What would the first operator partnership need to show you at month six for it to count as a win?" *Why it lands:* it sets your success measure in their terms.
2. **To Deepa:** "Where do partnerships and the product team disagree today?" *Why it lands:* it shows you are thinking about the seam before you own it.
3. **To Ross:** "How is partner commercial performance measured, and which part of that measure do you trust least?" *Why it lands:* it opens the commercials on their terms and shows you know a metric can mislead.
4. **To Ross:** "When a partner deal is marginal, who in the room gets to say no?" *Why it lands:* it asks about decision rights, which a commercial director owns.
5. **To either:** "What did the last person in this role get right, and what did they wish they had done earlier?" *Why it lands:* it signals you want the job as it is, not as the spec describes it.

## Sources

**Provided:** your message, including your background and the recruiter's email as you quoted it.
**Not provided:** job description; Kelverton's values page; the internal market report's content (you said you have read it, but did not paste it); public material on Deepa or Ross.

**Research tier: L1, searches 3 of 6, fetches 0 of 2.** All three searches were refused (permission not granted), and each counts against the budget.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Values cheat sheet, section 10, and the differentiator bank. Refused: "Kelverton Rail values." |
| 2. `Kelverton Rail interview process` | unavailable | Loop structure. The recruiter's email already fixes this round, so the change would be small. Refused: "Kelverton Rail interview process." |
| 3. `Kelverton Rail strategy` / recent news | unavailable | The CO bank and the POV's differentiation. The internal report is the nearest substitute and is not in the pack. Refused: "Kelverton Rail strategy scheduling software train operators." |
| 4. `{interviewer name} Kelverton Rail` | unavailable | Interviewer read and persona weights for Deepa and Ross. No search was sent, because the host refused searching. |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Fit snapshot JD rows. Not needed to proceed: the recruiter's own words stand in as requirements. |

**Loop:** the recruiter's email establishes one session, a panel, with a 15-minute presentation and 45 minutes of Q&A. No values-style round is documented, and the fallback archetype is not assumed, so no values round is detected.

## Upgrade menu

- **The job description** → fit snapshot rows become `[grounded]`, and the JD-tagged questions become specific.
- **The internal market report's headline points** (paste, not attachment) → the POV's differentiation section gets a real consensus answer, and C4 becomes specific.
- **Kelverton's values page** → names for the reverse questions and the CO bank. It does not create a values round.
- **Deepa's and Ross's public profiles or talks** → interviewer read, persona weights tuned per person, and a reverse question tied to their career path.
- **Web search enabled** → strategy brief, interview process, and the values page checked against the source, in place of the `[generic]` labels.
- **The recruiter's note on any pre-read or follow-up** → whether the POV is graded differently or needs to be sent beforehand.
