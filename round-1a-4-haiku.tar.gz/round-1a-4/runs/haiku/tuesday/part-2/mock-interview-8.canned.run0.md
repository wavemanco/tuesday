Your prep pack is saved at `/var/tmp/tuesday-measure/1a4/runs/haiku/tuesday/part-2/rooms/case-8-canned-b9316dbe/ashgrove_member-experience-lead_interview_pack.md`. It's built as one shared fit snapshot plus a mini-pack for each of the three rounds.

Three things matter most:

- **The biggest risk is the contact-centre gap.** The role is "across branches and the contact centre", and you've never worked in one. Expect it in Round 2. The rehearsal is to say the plain negative once, give a concrete plan for what you'd learn first, and concede the one thing you wouldn't know on day one (question B5).
- **Your values answers are thin.** Only Own the Fix and Members First have a quote from your message to build on, and both are weak. Plain Words and Neighbours have none. Before the panel, find one real decision for each value. If you can't, the pack says to say so plainly rather than invent one.
- **The 20-minute case is generic.** I wrote a complaint-escalation scenario and a six-step walkthrough (C5). If the recruiter can send the actual brief, I can rehearse that instead.

I used only your own sentences for your background and kept everything else as a question or a plan. The pack gives no pay, notice or location figures, since you haven't given any. I ran no web searches: your message already contained the values, the loop structure and the strategy summary.

Two offers, neither pushed: I can run a live drill, starting with the contact-centre question, or save a `tuesday-dossier.md` recording the gaps this prep exposed. I can also convert the pack to Word if you want it.

Is the 20-minute case a written scenario sent in advance, or is it read out in the room?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Role:** Member Experience Lead. **Company:** Ashgrove Credit Union (member-owned, about 900 staff).
**Dates:** 3 December 2026, three rounds.

- **Round 1**, 30 min: recruiter.
- **Round 2**, 45 min: Head of Member Services, your future manager. Mostly behavioural.
- **Round 3**, 60 min: panel of two branch managers, including a 20-minute complaint-escalation case. The panel scores against the four values.

Round 2 and Round 3 interviewers are not yet named. Their personas below are relationship priors, not reads of individuals.

**Built as a loop:** one shared fit snapshot and sources block, then one mini-pack per round with its own persona weights, bank and reverse questions. The values cheat sheet sits with Round 3, because that is the values-scored round.

**Assumptions:** built from the JD, values copy, recruiter email, strategy summary and background in your message. No CV was pasted. No pay, notice, location or reason for leaving was given, so those are slots, not facts.

## How to use, and type key

Personas describe how a question is asked. Types describe what is being scored.

- **VAL:** behavioural and values alignment
- **EXP:** your own experience, probed
- **JD:** the listed job's requirements, including gaps
- **CO:** company and strategy knowledge
- **CASE:** a live problem from the role

Guidance is scaffolding, not a script. Say it in your own words, and only the parts you did.

## Fit snapshot (shared across rounds)

Requirements are quoted from the JD you pasted. Evidence is quoted from your message. Each row's gap type follows its evidence cell.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material places you at one branch's formal log; "end to end" is not in it. Keep to the log: "I handled the branch's formal complaints log." Answer slot: "end to end" makes a probe on the steps from first contact to closure likely. If you set any step beyond the log, say which and how you decided; if you did not, say so and stay with the log. |
| F2 | "and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | You stated this absence, so the words are yours: "I've never worked in a contact centre." Then how you would learn it, as a plan and never as a past: what you would ask for first in your first month on contact-centre complaints. Nothing added to make the gap feel smaller. |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | The quote already reaches monthly complaints reporting, so keep its words as written. Answer slot: resolution times is the likely probe. If the spreadsheet carried them, say how you counted them; if it did not, say so and say what you would add first. |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote touches spreadsheet reporting but does not name the tool. Answer slot: if you built it in Excel, name the functions you used, in your own words; if it was another tool, say which. |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your coaching evidence is with tellers, not supervisors: "I trained new tellers on our escalation script." Answer slot: if you coached anyone above teller level on escalations, say who and what you did; if you did not, say so and say how you would start with supervisors. |
| F6 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | You stated this absence: "I've never presented to anyone above regional level." Then a plan: how you would build that skill before your first senior presentation. Never a claim to presenting work above regional level. |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent here, and you have not stated an absence. Answer slot: if you have changed a form, letter, web or app step with a digital team, name what, and your part in it; if not, say so and say how you would start with the digital team. |
| F8 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your material already reaches this in its own terms. Keep its scope: retail banking and branch supervision. Do not restate it as customer operations as a function. |
| F9 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Your material says "formal", not that the log ran under a regulator's or ombudsman's rules. This link is the pack's own derivation from one word, so it is never your claim. Answer slot: if the log ran under specific rules, name them and what you did at each step; if it did not, say so plainly. |

Requirements the JD states with no row above: none. Each requirement in the JD's list maps to a row.

## Prohibited claims

Built from the fit snapshot. Do not say any of these in any round. The honest form sits beside each.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says one branch's log. |
| Ran complaints across the contact centre | Negative you stated, F2 | "I've never worked in a contact centre." Plain acknowledgment, then a plan. |
| Presented to senior leaders | Negative you stated, F6 | "I've never presented to anyone above regional level." Plain acknowledgment, then a plan. |
| Coached branch supervisors | Inflated form of F5 | "I trained new tellers on our escalation script." |
| Tracked resolution times, or reported to senior leaders | Inflated form of F3 | "I built the monthly complaints spreadsheet our regional manager uses." Nothing about what it counted. |
| Ran the work under regulatory rules | Inflated form of F9 | "I handled the branch's formal complaints log," at that scope. |

## Grounding brief

From the July 2026 strategy summary you pasted. Learn the vocabulary; it is what the panel and Round 2 manager will use.

- Move 40% of member service to digital channels by 2028: "move 40% of member service to digital channels by 2028."
- Consolidate eight branches into five hubs over 2027: "consolidate eight branches into five hubs over 2027."
- Launch a small-business lending product in Q1 2027: "launch a small-business lending product in Q1 2027."
- The main competitive pressure is app-only banks: "the main competitive pressure is app-only banks."

Use these as context for questions about complaints, not as facts about your own work. The hub plan makes branch-level complaint experience a live question.

## Round 1: recruiter screen (30 min)

**Persona weights**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Friendly openers; logistics questions in a casual register | High. Recruiter priors put logistics and motivation checks here. The risk is treating it as unscored | Pre-scripted 90-second background arc; treat every logistics answer as scored |
| Skeptic (light) | Quick checks on the contact-centre and senior-presenting gaps | Medium. The gaps are in the JD and your message, so a recruiter may flag them early | Plain acknowledgment, then a plan |

**Bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in this order: the banking years and supervision (F8), the complaints log (F1), the spreadsheet (F3). Tell it in your own words and stop at the spreadsheet. Do not add anything the quotes do not hold | Opening question; the arc sets the first three facts the panel will hold you to |
| A2 | "What is drawing you to Ashgrove?" | CO | [generic] | Answer slot: give your own reason in your own words. Your message does not state one. Connect it to a value or to the member side of complaints only if that is true for you | Motivation is scored; a rehearsed reason is better than a borrowed one |
| A3 | "Why are you looking to move?" | EXP | [generic] | Logistics slot: give your own reason in one sentence. No reason is in your message, so the pack supplies none | Reason for leaving is a logistics slot in the recruiter's row |
| A4 | "What are you earning now, and what is your notice period?" | JD | [generic] | Logistics slot: give your actual notice period. For pay, give your own number or ask for the band first. Do not give a current pay figure if you are not asked for one | Notice and pay are logistics slots; no figure was supplied |
| A5 | "Where are you based, and can you work from one of the five hubs?" | JD | [inferred] from the hub plan in the grounding brief | Logistics slot: give your own answer on location and on hub working. Your message does not state either | The 2027 hub plan makes location a live screen question |
| A6 | "Tell me about your experience with regulated complaints." | JD | [inferred] "I handled the branch's formal complaints log" | F9 answer slot. Say what the log was and what you did with it. If it ran under specific rules, name them; if not, say so | Low-confidence row; this is coaching for clarity, not an asserted claim |
| A7 | "You haven't worked in a contact centre. How do you see that?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then the plan from F2, as a plan | Presupposes only the negative you stated |
| A8 | "How comfortable are you with Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | F4 answer slot: name the functions you used if it was Excel; name the tool if it was not | Tests the stated requirement directly |

**Reverse questions (Round 1)**

1. "How will the panel weight the four values against each other?" Why it lands: shows you know it is scored, and tells you where to put your effort.
2. "Will the 20-minute case come as a written scenario in advance, or be read out in the room?" Why it lands: changes how you prepare; asked here because the recruiter owns the process.
3. "How does the Head of Member Services' team split work between branches and the contact centre?" Why it lands: shows you are thinking about the role's real scope.
4. "How far has the 2027 hub plan been decided?" Why it lands: connects the role to the strategy in the brief.
5. "What would the first 90 days look like for someone in this role?" Why it lands: a standard question that signals you are planning to start.

## Round 2: Head of Member Services (45 min, mostly behavioural)

**Persona weights**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the contact-centre and senior-presenting gaps; asks why you, why now | High. A hiring manager buys capability and derisks gaps. F2 and F6 are the two places the material is thinnest | Hold, then concede specifically; a plan, never a past |
| Values / Behavioural | Scenario prompts about complaints; expects STAR-shaped answers | High. The round is mostly behavioural, which raises this above the usual manager prior | Story-map only from quotes; otherwise a selection scaffold with its honest branch |
| Case / Strategist | Live problems on hub consolidation and digital shift | Medium. Less time than the behavioural bank, so two questions | Clarify, then structure, then one metric |

**Bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you had to tell someone senior something they did not want to hear." | VAL | [generic] open prompt | Pick a time. If none comes to mind, say so plainly, then give the nearest thing your material holds: the complaints log you handled. Do not supply an ending you do not have | Open prompt; the persona stem is the theme source |
| B2 | "Tell me about a complaint you could not close at branch level." | EXP | [grounded] "I handled the branch's formal complaints log" | Name one entry from the log, what you did, and what happened to it, in your own words. If it went beyond the branch, say how it was escalated; if you did not escalate it, say so | Open prompt anchored on F1's quote; tests the scope of "end to end" |
| B3 | "How did a teller come to you with an escalation?" | EXP | [grounded] "trained new tellers on our escalation script" | Describe the script you taught and what happened when a teller used it, if one did. If you did not use the script that way, say so | Tests the scope of F5 at teller level |
| B4 | "How would you coach a branch supervisor who escalates too late?" | JD | [grounded] "trained new tellers on our escalation script" | Your coaching evidence is with tellers. Say that, then the plan for supervisors as a plan. Do not describe supervisor coaching you have not done | Tests F5; the JD line is the raising source |
| B5 | "You've never worked in a contact centre. Why should we trust you with complaints that come in by phone?" | JD | [grounded] "Never worked in a contact centre" | Highest-ROI rehearsal in this pack. Hold: "I've never worked in a contact centre." Then the plan from F2, and hold it through two follow-ups by returning to what you would learn first. Concede explicitly: name the one thing you would not know on day one | This objection is aimed at F2, the gap the role's title sits on; expect it in some form |
| B6 | "The role presents to senior leaders monthly. Have you?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Then the plan from F6: how you would prepare, rehearse and get feedback before a first senior presentation | Plain acknowledgment with a stated source |
| B7 | "Walk me through how you built the monthly complaints spreadsheet." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Use only the quoted beats: built, monthly, used by your regional manager. Answer slot: what it counted, and which part was yours. If it counted resolution times, say how; if not, say so | Premised question on the quote; the figures slot applies only to any number you give |
| B8 | "How would you cut resolution times as eight branches become five hubs?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" | Clarify volumes and the hub plan first. Then structure: where complaints would queue during the move, who owns each queue, one metric to watch. Do not claim you have done this | Strategy-grounded case; the hub plan is the raising source |
| B9 | "We are moving 40% of member service to digital by 2028. What does that do to complaints?" | CO | [grounded] "move 40% of member service to digital channels by 2028" | Name the risk that complaints inherit: members who cannot or will not use the app, and the routes they then use. Keep it as reasoning, not as your experience | The 40% target is the raising source; the derivation is the pack's |
| B10 | "What would you report in your first month?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Name the two measures the JD states, volumes and resolution times, and say what you would check first. If you have built a resolution-time measure before, say how; if not, say so | Tests F3 and F4 together |

**Reverse questions (Round 2)**

1. "What would make you say in six months that this hire was the right one?" Why it lands: asks for the success measure directly, and sets up your plan.
2. "How do you want the role to coach branch supervisors on escalations: a standard script or case reviews?" Why it lands: shows you have read the coaching line of the JD.
3. "As the hubs roll out, which complaint trend will you watch most closely?" Why it lands: links the role to the strategy.
4. "How will this role and the digital team share ownership of self-service complaint journeys?" Why it lands: tests the digital line of the JD.
5. "Where do you think the process most often fails between a branch and the contact centre?" Why it lands: shows you are thinking about the seam before you have been hired.

## Round 3: panel (60 min, with a 20-minute case; scored against the values)

**Values / principles cheat sheet (shared with this round)**

The panel scores against four values. The candidate's stories below are either a quote from your message or a selection scaffold with an honest branch. None of the four has a full story yet.

| Value | Working meaning | Your story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1 (your message): "I handled the branch's formal complaints log". Pick a decision you made from the member's side. If none comes to mind, say so, then give the complaints log: what you did for the member at that counter |
| Plain Words | If a member needs it explained twice, the wording was wrong | F5 (your message): "trained new tellers on our escalation script". Pick a time you rewrote wording so a member understood first time. If none, say so, and say how you would test whether a letter reads plainly |
| Neighbours, Not Numbers | Every branch is part of its town | No quote carries a story. Pick a time a branch decision affected its town; if none, say so, and say what you would check before a hub closure |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1 (your message): "I handled the branch's formal complaints log". Pick a complaint you kept until it was solved. If the log only recorded them, say so |

**Persona weights**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Scored scenario prompts on the four values | High. The round is the values round, so each value gets a question | Map a story where a quote carries one; scaffold with honest branch where none does |
| Case / Strategist | 20-minute complaint-escalation case | High. Scheduled as a case, so structure and reasoning are scored | Clarify, then structure, then one decision and a plan |
| Peer Evaluator | Branch managers as likely peers: seam questions, credit questions | Medium. Branch managers are probably peers of the role's team | Reciprocity framing; seam principles, not claimed seams |
| Data-Driven Prober | Probes the reporting numbers | Medium. The JD asks for reporting and the spreadsheet is in your message | Name the weakest assumption before they do; say plainly where you do not know |

**Bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell us about a time you put a member ahead of a number." | VAL | [generic] open prompt, theme from Members First | Pick a time. If none comes to mind, say so plainly, then give the nearest thing your material holds: the complaints log you handled | Members First is scored; the nearest quote is F1 |
| C2 | "Tell us about a time you explained something to a member twice." | VAL | [grounded] "trained new tellers on our escalation script" | Pick a time you changed wording so a member understood first time. If you rewrote the script for tellers, say how. If you did not, say so and say how you would test a letter's wording | Plain Words is scored; F5 is the nearest quote |
| C3 | "Tell us about your town and your branch's place in it." | VAL | [generic] open prompt, theme from Neighbours, Not Numbers | Pick a branch decision that affected its town. If none, say so, and say what you would check before a hub closure | Neighbours is scored; no quote carries a story |
| C4 | "Tell us about a problem you found and kept hold of until it was fixed." | VAL | [grounded] "I handled the branch's formal complaints log" | Pick a complaint you kept until it was solved. If the log only recorded them, say so and say what you would do differently | Own the Fix is scored; F1 is the nearest quote |
| C5 | Complaint-escalation case (20 minutes): "A member's complaint about a fee has been through the branch twice. The contact centre has marked it resolved. The member says it is not. Walk us through the next 48 hours." | CASE | [generic] scenario, not drawn from your background | Walkthrough below | The case is the 20-minute round's core; the scenario is a generic pattern, since the real brief is not known |
| C6 | "A branch supervisor escalates a complaint to you late. What do you do?" | JD | [generic] | Clarify what the supervisor knew and when. Then the decision: take hold of the fix, not pass it back. Then coach: what the supervisor will do differently next time | JD's coaching line; no past claim |
| C7 | "Walk us through how you would count resolution times." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Use the quoted beats. Answer slot: if you have counted resolution times before, name the assumption you would defend least; if not, say so and name the start and end points you would use | Data-Driven Prober's question; no figure is given |
| C8 | "When a branch and the contact centre disagree about who owns a complaint, what happens?" | JD | [generic] | Name the principle you would use: whoever found the problem keeps hold of it, per Own the Fix. Do not claim a seam you have run | Peer seam question; principles, not experience |
| C9 | "How do you handle credit when a fix spans two teams?" | VAL | [generic] | Name each team's contribution and say whose name goes on the fix. Keep the credit with the people who did the work | Peer credit probe; no past claim |
| C10 | "Tell us about a time you disagreed with a peer manager and it changed the outcome." | VAL | [generic] open prompt | Pick a time. If none comes to mind, say so plainly, then give the nearest thing you have: the complaints log, and what you changed in it | Open prompt; no quote carries a peer disagreement |
| C11 | "How would you work with the digital team on a self-service complaint journey?" | JD | none given: F7 answer slot | If you have changed a form, letter, web or app step with a digital team, name it and your part; if not, say so and set out how you would start | F7 is a silent row; the answer is an honest slot |
| C12 | "What is the hardest truth you would give a senior leader about complaints?" | VAL | [generic] | Name the fact you would give, and how you would keep it short. If you have given a senior leader an unwelcome complaints fact, say it; if not, say so | Pressure on the presenting gap; F6 is the honest backing |

**Case walkthrough for C5 (20 minutes)**

1. **Clarify (about 3 minutes).** Ask what the member has been told, what the branch has logged, and whether any response deadline applies. Clarifying questions are scored.
2. **Member's side first (about 3 minutes).** State what the member needs to be true at the end. Decide from that point, not from the log's status.
3. **Own the fix (about 5 minutes).** Name who keeps hold until the complaint is solved. "Passed to the contact centre" is not an owner.
4. **Stop the bounce (about 4 minutes).** Say what would stop the complaint going round between branch and contact centre: one named owner, one written record, one close date.
5. **Plain Words (about 2 minutes).** Describe the letter you would send, written to be understood on the first read.
6. **Coach and report (about 3 minutes).** Name what you would tell the branch supervisor, and what you would count monthly from this case.

Anchor, if asked, to your log: "I handled the branch's formal complaints log." Do not describe a contact-centre case. Your message says you have not worked in one.

**Reverse questions (Round 3)**

1. "How does the panel weigh the four values in the scoring?" Why it lands: tells you the scoring frame, and shows you know you are being scored.
2. "What could a new person do in their first month that would genuinely help your branch's team?" Why it lands: the peer reciprocity question. It turns the interview toward what you bring.
3. "How do branch managers and the contact centre share complaint data today?" Why it lands: shows you are already looking at the seam.
4. "Which decision on the 2027 hubs has the panel found hardest?" Why it lands: connects the case to the strategy.
5. "How do you want the role to handle complaints that come in digitally?" Why it lands: tests the digital line of the JD with the people who will work beside the role.

## Sources

Provided documents: your message (JD, values copy dated 24 November 2026, recruiter email, July 2026 strategy summary, background).

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet: the four values were pasted from the published page, so the inputs fix the names and meanings |
| 2. Ashgrove interview process | skipped | Loop structure: the recruiter's email fixes the three rounds and their lengths |
| 3. Ashgrove strategy / recent news | skipped | Grounding brief: the July 2026 summary you pasted fixes its content; a full brief would add detail (see upgrade menu) |
| 4. Interviewer name | n/a | No name was given for Round 2 or Round 3, so there was no query to form; the interviewer read is absent |
| 5. Representative JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The Head of Member Services' name and the two branch managers' names → persona weights per panel member, a tailored reverse question for each, and a read of their public footprint (research sent only with your consent)
- The 20-minute case brief, if one is sent in advance → rehearsal on the actual scenario, not the generic one in C5
- Your CV, and any Excel files or presentations you have made → F4 becomes a grounded Excel answer, and the defend-the-number slots on F3 and C7 get your own figures
- Any time you have coached a supervisor, presented above your branch, or changed a digital step → converts the answer slots in F5, F6 and F7 into stories you can tell
- Your own notice period, pay expectation and location → fills the logistics slots A3 to A5
- The recruiter's scoring guidance for the values → sharpens the cheat sheet's scaffolds into the panel's own criteria
- Deep research at L2, offered once (up to 6 further searches and 2 further fetches): the full July 2026 strategy brief, interviewer talks and loop reports → firms the grounding brief and adds a loop-report read of the panel
- A targeted L1 search on the complaint-handling rules that apply to a credit union in Ashgrove's jurisdiction (up to 6 searches, 2 fetches) → firms F9, A6 and the regulatory part of C5
- Prep time available before 3 December → adds a prioritised schedule to the pack
- A `tuesday-dossier.md` would record the gaps this prep exposes, for carrying into later sessions
