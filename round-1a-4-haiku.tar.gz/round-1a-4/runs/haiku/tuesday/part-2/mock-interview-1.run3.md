Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-2-rooms-case-1-denied-1b26c07d/0ec2b9d6-a594-4acd-8781-d976952d37d6/scratchpad/northwind-data_senior-gtm-strategy-lead_interview_pack.md. I built it for a peer round, on your JD highlights and Priya's summary. Web search was refused in this session, so Northwind's values, the loop structure and Dan's public footprint are not researched. The pack's sources section lists each attempt.

The pack has 19 interview questions across six personas, each tagged by type, with a fit snapshot, persona weights, a prohibited-claims list, reverse questions and an upgrade menu. Each question's rationale states why it is included and why it is tagged that way.

The highest-ROI prep is question D1, "You've never run classic sales-ops or quota-setting." Priya has no quota-setting record, and a sales-strategy director will test that first. The guidance gives her a plain acknowledgment, the volume-target bridge at its own scope, and a ramp plan, and it asks her to hold through two follow-ups.

I can also play the Skeptic on D1 as a live drill, save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Three questions to sharpen it:

1. Can you paste the full JD text and Priya's CV? The full JD would ground the six JD rows in the posting, and her CV lines would replace the summary I quoted.
2. Web search was refused here. If you grant search permission, I can research Northwind's values, the loop structure and Dan's public footprint. Otherwise the pack stays as built.
3. Did the recruiter name any focus areas or a pre-declared exercise? Either would change the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products

- **Company:** Northwind Data (B2B data-infrastructure SaaS, ~3,000 employees)
- **Candidate:** Priya
- **Interviewer:** Dan Kovac, Director of Sales Strategy. Relationship: peer (both report to the same VP)
- **Round:** single 60-minute conversation
- **Changes:** first version
- **Research tier:** L1 attempted; no search ran (see Sources)

## 1. How to use and type key

Personas describe how a question arrives. Types describe what is being scored.

| Tag | Name | Scores |
|---|---|---|
| EXP | Work-experience deep-dive | Whether the stated experience survives scrutiny, and what was actually Priya's |
| JD | Role / JD-driven | Stated responsibilities and qualifications, including gaps |
| CO | Company and strategy knowledge | Homework depth and altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a live problem from the role |
| VAL | Behavioral / collaboration | Past behavior in collaboration and credit-sharing (no values round detected) |

Guidance is scaffolding, not a script. Each guidance cell is written to be spoken in 90 to 120 seconds. Answer slots are instructions for the interview: they mark where Priya answers from her own experience, including the honest branch that the practice was not hers.

## 2. Fit snapshot

Requirements are quoted from your JD highlights. Evidence is quoted from your message, which is where Priya's summary reached this pack. Once you send the full JD and her CV (see upgrade menu), these rows can be re-grounded.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — your JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | The material shows a proposed change to a product's store surface and a credited figure. It does not show go-to-market ownership of a product line. Words: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: if you owned any part of how that change reached the market, say which and how you decided; if you did not, say so plainly and stay with the change itself. Expect a probe on the figure. |
| F2 | "identify whitespace across land/adopt/expand/renew" — your JD highlights | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | transferability | Target-setting is adjacent to whitespace identification, not the same work. Words: "I set annual volume targets with cross-org consensus." Answer slot: if your target-setting began from a view of where volume was coming from, say what that view was; if it did not, say so plainly. |
| F3 | "run independent analysis in SQL and Tableau" — your JD highlights | "skilled in SQL/Tableau" — your message | low | [grounded] | discovery | The material names the tools and not an analysis. Answer slot: name one analysis you ran in SQL or Tableau and what it decided; if none changed a decision, say so and name the analysis you would run first. |
| F4 | "partner-motion design experience required" — your JD highlights | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | The model is partner-level and was used in negotiations. Partner-motion design is about how partners are engaged and paid. Words: "I built a partner-level revenue model used in carrier negotiations." Limit, as the pack's own observation: the material does not show designing a partner motion. Answer slot: if you shaped any part of how partners were engaged or paid beyond that model, say which and how you decided; if not, say so plainly. |
| F5 | "strong cross-functional influence" — your JD highlights | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: consensus across organizations. Words: "I set annual volume targets with cross-org consensus." Do not add a stakeholder's reaction the quote does not carry. |
| F6 | "AI experience a plus" — your JD highlights | "uses AI tools daily" — your message | low | [grounded] | presentation | The quote reaches the requirement only as use. Words: "I use AI tools daily." Limit, as the pack's own observation: the material does not show building or deploying AI. |
| F7 | Sales-strategy roles usually expect quota-setting and sales-ops experience — [generic], role-family prose, not quoted | "No classic sales-ops or quota-setting experience" — your message | none | [grounded] | capability | The absence is stated by you, so the pack may give the words back. Plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." Then the bridge stays at F2's scope: "I set annual volume targets with cross-org consensus." Then how she would learn it, said as a plan and never as a past. |

## 3. Interviewer read: Dan Kovac

Sources: your interviewer profile only. His public footprint was not researched (see Sources).

- **Career pattern (as you described it):** pricing and monetization roles, with one early-stage-startup chapter.
- **Self-description (as you described it):** "relentlessly data-driven."

Practical implications:

1. Every headline number will be traced to its assumptions. See A1, A2 and E2.
2. Case questions will lean toward pricing, packaging and unit economics. C1 and C3 are framed that way.
3. The startup chapter means builder stories land. Expect scrappiness probes on big-company pace; these are answered inside B2, E2 and D3.
4. Shared vocabulary is monetization. Priya's own phrase, "partner-level revenue model," is the bridge. Use it, not borrowed jargon.

Shared jump: none that is safe to offer. Priya's move (consulting to consumer tech) is not his (startup to pricing), so no shared-jump reverse question is included.

## 4. Persona table

Weights start from the peer prior and adjust for Dan's profile. Top persona gets 5 questions, mid gets 3 to 4, low gets 2. Total: 19 questions.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober (weight 5) | Traces numbers to inputs and assumptions; follows up two levels deep | High. Peer prior, plus a self-described "relentlessly data-driven" profile | Name the weakest assumption before he does; say plainly what you do not know about how a figure was counted |
| B. Peer Evaluator (weight 4) | Seam questions, credit when work spans teams, "what would you need from me" | High. Peer prior; both report to the same VP, so the seam is live | Propose seam principles rather than pretending to know the seam; show spine and tact in one disagreement story |
| C. Case / Strategist (weight 3) | Live whitespace and bundling problems, asked through a pricing lens | Medium-high. The JD's live roadmap, and his pricing career pattern | Clarify, then objective, segmentation, approach, metrics, risks; challenge one premise |
| D. Skeptic (weight 3) | Pokes at the sales-ops gap and at the closest thing to a new-line launch | Medium. The quota and sales-ops absence is the most visible gap in the material | Plain acknowledgment, then the bridge at its own scope, then a ramp plan; never a claim to quota work |
| E. Pressure (weight 2) | Sixty-second challenges; "how much of that was actually you" | Low-medium. A peer round rarely time-boxes, but a single hour may | Pause, restate, hold through two follow-ups, concede precisely without folding |
| F. Conversational (weight 2) | "Walk me through the journey"; a casual AI question | Medium. Openers are near-universal, and casual questions are still scored | A 90-second arc built only from her quoted sentences; treat the AI question as scored |

## 5. Question banks

Each guidance cell rests only on the Provenance quotes in its row. Question IDs are used in the coverage line and the rehearsal priority.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | Defend the number. Say what the figure counts, in her words, and what she can and cannot say about how it was counted. Answer slot: if she measured or estimated the uplift herself, say how; if someone else counted it, say so plainly and say which part of the work was hers. | Headline figure on her record and the likeliest first probe from a prober. EXP because it tests attribution. |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | Weakest-assumption move: name, in her own words and before he does, the assumption she would defend least. If she cannot name one, say she does not know how it was counted. Do not supply an assumption. | Turns a gotcha into a credibility gain on the same figure as A1, at the second follow-up level. |
| A3 | "Tell me about an analysis you ran in SQL or Tableau that changed a decision." | JD | [grounded] "skilled in SQL/Tableau" — your message | Open prompt. Raising source: the JD's "run independent analysis in SQL and Tableau." Name one analysis, the question it answered and what changed. Answer slot: if none changed a decision, say so and name the analysis she would run first. | Scores the stated analysis requirement. The quote carries tools only, so the guidance names no analysis. |
| A4 | "What were the inputs to the partner-level revenue model, and which one would move its answer most?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" — your message | Name the inputs she actually used, in her own words, and the one that moves the answer most, with why. Answer slot: if she did not build some inputs, say which she used and who set the rest. | The strongest adjacent evidence for the partner requirement (F4). The prober tests whether the model is hers to defend. |
| A5 | "What did the cross-org consensus on those volume targets rest on?" | EXP | [grounded] "set annual volume targets with cross-org consensus" — your message | Say, in her own words, what the consensus was built on. Answer slot: if she can name the number the consensus rested on, say it; if she cannot reconstruct the basis, say so. | Tests the F5 quote without extending it. The honest branch allows that she does not remember the basis. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side — where's the seam, and what happens when we disagree?" | JD | [generic] persona stem; no candidate claim | Propose seam principles, such as who sets the target and who owns partner data, rather than pretending to know his seam. On disagreement, name one view she would hold against an equal, and what would change her mind. | Peer Evaluator stem. The seam is structural in a peer round and the answer makes no claim about her past. |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | Say who did what on the store-surface change, in her words, and how credit was assigned. Answer slot: if credit went beyond her part, say so and how she treated it; if the figure is shared, say that first. | Credit probe from a peer. The word "credited" is the sentence's own word and is not stretched. |
| B3 | "How did you get cross-org consensus on the annual volume targets?" | JD | [grounded] "set annual volume targets with cross-org consensus" — your message | Scores the JD's influence requirement. Name the two or three people whose agreement mattered and what each needed, in her own words. Answer slot: if she ran the process, say how; if others ran it, say what her part was. | Answers the JD's cross-functional influence requirement in the quote's own terms (F5). |
| B4 | "Where would you push back on me about how these new lines should be sold?" | VAL | [generic] persona stem; no candidate claim | Show spine and tact together: name a view she would defend against an equal, and the evidence that would change it. Make no claim about past disagreements she has not stated. | Peer objections return in collegial packaging, and this stem invites a view. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you'd find whitespace across land, adopt, expand and renew for the first of these two new lines." | CASE | [generic] JD requirement as raising source; no candidate claim | Clarify what counts as whitespace before segmenting. Then objective, segmentation, approach, metrics and risks. Use a pricing and unit-economics lens, and challenge one premise respectfully. | The JD's whitespace requirement asked as a live problem. The pricing lens follows his career pattern. |
| C2 | "Northwind's priorities include enterprise expansion and profitability. How would you weigh a new line against those two?" | CO | [grounded] "enterprise expansion" and "profitability" — your research note | Use the company's own words. Say what would make the new line a trade-off against expansion rather than an add-on, and name the metric she would watch first. | Grounded in your research note, not in fresh research. Keeps her current against the stated priorities. |
| C3 | "A much larger platform vendor bundles a competing product into its suite. How would you respond through partners?" | CASE | [grounded] "bundling by a much larger platform vendor" — your research note | Frame the bundle as a pricing and packaging problem. Say what partners would need to hold position, and name one thing she would not do. | Your note names bundling as the main competitive threat. The pricing lens matches his background. Also covers the partner requirement. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've never run classic sales-ops or quota-setting — what would you lean on from day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" — your message; bridge: [grounded] "set annual volume targets with cross-org consensus" — your message | **Highest-ROI rehearsal in this pack.** Hold: "I don't have classic sales-ops or quota-setting experience." Then the bridge at its own scope: "I set annual volume targets with cross-org consensus." Then a ramp plan, said as a plan. Hold through two follow-ups by returning to the target-setting scope and conceding the gap plainly. Never describe the volume targets as quota-setting. | The most predictable objection. A sales-strategy director will test the adjacent area first, and she has no quota-setting record. This is where the deepest rehearsal goes. |
| D2 | "Which part of owning go-to-market for a new product line would you be weakest at on day one?" | JD | [grounded] "own GTM strategy for two new product lines" — your JD highlights | Name the weakest part honestly, then the ramp. Do not claim go-to-market ownership she has not stated. | A Skeptic stem aimed at the JD's headline requirement. It presupposes nothing about her past. |
| D3 | "What is the closest you've come to taking a new line to market, and what did you own in it?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | Open prompt; raising source: the JD's "own GTM strategy for two new product lines." Story map from the quote's beats: the change, and the credit. Answer slot: if she owned part of its market entry, say which and how she decided; if not, say so and describe what she proposed. | F1 is the nearest evidence for the launch requirement, and this question tests it without adding to it. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run quota-setting?" | JD | [grounded] "No classic sales-ops or quota-setting experience" — your message; [grounded] "built a partner-level revenue model used in carrier negotiations" — your message | Pause, then restate. Hold the position on the partner-level revenue model and the cross-org target-setting. Concede the quota gap explicitly and specifically. Do not fold on the core claim. | Pressure on the same gap as D1, aimed at composure rather than content. |
| E2 | "That ~$400M — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | Hold-then-concede. Say what she proposed and what was hers in the credit, in her own words. If the credit was shared, concede that specifically. Do not restate the figure as hers. | Pressure on the headline figure. "Credited" is the sentence's own word. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" — your message; [grounded] "then 9 at a large consumer-tech company in product strategy & ops" — your message | A 90-second arc built only from those two sentences: two years in strategy consulting, then nine in product strategy and ops at a large consumer-tech company. Add nothing not stated here. | The opener is scored too. A pre-scripted arc stops it from freezing. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" — your message | Name the tools she actually uses and what she uses them for. If she has not built with them, say so. Treat it as scored: the JD lists AI as a plus. | A casual form of the JD's AI plus. Casual questions still count. |

### Requirement coverage

| JD requirement (your highlights) | Covered by |
|---|---|
| own GTM strategy for two new product lines | D2, D3 |
| identify whitespace across land/adopt/expand/renew | C1 |
| run independent analysis in SQL and Tableau | A3 |
| partner-motion design experience required | A4, C3 |
| strong cross-functional influence | B1, B3 |
| AI experience a plus | F2 |
| Headline figure (defend-the-number, from the CV) | A1, A2, B2, E2 |

Every stated requirement has at least one question. Nothing is left uncovered.

## 6. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've spent much of your career on pricing and monetization, with one stretch at an early-stage startup. Which pricing call on that path do you think a partner-led GTM lead most needs to get right?" | Ties to his own path, drawn from the career pattern you described. It turns an interview into a peer conversation. |
| R2 | "What would a new person on your side of the seam do in their first month that would genuinely help your team?" | Reciprocity question for a peer. Shows she is thinking about his team's load, not only her own needs. |
| R3 | "Where does sales strategy make the call on a new line's targets, and where does product?" | Asks directly about decision rights at the seam, which is what a peer will care about. |
| R4 | "How is the Compass launch changing what partners are asked to do this year?" | Ties to the AI copilot priority in your research note, and invites him to say what is moving. |
| R5 | "Which number on the enterprise-expansion priority does the team argue about most?" | A data-driven peer answers this in detail. Signals she wants the real debates, not the slide. |

## 7. Prohibited claims

What this pack will not coach, built from the fit snapshot. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned go-to-market for a product line" | Inflated form of F1 | "I proposed a store-surface change credited with a ~$400M ARR uplift." The pack's own observation: the material says the change, not the go-to-market. |
| "I set quotas" or "I ran quota-setting" | Inflated form of F2 and F7 | "I set annual volume targets with cross-org consensus." The absence, stated: "I don't have classic sales-ops or quota-setting experience." |
| "I designed the partner motion" | Inflated form of F4 | "I built a partner-level revenue model used in carrier negotiations." |
| "I drove the ~$400M" or "I delivered the ~$400M" | Inflated form of F1's figure | "credited with a ~$400M ARR uplift," with attribution in her own words (A1, E2). |
| "I ran independent SQL or Tableau analysis that changed decisions" | Inflated form of "skilled in SQL/Tableau" | "skilled in SQL/Tableau," at its own scope. The analysis itself is an answer slot (F3, A3). |
| "I use AI to build products" | Inflated form of F6 | "I use AI tools daily." |

## 8. Sources

**Provided documents:** your message: the JD highlights, Priya's background summary, the interviewer profile and the research note.

**Searches attempted (all refused: web search permission was not granted in this session):**

1. "Dan Kovac Director of Sales Strategy pricing monetization" — refused
2. "Northwind Data Compass AI copilot launch enterprise expansion profitability" — refused
3. "Northwind Data company values interview process sales strategy" — refused

**Fetches:** none.

**Research tier:** L1. Searches 0 of 6 ran (3 attempted, all refused); fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Values cheat sheet dropped. Query 3 refused. |
| 2. Northwind interview process | unavailable | Loop structure is unknown, so persona weights use the round as you described it. Query 3 refused. |
| 3. Strategy / recent news | skipped | Your research note already supplies the three priorities and the competitive threat. |
| 4. Interviewer public footprint | unavailable | Interviewer read is limited to your profile. Query 1 refused. |
| 5. Representative JD | skipped | Your JD highlights fix the requirement list. Full text would replace them. |

## 9. Upgrade menu

- **Full JD text** → the six JD rows become grounded in the posting, and the coverage line is checked against the real list.
- **Priya's CV** → the evidence cells quote her CV lines, not your summary.
- **Search permission (or a retry)** → Northwind's values, the loop structure and Dan's public footprint, which would change the persona weights and the reverse questions.
- **The recruiter's note** → whether a pre-declared exercise or focus areas change the banks.
- **Dan's public talks or writing** → his recurring themes become questions.
- **Prep time before the interview** → a prioritized triage section.
