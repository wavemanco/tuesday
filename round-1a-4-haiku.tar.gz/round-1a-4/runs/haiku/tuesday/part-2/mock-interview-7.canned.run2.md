I have what I need for the pack. Writing it to the scratchpad now.
Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-2-rooms-case-7-canned-0e526421/a2b5780f-af93-4ca6-a3eb-2bf0925c92af/scratchpad/saltmarsh_games_live-operations-producer_interview_pack.md, and I've sent it to you.

I built it for a hiring-manager round. The company's careers page says the Friday interview is the "Outage Hour": a live-incident tabletop on a simulated outage during a live event, then a values conversation. So expect about half the hour on a live problem and half on the three published values: Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener.

Three things to know before you open it:

- **The biggest exposure is the two-title requirement.** The JD asks for a live-events calendar across two titles, and your material shows one. Question A2 is the one to rehearse hardest. Answer it from the one title you ran, and say what would carry across.
- **"Never led a team" will come up.** The pack has you open with the plain line "I haven't led a team." It never has you claim management.
- **Two sources were thin.** I read the Larkspur news and Tobias's GDC talk from search snippets only and did not open either page. The talk link also sits on a domain that looks like a placeholder, so check the talk before you cite it.

Say the word and I'll play the Skeptic on A2 so you can drill it. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_games_live-operations-producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep pack

Interviewer: Tobias Wrenfield, Head of Live Operations (hiring manager). Format: 60 minutes, Friday. Round: the Outage Hour, a live-incident tabletop followed by a values conversation, per the company's careers page.

## How to use

Personas describe how a question is asked. Types describe what is being scored.

Type key:
- **CASE**: a live problem from the role, scored on structure and reasoning.
- **JD**: a stated responsibility or requirement, scored on whether you can do the listed job, gaps included.
- **EXP**: what you actually did in your past work, scored on attribution.
- **VAL**: whether past behavior shows the company's published values.
- **CO**: company and strategy knowledge.

Guidance is scaffolding, not a script. Say it in your own words, and say only what you did.

## Fit snapshot

Requirements come from the JD you supplied, quoted, or from the company's careers page where marked. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one title and weekly content drops, not a live-events calendar across two titles. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you ran or shared a calendar for a second title, say which and what you decided for it. If there was only the one, say so and say what would carry across. |
| F2 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Bridge: "I wrote the release checklist our QA team still uses." Do not say "managed"; the material does not say it. The checklist has not been inspected, so expect a probe on what it covers. |
| F3 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | discovery | The quote shows you presented retention numbers. It does not show whether you built or checked them. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you built or checked the calculation, say which step and how. If you presented figures someone else produced, say so plainly. |
| F4 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | presentation | A written artifact that others use is indirect evidence; "clear" is not shown. Bridge: the same sentence as F2, with no adjectives added. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | The years are real. The material does not say live-service. This is length of experience, not a gate, so it is graded like any other row. Bridge: "For four years I was an associate producer at a puzzle-game studio." Answer slot: say in your own words how that title was run and what it meant for the calendar. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | Your message shows the calendar work: "I ran the weekly content-drop calendar for our main title for the last two years." It does not show who you coordinated with on each drop. | low | [grounded] | discovery | Bridge is an answer slot only. Name the teams that worked on a drop with you and what each one did on it. If the drops went through a route that was not yours to run, say so plainly. |
| F7 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | discovery | No post-event review is in the material. Answer slot: if you ran a review after a drop or event, say what it covered and which figures it reported. If the figures you presented were produced for you, say so plainly. |
| F8 | Outage Hour: "a live-incident tabletop on a simulated outage during a live event" (company careers page) | none given | none | [grounded] | discovery | Your material says nothing about live incidents. Answer slot: if you have handled a live problem during an event, say what happened and what was yours. If not, say so and walk through how you would order the first hour. |

No row is a hard gate. The JD states no location, pay, travel or credential requirement, so no gate question is asked.

## Reading the interviewer

Public footprint only. This comes from a search snippet; I did not open the talk page.

- **Career pattern:** a talk description says Tobias was previously a QA lead at a console studio and is now Head of Live Operations. That is a QA-to-live-ops path. Your checklist work (F2) touches the QA side, but your path is not a similar jump, so do not present it as one.
- **Self-described argument:** the talk "Patch Notes Are a Promise" (GDC 2026, per the snippet) argues that a live team is judged by how often its patch notes describe what actually shipped.
- **Implications:**
  1. Expect a question about the release checklist and what it actually checks (C3, D1).
  2. Expect the "Ship the Patch Not the Promise" value to be probed directly.
  3. Lean on the words "what was built, not what was hoped" in the Outage Hour.
  4. A QA-rigor probe on any claim you make about shipped content is likely.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The Outage Hour tabletop: a live incident during a live event | Highest. The round is structured as a live problem, and the company page names it | Clarify, then decide the owner, then what players see, then the post-event review. Think aloud. |
| Skeptic | Probes the gaps: two titles (F1), leading a team (F6), puzzle versus live-service (F5) | High. The hiring-manager prior puts the Skeptic next to the Case persona, and F1 and F6 are the thinnest rows | Rehearse A2 until it is plain. Use the acknowledgments only where you stated them. |
| Values / Behavioral | The second half of the Outage Hour: the three published values | High. The careers page names a values conversation | Map one story to each value only where a sentence in section 4 carries it. Otherwise use the selection scaffold and say so if none comes. |
| Prober | Asks how the retention numbers were built and what the checklist covers | Medium. The talk's QA-rigor theme pushes this up | Say what you know about how a figure was counted. Say plainly when you do not know. |
| Pressure | Interrupts, time-boxes | Low. Nothing in the sources signals a stress format | Hold a position through two follow-ups before conceding. |

## Question banks

Weights: Case 5 questions, Skeptic 4, Values 4, Prober 3, Pressure 2. Total 18.

### A. Case / Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live incident breaks during a live event and players are seeing it. Walk me through your first hour." | CASE | [grounded] | Structure it: clarify what is broken and who is affected, decide who owns the call, decide what players see and when, and record what goes into the post-event review. Speak it in 90 to 120 seconds. Use "Players Before Plans" and "Ship the Patch Not the Promise" only where they fit. Make no claim about your past in this answer. | The Outage Hour is a live-incident tabletop, from the company's own page. The question is that round's first prompt. |
| A2 | "Your JD asks for a calendar across two mobile titles. What have you run across more than one title?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI rehearsal in this pack. Hold: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you ran or shared a calendar for a second title, say which and what you decided for it. If there was only the one, say so plainly and say what would carry across. Hold through two follow-ups by returning to the one title. | F1 is the requirement's evidence and the likeliest probe. The JD names the two-title scope, so the question is raised by the JD. |
| A3 | "Walk me through how a weekly content drop goes from idea to live, for one title." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on the quote: the calendar, the weekly rhythm, one main title and two years. Name steps only if you took them. Answer slot: the JD's "coordinate design, art, engineering and community teams" makes a probe on who set the sequence likely. If you set it, say how, in your own words. If not, or it was not yours, say so plainly. | F1 and F6. The question asks for a process you ran, so it needs the attribution check. |
| A4 | "A content drop shipped with a bug, and the fix is not ready for the event. What do you tell players, and who decides?" | CASE | [grounded] (careers page: "a live-incident tabletop on a simulated outage during a live event") | Structure: name the decision owner you would propose, say what players see and when (announce what is built, not what is hoped), and say what the post-event review records. Answer slot: if you have handled a live problem of this kind, say what happened and what was yours. If not, say so and walk the plan. | F8 has no evidence. The question is a live problem from the company's own round. |
| A5 | "Retention drops three points in the week after a drop. Diagnose it." | CASE | [grounded] "comfortable with player-retention metrics" (JD) | Name what you would check first: the drop's content, the cohort, the week's other changes. Name the assumption behind the figure you would defend least, before they do. The question supplies no figure of yours. | The JD names retention metrics, so the diagnosis is raised by the JD. Nothing here claims your past. |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never led a team. How do you coordinate design, art, engineering and community on an update without managing them?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Open with the plain acknowledgment: "I haven't led a team." Then say what you did do on the calendar. The coordination question is answer slot F6. Do not add "managed" or "led". | F6 and the stated negative. The JD's "coordinate" line raises the question. |
| B2 | "You've never worked on a game with in-app purchases. What would you need to learn first?" | JD | [grounded] "never worked on a game with in-app purchases" | Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then give a plan, as a plan and not as a past: what you would read, what you would ask, what you would check first. Do not assert anything about the titles here. | The negative is one you stated, so the acknowledgment is yours to say. The question does not assume the titles use purchases. |
| B3 | "Your material says you presented retention numbers. Did you build the calculation?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Hold: "I presented the monthly retention numbers to the studio head." Answer slot: if you built or checked the calculation, say which step and how, in your own words. If you presented figures someone else produced, say so plainly. Never claim the build. | F3 is discovery. This is the most likely place to be pushed on the JD's metrics line. |
| B4 | "What would the first thirty days in this role need to show, that your past work does not?" | JD | [generic] | Name the first things you would learn: the current calendar, the post-event review format, the KPIs the review reports. Say what you would measure first. Make no claim about your past. | F7 and F1. The question is a role pattern, not a fact about the company. |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time players and the calendar disagreed. What did you do?" | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time a calendar date and what players were experiencing pulled apart. If none comes to mind, say so plainly, then give the nearest thing your material carries: the retention numbers you presented, and what you did with them, in your own words. | "Players Before Plans" from the company's values page. Your material holds no story about a player-versus-plan clash. |
| C2 | "Tell me about a time you held a release against the checklist. What happened?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: pick a time you held a release line against the checklist. If none comes to mind, say so plainly, then describe the checklist you wrote, what it covers, and who uses it. Do not supply an outcome. | "Ship the Patch Not the Promise" from the values page. |
| C3 | "What have you changed in a checklist since it went live, and why?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Answer slot: if you revised the checklist after it was in use, say what changed and why. If it has not changed since you wrote it, say so plainly. | "Leave the Build Greener" from the values page, and F2's probe. |
| C4 | "A date you gave players slips. What do you say, and when?" | VAL | [grounded] "Players Before Plans" (company values page) | Announce what is built, not what is hoped. State the slip plainly. Give a new date only once it is built. Make no claim about a past slip. | Values page, "Ship the Patch Not the Promise" and "Players Before Plans" together. |

### D. Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What does the release checklist cover, and who has changed it since you wrote it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say what it covers in your own words. If it has changed, say by whom and how far you were involved. If it has not, say so plainly. | F2. The question asks what the checklist does; QA's involvement is the attribution check. |
| D2 | "Walk me through the monthly retention numbers you presented: the period, what counted as retained, and the assumption you would defend least." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | No figure of yours is in the material, so this is an answer slot. Say what you can about the period and the counting. If you do not know how a figure was counted, say so. Do not reconstruct a method you did not see. | F3. This is the defend-the-number probe, applied to the figures you presented. |
| D3 | "The JD says you would manage the release checklist with QA. What does managing it involve?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Do not adopt "manage". Say what you wrote and what QA does with it. If you do more than that, say what, in your own words. If its upkeep was not yours, say so. | F2. The question presupposes management; the answer may decline it. |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why hire someone who has never led a team for this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Hold the position through two follow-ups: "I haven't led a team. I ran the weekly content-drop calendar and wrote the checklist QA uses." Concede specifically: you have not coordinated four functions across two titles. Do not fold on what you did. | F6 and B1. |
| E2 | "What would you need to learn first about a game with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" | Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then name what you would learn first, as a plan. | B2. Asks a plan question, not a claim about the company. |

## Values cheat sheet

The values come from the company's values page, fetched. The round has a values conversation, per the careers page, so this section applies.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | F3 and C1. Your quote is the retention numbers you presented. No clash is in your material, so use the selection scaffold in C1. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | F2 and C2. The checklist is what you wrote. Its outcome is not in your material. |
| Leave the Build Greener | Each release leaves the codebase and the checklist better than it found them. | F2 and C3. Your quote says the checklist is still used. It does not say you improved it. Use the answer slot in C3. |

## Reverse questions

Each has a "why it lands."

1. "Your GDC talk argues a live team is judged by how often its patch notes describe what shipped. Before you moved into live operations, what did you check that you now delegate?" Why it lands: ties to the talk and his own path. It turns the interview toward a peer conversation.
2. "Project Larkspur moves both titles onto one shared events calendar from February 2027. What would the first ninety days in this role need to settle?" Why it lands: shows you read the company's news. Source is a search snippet; I did not open the page.
3. "The Outage Hour ends in a values conversation. Which of the three values do teams most often break under a live event?" Why it lands: opens the values talk on the interviewer's terms.
4. "How is the release checklist with QA handled now, and who owns changes to it?" Why it lands: shows you care about ownership, the JD's "manage" line.
5. "What does a post-event review look like here today, and which KPIs does it report?" Why it lands: puts the JD's own line to the interviewer and prepares F7.

## Prohibited claims

These are claims this pack will not coach. Each entry gives its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have led a team" or "I managed people" | Your stated negative: "Never led a team" | "I haven't led a team." No slot. |
| "I owned the calendar for two titles" | Inflated form of F1: your quote says one main title | F1's quote at its own scope. Pack observation: your material says one title. A2's slot stays inside the one title. |
| "Our puzzle title was live-service" | Inflated form of F5: your quote says a puzzle-game studio | "4 years as associate producer at a puzzle-game studio." No live-service claim. |
| "I coordinated design, art, engineering and community on each drop" | Inflated form of F6: your quote says you ran the calendar | The calendar quote at its own scope. F6's slot asks who worked on a drop with you. |
| "I owned the KPIs and the post-event review" | Inflated form of F7: your quote says you presented monthly numbers | "Presented the monthly retention numbers to the studio head." F7's slot asks what the review covered. |
| "I built the retention calculation" | Inflated form of F3: your quote says you presented | "Presented the monthly retention numbers to the studio head." B3's slot asks which step was yours. |
| "The checklist cut release problems" or any outcome for it | Outcome not in your material; inflated form of F2 | "Wrote the release checklist our QA team still uses." |

## Sources

Provided documents: your message (the background and the JD text in the request). No CV file was supplied.

Searches and fetches, in order:

1. Query "Saltmarsh Games values". Returned: saltmarshgames.com/values. Outcome: yes.
2. Query "Saltmarsh Games interview process live operations producer". Returned: saltmarshgames.com/careers/interviewing. Fetched and read. Outcome: yes.
3. Query "Saltmarsh Games strategy news". Returned: saltmarshgames.com/news/project-larkspur. Read from the search snippet only; not fetched. Outcome: yes.
4. Query "Tobias Wrenfield Saltmarsh Games". Returned: a GDC 2026 talk page, "Patch Notes Are a Promise", on talks.gdconf.example. Read from the search snippet only; not fetched. The domain looks like a placeholder, so verify the talk before you rely on it. Outcome: yes.
5. Fetch saltmarshgames.com/values. Read. Named the three values.
6. Fetch saltmarshgames.com/careers/interviewing. Read. Named the Outage Hour.

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet: three values named from the fetched page |
| 2. Saltmarsh Games interview process | yes | Round structure: the Outage Hour, a 60-minute hiring-manager session with a live-incident tabletop and a values conversation |
| 3. Saltmarsh Games strategy / recent news | yes | Reverse question 2 and the first-ninety-days question, from the Larkspur snippet |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Reading the interviewer: the GDC talk and QA-lead path, from a snippet only |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot |

Not searched: a deeper interviewer footprint, role-family loop reports, and the Larkspur press release beyond the snippet. These are the L2 targets, offered in the upgrade menu.

## Upgrade menu

- A redacted copy of the release checklist you wrote, with nothing studio-confidential in it → F2 moves from medium to high, and the checklist becomes an artifact you can point to.
- Any calendar you shared or ran for a second title → F1 moves from transferability to a stated match, and A2 gets a direct answer instead of a slot.
- How the monthly retention numbers were built, and which step was yours → F3 moves from discovery, and B3 and D2 get a stated practice to rehearse.
- Any post-event review you ran, and what it covered → F7 moves from discovery, and C-bank probes get a real example.
- Any live problem you handled during an event, and what was yours → F8 moves from none to grounded, and A1 and A4 get a real case.
- Your puzzle title's model in your own words, such as how its content ran → F5 moves from transferability.
- Verify the GDC talk page. I saw it only in a search snippet → fetching it confirms the talk title and claim before you rely on them.
- A deeper research pass, for the Larkspur detail, the interviewer's other talks, role-family loop reports and recent organisation changes: up to 6 more searches and 2 more fetches, several more minutes. Want it?
