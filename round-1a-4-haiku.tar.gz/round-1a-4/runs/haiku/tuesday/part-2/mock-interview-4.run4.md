The mock-interview module is running. It needs company values, interview structure and current strategy from research, since the dossier doesn't carry them, so I'll run the L1 targets first.
Web search was refused for this session, so the research targets came back unavailable and the pack is built on your dossier and the module's generic material. I'll write the pack file now.
Your prep pack is saved as /var/tmp/tuesday-measure/1a4/runs/haiku/tuesday/part-2/rooms/case-4-denied-4c4835f8/quartzline_product-manager-platform-apis_interview_pack.md. I built it for a hiring-manager round from your dossier. Web search was refused in this session, so the pack has no Quartzline values, interview structure or strategy. Those rows are marked unavailable, and the questions that depend on them are generic.

The one to rehearse is A2: "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" The dossier names it as the most likely objection. Your answer holds on the integration work at its own scope, and concedes the PM title and roadmap ownership without folding.

Say the word and I'll play the Skeptic on A2.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: hiring-manager conversation, 45 minutes, Thursday. Interviewer: not named. Built from tuesday-dossier.md (decision conditional_go, dated 2026-08-14). No web research ran; see Sources.

## How to use and type key

Personas describe how a question arrives. Types describe what is being scored.

- **VAL**: behavioral and values alignment
- **EXP**: your own past work, and whether it holds up under scrutiny
- **JD**: the job's listed responsibilities and qualifications, gaps included
- **CO**: company and strategy knowledge (none in this pack; see Sources)
- **CASE**: a live problem from the role, with no claim about your past

Guidance is scaffolding, not a script. Text in quotation marks is your own words from your CV, your messages or the dossier. An answer slot is a question you answer in your own words, and either honest branch it names is a valid answer.

## Prep triage

1. Rehearse A2 out loud until your concession sounds ordinary. The dossier names this objection as the one most likely to be asked.
2. Drill C1: how the 30+ integrations were counted. You need a clean answer in your own words.
3. Have answers ready for F5 and F6. Schema work and agile delivery are where your material says nothing.

Everything else is insurance.

## Fit snapshot

Requirements come from the dossier's role_profile, which stands in for the JD. Evidence is quoted from the dossier's verified entries. Rows F3 to F5 are this pack's own grading; the underwriter did not grade them. Treat those three as this pack's view.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row) | low | [inferred] | transferability | Adjacent work, not PM years. Say the integration work at its own scope and name the limit: it was integration delivery, not product management. Never describe it as PM experience. |
| F2 | "Own the roadmap for the partner-facing API platform" (dossier role_profile) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row) | none | [grounded] | capability | The dossier records that roadmap ownership is absent. Words: "I haven't owned a product roadmap." The session quote is medium on its own claim, but it feeds evidence to product and does not make roadmap decisions. Do not bridge to ownership. |
| F3 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row) | high | [grounded] | discovery | The verified entries show client-side work. They show no engineering or sales stakeholder work. Answer slot: if you managed engineering or sales people on any integration, say who and how. If you worked mainly through the client, say so plainly. |
| F4 | "Shipped API or platform products" (dossier role_profile R2) | "Wrote the internal integration playbook her team uses" (dossier row) | low | [inferred] | transferability | Integration work and a playbook are adjacent to shipping, not evidence of it. Answer slot: if you shipped an API or platform product yourself, name it and your part. If not, say so plainly and describe the integration work at its own scope. |
| F5 | "Technical fluency: API docs, schemas" (dossier role_profile R3) | "Wrote the internal integration playbook her team uses" (dossier row) | low | [inferred] | discovery | The material shows integration documentation but not schema work. Answer slot: if you have read or written API schemas, say which. If the work was mostly reading vendor docs, say that. |
| F6 | "Agile delivery experience" (dossier role_profile R5) | none given | low | [grounded] | discovery | Nothing quoted speaks to agile delivery. Answer slot: if you worked to sprints or a backlog, say which and what you ran. If not, say so plainly and ask what they mean by agile delivery here. |

## Prohibited claims

These are not coached in any answer, slot, hold or drill feedback in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier prohibited_claims | "I haven't held a product manager title or role." Plain acknowledgment, sourced to the dossier's prohibited_claims field. |
| Having owned a product roadmap | dossier prohibited_claims and uncertain_or_weak_areas (acknowledge_gap) | "I haven't owned a product roadmap." Sourced to the acknowledge_gap field. |
| Having set prioritization for an engineering squad | dossier prohibited_claims | "I haven't set prioritization for an engineering squad." Sourced to prohibited_claims. |
| Shipped API products | Inflated form of "Led 30+ end-to-end client integrations" (F1) | The quote at its own scope. The limit is this pack's observation: your material says integrations, not shipped products. |
| Set the API platform's product decisions | Inflated form of "Ran quarterly roadmap-input sessions feeding client evidence to product" (F2) | The quote at its own scope. The limit is this pack's observation: your material says the sessions fed evidence to product, not decisions. |

## Persona table

Relationship prior for a hiring manager: Case/Strategist and Skeptic, per the persona model. No interviewer name was given, so there are no interviewer signals. No loop source was found, so the weights rest on the round-type prior, not on a documented process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the PM title, the roadmap and the day-one weak spot | High. A hiring manager is buying capability and derisking gaps, and the dossier names the PM-title objection | Name the gap first, in your own words. Bridge at the quote's scope. Give a ramp plan. Hold, then concede. |
| Case/Strategist | A live problem on the platform roadmap or partner adoption | High. The hiring-manager prior, and the role is roadmap and partner discovery | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. |
| Data-Driven Prober | Counts behind the 30+ integrations and the sessions | Medium. The JD names adoption metrics and the dossier flags no baseline | Name your weakest assumption before they do. Say plainly what you cannot reconstruct. |
| Pressure | Time-boxed challenges to the fit | Medium. Stress style is unknown for this interviewer | Pause, restate, hold through two follow-ups, concede one specific thing. |
| Conversational | An opener and an "anything for me?" close | Low, but the opener is scored | A 90-second arc from your quoted entries. |

Weights: Skeptic 5, Case/Strategist 4, Data-Driven Prober 3, Pressure 3, Conversational 2. That totals 17 questions, one under the usual band. I have not padded it.

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (dossier role_profile); the negative rests on the dossier acknowledge_gap field | Name the roadmap in the JD's words. Say what you have not done: "I haven't owned a product roadmap." Then the first thing you would do to learn it, said as a plan, never as a past. | Skeptic stem. The roadmap line is F2's gap. |
| A2 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; the negative rests on dossier prohibited_claims and acknowledge_gap | Hold: "What I've led is the integration work," then the quote at its own scope. Hold through two follow-ups by returning to that work, not by adding to it. Concede: "I haven't held the PM title or owned a roadmap, and three years of the job is a real advantage I don't have." Then one ramp step, as a plan. | The underwriter named this objection, so it gets the deepest rehearsal. The question's negatives are sourced to named dossier fields, so it is asked as written. |
| A3 | "Which product decisions in that integration work were yours to make, and which went to someone else?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if a scoping or architecture decision was yours, say which and how you decided. If it was not yours, say so plainly and stay with the integration work at its own scope. | Tests attribution on the verified claim, which the dossier rates high. |
| A4 | "Have you ever defined an adoption metric? Tell me about one." | JD | [grounded] "Define and track adoption metrics" (dossier role_profile) | Answer slot: your material does not show an adoption metric. If you set or tracked a baseline on any integration, say which and how it was counted. If you have not, say so plainly and say what you would need to see first. | The JD names adoption metrics; the dossier flags that no baseline is stated. |
| A5 | "How has delivery been organised in the integration work you've led?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; JD line "Agile delivery experience" (dossier role_profile) | Clarify strategy: nothing quoted speaks to agile delivery itself, so the slot is the whole answer. If you worked to sprints or a backlog, say which. If you did not, say so plainly and ask what the team means by agile delivery. | F6's gap, under the clarify strategy from the dossier. |

### B. Case/Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner asks for a change that would break two integrations they already run. Walk me through how you'd decide." | CASE | none; the problem is the role's own | Structure: what breaks and for whom, objective, partner segmentation by integration, approach (versioning, deprecation window, communication), metrics, risks. Think aloud. | A live problem from the API-platform role. It makes no claim about your history. |
| B2 | "Partner adoption of the API dropped 20% this quarter. Diagnose it." | CASE | none; the problem is the role's own | Clarify the metric definition first. Split by partner tier and integration type. List the causes you would test, then the data you would need before concluding. | Case stem. Adoption is a stated responsibility. |
| B3 | "Two engineering squads disagree on the next release's priority. How do you handle it?" | JD | [grounded] "Write specs and drive delivery with two engineering squads" (dossier role_profile) | Structure the decision: whose priority wins, on what criteria, and how you bring the squad leads in. Do not claim the decision right; who holds it is the open question. Answer slot: if you have resolved a disagreement between engineers and a client or product, say which and what you did. | The decision-rights unknown from the dossier, asked as a case. |
| B4 | "You have three partner asks and one squad's capacity. What do you put first?" | CASE | none; the problem is the role's own | Clarify the criteria (partner value, revenue, platform risk). Name the trade-off out loud. Say what you would tell the partners you are not doing. | Prioritisation as a live problem. No candidate claim is made. |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot, defend-the-number: say how you counted them, what the count is sensitive to (what counted as end-to-end, which go-lives), the assumption you would defend least, and which part was yours. If you cannot reconstruct the counting, say so. | The headline number. The 30+ attaches to integrations, not to outcomes. |
| C2 | "Which assumption behind the quarterly roadmap-input sessions would you defend least?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer slot: name, in your own words, the assumption you would defend least. If you can show a product decision that changed because of the sessions, say which. If you cannot show one, say so. | The medium-confidence claim has limited inspectable proof, and a prober will find that seam. |
| C3 | "How would you know the integration playbook is being used?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Answer slot: if you can point to how the team uses it, say how. If you cannot see usage, say so and say what you would check first. | Tests the playbook claim beyond the sentence itself. |

### D. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM who has three years of the job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" | Pause, then restate the question. Hold through two follow-ups: the work you have is the integration work, stated at its own scope, and it is adjacent to PM work, not PM experience. Concede one specific gap in one sentence. Do not fold on the integration claim. | Pressure stem. The hold is the quote, not a stronger claim. |
| D2 | "That integration work — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: say which of the listed stages you ran, in your own words. If a stage was not yours, say so plainly. Do not add stages. | Attribution probe on the verified claim. |
| D3 | "You've integrated other people's APIs. Have you shipped one?" | JD | [grounded] "Shipped API or platform products" (dossier role_profile R2) | Answer slot: if you shipped an API or platform product yourself, name it and your part. If not, say so plainly and describe the integration work at its own scope. Do not reach for a stronger word than integration. | F4's gap, asked directly. |

### E. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | JD | [grounded] the three verified entries, quoted in the fit snapshot (F1, F3, F5) | A 90-second arc: the integration delivery at the vendor, then the playbook, then the roadmap-input sessions. Name the PM gap in one sentence. | An open opener, scored anyway. |
| E2 | "What are you playing with in API docs and schemas these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" | Answer slot: name what you have actually read or written in API docs and schemas. If the work was mostly reading vendor docs, say so. | R3 is marked important, and the material does not show schema work (F5). |

## Reverse questions

Each one carries why it lands.

1. "Which roadmap decisions does this role make alone, and which belong to the two squad leads?" Lands because it verifies the squad-authority question the dossier leaves open.
2. "How is partner API adoption measured today, and what is the current baseline?" Lands because adoption is a stated responsibility with no baseline in the posting. The answer tells you whether the metric exists at all.
3. "What would a strong first 90 days look like for someone coming from integration delivery?" Lands because it turns your gap into a ramp plan they have to react to.
4. "Which squad carries the partner-facing roadmap today, and what is each one blocked on?" Lands because it tests the two-squad structure against the JD.
5. "What did the last person in this role get right, and what did they wish they had?" Lands because it shows how the role has gone before, without assuming anything about that person.
6. "How will you decide, at six months, whether this hire worked?" Lands because it asks for success criteria, which you can then measure yourself against.

## Sources

Provided documents: tuesday-dossier.md, sections role_profile (the JD equivalent), handoff_to_mock_interview (verified evidence, weak areas, the named objection, risks, employer questions, prohibited claims) and decision. The dossier is dated 2026-08-14, about fourteen weeks before this round. Check the posting and the role's scope with the recruiter before Thursday; the dossier may be stale.

Research tier: L1 — searches 3 of 6, fetches 0 of 2; all 3 searches refused; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet. No values round was detected, so the sheet is absent either way. Query "Quartzline values": refused. |
| 2. Quartzline interview process product manager | unavailable | Loop structure. Persona weights rest on the hiring-manager prior, not on a documented process. Query "Quartzline interview process product manager": refused. |
| 3. Quartzline strategy / recent news | unavailable | CO bank. No strategy-grounded question exists, and the CASE bank is generic. Query "Quartzline strategy news": refused. |
| 4. Interviewer name | n/a | No name was given, so no query could be formed. |
| 5. Representative JD | skipped | The dossier's role_profile supplies the JD lines. |

## Upgrade menu

- A recruiter note on the interview format → confirms whether Thursday is the only round or part of a loop, and reweights the personas.
- Quartzline's values page, pasted → a values cheat sheet, only if a values round is named.
- The interviewer's name → a reverse question tied to their path, and persona weights from their public footprint.
- Permission to run web search (refused this session) → the three research targets above. A deeper strategy pass is available once, if you want it: up to six more searches and two fetches, several minutes.
- Your raw CV → the verified entries can be checked against the source, which would upgrade the grading of F1 to F6.
- A refreshed dossier, if the posting has changed since 2026-08-14.
