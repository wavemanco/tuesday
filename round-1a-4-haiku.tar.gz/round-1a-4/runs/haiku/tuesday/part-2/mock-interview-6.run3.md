I'm routing this to mock-interview, since you have interviews coming up and asked for prep and drills. Reading its playbook first.
The playbook is loaded. Before I write anything, I need the rules for output, personas, the question rubric and the reframing audit, plus the research checklist. I'm reading them in parallel.
The playbook calls for research on the company (values, loop structure, strategy) before I write the pack. Loading the search tool first.
WebSearch was refused on permission, so the research targets are unavailable. I won't retry the calls. The pack will be built from your message and the playbook's generic fallbacks, and every company-specific claim is labeled or left out. Writing the pack now.
Your prep pack covers all three rounds in one file. It is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-2-rooms-case-6-denied-527212fe/e43fb2fc-97ed-4665-a126-837ccd4b0171/scratchpad/Larkfield_Systems_engineering-manager_interview_pack.md. It has a shared fit snapshot and a bank of eight questions per round, with the reverse questions for each.

**Company research didn't run.** The three web searches were refused on permission, and I didn't retry them. So I have no Larkfield values, interview-loop details or strategy. The values cheat sheet is omitted, and the strategy and case questions are generic. If you grant search permission, I can rerun the research and update the pack.

**What the pack is built on:** your message, the role summary you pasted, and your schedule. Every claim about your past quotes one of your sentences, and the pack does not add a method, figure or outcome you didn't give.

**What it says you should prepare for:**
- **Director round:** "You've never owned a hardware-adjacent roadmap." That is the highest-return prep item. Lead with your plain acknowledgment, then a concrete plan for learning hardware.
- **Scope:** "Eleven engineers is more than the six you've led." You need a clear answer on where your six-person experience transfers and where it stops.
- **The 60% on-call figure:** three rounds will probe it. Rehearse how it was counted and which assumption you would defend least, in your own words. The pack doesn't supply either.
- **Managing managers:** you've said you haven't. The VP may press on it, so the pack has you hold on your six-person scope rather than argue it's not needed.

**One question:** can you paste the full job posting and your CV? Both would turn the role summary into complete requirements and add inspectable detail to your stories. If you'd rather not, I'll keep the pack as it stands.

Two offers, neither pushed: I can run a live drill on the Director round's hardware question, which is the pack's highest-return item, and I can save a `tuesday-dossier.md` recording the gaps this prep exposed for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield_Systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems

**Loop mode, three rounds.** Round 1: hiring manager (Director of Engineering), 45 min, Tuesday. Round 2: panel (two staff engineers and a product manager), 60 min, the Thursday after. Round 3: VP Engineering, 30 min, the following Monday, described by the recruiter as "values and leadership philosophy." Interviewer names not given. This is a first build; nothing to regenerate.

## How to use + type key

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.

- **VAL**: behavioral / values alignment
- **EXP**: your own past work, probed for attribution
- **JD**: the role's stated responsibilities
- **CO**: company and strategy knowledge (none researched here; any CO item is generic)
- **CASE**: a live problem from the role

Provenance labels: `[grounded]` traces to your message or the role text you pasted. `[inferred]` is this pack's derivation. `[generic]` is a pattern with no claim about you or Larkfield.

## Sources

- **Provided documents:** your message. It contains the role description ("Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap"), the round schedule, and your background.
- **Research tier: L1, searches 3 of 6, fetches 0 of 2.** Three searches were sent and all three were refused on permission. Nothing was retried.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have supplied published values for a values cheat sheet. Not built. Round 3's VAL items rest on the recruiter's words, "values and leadership philosophy" |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have confirmed the loop. The loop is established by your own schedule, so the persona weights below do not depend on it |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have supplied current strategy for CO and CASE items. All CO and CASE items below are generic |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Engineering Manager` JD | skipped | A role description was supplied, and it fixes the fit snapshot's requirements |

Research tier: L1 — searches 3 of 6, fetches 0 of 2

## Fit snapshot (shared across all three rounds)

Requirements come from the role description in your message. It is a summary, not the full posting, so the list may be incomplete. There are no gate rows: the text states no location, travel, authorization or credential term.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role description, your message) | "9 years engineering, 3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says one team of six, for three years. Keep it at that scope and do not say two squads. Answer slot: if you have led work across two groups at once, say what it involved and how you split it; if you have not, say so plainly and say how you would set up two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role description, your message) — delivery part | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | presentation | This already says delivery under pressure, in your terms. Lead with the quarter you pushed through and the result. The 60% is a figure, so it raises the defend-the-number slots in the banks. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role description, your message) — hiring part | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap, but a CV line with nothing inspected behind it, so expect a probe. Lead with the loop in your words. Your material does not show the 11-engineer hiring plan, and the pack does not claim it. |
| F4 | "own delivery, hiring and growth for 11 engineers" (role description, your message) — growth part | none given | none | [grounded] | discovery | Your material is silent on growing engineers. Answer slot: say how you have grown engineers, if you have, with the people and what changed for them. If you have not run a growth plan, say so plainly and say what you would do first. |
| F5 | "partner with hardware and product on roadmap" (role description, your message) — hardware part | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan, never as a past. |
| F6 | "partner with hardware and product on roadmap" (role description, your message) — product part | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Holding a roadmap against pressure is adjacent to partnering on one. Say the pressure and what you did with it, at that scope. |
| F7 | "device-management services" (role description, your message) | "currently at a payments company" — your message | low | [inferred] | transferability | Derivation: backend work in a payments company is treated as adjacent to backend services elsewhere. No device work is shown. Name the adjacency and its limit only. Do not claim device experience. |

## Prohibited claims (built locally, binds every cell below)

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads | Inflated form of F1 | "3 as a team lead of 6," at its scope. The limit is the pack's observation: your material says one team of six. |
| Managed managers | You stated the negative | Plain acknowledgment: "I've never managed managers." |
| Owned a hardware-adjacent roadmap | You stated the negative (F5) | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." |
| Designed the reliability plan, or led the on-call fix | Inflated form of F2 | "I pushed a reliability quarter through against roadmap pressure." The pack observes that your material does not say who designed its scope. |
| Stated the method behind the 60% | Inflated form of F2 | "dropped 60%." How it was counted is an answer slot, not a claim. |
| Designed the hiring process | Inflated form of F3 | "I run our hiring loop for backend roles." |
| Built device-management services | Inflated form of F7 | "currently at a payments company," at its scope. |

---

## Coverage: requirement to question IDs

| Requirement | Questions |
|---|---|
| Lead two squads building device-management services | H4, N2, V4 |
| Own delivery | H7, N3, N4 |
| Own hiring | N1, V3 |
| Growth for 11 engineers | H3, V2 |
| 11 engineers | H6, V4 |
| Partner with hardware on roadmap | H2, H5, N7 |
| Partner with product on roadmap | H1, N5, N6 |
| Device-management services | H4, N8 |
| 60% on-call figure (not a requirement; a headline metric) | H8, N3, N4 |

No requirement is left without a question.

---

## Round 1: Hiring manager (Director of Engineering), 45 min

**Persona weights**

| Persona | Questions | Reasoning |
|---|---|---|
| Case / Strategist | 4 (H1 to H4) | Hiring managers buy capability and test the roadmap. Expect live problems on the squads' real work. |
| Skeptic | 2 (H5, H6) | Reduced from the usual mid-weight because the round is 45 minutes. H5 is the highest-ROI item in this pack. |
| Pressure | 1 (H7) | Tests whether you hold the reliability story without folding. |
| Data-Driven Prober | 1 (H8) | Your 60% figure is a headline metric, and the coverage rule requires a defend-the-number item for it. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Eleven asks have landed on two squads, and you have capacity for three. How do you choose, and who do you tell?" | CASE | [generic] | Clarify the objective and the constraints first, then the criteria for choosing, then who must hear the decision and when. Think aloud. Make no claim about your past. | A live roadmap problem from the role. The question presupposes nothing about you, so there is no quote to support. |
| H2 | "A hardware dependency slips a quarter. What do you tell product, and what do you tell hardware?" | CASE | [generic] | Separate the two audiences: what product needs to decide, what hardware needs to unblock. Give the first two actions and the risk to name. | Hardware is where F5 is weakest, so a live hardware problem tests the gap without asking about your past. |
| H3 | "One of your engineers is strong but stalled. What do you do in the first month?" | CASE | [generic] | Diagnose before acting: what is stalling them, what they need, and what you would test first. Name one concrete step for the first two weeks. | Growth is a discovery gap (F4). This question tests the reasoning without requiring a record of growing people. |
| H4 | "Two squads, one of them new to device-management services. What would you need to know before you set their priorities?" | JD | [grounded] "Lead two squads building device-management services" (role description, your message) | Name the three things you need first: the squads' current scope, the hardware constraints, and the product commitments in flight. Answer slot: if you have led two groups before, say how you began; if you have not, say so plainly and describe your first steps. | The role's headline requirement. Answer from the question's logic, not from a claimed record. |
| H5 | "You've never owned a hardware-adjacent roadmap. How would you handle the hardware side of this role?" | Skeptic | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | **Highest-ROI prep in this pack.** Lead with the plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then give the plan: what you would learn first, who you would learn it from, and how you would know it was working. Hold through two follow-ups by returning to the plan. Concede the gap specifically; do not bluff a hardware record. | The question presupposes your own stated negative, so it is allowed. It is the objection the role most likely raises. |
| H6 | "Eleven engineers is more than the six you've led. Where does your six-person experience transfer, and where does it stop?" | Skeptic | [grounded] "9 years engineering, 3 as a team lead of 6" (your message); "own delivery, hiring and growth for 11 engineers" (role description) | Say where your six-person work carries over, in your terms. Then say where it stops and what you would change at eleven. Do not claim more than six. | Scope gap between your record and the role. The question names the gap as the interviewer's. |
| H7 | "The reliability quarter went through against roadmap pressure. What was the pressure, and how did you handle it?" | Pressure | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Tell it in your own words. Name the pressure and what you did with it. Hold your position through two follow-ups. Answer slot: if a trade-off was yours to make, say which and how you decided; if it was not, say so plainly. | Delivery under pressure is F2's strongest evidence and a probe is likely. |
| H8 | "The on-call burden dropped 60%. How was that counted, and which part of it was yours?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Defend-the-number: say how it was counted, what it is sensitive to, and the assumption you would defend least, in your own words. Answer slot: if you do not know how it was counted, say so plainly. Which part was yours is in your own words, and the pack does not supply it. | Headline metric, so a defend-the-number item is required. The method is not in your message and is not supplied here. |

**Reverse questions**

1. "What would the first two quarters look like for the first squad I'd lead?" *Why it lands:* it turns the interview toward delivery and shows you are planning, not just pitching.
2. "Where does hardware's roadmap input reach product today, and where does it stall?" *Why it lands:* it asks where the partnership actually breaks, which is the role's hardest seam.
3. "What has made the last two engineering manager hires succeed or stall here?" *Why it lands:* it asks about the real pattern and shows you intend to be judged on outcomes.
4. "What does a Director here need from an EM that they are not getting now?" *Why it lands:* it asks the boss directly and tests the fit from their side.
5. "How is the 11-engineer plan set, and which part of it is still open?" *Why it lands:* it surfaces what you would inherit and how much of it is decided.

---

## Round 2: Panel (two staff engineers and a product manager), 60 min

Names not given, so persona weights are blended by member type.

**Persona weights**

| Persona | Questions | Reasoning |
|---|---|---|
| Peer Evaluator | 2 (N5, N6) | The product manager is the cross-functional peer. Roadmap partnership is the panel's main seam. |
| Case / Strategist | 3 (N2, N7, N8) | Both staff engineers and the product manager can set live problems. |
| Data-Driven Prober | 2 (N1, N3) | Staff engineers are technical specialists and will test the two headline figures. |
| Pressure | 1 (N4) | A staff engineer may challenge the 60% figure. Hold, then concede specifically. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| N1 | "About forty interviews last year. How was that number counted, and which part of the loop was yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Defend-the-number: what was counted, what it is sensitive to, and the weakest assumption, in your words. Answer slot: if you made the call on a hire, say how; if the call was someone else's, say so plainly. | F3 is the hiring evidence and a staff engineer will probe its count. |
| N2 | "How would you split a device-management backlog across two squads?" | JD | [grounded] "Lead two squads building device-management services" (role description, your message) | Structure the split: by component, by hardware dependency, or by customer. State the criterion and one risk. Make no claim about your past. | JD-tagged; a technical staff engineer will test the design reasoning. |
| N3 | "Walk me through the reliability quarter you pushed through. What did you measure, and which assumption behind the on-call figure would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Defend-the-number, plus the weakest-assumption move: name the assumption before they do. Answer slot: if you did not measure it yourself, say so plainly and say what you know about the measurement. | Prober question on the 60%. The panel's staff engineers are the likeliest to test the number. |
| N4 | "A 60% drop in on-call burden is a strong claim. What would make you withdraw it?" | Pressure | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold-then-concede: hold the figure you gave, then name the specific condition that would make you withdraw it. Do not fold on the core claim just to restore harmony. | A stress item on the same figure. Tests composure without adding content. |
| N5 | "Where does the roadmap get decided, and where would you need me to say no?" | Peer | [grounded] "partner with hardware and product on roadmap" (role description, your message) | Reciprocity framing: what you would bring to product's side and what you would need from it. Propose a seam principle, not a claimed history. Answer slot: if you have held a roadmap against pressure, say what it was and what you did. | F6 is adjacent evidence. The PM is scoring partnership fit, so the answer must be collegial. |
| N6 | "Our squads and the hardware team sit side by side. Where's the seam, and what happens when we disagree?" | Peer | [grounded] "partner with hardware and product on roadmap" (role description, your message) | Propose seam principles and how you would handle disagreement between equals. Do not pretend to know the seam. Keep to the disagreement you can describe. | Peer stem on the role's own seam. The question is the interviewer's, so it may name the seam. |
| N7 | "A release date moves because hardware slipped. What do you do in week one?" | CASE | [generic] | Clarify what is committed and to whom, then decide what to tell product and what to escalate. Name the first two actions. | A live hardware problem from the role. Tests F5's weakest area without asking about your past. |
| N8 | "A firmware update doubles pages on the on-call rota. Diagnose it." | CASE | [generic] | Clarify what changed, then segment the pages by device and version. Name the likeliest cause and the test that would confirm it. | A live reliability problem in device services. Scores structure over the right answer. |

**Reverse questions**

1. "Where have roadmap decisions between product and hardware stalled in the last two quarters?" *Why it lands:* it asks for the actual seam, which the PM can answer and the staff engineers will respect.
2. "What does a bad week on the device-management services look like today?" *Why it lands:* it shows you are thinking about delivery reality.
3. "How does a delivery commitment get changed when hardware's schedule moves?" *Why it lands:* it tests the panel's process for the exact problem in N7.
4. "What could a new engineering manager do in the first month that would genuinely help your team?" *Why it lands:* the reciprocity question, for a peer panel. It shows you are asking how to contribute.
5. "Which parts of the device stack do the two squads own, and which do they depend on?" *Why it lands:* it grounds the scope question with the people who know it.

---

## Round 3: VP Engineering, 30 min, "values and leadership philosophy"

The recruiter's own words name a values round. That makes it values-style. No published company values were in hand, so there is no values cheat sheet. VAL items rest on the recruiter's words and on your quoted sentences. Where your sentences carry no story, the item gives a selection scaffold with an honest branch.

**Persona weights**

| Persona | Questions | Reasoning |
|---|---|---|
| Values / Behavioral | 3 (V1 to V3) | The recruiter named this round a values round. |
| Pressure | 2 (V4, V5) | A VP tests altitude and composure, and the scope gap is most likely to surface here. |
| Conversational | 1 (V6) | A short opener is still scored. Give a rehearsed 90-second arc. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Story-mapped on your quoted sentence: the pressure, the quarter, the result. Answer slot: if the truth you told was yours to tell, say what it was and to whom; if you did not deliver an unwelcome message, say so plainly and give the nearest case your material carries. | The stake in your quote is roadmap pressure, so it is the nearest story. The unpopular-truth framing is not in your message, so it is a slot. |
| V2 | "Tell me about a time you put someone's growth ahead of a delivery date." | VAL | [generic] | Selection scaffold: pick a time you chose someone's development over a date. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | Growth is F4's discovery gap, so no quote carries a story. The honest branch is required. |
| V3 | "How do you decide who gets hired into a team you'll be less close to than you are now?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Story-mapped on the loop: name it and its scale, in your words. Answer slot: if the decision on a hire was yours, say how you made it; if it was not, say so plainly. | Hiring is F3's evidence. The question asks about distance, which the role implies. |
| V4 | "Eleven engineers is nearly twice the six you've led. What makes you think you can run it?" | Pressure | [grounded] "9 years engineering, 3 as a team lead of 6" (your message); "own delivery, hiring and growth for 11 engineers" (role description) | Hold your six-person record as the evidence. Concede specifically what you have not done at eleven, including growth. Hold through two follow-ups. | A scope challenge drawn from both quotes. This is where F4 surfaces. |
| V5 | "You've never managed managers. Why should we hire you?" | Pressure | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Plain acknowledgment: "I've never managed managers." Then hold on the six-person scope and what you have delivered. Do not argue that managing managers is not needed. | The question presupposes your stated negative, so it is allowed. The role does not state managing managers, so the question does not assert it. |
| V6 | "Walk me through how you got here, in a couple of minutes." | VAL | [grounded] "9 years engineering, 3 as a team lead of 6" and "currently at a payments company" (your message) | Pre-scripted 90-second arc: your years, the six-person team, the payments company, and the reliability quarter. Use only these facts. | A conversational opener is scored. Rehearse the arc so it lands in ninety seconds. |

**Reverse questions**

1. "How does leadership here decide between a delivery commitment and reliability work?" *Why it lands:* it asks the VP's philosophy on the exact tension in your strongest story.
2. "What did a leader here do most recently that you would hold up as the standard?" *Why it lands:* it asks for values in practice, not in a slogan.
3. "What would you expect a new engineering manager to say no to in the first year?" *Why it lands:* it tests the leadership philosophy on boundaries.
4. "How do you know when a leadership approach is working across a team of eleven?" *Why it lands:* it ties the question to the scope the role describes.
5. "Which principle here would you expect a new leader to test first, and how?" *Why it lands:* it shows you intend to learn the values by use.

---

## Upgrade menu

- **Full job posting text** → the requirement list becomes complete, and the JD-tagged items rest on the full wording instead of the role summary.
- **Your CV** → each story gets its own quoted sentence, and F1, F3 and F6 can be checked against inspectable detail.
- **The Director's name** → the interviewer read, a tailored reverse question, and persona weights from their public footprint.
- **Panel member names** → per-member persona assignments, replacing the blended weights.
- **The recruiter's email** → the round formats, any pre-declared deliverables, and the VP round's values sources.
- **WebSearch permission granted** → an L1 run on Larkfield's values, loop structure and strategy. Those would unlock a values cheat sheet, a grounding brief, and grounded CO and CASE items.
- **Location, on-site, travel or authorization terms** → gate rows, surfaced prominently in the fit snapshot.
- **Whether the squads have leads who would report to you** → a managing-managers row, replacing the current silence on it.
- **How the 60% was counted** → defend-the-number answers you can repeat under a second question, in place of the current slots.
- **A deeper research pass (L2)** → up to 6 more searches and 2 more fetches, several more minutes. Available once, on consent.
- **A `tuesday-dossier.md` record of the gaps this prep exposed** → carried into later sessions.
