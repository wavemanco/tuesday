Your prep pack is saved as /var/tmp/tuesday-measure/1a4/runs/haiku/tuesday/part-2/rooms/case-7-denied-6cfe2416/saltmarsh-games_live-operations-producer_interview_pack.md. I built it for a hiring-manager round, since Tobias leads the function you'd join. Web search was refused in this session, so the pack has no Saltmarsh values, no interview-loop structure, and nothing on Tobias beyond his title.

**What to prep, in order:**
1. **"Never led a team."** This is the most predictable objection, and you named the gap yourself. The rehearsal is a plain "I haven't led a team," then a return to the calendar and checklist you actually ran (A2, with D1 as the pressure version).
2. **Scope and ownership of the calendar.** Your sentence says one title for two years. The posting asks for two titles. Say what you ran, and don't stretch it (A1, A5, F1).
3. **Post-event review and KPIs.** Your material shows you presented retention numbers, not that you owned a review or set the KPIs. If you did either, say what you decided. If not, say so and say what you'd put in a review first (C2, C3, F3).
4. **Coordination with design, art, engineering and community.** Nothing in your material covers this. Prepare a clear answer for both "I did this" and "I didn't" (A3, F1).

Two of your gaps sit outside the posting: no team leadership and no in-app purchase experience. Give both as plain acknowledgments. Don't offer experience you don't have.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

Say the word and I'll play the Skeptic on A2, the question the pack names as your highest-ROI prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, and is Friday a hiring-manager conversation? Or is there a panel, or a take-home or presentation I should build for? The answer reweights the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Round: 60 minutes, Friday. Relationship assumed to be hiring manager, because they lead the function the role sits in. Not yet confirmed (see the question in the message that delivers this file).

**Built from:** the job description and your background as you gave them. No web research ran (see Sources).

## How to use

- **Personas** describe how a question will arrive. **Types** describe what is being scored: EXP (your experience, tested for attribution), JD (the posting's own requirement), CO (company knowledge), CASE (a live problem), VAL (values; not used here, because no values round was detected).
- Guidance is scaffolding for a spoken answer, not a script. Say it in your own words, and stop where your material stops.

## Fit snapshot

Each JD line is quoted from the posting. Each evidence cell holds only your own sentences, quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your sentence covers one title, not two, and says nothing about live events beyond content drops. Words at its own scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you have planned across more than one title, say which and how; if you have not, say so and say how you would take on the second. |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material is silent on how an update got through design, art, engineering or community. Answer slot: name the handoffs you were part of with each of those teams; if you were part of none, say so plainly and say how you would run the first update's handoffs. |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Presenting numbers is adjacent to owning a review and the KPIs behind it; the material does not show the review. Words at scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you set which KPIs were reported, or ran a review after an event, say what you set and decided; if you did neither, say so and say what you would put in a post-event review first. |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote reaches the checklist and QA in other terms; it does not say who runs sign-off. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you were part of how a release is signed off today, say what your part was; if not, say so and stay with the checklist you wrote. |
| F5 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap: the quote reaches the requirement in role terms. Expect a probe on your share of it; that is A5's job. |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | presentation | The quote names retention numbers in your own terms, so it reaches the requirement. It does not say how the numbers were built. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which retention cut went to the studio head, say so; if the definition came from elsewhere, say that. |
| F7 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | presentation | Four years and the studio type are in your words. Your sentence does not say live-service. The nearest live-service work in your material is the content-drop calendar in F5; say the two together, and keep your title as you held it. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The checklist is the one written artifact your material names, and it is in use. The material does not show other writing. Words: "I wrote the release checklist our QA team still uses." Answer slot: if a reader relied on another piece of your writing, name it; if not, say so. |

**Two of your own gaps sit outside the posting's lines.** "Never led a team" and "never worked on a game with in-app purchases" are your sentences, and no JD line asks for either. The posting asks you to coordinate and to manage a checklist; it does not name leading a team. Those two negatives feed the Skeptic and Pressure banks (A2, A4, D1), and nothing is claimed in their place.

## Persona table

| Persona | How it shows up in this round | Likelihood and weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Tests the one-title scope, the lack of a post-event review, and the team-leadership negative | High, 5 questions | A hiring-manager round buys capability and derisks gaps. F1, F3, F2 and your two negatives are the material | Rehearse the most predictable objection until it is dull; plain acknowledgment; bridge only from what you actually said |
| Case / Strategist | A live two-title plan, and a retention dip to diagnose | High, 4 questions | Hiring-manager priors expect live problems on the role's own calendar | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Data-Driven Prober | How the retention numbers were counted; the assumption you would defend least | Medium, 3 questions | Retention metrics is a posting line (F6), and "presented" invites a count question | Say plainly what you know about how numbers were counted; name the weakest assumption before they do |
| Pressure / Stress | Whether the team-leadership gap is a dealbreaker; how much of the retention result was yours | Low, 2 questions | Not a hiring-manager prior, but one exchange in 60 minutes can turn on it | Hold through two follow-ups; concede a specific uncertainty, not the core |
| Conversational / Rapport | An opening "walk me through" and a casual question about mobile games | Low, 2 questions | Friendly register, still scored; most rounds open this way | Keep a 90-second arc ready; treat casual questions as scored |
| Peer Evaluator | Where design and art meet your calendar, and what happens on disagreement | Low, 2 questions | The coordination line reaches peers. A hiring manager tests seams less often | Propose seam principles, not invented seams; reciprocity |
| Values / Behavioral | Not detected | None, 0 questions | No loop source establishes the loop, and the generic fallback reads no values round | Ask the recruiter for the round format (upgrade menu) |

## Question banks

Depth follows persona weight. Provenance lists every sentence the guidance rests on.

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Three years of producing live-service work is the line in the posting. How do your four years at a puzzle-game studio count toward it?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Say the four years, the studio type and your title, then the calendar in its own words. Count the two years of content drops, and do not call the work live-service unless you say what the drops were. Then let them judge the fit. | The experience line is the first thing a skeptic tests. F7 is the row, and the bridge stays at its scope |
| A2 | "You have never led a team. What would make you the right person for this role anyway?" | JD | [grounded] "Never led a team" | Plain acknowledgment: "I haven't led a team." Then return to the work you did: the calendar you ran and the checklist you wrote. Answer slot: if you have coordinated people you did not manage, say what you did and whose decisions you moved; if you have not, say so and say how you would set up the first update's coordination with no team under you. | This is the highest-ROI prep in the pack. You named the gap yourself, and the posting's coordination line makes the probe predictable. F2 is the row the answer slot rests on |
| A3 | "The role coordinates design, art, engineering and community on every update. What have you run with those four teams?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" | Answer slot, both branches: if you worked with one of those teams on an update, name it and what you did; if you did not, say so plainly and describe how you would run the first update's handoffs. | F2 has no quote. The question's premise comes from the posting, not your material, so the second branch must allow that you did not do this |
| A4 | "If one of the titles had in-app purchases, what would change in how you plan an update?" | JD | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say what you would check first: what the title's team already measures about purchases, and whether an update changes what players buy before you move the calendar. | The question is conditional, so it presumes nothing about the company. The negative is yours, and you should give it plainly |
| A5 | "Which parts of that calendar did you own, and which did someone else set?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | For each part of the calendar, say whether you decided it, ran it, or received it. If someone else set a part, say so. Answer slot: if any part was yours to set, say which and how you decided; if none was, say so plainly and describe how the calendar ran. | This is the attribution probe that F1 and F5 invite. The honest answer is the one that splits the work |

### B. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you would plan the next two months of live events for a title that is already in the market. What do you need to know first?" | CASE | [generic] | Clarify first: the title's current retention and what is failing, what content is already in production, the capacity of the four teams, and any events already committed. Then objective, player segmentation, approach, metrics, risks. Speak it in 90 seconds. | A live problem from the calendar work. It asks about no past, so it presumes nothing about you |
| B2 | "Retention dropped in the week after a content update. Diagnose it." | CASE | [generic] | Clarify the window and the cohorts; ask whether the update changed everyone or one segment. Check what shipped against what was planned. Separate the update's effect from the calendar's and from outside effects. Name the metric you would check first. | Retention is a posting line, and a live dip is how a Case interviewer tests it |
| B3 | "You get two titles and one update slot a month between them. How do you split it?" | CASE | [grounded] "Plan and run the live-events calendar for two of our mobile titles" | Propose a rule and its trade-off: which title's retention or content is weaker, what each title owes its players, content readiness, and team capacity. Say what you would give up. | The two-title scope is the posting's own. The split is a generic approach, not a claim about your past |
| B4 | "What would you do in your first 30 days in this role?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" | Plan, not history: learn both calendars, meet the owners of design, art, engineering and community, walk the release checklist with QA, and read any post-event reviews that exist before writing one. | A plan is not a claim about your past, so the guidance needs no quote beyond the posting's line |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you know: the definition, the window, the population. If you do not know how they were counted, say so plainly. Answer slot: if you chose the cut that went to the studio head, say so; if the definition came from elsewhere, say that. | F6. No figure was given, so there is no defend-the-number slot; the probe is on the count itself |
| C2 | "Which assumption behind those numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Name the weakest assumption you know of before they do. If you know of none, say you do not know how the figure was counted. | The weakest-assumption move converts a gotcha into a credibility gain |
| C3 | "How would you measure whether a live event worked?" | JD | [grounded] "own the post-event review and the KPIs it reports" | Plan: name the event's goal, the metric that should move, the baseline you would compare against, the window, and what the post-event review would record. | The posting's KPI line. The answer is a method, so it needs no past claim |

### D. Pressure / Stress (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we give this to someone who has never led a team?" | JD | [grounded] "Never led a team" | Hold: "I haven't led a team." Then return to the calendar and the checklist. Hold through two follow-ups. Concede a specific uncertainty if pressed: say what you do not yet know about running people, and not the core of your fit. | Pressure on the same gap as A2, with less time to set it up. Hold, then concede the exact thing you do not know |
| D2 | "That retention result: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold the sentence: you presented the numbers. Answer slot: if you shaped what they showed, say how; if you only presented them, say so. Concede the part that was not yours, specifically, and do not fold on the presenting. | A pressure probe on attribution, the same test as A5 under time pressure |

### E. Conversational / Rapport (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | A 90-second arc, in this order: the studio and your title; the calendar, in its own words; the checklist; the monthly retention presentations; why this role. | An opener that is scored. It covers F5, F4 and F7 in one pass |
| E2 | "What are you playing in mobile live games these days?" | CO | [generic] | Name one game you actually play, and one thing its update cadence does well or badly. Keep to what you play. | Casual register, scored. No research ran, so this bank carries no company claim |

### F. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our design and art teams sit side by side with you. Where is the seam between their work and the calendar, and what happens when you disagree?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" | Propose a seam principle, such as content is locked before the checklist starts, and say who settles a disagreement. Answer slot: if you have disagreed with a team you did not manage, say what happened and how it ended; if not, say so and say how you would handle it. | F2 has no quote, so the disagreement branch must allow that none happened |
| F2 | "What would you need from QA to keep the release checklist current?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Name specific inputs: the sign-off steps, the release-day contacts, what QA sees first. Reciprocity: say what the checklist already gives QA. | F4 as a question. It tests whether you know the checklist is a shared tool |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two mobile titles | A1, A5, B3, B4 |
| Coordinate design, art, engineering and community on each update | A3, F1 |
| Own the post-event review and the KPIs it reports | C2, C3 |
| Manage the release checklist with QA | E1, F2 |
| 3+ years producing live-service games or apps | A1 |
| Experience running a content calendar | A5, E1 |
| Comfortable with player-retention metrics | C1, C2, D2, B2 |
| Clear written communication | none, and why: no writing exercise was declared, and E1 touches only the checklist. Add one if the recruiter names it |
| Your gap: team leadership (not a posting line) | A2, D1 |
| Your gap: in-app purchases (not a posting line) | A4 |

## Reverse questions

Each is one you can ask at the end. Why it lands follows each.

1. "What does a good post-event review look like here, and who writes it?" Why it lands: it tests the ownership reading in F3, and shows you intend to own the review.
2. "Which two titles does this role cover, and how far apart are their calendars?" Why it lands: it sizes the scope gap in F1 on their terms.
3. "How does a release get signed off with QA today?" Why it lands: it shows you know the checklist sits inside a larger process (F4).
4. "Which of the two titles' retention is the bigger worry this quarter?" Why it lands: retention is a stated requirement, and the question shows you read it as a live priority.
5. "What would you need to see in the first 90 days for this to be a good hire?" Why it lands: it draws out the manager's expectations, which is what a hiring-manager round is for.
6. "Which of design, art, engineering or community is hardest to get an update through right now?" Why it lands: it maps the coordination line in the posting onto their actual friction.

No reverse question ties to Tobias's own career path, because there is no profile for them yet (see the upgrade menu).

## Prohibited claims

Built from the fit snapshot before the banks were written. Each entry names its basis and the honest form that replaces it.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar for two titles | Inflated form of F1 and F5 (scope and ownership) | F1's quote at its own scope. The limit is this pack's observation: the material says one title, not two |
| Owned retention analysis | Inflated form of F6 | "I presented the monthly retention numbers to the studio head." The limit: presenting, not analysing |
| Set the post-event KPIs and owned the review | Inflated form of F3 | F3's quote at its own scope. The limit: the material does not show a review |
| Coordinated design, art, engineering and community on each update | Inflated form of F2 | No claim. A3's answer slot asks what you ran |
| Led a team | Sourced negative: "Never led a team" | Plain acknowledgment: "I haven't led a team." |
| Producer on live-service titles | Inflated form of F7 | "4 years as an associate producer at a puzzle-game studio." The limit: the material does not say live-service |
| Signed off every release through QA | Inflated form of F4 | "I wrote the release checklist our QA team still uses." The limit: writing it, not running sign-off |
| Experience with in-app purchases | Sourced negative: "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |

## Sources

- **Provided documents:** the job description and your background, both in your message. No CV was supplied.
- **Searches sent, both refused** (search permission was not granted): "Saltmarsh Games mobile studio values live operations" and "Tobias Wrenfield Head of Live Operations Saltmarsh Games".
- **Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, if a values-style round is confirmed. Query refused, listed above |
| 2. Saltmarsh interview process, live operations | unavailable | Loop structure and persona weights. No call was sent after the refusals; this host offers no search |
| 3. Saltmarsh strategy and recent news | unavailable | The company-knowledge bank; E2 is generic for this reason. No call was sent |
| 4. Tobias Wrenfield, Saltmarsh | unavailable | Interviewer read, persona weights from his own framing, and reverse questions tied to his path. Query refused, listed above |
| 5. Representative Live Operations Producer JD | skipped | The job description you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Web search permission, or Saltmarsh's values or operating-principles page pasted** → the values cheat sheet, if the round turns out to be values-style, and values-named questions
- **Tobias's public talks, posts or a profile, pasted** → an interviewer read, persona weights from his own framing, and reverse questions tied to his path
- **The recruiter's note on the round format, and any take-home or presentation** → whether this is a loop, and coverage of any deliverable
- **Your release checklist, with names removed** → F4, F8 and E1 become inspectable; confidence may move from medium
- **One calendar you ran, as a sanitised sheet** → F1, F5 and A5 get an inspectable artifact to rest on
- **Any post-event review you wrote** → F3 moves from transferability toward presentation
