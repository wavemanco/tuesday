Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-2-rooms-case-1-denied-651e493a/077ad893-55de-4975-baae-2a8fcf0d6ce5/scratchpad/northwind-data_senior-gtm-strategy-lead_interview_pack.md. I built it for a peer conversation with Dan, since your brief says he is a peer on the same VP.

Web search was refused in this session, so the company facts (priorities, Compass, the bundling threat) are your research note, unchecked. The pack covers 20 questions across seven personas, weighted toward a Data-Driven Prober, because Dan's self-description is "relentlessly data-driven."

The most important prep is the partner-motion gap (rows D2 and G1). The JD requires partner-motion design experience, and your material only shows a partner-level revenue model used in carrier negotiations. D2 is the one to rehearse hardest.

Two things to check before you use it:
- The evidence quotes come from your summary of Priya, not her own sentences. Her CV in her own words would firm them up.
- I left out the values cheat sheet and the delivery-coaching section, since no values were supplied and no assessment was provided.

Offers:
- I can play Dan as the Prober on A1–A2 and score her answer against that question's guidance.
- I can save a tuesday-dossier.md recording the gaps this prep exposed.
- If you'd like a Word version of the pack, say so.

Questions:
1. Has Priya designed or run any partner program, channel terms, co-sell motion or partner incentive? Or is the carrier negotiation model the closest thing? This decides how D1, D2 and G1 are written.
2. Does the recruiter or the invite name focus areas or a deliverable for the hour, or is it an open conversation?
3. Where is the role based, and does the posting or recruiter state an in-office pattern? Your material says nothing on this, and an office requirement would be a hard gate.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Northwind Data, Senior GTM Strategy Lead (Emerging Products): interview prep pack

**Interviewer:** Dan Kovac, Director of Sales Strategy. Relationship: peer, same VP.
**Round:** one 60-minute conversation.
**Built on:** your brief only: JD highlights, Priya's background as you summarized it, Dan's profile as you summarized it, and your research note. No CV, full JD text or dossier was supplied.
**Assumption:** web search was refused in this session, so company facts come from your research note and are unchecked.

## How to use

- **Personas** describe how a question arrives. **Types** describe what it scores.
- Type key: **VAL** behavioral/values alignment · **EXP** deep-dive into work experience · **JD** role requirement · **CO** company strategy · **CASE** live problem.
- Guidance is scaffolding for a 90–120 second spoken answer, not a script.
- "Answer slot" is an instruction for the interview. It is not a question for you to answer here.

## 1. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | transferability | Your material shows a product change with a credited uplift, not a go-to-market plan for a new line. Keep the words at that scope: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: if you set any part of how that change reached customers, say which part and how you decided; if none of it was yours to set, say so and describe how you would build GTM for a new line. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | discovery | The material does not show whether the model surfaced uncaptured revenue at any stage. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if it showed a stage where revenue was being left, say which stage and how you found it; if not, say so and say how you would find whitespace across the four stages. |
| F3 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | Adjacent work: the model was built for negotiations with partners, which is not the same as designing how partners are engaged. Keep the words at the quote's scope: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you designed any part of how partners were engaged, incentivized or onboarded, say which and how you decided; if the carrier model is the closest thing, say so and say how you would approach a partner motion for these lines. |
| F4 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (coach's notes) | medium | [grounded] | presentation | The quote already reaches the tools the JD names, but it does not show analysis run alone. Words: "I'm skilled in SQL and Tableau." Expect a probe for one analysis you ran yourself. If you have one you can walk through end to end, name it in your own words; if not, say how you would build one. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | none | Reaches the requirement in role terms. Words: "I set annual volume targets with cross-org consensus." Expect a probe on who disagreed and whose view prevailed; the quote says consensus, not who led it. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (coach's notes) | medium | [grounded] | transferability | Daily use of AI tools is adjacent to building an AI product. Words: "I use AI tools daily." Answer slot: if you have built or shipped anything that uses AI, name it and say what you did; if not, say how daily use would shape your approach to a copilot launch. |
| F7 | Sales-strategy scope: Dan's title and the role's sales-strategy work (not a JD highlight) | "No classic sales-ops or quota-setting experience" (coach's notes) | none | [inferred] | discovery | Your note records no classic sales-ops or quota-setting work. That is your note, not Priya's words, so the pack asserts no negative for her. An interviewer may test this through targets. Answer slot: say what you have done with targets a team had to hit, in your own words. |

No gate row: your material states no location, work-authorization, travel or office-pattern requirement. Q3 asks about it.

## 2. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM for two new product lines | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for her: the material shows a change credited with an uplift, not a GTM plan for a line. A1 and A2 stay on the figure. |
| Designed the partner motion, or owns partner programs | Inflated form of F3 | F3's carrier-model quote at its own scope. D2's slot asks only what she designed. |
| Ran independent end-to-end analysis in SQL and Tableau | Inflated form of F4 | F4's quote at its own scope. A3's slot asks for one analysis only if she has one. |
| Drove the ~$400M ARR | Inflated form of F1's figure ("credited with" becomes "drove") | F1's quote at its own scope. G2 holds the attribution. |
| Set the annual volume targets alone | Inflated form of F5 ("with cross-org consensus" becomes sole ownership) | F5's quote as written. D3 keeps the consensus in the sentence. |
| Has quota-setting or sales-ops experience, or has none | Negative from your note (F7), not from Priya | No plain acknowledgment is written, because the negative is not hers. Her words are an answer slot only. |

## 3. Reading the interviewer

- **Career pattern:** pricing and monetization roles, one early-stage startup chapter. Source: your profile summary. Public footprint was not checked (search refused).
- **Self-description:** "relentlessly data-driven."
- **Implications:**
  - Expect every number to be probed to its assumptions. Prober weight goes up.
  - Case questions will come in pricing, packaging and unit-economics terms. The bundling threat is his native ground.
  - The startup chapter means scrappiness and big-company pace may be tested. A builder story lands, but only one she can show.
- **Mirror opportunity:** his pricing and monetization path and her partner-level revenue model share a monetization thread. Quote: "built a partner-level revenue model used in carrier negotiations" (F3). Offer it as a shared professional path, not a shared identity.
- **No mirror on the startup chapter:** no candidate sentence carries a startup side.

## 4. Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Data-Driven Prober | Asks for denominators and assumptions on every number | High. Peer relationship prior, raised by his "relentlessly data-driven" profile | Name the weakest assumption before he does; say plainly what you do not know about how a figure was counted | 5 (A) |
| Peer Evaluator | Seam questions, "what would you need from me," disagreement | High. Peer relationship prior | Reciprocity framing; propose seam principles rather than pretending to know their rules | 3 (B) |
| Case/Strategist | Live pricing and expansion problems from the research note | Medium-high. Pricing spine tilts case toward pricing; the note supplies live problems | Clarify, then structure; think aloud; challenge one premise | 3 (C) |
| Skeptic | Probes the required partner-motion line and the sales-scope gap | Medium. Driven by F3 and F7, the thinnest rows | Rehearse the predictable objection until it is plain; hold, then concede exactly | 3 (D) |
| Values / Behavioral | Influence and conflict scenarios from the JD's influence line | Low-medium. No values round detected; the JD line raises the theme | Selection scaffold ending in the honest branch | 2 (H) |
| Conversational | Casual "journey" opener; AI plus asked lightly | Medium. Peer chats open casually, and casual questions are still scored | Pre-scripted 90-second arc; treat casual questions on hot JD topics as scored | 2 (E) |
| Pressure | Attribution challenge; "why you" | Low-medium. Peer register, but the required line may get pushed | Hold the quoted position through two follow-ups; concede specifically | 2 (G) |

Total: 20 questions, inside the 18–26 range. The loop is established by your brief (one conversation with a peer), so no archetype fallback applies.

## 5. Question banks

Types are the scored behavior. Provenance comes first and quotes every sentence the guidance relies on.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Defend-the-number. Say how the figure was counted, in your own words, and only what you know. Answer slot: if you do not know how it was counted, say so plainly. | F1's figure. Premised on the quote's "credited with"; the method is asked, not supplied. |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Weakest-assumption move: name it before he does, in your words. If you cannot name one, say you cannot say how it was counted, then say what you would check. Never supply an assumption. | Second defend-the-number slot for the same figure. |
| A3 | "Tell me about a time you used SQL or Tableau to reach a call someone acted on. What did you pull, and what did you leave out?" | JD | [grounded] "skilled in SQL/Tableau" (coach's notes) | Open prompt; no quoted sentence carries a story, so this is a selection scaffold. Pick one time the tools drove a decision; give the source, the cut and what you excluded. Honest branch: if no such time comes to mind, say so, then give the nearest analysis you can walk through, or how you would build one. | F4's probe. Theme from the JD's SQL/Tableau line. |
| A4 | "Which assumption in your partner-level revenue model would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Weakest-assumption move on the model. Say which parts you built. Answer slot: if you did not set the assumptions, say whose they were and which part you did build. | Premised on the quote's "built." F2 and F3 both lean on this model, so it is the deepest model probe. |
| A5 | "How would you know a whitespace number was real before a launch decision rests on it?" | JD | [generic] | Method, not past. Define whitespace for one land/adopt/expand/renew stage, name the denominator, name one sanity check and what would falsify the number. Make no claim about your work. | F2's requirement asked as method, so it presumes nothing about her history. |

### B. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side on pricing. Where's the seam between your new lines and pricing, and what happens when we disagree?" | JD | [generic] | Propose seam principles, such as who owns list price and who owns exceptions. Do not pretend to know the current rules. Disagreement: if you have a time you disagreed with a peer team and held a view, name it and the outcome; if not, say so and give the principle you would use. | Peer seam probe. Cross-functional line from the JD. |
| B2 | "What would you need from pricing in the first 90 days to make the new lines work?" | JD | [generic] | Name two or three concrete inputs (price-point data, packaging rules, deal-desk policy) and what you would bring back in return. Reciprocity framing. | Peer collaboration test on the GTM line. |
| B3 | "Partner-led and direct-led pipeline both matter to us. How would you split them for the new lines, and what data would change your mind?" | JD | [generic] | State a splitting principle, for example partner-led where a partner already has reach and direct where contract terms matter, and the data that would overturn it. Do not claim a split you have run. | Partner-motion requirement asked as design. Overlaps D1. |

### C. Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor bundles a similar capability into its suite at no extra price. How do you respond for Compass?" | CO | [grounded] "main threat is bundling by a much larger platform vendor" (your research note, unchecked) | Clarify first: which customers the bundle reaches and what Compass does that the bundle does not. Objective. Segment by enterprise and partner-led. Approach: packaging, a price floor, land versus expand. Metrics and risks. Think aloud. | Pricing-native case for Dan. The CO bank rests on your note, which is unverified. |
| C2 | "Enterprise expansion is a stated priority. You have account revenue and no seat data. Where do you find expansion whitespace first?" | CASE | [grounded] "enterprise expansion" (your research note, unchecked) | Clarify the account definition. Segment by contract stage. Size the gap against a comparable account. Say what the missing seat data does to the estimate. | Live problem; asks nothing about her past. |
| C3 | "Profitability is the stated goal. Where would you look in a new line's GTM for it, and what would you give up?" | CO | [grounded] "reaching profitability" (your research note, unchecked) | Pick one lever and state its trade-off. Say your hypothesis first and what you would verify. Do not claim knowledge of their numbers. | Tests altitude, using a stated priority. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" (JD highlights) | Name partner-motion design plainly as the weakest part. Bridge to the carrier model at its own scope. Then the 90-day ramp. Answer slot: if you designed part of a partner motion, say which and how you decided; if not, say so. | The predictable skeptic stem. The required line is the thin spot. |
| D2 | "Partner-motion design is required here. Which partner motion have you designed, and what did you own in it?" | JD | [grounded] "partner-motion design experience required" (JD highlights); [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | **Highest-ROI prep in this pack.** Hold through two follow-ups on the model: "I built a partner-level revenue model used in carrier negotiations." On the second follow-up, concede in your own words what you have not designed. Never claim a partner motion. Answer slot: if you designed one, say what you owned; if not, say that plainly, then give your ramp plan. | The required line is aimed where the material is thinnest. The premise may be false, so the second branch is open. |
| D3 | "You set annual volume targets. How did those get agreed, and who pushed back?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Story-mapped on F5: the targets and the cross-org consensus are the beats the quote states. Name who pushed back only if you know. Answer slot: if the targets were not yours to set, say whose they were and what you did do. If asked about quotas, describe what you have done with targets, in your own words. | F5 and F7 together: "why should we trust your targets." |

### H. Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you got a team to change a plan it had already agreed to." | JD | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Selection scaffold: pick a time you moved a group off a settled plan. Name the stake, whom you had to persuade and what changed. Honest branch: if no such time comes to mind, say so plainly, then describe the nearest consensus you did reach, at the quote's scope. | The JD's influence line. No values are published and no values round is detected, so this carries JD, not VAL. |
| H2 | "When two product teams want different GTM for the same launch, what do you do?" | JD | [generic] | Propose a decision rule: one owner, a stated tie-break, a data check. Say what you would escalate and when. Make no claim about your past. | Cross-functional conflict as a pattern. Generic because it is not about this employer. |

### E. Conversational / Rapport Builder (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | Pre-scripted 90-second arc using only these beats: two years of strategy consulting at a top firm, nine at a large consumer-tech company in product strategy and ops, the partner-level model, the store-surface change, and why this role, in her own words. | Casual register is still scored. The arc uses only quoted beats. |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Name the tools and one concrete task. Say how that informs a copilot launch. Do not describe building AI features. | The "AI experience a plus" line, asked casually. |

### G. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you, against someone who has already run partner GTM?" | JD | [grounded] "partner-motion design experience required" (JD highlights) | Hold: the carrier model is the partner-facing work she brings, and she would build the partner motion from it with a plan. Hold through two follow-ups. Concede exactly what she has not done. | Pressure stem on F3. The held position uses only quoted material. |
| G2 | "That ~$400M figure: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Hold-then-concede on attribution. Hold: "I proposed the change; the uplift was credited to it." Concede specifically: say what share she can defend and what she cannot. Never fold to the whole figure. | Attribution pressure on the headline figure. |

### Type index

| Type | Question IDs | Count |
|---|---|---|
| VAL | none. No published values are in hand and no values round is detected | 0 |
| EXP | A1, A2, A4, D3, E1, G2 | 6 |
| JD | A3, A5, B1, B2, B3, D1, D2, E2, G1, H1, H2 | 11 |
| CO | C1, C3 | 2 |
| CASE | C2 | 1 |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | F1: A1, A2, C1, H2 |
| identify whitespace across land/adopt/expand/renew | F2: A4, A5, C2 |
| run independent analysis in SQL and Tableau | F4: A3 |
| partner-motion design experience required | F3: D1, D2, G1, B3 |
| strong cross-functional influence | F5: B1, D3, H1 |
| AI experience a plus | F6: E2 |
| Sales-strategy scope (not a JD line) | F7: D3, A3 |

## 6. Reverse questions

| # | Question for Dan | Why it lands |
|---|---|---|
| R1 | "Which of the three priorities, enterprise expansion, Compass or profitability, matters most for this role's first six months?" | Forces a sequencing answer and shows you read the stated priorities. |
| R2 | "Where is partner-led versus direct-led pipeline contested today?" | Probes the partner-motion seam and shows you are thinking about his side. |
| R3 | "How did your pricing and monetization background change how you read sales strategy?" | Ties to his own path and turns the interview into a peer conversation. |
| R4 | "What could a new person do in their first month that would genuinely help your team?" | Peer reciprocity. Signals contribution, not just need. |
| R5 | "What does a good first 90 days look like on Compass?" | Pins the AI priority. Use the name as your research note gives it, and check it first. |

## 7. Sources

- **Provided documents:** your brief (JD highlights, not full JD text; Priya's background as you summarized it; Dan's profile as you summarized it; your research note, unchecked here).
- **Dossier:** none present.
- **Research tier:** L1 — searches 4 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Would have set a values cheat sheet. No values round is detected, so it would only have themed VAL questions. Search refused. |
| 2. Interview process, senior GTM | unavailable | Loop structure. Your brief names one conversation with a peer, which establishes the session, so the loop moves nothing here. Search refused. |
| 3. Strategy and recent news | unavailable | Would have checked your research note for C1–C3. Those rest on the note, unverified. Search refused. |
| 4. Dan Kovac and Northwind | unavailable | Would have moved the interviewer read and R3. Search refused. |
| 5. Representative JD | skipped | The JD highlights fix the fit snapshot's requirement lines. |

Queries sent, all refused: "Northwind Data company values principles"; "Northwind Data interview process Senior GTM strategy"; "Northwind Data Compass AI copilot enterprise expansion profitability"; "Dan Kovac Director of Sales Strategy Northwind Data".

## Upgrade menu

- Search permission → targets 1–4 run: values verify the cheat sheet, the loop and Dan's public footprint are checked, and your research note is tested against C1–C3.
- Priya's CV, in her own words → the evidence quotes move from your summary to her sentences, and confidence can rise where an artifact is named.
- Full JD text → the six highlight rows quote the whole posting, and the coverage table can reach mid-list items.
- A SQL or Tableau piece she can walk through → F4 moves from a probe to a story she can rehearse.
- Dan's talks or posts → recurring themes become questions in the Case and Conversational banks.
- Recruiter note on focus areas or a deliverable → the hour's shape is reweighted, and any deliverable gets its own build section.
- A tuesday-dossier.md would add evidence-graded objections and a prohibited-claims list. None exists yet.
