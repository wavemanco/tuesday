Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-2-rooms-case-3-denied-83a7e7f1/c20551b5-a545-437d-9b95-5d627b33f977/scratchpad/stripe_product-operations-manager_interview_pack.md`.

It's a generic pack. I had no job description, no CV, and no Stripe research: every web search was refused by a permission prompt. So the question banks are role-family patterns, not Stripe's own process. I left out the values cheat sheet and the strategy questions rather than guess at Stripe's values or current strategy.

**What's in it:** 20 questions across seven interviewer styles, five reverse questions to ask them, and a sources section showing the refused searches.

**Highest-return prep:** B1, "Which part of this role would you be weakest at on day one?" It's the most likely objection and the hardest to answer cold. Answer by naming the weakest part plainly and giving a ramp plan, without bluffing.

I can run a drill on B1 or any other question, with follow-ups that react to what you say. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

Three things would sharpen this:

1. What is the final round: one session or several, and who are the interviewers? That changes how the questions are weighted.
2. Could you paste the job description and your CV? The worksheet rows would then quote your own evidence, and the answers would be built on it. If you'd rather not, I'll proceed without them.
3. Can you grant web search permission? Then I can check Stripe's published values, the interview process, and recent strategy.

Is the person you're meeting your future manager, or a peer on the team? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe: Product Operations Manager, Final Round: Interview Pack

**Changelog:** first version. Built with no JD, no CV and no research (web search was not permitted), so every row is a worksheet row and every bank question is `[generic]`.

**Round:** final round. How many sessions, and who runs each, is unknown.
**Interviewer:** not known. Persona weights are flat, as the archetype fallback allows.

## 1. How to use + type key

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **Types:** VAL = behavioral/values · EXP = your experience, probed in depth · JD = the role's stated responsibilities · CO = company knowledge · CASE = a live problem from the role.
- Guidance is scaffolding, not a script. Say it in your own words, and only about things you actually did.

## 2. Fit snapshot (worksheet variant)

No CV or JD was supplied, so no evidence is quoted. Requirements are role-family patterns for product operations roles, not Stripe's posting. Every evidence cell is `none given`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Design and run operating cadences (planning, reviews, decision logs) for product teams | none given | none | [generic] | discovery | Answer slot: describe a cadence or decision process you ran, what it was for, and what you would check first. If you did not run one, say so and describe how you would set one up. |
| F2 | Align engineering, product, design and finance on priorities | none given | none | [generic] | discovery | Selection scaffold: pick a time you moved a group with competing priorities to one decision. Name the stake, your part, and where it stayed unresolved if it did. |
| F3 | Use data to inform product and operational decisions | none given | none | [generic] | discovery | Answer slot: name one metric you chose and how it was counted. If you did not count it, say so, and name what you would measure first. |
| F4 | Run launches and rollouts with clear owners and risks | none given | none | [generic] | discovery | Selection scaffold: pick a launch or rollout you were close to. Name what went wrong or nearly did, and what you were personally responsible for. |
| F5 | Trade off competing requests and say no | none given | none | [generic] | discovery | Selection scaffold: pick a request you declined or deferred. Say what the trade-off was and who you had to tell. |

**Gate rows:** none. No JD was supplied, so no eligibility or location terms are known. Ask your recruiter for them.

## 3. Prohibited list

No quoted claims exist yet, so no inflated-form entries can be built. The local rules are:

| Not coached | Basis | Honest form |
|---|---|---|
| Any metric, team size, outcome or title you did not personally own | Truthfulness core: no invented figures or credentials | Say what you did and what you did not own, in your own words |
| A process, cadence or decision as yours when it was a team's or someone else's | Attribution rule: "what was actually you" | Name your part; say plainly if the step was not yours |

## 4. Persona table

Flat weights, because the round's sessions and interviewers are unknown and no loop source was read. Depth follows weight.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live ops problem | High: product ops is judged on structure under live problems | Clarify, then structure, then metrics, then risks; think aloud |
| Skeptic | Challenges the lack of direct ops experience | High: the most likely objection is your match to the role's scope | Rehearse one answer until it is steady; calibrate, do not bluff |
| Data-Driven Prober | Asks how a number was counted | Medium: any figure you give will be checked | Know how each figure was counted; name the weakest assumption before they do |
| Values / Behavioral | Stories about candidness and customers | Medium: a final round often includes one, though no values round is confirmed | Use STAR; "we" for context, "I" for your contribution |
| Peer Evaluator | Seams with product and engineering, credit sharing | Medium: ops hires work beside peers | Name what you bring their team, not only what you need |
| Pressure | Time-boxed, interrupted, challenged | Low to medium: depends on the interviewer | Hold a position through two follow-ups; concede specifically |
| Conversational | Friendly opener and "walk me through your journey" | Medium: casual openers are still scored | Prepare a 90-second arc; treat casual questions as scored |

## 5. Question banks

**A. Case / Strategist (4)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our onboarding-to-first-payment rate dropped 15% last month. How would you diagnose it?" | CASE | [generic] | Clarify the metric and the period. Segment by customer type and channel. State two or three hypotheses, the metric for each, and the risks. | A live problem typical of ops roles; carries no claim about you |
| A2 | "Three product teams disagree on priorities. What do you do in your first 30 days?" | CASE | [generic] | Map the decisions and owners first. Then the forum where trade-offs get made, then the review cadence. Say what you would not change yet. | Tests F1 and F2 as a live problem |
| A3 | "What would you put in front of leadership first for a new ops program?" | JD | [generic] | Name one outcome metric and one leading indicator, and say how you would define each. | Tests F3 as a decision, not a record |
| A4 | "Which team metric would you check before proposing any change?" | CASE | [generic] | Name the input metric, its owner, and the failure it would hide. | Probes judgment, not recall |

**B. Skeptic (3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the weakest part plainly, then your ramp plan for it. Do not bluff a competency the interviewer owns. | Highest-ROI prep: this is the most likely objection. Answer slot: if you have done this work, say where; if not, say so and give your ramp plan. |
| B2 | "Why this role, and why now?" | EXP | [generic] | Give your own reasons in two sentences. Keep them the same in every round. | Tests motivation consistency |
| B3 | "Walk me through why you are leaving your current role." | EXP | [generic] | Give your true reason in one sentence, then the forward-looking one. Do not criticize former employers. | Common skeptic probe |

**C. Data-Driven Prober (3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the last number you put on a slide." | EXP | [generic] | Answer slot: the definition, the source, and the period, in your own words. If you did not count it, say so. | Defend-the-number slot |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Answer slot: name the assumption you are least sure of before they do. | Weakest-assumption move |
| C3 | "How would you know, in numbers, after 90 days that your ops process is working?" | JD | [generic] | Name two or three measures and their owners. Say what you would stop measuring. | Tests F3 |

**D. Values / Behavioral (3)**

No Stripe values were read, so these are general behavioral probes, not Stripe's values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time the truth landed. If none comes to mind, say so plainly, then give the nearest case you have and how you handled it. | Open prompt; no quoted material |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time the trade-off was real. Say what the metric was and what you did. | Open prompt |
| D3 | "Tell me about a process you retired or rebuilt because it was not working." | VAL | [generic] | Selection scaffold: pick a process you changed. Say what the evidence was and who agreed. If none, say so and give the nearest case. | Open prompt; tests F1 |

**E. Peer Evaluator (3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where is the seam between operations and the product teams, and what happens when you disagree?" | JD | [generic] | Propose seam principles, such as who decides what and when a disagreement escalates. Do not pretend to know their seam. | Peer probe on turf |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name the principle you use. Give one case only if you lived it. | Credit-sharing probe |
| E3 | "What would you need from my team to make this role succeed?" | JD | [generic] | Name two specific needs and what you would bring their team in return. | Reciprocity framing |

**F. Pressure (2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Answer in 60 seconds: one specific reason you can defend, then a concession. Hold the reason through two follow-ups. | Composure test |
| F2 | "Pick your strongest result. How much of it was actually you?" | EXP | [generic] | Answer slot: say which part was yours and which was the team's, in your own words. | Attribution honesty under pressure |

**G. Conversational (2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey." | EXP | [generic] | A 90-second arc: where you started, what you learned, why this role. | Rapport opener, still scored |
| G2 | "What are you playing with in operations tooling these days?" | JD | [generic] | Name one tool you have used and what you did with it. Do not list tools you have not used. | Casual JD probe |

**Coverage.** No JD was supplied, so the requirement-coverage line cannot be built. Total questions: 20, within the 18–26 range.

## 6. Reverse questions

1. "What does a good first 90 days look like for this role?" *Why it lands:* shows you are planning, not only interviewing.
2. "How do priorities get decided across product and operations today?" *Why it lands:* tests the seam without guessing it.
3. "What would you most like this person to change in the first quarter?" *Why it lands:* surfaces the real problem.
4. "What could a new person do in their first month that would genuinely help your team?" *Why it lands:* reciprocity, since the interviewer is probably a peer.
5. "What does the final round test that earlier rounds did not?" *Why it lands:* asks about the process and shows you prepared.

No interviewer profile exists, so no reverse question ties to their career path.

## 7. Sections dropped

- **Values cheat sheet:** dropped. No Stripe values were read, and no values-style round is confirmed.
- **Grounding brief:** dropped. No strategy research ran.
- **Reading the interviewer:** dropped. No interviewer is named.
- **Graded deliverables:** dropped. None declared.
- **Delivery coaching:** dropped. No assessment provided.
- **Prep triage:** dropped. Prep time not stated.

## 8. Sources

- Provided documents: none beyond your message.
- Searches: three standard web searches were attempted (Stripe values; Stripe final-round interview process; Stripe strategy news). All three were refused by a permission prompt. Nothing was fetched.

**Research tier: L1, searches 3 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet (section 7): every call was refused |
| 2. Stripe interview process | unavailable | Loop structure and persona weights: every call was refused, so the weights are flat |
| 3. Stripe strategy / recent news | unavailable | CO bank: every call was refused, so there are no CO questions |
| 4. Interviewer name | n/a | No name was given |
| 5. Representative JD | unavailable | JD-tagged questions would have rested on a representative posting; none was fetched |

Queries refused: "Stripe company values operating principles"; "Stripe interview process product operations manager final round"; "Stripe strategy news 2026".

## 9. Upgrade menu

- The job description → six `[generic]` rows become `[grounded]`, and the JD-tagged questions get their wording from the posting
- Your CV → the worksheet rows gain evidence quotes, and the answer slots become story maps
- The interviewers' names or roles → persona weights and a tailored reverse question
- The recruiter's note on the final's format → whether it is several sessions, and per-session packs
- Web search permission → Stripe's published values, the interview process, and a strategy sweep
- A `tuesday-dossier.md` from job-underwriter, if you have one → the highest-ROI objection grounded in your evidence
