Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-2-rooms-case-8-denied-936c6e16/8e889d43-c75b-408f-85ee-887468f2cf43/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as one shared fit snapshot with a mini-pack for each of the three rounds, from your message alone. I ran no web research, because the values, the round structure and the strategy summary are already in hand.

Say the word and I'll play the Head of Member Services on B2, the question the pack names as its highest-ROI prep. The gap there is the contact centre, which you have never worked in, and the JD puts it in its first responsibility.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you work from whichever hub this role is based at once the eight branches consolidate into five? The strategy summary doesn't say where this role sits, and the answer decides whether location is a screen issue or a no-go.

Did the recruiter say whether the 20-minute case is spoken, or whether it needs slides or a written answer? If it's written, the panel round needs a build section.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Rounds: three on 3 December 2026. Interviewers: the Head of Member Services (your future manager, name not given) for round 2, and two branch managers (names not given) for round 3. Loop mode: one shared fit snapshot and sources block, then one mini-pack per round. This is the first version, so there is no changelog.

Built from your message only: the JD, the values text you copied on 24 November 2026, the recruiter's round description, your summary of the July 2026 strategy brief, and your background. No web research was run.

## How to use

- **Personas** describe how a question arrives. **Types** describe what it scores.
- Type key: **VAL** is whether past behaviour shows a published value. **EXP** is whether your own claims survive scrutiny. **JD** is whether you can do a listed requirement, gaps included. **CO** is company and strategy knowledge. **CASE** is a live problem, reasoned aloud.
- Guidance is scaffolding, not a script. Each answer slot is an instruction for the interview. It asks for no reply here.
- Every quote is an exact fragment of your message, the JD, or the values text you pasted. Where a quote is from your message, the source is named "your message".

## Fit snapshot (shared across rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on the years. Say it as the sentence states it: six years in retail banking, three of them as a branch supervisor. A probe on whether branch work counts as customer operations is likely. Your material does not settle that, so answer it in your own words. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says "formal", not "regulated", and does not show which rules the log followed. Answer slot: if the log carried rules or timescales, say which and how you applied them; if it did not, say so and describe how formal complaints were handled. |
| F3 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | At its own scope: you trained tellers on the escalation script, and you were a branch supervisor for three years. Coaching other supervisors is not in the material. Answer slot: if you coached anyone other than tellers on escalations, say who and what you did; if not, say so and say how you would start. |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | The quote reaches reporting in other terms: a spreadsheet, built, used by your regional manager. Say it that way. Do not name a tool your material does not name. |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [grounded] | discovery | Monthly reporting is in the quote. Resolution times are not. Answer slot: if the spreadsheet recorded how long complaints took to close, say what it recorded and how it was counted; if it did not, say so and say what you would measure first. |
| F6 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Words: "I've never presented to anyone above regional level." Then a plan for how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller. |
| F7 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | At its own scope: one branch's formal complaints log. Answer slot: which steps of a complaint you owned, from first contact to closure; if you handled some steps and not others, name which. |
| F8 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | Words: "Never worked in a contact centre." Then a plan, not a past: how you would learn contact-centre complaint handling in your first month. |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | This is silence, not a stated absence: your material does not show any work with digital teams. Answer slot: if you worked with a team on a self-service or online journey, say what your part was; if you did not, say so and say how you would learn what those teams need. |
| F10 | Base location for this role. Not stated in the JD; it matters because of "consolidate eight branches into five hubs over 2027" — your message | none given | none | [inferred] | hard_gate | Your material does not establish where you can work. The one question allowed asks whether the gate is met, and it is asked in the closing questions. No workaround is offered here. |

Gap types follow the routing rule: F1 and F2 to F9 are not gates. F10 is a gate the material does not show met, so it is surfaced and never bridged.

## Prohibited claims

Not coached in any cell, answer, or drill. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F7 and F8 | F7's quote at its own scope. The limit is the pack's observation: the material says one branch's log, not the process across branches. |
| Coached branch supervisors on escalations | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material shows tellers, not supervisors. |
| Reported resolution times | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material shows monthly reporting, not what the spreadsheet measured. |
| Regulated complaints, as experience you have | Inflated form of F2 | F2's quote at its own scope: "I handled the branch's formal complaints log". |
| Built the spreadsheet in Excel | Inflated form of F4 | F4's quote. The tool is not named in the material. |
| Presented to senior leaders | Sourced entry: stated negative, F6 | The plain acknowledgment F6 gives: "I've never presented to anyone above regional level." |
| Worked in a contact centre | Sourced entry: stated negative, F8 | The plain acknowledgment F8 gives: "Never worked in a contact centre." |

## Grounding brief

Vocabulary the interviewers are likely to use, taken from your summary of the July 2026 brief. Check the brief's own wording before you use its terms. Your summary is the only copy the pack has.

- Member service, and digital channels, with the target of 40% moved by 2028.
- Eight branches consolidated into five hubs over 2027.
- A small-business lending product launching in Q1 2027.
- Competition from app-only banks.

Do not coach yourself to correct an interviewer's framing of the strategy. Use their terms.

---

## Round 1: Recruiter screen (30 minutes)

**Persona weights.** The relationship prior for a recruiter screen is conversational, with a light skeptic. Four of the eight questions are logistics slots: pay, notice, location and reason for leaving. Those are the screen's structure, not a persona. The persona questions are two conversational, one light skeptic and one light prober.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Friendly biography and a strategy check | High. It is the screen's register, and the risk is treating it as unscored. | Rehearse a 90-second arc. Treat the strategy question as scored. |
| Skeptic (light) | Why this role, after six years in branches | Medium. The prior is a light skeptic. | Give the motivation in your own words. |
| Data-driven prober (light) | A single count from the branch log | Low. One question. | Say what you know, and say when you do not. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you got from retail banking to a branch supervisor." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message | Tell the arc in your own words, as the quote states it: six years in retail banking, the last three as a branch supervisor. Keep it to about 90 seconds. Add no roles, dates or titles that are not in the sentence. | F1 is the evidence for the experience requirement. The conversational register does not lower the scoring. |
| A2 | "Why this role, after six years in branches?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message | Give the reason in your own words. Tie it to the complaints work the JD describes, without claiming contact-centre or senior-presenting experience. | Skeptic questions about motivation and why now land in the screen. F1 is the only history the answer can draw on. |
| A3 | "What pay are you looking for?" | JD | [generic] | Logistics slot. Give your own figure, or ask to see the band first, and say which. Do not give a figure you have not chosen. | Pay is a logistics term. Your answer fills its slot in your own words, and nothing else in the pack asks more on it. |
| A4 | "What notice would you have to give your current employer?" | JD | [generic] | Logistics slot. Give the notice period you actually owe, in your own words. | Notice is a logistics term, and only your own answer fills it. |
| A5 | "Which hubs or branches could you work from, and how far would you travel?" | JD | [generic] | Logistics slot. Give your actual answer. If the 2027 hub plan changes where you would be based, say what you can do. | Location is the gate in F10. The screen is where it is first asked. |
| A6 | "Why are you looking to leave where you are now?" | EXP | [generic] | Logistics slot. Give your own reason in one sentence, then stop. | The reason for leaving is a logistics term, and the recruiter will check that it matches the motivation in A2. |
| A7 | "How many complaints did your branch log in a typical month?" | EXP | [grounded] "I handled the branch's formal complaints log" — your message | Give the count you know. If you do not know it, say so. Do not reconstruct a figure to fill the gap. | F5 has no figure. A defend-the-number question is likely the first place a figure would be tested. |
| A8 | "What do you know about where Ashgrove is heading?" | CO | [grounded] "move 40% of member service to digital channels by 2028" — your message | Name the digital target in your own words. Say what, in your own view, it would change for complaint routing. Keep the claim to the target. | A CO question grounded in the strategy summary. It makes no claim about your history. |

---

## Round 2: Head of Member Services (45 minutes, behavioural)

**Persona weights.** The relationship prior for a hiring manager is case and skeptic. The recruiter says the round is mostly behavioural, which moves values up. The skeptic stays the top persona: a supervisor with no contact-centre or senior-presenting record is the first thing a manager checks. Four skeptic, three values, two pressure and one case.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the two stated gaps and the record's edges | High, and top weight. F6 and F8 are stated absences a manager will check first. | Say the plain acknowledgment first. Then the plan, and the nearest thing your record carries. |
| Values / behavioural | Asks for stories mapped to the four values | High. The round is mostly behavioural. | One story per value, and the honest branch where none exists. |
| Pressure | Interrupts and challenges credibility | Medium. Two questions. | Hold through two follow-ups, then concede only what is true. |
| Case / strategist | A strategy question on digital | Low. One question. | Structure the answer aloud. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level" — your message | Name the gap in your own words: "I've never presented to anyone above regional level." Then say how you would learn to present to senior leaders, as a plan. | F6 is the stated absence the JD's senior-leader requirement meets. A skeptic asks the day-one question to find it. |
| B2 | "This job runs complaints across the branches and the contact centre. What is your experience of the contact-centre side?" | JD | [grounded] "Never worked in a contact centre" — your message | **Highest-ROI prep in this pack.** Lead with the plain acknowledgment: "Never worked in a contact centre." Then the nearest thing your record carries: the branch's formal complaints log, which you handled. Then the plan: which contact-centre complaint data you would ask for in your first month, and who you would sit with. Hold the position through two follow-ups by returning to the branch log and the plan. Never add to the contact-centre claim. If pressed on whether you can run it, say you cannot yet, and what you would need to learn to. | F8 is the stated absence, and the JD names the contact centre in its first responsibility. The manager is most likely to probe here first, so this gets the deepest rehearsal. |
| B3 | "The role handles regulated complaints. Which rules or timescales did your log follow?" | JD | [grounded] "I handled the branch's formal complaints log" — your message | Answer slot. If the log followed rules or timescales, name them and how you applied them. If it did not, say so and describe how formal complaints were handled. Do not name a regulator or a deadline the material does not give. | F2 is discovery. The JD's regulated-complaints requirement raises the question. The second branch lets the premise be false. |
| B4 | "Walk me through the monthly complaints spreadsheet you built. What did it show?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Lead with what you built and who used it. Then the figures it showed, in your words. Resolution times are an answer slot: if it recorded how long complaints took to close, say how it was counted; if it did not, say so and say what you would measure first. | F4 and F5. The manager will ask about what the report showed before the resolution-time gap is found. |
| B5 | "Tell me about a complaint you kept going until it was actually fixed." | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Own the Fix. The story beat is the log you handled. Answer slot: if you kept a complaint going until it was solved, say which and how; if you handed one on, say so and what happened after. | Own the Fix is a published value. The quote carries the handling, not the resolution, so the resolution is a slot. |
| B6 | "Tell me about a time you put a member's side first when the process pointed the other way." | VAL | [generic] | Members First. Pick a complaint where the member's outcome changed a decision. If none comes to mind, say so plainly, then give the nearest thing your log carries, or how you would handle it. | No quote carries a member-side decision. The honest branch is the scaffold's own. |
| B7 | "Tell me about a time something you taught needed explaining twice." | VAL | [grounded] "trained new tellers on our escalation script" — your message | Plain Words. Story beat: you trained new tellers on the escalation script. Answer slot: if you changed how the script was worded or explained, say what and why; if you taught it as written, say so. | Plain Words is a published value. The quote carries the teaching, not the wording. |
| B8 | "What makes you credible to coach branch supervisors after three years as one?" | JD | [grounded] "the last 3 as a branch supervisor" — your message | Pressure. Hold: three years as a branch supervisor, and tellers trained on the escalation script. Concede only what is true: if pressed on coaching supervisors, say what you have not yet done, in your own words. | F3 is transferability. The hold is what the quote carries, and the concession is specific. |
| B9 | "Branch managers outrank you on the floor. Why would one take an escalation steer from you?" | JD | [grounded] "the last 3 as a branch supervisor" — your message | Pressure. Hold on the position the quote carries: a branch supervisor for three years knows the escalation work from the floor. Concede specifically if the steer was not yours to give. | A second pressure question on the same gap, aimed at the escalation steer. |
| B10 | "Forty percent of member service moves to digital by 2028. What changes first in complaint handling?" | CO | [grounded] "move 40% of member service to digital channels by 2028" — your message | Structure aloud: where digital complaints start, who gets them, and what data you check first. Name a risk. Make no claim about any past digital work. | A strategy question grounded in the summary. It keeps the digital requirement in front of the manager. |

---

## Round 3: Panel of two branch managers (60 minutes, values-scored, including a 20-minute case)

**Persona weights.** The recruiter says the panel scores against the four values, so values is the top persona. Branch managers are peers to a branch-network role, so peer and prober sit next. The 20-minute case gets a case persona. Four values, two peer, two case, two prober. The names of the panel members are not known, so the weights are shared. The upgrade menu asks for them.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / behavioural | One question per value, scored | Top. The recruiter says the panel scores against the four values. | Map a story to each value where a quote carries one. Otherwise use the scaffold and its honest branch. |
| Peer evaluator | Seams between branches and the central role | Medium. Branch managers are peers in the branch network. | Propose seam principles. Do not pretend to know the seam. |
| Case / strategist | The 20-minute complaint escalation | Medium. The recruiter names a 20-minute case. | Clarify, then structure aloud. |
| Data-driven prober | The spreadsheet's counting | Medium. A panel of managers reads the monthly report. | Name the weakest assumption you know, in your own words. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Members First. Pick a time you put the member ahead of a target. If none comes to mind, say so plainly, then give the nearest thing your log carries, or how you would handle it. | No quote carries a member-side decision. The honest branch is the scaffold's own. |
| C2 | "Tell me about a time something you wrote needed explaining twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" — your message | Plain Words. Story beat: you trained new tellers on the escalation script. Answer slot: if you changed how the script was worded, say what and why; if you taught it as written, say so. | Plain Words is a published value. The quote carries the teaching, not the wording. |
| C3 | "How did a branch's place in its town change how you handled a complaint?" | VAL | [generic] | Neighbours, Not Numbers. Pick a complaint where local context mattered. If none, say so plainly, then give the nearest thing your log carries. | No quote carries a local context. The honest branch is the scaffold's own. |
| C4 | "Tell me about a complaint you took on from someone else and carried to the end." | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Own the Fix. Story beat: the log you handled. Answer slot: if you carried one to the end, say how; if you did not, say so and what happened instead. | Own the Fix. The quote carries the handling, not the end state. |
| C5 | "Where is the seam between your work and ours, and what happens when we disagree?" | JD | [generic] | Propose the seam as principles, not as a map you do not have. Give one disagreement story only if a quote carries one; if none does, say so and name how you would handle it. | A peer question. It asks for principles, not a history the record does not hold. |
| C6 | "How do you handle credit when a complaint fix spans two branches?" | JD | [generic] | Name the credit principle you would use, then the shared-work practice. Make no claim about a past fix spanning branches, since none is in the material. | A peer question on credit-sharing. Reciprocity is in the reverse questions. |
| C7 | "A member's complaint has gone from a branch to the contact centre. The member says a callback was promised and never came. Talk me through the first hour." | CASE | [generic] | Structure aloud. Clarify first: what was promised, by whom, and what is logged. Objective: the member gets a callback and one named owner. Segmentation: is it logged as a formal complaint with a timescale. Approach: name one owner, log it, speak to the branch supervisor, and set the callback. Metrics: time to first contact, repeat contacts, and whether it is a one-off. Risks: the member's trust, and gaps at the handoff. | A live problem on the JD's contact-centre and branch scope. It asks about no past, so it claims nothing about you. |
| C8 | "Eight branches become five hubs over 2027. How would you keep escalation coaching consistent across the hubs?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" — your message | Structure aloud: what varies between branches now, what the hub changes, and one check you would run after the first quarter. Name a risk. | A CO question from the strategy summary. It tests the coaching requirement at the company's altitude. |
| C9 | "Walk me through how that spreadsheet counted a complaint." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Defend the number. Answer slot: if you chose the counting rule, say how and why; if the regional manager set it, or it had no written rule, say so. | F4 and F5. The question's premise is a counting method, which the quote does not carry, so the second branch must be available. |
| C10 | "Which part of that monthly report would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Name, in your own words, the weakest assumption you know of in the report, before they find it. If you do not know the answer, say so. | The prober's move on the report. It converts a gotcha into a credibility point. |

### Values cheat sheet (section 10: values round detected)

The panel scores against four values. The values are the ones you pasted from the Ashgrove site, on 24 November 2026.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No quote carries a member-side decision. Scaffold: pick one complaint whose outcome you changed for the member. Honest branch: if none comes to mind, say so plainly, then give the nearest thing your log carries. Rehearse C1. |
| Plain Words | If a member needs it explained twice, the wording was wrong. | F3 carries "trained new tellers on our escalation script". Story beat: the teaching. Answer slot: whether you changed the script's wording. Honest branch: if you taught it as written, say so. Rehearse C2. |
| Neighbours, Not Numbers | Every branch is part of its town. | No quote carries local context. Scaffold: pick a complaint where the town mattered. Honest branch: if none, say so plainly, then give the nearest thing your log carries. Rehearse C3. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F7 carries "I handled the branch's formal complaints log". Story beat: the log you handled. Answer slot: whether you kept one to closure or handed it on. Honest branch: if you handed one on, say so. Rehearse C4. |

---

## Reverse questions (shared; each has a "why it lands")

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "What does a good first six months look like in this role?" | It shows you are thinking about the outcome, not just the job title. |
| RQ2 | "How do the branch supervisors use complaints data today?" | It opens the coaching gap from F3 and shows you care about the supervisors' use of the data. |
| RQ3 | "How will the hub consolidation change how complaints are routed?" | It names the 2027 plan and asks about its effect on complaints, which is the job. |
| RQ4 | "How is complaint work in the contact centre measured today?" | It shows interest in the contact centre, the side your record does not cover. |
| RQ5 | "What has been the hardest escalation for the branch team this year?" | It asks for the real problem the manager is paid to fix. |
| RQ6 (reciprocity, round 3) | "What would a new person do in their first month that would genuinely help your branches?" | It is the peer reciprocity question, and it shows you are offering help, not just asking for it. |

## Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| 4+ years in financial-services customer operations | A1 | |
| Experience handling regulated complaints | B3 | |
| Confident presenting to senior leaders | B1 | No round 3 question, since the panel is a presentation of its own. |
| Comfortable with Excel reporting | B4, C9, C10 | |
| Own the member complaints process end to end across branches and the contact centre | B2, B5, C4 | |
| Report monthly on complaint volumes and resolution times | A7, B4, C9, C10 | Resolution times are a slot in B4 and F5. |
| Coach branch supervisors on escalations | B7, B8, C8 | |
| Work with digital teams on self-service journeys | B10, RQ3 | No round 1 question on this. |

## Sources

- Provided documents, all from your message: the JD text, the values text copied from ashgrovecu.org/about/values on 24 November 2026, the recruiter's round description, your summary of the July 2026 strategy brief, and your background. The brief itself was not provided, only your summary, so quotes from it are your summary's words.
- Research tier: L0. Provided documents only. No search or fetch was sent, because each L1 target's output was already fixed by an input in hand.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text you pasted fixes the values cheat sheet. |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the three rounds, their relationships and the case. |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief fixes the current priorities. News after July 2026 would have moved the CO questions; it is offered at L2 below. |
| 4. Interviewer name and company | n/a | No names were given for the Head of Member Services or the panel. |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The panel members' names → a persona assignment for each member and one tailored reverse question for round 3.
- The Head of Member Services' name → persona weights from public professional footprint, and a reverse question tied to their career path.
- Your CV or résumé → a second source for each quote. The quotes currently come from your message.
- The recruiter's note on the 20-minute case → whether it is spoken, or needs slides or a written answer. If written, it becomes a graded build section.
- Deep research, L2, offered once, with six more searches and two more fetches and a longer run time → recent strategy news after July 2026, role-family loop reports, and public talks by the interviewers, if named.
- A `tuesday-dossier.md` from a job-underwriter run → verified evidence and prohibited claims that bind every cell of this pack.
