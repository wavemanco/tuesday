The pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-2-rooms-case-1-denied-192bf6e8/ea0a9415-f9d6-4270-ab0f-b9fcd634b4af/scratchpad/northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md`. It is built on your JD highlights, the coach's notes on Priya, your profile note on Dan, and your research note. The three web searches were refused by permission, so there is no values, loop, or Dan public-footprint research. Those gaps are listed in Sources.

# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer (both report to the same VP). **Format:** one 60-minute conversation.

## 2. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral or values, **EXP** your past work, **JD** role requirements, **CO** company strategy, **CASE** live problem.
- Guidance is scaffolding, not a script. Answer in your own words. Rehearse only what you actually did.
- Question IDs run by persona: A Prober, B Peer, C Case, D Skeptic, E Pressure, G Conversational, H Values. F is reserved for fit-snapshot rows.

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | low | [grounded] | transferability | Your notes show product strategy and ops work, not go-to-market ownership of a product line. Keep the words at that scope: "For nine years I worked in product strategy and ops at a large consumer-tech company." Answer slot: if a go-to-market decision for a launch was yours to make, say which and how you decided. If none was yours, say so plainly and name the product-strategy decision that was. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | none given | none | [grounded] | discovery | Your notes say nothing about lifecycle whitespace. Answer slot: if you have mapped growth across land, adopt, expand or renew, say what you looked at. If not, say so plainly and say how you would find where the whitespace sits. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (coach's notes) | low | [grounded] | discovery | "Skilled in" is a skill claim, not an analysis run. Keep the words there: "I work in SQL and Tableau." Answer slot: name an analysis you ran in SQL or Tableau yourself and what it was for. If you have not run one end to end, say so plainly. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | Adjacent. The model is partner-facing input to negotiations, not a record of designing a partner motion (channel terms, incentives, co-selling). Words: "I built the partner-level revenue model, and it was used in carrier negotiations." Answer slot: if you shaped partner terms or incentives, say which. If the model was your part, say that and stop there. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: targets set and agreed across orgs. Words: "I set the annual volume targets, and they reached consensus across orgs." Limit, in this analysis only: these are volume targets, not quotas. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (coach's notes) | low | [grounded] | transferability | Usage, not building. Words: "I use AI tools daily." Limit, in this analysis only: usage, not building AI features. Answer slot: name one task where an AI tool changed your work, and how. |

No gate rows: the highlights name no location, work authorization, schedule or pay gate. The full posting might add one.

## 6. Grounding brief

From your research note, not independently checked.

- Stated priorities: enterprise expansion; an AI copilot launch ('Compass'); reaching profitability.
- Main competitive threat: bundling by a much larger platform vendor.
- No headline figures, leadership names or dated recent moves were supplied, and none are added here.

## 7. Reading the interviewer

Built only from your profile note, since the public-footprint search was refused.

- **Career pattern:** pricing and monetization roles, with one early-stage startup chapter.
- **Self-description:** "relentlessly data-driven."

1. **Prober up.** He will probe the assumptions behind every number. Rehearse A1, A2 and A5.
2. **Pricing spine.** Tilt case answers toward packaging, pricing and unit economics (C1).
3. **Startup chapter.** Builder stories may land with him. Expect a probe on big-company pace. The answer is hers to give; rehearse the question, not a line.
4. **Mirror opportunities:** none offered. Her path and his are not a similar jump in the material.

## 8. Persona table

| Persona | Weight | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | 5 | Denominators, assumptions and attribution on the ~$400M figure and the partner model | High. The peer prior puts the Prober at the top, and his self-description is "relentlessly data-driven" | Name the weakest assumption before he does. Say plainly what you cannot reproduce. |
| Peer Evaluator | 5 | The seam with pricing and sales strategy, disagreement, credit | High. The peer prior puts the Peer Evaluator at the top, and both report to the same VP | Reciprocity first: what you bring his team. Propose seam principles, not a seam you have not seen. |
| Case / Strategist | 3 | A pricing, packaging or whitespace problem | Medium. The GTM remit invites a case, and his pricing spine sets the angle | Clarify, objective, segmentation, approach, metrics, risks. State the hypothesis early. |
| Skeptic | 3 | GTM ownership, partner-motion design, consumer tech to B2B | Medium, with one question high (D1). The GTM ownership gap is the largest visible one | Hold what you did. Concede the gap plainly and specifically. Do not bluff a competency. |
| Conversational | 2 | The opening "walk me through" and a casual AI question | Medium. Casual questions are scored | Use the 90-second arc. Treat the AI question as scored. |
| Pressure | 2 | Challenges to the ~$400M figure | Low. Nothing in the profile signals a stress style | Pause, restate, hold through two follow-ups, then concede what you cannot attribute. |
| Values / Behavioral | 2 | Scenario probes | Low. No values-style round detected and no values in hand | Selection scaffolds only. No values are mapped. |

## 9. Question banks

**Highest-ROI prep: D1.** The GTM-ownership objection is the most predictable one for this candidate, so it gets the deepest rehearsal.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you counted the ~$400M ARR uplift." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Beats: she proposed the change, and the uplift was credited with it. Answer slot: say how the figure was counted, in her own words. If she does not know, say so plainly. Name the assumption she would defend least before he does. Say which part was hers. No method, baseline or attribution model is supplied. | The headline figure draws a prober. These are the defend-the-number slots. It is consumer-tech ARR, so do not translate it into B2B terms. |
| A2 | "Walk me through the partner-level revenue model you built. Who used it, and for what?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Beats: she built it, and it was used in carrier negotiations. Tell them in her words, and say which part of the model was hers. | F4 is the evidence. The probe tests whether the model was hers and what it was used for. |
| A3 | "How did you get cross-org agreement on the annual volume targets?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Beats: she set the annual volume targets, and they reached cross-org consensus. Answer slot: if she chose how the targets were built or who agreed, say so. If others built them, say that. If asked about quotas, say what she actually set. | F5 is the requirement. The probe is how the consensus happened. |
| A4 | "Tell me about a SQL or Tableau analysis you ran yourself, start to finish." | EXP | [grounded] "skilled in SQL/Tableau" (coach's notes) | Open prompt: she picks one instance. Answer slot: the question asked, the data, and what changed. If she has not run one end to end, say so and name the nearest she has. Do not describe an analysis she did not run. | F3 is discovery. This is where it gets tested. |
| A5 | "What could you show a finance partner today about the partner revenue model?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Say what exists, where it lives, and what she can reproduce. If it no longer exists or cannot be rerun, say so plainly. | Reproducibility probe on a headline he may request. |

### B. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Pricing and sales strategy sit side by side. Where is the seam, and what happens when we disagree?" | JD | [grounded] "both reporting to the same VP" (your note) | No past claim asked. Reciprocity first. Propose seam principles, not a seam she has not seen. Answer slot: if she has disagreed with a peer team and it resolved, say how. If not, say how she would handle it. | Peer prior. He tests turf and disagreement style. |
| B2 | "For the first new line, which go-to-market motion would you test first, and what would you need from my team?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights) | No past claim. Name the test, the first data needed, and what she would give his team. | The ownership line, asked as a peer question. |
| B3 | "Where should packaging decisions end and coverage decisions start?" | JD | [generic] | Principle: decision rights, and the one metric each owner watches. No claim about her past. | His pricing spine. [generic] because it is a role-family pattern. |
| B4 | "When a launch spans both our teams, who gets the credit, and how did you handle that before?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Say who did what, in her words. Credit for the uplift went to the change she proposed; she should not claim more. Answer slot: if she has shared credit across teams, say how. If not, say how she would handle it. | Credit-sharing probe, kept at the figure's own scope. |
| B5 | "What would make you a good partner to my team in your first 90 days?" | JD | [generic] | Principles, in the future tense: ask first, share the data, close loops. A plan, not a record. | Reciprocity without claiming a past. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you decide whether a new data line is an add-on or part of the core tier?" | CASE | [generic] | Clarify, then objective, segmentation, approach, metrics, risks. State the hypothesis early. Use pricing and packaging language. | His pricing spine tilts cases to packaging and unit economics. |
| C2 | "Land, adopt, expand, renew: where would you look for whitespace first in a data-infrastructure base?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights) | Structure by lifecycle stage. Name the data needed, and say what she would not know yet. | Puts the JD line to her as a live problem, covering F2's gap without asserting experience. |
| C3 | "Northwind's priorities are enterprise expansion, an AI copilot launch and reaching profitability. Where would a new line's go-to-market sit against them, and what would you trade off first?" | CO | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your research note); "bundling by a much larger platform vendor" (your research note) | Structure through the three priorities. Name one trade-off. Raise the bundling threat as the risk the plan must survive. | The only CO item. Its premise rests on your research note, which is not a listed raising source. If the priorities differ, cut the premise. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've spent nine years in product strategy and ops. Which go-to-market decision for a product line was yours?" | JD | [grounded] "then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | **Highest-ROI prep.** Answer slot: if a go-to-market decision for a launch was hers, name it and how she decided. If none was, say so plainly and name the product-strategy decision that was. Hold through two follow-ups by returning to product strategy, not by adding to it. Concede the gap once, plainly. Never bluff GTM ownership. | F1 is the requirement the material only partly reaches. This objection arrives in some form. |
| D2 | "Partner-motion design is required here. Have you designed one, or only modeled one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Answer slot: if she shaped partner terms, incentives or co-selling, say which. If her part was the model, say "I built the partner-level revenue model, and it was used in carrier negotiations," then stop. If the design was not hers, say so plainly. | F4's transferability gap. |
| D3 | "Consumer tech to B2B data infrastructure: what transfers, and which part of a sales motion is new to you?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | Name what transfers from product strategy and ops, in her words. Name what is new, and a 90-day ramp plan. Answer slot: if she has set quotas or run sales operations, say which. If not, say so plainly. | The sales-strategy title raises the sales motion. The quota probe rests on no claim she made, so the slot is the honest form. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should this seat be yours?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | Hold through two follow-ups. Use only the arc the sentence states. | A held position she can back. |
| E2 | "That ~$400M figure: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Hold: she proposed the change, and the uplift was credited with it. Concede specifically, in her words, what she cannot attribute to herself. Answer slot: say which part was hers. | The hold must be the quote. A claim she cannot back breaks on the second follow-up. |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | A 90-second arc with two stages, each as the sentence states it. End with why she is here. | The casual opener is scored. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Name one tool and one task. Say what she did not build. | The plus item asked casually. |

### H. Values / Behavioral (weight 2)

No values-style round was detected, and no published values are in hand, so nothing is mapped.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time the hard truth landed with leadership." | VAL | [generic] | Selection scaffold: pick a time she put an unwelcome number in front of leaders, with a named stake and an outcome. If none comes to mind, say so plainly, then give the nearest thing she has. | Keeps the style from being met for the first time live. |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Same scaffold. The customer must be a real person or group she served. | Same reason as H1. |

### Requirement coverage

| JD requirement (highlights) | Questions |
|---|---|
| own GTM strategy for two new product lines | B2, C3, D1 |
| identify whitespace across land/adopt/expand/renew | C2 |
| run independent analysis in SQL and Tableau | A4 |
| partner-motion design experience required | A2, D2 |
| strong cross-functional influence | A3, B4 |
| AI experience a plus | G2 |

Session total: 22 questions.

## 11. Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "Your career runs through pricing and monetization. Which pricing call would you most want a new peer to understand?" | Ties to his own path, turning an interrogation into a peer conversation. | [grounded] "pricing and monetization roles" (your profile note) |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, which a peer weights heavily. | [generic] |
| R3 | "Where does the line between sales strategy and the new product lines sit today, and who settles disputes?" | Tests the seam. | [generic] |
| R4 | "How has the Compass copilot launch changed how you scope go-to-market for a new line?" | Shows you read current research, not an old memo. | [grounded] "an AI copilot launch ('Compass')" (your research note) |
| R5 | "What did the last go-to-market plan for a new line get wrong?" | Shows you ask about failure, not only success. | [generic] |
| R6 | "How does the profitability goal change which new-line bets get funded?" | Links the priority to funding decisions. | [grounded] "reaching profitability" (your research note) |

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market for a product line | Inflated form of F1 | F1's sentence at its own scope. The notes show product strategy and ops, not GTM ownership. D1's slot stays inside that work. |
| Designed partner motions | Inflated form of F4 | F4's sentence at its own scope. D2's slot. |
| Delivered the ~$400M ARR | Inflated form of the figure: "credited with" is not "delivered" | "proposed a store-surface change credited with a ~$400M ARR uplift," at its own scope. A1, B4 and E2 slots. |
| Led cross-org target setting | Inflated form of F5 | F5's sentence at its own scope. A3's slot. |
| Built AI tools | Inflated form of F6 | "I use AI tools daily." |
| Any claim of quota or sales-ops experience, either way | The coach's notes say "No classic sales-ops or quota-setting experience." That is not a negative Priya stated, so no first-person line is coached | Observation only. Words for the interview: D3's answer slot. |

## 14. Sources

**Provided documents:** your message (five JD highlights, coach's notes on Priya), your profile note on Dan Kovac, and your research note. No CV text, no dossier, no published values, no full JD.

**Searches sent (all refused by permission; no fetches):**
- "Northwind Data company values": refused
- "Northwind Data interview process sales strategy": refused
- "Dan Kovac Director of Sales Strategy Northwind Data": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2 (all 3 refused)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Values cheat sheet could not be built, so it is omitted. Call refused. |
| 2. Interview process, sales strategy | unavailable | Loop structure unknown; persona weights rest on relationship priors and your profile note. Call refused. |
| 3. Strategy / recent news | skipped | Your research note fixes the priorities and competitive threat. |
| 4. Dan Kovac, Northwind | unavailable | Would have moved the interviewer read and reverse questions. Call refused. |
| 5. Representative JD | skipped | Your highlights fix the fit snapshot and JD-tagged questions. |

Omitted because their conditions do not hold: prep triage (prep time not stated), graded deliverables (none declared), values cheat sheet (no values in hand), delivery coaching (no assessment).

## 15. Upgrade menu

- **Full JD text** → the fit snapshot quotes the posting itself, any gate rows appear, and mid-list requirements get their own rows.
- **Recruiter's note on focus areas or a pre-declared deliverable** → a graded-deliverable section and coverage of it.
- **Prep time** → a prioritized triage section.
- **A pasted values page** → a values cheat sheet, with H1 and H2 mapped to published values.
- **Pasted links to Dan's talks or writing** → his recurring themes become questions, and reverse questions and persona weights are checked against them.
- **A retry of the three searches** → the values, loop and interviewer rows above. An L2 deep run is offered once: four further targets, up to 6 further searches and 2 fetches. The time cost falls on search, not on you.
- **Inspectable evidence**, such as the partner revenue model file, a SQL or Tableau workbook Priya built, or the analysis behind the ~$400M figure → raises the bands on F3, F4 and E2.
- **tuesday-dossier.md from an earlier run** → verified evidence and prohibited claims replace the inferred rows.

---

I can also play Dan as the Prober on A1, the ~$400M figure, and give feedback against that question's guidance. I can save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions. If you want the pack as a Word document, say so and I'll convert it.

1. Can you paste the full JD text? The fit snapshot quotes the highlights, and the full posting may add a gate row.
2. Did the recruiter flag any focus areas or a pre-declared deliverable, such as a POV or take-home?
3. How much prep time does Priya have before the conversation?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer (both report to the same VP). **Format:** one 60-minute conversation. **Session pack**, first build.

## 2. How to use this pack

- **Personas** describe how a question arrives (its delivery). **Types** describe what is being scored.
- Type key: **VAL** behavioral or values, **EXP** your past work, **JD** role requirements, **CO** company strategy, **CASE** live problem.
- Guidance is scaffolding, not a script. Answer in your own words. Rehearse only what you actually did.
- Question IDs run by persona: A Prober, B Peer, C Case, D Skeptic, E Pressure, G Conversational, H Values. F is reserved for fit-snapshot rows.

## 4. Fit snapshot

Requirements are your JD highlights (the full posting was not supplied). Evidence is quoted from the coach's notes on Priya; her CV was not supplied as text.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | low | [grounded] | transferability | Your notes show product strategy and ops work, not go-to-market ownership of a product line. Keep the words at that scope: "For nine years I worked in product strategy and ops at a large consumer-tech company." Answer slot: if a go-to-market decision for a launch was yours to make, say which and how you decided. If none was yours, say so plainly and name the product-strategy decision that was. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | none given | none | [grounded] | discovery | Your notes say nothing about lifecycle whitespace. Answer slot: if you have mapped growth across land, adopt, expand or renew, say what you looked at. If you have not, say so plainly and say how you would find where the whitespace sits. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (coach's notes) | low | [grounded] | discovery | "Skilled in" is a skill claim, not an analysis run. Keep the words there: "I work in SQL and Tableau." Answer slot: name an analysis you ran in SQL or Tableau yourself and what it was for. If you have not run one end to end, say so plainly. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | Adjacent. The model is partner-facing input to negotiations, not a record of designing a partner motion (channel terms, incentives, co-selling). Words: "I built the partner-level revenue model, and it was used in carrier negotiations." Expect a probe on the design question. Answer slot: if you shaped partner terms or incentives, say which. If the model was your part, say that and stop there. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: targets set and agreed across orgs. Words: "I set the annual volume targets, and they reached consensus across orgs." Limit, in this analysis only: these are volume targets, not quotas. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (coach's notes) | low | [grounded] | transferability | Usage, not building: adjacent to the plus item. Words: "I use AI tools daily." Limit, in this analysis only: usage, not building AI features. Answer slot: name one task where an AI tool changed your work, and how. |

No gate rows: the highlights name no location, work authorization, schedule or pay gate. The full posting might add one.

## 6. Grounding brief

From your research note. Not independently checked (see Sources).

- Stated priorities: enterprise expansion; an AI copilot launch ('Compass'); reaching profitability.
- Main competitive threat: bundling by a much larger platform vendor.
- No headline figures, leadership names or recent dated moves were supplied, and none are added here. Use the four terms above; do not cite numbers you have not checked.

## 7. Reading the interviewer

Public-footprint search was refused, so this read comes only from your profile note.

- **Career pattern:** pricing and monetization roles, with one early-stage startup chapter.
- **Self-description:** "relentlessly data-driven."

Implications:

1. **Prober up.** He will probe the assumptions behind every number Priya gives. Rehearse A1, A2 and A5.
2. **Pricing spine.** Tilt case answers toward packaging, pricing and unit economics (C1).
3. **Startup chapter.** Builder stories may land with him. Expect a probe on big-company pace. The answer is hers to give; rehearse the question, not a line.
4. **Mirror opportunities:** none offered. Her path (consulting, then product ops) and his (pricing, then one startup) are not a similar jump in the material.

## 8. Persona table

| Persona | Weight | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | 5 | Denominators, assumptions and attribution on the ~$400M figure and the partner model | High. The peer prior puts the Prober at the top, and his self-description is "relentlessly data-driven" | Name the weakest assumption you know before he does. Say plainly what you cannot reproduce. |
| Peer Evaluator | 5 | The seam with pricing and sales strategy, disagreement, credit | High. The peer prior puts the Peer Evaluator at the top, and both report to the same VP | Reciprocity first: what you bring his team. Propose seam principles, not a seam you have not seen. |
| Case / Strategist | 3 | A pricing, packaging or whitespace problem | Medium. The role's GTM remit invites a case, and his pricing spine sets the angle | Clarify, objective, segmentation, approach, metrics, risks. State the hypothesis early. |
| Skeptic | 3 | Probes on GTM ownership, partner-motion design, and consumer tech to B2B | Medium, with one question high (D1). The GTM ownership gap is the largest visible one | Hold what you did. Concede the gap plainly and specifically. Do not bluff a competency. |
| Conversational | 2 | The opening "walk me through" and a casual AI question | Medium. Casual questions are scored | Use the 90-second arc. Treat the AI question as scored. |
| Pressure | 2 | Challenges to the ~$400M figure | Low. Nothing in the profile signals a stress style | Pause, restate, hold through two follow-ups, then concede what you cannot attribute. |
| Values / Behavioral | 2 | Scenario probes | Low. No values-style round detected and no values in hand | Selection scaffolds only. No values are mapped. |

## 9. Question banks

**Highest-ROI prep: D1.** The GTM-ownership objection is the most predictable one for this candidate, so it gets the deepest rehearsal.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you counted the ~$400M ARR uplift." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Beats the sentence states: she proposed the change, and the uplift was credited with it. Answer slot: say how the figure was counted, in her own words. If she does not know, say so plainly. Name the assumption she would defend least before he does. Say which part was hers. No method, baseline or attribution model is supplied here. | The headline figure draws a prober. These are the four defend-the-number slots. It is consumer-tech ARR, so do not translate it into B2B terms. |
| A2 | "Walk me through the partner-level revenue model you built. Who used it, and for what?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Beats the sentence states: she built it, and it was used in carrier negotiations. Tell them in her own words, and say which part of the model was hers. | F4 is the evidence. The probe tests whether the model was hers and what it was used for. |
| A3 | "How did you get cross-org agreement on the annual volume targets?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Beats: she set the annual volume targets, and they reached cross-org consensus. Answer slot: if she chose how the targets were built or who agreed to them, say so. If others built them, say that. If asked about quotas, say what she actually set. | F5 is the requirement. The probe is how the consensus happened. |
| A4 | "Tell me about a SQL or Tableau analysis you ran yourself, start to finish." | EXP | [grounded] "skilled in SQL/Tableau" (coach's notes) | Open prompt: she picks one instance, and the theme is the JD's independent-analysis line. Answer slot: the question asked, the data, and what changed. If she has not run one end to end, say so plainly and name the nearest she has. Do not describe an analysis she did not run. | F3 is discovery. This question is where it gets tested. |
| A5 | "What could you show a finance partner today about the partner revenue model?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Say what exists, where it lives, and what she can reproduce. If it no longer exists or she cannot rerun it, say so plainly. | Data-driven probe on reproducibility of a headline the interviewer may request. |

### B. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Pricing and sales strategy sit side by side. Where is the seam, and what happens when we disagree?" | JD | [grounded] "both reporting to the same VP" (your note) | No past claim is asked. Reciprocity first: what she brings his team. Propose seam principles, not a seam she has not seen. Answer slot: if she has disagreed with a peer team and it resolved, say how, in her own words. If not, say how she would handle it. | Peer prior. He tests turf and disagreement style with an equal. |
| B2 | "For the first new line, which go-to-market motion would you test first, and what would you need from my team?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights) | No past claim. Name the test, the first data needed, and what she would give his team in return. | The ownership line, asked as a peer question. |
| B3 | "Where should packaging decisions end and coverage decisions start?" | JD | [generic] | Principle: decision rights, and the one metric each owner watches. No claim about her past. | His pricing spine, in his own language. [generic] because it is a role-family pattern, not a fact about Northwind. |
| B4 | "When a launch spans both our teams, who gets the credit, and how did you handle that before?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Say who did what, in her own words. Credit for the uplift went to the change she proposed; she should not claim more of it. Answer slot: if she has shared credit for work across teams, say how. If not, say how she would handle it. | Credit-sharing probe. The nearest sentence about credit is the figure, so the answer keeps credit at its own scope. |
| B5 | "What would make you a good partner to my team in your first 90 days?" | JD | [generic] | Principles, in the future tense: ask first, share the data, close loops. A plan, not a record. | Reciprocity rehearsed without claiming a past. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you decide whether a new data line is an add-on or part of the core tier?" | CASE | [generic] | Clarify, then objective, segmentation, approach, metrics, risks. State the hypothesis early. Use pricing and packaging language. No claim about her past. | His pricing spine tilts cases to packaging and unit economics. [generic] because it is a pattern for the problem. |
| C2 | "Land, adopt, expand, renew: where would you look for whitespace first in a data-infrastructure base?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights) | Structure by lifecycle stage. Name the data she would need, and say what she would not know yet. No claim about her past. | Puts the JD line to her as a live problem. This covers F2's gap without asserting experience. |
| C3 | "Northwind's priorities are enterprise expansion, an AI copilot launch and reaching profitability. Where would a new line's go-to-market sit against them, and what would you trade off first?" | CO | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your research note); "bundling by a much larger platform vendor" (your research note) | Structure through the three priorities. Name one trade-off she would face. Raise the bundling threat as the risk the plan must survive. Cite the priorities, not figures. | The only CO item. Its premise rests on your research note, which is not a listed raising source. If the priorities differ from your note, cut the premise. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've spent nine years in product strategy and ops. Which go-to-market decision for a product line was yours?" | JD | [grounded] "then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | **Highest-ROI prep in this pack.** Answer slot: if a go-to-market decision for a launch was hers to make, name it and how she decided. If none was hers, say so plainly and name the product-strategy decision that was. Hold through two follow-ups by returning to product strategy, not by adding to it. Concede the gap once, plainly and specifically. Never bluff GTM ownership. | F1 is the requirement the material only partly reaches. This objection arrives in some form, and an honest answer changes the interview. |
| D2 | "Partner-motion design is required here. Have you designed one, or only modeled one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Answer slot: if she shaped partner terms, incentives or co-selling, say which, in her words. If her part was the model, say "I built the partner-level revenue model, and it was used in carrier negotiations," then stop. If the design was not hers, say so plainly. | "Modeled" is her own noun, and "designed" is the JD's. This is F4's transferability gap. |
| D3 | "Consumer tech to B2B data infrastructure: what transfers, and which part of a sales motion is new to you?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | Name what transfers from product strategy and ops, in her own words. Name what is new, and a 90-day ramp plan in the future tense. Answer slot: if she has set quotas or run sales operations, say which. If not, say so plainly. | The interviewer's sales-strategy title raises the sales motion. The quota probe rests on no claim she made, so the slot is the honest form. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should this seat be yours?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | Hold the position through two follow-ups. Use only the arc the sentence states, and add no claim. | Pressure persona at low weight. A held position she can back. |
| E2 | "That ~$400M figure: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Hold: she proposed the change, and the uplift was credited with it. Concede specifically, in her own words, what she cannot attribute to herself. Answer slot: say which part was hers. | The hold has to be the quote. A held claim she cannot back is the one the second follow-up breaks. |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | A 90-second arc with two stages, each as the sentence states it. End with why she is here, in her own words. | The casual opener is scored. Prepare the arc, not a speech. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Name one tool and one task, in her words. Say what she did not build. | The plus item asked casually. F6 is low confidence, so no building claim. |

### H. Values / Behavioral (weight 2)

No values-style round was detected, and no published values are in hand, so nothing here is mapped.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time the hard truth landed with leadership." | VAL | [generic] | Selection scaffold: pick a time she put an unwelcome number in front of leaders, with a named stake and an outcome. If none comes to mind, say so plainly, then give the nearest thing she has. | Low-weight values probe, so the style is not met for the first time live. |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Same scaffold. The customer must be a real person or group she served. | Same reason as H1. |

### Requirement coverage

| JD requirement (highlights) | Questions that cover it |
|---|---|
| own GTM strategy for two new product lines | B2, C3, D1 |
| identify whitespace across land/adopt/expand/renew | C2 |
| run independent analysis in SQL and Tableau | A4 |
| partner-motion design experience required | A2, D2 |
| strong cross-functional influence | A3, B4 |
| AI experience a plus | G2 |

Session total: 22 questions (A5, B5, C3, D3, E2, G2, H2).

## 11. Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "Your career runs through pricing and monetization. Which pricing call would you most want a new peer to understand?" | Ties to his own path. It turns an interrogation into a peer conversation. | [grounded] "pricing and monetization roles" (your profile note) |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, which a peer weights heavily. | [generic] |
| R3 | "Where does the line between sales strategy and the new product lines sit today, and who settles disputes?" | Tests the seam, and shows you looked at his work. | [generic] |
| R4 | "How has the Compass copilot launch changed how you scope go-to-market for a new line?" | Shows you read the current research, not an old memo. | [grounded] "an AI copilot launch ('Compass')" (your research note) |
| R5 | "What did the last go-to-market plan for a new line get wrong?" | Shows you ask about failure, not only success. | [generic] |
| R6 | "How does the profitability goal change which new-line bets get funded?" | Links the priority to funding decisions. | [grounded] "reaching profitability" (your research note) |

## 13. Prohibited claims

Not coached, and why. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market for a product line | Inflated form of F1 | F1's sentence at its own scope. Limit, as this analysis's observation: the notes show product strategy and ops, not go-to-market ownership. D1's slot stays inside the product-strategy work. |
| Designed partner motions | Inflated form of F4 | F4's sentence at its own scope. D2's slot. |
| Delivered the ~$400M ARR | Inflated form of the figure: "credited with" is not "delivered" | "proposed a store-surface change credited with a ~$400M ARR uplift," at its own scope. A1, B4 and E2 slots. |
| Led cross-org target setting | Inflated form of F5 | F5's sentence at its own scope. A3's slot. |
| Built AI tools | Inflated form of F6 | "I use AI tools daily." No slot. |
| Any claim of quota or sales-ops experience, either way | The coach's notes say "No classic sales-ops or quota-setting experience." That is not a negative Priya stated, so no first-person line is coached | Observation only: the notes show no quota or sales-ops work. Words for the interview: D3's answer slot. |

## 14. Sources

**Provided documents:** your message, with the five JD highlights and the coach's notes on Priya; your profile note on Dan Kovac; your research note on Northwind's priorities and competitive threat. No CV text, no dossier, no published values page, and no full JD text.

**Searches sent (all refused by permission; no fetches sent):**

- "Northwind Data company values": refused
- "Northwind Data interview process sales strategy": refused
- "Dan Kovac Director of Sales Strategy Northwind Data": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2 (all 3 refused)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Values cheat sheet (section 10) could not be built, so it is omitted. Its calls were refused. |
| 2. Interview process, sales strategy | unavailable | Loop structure is unknown. Persona weights rest on relationship priors and your profile note. Its call was refused. |
| 3. Strategy / recent news | skipped | Your research note fixes the three priorities and the competitive threat, so the grounding brief and C3 rest on it. |
| 4. Dan Kovac, Northwind | unavailable | Would have moved the interviewer read (public talks and writing) and the reverse questions. Its call was refused. |
| 5. Representative JD | skipped | Your highlights fix the fit snapshot and the JD-tagged questions. |

Sections omitted because their conditions do not hold: prep triage (prep time not stated), graded deliverables (none declared), values cheat sheet (no values in hand), delivery coaching (no assessment).

## 15. Upgrade menu

- **Full JD text** → the fit snapshot quotes the posting itself, any gate rows appear, and the mid-list requirements get their own rows.
- **Recruiter's note on focus areas or a pre-declared deliverable** → a graded-deliverable section, and coverage of it.
- **Prep time** → a prioritized triage section.
- **A pasted values page** → a values cheat sheet, with H1 and H2 mapped to published values.
- **Pasted links to Dan's talks or writing** → his recurring themes become questions, and the reverse questions and persona weights are checked against them.
- **A retry of the three searches** (L1 caps: 6 searches, 2 fetches) → the values, loop and interviewer rows above. An L2 deep run is offered once: four further targets (strategy brief, interviewer talks and writing, role-family loop reports, recent org context), up to 6 further searches and 2 fetches. The time cost falls on search, not on you.
- **Inspectable evidence**, such as the partner revenue model file, a SQL or Tableau workbook built by Priya, or the analysis behind the ~$400M figure → raises the bands on F3, F4 and E2, and turns a claim into something checkable.
- **tuesday-dossier.md from an earlier run** → verified evidence and prohibited claims replace the inferred rows.
