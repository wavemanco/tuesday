Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-2-rooms-case-5-denied-8f141cf8/a8bcdeed-3fad-43b8-a705-29326b0f80f9/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md, and I've sent it to you as a file. I built it for the panel, and web search was refused in this session, so it has no Kelverton research. The Sources section says what that means. The recruiter's market report wasn't in your message either, so the POV can't yet depart from its consensus.

The pack's biggest prep item is B1, the question most likely to come up in some form: "You've never sold into rail." The rehearsal is the plain line "I haven't sold into rail," then a ramp plan you can defend, with no past rail work described. Ross's commercial push runs through C1 (no direct quota), C2 (the £4M) and C3 (pricing). The pack treats £4M as influenced revenue only, and it doesn't coach "built" or "owned" for anything you did.

Two things to check before Tuesday:
- Your consulting clients. F1 quotes "so I know the operator world from the other side." If your planning work was for operators, say so. If it wasn't, say who it was for. Deepa may ask.
- How the £4M and the 6-to-40 were counted. Ross's first probe is likely to be the denominator. If you can point to an export or report behind either figure, the pack can treat them as stronger evidence.

Two offers, neither pushed: I can play the Skeptic on B1 as a drill, or save a `tuesday-dossier.md` that records the gaps this prep exposed. A Word version is also available if you want it.

Three questions would sharpen the pack:
1. Can you paste the JD? Without it, the requirements are the recruiter's words or role-family patterns, and the coverage table can't be checked against the posting.
2. Can you paste the market report's headline findings or its shortlist? The POV has to depart from the consensus, and I can't see what the report says.
3. Have you ever shaped pricing or contract terms on a deal, even as an input? Your answer decides whether C3 and F6 are a story or stay a slot with a named limit.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second-round panel, 60 minutes. **Deepa** (VP Partnerships, your future manager) and **Ross** (Commercial Director).
**Format:** first 15 minutes, a spoken point of view on where you would take operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves. The rest is Q&A, and Ross will press on commercials.
**Version:** first version. No JD and no research were available (see Sources).

## How to use

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and only the things you actually did.

| Type | Meaning in this pack |
|---|---|
| EXP | Your own experience, tested for attribution |
| JD | The role's stated or implied requirements |
| CO | Commercial and company-altitude thinking |
| CASE | A live problem, reasoned out loud |

No values round was detected, so there is no values cheat sheet and no VAL questions.

## Prep triage (about 4 hours)

1. **75 min: build and speak the POV.** Section 5. Write one thesis in your own words, speak all three aloud, time it to 15 minutes, twice. Land on the operator outcome.
2. **60 min: commercials under pressure.** B2, C1, C2, C3, D1. Practise the hold-then-concede lines out loud. The £4M answer matters most.
3. **45 min: rail honesty.** B1 and C1. Say the plain acknowledgment and the ramp plan until neither sounds rehearsed.
4. **30 min: your operator-side story.** A3, E1 and fit row F1. Be ready to say who your consulting clients were.
5. **30 min: full run.** Ask for a Pressure drill on C2.

Everything else is insurance.

## Fit snapshot

No JD was supplied, so requirements come from the recruiter's own words (quoted in your message), or from role-family patterns marked [generic]. No row is a hard gate: the material sets no eligibility or location term, and a JD could add one.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "land on what it means for the operators themselves" (recruiter email, quoted in your message) | "bus and light rail network planning, so I know the operator world from the other side" (your message) | medium | [grounded] | presentation | Your material shows planning work on the operator side, in your words: "bus and light rail network planning." The limit to say before anyone asks: that was consulting. "From the other side" does not mean you worked for an operator. Answer slot: if your planning clients were operators, name them; if they were not, say who they were, then stay with the planning. |
| F2 | "our operator partnerships" (recruiter email, quoted in your message) | "running the ISV channel" (your message), "took it from 6 partners to 40" (your message) | medium | [grounded] | none | No gap. Say the two facts in your words. The probe will be on the 6 to 40, so B3 holds the defend-the-number answer. |
| F3 | "sell scheduling software to train operating companies" (your message) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | Words: "I haven't sold into rail." Then the ramp, as a plan and never as a past: which operator conversations you would have first, and what you would learn about their buying cycle. |
| F4 | "carry a direct quota" (role-family, [generic]) | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | Words: "I haven't carried a direct quota." Then what carries over, from F2 and F5, at its own scope. |
| F5 | "own revenue outcomes" (role-family, [generic]) | "roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your material says influenced, not owned. Words stay at that scope: "roughly £4M of influenced revenue." Answer slot: how the influence was counted, and which part was yours, in your words. |
| F6 | "commercial terms and pricing with operators" (role-family, [generic]) | none given | none | [generic] | discovery | Answer slot: if you shaped pricing or terms on any deal, say which and how you decided; if you did not, say so plainly and say how you would find the operator's budget cycle. |

Seven rules from the template, applied: each evidence cell holds only your sentences; the requirement quotes come from the recruiter's email, which you pasted; role-family requirements are unquoted and carry no slot of their own; F3 and F4 are capability because you stated the absence; F6 is discovery because your material is silent.

## Prohibited claims

These are not to be coached, in any cell, under any label.

| Not coached | Basis | Honest form |
|---|---|---|
| Worked on the operator side | Inflated form of F1 | "bus and light rail network planning" at its own scope: consulting work. Your material does not show that you worked for an operator. |
| Built the ISV channel | Inflated form of F2 | "running the ISV channel," and "took it from 6 partners to 40," at their own scope. |
| Owned or carried revenue | Inflated form of F5 and F4 | "roughly £4M of influenced revenue," and "never carried a direct quota." |
| Sold into rail | Negative you stated, F3 | "I haven't sold into rail." No slot. |

## Persona table

Relationship priors: a hiring manager takes Case/Strategist and Skeptic; a senior commercial interviewer takes Pressure and Data-Driven Prober; a panel blends each member's top two. No public profile for either interviewer was available, so weights come from titles and the recruiter's note alone.

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Deepa | A live operator problem over 18 months | High. She is the future manager; the POV is her brief | Clarify first, then the framework aloud once; one metric per stage |
| Skeptic | Deepa | "Which part would you be weakest at on day one?" | High. Your rail gap is the obvious place to probe a hire | Plain acknowledgment, then the ramp as a plan |
| Pressure | Ross | Interrupts on quota and on £4M | High. Commercials are his stated push | Pause, restate, hold two follow-ups, concede specifically |
| Data-Driven Prober | Ross | "How was that counted?" | Medium-high. A commercial director tests the denominator first | Name the weakest assumption before he does |
| Conversational | Deepa | "So, walk me through the journey" | Medium. Easy to underrate; casual questions are scored | A 90-second arc from the quoted sentences only |

## Question banks

### Bank A: Case/Strategist (Deepa, top weight, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What would you need to know about our operators before you proposed anything?" | CASE | [grounded] "where you'd take our operator partnerships over the next 18 months" (recruiter email, quoted in your message) | Clarify, then objective, segmentation, approach, metrics, risks. Name two things to ask first: which operators are the target, and what they measure today. Say the framework aloud once. | The POV's opening move; the brief names the 18 months. Says nothing about your past. |
| A2 | "Take one operator. What does a partnership look like for them in month one, and in month eighteen?" | CASE | [grounded] "where you'd take our operator partnerships over the next 18 months" (recruiter email, quoted in your message) | Build from the operator's side: what they buy, when, and who signs. One metric per stage. No claims about past operators. | The POV's core, tested live. |
| A3 | "What does 'what it means for the operators themselves' mean, in one sentence?" | JD | [grounded] "Please land on what it means for the operators themselves." (recruiter email, quoted in your message) | Lead with the operator's outcome, not our revenue. Then your one operator-side fact: "bus and light rail network planning." Answer slot: if that planning was for operators, say which; if not, say who it was for, then stay with the planning. | F1 is the only operator-side sentence in the material, and the brief asks for exactly this answer. |
| A4 | "Which of our operators would you talk to first, and what would you ask them?" | CASE | [generic] | Name the operators by what they do, then the three questions you would ask about their planning cycle. Say one thing you would not assume. | A live problem; asks nothing about your past. |
| A5 | "A top operator asks for a feature only they need. What do you do?" | CASE | [generic] | Structure: what it costs, what it does to the other operators, whether it is a partnership or a product question. Say no to a bespoke build until you have named the reuse case. | The anti-pick, applied to a live problem. |

### Bank B: Skeptic (Deepa, mid weight, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail. Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" (your message) | **Highest-ROI prep in this pack.** Plain acknowledgment: "I haven't sold into rail." Then the ramp as a plan: which operator conversations first, what you would learn about their buying cycle, who on the team you would lean on. Never describe past rail work. Hold through two follow-ups by returning to the ramp. | The objection most likely to be asked in some form. F3 is the material's gap; B1 is its probe. |
| B2 | "Your figure is influenced revenue. Where in the deal did your work sit?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Say what the influence was, in your words, and what you did not own. Answer slot: if you shaped a deal's terms or closed one, say which and how; if you did not, say so plainly and describe your part. | F5's limit. Premised only on the quote. |
| B3 | "Six partners to forty. What changed in the forty that did not change in the six?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Name the mechanisms you ran, each one you can explain. Answer slot: if you recruited or signed any of them, say which; if growth came from a programme you ran, say what it did. Never claim sole credit, and never say "built." | F2's defend-the-number slot. The probe for a channel role. |

### Bank C: Pressure (Ross, top weight of his, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why hire someone with no quota into a quota role?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Hold: "I haven't carried a direct quota." Then what carries over: "took it from 6 partners to 40." Hold through two follow-ups by returning to the channel work and the ramp. Concede specifically: "The first six months would be a real gap while I learn your deal cycle." Never fold on the channel result. | Ross's quota probe. Hold, then concede. |
| C2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Pause, restate. Name the weakest assumption first: how influence was attributed. Answer slot: if you know the attribution rule, say it; if you do not know how it was counted, say so. Hold the position: it was influenced, not owned. | The defend-the-number slot. Ross will go here first. |
| C3 | "Walk me through how pricing gets set on an operator deal." | CO | [generic] | Answer slot: if you shaped pricing or terms on any deal, say which and how you decided; if not, say so plainly, and say how you would find out the operator's budget cycle. | F6's discovery. The second branch allows that you never did it. |
| C4 | "Operators have fixed budgets. If ours drops 20%, what does the partnership plan cut?" | CASE | [generic] | Structure: what is protected (the outcomes operators pay for), what is cut first (new bespoke partners), what you would measure. Concede: without the plan's figures you would be guessing, so ask for them. | A live commercial problem for a Pressure interviewer. |

### Bank D: Data-Driven Prober (Ross, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What counts as a partner: signed, live, or producing?" | EXP | [grounded] "from 6 partners to 40" (your message) | Say what the figures counted, if you know. If you do not, say so. Name which definition you would defend least. | The denominator behind F2. |
| D2 | "Of the 40, how many produced revenue in the last 12 months?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Answer slot: if you know the producing count, say it and how it was measured; if you do not, say so and say how you would find it. | The probe a prober asks next. Asks for a figure the material does not carry. |
| D3 | "Of that £4M, how much came from partners you added, versus existing ones?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: if you can split it, say how; if you cannot, say the split was not counted, and what you would count first. | F5's second slot, asked by a prober. |
| D4 | "Who sells the operator's scheduling software: us, a partner, or the operator's own team? Defend one." | CASE | [generic] | Structure: pick the answer that fits the operator's buying process, defend it, and name the one case where you would be wrong. | A live partner-model question; asks nothing about your past. |

### Bank E: Conversational (Deepa, low weight, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting" and "9 years in partnerships" (your message) | A 90-second arc, using only the quoted sentences: transport planning, then partnerships, then the ISV channel. Casual questions are scored. | Biography opener. Keep to what your sentences say. |
| E2 | "What have you read about our operators lately?" | CO | [generic] | Name one thing from the report, once you have read it and can speak to it. Answer slot: if you have not read it yet, say what you read to prepare, and nothing more. | Casual, but scored. No claim about the report's contents. |

**Coverage.** 18 questions in total across five banks.

| Requirement (source) | Covered by | Note |
|---|---|---|
| Operator partnerships over 18 months (recruiter email) | A1, A2, A4 | |
| What it means for the operators (recruiter email) | A3, POV section 5 | |
| Rail selling (your message) | B1, C1 | |
| Quota and commercials (recruiter email, Ross) | C1, C2, C3, C4, D3 | |
| Partner growth (your message) | B3, D1, D2 | |
| JD requirements | none, and why: no JD was supplied | Upgrade menu |

## Section 5: the POV (graded deliverable)

Pre-declared by the recruiter: a 15-minute spoken POV, no slides. Its close is what it means for the operators themselves.

**Grounded facts to build on:**
- F1: "bus and light rail network planning, so I know the operator world from the other side" (your message)
- F2: "running the ISV channel" (your message), "took it from 6 partners to 40" (your message)
- F5: "roughly £4M of influenced revenue" (your message)

**Three theses, each with its concession** (all [generic]: these are candidate positions for you to own, not facts about Kelverton):

1. **Start from the operator's planning cycle, not the sale.** Operators' scarce resource is planning capacity, so the partnership should begin where their planning runs.
   *Concession:* planning cycles differ by operator, and you have not sold into any of them. The sequence may be wrong for some.
2. **Build reach through partners already inside operator planning teams.** Consultants and integrators sit where the decisions are; this is the channel logic from F2, applied to a new buyer.
   *Concession:* rail procurement and contracts differ from what you ran at the payments company. The channel model may not transfer as-is.
3. **Measure partnerships by operator outcomes, with influenced revenue as the lagging read.** Planning hours saved and schedule changes handled tell the operator, and the commercial plan, whether the partnership worked.
   *Concession:* operator outcomes are hard to attribute and may land after the 18-month window.

**Differentiation against the consensus answer.** The recruiter's market report is the consensus any prepared candidate has read. This pack has not seen its contents, so the differentiation cannot be written yet (upgrade menu). The anti-pick, which the role warrants: say no to one thing, for example "I would not open new operator partners before the first reference outcome is measured."

**Close:** end on the operator's result over 18 months, in one sentence, before Q&A begins.

## Reading the interviewers

No public profile was available, so this section is absent. Titles only: Deepa is VP Partnerships and your future manager; Ross is Commercial Director. Both are from the recruiter's note.

## Reverse questions

At least five, each with why it lands. None is tied to Deepa's own career path, because no profile was available (upgrade menu).

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a partner-led deal look like in your best operator relationship today?" | It asks for the operator's side of a working deal, which is the POV's question. |
| R2 | "Which operator would you want me in front of first, in the first 90 days?" | It shows you are thinking about the operator, not the pitch. |
| R3 | "How are partnerships counted in the commercial plan today: influenced or owned?" | It sets up the commercials conversation on the company's terms, not yours. |
| R4 | "What did the last partnerships hire get right, and what would you change in their first year?" | It tests what the role will really ask, without asking for a name. |
| R5 | "What would a good first year look like for Ross's commercial plan, in numbers?" | It asks for the measure, so you can work to it. |

## Delivery coaching

Not included: no working-style assessment was provided.

## Prohibited claims check

See the prohibited claims table above. Every bank, slot and reverse question was checked against it.

## Sources

**Provided documents:** your message, including the recruiter's email quoted in it. The recruiter's market report was attached in your email but its text was not in the message, so it is not used anywhere in this pack.

**Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail` values | unavailable | Values cheat sheet, not produced (no values round detected). Query "Kelverton Rail" refused. |
| 2. Kelverton Rail interview process, role family | unavailable | Loop structure and persona weights; no call sent, and the inputs do not fix it. |
| 3. Kelverton Rail strategy and recent news | unavailable | Strategy-grounded CO and CASE questions; query "Kelverton Rail scheduling software train operating companies partnerships" refused. |
| 4. Deepa, VP Partnerships, Kelverton Rail | unavailable | Interviewer read and persona weights; query "Deepa VP Partnerships Kelverton Rail" refused. |
| 5. Representative Senior Partnerships Manager JD | unavailable | Fit snapshot requirements, marked [inferred] rather than [generic]; no call sent, and no JD was supplied. |

Web search was refused by permission in this session, so every research target is unavailable, and no company fact is used. Everything about Kelverton is absent; every requirement is either the recruiter's own words or [generic].

## Upgrade menu

- The job description text → the six fit rows become [grounded] where they reach a requirement, and the requirement coverage table gets its rows
- The market report's headline findings or shortlist → the POV's differentiation section can be written, and the consensus answer gets named
- The interviewers' full names and company → the interviewer read, persona weights for Deepa and Ross, and a reverse question tied to Deepa's path
- Whether you ever shaped pricing or terms on any deal → C3, F6 and the commercial questions move from slot to story, or stay a slot with a named limit
- The export or report behind the £4M and the 6 to 40 → F2 and F5 can move from medium to high, and B2, B3, C2, D1 and D3 get a source to answer from
- Deep research (L2), if search is allowed later → strategy brief, interviewer talks and writing, and role-family loop reports; up to 6 further searches and 2 fetches, and the depth each one adds should be weighed against the time you have
