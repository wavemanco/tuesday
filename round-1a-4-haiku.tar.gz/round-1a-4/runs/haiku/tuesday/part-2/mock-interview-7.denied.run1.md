I have the playbook. Now the L1 research pass: company values, interview process, recent strategy, and the interviewer's public footprint, all in one batch.
All four research searches were refused, so the pack will rest on your message and the JD alone. Saving the pack now.
Your interview prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-2-rooms-case-7-denied-87cc3183/d8bda764-f0d9-4eb2-9972-36abc9ee9998/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md. I built it as a hiring-manager round, since you said Tobias is Head of Live Operations and I'm assuming he's your likely manager.

Web search was refused when I tried it, so the pack has nothing on Saltmarsh's values, interview structure, recent strategy or Tobias's background. Everything in it comes from your message and the JD. If you allow search, I can run that research and add it.

The most important prep is question B1: "This role coordinates four teams on every update. You have never led a team. Why would this go differently for you?" Rehearse it until it sounds plain. Say "I have never led a team," then describe the cross-team work you actually did. If you haven't done any, say so and say how you'd set up the first update. The pack names this as the likeliest hard question.

The pack also flags three places where your material is thin. Your sentences don't show that the puzzle titles were live-service, that you worked across design, art, engineering and community, or that you owned the post-event review. The pack gives you honest answers for each, so you don't have to stretch them.

Would you like me to offer one of these?
- **Mock drill:** I can play the skeptical interviewer on B1 and push back on your answer.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- **Word version:** I can convert the pack to .docx.

Is Tobias your future manager, or a peer on the team? The answer changes how the questions are weighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager (not yet confirmed).
**Round:** Final round, 60 minutes. Loop structure not established; the pack is built for one session with blended persona weights.
**Research:** None. Web search was refused, so company values, process, strategy and the interviewer's public footprint are absent (see Sources).

## How to use this pack

Personas describe how a question arrives. Types describe what it scores:

- **CASE**: a live problem from the role. Structure it aloud.
- **EXP**: your past work. Precision about what was yours is the whole test.
- **JD**: a requirement from the posting. Answer it directly.
- **CO**: company and strategy knowledge. None in this pack, because research did not run.
- **VAL**: published values. None in this pack, because no values round is established.

Guidance is scaffolding, not a script. Rehearse the beats and the honest branches. Do not memorise sentences you cannot repeat under a follow-up.

## Prep triage

Prep time was not stated, so no schedule is set. If you tell me how long you have, I will sort the sections by it.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message. No CV was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | Your material gives four years at a puzzle-game studio and does not say whether those titles were live-service. Bridge in those terms: "For four years I was an associate producer at a puzzle-game studio." Answer slot: if the titles ran live content, say what that involved for you; if they did not, say what you ran live and say where that stops. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Lead with it in your own words. Expect a probe on what you set yourself, which is an answer slot in A4. |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | The quote carries one title. Two titles are not in your material. Bridge at that scope: "For our main title I ran the weekly content-drop calendar." Answer slot: if you planned or ran a second title, say which; if the calendar covered only the main title, say so and say how you would extend it. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | none | The quote reaches retention metrics in role terms. Keep the verb: presented. Whether you built the numbers is not in the material, and that probe is covered in C1 and D2. |
| F5 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination across these four teams. Answer slot: say which of those teams you worked with on an update and what you did with them; if you did not work across them, say so plainly and say how you would set up the first update. |
| F6 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | transferability | Reporting numbers is adjacent to owning a review, and the material does not show ownership. Bridge at the quote's scope only: "I presented the monthly retention numbers to the studio head." Answer slot: if you owned or ran any post-event review, say what you did; if you did not, say so and say what you took from presenting monthly numbers. |
| F7 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Bridge rewords only that quote: "I wrote the release checklist our QA team still uses." Add no sign-off or running of it. Answer slot in C3 and the prohibited list covers the rest. |

Gate rows: none. The JD states no location, visa, schedule or credential term.

Pack observation, in analysis and not as words for you: "never led a team" is not a JD requirement, but the JD's coordination line ("coordinate ... teams") is where a interviewer is likeliest to read it as a leadership question. That is why B1 carries the deepest rehearsal.

## Prohibited claims

Built locally from the fit snapshot. These are not coached in any answer, slot, hold or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the content calendar for two titles | Inflated form of F3 | "I ran the weekly content-drop calendar for our main title for the last two years." |
| Owned the post-event review and its KPIs | Inflated form of F6 | "I presented the monthly retention numbers to the studio head." |
| Managed the release checklist with QA | Inflated form of F7 | "I wrote the release checklist our QA team still uses." |
| Built or computed the retention numbers | Inflated form of F4 | Your material says presented. Say that. |
| Led or managed a team | Negative you stated | Plain acknowledgment: "I have never led a team." |
| Worked on a game with in-app purchases | Negative you stated | Plain acknowledgment: "I have never worked on a game with in-app purchases." |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (weight 35) | A live problem on the calendar or a cross-team update | High. Hiring-manager prior, and the JD is a planning role | Clarify first, then structure. Say the decision aloud |
| Skeptic (weight 30) | "You have never led a team" and the coordination gap | High. The one gap the JD makes visible | Hold the plain acknowledgment, then return to what you did. Rehearse B1 until it is dull |
| Data-Driven Prober (weight 15) | How the retention numbers were counted | Medium. The JD names retention metrics and your material shows presenting, not building | Say what you know. Say "I don't know" where true |
| Pressure (weight 10) | A time-boxed challenge on leadership or attribution | Medium. Final rounds sometimes add one sharper interviewer | Pause, restate, hold through two follow-ups |
| Conversational (weight 10) | A casual opener and a casual JD question | Low to medium. Casual questions are still scored | A 90-second arc from your own sentences |

The weights come from the hiring-manager prior only. No interviewer signals, loop structure or values round were available to adjust them.

## Question banks

### A. Case / Strategist (5 questions, highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two of your titles are down on day-14 retention after a seasonal event. Walk me through how you'd plan the next event calendar." | CASE | [generic] | Clarify first: which title, down against what baseline, and what the event was meant to do. Then objective, the player segments it touches, cadence, and the metrics you would read first. Speakable in 90 seconds | A live problem on the JD's calendar line. It presupposes nothing about your past, so no story is mapped |
| A2 | "A design-led update is two weeks out and engineering says it needs a week more. What do you do?" | CASE | [generic] JD line: "coordinate design, art, engineering and community teams on each update" | Find out what the extra week protects and what it displaces. Then decide what the calendar moves, what ships without it, and who you tell first. State the decision and why | The JD's coordination line, asked as a decision. This is the hardest part to rehearse from record, so it is rehearsed as a decision |
| A3 | "What would you need to know before you planned the calendar for two titles you have not played before?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" | List inputs: the current backlog, release cadence, QA capacity, the KPI each title reports, and what community has already promised. No claim about your past | The JD's multi-title line, which F3 cannot yet cover with your own evidence |
| A4 | "Walk me through the content calendar you ran." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F2: the weekly content-drop calendar, the main title, two years. Tell it in your own words. Answer slot: if you set the cadence or chose what went into each drop, say how you decided; if you did not, say so plainly and describe how the calendar was set | F2 is the requirement's evidence and the likeliest opening. EXP because it tests what was yours |
| A5 | "How would you run that calendar across two titles instead of one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold to the one title you ran. Answer slot: if you planned or ran a second title's schedule, say which and what you did; if you did not, say what you would keep the same and what you would change for a second title | F3's transferability. The second title is in the JD and not in your sentence |

### B. Skeptic (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates four teams on every update. You have never led a team. Why would this go differently for you?" | JD | [grounded] "Never led a team" (your message); [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | **Highest-ROI prep in this pack.** Hold: "I have never led a team." Then separate coordinating from leading and answer with what you did. Answer slot: if you coordinated across functions on any update, say which teams and what you did; if you did not, say so plainly and say how you would set up the first cross-team update. Hold through two follow-ups by returning to what you did, never by adding to it. If pressed, concede plainly that leading and coordinating are different | The most predictable objection to you. F5 is where the material is silent, and this is the likeliest probe |
| B2 | "Which of design, art, engineering and community have you actually worked with on an update?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Answer slot: name each team you worked with on an update and what you did with them. If you did not work with one, say that. If you did not coordinate across any of them, say so plainly | F5 discovery. The JD line is the raising source |
| B3 | "You have spent four years at a puzzle-game studio. Which of that carries over to a live-service title, and which does not?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); [grounded] "never worked on a game with in-app purchases." (your message) | Answer slot: say what you ran live and how, in your own words; if the puzzle titles did not run live content, say so and say which skills transfer. If asked directly about in-app purchases, say: "I have never worked on a game with in-app purchases." | F1's transferability. The live-service line is the JD's own requirement |
| B4 | "The role owns the post-event review and the KPIs it reports. Which part of that have you done?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold to what you presented: "I presented the monthly retention numbers to the studio head." Answer slot: if you owned or ran any post-event review, say what you did; if you did not, say so plainly and say what you took from presenting monthly numbers | F6 is low confidence, and your sentence is reporting, not ownership. The question's premise is the JD's, and its second branch allows it to be false |

### C. Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how those retention numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: if you built or checked the count, say which steps and what you checked; if someone else produced the numbers, say who and what you verified before you presented them; if you do not know how they were counted, say that | F4 is covered. The JD's retention line raises this probe. No figure is given, so the slot is about attribution |
| C2 | "Which assumption behind a retention number would you defend least?" | EXP | [generic] | Name an assumption only if you know one. If you do not, say you do not know how the figure was counted, and say what you would check first | A persona stem. It makes no claim about your past |
| C3 | "You wrote the release checklist. Which part would you change first, and why?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Story-mapped on F7: you wrote it, and QA still uses it. Pick one step you would change and say why in your own words. Answer slot: if you have changed it since, say what changed and who agreed; if you have not seen a reason to change it, say so | F7's presentation. It is also the only written artifact in your material, which bears on clear written communication |

### D. Pressure (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone who has never led a team for this role?" | JD | [grounded] "Never led a team" (your message) | Pause and restate the question in your own words. Hold: "I have never led a team." Then give the coordination case in terms of what you did. If you have nothing to point to, say so and stay with what you did. Hold through two follow-ups before conceding anything; concede plainly that you have not led a team, and do not fold on what you did | The Pressure version of B1. Hold, then concede the specific point |
| D2 | "Of the monthly retention numbers you presented, how much was your own work?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold to the sentence: you presented them. Say what you did with them and what you did not. Answer slot: if you built any part of them, say which part. Never fold on what you did present | An attribution probe on F4. The hold stays at "presented" |

### E. Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message); [grounded] "Wrote the release checklist our QA team still uses." (your message); [grounded] "Presented the monthly retention numbers to the studio head." (your message) | A 90-second arc through these four sentences, in this order, with one line on why this role. Add no step between them | The arc is F1, F2, F7 and F4. It needs no claim beyond them |
| E2 | "What does a good live-events calendar look like to you?" | JD | [generic] | Give a short view: cadence, a named owner for each update, the KPI each event is judged on, and the post-event read. Keep it to what you would do, not what you have done | The JD's calendar line asked casually. Casual questions are still scored |

Session total: 16 questions. That is under the roughly 18 the coverage rule prefers. Adding more would pad the pack, and the thin areas are thin in your material, not in the banks.

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| 3+ years producing live-service games or apps | B3, with the F1 answer slot |
| Plan and run the live-events calendar for two of our mobile titles | A1, A3, A5 |
| Coordinate design, art, engineering and community teams on each update | A2, B1, B2 |
| Own the post-event review and the KPIs it reports | B4 |
| Manage the release checklist with QA | C3 |
| Experience running a content calendar | A4 |
| Comfortable with player-retention metrics | C1, C2, D2 |
| Clear written communication | C3, partly. No written exercise is established, so this row is covered only by your checklist |

## Reverse questions

Each one is for you to ask. Why it lands is the reason to ask it.

1. "What does success look like for these two titles at the end of the first six months?" Why it lands: it shows you treat KPIs as the job, and it reveals how they will score you.
2. "How are design, art, engineering and community kept in step on an update today?" Why it lands: it tests the coordination line directly and shows you are asking about process, not only about the role.
3. "Who owns the release checklist today, and how does QA sign-off work?" Why it lands: it shows you know the checklist exists and tests whether it still matches their process.
4. "Which KPIs does the post-event review report to leadership, and how often?" Why it lands: it asks about the ownership line in the JD, and it signals you are ready to own it.
5. "What would the first ninety days look like for the person in this role?" Why it lands: it opens a planning conversation and gives you the interviewer's own picture of the job.

No interviewer-path reverse question is included, because no public profile was available to research.

## Sources

**Provided documents:** your message, which contains the JD text and your background. Read in full.

**Research calls sent, all refused:**
- "Saltmarsh Games values". Refused.
- "Saltmarsh Games interview process live operations producer". Refused.
- "Saltmarsh Games mobile studio strategy news". Refused.
- "Tobias Wrenfield Saltmarsh Games". Refused.

No fetches were sent.

**Research tier:** L1, searches 4 of 6, fetches 0 of 2. All four searches were refused, so no result was used.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, section 10. Not included: no values round is established, so the section's condition fails either way |
| 2. Saltmarsh Games interview process | unavailable | Loop structure. Persona weights fall back to the hiring-manager prior, with no loop source |
| 3. Saltmarsh Games strategy and news | unavailable | The CO bank, and any strategy-based CASE question. None is in this pack |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | The interviewer read, persona adjustments, and a reverse question tied to his path. None is in this pack |
| 5. Representative JD for this title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission for web search → company values, the interview loop, recent strategy and Tobias's public footprint. Those would add a values round if one exists, a CO bank, adjusted persona weights and a reverse question tied to his path. A deeper research pass (up to 6 more searches and 2 more fetches, several minutes) is available once search is allowed.
- Your release checklist, as a shareable copy or an outline of its sections → F7 and F4 bridges gain a real artifact to point to, and F4 can move from medium toward high.
- Any live-service title you worked on, or a line on whether the puzzle titles ran live events → F1 moves from an answer slot to a grounded line.
- The retention deck, or its outline → C1 and D2 get the specifics you can stand behind.
- The recruiter's note on what the final covers, and any written or deck exercise → a graded deliverable section, and loop-mode mini-packs if the final has several sessions.
- Tobias's public profile or talk, if you want to share it → the interviewer read, and a reverse question tied to his career path.
- How much prep time you have before Friday → a prioritised triage section.
