Your prep pack is saved at `/var/tmp/tuesday-measure/1a4/runs/haiku/tuesday/part-2/rooms/case-4-denied-f8ea7b07/Quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a hiring-manager round from the dossier you pasted. Web search was refused in this session, so the pack has no Quartzline values, interview structure or strategy. Those are absent, not guessed.

Say the word and I'll play the Skeptic on A2, the objection the dossier flagged as the highest-return prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: hiring-manager conversation, 45 minutes, Thursday 2026-11-26. Interviewer: not named.
Built from: the underwriting dossier you pasted (dossier_version 1.1, generated 2026-08-14). Company research did not run: all three searches were refused (see Sources).

## How to use

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script.

Type key: **VAL** behavioral or values alignment. **EXP** what you actually did in past work. **JD** the role's stated responsibilities and qualifications. **CO** company strategy knowledge. **CASE** a live problem from the role. Each row lists one primary type; a dual call is explained in its rationale.

## Persona weights

| Persona | Weight | Questions | How it shows up here | Why this weight |
|---|---|---|---|---|
| Skeptic | top | A1 to A5 | Gaps: roadmap ownership, PM title, agile delivery | Hiring-manager prior: they are buying capability and derisking gaps. The dossier's likeliest objection lives here |
| Case/Strategist | top | B1 to B4 | Live problems on partner APIs, adoption, squad order | Hiring-manager prior: expect live problems on their roadmap |
| Data-Driven Prober | mid | C1 to C3 | The "30+" count, the playbook's use, what the roadmap sessions changed | Medium-confidence claims draw probes; the headline figure is the magnet |
| Pressure | mid | D1 to D3 | Holding the PM-title objection under time limits | Stress-testing composure on the one objection that matters |
| Conversational | low | E1 to E2 | The opener, and one casual question on API platforms | Casual questions are still scored |
| Peer Evaluator | low | F1 to F2 | Seams with the two engineering squads | Peer-register probes on the squad-authority question |

Not weighted: Values/Behavioral. No values-style round is detected, and no loop source established the loop, so the archetype fallback is Generic, which reads `no` for a values round. Weights rest on the relationship prior alone; no round structure is assumed.

## Prep triage

Not included: prep time was not stated, so no schedule is built. Everything below is the pack.

## Fit snapshot

Evidence key for the dossier's verified claims: **E1** is `verified_candidate_evidence` entry 1, **E2** entry 2, **E3** entry 3, in the dossier's order. Requirement text is the dossier's `role_profile`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier E3 | low | [grounded] | transferability | Adjacent work only: integration leadership, plus input into product. The limit, as the pack's own observation: this is not product management held as a title. Say the quoted work at its own scope. Any wider step is an answer slot inside that scope (A2, C3) |
| F2 | "Owning a roadmap and prioritization authority (R1 sub-claim)" — dossier uncertain_or_weak_areas | none given | none | [grounded] | capability | The dossier records this as a capability gap with the strategy acknowledge_gap. Plain acknowledgment, sourced to that field: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then how you would learn it, said as a plan. Never a bridge here |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | high | [grounded] | transferability | Integrations delivered on a platform's APIs, for clients. The limit: the quote says integrations, not a platform product you shipped. Say what you delivered at the quote's scope (A3). This row is this pack's reading; the dossier did not flag R2 |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Wrote the internal integration playbook her team uses" — dossier E2 | high | [grounded] | discovery | The playbook is inspectable (the dossier notes it was provided). Whether it covered API docs or schemas is not shown. Answer slot: if it covered them, say which; if it did not, say so plainly and say what you would check first (C2) |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier E3 | medium | [grounded] | transferability | Client-side stakeholder work. Caveat on E3: confirmed, limited inspectable proof, expect a probe. No quote shows engineering or sales. Answer slot: if you worked with either on an integration, say who and what you did; if not, say so and describe the client side (A5, F2) |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | Clarify strategy: no verified claim speaks to it, so the cell is an answer slot only. Here is what I would want to confirm about how you define agile delivery. If you ran sprints or a comparable cadence, say which and for what; if you never worked that way, say so plainly and describe how you did delivery (A4) |

Gate rows: none. The dossier lists no hard gates and no severe red flags.

## Prohibited claims

Not coached in any cell of this pack. Sourced entries carry the dossier's own wording, quoted whole. Inflated-form entries are built here from the quotes.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier prohibited_claims: "Having held a product manager title or role" | Plain acknowledgment, sourced to that field: "I haven't held a product manager title or role." Integration work is named as adjacent, never as the title |
| Having owned a product roadmap | dossier prohibited_claims: "Having owned a product roadmap" and acknowledge_gap | Plain acknowledgment, sourced to those fields: "I haven't owned a product roadmap." No slot |
| Having set prioritization for an engineering squad | dossier prohibited_claims: "Having set prioritization for an engineering squad" | Plain acknowledgment, sourced to that field: "I haven't set prioritization for an engineering squad." No slot |
| Owns the partner API roadmap, or drove product decisions from the roadmap sessions | Inflated form of E3 | E3 at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." The limit is the pack's observation, not a first-person negative: the material says feeding evidence, not deciding. C3 and D2 stay inside that scope |
| Shipped API or platform products | Inflated form of E1 | E1 at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs." The limit is the pack's observation: the quote says integrations for clients |
| Wrote the API docs and schemas | Inflated form of E2 | E2 at its own scope: "Wrote the internal integration playbook her team uses." The playbook's contents are not in the material |

## Question banks

Session totals: 19 questions, within the 18 to 26 range. Each row's Provenance quotes every candidate sentence its guidance rests on. Requirement coverage: R1 covered by A1, A2, D1; R2 by A3; R3 by C2; R4 by A5, F1, F2; R5 by A4. VAL is not used: no values-style round detected. CO is not used: no strategy research ran.

### A. Skeptic (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] dossier acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)"; dossier prohibited_claims: "Having owned a product roadmap" | Name the roadmap and prioritization plainly as the weakest part: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then say how you would learn it, as a plan: how you would learn the two squads' planning before you set anything. Do not describe any past | F2 is the one gap the dossier says to acknowledge; this is the role's own responsibility asked as a day-one question |
| A2 | "You have never held the PM title or owned a roadmap. Why hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3); dossier prohibited_claims: "Having held a product manager title or role", "Having owned a product roadmap" | The highest-ROI rehearsal. Hold: name the work you can speak to, in its quoted words: "I led 30+ end-to-end client integrations" and "I ran quarterly roadmap-input sessions feeding client evidence to product." Concede the core claim explicitly: "You're right that I haven't held the title or owned a roadmap." Then the closing plan from A1. Hold through two follow-ups by returning to the quoted work, never adding to it | The dossier named this objection; it is the likeliest form of the F1 and F2 gap. Deepest rehearsal: three follow-up levels |
| A3 | "Tell me about a product on an API platform you've shipped." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Open prompt. Story-map on E1: the integrations you led, through the five stages the quote names, in your own words. Answer slot: if no platform product of yours comes to mind, say so plainly, then give the nearest thing the quote carries: the integrations, at their own scope | F3: the JD asks for shipping, and the quote carries integrations; expect a probe on the difference |
| A4 | "How do you define agile delivery, and where have you practised it?" | JD | [generic] no quote speaks to agile delivery; the requirement is the dossier's R5 | Clarify strategy, no story. Answer slot: here is what I would want to confirm about how you define agile delivery. If you ran sprints or a comparable cadence, say which and for what; if you never worked that way, say so plainly and describe how you did delivery | F6: discovery, low. Clarify is the only strategy the dossier allows here |
| A5 | "Engineering and sales both sit in this role's stakeholder list. Tell me about a time you handled a conflict between them." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Open prompt. Story-map on the client side of E1: the requirements and UAT stages, in your own words. Answer slot: if you worked between engineering and sales on any integration, say who and what you did; if not, say so plainly and tell the nearest thing the quote carries | F5: transferability. Stakeholder management is asked across engineering and sales; the quote is client-side only |

### B. Case/Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner says their integration fails at the same authentication step every week. What do you need to know before you propose a fix?" | CASE | [generic] | Clarify first: which partners, since when, what changed. Then objective, segmentation by partner size and integration type, the approach (reproduce, triage, decide who owns the fix), metrics, and risks. Think aloud; challenge one premise respectfully | A live problem from the role's partner-facing platform. It asks for no claim about your past |
| B2 | "Sketch how you would decide whether to deprecate an endpoint partners still use." | CASE | [generic] | Clarify who uses it and how much. Then the cost to partners, the migration path, a deprecation window with a metric to watch, and the risk of losing a large partner. Name what you would need from the squad leads | Tests the role's roadmap judgment without assuming you have made that call before |
| B3 | "How would you tell whether partner API adoption is healthy?" | CASE | [generic] | Name an adoption metric, its denominator, and what counts as an active partner. Say that you do not yet know today's baseline and would ask for it before setting a target | The dossier names adoption as a responsibility with no baseline stated; this question tests the same unknown in a case form |
| B4 | "Two squads and a partner request land in the same week. Who decides the order?" | CASE | [generic] | First confirm the decision rights: who owns the roadmap call, and where the squad leads' authority stops. Propose a principle (customer impact, commitments already made, effort), and say how you would escalate. Do not claim you have made such a call | The dossier's squad-authority unknown, asked as a live problem; the answer is the question the role itself needs answered |

### C. Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the 30+ integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Defend the number: say what counted as an integration, where the count came from, what it is sensitive to, the assumption you would defend least, and which of them you led end to end. Answer slot: if you kept a count, say how; if the figure is an estimate, say so; if any were not yours to lead, say which | F3's headline figure; probers test how a figure was counted, and E1 is the high-confidence quote |
| C2 | "The playbook your team uses: how do you know it's in use, and does it cover schemas?" | JD | [grounded] "Wrote the internal integration playbook her team uses" (dossier E2) | Say what the playbook covers and how you know it is used, in those words. Answer slot: if it covered API docs or schemas, say how; if it did not, say so plainly and say what you would check first | F4: discovery on R3. Schemas come from the JD's own line, which the dossier supplies |
| C3 | "What did product do with the evidence you fed in through those sessions?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3; confidence medium, expect a probe) | Say what you fed in, in the quote's words. Answer slot: if you can trace a change to it, name the change and your part in it; if you cannot, or no change came from it, say so plainly. Name the caveat before it is extracted: the sessions are confirmed, with little inspectable proof | E3 is the medium-confidence claim; this is the probe it invites |

### D. Pressure (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we bet on integration leadership over a PM who has done the job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1); dossier prohibited_claims: "Having held a product manager title or role" | Pause and restate the question. Hold through two follow-ups on the quoted work: "I led 30+ end-to-end client integrations." Concede the core claim specifically: "I haven't held the PM title." Do not fold on the integration work | The pressure form of the A2 objection. Hold-then-concede on the one position the quotes carry |
| D2 | "Quarterly sessions feeding evidence to product: did any of what product built come from your input?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3) | Hold on the scope of E3: say what you fed in. Answer slot: if any of it reached what product built, say which and how; if none of it did, say so plainly and stay with what you fed in. Concede the limit, not the scope | E3 under time pressure; the second follow-up is where a held claim breaks |
| D3 | "Name two of those 30+ integrations you led end to end, and say what each one needed from you." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Time-boxed: two integrations in one sentence each. Say what each needed from you, in the quote's stages. Answer slot: if you cannot name two, say so plainly and name the one you remember best | Tests whether the verb "led" survives a specific request; time-boxed |

### E. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1); "Wrote the internal integration playbook her team uses" (dossier E2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3) | A 90-second arc in the order E1, E2, E3. Do not mention the PM title in the arc, and say what you want to do next. Keep it to the quoted claims | Casual openers are scored. The arc is the story the three quotes carry, nothing more |
| E2 | "What are you playing with in API platforms these days?" | JD | [generic] | Name the API platform or documentation tool you have actually used, if any. Answer slot: if you have used one, name it and what you did with it; if you have not, say so plainly and name how you would start | A casual touch on the R3 plus, asked as if it were not scored |

### F. Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our squads sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles (who sets scope, how a disagreement escalates, how commitments are logged) rather than pretending to know the seam. Say what you would bring to their teams, not only what you need | Peer-register version of the squad-authority unknown; reciprocity framing |
| F2 | "How do you handle credit when integration work spans teams?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Story-map the stages the quote names, in your own words. Answer slot: if architecture or any other stage was someone else's, say so and what your part was; if all of them were yours, say which | F5: the credit probe on the engineering-facing stages the quote does not show |

## Reverse questions

Each has a "why it lands". Two come straight from the dossier's employer questions and risks.

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: it is the dossier's squad-authority unknown, asked as diligence, and the answer tells you the real decision rights before you accept.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: the dossier's adoption-baseline unknown. You cannot judge a target without a starting number.
3. "What would a good first 90 days look like for someone coming from integration work rather than a PM track?" Why it lands: it turns A1's ramp into a plan they can react to, and shows whether the role has a ramp at all.
4. "How do the two squads' planning cycles interact with partner commitments?" Why it lands: it tests the seam F1 describes and shows you know the platform has two squads.
5. "What would make you say, six months in, that this hire was the right call?" Why it lands: it gets the measurable bar in their own words, which you can plan against.

## Sources

- **Provided:** the pasted dossier, dossier_version 1.1, generated 2026-08-14, about 14 weeks before this pack. Consumed sections: `role_profile` (requirement lines R1 to R5, and unknowns), `decision` (context only), `handoff_to_mock_interview` (verified evidence E1 to E3, uncertain areas, likely objection, risks, employer questions, prohibited claims). Not in the paste: `evidence_map`, `evidence_state`, `risk_register`. The dossier's two open unknowns, squad authority and adoption baseline, may have moved since August.
- **Searches sent, all refused by the host:**
  - "Quartzline values": refused
  - "Quartzline interview process product manager platform APIs": refused
  - "Quartzline strategy news 2026": refused
- **Research tier: L1, searches 3 of 6, fetches 0 of 2.** No company values, loop structure or strategy is in this pack. None of it is taken from memory.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet, and VAL questions. Refused, so the cheat sheet is absent |
| 2. Quartzline interview process | unavailable | Loop structure and round-specific persona weights. Refused, so the weights rest on the relationship prior alone |
| 3. Quartzline strategy / recent news | unavailable | Grounding brief and CO bank. Refused, so neither is in the pack |
| 4. Interviewer name with company | n/a | No interviewer name was given |
| 5. Representative JD | skipped | The dossier's role_profile fixes the requirement lines |

Sections dropped on their conditions: prep triage (no prep time stated), values cheat sheet (no values-style round detected), grounding brief (no strategy research), reading the interviewer (no interviewer information), graded deliverables (none declared), delivery coaching (no assessment provided).

## Upgrade menu

- The Thursday session's invitation, or the recruiter's note on the process → confirms whether this is the only session and whether a case or exercise is planned, and replaces the relationship-prior persona weights with round-specific ones.
- The interviewer's name → a tailored reverse question, and persona weights from their public professional footprint.
- Working web search, in a later session → Quartzline's values, interview process and strategy → a grounded values sheet, a loop structure, and a CO bank for the strategy questions. Nothing is run until you ask.
- A newer dossier, generated after your recent conversations → answers to the squad-authority and adoption-baseline unknowns, if they have moved since August.
- Your CV → the three dossier quotes (E1 to E3) checked against the document itself before Thursday.
- How many hours you have before Thursday → a prep schedule in the order the pack's rows matter most.
