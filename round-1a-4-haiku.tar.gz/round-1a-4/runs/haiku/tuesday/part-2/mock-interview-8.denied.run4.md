Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-2-rooms-case-8-denied-a6f9c563/734eea57-fc02-49fa-83df-2ffb2561907b/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as one pack with three mini-packs, one per round, since you gave the schedule. I haven't run any drills yet, so the pack comes first.

The highest-return prep is C1: "Your experience is branch-level, and this role covers the contact centre as well. Why should we believe you can lead it?" Your material shows a branch complaints log and no contact-centre work. The answer holds on the log, concedes the contact-centre gap plainly, and then gives a 30-day plan. It gets three follow-up levels of rehearsal.

The other main gap is presenting to senior leaders. You've said you've never presented above regional level, so the pack gives that back as your own words, plus a plan rather than a claim.

None of the four values has a finished story in your material, so the values answers are scaffolds with an honest "say so plainly" branch. I didn't invent stories to fill them.

Things to check before you rely on the pack:
- I didn't search or fetch anything. The strategy figures are as you relayed them, not checked against the published brief.
- The logistics questions (pay, notice, location, reason for leaving) are slots for you to fill in your own words. Your material doesn't give those answers, so the pack doesn't either.

Say the word and I'll play the Skeptic on C1 as the first drill. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Loop mode: three rounds on 3 December 2026. Shared fit snapshot and prohibited list first, then one mini-pack per round.

| Round | Length | Who | Persona weights |
|---|---|---|---|
| 1 | 30 min | Recruiter | Conversational (top), Skeptic (light) |
| 2 | 45 min | Head of Member Services, your future manager, mostly behavioural | Values/Behavioral (top), Skeptic, Pressure |
| 3 | 60 min | Panel of two branch managers, including a 20-minute complaint-escalation case; scored against the four values | Values/Behavioral (top), Case/Strategist, Peer Evaluator, Data-Driven Prober |

Interviewers beyond the recruiter are not yet named, so persona weights follow the round, not a person.

## How to use this pack and the type key

Personas describe how a question arrives. Types describe what is being scored:

- **JD**: a requirement from the job description
- **EXP**: what you actually did
- **VAL**: the four published values
- **CO**: Ashgrove's own strategy and direction
- **CASE**: a live problem, with no claim about your past

Guidance is scaffolding, not a script. Every answer is in your own words, and rehearses only what you did.

## Fit snapshot (shared across rounds)

Quotes come from the job description (JD), your message, the values as copied from ashgrovecu.org this morning, and the strategy brief as you summarised it.

No JD requirement is a gate under the evidence conventions, so no row is a gate and the pack asks you nothing.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD, branch half) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | For the branch, I handled the formal complaints log. Your material shows one branch's log, not the process end to end. Answer slot: if you set steps of the process across more than one branch, say which and how you decided; if you did not, say so plainly and stay with the branch log. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (JD, contact-centre half) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan, never as a past. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | "I built the monthly complaints spreadsheet our regional manager uses." Your material does not say what the spreadsheet counted. Volumes and resolution times are the JD's words, so any probe on them goes to the answer slots in A2 and H1. |
| F4 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | "I trained new tellers on our escalation script." That is adjacent work: training tellers, not coaching supervisors. Your material does not show coaching supervisors, so do not claim it. |
| F5 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Answer slot: if you have worked with a digital team on a customer journey, say which and what your part was; if you have not, say so plainly and say how you would start. |
| F6 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | Your quote carries it: "6 years in retail banking." A length requirement is not a gate; it is met on fit. |
| F7 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Adjacent work: formal complaints. Your material does not say the log was regulated. Answer slot: if the log carried regulatory deadlines or rules, say which; if it did not, say so plainly. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Words: "I've never presented to anyone above regional level." Then a plan for how you would prepare, as a plan and never as a past. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | "I built the monthly complaints spreadsheet our regional manager uses." Your material does not name the tool. Say which tool it was, in your own words. |

## Prohibited claims

Built locally from the fit snapshot, before any bank was written. These are the claims a candidate reaches for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 | F1's quote at its own scope. Your material describes the branch's log; that limit is this pack's observation, not words for you. |
| Worked in or ran a contact centre | Negative you stated, F2 | "I've never worked in a contact centre." No answer slot. |
| Presented to senior leaders | Negative you stated, F8 | "I've never presented to anyone above regional level." No answer slot. |
| Reported complaint volumes and resolution times to senior leaders | Inflated form of F3 | F3's quote at its scope: the regional manager uses the spreadsheet. |
| Coached branch supervisors | Inflated form of F4 | "I trained new tellers on our escalation script." |
| Handled regulated complaints | Inflated form of F7 | "I handled the branch's formal complaints log." |
| Used Excel | Inflated form of F9 | The spreadsheet quote. Your material does not name the tool. |

## Grounding brief

Ashgrove's current position, as you summarised the July 2026 strategy brief. These are your figures, not checked against the brief itself, so check them before you quote a number.

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- Main competitive pressure: app-only banks.

Use the vocabulary in the brief's own terms. Do not claim you know more about the plan than the brief says.

## Values cheat sheet (Round 3 panel)

The panel scores against the four values, so the values-style round is detected. None of your sentences carries a finished story for any value, so each row is a selection scaffold with its honest branch.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries it. Scaffold: pick a time you chose the member's side over the procedure or a branch number. If none comes to mind, say so plainly, then give the nearest thing the log carries. Question B6. |
| Plain Words | If a member needs it explained twice, the wording was wrong | Your quote: "trained new tellers on our escalation script" (F4). Scaffold: how you taught the script. If you have no time where a member needed it explained twice, say so plainly. Question B7. |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries it. Scaffold: a time a number and a community pulled apart. If none comes to mind, say so plainly, and say only what you know from your own experience. Question B4. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Your quote: "I handled the branch's formal complaints log" (F1). Scaffold: a complaint you stayed with from first contact to close. If none comes to mind, say so plainly, then give the log's nearest instance. Questions B2 and B5. |

---

## Round 1: recruiter screen (30 min)

Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly opener, a casual question on the JD's topics, then logistics | Top weight. A recruiter screen is priced on logistics and motivation, in a friendly register | Practise a 90-second arc; treat casual questions as scored |
| Skeptic (light) | "Why leave, why here, why now" | Light weight. One question, on motivation | Say your reason in one sentence, then what you want next |

Questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script" (your message) | A 90-second arc using only those beats: six years in retail banking, the last three as a branch supervisor, the formal complaints log, and training tellers on the escalation script. Add nothing. | F6 and F4 are the arc's spine. A casual opener is scored. |
| A2 | "What's the reporting side of your work like?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Name the spreadsheet in your own words and who uses it. Answer slot: if it carried volumes or resolution times, say how each was counted; if it did not, say so plainly. | F3 and F9. A hot JD topic asked casually. |
| A3 | "What drew you to a member-owned credit union?" | VAL | [grounded] "member-owned" (the JD) | Say your reason in your own words. The material gives none, so do not invent one. If a reason comes from your six years in retail banking, say it in your own words. | The JD names the member-owned model; this is motivation, scored casually. |
| A4 | Pay (logistics slot) | JD | [generic] | Instruction: give your own number or range, or ask for the role's band first. Do not name a figure you have not decided. | Logistics slot under the recruiter rule. Your pay expectation is not in your material, so the slot is yours to fill. |
| A5 | Notice (logistics slot) | JD | [generic] | Instruction: give your actual notice period in your own words. | Logistics slot. Your notice is not in your material. |
| A6 | Location and working pattern (logistics slot) | JD | [generic] | Instruction: say the working pattern you can actually do. If the role's pattern is unclear to you, ask for it before you answer. | Logistics slot. Not in your material. |
| A7 | "What do you know about where we're taking member service?" | CO | [grounded] "move 40% of member service to digital channels by 2028"; "consolidate eight branches into five hubs over 2027" (strategy brief as you relayed it) | Name the 40% digital target and the 2027 hub consolidation in the brief's terms. Say what the digital shift could mean for how members raise complaints, in your own words. Do not claim knowledge beyond what you were sent. | The current-strategy question. The brief is provided, so the answer is grounded in it. |
| C4 | "Why are you looking to leave your branch role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Instruction: give your actual reason in one sentence, in your own words, then what you want next. The reason, not a complaint about your branch. The material does not state a reason, so the slot is yours. | Motivation consistency, the Skeptic's question. Logistics slot. |

Reverse questions (Round 1)

1. "What does a strong first six months look like in this role?" Why it lands: gives you a success test you can meet, and the recruiter will know what to report.
2. "What reporting does the regional manager rely on each month?" Why it lands: shows you have read the role's reporting line.

---

## Round 2: Head of Member Services (45 min, your future manager)

Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario prompts mapped to the four values; STAR-shaped stories | Top weight. The round is mostly behavioural, and the manager will score values through it | Pick one story per value; say "we" for context and "I" for contribution |
| Skeptic | Probes the gaps: contact centre, senior presentation, digital | Middle weight. The manager is buying capability and derisking gaps | Concede the stated gaps plainly; bridge only from what you did |
| Pressure | Time-boxes, challenges "how much was actually you" | Low weight. Tests composure | Pause, restate, hold two follow-ups, then concede specifically |

Questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you decided something from the member's side of the counter when the procedure said otherwise." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Scaffold: pick a decision where the member's side changed the outcome. It needs a named procedure, your decision, and what the member got. If none comes to mind, say so plainly, then describe the nearest thing the log does carry, in your own words. | Members First. F1 is the closest evidence, and it does not carry a decision, so the honest branch is needed. |
| B2 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Scaffold: pick a complaint you stayed with from first contact to close. Name the open point you kept and what closed it. If none comes to mind, say so plainly, then give the log's nearest instance. | Own the Fix, the second value. F1. |
| B3 | "Tell me about a time a member needed something explained twice, and how you handled it." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Scaffold: if you have explained the escalation script to someone twice, say how the second time differed. If not, say so plainly, then describe how you taught the script to new tellers. | Plain Words. F4 carries training, not supervisor coaching, so the scope stays at the quote. |
| B4 | "Tell me about a time a branch's target pulled against what its town needed." | VAL | [grounded] "Neighbours, Not Numbers: every branch is part of its town" (the values page) | Scaffold: pick a time a number and a community pulled apart. If none comes to mind, say so plainly, and say only what you know from your own experience. | Neighbours, Not Numbers. No quoted sentence carries a story, so the honest branch is the answer. |
| C1 | "Your experience is branch-level, and this role covers the contact centre as well. Why should we believe you can lead it?" | JD | [grounded] "I handled the branch's formal complaints log" (your message); "Never worked in a contact centre" (your message) | The highest-ROI prep in the pack. Hold: say what the log covered and how you ran your part of it, and come back to the log through two follow-ups. Concede: "I've never worked in a contact centre." Then the plan: how you would learn the contact centre's handoffs in your first thirty days. Never fold into "I can lead it" as a past claim. Deepest rehearsal: three follow-up levels. | F1 and F2 are the biggest gap, and this objection is the most likely in some form. |
| C2 | "The role asks for confidence presenting to senior leaders, and you've never presented above regional level. What would you do?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan for your first senior presentation. No claim about past presentations. | F8. A stated negative, so it is given back as your own words. |
| C3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "work with digital teams on self-service journeys" (the JD) | Answer slot: name the requirement you have least of and what you would do first. For digital teams: if you have worked with one on a customer journey, say which and your part; if not, say so plainly and say how you would start. | F5, discovery. The Skeptic's classic question. |
| D1 | "Sixty seconds: what would you do in the first ninety days?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Pause, restate the question, anchor in what you stated, and give a 90-day plan. Hold through two follow-ups. | Pressure. The plan is the answer; the past is an anchor, not a claim. |
| D2 | "That formal complaints log: how much of it was actually you?" | JD, EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Hold, then concede. Say what your part was, in your words. Hold through two follow-ups by returning to your part. Concede specifically what was not yours. Answer slot: if the log carried regulatory deadlines or rules, say which and your part; if it did not, say so plainly. | Pressure, and it covers the regulated-complaints requirement (F7). |

Reverse questions (Round 2)

1. "What's the first complaint trend you'd want me to bring to the monthly review?" Why it lands: shows you want to be measured on the thing the role reports on.
2. "As branches move into hubs during 2027, which complaints are hardest to keep on time?" Why it lands: ties the question to the published plan and shows you read it.

---

## Round 3: panel of two branch managers (60 min, including a 20-minute case)

Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | The panel scores the four values | Top weight. The panel is also the values round | Use one story per value, with the honest branch where none exists |
| Case/Strategist | The 20-minute escalation case, and a strategy question | Middle weight. The case is scored on structure and clarification | Clarify, then structure, then answer; think aloud |
| Peer Evaluator | Seams between branches and the contact centre; credit | Middle weight. Two branch managers are peers to the role's seam | Offer seam principles, not a map you do not know; reciprocity |
| Data-Driven Prober | Asks how the spreadsheet was built and what it counted | Low weight. One question | Say what you know and say plainly what you do not |

Questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A member has escalated a fee complaint twice. It's now with you, and they want an answer by Friday. What do you do?" | JD, CASE | [generic] | Structure it: clarify the facts, state the objective, segment the options, set the approach, name the measures, and name the risks. Think aloud. Make no claim about your past. | The 20-minute case is a live problem from the JD's escalation line. A pattern for the problem, not a fact about this employer. |
| E2 | "Your published plan moves eight branches into five hubs over 2027. How does an escalation route change when a branch becomes part of a hub?" | CO, CASE | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief as you relayed it) | Clarify who escalates to whom. Protect the member's side first. Say what you would need from branch supervisors. Do not claim knowledge of your own branch's future. | The strategy question, grounded in the brief. Coaching supervisors through a change is the JD's escalation line. |
| B5 | "Tell me about a time you were asked to close a complaint and wouldn't." | VAL | [grounded] "Own the Fix: whoever finds the problem keeps hold of it until it is solved" (the values page) | Scaffold: name the stake, the refusal, and what changed. If none comes to mind, say so plainly, then give the nearest thing the log carries. | Own the Fix, the panel's version. |
| B6 | "When did a member's side of the counter change what you did?" | VAL | [grounded] "Members First, Always: we decide from the member's side of the counter" (the values page) | Scaffold: pick the decision and what the member got. If none comes to mind, say so plainly, then give the nearest thing the log carries. | Members First, panel version. |
| B7 | "Tell me about a time a member needed something explained twice." | VAL | [grounded] "Plain Words: if a member needs it explained twice, we wrote it wrong" (the values page); "trained new tellers on our escalation script" (your message) | Scaffold: how you explained the script, or a time you rewrote an explanation. If none, say so plainly, then give how you trained tellers on the script. | Plain Words, panel version. |
| G1 | "Our teams sit side by side. Where's the seam between the branches and the contact centre, and what happens when we disagree?" | JD | [grounded] "across branches and the contact centre" (the JD); "Never worked in a contact centre" (your message) | Propose seam principles rather than a map you do not know. Plain acknowledgment: "I've never worked in a contact centre, so I'd start by mapping the handoffs with your team." For disagreement: if you have a time you disagreed with a peer, say it; if not, say so plainly. | F2 and the seam. |
| G2 | "How do you handle credit when a fix spans two teams?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Reciprocity: say what you would bring to the peer's team, from the log you handled. Do not claim credit you did not have. | The peer's own worry, in collegial form. |
| H1 | "Walk me through the monthly complaints spreadsheet: what was in it, and who used it?" | JD, EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: if the spreadsheet carried volumes or resolution times, say how each was counted and what it was sensitive to; if it did not, say so plainly. Name the tool in your own words. | F3 and F9: the monthly reporting and Excel requirements, asked as a premised question on your quote. |

Reverse questions (Round 3)

1. "What could a new person do in their first month that would genuinely help your team?" Why it lands: a reciprocity question, which peers weigh heavily because it shows you are thinking about their load.
2. "Where do your branch managers say the complaint process is slowest today?" Why it lands: asks for the real pain rather than the brochure.

---

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | C1, G1, B2, D2 |
| Report monthly on complaint volumes and resolution times | A2, H1 |
| Coach branch supervisors on escalations | E1, E2 |
| Work with digital teams on self-service journeys | C3, A7 |
| 4+ years in financial-services customer operations | None, and why: your six years in retail banking meets the length, and A1 walks the arc |
| Experience handling regulated complaints | D2 |
| Confident presenting to senior leaders | C2 |
| Comfortable with Excel reporting | H1, A2 |

## Sources

- Provided documents: the JD and your message (background, the four values as copied from ashgrovecu.org this morning, the recruiter's email, and your summary of the strategy brief).
- Nothing was searched or fetched.

Research tier: L1 — searches 0 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The four values copied this morning fix the values cheat sheet and the value quotes |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the three rounds, their lengths, and the values round |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the brief fixes the grounding brief and A7 and E2. Figures are as you relayed them, not checked against the brief |
| 4. Interviewer name with Ashgrove | n/a | No names for the Head of Member Services or the panel, so no query could be formed |
| 5. Representative Member Experience Lead JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The published strategy brief, or its link → checks the four figures you relayed and moves the grounding brief onto the document itself.
- The names of the Head of Member Services and the two branch managers → a read of each interviewer's public footprint, per-member persona weights, and a tailored reverse question for each.
- A description of the monthly spreadsheet: its columns, and whether it held volumes or resolution times → turns the answer slots in A2, F3 and H1 into rehearsed answers.
- The recruiter's brief on the 20-minute case, if one is sent → sharpens E1 and E2 to the exact scenario.
- A deep research pass (L2): up to 6 further searches and 2 fetches on the loop, the brief, interviewer footprints and recent Ashgrove news. It is offered once and runs only if you say so.
- A tuesday-dossier.md from an earlier session → would sharpen the objection in C1 and the weak areas, but it is not needed for this pack.
