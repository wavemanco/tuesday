Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-2-rooms-case-4-denied-f4234336/247d2a95-a431-4c69-a91f-547ff1504873/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. It's built for the hiring-manager round from your dossier. Web search was refused in this session, so the pack has nothing on Quartzline's values, interview loop or strategy. Those parts are generic. If you grant web search permission, I can re-run it.

Say the word and I'll play the Skeptic on A1, the objection the dossier named as your highest-return rehearsal.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Hiring-manager round, 45 minutes, Thursday 2026-11-26. Interviewer: not named. Changelog: first pack.

Built on the pasted `tuesday-dossier.md` (version 1.1) and no other inputs. Company research was refused in this session (see Sources), so everything about Quartzline itself is `[generic]`.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: JD (the listed job), EXP (your experience, and whether it holds up), CO (company knowledge), CASE (a live problem), VAL (values).
- Guidance is scaffolding, not a script. Speak it in your own words, in 90 to 120 seconds, and rehearse only what you actually did.
- Answer slots are instructions for the interview. Each one gives both honest branches. Use the one that is true.

## Fit snapshot

Requirements are quoted from the dossier's `role_profile`. Evidence is quoted from the dossier's `handoff_to_mock_interview.verified_candidate_evidence` (V1 to V3, in the order given). The dossier pasted here has no `evidence_map`, so the confidence and gap grades for F3, F4 and F5 are my reading, not the underwriter's. The underwriter flagged only R1, the R1 roadmap sub-claim and R5 as uncertain.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | Adjacent work, not product management work. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." The limit, said before it is asked: "That is adjacent to product management, and I haven't held a product manager title." The second sentence is the plain acknowledgment from dossier prohibited_claims. |
| F2 | "3+ years product management experience" — dossier role_profile R1, must_have | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [grounded] | transferability | Confirmed, but with limited inspectable proof, so expect a probe. Volunteer the limit first. Words: "I ran quarterly roadmap-input sessions, feeding client evidence to product." Say that those sessions were input to the roadmap, not the roadmap itself. Answer slot: the roadmap question is the probe this row makes likely. If any roadmap decision was yours, say which. If none was, say so and stay with the sessions. |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | Words: "I led client go-lives on the vendor's REST APIs." Your material says client integrations that reached go-live, not an API platform product. Keep the words there. Answer slot: if an API product reached users through your own decisions, say which. If not, say so. |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Wrote the internal integration playbook her team uses" — dossier V2 | high | [grounded] | discovery | Words: "I wrote the internal integration playbook that my team uses." The playbook is documentation. Nothing in the material shows schemas. Answer slot: if you wrote, reviewed or changed a schema, say which and what changed. If not, say so, and say what integration docs you did read or write. |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | discovery | Customers are covered by the quote: scoping, requirements and UAT. Product is covered by F2. Engineering and sales are not shown. Answer slot: if you worked with engineering or sales on an integration, say who and what was decided. If not, say so. |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred | none given (the dossier grades R5 low, so nothing is quoted for it) | low | [inferred] | discovery | Derived from dossier uncertain area R5, graded low with strategy clarify. Nothing here is asserted as your claim. Answer slot, with the probe "Have you delivered Agile inside a product org?": if you have, say what you ran and your part in it. If you have not worked that way, say so, and say what you would want to confirm about how this organisation defines Agile delivery. |
| F7 | "Owning a roadmap and prioritization authority" — dossier uncertain area, R1 sub-claim | none given (dossier records the absence) | none | [grounded] | capability | Plain acknowledgment, sourced to the dossier's acknowledge_gap area and prohibited_claims: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan, stated as a plan and never as past work: what you would learn first, and from whom. No bridge, and no answer slot. |

Seven rules the table follows:

- Each Evidence cell holds only quoted text from the dossier, with its origin. Nothing is paraphrased.
- The F1 and F2 split is deliberate: the two quotes carry different confidence, so they get separate rows.
- The gap type follows the evidence. F3 and F5 are my reading of R2 and R4. They are not in the underwriter's uncertain list.
- Gap and bridge language never names a practice you did not state. An answer slot asks about it instead.
- F7 is the only row with a first-person negative. Its source is named by field.
- Provenance on the F7 row is `[grounded]` because the dossier records the gap.
- F6 is `[inferred]` because a `low` claim may only be coached as a clarify note.

## Prohibited claims

These bind every guidance cell. None may be asserted, softened or implied, whatever label a row carries.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier prohibited_claims | "I haven't held a product manager title." Nothing else in a bridge may lean on a PM title. |
| Having owned a product roadmap | dossier prohibited_claims and acknowledge_gap | "I haven't owned a product roadmap." Then the ramp plan. |
| Having set prioritization for an engineering squad | dossier prohibited_claims | "I haven't set prioritization for an engineering squad." |
| Owned or ran the roadmap | Inflated form of V3: "Ran quarterly roadmap-input sessions feeding client evidence to product" | The V3 quote at its own scope. The pack's observation, not words for you: your material says roadmap-input sessions, not the roadmap. |
| Shipped API platform products | Inflated form of V1: "Led 30+ end-to-end client integrations of the vendor's REST APIs" | The V1 quote at its own scope. The pack's observation: your material says client integrations, not a platform product. |

## Question banks

Coverage: 19 questions, weighted by persona (see the persona table). Each question's Provenance cell carries every sentence its guidance rests on.

### Persona weights

| Persona | Weight | How it shows up here | Likelihood | Reasoning |
|---|---|---|---|---|
| Skeptic | 5 (top) | The PM-title and roadmap objection, asked directly | high | The hiring-manager prior weights Skeptic and Case highest. The dossier named the objection, so it gets the most depth. |
| Case / Strategist | 4 | Live partner and adoption problems | high | Hiring-manager prior. A hiring manager buys capability and tests it on their actual roadmap. |
| Data-Driven Prober | 3 | The 30+ count and the adoption baseline | medium | Headline figure in V1, and an adoption baseline the employer has not stated. |
| Pressure / Stress | 3 | Attribution of V1, and decision authority | medium | Raised from its low prior, because hold-then-concede is the answer the objection needs. |
| Conversational | 2 | The opener and the "journey" question | medium | Relationship priors do not weight it for a hiring manager. Two questions keep it rehearsed. |
| Peer Evaluator | 2 | The seam with the two squad leads | low | Relationship priors do not weight it. Kept because the squad leads will be your daily peers. |

No interviewer profile was given, so no interviewer signal adjusts these weights. No research ran, so no loop source establishes the round. The archetype is therefore a generic fallback, and the weights above rest on the hiring-manager prior alone. That is a pattern, not a documented Quartzline process.

### Skeptic (A)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] the question is the underwriter's `likely_interviewer_objections`. Plain-acknowledgment sources: "Having held a product manager title or role" (dossier prohibited_claims); "Having owned a product roadmap" (dossier prohibited_claims). Evidence: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | Open with the plain acknowledgment: "I haven't held a product manager title, and I haven't owned a product roadmap." Then the work, in its own terms: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live," and "I ran quarterly roadmap-input sessions, feeding client evidence to product." Then one line on what you would do first, as a plan. Hold through two follow-ups by returning to those sentences. If pressed on authority, concede precisely: "Setting priorities for an engineering squad is the part I haven't done." There is no answer slot here, because the dossier records roadmap ownership as an acknowledged gap. | The underwriter named this as the most likely objection, from evidence you confirmed. It gets the deepest rehearsal. F1, F2 and F7 are the rows it draws on. Its negatives are sourced by field. |
| A2 | "What would owning the roadmap for the partner-facing API platform mean to you, and what would you decide first?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibilities) | Define owning as deciding scope and sequence, with the squad leads' inputs. Name the first decision you would make alone and the first one you would take to the squad leads. This is about the role, so it claims nothing about your past. | A role-definition question. Its raising source is the JD's own line, so it presupposes nothing about you. |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Owning a roadmap and prioritization authority (R1 sub-claim)" (dossier acknowledge_gap area) | Name the gap in plain words: "I haven't owned a product roadmap or set prioritization for an engineering squad." Then your ramp plan as a plan: what you would learn first, and from whom. No bridge, because the dossier records no evidence for it. | The Skeptic stem. The acknowledged gap, asked directly. Calibrated candour beats a bluff on a competency the interviewer owns. |
| A4 | "Write specs and drive delivery with two engineering squads — how would you run that from day one?" | JD | [grounded] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibilities) | Describe the cadence you would set and the decisions you would keep. Answer slot, with the interviewer's probe "Have you delivered Agile inside a product org?": if you have, say what you ran and your part in it. If you have not worked that way, say so, and say what you would want to confirm about how you define Agile delivery. | F6 is R5, graded `clarify`. The second branch is the honest one. R5 is preferred, not must-have, so it is asked once. |
| A5 | "How would decisions between you and the two squad leads get made?" | JD | [grounded] "Decision authority versus the two squad leads is asserted in the JD but not evidenced" (dossier opportunity_risks_to_validate) | Say that you do not yet know where the lines sit, and that you would want them written down before you commit. Claim no decision rights. Ask it yourself with reverse question RQ1. | The dossier's open unknown. The interviewer is testing the authority the JD asserts. |

### Case / Strategist (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two partners want different things from the platform, and only one of them can ship next quarter. How do you decide?" | CASE | [generic] a role-family pattern for a partner-platform trade-off | Clarify the objective first. Then segment the partners, name what each one stands to lose, and set out your approach, the metric you would watch, and the risk of choosing wrong. Think aloud, and challenge one premise. This makes no claim about your past. | A live problem from the role's partner-facing scope. It is `[generic]` because it is a pattern for the problem, not a fact about this employer. |
| B2 | "Partner API adoption has flattened over two quarters. What do you look at first?" | CASE | [grounded] "Define and track adoption metrics" (dossier role_profile responsibilities) | Start by asking for the baseline, since none is stated. Then segment adoption, separate a real drop from a change in measurement, and name the one metric you would defend. No past metrics are claimed. | The dossier's open risk: no baseline. This shows you would establish one before diagnosing. |
| B3 | "What do you need to know before writing the first spec for a partner-facing API change?" | CASE | [generic] | Name the inputs: the partner's use case, the integration pattern, the squad constraints, and what would break for existing partners. No past claims. | Covers the spec-writing responsibility and the partner-facing scope, as a live question. |
| B4 | "Which partner's request would you say no to first, and what would you tell them?" | CASE | [generic] a role-family pattern for prioritisation | Name the criterion you would decide on, say what you would tell the partner, and name who you would take the decision to. No past decisions are claimed. | The anti-pick. The role's real job includes saying no, and a hiring manager will test it. |

### Data-Driven Prober (C)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the 30+ integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Defend-the-number slot, in your own words: how the count was made, what it is sensitive to (what counted as end-to-end, what counted as led), the assumption you would defend least, and which of those integrations you led rather than supported. If there was no written count, say so. | F3 rests on this figure, and every headline figure gets a defend-the-number question. |
| C2 | "Show me an API doc or schema you would push back on. What would you change?" | JD | [grounded] "Wrote the internal integration playbook her team uses" (dossier V2) | Answer slot: if you wrote, reviewed or changed a schema, say which and what changed. If not, say so, name the integration docs you did write or read, and say what you would check in a schema first. | F4 (R3). The material shows docs and no schemas. Expect this probe. The honest answer is the second branch. |
| C3 | "What would you need to see to say partner API adoption is working?" | JD | [grounded] "Define and track adoption metrics" (dossier role_profile responsibilities) | Name the signals you would want first: which partners, which endpoints, and the baseline you would need before calling any change. Claim no adoption figures you have tracked. | The adoption-baseline risk. The Prober asks what the number would be before you claim one. |

### Pressure / Stress (D)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That is a long integration record. How much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); "Wrote the internal integration playbook her team uses" (dossier V2) | Name your part in each stage, in your own words. Hold "led" where the quote holds it. Concede precisely where a stage was the team's: say which stage, and what the team did. Hold through two follow-ups. Never fold on "led" to restore harmony. | Attribution is the honest test here. This question covers R1 and R2 together. |
| D2 | "Tell me about a time you pushed back on product, using client evidence." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | Story-map from V3: the sessions, the client evidence, the product side. Answer slot: if you did push back, say what you brought and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the roadmap-input sessions themselves. | An open prompt on stakeholder management. Its theme comes from the JD's R4 line. It presupposes no event. |
| D3 | "You would lead two engineering squads with decision rights you have not held. Where would you hold a position, and where would you concede?" | JD | [grounded] "Having set prioritization for an engineering squad" (dossier prohibited_claims, named by field) | Hold the position through two follow-ups: "The integration record is where I would ground decisions, and I would want the decision rights written down first." Concede specifically: "Prioritisation for an engineering squad is new to me." Never fold on the record. | Hold-then-concede. The concession is the sourced acknowledgment from F7. |

### Conversational (E)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); "Wrote the internal integration playbook her team uses" (dossier V2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | A 90-second arc, in this order: the integrations (V1), the playbook (V2), the roadmap-input sessions (V3), then the plain acknowledgment. End on what you want to do next, as a plan. Do not end on the title. | Casual openers are still scored. The arc is built only from the quotes. |
| E2 | "What is the part of partner integration you find most interesting?" | JD | [generic] | Answer slot: name one part of integration work you have done yourself, in your words. If none stands out, name the part you would most like to learn first. | Casual register, JD topic. It is scored as a plus-skill question. |

### Peer Evaluator (F)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Engineering and product sit side by side. Where is the seam with the squad leads, and what happens when you disagree?" | JD | [grounded] "Decision authority versus the two squad leads is asserted in the JD but not evidenced" (dossier opportunity_risks_to_validate); "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibilities) | Propose seam principles: who owns scope, who owns sequencing, and how a disagreement gets escalated. Answer slot: if you have disagreed with an engineering lead on a delivery, say what it was and how it resolved. If not, say so, and describe how you would raise it. | R4 and the authority risk. Peer-style seam questions come collegially. |
| F2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Name the work by the scope the quote gives: the integrations you led, and the teams the go-lives needed. Credit the teams in your own words. Do not widen "led" to cover what the team did. | A credit probe. The word "led" in V1 is the claim to keep exact. |

### Requirement coverage

| Requirement | Questions covering it |
|---|---|
| R1: 3+ years product management experience | A1, D1 |
| R2: Shipped API or platform products | C1, D1 |
| R3: Technical fluency: API docs, schemas | C2 |
| R4: Stakeholder management across engineering, sales, customers | D2, F1 |
| R5: Agile delivery experience | A4 (answer slot) |
| R1 sub-claim: owning a roadmap and prioritization authority | A1, A3, A5, D3 |
| Responsibility: own the roadmap for the partner-facing API platform | A2 |
| Responsibility: write specs and drive delivery with two engineering squads | A4, F1 |
| Responsibility: run discovery with integration partners | E1, not separately probed. V1 carries scoping and requirements. |
| Responsibility: define and track adoption metrics | B2, C3 |

## Reverse questions

Every one of these is a question you ask the interviewer.

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Tests the decision-authority risk the JD asserts without evidence. You need the answer before you accept. |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | No baseline is stated. You would need one to set a target, and the question reads as diligence. |
| RQ3 | "Which partner integrations is the team already committed to, and which decisions are still open?" | Shows you plan from the real queue, not from a generic one. |
| RQ4 | "How do sales and customer success bring partner requests into the roadmap today?" | Covers the engineering and sales gap in R4. You learn the channels a PM would have to run. |
| RQ5 | "What would a strong first 90 days look like, and who would judge it?" | The answer gives you the success criteria. Standard, and it lands with a hiring manager. |
| RQ6 | "What did the last person in this role get right, and what would they have done differently?" | Shows what the role has actually required, not what the posting says it requires. |

## Prohibited list

The table in the Prohibited claims section above holds this list. Those five entries bind every bank and every reverse question in this pack.

## Sources

**Provided documents.** The pasted `tuesday-dossier.md`, version 1.1. Sections consumed: `role_profile` (the JD equivalent: requirements, responsibilities, unknowns), `handoff_to_mock_interview` (verified evidence V1 to V3, uncertain areas, the likely objection, risks, employer questions, prohibited claims), and `decision` (context only). Not present in the pasted dossier: `evidence_map`, `evidence_state` and `risk_register`. Their absence is why the F3 to F5 grades are my reading.

**Target accounting.** Research tier: L1, searches 3 of 6, fetches 0 of 2. User links read: 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Every call was refused. The values cheat sheet is not built, and no value names are quoted. |
| 2. Quartzline interview process, product manager | unavailable | Every call was refused. The loop structure is unknown, so the persona weights use the generic archetype and say so. |
| 3. Quartzline strategy and recent news | unavailable | Every call was refused. The grounding brief and the CO bank are absent. B1 to B4 are `[generic]`. |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent. |
| 5. Representative JD | skipped | The dossier's `role_profile` supplies the JD's requirements and responsibilities. |

Searches sent, all refused by the host (permission not granted):
- "Quartzline company values": refused
- "Quartzline interview process product manager platform APIs": refused
- "Quartzline strategy news 2026": refused

No fetches were sent.

## Upgrade menu

- Web search permission granted → a re-run of targets 1 to 3 (about three searches). That gives the values cheat sheet, the loop structure and its persona weights, and the CO bank.
- The interviewer's name → an interviewer read, persona weights from their public footprint, and a tailored reverse question.
- The full dossier, with its `evidence_map` and `risk_register` → F3 to F5 are graded by the underwriter, not by this pack.
- One example of working with an engineering lead or a sales lead → F5 gets a quoted line in place of an answer slot.
- The recruiter's note on the round's focus, if one exists → coverage can be weighted to what they will assess.
