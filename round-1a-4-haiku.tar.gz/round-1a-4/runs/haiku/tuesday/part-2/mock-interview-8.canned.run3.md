Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/haiku/tuesday/part-2/rooms/case-8-canned-db5c7da2/ashgrove_member-experience-lead_interview_pack.md`. It's built as a loop: one shared fit snapshot, then a mini-pack for each of the three rounds, since they have different interviewers and different weightings. I didn't search the web. Your pasted values and the recruiter's description are the sources.

Two gaps shape the prep. You've never worked in a contact centre, and you've never presented above regional level, and the JD asks for both. The pack states these plainly as gaps you've named, and it doesn't turn them into stories. The highest-return prep is question B6, the contact-centre question, which will likely come up in some form in the Head of Member Services round.

The pack includes a written self-drill for the escalation case (C5) and for the values answers (C1 to C4). I can also run the escalation case live, with the panel persona and follow-ups that react to your answers. Say the word and I'll start.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead. Interview prep pack

Three rounds on 3 December 2026. Prepared 24 November 2026.
Loop mode: one shared fit snapshot and sources block, then a mini-pack per round.

- Round 1: recruiter, 30 minutes. Name not given.
- Round 2: Head of Member Services, 45 minutes, mostly behavioural. Your future manager. Name not given.
- Round 3: panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case. Scored against the four values. Names not given.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (a role requirement), CO (company and strategy), CASE (a live problem).
- **Provenance:** `[grounded]` traces to your message or the documents you sent. `[inferred]` is derived from them, with the derivation named. `[generic]` is a pattern for this kind of question, not a claim about you or Ashgrove.
- Guidance is scaffolding, not a script. Each cell is written to be spoken in 90 to 120 seconds, in your own words.
- Where a cell says **answer slot**, it is an instruction for the interview. It is not a question to me, and it has an honest branch: if the thing did not happen, or was not yours, say so.

## Fit snapshot (shared across rounds)

Requirements are quoted from the JD you sent. Evidence is quoted from your message. Nothing in the Evidence column is a summary.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | Your material gives six years in retail banking, three as a branch supervisor. Say it in those terms. "Customer operations" is the JD's phrase, so describe what the branch work covered in your own words. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material shows a formal log. It does not show whether its timescales or rules were regulatory. Words: "I handled the branch's formal complaints log." Answer slot: if the log followed a regulatory rule or deadline, name it and say how you tracked it. If it did not, say so plainly and describe how the log was run. |
| F3 | "end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | This is adjacent work: one branch's log. Words: "For the branch, I handled the formal complaints log." The limit is the pack's own observation: your material describes one branch, not an end-to-end process across branches. |
| F4 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked in a contact centre." Then a plan for how you would learn it, said as a plan and never as a past. |
| F5 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message); "the last 3 as a branch supervisor" (your message) | low | [inferred] | transferability | Your material shows teller training and a supervisor's role. It does not show coaching other supervisors, so keep the claim at what you trained. Answer slot: if you have coached another supervisor on an escalation, say what you did. If not, say so plainly and say how you would start. |
| F6 | "report monthly on complaint volumes" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Words: "I built the monthly complaints spreadsheet our regional manager uses." Expect a probe on what it counts. Describe what it counted in your own words. |
| F7 | "resolution times" (JD) | none given | none | [grounded] | discovery | Your material does not show whether the spreadsheet tracked how long complaints took to close. Answer slot: if it did, say how they were counted. If it did not, say so plainly and say how you would add them. |
| F8 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | The quote reaches the requirement: you built a reporting spreadsheet that others use. Do not upgrade it to advanced Excel. Your material says built, not which functions you used. |
| F9 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never presented to anyone above regional level." Then a plan, said as a plan. |
| F10 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: if you have worked with a digital or product team on a customer journey, say what you did. If not, say so plainly and say what you would ask them first. |

**Gates.** The JD names no gate requirement, so the snapshot has no `hard_gate` rows. Location and notice are handled as recruiter-screen logistics in Round 1.

**Reading the rows.** F1, F6 and F8 are the strongest things you have. F4 and F9 are the two gaps you stated yourself. The JD lists both of them as core requirements, so they will be tested.

## Prohibited claims (built locally)

These are the claims the pack will not coach. Each one is a stretch of your own wording, or a gap you stated. No answer, hold or bridge below asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material describes one branch's log. |
| Has worked in a contact centre, or run calls or queues | Negative you stated, F4 | "I haven't worked in a contact centre." |
| Has presented to senior leaders or executives | Negative you stated, F9 | "I've never presented to anyone above regional level." |
| Coached branch supervisors on escalations | Inflated form of F5 | The tellers you trained, at their own scope. |
| Handled regulated complaints | Inflated form of F2 | "I handled the branch's formal complaints log." The limit is the pack's observation: your material says formal, not regulated. |
| Advanced Excel skills | Inflated form of F8 | "I built the monthly complaints spreadsheet our regional manager uses." |

## Persona weights (shared logic)

Weights start from the relationship priors, then adjust for the interviewers' roles and for what you told me.

- **Round 1, recruiter:** the prior is Conversational plus a light Skeptic. The round is a logistics and motivation check, so the Conversational register is the danger. Casual questions are still scored.
- **Round 2, Head of Member Services:** the prior for a hiring manager is Case plus Skeptic. You said the round is "mostly behavioural", so Values/Behavioral moves to the top. Skeptic and Case stay in the mix.
- **Round 3, panel:** the recruiter says the panel is the values round. The prior for a dedicated values round is Values/Behavioral plus Conversational. The panel are branch managers, so Pressure takes the second slot. Case covers the 20-minute escalation. Each panel member's name is unknown, so personas are not assigned per person yet.

## Round 1: recruiter screen (30 minutes)

Weights: Conversational 4 (A1 to A3 and the logistics rows), Skeptic 2 (S1 and S2). Logistics rows are scored in the recruiter's register.

### Persona table, Round 1

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly opener, "walk me through", a casual aside on a JD topic | High. This is the recruiter's default register and it is scored. | A 90-second arc. Treat every casual question about reporting or the role as scored. |
| Skeptic | "I don't see X in your background" | Medium. Recruiters run knockout checks on stated gaps. | Plain acknowledgment of the gap, then what carries across, then a plan. |

### Question bank, Round 1

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in these beats: six years in retail banking, three as a branch supervisor, the complaints log, teller training, the spreadsheet. Use your own words. Add no roles, dates or outcomes that are not in those sentences. | F1, F3, F6 are the arc's beats. A casual opener is still the first scored answer. |
| A2 | "What drew you to Ashgrove?" | CO | [grounded] "we decide from the member's side of the counter" (the values page you sent) | Answer from what you were sent: the values page and the strategy summary. Pick one value and say why it matters to your work. Do not claim knowledge beyond those documents. | The recruiter will test whether you read the material. Quoting the values page is fine; reciting the strategy as if you had inside knowledge is not. |
| A3 | "The role reports monthly on complaint volumes and resolution times. What have you reported, and on what?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the spreadsheet covered, in its own words. Answer slot: if it recorded how long complaints took to close, say how that was counted. If it did not, say so plainly and say how you would add it. | F6 and F7. This is the JD's monthly-reporting duty, and resolution times is where the material is silent. |
| S1 | "I don't see contact-centre experience in your background. How would you run a contact-centre complaints process?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I haven't worked in a contact centre." Then what carries across, in your words: the formal complaints log and the escalation script. Then a plan for what you would learn first. Hold through two follow-ups by returning to the complaints log, not by adding to it. | F4, the most predictable gap in the pack. A knockout check in a friendly tone is still a check. Round 2's B6 has the deepest rehearsal of this. |
| S2 | "What would make this role the right next step for you?" | CO | [generic] | Answer in one or two sentences about the scope of the role and what you want to own. Do not criticise your current branch. | A motivation check, asked casually. It has no claim about you to back up. |
| A4 | "What would you do in your first 30 days?" | CASE | [generic] | Structure it: learn the process, learn the people, find where complaints are slowest, then decide. Use no past claims. | A live problem. It presupposes nothing about your history. |
| L1 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot. Give your own figure, or ask what the band is first. Your message gives no figure, so do not offer one or guess. | Pay is a logistics term. It fills its slot in your own words only. |
| L2 | "What is your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period in one sentence. Your message gives none, so do not estimate it. | Notice is a logistics term. Your own answer is the only safe one. |
| L3 | "Where would you be based?" | JD | [generic] | Logistics slot. Give your own answer. The strategy summary mentions branches consolidating into five hubs, but do not treat that as settled for any branch. If you do not know which hub, say so. | Location is a gate term. The consolidation is a real risk to your answer, so know your own position before the call. |
| L4 | "Why are you looking to move on?" | EXP | [generic] | Logistics slot. One sentence in your own words, about the move rather than about the branch. | Reason for leaving is a logistics term. Keep it short and own it. |

Coverage in this round: F1 (A1), F3 (A1), F4 (S1), F6 (A3), F7 (A3), F8 (A3).

## Round 2: Head of Member Services (45 minutes, your manager)

Weights: Values/Behavioral 5 (B1 to B5), Skeptic 4 (B6 to B8, B10), Case 3 (B9, B11, B12). Mostly behavioural, so the stories carry the round.

### Persona table, Round 2

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Tell me about a time…" with the four values as the theme | High. You told me the round is mostly behavioural, and the manager will test stories against the values. | STAR-shaped stories with "we" for context and "I" for your contribution. If there is no story, say so and give the nearest one. |
| Skeptic | "Which part of this role would you be weakest at?" | High. Your two stated gaps are the obvious target, and this is the interviewer who will be living with them. | Hold the stated facts. Name the gap in one sentence and give a plan. Do not bluff. |
| Case / Strategist | "How would you approach the first 90 days?" | Medium. The round is behavioural, but the manager will want to see how you think. | Clarify first, then structure, then decide. Speak your reasoning aloud. |

### Question bank, Round 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a complaint you had to keep hold of until it was resolved." | VAL | [grounded] "I handled the branch's formal complaints log" (raising source: the value "Own the Fix", from the values page) | Selection scaffold: pick a complaint from the log that you held from first contact to close. Use the log as the frame, in its words. If you cannot name one you held through to close, say so plainly, then give the nearest one from the log. | Own the Fix. The quote carries "handled", not "solved", so do not add an ending. |
| B2 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] "trained new tellers on our escalation script" (raising source: "Members First, Always", from the values page) | Selection scaffold: pick a case where you chose the member's view over a process step. If none comes to mind, say so plainly, then describe what you taught tellers about the escalation script, in your own words. | Members First. The teller training is the nearest real material. |
| B3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. Name the stake, what you said, and whether the relationship held. If there was no such time, say so, then give the nearest thing you did say upward, in your words. | A persona stem. Your material shows no such moment, so the honest branch is the strongest part of this answer. |
| B4 | "Tell me about a decision where your branch's town mattered more than a number." | VAL | [grounded] "the last 3 as a branch supervisor" (raising source: "Neighbours, Not Numbers", from the values page) | Selection scaffold: a decision where you knew your branch's members, not just its figures. If none comes to mind, say so plainly, then describe the branch you supervised, in your own words. | Neighbours, Not Numbers. Your material carries the least story for this value. Prepare one before 3 December. |
| B5 | "Tell me about a time you had to coach someone to a standard they did not like." | JD | [grounded] "trained new tellers on our escalation script" (raising source: the JD's "coach branch supervisors on escalations") | Use the teller training, at its own scope: you trained tellers. Answer slot: if you have coached a supervisor on an escalation, say what you did. If not, say so plainly and say how you would start with a supervisor. | F5. The JD asks about supervisors, and your material shows tellers. Name the difference rather than blur it. |
| B6 | "You haven't worked in a contact centre, and this role runs one. How would you lead a team you haven't run in that setting?" | JD | [grounded] "Never worked in a contact centre" | **Highest-ROI prep in this pack.** Plain acknowledgment: "I haven't worked in a contact centre." Then what carries across, in your own words: the complaints log and the escalation script. Hold through two follow-ups by returning to what you handled. Concede specifically: you have not run a contact-centre queue, and you would learn it first from the people who do. Give the plan as a plan. | F4 and the JD's "across branches and the contact centre". This will be asked in some form, and the honest answer here decides how the round goes. |
| B7 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Name the two gaps you stated, in those words. Then the plan for each. Do not add a third gap you have not stated. | F4 and F9 are the two you stated, so they are the honest answer to this question. |
| B8 | "Walk me through how the monthly complaints spreadsheet was built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what you built, in your own words. Answer slot: if you are not sure how a figure in it was counted, say so. Do not give a method you cannot repeat under a second question. | F6 and F8. This is a premised question about your own artifact. Only what you wrote is in play. |
| B9 | "What would you need to understand in the first 90 days before you changed anything about complaints across branches and the contact centre?" | CASE | [generic] | Structure it: clarify the complaint volumes and where they come from, the resolution times, who owns each step, and what the branches and the contact centre each measure. Decide after you know. Use no past claims. | A live problem from the JD's scope. It presupposes nothing about your history. |
| B10 | "What rules or timescales do you know a formal complaint has to meet?" | JD | [grounded] "experience handling regulated complaints" (JD) | An open question, so no premise. Answer slot: if your log followed a regulatory rule or timescale, name it and how you tracked it. If not, say so plainly and say what you did follow. | F2. The JD raises regulated complaints, and your material does not say whether your log was regulated. Do not guess the rules; name only what you can stand behind. |
| B11 | "How would you work with a digital team on a self-service journey for complaints?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Answer slot: if you have worked with a digital or product team on a customer journey, say what you did. If not, say so plainly and say what you would ask them first. | F10. Silence is a discovery gap. Prepare your honest answer before the round. |
| B12 | "Where do you think member service is heading at Ashgrove?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the July 2026 strategy brief) | Use the brief's target in its words, as you were sent it. Say what you would want to know about how complaints move across channels as service shifts. Do not claim more knowledge of the plan than the brief gives. | The CO question. The 40% target is the most concrete thing in your summary, and it connects complaints to the digital move. |

Coverage in this round: B1 to B4 (values), B5 (coaching supervisors), B6 and B7 (end to end across branches and the contact centre, senior presentation gap), B8 (Excel), B10 (regulated complaints), B11 (digital teams), B12 (strategy).

## Round 3: panel of two branch managers (60 minutes, including a 20-minute case)

Weights: Values/Behavioral 4 (C1 to C4), Case 3 (C5 to C7), Pressure 2 (C8, C9). The panel scores against the four values, so the values questions are scored hardest.

### Persona table, Round 3

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario questions mapped to the four values | High. The recruiter says this is the values round and that the panel scores against the four values. | One story per value where you have one. Where you do not, say so, and give the nearest real material. |
| Case / Strategist | The 20-minute escalation case | High. The case is the most likely place to be tested on coaching a supervisor and owning a fix. | Clarify, decide, coach, communicate, record, escalate. Speak your steps aloud. |
| Pressure | "Sixty seconds: why you over an internal candidate?" | Medium. Branch managers may test composure, and they are senior to your current role. | Pause, restate the question, hold your position through two follow-ups, and concede specifically. |

### Question bank, Round 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "When did a member's situation not fit the procedure? What did you do?" | VAL | [grounded] "trained new tellers on our escalation script" (raising source: "Members First, Always", from the values page) | Selection scaffold: pick a case where a rule and a member's situation pulled apart. Say what you did and what you did not do. If none comes to mind, say so plainly, then give the nearest thing your material carries: the escalation script you trained tellers on, in your own words. | Members First. Your material has no sentence about a rule bending for a member, so the honest branch is the answer. |
| C2 | "Tell me about a time a member had to hear something from you twice." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (raising source: "Plain Words", from the values page) | Selection scaffold: pick a case where the explanation did not land and you had to say it again. If none comes to mind, say so plainly, then describe what the spreadsheet made plain for your regional manager, in your own words. | Plain Words. Your material carries a clarity story only as a reporting artifact, so do not stretch it. |
| C3 | "When did you know something about your branch's town that changed how you handled a complaint?" | VAL | [grounded] "the last 3 as a branch supervisor" (raising source: "Neighbours, Not Numbers", from the values page) | Selection scaffold: pick a complaint where local knowledge mattered. If none comes to mind, say so, then describe the branch you supervised, in your own words. | Neighbours, Not Numbers. The weakest value in your material. Prepare one story before 3 December. |
| C4 | "Tell me about a problem you found that was not yours to solve. What did you do with it?" | VAL | [grounded] "I handled the branch's formal complaints log" (raising source: "Own the Fix", from the values page) | Selection scaffold: pick a case where you found the problem and kept hold of it until it was solved. If you passed it on, say to whom and whether you kept checking. If none, say so, then describe the log, in its words. | Own the Fix. The panel will test whether "handled" means "kept hold of until solved". |
| C5 | "A member has complained three times about a fee on their account. Today they ask for a senior person and say they will take it to an external ombudsman. Your supervisor believes the case is closed. Talk us through the next 20 minutes." | CASE | [generic] | **The escalation case.** Structure: (1) clarify what the complaint is, what has been done, and what the member is asking for, and check which complaint timescale applies to your firm. Do not assume a number. (2) Decide who owns the fix, and keep it. (3) Coach the supervisor privately before anyone speaks to the member: ask what they checked, and what would make the case closed. (4) Speak to the member in plain words, with one named owner and a date you will call back. (5) Record the case and what caused it. (6) Escalate only what needs a decision above you. Use your branch experience as the frame. Do not describe contact-centre work. | The case is a scenario and makes no claim about you. This is the JD's "coach branch supervisors on escalations" and the values' "Own the Fix" in one case. The guidance is a pattern for escalations of this kind, not a description of Ashgrove's process. |
| C6 | "Complaints are rising in the contact centre and falling in branches. What do you look at first?" | CASE | [generic] | Structure: check the denominator, the channel mix, whether one reason drives most of the rise, and whether the branch fall is real or a change in how complaints are logged. Use no numbers you have not been given. | The JD's "complaint volumes" and a live problem. Dual-tagged JD and CASE. |
| C7 | "A senior leader challenges your monthly report: the numbers do not match the branch files. What do you do?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | A live problem: check the spreadsheet's inputs against the branch files, find the first point of difference, and report what you found. Speak to the spreadsheet as the one you built. Do not claim a figure was ever challenged. If one was, say so. | The JD's reporting duty, asked as a problem. The spreadsheet quote is the only thing it draws on. |
| C8 | "You've never presented to anyone above regional level. Why would the executive team take a view from you on a change they would have to approve?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Hold your view on the complaints you handled and the report your regional manager uses, through two follow-ups. Then concede specifically: you have not presented to executives. Say how you would prepare, as a plan. | F9 and the JD's "confident presenting to senior leaders". This is a pressure hold: the position you hold must be one your material supports. |
| C9 | "Sixty seconds: why you over an internal candidate?" | VAL | [generic] | Pause, then answer for what you would bring, with the one gap named. If you do not know who else applied, say so. Do not compare yourself to people you have not met. | A pressure stem. The honest answer is the one that names the gap, and it holds the strongest position you have. |

Coverage in this round: C1 to C4 (values), C5 (coaching supervisors, escalation), C6 (complaint volumes), C7 (reporting), C8 (senior presentation), C9 (composure).

### Round 3 reverse questions for the panel

- "When a branch supervisor escalates a complaint, what do you most want them to have already done?" Why it lands: it sets the bar your case answer should meet.
- "What would a new person do in the first month that would genuinely help your branches?" Why it lands: a reciprocity question for a panel that will be your peers in the network. It shows you are thinking about their work, not just yours.

## Values cheat sheet (section 10)

The recruiter's words make the panel a values round, so the four published values are mapped below. Your material carries a story for only one value, and only partly. The others are selection scaffolds with an honest branch.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F5, "trained new tellers on our escalation script". It carries training, not a member decision, so use the scaffold in C1 and B2. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | F6, "I built the monthly complaints spreadsheet our regional manager uses". It carries a reporting artifact, not a plain-words story. Use the scaffold in C2. |
| Neighbours, Not Numbers | Every branch is part of its town | F1, "the last 3 as a branch supervisor". It carries time at a branch, not local knowledge. Use the scaffold in C3 and B4, and prepare one story. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F3, "I handled the branch's formal complaints log". It carries handling, not a solved problem. Use the scaffold in C4 and B1. |

## Grounding brief (from your summary of the July 2026 strategy brief)

I have your summary, not the brief itself. These are your words, not quotes from Ashgrove's document. Paste the brief to make them exact.

- Move 40% of member service to digital channels by 2028 (your summary).
- Consolidate eight branches into five hubs over 2027 (your summary).
- Launch a small-business lending product in Q1 2027 (your summary).
- The main competitive pressure is app-only banks (your summary).

Use these only as the CO questions use them (A2, B12). Do not quote them as Ashgrove's words.

## Reverse questions (all rounds)

- **To the recruiter:** "How is the panel scored, and is the rubric for the four values shared with candidates?" Why it lands: the recruiter said the panel scores against the four values. The answer tells you the bar.
- **To the Head of Member Services:** "What would the first 90 days look like for someone who takes this role on?" Why it lands: it sets up your manager's expectations and shows you are planning.
- **To the Head of Member Services:** "Which numbers do you use to judge the complaints function: volumes, resolution times, or both?" Why it lands: it shows you know the two measures the JD names.
- **To the Head of Member Services:** "As digital self-service grows, what should the complaints process look like in a few years?" Why it lands: it connects to the 40% target without quoting a number you do not hold.
- **To the panel:** the two questions in Round 3 above.

Interviewer-path questions are not included: no interviewer names were given.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B10, F2 |
| Confident presenting to senior leaders | C8, B7 |
| Comfortable with Excel reporting | A3, B8, C7 |
| Own the complaints process end to end across branches and the contact centre | S1, B6, B9 |
| Report monthly on complaint volumes and resolution times | A3, C6 |
| Coach branch supervisors on escalations | B5, C5 |
| Work with digital teams on self-service journeys | B11 |
| Values (Members First, Plain Words, Neighbours, Not Numbers, Own the Fix) | B1 to B4, C1 to C4, C9 |

## Self-drill: the escalation case and the values round (added at your request)

Use these to rehearse on your own. No one is playing the panel. Time yourself.

**Escalation case (C5), 20 minutes:**

1. Read C5 aloud. Give yourself 2 minutes to clarify: what the complaint is, what was done, what the member wants, and which timescale applies. Write down any number you do not know, and do not assume one.
2. Speak for 10 minutes. Say who owns the fix, what you ask the supervisor first, what you tell the member and when you will call back.
3. Take 6 minutes on record and escalation: what you log, what you think the cause is, and what goes above you.
4. Check against the C5 guidance. Did you name an owner? Did you coach the supervisor before the member call? Did you claim any contact-centre experience? If so, remove it.

**Values round (C1 to C4), one answer each, 90 seconds:**

1. Pick one value and one question from C1 to C4.
2. Give the answer. If you have no story, say so plainly and give the nearest real thing from your material.
3. Check it against the cheat sheet. Did you say what you did, in your own words? Did you say more than your quote carries? If so, cut it.

## Sources

Provided documents only. No searches were run.

- Your message: the JD requirements and duties, the four values from the values page, the recruiter's description of the three rounds, the strategy summary, and your background.
- The recruiter's email, as you summarised it.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet and the value names in the question banks. The four values were pasted from the values page, so the inputs fix them. |
| 2. Ashgrove interview process | skipped | Loop structure. The recruiter's description names the three rounds, the interviewers and the case, so the inputs fix the loop. |
| 3. Ashgrove strategy and recent news | skipped | Grounding brief and CO questions A2 and B12. Your summary covers the July 2026 brief. It does not cover news after July 2026, and I have not checked it. |
| 4. Interviewer name and Ashgrove | n/a | No names given, so there was no query to form. The interviewer read and interviewer-specific reverse questions are absent. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Names of the recruiter, the Head of Member Services and the two branch managers → persona weights for each panel member, and interviewer-specific reverse questions.
- The July 2026 strategy brief, pasted → the grounding brief quotes Ashgrove's words instead of yours, and A2 and B12 can cite the brief exactly.
- What your spreadsheet recorded, and whether it tracked resolution times → F7 moves from a gap to a grounded answer, and A3's slot is answered.
- Whether your formal complaints log followed a regulatory timescale, and which one → F2 moves from discovery to presentation, and B10 is answered.
- Any work with digital or product teams → F10 and B11 are answered.
- Any complaint figures from your log, and how they were counted → the defend-the-number rows get real answers, and C7 gets stronger.
- How many hours you have before 3 December → a prioritised prep schedule, placed in front of the rounds.
- Whether the 20-minute case is live or a written task → if written, it becomes a graded deliverable section, and C5 changes.
- A deeper research pass on Ashgrove's strategy and its interviewers (up to 6 searches and 2 fetches, several minutes) → recent news in the CO questions, and any public material on the interviewers. Want it? Say so and I'll run it.
