Tool's loaded. Running the default research pass now: company values, interview process, recent news, and the interviewer's public footprint.
Your prep pack is saved here: /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-2-rooms-case-7-canned-4b2e746e/c89eb238-0d5b-476b-99af-470c858f4379/scratchpad/saltmarsh_live-operations-producer_interview_pack.md

Three things matter most for Friday:

1. **The two-title calendar is your biggest gap.** Your material shows one title, and the JD asks for two. B1 is the question to rehearse hardest. Hold on what you ran, concede that you haven't planned across two titles, then give your sequence for doing it.
2. **The round is the Outage Hour.** Saltmarsh's careers page describes it as 60 minutes: a live-incident tabletop during a live event, then a values conversation. Practise A1 as a spoken walkthrough, in order: clarify, decide, tell players what's known, coordinate, review.
3. **Players Before Plans has no story in your material.** Give the honest branch in C1: say so plainly, then offer the nearest thing you actually did.

Two research notes. The news about Project Larkspur and the GDC talk came from search snippets, not full pages. The talk's domain isn't one I can confirm, so check it before you quote Tobias's argument back to him.

I can play the Skeptic on B1 if you want to drill it. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to? The answer changes how the banks are weighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager (treated as such; see Loop below). Round: a single 60-minute interview, the Outage Hour. Built from your message and the JD you pasted, plus one round of public research (L1).

## How to use this pack

- **Personas** describe how a question will arrive. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (the listed job), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Say it in your own words, and only the parts you did.
- Answer slots (sentences that start "if you…") are instructions for the interview. They ask for nothing here.

## Loop

The careers page says every Saltmarsh loop is a recruiter call, then the Outage Hour: a single 60-minute interview with the hiring manager, a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home. Your invite matches that format, so this pack prepares for one session with a tabletop and a values conversation. I have treated Tobias as the hiring manager because the page says the Outage Hour is with that role. The message asks you to confirm.

## Fit snapshot

Each JD line is quoted from your JD. Each evidence cell holds only your own sentences, quoted, with the source named.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material shows one title and weekly content drops, not live events across two. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you have planned or set cadence across more than one product, say how, in your own words; if not, say so and say how you would sequence one calendar for two. |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [grounded] | discovery | Your material shows QA working from your checklist, and nothing about the other four teams. Answer slot: if you coordinated any of design, art, engineering or community on an update, say which and what you did; if you did not, say so and say how you would set that coordination up. |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting numbers reaches the KPI report, not owning the review or choosing the KPIs. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs were reported or ran a post-event review, say what you did; if not, say so. |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote reaches the requirement in role terms, but "wrote" is not "manage", and the material does not say how the checklist is kept up. Words: "I wrote the release checklist our QA team still uses." Do not add "managed". |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | transferability | Four years matches the length. The quote does not say whether the studio's games were live-service after launch. This is a length requirement, not a gate, so it is graded like the others. Answer slot: if the puzzle game ran content after launch, say what it was; if not, say so. |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | The quote reaches the requirement directly. Expect a probe on scope (one title), which F1 covers. |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you presented the numbers. Presenting is not building or analysing them. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you can explain how a retention figure is calculated, say so in your words; if not, say you would check it first. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | The quote reaches the requirement in role terms: a written artifact a team still uses. It is one artifact, and the pack claims no more than that. |

Stated negatives, not JD lines but likely to come up: "Never led a team, and never worked on a game with in-app purchases." — your message. These are yours to acknowledge plainly (see B2 and the prohibited list).

## Prohibited claims

Claims this pack will not coach, and why. Each has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope: one title, weekly content drops. The limit is the pack's own observation: your material says one title, not two. |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote: presented the monthly retention numbers. |
| Managed the release checklist with QA | Inflated form of F4 | "I wrote the release checklist our QA team still uses." |
| Led a team | Negative you stated | "I haven't led a team." |
| Worked on a game with in-app purchases | Negative you stated | "I haven't worked on a game with in-app purchases." |

## Reading the interviewer

Public footprint only.

- **Role:** Head of Live Operations at Saltmarsh Games (company search result).
- **Career pattern:** a QA lead at a console studio, then live operations (description on a GDC 2026 talk page, search result).
- **Self-described argument:** "a live team is judged by how often its patch notes describe what actually shipped." This comes from the talk description on the search result. I could not fetch the page, and its domain is not one I can confirm as GDC's. Check the talk on the official GDC schedule before you quote him.

Implications:
1. Patch-note accuracy is his frame. Expect probes on announcing what is built. The company's "Ship the Patch Not the Promise" value says the same thing (see the values section).
2. His QA background makes release-checklist questions likely to land hard (A4, C3, R5).
3. Mirror opportunity: F4's sentence, "I wrote the release checklist our QA team still uses," sits beside his QA path. This is a shared professional domain, not a shared career jump, so do not describe it as one.

## Persona table

Weights come from the hiring-manager prior, the documented loop (a tabletop and a values conversation), and his public talk. Depth follows weight: 5, 4, 4, 3, 2.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (weight 5) | The Outage Hour's live-incident tabletop, then a live problem on the calendar | Highest. The loop documents the tabletop, and a hiring manager buys capability. | Clarify, then stabilise, then tell players what is known, then coordinate, then review. Think aloud. |
| Skeptic (weight 4) | "Why two titles, when you ran one?" and "You haven't led a team" | High. The two-title and coordination gaps (F1, F2) are the likeliest objections from a hiring manager. | Rehearse B1 until it is plain. Acknowledge the stated negatives in one line, then move to what you would do. |
| Values / Behavioral (weight 4) | The values conversation that closes the Outage Hour | High. The loop documents it, and the page names three values. | Map a story to each value where a quote carries one; otherwise use the selection scaffold and its honest branch. |
| Data-Driven Prober (weight 3) | Questions about how the retention figure was counted | Moderate. Retention is a JD line, and he runs a live team where patch notes are measured. | Say what you know about how the figure was built, and say plainly when you do not know. |
| Pressure / Stress (weight 2) | Time-boxed challenge on why you over an internal candidate | Lower. The loop as published has no composure round. Kept at weight 2 so the pack still touches it. | Pause, restate, hold on the calendar evidence, then concede what is true, specifically. |

## Question banks

Provenance comes first in every row. Quotes are yours unless a row says otherwise.

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event goes out with a reward missing for part of the player base six hours in. Walk me through the first hour." | CASE | [generic] pattern for live incidents | Speak it as a sequence. Clarify: which players, which build, how many, and what the event clock says. Decide whether to pause the event or the reward. Tell players only what is known. Get engineering and QA on the cause. Name who owns the next update. Keep it to two minutes. | The tabletop is the Outage Hour's core, per the loop page. [generic] because it is a pattern for the problem, not a Saltmarsh process. No claim about your past. |
| A2 | "You're asked to plan one events calendar across two titles. What do you need to know before you draft the first month?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" — JD | Ask which titles, which teams sign off each update, the release windows, the KPIs per title, and where the community team's calendar sits. Answer slot: if you have planned across more than one title, say how; if not, say so and give this sequence. | F1 is the gap; this asks for the plan without claiming any past. |
| A3 | "What do you know about how the company is organising live operations this year, and what would you ask first?" | CO | [grounded] research: search result for saltmarshgames.com/news/project-larkspur, "one shared events calendar from February 2027" | Name what you have read, in the company's terms: a shared events calendar for two titles from February 2027, and per-title event teams being retired. Say you read it in the announcement, not that you know the internals. Then ask about the new calendar owner's remit. | Meets the CO rule at L1. Only the search snippet was read, so keep the claim to what it says. |
| A4 | "Walk me through the release checklist with QA: what it checks, who signs it, and what happens when a check fails." | JD | [grounded] "Wrote the release checklist our QA team still uses." — your message | Answer slot: say what you wrote and what it checks, in your own words. If QA signs, say that. If a check fails, say what happens, and if you did not own that step, say so. If you changed the checklist after a release, say what changed and why. | F4 is the evidence. "Manage" is not in the quote, so do not claim it. |
| A5 | "Retention dropped after an event. Write the three-line update you would send the team before the review." | CASE | [generic] pattern for a written update | Three lines: what changed, what you know and do not, what you will check first, and who gets it. Written, short, and no claim about your past. | Covers F8 (clear written communication) under a live metric. [generic] because it is a pattern. |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've run one calendar for one title. Why should we trust you with two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Highest-ROI prep. Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Hold through two follow-ups by returning to that calendar. Concede specifically: "I haven't planned across two titles." Then give the sequence from A2. Answer slot: if you have set cadence across more than one product, say how; if not, say so. Never describe a two-title calendar. | F1 is the largest gap and the most predictable objection. It will arrive in some form, and a rehearsed, non-defensive answer changes the interview. |
| B2 | "You haven't led a team. This role coordinates four teams on every update. How do you get design, art and engineering to move when you have no authority over them?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message | Plain acknowledgment: "I haven't led a team." Then the answer slot for F2: if you coordinated any of those teams on an update, say which and how; if you did not, say so and say how you would set that up. | Stated negative, so the acknowledgment has a source. F2 is the discovery gap. |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] persona stem | Answer slot: name the part you expect to be weakest, and how you would learn it first. Anchor in F1 or F2 only as they appear in your own words. | Standard Skeptic stem. The answer names a weak area and a learning plan, not a claim about your past. |
| B4 | "Your retention numbers. Did you produce them, or present them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Hold: "I presented the monthly retention numbers to the studio head." Answer slot: if you built or checked any of the figures, say which; if you only presented them, say so. | F7 is presentation, not analysis. The question tests attribution. |

### Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [generic] selection scaffold; no quoted sentence carries this story | Pick a time a date or cadence ran against what players were asking for. It needs a decision you made, a named cost, and what you did for players. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the weekly content-drop calendar (F6). | Players Before Plans. No quote carries a players-versus-calendar story, so this is a scaffold. |
| C2 | "Tell me about a time you had to tell players something would slip." | VAL | [generic] selection scaffold | Pick a slip with a named cause and a message that said what was built, not what was hoped. If none comes to mind, say so plainly, then give the nearest: the checklist you wrote (F4), and only what you know it checks. | Ship the Patch Not the Promise. Scaffold with an honest branch. |
| C3 | "What did you change in the release checklist after a release, and why?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." — your message | Answer slot: if you changed it after a release, say what changed and why. If you did not, say so, and say what you would add first. | Leave the Build Greener means the checklist leaves better than it found it. The quote does not show that, so the answer must come from you. |
| C4 | "What does a live team owe players that the calendar does not?" | VAL | [generic] open prompt | Answer with one specific decision, not a principle. If you have one from your own work, say it. If not, say what you would do, marked as a plan. | Values conversation in general. |

### Your experience, probers (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What went into the retention figures you presented?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Answer slot: if you know how the figures were built, say so in your own words; if not, say you would check before answering. No figure was given, so no defend-the-number slot applies. | F7. Open prompt, so it presupposes no method. |
| D2 | "Walk me through one weekly drop, from plan to live. Who else had a say before it went out?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Set out one drop, then who else had a say. Answer slot: if you set the cadence, say so; if someone else set it, say who. | F6 and attribution. The question asks who had a say, which does not presume a sign-off process. |
| D3 | "What does a post-event review look like, and which KPIs does it report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Answer slot: the JD raises post-event reviews, and your material does not show one. If you ran or fed a review, say what it covered and which numbers. If you did not, say so and say what you would put in one. | F3. The second branch allows that no such review existed for you. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate with more years on a live title?" | JD | [generic] persona stem | Pause and restate. Anchor in what you stated: "I ran the weekly content-drop calendar for our main title for the last two years." and "4 years as an associate producer at a puzzle-game studio". Hold through two follow-ups. Answer slot: if the internal candidate has more years on these titles, say so, then say what you would bring instead. | F5 and F6. Hold on the calendar evidence. Concede only what is true. |
| E2 | "That retention presentation. How much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Hold: "I presented the monthly retention numbers to the studio head." Hold through two follow-ups. Concede specifically: name the parts you did not build. | F7 and attribution under pressure. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | F1: A2, B1 |
| coordinate design, art, engineering and community teams on each update | F2: A1, B2 |
| own the post-event review and the KPIs it reports | F3: D3, B4 |
| manage the release checklist with QA | F4: A4, C3 |
| 3+ years producing live-service games or apps | F5: E1 |
| experience running a content calendar | F6: D2 |
| comfortable with player-retention metrics | F7: D1, E2 |
| clear written communication | F8: A5 |

Session total: 18 questions (5, 4, 4, 3, 2). No JD requirement is left without a question.

## Values / principles cheat sheet

Source: the values page, fetched. Three values, by name.

| Value (official name) | Working meaning (paraphrased) | Candidate's mapped story |
|---|---|---|
| Players Before Plans | When the calendar and players disagree, the players win. | No quote carries this story. Selection scaffold: C1. Nearest material: F6. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | No quote carries a slip story. Selection scaffold: C2. Nearest material: F4. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | F4's quote carries the artifact, not the improvement. Answer slot: C3. |

## Reverse questions

Each one has a reason it lands.

1. "Two titles are moving onto one events calendar from February 2027. Who owns that calendar day to day?" Why it lands: it tests the owner's remit and shows you read the announcement.
2. "When a player-facing date and a player-facing promise conflict, who decides?" Why it lands: it tests Players Before Plans in practice, which a values-focused hiring manager will weigh.
3. "You came to live operations from QA. What do you still check before a patch note goes out?" Why it lands: it ties to his public path. Use only after you have verified the talk.
4. "How often does the Outage Hour scenario come from a real incident?" Why it lands: it shows you know the loop, and turns the tabletop into a conversation.
5. "What would a producer's first thirty days on the release checklist look like?" Why it lands: it signals that the QA interface matters to you.

## Prohibited claims

See the list above the persona table. Every guidance cell in the banks was written against it.

## Sources

Provided documents: your message (background and JD text). No dossier was supplied.

Searches and fetches, every call sent:

| Call | Query or URL | What came back |
|---|---|---|
| Search 1 | Saltmarsh Games values | saltmarshgames.com/values |
| Search 2 | Saltmarsh Games interview process live operations producer | saltmarshgames.com/careers/interviewing |
| Search 3 | Saltmarsh Games mobile studio news strategy | saltmarshgames.com/news/project-larkspur (snippet only, not fetched) |
| Search 4 | Tobias Wrenfield Saltmarsh Games Head of Live Operations | talks.gdconf.example/2026/patch-notes-are-a-promise (snippet only, not fetched; domain not confirmed) |
| Fetch 1 | https://saltmarshgames.com/values | Three values by name, with working meanings |
| Fetch 2 | https://saltmarshgames.com/careers/interviewing | The loop: recruiter call, then the 60-minute Outage Hour |

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. saltmarshgames values | yes | Values cheat sheet, with the three values by name |
| 2. interview process, product role | yes | The loop; the Outage Hour's tabletop and values conversation; persona weights |
| 3. strategy / recent news | yes | A3 and reverse question 1. Read from the search snippet only. |
| 4. interviewer name and company | yes | Interviewer read; reverse question 3. Snippet only; domain unconfirmed. |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Target 6 onward (deep research) did not run.

## Upgrade menu

- Recruiter confirmation that Friday is the Outage Hour as published → confirms the session format and the persona weights
- The two titles' names. The news names Tidepool Tactics and Lantern Row; if those are yours, the reverse questions can name them → tighter A2 and B1
- Any retention figure you can give, and how it was counted → the defend-the-number slots in D1 and E2
- Whether the puzzle game ran content after launch, with an example → F5 moves from transferability to grounded
- The full Larkspur announcement page, which I did not fetch → firmer A3 and reverse question 1
- The GDC talk on the official schedule → verifies the interviewer read and reverse question 3
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes. Covers the company strategy brief, Tobias's talks and writing, role-family loop reports, and recent org changes. Want it? (offered once)
- A tuesday-dossier.md recording the gaps this prep exposed → would sharpen B1, the highest-ROI objection
