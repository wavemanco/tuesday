Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-2-rooms-case-3-denied-9a1f2b24/da886d15-b894-4418-83cf-545f7078cc73/scratchpad/stripe_product-operations-manager_interview_pack.md. It's built on the company and title alone, because I had no CV or job description. Web search was refused in this session, so nothing in it about Stripe's values, interview loop or strategy is sourced. Those parts are labelled [generic] and the Sources section says so.

Its highest-return prep is B2, "Why this role, and why now?" It comes up in nearly every final, and without your CV there's no stronger material to draw on yet.

Say the word and I'll play the Skeptic on B2 as a drill. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.

Two things would make the pack much better:

1. Who is in the final round, and in what format? One interviewer, a panel, or a presentation?
2. Can you paste the job description and your CV? With those, the requirements become quoted, and the answers can be built from your own sentences.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

Interviewer: not known. Relationship to interviewer: not known. Round format: not known. Built on: the company and role title only. No CV, no job description, no web research (see Sources).

## How to use this pack

- **Personas** describe how a question is asked (the register and the pressure). **Types** describe what is being scored.
- Type key: **JD** = the role's stated work; **EXP** = what you actually did; **CO** = how well you understand the company's direction; **CASE** = a live problem you reason through; **VAL** = behaviour against stated values (not used here, see Sources).
- Guidance is scaffolding, not a script. Rehearse it out loud in your own words.

## Fit snapshot (worksheet variant)

No CV and no job description were provided, so no requirement is quoted and no evidence is on record. Requirements below are role-family patterns, not this posting's text. Every evidence cell is "none given". Fill the evidence column from your own sentences once you share your CV or the posting.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run cross-functional operating processes from start to finish | none given | none | [generic] | discovery | Selection scaffold: pick one process you changed that other teams depended on. Say what changed, who had to act, and how you knew it worked. If no such process comes to mind, say so plainly, then give the nearest thing you have done. |
| F2 | Build and maintain metrics that leaders use to make decisions | none given | none | [generic] | discovery | Selection scaffold: pick a metric you owned or relied on. Say how it was defined and what it could miss. If you never owned one, say so and say what you would measure first. |
| F3 | Land launches or process changes with teams you do not manage | none given | none | [generic] | discovery | Selection scaffold: pick a change you drove without authority over the people involved. Say how you got buy-in and what you did when someone disagreed. If none comes to mind, say so plainly, then give the nearest case. |
| F4 | Run a recurring operating cadence, such as a business review or planning cycle | none given | none | [generic] | discovery | Selection scaffold: describe a recurring review or planning meeting you ran or sat in on. Say what decisions came out of it. If you have not run one, say so and say how you would set it up. |
| F5 | Work with the controls, policy or vendor side of operations | none given | none | [generic] | discovery | Selection scaffold: pick a case where a policy, control or vendor affected a process you ran. Say what you did about it. If there was no such case, say so and say how you would find out where the risks sit. |

## Prohibited claims

No entries. This list is built from the fit snapshot, and the snapshot holds no sentence of yours to stretch. Once a CV is shared, each claim you are likely to over-reach on will be listed here, with the sentence it came from.

## Persona table

Relationship and round are unknown, so this pack uses flat weights, not a tilt. Each persona gets three questions. Weights would change once you know who is interviewing.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problem from the role, scored on structure | High. A final round usually includes at least one live problem | Clarify, then structure, then answer. Think aloud and name your assumptions |
| Skeptic | Quiet probing of gaps and motivation | High. "Why this role, why now" is asked in nearly every final | One rehearsed answer to the motivation question, and one real gap named with a plan |
| Pressure / Stress | Interruptions, time limits, challenge to a claim | Medium. Common in senior loops; unknown here | Pause, restate, hold a position through two follow-ups, then concede a specific point |
| Data-Driven Prober | Asks how a number was counted and what it leaves out | Medium. Ops roles are measured on metrics | Name the weakest assumption behind any figure before the interviewer does |
| Peer Evaluator | Seams between teams, disagreement, credit | Medium. Likely if the round includes a peer from a partner team | Propose seam principles, not invented detail. Show a disagreement you handled with spine and tact |
| Conversational / Rapport | Friendly openers that are still scored | High. Often the first minute of the round | Have a 90-second arc ready. Treat casual questions about the role as scored |

## Question banks

Provenance is [generic] throughout: no question rests on a sentence of yours. Where a question asks about your past, it is an open prompt with a selection scaffold and an honest branch.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A weekly review shows a key process missing target for three weeks. How would you diagnose it?" | CASE | [generic] | Clarify the metric and its definition first. Check whether measurement changed. Segment the problem. Talk to the owners. Then propose two options and a way to test them | Covers F1 and F4: diagnosis is the core of a cadence role |
| A2 | "We are moving a process to a new tool in six weeks. What do you need to know before you plan?" | CASE | [generic] | Ask about scope, owners, the risks the old process was covering, and how you would roll back. Name the first two things you would check | Covers F3 and F5: change with other teams and controls in play |
| A3 | "What would you need to learn about a company's priorities before proposing an operating change?" | CO | [generic] | Name where you would look: strategy documents, leaders' reviews, the owners of the roadmap. Do not claim knowledge of this company's priorities you have not checked | Tests how you learn before you propose. No research ran, so no company claim is made here |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about an operations process you improved that did not stick. What happened?" | EXP | [generic] | Open prompt. Choose one instance. Say what the change was, why it did not hold, and what you would change now. If no such time comes to mind, say so plainly, then give the nearest one | Covers F1. Skeptics probe whether change survives contact with teams |
| B2 | "Why this role, and why now?" | JD | [generic] | Name the work you want to do, in terms of what it involves, not the title. Give one honest reason for leaving or moving. Do not praise the company beyond what you can support | The highest-ROI prep in this pack: this question arrives in almost every final, and with no CV there is no stronger material to draw on yet |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one real gap, a plan to close it, and the person you would ask for help. Do not claim you already have it | Covers F2 and F4. Calibrated candor scores better than a bluffed competency |

### C. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over someone who has done this longer?" | JD | [generic] | Pause, then restate the question. Answer with one concrete thing you can do that the other candidate may not. Hold through two follow-ups. Concede one specific point, not the whole claim | Tests composure under a time box |
| C2 | "That result you are proud of. How much of it was actually you?" | EXP | [generic] | Open prompt. Pick a result. Split your part from the team's part, in your own words. If you did not carry one, say so plainly and name the nearest contribution | Attribution is the probe. Precise honesty scores better than a large claim |
| C3 | "You have two minutes. How would you cut our review meeting in half without losing decisions?" | CASE | [generic] | Name the decisions the meeting must make. Move the status items to written updates. Keep the decision items and set a time for each | Covers F4. A live problem with time pressure |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you would count whether an operations change worked." | CASE | [generic] | Define the metric and its baseline. Name a counter-metric that catches gaming. Name the weakest assumption before the interviewer does | Covers F2. Probers test the assumption, not the answer |
| D2 | "Which metric in an ops dashboard would you not trust, and why?" | JD | [generic] | Name a metric whose definition is contested, say why, and say how you would check it | Covers F2. Shows you read dashboards critically |
| D3 | "What did you count last time, and what did the count leave out?" | EXP | [generic] | Open prompt. Pick a count you kept. Say what it measured and what it missed. If you kept none, say so and say what you would count first | Covers F2 and F4. Tests whether you know your own numbers' limits |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam between us, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam: who decides what, and how disagreements escalate. Do not claim to know their team's detail | Covers F3. Peers price how you work with them |
| E2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Open prompt. Pick a shared piece of work. Say who did what and how you named it. If none comes to mind, say so and describe how you would handle it | Covers F3 |
| E3 | "What would you need from my team to do this job well?" | JD | [generic] | Name two specific things: information, decision rights, or a standing meeting. Do not promise anything on their behalf | Covers F1. Reciprocity signals that you plan to work with them |

### F. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | A three-beat arc, in your own words: the work you have done, what you did in it, why this role now. Under 90 seconds. The content is yours to supply; this pack does not supply it | Rapport openers are scored. The arc is a rehearsal device |
| F2 | "What are you playing with in operations tooling these days?" | JD | [generic] | Name one tool you have used, what it did for you, and one thing you would change about it. If you have used none, say so and name the one you would learn first | Casual register, scored content |
| F3 | "What is the part of this job that surprises people?" | JD | [generic] | Give one honest concrete answer that you could defend. Do not answer with a generic remark | Tests whether you have thought about the job, not only read the posting |

### Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| F1 Cross-functional process | A1, B1, E3 | |
| F2 Metrics leaders use | B3, D1, D2, D3 | |
| F3 Launches without authority | A2, E1, E2 | |
| F4 Operating cadence | A1, C3, D3 | |
| F5 Controls, policy, vendors | A2 | Only one question. Add a question once the posting is shared |

## Reverse questions

Each is for the end of the round. Ask one or two.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first ninety days look like in this role?" | Shows you plan for outcomes, not for the job description |
| R2 | "How is the operations team's work measured, and who decides whether a metric is working?" | Tests the metrics thread live and gives you the answer to D1's counting question |
| R3 | "Where do operations and product disagree most, and how is that settled?" | A seam question. It turns the interview into a working conversation |
| R4 | "What is one decision this team got wrong recently, and what changed afterwards?" | Shows you want the real picture, and lets them show candor |
| R5 | "Is there a take-home or presentation after this round?" | Process question. The answer decides how you prepare next |

## Delivery coaching

No working-style assessment was provided, so this section is omitted.

## Sources

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Every call was refused: web search permission was not granted in this session. Nothing below comes from a source. Company values, loop structure and current strategy are therefore not established, and the pack says so.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have moved the values cheat sheet. Not built, because no published values page is in hand. Values names are not supplied from memory. Calls sent: "Stripe company values operating principles" — refused |
| 2. Stripe interview process, product operations | unavailable | Would have named the rounds and set persona weights. Weights here are flat and stated as such. Calls sent: "Stripe interview process Product Operations Manager final round" — refused |
| 3. Stripe strategy and recent news | unavailable | Would have moved the CO questions. A3 stays generic and makes no claim about this company. Calls sent: "Stripe strategy 2026 news priorities" — refused |
| 4. Interviewer name and footprint | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Would have grounded the fit snapshot in quoted requirements. The rows above are role-family patterns. Calls sent: "Product Operations Manager job description responsibilities qualifications" — refused |

Dossier: none present. Provided documents: none beyond the company and role title.

## Upgrade menu

- The interviewer's name and role → a tailored reverse question, and persona weights read from their public footprint
- Who is in the round and in what format (one interviewer, a panel, a presentation) → the round's persona weights, and the mix of questions
- The job description, pasted → the fit snapshot's requirements become quoted and [grounded]; JD-tagged questions are written from the posting's own lines
- Your CV, pasted → the evidence column is filled from your sentences; selection scaffolds become story-mapped answers; the prohibited list gets its entries
- Web search permission, granted for a later session → values, loop structure and strategy checked. The pack's [generic] parts can then be upgraded. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available at your request
- Your recruiter's prep email → any deliverable the round requires, such as a presentation or take-home
