Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-2-rooms-case-7-denied-808c9f3d/3e0a56b5-3f8e-4f15-82bb-3fb8502c0d39/scratchpad/saltmarsh_live-operations-producer_interview_pack.md. I built it for a hiring-manager round, since your note didn't say who you're meeting. Web search was refused in this session, so nothing about Saltmarsh's values, interview loop, or strategy is in it yet.

The pack's main points:

- **Your biggest exposure is "never led a team."** The role coordinates four functions, so expect it to come up. The pack gives you one honest line ("I haven't led a team.") followed by a plan for coordinating without authority. Rehearse that answer hardest. It is question B1.
- **Your strongest material is the content calendar.** "I ran the weekly content-drop calendar for our main title for the last two years" covers the calendar requirement directly. It covers only one title, though, and the JD asks for two.
- **Your KPI and retention work is presentation, not ownership.** You presented the retention numbers. You did not say you built them or owned the post-event review. The pack keeps your claims at that scope.
- **Don't claim in-app purchase experience.** The JD doesn't ask for it, but a mobile studio may probe it. The honest answer is the plain "I haven't worked on a game with in-app purchases," followed by how you'd learn their model.

Would you like me to play the Skeptic on B1, the question the pack names as your highest-value prep?

I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your hiring manager, and is the 60 minutes one conversation or a panel? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager; not yet confirmed.
**Round:** one 60-minute session on Friday. Format (conversation or panel) not confirmed.
**Research:** web search was refused in this session. Nothing about Saltmarsh's values, interview loop, strategy or Tobias's public footprint is established. Company-specific content is therefore absent, and the banks use generic labels where it would have gone.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

- **EXP**: work-experience deep dive. Tests whether your claims hold up and what you actually did.
- **JD**: the role's stated responsibilities and requirements.
- **CASE**: a live problem from the role. Asks about no past.
- **VAL**: values. Not in this pack; no values page was established.
- **CO**: company strategy. Not in this pack; research was refused.

Guidance is scaffolding, not a script. Each guidance cell is written to be spoken in 90 to 120 seconds.

## Prep triage

Not included. Prep time was not stated.

## Fit snapshot

Requirements are quoted from the job description (JD) or from your message. "Your message" means the background you sent with this request.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | Years match. Your material does not say the studio's games were live-service; F2 is the nearest evidence. Words: "For four years I was an associate producer at a puzzle-game studio." The 3+ years is a length-of-experience requirement, so it is not a gate. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | The quote reaches the requirement directly. It is a claim with no inspectable artifact in the material, so expect a probe. Words: "I ran the weekly content-drop calendar for our main title for the last two years." |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material covers one title's calendar, not two. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Any wider step, such as planning across two titles, is an answer slot: if you planned or ran more than one title's calendar, say which and how; if you ran one, say so and say how you would plan two. |
| F4 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material is silent on coordinating these four teams. Answer slot: if you coordinated any of them on a drop, say which, what each needed from you, and how you decided what shipped. If the drops moved without you doing that, say so and say how the work reached each team. |
| F5 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Presenting numbers is adjacent to owning KPIs and a post-event review. The material shows neither ownership nor a review. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs went in, or ran a review after an event, say what and how. If not, say so and say what you would put in the review. |
| F6 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | The quote reaches the checklist in other terms: you wrote it and QA still uses it. It does not say you ran releases through it. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you ran a release through it with QA, say how it went in your own words. If you did not, say so. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote shows you presented retention numbers. It does not show that you built or analysed them. Words: "I presented the monthly retention numbers to the studio head." The pack's own observation: the material does not show how those numbers were built. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | One written artifact used by another team is the only written evidence in the material. The derivation is from F6's quote. Answer slot: name the written thing you would point to first, and say who used it. |
| F9 | Team leadership. No JD line names it; [generic] for a role that coordinates four functions | "Never led a team" (your message) | none | [grounded] | capability | Stated absence. Words: "I haven't led a team." Then a plan, not a past: how you would coordinate four functions without a team of your own. |
| F10 | In-app purchases. No JD line names them; [generic] for a mobile title's monetisation | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Stated absence. Words: "I haven't worked on a game with in-app purchases." Then a plan: how you would learn this studio's monetisation model. |

**Gap types.** F2 is none because the quote already reaches its requirement. F9 and F10 are capability because you stated the absence. F4 is discovery because the material is silent and you have stated no absence.

## Prohibited claims

What this pack will not coach, and why. Built locally from the fit snapshot, since no dossier was present.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the post-event review or its KPIs | Inflated form of F5 | F5's quote at its own scope. The pack's observation: your material says the numbers you presented, not the review or how the KPIs were defined. |
| Ran calendars for two titles | Inflated form of F3 | F2's quote at its own scope. The two-title scope gets an answer slot, not a claim. |
| Managed releases through the checklist with QA | Inflated form of F6 | F6's quote: "I wrote the release checklist our QA team still uses." |
| Built or analysed the retention figures | Inflated form of F7 | F7's quote: presented, not built. |
| Led a team | Sourced negative, F9 | "I haven't led a team." No answer slot. |
| Worked on in-app purchase economics | Sourced negative, F10 | "I haven't worked on a game with in-app purchases." No answer slot. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (top) | Live planning problems on a calendar and a coordination seam | Top weight. A hiring-manager round for a calendar role usually tests live planning. 5 questions. | Clarify, then structure, then plan. Speak plans as plans, never as history. |
| Skeptic (top) | Probes on team leadership and the two-title scope | Top weight. F9 and F3 are the likeliest objections. 4 questions. | Plain acknowledgment, then a plan. Rehearse B1 until it is boring. |
| Data-Driven Prober (mid) | Asks how a retention figure was built | Mid weight. Retention is a named requirement and a presented figure invites scrutiny. 3 questions. | Say what you presented and where it came from, and no further. |
| Pressure (low) | Tests composure on the puzzle-game background | Low weight. The four-years line is the likeliest place to be pushed. 2 questions. | Restate, anchor, hold through two follow-ups, concede precisely. |
| Peer Evaluator (low) | Seam questions between design and engineering | Low weight. The coordination line invites this. 2 questions. | Seam principles, not an invented seam. |
| Conversational (low) | Friendly opener and a casual check on live-service | Low weight, but casual questions are still scored. 2 questions. | A rehearsed 90-second arc. Name only titles you actually play. |
| Values/Behavioral | Not weighted | No values-style round is detected. No loop source was established, and the fallback archetype reads no. | None. |

**Loop.** No loop source established the rounds. The fallback archetype is Generic (screen, hiring manager, panel), so the weights above rest on a pattern for this kind of role, not on this company's documented process.

## Question banks

Question IDs are letter-by-persona. Provenance holds the candidate's own sentences that a guidance cell relies on. A [generic] label means the question makes no claim about your past.

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two titles, one calendar: how would you plan the next quarter of live events?" | CASE | [generic] | Clarify first: each title's goals, the drop cadence it runs on now, and what each team needs before a drop. Then objective, the teams touching each update, the sequence, the risks, and a checkpoint. Speak in plans, not past events. | JD line 1 is the requirement. A live problem presupposes nothing about your past, so the label is [generic]. |
| A2 | "Walk me through how you ran the weekly content-drop calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Tell the calendar in the quote's terms: the weekly drop, the main title, the two years. Answer slot: which parts were yours to set and which came from elsewhere. Say so plainly either way. | F2. This tests the content-calendar requirement. |
| A3 | "You ran a calendar for one title. How would you run one across two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what you ran, then your plan for two titles, marked as a plan. Answer slot: if you have planned across more than one title before, say how. If not, say so, and say what you would sequence first. | F3, transferability. The two-title scope is the gap. |
| A4 | "On a drop, design wants to ship a change engineering has not signed off. What do you do?" | CASE | [generic] | Clarify what the change is and what the date depends on. Name who decides, decide, record the decision, and tell the teams. Keep the structure visible while you talk. | JD coordination line (F4). A live problem, so no claim about your past. |
| A5 | "What do you need from design, art, engineering and community before a drop is locked?" | JD | [generic] | Name the handoff each team needs and the lead time each one needs. Plan, not history. | JD coordination line (F4). |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never led a team. How would you coordinate four functions without a team of your own?" | JD | [grounded] "Never led a team" | Start with the plain acknowledgment: "I haven't led a team." Hold: then the plan. Name the four functions, the decision rights you would ask for, and the record you would keep. Hold through two follow-ups by returning to the plan. Concede specifically: if asked for a case where you led one, say you have not led one. Never describe leading. | F9. The highest-ROI prep in this pack: it is the most predictable objection, and the material has no answer to it except the plan. Rehearse this one deepest. |
| B2 | "Have you worked on a game with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." Then how you would learn this studio's model: the title's purchase data, the design team, the economy documents. As a plan, not a past. Do not describe monetisation you did not touch. | F10. The JD does not name in-app purchases. The probe is likely because the studio makes mobile games; that is a [generic] pattern. |
| B3 | "Which KPIs did you own, and which were set for you?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if you chose which numbers went to the studio head, say which and why. If they were set for you, say so plainly, and say what you would bring to the KPI definitions. Hold on what you presented. | F5. The JD raises KPIs, so the premise is sourced. |
| B4 | "Tell me about a post-event review you were part of." | JD | [generic] | Open prompt. If you were part of one, say what you did in your own words and what you did not do. If you have not been part of one, say so, and describe how you would structure one. | F5, transferability. The JD raises the post-event review, so the theme is sourced. |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which retention figures did you present, and where did they come from?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if you built or checked a figure, say how, in your own words. If you passed on figures someone else built, say so. Name an assumption behind a figure only if you know one. | F7. No figure is given in the material, so no defend-the-number slot applies. |
| C2 | "How did you judge whether a content drop worked?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Open. Say what you looked at, in your words. If you judged drops by a number, name it and say how it was measured. If not, say so. | The JD raises player-retention metrics and KPIs. |
| C3 | "Walk me through the release checklist you wrote. How does QA use it?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Say what the checklist covers and how QA uses it, in those words. Answer slot: if you ran a release through it with QA, say how it went. If not, say so. | F6. This is the only question for the release-checklist requirement. |

### D. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone with four years on a puzzle game for a live-service role?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | Hold: restate the question, then anchor in the calendar you ran, in F2's words. Hold through two follow-ups. Concede specifically: if the titles you worked on were not live-service, say so plainly. Do not argue the label. | F1, presentation. The 3+ years requirement. |
| D2 | "Of the content calendar you ran, which part was yours?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the calendar you ran. Name exactly which decisions were yours and which were not. Concede precisely, and never fold on what you ran. | F2 and F3. Hold-then-concede. |

### E. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Design and engineering sit side by side on every drop. Where's the seam, and what happens when you disagree?" | JD | [generic] | Offer seam principles, not an invented seam: who decides scope, who decides the date. Name one disagreement you handled, if you have one. If not, say how you would handle one. | F4. The raising source is the JD's coordination line. |
| E2 | "How do you handle credit when a drop spans teams?" | EXP | [generic] | Persona stem. Say what you credit, in your own words. Keep "we" for shared work and "I" for what you did. | F4. Open prompt. |

### G. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc: the four years, the content calendar, the checklist, the retention presentation. Use the words you used. Do not add a role you did not hold. | F1, F2, F6, F7. The arc uses only the four quoted sentences. |
| G2 | "What live-service titles are you playing right now?" | JD | [generic] | Name a title you actually play and say what you notice about its calendar. If you do not play live-service titles, say so. | The JD's live-service requirement, asked casually. Casual questions are still scored. |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, A3 (F3) |
| Coordinate design, art, engineering and community teams on each update | A4, A5, E1, E2 (F4) |
| Own the post-event review and the KPIs it reports | B3, B4 (F5) |
| Manage the release checklist with QA | C3 (F6) |
| 3+ years producing live-service games or apps | D1, G2 (F1) |
| Experience running a content calendar | A2, D2 (F2) |
| Comfortable with player-retention metrics | C1, C2 (F7) |
| Clear written communication | none, and why: the interview is spoken, and no question here tests written work. The upgrade menu asks for a written sample. |

Question count: 18.

## Reverse questions

Each has a "why it lands." No interviewer profile exists, so none is tied to Tobias's own career path.

1. "What would a strong first 90 days on the calendar look like?" Why it lands: it shows you are planning, not just interviewing.
2. "Which of the two titles is harder to keep on schedule right now, and why?" Why it lands: it asks for the team's real problem and ties to A1 and A3.
3. "Who owns the post-event review today, and how are its KPIs chosen?" Why it lands: it tests F5's scope from their side.
4. "Where does coordination between design, art, engineering and community break down most often?" Why it lands: it shows where the seam is, which is what E1 rehearses.
5. "What would make someone who has never led a team succeed in this role?" Why it lands: it turns the gap into a shared question and shows you know it is there.

## Sources

Research tier: L1, searches 4 of 6, fetches 0 of 2. All four searches were refused, so no result came back.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, section 10 of the template. Not included, because no published values were established. |
| 2. Saltmarsh Games interview process | unavailable | Loop structure. Persona weights rest on the Generic archetype. |
| 3. Saltmarsh Games strategy or recent news | unavailable | CO bank. Without it, the case questions are labelled [generic], not company-grounded. |
| 4. Tobias Wrenfield with Saltmarsh Games | unavailable | Interviewer read, persona weights, and a reverse question tied to his path. |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Queries sent, all refused:
- "Saltmarsh Games values"
- "Saltmarsh Games interview process live operations producer"
- "Saltmarsh Games mobile game studio news strategy"
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations"

Provided documents: the job description and your background, both as you sent them. No links were read.

## Upgrade menu

- A pasted Saltmarsh values page or careers page → a values cheat sheet, and the loop structure. Neither is in this pack.
- Saltmarsh's recent news, or the names of its two titles → a CO question grounded in current strategy. The case questions would then go beyond [generic].
- Tobias's public talks or posts → an interviewer read, and a reverse question tied to his career path.
- A written sample, such as the release checklist itself or a retention summary → F8 becomes grounded, and a written-work question is added.
- Whether the two titles are live-service, and whether they use in-app purchases → sharpens F1 and the B2 probe.
- Permission for web search in this session → the research pass that fills the four refused targets.
- A tuesday-dossier.md from an earlier session → verified evidence for the fit snapshot, and any limits already recorded on your claims.
