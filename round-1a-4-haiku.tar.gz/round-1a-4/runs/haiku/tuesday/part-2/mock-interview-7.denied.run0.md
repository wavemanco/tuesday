Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-tuesday-part-2-rooms-case-7-denied-2a6dc6cd/4d20372c-906d-4d36-916c-bb0eae4bdaf8/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md. I built it for a hiring-manager round, since you're meeting the Head of Live Operations.

The research didn't run. The web searches were refused, so the pack has nothing on Saltmarsh's values, interview format, strategy, or Tobias's background. Everything is built from the JD and your message.

What to rehearse, in order:

- **Highest-ROI prep (S5):** "You've never led a team, and this role coordinates four of them on every update. Why should we hire you?" Hold on the calendar you ran and the checklist QA still uses. Then concede plainly that you haven't led a team. Don't claim leadership, even under pressure.
- **Coordination (S3):** The JD asks about coordinating design, art, engineering and community on each update, and your message doesn't show that. Have a real example ready if you have one. If you don't, say so and describe how you'd set it up.
- **Two titles (S1):** You ran one title's calendar. Name where you expect a second title to strain.
- **In-app purchases (S4):** Say you haven't worked on an IAP game, then describe what you'd study first.
- **Retention (P1, P2):** Have a clear answer on how the retention figure was counted and what it changed. If you don't know either, say that.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

Is Tobias your direct manager, or a level above? Does the 60 minutes include a live exercise, a presentation or a take-home?

If you want, I can run a drill where I play the Skeptic on S5. I can also save a tuesday-dossier.md recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Saltmarsh Games: Live Operations Producer, interview prep pack

Role: Live Operations Producer. Company: Saltmarsh Games (mobile games, about 350 people). Interviewer: Tobias Wrenfield, Head of Live Operations. Round: hiring-manager round, 60 minutes, Friday. Built for a hiring-manager round; the Head of Live Operations is the person you are meeting.

## How to use + type key

- Personas = how a question is asked. Types = what is being scored.
- VAL: behavioral / values. EXP: work-experience deep-dive. JD: role and JD-driven. CO: company knowledge. CASE: live hypothetical problem.
- Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message. Nothing here comes from research: the company, loop and interviewer searches were refused, so the pack has no company values, interview format, strategy or interviewer profile.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title and weekly content drops, not two titles or live events. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD is about two titles, so expect a probe on how you would plan across both. If you planned for a second title or for events beyond content drops, say which and how; if you did not, say so and say how you would set it up. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination with these teams. Answer slot: name a content drop and the teams you worked with on it, and what each one did; if someone else coordinated them, say so plainly. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | transferability | Presenting retention numbers is adjacent to owning KPIs and a post-event review. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: say whether you chose which metrics were reported, and whether any post-event review existed in your work; if not, say so. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | Closed. Caveat: the checklist itself has not been inspected here, so expect a probe on how QA uses it. If you can bring a copy, do. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | presentation | The years meet the number. Your material does not say "live-service". Bridge: "I was an associate producer at a puzzle-game studio for four years." Describe the weekly content drops in your own words; do not add the live-service label as your claim. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | Closed. Caveat: one title only. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | transferability | Your material shows you presented retention; it does not show how you defined or analysed it. Answer slot: which definition of retention you used, and what you did when the number moved. If you did not define it yourself, say so. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The checklist is writing that others use. Bridge: "I wrote the release checklist our QA team still uses." If you have a writing sample you can point to, bring it. |
| F9 | Not in JD. Stated by you. | "Never led a team, and never worked on a game with in-app purchases." (your message) (led a team) | none | [grounded] | capability | Plain acknowledgment: "I haven't led a team." Then how you would learn it, said as a plan, never as a past. The role coordinates four teams, so expect a probe. |
| F10 | Not in JD. Stated by you. | "Never led a team, and never worked on a game with in-app purchases." (your message) (in-app purchases) | none | [grounded] | capability | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then how you would learn it as a plan. Mobile-title monetisation may come up. |

Gate rule check: none of the JD requirements is a term gate (location, right to work, credential). The three-plus years is graded on fit, not as a gate.

## Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| Plan and run the live-events calendar for two titles | S1, C2, C4, P3 | |
| Coordinate design, art, engineering, community on each update | S3, C1 | |
| Own the post-event review and KPIs | C3, P3, P2 | |
| Manage the release checklist with QA | C1, P4 | |
| 3+ years producing live-service games or apps | V1 | Covered by fit row F5 |
| Experience running a content calendar | S1, P4 | |
| Comfortable with player-retention metrics | P1, P2, R3 | |
| Clear written communication | V1 | Covered by F8; no separate question |

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar for two mobile titles | Inflated form of F1 | F1 at its own scope: "For two years I ran the weekly content-drop calendar for our main title." Your material says one title, not two. |
| Led the post-event review and set its KPIs | Inflated form of F3 | F3 at its own scope: "I presented the monthly retention numbers to the studio head." |
| Has led a team | Negative you stated (F9) | "I haven't led a team." |
| Has worked on a game with in-app purchases | Negative you stated (F10) | "I haven't worked on a game with in-app purchases." |

## Persona table

Relationship prior: hiring manager, so Case/Strategist and Skeptic lead. No interviewer profile was found, so there are no interviewer-signal adjustments. No loop source establishes the loop, so the weights are an archetype pattern (generic), not this company's documented process. Round length is 60 minutes.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the two stated gaps (team leadership, in-app purchases) and of the one-title scope | Highest: the gaps are in your own message and the JD asks for coordination you do not show | Rehearse the team-leadership objection until it is routine; plain acknowledgment, then a plan |
| Case/Strategist | Live update or retention problem from the roadmap | High: hiring managers buy capability and test it live | Clarify, then structure, then decide; think aloud |
| Data-Driven Prober | How the retention figure was counted; what the checklist caught | Medium: the retention line is the most quantified thing you have said | Name the weakest assumption before they do; say what you do not know |
| Pressure | Holds your leadership gap and your "presented, not owned" line | Lower but real at 60 minutes | Pause, restate, hold through two follow-ups, then concede specifically |
| Conversational | Opener: walk me through your path | Certain as an opener, low in scoring weight | Use a 90-second arc built only from your quotes |

## Question banks

Weights: Skeptic 5, Case/Strategist 4, Data-Driven Prober 4, Pressure 3, Conversational 2. Total 18.

### Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You ran one title's calendar. We run two. Where would your process break first?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Describe the process for the one title in your own words. Name the first place you expect a second title to strain, as your reasoning, not as something you did. Answer slot: if you planned across two titles or events, say which and how; if you did not, say so and say how you would set it up. | F1 is the strongest match and the likeliest place to be probed. JD because it scores the calendar requirement. |
| S2 | "Have you ever led a team?" | Skeptic | [grounded] "Never led a team" | Plain acknowledgment: "I haven't led a team." Then one plan: how you would learn to coordinate four teams, as a plan, not a past. Hold no claim of leadership. | F9 is a stated negative; the question is the honest entry point. |
| S3 | "Walk me through a live update you coordinated across design, art, engineering and community." | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Answer slot: if you coordinated across those teams on a content drop, name each team and what each one owned. If you did not, say so plainly and describe how you would set it up. | F2 has no quote. The JD raises coordination, so the question is premised on it; the second branch lets the premise be false. |
| S4 | "What do you know about how in-app purchases shape a mobile live calendar?" | JD | [grounded] "Never worked on a game with in-app purchases." | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say what you would study first, as a plan. Answer slot: if you have seen content drops change spending in any game, say what you saw; if not, say so. | F10 is a stated negative. Expect this as a monetisation probe. |
| S5 | **Highest-ROI prep.** "You've never led a team, and this role coordinates four of them on every update. Why should we hire you?" | Skeptic | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Hold through two follow-ups: return to the calendar you ran and the checklist QA uses. Concede specifically: "Leading the four teams is not something I've done." Do not claim leadership. | This objection is the likeliest and most damaging. Deepest rehearsal: the hold is only what you have said, and the concession is named before it is asked for. |

### Case/Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "QA finds a blocker in a drop that goes live Thursday. What do you do?" | CASE | [generic] | Clarify: how severe, who owns the decision. Check the checklist for what it covers. Bring in engineering and QA; decide ship or hold; tell community what changes. | A live problem from the release checklist requirement. [generic] because it asks for a structure, not a past. |
| C2 | "One title's day-7 retention dropped three points after last month's update. Where do you start?" (hypothetical figure) | CASE | [generic] | Clarify the definition and cohort first. Segment by platform and by version. Check what the update changed. Decide what to test before the next drop. | Tests the retention requirement as a live problem. The figure is hypothetical. |
| C3 | "A post-event review shows a content drop lost players. What do you do before the next drop?" | CASE | [generic] | Structure: what the review measured, who else needs to see it, what to test, and what to change in the checklist. Make no claim about your past reviews. | Tests the post-event review and KPI requirement. |
| C4 | "What would you want in your first 90 days to own the calendar for two titles?" | JD | [generic] | Name three things you would check first: the calendar, the team owners, the review cadence. Mark what you would need to learn. | Forward-looking; carries no claim about your past. |

### Data-Driven Prober (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "How was that retention number counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you know the definition and window, say it. If you did not define it yourself, say so. Name the assumption you would defend least. | F7 is the only retention line; the figure itself is not in the material. |
| P2 | "What did the retention number change?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if a retention figure changed a decision, say which and how. If it did not, say so. | Premise is not in the quote, so the second branch stays open. |
| P3 | "How would you define a post-event KPI for a two-title calendar?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Say the metric, the window and the decision it feeds. Name what it would not show. No claim about your past. | Scores the JD's KPI requirement. |
| P4 | "How has QA used your release checklist?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Describe how QA uses it, in your words. If you do not know how often it is run, say so. | F4 is closed on fit but still open to a probe. |

### Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Sixty seconds: why you over someone who has led a live team?" | JD | [grounded] "Never led a team" | Pause, restate. Hold: the calendar and the checklist. Concede: "They have led a team and I haven't." | Pressure on F9. |
| R2 | "That was one title and weekly drops. Is that really live operations?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold: the calendar you ran, its cadence and length. Concede: the scope was one title. | Pressure on the scope of F1. |
| R3 | "You presented the numbers. Did you own them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold: what you presented. Answer slot: what you owned in that reporting, in your words. If you owned none of it, say so. | Pressure on F3 and F7. |

### Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | A 90-second arc built only from these three sentences: the four years, the calendar, the checklist. Add the retention presentations if you have time. Do not add scope. | Opener that scores communication economy. |
| V2 | "What are you playing on mobile these days?" | Conversational | [generic] | Answer honestly and briefly. Tie it to the role only if it is true. | Rapport question; scored casually. |

## Reverse questions

1. "What does a typical update look like from brief to live across design, art, engineering and community?" Why it lands: it shows you know the coordination requirement.
2. "How is the post-event review run today, and who sets the KPI definitions?" Why it lands: it tests the ownership boundary without claiming it.
3. "Which titles are on the calendar this half, and what is the next big event on each?" Why it lands: it shows you are planning for the job, not reading about it.
4. "What does the release checklist cover today, and where did QA last push back on it?" Why it lands: it links to the checklist you wrote.
5. "What would you want the next person in this role to fix first?" Why it lands: it signals judgement about the calendar.

## Sources

Provided documents: the JD and your message.

Research tier: L1, searches 4 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet: none. Search refused. |
| 2. Saltmarsh Games interview process, live operations | unavailable | Loop structure: none. Persona weights are an archetype pattern. Search refused. |
| 3. Saltmarsh Games strategy and recent news | unavailable | CO questions: none. Search refused. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read and tailored reverse questions: none. Search refused. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot. |

Refused calls: "Saltmarsh Games values", "Saltmarsh Games interview process live operations producer", "Saltmarsh Games mobile game studio news", "Tobias Wrenfield Head of Live Operations Saltmarsh Games". Each returned a permission refusal, not results.

## Upgrade menu

- The round's format (a live exercise, a presentation, a take-home) → a drill for that exercise.
- Whether Tobias Wrenfield is your direct manager → persona weights recomputed.
- Tobias's public profile or talks, once research can run → an interviewer read and a tailored reverse question.
- The company's values or careers page, pasted → a values cheat sheet.
- A copy of the release checklist or another writing sample → F4 and F8 move to high confidence.
