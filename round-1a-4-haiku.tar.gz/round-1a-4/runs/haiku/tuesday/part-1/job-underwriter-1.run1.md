**Yes, you fit the must-haves, and the role is worth applying to once the posting checks out. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R6
- `important`: direct: R7a · adjacent: R5 (Define and maintain the metrics layer), R7b (Partner with clinicians) · unclear: R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience, HIPAA)

R5 is a credible bridge through the governed Looker dashboards, but ownership of cross-team metric definitions is not evidenced; R7b rests on partnering with non-analyst leaders, with no clinician work in the record; R8 (`none`) has no mentoring stated either way; R9 bridges through consent-state and GDPR/CCPA work, with no HIPAA exposure.

**Opportunity ledger.** The posting is specific and states its outcomes (RR3). It is silent on location, pay and contract type (RR2), and I could not confirm it is live on Harborlight's own site (RR1), because web search was refused this session. A possible care-setting review step for experiments is noted (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the posting is confirmed live on Harborlight's careers page, RR1; (2) location, pay and contract type are checked against your constraints, RR2; (3) the health-data gap is presented as adjacent, never as HIPAA experience, R9.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C, as you gave it | `[grounded]` JD header, not checked |
| Mandate | Own product analytics for the care-navigation app: metrics layer, experiments, Looker dashboards, mentoring two analysts | `[grounded]` JD |
| Scope read | One analytics owner who also leads two juniors: a senior individual-contributor scope with people duties | `[inferred]` from the JD's responsibilities |
| Market calibration | Not run; the role-family search was refused, so no pay band is offered | — |
| Unknowns | Location, pay, contract type, whether a metrics layer already exists, clinician access | — |
| Contradictions | None visible within the JD | `[grounded]` JD |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a subscription company, stated; self-report with no artifact yet | `[grounded]` your statement | Attach CV to check dates and titles |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake is stated; daily use supports "expert" without proving depth | `[grounded]` your statement | Redacted query or model, which raises it to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and an 11% retention lift, stated; whether the lift is relative or absolute is unconfirmed | `[grounded]` your statement | Test readout or design doc, and the lift's basis |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built a Looker instance from scratch with 40+ governed dashboards, stated | `[grounded]` your statement | Dashboard screenshot or LookML excerpt, which raises it to high |
| R5 | Define and maintain the metrics layer | important | adjacent | medium | transferability | Governed dashboards and the monthly memo are the bridge; no stated ownership of shared metric definitions | `[inferred]` bridge from R4 and the memo | G1 |
| R6 | Strong written communication for non-technical stakeholders | must_have | direct | medium | none | Writes the monthly memo the exec team reads and presents it to the VP Product, stated | `[grounded]` your statement | Redacted memo, which raises it to high |
| R7a | Partner with product managers on roadmap decisions | important | direct | medium | none | Presents monthly to the VP Product and ran the pricing test; whether that analysis fed a decision is not stated | `[grounded]` your statement | none |
| R7b | Partner with clinicians on decisions | important | adjacent | medium | transferability | Partnering with exec and VP-level leaders is stated; clinicians are not in the record | `[inferred]` adjacency from R6 and R7a | G2 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Not stated either way | `[grounded]` silence in your background | G3 |
| R9 | Healthcare data experience, HIPAA | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII handling and a consent-state model, stated; HIPAA and PHI rules not exercised | `[inferred]` bridge; `[generic]` GDPR and HIPAA are different regimes | G4 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, important) | transferability | Governed dashboards and a memo, but no stated ownership of metric definitions shared across teams | The JD names this as the core of the role | A metric definition others adopted; a semantic-layer or LookML change; a metrics doc finance or marketing used | A metrics doc, a LookML excerpt, or a definitions change log | `[inferred]` bridge from R4; `[generic]` that this is the usual gap for analytics owners |
| G2 | Clinician partnership (R7b, important) | transferability | Partnering with business leaders is stated; no clinical or health-side work | Clinicians are a distinct audience with different evidence standards | An analysis a care, operations or customer-care lead acted on; a readout a non-product leader used | A readout or brief that changed a non-product team's plan | `[inferred]` adjacency; `[generic]` that health-side teams weigh evidence differently |
| G3 | Mentoring (R8, important) | discovery | Nothing about coaching, reviewing or hiring analysts | A stated duty of the role | Onboarding or reviewing a new analyst's SQL or readouts; interviewing analysts | A team-lead note, a review example, or a hiring panel record | `[grounded]` silence |
| G4 | Health data (R9, preferred) | transferability | Consumer PII and consent work under GDPR/CCPA | Health data has its own rules, and the JD says a plus | Consent or deletion decisions on sensitive data; any work with health, insurance or benefits data; HIPAA training | A consent-state model summary, redacted | `[inferred]` bridge; `[generic]` HIPAA and GDPR differ |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not verified on the employer's own site | unknown | — | "Senior Product Analyst — Harborlight Health" | The posting may be live as described, but the check did not run | `[grounded]` search refused this session | Can you point me at the live posting on your careers page, and who would I be interviewing with? | unresolved |
| RR2 | Location, pay and contract type not stated | unknown | — | Posting silent on these | They may be stated elsewhere or withheld | `[grounded]` JD silence | Is this role remote, hybrid or on-site, what is the salary band, and is the contract permanent? | unresolved |
| RR3 | Clear scope and named outcomes | positive_signal | — | "Own product analytics for our care-navigation app" | The mandate and responsibilities are concrete | `[grounded]` JD | What would success look like in the first year for the metrics layer? | noted |
| RR4 | Experiments in a care setting may need extra review | risk_signal | low | "partner with … clinicians to turn analysis into roadmap decisions" | Experiments on care navigation may need patient-safety and privacy review that is outside your experience so far | `[generic]` pattern for regulated health analytics, not a claim about this employer | How are product experiments reviewed for patient safety and privacy, and who signs off? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Harborlight's careers page before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the Looker build, the experiment program and the monthly memo | R1, R2, R3, R4, R6 | `[grounded]` evidence map | pending your approval |
| A3 | Describe the consent-state and GDPR/CCPA work as the nearest bridge to health data, never as HIPAA experience | R9 | `[grounded]` R9; `[generic]` HIPAA is a separate regime | pending your approval |
| A4 | Prepare a redacted memo or dashboard screenshot as the work sample | R4, R6 | `[grounded]` evidence map | pending your approval |

**Evidence status.** Verified: none yet. Everything above is your own statement, so it sits at `medium` at most. No unverified leads. No rejected inferences.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app Series C" and "Harborlight Health careers Senior Product Analyst"; both were refused, so the employer, its stage and the posting are unconfirmed. Would have moved RR1 |
| 2. Role-family sweep | unavailable | Searched "senior product analyst salary digital health scale-up experimentation Looker"; refused. Would have set the market calibration and the pay check |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Because the employer check never ran, the standing "employer not established" entry does not apply. It is not a finding that the employer is unreal.

**Dossier offer.** When you want, I can write this assessment to a `tuesday-dossier.md` file so that later work can pick it up.

**Upgrade menu**

- The live posting from Harborlight's careers page → RR1 closes, and the employer check can run.
- Location, pay and contract type → RR2 closes, and the decision may move to `go` or `no_go`.
- Your CV → checks the dates and titles behind R1, R2 and R4.
- A redacted memo or dashboard screenshot → R4 and R6 move to `high`.
- A test readout or design doc → R3 moves to `high`.
- Web search enabled, or a re-run → the employer check (RR1), the pay band, and Harborlight's stage.

**Questions**

G3 — Have you trained, reviewed or hired junior analysts? What did you own, and how many people was it?

G2 — Have you done analysis for clinicians, care managers or another health-side team that changed what they did? What was your role, and what happened?

Constraints (no row yet) — What are your constraints for this role: location or remote, pay floor, and whether you need a permanent contract? The posting states none of them.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.