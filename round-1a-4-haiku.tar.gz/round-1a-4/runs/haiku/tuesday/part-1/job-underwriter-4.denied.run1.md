**Yes, apply, with three checks first.** Status: `conditional_go`.

Your six must-haves (R2, R3, R4, R5, R6, R7) are `direct` against your own record. The open items are the UK-remote gate (R1), the product side of the role (R8), and the employer check (RR4). I could not run the web checks: the search tool was declined, so Brindlemoor and Odile Varga are unverified.

**Fit ledger**
- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2 (4+ years pricing analytics), R3 (Build and monitor rating models), R4 (Strong SQL and Python), R5 (GLM experience), R6 (Design and read price tests), R7 (Present to underwriting or actuarial leads)
- `important`: adjacent: R8 (Turn results into recommendations for underwriting and product), R10 (Pet-insurance product)
- `preferred`: direct: R9 (Insurance experience)

R8: underwriting recommendations are evidenced, product ones are not. R10: motor pricing transfers, pet does not. R1: not established, since your location and right to work aren't in what you gave me.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found

**Opportunity ledger:** Sound, with open items. The employer is unverified (RR4), which caps the decision at `conditional_go`. Line management is unstated (RR1), and the pasted posting gives no salary (RR3). One positive: the scope is concrete and matches your record (RR5).

**Conditions for go:** (1) R1 confirmed; (2) RR4 cleared, meaning you find the posting on Brindlemoor's own careers page; (3) RR1 answered, so you know whether the role has direct reports.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor (insurtech), pet-insurance product | `[grounded]` JD header; existence not verified |
| Mandate | Own pricing analytics; build and monitor rating models; design and read price tests; turn results into recommendations | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` JD; public footprint not checked |
| Scope read | Senior-analyst scope, responsibilities concrete | `[inferred]` from the JD's responsibilities |
| Market calibration | Not run: the role-family search was declined, so there is no salary band | — |
| Unknowns | People management, salary, product-team interface, pet claims data | — |
| Contradictions | None in the pasted posting | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based (right to work implied) | hard_gate | unclear | none | hard_gate | Not in your brief | `[grounded]` JD; constraint not given | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years motor pricing, stated by you; no artifact inspected | `[grounded]` your statement | none |
| R3 | Build and monitor rating models | must_have | direct | medium | none | Built and maintained a GLM; "monitor" is implied, not stated | `[grounded]`; `[inferred]` on monitoring | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | `[grounded]` your statement | none |
| R5 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM (motor) | `[grounded]` your statement | none |
| R6 | Design and read price tests | must_have | direct | medium | none | 14 price tests run with the underwriting team last year | `[grounded]` your statement | none |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R8 | Turn results into recommendations for underwriting and product | important | adjacent | medium | transferability | Underwriting evidenced; no product-side recommendations stated | `[grounded]`; limit named | G1 |
| R9 | Insurance experience | preferred | direct | medium | none | Motor insurance | `[grounded]` | none |
| R10 | Pet-insurance product knowledge | important | adjacent | medium | transferability | Motor pricing carries over; you have never worked on pet | `[inferred]` from the JD's product line; `[grounded]` your statement | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product-side recommendations (R8, important) | transferability | Underwriting recommendations evidenced; product not | The limit an interviewer is likeliest to test | A pricing finding that changed a cover, excess or product feature, even informally | A change note or product-facing review | `[inferred]` from R8's source |
| G2 | Pet-insurance knowledge (R10, important) | transferability | Motor only | The product is pet, so the learning curve is real | Any pet claims, vet-cost or policy-design work | None inspectable; state it as a limit | `[generic]` pet pricing differs from motor in cost drivers and policy design |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Line management unstated | unknown | — | JD silent; title "Senior Pricing Analyst" | The role may carry direct reports; you have not managed anyone | `[inferred]` from JD silence against your background | Does this role line-manage anyone, and what would be expected of me in year one? | unresolved |
| RR2 | Pet pricing learning curve | risk_signal | low | "our pet-insurance product" | Pet pricing differs from motor, e.g. vet-cost trend and policy design | `[generic]` pattern for pet pricing, not a claim about this product | What does the book's claims experience look like, and what pricing data would I inherit? | unresolved |
| RR3 | Salary absent | unknown | — | None in the pasted posting | A band may be set but unpublished | `[inferred]` from the pasted text | What is the budgeted band for this role? | unresolved |
| RR4 | Employer not verified | risk_signal | medium | "Brindlemoor (insurtech)" | Research was declined, so this is not a finding of absence: the entity may be too new or small for a footprint, or the posting stale | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Brindlemoor's own careers page, and who would I be interviewing with? | unresolved |
| RR5 | Concrete scope | positive_signal | — | "Own pricing analytics … build and monitor rating models, design and read price tests" | The responsibilities are specific and match your record | `[grounded]` JD against your statement | Which of these would be new to the team? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the posting on Brindlemoor's careers page before applying | see RR4 | `[grounded]` RR4 | pending your approval |
| A2 | Ask RR1 and RR3 at the first recruiter contact | the register doubles as prep | `[grounded]` register | pending your approval |
| A3 | Name pet as your limit yourself, next to the motor pricing that carries over | see R10 | `[inferred]` from R10 | pending your approval |

## Evidence status

Verified: none yet. The brief is your own statement; nothing has been inspected.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search for Brindlemoor was declined; employer and posting unverified (RR4) |
| 2. Role-family sweep | unavailable | Search for UK pet-insurance pricing pay was declined; no market band (RR3) |
| 3. Hiring manager's public footprint | unavailable | Search for Odile Varga was declined; not checked |

Each of the three was refused by the tool, not skipped, so each reads `unavailable`.

**Dossier offer:** I can emit this as a `tuesday-dossier.md` if you want to keep it.

**Upgrade menu**
- An anonymised pricing-review deck or GLM documentation extract → raises R2 to R7 from `medium` toward `high`.
- Web search enabled → runs the three declined checks: the employer and posting (RR4), the salary band (RR3), and the hiring manager's footprint.
- An answer to G1 → R8 moves to `direct` or closes.

**Questions**

R1 — Are you based in the UK with the right to work, and able to work fully remote from there?

R8 — Have you ever taken a pricing finding into a product decision, such as a change to cover, excess or a product feature? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.