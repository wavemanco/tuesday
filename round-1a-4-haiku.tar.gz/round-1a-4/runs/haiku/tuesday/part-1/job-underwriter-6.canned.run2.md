**Worth applying, with conditions. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`, direct: 4+ years in revenue or sales operations (5 years, last 2 in RevOps); Salesforce administration (certified); strong SQL and spreadsheet modelling (weekly and daily).
- `must_have`, adjacent: owning a forecast. You run the monthly pipeline review, which is the closest thing to forecast input, but you have never owned the number.
- `must_have`, absent: working with finance on billing or revenue data. You have not worked on billing data.
- `important`, direct: pipeline and renewal reporting (you have rebuilt both).

**Opportunity ledger.** The posting is clear on outcomes and pay. Its scope is bundled: one role owns CRM data, billing data, reporting for sales and finance, and the quarterly forecast with the CFO. Those are usually separate jobs, and at a 96-person company the boundary with finance is unclear.

- **Hard gates:** none failed. Unconfirmed: the Bristol hybrid pattern (two office days a week). You gave no location or other constraints, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Before interview, establish whether the role owns the forecast number or prepares inputs for the CFO. Do not describe pipeline review as forecast ownership.
  2. Frame the billing gap honestly as a ramp, with your payments-company exposure as the bridge, and only to the extent you can describe it.
  3. Confirm the posting on Quillfield's own careers page or through the recruiter's email domain (see RR5).

**Research tier:** L1, searches 3 of 5, fetches 0 of 2; user links read 1.

| Target | Status | What it moved |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers Revenue Operations Lead." Found the About page (quillfield.co.uk/about): Bristol, founded 2018, 96 employees, Series A (£11M, April 2025). No careers page for this role surfaced, so posting consistency is unverified (RR5). |
| 2. Role-family sweep | yes | Searched "revenue operations lead B2B SaaS salary UK responsibilities forecasting." Returned the Ledgerline 2026 UK Revenue Operations Pay Guide (ledgerline.example/2026-uk-revenue-operations-pay-guide). Calibration below. |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield." Returned a public profile (linkedin.example/in/tamsin-achebe): Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years. |

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; Series A, 96 staff | `[grounded]` About page |
| Scope | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two office days a week | `[grounded]` posting |
| Market calibration | Median base £64,200; IQR £57,800–£70,400. The posted range sits inside the IQR, near the median. | `[generic]` Ledgerline 2026 |
| Scope read | Broad for the title: billing data and the forecast sit inside a role that also owns CRM and reporting. Reads as a seniority-appropriate combined role at a Series A, not an unusually junior one. | `[inferred]` from the posting's list of responsibilities |
| Outcomes | Not stated. The posting names responsibilities, not first-year deliverables. | — |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations; background in sales operations, then RevOps. Your path runs in the same direction. | `[grounded]` public profile; the parallel is `[inferred]` |
| Contradictions | None found between the posting and the About page, but the posting's presence on Quillfield's own careers site is unconfirmed | `[grounded]` vs. unverified |

**Evidence map.** Confidence reflects how strongly the evidence is documented. Your statements in this conversation are stated, not yet supported by artifacts.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years in RevOps or sales ops at a B2B company | must_have | direct | medium | none | 5 years in sales ops at a B2B payments company, last 2 in RevOps. "Software" versus "payments" is a minor wording point. | Stated by you | None |
| R2 | Salesforce or HubSpot admin | must_have | direct | medium | none | Salesforce admin certified; the certificate would raise confidence to high | Stated by you | Share the certificate if you want it on record |
| R3 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily; no artifact yet | Stated by you | A sanitized query or model would raise to high |
| R4 | Pipeline and renewal reporting | must_have | direct | medium | none | You rebuilt both dashboards | Stated by you | A screenshot or description of one would raise to high |
| R5 | Owning a revenue forecast | must_have | adjacent | low | transferability | You run the monthly pipeline review with the sales director, which feeds forecasting. You have never owned the company forecast; finance did. | Stated by you | Gap G1 |
| R6 | Working with finance on billing or revenue data | must_have | absent | none | capability | No billing data experience stated. The payments-company background may offer a bridge; that is unverified. | Stated by you | Gap G2 |
| R7 | Owning CRM and billing data | must_have | adjacent | medium | transferability | CRM: direct. Billing: absent (see R6). | Mixed | Covered by G2 |
| R8 | Bristol hybrid, two days a week | structural | unknown | — | — | Your location and preference were not given | — | Question Q3 |

**Gap recovery queue.** Each gap row says what it is and what would close it. The questions are in the closing block, tagged by row id.

| # | Gap (req) | Type | What I currently see | Why it matters | What may count | Useful evidence |
|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R5) | transferability | Pipeline review with the sales director; no forecasting work stated | The posting says "run the quarterly revenue forecast." Pipeline review is the nearest input, but it is not ownership. | Any forecast inputs you built or maintained, even if finance made the final call | A pipeline-to-forecast reconciliation, or a description of what the monthly review fed into |
| G2 | Billing data (R6, R7) | capability | No billing data stated. Payments-company exposure is unverified. | The role owns billing data. This is the largest gap for a must-have requirement. | Any reconciliation, payment-run, refunds or revenue-recognition work with finance | A sanitized description of data you have worked with at the payments company |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bundled scope: CRM, billing data, reporting and the forecast in one role | risk_signal | medium | "You will own our CRM and billing data… and run the quarterly revenue forecast with the CFO" | Finance-ops and RevOps duties may be folded together at this stage; the role may end up with more than one job | `[inferred]` from the posting's responsibility list | Which parts of billing data and the forecast does this role own outright, and which does finance own? | unresolved |
| RR2 | First-year outcomes not stated | unknown | — | (none) | The posting may be too early for defined deliverables | — | What would success look like at six and twelve months? | unresolved |
| RR3 | Salary stated and inside the market band | positive_signal | — | "£61,500–£67,000 plus share options" | Transparent and in range | `[grounded]` posting, `[generic]` band | — | noted |
| RR4 | Hybrid pattern vs. your location | unknown | — | "two days a week in the office" | Unknown until your location is confirmed | — | Q3 | unresolved |
| RR5 | Posting source | unknown | — | Posting appears on tallyboard.example; the About page confirms the company exists, but this role was not found on its careers page | The posting may be live on the company's site under a different URL, or may have been posted only to the job board | — | Is the role on Quillfield's careers page, or did the recruiter send it from a Quillfield email domain? | unresolved |

This is not a failed attribution. The company exists as described. RR5 is an unverified detail, not a reason to doubt the posting.

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the posting on Quillfield's careers page or the recruiter's email domain before investing time | RR5 | `[grounded]` RR5 | proposed |
| P2 | Ask the recruiter or Tamsin Achebe: does the role own the forecast number, or prepare inputs for the CFO? | RR1, G1 | `[grounded]` RR1 | proposed |
| P3 | Lead with the pipeline and renewal dashboards and the monthly pipeline review, as verified work, not as forecasting experience | Hiring manager's background is sales operations, the same route as yours | `[inferred]` from public profile | proposed |
| P4 | Describe the payments-company exposure to billing data only in terms you can back up | G2; avoid reframing that claims billing ownership | `[grounded]` R6 | proposed |
| P5 | When you have an interview, mock-interview can drill the forecast and billing questions | Its job, not this module's | — | proposed |

Every row is a proposal. Nothing goes into a CV or outreach text without your approval.

**Evidence status.**
Verified: posting terms (pay, location, requirements) from the posting link; company facts from the About page; Tamsin Achebe's role from a public profile.
Your claims: none verified yet. Everything in the evidence map rests on what you have told me in this conversation.
Rejected inferences: none.

**Upgrade menu.**

- A sanitized dashboard, or a query or model you have built → R3, R4 move to high.
- A reconciliation or billing-data example → G2 becomes a bridge, not an absence.
- The recruiter's answer on forecast ownership → RR1 closes, and the decision may move to `go` or `no_go`.
- Your location and any constraints → R8 and RR4 close.
- Deeper research on Quillfield (funding, hiring patterns, staff reports; up to 5 more searches and 2 more fetches). I can run it if you want.

**Dossier offer:** At the end of this engagement I can write a `tuesday-dossier.md` for this role, if you want one.

**Questions:**

- **G1:** Did your monthly pipeline review feed any forecast? If so, what did you own in it: the inputs, the assumptions, or the reconciliation to actuals?
- **G2:** Have you worked with any billing, invoicing or payment-run data at the payments company? If so, at what level: reports, reconciliation, or the source systems?
- **Q3 (R8):** Are you based in or willing to commute to Bristol two days a week? Are there any other constraints, such as notice period or a salary floor?

Response mode: answer in text, or paste a short description of each.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.