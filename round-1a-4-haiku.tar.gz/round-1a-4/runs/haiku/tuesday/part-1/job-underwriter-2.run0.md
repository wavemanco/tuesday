**Not a waste of time, but this is a reach rather than a fit.** The gap that matters is R1b, the 3+ years of titled product management, which you don't have. Status: `conditional_go`, applying only once the posting verifies.

**Fit ledger.**
- `must_have`: direct: R3, R4 · adjacent: R1a (3+ years product management), R2 (shipped API or platform products) · unclear: R6 (agile delivery) · absent: R1b (3+ years product management, titled)
- `important`: adjacent: R7 (discovery with integration partners), R8 (specs and delivery with two engineering squads) · unclear: R5 (launch coordination with sales and support), R9 (adoption metrics)

R1b, the absent titled-years row; R1a, the product-side work that bridges it; R2, integration work rather than product ownership; R6, no agile evidence in what you gave; R3 and R4, direct on the CV, with R4's sales half sitting in R5.

**Opportunity ledger.** The posting is clear about scope and measurement (RR3, positive). Roadmap decision rights (RR1) and pay (RR2) are unstated. Quartzline is not verified (RR4, medium).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the posting is confirmed on Quartzline's own careers page (RR4); (2) in interviews, roadmap authority is concrete (RR1); (3) you present the product-side work as a bridge with its limit named, not as product-management experience (R1a, R2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header only; not verified, since research was refused |
| Mandate | Own the roadmap for the partner-facing API platform; run partner discovery; write specs; drive delivery with two engineering squads; define and track adoption metrics; coordinate launches | `[grounded]` JD |
| First-year outcomes | Not stated | — |
| Scope read | Product-owner scope with named squads and named metrics, on one product area | `[inferred]` from the JD's listed responsibilities |
| Market calibration | Not established: the role-family search was refused, so there is no band to compare against | — |
| Unknowns | Roadmap decision rights and budget; pay; whether the squads report to this role; how adoption is measured today | — |
| Contradictions | None found within the JD text | `[grounded]` JD text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience (the product-side years) | must_have | adjacent | medium | transferability | Roadmap-input sessions and requirements documents are product-side work. Not roadmap ownership or prioritization, and not titled | `[grounded]` CV | G1 |
| R1b | 3+ years product management experience (titled) | must_have | absent | none | capability | No PM title held, by your statement. This is a length-of-experience requirement, so it is graded, not gated | `[grounded]` your statement; `[generic]` that a titled-years bar is often screened literally | Closure path in G1 |
| R2 | shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ end-to-end client integrations of the REST APIs. You shipped integrations into client builds, not a platform product you owned | `[grounded]` CV | G2 |
| R3 | strong technical fluency, comfortable reading API docs and discussing schemas | must_have | direct | medium | presentation | Postman, SQL, OpenAPI reading and integration architecture are on the CV. Schema discussion is implied, not stated | `[grounded]` CV | P1 |
| R4 | stakeholder management across engineering, sales, and customers | must_have | direct | medium | presentation | Coordinated vendor engineers, client engineers and PMs; ran scoping workshops. Sales is not on the CV, so the sales half is carried in R5 | `[grounded]` CV | P1 |
| R5 | coordinate launches with sales and support | important | unclear | low | discovery | Go-live work is on the CV; sales and support coordination is not | `[grounded]` CV silence | Deferred (see upgrade menu) |
| R6 | experience with agile delivery | must_have | unclear | low | discovery | Nothing names sprints, squads or agile practice. Your delivery evidence is go-live and UAT | `[grounded]` CV silence | G3 |
| R7 | run discovery with integration partners | important | adjacent | medium | transferability | Quarterly roadmap-input sessions collected client feedback for product. Input-gathering, not synthesis or decisions | `[grounded]` CV | G1 |
| R8 | write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | Requirements documents and coordination on custom builds. Project-scoped, not standing-product squads | `[grounded]` CV | G1 |
| R9 | define and track adoption metrics | important | unclear | low | discovery | No adoption measurement on the CV | `[grounded]` CV silence | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product-side ownership (R1a, R7, R8) | transferability | Roadmap input, requirements documents and coordination are on the CV; roadmap ownership or a prioritization decision is not | R1a is a must-have at adjacent, and the roadmap is the core of this job | A prioritization call on a custom build; a backlog you ordered for a client; a scope cut you proposed and got accepted; any of these, even without the title | A sanitized requirements document, or a roadmap-input summary you sent to product | `[grounded]` CV; `[generic]` that titled-years bars are often screened literally |
| G2 | Shipped API products (R2) | transferability | 30+ end-to-end integrations; no product-level ownership of the API itself | The posting says "shipped"; the honest bridge is integration-side shipping | Integration patterns you standardized; API changes you pushed to product; a versioning decision you influenced | The integration playbook; a sanitized integration architecture | `[grounded]` CV; `[inferred]` that the playbook shows standardization |
| G3 | Agile delivery (R6) | discovery | Sprints and squad delivery are not named; go-live and UAT are | Must-have at low confidence; evidence may sit inside the custom-build work | Release cadence on a custom build; a standing integration team | A sprint board or release plan | `[grounded]` CV silence |
| G4 | Adoption metrics (R9) | discovery | No adoption measurement on the CV; playbook use is stated but not measured | Important, and the posting asks you to track it | Usage counts you tracked for the playbook or a tool; adoption figures from a client rollout | A usage report or dashboard | `[grounded]` CV silence. A prior-conversation note is not evidence (see Evidence status) |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Roadmap authority not stated | unknown | — | "Own the roadmap for our partner-facing API platform" | Ownership may be of direction without decision rights over budget or squad priorities | `[inferred]` from the ownership language against silence on decision rights | Which roadmap decisions does this role make alone, and what budget and team authority come with it? | unresolved |
| RR2 | Pay not stated | unknown | — | JD silent on pay | The figure may be withheld, or may sit below the role-family band, which was not established | `[grounded]` JD silence | What is the budgeted base salary range for this role? | unresolved |
| RR3 | Scope and metrics explicit | positive_signal | — | "define and track adoption metrics" | The role is defined and measurable | `[grounded]` JD | Who owns the adoption metrics today, and what is the current baseline? | noted |
| RR4 | Employer not established | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Quartzline may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Not checked: research was refused | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Move the OpenAPI, integration-architecture and requirements work to the top of the CV | R3, R4, R8 are direct or adjacent and currently buried | `[grounded]` CV | resume_edits_pending_approval |
| P2 | Describe the history as "end-to-end client integrations of our REST APIs" and "requirements documents for product". Do not write "product manager", "owned the roadmap" or "shipped" for this history | R1a, R2, R7. Your sentences say you scoped and integrated, not that you decided | `[grounded]` CV; reframing audit | pending your approval |
| P3 | Before applying, confirm the posting on Quartzline's own careers page | RR4 | `[generic]` pattern for employers of this size | pending your approval |
| P4 | In the screen, ask RR1 and RR2 verbatim | They are the questions that decide the conditions | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Unverified lead: a prior-conversation note that you may have built an internal request-triage tool that support agents adopted. It is not evidence, and no row above relies on it. It prompts question G4 only.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Quartzline logistics software company"; "Quartzline careers Product Manager Platform APIs") were refused by the host's permission prompt. Would have moved RR4 and the contradictions row |
| 2. Role-family sweep | unavailable | One search ("product manager API platform salary range B2B Series B") was refused. Would have moved the market calibration line and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you want this kept, I can emit it as a `tuesday-dossier.md` you can append to later.

**Upgrade menu**
- Allow web search, or paste the posting's link from Quartzline's careers site: RR4 gets checked, and the salary search runs, setting RR2's calibration. Up to 5 searches and 2 fetches.
- A sanitized requirements document or OpenAPI spec you wrote: R8 and R2 move toward direct.
- An integration playbook excerpt or any adoption figure: R9 closes or stays unclear.
- A pay band from the recruiter: RR2 closes.

**Questions**

G1 — Have you ever made a prioritization or roadmap call on a custom build, even without the title? If so, what did you decide, who could overrule it, and what happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G4 — I have only an unverified note that you may have built an internal request-triage tool that support agents adopted. Is that right? If so, what did you own, how many agents used it, and what did you measure?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

RR4 — Do you have the posting's link from Quartzline's own careers site? Paste it if so; if not, check it there before you apply.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.