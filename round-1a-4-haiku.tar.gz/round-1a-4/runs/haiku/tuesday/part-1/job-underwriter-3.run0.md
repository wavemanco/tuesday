**No, not as posted.** It fails both of your hard constraints, and the rest of the posting doesn't change that. Status: `no_go`.

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (base pay floor of $150k), R2 (remote-only, Portland)
- `must_have`: direct: R3 (8+ years growth leadership), R4a (paid acquisition and lifecycle); unclear: R4b (SEO/content, brand, PR, partnerships, sales ops)

On scope, the posting is within your experience. The problem is the terms: R1 and R2 are gates, and the posting states both against you.

- **Hard gates:** failed: R1 (base pay floor of $150k), R2 (remote-only, Portland); candidate constraints given, checks run.
- **Severe red flags:** none found.
- **Opportunity ledger:** RR1 (team of one, end-to-end scope with no budget or decision rights stated) and RR2 (evenings and weekends expected) are risk signals. RR3 (Series A, profitable since day one) is a positive signal, but it is the employer's own claim and I could not verify it.
- **What would change this:** the employer would have to make the role remote-eligible and set base at or above $150k, both in writing. The posting says "no exceptions" on the office, so I would not expect that.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, profitable (employer's claim) | `[grounded]` posting; not verified (see Evidence status) |
| Mandate | All revenue growth end to end, across seven channels | `[grounded]` posting |
| Scope read | Head-level mandate with no team, budget or named resources | `[inferred]` from the scope list against the "team of one" line |
| Working pattern | On-site Austin, 5 days a week, "no exceptions"; evenings and weekends | `[grounded]` posting |
| Pay | $70–85k base plus equity; equity unquantified | `[grounded]` posting |
| Market calibration | Not established: the role-family sweep was refused, so I give no band | — |
| Unknowns | Budget, headcount, decision rights; whether the pay figure is current | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay floor of $150k | hard_gate | hard_gate_fail | high | hard_gate | Your stated floor, specific and confirmed. Posting states $70–85k, roughly half the floor | `[grounded]` intake and posting | None; only the employer changing pay resolves it |
| R2 | Remote-only, Portland | hard_gate | hard_gate_fail | high | hard_gate | Your stated constraint. Posting requires Austin on-site 5 days, "no exceptions" | `[grounded]` intake and posting | None; only the employer changing terms resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | 9 years, two B2C subscription companies. Self-reported, no inspectable artifact yet | `[grounded]` intake | None |
| R4a | Paid acquisition and lifecycle/CRM | must_have | direct | medium | none | You owned both and scaled one company from $8M to $40M ARR. Self-reported | `[grounded]` intake | None |
| R4b | SEO/content, brand, PR, partnerships, sales ops | must_have | unclear | low | discovery | Not in your intake. Could be gap or unmentioned experience | `[grounded]` intake silence | Recall prompt; not asked this turn |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Responsibility without resources | risk_signal | medium | "team of one to start" | You would own all revenue channels with no budget or decision rights in sight | `[inferred]` from scope against silence on budget | What budget, headcount and decision rights come with this role in year one? | unresolved |
| RR2 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Overtime is normal and uncompensated | `[grounded]` quote; the pattern is `[generic]` | How often are evenings and weekends expected, and how is that handled in pay? | unresolved |
| RR3 | Employer not established | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A…)" | The employer may be too new or small for a public footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on Novaline's own careers site, and who would I interview with? | unresolved |
| RR4 | Positive: stated stage and profitability | positive_signal | — | "profitable since day one" | If true, the company is less fragile than most at this stage | `[grounded]` employer's own claim, unverified | Can you share the audited or board-level basis for "profitable since day one"? | noted |

Pay is in R1, not the register: the posted figure is the gate failure. The market band is not established, since the sweep was refused, so I cannot say whether $70–85k is low for this seniority.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't apply on these terms | R1 and R2 fail | `[grounded]` R1, R2 | proposed |
| P2 | If you revisit, ask RR3's question through Novaline's own careers site, not a message from the poster | Employer not established | `[generic]` standing entry | proposed |

**Evidence status**

Verified: R1 and R2 are your own stated constraints, confirmed in this conversation. R3 and R4a are self-report at `medium`; there's no CV or artifact to inspect yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Novaline's company and careers page were refused. Would have verified RR3 and whether the posting is live |
| 2. Role-family sweep | unavailable | One salary search for Head of Growth at Series A was refused. Would have set the market band behind R1 and the scope read |
| 3. Hiring manager's public footprint | n/a | No name given, so there was no query to form |

Your search permission was declined. Since I couldn't search, I didn't fall back on memory for salary bands or company facts.

**Upgrade menu**

- Permission to run the L1 searches (up to 5 searches and 2 fetches) would verify whether Novaline exists and is hiring, and set the $70–85k figure against a market band. It would not change the `no_go` on R1 and R2.
- The posting's link on Novaline's own careers page would clear RR3's check.
- Written confirmation from the employer on the pay figure and location would be the only thing that could change R1 or R2.

I can also write this assessment to `tuesday-dossier.md` so you have it for later. Say the word.

No questions this turn. The decision is stable because two hard gates fail on the posted terms.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.