**No.** On the posted terms, the role fails both of your hard constraints, which is probably the "something feels off." Your fit is strong, but the posting itself rules out the two things you need. Status: `no_go`.

**Decision snapshot**

**Fit ledger.**

- `hard_gate`: failed: R1, R2
- `must_have`: direct: R3, R4a
- `important`: unclear: R4b (SEO/content, brand, PR, partnerships, sales ops)

R1 (pay floor) and R2 (remote-only) fail on the posting's own figures. R3 (8+ years) is stated but not evidenced. R4a (paid and lifecycle) is stated. R4b is not in your background.

**Opportunity ledger.** Risk signals: an always-on expectation (RR1), scope without stated resources (RR2), undefined success metrics (RR3), pay against your floor with no market check (RR4), and unstated equity (RR5). One positive, RR6, is the stated Series A and profitability, which I have not verified.

- **Hard gates:** failed: R1 (Compensation: $70–85k base), R2 (On-site in Austin, 5 days a week); met: none; candidate constraints given.
- **Severe red flags:** none found.
- **What would change this:** the posted range would have to reach your $150k floor, and the on-site requirement would have to change. The posting says "no exceptions," and the status stays `no_go` unless those terms change. Whether to revisit your own constraints is your call.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting's own claim, not checked |
| Mandate | Own all revenue growth: paid, SEO/content, lifecycle, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Scope read | Broad mandate, no team | `[inferred]` from "team of one to start" against the mandate |
| Working pattern | On-site Austin 5 days; evenings and weekends | `[grounded]` posting |
| Market calibration | Not run; no band stated | — |
| Unknowns | Equity size, budget and headcount, success metrics | — |
| Contradictions | "Team of one" against owning six-plus functions end to end | `[grounded]` posting |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Compensation: $70–85k base | hard_gate | hard_gate_fail | high | hard_gate | Your floor is $150k; the top of the posted range is $65k below it. Confidence grades your stated floor. | `[grounded]` posting; your stated constraint | Surfaced in snapshot |
| R2 | On-site in Austin, 5 days a week | hard_gate | hard_gate_fail | high | hard_gate | You are remote-only in Portland. The posting says "no exceptions." | `[grounded]` posting; your stated constraint | Surfaced in snapshot |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Stated in writing, specific, no artifact to inspect | `[grounded]` your statement | none |
| R4a | Paid acquisition and lifecycle/CRM ownership | must_have | direct | medium | none | Stated: paid, lifecycle, experimentation; Braze, GA4, SQL | `[grounded]` your statement | none |
| R4b | SEO/content, brand, PR, partnerships, sales ops | important | unclear | low | discovery | Not in your stated background; not established either way | `[grounded]` silence in your background | G1 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Channels beyond paid and lifecycle (R4b, important) | discovery | Your background covers paid, lifecycle and experimentation; the other channels are not stated | Matters only if the gates change | Owning SEO or content output, a brand or PR campaign, a partner program, a sales-ops process | A channel plan, a campaign deck, a partner agreement | `[grounded]` background silence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Hours may run past the stated schedule | `[inferred]` from the posting's wording | How often are evenings and weekends expected in a typical month? | unresolved |
| RR2 | Scope without resources | risk_signal | medium | "team of one to start … don't need a bench" | Accountable for the full revenue scope with no budget or team committed | `[inferred]` scope against stated resources | What budget and headcount are committed to this role in year one? | unresolved |
| RR3 | Success metrics undefined | risk_signal | medium | "success metrics will evolve as we learn" | Success may be judged on criteria set after hiring | `[inferred]` from the posting's silence on targets | What three numbers will define success at six and twelve months? | unresolved |
| RR4 | Pay against your floor | risk_signal | medium | "$70–85k base" for "8+ years" | Pay may be below the market for this scope; not checked | `[inferred]` posted figure against your floor; no market band searched | How was the $70–85k range set for a Head-level hire? | unresolved |
| RR5 | Equity unstated | unknown | — | "meaningful equity upside" | Equity size and terms unknown | `[inferred]` from the posting's silence | What equity grant and vesting schedule does this role get? | unresolved |
| RR6 | Stated traction | positive_signal | — | "Series A, profitable since day one" | Stated by the company, not checked | `[grounded]` posting's claim | What are current revenue and runway? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply on the posted terms | R1 and R2 fail on the posting's own figures | `[grounded]` R1, R2 | recommended; your call |
| A2 | If you proceed anyway, put the RR1–RR5 questions to the employer first | The register is most useful when the decision goes against the recommendation | `[grounded]` register | pending your decision |

**Evidence status.** Verified: R1 and R2 (your stated constraints), R3 and R4a (stated by you in writing; no artifact yet, so `medium`). Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 0 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | The posted pay and on-site terms fail R1 and R2 on their own, which fixes the status at `no_go`. An attribution check could only cap a `go`. |
| 2. Role-family sweep | skipped | The posted $70–85k against your $150k floor is settled from the posting itself. A market band would add context to RR4 but cannot change the status. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

Nothing above is a market value I recalled from memory.

I am not offering the dossier file for now. If you want this kept as a record, I can write it as a `tuesday-dossier.md`.

**Upgrade menu**

- A market pay sweep for Head-of-Growth roles at Series A companies. It would give RR4 a sourced band; it does not change `no_go`.
- Novaline's own careers page and the live posting. This verifies the company exists and the role is open, and it matters only if the gates change.
- Evidence for SEO/content, brand, PR, partnerships or sales ops (G1). This closes R4b, and it matters only if the gates change.

No questions this turn; the decision is stable.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.