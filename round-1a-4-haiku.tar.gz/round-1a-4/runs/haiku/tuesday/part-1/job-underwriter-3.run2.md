## Decision snapshot

**No. Don't pursue this posting as written. Status: `no_go`.** R1 (base pay) and R2 (on-site location) both fail on the posting's own stated terms, and neither is a fact I could expect to change.

**Fit ledger.**

- `hard_gate`: failed: R1, R2
- `must_have`: direct: R3, R5, R6 · unclear: R4
- `important`: direct: R7 · unclear: R8

R1 and R2: the two gates, each failing. R3, R5 and R6: your stated experience covers these must-haves. R4: SEO, brand, PR, partnerships and sales ops are not in your background. R8: ambiguity is not addressed yet.

**Opportunity ledger.** The posting is unattractive on its terms, which the register explains: always-on hours (RR1), a solo mandate across seven functions with no stated authority or budget (RR2), and no defined success metrics (RR3). RR4 (equity is unquantified) is a lesser signal. The employer itself was not checked (RR5), because the search that would check it was not run.

- **Hard gates:** failed: R1 (Compensation: $70–85k base plus meaningful equity upside), R2 (On-site in our Austin office 5 days a week — no exceptions)
- **Severe red flags:** none found. No payment requests and no chat-only hiring appear in the posting.
- **What would change this:** R2 needs the employer to drop an explicitly stated "no exceptions" term, which is unlikely. R1 needs the posted base to rise from $70–85k to above your $150k floor, or your floor to change. Only your own change to the floor would move R1, and that is a choice you would make. The status would remain `no_go` unless both change.

## Research tier

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both Novaline searches were refused by the permission prompt, so the careers page and whether the posting is live are unchecked. Would have moved RR5 and the contradictions row. |
| 2. Role-family sweep | unavailable | The search was refused, so no market band exists for this title and seniority. Would have moved the market calibration line and RR6. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

I have not retried the refused searches. If you grant search permission, I can run targets 1 and 2 on the next turn.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting. Existence and profitability are unverified, because target 1 is unavailable. |
| Mandate | "Own all revenue growth end to end" across paid, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` posting |
| Team | "A team of one to start" | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin five days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` posting |
| Compensation | $70–85k base, plus "meaningful equity upside" with no figures given | `[grounded]` posting |
| First-year outcomes | None stated; success metrics "will evolve as we learn" | `[grounded]` posting |
| Market calibration | Not run; target 2 unavailable | — |
| Unknowns | Equity terms, authority and budget, what evenings and weekends mean in practice, whether the employer is live | — |
| Contradictions | "Own all revenue growth end to end" across seven functions, against "a team of one" | `[grounded]` posting, internal to the JD |

## Evidence map

Your background is self-report, so claims stay at `medium` unless they are your own stated constraints, which are `high`. No CV or artifact was provided.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Compensation: $70–85k base plus meaningful equity upside | hard_gate | hard_gate_fail | high | hard_gate | Your $150k base floor is your own specific statement. The posted base is $70–85k, so the terms conflict. | `[grounded]` posting and your stated floor | None; only a change to the posted terms or to your floor resolves it |
| R2 | On-site in our Austin office 5 days a week — no exceptions | hard_gate | hard_gate_fail | high | hard_gate | Your remote-only, non-relocating constraint is your own statement. The posting says on-site with no exceptions. | `[grounded]` posting and your stated constraint | None; the posting rules out the exception |
| R3 | Paid acquisition, owned end to end | must_have | direct | medium | none | You owned paid and scaled one company from $8M to $40M ARR with a budget you controlled. Self-reported, with no inspectable artifact yet. | `[grounded]` your background | Offer in the upgrade menu |
| R4 | SEO/content, brand, PR, partnerships, sales ops | must_have | unclear | none | discovery | Your background does not mention any of these. No claim exists. | `[grounded]` your background is silent | Question in the gap queue (G1) |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle and worked in Braze. Self-reported. | `[grounded]` your background | Offer in the upgrade menu |
| R6 | 8+ years growth leadership | must_have | direct | medium | none | Nine years of growth work, including two Head-of roles. A length of experience, not a gate. | `[grounded]` your background | None |
| R7 | Analytics (SQL, GA4) and experimentation | important | direct | medium | none | You are deep in SQL and GA4 and owned experimentation. Self-reported. | `[grounded]` your background | None |
| R8 | Thrives on ambiguity; metrics will evolve | important | unclear | none | discovery | Your background does not address this. | `[grounded]` posting; your background is silent | Question in the gap queue (G1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Cross-functional scope (R4, R8) | discovery | Your background covers paid, lifecycle and experimentation. It does not cover SEO, brand, PR, partnerships or sales ops, and it does not address ambiguity. | These are must-have and important requirements, and they only matter if the role is worth pursuing, which the gates already decide against. | Any SEO, content, PR or partnership work you have run; any sales-ops or revenue-tooling work. | A plan, dashboard or post-mortem from one of those areas. | `[grounded]` the gap is silence in your background; `[generic]` that solo, multi-function mandates like this one are common in posting language. |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Hours may extend past the posted schedule as a routine part of the job. | `[inferred]` from the quoted language | What does a typical evening or weekend look like in this role, and how often did it happen last quarter? | unresolved |
| RR2 | Responsibility without authority or resources | risk_signal | medium | "Own all revenue growth end to end … a team of one to start" | You may be accountable for seven functions with no budget or headcount in sight. | `[inferred]` from the scope against the solo-start language | What budget, headcount and spend authority come with this role on day one? | unresolved |
| RR3 | Absent success metrics on a demanding mandate | risk_signal | low | "success metrics will evolve as we learn" | Accountability may arrive without a definition of success. | `[inferred]` from the quoted phrase | What three numbers define success at the end of year one? | unresolved |
| RR4 | Evasive compensation | risk_signal | low | "meaningful equity upside" | Equity is unquantified, so the total package cannot be compared. | `[inferred]` from the quoted phrase | What is the equity grant, its vesting schedule and the strike price? | unresolved |
| RR5 | Employer not established | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity has not been checked, so the posting could be stale or aggregated. This is not a finding that the employer is unreal. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Stated base sits below your floor | risk_signal | medium | "$70–85k base" | Mismatch with your floor. See R1. | `[grounded]` R1 | Is $70–85k the full base range, or is there room above it? | unresolved |
| RR7 | Series A and "profitable since day one" | unknown | — | "Series A, profitable since day one" | Unverified; not checked. | `[grounded]` posting; unverified | Can you share the date of the last round and your current profitability position? | unresolved |

**Severe red flags:** none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't spend application effort on this posting in its current form | R1 and R2 fail on the posting's own stated terms | `[grounded]` R1, R2 | pending your approval |
| P2 | If you want to keep the door open, put the verification questions to the employer in writing: RR5, RR6, RR1 | They are the cheapest test of whether the gates can move | `[generic]` pattern for early-stage hiring | pending your approval |

## Evidence status

Verified: R1 and R2 (your own stated constraints, specific). All other rows are unverified self-report.

Unverified leads: none.

Rejected inferences: none.

## Upgrade menu

- Search permission granted → target 1 (does Novaline exist, is the posting live) and target 2 (the market band for this title). Moves RR5, RR6 and the market calibration line. The status is unlikely to change, because R1 and R2 fail on the posting's own terms.
- A CV, or a case readout from your $8M→$40M period, or a Braze or GA4 dashboard screenshot → R3, R5 and R7 move from `medium` to `high`.
- A name for the hiring manager → target 3 runs, and the scope read in role reality can be checked against that person's public footprint.

Would you like me to write `tuesday-dossier.md` with this assessment, so you can keep it for later?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.