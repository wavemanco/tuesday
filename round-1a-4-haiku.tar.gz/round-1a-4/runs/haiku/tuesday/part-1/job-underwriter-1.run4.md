## Decision snapshot

**Yes, worth applying, with conditions. Status: `conditional_go`.** On your stated background you are a fit for the core analytics work: R1 through R7 read as `direct`, at `medium` confidence because nothing is inspected yet. The real gaps are healthcare data (R10, a preferred requirement you can only bridge, not claim) and two people-side responsibilities the background doesn't mention (R8 and R9).

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5, R6
- `important`: direct: R7 · unclear: R8 (Partner with clinicians), R9 (Mentor two junior analysts)
- `preferred`: adjacent: R10 (Healthcare data experience, HIPAA)

R10 — a credible bridge, its limit named; R1, R2, R3, R4, R5, R6 and R7 (`medium`) — stated, unprobed, waiting on an artifact.

**Opportunity ledger.** The standing employer-not-established entry (RR1) caps the decision at `conditional_go`. RR2 (decision rights over metrics), RR3 (whether PHI is in scope) and RR4 (compensation) are unresolved. RR5 is a positive signal: the responsibilities are concrete and measurable.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 cleared: the role is live on Harborlight's own careers page, checked before you spend application effort. (2) R8 and R9 answered in your own words. (3) R10 framed as adjacent, never as HIPAA experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` your posting text |
| Mandate | Own product analytics for a care-navigation app: metrics layer, A/B tests, Looker dashboards, PM and clinician partnership, two junior analysts | `[grounded]` posting |
| Scope read | A senior individual-contributor scope with a people component | `[inferred]` from mentoring plus metrics ownership |
| Market calibration | Not run. The role-family search was refused, so no pay or scope norm is calibrated | — |
| Unknowns | Metric-definition ownership, PHI in scope, decision rights, pay, clinician exposure | — |
| Contradictions | None found in the posting text you gave | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years stated; nothing inspected | `[grounded]` your intake | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake stated; "expert" is a judgment | `[grounded]` your intake | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and an 11% retention lift, stated; the lift needs a readout to verify | `[grounded]` your intake | Upgrade menu: pricing-test readout |
| R4 | Looker or similar BI, self-serve dashboards | must_have | direct | medium | none | Built the Looker instance and 40+ governed dashboards, stated | `[grounded]` your intake | none |
| R5 | Define and maintain the metrics layer | must_have | direct | medium | none | Governed dashboards imply it; whether you wrote definitions or inherited them is not stated | `[inferred]` from governed dashboards | Upgrade menu: metric-definition page |
| R6 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly exec memo and VP Product presentation, stated | `[grounded]` your intake | none |
| R7 | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | The memo cadence implies it; no PM-level decision named | `[inferred]` from memo cadence | none |
| R8 | Partner with clinicians | important | unclear | low | discovery | No clinician-facing work stated | `[grounded]` silence in intake | Gap G2 |
| R9 | Mentor two junior analysts | important | unclear | low | discovery | No mentoring stated | `[grounded]` silence in intake | Gap G3 |
| R10 | Healthcare data experience, HIPAA (a plus) | preferred | adjacent | medium | transferability | Consumer PII under GDPR/CCPA and the consent-state model are specific; no PHI or HIPAA work. Limit: no clinical data or HIPAA controls | `[grounded]` your intake; bridge `[inferred]` | Gap G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Healthcare and HIPAA (R10) | transferability | Consent-state model and consumer PII handling; no PHI, BAA, or HIPAA-controlled data | Any PHI, BAA or HIPAA-controlled data work, even at the edge of a role | `[inferred]` bridge; `[generic]` that clinical data is the likeliest objection |
| G2 | Clinician partnership (R8) | discovery | No clinician-facing work stated | Any direct work with clinical or care staff | `[grounded]` silence in intake |
| G3 | Mentoring junior analysts (R9) | discovery | No mentoring stated | Any mentoring or management of analysts | `[grounded]` silence in intake |

The queue holds no questions. The three questions are in the closing block, tagged by row.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Web search was refused in this session, so the entity and the live posting are unchecked. This records that gap; it is not a finding about the company | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Metric ownership and decision rights unstated | unknown | — | "define and maintain the metrics layer" | The role may inherit metric definitions set elsewhere, or set them alone | `[inferred]` from scope language against silence on decision rights | Who owns the metric definitions today, and does this role set them or inherit them? | unresolved |
| RR3 | Whether PHI is in scope | unknown | — | "healthcare data experience (HIPAA) a plus" | The analytics may touch PHI under HIPAA controls | `[inferred]` from the requirement's wording | Does this analytics stack hold PHI, and which access and HIPAA controls apply? | unresolved |
| RR4 | Compensation not in the posting text | unknown | — | (no compensation in the text provided) | Can't calibrate pay; the band search was refused | `[generic]` band not searched | What is the budgeted base range for this level? | unresolved |
| RR5 | Concrete, measurable responsibilities | positive_signal | — | "design and analyze A/B tests … build self-serve dashboards in Looker" | Scope is specified in tools and deliverables, not just a title | `[grounded]` posting text | What does year-one success look like for the metrics layer and experiment program? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the role on Harborlight's own careers page, and find the hiring contact there, before applying | RR1 | `[generic]` standing pattern | pending your approval |
| A2 | Lead the resume with: "Built the company's Looker instance from scratch; 40+ governed dashboards" | R3, R4 | `[grounded]` your intake | `resume_edits_pending_approval` |
| A3 | Frame healthcare as adjacent: "Built the warehouse consent-state model and handled GDPR/CCPA consumer PII." No HIPAA wording | R10 | `[grounded]` your intake | `resume_edits_pending_approval` |
| A4 | Prepare honest answers on mentoring and clinicians: say what you did, not what the role implies | R8, R9 | `[generic]` interviewers probe ownership | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Web search was refused in this session, so the entity and the posting's live status are unchecked. Would have moved RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | The same refusal. Would have calibrated pay (RR4) and scope norms |
| 3. Hiring manager's public footprint | n/a | No name given |

## Upgrade menu

- Permission to run web search again: up to 2 more searches and 2 fetches within the L1 cap would check the employer and calibrate pay. That settles RR1 and RR4.
- The live posting link from Harborlight's careers page: settles RR1 and the contradictions check without a search.
- A sanitized readout of the pricing test: R3 moves toward `high`.
- A metric-definition page you wrote, or a sanitized dashboard screenshot: R5 moves toward `high`.
- Answers to G1–G3: R8, R9 and R10 move off `unclear` or `adjacent` if the answers are specific.
- Deeper research on Harborlight (funding, leadership, recent news; up to 5 more searches and 2 more fetches): say the word and it runs. This is offered once.

If you want, I can write these findings to a `tuesday-dossier.md` you can keep and reuse.

**Questions** (three, each tagged to its gap row):

G1 — Have you ever worked with PHI, or on data under HIPAA or a business associate agreement, even in a consumer-data role at a health-adjacent company? What did you own?

G2 — Have you worked directly with clinicians or care staff, or built analysis they used to make decisions? Who were they, and what changed because of your work?

G3 — Have you managed or mentored junior analysts? What did you own, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.