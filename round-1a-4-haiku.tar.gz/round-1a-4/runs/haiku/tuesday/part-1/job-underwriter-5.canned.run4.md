**Yes, it's worth applying, with three checks first. Status: `conditional_go`.** Your stack matches the posting closely. The open items are the two gates the posting sets (location and pay), which I can't check without your constraints, and BigQuery, which you haven't used.

**Fit ledger.**

- `hard_gate` — unclear: R1 (remote US or Denver location), R2 (pay band against your floor)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R7 (Airflow or similar), R8 (data quality testing)
- `important` — adjacent: R6 (BigQuery warehouse); unclear: R9 (app and CRM ingestion), R10 (data contracts analysts depend on)

R6 — transferable, but you have never run BigQuery; R9 and R10 — no evidence either way, so ask before counting them.

**Opportunity ledger.** The pay is at market and the scope is slightly broad. RR1 (posted base sits near the report's median, a positive signal), RR2 (the scope covers the whole reporting stack, a low-severity risk), RR3 (no hiring manager named) and RR4 (the company's Series C is stated only on its own site) are the entries to check.

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver location), R2 (pay band against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) location and pay fit your constraints (R1, R2); (2) CRM or app ingestion experience is real, or you're comfortable learning it (R9); (3) you can ramp on BigQuery without it being a surprise in interviews (R6).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states, Denver, 264 employees, Series C ($52M, Feb 2026) | `[grounded]` company About page you pasted; funding stated only there |
| Mandate | Build and run ingestion, a dbt warehouse on BigQuery, and data contracts for analysts | `[grounded]` JD |
| Scope read | Covers ingestion through contracts and orchestration, wider than one domain's pipelines | `[inferred]` JD scope against the report's typical scope |
| Market calibration | Report: base median $151,000, IQR $139,000–$163,500, "Senior" = 5–8 years. The posted $148k–$166k brackets the median | `[grounded]` figures from the report you sent; the comparison itself is `[generic]` |
| Unknowns | Location and pay against your constraints; contract type; equity terms; hiring manager | — |
| Contradictions | None between the JD and the pasted careers copy | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver office | hard_gate | unclear | none | hard_gate | No constraint given, so the gate is not settled | `[grounded]` JD | Q1 |
| R2 | Base $148k–$166k plus equity | hard_gate | unclear | none | hard_gate | No pay floor given | `[grounded]` JD | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; stated at intake, no artifact yet | `[grounded]` your intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use; no artifact yet | `[grounded]` your intake | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt on Snowflake, ~180 models | `[grounded]` your intake | none |
| R6 | BigQuery warehouse | important | adjacent | medium | transferability | Snowflake and dbt carry over; no BigQuery operation, so cost, partitioning and GCP tooling are untested | `[inferred]` bridge from R5 | G1 |
| R7 | Airflow or similar | must_have | direct | medium | none | Airflow orchestration | `[grounded]` your intake | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite; ongoing ownership not stated | `[grounded]` your intake | confirm ownership |
| R9 | App and CRM ingestion | important | unclear | none | discovery | Not mentioned at intake | `[grounded]` JD | G2 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Not mentioned at intake | `[grounded]` JD | G3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6) | transferability | dbt and SQL on Snowflake, nothing on BigQuery | Named as the warehouse in the posting | Any BigQuery use, including a sandbox or a course project | A small dbt project on BigQuery with a note on partitioning and cost | `[inferred]` bridge from your Snowflake work |
| G2 | CRM and app ingestion (R9) | discovery | Ingestion of other sources is not stated | Named as the first responsibility | Pipelines from a CRM API, event streams or an app database | A pipeline diagram or a sanitized DAG | `[grounded]` JD |
| G3 | Data contracts (R10) | discovery | Not stated | Named as what analysts depend on | Schema agreements with consumers, breaking-change handling | A contract template or a sanitized example | `[grounded]` JD |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted base near market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is at market for this seniority | `[grounded]` report figures against the posted range | Is equity part of the same package, and what is the budgeted base? | noted |
| RR2 | Scope spans the whole reporting stack | risk_signal | low | "Build and run the pipelines … the data contracts our analysts depend on" | May be one owner for ingestion, modelling and contracts, more than a typical single-domain role | `[inferred]` from JD scope against `[generic]` report norm | Which pipelines does this role own end to end, and which do other teams share? | unresolved |
| RR3 | No hiring manager named | unknown | — | (posting names none) | Common for postings like this; not a warning sign by itself | `[generic]` | Who is the hiring manager, and who would I work with on analytics? | unresolved |
| RR4 | Company footprint stated only on its own site | unknown | — | "Series C ($52M, February 2026)" | The funding and headcount are accurate but not yet independently confirmed | `[grounded]` search returned only the company's About page | Could you confirm the funding round and the current size of the data team? | unresolved |

**Application plan** (every row needs your approval before anything is sent or added to a résumé)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead your résumé with dbt on Snowflake (~180 models), Airflow and the Great Expectations suite | Matches R5, R7, R8 | `[grounded]` your intake | pending your approval |
| A2 | Do not list BigQuery; describe it as a planned ramp if asked | Keeps R6 at `adjacent` | `[grounded]` R6 | pending your approval |
| A3 | Confirm location and pay with the recruiter before a long application | Hard gates R1, R2 | `[grounded]` JD | pending your approval |
| A4 | Put RR2 and RR4 to the recruiter as written | They are the questions an interviewer will expect you to ask | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet. Your intake claims are self-report, so they stay at `medium` until you show an artifact.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results) and "Pellucid Learning Series C funding 2026" (returned only pellucidlearning.com/about, the page your text came from). No independent source confirms the funding or headcount, so RR4 stays open. The employer is attributed through its own site alone. |
| 2. Role-family sweep | skipped | The recruiter's report, pasted in full, already fixes the market band (inputs fix this output) |
| 3. Hiring manager's public footprint | n/a | No name given |

**Upgrade menu**

- A sanitized dbt or BigQuery sandbox, or a note on partitioning and cost → R6 to `direct`.
- A description of one CRM or app ingestion pipeline → R9 resolves.
- Your location and pay constraints → R1 and R2 close, and the decision becomes `go` or `no_go`.
- A deeper check on Pellucid (funding coverage, leadership changes, recent hiring; up to 5 more searches and 2 more fetches) — say the word and it runs.

I can also write this up as `tuesday-dossier.md` to carry into interview prep, if you want it.

1. Are a remote US or Denver location and a $148k–$166k base plus equity within your constraints? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. Have you built ingestion from a CRM or your app's event data? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. Have you used BigQuery at all, even in a sandbox or a course? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.