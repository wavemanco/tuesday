**Yes, apply.** On the evidence you've given, all five must-have rows read `direct`, and the open edges are healthcare, clinician work and mentoring. Status: `conditional_go`.

**Fit ledger**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: adjacent: R6 (metrics layer), R7a (product-manager partnership); unclear: R7b (clinician partnership), R8 (mentoring junior analysts)
- `preferred`: adjacent: R9 (healthcare data, HIPAA)

R1–R5 rest on your intake description, which I can't yet verify, so they stay at `medium`. R6 and R7a are bridges from work you've described. R7b and R8 have no evidence in what you've given me.

**Opportunity ledger.** Scope and outcomes are concrete (RR3, positive). Pay, location and contract type are not in the posting (RR2). The employer is not yet verified (RR1, standing entry), and it caps the decision at `conditional_go`.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** conditions for `conditional_go`: (1) RR1 clears, meaning the posting is confirmed on Harborlight's own careers page; (2) RR2 clears, meaning pay, location and contract type fit your needs (you haven't told me yours); (3) R7b and R8 get concrete examples from you before interviews, or the application stops claiming them.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD header, not checked against the company's own site |
| Mandate | Product analytics for the care-navigation app: metrics layer, A/B tests, Looker self-serve, PM and clinician partnership, mentoring two juniors | `[grounded]` JD |
| Scope read | A senior individual-contributor role with a mentoring load and metrics-layer ownership | `[inferred]` from the JD's responsibility list |
| Market calibration | None. The role-family sweep did not run, so there is no band | — |
| Unknowns | Pay, location, contract type, whether clinical data is in scope, and who decides metric definitions | — |
| Contradictions | None inside the posting | `[grounded]` JD |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company is stated, unprobed. Ceiling is `medium` at intake | `[grounded]` intake prose | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake is stated. "Expert" is your own rating, not yet shown | `[grounded]` intake prose | Share a sanitized query you wrote; that raises it to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and an 11% retention lift are stated. The lift is unverified | `[grounded]` intake prose | A scrubbed readout of the pricing test raises it to `high` |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the Looker instance and 40+ governed dashboards | `[grounded]` intake prose | A governance doc or dashboard screenshot raises it to `high` |
| R5 | Strong written communication for non-technical readers | must_have | direct | medium | none | Writes the monthly metrics memo that the exec team reads | `[grounded]` intake prose | A scrubbed copy of the memo raises it to `high` |
| R6 | Define and maintain the metrics layer | important | adjacent | medium | transferability | Governed dashboards and the metrics memo carry over. Ownership of metric definitions is not stated | `[inferred]` bridge from R4 and R5 | Ask who owned definitions and change control (G1) |
| R7a | Partner with product managers on roadmap decisions | important | adjacent | medium | transferability | The monthly VP Product readout carries over. No stated PM co-decision | `[grounded]` intake prose | Bridge: exec readouts. Limit: PM co-decision not shown |
| R7b | Partner with clinicians | important | unclear | low | discovery | Nothing in the material touches clinicians | `[grounded]` absence in intake | Closing question Q2 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | No mentoring is stated | `[grounded]` absence in intake | Closing question Q1 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model carry over. No PHI or HIPAA work stated. Preferred, so it cannot gate | `[grounded]` intake prose; `[generic]` that HIPAA adds handling rules beyond consent | Bridge: consent and privacy. Limit: no HIPAA or PHI handling. Do not claim healthcare data experience |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics-layer ownership (R6, important) | transferability | Governed dashboards and a memo; no stated ownership of definitions | Decides whether the bridge reads as ownership or as usage | Maintaining a metric dictionary; resolving disputes over a metric's definition; changing a governed definition | A metric-definition doc, a change log | `[inferred]` bridge; `[generic]` that this is the likeliest probe |
| G2 | Clinician partnership (R7b, important) | discovery | Nothing in the material | A named gap in a responsibility the JD lists | Work with ops, care teams, or any non-product domain experts | A brief or readout written for them | `[grounded]` absence |
| G3 | Mentoring (R8, important) | discovery | Nothing in the material | The JD names it; interviewers will ask | Onboarding, code or query review, career conversations | A review note or onboarding doc | `[grounded]` absence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small for a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Harborlight's own careers page, and who would I be interviewing with? | unresolved |
| RR2 | Pay, location and contract type unstated | unknown | — | (silent in the posting) | The range may fall outside your needs, or the posting may leave it to the interview stage | `[inferred]` from the posting's silence | What is the base range, where is the role based, and is it permanent? | unresolved |
| RR3 | Scope and outcomes defined | positive_signal | — | "define and maintain the metrics layer" | Scope is concrete and success is measurable | `[grounded]` JD | Who signs off metric definitions today, and how is the layer governed? | noted |
| RR4 | Clinical and PHI scope unspecified | unknown | — | "partner with … clinicians"; "healthcare data experience (HIPAA) a plus" | The data may be consumer usage or protected health information, and the handling rules differ | `[inferred]` from the clinician partnership and the HIPAA mention | Which data sets does this role analyze, and how much is protected health information? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Prepare a scrubbed memo or experiment readout as a work sample | Raises R3 and R5 to `high` | `[grounded]` R3, R5 rows | pending your approval |
| A1 | Check the posting on Harborlight's careers page before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the recruiter for pay, location and contract type before the loop | RR2 | `[grounded]` RR2 | pending your approval |
| A3 | Describe healthcare as consent and privacy work (R9), and do not claim HIPAA or PHI experience | R9 limit | `[grounded]` R9 row | pending your approval |
| A4 | Prepare a mentoring example only if a real one exists | R8 | `[grounded]` R8 row | pending your approval |

**Evidence status**

Verified: none yet. Your intake description is self-report, so every claim is still a lead.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused by the session's permission setting, so the posting is unchecked. This would have settled RR1 |
| 2. Role-family sweep | unavailable | Refused in the same way. This would have set the market band for pay and scope |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Dossier offer:** I can emit this analysis as a `tuesday-dossier.md` file for the other modules to read, if you want it.

**Upgrade menu**

- Allowing web search, or pasting the careers-page link, runs targets 1 and 2 (up to 5 searches and 2 fetches) and can close RR1.
- A recruiter's answer on pay, location and contract type closes RR2 and sets the band against it.
- A scrubbed memo or experiment readout raises R3 and R5 to `high`.
- Your pay floor, location and work-pattern limits would let the hard-gates line run its checks.

**Questions**

Q1 (R8, G3): Have you mentored or trained junior analysts? What did you own, and what happened?

Q2 (R7b, G2): Have you worked on an analysis with clinicians or other non-product domain experts? What did you own?

Q3 (constraints): Do you have non-negotiables on pay floor, location or work pattern? If none, say so.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.