**Worth applying to, after two quick checks. Status: `conditional_go`.** Your pipeline, renewal, CRM and SQL work matches most of this role. The gap is the forecast and billing-data half, which the posting puts at the centre of the job.

- **Hard gates:** none failed; unconfirmed: R1 (pay £61,500–£67,000 plus share options), R2 (Bristol, two days a week in the office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.

**Fit ledger.** This is a map projection, so every row appears once.

- `hard_gate`: unclear: R1 (pay), R2 (Bristol hybrid)
- `must_have`: direct: R4, R5 · adjacent: R3, R6 · absent: R7
- `important`: direct: R8a, R9 · absent: R8b

R3 — adjacent, payments rather than software. R6 — adjacent, pipeline review but never the forecast. R7 — absent, no billing work. R8b — absent, the billing half of the CRM-and-billing ownership.

**Opportunity ledger.** The stated pay sits inside the market band, and the remit is concrete. Two entries need checking: the forecast and billing scope may be bundled (RR1), and the hiring manager's public title overlaps the forecast remit (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organisation | Quillfield, invoicing and payments software for UK builders' merchants; Bristol; 96 staff; £11M Series A, April 2025 | `[grounded]` company About page |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Market band | Median £64,200, interquartile range £57,800–£70,400 for UK revenue operations leads at B2B software firms | `[generic]` Ledgerline 2026 pay guide; the posted range sits inside it |
| Working pattern | Hybrid, two days a week in the Bristol office | `[grounded]` posting |
| Unknowns | Forecast ownership versus the CFO's; whether billing data is run here or only read; right to work | — |
| Contradictions | None between the posting and the company's About page | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor given, so the check cannot run | `[grounded]` posting | Q1 |
| R2 | Bristol, two days a week in the office | hard_gate | unclear | none | hard_gate | No location or schedule constraint given | `[grounded]` posting | Q1 |
| R3 | 4+ years in RevOps, sales ops or analytics at a B2B software company | must_have | adjacent | medium | transferability | Five years in sales operations, two running RevOps, at a B2B payments company. Limit: software versus payments, and the years are self-reported | `[grounded]` your intake, CV-equivalent | Name the payments-to-software bridge in the CV |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. Certificate not yet inspected | `[grounded]` your intake | Upload the certificate to raise to high |
| R5 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily; self-reported | `[grounded]` your intake | none |
| R6 | Experience owning a forecast; running the quarterly forecast with the CFO | must_have | adjacent | medium | transferability | Monthly pipeline review with the sales director is a forecast input. Limit: you have never owned the company forecast; finance did | `[inferred]` bridge from the pipeline review | Q3 |
| R7 | Experience working with finance on billing or revenue data | must_have | absent | none | transferability | You have never worked on billing data. Pipeline and renewal data is the nearest adjacent work | `[grounded]` your statement | Q2 |
| R8a | Own the CRM data | important | direct | medium | none | Salesforce admin and rebuilt dashboards | `[grounded]` your intake | none |
| R8b | Own the billing data | important | absent | none | capability | No billing ownership stated | `[grounded]` your statement | Q2 |
| R9 | Build pipeline and renewal reporting | important | direct | medium | none | Rebuilt the pipeline and renewal dashboards | `[grounded]` your intake | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | transferability | Pipeline review, not the forecast | This is the requirement the posting names most directly | Forecast-input work: deal-stage accuracy, close-date slippage calls, a pipeline-to-forecast bridge you fed | A forecast-versus-actual sheet, a pipeline-review pack | `[inferred]` bridge from the pipeline review; `[generic]` that forecast ownership is the likeliest objection |
| G2 | Billing data (R7, R8b) | transferability | Pipeline and renewal data only | Two requirements touch billing | Reconciling bookings to invoices, renewal value against billed value | A reconciliation example | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast and billing scope bundled into one lead role | risk_signal | low | "run the quarterly revenue forecast with the CFO"; "own our CRM and billing data" | The role may carry three jobs (RevOps, forecasting, billing data) at a mid-band salary | `[inferred]` from the posting's scope against its pay band | Which parts of the quarterly forecast does this role own, and which stay with the CFO's team? | unresolved |
| RR2 | Hiring manager's public title overlaps the forecast remit | unknown | — | Hiring manager listed as Head of Revenue Operations | The Lead may report into a Head whose remit already covers forecasting and reporting | `[grounded]` public profile, linkedin.example/in/tamsin-achebe | How does this role's forecast ownership sit alongside the Head of Revenue Operations' remit? | unresolved |
| RR3 | Role not found on the company's own pages | risk_signal | low | Search on the company name and role returned nothing | The live posting may sit only on an aggregator, or the role may be stale | `[generic]` pattern for aggregator postings; the company itself is attributed | Can you point me at this role on Quillfield's own careers page? | unresolved |
| RR4 | Pay inside the market band | positive_signal | — | £61,500–£67,000 | The offer is in the normal range for this title | `[generic]` band against `[grounded]` posting | What is the budgeted salary, and does the band include the share options? | noted |

Severe red flags: none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the Salesforce admin certification and the pipeline and renewal dashboards | R4, R9 | `[grounded]` your intake | pending your approval |
| E2 | Describe the forecast work as pipeline inputs to the forecast; never as owning it | R6 | `[grounded]` your statement | pending your approval |
| A1 | Ask the RR1, RR2 and RR3 questions verbatim in the first call with the recruiter | Interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your intake is CV-equivalent, so every claim above is unconfirmed until you answer a question or attach an artifact. The employer is attributable, so the employer-not-established standing entry does not apply.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" → quillfield.co.uk/about (Bristol, 96 staff, Series A April 2025): the employer exists as described. Searched "Quillfield Revenue Operations Lead jobs" → no results, so the role was not found on the company's own pages (RR3) |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B software 2026" → Ledgerline 2026 UK Revenue Operations Pay Guide (ledgerline.example/2026-uk-revenue-operations-pay-guide): median £64,200, interquartile range £57,800–£70,400, n=438. Moved the market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" → linkedin.example/in/tamsin-achebe: Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years. Moved RR2 |

The three `yes` rows rest on search snippets. I did not fetch any page, so the posting's liveness on the company's own site is still unverified.

**Dossier offer:** I can save this as `tuesday-dossier.md` so a later session can pick it up from here.

## Upgrade menu

- Quillfield's careers page, or the recruiter's email domain → RR3 closes.
- The pay floor and the office-days answer → R1 and R2 move from unconfirmed to met or failed.
- A forecast-versus-actual sheet or a pipeline-review pack → R6 rises from `medium`.
- A reconciliation example from billing or renewal data → R7 and R8b rise.
- The Salesforce admin certificate → R4 rises to `high`.
- A deeper pass on Quillfield (funding, leadership changes, past postings; up to 5 more searches and 2 more fetches) → say the word and it runs.

## Questions

Q1 (R1, R2) — Are the gate terms workable for you: two days a week in the Bristol office, a base of £61,500, and no need for sponsorship?

Q2 (R7, R8b) — Have you ever worked with invoice, billing or renewal-value data, even read-only? What did you do with it, and what was the outcome?

Q3 (R6) — Did you ever feed the forecast, for example deal-stage accuracy, close-date slippage calls, or a pipeline-to-forecast bridge? Who owned the final number, and what did your input change?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.