**Yes, apply, on two conditions. `conditional_go`.** Your GLM, SQL/Python, price-testing and underwriting-presentation experience matches the core of this role. The gap is pet insurance, which is a transferability gap, not an absence. Two things stay open: whether you meet the UK remote gate, which you haven't told me, and whether Brindlemoor is a live, real employer, which I could not check.

**Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0.** Every search was refused by the permission prompt, so I could not check the company, the posting, Odile Varga's public footprint, or market pay. I have not retried them.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches on Brindlemoor were refused. Would have settled whether the employer and posting are real (RR1) |
| 2. Role-family sweep | unavailable | One salary and norms search was refused. No market calibration line is given |
| 3. Hiring manager's public footprint | unavailable | One search on Odile Varga was refused. Would have fed the positioning for this reader |

## Decision snapshot

**Yes, apply — `conditional_go`.** Apply once the UK-remote gate is confirmed and the employer checks out.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2 (4+ years pricing analytics), R3 (strong SQL and Python), R4 (GLM experience), R5 (presenting to underwriting or actuarial leads)
- `important` — direct: R6 (designing and reading price tests), R7 (building and monitoring rating models) · adjacent: R8 (Own pricing analytics for a pet-insurance product)
- `preferred` — direct: R9 (Insurance experience)

R8 — a credible bridge from motor pricing, its limit named; R1 — the gate is not yet settled, and it is the first question below.

**Opportunity ledger.** The scope is concrete and the reporting line is clear, so the role reads as well defined (RR4). Against that, the employer is unverified (RR1, standing entry), the pay and contract are not stated (RR2), and the posting doesn't say whether the role manages people (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed, meaning you are UK-based and can work for a UK employer without sponsorship; (2) RR1 cleared: the live posting is on Brindlemoor's own careers page and the employer is verified; (3) the pet-insurance bridge is framed as transferable motor pricing, never as pet-insurance experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product; fully remote, UK | `[grounded]` JD header |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Scope read | A senior individual-contributor scope. The JD gives no reports and no people-management language | `[inferred]` from the JD's silence on reports |
| Market calibration | Not run. The searches were refused, so there is no band | — |
| Unknowns | Pay, contract type, reports, whether a pet-claims dataset exists, the employer's verification | — |
| Contradictions | None visible within the JD | `[grounded]` JD |

## Evidence map

Your intake is prose, so no row can go above `medium` yet. Nothing is verified.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | Your location and right to work are not in the intake | `[grounded]` JD; candidate silent | Question 1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in motor pricing analytics, stated, with no artifact | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | `[grounded]` your statement | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model for the young-driver book | `[grounded]` your statement | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review presented to the head of underwriting | `[grounded]` your statement | none |
| R6 | Designing and reading price tests | important | direct | medium | none | Fourteen price tests run last year with underwriting | `[grounded]` your statement | none |
| R7 | Building and monitoring rating models | important | direct | medium | none | Maintained the young-driver model; monitoring is implied, not stated | `[grounded]` your statement; monitoring `[inferred]` | Confirm monitoring is in your remit |
| R8 | Pet-insurance product pricing | important | adjacent | medium | transferability | Motor rating and price-testing methods carry over. You have not exercised pet cover structure or pet claims costs | `[inferred]` from R4 and R6; `[generic]` that pet cover prices differently from motor | G1 |
| R9 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your statement | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product pricing (R8, important) | transferability | Motor rating and price-test work; nothing on pet cover | The likeliest objection. Your motor depth is the bridge; pet cover and claims costs are the limit | Any non-motor product, any work on claims costs that aren't vehicle-based, any cover-structure change you priced | A redacted pricing note, a price-test readout, or a model doc from any non-motor line | `[inferred]` bridge from R4 and R6; `[generic]` on the objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | Not checked: the searches were refused. The entry could be a thin footprint, a stale posting, or not a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at the live posting on your careers site, and who would I interview with?" | unresolved |
| RR2 | Pay and contract not stated | unknown | — | "Fully remote (UK)"; no salary given | Pay may sit below or above the market band; the withholding is itself worth asking about | `[inferred]` from the JD's silence | "What is the budgeted salary and the contract type for this post?" | unresolved |
| RR3 | People management not stated | unknown | — | "Own pricing analytics"; no reports mentioned | The role may be individual-contributor, or may carry reports under a Director of Pricing | `[inferred]` from the JD's silence | "Does this role line-manage anyone, and who is the Director of Pricing's team?" | unresolved |
| RR4 | Scope well defined | positive_signal | — | "build and monitor rating models, design and read price tests" | The mandate is concrete and measurable | `[grounded]` JD | "What does success look like in year one?" | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your UK base and right to work before you apply | R1 is an unsettled gate | `[grounded]` R1 | pending your approval |
| A2 | Find the live posting on Brindlemoor's own careers page, and check the employer exists | RR1 | `[generic]` pattern | pending your approval |
| A3 | Lead with motor GLM and price-test work; state pet as an explicit gap, not as experience | R4, R6, R8 | `[grounded]` rows; `[inferred]` framing | pending your approval |
| A4 | Positioning line, for your approval: "Built and maintained a GLM rating model for a young-driver motor book; designed and read price tests with underwriting. No pet-insurance pricing to date." | Reframing audit: every clause traces to your intake. "Ran 14 price tests" is kept as "designed and read" only if you confirm you led the design | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet. Your intake is self-report, so every claim stays a lead until you confirm it.

## Upgrade menu

- A redacted GLM model doc or validation note → R4 and R7 to `high`.
- A redacted price-test readout you presented → R6 to `high`.
- Any non-motor pricing work → R8 narrows; G1 closes.
- The live posting link and Brindlemoor's careers page → RR1 clears.
- The budgeted salary and contract → RR2 closes.
- Research on Brindlemoor and Odile Varga's public footprint needs searches to be allowed; they were refused here, so it's not available until you allow them.

I can also write this up as `tuesday-dossier.md`, so other modules can read it later.

1. **R1** — Are you based in the UK, and can you work for a UK employer without sponsorship? Answer in text, or say skip.
2. **R8** — Have you priced, or worked on claims costs for, any non-motor product? Answer in text, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.