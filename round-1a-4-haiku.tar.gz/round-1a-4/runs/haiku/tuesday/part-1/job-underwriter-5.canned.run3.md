**Yes, it's worth applying: `conditional_go`.** Your direct experience covers the five must-haves. The conditions are two gates I can't check until you tell me your location and pay floor, and one question about ingestion ownership.

**Fit ledger**

- `hard_gate`: unclear: R9 (remote US or Denver location), R10 (base pay $148,000–$166,000)
- `must_have`: direct: R1 (5+ years data engineering), R2 (strong SQL and Python), R3 (dbt and a cloud warehouse), R4 (Airflow or similar orchestration), R5 (data quality testing)
- `important`: adjacent: R6 (BigQuery warehouse), R8 (data contracts analysts depend on); unclear: R7 (ingestion from app and CRM)

R1–R5 are each `direct` at `medium`, the intake ceiling. R6: Snowflake transfers, BigQuery itself is none. R7: no evidence either way. R8: quality tests are the nearest work, and contracts with downstream users are not claimed. R9 and R10: your constraints were not given.

- **Hard gates:** none failed; unconfirmed: R9 (remote US or Denver location), R10 (base pay $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** The posted pay (RR4) reads at-market against the pay report. Open unknowns are equity (RR1) and the reporting line (RR3). One low-severity risk signal is scope breadth (RR2).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` about page, via search |
| Mandate | Ingestion from app and CRM, a dbt warehouse on BigQuery, data contracts | `[grounded]` JD |
| Scope read | Three areas under one owner, wider than the usual one-domain scope | `[inferred]` from the JD's three-part scope, against a `[generic]` norm |
| Market calibration | Senior at Series B–D: base median $151,000, IQR $139,000–$163,500. The posted range sits around the median. | `[generic]` Datawright 2026 pay report (n=2,310), search snippet; posted range `[grounded]` JD |
| Unknowns | Equity, reporting line, hiring manager, your location and pay floor | — |
| Contradictions | None. The careers page text matches the JD you pasted. | `[grounded]` careers page fetched |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; intake prose stops at medium | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated, no artifact yet | `[grounded]` your background | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake | `[grounded]` your background | none |
| R4 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow orchestration stated | `[grounded]` your background | none |
| R5 | Data quality testing | must_have | direct | medium | none | Great Expectations suite set up by you | `[grounded]` your background | none |
| R6 | BigQuery warehouse (in the JD's responsibilities, not its requirement list) | important | adjacent | medium | transferability | Snowflake dbt work carries over; BigQuery itself is none | `[grounded]` JD; `[inferred]` transfer from Snowflake dbt work | Name BigQuery as a limit; a ramp plan would narrow it |
| R7 | Ingestion from app and CRM | important | unclear | low | discovery | Your background is silent on ingestion | `[grounded]` background silence | Question below |
| R8 | Data contracts analysts depend on | important | adjacent | low | transferability | Quality tests are the nearest work; contracts with consumers not claimed | `[inferred]` from R5 | Ask whether you've agreed contracts with downstream users |
| R9 | Remote US or Denver location | hard_gate | unclear | none | hard_gate | Your location was not given | `[grounded]` JD | Question below |
| R10 | Base pay $148,000–$166,000 against your floor | hard_gate | unclear | none | hard_gate | Your floor was not given | `[grounded]` JD | Question below |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Ingestion (R7) | discovery | Not in your background | An example of an app or CRM source you ingested | `[grounded]` background silence |
| G2 | Data contracts (R8) | transferability | Tests exist; no contract with consumers | A contract or schema agreement with a downstream team | `[inferred]` from R5 |
| G3 | BigQuery (R6) | transferability | Snowflake and dbt only | A BigQuery sample, or a ramp plan with a small project | `[grounded]` background; `[inferred]` transfer |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity unstated | unknown | — | "plus equity" | Equity could be meaningful or nominal | `[inferred]` from posting silence | What is the equity grant for this level, and what is its vesting schedule? | unresolved |
| RR2 | One owner across three areas | risk_signal | low | "Build and run the pipelines behind our tutoring platform's reporting: ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | Scope is wider than the usual one-domain scope | `[generic]` norm for this pay band; `[inferred]` from the JD's three-part scope | Who else owns pipelines here, and which of the three areas would I own alone? | unresolved |
| RR3 | Hiring manager and reporting line not named | unknown | — | (no manager named in the posting) | Reporting line unknown | `[inferred]` from posting silence | Who would I report to, and how many data engineers are on the team? | unresolved |
| RR4 | Pay posted and consistent | positive_signal | — | "$148,000–$166,000" | Pay is transparent and sits around the market median | `[grounded]` JD; `[generic]` band | — | noted |

The standing employer-not-established entry does not apply: the careers page is live and the about page matches your copy.

**Application plan** (every row pending your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the CV with the Snowflake dbt project and the Great Expectations suite | see R3, R5 | `[grounded]` background | pending your approval |
| A2 | Present BigQuery as a limit with a ramp plan, not as a skill | see R6 | `[inferred]` | pending your approval |
| A3 | Ask the recruiter for the equity grant and reporting line before the loop | see RR1, RR3 | `[generic]` pattern | pending your approval |

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched pellucidlearning.com/careers/senior-data-engineer: the posting is live and its text matches the JD you pasted. The about page (pellucidlearning.com/about) came back on the pay-report search, not on the company search, which returned nothing. Moved the contradictions row to none and confirmed the employer. |
| 2. Role-family sweep | yes | Searched "Senior Data Engineer salary Series B-D 2026 median base pay report"; the result was the Datawright 2026 Data Engineering Pay Report (datawright.example/2026-data-engineering-pay-report), read from the search snippet only, not fetched. Set the market calibration against it as `[generic]`. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. The upgrade menu names what a name would unlock. |

Dossier offer: I can write this assessment to `tuesday-dossier.md` so the next round can pick it up.

**Upgrade menu**

- Your location and base-pay floor → R9 and R10 close, and the first condition resolves.
- An example of ingestion from an app or CRM source → R7 moves off unclear.
- A BigQuery sample or a short ramp plan → R6's limit narrows.
- The equity grant and the hiring manager's name → RR1 and RR3 close, and the scope read sharpens.
- Deeper research on Pellucid (funding and leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

R9 and R10: Where are you based, could you work from the Denver office or remotely in the US, and what is the lowest base salary you'd accept?

R7: Have you owned ingestion from an application database or a CRM into a warehouse? Which tools, how many sources, and who depended on the data?

RR2: Who else on the team owns pipelines, and which of the three areas would you own alone?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.