**Yes, it's worth applying, with conditions. Status: `conditional_go`.** Your stack matches the JD almost line for line. The open items are BigQuery, which is adjacent to your Snowflake work, and two responsibilities your intake doesn't describe. Before you invest in the application, check that the posting is live on the company's own site and settle your location and pay floor.

**Fit ledger.**

- `hard_gate` — unclear: R1 (remote US or Denver office), R2 (base pay range)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt), R6 (cloud warehouse), R7 (Airflow orchestration), R8 (data quality testing)
- `important` — adjacent: R9 (BigQuery); unclear: R10 (ingestion from our app and CRM), R11 (data contracts analysts depend on)

R9 is a credible bridge with its limit named. R10 and R11 are in the JD but not in your background. R1 and R2 are gates that stay open until you answer.

**Opportunity ledger.** The pay sits inside the market band (RR3), and the hiring manager, equity and scope are unknown (RR2, RR4, RR5). The employer and posting are not yet verified (RR1). Web search was refused this session, so RR1 caps the decision at `conditional_go` until you check the posting yourself.

- **Hard gates:** none failed (no gate row `direct`); unconfirmed: R1 (remote US or Denver office), R2 (base pay range); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** Go, once RR1 clears (the posting is live on pellucidlearning.com), R1 confirms you're US-based or can work for a US employer without sponsorship, and R2's $148,000 base is above your floor. It becomes `no_go` if R1 fails, or if your floor is above the $166,000 top of the range.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, Feb 2026 | `[grounded]` your copy of the About page; not independently checked |
| Mandate | Build and run reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | One reporting domain across three layers, which is broader than a single pipeline | `[inferred]` from the JD's three named layers |
| Market calibration | Senior at Series B–D companies: base median $151,000, IQR $139,000–$163,500, 5–8 years, one domain, no direct reports. The posting's midpoint ($157,000) sits inside the IQR; its top ($166,000) is above it | `[generic]` the 2026 Datawright report as your recruiter quoted it; its method is not seen |
| Unknowns | Hiring manager; equity value; whether ingestion from the app and CRM already exists or must be built; whether the warehouse is already on BigQuery | — |
| Contradictions | None in the material you gave. The live careers page was not checked | `[grounded]` the JD and About page as provided |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and work status weren't given, so the gate isn't settled. No statement of yours exists to grade | `[inferred]` from the JD's location terms | Question A |
| R2 | Base pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your floor wasn't given. Equity is unquantified and doesn't count toward the gate | `[grounded]` JD | Question B |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated at intake. Medium is the intake ceiling. Length of experience is not a gate | `[grounded]` your intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated; no artifact yet | `[grounded]` your intake | none |
| R5 | dbt | must_have | direct | medium | none | dbt project of about 180 models, built on Snowflake | `[grounded]` your intake | none |
| R6 | Cloud warehouse | must_have | direct | medium | none | Snowflake in production | `[grounded]` your intake | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, stated | `[grounded]` your intake | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` your intake | none |
| R9 | BigQuery (named platform) | important | adjacent | medium | transferability | Snowflake dbt and SQL carry over. BigQuery's cost model, partitioning and IAM are not exercised; you've never used BigQuery | `[grounded]` the Snowflake claim; `[inferred]` the transfer; `[generic]` that dbt's modelling is largely portable across warehouses | Gap queue G1 |
| R10 | Ingestion from our app and CRM | important | unclear | none | discovery | Your intake names no source systems | `[grounded]` absence in intake | Question C |
| R11 | Data contracts analysts depend on | important | unclear | none | discovery | No contract work is stated; GE tests are adjacent but not the same thing | `[grounded]` absence in intake | Question C |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9) | transferability | Snowflake dbt and SQL work; no BigQuery | The JD names the platform, so a stronger bridge narrows the likely objection | Snowflake cost tuning (warehouse sizing, clustering, query costs) that maps onto BigQuery's bytes-scanned model; any dbt macros that were warehouse-specific | A sanitized dbt model or a Snowflake cost review | `[grounded]` intake; `[inferred]` the cost-tuning transfer; `[generic]` dbt portability |
| G2 | Ingestion and data contracts (R10, R11) | discovery | Airflow and GE are stated; source systems and consumer contracts are not | These are two of the JD's three named layers, so they decide whether the role is your work | A pipeline that pulled from a product database, an API or a CRM; a schema that downstream teams relied on, with change notice or versioning | An anonymized DAG or source list; a GE expectations file | `[grounded]` intake absence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not established | risk_signal | medium | "Senior Data Engineer — Pellucid Learning" | Unverified, not found missing: search was refused, so no independent check ran. The posting may be stale, or the employer may be too new or small to have a footprint | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | No hiring manager named | unknown | — | (none named) | Without an owner, scope and reporting can't be checked | `[inferred]` from the posting's silence | Who owns this pipeline day to day, and who does this role report to? | unresolved |
| RR3 | Base pay inside the market band | positive_signal | — | "$148,000–$166,000 plus equity" | The base sits inside the IQR and near the median | `[grounded]` posting figure; `[generic]` band from the recruiter's copy of the report | How is the base set within the range for a new hire? | noted |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Its value can't be judged from the posting | `[inferred]` from the posting's silence | What equity is offered, on what vesting, and at what recent valuation? | unresolved |
| RR5 | Scope across three layers | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting…" | Ownership may be one domain, as is typical at this level, or a broader platform scope | `[inferred]` from the JD's three layers against `[generic]` Senior scope | Which pipelines would this role own end to end, and who else touches the warehouse? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on pellucidlearning.com's careers page before applying | RR1 | `[grounded]` RR1 | proposed |
| A2 | Resume line, pending your approval: "Built our dbt project on Snowflake, about 180 models; no BigQuery experience yet." The last clause is deliberate candor | R5, R9 | `[grounded]` your sentences | resume_edits_pending_approval |
| A3 | Ask about the source systems and the consumers of the contracts early in the first screen | R10, R11 | `[generic]` that screens test scope early | proposed |
| A4 | Put RR2, RR4 and RR5's verification questions to the interviewer verbatim | The register doubles as interview preparation | `[grounded]` register | proposed |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches on Pellucid Learning were refused: web search wasn't permitted in this session. No fetch was attempted. This would have moved RR1 and the contradictions row |
| 2. Role-family sweep | skipped | The pay report's figures are quoted in your message and fix the market calibration. Checking the report's method would need a search you can't yet grant |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

**Upgrade menu**

- Your location and work status → R1 closes, and the hard-gates line changes.
- Your base floor → R2 closes, and RR3 is read against your number.
- A live posting link or the careers-page URL → RR1 clears or stays open.
- A sanitized dbt model, a Snowflake cost review, or a GE expectations file → R3 to R9 can move from medium to high, and G1 narrows.
- A description of the source systems and one contract → G2 closes, and R10 and R11 can move to direct.
- Deeper research on Pellucid (leadership changes, hiring patterns, public employee reports; up to 5 more searches and 2 more fetches). Search would need permission for this to run.

If you want, I can write this into `tuesday-dossier.md` so later turns can pick it up.

Three questions, each tied to its row:

**R1:** Where are you based, and can you work for a US employer without sponsorship?

**R2:** Is a $148,000 base above the lowest you'd accept?

**R10 and R11:** Which source systems have you ingested from, and have you owned a data contract with analysts? Name the source, the pipeline and who consumed it.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.