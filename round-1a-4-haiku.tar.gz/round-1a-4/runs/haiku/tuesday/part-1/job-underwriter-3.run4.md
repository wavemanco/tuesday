## Decision snapshot

**No: R1 and R2, both hard gates, fail · `no_go`.** As posted, this role conflicts with your two hard constraints, so the fit doesn't matter.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (on-site in Austin, 5 days a week), R2 (base pay $70–85k)
- `must_have` — direct: R3a, R4 · unclear: R3b (SEO/content, brand, PR, partnerships, sales ops), R5 (thrive on ambiguity)
- `important` — adjacent: R6 (e-commerce enablement buyer)

R4 — nine years in growth, Head of Growth at B2C subscription companies, `medium`, self-reported; R3a — paid and lifecycle owned, `medium`; R6 (`medium`) — B2C background, not merchant-facing; R3b and R5 — not evidenced yet.

**Opportunity ledger.** The two failed terms are stated in the posting itself (RR1, RR2, both `red_flag`). The scope, hours and undefined success read as risk signals (RR3, RR4, RR5). The company's stage and existence are unverified (RR6, RR7). The reporting line is clear (RR8).

- **Hard gates:** failed: R1 (on-site in Austin 5 days a week), R2 (base pay $70–85k)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** R1 would have to read remote-eligible from Portland, and R2 would have to read a base of at least $150k. Both need to come from the employer in writing, and the posting currently says the opposite on location.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting; not verified (search refused, see Evidence status) |
| Mandate | All revenue growth end to end: seven functions, team of one to start | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | Austin on-site 5 days a week, no exceptions; evenings and weekends | `[grounded]` posting |
| Compensation | $70–85k base plus unquantified equity | `[grounded]` posting |
| Market calibration | Not run: the role-family search was refused, so there is no band. Pay is judged against your $150k floor instead (RR2) | — |
| Unknowns | Whether the company is profitable; equity size; which functions have budget; success metrics | — |
| Contradictions | "Team of one" against seven owned functions | `[grounded]` posting text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site Austin 5 days a week, no exceptions | hard_gate | hard_gate_fail | high | hard_gate | Your constraint is remote-only from Portland, not relocating. Confidence grades your statement, not the fit | `[grounded]` posting; your intake | Surface; only the employer changing the term in writing resolves it |
| R2 | Base pay $70–85k (your floor $150k) | hard_gate | hard_gate_fail | high | hard_gate | The top of the base range is $65k under your floor. Equity is unquantified and is not base pay | `[grounded]` posting; your intake | Surface; only the employer changing the range in writing resolves it |
| R3a | Own paid acquisition and lifecycle/CRM | must_have | direct | medium | none | Your description says you owned both at B2C subscription companies. No artifact yet | `[grounded]` your intake | Upload a CV to lift this to an inspectable read |
| R3b | Own SEO/content, brand, PR, partnerships, sales ops | must_have | unclear | none | discovery | Not in your description; the posting makes them part of the role | `[grounded]` posting; no claim from you | Held question (see Questions) |
| R4 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, Head of Growth at B2C companies. A length-of-experience requirement is graded on fit, not as a gate | `[grounded]` your intake | none |
| R5 | Thrive on ambiguity | must_have | unclear | none | discovery | Nothing in your description addresses working without defined metrics. The $8M to $40M scale-up is related, not a direct answer | `[inferred]` from the posting's wording | Held question (see Questions) |
| R6 | Growth in e-commerce enablement | important | adjacent | medium | transferability | B2C subscription background; the company's buyer is e-commerce businesses. Limit: no merchant-facing or B2B selling named | `[inferred]` from the company description against your background | Name the B2C-to-B2B difference yourself; claim nothing past it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Functions beyond paid and lifecycle (R3b, must_have) | discovery | Nothing on SEO/content, brand, PR, partnerships or sales ops | Five of the posting's seven functions | Content or SEO programmes you led; PR or partnership deals; a sales-ops process you set up | A CV or case study | `[grounded]` silence in your description |
| G2 | Working without defined metrics (R5, must_have) | discovery | No example in your description | The posting says the metrics will change | A target or plan you wrote where none existed | A plan or dashboard you built | `[grounded]` silence in your description |
| G3 | B2C to e-commerce enablement (R6, important) | transferability | B2C subscription growth at two companies | The buyer and sales motion differ | Any merchant- or partner-facing growth work | A partner deck or merchant case | `[inferred]` from the company description |

The queue holds no questions. See Questions below.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site five days in Austin, against your remote-only constraint | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | Conflicts with a stated non-negotiable; see R1 | `[grounded]` posting; your intake | Is the Austin on-site requirement open to remote work from Portland for this role? If not, why? | confirmed |
| RR2 | Base ceiling below your floor; equity unquantified | red_flag | high | "Compensation: $70–85k base plus meaningful equity upside." | The top of the base is $65k under your floor; equity cannot close a base gap on the evidence given; see R2 | `[grounded]` posting figure against your floor | Is the base range final, and what is the equity grant in shares or percentage? | confirmed |
| RR3 | Seven functions in one role, team of one | risk_signal | medium | "Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one to start." | Accountable for seven functions with no team to start; authority and budget may not match scope | `[inferred]` from the posting's own list against "team of one" | Which of these functions have budget and headcount committed in year one, and which come later? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Work hours beyond the stated role may be the norm | `[inferred]` from the posting's wording | How often has this function needed evening or weekend work in a typical quarter, and how is that time offset? | unresolved |
| RR5 | Accountability without defined success | risk_signal | medium | "Must thrive on ambiguity; success metrics will evolve as we learn." | Responsibility for all revenue growth with no stated measure of success | `[inferred]` from the posting's silence on a target | What revenue target is this role measured against in its first twelve months? | unresolved |
| RR6 | Series A and profitability claims unchecked | unknown | — | "Series A, profitable since day one" | Not checked; the search that would have checked it was refused | `[grounded]` posting claim; unverified | What is the current revenue and profitability, and when did the Series A close? | unresolved |
| RR7 | Employer not established | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | Employer not established from attributable sources. Here that means unchecked, not searched and missing. Possible reasons, none ranked: too new or small, a stale posting, or not a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR8 | Clear reporting line | positive_signal | — | "Report to the CEO with a dotted line to the board." | Authority structure is stated plainly | `[grounded]` posting | Who would I work with day to day, and how often do I meet the board? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Don't tailor a resume to this posting yet | R1 and R2 fail as posted | `[grounded]` R1, R2 | pending your approval |
| E2 | If you still want to talk to them, put RR1 and RR2's questions to the employer in writing, verbatim | Only a written change from the employer moves either gate | `[grounded]` RR1, RR2 | pending your approval |
| E3 | Before any application effort, confirm Novaline and this posting on the company's own careers page | RR7 | `[generic]` pattern for companies of this size, not a claim about this one | pending your approval |

## Evidence status

Verified: R1 and R2 claims, which are your own stated constraints. R3a, R4 and R6 are your intake description, which is self-report and not yet verified. R3b and R5 have no claim.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Novaline e-commerce enablement startup Austin Series A" and "Novaline careers Head of Growth" were refused before they ran, so no result came back. Would have checked that Novaline exists as described and that the posting is live on its own site. Moves RR6 and RR7. Not retried |
| 2. Role-family sweep | unavailable | Search "Head of Growth base salary range Series A startup 2026 US remote" was refused. Would have set a market band for the calibration line and the pay check. Not retried |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Search access → rows 1 and 2 above. Would check whether Novaline exists as described and set a market band for the role. Can clear RR6 and RR7. Cannot change R1 or R2, since those come from the posting's own terms and your constraints.
- Your CV or resume → lifts R3a and R4 from self-report toward an inspectable artifact, and tests R3b, R5 and R6 against your real work.
- The live posting link → confirms the text against the company's own careers page (RR7).
- The recruiter's written answer on the on-site term and the base range → moves R1 and R2 only if the answer changes the terms. Closes RR1 and RR2.

Do you want this saved as `tuesday-dossier.md`, so the gate facts and the register's questions travel with you?

**Questions:** none this turn. The two gates decide the status, and your answers to R3b and R5 can't change it. Ask them only if you decide to pursue the role despite the gates.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.