**Yes, apply, on conditions: `conditional_go`.** R2, R3, R4, R6b and R7 are direct on what you've described. The real objection is the pet-insurance product (R5, R10), and the employer is unverified because the web searches were refused.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2 (4+ years pricing or actuarial analytics), R3 (SQL and Python), R4 (GLM experience), R6b (read price-test results), R7 (present to underwriting or actuarial leads) · adjacent: R5 (build and monitor rating models) · unclear: R6a (design price tests)
- `important`: direct: R8a (recommendations for underwriting) · adjacent: R10 (pet-insurance product) · unclear: R8b (recommendations for product)
- `preferred`: direct: R9 (insurance experience)

R2, R3, R4, R6b and R7 are all `medium` until probed; R5 and R10 are the pet-product gap, where motor transfers with limits named; R6a is whether you designed the price tests, the probe to expect first.

**Opportunity ledger.** RR1 is an employer not yet verified, since research could not run; RR2 and RR3 are pay and decision rights left unstated; RR4 is pet-product maturity unknown; RR5 is concrete scope, a positive signal.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed: you are UK-based with the right to work; (2) RR1 verified on Brindlemoor's own careers site; (3) R6a: you can show you designed at least one of the 14 price tests. If R1 turns out to fail, the status becomes `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor (insurtech); existence and stage not verified | `[grounded]` posting header; entity not checked, research unavailable |
| Mandate | Own pricing analytics for the pet-insurance product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing; public footprint not researched | `[grounded]` your message |
| Stated pay | None in the posting | `[grounded]` JD: silent |
| Market calibration | Not run: no pay or scope band | — |
| Scope read | Owns analytics and recommends; whether it owns rating-factor decisions or has direct reports is unstated | `[inferred]` from "own analytics" and "recommendations" |
| Unknowns | Reporting line, team size, contract type, pay, pet book size and maturity | — |
| Contradictions | None visible; only one source (the JD) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based (gate) | hard_gate | unclear | low | hard_gate | UK employer and a UK insurer background imply UK work, but residence and right to work are not stated | `[grounded]` JD; `[inferred]` from your UK background | Q1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, last two senior; self-report, no artifact | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated; no artifact yet | `[grounded]` your statement | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM; motor book | `[grounded]` your statement | none |
| R5 | Build and monitor rating models (for the pet product) | must_have | adjacent | medium | transferability | Motor rating-model work carries over; no pet model built. Limit: pet rating is not exercised | `[inferred]` from R4 against the JD's product | G2 |
| R6a | Design price tests | must_have | unclear | low | discovery | "Ran 14 price tests" does not say you designed them | `[grounded]` your statement; design ownership unknown | Q2 below |
| R6b | Read price-test results | must_have | direct | medium | none | Ran 14 tests with underwriting and read them | `[grounded]` your statement | none |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R8a | Recommendations for underwriting | important | direct | medium | none | Quarterly review carries recommendations to underwriting | `[grounded]` your statement | none |
| R8b | Recommendations for product | important | unclear | low | discovery | No product-side recommendations in your account | `[grounded]` silence | G4 |
| R9 | Insurance experience (preferred) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your statement | none |
| R10 | Pet-insurance product context (implied by "our pet-insurance product") | important | adjacent | medium | transferability | Motor and pet both rate on GLM-type models; claim patterns differ, and none of your work touched pet | `[inferred]` from the JD's product; `[generic]` that pet and motor claim patterns differ | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Design price tests (R6a, must_have) | discovery | "Ran 14 tests" and "read" them; design role not stated | Design ownership is the probe most likely in an interview for this JD | Choosing which factors or segments to test; sizing a test; writing a hypothesis or test plan; a read-out you wrote | A test plan, sizing sheet, or read-out deck | `[grounded]` your statement |
| G2 | Pet-product rating (R5, R10) | transferability | Motor GLM and price-test work; no pet work | This is the objection most likely to be raised; a bridge narrows it | Any non-motor pricing, benchmarking, or claims-data review, even a side analysis | A benchmark note, a review, an excerpt from a non-motor analysis | `[inferred]` bridge from the motor work; `[generic]` that pet claims differ |
| G3 | Right to work and residence (R1, hard_gate) | hard_gate | Not stated | A failed gate caps the status at `no_go` | Confirmation of UK residence and right to work | Your own statement | `[grounded]` JD: fully remote UK |
| G4 | Product recommendations (R8b, important) | discovery | Pricing recommendations go to underwriting; product is not in your account | Half of the JD's recommendations sentence | Product changes you proposed from price-test results | A product proposal or launch note | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. Research could not run, so this is unverified, not disproved | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I interview with? | unresolved |
| RR2 | Pay withheld | unknown | — | (no salary in the JD) | The band may sit below your expectations, or the posting may simply omit pay | `[inferred]` from silence on pay; no band calibrated | What is the base salary range for this role? | unresolved |
| RR3 | Decision rights and reports unstated | unknown | — | "Own pricing analytics" | The role may recommend rating changes rather than own them, and may or may not have direct reports (you have never managed anyone) | `[inferred]` from "own analytics" against "recommendations" | Does this role own rating-factor decisions, or recommend them, and does it have direct reports? | unresolved |
| RR4 | Pet-product maturity unknown | unknown | — | "our pet-insurance product" | A young product may have a thin claims history to rate on | `[generic]` new products often have short histories; not a claim about this product | How much claims history does the pet book have, and how far is the rating model built? | unresolved |
| RR5 | Concrete scope | positive_signal | — | "build and monitor rating models, design and read price tests" | The role's remit is specific and measurable | `[grounded]` JD | How do you judge a rating model's performance once it is live? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Write one line per price test, marking which you designed and which you only ran and read | G1, R6a | `[grounded]` your statement | pending your approval |
| P2 | Lead the CV with the quarterly review to underwriting and the price tests, as confirmed; do not frame motor work as pet experience | R2–R4, R6b, R7 | `[grounded]` rows | pending your approval |
| P3 | Before the interview loop, check the careers page and ask the recruiter for the pay range and reporting line | RR1, RR2, RR3 | `[generic]` pattern for screening | pending your approval |
| P4 | A one-page note mapping motor GLM work to pet rating questions, as your reasoning, not a claim of experience | G2, R5, R10 | `[inferred]` from R5, R10 | pending your approval |

Every row is proposed; none is applied.

## Evidence status

Verified: none yet. Your intake is self-report, which is the `medium` ceiling; nothing has been confirmed by a probe.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | All calls refused by the permission gate, so nothing was read. Would have verified the entity, its stage, and whether the posting is live: RR1 and the organization row |
| 2. Role-family sweep | unavailable | Refused. Would have set the pay band and the scope norm: RR2 and the market calibration line |
| 3. Hiring manager's public footprint | unavailable | Refused. A name was given (Odile Varga), so the query was formable. Would have fed the scope read and positioning |

## Upgrade menu

- Granting search permission, so the L1 targets can run: about one search and two page fetches remain within the L1 cap. Would verify RR1, set the pay band for RR2, and read Odile Varga's public background. A deeper L2 pass (up to 5 more searches and 2 more fetches) is available once, on request.
- A one-line account per price test that separates designed from run → R6a to `medium` or higher, and G1 closes.
- Any non-motor pricing or benchmarking work, even a side analysis → R10 and G2 narrow.
- The base salary range → RR2 closes, and the pay can be set against a band.

I can write this up as `tuesday-dossier.md` if you want to keep it.

**Questions:**

- **Q1 (R1):** Are you based in the UK with the right to work there, with no sponsorship needed?
- **Q2 (G1, R6a):** Of your 14 price tests last year, how many did you design yourself (hypothesis, test cells, sizing), and how many did you only run and read?
- **Q3 (G2, R10):** Have you done any non-motor pricing, benchmarking, or claims-data work, even a review or side analysis?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.