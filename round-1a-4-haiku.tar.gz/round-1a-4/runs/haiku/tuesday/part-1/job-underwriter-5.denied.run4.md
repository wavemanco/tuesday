**Probably worth applying, once R1 and R2 are answered. Status: `hold_pending_answers`.** The stack matches the posting's core. Two gate rows are unconfirmed, and I couldn't verify the employer.

**Fit ledger**
- `hard_gate`: unclear: R1 (Remote US or Denver location), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3 (data quality testing), R4 (5+ years data engineering), R5 (strong SQL and Python), R6 (dbt and a cloud warehouse), R7 (Airflow orchestration)
- `important`: adjacent: R8 (dbt-modelled warehouse in BigQuery); unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R3, R4, R5, R6 and R7 are each `medium`, stated but without artifacts yet. R8 is a credible bridge from Snowflake, with its limit named. R9 and R10 have nothing in what you've shared.

- **Hard gates:** none failed (R1 `unclear`, R2 `unclear`); unconfirmed: R1 (Remote US or Denver location), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** Sound, with checks open. Pay is stated and sits near the cohort median (RR4). Equity and hiring manager are unnamed (RR1, RR2). The employer check (RR3) did not run.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 states; founded 2016; 264 employees; Series C $52M, Feb 2026 | `[grounded]` your pasted About text; not checked, search refused |
| Mandate | Pipelines for tutoring reporting: app and CRM ingestion, dbt warehouse on BigQuery, data contracts | `[grounded]` JD |
| Scope | One domain's reporting pipelines; no direct reports stated | `[inferred]` from JD responsibilities |
| Market calibration | Senior DE at Series B–D: base median $151,000, IQR $139,000–$163,500; typical 5–8 years. The posted $148,000–$166,000 sits around the median, inside the IQR, with its top above the upper quartile | `[grounded]` report figures; `[generic]` cohort calibration |
| Unknowns | Equity amount, hiring manager, contract type, location eligibility, whether BigQuery is live or being migrated | — |
| Contradictions | None between the JD and the About text | `[grounded]` both pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver location | hard_gate | unclear | none | hard_gate | Your location isn't in what you've shared | `[grounded]` JD | Q1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Pay is a gate term; your floor isn't given | `[grounded]` JD | Q2 |
| R3 | Data quality testing | must_have | direct | medium | none | Great Expectations suite set up; prose only, expect a probe | `[grounded]` intake | none |
| R4 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; a length requirement, so graded on fit, not as a gate | `[grounded]` intake | none |
| R5 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both | `[grounded]` intake | none |
| R6 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt on Snowflake, about 180 models | `[grounded]` intake | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration | `[grounded]` intake | none |
| R8 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Snowflake dbt carries over; BigQuery itself never used | `[grounded]` Snowflake; `[inferred]` dbt transfers; `[generic]` BigQuery's cost and partitioning differ | G1 |
| R9 | Ingestion from app and CRM | important | unclear | none | discovery | Silent in intake | `[grounded]` JD | Q3 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Silent in intake | `[grounded]` JD | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | Snowflake and dbt experience, no BigQuery work | A BigQuery dbt project, or a migration you touched. The limit stays: BigQuery's own tooling and cost model | `[inferred]` transfer; `[generic]` BigQuery differences |
| G2 | Ingestion and contracts (R9, R10) | discovery | Nothing in intake | Named systems you built or owned, and any contract analysts relied on | `[grounded]` intake silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity unquantified | unknown | — | "plus equity" | Equity may be a small or nominal share of pay | `[inferred]` from the posting's silence | What equity is granted at this level, on what vesting schedule, at what strike price? | unresolved |
| RR2 | No hiring manager named | unknown | — | (no name in posting) | Reporting line is unknown | `[inferred]` from the posting's silence | Who would I report to, and who runs the data team day to day? | unresolved |
| RR3 | Employer and posting not verified | risk_signal | medium | "runs live online tutoring for K-12 schools in 31 US states" | The employer may be too new or small for a footprint, the posting stale, or it may not be a real hiring employer. The check was refused, so this is unchecked, not a finding | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR4 | Pay stated, near cohort median | positive_signal | — | "$148,000–$166,000" | Posted band sits around the Series B–D median and inside its IQR | `[grounded]` posted figure; `[generic]` cohort band | Is the band open, and where does this level land in it? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Answer Q1 and Q2 | R1, R2 gates | `[grounded]` gate rows | awaiting you |
| A2 | Ask the recruiter for equity terms and the hiring manager | RR1, RR2 | `[grounded]` register | your call |
| A3 | Confirm the posting is on Pellucid's own careers page before investing | RR3 | `[generic]` pattern | your call |
| A4 | Proposed positioning: "Built our dbt project on Snowflake (about 180 models), with Airflow orchestration and a Great Expectations test suite." Each clause traces to your intake sentences | R3, R6, R7 | `[grounded]` intake | pending your approval |
| A5 | State plainly that you haven't used BigQuery, then close it with a small BigQuery dbt project before the loop | R8 | `[inferred]` closure path | your call |

If you go ahead, mock-interview can drill the BigQuery and contracts questions.

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches on the employer and its Series C were refused, so nothing came back. Would have checked that the entity exists as described, that the posting is live, and the funding and size figures. RR3 stays open |
| 2. Role-family sweep | skipped | The pay report you pasted already fixes the cohort band; no search would change it |
| 3. Hiring manager's public footprint | n/a | No name was given |

Dossier offer: I can write this up as a `tuesday-dossier.md` you can keep and append to as answers come in.

**Upgrade menu**
- Your location and pay floor → R1 and R2 leave `unclear`; the status moves to `go`, `conditional_go` or `no_go`.
- Any BigQuery work → R8 moves toward `direct`.
- A public artifact (a dbt repo, a Great Expectations suite, or a redacted DAG) → R3, R6 and R7 move from `medium` to `high`.
- Web search permission → the employer check (RR3) can run. It was refused this session.

**Questions**
- **Q1 (R1):** Where are you based, and can you work remotely from there for a US-remote role?
- **Q2 (R2):** What base-pay floor do you need, and does $148,000–$166,000 plus equity clear it?
- **Q3 (R9, R10):** Have you built ingestion from an application database or CRM, or put data contracts in front of analysts? Name the system and what you owned.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.