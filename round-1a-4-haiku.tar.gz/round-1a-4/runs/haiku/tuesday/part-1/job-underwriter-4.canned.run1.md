**Yes, go for it, with one condition: the location. Status: `conditional_go`.** Your must-haves are all covered by direct evidence. The posting contradicts itself on where the job is based, and that has to be settled before you invest in the application.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5
- `important` — direct: R6 · adjacent: R7 (Monitoring rating models), R8 (Pet-insurance product)
- `preferred` — direct: R9

R7 and R8 are the two real gaps. Your motor GLM and monitoring work carries over to pet, but pet books aren't something you've worked on.

**Opportunity ledger.** The posting states its outcomes and reporting line clearly (RR4), and the careers page shows it live. Two things are open: the remote-versus-Leeds contradiction (RR1) and the unstated salary (RR2). Whether the role line-manages anyone is also unstated (RR3), and you have never managed people.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 resolves to fully remote, or to a Leeds pattern you can work with (R1); (2) the recruiter confirms the scope of line management (RR3); (3) you frame pet as adjacent, never as experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech, pet-insurance product | `[grounded]` JD; careers page fetched |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations | `[grounded]` JD |
| Reporting line | Director of Pricing (Odile Varga) | `[grounded]` JD and careers page |
| Working pattern | Contradicted: JD says fully remote (UK); careers page says Leeds office four days a week | `[grounded]` both sources |
| Scope read | A normal senior IC scope for the title; no stated people management | `[inferred]` from the responsibility list |
| Market calibration | Senior pricing analyst, UK insurers and insurtechs: median base £58,400, IQR £52,100–£64,900. Not pet-specific. The JD states no salary, so this is what to expect, not this employer's offer | `[generic]` Pricewell 2026 survey (n=612) |
| Unknowns | Location; salary; line management; how the pet book's monitoring is owned today | — |
| Contradictions | Remote (JD) versus Leeds four days a week (careers page) | `[grounded]` both sources |

The hiring manager's public footprint (search snippets, not fetched): Odile Varga is Director of Pricing at Brindlemoor and previously led pricing analytics at Calloway Re for six years. A 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", covered monitoring rating models in small books. `[grounded]` profile snippet and talk title.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | none | hard_gate | JD says fully remote; careers page says Leeds four days a week. Your own location constraint wasn't given, so nothing settles it | `[grounded]` both sources | RR1: recruiter confirms in writing; Q1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in UK motor pricing analytics, last two as senior analyst. Intake prose, no artifact yet | `[grounded]` your intake message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both. No artifact yet | `[grounded]` your intake message | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM rating model | `[grounded]` your intake message | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Present the quarterly pricing review to the head of underwriting | `[grounded]` your intake message | none |
| R6 | Designing and reading price tests | important | direct | medium | none | Ran 14 price tests last year with underwriting | `[grounded]` your intake message | none |
| R7 | Monitoring rating models (JD: "build and monitor") | important | adjacent | medium | transferability | You maintained the GLM, so monitoring is likely but unstated. Adjacent until you say what monitoring you did | `[inferred]` from "built and maintained" | Q2 below |
| R8 | Pet-insurance product knowledge (inferred from the JD's product scope) | important | adjacent | medium | transferability | Motor pricing transfers. Pet claims drivers and product design don't. You've never worked on pet | `[inferred]` from the JD scope; `[generic]` that pet books differ from motor in claim drivers | Q3 below |
| R9 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your intake message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location (R1, hard_gate) | hard_gate | Posting contradicts itself; your location constraint isn't on file | Decides whether the role is open to you at all | Not a workaround hunt: whether fully remote UK works | A written recruiter answer | `[grounded]` RR1 |
| G2 | Monitoring rating models (R7, important) | transferability | Maintained the GLM; no monitoring detail | The JD names monitoring as a core duty, and Odile's talk covers it | Drift or A/E checks on the young-driver model; threshold alerts; re-fits | A monitoring pack, a drift report, a dashboard screenshot | `[inferred]` adjacency; `[generic]` monitoring is a core duty for pricing roles |
| G3 | Pet-insurance knowledge (R8, important) | transferability | Motor only | Pet is the product you'd own | Any non-motor book (home, travel, health), claims-cost modelling, vet-cost or lifetime-value work | A non-motor analysis, even small | `[generic]` pet books differ from motor in claim drivers |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Remote contradicts a Leeds office requirement | risk_signal | medium | "Fully remote (UK)" vs "Leeds office four days a week" | The posting may be out of date, or the office pattern may be the real one | `[inferred]` from the two sources | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | (no figure in the JD) | The figure may sit near the band, or pay may not be published | `[generic]` band from Pricewell 2026; `[inferred]` from the missing figure | What is the base salary range for this role? | unresolved |
| RR3 | Line management unstated | unknown | — | (no mention in the JD) | The role may carry reports, which would be a gap for you | `[inferred]` from the JD's silence on people | Does this role line-manage analysts, and if so, how many? | unresolved |
| RR4 | Outcomes and reporting line explicit | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | Scope is defined and the reporting line is clear | `[grounded]` JD and careers page | Which of the monitoring tasks does this role own outright? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter to confirm the location in writing before you apply | see R1, RR1 | `[grounded]` RR1 | proposed |
| A2 | Describe the young-driver GLM as built and maintained; add monitoring detail only if you did it | see R7 | `[grounded]` your intake message | proposed |
| A3 | Prepare how you'd monitor a rating model on a small pet book, drawing on the Forum talk's theme | Odile's public focus | `[grounded]` talk title | proposed |
| A4 | Don't claim pet experience; frame motor as transferable, with its limits named | see R8 | `[generic]` role-family pattern | proposed |

## Evidence status

Verified: none yet. Your claims are prose-level and sit at `medium` until an artifact or a specific probe confirms them.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results) and "Brindlemoor Senior Pricing Analyst pet insurance job"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved the contradictions row and RR1 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary GLM", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example). Moved the market calibration line and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned a profile (linkedin.example/in/odile-varga) and the Forum talk listing. Moved A3 (snippets only, not fetched) |

## Upgrade menu

- The recruiter's written answer on location → R1 closes; the decision moves to `go` or `no_go`.
- A monitoring pack, drift report or dashboard screenshot → R7 to `direct`, at `high` if inspectable.
- A non-motor analysis, even small → R8 moves from adjacent toward direct.
- The budgeted salary → RR2 closes, and the figure is set against the band above.
- The line-management answer → RR3 closes.
- A deeper research pass on Brindlemoor (funding, leadership, public candidate reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you want, I can write this up as `tuesday-dossier.md` to carry into the next steps.

Answer each question in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Q1 (G1):** Is fully remote UK workable for you, or would four days a week in Leeds rule the role out?

**Q2 (G2):** After you built the young-driver GLM, what monitoring did you run on it, how often, and did any check ever trigger a change?

**Q3 (G3):** Have you modelled any non-motor book, such as home, travel or health, even briefly?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.