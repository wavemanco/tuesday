**Yes, it's worth applying, as `conditional_go`.** Your requirement fit is strong, and the posted pay sits inside the market band. The open items are your own location and pay floor, which I don't have, plus BigQuery and the team you'd be joining.

**Research tier: L1 — searches 2 of 5, fetches 1 of 2**

**Decision snapshot**

**Status: `conditional_go`.** Apply once the gates below are confirmed against your constraints.

**Fit ledger**

- `hard_gate` — unclear: R9, R10
- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — adjacent: R6, R7 · unclear: R8

R6 — Snowflake work transfers, BigQuery is untested for you; R7 — quality tests and dbt models are adjacent, contracts not claimed; R8 — no ingestion work in the background.

**Opportunity ledger.** Positive: RR4 (posting is live and matches the JD) and RR5 (posted pay sits inside the pay report's interquartile range). Unknowns: RR1 (team and manager unnamed), RR2 (equity unstated), RR3 (company figures self-reported).

- **Hard gates:** none failed; unconfirmed: R9 (Salary $148,000–$166,000 plus equity), R10 (Remote US or Denver office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) R9 and R10 hold for you (see Q1); (2) RR1 holds up in interviews; (3) BigQuery is framed as transferable, with the limit named (R6, G1).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 US states | `[grounded]` company About page |
| Mandate | Build and run ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and analyst data contracts | `[grounded]` posting |
| Working pattern | Remote (US) or Denver office | `[grounded]` posting |
| Scope read | One domain (tutoring-platform reporting) with no direct reports named; normal for the title | `[inferred]` from the posting's scope list against its silence on team |
| Market calibration | Pay report band for Senior Data Engineer at Series B–D: median $151,000, IQR $139,000–$163,500; posted midpoint $157,000 sits inside the IQR | `[generic]` Datawright 2026 report from your recruiter; `[grounded]` posted range |
| Unknowns | Team size, manager, equity terms, your location and pay floor | — |
| Contradictions | None between the posting and the careers page | `[grounded]` careers page fetched |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; stated, not yet probed. A length requirement, not a gate | `[grounded]` your intake | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both, stated | `[grounded]` your intake | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake, a cloud warehouse | `[grounded]` your intake | none |
| R4 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, stated | `[grounded]` your intake | none |
| R5 | Data quality testing | must_have | direct | medium | none | Great Expectations suite set up, stated, not inspected | `[grounded]` your intake | offer: inspectable suite (upgrade menu) |
| R6 | A dbt-modelled warehouse in BigQuery (responsibilities, not the requirements list) | important | adjacent | medium | transferability | Snowflake and dbt carry over. BigQuery SQL dialect and cost model are untested for you | `[grounded]` no BigQuery use stated; `[generic]` that BigQuery's dialect and cost model differ from Snowflake's | G1, Q2 |
| R7 | Data contracts analysts depend on | important | adjacent | low | transferability | Quality tests and dbt models are the nearest work; contracts with consumers not claimed | `[inferred]` from R3 and R5 | G3 |
| R8 | Ingestion from the app and CRM | important | unclear | low | discovery | Background silent on ingestion sources | `[grounded]` silence in your intake | G2 |
| R9 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor given, so the check is not yet possible | `[grounded]` posting | Q1 |
| R10 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location not given | `[grounded]` posting | Q1 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6) | transferability | Snowflake-based dbt work; no BigQuery use stated | The posting names BigQuery as the warehouse, so the objection is likely to come up | Any BigQuery project, sandbox or course; any cloud warehouse migration you ran | A sandbox project, a course certificate, or a short note on any migration | `[grounded]` intake; `[generic]` dialect and cost differences |
| G2 | Ingestion (R8) | discovery | Background silent on source ingestion | Ingestion from app and CRM is half the stated mandate | Pipelines pulling from a product database, a CRM API, or a vendor connector | Tool names, a pipeline diagram | `[grounded]` silence |
| G3 | Data contracts (R7) | transferability | Quality tests exist; no consumer contracts stated | The analysts depend on these, so the bridge needs stating | Schema or freshness agreements with consumers; test ownership | A sample contract or test spec | `[inferred]` from R3 and R5 |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team and manager unnamed | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the whole data function, with no team and no named manager | `[inferred]` from the scope list against the silence on team | Who else is on the data team, and who would I report to? | unresolved |
| RR2 | Equity unstated | unknown | — | "Salary $148,000–$166,000 plus equity" | Total pay can't be judged without the equity terms | `[grounded]` posting is silent on equity | What are the grant size, vesting schedule and strike price for this level? | unresolved |
| RR3 | Company figures self-reported | unknown | — | "264 employees. Series C ($52M, February 2026)." | Only the company's own About page came back in search, so these figures are not independently checked | `[inferred]` from search results | Which investors led the Series C, and can you point me to the announcement? | unresolved |
| RR4 | Posting live and consistent | positive_signal | — | "Accepting applications." | The live posting matches the JD | `[grounded]` careers page fetched | Who reviews applications, and what is the timeline? | noted |
| RR5 | Posted pay inside market band | positive_signal | — | "$148,000–$166,000" | Midpoint $157,000 falls within the report's IQR | `[generic]` pay report band; `[grounded]` posted range | Is this range the budgeted figure for the level, or does it move with experience? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with R1–R5 and name the Snowflake stack: "Built and ran a dbt project of about 180 models on Snowflake" | Your own sentence, unchanged | `[grounded]` your intake | pending your approval |
| E2 | State plainly that you have not used BigQuery, and name what carries over: dbt, SQL, testing | R6 is a transferability gap; naming the limit is the honest bridge | `[grounded]` R6 | pending your approval |
| E3 | Ask RR1 and RR2 in the first screen. mock-interview can drill them before the screen | Both are unknowns the decision depends on | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet. Your intake is self-report until probed.

Research tier: L1 — searches 2 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched pellucidlearning.com/careers/senior-data-engineer ("Senior Data Engineer — Pellucid Learning careers"): posting is live and matches the pasted text. Searched "Pellucid Learning live online tutoring K-12 Denver" (no results) and "\"Pellucid Learning\" company" (returned pellucidlearning.com/about). Moved role reality's contradictions row (none) and RR3 |
| 2. Role-family sweep | skipped | Your recruiter's pay report is in hand and fixes the band, so no search was sent. Feeds the market calibration line |
| 3. Hiring manager's public footprint | n/a | No name given |

**Dossier offer:** I can write this up as `tuesday-dossier.md` so you can keep it and append to it.

**Upgrade menu**

- Any BigQuery exposure (sandbox, course, GCP project) → R6 moves up from adjacent.
- An inspectable artifact: your Great Expectations suite or a sanitized dbt excerpt → R5 and R3 to `high`.
- Your location and pay floor → R9 and R10 close.
- The team and manager → RR1 closes.
- A deeper company pass (L2): funding and leadership churn, past hiring, employee reports. Up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions**

Q1 (R9, R10): Are you in the US, and would Denver or fully remote work for you? Is $148,000–$166,000 plus equity above your floor?

Q2 (G1): Have you done any BigQuery work at all, such as a sandbox project, a course, or a read-only look at someone's project? What did you touch?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.