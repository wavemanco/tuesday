**Yes, probably, but hold off applying until you know whether the Leeds requirement applies to you.** `hold_pending_answers`

The posting contradicts itself on location. Your fit is strong on the must-haves, and pet insurance is the main gap.

**Fit ledger.**
- `hard_gate`: unclear: R1 (Location: fully remote UK, or Leeds four days a week)
- `must_have`: direct: R2, R3, R4, R5, R9
- `important`: direct: R8, R10a; adjacent: R7 (Pet-insurance product pricing); unclear: R10b (Recommendations for product)
- `preferred`: direct: R6 (Insurance experience)

R7, a credible bridge with its limit named; R1, the gate the posting contradicts itself on.

**Opportunity ledger.** Scope is defined and the role reports to the Director of Pricing (RR5, positive). Two entries are open: the location contradiction (RR1) and the thin public footprint for the employer (RR2). Pay isn't in the posting text you shared (RR3), and decision rights are unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Location: fully remote UK, or Leeds four days a week); candidate constraints not given. Checks against your pay floor, location and contract needs are unknown.
- **Severe red flags:** none found.
- **What would change this:** the status moves on three answers. (1) Is Leeds four days a week required (R1, RR1)? (2) What are your non-negotiables: location, pay floor, contract type? (3) Which pricing decisions does the role make alone (RR4)? If the role is genuinely remote, or you can work from Leeds, it becomes `conditional_go`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech, pet-insurance product | `[grounded]` JD; careers page |
| Reporting line | Reports to the Director of Pricing | `[grounded]` careers page |
| Working pattern | JD says fully remote (UK); careers page says Leeds office four days a week | `[grounded]` both; **contradiction, unresolved** |
| Scope read | One product, analytics owned end to end, recommendations rather than stated decisions | `[inferred]` from the JD wording |
| Market calibration | Pricewell 2026 UK survey (n=612): senior pricing analyst median £58,400, interquartile range £52,100–£64,900. The posting withholds pay, so this is what to expect, not this employer's offer | `[generic]` role-family sweep, this month |
| Hiring manager | Odile Varga, Director of Pricing. Spoke at the 2025 Insurance Pricing Forum on monitoring rating models in small books. Previously head of pricing analytics at Calloway Re | `[grounded]` public profile and talk listing |
| Unknowns | Pay, contract type, decision rights, product-side role | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: fully remote UK (JD) vs Leeds four days a week (careers page) | hard_gate | unclear | none | hard_gate | Posting contradicts itself; your location not given | `[grounded]` both sources | RR1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two senior; confirmed, no artifact yet | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use; confirmed, no artifact | `[grounded]` your statement | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM (motor) | `[grounded]` your statement | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly review to the head of underwriting | `[grounded]` your statement | none |
| R6 | Insurance experience | preferred | direct | medium | none | UK motor insurance | `[grounded]` your statement | none |
| R7 | Pet-insurance product pricing (implied by "our pet-insurance product") | important | adjacent | medium | transferability | GLM and price-test method carry over; no pet book priced; pet drivers (species, breed, vet-cost inflation) not exercised | `[inferred]` adjacency from motor GLM work | G1 |
| R8 | Designing and reading price tests | important | direct | medium | none | 14 tests last year with underwriting | `[grounded]` your statement | none |
| R9 | Building and monitoring rating models | must_have | direct | medium | none | Built and maintained a GLM | `[grounded]` your statement | none |
| R10a | Recommendations for underwriting | important | direct | medium | none | Quarterly review feeds underwriting | `[grounded]` your statement | none |
| R10b | Recommendations for product | important | unclear | low | discovery | No product-side evidence given | — | G2 |

You have no people-management requirement in this posting, so none is mapped. Your lack of management experience is not a gap here.

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance pricing (R7, important) | transferability | Motor GLM and price-test work; no pet book | Probably the first objection | Non-motor pricing, claims or retention analysis; any pet or companion-animal data work | Pricing review deck, de-identified model documentation, test readout | `[inferred]` bridge; `[generic]` that this is the likeliest objection |
| G2 | Product recommendations (R10b, important) | discovery | Recommendations to underwriting only | The JD names product as a recipient | Product changes you shaped from a test result | A test readout or product memo | `[grounded]` JD wording |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location contradicts itself | risk_signal | medium | "Fully remote (UK)" (JD); "Leeds office four days a week" (careers page) | The role may be hybrid with Leeds attendance, or the JD may be out of date | `[grounded]` both sources | Is this role fully remote within the UK, or does it require Leeds four days a week? | unresolved |
| RR2 | Employer footprint thin | risk_signal | medium | "Brindlemoor careers" (company domain only) | Brindlemoor may be too new or small to have press coverage, or the posting may be stale. Standing entry; caps the decision at `conditional_go` until verified | `[generic]` pattern for companies of this size, not a claim about this one | How long has the pet product been live, and how large is the book? | unresolved |
| RR3 | Pay withheld | unknown | — | No salary in the posting text provided | The budget may sit below the band, or pay may simply not be published | `[inferred]` from the posting's silence against the `[generic]` band | What salary is budgeted for this role? | unresolved |
| RR4 | Decision rights unstated | unknown | — | "turn the results into recommendations" | The role may recommend, with decisions sitting with underwriting or the Director | `[inferred]` from the wording against silence on decision rights | Which pricing decisions does this role make alone, and which go to underwriting or to you? | unresolved |
| RR5 | Defined scope and reporting line | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | The role is clearly scoped and the manager is identified | `[grounded]` careers page | Who owns the pet product's pricing targets today? | noted |

**Application plan** (all proposed; nothing is sent)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the location question before investing in the application | RR1, R1 | `[grounded]` | pending your approval |
| A2 | Lead with the GLM build-and-monitor record and your price-test results, not the talk's framing | The Director's talk is on monitoring rating models, which is your strongest overlap. Describe what you did, not what the talk argues | `[grounded]` the talk listing, `[generic]` the pattern | pending your approval |
| A3 | Frame pet insurance as an adjacent move: motor GLM and test methods transfer, and pet drivers are new to you. Name the limit | R7 | `[inferred]` | pending your approval |
| A4 | Put the RR1 to RR4 verification questions to the employer in the interview | The register doubles as interview preparation | `[grounded]` register | pending your approval |

**Evidence status**

Research tier: L1 — searches 5 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results), "Brindlemoor Senior Pricing Analyst pet insurance careers" (returned the careers page), and "Brindlemoor Ltd Leeds" (no results). Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved the location contradiction (RR1) and the reporting line |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary GLM", which returned the Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (pricewell.example/2026-uk-pricing-analytics-pay-survey). Set the market calibration `[generic]` and the RR3 band |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned the public profile (linkedin.example/in/odile-varga). Informed A2 |

Verified (your word, not yet inspected): R2, R3, R4, R5, R6, R8, R9, R10a. Unverified: R1, R7, R10b. Rejected inferences: none.

**Upgrade menu**
- Your location and non-negotiables (pay floor, contract type) → resolves R1 and the hard-gate line.
- The employer's answer on location and decision rights → closes RR1 and RR4.
- A budgeted salary → closes RR3 and sets it against the band.
- A de-identified motor pricing work sample (GLM documentation or a test readout) → lifts R4 and R8 from `medium` to `high`, and makes the bridge in G1 concrete.
- A deeper research pass on Brindlemoor (funding, leadership changes, reviews, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you want, I can save this as `tuesday-dossier.md` so the interview prep module can pick it up.

1. Would you be able to work from the Leeds office four days a week, or is fully remote UK the only arrangement you'd take? (RR1, R1)
2. What are your must-haves for this role (pay floor, location, contract type), so I can check the offer against them? (Structural inputs; checks unknown until answered)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.