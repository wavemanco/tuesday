Research tier: L1, searches 3 of 5, fetches 0 of 2; user links read 1.

## Decision snapshot

**Hold pending answers.** Your sales-ops and Salesforce background fits most of the posting. Two stated must-haves are the core of the role, though, and you have neither: owning a forecast and working with finance on billing data. Location and pay are also unknown for you.

- **Must-haves, met:** 4+ years in RevOps or sales ops at a B2B company (partial, see below), Salesforce admin, pipeline and renewal reporting.
- **Must-haves, partial or missing:** SQL and spreadsheet modelling (SQL and Excel are in daily use, but modelling isn't evidenced), forecast ownership (missing), finance work on billing or revenue data (missing).
- **Hard gates, unknown:** Bristol hybrid, two days a week in the office; the £61,500–£67,000 band against your floor; right to work (not stated).

Worth applying only if you can credibly show adjacent forecasting work and some finance-facing revenue work. If you can't, this is a no-go on the posting's own terms.

## Role reality

- **Posting:** Revenue Operations Lead, Quillfield (Bristol), hybrid, £61,500–£67,000 plus share options `[grounded]` from the posting.
- **Scope:** owns CRM and billing data; builds pipeline and renewal reporting for sales and finance; runs the quarterly revenue forecast with the CFO `[grounded]`.
- **Market calibration:** the posting's midpoint (£64,250) sits close to the UK RevOps lead median of £64,200 (interquartile range £57,800–£70,400) `[generic]`, from a single pay guide. No mismatch.
- **Organization:** Quillfield makes invoicing and payments software for UK builders' merchants, founded 2018, 96 employees, Series A (£11M) in April 2025 `[grounded]`, from a search snippet of its About page; I did not open the page.
- **Hiring manager:** Tamsin Achebe is listed as Head of Revenue Operations at Quillfield, previously a sales operations manager at a payments company for four years `[grounded]`, from a search snippet only. The role's reporting line and scope relative to that title are unconfirmed.

## Evidence map

| # | Priority | Requirement | Fit | Confidence | Note |
|---|---|---|---|---|---|
| 1 | Must | 4+ yrs RevOps / sales ops at B2B software co. | Partial | Medium | Five years, but at a payments company. Likely to count; confirm with the recruiter. `[inferred]` |
| 2 | Must | HubSpot or Salesforce admin | Meets | Medium | Salesforce admin certified; certificate not yet seen. |
| 3 | Must | Strong SQL and spreadsheet modelling | Partial | Medium | SQL weekly, Excel daily; modelling not evidenced. |
| 4 | Must | Experience owning a forecast | Gap | n/a | Finance owned it. Pipeline review with the sales director is adjacent, not ownership. |
| 5 | Must | Working with finance on billing or revenue data | Gap | n/a | No billing data work. |
| 6 | Scope | Pipeline and renewal reporting | Meets | Medium | Rebuilt both dashboards. |
| 7 | Gate | Bristol, hybrid 2 days/week | Unknown | n/a | Your location is not stated. |
| 8 | Gate | £61.5k–£67k vs your floor | Unknown | n/a | Floor not stated. |

## Gap recovery queue

- **Row 4, forecast ownership:** closes with evidence you shaped or presented a forecast or commit view, even inside finance's process (inputs, stage categories, forecast vs actuals reviews).
- **Row 5, billing data:** closes with any work reconciling bookings, renewals or invoices against revenue, even as a consumer of finance's data.
- **Row 3, modelling:** closes with a spreadsheet model you built (scenarios, cohort or renewal curves) that you can describe.

## Risk register

- **Failed attribution (standing, medium):** the employer is confirmed by search, but the posting is hosted on an aggregator (tallyboard.example). I did not find it on Quillfield's own careers page. Resolve with the careers-page link or the recruiter's email domain.
- **Pay (no mismatch):** see market calibration above.
- **Scope (medium):** the posting makes forecast ownership a must-have, though the role sits alongside a CFO. Ask what the forecast process looks like now.

## Application plan (as far as evidence allows)

- Lead with pipeline and renewal reporting, Salesforce, and the monthly pipeline review, which are verifiable.
- Don't claim forecast ownership or billing-data work. If either is real, we can build the wording together after you confirm it. Nothing goes out without your approval.
- Tamsin Achebe's public background (payments sales ops, then RevOps leadership) overlaps with yours, so your story may read as familiar to them. That's a positioning point, not evidence of fit.

## Evidence status

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | yes | Search result for Quillfield About page; posting not confirmed on Quillfield's own careers page. |
| 2. Role-family sweep | yes | Ledgerline 2026 UK RevOps pay guide. |
| 3. Hiring manager footprint | yes | Search result for Tamsin Achebe (LinkedIn listing). |
| 4. Deeper company diligence (L2) | n/a | Not run. |
| 5. Recent-news sweep (L2) | n/a | Not run. |

## Dossier offer

I can write this assessment to `tuesday-dossier.md` so it carries into mock-interview prep, if you want that later.

## Upgrade menu

- **Location and right to work:** confirms or closes two hard gates.
- **Salary floor:** confirms the pay gate against £61.5k–£67k.
- **A forecast or modelling work sample (anonymised):** would raise rows 3 and 4.
- **A billing or revenue reconciliation example:** would raise row 5.
- **The Salesforce certificate:** would raise row 2 to high.

## Questions

1. Where are you based, and can you do Bristol two days a week?
2. Have you ever worked on any part of a forecast, even as an input provider or a forecast-vs-actuals reviewer?
3. Has any of your work touched billing or invoicing data, or reconciled bookings or renewals against revenue?

Answer, skip, or say "not applicable" for each; a skip counts as an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.