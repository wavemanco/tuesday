**Yes, apply, with conditions. Status: `conditional_go`.** Your sales-ops and revenue-ops record covers most of the role. The two real stretches are owning the quarterly forecast and working with billing data, and neither has evidence on your side yet.

**Fit ledger.**

- `hard_gate`: unclear: R8 (Bristol, two office days a week), R9 (base £61,500–£67,000)
- `must_have`: direct: R2 (Salesforce or HubSpot administration), R3 (SQL and spreadsheet modelling); adjacent: R1 (4+ years at a B2B software company), R4 (owning a forecast); absent: R5 (working with finance on billing or revenue data)
- `important`: direct: R7 (pipeline and renewal reporting); adjacent: R6 (owning CRM and billing data)

R4 has a bridge in your monthly pipeline review, but the forecast itself was never yours. R5 has no bridge yet, since you have not worked on billing data.

**Opportunity ledger.** The employer is real and the pay is disclosed, which are both positives. The open questions are how forecast ownership is split with the CFO (RR1) and what "owning billing data" covers (RR2). The hiring manager's public title overlaps with this role's (RR3).

- **Hard gates:** none failed; unconfirmed: R8 (Bristol, two office days a week), R9 (base £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R8 and R9 match your own constraints (H1 below); (2) RR1 and RR2 resolve with the recruiter, so you know who owns the forecast number and what billing ownership means; (3) you never describe yourself as having owned a forecast.

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; Bristol; founded 2018; 96 employees; Series A £11M, April 2025 | `[grounded]` quillfield.co.uk/about |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol hybrid, two office days a week | `[grounded]` posting |
| Scope read | Three areas in one lead post (data ownership, reporting, forecast) is broad for a single role | `[inferred]` from the posting's responsibility list |
| Market calibration | UK revenue-ops leads at B2B software: median £64,200, IQR £57,800–£70,400 (n=438, 2026). The posted £61,500–£67,000 sits mid-band | `[generic]` Ledgerline 2026 pay guide; `[grounded]` posting for the figure |
| First-year outcomes | Not stated | — |
| Unknowns | Forecast sign-off; billing-data scope; reporting line to the hiring manager; whether the role is on Quillfield's own careers page | — |
| Contradictions | The posting is on a third-party job board. My search of the employer's site found no careers listing for it | `[grounded]` search results |

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years in RevOps, sales ops or analytics at a B2B software company | must_have | adjacent | medium | transferability | Years and function met. Your company was B2B payments, not software | `[grounded]` your intake; `[inferred]` on the company-type gap | G4 |
| R2 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified (self-reported) | `[grounded]` intake | none |
| R3 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily; modelling not described in detail | `[grounded]` intake | none |
| R4 | Experience owning a forecast | must_have | adjacent | medium | transferability | You ran the monthly pipeline review but never owned the company forecast; finance did | `[grounded]` intake | G1 |
| R5 | Working with finance on billing or revenue data | must_have | absent | medium | transferability | No billing work. Renewal and pipeline data is the nearest revenue data | `[grounded]` intake | G2 |
| R6 | Owning CRM and billing data | important | adjacent | medium | transferability | CRM is covered by Salesforce admin work. Billing data is not | `[inferred]` from R2 and R5 | G3 |
| R7 | Building pipeline and renewal reporting | important | direct | medium | none | You rebuilt both dashboards | `[grounded]` intake | none |
| R8 | Bristol hybrid, two office days a week | hard_gate | unclear | medium | hard_gate | Your location and willingness are not stated | `[grounded]` posting | H1 |
| R9 | Base £61,500–£67,000 | hard_gate | unclear | medium | hard_gate | Your pay floor is not stated | `[grounded]` posting | H1 |

**Gap recovery queue.**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R4, must_have) | transferability | Monthly pipeline review with the sales director; no forecast ownership | This is the main objection. The bridge is real but must be stated as a limit | Any input you gave finance into a forecast, even a pipeline extract | A pipeline review pack or a forecast-input sheet | `[inferred]` bridge from the pipeline review; `[generic]` that forecasting is the likeliest objection |
| G2 | Billing or revenue data with finance (R5, must_have) | transferability | No billing work; renewal and pipeline data only | A must-have at `absent` | Renewal reporting consumed by finance; any reconciliation with invoices | A renewal report or a finance-facing dashboard | `[grounded]` intake |
| G3 | Billing data ownership (R6, important) | transferability | CRM ownership is close; billing is not | Shapes what "owning billing data" means day to day | Data-quality work on CRM-to-billing fields, if any | A data dictionary or field map | `[inferred]` |
| G4 | Software company experience (R1, must_have) | transferability | B2B payments, not software | Adjacent, and the posting names software specifically | Subscription or usage-based revenue work | None needed; state the limit | `[grounded]` intake |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast sign-off unclear | risk_signal | medium | "run the quarterly revenue forecast with the CFO" | The role may own the model and inputs while the CFO owns the number, or the reverse | `[inferred]` from the posting's wording | "Which parts of the quarterly forecast does this role own, and what does the CFO sign off?" | unresolved |
| RR2 | Billing-data scope | unknown | — | "own our CRM and billing data" | Ownership may mean data quality and reporting, not the billing system | `[inferred]` from silence on billing-system ownership | "What does owning billing data cover: the data model, data quality, or reporting on it?" | unresolved |
| RR3 | Reporting line | unknown | — | Hiring manager's public title: Head of Revenue Operations `[grounded]` | The role may sit under or beside the hiring manager's function | `[inferred]` from the title overlap | "Does this role report to you, and what does RevOps own that this role does not?" | unresolved |
| RR4 | Pay disclosed | positive_signal | — | "£61,500–£67,000 plus share options" | The range is stated and sits mid-band | `[generic]` pay band; `[grounded]` posting | "How are share options sized and vested?" | noted |
| RR5 | Posting not found on employer's site | unknown | — | Job-board posting | The posting may be live only on the board, or may be stale | `[generic]` pattern for job-board postings, not a claim about this employer | "Is this role also live on Quillfield's careers page, and is it still open?" | unresolved |

The employer is established (RR5 does not raise the standing employer-not-established entry), so this is a question, not a hold.

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Describe the pipeline review and dashboards exactly as they happened; add no forecast-ownership language until G1 is answered | R4, R7 | `[grounded]` intake | resume_edits_pending_approval |
| E2 | Email the recruiter with RR1, RR2 and RR5 before investing in an application | RR1, RR2, RR5 | `[grounded]` register | pending your approval |
| A1 | For the Tamsin Achebe round, mock-interview can drill the forecast and billing questions | RR1–RR3 are interview questions | `[grounded]` register | pending your approval |

Her public profile shows a background in payments-company sales operations. That is common ground to check in conversation, not something to assume.

**Evidence status.** Verified: none yet. Your claims are intake-level (`medium`), and nothing has an inspectable artifact yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" (quillfield.co.uk/about: Bristol, founded 2018, 96 employees, Series A £11M April 2025) and "Quillfield Revenue Operations Lead careers" (no listing found). Moved the organization row and RR5 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software 2026" (Ledgerline 2026 UK Revenue Operations Pay Guide: median £64,200, IQR £57,800–£70,400, n=438). Moved market calibration and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" (public profile: Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments, four years). Moved RR3 |

**Hard gates, questions, and the rest:**

- **Dossier offer:** I can write this up as a `tuesday-dossier.md` to keep and add to as answers arrive.
- **Upgrade menu:**
  - Your location and pay floor → R8 and R9 close.
  - A pipeline or forecast-input artifact → R4 can move from `medium` toward `high`.
  - Any billing or invoice-adjacent work, even as a consumer of finance's data → R5 and R6 move.
  - The recruiter's answers on forecast sign-off and billing scope → RR1 and RR2 close.
  - Deeper research on Quillfield (leadership changes, funding, reviews): up to 5 more searches and 2 more fetches, once, if you want it.
- **Questions:**
  - H1: Do Bristol, two office days a week, and a base at or above £61,500 fit your constraints? If not, which one doesn't?
  - G1: Have you ever supplied inputs to a forecast that finance or a CFO signed off? If so, what did you own?
  - G2: Have you worked with billing or invoicing data at all, even as the person pulling reports from it for finance?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.