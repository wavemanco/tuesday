## Decision snapshot

**Not a waste of your time, but not a go yet. Status: `hold_pending_answers`.** As a first PM role this is a stretch. Your execution record matches much of the job; the titled PM years, roadmap ownership and adoption metrics don't yet.

**Fit ledger.**

- `hard_gate` — none stated
- `must_have` — direct: R4, R5, R9a, R10 · adjacent: R1a (3+ years product management experience, adjacent part), R3 (shipped API or platform products) · unclear: R2 (owns the roadmap), R6 (agile delivery), R7 (defines and tracks adoption metrics), R9b (stakeholder management with sales) · absent: R1b (titled product management years)
- `important` — adjacent: R8 (coordinates launches with sales and support)

R4, R5, R9a and R10 are the discovery, spec, stakeholder and schema work you can show. R1a and R3 are bridges with their limits named. R2, R6, R7 and R9b are open, not failed. R1b is the one row with nothing behind it.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** The posting is concrete (RR1, positive signal). The employer is unverified (RR2), because the search was refused this session, so that is unknown, not a finding. Pay and contract basis are not stated (RR3).
- **What would change this:** The awaited answers are G1 (did you decide roadmap priorities, or only collect input?) and G2 (did you define adoption measures, and does the support-tool note hold up?). A concrete roadmap decision of yours plus a measure you defined moves this toward `conditional_go`. If G1 comes back as input only, the gap on R2 and R1b is larger than this title usually allows, and a PM-titled role closer to your proven scope is the better first step.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics tech, about 150 people, Series B | `[grounded]` JD header; existence not verified (RR2) |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| First-year outcomes | None stated | — |
| Scope read | Owning a platform roadmap, partner discovery and two squads is a mid-level PM scope | `[inferred]` from the JD's listed responsibilities; no market check ran |
| Market calibration | Not run. The role-family search was refused, so there is no pay or scope band | — |
| Unknowns | Pay, contract basis, reporting line, whether this PM decides priorities or proposes them to the squads | — |
| Contradictions | None visible within the posting | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience (adjacent part) | must_have | adjacent | medium | transferability | Roadmap-input sessions and coordinating PMs on custom builds are PM-adjacent. No titled PM years. Limit: you collected and passed on input; you did not own the decision. | `[grounded]` CV | Bridge case in G1 and G4 |
| R1b | 3+ years product management experience (titled) | must_have | absent | none | capability | No PM title on the CV, and you have said you have never held one. Closure is a PM role or an internal PM rotation, not a reframing. | `[grounded]` CV and your statement | Name a closure path in the screen |
| R2 | Owns the platform roadmap | must_have | unclear | low | discovery | The CV shows input to the roadmap, not decisions on it. Not established either way. | `[grounded]` CV silence; `[inferred]` that ownership sits in decisions, not input | G1 |
| R3 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST integrations delivered end to end are shipped work on a platform someone else built and released. Limit: you did not build, version or release the platform. | `[grounded]` CV | G4 |
| R4 | Runs discovery with integration partners | must_have | direct | medium | none | Scoping workshops and requirements gathering with client engineers are discovery in practice. CV only; expect a probe. | `[grounded]` CV | Be ready with one scoping example |
| R5 | Writes specs and drives delivery with engineering squads | must_have | direct | medium | none | Requirements documents, integration architecture, and coordinating engineers on client builds. These are client-build specs, not platform product specs. | `[grounded]` CV; `[inferred]` that the spec type differs | State the spec type you wrote in the screen |
| R6 | Agile delivery experience | must_have | unclear | low | discovery | The CV names no cadence or role. | `[grounded]` CV silence | G3 |
| R7 | Defines and tracks adoption metrics | must_have | unclear | low | discovery | No adoption metric on the CV. A prior-conversation note about a support tool is unconfirmed and not counted here. | `[grounded]` CV silence | G2 |
| R8 | Coordinates launches with sales and support | important | adjacent | medium | transferability | Go-live, UAT and client launch coordination are close to launch work. Sales and support coordination are not on the CV. | `[grounded]` CV; `[inferred]` closeness | Name one launch where you worked with the client's support team |
| R9a | Stakeholder management across engineering and customers | must_have | direct | medium | none | Coordinated engineers, client engineers and PMs on custom builds. | `[grounded]` CV | none |
| R9b | Stakeholder management with sales | must_have | unclear | low | discovery | Sales is not on the CV. | `[grounded]` CV silence | Name any sales conversation you joined |
| R10 | Technical fluency: API docs and schemas | must_have | direct | medium | none | Postman, SQL, reading OpenAPI specs, integration architecture. | `[grounded]` CV | Be ready to walk one schema you changed |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owns the roadmap (R2, must_have) | discovery | You ran sessions that collected client feedback for product. The CV does not say whether you ever decided what got built | Roadmap ownership is the core of the job; this row decides the status | A prioritization you made between competing client asks; a scope call you took to a squad; a feature you pushed back on and why | A roadmap-input summary, a backlog you ordered, a decision note | `[grounded]` CV silence; `[generic]` that PM interviews test the decision, not the input |
| G2 | Adoption metrics (R7, must_have) | discovery | No adoption measure on the CV. A prior-conversation note suggests an internal triage tool that support agents adopted; unconfirmed | Defining and tracking adoption is a named responsibility; a real tool with adoption would be the strongest PM-adjacent evidence you have | Any integration or tool where you tracked go-live time, error rates, or who used it; an internal tool others chose to use | A usage count, a dashboard, a before-and-after note | `[grounded]` CV silence; memory lead, unconfirmed |
| G3 | Agile delivery (R6, must_have) | discovery | No cadence named | Two squads are named in the JD | The sprint or planning rhythm you ran with engineers; who owned the backlog | A sprint review or planning note | `[grounded]` CV silence |
| G4 | Shipped platform products (R3, must_have) | transferability | 30+ integrations shipped on someone else's platform; no release of your own | The limit is the platform itself, and the bridge is the playbook you wrote | A playbook section others used as the standard; an API change you drove to clients | A sanitized playbook excerpt, release notes you contributed to | `[grounded]` CV; `[inferred]` that the playbook is the nearest platform artifact |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Concrete scope | positive_signal | — | "Own the roadmap for our partner-facing API platform" | The named platform, partners, two squads and metrics make the role's scope checkable | `[grounded]` JD | Which roadmap decisions does this role make alone, and which go to the squads or leadership? | noted |
| RR2 | Employer not verified | unknown | — | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Unverified because the search was refused this session, not because no footprint was found | `[grounded]` JD header; search refused | Can you point me at the posting on Quartzline's own careers page, and who would I interview with? | unresolved |
| RR3 | Pay and contract basis not stated | unknown | — | No pay or contract term in the posting | Pay may sit outside the posting; the contract type is unknown | `[inferred]` from the posting's silence | What is the base salary range, and is this a permanent role? | unresolved |

## Application plan

Nothing below is applied. Each row needs your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Use this summary line: "Seven years on the vendor side of REST API integrations: I led 30+ client integrations end to end, from scoping workshops through go-live, and ran the quarterly sessions that brought client feedback into product." | Puts R4, R9a, R10 and R1a in front of a reader without claiming PM years. "Customer side" is deliberately not used: you stood on the vendor side, so that phrase would invert the relationship. | `[grounded]` each clause traces to the CV: "Led 30+ client integrations of our REST APIs end to end"; "scoping workshops … go-live"; "Ran quarterly roadmap-input sessions collecting client feedback for product"; "solutions engineer … at an enterprise-software vendor" | `resume_edits_pending_approval` |
| E2 | Lead your bullets with the roadmap-input sessions, not the integration count | Puts the PM-adjacent evidence (R1a, R2) first | `[inferred]` from reading the map; reorder only, no new claim | pending your approval |
| W1 | If you have one, a sanitized roadmap-input summary: what client feedback you collected and what changed in product | Would move R2 and R1a | `[grounded]` G1 and G4 | pending your approval |
| A1 | Check the posting on Quartzline's own careers page before you invest in an application | Settles RR2 | `[generic]` standard verification step | pending your approval |

The full CV rewrite is resume-tailor's job; the line above is the only language proposed here.

Dossier offer: If you want this kept for later sessions, I can write it as `tuesday-dossier.md`.

## Upgrade menu

- Permission to run the two refused searches (Quartzline's careers page, and the role-family pay and scope check) → RR2 closes, and the pay band goes into role reality.
- A roadmap-input summary or any inspectable artifact → R2 and R1a move up.
- The live posting link → RR2 closes.
- A salary range → RR3 closes.
- Details of the support-tool note, if it is real → R7 and R3 can move (see G2).

## Questions

G1 — Did you ever decide what got built, or did you collect client input and pass it to product? If you made a call, name one and say what you decided and who else was involved.

G2 — A note from a previous conversation suggests you built an internal request-triage tool that support agents adopted. Is that right? If so, what was it, and how did you measure whether people used it?

G3 — Which delivery cadence did you run with engineers (sprints, Kanban, or something else), and did you own the backlog or only take part in planning?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.