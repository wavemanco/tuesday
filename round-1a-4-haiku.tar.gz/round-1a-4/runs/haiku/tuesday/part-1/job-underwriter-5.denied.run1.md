**Worth applying, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (remote US or Denver office), R2 (base pay $148,000–$166,000 against your floor)
- `must_have`: direct: R3 (dbt and a cloud warehouse), R4 (strong SQL and Python), R5 (5+ years data engineering), R6 (Airflow or similar), R7 (data quality testing), R8 (build and run reporting pipelines)
- `important`: adjacent: R9 (dbt-modelled warehouse on BigQuery); unclear: R10 (ingestion from app and CRM), R11 (data contracts analysts depend on)

R9: dbt and SQL carry over, the BigQuery specifics don't. R10 and R11 aren't described in what you've shared, so they wait on your answer.

**Opportunity ledger.** The scope and pay read as normal for a senior post (RR4, RR5). The open items are unknowns, not red flags: the employer and posting are unchecked (RR1), team and ownership are unstated (RR2), and the equity is unquantified (RR3).

- **Hard gates:** none failed (R1 and R2 both `unclear`); unconfirmed: R1 (remote US or Denver office), R2 (base pay, $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1: you can work in the US, remotely or from Denver; (2) R2: the bottom of the range clears your floor; (3) RR1: the posting is live on pellucidlearning.com and the employer checks out.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 states; founded 2016 in Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` your pasted About page, not checked independently |
| Mandate | Build and run reporting pipelines, the dbt warehouse on BigQuery, app and CRM ingestion, and data contracts | `[grounded]` posting |
| Scope read | One domain's pipelines with contracts and no named team, which is the senior norm | `[generic]` the pasted report's "one domain, no direct reports"; `[inferred]` from the posting's silence on team |
| Market calibration | Posted range midpoint $157,000 sits above the pasted median of $151,000, inside the IQR of $139,000–$163,500 | `[grounded]` posting; `[generic]` the Datawright band, which covers Series B–D. Pellucid is Series C, so this comparison is close, not exact |
| Unknowns | Team size, contract ownership, equity value, hiring manager | — |
| Contradictions | None in what you pasted | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver office | hard_gate | unclear | none | hard_gate | Nothing stated about location or work authorization | `[grounded]` posting | Q1 |
| R2 | Base pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No floor given; the range sits near market | `[grounded]` posting | Q2 |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt on Snowflake, about 180 models. Stated, not inspected; expect a probe | `[grounded]` your intake | Upgrade menu |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | `[grounded]` your intake | none |
| R5 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company | `[grounded]` your intake | none |
| R6 | Airflow or similar | must_have | direct | medium | none | Airflow for orchestration, stated | `[grounded]` your intake | Upgrade menu |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` your intake | Upgrade menu |
| R8 | Build and run pipelines | must_have | direct | medium | none | Pipeline ownership stated; the reporting domain isn't described | `[grounded]` your intake | none |
| R9 | Warehouse on BigQuery | important | adjacent | medium | transferability | You've never used BigQuery. Partitioning, clustering and cost control aren't exercised | `[grounded]` your statement; `[inferred]` the bridge from Snowflake work | G1 |
| R10 | Ingestion from app and CRM | important | unclear | none | discovery | Not in what you've shared | — | Q3 |
| R11 | Data contracts analysts depend on | important | unclear | none | discovery | Not in what you've shared | — | Q3 |

Your claims are `medium` because nothing has been inspected yet. R1 and R2 are gates, so they carry the closing questions instead of a queue row.

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | What would close it |
|---|---|---|---|---|
| G1 | BigQuery (R9) | transferability | Snowflake dbt work and SQL, no BigQuery | Name the limit: no BigQuery partitioning, clustering or cost work. Strengthen it with a small dbt project on BigQuery's public datasets, linked from your CV. `[inferred]` that this narrows the objection |
| G2 | Ingestion (R10) | discovery | Not described | Q3 |
| G3 | Contracts (R11) | discovery | Not described | Q3 |

**Opportunity risk register**

| # | Signal | Class | Severity | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting unchecked | unknown | — | Web search was refused, so the About page and posting are as you pasted them. The live posting should be confirmed before you invest effort. Not recorded as the standing "employer not established" entry, since no search returned anything either way | `[grounded]` your pasted text; the check is outstanding | "Is this posting live on your careers page, and who would I be interviewing with?" | unresolved |
| RR2 | Team and ownership unstated | unknown | — | Build-and-run plus contracts could mean one owner, or an unnamed team | `[inferred]` from the posting's silence on team | "Who else builds and owns these pipelines, and who decides the data contracts?" | unresolved |
| RR3 | Equity unquantified | unknown | — | Its value is unknown | `[grounded]` posting | "What's the equity: type, grant size, vesting, and valuation basis?" | unresolved |
| RR4 | Pay sits near market | positive_signal | — | Midpoint $157,000 is above the pasted median | `[grounded]` posting; `[generic]` the B–D band | "Where in the range would a new hire at this level usually start?" | noted |
| RR5 | Scope and stage look normal | positive_signal | — | Series C, $52M raised February 2026; scope matches the senior norm | `[grounded]` your About page; `[generic]` the senior norm | "What's the reporting roadmap for the next year?" | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the live posting on pellucidlearning.com and note any recruiter email domain | RR1 | `[grounded]` RR1 | yours to do |
| A2 | Ask the recruiter what BigQuery work the role starts with, and the equity terms | R9, RR3 | `[grounded]` R9, RR3 | yours to do |
| A3 | Build a small BigQuery dbt project to link, if you have time | G1 | `[inferred]` | optional |
| A4 | Share your CV before any wording is drafted | No CV yet; no resume language is proposed | — | none proposed |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Pellucid and its posting were refused by the host's search permission, so nothing returned. Would have moved RR1 |
| 2. Role-family sweep | skipped | The pasted Datawright report fixes the band and scope norm, so no search was needed. Its cohort is Series B–D, one stage short of Pellucid |
| 3. Hiring manager's public footprint | n/a | No name given |

If you can grant search permission, I'll run the company check (up to 5 searches and 2 fetches) and it can settle RR1.

If you'd like, I can write this up as a `tuesday-dossier.md` to keep for later prep.

**Upgrade menu**

- Search permission, or the careers page link → RR1 checked, the company check that didn't run.
- Your CV → turns the intake claims for R3–R8 into checkable ones, and makes resume language possible with your approval.
- A sanitized dbt model, Great Expectations suite or Airflow DAG → R3, R6 and R7 toward `high`.
- A linked BigQuery project → the R9 bridge gets evidence.
- The equity terms → RR3 closes.

**Questions**

R1: Are you authorized to work in the US, and can you work remotely from there or from Denver?

R2: Is the $148,000 base, the bottom of the posted range, above your floor?

R10 and R11: Have you built ingestion from a product app or a CRM into a warehouse, or defined or enforced a data contract with analysts? Describe the one you owned: what it moved, what broke, and who relied on it.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.