**Yes, it's worth applying, with two checks first.** Your stack matches the posting closely, and the pay is at market. Status: `conditional_go`.

- **Hard gates:** `none failed; unconfirmed: H1 (remote US or Denver office), H2 (base $148,000–$166,000); candidate constraints not given — checks against them unknown`
- **Fit ledger** (rows read off the evidence map below):
  - `hard_gate`: unclear: H1 (remote US or Denver office), H2 (base $148,000–$166,000)
  - `must_have`: direct: R1 (5+ years data engineering), R2 (strong SQL and Python), R3 (dbt and a cloud warehouse), R4 (orchestration with Airflow or similar), R5 (experience with data quality testing)
  - `important`: adjacent: R6 (dbt-modelled warehouse in BigQuery); unclear: R7 (ingestion from our app and CRM), R8 (data contracts our analysts depend on)
  - R1 through R5 are all `direct`. R6 is the real limit: you have dbt on Snowflake, not BigQuery. R7 and R8 are unknown, not missing. H1 and H2 depend on constraints you haven't given me.
- **Opportunity ledger:** The posting is coherent and the pay is in the market band. RR1 (hiring manager and scope unknown) and RR2 (three pipelines may sit on one person) are open questions. RR3: I could not corroborate the company's funding or size outside its own pages.
- **Severe red flags:** none found.
- **Conditions for go:** (1) H1 and H2 work for you; (2) R6 is named in your application as a Snowflake-to-BigQuery transfer, not BigQuery experience; (3) RR3's funding claim is checked, or you're comfortable with it unverified.
- **What would change this:** a pay floor above $166,000, or a location that rules out remote-US and Denver, would make H1 or H2 `hard_gate_fail` and the status `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools. The posting and the about page agree, and the careers page is live | `[grounded]` careers page fetched; `[grounded]` about page via search |
| Scope | Build and run ingestion, a dbt warehouse and data contracts for tutoring reporting | `[grounded]` posting |
| Seniority | Your 6 years sits inside the 5–8 years the report gives for "Senior" | `[generic]` Datawright 2026 pattern, as pasted |
| Pay | $148,000–$166,000 posted. The range midpoint is about $157,000, above the report's $151,000 median and inside its $139,000–$163,500 interquartile range | `[grounded]` posting and pasted report; the market comparison is `[generic]` |
| Scope read | Three pipeline domains in one post is ordinary for the title, but it's a stretch for one person to own all three | `[inferred]` from the posting's list against the report's "one domain" norm |
| Unknowns | Hiring manager, team shape, on-call, contract basis, whether the contract is permanent | — |
| Contradictions | None between the posting and the careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| H1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location isn't in the material, so the gate isn't settled | `[grounded]` posting; your location not given | Question Q1 |
| H2 | Base $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your pay floor isn't in the material | `[grounded]` posting; your floor not given | Question Q1 |
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years at a payroll company. Self-reported, so `medium` | `[grounded]` your intake | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both, self-reported | `[grounded]` your intake | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | About 180 dbt models on Snowflake | `[grounded]` your intake | none |
| R4 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration | `[grounded]` your intake | none |
| R5 | Experience with data quality testing | must_have | direct | medium | none | You set up a Great Expectations suite. "Set up" is not "ran for years", so no stronger claim | `[grounded]` your intake | none |
| R6 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | dbt modelling carries over. BigQuery's cost model, partitioning and dialect are not exercised | `[inferred]` adjacency from R3 | Gap G1 |
| R7 | Ingestion from our app and CRM | important | unclear | low | discovery | Your intake doesn't mention ingestion or CRM work | `[grounded]` posting; your intake silent | Gap G2 |
| R8 | Data contracts our analysts depend on | important | unclear | low | discovery | Your intake doesn't mention contracts | `[grounded]` posting; your intake silent | Gap G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | Snowflake dbt work, no BigQuery | The posting names BigQuery; a named limit is better than an unnamed one | Any BigQuery use, including a sandbox | A query log, a small dbt project on BigQuery | `[inferred]` transfer from R3; `[generic]` that BigQuery differences matter to dbt hiring |
| G2 | Ingestion from app and CRM (R7, important) | discovery | Intake silent on source ingestion | Core to the scope | Pipelines pulling from a product database or a CRM API | A pipeline diagram, a DAG, a repo | `[grounded]` posting |
| G3 | Data contracts (R8, important) | discovery | Intake silent on contracts | Named in the posting as what analysts depend on | Schema agreements, dbt contracts, owner-and-breaking-change processes | A contract doc or a schema test | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Hiring manager and team not named | unknown | — | (posting names no hiring manager) | The team may be shaped differently than the posting suggests | `[grounded]` posting silent | Who would I report to, and which team owns ingestion and the warehouse? | unresolved |
| RR2 | Three pipeline domains in one role | risk_signal | low | "Build and run the pipelines … ingestion … warehouse … data contracts" | One person may own everything, including on-call | `[inferred]` from the posting's list against the report's one-domain norm | Does this role own all three, or is there a platform or on-call team? | unresolved |
| RR3 | Company facts not corroborated outside its own pages | risk_signal | medium | "Series C ($52M, February 2026)" | The funding and headcount claims may be accurate, but only the company's own site repeats them | `[grounded]` search returned only the about page; the hypothesis is `[generic]` for companies this size | Which investors led the Series C, and how big is the data team? | unresolved |
| RR4 | Salary disclosed, near market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range sits around the role-band median | `[grounded]` posting; `[generic]` band from the pasted report | How is the range set within the band for this level? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check H1 and H2 against your location and pay floor before applying | These are the two gates the material can't settle | `[grounded]` H1, H2 | for you |
| A2 | Name BigQuery in the application as a Snowflake-to-BigQuery transfer, with the limit stated | Honest framing of R6 | `[grounded]` R6 | pending your approval |
| A3 | Lead with the 180-model dbt project and the Great Expectations suite | These are your strongest direct matches | `[grounded]` R3, R5 | pending your approval |
| A4 | Ask RR1, RR2 and RR3 of the employer before the loop | The register doubles as interview prep | `[grounded]` register | pending your approval |

When a screen is booked, mock-interview can drill the BigQuery and ingestion questions.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring Denver" (no results) and "Pellucid Learning Series C funding" (returned only pellucidlearning.com/about, which repeats the company's own figures). Fetched pellucidlearning.com/careers/senior-data-engineer: live, matches the posting you pasted. Moved RR3; the contradictions row is empty |
| 2. Role-family sweep | skipped | The pasted Datawright 2026 figures (median $151,000; IQR $139,000–$163,500; Senior means 5–8 years) already fix the band, so no search was sent |
| 3. Hiring manager's public footprint | n/a | No name was given, and the posting names none |

I'm offering a deeper pass on Pellucid Learning (funding and leadership changes, and past grants or staff reports; up to 5 more searches and 2 more fetches), which I'd run if you say so.

If you want this kept for later modules, I can emit it as `tuesday-dossier.md`.

## Upgrade menu

- Your location and base pay floor → H1 and H2 close, and the status moves to `go` or `no_go`.
- A BigQuery project, query log or sandbox → R6 moves from adjacent toward direct.
- A repo, the Great Expectations config, or a dbt project (anonymized) → R3 and R5 move from `medium` to `high`.
- A pipeline diagram or a contract example → R7 and R8 close.
- The hiring manager's name → RR1 closes, and the public-footprint research target can run.
- The deeper pass on Pellucid Learning, described above.

## Questions

Q1 (H1, H2): Does a remote-US or Denver setup, with a base of $148,000 or more, work for you?

Q2 (R7, R8): Have you built ingestion from an app or a CRM, or defined a data contract with analysts? What did you own?

Q3 (R6): Have you used BigQuery at all, even in a sandbox or a side project?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.