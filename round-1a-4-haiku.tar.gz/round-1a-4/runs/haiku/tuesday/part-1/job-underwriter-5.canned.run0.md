## Decision snapshot

**Probably worth applying to, after two checks: your location and your pay floor. Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (base pay $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (dbt-modelled warehouse in BigQuery); unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R3–R7 — all five must-haves are direct, at medium confidence from your own statements; R8 — a credible bridge, its BigQuery limit named; R9 and R10 — not in your background, asked below.

**Opportunity ledger.** The scope is concrete and the posted pay brackets the market median (RR4, RR5). Equity has no terms, the location wording is open to interpretation, and the funding figures come only from the company's own pages (RR1, RR2, RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (base pay $148,000–$166,000); met: none; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** `hold_pending_answers` waits on Q1 (R1) and Q2 (R2). If you are US-based and your floor is at or below $148,000, it moves to `conditional_go`, with conditions on R8 (the BigQuery bridge) and R9/R10 (the ingestion and data-contract answers). If you are outside the US and not in Denver, R1 fails and the status is `no_go` for this posting.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 states, founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company About page; headcount and funding not independently corroborated (see RR3) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting, a dbt warehouse in BigQuery, and data contracts for analysts | `[grounded]` JD |
| Scope read | One domain's pipelines, with no direct reports stated | `[inferred]` from the JD's scope sentence; `[generic]` that this matches the report's typical scope for the title |
| Market calibration | Posted $148,000–$166,000 against the report's base median of $151,000 (IQR $139,000–$163,500); the range sits around the median | `[generic]` Datawright 2026 band (US, Series B–D, n=2,310), as supplied; `[grounded]` posted figures |
| Seniority read | Six years sits inside the report's 5–8 year band for "Senior" | `[generic]` the report's definition |
| Unknowns | Equity terms, location eligibility, contract basis, hiring manager, ingestion and data-contract scope | — |
| Contradictions | None between the JD, the careers page and the About page | `[grounded]` search results for both pages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | The posting sets a location term; your location is not in the material, so the gate is not established | `[grounded]` JD; location not given | Q1 |
| R2 | Base pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The pay is stated; your floor is not given, so the gate is not established | `[grounded]` JD; floor not given | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; a length requirement, graded on fit, not as a gate | `[grounded]` your intake statement | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Both used daily | `[grounded]` your intake statement | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | A dbt project of about 180 models on Snowflake, a cloud warehouse | `[grounded]` your intake statement | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration | `[grounded]` your intake statement | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | Set up a Great Expectations test suite | `[grounded]` your intake statement | Upgrade: an anonymized suite would raise to high |
| R8 | Dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The role names BigQuery as its warehouse. Your dbt modelling and testing on Snowflake carry over; BigQuery tooling does not, and you have not used it | `[inferred]` from the JD's role description; `[grounded]` your Snowflake and no-BigQuery statements | G1 |
| R9 | Build and run ingestion from app and CRM | important | unclear | none | discovery | Named in the JD's responsibilities; absent from your background | `[grounded]` JD; background silent | Q3 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Named in the JD's responsibilities; absent from your background | `[grounded]` JD; background silent | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Dbt modelling and testing on Snowflake; no BigQuery work | The role names the warehouse, and the bridge narrows the likeliest objection | Any dbt model, test or cost work on another cloud warehouse; any BigQuery query or project, even on public data | A short BigQuery sample or project README | `[inferred]` bridge from your Snowflake work; `[generic]` that BigQuery is the likeliest objection |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Nothing about ingestion in your background | A named responsibility; evidence would move the row from unclear | A pipeline that pulled from a CRM or product database, and what you owned in it | A design note or a pipeline diagram | `[grounded]` JD responsibility; background silence |
| G3 | Data contracts (R10, important) | discovery | Nothing about contracts with consumers | A named responsibility, and the one the analysts rely on | A schema agreement, versioning or breaking-change process with downstream users | A contract document or a changelog | `[grounded]` JD responsibility; background silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity unpriced | unknown | — | "plus equity" | Equity could be material or nominal; the posting gives no terms | `[inferred]` from the posting's silence on equity | What is the equity grant for this role: options or RSUs, vesting, strike price, and the latest valuation? | unresolved |
| RR2 | Location eligibility unspecified | unknown | — | "Remote (US) or our Denver office" | Remote eligibility may depend on state or time zone, or on in-office expectations | `[inferred]` from the JD's location wording | Which states can this role be remote from, and what in-office expectations apply to remote hires? | unresolved |
| RR3 | Funding and headcount self-reported | unknown | — | "Series C ($52M, February 2026)" | The figures appear only on the company's own pages in the one search run | `[inferred]` from search results that returned only company pages | Which investors led the Series C, and is there a public announcement I can read? | unresolved |
| RR4 | Concrete scope | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | Scope is one domain's pipelines, which matches the report's typical scope for the title | `[generic]` typical scope; `[grounded]` the posting | Which pipelines does this role own end to end, and who else changes the warehouse? | noted |
| RR5 | Posted pay brackets the market median | positive_signal | — | "$148,000–$166,000" | The posted range contains the report's median of $151,000 | `[generic]` Datawright band; `[grounded]` posted figures | What is budgeted at the top of the range for a candidate at this level? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Hold the application until Q1 and Q2 are answered | R1 and R2 are gates not yet established | `[grounded]` gate rows | pending your approval |
| P2 | Put RR1, RR2 and RR3 to the recruiter, verbatim, in the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P3 | Lead the CV with the 180-model dbt project and the Great Expectations suite | R5 and R7 are direct, with medium confidence | `[grounded]` your statements | `resume_edits_pending_approval` |
| P4 | Frame BigQuery as the gap it is: dbt modelling and testing carry over, and BigQuery tooling is new to you | R8 is adjacent, with its limit named | `[grounded]` your statement; `[inferred]` that interviewers will probe this gap | pending your approval |

## Evidence status

Verified: none yet. Your statements are intake material and have not yet been probed.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning Senior Data Engineer careers": the careers page is listed as accepting applications, and its text matches the JD you pasted. Searched "Pellucid Learning live online tutoring K-12 Series C": the About page matches the text you pasted. Both results are the company's own pages, so the Series C and headcount remain uncorroborated (RR3). The failed-attribution entry is not triggered. |
| 2. Role-family sweep | skipped | The Datawright figures you pasted (median, IQR, 5–8 year band, scope) already fix the market calibration. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

Dossier offer: If you want, I can write this up as a `tuesday-dossier.md` you can keep and append to after each recruiter call.

## Upgrade menu

- A BigQuery sample, such as any project or query you have run, even on public data → R8's bridge narrows.
- An anonymized Great Expectations suite or test-results summary → R7 rises to `high`.
- A description of an ingestion or data-contract project you owned → R9 and R10 gain evidence rows.
- Deeper research on Pellucid Learning (funding corroboration, leadership changes, past hiring; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

Q1 (R1) — Are you based in the US, and in which state? The posting says "Remote (US) or our Denver office," so this decides whether the gate is met.

Q2 (R2) — What is the lowest base salary you would accept for this role?

Q3 (R9, R10) — Have you built CRM or app ingestion, or defined data contracts that analysts relied on? One example, with what you owned, is enough.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.