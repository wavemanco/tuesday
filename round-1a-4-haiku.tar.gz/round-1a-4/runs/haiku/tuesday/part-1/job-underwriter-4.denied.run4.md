## Decision snapshot

Yes, apply, once two things check out. Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: unclear: R1 (fully remote, UK)
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: direct: R7 · adjacent: R8 (product recommendations), R9 (pet-insurance product knowledge)
- `preferred`: direct: R10 (insurance experience)

R2, R3, R4 and R5 match your stated experience; R6 is direct, but who designed the tests is unstated; R8 has underwriting recommendations evidenced and product recommendations not; R9 has motor transfer but no pet-specific work.

**Opportunity ledger.** Mostly unknowns rather than red flags: the mandate is clear (RR1, positive); pay, reporting line and pet-book scale are not in the posting (RR3, RR4, RR5); and the employer is unverified (RR2), which caps this at `conditional_go`. Web search was not permitted in this session, so none of the employer checks ran.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found. The posting asks for no payment, deposit or bank details.
- **Conditions for go:** (1) RR2 verifies: the role is live on Brindlemoor's own careers site (A1); (2) R1 is confirmed: you are UK-based with the right to work; (3) R6 holds: you can say which price tests you designed.
- **What would change this:** if (1) fails, hold until it verifies. A payment or deposit request would make this `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` posting header; no footprint checked |
| Mandate | Own pricing analytics for the pet product: rating models, price tests, recommendations to underwriting and product | `[grounded]` posting |
| Working pattern | Fully remote, UK | `[grounded]` posting |
| Scope read | A senior individual-contributor analytics role with stakeholder presentations; the posting does not mention reports | `[inferred]` from the responsibilities against the silence on reports |
| Market calibration | Not run. Web search was not permitted, so no pay or scope norm is set here | — |
| Unknowns | Pay; reporting line; team; pet-book size and claims history; contract type; interview process | — |
| Contradictions | None visible in the posting as pasted | `[grounded]` posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK (location and right to work) | hard_gate | unclear | none | hard_gate | No candidate constraint given, so nothing settles this | `[grounded]` posting; no candidate statement | Q2 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years stated, last two senior. Self-report; no artifact yet | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated. Expect a live test | `[grounded]` your statement | prepare a short SQL and Python walkthrough |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the young-driver GLM | `[grounded]` your statement | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R6 | Design and read price tests | must_have | direct | medium | discovery | Fourteen tests run with underwriting. Design ownership is not stated | `[grounded]` your statement | Q1 |
| R7 | Build and monitor rating models | important | direct | medium | none | Maintained a model; monitoring is implied, not stated | `[inferred]` from "maintained" | confirm monitoring cadence in interview prep |
| R8 | Turn results into recommendations for underwriting and product | important | adjacent | medium | transferability | Underwriting recommendations evidenced; product recommendations not. Limit: no product-side decisions stated | `[grounded]` your review; `[inferred]` product gap from silence | G2 |
| R9 | Pet-insurance product knowledge (implied by the mandate) | important | adjacent | medium | transferability | Motor rating and GLM method carry over. Pet mechanics not exercised | `[inferred]` from the mandate; `[generic]` that pet cover differs in structure and claims behaviour | G3 |
| R10 | Insurance experience (a plus) | preferred | direct | medium | none | UK motor insurer, five years | `[grounded]` your statement | none |

Your statements are at `medium` because they are specific but have no inspectable artifact yet. Management is not in the posting, so it is not a row.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Designing price tests (R6, must_have) | discovery | Fourteen tests run; design ownership not stated | "Design and read" is a must-have; design ownership is what interviewers will probe | Setting the hypothesis, test cells, or sample size for a test; deciding what to stop or keep | A test brief, a readout deck, or the test-sizing sheet | `[grounded]` your statement |
| G2 | Product recommendations (R8, important) | transferability | Recommendations to underwriting are evidenced; to product are not | The posting names product as a recipient | A pricing change you proposed that product accepted or rejected | A recommendation memo | `[inferred]` from silence |
| G3 | Pet-insurance product knowledge (R9, important) | transferability | Motor GLM and pricing method; nothing pet-specific | Pet pricing rests on different structures and claims behaviour; this is what the interview will test | Any non-motor rating, a frequency-severity model, or a claims-cost analysis you have run | A short write-up of how you would structure a pet model | `[generic]` that pet products differ in structure and claims behaviour |
| G4 | Remote UK gate (R1, hard_gate) | hard_gate | Not stated by you | Unconfirmed gates cannot be checked | Not applicable | Not applicable | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Clear, specific mandate | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | Scope is defined and measurable; this is a real pricing role | `[inferred]` from the listed responsibilities | Which rating models and price tests would I own in the first six months? | noted |
| RR2 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | Not verified, because no search ran. The firm may be too new or small for a footprint, the posting may be stale or aggregated, or it may not be a live hiring employer. This is unverified, not a finding against the firm | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Pay not in the posting | unknown | — | (no pay figure in the pasted posting) | Pay may be withheld or may sit off the posting | `[inferred]` from absence in the pasted text | What is the base salary range for this role, and is there a bonus? | unresolved |
| RR4 | Reporting line and team not stated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be solo analytics or may carry reports. The posting does not ask for management | `[inferred]` from silence on reports | Does this role line-manage anyone, and who would I work with day to day? | unresolved |
| RR5 | Pet-book scale and claims history unknown | unknown | — | "our pet-insurance product" | A thin or young book would change how much the motor GLM work transfers | `[inferred]` from silence on size | How many policies and how many years of claims data does the pet book have? | unresolved |

Severity is `—` on the unknown and positive rows because it applies only to risk signals and red flags.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the role on Brindlemoor's own careers page before you invest in an application | see RR2 | `[generic]` pattern, a check and not a claim about the firm | pending your approval |
| A2 | Lead the CV with GLM work and the underwriting review | R4 and R5 are direct and the posting names both | `[grounded]` R4, R5 | resume_edits_pending_approval |
| A3 | Frame motor pricing as transferable method; name pet mechanics as what you would learn, not as experience | see R9, G3; avoids implying pet experience | `[grounded]` your motor work; `[generic]` what pet cover involves | pending your approval |
| A4 | Be ready to say which of the fourteen tests you designed and which you ran | see R6, G1 | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet. Your statements are intake prose, so they stand at `medium` until probed. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Four searches were refused, so this is unchecked. It would have moved RR2 and the contradictions row |
| 2. Role-family sweep | unavailable | Search refused. It would have set the UK pay and scope norm for this title (role reality's market calibration) |
| 3. Hiring manager's public footprint | unavailable | Search refused. A name was given (Odile Varga, Director of Pricing); this would have covered public professional footprint only |

Dossier offer: I can write this assessment to `tuesday-dossier.md` so the other modules can pick it up.

## Upgrade menu

- The live posting link from Brindlemoor's careers page → RR2 closes and the decision can move toward `go`.
- Your confirmation that you are UK-based with the right to work → R1 becomes `direct`.
- A list of the fourteen tests, marking which you designed → R6 firms up.
- The posted or budgeted salary → RR3 closes; it can be set against a UK band if search is permitted.
- Permission to use web search → the three checks in Evidence status run: the employer, the pay norm, and Odile Varga's public professional footprint.
- Any non-motor rating work or claims-cost analysis you have done → R9 moves from adjacent toward direct.

## Questions

G1: Of the fourteen price tests you ran last year, which did you design (the question, the test cells, the sizing), and which did you run and read?

G4: Are you based in the UK, with the right to work here, for a fully remote role?

RR2: Can you send the link to this posting on Brindlemoor's own careers site?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.