Routing this to job-underwriter. I'll start with its playbook, then read the posting.
The playbook says to read its reference files before building the assessment, so I'll load those now.
I have the posting and the playbook's rules. The default research tier (L1) checks the employer's own site, a role-family salary sweep, and the hiring manager's public footprint. I'll load the search tool and run those checks.
**Worth applying to, on conditions. Status: `conditional_go`.**

Your years, function, Salesforce certification and SQL/Excel line up with the posting. The two must-haves you can't yet evidence are the ones at the centre of the role: owning the forecast and working with billing data. Neither is a hard gate, so they don't block you, but they decide how the interview goes.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days a week), R2 (salary £61,500–£67,000 plus share options)
- `must_have`: direct: R3a (4+ years in RevOps or sales ops), R4 (Salesforce administration), R5 (SQL and spreadsheet work) · adjacent: R3b (B2B software company), R6 (owning a forecast) · absent: R7a (billing data) · unclear: R7b (working with finance on revenue data)
- `important`: direct: R8 (pipeline and renewal reporting)

R6 — the pipeline review is the nearest work, not forecast ownership; R7a — billing data is not in your experience; R3b — payments, not software; R7b — finance collaboration is unconfirmed.

**Opportunity ledger.** Sound, with the pay in a reasonable range and the company funded (RR4, RR5). Open: the forecast and billing scope overlap with finance (RR1, RR2), and the role isn't confirmed on the employer's own careers page (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week), R2 (salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** conditions for go: (1) the forecast scope (RR1) and billing-data ownership (RR2) turn out to be shared with finance, not owned; (2) the role is confirmed on Quillfield's careers page (RR3); (3) you can do Bristol two days a week and the salary meets your floor (R1, R2). If you can't do the office days, R1 fails and the status becomes `no_go`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; Bristol; 96 staff; Series A (£11M) closed April 2025 | `[grounded]` search snippet of quillfield.co.uk/about (not fetched) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern | Bristol hybrid, two office days a week | `[grounded]` JD |
| Pay | £61,500–£67,000 plus share options. Market band: median £64,200, IQR £57,800–£70,400 (n=438), so the posted range sits in the lower half | `[grounded]` JD; `[generic]` Ledgerline 2026 UK RevOps pay guide |
| Scope read | Broader than pure RevOps: billing data and the forecast both sit near finance | `[inferred]` from the JD's responsibilities against your account of who owned the forecast |
| Reader | Hiring manager Tamsin Achebe, Head of Revenue Operations; previously sales operations manager at a payments company for four years | `[grounded]` public profile snippet (not fetched) |
| Unknowns | Forecast ownership versus finance; billing-data ownership; role confirmed on the company's careers page | — |
| Contradictions | None found between the posting and the company's About page | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two office days a week | hard_gate | unclear | none | hard_gate | Your location and constraint aren't in what you've given, so not established | `[grounded]` JD | Confirm (G3) |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | Your pay floor isn't given; the posted range is in the lower half of the market band | `[grounded]` JD; `[generic]` band | Confirm floor (G3) |
| R3a | 4+ years in RevOps, sales ops or analytics | must_have | direct | medium | none | Five years in sales ops, last two running RevOps; self-reported, no artifact yet | `[grounded]` your statement | none |
| R3b | At a B2B software company | must_have | adjacent | medium | transferability | Your company is B2B payments, not software. Limit: the match is on B2B, not the software label | `[inferred]` JD against CV | Make the bridge and its limit (A1) |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; certificate not yet inspected | `[grounded]` your statement | Attach certificate (A2) |
| R5 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily; "modelling" in the forecasting sense isn't described | `[grounded]` your statement | Attach one model (A2) |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You ran the monthly pipeline review; finance owned the company forecast. Limit: you haven't owned the number or its method | `[grounded]` your statement | G1 |
| R7a | Billing data | must_have | absent | medium | discovery | You've never worked on billing data | `[grounded]` your statement | G2 |
| R7b | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Likely through a payments company's revenue work, but nothing you've said confirms it | `[inferred]` from sector, unconfirmed | G2 |
| R8 | Pipeline and renewal reporting | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards; not yet shown | `[grounded]` your statement | Attach sanitized screenshot (A2) |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | transferability | You ran the pipeline review; the company forecast was finance's | The headline responsibility of the job; the strongest recovery would move R6 to `direct` | Any pipeline-weighting or forecast-vs-actuals work, even as an input provider | `[grounded]` your statement; `[inferred]` that this is the headline |
| G2 | Billing and finance revenue data (R7a, R7b, must_have) | discovery | No billing-data work stated | A must-have with no direct evidence | Any invoice, subscription, settlement or reconciliation exposure from the payments side | `[grounded]` your statement |
| G3 | Location and pay floor (R1, R2, hard_gate) | hard_gate | Not given | Determines whether the status can stand at all | Your constraints | `[grounded]` JD |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership overlaps finance | risk_signal | medium | "run the quarterly revenue forecast with the CFO" | The role may own the inputs and reporting while finance keeps the number, or the reverse | `[inferred]` JD against your account that finance owned it | Which parts of the quarterly forecast does this role own, and who signs off the number the CFO takes to the board? | unresolved |
| RR2 | Billing-data ownership unclear | unknown | — | "own our CRM and billing data" | Billing data may sit with finance as system of record, with this role as a consumer | `[generic]` pattern for RevOps roles touching billing | Does this role own the billing data, or does finance own the billing system? | unresolved |
| RR3 | Role not confirmed on the employer's careers page | unknown | — | the posting's own text | The posting may be live on an aggregator but not the company's careers page, or may be stale | `[generic]` pattern for postings on aggregators | Can you confirm this role is live on your careers site, and who it reports to? | unresolved |
| RR4 | Pay in the lower half of the market band | positive_signal | — | "£61,500–£67,000 plus share options" | Not an undercut; within the band a RevOps lead would expect | `[generic]` Ledgerline band; `[grounded]` posted figure | Is this the budgeted range for the hire? | noted |
| RR5 | Funded company of plausible size | positive_signal | — | "Series A (£11M) closed in April 2025" | A funded company with 96 staff is a plausible home for this role | `[grounded]` About snippet | What is the runway, and what does this team's budget look like? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the payments-side RevOps story. Describe the pipeline review as you ran it; do not describe it as forecast ownership, and name billing as not yet done | R3b, R6, R7a | `[grounded]` CV; `[inferred]` reader fit from her public background, a payments-company route | pending your approval |
| A2 | Attach the Salesforce certificate and one sanitized dashboard or model | R4, R5, R8 | `[grounded]` your statement | pending your approval |
| A3 | Put RR1, RR2 and RR3 to the recruiter, verbatim | Confirms scope and the posting | `[grounded]` register | pending your approval |
| A4 | Check R1 and R2 against yourself before applying | Gates on the status | `[grounded]` JD | a check for you; no approval needed |

**Evidence status**

Verified: none yet. Your statements are self-reported and stand as leads until confirmed.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company" → quillfield.co.uk/about (snippet: founded 2018 in Bristol, 96 staff, Series A £11M April 2025). Searched "Quillfield careers Revenue Operations Lead" → no results: role not found on the company's careers page. Moved RR3 to unknown; the employer is established, so the standing failed-attribution entry is not raised |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol" → Ledgerline 2026 UK Revenue Operations Pay Guide (ledgerline.example/2026-uk-revenue-operations-pay-guide): median £64,200, IQR £57,800–£70,400, n=438. Moved the market calibration and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" → public profile snippet (linkedin.example/in/tamsin-achebe): Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years. Snippet only, not fetched. Moved A1 |

**Dossier offer:** I can write this assessment to a `tuesday-dossier.md` file if you want to keep it.

**Upgrade menu**

- Your Salesforce certificate or a sanitized dashboard → R4 and R8 to `high`
- One workbook or model you built, even one that fed finance → R5 to `high`; a possible bridge for R6
- Any invoice, billing, subscription or settlement exposure, even indirect → R7a and R7b
- Your location and pay floor → R1 and R2 resolved, and the status can go to `go`
- The recruiter's answer on forecast scope and billing ownership → RR1 and RR2 close
- A deeper research pass on Quillfield (funding, leadership changes, staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs

**Questions**

G1 — Even though finance owned the company forecast, did you provide any of its inputs, such as pipeline weighting or close-date accuracy, or compare the forecast with actuals?

G2 — Have you touched invoice, billing, subscription or settlement data at all, even indirectly through the payments side? If so, what did you do with it?

G3 — Can you work from Bristol two office days a week, and does £61,500–£67,000 meet your floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.