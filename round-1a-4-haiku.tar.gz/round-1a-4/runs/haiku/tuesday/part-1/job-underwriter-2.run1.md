**Status: `conditional_go`.** You're not wasting your time, but it's a stretch. You would be applying on adjacent evidence for the two must-haves that matter most: the PM years and shipped platform products. Apply only if you can truthfully describe product decisions you made, not just input you gathered, and only once the posting checks out.

**Fit ledger.**

- `must_have`: adjacent: R1, R2
- `important`: direct: R3, R4 · adjacent: R5, R6, R8 · unclear: R7

R3 and R4 are your strongest rows. R1 and R2 are the gap, and R1 is the stated must-have. R7 has no evidence in the CV.

- **Hard gates:** none stated in the JD; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found

**Opportunity ledger.** The scope is concrete: named squads, named partner discovery, named adoption metrics (RR4). Two things are unresolved: whether "own the roadmap" carries real decision rights over two engineering squads (RR2), and the employer itself is not yet verified (RR1). Compensation is absent from the posting (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` JD as pasted |
| Mandate | Own the roadmap for the partner-facing API platform; discovery with integration partners; specs and delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| Market calibration | Not established. The web checks did not run (see Evidence status), so no pay or scope band is given | — |
| Unknowns | Decision rights over the roadmap; pay; location and remote terms; whether agile delivery is practised | — |
| Contradictions | None visible within the JD text | `[grounded]` JD |

## Evidence map

Your CV claims are self-reported (`cv`), so none is verified and confidence is capped at `medium` until you confirm them.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years PM experience | must_have | adjacent | medium | transferability | Seven years of implementation and requirements work, with no PM title. Limit: roadmap input and delivery coordination, not owning prioritisation. Length is graded as a must-have, not a gate | `[grounded]` CV; `[inferred]` that this is the closest equivalent | Q2 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You shipped 30+ client integrations of a REST API to go-live. Limit: you did not own a product or its launch as a PM | `[grounded]` CV | Q2 |
| R3 | Technical fluency: API docs, schemas | important | direct | medium | none | Postman, SQL, OpenAPI, and integration architecture on 30+ projects. Expect a probe | `[grounded]` CV, unverified | Reference a schema or spec you wrote |
| R4 | Stakeholder management across engineering, sales, customers | important | direct | medium | none | Coordinated your engineers, client engineers and PMs. Sales coordination is not stated | `[grounded]` CV | Confirm sales involvement |
| R5 | Run discovery with integration partners | important | adjacent | medium | transferability | Quarterly roadmap-input sessions with clients. Limit: input collection, not discovery owned for the product | `[grounded]` CV | Q2 |
| R6 | Specs and delivery with engineering squads; agile | important | adjacent | medium | transferability | Requirements documents and go-live coordination. Agile practice not stated | `[grounded]` CV; agile absent | Confirm agile experience |
| R7 | Define and track adoption metrics | important | unclear | low | discovery | The CV is silent. Any adoption tracking would be an unconfirmed lead | `[grounded]` CV silence | Q3 |
| R8 | Launch coordination with sales and support | important | adjacent | medium | transferability | Go-live and UAT coordination. Support is not mentioned | `[grounded]` CV | Confirm support involvement |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Closure | Provenance |
|---|---|---|---|---|---|---|
| G1 | PM years and product ownership (R1, R2) | transferability | Strong implementation record; no PM title or product ownership | The two must-haves that set the decision | A confirmed example of a prioritisation decision you made | `[grounded]` CV; `[inferred]` that this is what the role tests |
| G2 | Adoption metrics (R7) | discovery | CV silent | An important row the posting names explicitly | A real adoption measure you tracked, with its source | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Quartzline … Series B" | Web checks did not run, so the employer is unverified. The posting may be stale, too new to have a footprint, or not a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Roadmap ownership without stated decision rights | unknown | — | "Own the roadmap for our partner-facing API platform" | Accountable for the roadmap while two squads and sales may hold the real decisions | `[inferred]` from the scope language against its silence on decision rights | Which roadmap decisions does this role make alone, and which go to engineering leadership or sales? | unresolved |
| RR3 | Compensation absent | unknown | — | JD gives no pay | The posting withholds pay; the band is unknown | `[grounded]` absence in the JD as pasted | What is the base salary range for this role? | unresolved |
| RR4 | Concrete scope | positive_signal | — | "define and track adoption metrics" | Success is measurable and the scope is defined | `[grounded]` JD | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the CV with the integration record, stated as you wrote it: "Led 30+ client integrations of our REST APIs end to end — scoping workshops, requirements documents, integration architecture, UAT, go-live" | R2, R3 | `[grounded]` your CV | pending your approval |
| A2 | Describe roadmap input as input: "Ran quarterly roadmap-input sessions collecting client feedback for product." Do not write "set the roadmap" or "owned" | R1, R5 | `[grounded]` your CV; the second wording would be verb drift | pending your approval |
| A3 | Do not add a product or PM title, or the triage tool, until you confirm them | R1, R2 | Memory lead, unconfirmed | pending your approval |
| A4 | Before applying, verify the posting on Quartzline's own careers page | RR1 | `[generic]` standard check | pending your approval |

## Evidence status

Verified: none yet. Your CV claims are unconfirmed.

Unverified lead: an internal request-triage tool that support agents adopted, from prior context. Not evidence, and it counts for nothing until you confirm it.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three search calls were refused by this session's permissions. It would have confirmed the employer and the posting, which resolves RR1 |
| 2. Role-family sweep | unavailable | Same refusal. It would have set the market calibration for scope and pay, which is missing from role reality and the RR3 comparison |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- A confirmed triage tool: what you built, who adopted it, and how you know they did → R1 and R2 move, possibly to `direct`, and it becomes the strongest product evidence you have.
- A sanitised integration spec, or a discovery readout you wrote → R3 to `high`, and R5 and R6 gain an artifact.
- Permission for web searches → RR1 resolves, and the market calibration line and RR3's comparison get filled.
- The posted pay and location → RR3 closes.

I can also write a `tuesday-dossier.md` from this map so your answers carry into the next turn. No pressure.

1. (R1, R2, memory lead, unconfirmed) Earlier context mentioned an internal request-triage tool that support agents adopted. Is that accurate? If so, what did you build, who adopted it, and what shows they did?
2. (R1, R5) Have you ever made a prioritisation call on what got built, such as a client's custom build, a feature request, or an internal tool? Name one, what you decided, who else had a say, and what happened.
3. (R7) Did you measure whether integrations succeeded after go-live, such as time to first call, client usage, or escalations? If so, what, and where did the numbers come from?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.