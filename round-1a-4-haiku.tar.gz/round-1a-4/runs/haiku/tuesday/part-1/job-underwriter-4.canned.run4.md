**Snapshot: yes, worth applying to, but hold until one question is answered. Status: `hold_pending_answers`.**

Your background fits the posting's requirements well. The open question is location. The posting says fully remote (UK), but the company's careers page says Leeds office four days a week. I can't resolve that from here, and it is a hard gate for you.

**Fit ledger.**

- `hard_gate`: unclear: R1 (location: fully remote UK, or Leeds four days a week)
- `must_have`: direct: R2, R3, R4, R5 and R6 (all five `must_have` rows: GLM, SQL and Python, price tests, presenting to underwriting leads, 4+ years)
- `important`: adjacent: R7 (pet-insurance pricing domain)
- `preferred`: direct: R8 (insurance experience)

R7 — motor pricing method carries over, the pet product itself does not yet.

**Opportunity ledger.** Sound, with one contradiction to resolve: the location terms conflict between the posting and the careers page (RR1). Salary is not stated (RR2). The posting names a funded company with a clear remit (RR3).

- **Hard gates:** unconfirmed: R1 (location: fully remote UK, or Leeds four days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** the awaited answer is R1. If the role is Leeds four days a week and that works for you, the status moves to `conditional_go`, with R7 and RR2 as conditions. If it is remote in fact, it moves to `go`. If you can't work Leeds, it becomes `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor: Leeds-based insurtech, founded 2019, Series B in May 2026, 143 staff; sells pet insurance through veterinary practices | `[grounded]` "About Brindlemoor" (brindlemoor.co.uk/about), search snippet only, not fetched |
| Mandate | Own pricing analytics for the pet-insurance product; reports to the Director of Pricing | `[grounded]` your JD; careers page (brindlemoor.co.uk/careers/senior-pricing-analyst, fetched) |
| Working pattern | Contradiction: JD says fully remote (UK); careers page says Leeds office four days a week | `[grounded]` both sources |
| Scope read | One product, a senior analyst reporting to a director: a normal scope for the title | `[inferred]` from the reporting line against the stated remit |
| Market calibration | Senior pricing analyst, UK insurers and insurtechs: median base £58,400, IQR £52,100–£64,900 | `[generic]` Pricewell 2026 pay survey (pricewell.example), search snippet only; the posting states no salary, so this is a band, not their offer |
| People management | Not in the posting; no management requirement | `[grounded]` JD |

## Evidence map

Confidence is capped at `medium` for everything you've told me, since none of it is inspected yet.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: fully remote UK vs Leeds four days a week | hard_gate | unclear | none | hard_gate | Posting conflicts with itself; you have not stated a location constraint | `[grounded]` JD and careers page | Answer the closing question on location |
| R2 | GLM rating models | must_have | direct | medium | none | Built and maintained the young-driver GLM. Self-reported | `[grounded]` your background | none |
| R3 | SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your background | none |
| R4 | Design and read price tests | must_have | direct | medium | none | 14 tests last year with underwriting, self-reported | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly review to the head of underwriting, self-reported | `[grounded]` your background | none |
| R6 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years, last 2 senior | `[grounded]` your background | none |
| R7 | Pet-insurance pricing domain | important | adjacent | medium | transferability | Motor pricing method transfers; no pet product experience | `[inferred]` from the JD's pet-product scope against your motor background | Bridge case below |
| R8 | Insurance experience | preferred | direct | medium | none | Motor insurer, 5 years | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance domain (R7) | transferability | Motor pricing only; no pet product | Adjacent, not direct; the interviewer will probe it | Any pricing work on a non-motor product; claims-frequency or severity analysis; a pricing review you ran for a different book | A sanitized pricing review or model summary | `[inferred]` transfer from motor; `[generic]` that interviewers probe product-domain gaps |

**The bridge case, with its limit:** your GLM, price-testing and monitoring method carries over. What it did not exercise is pet-specific risk and claims behaviour. Do not present it as pet experience.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location terms conflict | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | Terms may have changed, or the careers page may be stale | `[inferred]` from the two sources disagreeing | Is this role fully remote, or based in Leeds four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | (none in the posting) | The role may pay below the band, or the company may withhold pay | `[generic]` band from the survey snippet, against the posting's silence | What is the budgeted salary for this role? | unresolved |
| RR3 | Funded and staffed company | positive_signal | — | "Series B raised May 2026" (about page snippet) | Funding and headcount suggest a stable hiring base | `[grounded]` about page snippet | What does the pricing team look like today? | noted |

## Application plan (all proposed; nothing is sent or edited without your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter to confirm location terms before you invest in the application | see RR1, R1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the CV with the GLM monitoring and price-test results | The hiring manager spoke on monitoring rating models in small books; see the next row | `[grounded]` R2, R4 | pending your approval |
| P1 | State the pet-domain limit openly: method transfers, product does not | see R7 | `[grounded]` R7 | pending your approval |
| Q1 | Ask the salary question verbatim | see RR2 | `[grounded]` RR2 | pending your approval |

**Hiring manager's public footprint:** Odile Varga is Director of Pricing at Brindlemoor. They spoke at the 2025 Insurance Pricing Forum on monitoring rating models in small books, and previously led pricing analytics at Calloway Re for six years (linkedin.example profile, search snippet only). `[grounded]` that snippet. This is the reason E1 leads with monitoring.

## Evidence status

Verified: none yet. Everything above rests on your own description, which is CV-equivalent until you confirm specifics.

Research tier: L1 — searches 5 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor Senior Pricing Analyst careers" and "Brindlemoor pet insurance company UK"; fetched brindlemoor.co.uk/careers/senior-pricing-analyst. Moved RR1 (location conflict) and confirmed the employer exists (not failed attribution) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst insurance UK salary pricing analytics", which returned Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (pricewell.example), snippet only. Market calibration `[generic]` for RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned a public profile (linkedin.example), snippet only. Moved positioning for E1 |

**Not verified:** the about page, the LinkedIn profile and the survey were read from search snippets, not fetched. Confirm them before relying on the exact figures.

**Dossier offer:** I can write these findings to `tuesday-dossier.md` so they survive into later sessions, if you want that.

**Upgrade menu**

- Confirming your location constraint and whether Leeds four days a week works → R1 closes; the status moves to `go` or `no_go`
- Your other non-negotiables (pay floor, start date) → the hard-gate checks run against them; right now they are unknown
- Any pricing work beyond motor, even a side analysis → R7 moves from `adjacent` toward `direct`
- A deeper research pass on Brindlemoor (funding and leadership changes, staff reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs

**Questions**

1. R1: Is the role fully remote, or Leeds four days a week? If it is Leeds, can you work that pattern? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. G1: Have you done any pricing work on a non-motor product, even a side analysis? What did you own? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.