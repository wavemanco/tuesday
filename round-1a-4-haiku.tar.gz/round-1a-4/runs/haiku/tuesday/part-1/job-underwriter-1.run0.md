**Yes, apply once the posting checks out. Status: `conditional_go`.** On your own account you meet the core analytics requirements. The gaps are healthcare data, clinician partnership and mentoring, and nothing about Harborlight has been verified because web search was not permitted in this session.

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5 · adjacent: R7a (partner with PMs) · unclear: R6 (define and maintain the metrics layer) · absent: R7b (partner with clinicians)
- `important`: unclear: R8 (mentor two junior analysts)
- `preferred`: adjacent: R9 (healthcare data, HIPAA)

R1, R2, R3, R4 and R5 rest on your own account, with no artifact yet. R7a is the nearest bridge to PM partnership. R6 is a claim about governed dashboards, not about owning the metric definitions. R7b and R8 are not in your account. R9 is consent and PII work, with no HIPAA.

- **Hard gates:** none stated in the posting; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** the deliverables are concrete (RR3), but the employer is unverified (RR1) and pay is absent from the posting (RR2).
- **Conditions for go:** (1) the posting is confirmed on Harborlight's own careers site (RR1); (2) you state any non-negotiables so the gate checks can run (Q1); (3) metric-definition ownership (R6) and mentoring (R8) hold up in interviews.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` posting header; not verified, search refused |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, mentoring two junior analysts | `[grounded]` posting |
| Scope read | Senior analytics role with mentoring; whether that includes line management is unstated | `[inferred]` from the listed deliverables |
| Market calibration | Not run: the role-family search was refused, so there is no pay or scope band | — |
| Unknowns | Base pay and bonus, location and work pattern, share of work on clinical data, whether mentoring is management | — |
| Contradictions | None found within the posting text | `[grounded]` posting only |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years, stated in your account; not inspected | `[grounded]` your account | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake, self-reported | `[grounded]` your account | Redacted query sample would raise to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, including the pricing test; no readout attached | `[grounded]` your account | Redacted test readout would raise to high |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the instance and 40+ governed dashboards; self-reported | `[grounded]` your account | Dashboard screenshot would raise to high |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly exec memo and monthly VP Product presentation | `[grounded]` your account | Redacted memo would raise to high |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed" implies definitions; whether you set canonical definitions is not stated | `[inferred]` from the Looker claim | Q3 below |
| R7a | Partner with PMs on roadmap decisions | must_have | adjacent | medium | transferability | Analysis reaches roadmap through the VP Product presentation; day-to-day PM partnership not stated | `[grounded]` your account | Limit to name in interviews |
| R7b | Partner with clinicians | must_have | absent | none | transferability | No clinical stakeholders stated; nearest is non-analyst executive audiences | `[inferred]` | Any care-team collaboration would move it |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Not mentioned, so unknown rather than absent | `[grounded]` silence in your account | Q2 below |
| R9 | Healthcare data, HIPAA | preferred | adjacent | medium | transferability | GDPR/CCPA PII handling and a consent-state model; no HIPAA or PHI; consumer data, not regulated health data | `[inferred]` adjacency from your account | Name the limit plainly |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Closure | Provenance |
|---|---|---|---|---|---|---|
| G1 | Metric definitions (R6, must_have) | discovery | Governed dashboards, no ownership of definitions stated | Must-have row; the likeliest interview probe | Evidence of owning definitions: a metric dictionary or definition doc | `[inferred]` |
| G2 | Clinician partnership (R7b, must_have) | transferability | No clinical collaboration stated | Must-have row with no evidence | Any clinical or care-team work; otherwise state the limit | `[inferred]` |
| G3 | Mentoring (R8, important) | discovery | Not mentioned | Explicit in the posting | Any mentoring or onboarding of analysts | `[grounded]` posting |
| G4 | Healthcare data (R9, preferred) | transferability | Consent and PII work is the nearest bridge | Preferred, not a gate; it shapes the healthcare answer | Name the limit; a health-data course or project only if you have one | `[inferred]` |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health" (posting header) | Unverified, not refuted: no search ran. The posting may be stale, or the company may be newer or smaller than described | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Base pay not stated | unknown | — | No compensation line in the posting text | Pay may sit outside your expectations; the band could not be checked | `[grounded]` posting silence | What is the base salary range, and is there a bonus or equity component? | unresolved |
| RR3 | Deliverables named | positive_signal | — | "Own product analytics for the care-navigation app: define and maintain the metrics layer" | Concrete scope makes the role assessable | `[grounded]` posting wording | Which of these deliverables would I own in the first ninety days, and which sit with others? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Harborlight's careers site before investing in an application | RR1 | `[grounded]` RR1 | proposed |
| A2 | Lead with experimentation: "Designed and ran a 30+ test-a-year program, including the pricing test behind an 11% retention lift." | R3, your account | `[grounded]` your account | pending your approval |
| A3 | On healthcare: "My work is consumer PII and consent, not HIPAA. The nearest part is building a consent-state model." | R9 limit | `[grounded]` R9 | pending your approval |
| A4 | Ask the recruiter about mentoring scope and who sets metric definitions | R6, R8 | `[grounded]` G1, G3 | proposed |

**Evidence status**

Verified: none yet. Unverified leads: none. Rejected inferences: none. Stage: evaluating (assumed).

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches on Harborlight were refused, so nothing returned. They would have checked that the company exists as described and that the posting is live (RR1) |
| 2. Role-family sweep | unavailable | One search on senior product analyst pay and scope was refused. It would have set the market calibration and the pay band (RR2) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I did not retry the refused searches.

Dossier offer: I can write this up as a `tuesday-dossier.md` you can keep, if you want it.

**Upgrade menu**

- Permission to run web search → the L1 checks on Harborlight and the pay band; RR1 and RR2 can close.
- The careers-page link for this posting → RR1 closes, and the posting is checked against the JD.
- Your non-negotiables (pay floor, location or remote, start date, contract type) → the hard-gate checks run; today they are unknown.
- A redacted memo, query sample or test readout → R2, R3 and R5 move to `high`.
- Your CV → the map is rebuilt from the document rather than from this intake account.

1. Do you have non-negotiables for this role: a pay floor, location or remote terms, a start date, or a contract type? Without them the gate checks stay unknown. (no row yet)
2. G3 — Have you mentored or managed junior analysts? Who, for how long, and what did you own: reviews, hiring, career goals?
3. G1 — Did you set the canonical metric definitions for the subscription business, through a metric dictionary or semantic layer, or did you use definitions others set? If you set them, which ones, and how were disputes settled?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.