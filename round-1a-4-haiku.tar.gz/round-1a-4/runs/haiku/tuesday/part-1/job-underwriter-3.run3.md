**No — R1 (base pay) and R2 (on-site location) both fail your hard constraints. Status: `no_go`.**

**Fit ledger.**
- `hard_gate` — hard_gate_fail: R1 (base pay at or above $150k), R2 (on-site in Austin five days a week)
- `must_have` — direct: R3, R4a · unclear: R4b (SEO/content, brand, PR, partnerships, sales ops), R5 (thrive on ambiguity)

R1 and R2 — both gates fail as stated; R3 and R4a — direct on experience and on paid, lifecycle and experimentation work; R4b and R5 — the other channels and ambiguity, unclear.

**Opportunity ledger.** The posting's terms don't fit together: one owner for seven channels with no stated budget (RR1), an always-on norm (RR3), no defined success metric (RR4), and a base that tops out at $85k against your $150k floor (RR2).

- **Hard gates:** failed: R1 (base pay at or above $150k), R2 (on-site in Austin five days a week); unconfirmed: none; met: none
- **Severe red flags:** RR2 (`severity: high`)
- **What would change this:** both R1 and R2 would have to change, base at or above $150k and the role open to remote work from Portland. Fixing one leaves the other failed. Equity doesn't cure R1, because your floor is on base.

Research was refused in this session, so the employer, the live posting and the market band are unchecked. None of those can reopen the two gates.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, profitable since day one | `[grounded]` posting's own claims; not checked against the company's site |
| Mandate | Own all revenue growth: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin five days a week, no exceptions; evenings and weekends "when it matters" | `[grounded]` posting |
| Staffing | Team of one to start | `[grounded]` posting |
| Compensation | $70–85k base plus equity | `[grounded]` posting |
| Scope read | Seven channels, one person, no stated budget or headcount | `[inferred]` from the mandate list against the staffing line |
| Market calibration | Not run: the role-family sweep was refused, so there is no band for this title and seniority | — |
| Unknowns | Budget; decision rights; equity value; success metric; whether the base can move | — |
| Contradictions | 8+ years required, $70–85k base, and a team of one, as written, don't fit together | `[inferred]` from the posting's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay at or above $150k (your floor) | hard_gate | hard_gate_fail | high | hard_gate | Your floor is a stated, confirmed constraint. The posted base tops out at $85k. Equity can't stand in for base under this constraint | `[grounded]` posting pay line; your stated floor | none; only the employer changing its base resolves it |
| R2 | On-site in Austin five days a week (you are remote-only, in Portland) | hard_gate | hard_gate_fail | high | hard_gate | Posting says "no exceptions." Your constraint is stated and confirmed | `[grounded]` posting; your stated constraint | none; only the employer changing its terms resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then Head of Growth at two companies. Self-report at intake, no artifact yet. A length requirement, so it is graded on fit, not as a gate | `[grounded]` your account | none |
| R4a | Own paid acquisition, lifecycle/CRM and experimentation | must_have | direct | medium | none | You owned all three. Self-report, no artifact yet | `[grounded]` your account | none |
| R4b | Own SEO/content, brand, PR, partnerships and sales ops | must_have | unclear | none | discovery | Your profile is silent on all five | `[grounded]` profile silence | none while the decision stands |
| R5 | Thrive on ambiguity; success metrics will evolve | must_have | unclear | low | discovery | You scaled a company from $8M to $40M ARR with a budget you controlled. That is not the same as working where metrics are undefined | `[inferred]` from the scale record | none while the decision stands |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content, brand, PR, partnerships, sales ops (R4b) | discovery | Profile names paid, lifecycle and experimentation; nothing on these five | Would matter only if the gates opened. They don't | Any SEO or content program you ran, PR placement, a partner channel, sales-ops reporting you built | A program brief or plan you wrote | `[grounded]` profile silence |
| G2 | Thrive on ambiguity (R5) | discovery | Scale record with a budget you controlled; nothing on work with undefined metrics | Same as G1: doesn't reopen the decision | A launch where you set the baseline and the measures yourself | A plan or brief from that work | `[inferred]` from the scale record |

The queue holds no questions. Neither gap changes the decision, so asking would cost you a reply for nothing.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Responsibility without resources | risk_signal | medium | "Own all revenue growth end to end … You will be a team of one to start" | Accountable for seven channels with no team, budget or decision rights stated | `[inferred]` from the mandate against the staffing line and the silence on budget | What budget and headcount are committed to this role, and who approves spend? | unresolved |
| RR2 | Base pay conflicts with your floor | red_flag | high | "$70–85k base plus meaningful equity upside" | For you, a base that tops out at $85k is incompatible with a $150k floor | `[grounded]` posted figure against your stated floor | Is $70–85k the fixed base for this role, or is there room to move toward $150k? | confirmed |
| RR3 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Hours beyond the stated schedule are likely a norm, not an exception | `[grounded]` posting wording; the norm reading is `[inferred]` | How many evenings and weekends a month does this role typically take? | unresolved |
| RR4 | No success metric on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountable for revenue growth with no defined target | `[grounded]` posting; the reading is `[inferred]` | What revenue target is this role measured on in its first year, and who set it? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Don't apply as posted | R1 and R2 fail; effort here buys nothing | `[grounded]` R1, R2 | pending your approval |
| E2 | Check the posting on Novaline's own careers page yourself | The live posting and the employer were not checked here | `[grounded]` evidence status | pending your approval |
| E3 | If you want to test the terms: one written question to Novaline on whether the role can be remote from Portland and whether the base can reach $150k. Send nothing until you decide | The only route by which R1 or R2 could change | `[grounded]` RR2, R1, R2 | pending your approval |

## Evidence status

Verified: R1, R2 (your stated constraints, `high`). R3 and R4a are your account at intake and not yet backed by an artifact. R4b and R5 are unclear.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both search calls were refused by permission. The employer and the live posting were not checked. This would have moved the contradictions row and any employer-attribution check |
| 2. Role-family sweep | unavailable | Same refusal. This would have set the market calibration for the title and pay, which is currently not run |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

The dossier offer: if you want this kept, I can write it out as `tuesday-dossier.md`.

**Upgrade menu**
- The live posting link, or Novaline's careers page: confirms the employer and posting are live. It can't reopen R1 or R2.
- Permission to run search later: the market band for this title and seniority would size RR2 against the market. It would not reverse `no_go`.
- Novaline's written answer on remote work and base pay: the only input that could move R1 or R2. The "no exceptions" line makes that unlikely.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.