**Yes on fit, but hold before you apply.** Your evidence lines up with most of the must-haves. The posting contradicts itself on location, though, and that could fail a hard gate. Status: `hold_pending_answers`.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (fully remote UK, or Leeds four days a week)
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: direct: R7, R8a · unclear: R8b (recommendations to product)
- `preferred`: direct: R9 · adjacent: R10 (pet-insurance product)

R8b — product recommendations are not evidenced; R10 — motor rating-model work transfers, pet-specific drivers are not exercised; R1 — the location terms conflict.

**Opportunity ledger.** The role is well defined, but the location contradicts itself (RR1), pay is unstated (RR2), and the company's public footprint is thin (RR3). The hiring manager's public work points the same way as the role (RR5, positive). Authority over pricing changes is unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (fully remote UK against Leeds four days a week); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** the awaited answers are (1) where the role is based in practice (Q1 below), and (2) your pay floor against the market band (Q2). If the Leeds requirement is real and you can't do it, R1 becomes `hard_gate_fail` and the status becomes `no_go`. If it is fully remote, R1 closes and the status moves to `conditional_go`, conditional on RR4 and RR3 checking out in interviews.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, pet-insurance product; the careers page is live and accepting applications | `[grounded]` careers page fetched |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page, JD |
| Working pattern | Contradicted: JD says "fully remote (UK)"; careers page says "Leeds office four days a week" | `[grounded]` both sources |
| Scope read | Owns pricing analytics for one product; not unusually broad for the title | `[inferred]` from the JD's single-product scope |
| People management | Not in the JD. Nothing in the material says this role manages anyone, so your lack of management experience is not a gap here | `[grounded]` JD silence |
| Market calibration | Senior pricing analyst, UK insurers and insurtechs: median £58,400, interquartile range £52,100–£64,900 (n=612) | `[generic]` Pricewell 2026 pay survey, search snippet; a band, never this employer's offer |
| Salary | Not stated in the JD or on the careers page | `[grounded]` both sources |
| Unknowns | Location; salary; decision rights over rate changes; size of the pet book | — |
| Contradictions | Working pattern, as above | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote UK (JD) / Leeds four days a week (careers page) | hard_gate | unclear | none | hard_gate | No candidate constraint given, so nothing to grade. The sources conflict and the material doesn't settle it | `[grounded]` both sources | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years at a UK motor insurer, last two senior. Self-report, so the intake ceiling applies | `[grounded]` your intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Both used daily. Self-report | `[grounded]` your intake | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM. Self-report; a model file would raise it | `[grounded]` your intake | upgrade menu |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your intake | none |
| R6 | Build and monitor rating models | must_have | direct | medium | none | Built and maintained the model; monitoring specifics not stated | `[grounded]` your intake | none |
| R7 | Design and read price tests | important | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your intake | upgrade menu |
| R8a | Recommendations for underwriting | important | direct | medium | none | Quarterly review gives recommendations to underwriting | `[grounded]` your intake | none |
| R8b | Recommendations for product | important | unclear | low | discovery | Nothing in the material shows work with product | `[grounded]` silence | Q-level question held; gap G2 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurance pricing | `[grounded]` your intake | none |
| R10 | Pet-insurance product (implied by "our pet-insurance product") | preferred | adjacent | medium | transferability | Rating-model work carries over; pet-specific drivers (lifetime vs annual cover, breed-level claims) are not exercised | `[inferred]` from R4 and the JD's product name; `[generic]` that pet pricing has distinct drivers | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product (R10, preferred) | transferability | Motor pricing and rating models; nothing pet-specific | Preferred, not must-have, so a minor risk. A stated bridge narrows the objection | Any pet, travel or other short-tail pricing; claims-frequency work on a non-motor book; a rating-factor review | A sanitized rating-factor note or claims-analysis summary | `[inferred]` bridge from R4; `[generic]` that pet drivers differ |
| G2 | Recommendations for product (R8b, important) | discovery | Underwriting recommendations are evidenced; product ones are not | Would move R8b to direct | Pricing changes you proposed that product took up; launch or proposition decisions informed by a price test | A product brief or test readout you contributed to | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location contradicted | risk_signal | medium | "Fully remote (UK)" / "Leeds office four days a week" | The role may be hybrid with a Leeds presence, and the JD may be out of date | `[grounded]` both sources | Is this role based in Leeds four days a week, or fully remote as the posting says? | unresolved |
| RR2 | Salary not stated | unknown | — | (no figure in either source) | The budget may sit inside or below the band, or may not be published | `[inferred]` from the withheld figure against `[generic]` band | What salary is budgeted for this post? | unresolved |
| RR3 | Thin public footprint for the company | unknown | — | Company search returned no press or product results; only the careers page and the hiring manager's profile attribute the role | Small or young company; not a finding of concern | `[generic]` pattern for companies of this size | How many policies does this role's pricing cover, and what share of your book is it? | unresolved |
| RR4 | Authority over rate changes not stated | unknown | — | "Own pricing analytics" | The role may recommend rather than sign off pricing changes | `[inferred]` from the JD's scope against its silence on decision rights | Which pricing changes does this role decide alone, and which go through you? | unresolved |
| RR5 | Hiring manager's public work matches the role | positive_signal | — | Public talk, "Small Books, Loud Errors" (2025), on monitoring rating models in small books | Your monitoring experience is a relevant lead for this reader | `[grounded]` search snippet, not fetched | How do you decide when a rating model needs refitting in a small book? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter to confirm where the role is based before you invest in an application | R1, RR1 | `[grounded]` the two sources conflict | proposed |
| A2 | Lead with GLM ownership and the 14 price tests, stated as you did them | R4, R7 | `[grounded]` your intake | pending your approval |
| A3 | Position pet as transferable, not claimed | R10 | `[grounded]` no pet experience in your intake | pending your approval |
| A4 | Ask RR4 and RR2 verbatim in the first conversation | Decision rights and budget | `[grounded]` register | proposed |

## Evidence status

Verified: none yet. Every claim so far is your own word, not checked against an artifact.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor Senior Pricing Analyst pet insurance careers"; fetched brindlemoor.co.uk/careers/senior-pricing-analyst. Moved the working-pattern contradiction (RR1) and confirmed the role exists and reports to the Director of Pricing |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary GLM"; returned the Pricewell 2026 pay survey (pricewell.example/2026-uk-pricing-analytics-pay-survey), read as a snippet only. Moved the market band. The remit sweep was not run |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing insurance"; returned her public profile (linkedin.example/in/odile-varga), read as a snippet only. Moved the positioning lead (RR5) |

## Dossier offer

If you want this kept as a file, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- A sanitized GLM documentation sheet or model summary → R4 to `high`.
- A sanitized price-test readout → R7 to `high`.
- Confirmation of the working pattern from the recruiter → R1 closes, and the decision can move.
- Any pet-insurance exposure, or a pet pricing note → R10 moves toward direct.
- The budgeted salary → RR2 closes, and the figure is set against the band.
- A deeper research pass on Brindlemoor (funding, leadership, public candidate reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Q1 (R1).** Would you be able to work from Leeds four days a week, or do you need the role to be fully remote?
**Q2 (RR2).** What's your pay floor for this role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.