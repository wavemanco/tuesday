## Decision snapshot

**Yes, apply, once the posting checks out. `conditional_go`.** On the must-haves you are a direct fit: R1, R2, R3, R4, R6 and R9 are all `direct`. The open items are two scope questions about you (R5, R8) and whether the employer and posting are real.

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R6, R9
- `important`: adjacent: R7 · unclear: R5, R8
- `preferred`: adjacent: R10

R7 — a bridge to clinicians, its limit named; R10 — a bridge to HIPAA, its limit named; R5 and R8 — unclear, one question each would settle them.

**Opportunity ledger.** The posting is concrete about what the work is (dashboards, metrics, experiments, mentoring), but it leaves decision rights, pay, location and contract type unstated (RR2, RR3). The employer is also unverified (RR1), so the status caps at `conditional_go`.

- **Hard gates:** none stated in the posting; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears: the role is on Harborlight's own careers page; (2) R8 is answered, either with mentoring evidence or as a stated gap; (3) R10 is framed as consumer PII and consent work, never as healthcare data experience.
- **What would change this:** if the role is not on the company's own site, hold. If the pay, location or contract type conflicts with your constraints, that becomes a hard-gate check and could move the status.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health: digital-health scale-up, ~400 people, Series C, care-navigation app | `[grounded]` JD header as pasted; not checked (see Evidence status) |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, two junior analysts | `[grounded]` JD |
| Scope read | A senior individual-contributor role with a light people-lead element (mentoring two analysts) | `[inferred]` from the responsibility list |
| Market calibration | Not run: the salary sweep was refused, so there is no band to compare against | — |
| Unknowns | Pay, location and remote policy, contract type, reporting line, team size, decision rights over the roadmap, whether the metrics layer exists or is greenfield, how much PHI analysts touch | — |
| Contradictions | None visible, but only one source (the pasted JD) was available to check against | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company. The length is not a gate, so it is graded on fit. Intake prose caps at medium | `[grounded]` your statement | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" is the claim a probe will test; nothing inspectable yet | `[grounded]` your statement | sanitized query sample would raise to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, designed and run. The 11% retention lift needs its basis pinned (relative or absolute, window, metric) before you use it | `[grounded]` your statement | confirm the lift's basis and your role in design versus running it |
| R4 | Looker or similar BI, self-serve dashboards | must_have | direct | medium | none | Built the instance from scratch; 40+ governed dashboards | `[grounded]` your statement | scrubbed dashboard screenshot would raise to high |
| R5 | Define and maintain the metrics layer | important | unclear | low | discovery | "Governed dashboards" and the monthly memo imply metric definitions were set. Nothing says you owned the canonical definitions or where they live | `[inferred]` from "governed dashboards" | ask: who owned canonical definitions, and where did they live? |
| R6 | Partner with PMs to turn analysis into roadmap decisions | must_have | direct | medium | none | Presents monthly to the VP Product | `[grounded]` your statement | none |
| R7 | Partner with clinicians | important | adjacent | low | transferability | Work with non-technical executives is credible; clinicians are a different audience and you have not worked with them. Limit: no clinical contact | `[inferred]` adjacency from the exec memo | prepare the bridge and state the limit |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | No mentoring evidence in what you gave | — | ask whether you have mentored or managed analysts |
| R9 | Strong written communication for non-technical readers | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads | `[grounded]` your statement | none |
| R10 | Healthcare data (HIPAA), a plus | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII handling and a consent-state model are adjacent. Limit: no PHI, no HIPAA-covered work | `[grounded]` your statement; the adjacency is `[inferred]` | frame it as consent and PII work, never as healthcare data |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics ownership (R5, important) | discovery | Governed dashboards and the memo imply definitions were set; ownership is not stated | Decides whether R5 is a strength or a gap at a role that names it first | Setting a metric definition that finance or product used; a retention or subscriber definition you wrote into the warehouse; a LookML or dbt model you owned | A metric dictionary, a LookML file, a definitions doc | `[inferred]` that R5 is the one thing that could move the scope read |
| G2 | Mentoring (R8, important) | discovery | No evidence of mentoring or managing analysts | The role names it as a responsibility | Onboarding a new analyst; code or query review for a junior; owning a junior's work plan | None needed if the answer is no; say so | `[generic]` that senior loops probe mentoring directly |

The questions for G1 and G2 are in the closing block, tagged to their rows.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Research was refused, so this is unverified, not found missing | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Decision rights over the roadmap not stated | unknown | — | "define and maintain the metrics layer … turn analysis into roadmap decisions" | The role may own the metrics and the analysis but not the decisions they feed | `[inferred]` from the scope against its silence on decision rights | Which roadmap decisions does this role make itself, and which sit with PMs or clinical leads? | unresolved |
| RR3 | Pay, location and contract type not stated | unknown | — | Not in the posting | Could sit outside your constraints; cannot be checked yet | `[grounded]` absence in the JD | What is the base range, and is the role remote, hybrid or on-site? | unresolved |
| RR4 | Analysts may touch PHI | unknown | — | "healthcare data experience (HIPAA) a plus" | HIPAA-covered data may sit in the warehouse, which changes access and review | `[generic]` pattern for digital-health analytics | What patient-identifiable data can analysts query, and what approvals does a new analyst need? | unresolved |
| RR5 | Concrete scope with an existing team implied | positive_signal | — | "mentor two junior analysts" | A team exists to work with, so the role is not a one-person function | `[inferred]` from the mentoring line | How many analysts would I work alongside, and who leads them? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the posting on Harborlight's own careers page before you apply | RR1 | `[generic]` pattern | your check |
| A2 | Pin the 11% lift's basis: metric, relative or absolute, window, and your role | R3 | `[grounded]` your statement | your check |
| A3 | Describe PHI experience as "handled consumer PII under GDPR/CCPA and built the consent-state model", and say you have not worked with healthcare data | R10. Your own words, traced clause by clause; "healthcare data" is not in them | `[grounded]` your statement | pending your approval |
| A4 | Prepare one sentence on translating analysis for non-technical readers, and state that you have not worked with clinicians | R7, R9 | `[grounded]` R9; the limit is `[inferred]` | pending your approval |
| A5 | If you have mentored, bring a concrete example. If not, say so and describe how you would onboard two juniors | R8. Never invent mentoring | `[generic]` that senior loops ask this directly | your call |

## Evidence status

Verified: none yet. Everything above is your statement at intake, which is CV-equivalent: a lead to confirm, not proof.

Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | All three searches were refused, so the company and posting could not be checked. Would have moved RR1 and the role-reality contradictions row |
| 2. Role-family sweep | unavailable | Same refusal. Would have set a salary band for the market calibration line and the comparison for RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- The posting link from Harborlight's own careers page, or the recruiter's email domain → RR1 closes. If search is allowed, I can run the three searches and two fetches to check the company and the posting myself.
- Your constraints (location or remote, pay floor, contract type) → the hard-gate checks run; RR3 closes.
- A scrubbed experiment readout or dashboard screenshot → R3 and R4 move to `high`.
- A scrubbed SQL sample → R2 moves to `high`.
- Whether your analysts have a metric dictionary or LookML definitions → R5 resolves.

If you want to keep this, I can write it up as `tuesday-dossier.md` for later use.

1. Have you mentored or managed junior analysts? If yes: how many, for how long, and what did you own (hiring, reviews, their work plans)? If no, say so. (G2, R8)
2. Did you own the canonical metric definitions, such as retention or subscriber counts, and where did they live: LookML, dbt or the warehouse? (G1, R5)
3. What are your non-negotiables for this search: location or remote, pay floor, and contract type?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.