**Probably yes, but hold until two gate answers come back.** The core stack matches and the pay sits at market. Status: `hold_pending_answers`.

## Decision snapshot

**Worth applying to, once your location and pay floor are checked. Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (remote US or Denver location), R2 (base pay $148k–$166k against your floor)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (orchestration with Airflow), R7 (data quality testing)
- `important` — adjacent: R8 (BigQuery warehouse); unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R5 — dbt and Snowflake, direct; R8 (`medium`) — BigQuery is a bridge, its limit named; R1, R2 — the gates waiting on your answers.

**Opportunity ledger.** The company page shows Series C funding (RR4), and pay sits at the market median and above (see Role reality). The employer is not yet verified (RR1, `medium`), which caps any `go` at `conditional_go`. Equity, hiring manager and team are unknown (RR2, RR3).

- **Hard gates:** none failed (R1 and R2 both unconfirmed); unconfirmed: R1 (remote US or Denver location), R2 (base pay against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** answers to R1 and R2. A failed R1 or R2 makes it `no_go`. If the posting checks out on the employer's own careers site (RR1), the status moves to `go` once R1 and R2 pass.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 in 31 states, founded 2016, Denver, 264 employees, Series C $52M (Feb 2026) | `[grounded]` your pasted About page; not independently checked |
| Mandate | Build and run ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts rely on | `[grounded]` JD |
| Scope read | End-to-end ownership of one reporting platform, no direct reports stated | `[inferred]` from the JD's scope against the Senior norm |
| Market calibration | Senior Data Engineer at Series B–D: base median $151k, IQR $139k–$163.5k. Posted $148k–$166k: low end at median, high end above the IQR top | `[generic]` Datawright 2026 figures as you pasted them; `[grounded]` JD figure |
| Unknowns | Hiring manager, team size, equity value and vesting, whether the data contracts exist yet, whether the BigQuery stack is live or migrating | — |
| Contradictions | None found between the JD and the About page | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver office: your location and work status | hard_gate | unclear | none | hard_gate | Your location and work status aren't given, so the gate can't be checked | `[grounded]` JD location term | Q1 |
| R2 | Base pay $148k–$166k against your floor | hard_gate | unclear | none | hard_gate | No floor given | `[grounded]` JD; `[generic]` band | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; self-reported, no artifact yet | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use; self-reported | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of ~180 models on Snowflake. BigQuery is named in the description, not here (see R8) | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow; self-reported | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up a Great Expectations suite; the suite itself would be inspectable | `[grounded]` your background | suite excerpt would raise to `high` |
| R8 | BigQuery warehouse (in the JD description, not requirements) | important | adjacent | medium | transferability | dbt and modelling carry over; BigQuery's cost model, partitioning and tooling aren't exercised; you've never used it | `[inferred]` adjacency from R5 | G1 |
| R9 | Ingestion from the app and CRM | important | unclear | none | discovery | Your background is silent on ingestion | `[inferred]` from JD description | Q3 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Silent on producer–consumer contracts. Great Expectations checks quality, not contracts | `[inferred]` from JD description | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R8, important) | transferability | Snowflake dbt work on ~180 models; no BigQuery | The posting names BigQuery as the warehouse, so a stronger bridge narrows the likeliest objection | A cost, partitioning or performance decision on Snowflake; a warehouse migration | A sanitized model or cost note from Snowflake work; a short BigQuery project | `[inferred]` bridge from your dbt work; `[generic]` that BigQuery cost work is the likely probe |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning" (posting and About page) | May be too new or small for a public footprint, the posting may be stale, or it may not be a live hiring employer. This run could not check: web search was refused, so this is not a failed check | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Hiring manager and team not named | unknown | — | (absent from the posting) | Scope, team size and reporting line are unknown. `[generic]`: a posting with no named manager is common, not a claim about this employer | `[generic]` market pattern; `[grounded]` the posting's silence | Who would I report to, and how big is the data team? | unresolved |
| RR3 | Equity unquantified | unknown | — | "plus equity" | Total package can't be compared with the base alone | `[inferred]` from "plus equity" with no grant terms | How many shares does the grant represent, what is the vesting schedule, and what is the current price per share? | unresolved |
| RR4 | Funded data platform | positive_signal | — | "Series C ($52M, February 2026)" (About page) | Funding gives the data team a base to build on | `[grounded]` About page; not independently checked | How much of this round is planned for the data platform, and how many engineers will own pipelines? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Pellucid's own careers site, not via any link sent to you | Clears RR1's cap | `[grounded]` RR1 | pending your approval |
| A2 | Resume line: "Built and maintained a dbt project of ~180 models on Snowflake, orchestrated in Airflow, with a Great Expectations test suite." Every clause traces to your background | Leads with the direct matches | `[grounded]` R3–R7 | resume_edits_pending_approval |
| A3 | Interview line on BigQuery: "My dbt models and tests carry over; I haven't run BigQuery, and I'd learn its cost model first" | Makes the bridge and its limit explicit | `[inferred]` R8 | pending your approval |
| A4 | Ask Q1–Q3 before spending time on the loop | Gates first | `[grounded]` R1, R2, R9, R10 | pending your approval |

## Evidence status

Verified: none yet. R3–R7 rest on your background as written, which is self-report until probed. The claim "never used BigQuery" is yours and specific.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent ("Pellucid Learning live online tutoring K-12 Denver" and "Pellucid Learning Senior Data Engineer job posting"); both were refused permission. Would have moved RR1 and whether the posting is live |
| 2. Role-family sweep | skipped | Your pasted Datawright median, IQR and the posted range fix the calibration line. A search would only check their currency |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Allow web search, and I'll check the employer and posting live. That clears RR1's cap.
- A sanitized Great Expectations suite excerpt raises R7 to `high`.
- A BigQuery project or cost note turns R8 from a bridge into direct experience.
- The hiring manager's name would sharpen the scope read in Role reality.
- A deeper research pass on Pellucid (funding, leadership, past postings; up to 5 more searches and 2 more fetches) is available if you want it.

I can also write this analysis to `tuesday-dossier.md` so you can pick it up in a later session. Say the word.

1. **R1 — Where are you based, and can you work for a US employer without sponsorship?** The role is remote US or Denver.
2. **R2 — What base pay is your floor, and does a base near $148k meet it?**
3. **R9–R10 — Have you built ingestion from a product database or a CRM, or defined data contracts that analysts depended on? If so, what, and where?**

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.