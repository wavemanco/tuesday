**Worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1
- `must_have`: direct: R3, R4, R5, R6
- `important`: direct: R8 · adjacent: R9
- `preferred`: direct: R7

- **Hard gates:** none failed; unconfirmed: R1 (right to work and UK location, not stated in what you sent). Candidate constraints not given.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live and a salary band is known, RR1 and RR4; (2) you learn whether the role line-manages, RR3; (3) the motor-to-pet gap is named as a bridge, never as pet experience, R9.

Fit is strong on every must-have. The main unknown is pet insurance, which the JD doesn't list as a requirement. Confidence is `medium` across the board because everything rests on your CV. Nothing has been backed by an artifact yet.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech, pet insurance | `[grounded]` JD |
| Mandate | Own pricing analytics for the pet product; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | A senior IC-style pricing remit. The JD never mentions direct reports | `[inferred]` from the responsibilities and the silence on people management |
| Market calibration | Not checked. No research run | — |
| Unknowns | Salary, contract basis, direct reports, whether the posting is live | — |
| Contradictions | None within what you sent | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Right to work in the UK; UK location | hard_gate | unclear | low | hard_gate | Not in the material. Unchecked, not failed | `[grounded]` JD; your status not stated | Confirm |
| R3 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years at a UK motor insurer, last two senior | `[grounded]` CV, stated | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use | `[grounded]` CV, stated | none |
| R5 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM. The technique transfers; the motor rating factors don't | `[grounded]` CV, stated | A sanitized model-validation note would raise this to high |
| R6 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting, the JD's audience | `[grounded]` CV, stated | none |
| R7 | Insurance experience | preferred | direct | medium | none | UK motor insurer. The JD counts it as a plus | `[grounded]` CV, stated | none |
| R8 | Designing and reading price tests | important | direct | medium | none | Ran 14 tests last year with underwriting | `[grounded]` CV, stated | none |
| R9 | Pet-insurance product knowledge | important | adjacent | medium | transferability | Motor pricing mechanics carry over. Pet drivers (species and breed, age-related claims, vet cost inflation, lifetime versus annual cover, condition exclusions) don't, and are the ramp | `[inferred]` from your motor background against the pet product; `[generic]` for the pet drivers | See G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R9, important) | transferability | Motor pricing and GLM work, nothing pet-specific | The likeliest objection from a hiring manager at a pet insurer. A clear bridge narrows it | Any work on claims frequency or severity by segment, cover-tier design, or a book where the risk drivers differed from motor | A sanitized pricing note from any non-motor product, or a motor price-test write-up that shows segment-level reasoning | `[inferred]` bridge from your CV; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary not in the JD you pasted | unknown | — | none quoted | The posting may withhold it, or the paste dropped it | `[grounded]` absence in the JD | Is there a published band or a budgeted figure? | unresolved |
| RR2 | Contract basis not stated | unknown | — | none quoted | Could be permanent or fixed-term to a programme | `[grounded]` absence in the JD | Is this a permanent role? | unresolved |
| RR3 | Direct reports not stated | unknown | — | JD silent on people management | The role may line-manage analysts. You haven't managed anyone, so this matters | `[grounded]` absence in the JD | Does the role line-manage? | unresolved |
| RR4 | Employer and posting not checked | unknown | — | none | The posting may be stale or not live. Unverified, not failed | `[inferred]` no research run | Is there a live posting link or careers page? | unresolved |
| RR5 | Clear ownership and measurable responsibilities | positive_signal | — | "Own pricing analytics for our pet-insurance product" | The scope is defined, and it names the work you already do | `[grounded]` JD | Who currently owns the price-test roadmap? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the CV with the GLM build and the 14 price tests as outcome bullets, and say "motor" plainly | Matches R5 and R8 without claiming pet experience | `[grounded]` CV | pending your approval |
| A2 | Get the posting link and any salary band before a long application | RR1, RR4 | `[grounded]` RR1, RR4 | pending your approval |
| A3 | Name the motor-to-pet bridge in the cover note, with one concrete plan for learning pet drivers in the first 90 days | R9 is the likeliest objection | `[generic]` the usual objection for a cross-line hire | pending your approval |
| A4 | Have an answer ready on direct reports | RR3 | `[grounded]` RR3 | pending your approval |

## Evidence status

Research tier: L0, no searches. Nothing was checked online.

Stated, not verified: R3 to R8, all from your description. They're CV-level claims, so fit holds at `medium` until an artifact backs them. Unverified leads: none. Rejected inferences: none.

If you want, I can write this up as `tuesday-dossier.md` so a later interview-prep run can read it.

**Upgrade menu**

- The live posting link or the company careers page: checks RR4 and the scope.
- A published or budgeted salary: closes RR1.
- A sanitized model-validation note or price-test write-up: raises R5 and R8 to `high`.
- A research pass (up to 5 searches and 2 page fetches) to confirm the company and the market band for this seniority. Say the word and it runs.

**Questions**

1. (RR3) Does this role line-manage analysts?
2. (RR4, RR1) Can you share the posting link, so we can check it's live and whether a salary is listed?
3. (R1) Are you eligible to work in the UK without sponsorship?

Answer any of these, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.