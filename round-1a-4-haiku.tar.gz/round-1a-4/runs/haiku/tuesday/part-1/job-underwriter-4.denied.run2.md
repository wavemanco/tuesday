Yes, it's worth applying, on conditions. Status: `conditional_go`. Your stated record meets every must-have, and the gaps are pet-insurance experience and product-side recommendations. Three things about the role are unknown, and one gate is unconfirmed.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear R1 (Fully remote, UK-based)
- `must_have`: direct R2 (4+ years pricing analytics), R3 (SQL and Python), R4 (GLM experience), R5 (presenting to underwriting leads), R6 (build and monitor rating models), R7 (design and read price tests)
- `important`: direct R8a (recommendations to underwriting) · adjacent R10 (pet-insurance product) · unclear R8b (product recommendations)
- `preferred`: direct R9 (insurance experience)

R10 is a credible adjacency with its limit named. R8b has no evidence yet. R1 is the one gate, still unconfirmed.

**Opportunity ledger.** The posting is sound on its own terms but leaves three things unstated: line management (RR1), pay (RR2), and who signs off rating changes (RR3). The standing entry RR4 caps this at `conditional_go` until the posting is checked on the company's own site.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed; (2) RR4 cleared on Brindlemoor's own careers page; (3) RR1 and RR3 answered in interviews without contradiction; (4) R10 framed as adjacent, never as pet experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; existence not yet verified | `[grounded]` JD header; existence `[generic]` until checked (RR4) |
| Mandate | Own pricing analytics for a pet-insurance product; build and monitor rating models; design and read price tests; recommendations to underwriting and product | `[grounded]` JD |
| Seniority and location | Senior; fully remote, UK | `[grounded]` JD |
| Reporting line | Odile Varga, Director of Pricing | `[grounded]` JD |
| Scope read | "Own" analytics for one product suggests a single-owner remit | `[inferred]` from "own" against the JD's silence on team size |
| Market calibration | Not run; no pay or scope band available this session | — |
| Unknowns | Line management, pay, sign-off on rating changes, contract type | — |
| Contradictions | None visible in the one source supplied | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | none | hard_gate | Your residence and right to work aren't in your message. The UK motor employer is context, not an answer. | `[grounded]` JD location term | G3 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two senior. Self-reported, no CV yet. | `[grounded]` your background; intake ceiling `medium` | Upgrade menu |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported. No code sample yet. | `[grounded]` your background | Upgrade menu |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM for a young-driver motor book. | `[grounded]` your background | Upgrade menu |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting. | `[grounded]` your background | None |
| R6 | Build and monitor rating models | must_have | direct | medium | none | Built and maintained the model. How monitoring ran isn't stated. | `[grounded]` your background | Upgrade menu |
| R7 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team. | `[grounded]` your background | Upgrade menu |
| R8a | Recommendations to underwriting | important | direct | medium | none | Quarterly review plus test readouts to underwriting. | `[grounded]` your background | None |
| R8b | Recommendations to product | important | unclear | none | discovery | Nothing product-side in your background. The JD asks for both. | `[grounded]` JD; absence in your message | G1 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years UK motor pricing. | `[grounded]` your background | None |
| R10 | Pet-insurance product (named in the JD) | important | adjacent | medium | transferability | The motor rating method carries over. Pet specifics (species, breed, lifetime vs annual cover, vet-bill claims) are not exercised, and you have said you haven't worked on pet. | `[inferred]` requirement from the JD's product name; `[grounded]` your no-pet statement | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product-side recommendations (R8b, important) | discovery | Test results and underwriting recommendations are evidenced; product decisions (cover terms, excess, add-ons, eligibility) are not | The JD asks for product recommendations, so this is where the role's scope is most likely to reach past what you've done | Any test that changed a product term, or a product-team review you presented into | A test readout or product-review deck | `[grounded]` JD and your message |
| G2 | Pet-insurance product (R10, important) | transferability | Motor pricing is evidenced; pet is not | It is the most likely objection in interview | Vet-bill or claims-cost analysis; species or breed rating; lifetime-cover work; any non-motor product | A short note on how the GLM method maps to pet | `[inferred]` the likeliest objection; `[grounded]` your no-pet statement |
| G3 | UK residence and right to work (R1, hard_gate) | hard_gate | Not stated | A gate the material does not settle | None needed | None needed | `[grounded]` JD location term |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Line management not stated | unknown | — | "Senior Pricing Analyst" (no line-management line in the JD) | The role may expect people leadership you haven't done | `[inferred]` from the title against the JD's silence | Does this role line-manage anyone, and is people leadership expected in year one? | unresolved |
| RR2 | Pay not stated | unknown | — | No salary in the posting | The budget may be fixed and unpublished | `[inferred]` from the posting's silence | What is the budgeted salary for this role? | unresolved |
| RR3 | Sign-off on rating changes not stated | unknown | — | "Own pricing analytics for our pet-insurance product" | Owning analytics may stop short of signing off rate changes | `[inferred]` from "own analytics" against silence on sign-off | Who signs off rating changes: this role, underwriting, or a committee? | unresolved |
| RR4 | Employer not established | risk_signal | medium | "Brindlemoor (insurtech)" | Not checked: the search calls were refused, so the employer and the live posting are unconfirmed. Possible reasons, none ranked: the company is too new or small for a public footprint; the posting is stale or aggregated; the posting is not on the company's own site. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the live posting on your careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting on Brindlemoor's own careers page, and look up Odile Varga's public profile yourself | Search was refused; RR4 | `[grounded]` RR4 | proposed |
| A2 | Confirm R1 before applying | Hard gate, unconfirmed | `[grounded]` JD location term | proposed |
| E1 | CV line, in your own words: "Built and maintained the GLM rating model for the young-driver book" | R4 | `[grounded]` your message | resume_edits_pending_approval |
| E2 | For pet: "motor GLM method; pet-specific work not yet done" rather than implying pet experience | R10 | `[grounded]` your statement; reframing audit | pending your approval |
| A3 | Ask RR1, RR2 and RR3 verbatim in the first interview | The register doubles as interview prep | `[grounded]` register | proposed |

## Evidence status

Verified: none yet. Your claims are intake prose, which counts as CV-equivalent until you answer a specific probe or send a document.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would have confirmed Brindlemoor exists as described and the posting is live (RR4). Three search calls were refused, so nothing was checked. |
| 2. Role-family sweep | unavailable | Would have set a pay and scope band for senior pricing analysts (RR2 and the market calibration line). Refused. |
| 3. Hiring manager's public footprint | unavailable | Name given: Odile Varga, Director of Pricing. Would have informed positioning for her. Not searched. |

I'll stop searching for this session. Once you can grant search, targets 1 to 3 are the first thing to run.

I can write this up as a `tuesday-dossier.md` file whenever you want to keep it.

**Upgrade menu**

- A CV, or an anonymised artifact (model documentation, a test readout slide, a SQL or Python sample) → R2 through R7 move from `medium` toward `high`.
- Confirmed exposure to vet-bill, species or lifetime-cover data → R10 moves toward `direct`.
- The live posting link → RR4 closes.
- The budgeted salary, from the employer → RR2 closes.
- Search permission → targets 1 to 3 run, which settles RR4 and gives a pay band.

**Questions**

G3 — Are you based in the UK, with the right to work here without sponsorship?

G1 — Have you ever turned a price-test result into a product decision (cover terms, excess, add-ons, eligibility), not just an underwriting one? What did you own?

G2 — Have you worked on any non-motor data, such as vet bills, species or breed rating, or lifetime-cover claims? A side analysis counts.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.