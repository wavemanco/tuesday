**No, you're not wasting your time on the substance. `conditional_go`**, with one must-have that could end it before a conversation: R1a, titled PM experience, is absent.

**Fit ledger.**

- `must_have`: direct: R3 (technical fluency), R4 (stakeholder management) · adjacent: R1b (3+ years PM experience, done without the title), R2 (shipped API or platform products), R5 (write specs, drive delivery with two engineering squads), R7 (own the roadmap) · unclear: R6 (agile delivery experience) · absent: R1a (3+ years PM experience, titled)
- `important`: direct: R10 (run discovery with integration partners) · adjacent: R9 (coordinate launches with sales and support) · unclear: R8 (define and track adoption metrics)

R1a `absent` — no PM title in any role; R3 (`medium`) — tool-level fluency is stated, schema depth is not yet.

**How the 3+ years must-have is handled.** It is a length-of-experience requirement, not a gate, so it is graded like the others, split into R1a (the title) and R1b (the work). It cannot by itself set `no_go`. It does sit on the must-have tier, and a literal screen on it is the risk (RR2).

**Opportunity ledger.** The posting is specific about scope and first outcomes (RR4, `positive_signal`). Decision rights, pay, location and working pattern are not stated (RR1, RR3). RR2 is the one risk signal: a literal screen on the titled years.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this (conditions for go):** (1) R1a: the employer reads product-adjacent work against the 3+ years line (RR2); (2) R6 and R8 come back direct in the first conversation; (3) you confirm the posting on Quartzline's own careers page, since research did not run.

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics tech, ~150 people, Series B | `[grounded]` JD header, as you gave it |
| Mandate | Own the roadmap for the partner-facing API platform | `[grounded]` JD |
| Scope read | One platform, two engineering squads, launches and metrics: a full product-owner remit, not a single programme | `[inferred]` from the responsibilities list |
| Market calibration | Not run: the role-family search was refused | — |
| Unknowns | Decision rights over priorities, pay, location, schedule, whether squads run agile | — |
| Contradictions | None found in the material you gave; no outside check ran | — |

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years PM experience, titled | must_have | absent | none | transferability | No PM title in any role. The bridge is R1b | `[grounded]` intake: "never held a PM title" | Q1 |
| R1b | 3+ years PM experience, done without the title | must_have | adjacent | medium | transferability | Roadmap-input sessions, requirements docs, coordinating PMs on builds. Limit: inputs and delivery, not priority decisions | `[grounded]` intake, self-report, medium ceiling | Q1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST API integrations taken end to end on your employer's platform. Limit: you shipped integrations, not the platform | `[grounded]` intake | Upgrade: a go-live plan you wrote |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading, integration architecture. Schema design depth not stated | `[grounded]` intake | Upgrade: a schema or OpenAPI doc you wrote |
| R4 | Stakeholder management: engineering, sales, customers | must_have | direct | medium | none | Engineers, client engineers, PMs and quarterly client sessions are stated. Sales is not | `[grounded]` intake | None |
| R5 | Write specs, drive delivery with two engineering squads | must_have | adjacent | medium | transferability | Requirements docs and coordination on builds are stated. Running squads is not | `[grounded]` intake | Upgrade: a sanitized requirements doc |
| R6 | Agile delivery experience | must_have | unclear | none | discovery | Not mentioned in the material | `[grounded]` absence in intake | Upgrade: how delivery ran (sprints, cadence) |
| R7 | Own the roadmap for the platform | must_have | adjacent | medium | transferability | Quarterly sessions gathered client feedback for product. You did not set the roadmap | `[grounded]` intake | None |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | Not stated. The only lead is an unconfirmed note of a request-triage tool, a basis for a question, not evidence | `[grounded]` absence; memory lead | Q2 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-live and UAT coordination, and a team integration playbook. Sales and support launch work not stated | `[grounded]` intake | None |
| R10 | Run discovery with integration partners | important | direct | medium | none | Scoping workshops and client requirements work. The limit (one deployment's scope, not a platform's roadmap) sits in R7 | `[grounded]` intake | None |

**Gap recovery queue.** No questions here; the closing block asks them.

| # | Gap (req) | Type | What closes it | Provenance |
|---|---|---|---|---|
| G1 | Titled PM years (R1a) | transferability | Whether any PM responsibility was yours in practice, and the evidence for it | `[inferred]` bridge from R1b |
| G2 | Squad delivery and agile (R5, R6) | transferability / discovery | One sanitized requirements doc and a description of how delivery ran | `[grounded]` rows R5, R6 |
| G3 | Adoption metrics (R8) | discovery | Whether the triage tool exists and what its adoption was measured by | `[grounded]` memory lead, unconfirmed |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Roadmap ownership without stated decision rights | unknown | — | "Own the roadmap for our partner-facing API platform" | Accountability may sit without authority over engineering or sales priorities | `[inferred]` from the JD's silence on decision rights | Which roadmap decisions does this role make alone, and which go to engineering or sales leadership? | unresolved |
| RR2 | Must-have titled years may be screened literally | risk_signal | medium | "3+ years product management experience (must-have)" | Application may stop at the screen before the adjacent work is read | `[generic]` pattern for PM hiring; not a claim about this employer | Would a candidate whose PM work came from implementation roles be considered against the 3+ years line, and what would you need to see? | unresolved |
| RR3 | Pay, location, schedule not stated | unknown | — | Not stated | Could be a withheld figure or a normal posting | `[inferred]` from silence | What are the pay range, location and working pattern? | unresolved |
| RR4 | Concrete scope and outcomes | positive_signal | — | "Launches with sales and support" | The role is defined enough to assess | `[grounded]` JD | — | noted |

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line: "Led scoping workshops for 30+ client REST API integrations" (your words, "scoping workshops" and "30+ client integrations" as written) | R10 presentation | `[grounded]` intake | resume_edits_pending_approval |
| A1 | Ask the employer how the 3+ years line is screened before a long application | RR2 | `[grounded]` RR2 | pending your approval |
| A2 | Confirm the posting on Quartzline's careers page | Research did not run | `[grounded]` posting provided | pending your approval |

**Evidence status.** Verified: none yet. Unverified lead: the triage tool (memory lead, R8). Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for Quartzline's profile and this posting were refused. Posting status and company stage stay unverified |
| 2. Role-family sweep | unavailable | The search for PM-platform norms on titled years was refused; no market calibration |
| 3. Hiring manager's public footprint | n/a | No name was given |

I did not retry the refused searches.

If you want a permanent copy, I can write this to `tuesday-dossier.md`, so the map and questions travel with you.

**Upgrade menu.**
- Quartzline's careers link or this posting's URL → verifies R-level company facts and clears the posting check.
- Permission for web search → runs targets 1 and 2 and calibrates the titled-years screen.
- A sanitized requirements doc or go-live plan you wrote → R2 and R5 move toward `high`.
- A description of how sprints and squads ran → R6 moves from `unclear`.
- Pay floor, location, work pattern → the hard-gate checks run.

**Questions.**
- **R1a** — Did any role give you PM responsibility in practice, even without the title: setting priorities, deciding what not to build, answering for outcomes?
- **G3 (R8)** — I have an unconfirmed note that you may have built an internal request-triage tool that support agents adopted. Is that right? If so, what did adoption look like, and what did you measure?
- **Constraints** — What are your hard constraints: pay floor, location or work pattern, and contract type?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.