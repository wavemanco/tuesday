## Decision snapshot

Not a waste of time in general, but applying to this posting as your resume stands is a weak bet. Its first must-have asks for 3+ years of product management, and the resume shows none. Your product-adjacent work is real and closer to the role than that headline suggests.

**Status: `hold_pending_answers`.** Three answers, listed under "What would change this," would move it to `conditional_go` or `no_go`.

**Fit ledger.**

- `must_have` — direct: R3, R4 · adjacent: R1b, R2, R5 · absent: R1a
- `important` — direct: R9 · adjacent: R7 · unclear: R6, R8

R1a — titled PM years (`absent`): no reframing closes this; it is a capability gap on the titled bar. R1b and R2 — product-scope work and shipped-API work (`adjacent`): real, with limits named in the map. R4 — discovery (`direct`): the work is already yours, and the CV just doesn't call it discovery.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity side:** unverified, not negative. The posting withholds pay and location, and research could not run to check the employer (RR1, RR5). RR2 is the entry that decides the application: if the titled-years bar is strict, this is a `no_go`; if it is negotiable, the status moves toward `conditional_go`.
- **What would change this:** (1) the recruiter's answer on RR2; (2) Q1 — whether you ever made scope calls that shipped (would move R1b and R2 up); (3) Q2 — whether you tracked adoption (R8). Without those, my read is no-go on the posting as written.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` your paste |
| Mandate | Own the roadmap for a partner-facing API platform; discovery with integration partners; specs and delivery with two engineering squads; adoption metrics; launch coordination with sales and support | `[grounded]` JD |
| Scope read | Broad for a PM at a company this size: roadmap, two squads, metrics and launches in one role | `[inferred]` from the JD's scope list |
| Market calibration | Not run; no search was available, so no band for this title, bar or pay | — |
| Unknowns | Pay; location; contract type; who ranks sales requests against partner requests; what authority the role holds over the two squads | — |
| Contradictions | None in the material you gave | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years of product management, titled | must_have | absent | medium | capability | You state you have never held a PM title. A claim about your history, so `medium` at intake. No repositioning closes a titled-years gap | `[grounded]` your statement | Closure path, see G1 |
| R1b | Product-scope years: shaping what a product does | must_have | adjacent | medium | transferability | Roadmap-input sessions and requirements documents for 30+ integrations. Limit: input, not decisions. No evidence you prioritized or signed off a roadmap or owned a backlog | `[grounded]` CV; `[inferred]` adjacency | Q1 |
| R2 | Shipped an API or platform product | must_have | adjacent | medium | transferability | You delivered 30+ REST API integrations end to end, as the implementer of a vendor's API. Limit: you did not shape the API surface, versioning or release | `[grounded]` CV; `[inferred]` adjacency | Q1 |
| R3 | Technical fluency: API docs and schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading and integration architecture are on the CV. No inspectable artifact yet, so expect a schema probe | `[grounded]` CV | Offer: a redacted OpenAPI review or Postman collection raises to `high` |
| R4 | Run discovery with integration partners | must_have | direct | medium | presentation | Scoping workshops and roadmap-input sessions with clients are discovery in substance. The CV calls them scoping, not discovery | `[grounded]` CV | E1 |
| R5 | Write specs and drive delivery with engineering squads | must_have | adjacent | medium | transferability | Requirements documents; coordinated engineers across vendor, client and PMs on custom builds. Limit: no squad-level ownership or backlog | `[grounded]` CV; `[inferred]` adjacency | Q1 |
| R6 | Agile delivery experience | important | unclear | low | discovery | The CV is silent on cadence. Implementation work may have run in sprints or not | `[grounded]` CV silence | Q3 |
| R7 | Stakeholder management: engineering, sales, customers | important | adjacent | medium | transferability | Strong with engineering and customers. Sales-facing work is not on the CV | `[grounded]` CV; `[inferred]` adjacency | Add sales-facing work if you have it |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | No metric ownership on the CV. Any adoption tracking is unconfirmed; see the memory lead in Evidence status | `[grounded]` CV silence | Q2 |
| R9 | Coordinate launches with sales and support | important | direct | medium | presentation | You led go-live and UAT end to end on 30+ integrations. Support hand-off is not stated | `[grounded]` CV | E1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Titled PM years (R1a, must_have) | capability | No PM title, and no credible direct evidence. Nothing on the CV closes this | It is the first must-have and the one a screen reads literally | Product-owner or PM-scoped work with decision rights, at a company that would take you into a PM title | An offer or role description showing decision rights | `[grounded]` your statement; `[generic]` that titled-years bars are commonly read literally |
| G2 | Shipped product and product decisions (R1b, R2, R5) | transferability | Integration delivery and input to product; no shipped scope decisions on record | Adjacency is the case you can make, and its limit is the objection | A feature or API change you asked for that shipped; scope you cut or chose | A release note, a change log, a roadmap page | `[inferred]` bridge from the CV; `[generic]` that this is the likeliest objection |
| G3 | Adoption metrics (R8) | discovery | No tracking or ownership on the CV | An important row with a verifiable answer either way | Usage tracking on an integration or the playbook; any internal tool | A dashboard or usage export | `[grounded]` CV silence |
| G4 | Agile cadence (R6) | discovery | Cadence not stated | Important for two squads | Sprint work, backlog ownership, or milestone gates | A sprint board or a delivery plan | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not yet verified | unknown | — | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The posting may be stale, or not on the company's own careers page | `[grounded]` the posting names Quartzline; nothing checked, since research did not run | Can you point me to this role on Quartzline's own careers page, and who would I interview with? | unresolved |
| RR2 | Titled-years must-have | risk_signal | medium | "3+ years product management experience (must-have)" | The bar may be screened literally, so the adjacent case is never read | `[generic]` pattern for experience bars in product hiring, not a claim about this employer | Would you consider a candidate with product-scope work and no PM title, and what would they need to show? | unresolved |
| RR3 | Decision rights unstated | unknown | — | "Own the roadmap… drive delivery with two engineering squads" | Owning a roadmap may not come with authority over competing sales and partner requests | `[inferred]` from owning the roadmap against silence on who ranks requests | Who makes the final call between sales requests and partner requests, and what authority does this role hold over the two squads? | unresolved |
| RR4 | Scope is concrete | positive_signal | — | "run discovery… write specs… define and track adoption metrics; coordinate launches" | Named outputs make success checkable | `[grounded]` the posting lists concrete outputs | What adoption figure would count as success at six months? | noted |
| RR5 | Pay and location withheld | unknown | — | Not stated in the posting | Pay and location could sit outside your terms | `[grounded]` the posting's silence | What is the base salary range and the work location? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Rewrite the CV line "Led 30+ client integrations of our REST APIs end to end" to lead with the discovery work: "Ran scoping workshops and requirements documents for 30+ client REST API integrations, end to end." Every clause traces to your CV; no outcome or ownership is added | Presents R4 and R9 as the evidence they are | `[grounded]` CV sentences | `resume_edits_pending_approval` |
| E2 | Hold the cover letter until Q1 is answered. Do not describe yourself as a product manager, and do not describe product input as product decisions | The gap is R1a; a title claim is the one thing an interviewer checks first | `[grounded]` R1a and R1b rows | Your call |
| A1 | Ask the recruiter RR2 and RR5 before you spend effort on the application | Decides whether the hold becomes a conditional go or a no-go | `[grounded]` RR2, RR5 | Your call; pending your approval if sent |
| A2 | Find the posting on Quartzline's careers page yourself | Verifies RR1; research could not run | `[grounded]` RR1 | Your call |
| A3 | If RR2 is strict, aim at product-scope roles that do not carry a titled bar | That is the closure path for G1 | `[generic]` a pattern about hiring bars, not a claim about Quartzline | Your call |

## Evidence status

Verified: none yet. Your CV claims are self-report and remain leads until you confirm them with specifics.

Unverified leads: an earlier conversation's memory note that you once built an internal request-triage tool that support agents adopted. It is unconfirmed and cannot be cited as evidence; Q2 asks about it.

Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search sent for "Quartzline logistics API platform Series B"; refused, as the session has no search permission. Would have moved RR1 and whether the posting is live |
| 2. Role-family sweep | unavailable | Search sent for the role profile and salary; refused. Would have set the market calibration for this title, the typical titled-years bar, and the pay band |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Quartzline's careers-page link for this role → verifies RR1 and clears the employer check.
- Search access, which this session denied → runs targets 1 and 2: the employer's footprint and the market band for this title, bar and pay.
- The pay range, location and contract type → checks any constraints you hold, and calibrates pay.
- A redacted integration playbook, API spec or Postman collection you wrote → raises R3 to `high`, and gives R2 and R4 an inspectable artifact.
- A sprint board or delivery plan → R6.
- Deeper research on Quartzline (funding, leadership, public candidate reports; up to 5 more searches and 2 more fetches). I'll run it once search is on and you say so.

I can also emit this analysis as a `tuesday-dossier.md` so it carries into later sessions.

Q1 (R1b, R2, R5): Did you ever decide what an integration or API change would include, or choose between competing partner requests, with that choice shipping? If your part was input only, say so; it changes the read.

Q2 (R8): I have an unconfirmed note from an earlier conversation that you built an internal request-triage tool that support agents adopted. Is that right? If so, what did you own, and did you measure whether people kept using it?

Q3 (R6): How did your implementation work run day to day: sprints with an engineering team, a backlog you maintained, or milestone gates?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.