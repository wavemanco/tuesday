**Yes, worth applying, on conditions: `conditional_go`.** R3–R7 are `direct` against the stack you already run, and R8 (BigQuery) is the one real stack gap. Two hard gates are unconfirmed, and the employer has not been checked.

**Fit ledger.**

- `hard_gate` — unclear: R1 (US-based, for remote or Denver), R2 (base pay against your floor)
- `must_have` — direct: R3 (dbt and a cloud warehouse), R4 (strong SQL and Python), R5 (Airflow or similar), R6 (data quality testing), R7 (5+ years data engineering) · adjacent: R8 (the BigQuery warehouse)
- `important` — unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R8 — Snowflake dbt transfers, BigQuery is untested; R9, R10 — no evidence in what you've given me yet.

**Opportunity ledger.** The posting is clear and its pay sits inside the role-family band (RR5). Three things stay open: the employer and posting are unverified (RR1), equity is unstated (RR2), and scope looks wider than a typical senior role (RR3, low).

- **Hard gates:** none failed; unconfirmed: R1 (US-based, for remote or Denver), R2 (base pay against your floor); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the posting is confirmed live on Pellucid's own careers page (RR1); (2) you can work from the US and the base clears your floor (R1, R2); (3) you can speak to ingestion or data-contract ownership, or you accept that as a gap (R9, R10).
- **What would change this:** if you are not US-based, it's `no_go`, since the posting is US-remote or Denver only. If the posting doesn't verify, hold the application effort.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C, $52M, Feb 2026 | `[grounded]` your paste of their About page; not checked live |
| Mandate | Build and run ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and analyst-facing data contracts | `[grounded]` JD |
| Pay | Posted $148,000–$166,000 plus equity. Midpoint $157,000 sits above the $151,000 median and inside the $139,000–$163,500 interquartile range | `[generic]` Datawright 2026, US, n=2,310, Senior at Series B–D, as you quoted it; not this employer's offer |
| Seniority | "5+ years" sits inside Datawright's 5–8 year definition of Senior | `[generic]` same report |
| Scope read | Spans ingestion, warehouse and contracts. Datawright's typical Senior scope is one domain's pipelines with no direct reports | `[inferred]` from the JD against `[generic]` norm |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Unknowns | Equity size and vesting; team and reporting line; hiring manager (not named); whether "plus equity" is the only non-base pay | — |
| Contradictions | None found between the JD and your paste. The live-site comparison did not run | `[grounded]` as far as your paste goes |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work from the US (remote) or Denver | hard_gate | unclear | none | hard_gate | No location stated; the posting's gate is not settled by anything you've given | `[grounded]` JD | Q1 |
| R2 | Base pay against your floor ($148k–$166k posted) | hard_gate | unclear | none | hard_gate | No floor stated; posted band is `[grounded]` and sits in the `[generic]` band | `[grounded]` JD; `[generic]` band | Q1 |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | ~180 dbt models on Snowflake, self-reported; claim is confirmed prose, no artifact | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your background | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow orchestration, self-reported | `[grounded]` your background | none |
| R6 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, self-reported | `[grounded]` your background | none |
| R7 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company | `[grounded]` your background | none |
| R8 | The dbt-modelled warehouse in BigQuery (named in the JD's duties) | must_have | adjacent | medium | transferability | Snowflake dbt carries over; BigQuery's cost model, partitioning and IAM are unexercised | `[inferred]` from the Snowflake work; `[generic]` on what BigQuery adds | G1 |
| R9 | Ingestion from the product app and the CRM | important | unclear | low | discovery | Pipelines are described but no source systems are named | `[grounded]` absence in your background | Q3 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Not mentioned; a test suite is not a contract | `[grounded]` absence in your background | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, must_have) | transferability | Snowflake dbt at ~180 models; no BigQuery | The JD names it as the warehouse; a stronger bridge narrows the objection | Any dbt project you've ported across platforms; BigQuery sandbox work; a GCP certification in progress | A BigQuery model in a repo, or a sandbox project link | `[inferred]` bridge; `[generic]` that BigQuery is the likeliest interview probe |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Pipelines described, sources not named | JD lists it as core work | A sync from a product database; a CRM extract (Salesforce, HubSpot) you owned | A pipeline diagram or DAG list | `[grounded]` silence in your background |
| G3 | Data contracts (R10, important) | discovery | Test suite only | JD names it as something analysts rely on | A schema or freshness promise downstream teams used; a contract doc | A contract file or a stakeholder thread | `[grounded]` silence in your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | risk_signal | medium | "Remote (US) or our Denver office" | Possibilities side by side, none ranked: too new or small for a footprint; a stale or aggregated posting; not a real hiring employer. The outside check did not run | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Equity unstated | unknown | — | "plus equity" | Could be meaningful or token; the posting gives no basis to tell | `[grounded]` JD silence | What's the equity grant size, vesting schedule, and latest valuation? | unresolved |
| RR3 | Scope wider than a typical Senior | risk_signal | low | "Build and run the pipelines behind our tutoring platform's reporting" | Ownership may be broader than one domain, with less support | `[generic]` Datawright's typical Senior scope, against `[inferred]` from the JD's scope | Who else owns ingestion and the contracts, and how big is the team around this role? | unresolved |
| RR4 | Hiring manager not named | unknown | — | (no name in the posting) | Could be normal for this employer; nothing settles it | `[grounded]` JD silence | Who is the hiring manager, and which analysts does this role serve? | unresolved |
| RR5 | Pay stated and inside the role-family band | positive_signal | — | "$148,000–$166,000 plus equity" | Transparent pay with a realistic range | `[grounded]` JD; `[generic]` band | Is $148,000–$166,000 base before bonus, and is it the budgeted band? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the posting on Pellucid's own careers site before applying | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the recruiter for the location expectation and the budgeted band | R1, R2, RR5 | `[grounded]` gate rows | pending your approval |
| L1 | Frame the Snowflake work as the source of the dbt skill, and BigQuery as adjacent: "Built and maintained a dbt project of ~180 models on Snowflake." Proposed; it claims only what you've said | R3, R8 | `[grounded]` your sentence; positioning advice | pending your approval |
| L2 | Name the BigQuery gap yourself and pair it with a closure plan (a sandbox model) | R8, G1 | `[inferred]` bridge | pending your approval |

## Evidence status

Verified: none yet. Every claim so far is self-report at `medium` or lower.

Research tier: L1 — searches 1 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused (permission not granted), so the posting and company facts are not checked against the live site. It would have moved RR1 |
| 2. Role-family sweep | skipped | Your message supplies the report's figures (median, interquartile range, the Senior definition, typical scope), so the band is fixed by inputs |
| 3. Hiring manager's public footprint | n/a | No name given, so there is no query to form |

The one search I sent was refused, so the employer check is unverified. Until it runs, the standing entry RR1 caps the decision at `conditional_go`.

The dossier offer: I can write this assessment to a `tuesday-dossier.md` file if you want to keep it.

**Upgrade menu**

- Permission to run the employer check (one search on Pellucid's careers page) → RR1 moves from unverified to confirmed or not established, and can lift the `conditional_go` cap
- A link to the live posting → the same check, without a search
- Your location and pay floor → R1 and R2 close; the status becomes `go` or `no_go`
- A CRM sync or a data-contract example you built → R9 or R10 moves up from `unclear`
- A BigQuery sandbox project or model link → R8 moves toward `direct`
- The equity grant details → RR2 closes
- A deeper research pass on Pellucid (funding, leadership changes, reviews; up to 5 more searches and 2 more fetches). Say the word and it runs

**Questions**

Q1 — R1 and R2: Are you able to work from the US (remote) or Denver, and does the $148,000 base clear your floor?

Q2 — G3 (R10): Have you owned a data contract that analysts relied on, meaning a schema, freshness or quality promise with downstream users? What did you own, and how was it enforced?

Q3 — G2 (R9): Have you built ingestion from a product database or a CRM such as Salesforce or HubSpot? Which tool, and who owned the sync?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.