**Decision: `no_go`. Do not send anything, and do not pay anything.** This is a recruitment scam. The posting may be fake, and the Telegram process shows the pattern that scammers use to take money and personal data.

**Decision snapshot**
- **Status:** `no_go`, on the opportunity side. The role's terms and process are the reason, not your fit. On fit, your background is a reasonable match for the requirements.
- **Fit ledger:**
  - `must_have`, `direct`: spreadsheets (R3). You keep a weekly Excel tracker.
  - `must_have`, `adjacent`: attention to detail (R1); written English (R4), from ticket work rather than a written-English standard; order processing (R2), from parcel courier work.
  - `hard_gate`, `unconfirmed`: pay floor of €30,000 (R5). The posting says "up to €26/hour" for "15–30 a week" and an unstated commission. Reaching €30,000 needs about 22 paid hours every week, all year, at the top rate.
  - `unknown`: quiet workspace (R6). You didn't say.
- **Hard gates:** `unconfirmed: R5 (pay floor, €30,000/year)`. Candidate constraints were given.
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`).
- **What would change this:** nothing in the current terms. Only a company that did not ask for money, bank details and identity documents before any real employment could change the answer.

**Red flags**

| ID | Signal | Class | Severity | Source quote |
|---|---|---|---|---|
| RR1 | Upfront payment for equipment | red flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it" |
| RR2 | Cheque-forwarding scheme | red flag | high | "We are posting you a cheque for €2,850. Lodge it… transfer the rest to our equipment partner" |
| RR3 | Personal data and bank details requested before any interview | red flag | high | "send your IBAN, your PPS number and a clear photo of your passport" |
| RR4 | Only contact is Telegram, with no calls, video or a verifiable company | risk signal | medium | "no calls or video interviews… message @VellowayHiring" |
| RR5 | Employer not established: I have not checked Velloway Logistics against any public source | risk signal | medium | "Velloway Logistics" |

Each entry's provenance is `[generic]`: this is the well-known pattern for employment fraud. Each entry's verification question for the employer is: "Can you point me to this role on your official company careers page, and to a registered company address and an employer's email domain?"

**Why this is a scam.** Three things follow from the messages, not just from my pattern-matching:
- Real employers don't take bank details, PPS numbers and passport photos before an interview. Payroll is set up after an offer is signed.
- Real employers don't ask a new hire to pay for equipment and wait for a refund.
- The cheque instruction is the most serious part. You would deposit a cheque, keep €350, and send the rest to a third party. If the cheque bounces, the bank takes the money back from your account, and the money you sent on is gone. Passing money through your account like this can make you liable for fraud or money laundering, even if you didn't know.

**Evidence status:** no online checks were run (Research tier: L0, no searches). Everything above comes from the text you gave me and general knowledge of this scam pattern.

**What to do now**
1. Don't send your IBAN, PPS number or passport photo, and don't pay the €349. Reply on Telegram that you've withdrawn, or just stop replying.
2. If you have already sent any details, contact your bank today, ask them to flag the account, and change your online banking password.
3. If you have sent a PPS number or passport photo, contact the Department of Social Protection and the Gardaí. Report the Telegram account and the contact email to the Gardaí and to the job site.
4. Keep screenshots of the messages and the posting.
5. Look for real roles through the company's own careers page, or through established job boards.

Your background is a real asset for legitimate remote customer-operations work, including Excel tracking and training new starters. Those are things to put on your CV and in applications to employers you can verify.

**Dossier offer:** I can write a `tuesday-dossier.md` that keeps this assessment, your evidence and the next steps in one file for later use.

**Upgrade menu:**
- Live checks (Level 1 research, up to 5 searches and 2 page fetches): whether Velloway Logistics exists, whether its registered address and domain match, and whether public reports describe this scam. This would confirm or strengthen the red flags, not change the decision.
- The actual posting link, if you have one.
- Your workspace conditions, which would close R6.
- Your CV, which would firm up R1 to R4.

**Question:** Do you want me to run the live checks on Velloway Logistics (up to 5 searches and 2 page fetches), or is this enough to act on?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.