**Decision: no_go.** Don't send anything else, and don't pay, deposit the cheque or forward money. This is a payment-and-identity scam, and your background is a good fit for the role it's using as bait.

**Hard gates: failed (3)**
1. They want €349 from you before any work, for "equipment."
2. They want your IBAN, PPS number and passport photo before any interview.
3. They want you to deposit a €2,850 cheque, keep €350 and send the rest to a third party. That's a standard overpayment scam: the cheque bounces after you've moved the money, and the loss is yours.

**Other red flags**
- The whole process runs on Telegram, with no call or video interview. A "chat interview" after a "screening" is not how a real employer hires.
- The contact is a generic postmail address, not a company domain.
- Stated pay is "up to €26/hr plus commission." Commission is undefined.

**Fit (the candidate ledger, which doesn't change the decision)**
- *Strong:* spreadsheets (you keep a weekly Excel tracker); attention to detail and customer-service volume (about 60 Zendesk tickets a day); training others (you trained two starters).
- *Transferable:* parcel-courier background is adjacent to order processing.
- *Unevidenced:* written English (inferred from the customer-service role, not shown), and whether your workspace is quiet enough.

**Pay check**
- 15–30 h/wk × 52 × €26 = €20,280–€40,560 before commission.
- Your €30,000 floor needs about 22 h/wk at the top rate, and "up to" doesn't guarantee that rate.
- The posting's own figure is `[grounded]`; the comparison is my calculation.

**Application plan**
1. Stop replying to @VellowayHiring. Don't send the IBAN, PPS number or passport photo, and don't pay or deposit anything.
2. If you've already shared any of these, tell your bank now and watch your account. Report the scam to the Gardaí.
3. Report the posting and the Telegram account to the jobs site.
4. Check whether Velloway Logistics is a registered company on the CRO register before trusting any Velloway contact.
5. Apply instead to order-processing, operations-support or customer-operations roles where the employer can be verified, and lead with Zendesk volume, your Excel tracker and your training work.

**Research tier: L0 — no searches.** I haven't checked whether Velloway Logistics exists.

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | Not run; needs your consent |
| 2 | Role-family pay and scope sweep | skipped | Not run; needs your consent |
| 3 | Hiring manager's public footprint | n/a | Only a Telegram handle was given, not a name |

A dossier of this assessment can be saved as `tuesday-dossier.md` if you want it to carry into later interview prep.

**What would change this:** nothing in the Telegram thread can. A verifiable employer, a named recruiter on a company email domain, and a real video interview would be the minimum to reconsider.

Questions:
1. Do you want me to run the company check now (up to 5 searches and 2 page fetches)?
2. Which jobs site was the posting on? That tells you where to report it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.