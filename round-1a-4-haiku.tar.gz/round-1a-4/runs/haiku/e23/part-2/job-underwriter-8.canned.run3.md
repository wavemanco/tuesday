**Decision: no_go.** Don't reply with anything else, don't send your IBAN, PPS number or passport, don't pay the €349, and don't lodge the cheque.

**Snapshot**
- **Opportunity:** no_go. The messages show the standard markers of an advance-fee and fake-cheque scam. This comes from the text you pasted, so it is `[grounded]`.
- **Candidate fit:** strong on the posting's stated requirements. Your three years of Zendesk work at about 60 tickets a day, your training of two starters, and your Excel tracker match well. Good written English is `[inferred]` from how you write. Fit is not the problem here.
- **Hard gates:** none of your stated constraints is tripped on paper. Pay is a mismatch: at €26/hour, reaching €30,000 takes about 22 hours a week every week, before any commission (`[inferred]`, from €30,000 ÷ €26 ÷ 52).
- **Research tier:** L0, no searches. The verdict rests on the messages, which don't need outside checking.

**Role reality and risk register**

| # | Signal | Why it matters |
|---|---|---|
| 1 | Pay €349 by bank transfer to a third-party "equipment partner," refund "with first wages" | Real employers supply equipment or reimburse through payroll. Paying a third party for a job you haven't started is the scam itself. |
| 2 | Cheque for €2,850; keep €350, send the rest to the "partner" | Fake-cheque scheme. The cheque bounces days later, after the money has gone out, and you owe your bank that amount. Forwarding someone else's money can also make you a money mule, which is a crime even if done unknowingly. |
| 3 | IBAN, PPS number and passport photo requested before any interview or contract | Enough to commit identity fraud. |
| 4 | "Passed screening" before any interview, then the job offered in the chat itself | Pressure to move fast, with no real hiring step. |
| 5 | Telegram only, no calls or video, contact via a generic mail domain | No way to verify the company or the person. |
| 6 | Vague pay ("up to €26 plus commission"), "no experience needed" | Unverifiable terms, typical of these offers. |

**Application plan:** none. Next steps:
- Stop replying to @VellowayHiring.
- If you have already sent your IBAN, PPS number or passport, call your bank now, ask them to flag the account, and watch for unfamiliar activity. Report the scam to the Gardaí. Report the Telegram account to Telegram.
- If a cheque arrives, don't lodge it or send any money. Take it to your bank unlodged.
- Your real evidence fits legitimate customer-operations or support-coordinator roles. Search employer career pages directly, and for an Irish-registered company, check its registration on the CRO website.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| 1. Company's official site and careers page | skipped | L0, no research run. The verdict doesn't depend on it. |
| 2. Role-family sweep (pay and scope) | skipped | L0, no research run. |
| 3. Hiring manager's public footprint | n/a | No name given. |

Dossier offer: I can write a `tuesday-dossier.md` capturing this assessment if you want a record.

**Upgrade menu:** nothing you could add would make the upfront payment or the cheque arrangement safe, and a real employer would not need your passport before an interview. The only checks worth doing are the CRO record and the company's own careers page, and only if you still want to pursue this employer.

**Questions**
1. Have you sent any of your IBAN, PPS number, passport or money to anyone yet?
2. Where did you find the posting (which jobs site, and do you have the link)?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.