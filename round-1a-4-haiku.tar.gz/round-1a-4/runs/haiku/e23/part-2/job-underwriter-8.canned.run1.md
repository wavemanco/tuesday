**Decision: no_go. Don't send anything else, don't pay, and don't lodge the cheque.** This is a fake-job scam, and the cheque step is the most dangerous part.

**Decision snapshot**
- **Opportunity:** no_go. The hiring process is a payment and data-collection scheme, not an employment process. [inferred from the messages you quoted]
- **Candidate fit:** strong on the described tasks, but that doesn't change the decision.
- **Hard gates:** pay floor not met on the posting's own terms (see below). Hard-gate failure: pay.

**Opportunity ledger: red flags**
- **Pay for a job:** you're asked to pay €349 to an "equipment partner" before any work, with a refund promised "with your first wages." Legitimate employers don't charge for equipment. [grounded: message 2]
- **Personal data before any contract:** IBAN, PPS number and passport photo requested before a "chat interview" and before any contract. That is enough to commit identity fraud. [grounded: message 1]
- **Overpayment cheque:** you're told to deposit €2,850, keep €350, and send the remaining €2,500 to a third party. Cheques can appear to clear and then bounce days or weeks later, and the money you sent is gone. This is the standard mule/overpayment fraud pattern. [grounded: message 3, generic pattern]
- **Recruitment channel:** Telegram only, no calls or video, and the "interview" happens in a chat. Interviews this fast, with a pass after one chat, are typical of scams. [grounded from the posting and messages; pattern generic]
- **Contact domain:** the contact is a generic mail address with no company domain. [grounded: posting]
- **Vague duties:** "order processing" with commission on unspecified orders, no experience needed, and no named manager or entity. [grounded]

**Pay check against your floor**
- "Up to €26/hour" at 15–30 hours a week, 52 weeks, is about €20,300–€40,600 a year before commission. The rate is a ceiling, not a guarantee, and commission is unquantified. So the €30k floor is reachable only at the top of the range and is not promised. [inferred from the posting's figures]

**Fit ledger (Ciara)**
- Attention to detail and ticket volume (~60 Zendesk tickets/day): strong evidence from your CV. Confidence: CV claim, not independently verified.
- Spreadsheets (weekly Excel tracker): strong evidence. Same confidence level.
- Training others (two new starters): relevant to the posting's "training" element.
- Written English: not evidenced in what you've shared; stated as a requirement only.

Your background would fit a genuine version of this role. That is why the scheme is effective, and it does not make this offer legitimate.

**Application plan:** none. Do not apply further and do not send any of the requested details.

**Research tier: L0 — no searches.** The decision rests on the posting and messages you provided. I did not check whether Velloway Logistics exists.

**Immediate steps**
1. Send nothing else. Do not paste your IBAN into the chat.
2. If you have not paid or sent details, block the Telegram account and report it in Telegram and to the jobs site.
3. If the cheque has arrived, do not lodge it and do not transfer any money from it. Take it unopened to your bank and tell them it is a suspected scam.
4. If you already sent your IBAN, PPS number or passport photo, contact your bank to flag the account and watch for unusual activity. Report to the Gardaí, and consider contacting the Department of Employment Affairs and Social Protection about your PPS number. Reporting also helps others.

**Dossier offer:** I can save this assessment as `tuesday-dossier.md` for your records, if that's useful.

**Upgrade menu:** A Level 1 check would search for Velloway Logistics' registration and website and look for the live posting. It would take up to 5 searches and 2 page fetches. It is unlikely to change the decision, but it would confirm whether the company exists.

**Questions**
1. Have you sent any money, your IBAN, PPS number or passport photo, or any other personal details to @VellowayHiring or the "equipment partner"?
2. Has the €2,850 cheque arrived, or has anyone given you the equipment partner's bank details yet?
3. Do you want the Level 1 check on Velloway Logistics, or is this enough to stop?

Answer in prose; no need to pick from a list.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.