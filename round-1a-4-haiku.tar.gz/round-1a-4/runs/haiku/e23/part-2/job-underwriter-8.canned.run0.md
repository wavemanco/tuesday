**Don't go ahead. This is a recruitment scam, and it's a common one.** You don't need to verify the company to know that. The messages alone are enough.

**Red flags:**
- **Hiring only on Telegram, with no calls or video,** and a "chat interview" that is really a message exchange.
- **They ask for your IBAN, PPS number and passport photo before any job exists.** That's the identity-theft step. A real employer collects these only after a signed contract, through a payroll system.
- **They ask you to pay €349 for "equipment" and promise a refund.** Real employers don't make new hires pay for their own kit.
- **The cheque plan is the core of the fraud.** They send you a €2,850 cheque, tell you to keep €350, and send the rest to a "partner." Banks usually credit cheques quickly but can reverse them weeks later when they turn out to be fake. By then the money you sent out is gone, and you're liable for it. This also makes you the money-mule the scam needs.
- **The pay doesn't add up anyway.** €26/hour for 15–30 hours a week comes to about €20k–€40k a year before tax, and hitting your €30k floor takes roughly 23 hours a week at that rate.

**What to do now:**
1. **Send them nothing.** No IBAN, PPS, passport photo, bank transfer or cheque deposit. Don't reply to @VellowayHiring or velloway.hr@postmail.example.
2. **If you already sent your passport, PPS or IBAN,** contact your bank now and ask them to watch the account. Consider a credit-monitoring service, and check whether anyone has opened credit in your name.
3. **Report it** to the Gardaí (Garda National Cyber Crime Bureau) and to the jobs site that posted the ad.

**Your background is a strong fit for real jobs.** Three years of high-volume ticketing, training new starters and running a tracker in Excel are exactly what remote customer-service, operations and support-coordinator roles ask for. Those roles are usually listed with a named employer, a stated salary and a normal application process. If you want, I can help you tighten your CV for that search or check a specific posting you're considering.