Before we start, the message has several common job-scam signs: an unknown number, a recruiter who found you online, an interview with no call or video, a "flexible remote" role, and a tight deadline. I'll help you prep, but check the company before you share anything personal.
I can't build the prep pack yet, because I need the company name and the exact role title. Without those, the questions would be generic and not worth rehearsing.

**Check this before tomorrow.** Several things in the message match common job scams:

- An unknown number that says it found you "online," with no posting you can point to.
- The whole process over WhatsApp, with no call or video and a contract to follow.
- A "flexible" remote role with a fast interview slot.

Verify it before you share anything personal:

1. **Ask Jess for the company's full legal name, the job title, and the posting or reference number.** Then ask which site the role was advertised on.
2. **Find the company yourself.** Search for its official website, and find the job on its careers page or on LinkedIn. Don't use links or contact details Jess sends you.
3. **Call the company through the number on its official website,** and ask whether it's hiring for that role and whether it works with Jess or the recruitment firm she names.
4. **If there's a recruitment agency,** check that it exists in your country's official company register.
5. **Don't send ID, bank details, or a photo of your passport or driving licence,** and don't pay for training, equipment, or "onboarding." A legitimate employer won't ask you to do either before an offer.

If it checks out, send me:

- The company name and exact role title.
- The job description, if you have it. Paste the text, since I can't open the posting for you.
- Your CV, or a short summary of your background. Please remove your address, phone number, and any ID numbers first.
- Who you'll be talking to tomorrow, and whether it's a screening call with a recruiter or an interview with the hiring manager.

I'll build the full pack from those.