I'd hold off on interview prep until you've checked this one. The message has several hallmarks of a recruitment scam:

- **No calls or video at any stage.** Legitimate recruiters almost always do at least a phone or video screen. Running everything over WhatsApp, from first contact to contract, is the biggest red flag.
- **No company or role named.** "Remote position with flexible hours" with no employer, job title, or pay is how these messages are usually written.
- **Unknown number and a vague "we found your profile online".** That can be true, but you can't tell from this message.
- **Pressure.** An interview tomorrow, arranged within a day, with no earlier contact.

Scams like this often go on to ask for ID, bank details, or a "training" or "equipment" payment, or ask you to receive and forward money. Don't send any of those.

**Before you reply, check:**

1. **Did you apply through an agency?** Look through your applications. If you can't find one with this agency or a "Jess", that's a strong signal.
2. **Ask for specifics.** Reply with: Jess's full name, the agency's name and registration details, the client company's name, and the job reference or advert you're being considered for.
3. **Verify independently.** Look up the agency and client on your country's official company register and on their own website. Find the role on the company's careers page, not through links in the message.
4. **Ask for a video call.** A real recruiter will agree. If they refuse or insist on WhatsApp only, treat that as a no.
5. **Don't share** your passport, ID, National Insurance or Social Security number, or bank details until you've verified the employer and have a written offer.

If the company checks out and Jess agrees to a call, I'm happy to run the mock-interview prep. To do that properly I'll need:

- the job advert or description
- your CV or a summary of your experience
- the company name and anything you know about it

If you decide to go ahead with this interview regardless, I can also give you a short list of questions to ask Jess that will show quickly whether she's legitimate.