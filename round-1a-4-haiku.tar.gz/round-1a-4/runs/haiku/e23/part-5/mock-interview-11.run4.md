**Before anything else: treat this message as a likely recruitment scam until you've verified it.** Interview prep is still worth doing, but don't share personal or financial details yet.

**Red flags in what you received:**
- Unsolicited contact from an unknown number, claiming they "found your profile online."
- The whole process, from interview to contract, runs over WhatsApp, with no call or video.
- A vague "remote role with flexible hours" and no named company.
- Urgency: an interview "tomorrow at 11am."

Scammers use this pattern to collect ID documents, bank details, or fees for "equipment" or "training," or to push fake job offers. Even if this is a genuine follow-up from one of your applications, a legitimate recruiter will still be able to show you who they are.

**Verify before you engage:**
1. **Check where you applied.** Look through your application history on job boards and company sites. If you can't find an application that matches this role, be suspicious.
2. **Look up the company independently.** Find its official website and careers page through a search you run yourself, not through a link in the message.
3. **Verify the recruiter.** Search for "Jess" on the company's site or on LinkedIn and check that the role and firm match. Don't trust a name or profile the message points you to.
4. **Call the company's main switchboard** (from its official website, not the number that messaged you) and ask whether they're recruiting for this role and whether Jess works there.
5. **Ask for a video call.** A real recruiter will usually agree. Refusal, or insistence on WhatsApp only, is a warning sign.
6. **Never pay for anything,** including training, software, or equipment, and never send ID scans, bank details, or your National Insurance/tax number until you've verified the employer and have a written offer from a company domain.

**Interview prep you can use regardless:** I don't have your CV or the job description yet, so this is a general pack. Please answer the questions at the end and I'll tailor it.

### Common questions and how to answer them

| Question | Answer guidance | Type |
|---|---|---|
| "Tell me about yourself." | Give a 60–90 second summary: your current role, two or three strengths relevant to this job, and what you're looking for next. Keep it to facts you can back up. | Generic |
| "Why do you want this role?" | Name two or three things from the job description and connect each to something you've actually done. Avoid generic praise of the company. | Generic |
| "Why are you leaving your current job?" | Stay factual and brief, and focus on what you want next rather than criticising your employer. | Generic |
| "Tell me about a challenge you faced at work." | Use one real example in STAR form: Situation, Task, Action, Result. Say what you personally did. | Generic |
| "How do you work remotely?" | Describe your routine, how you communicate with colleagues, and how you keep focus. Use a real example if you have one. | Generic |
| "What are your weaknesses?" | Name a real area you're improving, and describe the specific steps you've taken. | Generic |
| "Do you have any questions for us?" | Prepare three: about the team's priorities, how success is measured in the role, and the interview process. | Generic |

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

---

**Offers:**
- **Drill:** I can play the interviewer and run a live practice session on any of these questions, with feedback afterwards.
- **Dossier:** Once you have a verified job description, I can build a tailored pack that maps your experience to the role's requirements.

**Questions (up to three):**
1. Which company and role did you apply for, and on which site? I can help you check it against the verification steps above.
2. Can you paste the job description, or a short summary, once you've verified the role?
3. Would you like me to draft a short, polite reply to Jess asking for a video call and the company's details, before you commit to tomorrow's slot?