Before we prep, I'd check this message carefully. It has several classic signs of a recruitment scam:

- **Unsolicited contact** from an unknown number, claiming you were "found online" rather than responding to a specific posting.
- **No calls or video at any stage**, including the interview and the contract. Legitimate employers almost always hold at least one live video or phone conversation.
- **Vague details:** no company name, no job title, no recruiter agency name, and no pay.
- **Very short notice:** an interview tomorrow at 11am.

Your recent applications are a plausible explanation, but that is also what scammers rely on. Until you've verified it:

- **Don't send** ID, bank details, tax or National Insurance numbers, or a CV with your full address or date of birth.
- **Don't pay** for equipment, training, background checks, or "onboarding."
- **Don't click** links Jess sends, and don't install anything.

To check whether it's real:

1. Ask Jess for the company name, the job title, the agency name and the listing reference. A real recruiter answers these easily.
2. Find the job on the site you applied through, or on the company's official careers page. Don't use a link from the message.
3. Look up Jess on LinkedIn and check that the agency and the company exist. Contact the company through its official switchboard, not a number from the message.
4. Ask for a video call. A reluctance to do one is a strong warning sign.

I can't build the prep pack yet because the skill needs the company and role title to start. If it turns out to be a real opportunity, send me:

1. The company and exact job title, and where you saw the listing.
2. The job description, if you have it.
3. Your CV, or a summary of your recent experience.
4. Whether this is a screening call, a hiring-manager interview, or a panel.

I can also draft a reply to Jess that asks for the verification details above, so you can test whether the recruiter is legitimate before you spend time preparing.