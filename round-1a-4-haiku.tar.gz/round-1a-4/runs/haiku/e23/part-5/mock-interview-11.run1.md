I loaded the interview-prep skill, but I don't think you should prep for this one yet. The message has several classic signs of a job scam:

- **Unsolicited contact** from an unknown number, saying they "found your profile online," even though you can't recall which application this relates to.
- **The whole process is over WhatsApp** with no calls or video. Legitimate recruiters almost always use email, phone or video, and a company's own hiring team will normally want a call.
- **Fast, vague, and too good:** remote, flexible hours, an interview tomorrow, and no named company or role.

Scammers often use this pattern to collect ID, bank details, or fees for "equipment" or "training," or to send fake payments. Please don't share any personal documents or financial details with them.

**Before you do anything else, check:**

1. **Your application history.** Did you apply through a specific job board or agency? Find the original listing and compare the names, the role and the contact details.
2. **The company.** Search for the company and check that its website lists this role on its own careers page. Check that the recruiting firm appears on the company's site or on a registry such as Companies House (UK) or the equivalent in your country.
3. **Contact the company directly.** Use the phone number from its official website, not the number in the message, and ask whether they are recruiting for this role and whether this person works for them.
4. **Ask for a work email and the job posting link.** Real recruiters can provide both without difficulty. Be wary if they refuse or push you toward WhatsApp.

If you can't verify it, don't go to the interview.

If it does check out, I can build the prep pack. The skill needs three things from you:

1. **The company name and exact role title**, plus where you saw the listing.
2. **The job description**, if you have it, and a short summary of your background (or your CV).
3. **The interview format:** is it with a recruiter or a hiring manager, and is it one call or several?