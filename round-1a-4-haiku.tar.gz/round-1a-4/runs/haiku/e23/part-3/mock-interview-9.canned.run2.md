Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-e23-part-3-rooms-case-9-canned-c5089f96/37da07a7-2eab-4aec-b19a-bb7dd2ac87d6/scratchpad/Halvering_fourth-grade-teacher_interview_pack.md`. I built it for a panel: the principal and two team members, treated as peers. I left your Social Security number out of the pack and this message. It doesn't belong in interview materials.

Two things to check:
- If "Thursday" means 26 November 2026, that is Thanksgiving in the US. Confirm the date with HR.
- The pack is built from your CV text and the invitation only. No research has run, so it has no values, strategy or interviewer-background sections.

The biggest gap is that you've never taught fourth grade. Question A2 is the one to rehearse first; the pack names it as the highest-value prep.

Say the word and I'll play the Skeptic on A2. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the job posting? If so, paste it. Without it, the requirements come only from the invitation.

Shall I run a light public-research pass on Halvering's values and the interview process, about six searches and two page reads?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District · Panel, 45 minutes, Thursday · Candidate: Grace
Built from: the invitation, your CV text, and your message. Research tier: L0 (no search run yet).
Date check: if Thursday means 26 November 2026, that is Thanksgiving in the US. Confirm the date with HR.
Change note: first version.

## How to use

Personas describe how a question is asked. Types describe what is being scored.

| Type | Meaning |
|---|---|
| JD | Can you do the job as stated, including its gaps |
| EXP | Does what you did hold up under attribution questions |
| CASE | A live problem from the role, reasoned aloud |
| CO | Company knowledge. None in this pack: no research has run |
| VAL | Values alignment. None in this pack: no published values were supplied |

Guidance is scaffolding, not a script. Say it in your own words, and say only what you did.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Gate shown met by your CV. Expect a document check, so bring the license. No bridge needed. |
| F2 | "Fourth Grade Teacher position" (invitation) | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your CV | medium | [grounded] | transferability | Third grade is adjacent, not fourth. Say the quote at its own scope: six years of third grade. Plain acknowledgment: "I've never taught fourth grade." Answer slot: if anything you taught in third grade carries into fourth, name it and how you know; if nothing does, say so and say how you would learn the fourth-grade year. |
| F3 | Collaborating on a grade-level team (role family, no source supplied) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [grounded] | transferability | Your material shows a led curriculum move, not team leadership. Plain acknowledgment: "I've never been a team lead." The move stays at its own scope. Answer slot: if the move was made with colleagues, say how decisions were shared and which were yours. |
| F4 | Teaching early reading (role family, no source supplied) | "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | none | No gap in the quote's terms. Say it at its own scope: two years of the club, nothing added about results. |
| F5 | Communicating with families (role family, no source supplied) | "I write a weekly email to families" — your CV | medium | [grounded] | none | No gap in the quote's terms. Say it at its own scope. |

Your material does not show any results for the reading club or the curriculum move. Nothing below adds any.

## Persona table

Relationship priors: the principal sits in the hiring-manager row (Skeptic and Case/Strategist). The two team members sit in the peer row (Peer Evaluator and Prober). Per the panel rule, the top two personas of each relationship are blended. No interviewer profile was researched, so there is no interviewer read; team members are not named.

| Persona | Who it likely is | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Principal, Dolores Vantongeren | 5 | Fourth grade is the sharpest gap (F2), and the invitation names the position. | Rehearse A2 until it is boring. Hold the third-grade base; concede the fourth-grade content you have not taught. |
| Peer Evaluator | Team members | 4 | Peers price what a hire adds to their load and probe the seams. | Ask what you would need; propose seam principles, not claims about their seam. |
| Case/Strategist | Principal | 4 | Hiring managers buy capability and test the roadmap with live problems. | Clarify, then structure, then metrics, then risks. Think aloud. |
| Prober | Team members | 3 | Your CV's reading club and curriculum move invite attribution questions. | Know what was counted and what was not. Say plainly when you do not know. |
| Conversational | Any panelist, at the opening | 2 | Casual openers are scored too. | Use a 90-second arc built from your own lines. |

## Question banks

Coverage: 18 questions. Depth follows weight: Skeptic 5, Peer Evaluator 4, Case/Strategist 4, Prober 3, Conversational 2.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Why fourth grade, and why leave third after six years?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV | Give your reason in your own words; the pack cannot supply it. Start from the six years in the quote, then state the reason as something you hold. Answer slot: if you can state the reason in a sentence, say it; if you have not settled it, say what you are choosing between. | The motivation probe on any career change. F2 is the gap it aims at. JD because the position is the fourth-grade role. |
| A2 | "You've never taught fourth grade. What in six years of third grade transfers, and what would you not know on day one?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your CV | Highest-ROI rehearsal in this pack. Open with the quote at its own scope: six years of third grade. Then the plain words: "I've never taught fourth grade." Name the first thing you would learn, as a plan. Hold through two follow-ups by returning to the six years; concede specifically the fourth-grade content you have not taught. Answer slot: if any third-grade work overlaps fourth-grade content, name it and how you know; if none does, say so. | F2 is the gap this objection presses on. The negative in the question is one you stated, so the question may presuppose it. This is the question most likely to come first. |
| A3 | "Which part of a fourth-grade year would you be weakest at on day one?" | JD | [generic] | Name the weakest part honestly, and what you would do in week one to close it: ask the team, observe, read the unit plans. Do not claim knowledge you lack. | A standard Skeptic probe. Calibrated candor beats a bluff. The guidance makes no claim about your past. |
| A4 | "You've never been a team lead. Why would this team trust you to lead anything?" | JD | [grounded] "I've never been a team lead" — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV | Plain acknowledgment first: "I've never been a team lead." Then the quote, unchanged: "I led our grade level's move to a new reading curriculum in 2024." Hold through two follow-ups on the move only; do not call it team leadership. Answer slot: say how the move was carried out and which decisions were yours. | F3 is the bridge. The probe presses team lead, which the material does not show. The hold is the curriculum move, at its own scope. |
| A5 | "Sixty seconds: why should we choose a candidate with six years in one grade over someone who has taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV; "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | Restate the question in your words. Then, in order: the six years of third grade; the endorsement's range as the quote states it; what you would do first with the team. Concede plainly that a teacher with fourth-grade years brings them on day one. | The Skeptic's time-boxed challenge when a panel compares candidates. The concession is the point you hold to. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you need from this team to start on day one?" | JD | [generic] | Name the inputs you would ask for: current unit plans, the pacing guide, the assessment calendar. Offer one thing you would bring to planning, stated as a plan. | Reciprocity probe: the team wants to know what the hire adds to its load. |
| B2 | "Tell me about a time you disagreed with colleagues on how to teach something. How did it end?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Pick a real disagreement, name the two positions, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the 2024 move, in its quoted terms. Do not add a disagreement you cannot describe. | Disagreement with equals, returned in collegial form. The guidance supplies no past event; the fallback is the quoted line. |
| B3 | "Our classroom and yours sit side by side. Where would you expect the seam between us to be?" | JD | [generic] | Name a principle for the seam, not a guess at this team's. For example: agree on who owns a shared assessment or a shared family message. Do not pretend to know the seam. | Peer seam probe. A principle shows you think about turf without claiming knowledge. |
| B4 | "Families get messages from us and from the grade. How do you keep yours consistent with the team's?" | EXP | [grounded] "I write a weekly email to families" — your CV | Say what the weekly email covers, in your words. Then the principle: keep family messages consistent through the team. Answer slot: if you have coordinated family messages with colleagues, say how; if you have only written your own, say so and say how you would align them. | Seam probe aimed at the family-email practice. The slot stops a claim of coordination the material does not show. |

### C. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Fourth-grade reading scores dipped this year. What would you want to know first?" | CASE | [generic] | Clarify first: what the scores measure, and which students dropped and when. Then the objective, the segments to check, two or three approaches, the metrics you would watch, and the risks. Name no program. | A live problem from the role. The guidance makes no claim about your past. |
| C2 | "A fourth grader has finished third grade and still struggles with reading comprehension. What do you do this week?" | CASE | [generic] | Check what the student can read and where comprehension breaks. Bring in the team. Talk to the previous teacher. Set one measure to track. Keep it a plan. | A case probe on the reading requirement. |
| C3 | "Tell me about the reading club you've run for two years. Who came, and how did you know whether it was working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Say who attended and how you chose them, in your words. Answer slot: if you counted anything about the club's results, say what you counted and how; if you did not, say so plainly and say what you would measure first. Do not offer a result you cannot describe. | A defend-the-figure probe on the two-year count. The club's results are not in the quote. |
| C4 | "A parent emails, upset about a grade, and copies the principal. Walk us through your response." | CASE | [grounded] "I write a weekly email to families" — your CV | Structure it: reply to the parent promptly, offer a call or meeting, check the grade's facts with the team, and keep the principal informed. Use the weekly email only as the channel you already use, not as a result. | A case about family communication. The quote carries only the practice of writing to families. |

### D. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey to here." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | A 90-second arc in this order: the six years in Joliet, the 2024 move in its quoted terms, the reading club for two years, and why this position. Keep each beat to what those lines say. The "why" is yours to fill in. | Casual openers are scored. The arc uses only quoted lines. |
| D2 | "What's been the most rewarding part of the reading club?" | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Name one moment from the club you can describe in plain terms. If none comes, describe what the sessions were like. Do not invent a moment. | A casual question that tests whether you describe real practice rather than adjectives. |

### E. Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Do you have a count of the students who came to the reading club? What did you track about their reading?" | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Give the count you have, in your words. Answer slot: if you kept attendance or reading records, say what was counted and how; if you did not, say so plainly. | A figure probe on the club. The answer names what was counted, not a result. |
| E2 | "Which part of the 2024 curriculum move was your decision, and which was not?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Name the decisions you made and the ones made above you or by the grade, in your words. Answer slot: if you chose the curriculum, say how; if it was chosen above you, say you led the move, not the choice. Then name the assumption behind the move you would defend least. | An attribution probe on a led move. The slot keeps the verb at its own scope. |
| E3 | "You write to families every week. How do you know they read it?" | EXP | [grounded] "I write a weekly email to families" — your CV | Say what you actually know: replies, questions you have been asked, or nothing you can track. Answer slot: if you tracked any response, say what and how; if you did not, say so plainly. | The denominator probe on a routine. The slot keeps the answer honest. |

### Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| Illinois PEL with elementary endorsement (invitation) | none, and why: a gate your CV shows met (F1); the check is a document, not a question | |
| Fourth-grade teaching (position) | A1, A2, A3, A5 | |
| Team work and team lead (stated gap, F3) | A4, B1, B2 | |
| Early reading (role family) | C1, C2, C3, E2 | |
| Family communication (role family) | B4, C4, D2, E3 | |
| Results and measurement (your reading club) | C3, E1 | |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the fourth-grade team already have in place for a new teacher's first weeks?" | Shows you plan for onboarding and asks for facts the team knows. |
| R2 | "Which reading materials does fourth grade use, and what has the team found works?" | Ties to the reading requirement and asks for the team's own evidence. |
| R3 | "What could a new team member do in the first month that would genuinely help this team?" | Reciprocity for a peer. It signals you want to add to the team, not only take from it. |
| R4 | "How do families hear from the grade: shared messages, or each teacher's own?" | Connects to your weekly email and shows you think about consistency. |
| R5 | "How does the team split planning, and who leads it day to day?" | Lets the panel show how team leadership works, without you claiming it. |
| R6 | "What would you hope a new teacher has learned by the end of the first year?" | Gets the success criteria in the panel's own words. |

No interviewer profile was researched, so no reverse question is tied to a career path.

## Prohibited claims

Built locally from the fit snapshot. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Taught fourth grade, or fourth-grade experience | Negative you stated: "I've never taught fourth grade" (your CV) | "I've never taught fourth grade." Then F2's quote at its own scope. |
| Has been a team lead, or led a team | Negative you stated: "I've never been a team lead" (your CV) | "I've never been a team lead." Then F3's quote at its own scope. |
| Chose or selected the curriculum, or led the district's reading adoption | Inflated form of F3's quote: "I led our grade level's move to a new reading curriculum in 2024" (your CV) | The quote at its own scope. The pack's observation, in its analysis: your material says you led the grade-level move, not that you chose the program or led beyond your grade. E2's slot asks which part was yours. |

## Sources

- Provided documents: the invitation from Human Resources, Orrinsford Community School District (requirement, panel format, position title); your CV text; your message (the two negatives in the CV, the gaps you named).
- Research tier: L0 for this delivery. No search or fetch has run. Research has not been consented.
- No Recruiter or HR guidance beyond the invitation was supplied. No graded deliverable is declared.
- No values-style round is detected, so no values cheat sheet is included.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering or Orrinsford values | unavailable | Would have built the values cheat sheet. Not run at L0. |
| 2. Orrinsford interview process, elementary teacher | unavailable | Would have set loop structure and persona weights per round. Not run at L0. |
| 3. Orrinsford strategy and recent news | unavailable | Would have added CO questions. Not run at L0. |
| 4. Dolores Vantongeren, Orrinsford | unavailable | Would have built the interviewer read and tailored a reverse question. Not run at L0. |
| 5. Representative Fourth Grade Teacher JD, Illinois | unavailable | The invitation fixes only the license requirement; a representative JD would add the role's other requirements, labeled [inferred]. Not run at L0. |

## Upgrade menu

- The job posting or full JD text → the invitation's one requirement becomes the full list; F3 to F5 gain JD-sourced quotes, and their [generic] requirements become [grounded].
- Research consent at L1 → a values section if the district publishes values; an interviewer read for Dolores Vantongeren; strategy-tied CO questions.
- The two team members' names → persona weights per panelist instead of a blend.
- Attendance or reading records for the reading club → C3 and E1 become rehearsed counts in place of answer slots.
- Who decided what in the 2024 curriculum move → A4, B2 and E2 gain a story map in place of slots.
- Prep time before Thursday → a prep triage section, ordered to that time.
- Any recruiter note on panel format or materials → a graded-deliverable section, if one is declared.
