I'll use the interview-prep skill for this. Your interview is Thursday, two days from today.
Your interview is Thursday, November 26. Before the pack: you don't need your Social Security number for this interview, and I haven't used it or repeated it. Keep it off application forms unless the district's HR asks for it through its secure system.

The pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-e23-part-3-rooms-case-9-canned-5aa7955c/47475008-22a4-4aef-9a3c-e32020e75358/scratchpad/Halvering_Elementary_fourth-grade-teacher_interview_pack.md`, and here it is in full:

# Interview prep: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Panel interview, 45 minutes, Thursday 26 November 2026, with Principal Dolores Vantongeren and two fourth-grade team members. Built from your invitation, your resume and your note. No research was run (L0), and there is no job description yet, so the requirements below come from the invitation alone.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Every claim about your experience comes from your own words, quoted in the tables.

Type key:
- **EXP**: what you actually did, and whether it holds up under questions
- **JD**: whether you can do the listed job, gaps included
- **CASE**: how you reason through a classroom problem (generic, not about your past)

## Prep triage (about two days: today and Wednesday)

1. Question A2, rehearsed aloud three times, with two follow-ups each. This is the highest-return prep in the pack.
2. A1 and A4: say your two gaps plainly, in under 20 seconds each.
3. E1: the 90-second career arc.
4. D1 and D2: know what you will say when you have no data. That is an honest answer, and it is the one most candidates fumble.
5. C3 and B3: the curriculum move. Stay inside what you did.
6. B1 and B2: the classroom scenarios.
7. Reverse questions: pick three of the five and make them your own words.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. Say the license and its expiry date as written. |
| F2 | Fourth-grade teaching (the role title in the invitation) | "I've never taught fourth grade" (your message) | none | [grounded] | capability | Your material shows six years in third grade: "Six years teaching third grade at a public elementary school in Joliet." Words for the gap: "I haven't taught fourth grade." Then a plan, said as a plan, never as a past. |
| F3 | Working on a grade-level team (role-family prose, [generic]) | "I led our grade level's move to a new reading curriculum in 2024" (your CV). "I've never been a team lead." (your message) | medium | [grounded] | transferability | The quote carries leading one curriculum move, not leading a team. Say both: the move at its own scope, then "I haven't been a team lead." Do not stretch "led the move" into "led a team." |
| F4 | Reading instruction (role-family prose, [generic]) | "I've run the after-school reading club for the last two years." (your CV) | medium | [grounded] | presentation | Reword only the quote. Do not add practices, numbers or outcomes to it. |
| F5 | Communicating with families (role-family prose, [generic]) | "I write a weekly email to families." (your CV) | medium | [grounded] | none | No gap. Say the weekly email as written. |
| F6 | Using student data to plan reading groups (role-family prose, [generic]) | none given | none | [generic] | discovery | Your material does not show whether you tracked reading results. Answer slot: if you tracked results for the club or the curriculum move, say what you counted and from whom; if you did not, say so plainly and say what you would track first. |

Gap types: F2 is `capability` because you stated the absence. F3 is `transferability` because the quote is adjacent work. F6 is `discovery` because the material is silent.

## Prohibited claims

Not coached, and why. Every answer below is written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Taught fourth grade | You stated otherwise (F2) | "I haven't taught fourth grade." No slot. |
| Has been a team lead | You stated otherwise (F3) | "I haven't been a team lead." No slot. |
| Led a team of teachers | Inflated form of F3's quote | "I led our grade level's move to a new reading curriculum in 2024." Your material says you led the move, not a team. |
| Reading results improved because of the club or the curriculum | Inflated form of F4 and F6; no results are in your material | Say what you ran and what you tracked, if anything (F6's slot). |

## Persona table

The panel mixes two kinds of member. The principal is the hiring authority; the two teammates are peers who will judge fit with their team. Weights follow the relationship priors, with no interviewer research behind them.

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|---|
| Skeptic | Principal | Quiet probing of the fourth-grade and team-lead gaps | High. A hiring authority derisks gaps, and F2 and F3 are the visible ones. | Hold your position, then concede specifically. Give a concrete first-month plan. | 4 |
| Peer Evaluator | Teammates | Seams with third grade, collaboration, credit | High. Peers price what you add to their team. | Reciprocity: what you bring, not only what you need. Seam principles, not claims. | 4 |
| Data-Driven Prober | Teammates | Counts, measurement, what the CV does not show | High for reading results. The invitation names no data, but your CV gives the probe something to hold. | Say what you tracked, or that you did not. Name the weakest assumption. | 4 |
| Case / Strategist | Principal | A classroom scenario | Medium. The principal fits the hiring-manager prior, but the scenario is generic. | Say the steps aloud: clarify, assess, group, plan, family contact. | 3 |
| Conversational | Any panelist | "Walk us through your path." | Medium. Panel openers are often friendly and still scored. | A 90-second arc, rehearsed. | 3 |

## Question banks

Eighteen questions in total. Weight decides depth: 4 for the top personas, 3 for the rest.

### A. Skeptic (principal), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade. What makes you ready for fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Hold: the six years are real and relevant. Concede plainly that fourth grade is new to you. Then name the first thing you would do: learn the fourth-grade standards and the team's sequence. Answer slot: if any fourth-grade work is already underway for you, say what and how; if not, say so plainly and say how you would learn it. | F2 is the central objection. This is the bridge, and it stays inside the quote. |
| A2 | "Why should we hire someone who has never taught fourth grade over someone who has?" | JD | [grounded] "I've never taught fourth grade" (your message) | Highest-return prep. Hold through two follow-ups by returning to what you did: six years of third grade. Do not argue that you are better. Concede that a candidate who has taught fourth grade has a year of practice you do not. Name that limit before they ask for it. | F2 is the single most likely objection, and the principal is the hiring authority. |
| A3 | "Tell me about a time a plan you were part of did not work. What did you change?" | EXP | [generic] open prompt | Pick a time that actually happened. Name what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the 2024 curriculum move (F3). | Open prompt. It asks you to choose an instance, so it supplies none. |
| A4 | "What would make you a weak choice for this role?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." (your message) | Name the two gaps in your own words, once, plainly, then your plan for each. Do not add a third weakness to look humble. | The Skeptic's usual close. You already have the words. |

### B. Case / Strategist (principal), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A student in your class is two grade levels behind in reading in October. What is your first week?" | CASE | [generic] | Clarify first: what data you have and where it comes from. Then group, plan, and contact the family. Say the steps aloud. Do not claim you have done this before. | Generic classroom case. Reading is the most likely domain. |
| B2 | "A family writes upset that their child's reading has slipped. What do you do?" | CASE | [grounded] "I write a weekly email to families." (your CV) | Use the channel you already have: the weekly email. Then describe the call you would make. Do not say the email has ever resolved a complaint. | The quote shows a habit, not a resolution. Keep the two apart. |
| B3 | "A new reading curriculum arrives and your team doesn't know it yet. How do you start?" | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Describe the 2024 move in your own words: what you did and when. If you brought colleagues along, say how. If you did not, say so. | Story-mapped on the quote. The rest is your own account. |

### C. Peer Evaluator (team members), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our fourth-grade team plans together every week. How would you fit in?" | JD | [grounded] "I've never been a team lead." (your message) | Say what you would bring to shared planning, and ask what the team needs from a colleague who knows third grade. Do not claim leadership. | The panel is the fourth-grade team, so this is the raising line. Reciprocity answers the team-lead gap. |
| C2 | "Where is the seam between third and fourth grade, and what happens when you disagree with us about it?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." (your CV) | Name a seam principle, such as what students arrive knowing, rather than a claim. Answer slot: if you have disagreed with a colleague on a grade-level decision, say what happened; if not, say so and say how you would raise a disagreement. | The Peer Evaluator's seam probe. |
| C3 | "You led the reading curriculum move. How did you get colleagues on board?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Premised question: it presumes you got colleagues on board. Answer slot: if you brought people along, say how, in your words; if the move was decided above you, say so. Do not add a meeting or a result you have not stated. | Premise is the team's; the answer keeps to your quote. |
| C4 | "How do you handle credit when work spans teams?" | JD | [generic] | Name the people and the work, not just yourself. If you have a 2024 example, use only what is in that quote. | Generic peer stem. |

### D. Data-Driven Prober (team members), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you measure whether the new reading curriculum worked?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Name the assumption you would defend least, before they do. Answer slot: if you tracked results, say what you counted and from whom; if you did not, say so plainly and what you would track first. | F6. The question presumes a measurement your material does not show. |
| D2 | "How many students were in the after-school reading club, and what changed for them?" | EXP | [grounded] "I've run the after-school reading club for the last two years." (your CV) | Say what you ran and for how long, in those words. Answer slot: if you have a count, say how it was counted; if you do not, say so. Do not estimate a number on the spot. | The figure is not in your material, so the honest answer may be "I don't have it." |
| D3 | "What does your weekly family email track, if anything?" | EXP | [grounded] "I write a weekly email to families." (your CV) | Say what the email contains. If it tracks nothing, say so. | The Prober wants to know whether the habit produces data. |
| D4 | "Which student data would you look at first before grouping for reading?" | CASE | [generic] | Name the sources you would check, labeled as your plan. Make no claim about past practice. | Generic case on data use. |

### E. Conversational (any panelist), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through your path to teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." and "I've run the after-school reading club for the last two years." (your CV) | 90-second arc: six years in third grade in Joliet, the 2024 reading curriculum move, two years of the reading club, then why fourth grade. Say the gap early, in one sentence, not at the end. Answer slot: say why fourth grade, in your own words. | Panel openers are scored. Keep the arc to what is quoted. |
| E2 | "What are you reading with your own students these days?" | EXP | [generic] | Name a book or program only if you use it. If you are not sure, say so. | Open-ended and easy to over-claim. |
| E3 | "Why this school?" | JD | [generic] | Answer from the invitation and the posting only: the role, the team, the district. Say plainly that you have not researched the school beyond those. | Motivation probe. No research was run, so make no claim about the school's values. |

### Reverse questions

Five of them. Pick three.

1. "What does a typical week look like for the fourth-grade team, and when do you plan together?" Why it lands: it shows you are thinking about the work, not only the title.
2. "Which fourth-grade reading standards is the team focusing on this year?" Why it lands: it signals you have read the role, and it lets the panel show you the real work.
3. "What would a new teacher on this team need to learn in the first month?" Why it lands: it is a reciprocity question that answers the team-lead gap.
4. "How does the team share reading assessment data?" Why it lands: it speaks to the Prober's concern and shows you care about evidence.
5. "What would make the first year feel like a success to you?" Why it lands: it asks the principal's own standard, which is the question the decision rests on.

## Sources

Provided documents: the invitation, your resume and your note. No searches or fetches were run.

**Research tier:** L0. No searches run, no pages fetched.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Values | unavailable | Values cheat sheet, not built. No values-style round was detected from the invitation, and L0 did not search. |
| 2. Interview process | unavailable | Loop structure. The invitation already fixes the format (a 45-minute panel), so only the other rounds were unknown. |
| 3. Strategy and recent news | unavailable | A current-affairs question and a grounding brief. |
| 4. Interviewer public footprint (Dolores Vantongeren) | unavailable | A tailored reverse question and the principal's persona weights. |
| 5. Representative job description | unavailable | Coverage of mid-list requirements. No job description was supplied. |

## Upgrade menu

- The full job description → mid-list requirements become grounded rows and new JD questions.
- The two teammates' names and roles → persona weights per member, instead of the panel blend.
- Public footprint research on the principal (L1: six searches, two page fetches) → a tailored reverse question and a grounded interviewer read.
- Any reading-club counts or curriculum results you have → D1 and D2 move from answer slots to grounded answers.
- Deep research (L2: six further searches, two further fetches) → district values, recent strategy, and the loop structure. Offered once; I would run it only if you want it.

---

Say the word and I'll play the Principal on A2, the question the pack names as the highest-return prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two questions, and the answers would reshape the pack:
1. Is Principal Vantongeren the final decision-maker, and do you know the two teammates' roles?
2. Do you have the full job description? If so, I'd replace the invitation-only requirements with its actual list.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_Elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Panel interview, 45 minutes, Thursday 26 November 2026, with Principal Dolores Vantongeren and two fourth-grade team members. Built from your invitation, your resume and your note. No research was run (L0), and there is no job description yet, so the requirements below come from the invitation alone.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Every claim about your experience comes from your own words, quoted in the tables.

Type key:
- **EXP**: what you actually did, and whether it holds up under questions
- **JD**: whether you can do the listed job, gaps included
- **CASE**: how you reason through a classroom problem (generic, not about your past)

## Prep triage (about two days: today and Wednesday)

1. Question A2, rehearsed aloud three times, with two follow-ups each. This is the highest-return prep in the pack.
2. A1 and A4: say your two gaps plainly, in under 20 seconds each.
3. E1: the 90-second career arc.
4. D1 and D2: know what you will say when you have no data. That is an honest answer, and it is the one most candidates fumble.
5. C3 and B3: the curriculum move. Stay inside what you did.
6. B1 and B2: the classroom scenarios.
7. Reverse questions: pick three of the five and make them your own words.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. Say the license and its expiry date as written. |
| F2 | Fourth-grade teaching (the role title in the invitation) | "I've never taught fourth grade" (your message) | none | [grounded] | capability | Your material shows six years in third grade: "Six years teaching third grade at a public elementary school in Joliet." Words for the gap: "I haven't taught fourth grade." Then a plan, said as a plan, never as a past. |
| F3 | Working on a grade-level team (role-family prose, [generic]) | "I led our grade level's move to a new reading curriculum in 2024" (your CV). "I've never been a team lead." (your message) | medium | [grounded] | transferability | The quote carries leading one curriculum move, not leading a team. Say both: the move at its own scope, then "I haven't been a team lead." Do not stretch "led the move" into "led a team." |
| F4 | Reading instruction (role-family prose, [generic]) | "I've run the after-school reading club for the last two years." (your CV) | medium | [grounded] | presentation | Reword only the quote. Do not add practices, numbers or outcomes to it. |
| F5 | Communicating with families (role-family prose, [generic]) | "I write a weekly email to families." (your CV) | medium | [grounded] | none | No gap. Say the weekly email as written. |
| F6 | Using student data to plan reading groups (role-family prose, [generic]) | none given | none | [generic] | discovery | Your material does not show whether you tracked reading results. Answer slot: if you tracked results for the club or the curriculum move, say what you counted and from whom; if you did not, say so plainly and say what you would track first. |

Gap types: F2 is `capability` because you stated the absence. F3 is `transferability` because the quote is adjacent work. F6 is `discovery` because the material is silent.

## Prohibited claims

Not coached, and why. Every answer below is written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Taught fourth grade | You stated otherwise (F2) | "I haven't taught fourth grade." No slot. |
| Has been a team lead | You stated otherwise (F3) | "I haven't been a team lead." No slot. |
| Led a team of teachers | Inflated form of F3's quote | "I led our grade level's move to a new reading curriculum in 2024." Your material says you led the move, not a team. |
| Reading results improved because of the club or the curriculum | Inflated form of F4 and F6; no results are in your material | Say what you ran and what you tracked, if anything (F6's slot). |

## Persona table

The panel mixes two kinds of member. The principal is the hiring authority; the two teammates are peers who will judge fit with their team. Weights follow the relationship priors, with no interviewer research behind them.

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|---|
| Skeptic | Principal | Quiet probing of the fourth-grade and team-lead gaps | High. A hiring authority derisks gaps, and F2 and F3 are the visible ones. | Hold your position, then concede specifically. Give a concrete first-month plan. | 4 |
| Peer Evaluator | Teammates | Seams with third grade, collaboration, credit | High. Peers price what you add to their team. | Reciprocity: what you bring, not only what you need. Seam principles, not claims. | 4 |
| Data-Driven Prober | Teammates | Counts, measurement, what the CV does not show | High for reading results. The invitation names no data, but your CV gives the probe something to hold. | Say what you tracked, or that you did not. Name the weakest assumption. | 4 |
| Case / Strategist | Principal | A classroom scenario | Medium. The principal fits the hiring-manager prior, but the scenario is generic. | Say the steps aloud: clarify, assess, group, plan, family contact. | 3 |
| Conversational | Any panelist | "Walk us through your path." | Medium. Panel openers are often friendly and still scored. | A 90-second arc, rehearsed. | 3 |

## Question banks

Eighteen questions in total. Weight decides depth: 4 for the top personas, 3 for the rest.

### A. Skeptic (principal), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade. What makes you ready for fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Hold: the six years are real and relevant. Concede plainly that fourth grade is new to you. Then name the first thing you would do: learn the fourth-grade standards and the team's sequence. Answer slot: if any fourth-grade work is already underway for you, say what and how; if not, say so plainly and say how you would learn it. | F2 is the central objection. This is the bridge, and it stays inside the quote. |
| A2 | "Why should we hire someone who has never taught fourth grade over someone who has?" | JD | [grounded] "I've never taught fourth grade" (your message) | Highest-return prep. Hold through two follow-ups by returning to what you did: six years of third grade. Do not argue that you are better. Concede that a candidate who has taught fourth grade has a year of practice you do not. Name that limit before they ask for it. | F2 is the single most likely objection, and the principal is the hiring authority. |
| A3 | "Tell me about a time a plan you were part of did not work. What did you change?" | EXP | [generic] open prompt | Pick a time that actually happened. Name what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the 2024 curriculum move (F3). | Open prompt. It asks you to choose an instance, so it supplies none. |
| A4 | "What would make you a weak choice for this role?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." (your message) | Name the two gaps in your own words, once, plainly, then your plan for each. Do not add a third weakness to look humble. | The Skeptic's usual close. You already have the words. |

### B. Case / Strategist (principal), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A student in your class is two grade levels behind in reading in October. What is your first week?" | CASE | [generic] | Clarify first: what data you have and where it comes from. Then group, plan, and contact the family. Say the steps aloud. Do not claim you have done this before. | Generic classroom case. Reading is the most likely domain. |
| B2 | "A family writes upset that their child's reading has slipped. What do you do?" | CASE | [grounded] "I write a weekly email to families." (your CV) | Use the channel you already have: the weekly email. Then describe the call you would make. Do not say the email has ever resolved a complaint. | The quote shows a habit, not a resolution. Keep the two apart. |
| B3 | "A new reading curriculum arrives and your team doesn't know it yet. How do you start?" | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Describe the 2024 move in your own words: what you did and when. If you brought colleagues along, say how. If you did not, say so. | Story-mapped on the quote. The rest is your own account. |

### C. Peer Evaluator (team members), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our fourth-grade team plans together every week. How would you fit in?" | JD | [grounded] "I've never been a team lead." (your message) | Say what you would bring to shared planning, and ask what the team needs from a colleague who knows third grade. Do not claim leadership. | The panel is the fourth-grade team, so this is the raising line. Reciprocity answers the team-lead gap. |
| C2 | "Where is the seam between third and fourth grade, and what happens when you disagree with us about it?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." (your CV) | Name a seam principle, such as what students arrive knowing, rather than a claim. Answer slot: if you have disagreed with a colleague on a grade-level decision, say what happened; if not, say so and say how you would raise a disagreement. | The Peer Evaluator's seam probe. |
| C3 | "You led the reading curriculum move. How did you get colleagues on board?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Premised question: it presumes you got colleagues on board. Answer slot: if you brought people along, say how, in your words; if the move was decided above you, say so. Do not add a meeting or a result you have not stated. | Premise is the team's; the answer keeps to your quote. |
| C4 | "How do you handle credit when work spans teams?" | JD | [generic] | Name the people and the work, not just yourself. If you have a 2024 example, use only what is in that quote. | Generic peer stem. |

### D. Data-Driven Prober (team members), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you measure whether the new reading curriculum worked?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Name the assumption you would defend least, before they do. Answer slot: if you tracked results, say what you counted and from whom; if you did not, say so plainly and what you would track first. | F6. The question presumes a measurement your material does not show. |
| D2 | "How many students were in the after-school reading club, and what changed for them?" | EXP | [grounded] "I've run the after-school reading club for the last two years." (your CV) | Say what you ran and for how long, in those words. Answer slot: if you have a count, say how it was counted; if you do not, say so. Do not estimate a number on the spot. | The figure is not in your material, so the honest answer may be "I don't have it." |
| D3 | "What does your weekly family email track, if anything?" | EXP | [grounded] "I write a weekly email to families." (your CV) | Say what the email contains. If it tracks nothing, say so. | The Prober wants to know whether the habit produces data. |
| D4 | "Which student data would you look at first before grouping for reading?" | CASE | [generic] | Name the sources you would check, labeled as your plan. Make no claim about past practice. | Generic case on data use. |

### E. Conversational (any panelist), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through your path to teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." and "I've run the after-school reading club for the last two years." (your CV) | 90-second arc: six years in third grade in Joliet, the 2024 reading curriculum move, two years of the reading club, then why fourth grade. Say the gap early, in one sentence, not at the end. Answer slot: say why fourth grade, in your own words. | Panel openers are scored. Keep the arc to what is quoted. |
| E2 | "What are you reading with your own students these days?" | EXP | [generic] | Name a book or program only if you use it. If you are not sure, say so. | Open-ended and easy to over-claim. |
| E3 | "Why this school?" | JD | [generic] | Answer from the invitation and the posting only: the role, the team, the district. Say plainly that you have not researched the school beyond those. | Motivation probe. No research was run, so make no claim about the school's values. |

### Reverse questions

Five of them. Pick three.

1. "What does a typical week look like for the fourth-grade team, and when do you plan together?" Why it lands: it shows you are thinking about the work, not only the title.
2. "Which fourth-grade reading standards is the team focusing on this year?" Why it lands: it signals you have read the role, and it lets the panel show you the real work.
3. "What would a new teacher on this team need to learn in the first month?" Why it lands: it is a reciprocity question that answers the team-lead gap.
4. "How does the team share reading assessment data?" Why it lands: it speaks to the Prober's concern and shows you care about evidence.
5. "What would make the first year feel like a success to you?" Why it lands: it asks the principal's own standard, which is the question the decision rests on.

## Sources

Provided documents: the invitation, your resume and your note. No searches or fetches were run.

**Research tier:** L0. No searches run, no pages fetched.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Values | unavailable | Values cheat sheet, not built. No values-style round was detected from the invitation, and L0 did not search. |
| 2. Interview process | unavailable | Loop structure. The invitation already fixes the format (a 45-minute panel), so only the other rounds were unknown. |
| 3. Strategy and recent news | unavailable | A current-affairs question and a grounding brief. |
| 4. Interviewer public footprint (Dolores Vantongeren) | unavailable | A tailored reverse question and the principal's persona weights. |
| 5. Representative job description | unavailable | Coverage of mid-list requirements. No job description was supplied. |

## Upgrade menu

- The full job description → mid-list requirements become grounded rows and new JD questions.
- The two teammates' names and roles → persona weights per member, instead of the panel blend.
- Public footprint research on the principal (L1: six searches, two page fetches) → a tailored reverse question and a grounded interviewer read.
- Any reading-club counts or curriculum results you have → D1 and D2 move from answer slots to grounded answers.
- Deep research (L2: six further searches, two further fetches) → district values, recent strategy, and the loop structure. Offered once; I would run it only if you want it.
