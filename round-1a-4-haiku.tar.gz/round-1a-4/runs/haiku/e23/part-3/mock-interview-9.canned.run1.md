Your prep pack is saved here: /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-e23-part-3-rooms-case-9-canned-0f47cdf6/4717819b-f781-490c-92c3-28ac22733936/scratchpad/halvering_fourth_grade_teacher_interview_pack.md

It has a fit snapshot, 19 questions across six interviewer styles for the principal and the two team members, reverse questions, and the things it won't coach you to claim. I built it from the invitation and your notes without web research, so the school's values and interview process aren't covered yet. I also left your Social Security number out, since interview prep doesn't need it. Keep it off any prep notes or copies you send out.

Thursday, 26 November is Thanksgiving Day in the US. It's worth confirming the date with HR.

Say the word and I'll play the principal and run the Skeptic question, B1, which is the one I'd rehearse hardest. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you'd like.

Do you have the full posting, or any written focus areas or format from HR?

Has the panel announced a demo lesson or any other task?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering_fourth_grade_teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Organization:** Orrinsford Community School District
**Format:** 45-minute panel, Thursday 26 November 2026 (note: that date is US Thanksgiving Day; confirm it with HR)
**Panel:** Principal Dolores Vantongeren, plus two members of the fourth-grade team
**Built at:** research tier L0. No web research was run, so company values, process and strategy are not established. Built from the invitation text and your notes.

---

## 1. How to use this pack

- **Personas** describe how a question arrives (its delivery). **Types** describe what is being scored.
- Types: **JD** = stated requirement. **EXP** = your past work, checked for accuracy. **CASE** = a live problem for the role. **CO** = company knowledge (none established here). **VAL** = values (none detected).
- Guidance is scaffolding, not a script. Each cell is about 90 to 120 seconds spoken.
- Labels: **[grounded]** traces to your words or the invitation. **[inferred]** is derived. **[generic]** is a role-family pattern with no claim about you or this school.

---

## 2. Fit snapshot

The invitation's one stated requirement is the license. The other rows come from the title and from what you told me.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | Gate shown met. Say it plainly: "I hold an active Illinois PEL with an elementary endorsement, through June 30, 2029." Bring a copy of the license to confirm the claim. |
| F2 | "Fourth Grade Teacher position" (invitation) | "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school" (your CV) | none | [grounded] | capability | Stated absence. Words: "I haven't taught fourth grade." Then the nearest thing your material carries: six years of third grade. Do not describe any fourth-grade work you did not tell me about. |
| F3 | [generic] team leadership on a grade-level team | "I've never been a team lead" (your message) | none | [grounded] | capability | Stated absence. Words: "I haven't been a team lead." Then only what you led: "I led our grade level's move to a new reading curriculum in 2024," at that scope. |
| F4 | [generic] grade-level reading instruction | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | presentation | Your quotes already reach this in other terms. Reword only those sentences: you led the move, and you have run the reading club for two years. Add no practice, figure or outcome. |
| F5 | [generic] communication with families | "I write a weekly email to families" (your message) | medium | [grounded] | none | Your sentence already reaches this. Say it as written. A sample email would raise the confidence (see upgrade menu). |
| F6 | [generic] working with colleagues on a grade-level team | none given | none | [generic] | discovery | No quoted sentence reaches this. Answer slot: if you worked with colleagues on the curriculum move, say what your part was in your own words. If you did not work with colleagues on it, say so and say how you would start with this team. |

**Gap type routing.** The license is a gate and the material shows it met, so it routes by its evidence cell (F1, `none`). F2 and F3 are stated absences, so they are `capability`. F4 is `presentation` because the quotes already reach the requirement. F6 is `discovery` because silence is not a capability claim.

**No headline figure.** Your material has no metric, count or outcome, so no row needs a defend-the-number question.

---

## 3. Prohibited claims

Not coached in any cell of this pack, with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Having taught fourth grade | Negative you stated (F2) | "I haven't taught fourth grade." No slot on this point. |
| Having been a team lead | Negative you stated (F3) | "I haven't been a team lead." No slot on this point. |
| Choosing or training the team on the reading curriculum | Inflated form of F4 | F4's quote at its own scope. The pack's observation, not words for you: your material says you led the move, not that you chose the curriculum. D1's slot asks which decisions were yours. |
| Any reading result, count or figure from the curriculum move or the reading club | No figure in the material; any number would be invented | None coached. D2 and D3 ask only what you tracked, if anything. |

---

## 4. Persona weights

Interviewer read: **dropped.** You gave a name and a role but no public profile was researched, so no career pattern or style is assumed.

Values-style round: **not detected.** The invitation establishes a single 45-minute panel session with named roles, and it names no values round. The archetype fallback does not apply, because a loop source (your invitation) establishes the session.

| Panel member | Dominant personas | Likelihood, with reasoning | Counter-strategy (rehearsal method) |
|---|---|---|---|
| Principal Dolores Vantongeren | Case/Strategist (weight 4) and Skeptic (weight 4) | Hiring-side panelist: she is buying capability and checking the two gaps (F2, F3). Expect a live classroom problem and a direct probe of the fourth-grade gap. | Clarify before answering. Hold the position you actually stated, and concede specific uncertainty without folding. |
| Fourth-grade team member 1 | Data-Driven Prober (weight 3) and Peer Evaluator (weight 4) | Peer-side panelist: probes what you did with the curriculum move, and what it cost the team. | Say what you did and what you did not do. Name what you did not track before they ask. |
| Fourth-grade team member 2 | Peer Evaluator (weight 4) and Conversational (weight 2) | Peer-side panelist: tests seams and collaboration, and asks casual openers that are still scored. | Make reciprocity the frame: what you bring to their team, and what you would need from them. |
| Any member under stress | Pressure (weight 2) | Low, but a panel can time-box answers. | Pause, restate, anchor in what you stated. |

**Protective mini-bank:** not included, because you did not ask for it.

---

## 5. Question banks

Coverage line: "requirement to question IDs"
- License (gate, F1): state it, no question. Covered by E1.
- Fourth-grade experience (F2): B1, B2, A4.
- Team lead (F3, user-named): B3.
- Reading instruction (F4): D1, D2, E1.
- Family communication (F5): C3.
- Colleagues on a grade-level team (F6): C1, C4.
- Defend-the-number: none, because your material has no figure.
- Company strategy (CO): none, because no research ran.

Session total: 19 questions.

### A: Case/Strategist (principal, weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you would plan the first six weeks with a fourth-grade class reading below level." | CASE | [generic] | Clarify first: which reading levels, and what evidence you would have. Then objective, approach, checks, risks. Name no past event; this needs none. | A live problem for this role. [generic] because it is a pattern, not a fact about this school. |
| A2 | "A student has been reading two levels behind all year. What do you do this week?" | CASE | [generic] | Say what you would check first, who you would talk to, and what you would try in the first week. Make no claim about having done this before. | Live problem from the role. Tests structure, not a memory. |
| A3 | "Two colleagues disagree about which reading program to use next year. How do you help them decide?" | CASE | [generic] | Structure: what each side needs to be true, what evidence would settle it, and who decides. Describe a process, not a past event. | Tests judgment with colleagues, which F6 leaves open. |
| A4 | "What would you need to know about our fourth-grade students before you planned the reading block?" | CASE | [generic] | Name the three or four things you would ask for first. Do not pretend to know the class. | Shows you plan before you assume. Ties to F2, because the fourth-grade gap is the first thing this panel will test. |

### B: Skeptic (principal, weight 4). Deepest rehearsal: B1.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't taught fourth grade. Why should we take a chance on you for this role?" | JD | [grounded] "I've never taught fourth grade" (your message); [grounded] "Six years teaching third grade at a public elementary school" (your CV) | **Highest-ROI prep in this pack.** Hold: "I haven't taught fourth grade." Then the nearest thing you have: six years of third grade, at the same school level. Follow-up 1: "What in third grade carries over?" Name the specific skills you used, and no fourth-grade result you did not have. Follow-up 2: "Why not wait for a candidate with fourth-grade experience?" Hold the belief that third-grade skills transfer, and say what you would do in the first month to close the gap. Concede specifically: "I can't yet say how I'll handle fourth-grade content day to day." Answer slot: if you have any fourth-grade contact, say what; if not, say so and say what you would do first. | F2 is the gap this panel will test, and this question will be asked in some form. JD because it scores the stated title. |
| B2 | "Your fourth-grade team has been together for some time. How would you fit in?" | JD | [grounded] "two members of our fourth-grade team" (invitation) | Describe the plan, not a past. Ask what the team does together, and where a new teacher fits. Name no team history you were not told about. | Tests the team fit the invitation raises. |
| B3 | "You've never been a team lead. Why would this team trust you with anything led?" | JD | [grounded] "I've never been a team lead" (your message); [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Hold: "I haven't been a team lead." Then: "I led our grade level's move to a new reading curriculum in 2024." Concede: the team lead role is new to you. Answer slot: if you led anything else on your team, say what and how you decided; if not, say so. | F3 is a stated absence. Hold the line you can back. |
| B4 | "On your first day, what would you be weakest at?" | JD | [generic] | Name the fourth-grade content gap plainly, then the ramp plan: what you would read, observe and ask in your first two weeks. Calibrated candor, not bluffing. | Persona stem for the Skeptic. Lets you name the gap yourself before it is raised. |

### C: Peer Evaluator (team members, weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What would you need from this team in your first month?" | JD | [generic] | Ask for specifics: planning time, materials, who to observe. Then reciprocity: what you bring to their team, using C3's sentence. | Reciprocity is the peer-scored move here. F6 is `discovery`, so answer from the plan, not a past. |
| C2 | "When you disagree with a colleague about a student's plan, what happens?" | VAL | [generic] | Open prompt. Selection scaffold: pick a time you disagreed with a colleague over a plan; say what you proposed, what you conceded, and how it ended. If no such time comes to mind, say so plainly and give the nearest thing your material carries: the curriculum move in F4. | Peer-scored disagreement style. No value round was detected, so the type is VAL by its content, not by a published value. |
| C3 | "You send a weekly email to families. How does that work?" | EXP | [grounded] "I write a weekly email to families" (your message) | Say it as written: weekly, to families. Do not add what the email covers or how many families read it, because you have not told me. Answer slot: if you measured response, say what; if not, say so. | F5 is the family-communication requirement. Lets you show consistency rather than claim more. |
| C4 | "Where is the seam between third and fourth grade, and how would you handle it?" | JD | [grounded] "Six years teaching third grade at a public elementary school" (your CV) | Propose a principle for the seam, not a fact about this school. Ask the team what they expect students to arrive with. Your third-grade time is the evidence you bring, in its own scope. | F6 seam probe. Peers test seams; name one, without pretending to know this school's seam. |

### D: Data-Driven Prober (team member 1, weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you led the move to the new reading curriculum." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Story-mapped on F4: the move, its year, and that you led it, in your own words. Answer slot: which decisions were yours (the choice, the timing, the training). If you did not choose the curriculum, say so and say what you did lead. | The likeliest probe of your strongest story. EXP because it tests what was actually yours. |
| D2 | "How would you know whether a reading curriculum is working for your students?" | EXP | [generic] | Say what you would track, and what you tracked for the 2024 move if anything. Answer slot: if you tracked results, say what and how they were counted; if not, say so. Never name a result you do not have. | Prober stem. The answer is your honest measure, not an invented one. |
| D3 | "You've run an after-school reading club for two years. How do you know it helps?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Say what you ran, for how long, in those words. Answer slot: if you tracked whether it helped, say what and how; if not, say so and say what you would track. | Probers test claims about programs. The club is real; the effect is not in your material. |

### E: Conversational (team member 2, weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through your path into teaching." | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV); "Six years teaching third grade at a public elementary school" (your CV); "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your CV) | A 90-second arc in this order: license, six years of third grade, the 2024 curriculum move, the reading club. Stop there. Do not add a backstory. | Casual openers are scored. Give the arc once, cleanly. |
| E2 | "What's the reading moment you most enjoy with students?" | CO | [generic] | Name one moment, from your own classroom, in your own words. Keep it short and specific. Do not invent a story. | Rapport question. A short true answer beats a long one. |

### F: Pressure (panel, weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why should we hire you over a candidate who has taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" (your message); [grounded] "Six years teaching third grade at a public elementary school" (your CV) | Pause. Restate the question. Hold: "I haven't taught fourth grade." Then the two things you can back: six years of third grade and the 2024 curriculum move. Hold through two follow-ups; concede specifically on fourth-grade content. Do not argue that you are better. | Pressure persona. Scores composure, not the claim. |
| F2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Hold: you led the move. Concede any specific part others decided, by name of the part. Do not inflate the share. Answer slot: which parts you decided, in your own words. | Pressure on attribution. The hold is only what your sentence says. |

---

## 6. Reverse questions

Each has a "why it lands" line. No interviewer profile was researched, so none is tied to a principal's career path.

1. "What does a successful first semester look like for a new fourth-grade teacher here?" *Why it lands:* signals you are planning to succeed, not just to be hired. Ask the principal.
2. "How does the fourth-grade team plan together, and where would a new teacher fit?" *Why it lands:* shows you are thinking about the team, not only yourself. Ask a team member.
3. "What would a new team member do in their first month that would genuinely help your team?" *Why it lands:* the reciprocity question. Peers weight it as a preparation signal.
4. "Which part of the fourth-grade reading block is hardest for students right now?" *Why it lands:* shows you listen for the real problem before offering a fix.
5. "What reading initiatives are in progress across the school this year?" *Why it lands:* lets you connect your 2024 curriculum work to what the school is doing now.

---

## 7. Sources

Provided documents: the invitation text, as you pasted it; your CV and your note in the same message.

**Research tier: L0. Searches 0 of 0. Fetches 0 of 0.** No web research was run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | unavailable | Values cheat sheet. Dropped, because no values source is in hand. |
| 2. `Halvering Elementary School interview process fourth grade teacher` | unavailable | Loop structure. The invitation already establishes one 45-minute panel. |
| 3. `Orrinsford Community School District strategy` / recent news | unavailable | CO bank. Would have made E2 and A-series questions school-specific. |
| 4. `Dolores Vantongeren Halvering Elementary School` | unavailable | Interviewer read and persona weights; the name is given, so a public-footprint search was available. |
| 5. representative `Fourth Grade Teacher` JD | skipped | Not needed: the invitation's requirement and your notes fix the fit snapshot. |

---

## 8. Upgrade menu

- **The full posting or HR's written focus areas** → F2 to F6 become grounded requirements where the text names them, and the coverage line updates.
- **Consent to a targeted research pass (about 6 searches and 2 page fetches)** → the school's values, its interview process and the principal's public footprint, which set the persona weights and any values round.
- **Any pre-declared demo lesson or other deliverable from HR** → a graded-deliverable section.
- **A copy of your license** → F1 moves from medium to high.
- **A sample of your weekly family email** → F5 moves from medium to high, and C3 gets something specific to rehearse.
- **Any result you tracked for the curriculum move or the reading club** → D2 and D3 gain a defend-the-number slot. Without a figure, those slots stay as they are.
- **Any fourth-grade contact, observation or coursework** → the answer slot on B1 gets a named example to rehearse.
