# Interview prep: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Format: 45-minute panel. Principal Dolores Vantongeren, plus two members of the fourth-grade team. Built with no posting text, no interviewer research, and no prep time given. Changes from a regeneration: none (first version).

## How to use

- **Personas** = how a question arrives (tone, register, pressure). **Types** = what is being scored.
- Type key: **VAL** behavioral/values · **EXP** experience deep-dive · **JD** role requirement · **CO** company knowledge · **CASE** live problem.
- Guidance is scaffolding, not a script. Rehearse out loud, in your own words, to about 90–120 seconds.

## Fit snapshot

Requirements come from the invitation (quoted) or are marked `[generic]` where no source supplied them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — invitation | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | high | [grounded] | none | Met on the page. Words: "I hold an Illinois Professional Educator License with an elementary endorsement, grades 1–6, active through June 30, 2029." |
| F2 | "Fourth Grade Teacher position" — invitation | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [grounded] | transferability | Adjacent work, one grade below. Keep to the quote: "I've taught third grade for six years." Answer slot: if you know any fourth-grade standard or assessment from your own work, name it; if not, say so and say how you would learn the fourth-grade sequence. |
| F3 | "Fourth Grade Teacher position" — invitation | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A stated absence. Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan and never as a past. |
| F4 | "two members of our fourth-grade team" — invitation | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | A grade-level change you led is adjacent to working with a grade team. Words: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if decisions in that move were made above you, say so and stay with what you ran. |
| F5 | [generic] grade-team leadership (role family, no source) | "I've never been a team lead" — your CV | none | [grounded] | capability | A stated absence. Words: "I haven't been a team lead." Then how you would contribute to a team you join, as a plan. |
| F6 | [generic] literacy instruction and family communication (role family, no source) | "I've run the after-school reading club for the last two years" — your CV; "I write a weekly email to families" — your CV | medium | [grounded] | none | Both quotes reach the role in role-relevant terms. Say each at its own scope. |

Your material shows the license is met. It does not show fourth-grade experience or team leadership. Those are the two gaps the panel is most likely to test.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Fourth-grade teaching experience | Negative you stated (F3) | "I haven't taught fourth grade." No claim about fourth-grade practice. |
| Team lead experience | Negative you stated (F5) | "I haven't been a team lead." |
| Choosing the reading curriculum | Inflated form of F4: "led the move" stretched to "selected" | F4's quote at its own scope. Analysis: your material says you led the move, not that you chose the curriculum. |
| Designing the reading club | Inflated form of F6: "run" stretched to "designed" | "I've run the after-school reading club for the last two years." |

## Personas and weights

Panel: the principal's relationship prior is hiring-manager (Case + Skeptic). The teammates' prior is peer (Peer Evaluator + Prober). Pressure is a secondary principal tilt. No interviewer research was run, so no signal adjustments apply.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Principal presses on the two stated gaps | High (5 questions). Your two stated absences are the obvious probes. | Rehearse A1 until it is plain. Acknowledge, bridge from the quote, then give a plan. |
| Peer Evaluator | Teammates ask about seams, credit, and what they would need to do | High (4). Two teammates; the peer prior applies. | Reciprocity: what you offer their team, not only what you need. |
| Case / Strategist | Live first-weeks problem | Medium (3). The principal's prior. | Clarify before answering. |
| Data-Driven Prober | Asks what the reading change showed | Medium (3). No outcome figures appear in your material, so any metric question will land on a gap. | Say what you tracked, if anything. Say plainly if you did not track it. |
| Pressure | Time-boxed "why you" | Low (2). | Hold, then concede the specific point. |
| Conversational | Opening "walk me through" | Low (2). | A 90-second arc. |

## Question banks

**Skeptic (weight 5) — principal**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. Why should we believe you can start in September?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | **Highest-ROI prep in this pack.** Acknowledge first: "I haven't taught fourth grade." Then bridge from the quote: "I've taught third grade for six years." Then a plan. Answer slot: name one fourth-grade standard or assessment you would check first, and say how you would learn the sequence from the team. Hold through two follow-ups by returning to the third-grade base, and concede the specific gap if pressed. | F3 is the gap and F2 is the bridge. This is the objection the invitation makes almost certain. |
| A2 | "What in your third-grade practice will not carry over to fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Name one thing you would adjust and how you would find out what fourth graders need. Answer slot: if you already know a specific fourth-grade need, name it; if not, say so and give your plan. | F2 is transferability. This tests whether the bridge is honest. |
| A3 | "You've never been a team lead. Why would we trust you to coordinate with this team?" | JD | [grounded] "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | Plain acknowledgment: "I haven't been a team lead." Bridge from the quote: the 2024 move, at its own scope. Answer slot: if you coordinated any group's work, say what you did; if you did not, say so and describe how you would work with the team you join. | F5 is the gap; F4 is the bridge. |
| A4 | "Why leave a grade you've taught for six years, and why this school?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Give the reason in your own words. If the reading work is part of it, say so using the quote: "I led our grade level's move to a new reading curriculum in 2024." Do not invent a school-specific reason you have not stated. | Skeptic's motivation probe ("why leave, why here, why now"). |
| A5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Name the weakest part honestly, in your own words. Then give a ramp plan. Do not claim readiness you have not shown. | Honest self-assessment is what this probe scores. |

**Peer Evaluator (weight 4) — teammates**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between third and fourth grade, and what would you need from us?" | JD | [grounded] "I write a weekly email to families" | Propose seam principles, not claims about their curriculum: shared scope and sequence, and a family-communication routine you can share. Ask what they would want from you. | F6 is the offer; reciprocity is the scored move. |
| B2 | "How do you handle credit when a change like a reading curriculum spans a whole grade?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say who was involved, in your words. Keep "led" at the quote's scope. Answer slot: if the choice was made by others, name them and say what you did. | F4 is the evidence. A premised question, so the second branch must be allowed. |
| B3 | "What's your read on the reading materials we use in fourth grade?" | CO | [generic] | Do not pretend to know their materials. Say what you learned from the 2024 change, then ask what they use and why. | Tests curiosity and honesty about what you do not know. |
| B4 | "How would you want us to tell you when something isn't working in your class?" | VAL | [generic] | Describe a process you would welcome, as a plan. | Peer-style collaboration check. |

**Case / Strategist (weight 3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Plan your first six weeks with a fourth-grade class you have never taught. What do you need to know first?" | CASE | [generic] | Clarify first: class profile, current reading levels, team's sequence, family contacts. Then objectives, routines, assessment baseline, and checkpoints. Think aloud. | Live problem from the role. Presupposes nothing about your past. |
| C2 | "A parent emails upset about a reading grade. Walk us through your response." | CASE | [generic] | Acknowledge, get the facts, involve the team if needed, then respond in writing and in person. Do not claim a past case. | Tests judgment with families. |
| C3 | "The grade team is adopting a new math sequence. How would you prepare?" | CASE | [generic] | Clarify scope and timeline, then a plan: learn the sequence with the team, pilot a unit, gather student evidence. | Generic team-adoption problem. |

**Data-Driven Prober (weight 3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What did you use to tell whether the reading change worked?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say what you looked at, in your words. Answer slot: if you tracked results, say what and for whom; if you did not, say so and say what you would track first. | F4 is the evidence. Open wording so the question does not presuppose a measure. |
| D2 | "How many students were in the reading club, and how did you choose them?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | If you have the count, give it. If you do not, say so and say what you would record next time. | F6. Probes the number, not a claim. |
| D3 | "How do you know whether your weekly family emails are read?" | EXP | [grounded] "I write a weekly email to families" | Say what you can see, in your words. If you cannot see anything, say so. | F6. Tests whether you can show effect, not only effort. |

**Pressure (weight 2) — principal**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" | Hold: concede that fourth-grade experience is real and you do not have it. Then state what you do bring, from the quotes. Do not fold on the core claim. | F3, under time pressure. Hold-then-concede. |
| E2 | "That 2024 change: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say what you did, at the quote's scope. If others decided, say so plainly. Do not expand "led" into "chose". | F4. Attribution under pressure. |

**Conversational (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've run the after-school reading club for the last two years" | A 90-second arc: Joliet and six years of third grade, the 2024 reading move, the reading club, the family emails, and why fourth grade now. | F2, F4, F6 in order. |

**Requirement coverage:** no posting text was supplied, so the coverage map is partial. The license requirement (F1) needs no question. Fourth-grade work: A1, A2, C1. Team work: A3, B1, B2. Family communication: B1, D3. Reading instruction: D1, D2.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first semester look like for this grade team?" | Shows you are planning for the role, not only interviewing for it. |
| R2 | "How does the grade team plan together: weekly, or by unit?" | Shows you think about process, and gives you the teammates' own view. |
| R3 | "What reading materials does the fourth-grade team use now?" | Lets you ask about their work without pretending to know it. |
| R4 | "Principal Vantongeren, what would success in this role look like at the end of the year?" | Invites the principal to name the expectation you will be measured against. |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for the peer teammates. Shows you are thinking about what you bring. |

## Sources

Provided documents: the interview invitation and your résumé text, both in this conversation.

Research tier: L0, no search run. Research was not offered or consented to in this session.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Halvering Elementary values` | unavailable | Values cheat sheet (section not in this pack). No search was run. |
| 2. `Orrinsford Community School District interview process` | unavailable | Loop structure, panel weights. No search was run. |
| 3. `Orrinsford district strategy / recent news` | unavailable | Company knowledge (CO) questions. No search was run. |
| 4. `Dolores Vantongeren Halvering Elementary` | unavailable | Interviewer read and a tailored reverse question. No search was run. |
| 5. Representative `fourth grade teacher` posting | unavailable | Requirement rows marked `[inferred]`. No search was run. |

## Upgrade menu

- The posting or job description → the `[generic]` requirements become `[grounded]`, and the coverage line becomes complete.
- Research at the L1 tier → values section, district context, and an interviewer read for Dolores Vantongeren.
- Names or roles of the two teammates, if you know them → per-person persona weights.
- Prep time before Thursday → a prioritized prep triage.
- Any fourth-grade material you have used (a unit, standard, or assessment) → F2 and A1 gain quoted evidence.
