# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Company:** Halvering Elementary School, Orrinsford Community School District
**Round:** 45-minute panel. Principal Dolores Vantongeren, plus two fourth-grade team members (names not given)
**Date:** Thursday, to confirm. Nov 26, 2026 is Thanksgiving
**Built from:** the invitation and your résumé. No job posting text, no research run (tier L0)

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** values/behavioral, **EXP** your experience in depth, **JD** the job's stated needs, **CO** company knowledge (none in this pack, since no research ran), **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | Met on your CV's own terms. State it as the CV does. |
| F2 | Fourth-grade content knowledge (role family, no posting text) | "Six years teaching third grade at a public elementary school in Joliet" (your CV) | medium | [generic] | transferability | Your material shows third grade, six years. It does not show fourth-grade content yet, so the bridge stays at third grade: "I taught third grade for six years." Answer slot: name the third-grade units or standards you expect to carry into fourth grade, and what you would check first. If you have not reviewed fourth-grade material, say so. |
| F3 | Grade-team leadership (role family, no posting text) | "I've never been a team lead." (your message) | low | [grounded] | capability | Words: "I haven't been a team lead." Then the nearest adjacent work, at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Do not stretch that into leading the team. |
| F4 | Reading instruction (role family, no posting text) | "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years" (your CV) | medium | [generic] | presentation | Both lines already reach reading instruction in other terms. Reword only; add no practice, figure or result. |
| F5 | Family communication (role family, no posting text) | "I write a weekly email to families." (your CV) | medium | [generic] | none | Say it as written. |

Gate: the PEL (F1) is the only gate, and your material shows it met, so it routes by its evidence cell like any other row.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I've led a grade-level team" or "I ran the grade team" | Inflated form of F3 | "I haven't been a team lead." The curriculum move is your nearest work, at its own scope. The limit is this pack's observation: your material shows one curriculum move you led, not team leadership. |
| "I've taught fourth grade" or "I know the fourth-grade standards" | Inflated form of F2 | "I taught third grade for six years." Then the plan you would follow. |
| "I led our whole grade level" | Inflated form of F4 | "I led our grade level's move to a new reading curriculum in 2024," with nothing added. |

## Personas and weights

| Persona | Who | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|---|
| Skeptic | Principal | Quiet probes on fourth-grade fit and leadership: "where are the gaps?" | 5 | A hiring-manager voice on a role where the CV shows no fourth-grade work and no team lead | Rehearse the gap plainly once, then the ramp plan. Do not bluff. |
| Case / Strategist | Principal | Live problems from a fourth-grade classroom | 3 | Hiring managers give live problems about their own roadmap | Clarify, then structure, then one next step |
| Peer Evaluator | Team members | Collaboration, disagreement, credit, the seam between classrooms | 4 | Colleagues price what the hire adds to their own load | Reciprocity: what you bring their team, not only what you need |
| Data-Driven Prober | Team members | Probes the reading club and the 2024 move, and the six years | 4 | Team members read the CV closely and test its numbers | Defend the number in your own words. Say plainly what you did not measure. |
| Conversational | Panel, opener | An opening "walk us through" question | 2 | Casual openers are still scored | Use a 90-second arc |

Panel rule applied: each team member gets the top two personas of a peer, and the principal gets the top two of a hiring manager.

## Question banks

Question-type tags are in the Type column. Answer slots are instructions for the interview, not questions to me.

### Skeptic (principal), weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What would you do in your first month to get ready?" | JD | [grounded] "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Say it plainly: "I haven't taught fourth grade." Then the plan: which third-grade material you would check against the fourth-grade standards, who you would ask, and what you would observe first. Answer slot: if you have already reviewed fourth-grade material, name it; if not, say so. | This is the highest-ROI prep in the pack. The gap in F2 is the first thing this panel will probe, so the plan has to be ready before the question is asked. |
| A2 | "How would you lead a grade-level team you have just joined?" | CASE | [generic] | Say "I haven't been a team lead," then clarify what the team needs. Answer slot: if you led any part of the 2024 curriculum move, say which part and what you decided; if you did not set the plan, say so and describe how you would work with the team. | F3 is the capability gap. The question is hypothetical, so it presupposes nothing about your past. |
| A3 | "Which part of this job will take you longest to learn?" | JD | [generic] | Name the fourth-grade content first, in plain words, then the ramp plan you would follow. | Skeptic stem. The answer is one honest sentence and one plan. |
| A4 | "Why move from third grade to fourth? Why now?" | EXP | [generic] | Give the reason you actually have, in your own words. The material does not state one, so the reason is yours to supply. | Motivation is scored. A reason you can repeat under a follow-up beats an impressive one. |
| A5 | "What would you need from this team in your first year?" | JD | [generic] | Name specific support: planning time, the fourth-grade curriculum, a mentor. Ask for support; do not claim you already have it. | Shows you plan for the gap instead of hiding it. |

### Case / Strategist (principal), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your reading group is three weeks behind the team's pacing. What do you do this week?" | CASE | [grounded] "I write a weekly email to families." (your CV) | Clarify first: which group, what is behind, why. Then structure: check the data, talk to the team, adjust the plan, tell families. Use the weekly email as the channel you already use. | A live problem. It asks nothing about your past, and the family email is a channel you already use, quoted as written. |
| B2 | "A reading curriculum new to you is the team's standard. How do you start?" | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say what you did in the 2024 move, at its own scope, then the first steps you would take. Answer slot: if you set any part of the 2024 rollout, say which part; if not, say so. | Your closest evidence for curriculum work. The question is hypothetical. |
| B3 | "How do you keep families informed when a unit is not going as planned?" | JD | [grounded] "I write a weekly email to families." (your CV) | Say what the weekly email covers and how you would add a note when a unit changes. Do not claim you have done this unless you have. | F5 is your strongest communication evidence. |

### Peer Evaluator (team members), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our team plans together every week. What do you bring to shared planning, and what do you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Name one thing you bring from the 2024 work, at its own scope. Then name what you need, which is also the reciprocity point. | Peer reciprocity. Asking for their help shows you know your gap. |
| C2 | "Tell us about a time you disagreed with a colleague on a plan. How did it end?" | EXP | [generic] | Pick a time that ended with the plan working or the relationship intact. Answer slot: if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | Open prompt. Disagreement with equals is scored. |
| C3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Credit goes to what each person did. Say what you did and name others who did theirs. | Peer stem. Credit-sharing is scored. |
| C4 | "Our classrooms share a reading block. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam, such as a shared schedule and a named decision-maker. Do not claim to know the seam before you have seen it. | Peer stem. Principles beat pretending to know. |

### Data-Driven Prober (team members), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How do you measure whether the reading club is working?" | EXP | [grounded] "I've run the after-school reading club for the last two years." (your CV) | Say what you track and what you do not. Answer slot: if you counted anything, say what and how; if not, say so and name what you would measure first. | A premised question about your club. Never invent results. |
| D2 | "What evidence did you use to judge the 2024 reading curriculum move?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: if you used evidence, say what it was and how you read it. If you did not, say so and name the evidence you would use now. | Probers test the claims you lead with. |
| D3 | "Your résumé says six years. Which of those years would you point to as your clearest work?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Name one year and what in it was yours. If you cannot name one, say so. | Defend-the-number, applied to the six years. |
| D4 | "How would you know by December whether a student is ready for the next reading level?" | CASE | [generic] | Name the evidence you would look at, such as classwork, a short check, and the teacher's judgment. Do not name a method you have not used. | A live problem for a fourth-grade teacher. |

### Conversational (opener), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through your path to teaching." | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | A 90-second arc: Joliet, six years in third grade, the 2024 curriculum move, the reading club, and why fourth grade. Stop there. | The opener is scored for economy. |
| E2 | "What's the best part of the reading club for you?" | VAL | [grounded] "I've run the after-school reading club for the last two years." (your CV) | Say one specific thing from the club, in your own words. | Casual question, scored for genuineness. |

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| PEL (F1) | none, and why | Gate shown met. No question needed. |
| Fourth-grade content (F2) | A1, A3, B2, D4 | |
| Team leadership (F3) | A2, A5, C1 | |
| Reading instruction (F4) | B2, D1, D2 | |
| Family communication (F5) | B1, B3 | |

**Highest-ROI prep:** A1. Rehearse it until the plan is boring.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a fourth-grade teacher on this team be expected to own in the first year?" | Shows you are planning for the role |
| R2 | "How does the team plan the reading block together, and how often?" | Shows interest in their working rhythm |
| R3 | "What did the team change after its last curriculum or assessment review?" | Invites them to show their own reflection |
| R4 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, for the peer team members |
| R5 | "What's the first thing you'd want a new fourth-grade teacher to get right?" | Puts the principal's priority in their own words |
| R6 | "How does the school share its work with families?" | Connects to your weekly email (F5) |

No interviewer profile exists, so no reverse question ties to an interviewer's career path.

## Sources

**Research tier: L0.** No search or fetch was run. Inputs were the invitation and your résumé.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | skipped | Would enable the values cheat sheet |
| 2. Interview process for the role | skipped | Would fix loop structure and persona weights |
| 3. Company strategy and recent news | skipped | Would enable company-knowledge questions |
| 4. Interviewer footprint (Dolores Vantongeren) | skipped | Would enable a tailored reverse question |
| 5. Representative posting | skipped | Would convert role-family rows from [generic] to [inferred] |

## Upgrade menu

- The posting's full text → F2–F5 become [grounded] quotes, and JD-tagged questions are added
- The posting's full text, or the district's values page → the values cheat sheet
- Research at the default tier, which is up to 6 searches and 2 fetches → the district's interview process and recent news
- Dolores Vantongeren's public footprint → a tailored reverse question and persona weights
- Any deliverable HR named, such as a demo lesson → a build section for it
