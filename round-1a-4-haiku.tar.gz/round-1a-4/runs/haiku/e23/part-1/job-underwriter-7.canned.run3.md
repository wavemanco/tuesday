**Yes, apply, on three conditions.** Status: `conditional_go`.

**Fit ledger.**
- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R12
- `important`: direct: R4a, R5, R7 · adjacent: R4b, R11 · unclear: R6, R8, R9 · absent: R10
- `preferred`: absent: R13

R4b (leg-ulcer care), R10 (own caseload) and R13 (Doppler) are the rows below `direct` that matter most. R10 is the absence a recruiter will probe first.

**Opportunity ledger.** Sound on the page. Pay is stated and the posted range spans the `[generic]` interquartile band (RR2). Caseload support is described but not detailed (RR3). The post's live status and contract basis are not verified (RR1, RR5). The hiring manager's public talk on Doppler training for new community staff is a positive lead, `[inferred]` for this post (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:**
  1. The post is confirmed open and matches the advert (RR1).
  2. The caseload size and senior support for a new starter are answered satisfactorily (R10, RR3).
  3. Community experience is framed as adjacent, never as district nursing or leg-ulcer expertise (R4b, R11).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing under an NHS contract across Calderdale, founded 2015, 410 staff, four locality hubs | `[grounded]` organization's about page |
| Mandate | Caseload-holding district nursing for housebound adults at home: wounds, catheters, continence, insulin, end-of-life visits, care planning | `[grounded]` JD |
| Working pattern | Home-based, pool cars provided, mileage paid | `[grounded]` JD |
| Scope read | A normal caseload-holding Band 5 post; the caseload is "small", its size unstated | `[inferred]` from JD wording |
| Market calibration | Band 5 community staff nurse, England: median basic pay £34,300, interquartile range £32,400–£36,600 (n=1,240, 2026); 61% of respondents were paid mileage | `[generic]` role-family pay survey |
| Pay | Posted range £31,050–£37,800 spans the band and sits either side of it; mileage on top | `[grounded]` JD; band `[generic]` |
| Unknowns | Caseload size and ramp; contract basis; continence, end-of-life and care-planning expectations; EPR system | — |
| Contradictions | None found between JD and the organization's about page (both place the service in Halifax / Calderdale) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | PIN and active registration stated in CV; not yet checked on the NMC register | `[grounded]` CV | Check the PIN on the NMC register before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B stated in CV; not yet inspected | `[grounded]` CV | Carry the licence to interview |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as staff nurse, acute medical ward | `[grounded]` CV | none |
| R4a | Wound care | important | direct | medium | none | Pressure ulcers and surgical wounds stated; no leg ulcers | `[grounded]` CV | none |
| R4b | Leg-ulcer care | important | adjacent | low | transferability | Wound-care skill carries over; no leg-ulcer work stated. Limit: no leg-ulcer caseload or community leg-ulcer clinic | `[inferred]` from R4a | Bridge case only; see Application plan |
| R5 | Catheter and continence care | important | direct | medium | none | Catheter care stated; continence not mentioned | `[grounded]` CV | none |
| R6 | Continence care | important | unclear | low | discovery | Catheter work is not continence work; the CV is silent | `[grounded]` CV silence | Question 2 |
| R7 | Insulin administration | important | direct | medium | none | Stated in CV | `[grounded]` CV | none |
| R8 | End-of-life visits | important | unclear | none | discovery | No end-of-life work stated | `[grounded]` CV silence | Question 2 |
| R9 | Care planning | important | unclear | low | discovery | Discharge-to-assess role may include planning; not stated | `[inferred]` from role | Question 2 |
| R10 | Holding a small caseload of your own | important | absent | none | capability | Stated: no caseload held before | `[grounded]` your statement | Closure path in Risk register RR3 |
| R11 | Home-based nursing setting | important | adjacent | medium | transferability | Discharge-to-assess home visits, first week after discharge; limit: short, post-discharge visits, not ongoing housebound care | `[grounded]` CV | Use in positioning (Application plan) |
| R12 | Clear, timely written records; electronic patient record | must_have | unclear | low | discovery | Essential term; records and EPR not described in CV | `[grounded]` CV silence | Question 3 |
| R13 | Doppler assessment for leg ulcers | preferred | absent | none | capability | Stated: never done | `[grounded]` your statement | Ask about training (RR4) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Caseload ownership (R10, important) | capability | No caseload held; discharge visits were assigned, not owned | Interviewers will ask whether you can run a list alone | Any prioritisation of your own visits in the discharge team; a patient list you triaged | A short anonymised example of prioritising visits | `[grounded]` CV; `[inferred]` that this is the probe |
| G2 | Leg-ulcer care (R4b, important) | transferability | Pressure and surgical wounds only | The posting names leg ulcers first | Any dressing-plan or wound-review work on any leg wound | Wound-care training record | `[grounded]` CV |
| G3 | Continence, end-of-life, care planning, records (R6, R8, R9, R12) | discovery | Not in CV | Core to the role's daily work | Any continence assessment, end-of-life visit, care plan, or EPR use | Anonymised record or care-plan excerpt | `[grounded]` CV silence |

The queue holds no questions. Its questions are in the closing block.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Post's live status unverified | unknown | — | Careers page fetch returned "No page" | The advert may be closed, or the post may be circulated outside the careers listing | `[generic]` pattern for postings of this kind | Is this post still open, and is it the advert I'm looking at? | unresolved |
| RR2 | Pay stated | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Pay is disclosed and spans the band | `[grounded]` JD; band `[generic]` | Where in this range will an offer for this post sit? | unresolved |
| RR3 | Caseload support unspecified | unknown | — | "hold a small caseload of your own, supported by a senior community nurse" | Caseload size and support may not be fixed for the first months | `[inferred]` from JD silence on size and ramp | What caseload size and senior support will a new starter have in the first three months? | unresolved |
| RR4 | Doppler training may be provided | positive_signal | — | Speaker bio: "Doppler training for staff new to community work" | Training may exist for new starters, though not confirmed for this post | `[grounded]` public talk listing; `[inferred]` for this post | Is Doppler training provided for staff who join without the skill, and is it part of the post? | unresolved |
| RR5 | Contract basis unstated | unknown | — | JD silent on permanent or fixed-term | The post may be fixed-term | `[inferred]` from JD silence | Is this post permanent or fixed-term? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Restate the CV line on the discharge-to-assess role as: "18 months in the discharge-to-assess team, making home visits in the first week after discharge" | Puts R11 forward in your own words, with no new scope | `[grounded]` CV | resume_edits_pending_approval |
| E2 | List wound care exactly as "pressure ulcers and surgical wounds"; do not claim leg-ulcer or Doppler experience | Keeps R4b and R13 at their true fit | `[grounded]` R4a, R4b, R13 | resume_edits_pending_approval |
| A1 | Check your PIN on the NMC register before applying | Confirms the hard gate (R1) against an inspectable record | `[grounded]` CV | pending your approval |
| A2 | Ask the post's status and the contract basis before investing in the application | RR1, RR5 | `[grounded]` register | pending your approval |
| A3 | At the informal chat, ask RR3 and RR4 | The register doubles as interview preparation | `[grounded]` register; `[inferred]` that the chat is the right venue | pending your approval |
| A4 | Interview bridge line for R4b and R11, to approve or change: "I haven't done leg-ulcer work. My wound care is pressure ulcers and surgical wounds, and I have made home visits in the first week after discharge." | Limit stated with the bridge, as the skill requires | `[grounded]` CV; reframing audit: no clause beyond your sentences | pending your approval |

Interview rehearsal belongs to the sibling skill, mock-interview.

## Evidence status

Verified: none yet. Every row rests on the CV as written, and the CV is self-report.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Community Staff Nurse Band 5 Calderbrook Community Health jobs"; fetched calderbrookhealth.example/careers, which returned "No page". The about page (calderbrookhealth.example/about) confirms the organization exists as described; the post is not verified live (RR1) |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary £31,050 £37,800", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration `[generic]`; RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned a speaker bio (communitynursingforum.example/speakers/rhiannon-mabbott): leads the Halifax district nursing team; 2025 forum talk on leg-ulcer clinics and Doppler training. Feeds RR4 and the interview bridge |

Failed attribution: not triggered. The employer is attributable to the about page. Clearing RR1 still means seeing the live advert.

The dossier offer: I can save this assessment as `tuesday-dossier.md` if you want it kept.

## Upgrade menu

- The NMC register check, and the live advert or the employer's confirmation that the post is open → R1 to `high`; RR1 closes.
- Anonymised record or care-plan excerpt, or wound-care training record → R12 and R4a to `high`.
- Any continence, end-of-life or care-planning work → R6, R8 and R9 move off `unclear`.
- Your minimum pay, mileage needs, and any shift or location limits → the hard-gate checks against you become possible. Currently "unknown".
- Deeper research on the organization (funding, leadership changes, recent staff or inspection reports, up to 5 more searches and 2 more fetches). This is offered once; say the word and it runs.

## Questions

Question 1 (hard gates): What is your minimum pay, how much mileage can you take on, and do you have any shift or location limits? Those decide whether the hard-gate checks against you are met.

Question 2 (R6, R8, R9): In your discharge-to-assess work or elsewhere, did you ever assess continence, do end-of-life visits, or write care plans? Describe one example.

Question 3 (R12): Which electronic patient record have you used, and how did you keep written records under time pressure?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.