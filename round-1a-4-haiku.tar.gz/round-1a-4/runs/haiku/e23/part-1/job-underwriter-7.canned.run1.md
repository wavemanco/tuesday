**Decision snapshot: conditional_go**

- **Fit ledger:** Essentials met on registration, licence and experience. Strong partial fit on wound, catheter and insulin care. Not yet evidenced for own caseload, end-of-life visits, continence care, care planning as your own work, and electronic records. Desirable Doppler not held.
- **Hard gates:** Registration (met, verify on the NMC register). Full licence (met). Location: Halifax (matches). Pay: advertised £31,050–£37,800, your floor unknown. Mileage terms unclear.
- **Confidence:** Medium. Everything rests on your CV and the advert. I did not run web research, so the employer is unverified.

Research tier: L0, no searches. The employer, the Band 5 pay point and any community norms are not checked.

## Role reality

- **Stated responsibilities:** District nursing for housebound adults. Wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, all on an electronic record. A small personal caseload with senior support.
- **Scope signal:** This is a community role with autonomy. "Supported by a senior" suggests supervision, not a shadowing post. `[inferred]`
- **Contradictions and unknowns:** The advert says "Community Staff Nurse, Band 5" and "plus mileage", but pool cars are provided. It is unclear whether mileage applies to your own car. Calderbrook Community Health CIC is not verified. `[grounded]` for what the advert says, nothing more.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | NMC Adult registration | Essential | met | high | hard-gate | CV: registration active, PIN, revalidation March 2028 |
| 2 | Full UK driving licence | Essential | met | high | hard-gate | CV: category B |
| 3 | 1+ year post-registration | Essential | met | high | none | Five years as staff nurse |
| 4 | Clear, timely written records | Essential | partly | medium | discovery | Ward and discharge work implies charting; no sample |
| 5 | Wound care, incl. leg ulcers | Essential | partly | medium | transferability | Pressure ulcers and surgical wounds; leg ulcers not stated |
| 6 | Catheter and continence care | Essential | partly | medium | discovery | Catheter care stated; continence not stated |
| 7 | End-of-life visits | Essential | not evidenced | low | discovery | Not in CV |
| 8 | Insulin administration | Essential | met | high | none | CV |
| 9 | Care planning | Essential | partly | low | discovery | Discharge work may include planning; unconfirmed |
| 10 | Own caseload | Stated responsibility | not held | — | capability/experience | CV: never held one |
| 11 | Home-based working | Implied | partly | medium | transferability | Home visits in discharge-to-assess role |
| 12 | Electronic patient record | Implied | not stated | low | discovery | Not in CV |
| 13 | Doppler assessment | Desirable | not held | — | capability | CV: never done one |

## Gap recovery queue

- **Row 10, own caseload:** Closest evidence is home visits in your discharge role. Whether you planned and ran those visits yourself is unknown.
- **Row 13, Doppler:** Trainable. Closing it means a training record or an employer commitment to train.
- **Rows 6, 7, 9, 12:** Discovery items. They may already be covered by experience you haven't listed.

## Opportunity risk register

- **Employer unverified (standing entry):** Not confirmed. Check the Companies House CIC register and the live posting before applying.
- **Pay and terms (medium):** Your floor is unknown, so there is no comparison yet. Band 5 scale and mileage terms are unconfirmed.
- **Autonomy and support (medium):** Caseload size and supervision are not stated.
- **Doppler expectation (low):** Desirable only. Confirm whether training is provided.

## Application plan

- **Lead with:** Five years on an acute medical ward, plus home visits in your discharge-to-assess role. Then wound care, catheter care and insulin, and your Halifax base.
- **Don't claim without evidence:** A community caseload, Doppler, leg ulcers, continence care, end-of-life work or electronic record experience. "Visited patients at home" is accurate. "Managed a community caseload" would overstate it.
- **Before anything goes out:** Any CV wording would be proposed as edits for your approval first. I won't finalize it without that.
- **Informal chat:** Contact Rhiannon Mabbott. Ask about caseload size, supervision, Doppler training, electronic record system, the pay point and mileage.

## Evidence status

| Target | Status | Reason |
|---|---|---|
| L1-1: employer site and careers page | skipped | Not run at L0 |
| L1-2: role-family sweep | skipped | Not run at L0 |
| L1-3: hiring manager footprint | n/a | No name given |

The dossier-offer, upgrade-menu and question shapes come from the skill's reference files, which I did not read in full before writing this.

I can save this as `tuesday-dossier.md` for a later prep session if you want it.

**Upgrade menu**
- **Live posting or employer careers page:** Verifies the employer, pay point and mileage terms.
- **L1 research (up to 5 searches, 2 fetches):** Confirms the CIC and its scale, and gives a generic Band 5 community norm.
- **NMC register check:** Upgrades the registration row to verified.
- **Any Doppler, continence or record-system experience:** Upgrades the matching rows.

Three questions. Answer any, or say skip. Skipping counts as an answer.

1. In your discharge-to-assess role, did you plan and run your own visits from start to finish, or go out on other people's plans?
2. Which of these have you done, even briefly: continence assessment, end-of-life visits, or charting in an electronic patient record?
3. What is your pay floor, and would you need mileage on your own car covered?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.