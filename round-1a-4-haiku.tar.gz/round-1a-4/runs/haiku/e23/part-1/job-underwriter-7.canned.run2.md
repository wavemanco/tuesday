**Worth applying for, as a conditional go.** Your hands-on clinical core matches the post. The gaps are leg-ulcer work, Doppler, owning a caseload, and written records. None of them is a hard gate.

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R7, R9 · adjacent: R5 (leg-ulcer part) · unclear: R4 (written records)
- `important` — adjacent: R13 (own caseload) · unclear: R8 (continence), R10 (care planning), R11 (end-of-life visits), R12 (electronic patient record)
- `preferred` — absent: R6 (Doppler assessment)

R5 (`adjacent`) is a credible bridge with its limit named. R1 and R2 are `direct` at `medium` confidence: stated by you, not yet checked.

**Opportunity ledger.** The employer is real, but the posting itself is unconfirmed (RR3). Two unknowns, caseload size and salary position, are open (RR1, RR2). Pool cars and a named team lead with public Doppler teaching are positive signals (RR4, RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found

**What would change this:** the posting is confirmed live on the careers page (RR3); your NMC register entry checks out (R1); the caseload and leg-ulcer answers come back as you'd expect (RR1, R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing across Calderdale under an NHS contract, founded 2015, 410 staff, four locality hubs | `[grounded]` about page |
| Mandate | District nursing for housebound adults: wounds and leg ulcers, catheter and continence, end-of-life, insulin, care planning, on an electronic record | `[grounded]` JD |
| Working pattern | Home visits; a small personal caseload; pool cars; mileage paid | `[grounded]` JD |
| Scope read | A caseload-holding community post, not a discharge-team visiting role. Ownership of ongoing care is the step up | `[inferred]` from the JD's caseload wording against your discharge-team role |
| Market calibration | Band 5 community staff nurse, 2026 survey of 1,240: median £34,300, middle half £32,400–£36,600. The posting's £31,050–£37,800 brackets that middle | `[generic]` Wardround 2026 survey; `[grounded]` JD range. This is a pattern, not this employer's offer |
| Unknowns | Caseload size; what senior-nurse support looks like; where in the range this starts; how continence, end-of-life and EPR use split across the role | — |
| Contradictions | None found between the JD and the employer's about page. The posting itself was not located | `[grounded]` about page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | NMC registration as Adult Nurse | hard_gate | direct | medium | none | Registration active, stated by you; not yet checked against the register | `[grounded]` CV | Check your NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B licence stated; pool cars mean no car of your own is needed | `[grounded]` CV, JD | none |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years as staff nurse; no reference yet | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | CV silent on record quality | `[grounded]` CV silence | G4 |
| R5 | Wound and leg-ulcer care | must_have | adjacent | medium | transferability | Wound care including pressure and surgical wounds is real; leg ulcers are not named in the CV | `[grounded]` CV; `[inferred]` bridge | G1 |
| R6 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No evidence in the CV | `[grounded]` CV | G2 |
| R7 | Catheter care | must_have | direct | medium | none | Named in the CV | `[grounded]` CV | none |
| R8 | Continence care | important | unclear | low | discovery | CV silent on continence | `[grounded]` CV silence | G5 |
| R9 | Insulin administration | must_have | direct | medium | none | Named in the CV | `[grounded]` CV | none |
| R10 | Care planning | important | unclear | low | discovery | Home visits are in the CV; planning is not named | `[grounded]` CV silence | G5 |
| R11 | End-of-life visits | important | unclear | low | discovery | CV silent | `[grounded]` CV silence | G5 |
| R12 | Electronic patient record | important | unclear | low | discovery | CV silent on which system | `[grounded]` CV silence | G5 |
| R13 | Holding a small caseload | important | adjacent | medium | transferability | Home visits in the discharge-to-assess team are real; caseload ownership is not | `[grounded]` CV; `[inferred]` bridge | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R5, must_have) | transferability | Wound care is real; leg ulcers are not named | A must-have row; a clear bridge narrows the likeliest objection | Any wound round or review where compression or dressing choice was part of the plan | A sanitized wound-care care plan or audit | `[grounded]` CV; `[inferred]` bridge |
| G2 | Doppler assessment (R6, preferred) | capability | No evidence | Preferred, so a minor risk; a closure path matters more than the gap | A Doppler course, or staff training if the employer offers it | A course certificate, or a plan to learn it | `[grounded]` JD; `[inferred]` that the employer offers training (from RR5) |
| G3 | Own caseload (R13, important) | transferability | Discharge-team home visits; no owned caseload | This is the step up the post describes | Any patient you led the plan for across several visits | A sanitized visit plan | `[grounded]` CV; `[inferred]` bridge |
| G4 | Written records (R4, must_have) | discovery | CV silent | A must-have row, and the JD names it | Discharge summaries, EPR entries, handovers | A sanitized record excerpt | `[grounded]` JD; `[inferred]` that it moves the decision |
| G5 | Continence, care planning, end-of-life, EPR (R8, R10, R11, R12) | discovery | CV silent on all four | Four important rows; any one could still be a strong fit | Each one, if it was part of your ward or discharge work | Role descriptions, EPR training records | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload size and senior-nurse support unstated | unknown | — | "a small caseload of your own, supported by a senior community nurse" | The caseload may be full from day one, with support in name only | `[inferred]` from the post's silence on size and supervision | How many patients would I hold at the start, and what does supervision by the senior nurse look like week to week? | unresolved |
| RR2 | Salary point in range unstated | unknown | — | "£31,050–£37,800 a year plus mileage" | The start point may sit low in the range | `[generic]` Wardround 2026 middle half £32,400–£36,600 | Where in this range does the post start for someone with five years' post-registration experience, and what is the mileage rate? | unresolved |
| RR3 | Posting not located on any page reached | risk_signal | low | "Community Staff Nurse, Band 5" | The post may have closed or been relisted, or the page reached may not be the live careers page | `[generic]` pattern for listings; `[grounded]` employer exists on the about page | Is this post live on your careers page now, and is it the post I'd be applying to? | unresolved |
| RR4 | Pool cars and mileage provided | positive_signal | — | "pool cars are provided" | No own car is needed; mileage covers the rest | `[grounded]` JD | Which pool cars are available for Halifax-area visits, and how is mileage claimed? | noted |
| RR5 | Team lead's public Doppler teaching | positive_signal | — | Forum speaker page: "Doppler training for staff new to community work" | The team trains new staff in Doppler, so R6 may be closable after hiring | `[grounded]` speaker page; `[inferred]` that training is offered to new hires | Is Doppler training provided for staff new to community work, and what would it look like for me? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the community-facing bullets with the 18-month discharge-to-assess home visits | Presentation of real evidence; see R13 | `[grounded]` CV | pending your approval |
| E2 | Add a record-keeping line only where you can point to a real example | see R4; no claims about EPR use until you confirm it | `[grounded]` R4 | pending your approval |
| A1 | Check your NMC register entry and confirm the revalidation date | Moves R1 from `medium` to `high` | `[grounded]` CV | yours to do |
| A2 | Confirm the post is live on the careers page before applying | see RR3 | `[grounded]` RR3 | yours to do |
| A3 | Contact Rhiannon Mabbott for the informal chat, asking RR1, RR2 and RR5 | The JD names her as the contact | `[grounded]` JD | your decision |

Every row is a proposal. Nothing goes into a CV or a message until you approve it.

## Evidence status

Verified: none yet. Your CV claims are self-reported leads until checked.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health careers Community Staff Nurse Band 5 district nursing"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). The employer checks out as a real CIC with an NHS contract. The posting was not found on any page reached, so RR3 stays open |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse salary district nursing UK 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration line and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned the speaker page at communitynursingforum.example/speakers/rhiannon-mabbott. Moved RR5 and the positioning. Public talk only |

## Upgrade menu

- Your NMC register entry, checked → R1 to `high`
- A sanitized wound-care plan or audit that includes a leg ulcer, even a small one → R5 firmer, and it answers the bridge question
- A sanitized visit plan you led across several visits → R13 firmer
- A link to the live posting on the careers page → RR3 closes
- Your answer to the chat questions in RR1 and RR2 → caseload and salary terms known before you apply
- A deeper research pass on Calderbrook (recent staffing and contract news, past recruitment rounds; up to 5 more searches and 2 more fetches). Say the word and it runs. I'd offer this once; it's optional.

If you want, I can write this up as a `tuesday-dossier.md` file to keep and to hand to mock-interview later.

Three questions, each tied to a gap row. Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**G1** — Have you ever dressed, measured, reviewed or planned care for a leg ulcer, even as part of a wider wound round or a discharge plan? What was your part?

**G3** — On the discharge-to-assess visits, did you ever lead a patient's plan across several visits, or was that the team's? What did you own?

**G4** — Give me an example of a record you wrote that someone relied on, such as a discharge summary, an EPR entry or a handover. How was it checked?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.