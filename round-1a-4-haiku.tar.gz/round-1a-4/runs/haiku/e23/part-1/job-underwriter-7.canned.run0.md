**Yes, it's worth applying for, on three conditions. Status: `conditional_go`.** Your hard requirements are met on your own account, and the one clear gap is caseload ownership, which you can describe honestly. Two things can't be settled from here: the posting isn't confirmed live, and the caseload and support details aren't in the advert.

**Fit ledger.**

- `hard_gate`: direct: R1, R2, R3
- `must_have`: direct: R4, R6, R8, R10 · adjacent: R7 (leg-ulcer care), R13 (independent caseload) · unclear: R5 (clear, timely written records), R9 (continence care), R11 (care planning), R12 (end-of-life visits)
- `important`: unclear: R14 (electronic patient record)
- `preferred`: absent: R15 (Doppler assessment for leg ulcers)

R13 and R7 are the two must-haves you can't claim as direct. R15 is desirable only, and you've never done one.

**Opportunity ledger.** The employer is established: a community interest company running adult community nursing across Calderdale under an NHS contract. The posting itself is unconfirmed (RR3), and the caseload size, senior-nurse support and mileage terms are unstated (RR1, RR2). One positive signal: the team lead has spoken publicly on leg-ulcer clinics and on Doppler training for people new to community work (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR3: the vacancy is confirmed open; (2) RR1: caseload size and senior-nurse support are clear; (3) R7 and R15 are presented as adjacent or not yet done, never as experience.

**Research tier: L1 — searches 3 of 5, fetches 1 of 2**

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, founded 2015, 410 staff, four locality hubs | `[grounded]` about page (calderbrookhealth.example/about) |
| Mandate | District nursing home visits to housebound adults: wounds, catheters, continence, insulin, end-of-life, care planning, with a small caseload | `[grounded]` advert |
| Working pattern | Home visits; pool cars provided; mileage paid | `[grounded]` advert |
| Scope read | A small caseload with a senior nurse behind it | `[inferred]` from the advert's own description |
| Pay | Posted £31,050–£37,800 plus mileage | `[grounded]` advert |
| Market calibration | Survey median £34,300; interquartile range £32,400–£36,600; 61% of respondents paid mileage. The posted range covers that interquartile range | `[generic]` Wardround 2026 community nursing pay guide, England, n=1,240 |
| Unknowns | Caseload size, senior-nurse support, service area, mileage versus pool cars, whether the post is open | — |
| Contradictions | None between the advert and the about page. The careers page I tried returned nothing, so the posting is unverified, not contradicted | `[grounded]` fetch result |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | NMC registration, Adult Nurse, current | hard_gate | direct | medium | none | CV states active registration; the NMC register is the inspectable check | `[grounded]` CV | Check the register entry before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states full category B | `[grounded]` CV | Have it to hand |
| R3 | Work base in Halifax | hard_gate | direct | medium | none | You live in Halifax; advert base is Halifax; service area unstated (RR1) | `[grounded]` CV and advert | none |
| R4 | At least one year post-registration | must_have | direct | medium | none | Five years as a staff nurse. The one-year bar isn't tied to a legal bar, so it's graded on fit | `[grounded]` CV | none |
| R5 | Clear, timely written records | must_have | unclear | low | discovery | CV is silent on documentation | `[grounded]` CV silence | G3 |
| R6 | Wound care: pressure and surgical wounds | must_have | direct | medium | none | CV names both | `[grounded]` CV | none |
| R7 | Leg-ulcer wound care | must_have | adjacent | low | transferability | Wound work carries over; leg ulcers are not named in the CV. Limit: no leg-ulcer caseload stated | `[grounded]` CV silence; `[inferred]` adjacency from pressure-ulcer work | G2 |
| R8 | Catheter care | must_have | direct | medium | none | CV names catheter care | `[grounded]` CV | none |
| R9 | Continence care | must_have | unclear | low | discovery | CV is silent | `[grounded]` CV silence | G2 |
| R10 | Insulin administration | must_have | direct | medium | none | CV names it | `[grounded]` CV | none |
| R11 | Care planning | must_have | unclear | low | discovery | CV is silent on planning | `[grounded]` CV silence | G1 |
| R12 | End-of-life visits | must_have | unclear | low | discovery | Home visits are adjacent; end-of-life work is not named | `[grounded]` CV silence | G2 |
| R13 | Holding a small caseload independently, with a senior nurse | must_have | adjacent | medium | transferability | Seconded to home visits in the first week after discharge. You've never held your own caseload (your statement). Limit: caseload ownership | `[grounded]` CV and your statement | G1 |
| R14 | Electronic patient record | important | unclear | low | discovery | CV doesn't name the system | `[grounded]` CV silence | G3 |
| R15 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You've never done one. Closure path: formal Doppler training; the team lead has spoken on training for new staff | `[grounded]` your statement and speaker listing | Ask the team; claim no exposure |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Caseload and planning (R13, R11) | transferability | Home visits and discharge planning in the CV; no ownership of a list | Caseload is an essential responsibility in the advert | Planning and deciding the next step on discharge visits; running a daily visit list with a senior to call on | A visit list or anonymised care plan you wrote | `[grounded]` CV; `[inferred]` that ownership is what the advert means |
| G2 | Leg-ulcer, continence, end-of-life (R7, R9, R12) | transferability | Pressure and surgical wounds; catheter and insulin care | Three must-haves at unclear or adjacent | Any home-setting dressing, continence assessment or end-of-life visit, even if supervised | An anonymised wound-care or handover record | `[grounded]` CV silence |
| G3 | Records and electronic record (R5, R14) | discovery | Records not described in the CV | Essential in the advert; both rows unclear | Any home-visit documentation, whichever system | A record extract with identifiers removed | `[grounded]` CV silence |
| G4 | Doppler (R15) | capability | No Doppler and no adjacent evidence | Desirable, not essential | None to claim | Training record if any | `[grounded]` your statement |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload size and senior support unstated | unknown | — | "hold a small caseload of your own, supported by a senior community nurse" | Caseload or support may be heavier in practice than the wording suggests | `[inferred]` from the advert's silence on size | What is a typical caseload size, how much out-of-hours cover is there, and how wide is the service area? | unresolved |
| RR2 | Mileage terms unstated | unknown | — | "£31,050–£37,800 a year plus mileage" | Mileage may not be paid on own-car use if pool cars cover visits | `[inferred]` from "pool cars are provided" against the mileage line; `[generic]` survey band in market calibration | Is mileage paid when I use my own car, and are pool cars available for home visits? | unresolved |
| RR3 | Posting not confirmed live | risk_signal | low | "Current vacancies are listed on our careers page" (about page) | The post may be closed, or the advert may be out of date | `[grounded]` about page quote; `[inferred]` from one failed fetch of a guessed careers address | Is this vacancy open now, and can you point me to it on your careers page? | unresolved |
| RR4 | Team invests in leg-ulcer and Doppler work | positive_signal | — | Speaker listing, 2025: leg-ulcer clinics and Doppler training for new community staff | Doppler training may be available to you if hired | `[grounded]` speaker listing; `[inferred]` that it applies to this post | What Doppler training does the team give people who haven't done one, and when? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the discharge-to-assess home visits and the wound care, and state plainly that you haven't held a caseload | R13, R6 | `[grounded]` CV | pending your approval |
| A1 | Confirm the vacancy is open before you write | RR3 | `[grounded]` about page | pending your approval |
| A2 | Take up the advert's invitation to an informal chat with Rhiannon Mabbott and ask RR1, RR2 and RR4 | Register | `[grounded]` advert | pending your approval |
| A3 | Describe leg-ulcer and Doppler work as not yet done, and ask about the training route. Don't claim any exposure | R7, R15 | `[generic]` interviewers test claims about unfamiliar skills | pending your approval |

Approval covers the wording in E1 and A3 only, not any sentence you haven't read.

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health community staff nurse vacancy Rhiannon Mabbott". The about page (calderbrookhealth.example/about) confirms the employer. Fetched calderbrookhealth.example/careers: no page. Moved RR3 |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse salary NHS England 2026 £31,050 £37,800". Returned Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched the named contact with the employer, as above. Returned her speaker listing at communitynursingforum.example/speakers/rhiannon-mabbott. Moved RR4 and the Doppler handling in A3 |

**Upgrade menu**

- Your NMC register entry, checked → R1 moves to `high`
- An anonymised visit list or care plan from discharge visits → R13 and G1 strengthen
- A wound-care or handover record with any leg-ulcer work → R7 narrows
- The recruiter's or careers-page confirmation → RR3 closes
- A deeper pass on Calderbrook (accounts, inspection reports, recent news; up to 5 more searches and 2 more fetches). It's on offer once; say the word and it runs.

If you want, I can write this up as `tuesday-dossier.md`, a file you can keep and reuse.

**Questions**

1. **G1:** On the discharge visits, did you plan each patient's visits and decide next steps yourself, or did a senior decide? Roughly how many patients were you seeing a week?
2. **G2:** Have you dressed or assessed a leg ulcer, done a continence assessment, or been on an end-of-life visit at home? If so, what was your part?
3. **G3:** Which electronic record system have you used, and how did you keep notes on home visits?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.