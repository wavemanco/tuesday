**Yes, apply: `conditional_go`.** Your two gates are met and most essentials are evidenced on paper. What's open is whether a first caseload comes with enough support, and two clinical areas the advert names that your CV doesn't cover.

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4
- `important`: direct: R5, R7, R9 · adjacent: R6, R11, R12 · unclear: R8, R10, R13
- `preferred`: absent: R14

R4 (written records) is the must-have that could move the status. R6 and R12 are the adjacent bridges, and their limits are named in the gap queue.

**Opportunity ledger.** The advert is clear about the work and gives real support detail: a senior nurse, pool cars, a named contact. It is silent on caseload size, out-of-hours duties, contract type and pay basis (RR1 to RR4, all `[inferred]` from that silence). I see no red flags.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) caseload size and clinical support are described concretely (RR1); (2) out-of-hours and contract basis are confirmed (RR2, RR4); (3) you present leg-ulcer work and caseload as adjacent, not held (R6, R12).

Stage assumed: evaluating.

Research tier: L0 — no searches; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | You chose L0. Would have checked that Calderbrook exists as described and the posting is live. The employer is unverified. |
| 2. Role-family sweep | unavailable | You chose L0. Would have set the posted band against community-nursing norms. |
| 3. Hiring manager's public footprint | unavailable | You chose L0. A name is given (Rhiannon Mabbott), so a check was possible. It would only have shaped how you approach the chat. |

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, Halifax. Existence not checked. | `[grounded]` advert; unverified |
| Role | Community Staff Nurse, Band 5. District nursing for housebound adults at home, with a small own caseload under a senior community nurse. | `[grounded]` advert |
| Work | Wounds and leg ulcers, catheter and continence, end-of-life visits, insulin, care planning, all on the EPR | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` advert |
| Working pattern | Home-based, pool cars. Hours, on-call and lone working not stated. | `[grounded]` advert silence |
| Unknowns | Caseload size, out-of-hours, contract type, whether Band 5 terms apply | — |
| Contradictions | None visible; the advert is a single source | — |
| Market calibration | Not run at L0. The pay figure is the advert's own. | — |

**Evidence map.** Every claim is your CV's self-report, so confidence stays at `medium` at most.

| # | Requirement | Priority | Fit | Confidence | Gap | Basis (provenance) | Next action |
|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | PIN and active status on CV `[grounded]` | You check your NMC register entry before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B on CV `[grounded]` | none |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years as staff nurse `[grounded]` | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | CV silent on records `[grounded]` | Q1 |
| R5 | Wound care, incl. pressure ulcers and surgical wounds | important | direct | medium | none | CV `[grounded]` | none |
| R6 | Leg-ulcer care | important | adjacent | low | transferability | Wound care carries over; leg-ulcer assessment and compression not stated `[inferred]` | Gap queue G2 |
| R7 | Catheter care | important | direct | medium | none | CV `[grounded]`; hospital setting | none |
| R8 | Continence care | important | unclear | low | discovery | CV silent | Q3 |
| R9 | Insulin administration | important | direct | medium | none | CV `[grounded]` | none |
| R10 | End-of-life visits | important | unclear | low | discovery | CV silent | Q2 |
| R11 | Care planning | important | adjacent | low | transferability | Discharge-to-assess planning `[inferred]` | Gap queue G3 |
| R12 | Holding a small caseload | important | adjacent | medium | transferability | Home visits, first week after discharge, within a team; never held own caseload `[grounded]` CV | Gap queue G3 |
| R13 | Recording on an electronic patient record | important | unclear | low | discovery | CV silent on system | Q1 |
| R14 | Doppler assessment (desirable) | preferred | absent | none | capability | None on CV | Gap queue G4 |

**Gap recovery queue.** Questions for these rows are in the closing block.

- **G1 (R4, discovery):** the CV doesn't say how or where you recorded visits. Closed by one concrete example of a timely, clear note.
- **G2 (R6, transferability):** carries over: wound assessment and dressings in patients' homes. Limit: leg-ulcer aetiology and compression are not on your CV. Strengthener: any leg-ulcer patient you've cared for.
- **G3 (R12, transferability):** carries over: home assessment and discharge planning with some autonomy. Limit: you have not owned a caseload or its follow-up. Strengthener: one case where you made a call and followed it through.
- **G4 (R14, capability):** no credible evidence. The closure path is training, which "desirable" implies. Carried as a minor risk.

**Opportunity risk register.**

| # | Signal | Class | Severity | Hypothesis (provenance) | Verification question | Status |
|---|---|---|---|---|---|---|
| RR1 | Caseload size and clinical support not described | unknown | — | Caseload may be large or loosely supported `[inferred]` from advert silence | How many patients would I hold at once, and who reviews my clinical decisions day to day? | unresolved |
| RR2 | Out-of-hours, on-call and lone working not stated | unknown | — | Duties may sit outside the stated hours `[inferred]` from silence | What out-of-hours or on-call duties come with the post, and how is lone working supported? | unresolved |
| RR3 | Doppler training not stated | unknown | — | Desirable skill may be expected on arrival `[inferred]` from silence | Is Doppler training provided, and within what timeframe? | unresolved |
| RR4 | Contract type and pay basis unstated | unknown | — | "Band 5" is commonly a national pay label; a CIC may use its own scale `[generic]` pattern, applicability `[inferred]` | Is the post permanent, do Agenda for Change terms apply, and what is the mileage rate? | unresolved |
| RR5 | Senior nurse support, pool cars, named contact | positive_signal | — | Support is stated, not assumed `[grounded]` advert | Who would I call for clinical queries in the first months? | noted |

**Application plan.** Every line below is proposed and pending your approval, except P1, which you do yourself.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check your NMC register entry before applying | R1 | `[grounded]` your PIN | yours to do |
| P2 | CV: lead with home assessment and with wound, catheter and insulin care. Don't add caseload, leg-ulcer, Doppler or EPR. | R5, R7, R9, R12 | `[grounded]` CV | pending your approval |
| P3 | Cover letter: say plainly you haven't held your own caseload, and what you'd bring to one | R12 | `[grounded]` CV | pending your approval |
| P4 | Leg ulcers: describe what you've seen and what you'd want trained. Don't claim Doppler. | R6, R14 | `[grounded]` CV | pending your approval |
| P5 | Informal chat with Rhiannon Mabbott: put RR1 to RR4 to them. Rehearsing it is the mock-interview skill's job. | RR1–RR4 | `[grounded]` advert | ready |

**Evidence status.** Verified: none yet. Every claim is your CV's self-report. Rejected inferences: none.

Research tier line above is the full accounting. No recap follows.

I can write this up as a `tuesday-dossier.md` to carry into interview prep.

**Upgrade menu.**

- A leg-ulcer, continence or end-of-life case you've handled or observed, even on the ward → R6, R8, R10 move.
- The name of the record system you used on discharge visits, plus one documented note → R4 and R13 move.
- The live posting or Calderbrook's own careers page → confirms the employer, and closes RR4 and RR5.
- Any non-negotiables (a pay floor, hours, a contract type you won't take) → the constraint checks run instead of showing as unknown.
- Research at L1: checks Calderbrook exists and the posted band against role norms. Up to 5 searches and 2 fetches. Say the word and I'll run it.

**Questions.** Each is tagged to the row it closes.

1. **R4 / R13:** On your discharge-to-assess visits, what did you write up after each one, and on what system? Can you describe one note you're proud of for being timely and clear?
2. **R10:** Have you been involved in end-of-life or palliative visits or discharges, on the ward or at home? What was your part?
3. **R8 / R6:** Have you seen or managed leg ulcers (compression, assessment) or continence care (catheters, bladder or bowel problems, pads) in any setting? What did you do?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.