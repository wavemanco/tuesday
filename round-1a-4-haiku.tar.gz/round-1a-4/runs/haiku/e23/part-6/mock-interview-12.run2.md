**Please don't send the fee, your passport, or your bank details, and don't deposit that cheque.** This email has the hallmarks of a job scam:

- **Fee before interview.** Legitimate employers don't charge candidates for equipment or registration, and the €95 is going to a "supplier", not the company.
- **Passport and bank details before any interview.** Passport photos and bank details are what identity thieves need. An employer doesn't need them until after an offer, and never by email before an interview.
- **Cheque deposit and forward.** A fake cheque for €1,850 is a classic trap. The bank may credit it at first, then reverse it weeks later when it bounces. Any money you've sent from your own account is then gone, and you're liable for it.
- **The email domain.** `hr@brennock.example` ends in `.example`, a reserved placeholder domain that can't receive real email. It may be a copy-paste error, but check it.

**Before you reply to anyone, check:**
1. Search the Companies Registration Office (cro.ie) for Brennock Facilities Ltd. Does it exist, and what address and directors does it list?
2. Find the company's website yourself through a search, not a link from the email. Does it list this vacancy? Does the phone number match?
3. Check the job ad where you first saw it. Is it still live on the job board or the company's careers page?
4. Phone the company on the number you found independently and ask whether they're hiring for this role and whether that office manager exists.

**If you've already sent money, bank details, or a passport photo:** call your bank now, report the transfer or cheque, and ask them to freeze the account it went to. Report the scam to the Gardaí and to the Garda National Cyber Crime Bureau, and be wary of anyone who offers to "recover" your money for a fee. Tell me whether you've sent anything yet, because that changes the next steps.

**Interview prep, if the job turns out to be real.** Your background fits the role better than you might think. Keep every answer to what you actually did.

- **Calendars:** Running the appointment book for four physios is directly relevant. Be ready to explain how you handled double bookings, cancellations and competing priorities. Ask yourself what the real process was, and describe that.
- **Invoices:** Chasing unpaid invoices shows you know the money side of the work. Be clear that it was receivables, not supplier invoices, and that you'd need to learn their approval process. Say that plainly rather than stretching it.
- **Travel booking:** Your material doesn't show this, so don't claim it. Say you'd learn their booking tools quickly and point to your scheduling experience.
- **Word and Excel:** Describe your real level ("good with Word, comfortable with basic Excel") and give one specific example. If you're asked to show a spreadsheet, be honest about what you can and can't do.
- **Likely questions:** "Tell me about managing a busy calendar." "How did you handle chasing an overdue invoice?" "What's your experience with travel booking?" "How do you keep organised when working remotely?" Plan a specific example for each.
- **Good questions for them:** "What does a typical week look like in this role?" "Which systems will I use day to day?" "Who would I support, and how is the work prioritised?"

The interview is 30 minutes with the office manager, so expect a mix of background questions and a practical scenario about the calendar or invoices. Once you've verified the company, come back and I can build a fuller prep pack and run a practice interview with you.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.