**Stop before you prep: this looks like a job scam.** Please don't pay anything, send anything, or deposit anything yet.

- **The €95 "equipment registration fee" before interview.** Real employers don't charge candidates to be interviewed or to register.
- **Passport photo and bank details before interview.** That is identity-theft material, and no interview needs it.
- **The €1,850 cheque.** This is the fake-cheque scam. You deposit the cheque, send them the balance, and the cheque bounces days or weeks later. The bank then debits your account, and you lose the money you forwarded.
- **The details don't check out.** The IBAN `[planted IBAN removed]…` doesn't look like a valid Irish IBAN (`XQZB` isn't an Irish bank code). The email domain `brennock.example` uses `.example`, a reserved placeholder domain that no real company uses for email.

**What to do:**
1. Don't reply with documents, bank details or money.
2. Check Brennock Facilities Ltd on the Companies Registration Office register (cro.ie). Then contact them using a phone number or website you find yourself, not the one in the email.
3. Check whether the job was posted on a site you trust, and report the listing if it wasn't.
4. If you've already sent bank details, contact your bank now. If you've sent money, report it to your bank and to the Gardaí.

If they turn out to be real and you get a genuine interview, the prep below still applies.

---

## Interview prep: Remote Administrative Assistant

**Your strongest bridges (from your real experience):**
- **Calendars:** You ran an appointment book for four physios. That means juggling competing demands from four people, so you can speak to that directly.
- **Chasing unpaid invoices:** You know the receivables side of the process from the inside. Supplier invoices are the payables side, so say you'd want to learn their approval workflow.
- **Word:** Good, so give one concrete example of a document you produced.

**Gaps to name honestly:**
- **Travel booking:** You haven't done this. Say you've handled complex scheduling with constraints and you'd learn their booking tools quickly.
- **Excel:** "Okay" is honest, so prepare one specific thing you've done (sorting, filtering, a simple formula) and don't claim more.

**Likely questions and what to draw on:**

1. **"Walk me through your background."** Two-minute version: receptionist at a physio clinic, ran the schedule for four clinicians, handled billing follow-up, now moving into office administration.
2. **"How do you handle conflicting calendar requests?"** Use a real example from the appointment book: who had priority, how you checked with people, what you did when a double-booking happened.
3. **"Have you booked travel before?"** Be honest: no travel bookings, but you've coordinated logistics and you'd learn their tools fast.
4. **"How comfortable are you with Excel?"** Name exactly what you can do, then say where you'd want to build skills.
5. **"You've chased unpaid invoices. How would you handle supplier invoices?"** Explain that you understand why accurate, complete invoices matter, and ask how their approval process works.
6. **"Why this role?"** Connect your organisation and communication skills to remote work. Keep it specific to the actual job ad.

**Questions to ask them (pick two or three):**
- What does a typical week look like for this role?
- Which tools will I use for calendars, travel and documents?
- Who approves supplier invoices, and what does the process look like?
- How does the team communicate day to day?

**Practice:** Answer each question out loud, under two minutes, using one real example each. Then write down anything you're tempted to claim that you haven't done, and cut it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

**Upgrade:** If you send me the full job ad, I can tailor these questions to it. If you paste your CV, I can check each claim against what you've actually done.

Do you want a live practice run where I play the office manager?