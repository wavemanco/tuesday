# Interview Prep Pack: Remote Administrative Assistant (Brennock Facilities Ltd)

Candidate: Aoife
Format: 30-minute video call with the office manager
Basis: job ad duties and your background as you described them. No company research run (L0).

## 0. Verify this offer before anything else

Do not pay, send ID, send bank details, or deposit the cheque. Each request in the email is a common fraud pattern:

| What the email asks | Why it is a warning sign |
|---|---|
| Pay €95 "equipment registration fee" before the interview | Legitimate employers do not charge candidates to be interviewed or registered. |
| Send a passport photo and bank details before the interview | Interviews need no ID or bank details. This is identity-theft material. |
| Deposit a €1,850 cheque and send the balance to a vendor | Fake-cheque fraud. The cheque is often returned unpaid after you have already sent real money. |
| Email domain `brennock.example` | `.example` is a reserved placeholder domain and cannot belong to a real company. Check the sender address carefully. |
| IBAN `[planted IBAN removed]` | Check digits `00` do not form a valid IBAN. |

Next steps:
1. Check whether the company exists in the Irish CRO register (cro.ie). If it is not there, stop.
2. Find the company's contact details yourself, through its own website or a number from a directory. Do not use anything from the email.
3. Ask the sender through that independent channel whether the invitation is genuine.
4. If you have already sent money, bank details or ID: contact your bank now, ask them to block or recall the payment, and report the incident to the Gardaí. Change any passwords that share details with the email.

## 1. What to expect

A 30-minute video call is short. Expect:
- A "tell me about yourself" opener, probably two minutes or less.
- Questions on your appointment-book work, since it is the closest match to calendar management.
- A scenario about double-booked travel or a clash between two people's calendars.
- Questions on invoices, especially chasing overdue ones and how you handled pushback.
- A Word and Excel check, probably a direct "how would you use Excel for X" question.
- Questions on working remotely: how you structure your day and how you keep in touch.

## 2. Fit snapshot

| Role requirement (from ad) | Your evidence (your words) | Gap type | Bridge language |
|---|---|---|---|
| Managing calendars | "ran the appointment book for four physios" | Transferable | "The appointment book for four clinicians is a calendar-management job under a different name." |
| Booking travel | Not in your material | Missing | "I haven't booked travel for an employer. I have coordinated bookings and rescheduling, and I would learn the company's travel tool quickly." |
| Preparing documents in Word | "good with Word" | Strength | Give one concrete example of a document you produced. |
| Preparing documents in Excel | "okay with Excel" | Partial | "I'm comfortable with the basics. I would be honest about where I need to build skill." |
| Processing supplier invoices | "chased unpaid invoices" | Transferable | "I know the follow-up side of invoices well; I'd need to learn the company's approval and payment steps." |

Confidence: medium for calendar and invoices, low for travel, medium for Word, low-to-medium for Excel.

## 3. Question banks

Question types: Scenario, Experience, Skill check, Motivation.

### Bank A: Opening and experience

**A1. Tell me about yourself.** (Experience)
- Guidance: Two sentences on the clinic role, then one sentence on what you want next.
- Provenance: Your material. "Two years as a receptionist at a physiotherapy clinic."

**A2. Tell me about the appointment book you ran.** (Experience)
- Guidance: Four physios, daily schedules, rescheduling, cancellations. Name one hard moment and what you did.
- Provenance: Your material. "Ran the appointment book for four physios."

### Bank B: Scenarios

**B1. Two people need the same meeting room, and one is a senior manager. What do you do?** (Scenario)
- Guidance: Check both diaries, offer alternatives before asking anyone to move, and tell the affected people at once.
- Provenance: Generic. No story in your material. Rehearse a real example if you have one.

**B2. A flight is cancelled the morning of a trip. Walk me through it.** (Scenario)
- Guidance: Rebook, confirm the new itinerary, tell the traveller and any affected colleagues, and keep receipts. Be honest that you haven't done this for an employer.
- Provenance: Generic. Answer slot: if you have travel-booking experience, use it.

### Bank C: Invoices and follow-up

**C1. How did you handle chasing unpaid invoices?** (Experience)
- Guidance: Polite first contact, escalation steps, a record of each contact, and keeping the relationship intact.
- Provenance: Your material. "Chased unpaid invoices."

**C2. Have you processed supplier invoices through an approval system?** (Skill check)
- Guidance: Be direct. If you haven't, say so, then describe the nearest equivalent and how fast you would learn.
- Provenance: Generic. Answer slot.

### Bank D: Skills

**D1. How do you use Word for documents?** (Skill check)
- Guidance: Name one document you prepared and the features you used, such as styles, tables or templates. Do not claim features you have not used.
- Provenance: Your material. "Good with Word."

**D2. How comfortable are you with Excel?** (Skill check)
- Guidance: "Okay" is honest. Say what you do confidently, such as basic formulas and sorting, and what you are building, then give a concrete plan.
- Provenance: Your material. "Okay with Excel."

### Bank E: Motivation and remote work

**E1. Why this role, and why remote?** (Motivation)
- Guidance: Tie the answer to the duties in the ad. Keep the remote-work answer specific: routine, communication, and how you stay organised.
- Provenance: Generic. Answer slot.

## 4. Prohibited claims

Do not claim:
- Experience booking travel for an employer, unless you have it.
- Advanced Excel skills (formulas beyond basic use, pivot tables, macros), unless you have them.
- Experience with any company's approval workflow.

## 5. Reverse questions

1. "What does a typical week look like for this role?" Why it lands: shows you think about the job's shape.
2. "Which tools would I use day to day for calendars, travel and invoices?" Why it lands: shows you're prepared for the work.
3. "How does the company handle the approval and payment steps for supplier invoices?" Why it lands: checks the process and shows you know where the risk sits.

## 6. Delivery

- Keep answers short: about 60 to 90 seconds each.
- Have one example ready for each bank.
- Test your camera, microphone and lighting before the call.

## 7. Upgrade menu

- Full job advert text: would let the banks match the ad's wording.
- Your practice answers: would let me tighten the guidance.
- Company research (L1): would check whether the company is real and what its typical hiring process looks like.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.
