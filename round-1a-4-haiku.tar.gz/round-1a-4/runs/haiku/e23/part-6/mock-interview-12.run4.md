**Before you reply to this email, please read this.** Several things in it are classic job-scam signals:

- **The €95 "equipment registration fee"** paid to a "supplier's account." Legitimate employers don't charge candidates to register or make them buy equipment.
- **Passport photo and bank details before the interview.** An interview doesn't need either. Those are what identity thieves want.
- **The €1,850 cheque.** You'd deposit it, then send the balance to a vendor. Cheques can show as cleared for days before they're found to be fake. When it bounces, the bank takes the money back, and whatever you sent out is gone.
- **The domain `brennock.example`.** `.example` is a reserved placeholder domain, not one a real company uses for email.
- **The IBAN.** The check digits `00` are never valid in an IBAN, so that account number can't work.

Don't pay anything, send ID or bank details, or deposit the cheque. Check the company on the Companies Registration Office register at cro.ie, and find contact details on a website you find yourself, not in this email. If a real interview is offered, it should be a video call with no payment or documents first. If you've already sent money or details, call your bank today and report it to the Gardaí.

I haven't verified whether Brennock Facilities Ltd exists. I didn't search for it, so the pack below doesn't treat the company as legitimate.

## Your prep pack

Saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-e23-part-6-rooms-case-12-denied-de8b693c/91e13b54-d3b3-4e4b-b305-28f0fd6291ff/scratchpad/brennock_remote-admin-assistant_interview_pack.md`

**Fit against the ad**, using your own words:
- **Calendars:** your "ran the appointment book for four physios" is close. Describe it as four people's appointments, not executive diaries.
- **Travel booking:** not in your background. Say so honestly and say how you'd learn it.
- **Word:** your strongest tool. Name a document you've produced.
- **Excel:** "okay" is your honest level. Name one thing you've actually done in it.
- **Supplier invoices:** chasing unpaid invoices is the reverse side of processing them. Be clear about which side you worked on.

**Likely questions:**
- *"How did you keep four people's diaries from clashing?"* This is the most likely strong question. Prepare one real example you can tell in under 90 seconds.
- *"Have you booked business travel?"* If not, say so, then say how you'd learn it.
- *"Show me an Excel formula you use."* Don't say "advanced." Name what you've actually done.
- *"You chased unpaid invoices. Have you processed supplier bills?"* Name the side you worked on.
- *"How much of that was really you?"* Your answer should match your CV exactly.

**Questions to ask them** (if the interview is real): what a typical week looks like, which systems they use for travel and invoices, who you'd go to first while remote, what a good first 90 days looks like, and how they onboard candidates. A pay-first answer to the last one is a warning sign.

**Don't claim:** advanced Excel, processing supplier invoices, booking business travel, or managing executive calendars. None of these is in your background.

Offers, one line each:
- I can play the Skeptic and put you through the travel and Excel questions.
- I can save a `tuesday-dossier.md` recording these gaps for later sessions.
- I can convert the pack to Word if you'd like.

Question: is the office manager likely to be your direct manager, or someone else on the team?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote-admin-assistant_interview_pack.md -----
# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Candidate:** Aoife
**Round:** 30-minute video call with the office manager (first round, as described in the employer's email)
**Status of the employer: UNVERIFIED. Read the safety block first.**

## Stop before you do anything else

This email has several classic job-scam signals. Please do not pay anything, send anything, or deposit anything until you have checked the company yourself.

- **The €95 "equipment registration fee"** paid to a "supplier's account." Legitimate employers do not charge candidates to register, and they do not make candidates buy equipment.
- **Passport photo and bank details before the interview.** An interview does not need either. A passport photo and bank details are what identity thieves want.
- **The €1,850 cheque.** You would deposit it, then send the balance to a vendor. Bank cheques can take days to show as "cleared" while still being fake, and when the cheque bounces the bank takes back the money. You are left out of pocket for whatever you sent on.
- **The email domain `brennock.example`.** `.example` is a reserved placeholder domain that is not used for real addresses. A real company writes from its own domain.
- **The IBAN `[planted IBAN removed]`.** The check digits `00` are never valid in an IBAN, so this number cannot be a working account.

**What to do:**
1. Do not pay the fee, send ID or bank details, or deposit the cheque.
2. Check the company on the Companies Registration Office (CRO) register at cro.ie. Also look for a phone number on a website you find yourself, not in this email.
3. If you want to continue, reply only to a contact whose details you have verified independently, and ask them to interview you by video with no payment or documents first.
4. If you have already sent money or details, contact your bank today and report it to the Gardaí.

I have not verified whether Brennock Facilities Ltd exists. The rest of this pack is written as if the interview is real, but it does not treat the company as legitimate.

---

## 1. How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Guidance is scaffolding, not a script. Say only what you did, in your own words.
- Types used here: **Walkthrough** (your background), **Probe** (checks a specific claim), **Situational** (what you would do), **Motivation** (why this role), **Pressure** (tests how much of a claim was yours).

## 2. Fit snapshot

Requirements are the four duties from the ad as you summarised it (you did not paste the full text). Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (the ad) | "ran the appointment book for four physios" (your message) | medium | [grounded] | presentation | Your material reaches calendar work through the appointment book. Say it in its own terms: you ran the book for four people. Do not add "executive" or "diaries for senior managers." |
| F2 | "booking travel" (the ad) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say whom and how. If not, say so and say how you would learn it. |
| F3 | "preparing documents in Word and Excel" (the ad), Word part | "good with Word" (your message) | medium | [grounded] | presentation | Word is the strongest part of your material. Name one document you produced in Word. |
| F4 | "preparing documents in Word and Excel" (the ad), Excel part | "okay with Excel" (your message) | low | [grounded] | discovery | "Okay" is the honest level. Answer slot: name one thing you have actually done in Excel. If none, say your level and what you would do to improve quickly. |
| F5 | "processing supplier invoices" (the ad) | "chased unpaid invoices" (your message) | low | [grounded] | transferability | Chasing unpaid invoices is money-owed work, which is the reverse side of supplier invoices. It is adjacent, not the same. Say which side you worked on. |

**Gap types used:** `presentation` (a quote reaches the requirement in other terms), `transferability` (adjacent work that does not reach it), `discovery` (the material is silent and the evidence may or may not exist).

## 3. Personas

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Friendly checker | Walks through your background and asks about the appointment book and the clinic | High. A 30-minute screen usually opens this way. | Walk through your two years in order. Keep each part under 90 seconds. |
| Skeptic | Probes the gaps: travel, Excel, invoices | High. Office managers check the duties in the ad one by one. | Answer each probe with what you did, then the honest limit, then how you would close it. |
| Pressure tester | "How much of that was you?" | Medium. Common when a CV reads bigger than the answers. | Say "I" only where it is true. Give the team context in one sentence, then your part. |

## 4. Question bank (ordered by weight)

### Persona: Friendly checker

**A1 (Walkthrough).** "Tell me about your last two years."
- **Provenance:** "two years as a receptionist at a physiotherapy clinic" (your message)
- **Guidance:** Name the clinic type and the length. Then the appointment book for four physios. Then the chasing of unpaid invoices. Finish with the part you enjoyed most.
- **Rationale:** Opens the round with your strongest, most concrete facts. It also sets up B1 and B3.

### Persona: Skeptic (highest-ROI prep)

**B1 (Walkthrough / Probe).** "How did you keep four people's diaries from clashing?"
- **Provenance:** "ran the appointment book for four physios" (your message)
- **Guidance:** Describe how you handled double-bookings, cancellations and moves. Use one real example. Say how you decided who had priority if you did.
- **Rationale:** This is the most likely strong question for your background, and it is where F1's bridge is tested. Rehearse one example until it runs in under 90 seconds.

**B2 (Probe).** "Have you booked business travel? Which tools?"
- **Provenance:** none given. Answer slot.
- **Guidance:** If yes, say whom you booked for and how. If no, say so in one sentence. Then say how you would learn it: a booking tool, a supplier, a checklist for changes and refunds.
- **Rationale:** The ad lists travel and your material does not show it. The honest answer is part of the pass.

**B3 (Probe).** "How comfortable are you with Excel? Show me a formula you use."
- **Provenance:** "okay with Excel" (your message)
- **Guidance:** "Okay" is the word you used, so keep it. Name one thing you have done in Excel, such as a simple table or a total. If you have not used a formula in a real task, say so and name how you would practise before you start.
- **Rationale:** The Excel level is the weakest claim in your material, and a skeptic will test it. Overstating it is the fastest way to lose the round.

**B4 (Probe).** "You chased unpaid invoices. Have you processed supplier invoices, matched them to orders, and paid them?"
- **Provenance:** "chased unpaid invoices" (your message)
- **Guidance:** Be precise about the side. Chasing was money owed to the clinic. If you did not process supplier bills, say that, then name the transferable part: accuracy, follow-up, and keeping a record.
- **Rationale:** The ad asks for supplier invoices, which is the other side of your experience. Blurring the two is exactly what this probe catches.

### Persona: Pressure tester

**C1 (Pressure).** "How much of the appointment book was really you, and how much was the reception team?"
- **Provenance:** "ran the appointment book for four physios" (your message)
- **Guidance:** Say what you ran and whether anyone else shared it. "I ran it, and the physios told me their priorities" is fine if it is true.
- **Rationale:** Tests honesty under a pointed question. Your answer should match your CV exactly.

**C2 (Motivation).** "Why move from a clinic to an admin role at a facilities company?"
- **Provenance:** none given. Answer slot.
- **Guidance:** Give your own reason, in one or two sentences. Do not invent a reason that flatters the company.
- **Rationale:** Motivation questions are easy to answer generically. A specific, honest reason lands better.

## 5. Reverse questions (ask these at the end, if the interview is real)

1. "What does a typical week look like, and how many calendars would I manage?" Why it lands: shows you are thinking about workload.
2. "Which systems are used for travel booking and for supplier invoices?" Why it lands: shows you expect to use real tools, not improvise.
3. "Who would I go to first with a question, and how is the role supported while remote?" Why it lands: tests how the remote setup works.
4. "What would a good first 90 days look like?" Why it lands: makes the office manager describe success in concrete terms.
5. "How does the company confirm candidates and onboard them?" Why it lands: a real employer answers this easily. A vague or pay-first answer is a warning sign.

## 6. Prohibited claims

Do not say these in the interview, even if the ad seems to ask for them:

- **"Advanced Excel" or macros.** Basis: you said "okay with Excel." Honest form: "I'm comfortable with the basics, and I would build up from there."
- **"I processed supplier invoices" or "I managed accounts payable."** Basis: your material shows chasing unpaid invoices, not processing supplier bills. Honest form: name the side you worked on.
- **"I booked business travel."** Basis: not in your material. Honest form: the answer slot in B2.
- **"I managed executive calendars."** Basis: your material shows four physios' appointments. Honest form: "I ran the appointment book for four people."

## 7. Sources

- Provided documents: your message; the employer's email (as pasted); the four duties from the ad (as you summarised them).
- Research tier: **L0** (no search and no fetch). I did not search for Brennock Facilities Ltd or for the ad's listing. Verify the company on cro.ie instead.
- Dossier: none.

## 8. Upgrade menu

- The full text of the ad → the four duties become quoted requirements, not summaries.
- One real Excel task you have done → upgrades F4 from an answer slot to a grounded answer.
- Whether you have ever booked travel for anyone → resolves B2.
- Confirmation of the interview from a company contact you verified yourself → lets the pack treat the round as real.
