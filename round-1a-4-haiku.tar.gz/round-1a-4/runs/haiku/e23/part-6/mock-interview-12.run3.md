Before the prep, one thing matters more than anything else in your email: **this looks like a scam.** Please don't pay the €95, don't send your passport or bank details, and don't deposit the €1,850 cheque.

- **The fee.** Legitimate employers don't charge candidates for equipment or registration.
- **The documents.** Passport and bank details come later, through a verified process, never before an interview.
- **The cheque.** You deposit it, then send the balance to a vendor. This is the standard fake-cheque scam. The cheque bounces after you have already sent real money.

**What to do now:**
1. Don't reply to the email or pay anything.
2. Check whether Brennock Facilities Ltd is a registered company (the Companies Registration Office register in Ireland). Find its website and phone number yourself, not from this email.
3. Check whether you actually applied to Brennock, and through which site. If you didn't, treat the invitation as suspicious.
4. If you've already sent money or details, contact your bank now and report it to the Gardaí. Report the email to the job board you used.

## Interview prep (only if the role turns out to be real)

The interview is a 30-minute video call with the office manager. Expect practical, scenario-based questions about calendars, travel, documents and invoices.

**Your fit, based on what you told me:**

| Requirement | Your evidence | How to handle it |
|---|---|---|
| Managing calendars | Ran the appointment book for four physios | Lead with this. It's your strongest match. |
| Word documents | Good with Word | Give one concrete example. |
| Excel documents | Okay with Excel | Be specific and don't oversell. |
| Supplier invoices | Chased unpaid invoices | Say plainly that chasing is adjacent to processing. |
| Travel booking | Not in your material | Be honest. Name a tool you'd learn. |

**Don't claim:** travel booking you haven't done, advanced Excel (formulas, pivots, macros), or end-to-end invoice processing.

**Likely questions and how to answer them:**
1. *Walk me through how you managed a busy diary.* Use the appointment book: clashes, cancellations, priorities. Give one example with a result.
2. *Have you booked travel? What if a flight changed?* If you haven't booked travel, say so. Explain how you'd handle a change: check the booking, contact the provider, rebook, inform those affected.
3. *How comfortable are you with Excel?* Name what you do well and what you'd need to learn. Don't go beyond "okay."
4. *Have you dealt with supplier invoices?* Describe how you tracked and chased unpaid ones, and who responded. Be clear you didn't process them end to end.
5. *Tell me about prioritising competing requests.* Use a busy-clinic example and explain your method, not just the outcome.

**Questions to ask them:** What does a typical week look like? How is the office manager's work split between travel, documents and invoices? What does success look like after three months?

**Call tips:** Test your camera and connection beforehand. Have two or three examples ready, each with situation, action and result.

The full pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-e23-part-6-rooms-case-12-denied-9c2fa9a1/3c83de01-a136-436a-8f94-7fb347ecf530/scratchpad/aoife-brennock-prep-pack.md`. I can also make a Word version.

I built this from your summary alone, with no research and no full job description. Adding the full ad, your CV, or the interviewer's name would make it more specific.

Two quick questions:
1. Did you apply to Brennock directly, or through a job site? If you're not sure, it's worth checking before anything else.
2. Can you paste the full job description?

I can also run a practice session where I play the office manager and ask you these questions live, with feedback afterwards.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: aoife-brennock-prep-pack.md -----
# Mock-interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Built from:** the job ad summary and the interview invitation you pasted, and your background as you described it. No research was run (L0). No CV or full job description was supplied.

## Before anything else: verify this company

The invitation contains four strong scam indicators. Do not pay, send documents, or deposit the cheque until you have verified it independently.

- A **€95 "equipment registration fee"** paid to a "supplier's account". Legitimate employers do not charge candidates to be interviewed or to be onboarded.
- A request for your **passport and bank details before the interview**. Identity documents come later, through a verified process, and never before an interview.
- A **€1,850 cheque** to deposit, with the balance sent on to a vendor. This is the classic fake-cheque scam. The cheque is usually returned as fraudulent after you have already sent real money.
- The pressure to act quickly, and an interview that exists only as a fee-and-documents process.

**What to do now:**
1. Do not reply to the email, pay anything, or send any ID or bank details.
2. Confirm the company exists independently. Search the Companies Registration Office (CRO) register for "Brennock Facilities Ltd", and look for its official website and phone number yourself, not from the email.
3. Check whether you actually applied to Brennock and through which site. If you did not, treat the invitation as suspicious.
4. If you have already sent money or details, contact your bank now and report it to the Gardaí. Report the phishing or scam email to the job board you applied through.

The rest of this pack is useful only if the role turns out to be genuine. Its guidance assumes a real interview.

## Round and format

- **Round:** 30-minute video call with the office manager.
- **Persona weighting (generic, no research):** Operator-style. The office manager will test whether you can run the day-to-day work: calendars, travel, documents, invoices. Expect practical, scenario-based questions rather than strategy questions.

## Fit snapshot

| JD requirement | Your evidence (your words) | Gap type | Gap-and-bridge language |
|---|---|---|---|
| Managing calendars | "ran the appointment book for four physios" | Covered | Lead with this. It is your strongest match. |
| Preparing documents in Word | "good with Word" | Covered | Give one concrete example of a document you produced. |
| Preparing documents in Excel | "okay with Excel" | Partial | Be specific about what you can do, and do not oversell. |
| Processing supplier invoices | "chased unpaid invoices" | Partial | Chasing invoices is adjacent to processing them. Say that plainly. |
| Booking travel | Not shown in your material | Gap | Describe any booking you have done, however small. If none, say you have not done it but understand the process, and name a tool you would learn. |

**Confidence:** High for calendars and Word. Medium for invoices. Low for travel and Excel depth.

## Prohibited claims (do not say these)

- Do not claim you have booked travel for others unless you have.
- Do not claim advanced Excel skills (formulas, pivots, macros) unless you can demonstrate them.
- Do not claim you have processed supplier invoices end to end. You chased unpaid ones. Describe that accurately.

## Question bank (Operator persona)

**1. Walk me through how you managed a busy diary.**
- *Type:* Behavioural.
- *Guidance:* Use the appointment book for four physios. Cover how you handled clashes, cancellations and priorities. Give one specific example with a result.
- *Rationale:* Calendar management is the first listed duty, and your clinic work is the closest evidence you have.
- *Provenance:* Candidate-provided. Your own quote: "ran the appointment book for four physios."

**2. Have you booked travel for someone? What would you do if a flight changed at short notice?**
- *Type:* Skeptic / gap.
- *Guidance:* Be honest that travel booking is new to you if it is. Explain how you would handle a change: check the booking, contact the provider, rebook, and inform the people affected. Name the tools you would learn.
- *Rationale:* This is the largest gap in your fit. Your honest bridge is the strongest answer available.
- *Provenance:* Generic. Not from your material. Answer slot: fill in any real travel booking you have done.

**3. How comfortable are you with Excel for preparing documents?**
- *Type:* Technical, self-assessment check.
- *Guidance:* Say what you do well (for example, tables, sorting, simple formulas) and what you would need to learn. Do not claim more than "okay."
- *Rationale:* Interviewers test self-rated skills. An overclaim is easy to expose.
- *Provenance:* Candidate-provided. Your own quote: "okay with Excel."

**4. Have you dealt with supplier invoices? What did you do with an unpaid one?**
- *Type:* Behavioural, bridge.
- *Guidance:* Describe chasing unpaid invoices at the clinic. Explain how you tracked them, who you contacted, and what got a response. Say clearly that you did not process invoices end to end.
- *Rationale:* Your chasing experience is real and relevant, but it is not the same as processing.
- *Provenance:* Candidate-provided. Your own quote: "chased unpaid invoices."

**5. Tell me about a time you had to prioritise competing requests.**
- *Type:* Behavioural.
- *Guidance:* Use a busy-clinic example. Show the method you used, not only the outcome.
- *Rationale:* Standard for administrative roles. Your receptionist work supplies the evidence.
- *Provenance:* Generic prompt. Answer slot: pick a real example from your clinic work.

## Reverse questions (ask the interviewer)

1. What does a typical week look like for this role, and which duties take the most time?
2. How is the office manager's work split between travel, documents and invoices?
3. What does success look like after the first three months?

Each is worth asking because it shows you understand the work and gives you the answer you need to judge the role.

## Delivery tips for a 30-minute video call

- Test your camera, microphone and connection before the call.
- Keep two or three examples ready, each with a clear situation, action and result.
- Be direct about gaps. Interviewers respect a precise, honest answer more than a vague one.

---
**Upgrade menu:** Add the full job description (sharpens the fit snapshot). Add your CV (replaces answer slots with real examples). Add the interviewer's name if you have it (adds an interviewer read). Share the company's verified website or CRO details if you find them (lets me check the role against them).
