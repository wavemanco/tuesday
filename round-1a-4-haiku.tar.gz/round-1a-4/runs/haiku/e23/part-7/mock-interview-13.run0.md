Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-e23-part-7-rooms-case-13-denied-07c3cd7b/a96cf1d9-aed0-41c4-8943-4792a43f4b91/scratchpad/quillmoor_operations_coordinator_interview_pack.md`. It covers Hannah's four topics, the two gaps in the advert, and five reverse questions. I built it from the advert and your notes only, with no web research, so there's nothing about Quillmoor's values or recent news.

**What to say on the call:**
- **Why you're moving (S1):** The Bristol office is closing next year, and the only offer is relocating to Reading, which you don't want. State that as fact and don't comment on their decision.
- **Hybrid (C4):** Two days at Avonmouth works, and three is the most you'd take.
- **Salary (P1):** Say £42,000, which sits inside their £38,000–£44,000 range. Hold it through two pushes.
- **Notice period and current salary (P2):** Your notes don't include either, so the pack leaves them as blanks rather than guessing.

**Where you're exposed:**
- **Production planning across planning, the warehouse and QA (S3):** Your evidence is delivery scheduling for three depots. Be ready to say which parts of production planning, if any, were yours, and if none, say so and what carries over.
- **SAP (S2):** Say plainly "I've never used SAP," then mention running your in-house stock system, and describe how you'd learn SAP as a plan.
- **Dispatch report (S4):** If you never reported on-time dispatch, say so and say what you'd track first.

**Don't stretch:** The pack lists four claims to avoid, including "advanced Excel," "ERP experience," and making the stock-count improvement sound like yours alone. Each one has the honest version to use instead.

Offers, neither pushed:
- I can play the Skeptic on S3, the production-planning question, as a live drill.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- I can convert the pack to a Word document.

Two questions, because the answers would change the pack:
1. What's your notice period, and what do you earn now? Hannah will ask both, and your notes don't have either.
2. Do you have the right to work in the UK without sponsorship? The advert doesn't say, and I can't establish it from what you've given me.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations_coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

Recruiter: Hannah Lowther, Talent Partner. Round: 30-minute phone screen, Thursday 2pm, on the mobile number from your application. Built from the advert, your message and the LinkedIn messages. No interviewer profile and no web research (L0), so the company-specific sections are left out.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored: **VAL** values, **EXP** your experience, **JD** the advert's requirements, **CO** company knowledge, **CASE** a live problem. Guidance is scaffolding, not a script. Say it in your own words.

Hannah's four topics, and where they are covered: salary (P1, P2), notice period (P2), hybrid pattern (C4), what's prompting the move (S1). Her team and next-steps part is covered by the reverse questions.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | transferability | Your material says delivery scheduling across three depots, not production schedules across planning, the warehouse and QA. Bridge: "I schedule deliveries for our three depots." Answer slot: if any part of production planning or QA input was yours, say which; if none was, say so plainly and say what delivery scheduling carries over. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | none | The quote already reaches the requirement. Say it in those words: you chase suppliers when orders slip. |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on the figure; the defend-the-number slots are in C2. |
| F4 | "weekly report on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show a dispatch report. Answer slot: if you reported any delivery timing measure on a regular basis, say what it measured and who saw it; if you did not, say so and say what you would track first. |
| F5 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | Spreadsheet work is near the Excel line, but it does not show Excel skill. Answer slot: name the Excel functions you used to rebuild the spreadsheet, if you can; if you would rate yourself, say so in your own words. |
| F6 | "ERP (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | medium | [grounded] | capability | Stated absence. Plain acknowledgment: "I've never used SAP." Then the nearest true thing: "we run our own in-house stock system." Learning SAP is a plan, not a past. |
| F7 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler." (your message) | medium | [grounded] | none | The quote reaches the requirement. Say the years and the role in those words. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert; schedule and location gate) | "two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Your own stated constraint, and the advert sits inside it. Say two days works and three is the most you'd take. |
| F9 | "£38,000–£44,000" (advert; pay) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your expectation sits inside the advertised range. |
| F10 | Right to work in the UK (not in the advert; common screening check) | none given | none | [generic] | hard_gate | Your material does not establish this, and the advert does not mention it. Not bridged. The one question in the message asks whether it is met. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I've coordinated production schedules across planning, the warehouse and QA" | Inflated form of F1 | "I schedule deliveries for our three depots." Your material says delivery scheduling; the limit is the pack's own observation. C2's and S3's slots stay inside delivery. |
| "I have ERP or SAP experience" | Negative you stated, F6 | "I've never used SAP." |
| "I'm an advanced Excel user" | Inflated form of F5 | The spreadsheet quote at its own scope. F5's slot asks only which functions you used. |
| "Discrepancies fell because of my changes alone" | Inflated form of F3 | The quote as written. C2's slot asks what was counted and which part was yours. |

## Persona table

| Persona | How it shows up in this call | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Conversational / Rapport | Open questions about your background, plain questions on the hybrid pattern | High. Recruiter screens open this way, and the risk is treating casual questions as unscored | Ninety-second arc for the background question; answer the hybrid question in one sentence | 4 |
| Skeptic | Why you're moving; the SAP and production-planning gaps; the dispatch report | High. Hannah listed motivation and the location pattern as topics, and the advert names two gaps | Name the gap, then state the plan. Don't stretch the bridge | 3 |
| Pressure | Pushing on the £42,000 figure, and on notice and current salary | Medium. Salary is on her list and is the figure most likely to be pushed | Hold the number through two pushes; concede only within the advertised range | 2 |

## Question banks

### Conversational (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Open with the four years at the wholesaler, then the three depots, the delivery scheduling and the supplier chasing, in those words. Then stop and let the next question come. | F7 and F2 carry the background. EXP because it tests the CV's own claims in plain terms. |
| C2 | "What have you built or changed in your current role?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say you rebuilt the stock-count spreadsheet and that discrepancies fell by about a third over a year, in those words. Answer slot: if you can say how the discrepancies were counted, say so; say what the figure is sensitive to, which assumption you would defend least, and which part was yours. If you cannot say how it was counted, say that plainly. | F3 is your strongest line and the likeliest figure to be probed. Starting here keeps the number in your own sentence. |
| C3 | "How comfortable are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet" | Answer in what you built. Answer slot: name the functions you used, if you can; if you would rate yourself, say so plainly. | F5. The advert requires Excel, and your spreadsheet work is the nearest evidence. |
| C4 | "The role is two days a week at Avonmouth. How does that work for you?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three." | Say two days works and three is the most you'd take. Do not add a commute time; none is in your notes. | F8. Hannah named the hybrid pattern as a topic, so a short plain answer is enough. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Why are you looking to move on?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say the Bristol office is closing next year and the only offer is relocating to Reading, which you don't want. Don't comment on the employer's decision beyond that fact. Answer slot: say in your own words what draws you to this role. | This is Hannah's fourth topic. A factual answer about the closure shows the move is not about the role. |
| S2 | "The role lists SAP or similar as a plus. What's your experience?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain acknowledgment: "I've never used SAP." Then: "we run our own in-house stock system." Then your plan to learn SAP, given as a plan. | F6. The plain acknowledgment needs no slot. Do not stretch the stock system into ERP. |
| S3 | "This role coordinates production schedules across planning, the warehouse and QA. Have you done that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if any part of production planning or QA input was yours, say which and how you handled it; if none was, say so plainly and say what delivery scheduling carries over. | F1. The question's premise is the advert's. The second branch lets it be false. |
| S4 | "We report weekly on on-time dispatch. Have you reported delivery timings regularly?" | JD | [grounded] (advert) | Answer slot: if you reported any delivery timing measure regularly, say what it measured and who saw it; if you did not, say so and say what you would track first. | F4. The guidance makes no claim about your past, so it carries no candidate quote. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "The advert says £38,000–£44,000. Why would you need more than the bottom of that?" | JD | [grounded] "I'm hoping for £42,000." | Say £42,000, and that you're aiming inside the advertised range. Hold the number through two pushes. The only concession is that the advertised range is the one you've seen. | F9. Hold-then-concede: the number is yours, and the range is the advert's. |
| P2 | "What are you on now, and what's your notice period?" | EXP | [generic] | Answer slot: say your current salary and notice period in your own words. Neither is in your notes, so do not round a figure. | Hannah listed both topics. Filling this gap is the top upgrade. |

**Requirement coverage.** Production schedules: S3 (F1). Supplier deliveries and late orders: C1 (F2). Stock records: C2 (F3). Weekly dispatch report: S4 (F4). Two years or more: C1 (F7). Excel: C3 (F5). ERP a plus: S2 (F6). Hybrid pattern: C4 (F8). Pay range: P1 (F9). Right to work: none in the banks; asked directly (F10).

**Highest-ROI prep:** S3. Production planning across planning, the warehouse and QA is the advert's largest gap against your material, and it is the question most likely to be asked. Rehearse the delivery-scheduling answer and the second branch until both come out easily.

## Reverse questions

1. **"What does the first month look like for someone in this role?"** Why it lands: it gets the real shape of the job from the recruiter, not the advert.
2. **"What does the weekly on-time dispatch report look like today, and who reads it?"** Why it lands: it tests F4 from the other side, and shows you read the advert closely.
3. **"Is the two-day Avonmouth pattern set for everyone in the role, or agreed case by case?"** Why it lands: it tells you whether your three-day limit is a real constraint.
4. **"Which teams would this role work with most often, and how does input from planning, the warehouse and QA reach you?"** Why it lands: it shows you understand the cross-team coordination the role requires.
5. **"What happens between this call and an offer, and when would you expect to hear?"** Why it lands: it covers her next-steps part directly.

## Prohibited list check

Built from the fit snapshot before the banks. Each entry is in the prohibited list above.

## Sources

Provided documents: the advert, your message with the salary, hybrid and move details, and the LinkedIn messages from Hannah Lowther.

Research tier: L0, provided documents only. No searches or page fetches were run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | unavailable | Values cheat sheet, omitted: no values round detected. L0 was chosen |
| 2. Quillmoor interview process, operations | unavailable | Loop structure. A recruiter screen is one round, so the weights follow the round type |
| 3. Quillmoor strategy or recent news | unavailable | Grounding brief: current language for the call. L0 was chosen |
| 4. Hannah Lowther, Quillmoor | unavailable | Interviewer read: a name was given, so a search could run. L0 was chosen |
| 5. Representative operations coordinator JD | skipped | The advert fixes the fit snapshot |

## Upgrade menu

- Your notice period and current salary → P2 and the pay answers become figures you can say aloud.
- Your answer on right to work → clears the one gate the material does not establish (F10).
- Any production-planning, warehouse or QA input you handled → S3's slot can be answered from your own words, and F1 moves from transferability to presentation.
- Any Excel functions you used, such as lookups, pivot tables or formulas → F5 moves from discovery to presentation.
- Any delivery timing you reported regularly → S4's slot becomes a story, and F4 moves from discovery to presentation.
- Hannah's profile or the team's name → a tailored reverse question and a reading of the interviewer.
