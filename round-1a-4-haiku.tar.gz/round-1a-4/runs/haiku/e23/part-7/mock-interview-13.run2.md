Your pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-e23-part-7-rooms-case-13-denied-a78e660a/84c84b45-244a-426b-a25a-648ac7ca5d61/scratchpad/quillmoor-screen-prep.md`. Here are the key points for Thursday.

**Your strongest matches:** "4 years as a logistics coordinator" meets the 2+ years requirement. Chasing suppliers and the stock-count rebuild map directly onto the advert.

**Your gaps:** production planning and QA don't appear in your background, and neither does on-time dispatch reporting. Your closest bridge is scheduling deliveries across three depots. Don't claim production or QA work, and don't claim SAP. Say you've used an in-house stock system and are comfortable learning a new one.

**Salary:** Name a number once: "I'm targeting around £42,000, and I'm open to talking about the full package." If she offers less, ask what the band is and whether there's room, rather than accepting or refusing on the spot. Know your floor before the call.

**Hybrid:** "Two days at Avonmouth works for me. I'd be uncomfortable going beyond three."

**Moving:** Keep it short: "The Bristol office is closing next year, and the only option offered is relocation to Reading. I want to stay in Bristol, and this role matches what I've done." Don't criticise the company. If she asks whether you'd relocate, the honest answer is no.

**Questions to ask Hannah:** Who the role reports to and the team size; whether it's new or a replacement; how on-time dispatch is measured today; where the planning, warehouse and QA handoff usually breaks down; what SAP use looks like early on; whether the two Avonmouth days are fixed; and the next steps.

I didn't run web research on Quillmoor, so their values and interview process are unverified.

Three things would sharpen this:
1. What's your notice period?
2. What's your current salary, and is £42k base or total package?
3. How comfortable are you with Excel (formulas, lookups, pivots), and did you ever report on-time delivery figures?

Two optional offers: I can run a quick mock call where I play Hannah and push back on your salary and gap answers. I can also start a `tuesday-dossier.md` to keep track of these notes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-screen-prep.md -----
# Recruiter screen prep: Operations Coordinator, Quillmoor Diagnostics

**Call:** Thursday, 2pm, 30 min, by phone (Hannah Lowther, Talent Partner, on Sam's mobile)
**Her agenda:** salary expectations, notice period, hybrid pattern, reason for moving; then team and next steps.
**Basis:** the advert and Sam's background as given in the request. No web research was run; Quillmoor's values and loop are unverified.

## Fit snapshot

| JD requirement | Sam's evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| 2+ years operations or logistics coordination | "4 years as a logistics coordinator at a building-supplies wholesaler" | High | None | Lead with this. |
| Track supplier deliveries, chase late orders | "I chase suppliers when orders slip." | High | None | Describe the chasing process concretely. |
| Keep stock records accurate | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | High | None | Quote the figure as stated. |
| Coordinate production schedules between planning, warehouse and QA | "I schedule deliveries for our three depots." | Medium | Domain gap: no production or QA exposure in the material | Scheduling across three depots is the closest bridge. Do not claim production planning or QA work. |
| Weekly on-time dispatch reporting | Not in the material | Low | Evidence gap | Ask Sam whether they reported on-time performance. |
| Confident with Excel | "I rebuilt our stock-count spreadsheet" | Medium | Depth unknown | Confirm the level (formulas, pivots, lookups) before the call. |
| ERP (SAP or similar) a plus | "Never used SAP — we run our own in-house stock system." | Medium | Tool gap, not a requirement | Describe the in-house system honestly and say SAP is new to Sam. |

## Prohibited claims (local list; binds every line below)

1. Claiming SAP or any ERP experience beyond the in-house stock system.
2. Claiming production planning, QA, or production-scheduling ownership.
3. Claiming on-time dispatch reporting unless Sam confirms it.
4. Inflating the discrepancy result. It is "about a third over a year," and the spreadsheet was one part of the work.

## Likely questions and guidance

**Type: Salary.** Provenance: the advert's band (£38–44k) plus Sam's stated hope.
- "What are you looking for?" Answer: "I'm targeting around £42,000, and I'm open to talking about the full package." Name a number once and stop talking. Sam should know their floor before the call, and that is not in the material.
- If Hannah offers less than £42k: ask what the band is for this role and whether there is room to move, rather than accepting or refusing on the spot.

**Type: Notice period.** Provenance: none. The length is not in the material.
- Answer with the actual length and any start-date constraint. Do not guess.

**Type: Hybrid.** Provenance: Sam's stated position (north Bristol; two days at Avonmouth fine; three is the maximum).
- "Two days at Avonmouth works for me. I'd be uncomfortable going beyond three." Mention the commute only if Sam has checked it.

**Type: Motivation / reason for moving.** Provenance: "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want."
- Keep it short and factual: "The Bristol office is closing next year, and the only option offered is relocation to Reading. I want to stay in Bristol, and this role is a good match for what I've done." Do not criticise the employer.
- If asked whether Sam would relocate: answer honestly. Sam does not want to.

**Type: Gap probe.** "You haven't used SAP." Provenance: "Never used SAP — we run our own in-house stock system."
- "That's right. I've worked with an in-house stock system, and I'm comfortable learning a new one." Do not oversell.

**Type: Gap probe.** "Have you worked with production or QA?" Provenance: "I schedule deliveries for our three depots."
- "Not directly. My closest experience is coordinating deliveries across three depots and chasing suppliers when orders slip."

## Reverse questions for Hannah

1. Who does the role report to, and how big is the team?
2. Is this a new role or a replacement?
3. How is the on-time dispatch target measured today, and how far is the team from it?
4. Where does the handoff between planning, warehouse and QA usually break down?
5. What would SAP use look like in the first three months, and is training provided?
6. Are the two Avonmouth days fixed, or flexible?
7. What are the next steps and the timeline after this call?

## Upgrade menu

- Sam's current salary and whether £42k is base or total package. Unlocks a more precise salary answer.
- Notice period length. Unlocks the notice answer.
- Excel depth. Unlocks the Excel claim.
- Whether Sam reported on-time metrics. Unlocks the on-time dispatch answer.
- Sam's floor salary. Unlocks a negotiation plan.
