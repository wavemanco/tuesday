# Quillmoor Diagnostics: Operations Coordinator, recruiter screen

Recruiter: Hannah Lowther, Talent Partner (they/them). Thursday, 2pm, 30-minute phone call. Hannah said they will cover salary expectations, notice period, hybrid working and reasons for moving, then the team and next steps.

**How to use:** Personas describe how a question is asked. Types describe what is being scored (JD = role fit, EXP = your past work, VAL = values, CO = company, CASE = live problem). The guidance is scaffolding, not a script.

## Prep triage

1. Before Thursday: fill in your notice period, and decide your salary floor (see Logistics, L1 and L2).
2. Rehearse the SAP answer aloud (B3). This is the most likely probe and the highest-return prep here.
3. Rehearse the salary, hybrid and "why moving" answers (L1 to L4).
4. Rehearse the production-scheduling answer (B4) and the reporting answer (B5), the two places your material is thin.
5. Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | No gap. Say the four years and the role in those words. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | high | [grounded] | none | The quote reaches the requirement. Say it in those words. |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | none | The quote reaches the requirement. Confidence is medium because the method behind "about a third" is not in the material. Answer slot: if you know how discrepancies were counted, say so in your own words; if not, say that. |
| F4 | "confident with Excel" (advert) | None names Excel. "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | Your material shows a spreadsheet, not a stated Excel skill level. Answer slot: name the Excel tasks you actually do; if you are unsure of your level, say so. |
| F5 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | high | [grounded] | capability | Your stated absence. Words: "I haven't used SAP. We run our own in-house stock system." Then how you would learn it, said as a plan, never as a past. |
| F6 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | low | [inferred] | transferability | Your material shows delivery scheduling across depots, not production scheduling across planning, warehouse and QA. Answer slot: if you have coordinated schedules across teams, say which and how; if not, say that. |
| F7 | "report weekly on on-time dispatch" (advert) | None given | none | [grounded] | discovery | The material is silent. Answer slot: if you have tracked or reported on-time performance, say what you measured; if not, say that and what you would track first. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Met. |

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| "I coordinated production schedules" | Inflated form of F6 | "I schedule deliveries for our three depots." Your material says deliveries, not production. |
| "I cut discrepancies by a third" | Inflated form of F3: you rebuilt the sheet, and discrepancies fell | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." |
| "I'm confident with Excel" / "Excel expert" | Inflated form of F4 | The spreadsheet you rebuilt, and the Excel tasks you name in your own words. |
| "I have SAP experience" / "I know ERP systems" | Your stated negative, F5 | "I haven't used SAP. We run our own in-house stock system." No answer slot. |

## Logistics answers (not scored; these are the call's own questions)

**L1. Salary.** Provenance: [grounded] "I'm hoping for £42,000."
Script: "I'm looking for around £42,000. I'd like to hear the band for the role before we go further."
Rationale: £42,000 sits inside the advertised £38,000–£44,000. Decide your floor before Thursday; I have not assumed one.

**L2. Notice period.** Provenance: none given (not in your material).
Answer slot: "My notice period is ___." Fill this in before the call.

**L3. Hybrid.** Provenance: [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three."
Script: "Two days at Avonmouth works for me, as I live in north Bristol. I wouldn't want to go beyond three days."

**L4. Reason for moving.** Provenance: [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want."
Script: "Our Bristol office is closing next year, and the only option offered is relocating to Reading, which I don't want to do. I'm looking for a role I can keep in Bristol."
Rationale: It states the fact and your preference. It does not criticise the employer, and it does not need to.

## Question bank: likely probes

**B1.** "Walk me through how you schedule deliveries and chase late orders." | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Say the three depots and the chasing in those words. Answer slot: the advert asks for tracking supplier deliveries; if you keep a tracking record, say what it holds; if not, say how you know when an order is late. | F2 is your strongest match, so expect it early.

**B2.** "How did you measure the drop in discrepancies?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Defend-the-number. Answer slot: say how discrepancies were counted, what the figure is sensitive to, and which part was yours, in your own words. If you don't know how it was counted, say so. | F3. Most of the headline is yours to claim, but the figure is not yours to explain.

**B3 (highest ROI).** "The advert asks for SAP or similar. What's your experience?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain acknowledgment: "I haven't used SAP. We run our own in-house stock system." Then a plan: how you would learn it. Do not describe your in-house system as ERP. | F5. A clear, unhurried answer ends this probe; a defensive one invites a second.

**B4.** "Production schedules across planning, the warehouse and QA — have you done that?" | JD | [grounded] "I schedule deliveries for our three depots" | Answer slot: if you have coordinated schedules across teams, say which and how; if not, say so and describe what the deliveries work does carry over, in your own words. | F6.

**B5.** "We report weekly on on-time dispatch. What's your experience with that?" | JD | [grounded] advert: "report weekly on on-time dispatch" (no quote from you) | Answer slot: if you have tracked or reported on-time performance, say what you measured; if not, say so and what you would track first. | F7.

**B6.** "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet" | Answer with the Excel tasks you actually do, named in your words. Say "confident" only if it is true. | F4.

Requirement coverage: 2+ years → B1, L1; track deliveries and chase late orders → B1; accurate stock records → B2; Excel → B6; ERP/SAP → B3; production scheduling → B4; weekly on-time dispatch → B5; hybrid and salary → L1, L3.

## Reverse questions

- **R1.** "What does the team look like, and who would I work with most closely?" Why it lands: Hannah said they would cover the team, so this follows their order.
- **R2.** "How is on-time dispatch measured at the moment?" Why it lands: shows you read the reporting duty and want to know the baseline.
- **R3.** "Which systems does the team use day to day for stock and scheduling?" Why it lands: tests the SAP expectation early.
- **R4.** "What's the salary band for the role, and how is it set?" Why it lands: asks before you commit to a number.
- **R5.** "Is the two-day pattern fixed, or does it vary by week?" Why it lands: practical, and it shows you have thought about the commute.

## Upgrade menu

- Your notice period → fills L2, the one blank in the call's own questions.
- Your salary floor → lets me say what to do if the band comes in below it. I have not invented one.
- The Excel tasks you actually do → upgrades F4 from inferred to grounded.
- Hannah's full JD, if they send one → confirms F6 and the production-scheduling wording.
