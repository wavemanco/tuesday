# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

**Round:** Recruiter screen, 30-minute phone call, Thursday 2pm
**Interviewer:** Hannah Lowther, Talent Partner (recruiter)
**Agenda Hannah set:** salary expectations, notice period, hybrid pattern, reason for moving; then the team and next steps
**Research tier:** L0, provided documents only. No searches were run, so this pack says nothing about Quillmoor's values, team or recent news.

## How to use

Personas describe how a question is asked. Types describe what is being scored.

- **VAL**: behavioural and values alignment
- **EXP**: experience deep-dive; tests whether your CV claims hold up
- **JD**: role and advert-driven
- **CO**: company and strategy knowledge (none in this pack, see upgrade menu)
- **CASE**: live problem (none in this pack)

Guidance is scaffolding, not a script.

## Prep triage

1. Your notice period and earliest start date. This is the one number you have not given me (A2, F10).
2. Say £42,000 plainly, then stop talking (A1).
3. The SAP answer: no, then a plan (A6).
4. The move reason in one sentence (A4).
5. Two or three reverse questions (R1 to R3).

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Delivery scheduling is adjacent, not production planning. Say what you schedule and where it stops. Never claim production or QA work. Answer slot: if you have ever worked with planning or QA on a schedule, say what it was; if not, say so. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I chase suppliers when orders slip" (your message) | medium | [grounded] | none | Direct. Lead with the advert's own words: you chase suppliers when orders slip. |
| F3 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | Direct. Say the number and the sector. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | Direct. Keep to the stock count: about a third, over a year. Do not widen it. |
| F5 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | none | The rebuild is your evidence for "confident". Expect a quick check on a formula or feature you use. |
| F6 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Answer slot: did you track whether deliveries went out on time, weekly or otherwise? If yes, say what was counted. If no, say so and say how you would start from the delivery schedule you already keep. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | low | [grounded] | transferability | Adjacent only: an in-house stock system, not an ERP. Words: "I haven't used SAP. We run our own in-house stock system." Then learning as a plan, never as a past. |
| F8 | Salary: £38,000–£44,000 (advert) against your target | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Your own stated figure, inside the advert's range. |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Your own constraint. The advert's two days sit inside it. Gate met. |
| F10 | Notice period (not in the advert; on Hannah's agenda) | none given | none | [grounded] | hard_gate | Nothing you have given me settles this. Answer slot: your notice period in weeks and your earliest start date. This is the one question in this pack. |

**Gate status:** pay (F8) and hybrid (F9) are met. Notice period (F10) is not yet established.

## Prohibited claims

| # | Claim this pack will not coach | Basis | Honest form |
|---|---|---|---|
| P1 | Any SAP or ERP experience | F7: "Never used SAP" | "I haven't used SAP. We run our own in-house stock system." |
| P2 | Production planning or QA scheduling | F1: your scheduling is of deliveries | "I schedule deliveries for our three depots. I haven't planned production or worked in QA." |
| P3 | Weekly on-time dispatch reporting | F6: none given | Use the A7 answer slot. Do not claim it. |
| P4 | The discrepancy fall as company-wide, or as yours alone | F4: "about a third over a year", on the stock count | "Discrepancies fell by about a third over a year, after I rebuilt the stock-count spreadsheet." Add who else was involved, if anyone. |
| P5 | A market-rate justification for £42,000 | No market data in this pack | "I'm hoping for £42,000." Market-rate claims need research (see upgrade menu). |

## Question banks

**Persona weights** (screen-led round, recruiter interviewer)

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Screener | Checks pay, notice, hybrid and move reason against the advert | High. A recruiter screen is built on these, and Hannah listed them | Answer each in one or two sentences, number first, then stop |
| Probe | Asks how much of a number or result was yours | Medium. A CV figure on a stock count often gets a follow-up | Name what you did and who else was involved |
| Sell-through | Describes the team and asks for your reaction | Medium. Hannah said they would cover the team | Ask two reverse questions. Do not claim anything about the team |

### Screener bank

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" (your message) | Say £42,000 as your figure, first, in one sentence. Then stop. If they offer a range, say £42,000 is your target and that you would want to see the whole package. | Pay is one of Hannah's four topics. The advert sets the range, and your figure sits inside it. |
| A2 | "What's your notice period, and when could you start?" | JD | [generic] answer slot; no notice figure was given (see F10) | Say the notice period in weeks and the earliest start date, in one sentence. If the period is contractual and cannot be shortened, say so. | Notice is on Hannah's agenda and the advert is silent on it. I have no figure for it. |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | Say two days at Avonmouth works, you live in north Bristol, and you would not want more than three. Stop there. | Your constraint is stated and high-confidence. The advert's two days sit inside it. |
| A4 | "What's prompting you to look?" | VAL | [grounded] "our Bristol office is closing next year" and "relocating to Reading, which I don't want" (your message) | One factual sentence: the Bristol office closes next year, and the only offer is relocation to Reading, which you do not want. Then move to what you want from this role. No criticism of the employer. | A plain reason with no spin is the strongest answer. A refusal to relocate is clean when stated once. |
| A5 | "Talk me through your operations or logistics experience." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" and "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | 60 to 90 seconds: four years, the wholesaler, three depots, delivery scheduling, chasing suppliers. Stop before the stock count (A8) and let them pick it up. | Their opening question is about your background. Use the advert's words where they match. |
| A6 | "Have you worked in SAP or another ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" (your message) | "I haven't used SAP. We run our own in-house stock system, and I rebuilt our stock-count spreadsheet." Then one sentence on how you would learn an ERP, as a plan. | The advert says "a plus", not required. A plain no with a plan stays credible. Prohibited P1. |
| A7 | "Have you reported on on-time dispatch?" | JD | [inferred] derived from "I schedule deliveries for our three depots" (your message); answer slot | If you tracked whether deliveries arrived on time, say what you counted and how often. If not, say so, and say you would start from the delivery schedule you already keep. | The advert asks for weekly on-time reporting and nothing you have given me says you did it. An honest no is safer than an invented metric. Prohibited P3. |
| A8 | "How much of the stock-count improvement was you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | Name what you did: you rebuilt the spreadsheet. Give the figure as you gave it: about a third, over a year. If others changed the count process too, say so. | The most likely follow-up to a number on a CV. Prohibited P4. |
| A9 | "Are you confident in Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | One sentence on what you built and what it does. If you want a line to back "confident", name one formula or feature you use often. Do not claim tools you have not used. | "Confident" is your word, and the rebuild is the evidence. Expect a quick check. |

### Reverse questions

| ID | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like across planning, the warehouse and QA?" | Tests your scheduling picture against the real job |
| R2 | "What is the on-time dispatch figure now, and what drives the misses?" | Shows you read the advert's reporting duty |
| R3 | "Which ERP do you run, and is a move planned?" | Tells you whether SAP is a near-term need |
| R4 | "Who would I report to, and who else is on the team?" | Hannah said they would cover the team; this makes sure it happens |
| R5 | "Do the Avonmouth days need to be fixed, or agreed with the team?" | Settles the one hybrid detail the call has not covered |
| R6 | "What are the next steps, and when would a decision come?" | The call ends on next steps; this sets the timeline |

Values cheat sheet, grounding brief and graded deliverables are omitted: no published values are in hand, no research was run, and none was declared.

## Sources

- Provided documents: the advert text and your message, including Hannah's booking message.
- Searches and fetches: none run. Research tier L0.

## Upgrade menu

- Your notice period and earliest start date → settles F10 and turns A2 from an answer slot into a plain answer
- Quillmoor's published values and recent news (L1 research) → a grounding brief, and a values cheat sheet if values are published
- Hannah's public professional profile → one reverse question tied to their own career path
