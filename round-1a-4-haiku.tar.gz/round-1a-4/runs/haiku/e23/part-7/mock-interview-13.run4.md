Your prep pack is saved as quillmoor_operations-coordinator_interview_pack.md, and I've sent it over. I built it from your message, the advert and Hannah's message. I didn't run any research, so it doesn't cover Quillmoor's systems or recent news.

The three things most worth rehearsing before Thursday:

- **The SAP gap (B1).** ERP is in the advert, and you've never used SAP. Say "I haven't used SAP" plainly, then describe how you'd learn it as a plan. Don't describe your in-house stock system as an ERP.
- **The production side (B2, D1).** The advert's first requirement is production scheduling across planning, the warehouse and QA. Your material shows delivery scheduling across three depots, so say that scope accurately.
- **The discrepancy figure (C1).** "About a third" will get probed. Be ready to say how it was counted, what it's sensitive to, your weakest assumption, and which part was yours.

For the reason you're moving, say it as you wrote it: the office closes next year and the only offer is Reading, which you don't want. Don't add a "would have left anyway" that isn't true.

Two things you need to fill in, since the pack can't supply them: your notice period and a lowest acceptable salary. If Hannah counters at the bottom of the £38,000–£44,000 range, you'll want a number already decided.

Want a live rehearsal? I can play Hannah on the SAP question (B1) and push back twice.

I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Three quick questions so I can tighten the answers:
1. What's your notice period, in weeks?
2. How do you use Excel day to day: formulas and lookups, or mostly plain sheets?
3. How long is your commute to Avonmouth?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

- **Role:** Operations Coordinator, Quillmoor Diagnostics (diagnostic-test manufacturer, about 400 staff), Avonmouth, Bristol, hybrid
- **Interviewer:** Hannah Lowther, Talent Partner (recruiter)
- **Round:** 30-minute phone call, Thursday 2pm, on the mobile number on your application
- **Candidate:** Sam
- **Regeneration:** none; first pack

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you did.

Type key:
- **VAL**: behavioural and values questions
- **EXP**: your own experience, checked for accuracy
- **JD**: the job's stated requirements
- **CO**: company knowledge
- **CASE**: a live problem from the role

## Research tier

L0. No searches or page fetches were run. Nothing about Quillmoor's systems, values or news is in this pack. Dossier: none.

## Fit snapshot

Requirements come from the advert you pasted. Evidence is quoted from your own messages. The advert has no knockout criteria beyond the experience line, and F1 meets it, so there are no gate rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | No gap. Say it plainly: four years as a logistics coordinator. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | high | [grounded] | none | No gap. Chasing slipped orders is part of your daily work, at three depots. |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | presentation | The quote already reaches the requirement: "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year." The figure has no method behind it in your material. See C1. |
| F4 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | high | [grounded] | capability | Words: "I haven't used SAP." Then how you would learn it, said as a plan. Do not call the in-house system an ERP unless you know it is. |
| F5 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | low | [inferred] | transferability | Your material shows delivery scheduling across three depots. It does not show production scheduling, planning, or QA. Say that scope as it is. Answer slot: if you have worked with planning, the warehouse or QA on timing, say which and how; if not, say so and say how you would learn the production side. |
| F6 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if you have reported on delivery timings, say what and how often; if not, say so and say what you would measure first. |
| F7 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | The spreadsheet touches the requirement without showing your level. Answer slot: say what you did in the spreadsheet, in your own words; name only the features you have used. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | No gap. Your commute time from north Bristol is not in the material. |

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. None of the guidance below may assert, soften or imply them.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have ERP or SAP experience" | Inflated form of F4 | "I haven't used SAP." No answer slot. |
| "I've coordinated production schedules, or worked with QA" | Inflated form of F5 | F5's quote at its own scope: "I schedule deliveries for our three depots." Observation, in this analysis only: your material shows delivery scheduling, not production or QA. |
| "I'm strong in Excel" or "I build complex spreadsheets" | Inflated form of F3 and F7 | "I rebuilt our stock-count spreadsheet." |
| "The drop in discrepancies was all from my rebuild" | Inflated form of F3: the sentence gives the rebuild and the drop, not the cause | The sentence at its own scope. Observation, in this analysis only: your material does not show what else changed. |

## Persona weights

Relationship prior for a recruiter screen: Conversational plus a light Skeptic. No interviewer profile exists, so there are no interviewer-signal adjustments. No values-style round is detected, so there is no values section and no VAL questions. Weights:

| Persona | Weight | Questions |
|---|---|---|
| Conversational / Rapport Builder | top | 5 |
| Skeptic | mid | 3 |
| Data-Driven Prober | low | 2 |
| Pressure / Stress | low | 2 |
| Case / Strategist | low | 2 |

The pack has 14 questions. That is below the usual 18 to 26 range, because a 30-minute screen cannot carry more rehearsal than that. Breadth is traded for depth on the questions most likely to decide the call.

## Question banks

### Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | Tell me a bit about your background and what you do now. | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | Speak for about 90 seconds: the role, the scope (three depots), what you chase, and the stock rebuild as one result. Use only those sentences. | An opener that is still scored. It checks F1 and F2. |
| A2 | What's prompting the move? | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | Say it as written: the office closes next year, the only offer is Reading, and you want to stay in Bristol. Then stop. Do not criticise the company or describe a plan you have not made. | She named this topic. Motivation is scored. A short, plain reason lands; an embellished one gets probed. |
| A3 | What are your salary expectations? | EXP | [grounded] "I'm hoping for £42,000." (your message) | Say: "I'm looking for around £42,000." The advert range is £38,000 to £44,000, so £42,000 sits inside it. If she counters at the bottom, you need a lowest figure decided before Thursday; your material does not give one (see the upgrade menu). | She named salary first. This is a knockout check. |
| A4 | What's your notice period? | EXP | [grounded] "your notice period" (recruiter's message). Notice length: none given. | Answer slot: state your notice period in weeks, as your contract states it. Do not round it to something more agreeable. | She named it. The pack cannot supply the figure. |
| A5 | How would the hybrid pattern work for you? | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | Say: two days a week at Avonmouth works; more than three would not. Keep the limit as you stated it. Name the commute only if you know it. | The advert says two days. A stated limit is a boundary, not an opening bid. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | You haven't used SAP. How would you get up to speed on an ERP like that? | JD | [grounded] "Never used SAP — we run our own in-house stock system." (your message) | Plain acknowledgment: "I haven't used SAP." Then the plan, as a plan: how you would learn it (training, a sandbox, a colleague who uses it). Say what you did in your in-house stock system, in your own words, if anything. Hold the plan through two follow-ups such as "what if we need you on day one?" Then concede plainly: "I'd be slower on it at first." Do not call the in-house system an ERP. | **Highest-ROI prep in this pack.** ERP is in the advert, and SAP is the one clear gap in your material. The recruiter will check the box. This gets the deepest rehearsal. |
| B2 | Production scheduling covers planning, the warehouse and QA. What's your experience there? | JD | [grounded] "I schedule deliveries for our three depots" (your message); "Coordinate production schedules between planning, the warehouse and QA" (advert) | Say your delivery scheduling accurately, across three depots. Answer slot: if you have worked with planning, the warehouse or QA on timing, say which and how; if not, say so, and say how you would learn the production side. | This is the advert's first requirement. Your material shows delivery work, not production or QA. |
| B3 | Have you reported on on-time dispatch? | JD | Raising source: advert, "report weekly on on-time dispatch". Your material: none given. | Answer slot: if you have reported on delivery timings, say what and how often; if not, say so and say what you would measure first. | The advert's reporting duty. Your material is silent on it. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | You said discrepancies fell by about a third. How was that counted? | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | Four probes the figure raises. Answer each in your own words: how it was counted; what it is sensitive to; the assumption you would defend least; which part was yours. If you don't know how it was counted, say so. Weakest-assumption move: name your weakest assumption before she asks. | A headline figure. Expect it to be tested. |
| C2 | What did you change when you rebuilt it? | EXP | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | Name the changes you made, in your words. Name a spreadsheet feature only if you used it. If you don't recall the detail, say so. | The Excel requirement is "confident". This probe checks depth. |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | Honestly: no SAP, no production experience. Why shouldn't we hire someone who has both? | JD | [grounded] "Never used SAP" and "I schedule deliveries for our three depots" (your message) | Hold the position: four years of coordination and the depot work are what you bring. Hold through two follow-ups. Concede specifically: "I don't have SAP or production scheduling, and I would be learning both." Do not fold on the four years. | Tests whether you hold without getting defensive. These are the two obvious objections. |
| D2 | Four years in one job, and now you're looking because of a closure. What would you have done otherwise? | EXP | [grounded] "our Bristol office is closing next year" (your message) | Answer the reason as given. Do not invent "I'd have left anyway" or "I'd have stayed". If the honest answer is that you don't know, say so. Hold the reason. | Tests whether the stated reason stays consistent under a hypothetical. The temptation is to make the story neater than it is. |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | A supplier's order is two weeks late and a depot is short. What do you do first? | CASE | Raising source: advert, "chase late orders". [grounded] "chase suppliers when orders slip" (your message) | Scaffold: confirm which order and what is short; ask the supplier when it will land; then tell the depot. Use the steps you have actually taken, not a new process. | A live problem scored for structure, not for a right answer. |
| E2 | How would you keep stock records accurate day to day? | CASE | Raising source: advert, "keep stock records accurate". [grounded] "I rebuilt our stock-count spreadsheet" (your message) | Scaffold: what you count and how often, how you reconcile differences, who you tell. Say what you did. If the honest answer is that you haven't done it day to day, say that. | The advert's stock duty, linked to the spreadsheet you rebuilt. |

## Question coverage

| Requirement or topic | Question IDs |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Supplier deliveries and chasing late orders | A1, E1 |
| Stock records accurate | C1, E2 |
| Production schedules across planning, warehouse and QA | B2, D1 |
| Weekly on-time dispatch reporting | B3 |
| Excel | C2 |
| ERP (SAP or similar) | B1 |
| Hybrid, two days at Avonmouth | A5 |
| Salary | A3 |
| Notice period (recruiter's topic) | A4 |
| Reason for moving (recruiter's topic) | A2 |
| Team and next steps (recruiter will cover) | R1 to R5 |

## Reverse questions

Recruiter, not a peer, and no interviewer profile, so no reciprocity question and no career-path question. Ask these after she describes the team.

| # | Question | Why it lands |
|---|---|---|
| R1 | What does a typical week look like, and how much of it is production planning versus chasing? | Gets the real split of the production work, which is your biggest gap, and shows you think about the day. |
| R2 | How is on-time dispatch measured now, and who owns the weekly report? | Tests the reporting duty in B3 and shows you read the advert closely. |
| R3 | Which stock and planning system does the team use, and what training would someone new get on it? | Answers the SAP gap from her side and shows you have a plan for it. |
| R4 | Is this role new, or replacing someone? | Gives context for the hiring, and she is likely to know. |
| R5 | What happens after this call, and roughly when would a decision come? | Asks the next-steps question directly. She will cover next steps, so ask only if she leaves a gap. |

## Upgrade menu

- Your notice period in weeks: A4 becomes a fixed answer, not a slot.
- Your commute time from north Bristol to Avonmouth: A5 gets a number you can state.
- Your lowest acceptable salary, decided before Thursday: A3 has a floor ready for a counter-offer.
- How you actually use Excel day to day: F7 becomes a grounded row, and C2 gets sharper.
- Research at L1 (Quillmoor's systems, values and recent news): R1 to R5 and the team answer can use company-specific language.
- The hiring manager's name, once you know it: a per-round pack with persona weights for that person.
