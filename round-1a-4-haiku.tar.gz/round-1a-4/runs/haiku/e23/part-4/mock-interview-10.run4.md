Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-e23-part-4-rooms-case-10-denied-818b8dd2/1927bd30-2183-4e1a-98de-a8f7e4381c05/scratchpad/lumenvale_customer-support-specialist_interview_pack.md`. It's built only from your message: web search was refused, so there's no research on Lumenvale.

Before you reply to Marcus, check the invite itself. Some of what you described is common in recruitment scams:

| Check | Why | Provenance |
|---|---|---|
| Confirm the role and Marcus Hale through Lumenvale's careers page or a contact address you find yourself, not through the Telegram message | Unsolicited recruiter messages on messaging apps are a known scam route | [generic] |
| Don't send ID, bank details or a passport scan in the chat until you have verified an offer | Scams ask for these early | [generic] |
| Be wary of any step that asks you to pay, buy equipment, or move the process off the company's own site | Fake job offers often do this | [generic] |

---

# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

Round: text chat on Telegram with the support team lead (interviewer's name not given). Built from your message only; no web research ran (see Sources).

## How to use

Personas describe how a question arrives. Types describe what is being scored.

| Tag | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values | Past behavior against stated values |
| EXP | Experience deep-dive | Whether your claims survive a closer look |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy | Homework depth (not covered: no research ran) |
| CASE | Hypothetical / live problem | Structure and reasoning on a live problem |

The guidance is scaffolding, not a script. In a text chat, rehearse by typing your answer at the length you would actually send.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (the ad, as quoted in your message) | "3 years as a customer service advisor at an energy supplier" (your message) | high | [grounded] | none | No gap on years. Say it in your words: three years as a customer service advisor at an energy supplier. |
| F2 | "experience with Zendesk or a similar ticketing tool" (the ad, as quoted in your message) | "I use Freshdesk every day" (your message) | high | [grounded] | presentation | Freshdesk is a similar ticketing tool, and the bridge rewords only your sentence: "I use Freshdesk every day." Do not claim Zendesk experience you do not have. |
| F3 | "clear written communication" (the ad, as quoted in your message) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Handling emails daily is not the same as showing clear writing, so do not stretch the bridge. Answer slot: if you have written something a customer or colleague acted on, say what it said and what happened, in your own words. If you have not, say so plainly and stay with the emails you answered each day. |
| F4 | "confidence handling escalations" (the ad, as quoted in your message) | none given | none | [grounded] | discovery | Your material does not show an escalation. Answer slot: if you handled one, say what the customer needed and what you did, in your own words. If you did not, or it was not yours to handle, say so plainly and say how you would start. |
| F5 | Software company background (not in the ad as quoted; your note) | "I've never worked for a software company" (your message) | none | [grounded] | capability | Words: "I haven't worked for a software company." Then how you would learn a product's support queue, said as a plan and never as a past. |

## Persona weights

Relationship prior: a team lead interviewing for a support role leans Case/Strategist and Skeptic, with a Conversational opener. No interviewer profile exists, so there is no interviewer adjustment. The round is a single session of unknown length, so this is session mode with blended weights.

| Persona | How it shows up in chat | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (weight 5) | A live support problem to work through in writing | High. A team lead is buying the ability to handle the queue, and a live case is the cheapest test | Clarify, then act, then write the reply |
| Skeptic (weight 4) | Probes the software gap, the missing Zendesk, and the missing escalation record | High. The ad's escalation line and your note about software are where a team lead presses | Rehearse S1 until it is boring: plain acknowledgment, then the customer work you have, then a plan |
| Data-driven Prober (weight 3) | Asks how your 60-a-day figure and your four trainees were counted | Medium. These are the only numbers in your message, so they draw probes | Say how it was counted, or say "around" and stop |
| Conversational (weight 3) | Opens with a casual "walk me through it" | Medium. Casual questions are still scored | A 90-second arc built only from your own sentences |
| Pressure (weight 3) | Pushback and short time limits, in writing | Lower in text, but a sharp "that's a big claim" is likely | Hold the position for two messages, then concede the specific gap |

## Question banks

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A customer's refund was refused last week, and they say they were told it would go through. What do you do?" | CASE | [generic] | Clarify what they were told and by whom. Check the refund record. Say what you can decide yourself, then the escalation path, then the reply you would send. Speak it in about 90 seconds. | Sits on the escalation line in F4. A pattern for the problem, not a fact about you, so it claims nothing about your past. |
| C2 | "A customer reports a bug in chat. It is not a support issue. What are your next three actions?" | CASE | [generic] | Confirm it reproduces. Gather what the customer did and when. Write a clear note for the product team. Tell the customer what happens next and when. | Tests routing and clear writing together, the two gaps in F3 and F4. |
| C3 | "Write the first reply you would send to that angry customer, here in this chat." | CASE | [generic] | Short. Acknowledge the problem in one line. State the next step and a realistic time. Promise nothing you cannot keep. Test it: would a customer understand it on one read? | The chat is the interview itself, and it is the only direct test of the written-communication requirement (F3). |
| C4 | "A ticket has sat for two days with no reply. Walk me through what you do." | CASE | [generic] | Check the ticket's status and history. Reply with a status update. Set the follow-up. Say who owns it if it is not yours. | Tests ticket ownership and follow-up, the daily work of the ticketing tool named in F2. |
| C5 | "A customer asks to speak to a manager. What do you do?" | CASE | [generic] | Acknowledge the request. Say what you can still do yourself. Pass it on with a clear summary so the customer does not repeat their story. Say what happens next. | Escalation in its simplest form (F4). The summary is what a team lead checks first. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You've never worked for a software company. Why should we believe you'll cope with supporting our product?" | JD | [grounded] "I've never worked for a software company" (your message); "3 years as a customer service advisor at an energy supplier" (your message) | Open with the plain acknowledgment: "I haven't worked for a software company." Then the customer work you have: three years as a customer service advisor at an energy supplier. Then a plan, said as a plan: how you would learn the product in your first weeks. Hold the customer-work point through two follow-ups, then concede the software gap in one sentence. Never claim product knowledge. | The highest-ROI prep in this pack. It is the one objection your own message makes certain, so the answer must come out calm, not defensive. F5 and F1 carry it. |
| S2 | "We run Zendesk. Have you used it?" | JD | [grounded] "I use Freshdesk every day" (your message) | Yes, in those words: "I use Freshdesk every day." Answer slot: if you have used Zendesk, say where and for how long, in your own words. If you have not, say so plainly, then say how you would get up to speed on its ticket views, as a plan. | F2 is a presentation gap: the ad's "similar ticketing tool" is the bridge, and Zendesk is the named tool. |
| S3 | "Escalations are part of this role. Tell me about one you handled." | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Open prompt, so a selection scaffold: pick a contact that needed someone above your decision. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: the refunds process you trained four starters on, and what you did when a case went past your authority, if one did. | F4 is the gap this probes. Your nearest quoted sentence is the refunds training, so the scaffold points there and nowhere further. |
| S4 | "Why a support role at a software company, rather than staying in energy?" | JD | [generic] | Answer in terms of the work you want, tied to the ad's own requirements: escalations and clear writing. Do not invent a reason about their product or market. | Motivation is the Skeptic's question after a background gap. [generic] because no quote supports a motive, so the answer must be yours. |

### Data-driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "You mention around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Say what you counted and where the number came from, in your own words. Name the assumption behind it that you would defend least, before they ask. Answer slot: if you did not count it, say so plainly and keep the word "around". Never describe a method you did not use. | The only headline figure in your message. The weakest-assumption move turns a gotcha into a credibility point. |
| P2 | "How did you check that the four new starters had the refunds process before they took calls?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Answer slot: if you checked them, say how, in your own words. If you did not check them, or no check happened, say so plainly and say what you would check. | Premised on a check your quote does not state, so it is an answer slot whose second branch allows that no check happened. |
| P3 | "Which Freshdesk view would you open to see this week's backlog, and what would you leave out?" | JD | [grounded] "I use Freshdesk every day" (your message) | Answer from your own use only. Name the view you actually use. If you do not use reports, say so and name the view you do use. Never describe a report you have not opened. | Tool depth. A Freshdesk-specific probe tests whether the daily use is real, which is what F2 rests on. |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through how you got into customer support." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); "answering around 60 calls and emails a day" (your message); "I use Freshdesk every day" (your message) | A 90-second arc in your own sentences: the energy supplier and the three years, the daily volume, then the tool. Use no beat you did not state. | A casual opener is still scored. This arc is the spine every other answer reuses. |
| R2 | "What's the part of the job you like best?" | JD | [grounded] "I trained four new starters on our refunds process last year" (your message) | Answer honestly and briefly. If teaching is the true answer, it is the quoted sentence. If it is not, give the true answer in one line. | Casual questions about the role are scored for fit with the ad's communication requirement. |
| R3 | "Anything you'd like to ask me?" | JD | [generic] | Have two reverse questions ready from the list below. Never answer "I think you've covered everything." | Rapport-style interviewers weight this slot heavily as a preparation signal. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| X1 | "Sixty seconds: why should we pick you over someone who has used our kind of tool for years?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); "I use Freshdesk every day" (your message) | Hold: three years of customer contact and daily Freshdesk use, in your sentences. Concede on the second follow-up, in one specific sentence: "I haven't worked for a software company." Do not fold on the three years. | Composure under pressure. A defensive reply reads as more defensive in writing than it sounds in speech. |
| X2 | "How much of your daily Freshdesk work was your own, and how much was the team's setup?" | EXP | [grounded] "I use Freshdesk every day" (your message) | Say what you do in the tool yourself, in your own words. If any of the setup is the team's, say so. Hold once, then concede any part that was not yours. | The attribution probe: what was actually you, asked of a daily-use claim. |
| X3 | "You trained four people. Did you write the refunds process, or only teach it?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Answer slot: if you helped write any of it, say which part, in your own words. If you did not, say so plainly: you trained four new starters on it. Never say "I wrote" or "I designed". | Trained is not wrote. The inflated form is on the prohibited list below. |

### Coverage of the ad's requirements

| JD requirement (as quoted in your message) | Covered by |
|---|---|
| "2+ years in customer support" | R1, X1 |
| "experience with Zendesk or a similar ticketing tool" | S2, P3 |
| "clear written communication" | C3, C4 |
| "confidence handling escalations" | S3, C1, C5 |
| Software company background (your note, not in the ad as quoted) | S1, X1 |

## Prohibited claims

Not coached, and why. None of these may be asserted, softened or implied in any answer above.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned Zendesk, or any tool beyond Freshdesk | Inflated form of F2 | "I use Freshdesk every day." Your material names Freshdesk only. |
| Led or designed the refunds process | Inflated form of "I trained four new starters on our refunds process last year" | That sentence at its own scope. Your material says you trained, not that you set the policy. |
| Resolved every contact | Inflated form of "answering around 60 calls and emails a day" | That sentence at its own scope, with "around". |
| Product or software company experience | Negative you stated, F5 | "I haven't worked for a software company." No answer slot. |

## Reverse questions

| Question to ask them | Why it lands |
|---|---|
| "What does an escalation look like on this team, and who makes the final call?" | It shows you have thought about the escalation line in the ad. |
| "How does the team hand an unresolved ticket over between shifts?" | It is a written-handover question, which tests the same skill as the chat itself. |
| "Which tools does the team use alongside the ticketing system?" | It exposes whether Zendesk is the only tool, and shows you are planning for the tool gap. |
| "What would a good first three months look like for someone new to the product?" | It turns the software gap into a plan you can discuss openly. |
| "Who decides refund exceptions, and what can an advisor approve alone?" | It ties to the refunds process you trained others on, and it shows you know where authority sits. |

## Sources

Research tier: L0, provided documents only. The one web search attempted was refused, so no research target ran.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Values cheat sheet, not built. The search that would have fed it was refused. |
| 2. Lumenvale interview process, customer support | unavailable | Loop structure and persona weights, which stay at the relationship prior. |
| 3. Lumenvale strategy and recent news | unavailable | Company and strategy bank: none written. |
| 4. Interviewer name | n/a | No name was given, so there was no query to form. The interviewer read is absent. |
| 5. Representative job ad | unavailable | Your summary of the ad, not the full text, fixes the fit rows. The full ad would ground more rows. |

Provided documents: your Telegram message (the recruiter's invitation from Marcus Hale, your summary of the ad, and your background). Search attempted and refused: "Lumenvale Software customer support careers".

## Upgrade menu

- The full job ad text → the five fit rows gain their full requirement lines, and any further requirement becomes a row with its own question
- The team lead's name → persona weights and reverse questions tuned to their path
- Whether the chat includes a written exercise, such as a sample ticket, or a timed task → a graded-deliverable section
- Web search allowed → company values, the published support process, and a check that the role is still open

---

I can also run a drill: I'll play the Skeptic on S1, the software-background question, and give feedback against its guidance. I can save a `tuesday-dossier.md` that records the gaps this prep exposed, for later sessions.

Two things would sharpen the pack:
1. Is the Telegram chat one session? Does it include a written exercise, like replying to a sample ticket, or a timed task?
2. Could you paste the full job ad? I've worked from your summary, and the full text may add requirements.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

Round: text chat on Telegram with the support team lead (interviewer's name not given). Built from your message only; no web research ran (see Sources).

## How to use

Personas describe how a question arrives. Types describe what is being scored.

| Tag | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values | Past behavior against stated values |
| EXP | Experience deep-dive | Whether your claims survive a closer look |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy | Homework depth (not covered: no research ran) |
| CASE | Hypothetical / live problem | Structure and reasoning on a live problem |

The guidance is scaffolding, not a script. In a text chat, rehearse by typing your answer at the length you would actually send.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (the ad, as quoted in your message) | "3 years as a customer service advisor at an energy supplier" (your message) | high | [grounded] | none | No gap on years. Say it in your words: three years as a customer service advisor at an energy supplier. |
| F2 | "experience with Zendesk or a similar ticketing tool" (the ad, as quoted in your message) | "I use Freshdesk every day" (your message) | high | [grounded] | presentation | Freshdesk is a similar ticketing tool, and the bridge rewords only your sentence: "I use Freshdesk every day." Do not claim Zendesk experience you do not have. |
| F3 | "clear written communication" (the ad, as quoted in your message) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Handling emails daily is not the same as showing clear writing, so do not stretch the bridge. Answer slot: if you have written something a customer or colleague acted on, say what it said and what happened, in your own words. If you have not, say so plainly and stay with the emails you answered each day. |
| F4 | "confidence handling escalations" (the ad, as quoted in your message) | none given | none | [grounded] | discovery | Your material does not show an escalation. Answer slot: if you handled one, say what the customer needed and what you did, in your own words. If you did not, or it was not yours to handle, say so plainly and say how you would start. |
| F5 | Software company background (not in the ad as quoted; your note) | "I've never worked for a software company" (your message) | none | [grounded] | capability | Words: "I haven't worked for a software company." Then how you would learn a product's support queue, said as a plan and never as a past. |

Gap types are set by the evidence column: F2 quotes a tool that reaches the requirement in other terms; F3 and F4 are silence or thin evidence, so they carry answer slots; F5 is a negative you stated, so it carries a plain acknowledgment.

## Persona weights

Relationship prior: a team lead interviewing for a support role leans Case/Strategist and Skeptic, with a Conversational opener. No interviewer profile exists, so there is no interviewer adjustment. The round is a single session of unknown length, so this is session mode with blended weights.

| Persona | How it shows up in chat | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (weight 5) | A live support problem to work through in writing | High. A team lead is buying the ability to handle the queue, and a live case is the cheapest test | Clarify, then act, then write the reply |
| Skeptic (weight 4) | Probes the software gap, the missing Zendesk, and the missing escalation record | High. The ad's escalation line and your note about software are where a team lead presses | Rehearse S1 until it is boring: plain acknowledgment, then the customer work you have, then a plan |
| Data-driven Prober (weight 3) | Asks how your 60-a-day figure and your four trainees were counted | Medium. These are the only numbers in your message, so they draw probes | Say how it was counted, or say "around" and stop |
| Conversational (weight 3) | Opens with a casual "walk me through it" | Medium. Casual questions are still scored | A 90-second arc built only from your own sentences |
| Pressure (weight 3) | Pushback and short time limits, in writing | Lower in text, but a sharp "that's a big claim" is likely | Hold the position for two messages, then concede the specific gap |

## Question banks

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A customer's refund was refused last week, and they say they were told it would go through. What do you do?" | CASE | [generic] | Clarify what they were told and by whom. Check the refund record. Say what you can decide yourself, then the escalation path, then the reply you would send. Speak it in about 90 seconds. | Sits on the escalation line in F4. A pattern for the problem, not a fact about you, so it claims nothing about your past. |
| C2 | "A customer reports a bug in chat. It is not a support issue. What are your next three actions?" | CASE | [generic] | Confirm it reproduces. Gather what the customer did and when. Write a clear note for the product team. Tell the customer what happens next and when. | Tests routing and clear writing together, the two gaps in F3 and F4. |
| C3 | "Write the first reply you would send to that angry customer, here in this chat." | CASE | [generic] | Short. Acknowledge the problem in one line. State the next step and a realistic time. Promise nothing you cannot keep. Test it: would a customer understand it on one read? | The chat is the interview itself, and it is the only direct test of the written-communication requirement (F3). |
| C4 | "A ticket has sat for two days with no reply. Walk me through what you do." | CASE | [generic] | Check the ticket's status and history. Reply with a status update. Set the follow-up. Say who owns it if it is not yours. | Tests ticket ownership and follow-up, the daily work of the ticketing tool named in F2. |
| C5 | "A customer asks to speak to a manager. What do you do?" | CASE | [generic] | Acknowledge the request. Say what you can still do yourself. Pass it on with a clear summary so the customer does not repeat their story. Say what happens next. | Escalation in its simplest form (F4). The summary is what a team lead checks first. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You've never worked for a software company. Why should we believe you'll cope with supporting our product?" | JD | [grounded] "I've never worked for a software company" (your message); "3 years as a customer service advisor at an energy supplier" (your message) | Open with the plain acknowledgment: "I haven't worked for a software company." Then the customer work you have: three years as a customer service advisor at an energy supplier. Then a plan, said as a plan: how you would learn the product in your first weeks. Hold the customer-work point through two follow-ups, then concede the software gap in one sentence. Never claim product knowledge. | The highest-ROI prep in this pack. It is the one objection your own message makes certain, so the answer must come out calm, not defensive. F5 and F1 carry it. |
| S2 | "We run Zendesk. Have you used it?" | JD | [grounded] "I use Freshdesk every day" (your message) | Yes, in those words: "I use Freshdesk every day." Answer slot: if you have used Zendesk, say where and for how long, in your own words. If you have not, say so plainly, then say how you would get up to speed on its ticket views, as a plan. | F2 is a presentation gap: the ad's "similar ticketing tool" is the bridge, and Zendesk is the named tool. |
| S3 | "Escalations are part of this role. Tell me about one you handled." | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Open prompt, so a selection scaffold: pick a contact that needed someone above your decision. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: the refunds process you trained four starters on, and what you did when a case went past your authority, if one did. | F4 is the gap this probes. Your nearest quoted sentence is the refunds training, so the scaffold points there and nowhere further. |
| S4 | "Why a support role at a software company, rather than staying in energy?" | JD | [generic] | Answer in terms of the work you want, tied to the ad's own requirements: escalations and clear writing. Do not invent a reason about their product or market. | Motivation is the Skeptic's question after a background gap. [generic] because no quote supports a motive, so the answer must be yours. |

### Data-driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "You mention around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Say what you counted and where the number came from, in your own words. Name the assumption behind it that you would defend least, before they ask. Answer slot: if you did not count it, say so plainly and keep the word "around". Never describe a method you did not use. | The only headline figure in your message. The weakest-assumption move turns a gotcha into a credibility point. |
| P2 | "How did you check that the four new starters had the refunds process before they took calls?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Answer slot: if you checked them, say how, in your own words. If you did not check them, or no check happened, say so plainly and say what you would check. | Premised on a check your quote does not state, so it is an answer slot whose second branch allows that no check happened. |
| P3 | "Which Freshdesk view would you open to see this week's backlog, and what would you leave out?" | JD | [grounded] "I use Freshdesk every day" (your message) | Answer from your own use only. Name the view you actually use. If you do not use reports, say so and name the view you do use. Never describe a report you have not opened. | Tool depth. A Freshdesk-specific probe tests whether the daily use is real, which is what F2 rests on. |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through how you got into customer support." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); "answering around 60 calls and emails a day" (your message); "I use Freshdesk every day" (your message) | A 90-second arc in your own sentences: the energy supplier and the three years, the daily volume, then the tool. Use no beat you did not state. | A casual opener is still scored. This arc is the spine every other answer reuses. |
| R2 | "What's the part of the job you like best?" | JD | [grounded] "I trained four new starters on our refunds process last year" (your message) | Answer honestly and briefly. If teaching is the true answer, it is the quoted sentence. If it is not, give the true answer in one line. | Casual questions about the role are scored for fit with the ad's communication requirement. |
| R3 | "Anything you'd like to ask me?" | JD | [generic] | Have two reverse questions ready from the list below. Never answer "I think you've covered everything." | Rapport-style interviewers weight this slot heavily as a preparation signal. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| X1 | "Sixty seconds: why should we pick you over someone who has used our kind of tool for years?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); "I use Freshdesk every day" (your message) | Hold: three years of customer contact and daily Freshdesk use, in your sentences. Concede on the second follow-up, in one specific sentence: "I haven't worked for a software company." Do not fold on the three years. | Composure under pressure. A defensive reply reads as more defensive in writing than it sounds in speech. |
| X2 | "How much of your daily Freshdesk work was your own, and how much was the team's setup?" | EXP | [grounded] "I use Freshdesk every day" (your message) | Say what you do in the tool yourself, in your own words. If any of the setup is the team's, say so. Hold once, then concede any part that was not yours. | The attribution probe: what was actually you, asked of a daily-use claim. |
| X3 | "You trained four people. Did you write the refunds process, or only teach it?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Answer slot: if you helped write any of it, say which part, in your own words. If you did not, say so plainly: you trained four new starters on it. Never say "I wrote" or "I designed". | Trained is not wrote. The inflated form is on the prohibited list below. |

### Coverage of the ad's requirements

| JD requirement (as quoted in your message) | Covered by |
|---|---|
| "2+ years in customer support" | R1, X1 |
| "experience with Zendesk or a similar ticketing tool" | S2, P3 |
| "clear written communication" | C3, C4 |
| "confidence handling escalations" | S3, C1, C5 |
| Software company background (your note, not in the ad as quoted) | S1, X1 |

## Prohibited claims

Not coached, and why. None of these may be asserted, softened or implied in any answer above.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned Zendesk, or any tool beyond Freshdesk | Inflated form of F2 | "I use Freshdesk every day." Your material names Freshdesk only. |
| Led or designed the refunds process | Inflated form of "I trained four new starters on our refunds process last year" | That sentence at its own scope. Your material says you trained, not that you set the policy. |
| Resolved every contact | Inflated form of "answering around 60 calls and emails a day" | That sentence at its own scope, with "around". |
| Product or software company experience | Negative you stated, F5 | "I haven't worked for a software company." No answer slot. |

## Reverse questions

| Question to ask them | Why it lands |
|---|---|
| "What does an escalation look like on this team, and who makes the final call?" | It shows you have thought about the escalation line in the ad. |
| "How does the team hand an unresolved ticket over between shifts?" | It is a written-handover question, which tests the same skill as the chat itself. |
| "Which tools does the team use alongside the ticketing system?" | It exposes whether Zendesk is the only tool, and shows you are planning for the tool gap. |
| "What would a good first three months look like for someone new to the product?" | It turns the software gap into a plan you can discuss openly. |
| "Who decides refund exceptions, and what can an advisor approve alone?" | It ties to the refunds process you trained others on, and it shows you know where authority sits. |

## Sources

Research tier: L0, provided documents only. The one web search attempted was refused, so no research target ran.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Values cheat sheet, not built. The search that would have fed it was refused. |
| 2. Lumenvale interview process, customer support | unavailable | Loop structure and persona weights, which stay at the relationship prior. |
| 3. Lumenvale strategy and recent news | unavailable | Company and strategy bank: none written. |
| 4. Interviewer name | n/a | No name was given, so there was no query to form. The interviewer read is absent. |
| 5. Representative job ad | unavailable | Your summary of the ad, not the full text, fixes the fit rows. The full ad would ground more rows. |

Provided documents: your Telegram message (the recruiter's invitation from Marcus Hale, your summary of the ad, and your background). Search attempted and refused: "Lumenvale Software customer support careers".

## Upgrade menu

- The full job ad text → the five fit rows gain their full requirement lines, and any further requirement becomes a row with its own question
- The team lead's name → persona weights and reverse questions tuned to their path
- Whether the chat includes a written exercise, such as a sample ticket, or a timed task → a graded-deliverable section
- Web search allowed → company values, the published support process, and a check that the role is still open
