Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-e23-part-4-rooms-case-10-denied-71ecadaf/bde8431a-8e31-4fcd-9e8a-0f197a24b705/scratchpad/lumenvale_customer_support_specialist_interview_pack.md`. I built it on the assumption that the team lead is your hiring manager, since the recruiter's note doesn't say.

# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Role:** Customer Support Specialist (remote)
**Company:** Lumenvale Software
**Interviewer:** support team lead (name not given). Relationship assumed to be hiring manager; see Question 1 below.
**Round:** text interview in a Telegram chat, one session
**Version:** first version

## How to use

- **Check the recruiter before you share anything.** Hiring that runs entirely through a chat app, with the interview, offer and onboarding all done there, is a pattern scammers use. Confirm Marcus Hale and the role through Lumenvale's official careers page or a contact listed on their own website, not through the Telegram message. Do not send ID documents or bank details, and do not pay any fee.
- **Type key:** JD = the requirements of the ad. EXP = your own experience. CASE = a live problem. CO and VAL are not used in this pack, because no company research or published values were used (see Sources).
- **Guidance is scaffolding, not a script.** Say it in your own words.
- **Text-chat delivery:** answer in short paragraphs, as you would write to a customer. Answer the question first, then the detail. Ask one clarifying question when a case is unclear.

## Fit snapshot

The requirements below are your summary of the ad, not its wording, so none is in quotation marks. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | 2+ years in customer support (your summary of the ad) | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap. Say the three years in those words, then what the role covered, in your own terms. |
| F2 | Experience with Zendesk or a similar ticketing tool (your summary of the ad) | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Your line reaches the "similar ticketing tool" part, not Zendesk by name. Say it as it is: "I use Freshdesk every day." Answer slot: if you have used Zendesk, say where and how; if you have not, say so plainly, and say how you would learn its ticket tools in your first week. |
| F3 | Clear written communication (your summary of the ad) | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The volume shows how much you write, not how clearly. Answer slot: if any of your written replies were checked or reviewed, say how; if none were, say so and say what you check yourself. |
| F4 | Confidence handling escalations (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not show escalation work. Answer slot: if you have passed a case up, say what came in, what you decided and who you passed it to; if no such case came to you, say so and describe how you decide what to escalate. |
| F5 | Software company background (your own concern; the ad as you summarised it does not list it) | "I've never worked for a software company" — your message | high | [grounded] | capability | Plain words: "I haven't worked for a software company." Then how you would learn their product, as a plan and never as a past. |
| F6 | Your training story (not a listed requirement) | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | No gap. This is your strongest story of explaining a process to others. Say it in your own words, with the four starters and the refunds process as you stated them. |

**Gap types, briefly:** F2 is `presentation` because Freshdesk reaches the "similar tool" part in other terms. F3 and F4 are `discovery` because the material is silent on quality and escalation, which is not the same as a lack of them. F5 is `capability` because you stated the absence yourself.

## Persona table

| Persona | How it shows up in this chat | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the ticketing-tool gap and the software background; asks why you | 5, the top weight. A team lead hiring for a support role is buying capability and checking the gaps F2 and F5 | Rehearse A1 and A2 until they are plain. Hold, then concede specifically |
| Case / Strategist | Sends a live ticket problem in text and watches how you structure the reply | 4. The role is ticket work, so live problems are likely | Clarify, then reply, then state the escalation point, in short messages |
| Data-Driven Prober | Asks how your headline figures were counted | 4. The 60-a-day figure is the one number on your message, so it is the likely probe | Say how it was counted, or say plainly that you do not know |
| Conversational / Rapport | A chatty opener that is still scored | 3. Team leads often open casually in chat | A 90-second background arc. Treat casual questions as scored |
| Pressure / Stress | Short deadline and a challenge to your position, in text | 2. Lower weight for a hiring manager, but the software gap invites a challenge | Pause, restate the question, hold two follow-ups, then concede one specific point |

## Question banks

**Requirement coverage**

| Requirement (your summary of the ad) | Covered by |
|---|---|
| 2+ years in customer support | D1, C1 |
| Zendesk or a similar ticketing tool | A1, A2, C3 |
| Clear written communication | A4, B1, B4 |
| Confidence handling escalations | A3, B1, B2 |
| Software company background (your concern) | A2, E1 |

**Highest-ROI prep: A1 and A2.** The tool gap and the software background are the two objections most likely to be raised in some form. Rehearse both until the plain answer comes without thinking.

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which ticketing tools have you used, and how would you get up to speed on the one you haven't?" | JD | [grounded] "I use Freshdesk every day" — your message | Name Freshdesk and the daily use, in those words: "I use Freshdesk every day." Answer slot: if you have used Zendesk, say where and how; if you have not, say so plainly, then give your learning plan for its ticket views and tools, as a plan and never as a past. | Highest-ROI prep. F2 is the gap the ad's Zendesk line presses hardest, so this will arrive in some form. Asked as a choice, so the honest branch is always available. JD because it scores the tool requirement. |
| A2 | "Your last role was in energy. What would be different about supporting a software product?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" — your message; [grounded] "I've never worked for a software company" — your message | Start from the three years, in those words. Name what you would expect to differ, and mark it as an expectation, not experience. Plain acknowledgment: "I haven't worked for a software company." Then say what you would learn first. Answer slot: if you have supported any product or app before, say what it was and how you supported it; if not, the acknowledgment and the learning plan stand. | F5 is the objection most likely to come up, and the plain acknowledgment is your own words, so it can be said without being contested. The question presupposes only your sector. |
| A3 | "Tell me about a time you could not resolve a customer's problem yourself. What did you do?" | JD | [generic] | Open prompt: choose a case that was beyond what you could decide, such as a refund you could not approve or a complaint you passed on. Say what came in, what you decided, who you passed it to, and how it ended. If no such case comes to mind, say so plainly, then describe how you decide what to escalate. Do not invent a case. | F4 has no quoted escalation sentence, so the guidance is a selection scaffold with its honest branch. The escalation theme comes from the ad as you summarised it. |
| A4 | "What does a clear reply to a customer look like to you, and how would you check one before it goes out?" | JD | [grounded] "answering around 60 calls and emails a day" — your message | Describe the checks you use, in your own words. Answer slot: if any of your written replies were reviewed or checked, say how; if none were, say so and say what you check yourself. Offer to write a sample reply in the chat rather than claiming a quality record. | F3 shows volume, not clarity. The question asks for your standard, not a record you do not have. |
| A5 | "You trained four new starters on refunds. Walk me through what you taught first and why." | EXP | [grounded] "I trained four new starters on our refunds process last year" — your message | Story map: the four starters, the refunds process, and what you taught first, in the quote's terms. Answer slot: if you checked whether they had learned it, say how; if you did not check, say so. Do not claim their results. | F6 is your strongest sentence for explaining a process. The skeptic bank tests whether it survives follow-up. |

### Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer is angry that a refund was refused and says they will cancel. Write your first reply in this chat, then tell me when you would escalate." | CASE | [generic] | Clarify first: what the refund decision was based on, and what you can see on the account. Then a short reply: acknowledge, state what you know, say what happens next, and promise only what you can deliver. Escalation: name the point where it goes up, such as a dispute, a complaint about the decision, or a fault you cannot fix. | A live written problem covering the escalation and writing requirements. [generic] because it is a pattern for the problem, not a fact about the employer. |
| B2 | "A ticket says it is urgent, but the account name and email do not match. What do you do first?" | CASE | [generic] | Structure: verify before acting, check the record, decide who owns the next step, and reply without disclosing account details. | Tests structure before action on a live ticket. |
| B3 | "Many customers report the same login error within an hour. What do you do?" | CASE | [generic] | Clarify the impact. Check whether the issue is already known. Tell your lead with the facts you have. Send a short holding reply. Do not guess the cause in front of customers. | Tests escalation judgement at team level. |
| B4 | "Write a two-line reply to a customer whose refund decision is three days late." | CASE | [generic] | Say the delay honestly, state the next step, and give a date only if you know it. Keep it to two lines. | A written clarity drill, since this is a text interview. |

### Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was the 60 a day counted: calls, emails, or both, and over what period?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Defend the number. Say how it was counted, in your own words. Name the assumption behind it that you would defend least. Answer slot: if you counted it, say how; if it is an estimate, say so; if you do not know how it was counted, say that plainly. | A headline figure is a probe target. The figure raises only the defend-the-number slots. |
| C2 | "Of those 60 a day, which part was yours to handle, and which part went to someone else?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Keep "around" and "60" as you said them. Say which part you handled and which you passed on, if you can. Answer slot: if you can split the figure, say how; if you cannot, say so, and say what you did with each part. | Defend-the-number slot on whose part it was. The quote does not carry a split, so the second branch covers it. |
| C3 | "How much of that work was in Freshdesk, and what else did you use?" | EXP | [grounded] "I use Freshdesk every day" — your message | Name Freshdesk and the daily use in those words. Answer slot: if other tools were involved, name them; if Freshdesk was the only one, say so. | Probes tool use from a different angle than A1. |
| C4 | "Tell me what you did to train four new starters on refunds, and whether you checked how it went." | EXP | [grounded] "I trained four new starters on our refunds process last year" — your message | Say what you did, in the quote's words. Answer slot: if you checked whether the starters had learned the process, say how; if you did not check, say so. Do not describe results you did not see. | The question asks whether a check was made without assuming one was, so both branches stay honest. |

### Conversational / Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your background in support." | JD | [grounded] "3 years as a customer service advisor at an energy supplier" — your message; [grounded] "I use Freshdesk every day" — your message | A 90-second arc: the role and the three years, then the volume, then daily Freshdesk use, then the training, then why support software. Each beat is one of the sentences above, in your words. | A casual opener is scored. It covers the 2+ years requirement. |
| D2 | "What do you enjoy most about support work, and what do you find hardest?" | JD | [generic] | One honest example each. Do not claim enjoyment you cannot describe. | Rapport question that is scored on honesty and on fit with the role. |
| D3 | "What made you apply to us?" | JD | [generic] | Give the reason in one or two sentences, in your own words, tied to the role. Do not claim knowledge of their product that you have not gained. | Tests motivation consistency. Without research, the guidance makes no claim about the company. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has worked for a software company?" | JD | [grounded] "I've never worked for a software company" — your message; [grounded] "I use Freshdesk every day" — your message | Pause and restate the question. Hold: the three years and the daily Freshdesk use are the support work you can point to. Hold through two follow-ups. Concede one specific point: "I haven't used your product yet, and I would learn it first." Never fold on the support experience. | Hold-then-concede. The position held is one your quotes carry. |
| E2 | "That is a lot of volume. How much of it was really your work?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Pause and restate. Hold: say what you did with those calls and emails, in your own words. Answer slot: if part of the figure was not yours, say so. Hold through two follow-ups, and concede the specific part you cannot vouch for, never a general retreat. | Attribution pressure on the volume figure. The concession has to be specific. |

## Reverse questions for the team lead

| Question | Why it lands |
|---|---|
| "How do you decide when a ticket moves from support to engineering, and who makes that call?" | Shows you think about escalation as a process, not a reflex. |
| "Which ticketing tools does the team use day to day, and how is a new starter trained on them?" | Turns the tool gap into a practical question and shows you expect to learn. |
| "What does a good first 90 days look like for someone who is new to the team?" | Signals you are planning for the start, and gives the lead room to describe what they expect. |
| "How do you check quality on written replies: sampling, scores, or lead review?" | Shows you care about the written standard the ad asks for. |
| "What have new hires found hardest in their first three months?" | Invites candour. It also tells you what the lead will probe later. |

## Prohibited list

Claims this pack will not coach, each with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Any Zendesk experience | Inflated form of F2: "I use Freshdesk every day" widened to name a tool it does not name | "I use Freshdesk every day," at its own scope. The pack's observation: your material shows Freshdesk, not Zendesk. A2 and A1 stay inside that scope. |
| Software-product or software-company experience | Inflated form of F1, and it contradicts F5 | F1 at its own scope. Plain acknowledgment: "I haven't worked for a software company." |
| Answering 60 a day with high quality or a high resolution rate | Inflated form of F3: the volume widened into a quality or outcome claim | "answering around 60 calls and emails a day," at its own scope. The pack's observation: the material shows the volume, not the quality. |
| Owning or setting the refunds process | Inflated form of F6: "trained four new starters on our refunds process" widened to ownership | F6's quote at its own scope. The pack's observation: the material says you trained people on the process, not that you set it. |

## Sources

- **Provided:** the Telegram message from Marcus Hale; your summary of the ad's requirements; your background message.
- **Research tier: L0.** No searches and no fetches were run. Company research was not consented to, so the company-side sections are absent, and the upgrade menu offers it.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Lumenvale values | unavailable | Values cheat sheet. Not run at L0; offered at L1 in the upgrade menu |
| 2. Lumenvale interview process | unavailable | Loop structure and persona weights. Not run at L0 |
| 3. Lumenvale strategy and recent news | unavailable | Company and strategy bank. Not run at L0 |
| 4. Team lead's name | n/a | No name was given, so there was no query to form |
| 5. Representative JD for the title | skipped | Your summary already fixes the requirements, so a representative JD would not change the fit snapshot |

## Upgrade menu

- The full job ad → the requirement rows become quoted `[grounded]` lines, and A3 gets a real raising source
- The team lead's name → an interviewer read and a tailored reverse question
- Your answer to Question 1 → persona weights set for a manager or for a peer
- Your answer to Question 3 → any gate in the ad (right to work, location, hours) checked against your situation
- Approval to run L1 research → company values, the interview process, and current support tooling, so the company-side sections can be added
- A written reply you have sent, with client details removed → F3 can be `medium` on inspectable proof, and A4 gets a real sample to rehearse
- An escalation you handled, in your own words → F4 moves from `discovery` to `grounded`, and A3 gets a story to map
- Your prep time before the interview → a prioritised prep schedule

---

Say "drill" and I'll play the Skeptic on A1, the highest-ROI question, and give feedback against its guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Is the support team lead your future manager, or a peer on the team? The answer reweights the persona table.
2. Could you paste the full job ad? It turns my summary of the requirements into quoted lines.
3. Does the full ad list anything about location, right to work, working hours or time zone? If so, tell me whether you meet those terms.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer_support_specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Role:** Customer Support Specialist (remote)
**Company:** Lumenvale Software
**Interviewer:** support team lead (name not given). Relationship assumed to be hiring manager; see Question 1 below.
**Round:** text interview in a Telegram chat, one session
**Version:** first version

## How to use

- **Check the recruiter before you share anything.** Hiring that runs entirely through a chat app, with the interview, offer and onboarding all done there, is a pattern scammers use. Confirm Marcus Hale and the role through Lumenvale's official careers page or a contact listed on their own website, not through the Telegram message. Do not send ID documents or bank details, and do not pay any fee.
- **Type key:** JD = the requirements of the ad. EXP = your own experience. CASE = a live problem. CO and VAL are not used in this pack, because no company research or published values were used (see Sources).
- **Guidance is scaffolding, not a script.** Say it in your own words.
- **Text-chat delivery:** answer in short paragraphs, as you would write to a customer. Answer the question first, then the detail. Ask one clarifying question when a case is unclear.

## Fit snapshot

The requirements below are your summary of the ad, not its wording, so none is in quotation marks. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | 2+ years in customer support (your summary of the ad) | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap. Say the three years in those words, then what the role covered, in your own terms. |
| F2 | Experience with Zendesk or a similar ticketing tool (your summary of the ad) | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Your line reaches the "similar ticketing tool" part, not Zendesk by name. Say it as it is: "I use Freshdesk every day." Answer slot: if you have used Zendesk, say where and how; if you have not, say so plainly, and say how you would learn its ticket tools in your first week. |
| F3 | Clear written communication (your summary of the ad) | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The volume shows how much you write, not how clearly. Answer slot: if any of your written replies were checked or reviewed, say how; if none were, say so and say what you check yourself. |
| F4 | Confidence handling escalations (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not show escalation work. Answer slot: if you have passed a case up, say what came in, what you decided and who you passed it to; if no such case came to you, say so and describe how you decide what to escalate. |
| F5 | Software company background (your own concern; the ad as you summarised it does not list it) | "I've never worked for a software company" — your message | high | [grounded] | capability | Plain words: "I haven't worked for a software company." Then how you would learn their product, as a plan and never as a past. |
| F6 | Your training story (not a listed requirement) | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | No gap. This is your strongest story of explaining a process to others. Say it in your own words, with the four starters and the refunds process as you stated them. |

**Gap types, briefly:** F2 is `presentation` because Freshdesk reaches the "similar tool" part in other terms. F3 and F4 are `discovery` because the material is silent on quality and escalation, which is not the same as a lack of them. F5 is `capability` because you stated the absence yourself.

## Persona table

| Persona | How it shows up in this chat | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the ticketing-tool gap and the software background; asks why you | 5, the top weight. A team lead hiring for a support role is buying capability and checking the gaps F2 and F5 | Rehearse A1 and A2 until they are plain. Hold, then concede specifically |
| Case / Strategist | Sends a live ticket problem in text and watches how you structure the reply | 4. The role is ticket work, so live problems are likely | Clarify, then reply, then state the escalation point, in short messages |
| Data-Driven Prober | Asks how your headline figures were counted | 4. The 60-a-day figure is the one number on your message, so it is the likely probe | Say how it was counted, or say plainly that you do not know |
| Conversational / Rapport | A chatty opener that is still scored | 3. Team leads often open casually in chat | A 90-second background arc. Treat casual questions as scored |
| Pressure / Stress | Short deadline and a challenge to your position, in text | 2. Lower weight for a hiring manager, but the software gap invites a challenge | Pause, restate the question, hold two follow-ups, then concede one specific point |

## Question banks

**Requirement coverage**

| Requirement (your summary of the ad) | Covered by |
|---|---|
| 2+ years in customer support | D1, C1 |
| Zendesk or a similar ticketing tool | A1, A2, C3 |
| Clear written communication | A4, B1, B4 |
| Confidence handling escalations | A3, B1, B2 |
| Software company background (your concern) | A2, E1 |

**Highest-ROI prep: A1 and A2.** The tool gap and the software background are the two objections most likely to be raised in some form. Rehearse both until the plain answer comes without thinking.

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which ticketing tools have you used, and how would you get up to speed on the one you haven't?" | JD | [grounded] "I use Freshdesk every day" — your message | Name Freshdesk and the daily use, in those words: "I use Freshdesk every day." Answer slot: if you have used Zendesk, say where and how; if you have not, say so plainly, then give your learning plan for its ticket views and tools, as a plan and never as a past. | Highest-ROI prep. F2 is the gap the ad's Zendesk line presses hardest, so this will arrive in some form. Asked as a choice, so the honest branch is always available. JD because it scores the tool requirement. |
| A2 | "Your last role was in energy. What would be different about supporting a software product?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" — your message; [grounded] "I've never worked for a software company" — your message | Start from the three years, in those words. Name what you would expect to differ, and mark it as an expectation, not experience. Plain acknowledgment: "I haven't worked for a software company." Then say what you would learn first. Answer slot: if you have supported any product or app before, say what it was and how you supported it; if not, the acknowledgment and the learning plan stand. | F5 is the objection most likely to come up, and the plain acknowledgment is your own words, so it can be said without being contested. The question presupposes only your sector. |
| A3 | "Tell me about a time you could not resolve a customer's problem yourself. What did you do?" | JD | [generic] | Open prompt: choose a case that was beyond what you could decide, such as a refund you could not approve or a complaint you passed on. Say what came in, what you decided, who you passed it to, and how it ended. If no such case comes to mind, say so plainly, then describe how you decide what to escalate. Do not invent a case. | F4 has no quoted escalation sentence, so the guidance is a selection scaffold with its honest branch. The escalation theme comes from the ad as you summarised it. |
| A4 | "What does a clear reply to a customer look like to you, and how would you check one before it goes out?" | JD | [grounded] "answering around 60 calls and emails a day" — your message | Describe the checks you use, in your own words. Answer slot: if any of your written replies were reviewed or checked, say how; if none were, say so and say what you check yourself. Offer to write a sample reply in the chat rather than claiming a quality record. | F3 shows volume, not clarity. The question asks for your standard, not a record you do not have. |
| A5 | "You trained four new starters on refunds. Walk me through what you taught first and why." | EXP | [grounded] "I trained four new starters on our refunds process last year" — your message | Story map: the four starters, the refunds process, and what you taught first, in the quote's terms. Answer slot: if you checked whether they had learned it, say how; if you did not check, say so. Do not claim their results. | F6 is your strongest sentence for explaining a process. The skeptic bank tests whether it survives follow-up. |

### Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer is angry that a refund was refused and says they will cancel. Write your first reply in this chat, then tell me when you would escalate." | CASE | [generic] | Clarify first: what the refund decision was based on, and what you can see on the account. Then a short reply: acknowledge, state what you know, say what happens next, and promise only what you can deliver. Escalation: name the point where it goes up, such as a dispute, a complaint about the decision, or a fault you cannot fix. | A live written problem covering the escalation and writing requirements. [generic] because it is a pattern for the problem, not a fact about the employer. |
| B2 | "A ticket says it is urgent, but the account name and email do not match. What do you do first?" | CASE | [generic] | Structure: verify before acting, check the record, decide who owns the next step, and reply without disclosing account details. | Tests structure before action on a live ticket. |
| B3 | "Many customers report the same login error within an hour. What do you do?" | CASE | [generic] | Clarify the impact. Check whether the issue is already known. Tell your lead with the facts you have. Send a short holding reply. Do not guess the cause in front of customers. | Tests escalation judgement at team level. |
| B4 | "Write a two-line reply to a customer whose refund decision is three days late." | CASE | [generic] | Say the delay honestly, state the next step, and give a date only if you know it. Keep it to two lines. | A written clarity drill, since this is a text interview. |

### Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was the 60 a day counted: calls, emails, or both, and over what period?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Defend the number. Say how it was counted, in your own words. Name the assumption behind it that you would defend least. Answer slot: if you counted it, say how; if it is an estimate, say so; if you do not know how it was counted, say that plainly. | A headline figure is a probe target. The figure raises only the defend-the-number slots. |
| C2 | "Of those 60 a day, which part was yours to handle, and which part went to someone else?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Keep "around" and "60" as you said them. Say which part you handled and which you passed on, if you can. Answer slot: if you can split the figure, say how; if you cannot, say so, and say what you did with each part. | Defend-the-number slot on whose part it was. The quote does not carry a split, so the second branch covers it. |
| C3 | "How much of that work was in Freshdesk, and what else did you use?" | EXP | [grounded] "I use Freshdesk every day" — your message | Name Freshdesk and the daily use in those words. Answer slot: if other tools were involved, name them; if Freshdesk was the only one, say so. | Probes tool use from a different angle than A1. |
| C4 | "Tell me what you did to train four new starters on refunds, and whether you checked how it went." | EXP | [grounded] "I trained four new starters on our refunds process last year" — your message | Say what you did, in the quote's words. Answer slot: if you checked whether the starters had learned the process, say how; if you did not check, say so. Do not describe results you did not see. | The question asks whether a check was made without assuming one was, so both branches stay honest. |

### Conversational / Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your background in support." | JD | [grounded] "3 years as a customer service advisor at an energy supplier" — your message; [grounded] "I use Freshdesk every day" — your message | A 90-second arc: the role and the three years, then the volume, then daily Freshdesk use, then the training, then why support software. Each beat is one of the sentences above, in your words. | A casual opener is scored. It covers the 2+ years requirement. |
| D2 | "What do you enjoy most about support work, and what do you find hardest?" | JD | [generic] | One honest example each. Do not claim enjoyment you cannot describe. | Rapport question that is scored on honesty and on fit with the role. |
| D3 | "What made you apply to us?" | JD | [generic] | Give the reason in one or two sentences, in your own words, tied to the role. Do not claim knowledge of their product that you have not gained. | Tests motivation consistency. Without research, the guidance makes no claim about the company. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has worked for a software company?" | JD | [grounded] "I've never worked for a software company" — your message; [grounded] "I use Freshdesk every day" — your message | Pause and restate the question. Hold: the three years and the daily Freshdesk use are the support work you can point to. Hold through two follow-ups. Concede one specific point: "I haven't used your product yet, and I would learn it first." Never fold on the support experience. | Hold-then-concede. The position held is one your quotes carry. |
| E2 | "That is a lot of volume. How much of it was really your work?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Pause and restate. Hold: say what you did with those calls and emails, in your own words. Answer slot: if part of the figure was not yours, say so. Hold through two follow-ups, and concede the specific part you cannot vouch for, never a general retreat. | Attribution pressure on the volume figure. The concession has to be specific. |

## Reverse questions for the team lead

| Question | Why it lands |
|---|---|
| "How do you decide when a ticket moves from support to engineering, and who makes that call?" | Shows you think about escalation as a process, not a reflex. |
| "Which ticketing tools does the team use day to day, and how is a new starter trained on them?" | Turns the tool gap into a practical question and shows you expect to learn. |
| "What does a good first 90 days look like for someone who is new to the team?" | Signals you are planning for the start, and gives the lead room to describe what they expect. |
| "How do you check quality on written replies: sampling, scores, or lead review?" | Shows you care about the written standard the ad asks for. |
| "What have new hires found hardest in their first three months?" | Invites candour. It also tells you what the lead will probe later. |

## Prohibited list

Claims this pack will not coach, each with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Any Zendesk experience | Inflated form of F2: "I use Freshdesk every day" widened to name a tool it does not name | "I use Freshdesk every day," at its own scope. The pack's observation: your material shows Freshdesk, not Zendesk. A2 and A1 stay inside that scope. |
| Software-product or software-company experience | Inflated form of F1, and it contradicts F5 | F1 at its own scope. Plain acknowledgment: "I haven't worked for a software company." |
| Answering 60 a day with high quality or a high resolution rate | Inflated form of F3: the volume widened into a quality or outcome claim | "answering around 60 calls and emails a day," at its own scope. The pack's observation: the material shows the volume, not the quality. |
| Owning or setting the refunds process | Inflated form of F6: "trained four new starters on our refunds process" widened to ownership | F6's quote at its own scope. The pack's observation: the material says you trained people on the process, not that you set it. |

## Sources

- **Provided:** the Telegram message from Marcus Hale; your summary of the ad's requirements; your background message.
- **Research tier: L0.** No searches and no fetches were run. Company research was not consented to, so the company-side sections are absent, and the upgrade menu offers it.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Lumenvale values | unavailable | Values cheat sheet. Not run at L0; offered at L1 in the upgrade menu |
| 2. Lumenvale interview process | unavailable | Loop structure and persona weights. Not run at L0 |
| 3. Lumenvale strategy and recent news | unavailable | Company and strategy bank. Not run at L0 |
| 4. Team lead's name | n/a | No name was given, so there was no query to form |
| 5. Representative JD for the title | skipped | Your summary already fixes the requirements, so a representative JD would not change the fit snapshot |

## Upgrade menu

- The full job ad → the requirement rows become quoted `[grounded]` lines, and A3 gets a real raising source
- The team lead's name → an interviewer read and a tailored reverse question
- Your answer to Question 1 → persona weights set for a manager or for a peer
- Your answer to Question 3 → any gate in the ad (right to work, location, hours) checked against your situation
- Approval to run L1 research → company values, the interview process, and current support tooling, so the company-side sections can be added
- A written reply you have sent, with client details removed → F3 can be `medium` on inspectable proof, and A4 gets a real sample to rehearse
- An escalation you handled, in your own words → F4 moves from `discovery` to `grounded`, and A3 gets a story to map
- Your prep time before the interview → a prioritised prep schedule
