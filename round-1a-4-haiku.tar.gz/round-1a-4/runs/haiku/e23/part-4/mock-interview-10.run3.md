I'll build the prep pack with the interview-prep skill. I'll also flag the Telegram details in the message, since they matter before you reply.
Web search was refused in this session, so the pack below is built from your message and the recruiter's message only. I'll say so in the file's sources section.
Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-e23-part-4-rooms-case-10-denied-05dfddc9/93a0842e-492a-43e3-821d-b4204117ce22/scratchpad/lumenvale_customer_support_specialist_interview_pack.md`.

**Before you reply to Marcus, check the process.** The recruiter says the whole hiring process runs on Telegram, including the interview, the offer and onboarding. That is a common pattern in recruitment scams, and it is worth checking before you share anything. Confirm the application through the careers page or a company email address, and find Marcus Hale and the company on sites you look up yourself. Don't send bank details, ID scans or any deposit through the chat. You can ask for a company email and a voice or video call with the team lead. The pack's first section covers this.

I could not run web searches, because the search permission was refused. So the pack has no company values, interview structure or recent news, and I did not guess at any of them. It is built only from your message and the recruiter's.

What the pack covers:

- **Fit snapshot:** your 3 years in customer service and your daily Freshdesk use are the strongest matches. Zendesk, written clarity and escalations have no direct evidence in your message. Software-company experience is a stated gap, and I've written the honest wording for it.
- **Question banks:** 16 questions in four groups (case, skeptic, pressure, conversational). The highest-priority one is "You've never worked for a software company. Why would this work for you?"
- **Reverse questions:** five to ask the team lead, including one about how the offer and onboarding will be sent.
- **Text-only format:** short messages, reading replies back before sending, and pausing when asked to share documents or money.

One question for you: did you apply through the careers page on their own website, and do you have a company email address from them? The answer shapes the verification step.

Is it useful to run a drill on the software-gap question next? I can also save a `tuesday-dossier.md` recording these gaps for later sessions, or convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer_support_specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software (remote)

**Interview format:** text-chat interview on Telegram with the support team lead (name not given). Recruiter: Marcus Hale, talent team.
**Candidate:** Imani
**Changelog:** first version. Research was not run (see Sources), so every company-specific line is absent rather than guessed.

## Before you reply to Marcus

This is the most important section. The recruiter's own message describes an unusual process, and it should be checked before you share anything.

| What to check | Why | Provenance |
|---|---|---|
| The whole process is on Telegram: interview, offer and onboarding | Hiring fraud often moves candidates off normal channels as early as possible | [grounded] "your interview will be a text chat here with our support team lead, and if you are successful your offer and onboarding will be completed in this chat as well" (recruiter's message) |
| Confirm the application through the careers page or a company email address, not only the Telegram message | A real application usually leaves a trace on the company's own system | [generic] standard pre-interview check for unsolicited recruiter contact |
| Don't send bank details, ID scans, tax numbers or a deposit, in chat or anywhere else, before you have verified the company | Fake offers usually ask for these during "onboarding" | [generic] common pattern in recruitment fraud |
| Check the company exists and that Marcus Hale works there, using a site you find yourself (LinkedIn, the company's official website) | The message contains no link, company email or phone number to check against | [generic] |
| Ask the recruiter for a company email address and a video or voice call with the team lead | A real employer can usually do this easily | [generic] |

Until these checks pass, treat the process as unverified. Keep replies short, and don't share personal documents.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored.

- **JD**: tests a requirement from the job ad
- **EXP**: tests what you actually did in your past roles
- **CASE**: a live problem from the job, answered as you think
- **VAL**: not used here, because no company values were found
- **CO**: not used here, because no company research was run

Guidance is scaffolding, not a script. Write your own words.

## Fit snapshot

Requirements are quoted from your message. Your evidence is quoted from your message too. Confidence reflects how far your own statement can be checked. Nothing here is verified by a document.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your summary of the ad) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | none | The quote already reaches this requirement. Expect a probe on whether a customer service advisor role counts as customer support, so say what the work involved in your own words |
| F2 | "experience with Zendesk or a similar ticketing tool" (your summary of the ad) | "I use Freshdesk every day" (your message) | medium | [grounded] | presentation | Freshdesk is a ticketing tool, so it reaches the "similar" part. Say it as Freshdesk, daily. Do not claim Zendesk. Limit: your material shows Freshdesk, not Zendesk |
| F3 | "clear written communication" (your summary of the ad) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Your material shows volume of email, not how clear the writing was. Answer slot: if you can point to a written reply that resolved a case, say what it was and why it worked. If you can't, say so and describe how you check your own writing |
| F4 | "confidence handling escalations" (your summary of the ad) | none given | none | [grounded] | discovery | Your message does not say anything about escalations. Answer slot: if you have escalated a case, say when and to whom. If you have not, say so and say how you would decide to escalate |
| F5 | Software-company experience (not in the ad; likely to be asked) | "I've never worked for a software company." (your message) | none | [grounded] | capability | Words: "I've never worked for a software company." Then how you would learn the product, stated as a plan. Do not add product knowledge |
| F6 | Training or onboarding others (not in the ad) | "I trained four new starters on our refunds process last year" (your message) | medium | [grounded] | none | Useful for the team lead, who will care about how you work with other people. Say what you taught and how you checked they had learned it |

## Prohibited list

These are claims the pack will not coach you to make.

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Inflated form of F2. Your material names Freshdesk only | The quote at its own scope: "I use Freshdesk every day". The limit is the pack's observation: your material shows Freshdesk, not Zendesk |
| Designed the refunds process | Inflated form of "I trained four new starters on our refunds process last year" | Your quote at its own scope: you trained four new starters on the process. Your material does not say you designed it |
| Knowledge of software products | Negative you stated, F5 | "I've never worked for a software company." No slot |

## Persona weights

Support team lead, round type assumed to be a hiring-manager interview (your note didn't say, so this is an assumption). Weights:

| Persona | Weight | How it shows up here | Why | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | 5 | Live support scenarios: an angry customer, a bug report, a refund dispute | The team lead is scoring how you would handle the actual job | Structure first: acknowledge, check facts, state next step and timing |
| Skeptic | 3 | Questions about the software gap and the lack of Zendesk | Your CV has no software or Zendesk line, and the team lead will see both | Concede the gap plainly, then state the bridge you can support |
| Pressure | 2 | Short time limits, challenges to your choices | Support leads often test calm under escalation | Pause, restate the question, hold a fair position through two follow-ups |
| Conversational | 2 | Casual openers and "tell me about yourself" in chat | Chat openers are scored too | Keep a 90-second version of your background ready |

## Question banks

Provenance comes first. The guidance may only say what your quoted sentences say.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes angrily that their refund still hasn't arrived. How do you reply?" | CASE | [generic] | Structure: acknowledge the frustration in one line, check the refund's status, give a specific next step and a timeframe, and say what you will do if it isn't resolved. No claim about your past | A live problem from the job, asked in chat, so the reply itself is scored |
| A2 | "What would you check before replying to a bug report from a customer?" | CASE | [generic] | Clarify first: what the customer did, which product, which version, whether it happens every time. Then state what you would tell them and what you would send to the engineering team | Tests structure, not product knowledge. The guidance claims nothing about software work |
| A3 | "Tell me about a time you handled a refund dispute." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Say how the refund process works as you know it, and what you did with it. Answer slot: if you decided the outcome of a dispute, say what you decided; if you didn't, say so and describe your part | F6 is the nearest story. Keep to what you trained, not what you designed |
| A4 | "How do you use Freshdesk day to day?" | EXP | [grounded] "I use Freshdesk every day" | Describe your real daily workflow in your own words. Answer slot: if you set up views, macros or automations, say which and how; if you did not, say so | F2's quote is the only thing you have said about the tool. Don't add features you have not used |
| A5 | "How would you handle a case you are not sure you should escalate?" | JD | [grounded] "confidence handling escalations" (your summary of the ad) | Say what would make you escalate, who you would escalate to, and what you would tell the customer while it is passed on. Answer slot: if you have escalated a case, say when and to whom. If you have not, say so and describe your decision rule | F4's requirement is a JD line, not a claim about you. Keep the answer about the decision |
| A6 | "What's the first thing you would do in your first week on the team?" | JD | [generic] | Name learning steps: the help articles, the top ticket categories, shadowing live chats, and a question list for the team lead | Shows how you would ramp. No claim about your past |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. Why would this work for you?" | JD | [grounded] "I've never worked for a software company." | Start with the plain fact in your own words. Then say what carries over: working with customers, reading their problem, writing clear answers. Then say how you would learn the product. Do not claim software knowledge | F5 is the biggest gap. This objection is nearly certain, so it is the highest-return prep in this pack |
| B2 | "We use Zendesk. Have you used it?" | JD | [grounded] "I use Freshdesk every day" | Say you use Freshdesk every day, and that you haven't used Zendesk, if that is true. Then say how you would learn it, and that you know how a ticketing queue works. Do not claim Zendesk | F2's presentation case. The interviewer may think the tools are close; say what you actually use |
| B3 | "Your writing is the job. Show me how you'd write a reply in chat with no tone of voice." | CASE | [grounded] "answering around 60 calls and emails a day" | Say your approach: short sentences, one clear next step, and reading it back before sending. Answer slot: if you have written a reply that resolved a case, say what it was. If you have not, say so | F3's gap. Written clarity is asked directly here, so the reply itself counts |
| B4 | "How many of those 60 a day did you resolve yourself?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say what you can measure. Name the figure you would defend least: "around 60" is an estimate. Answer slot: if you tracked how many were resolved, say so; if you did not, say it was a daily volume, not a resolution count | The number is a figure you gave, so it will be probed. Say how sure you are |

### C. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we hire someone from energy when we need software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" | Pause. Name what the job shares: a customer, a problem, a queue. Hold that view through one follow-up, then concede the product gap and say how you would close it | Tests composure on a gap. Hold, then concede, and do not overclaim |
| C2 | "That 60-a-day figure sounds high. Is it really true?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say "around", and say what it included. Hold the figure. If challenged again, say you can't give an exact count, and explain what you know | Pressure on the number. The quote keeps its "around" |
| C3 | "Why do you want a team lead to evaluate you in a chat instead of a call?" | Pressure | [generic] | Answer directly: the format suits written support, and you are glad to show your writing. No claim about your past | Tests whether you accept the format calmly |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me a bit about yourself." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | A 90-second version: the energy supplier role, the daily tools, the training you did, and why support work suits you. Stick to what is in your message | A casual opener is still scored |
| D2 | "What's been the best part of support work for you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Name one thing you liked, then give a short example from the training. Keep it honest and short | Shows how you think about the work |

## Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in customer support | F1 (fit); D1 |
| Zendesk or similar ticketing tool | B2, A4 |
| Clear written communication | B3, A1, A2 |
| Confidence handling escalations | A5 |
| Software-company experience (not in the ad) | B1, C1 |

## Reverse questions

Each one carries a reason it lands.

1. **"What does a good first reply look like on this team?"** Lands because it shows you are thinking about quality, not only speed.
2. **"How are escalations passed on, and who owns a case once it is escalated?"** Lands because it tests the escalation process you were asked about.
3. **"What do you measure in the first 90 days, and what does good look like?"** Lands because it sets the bar you will be judged on.
4. **"Which ticketing tool does the team use, and how are macros and views set up?"** Lands because it lets you ask about the tool without claiming it.
5. **"Could you send the offer and onboarding details to a company email, and set up a voice or video call with you before we go further?"** Lands because it checks the process you were offered, and a real employer will usually agree. Ask it before you share anything personal.

## Text-only format

The interview is a chat. Prepare for that specifically:

- Write short messages. One idea per message, a clear next step at the end.
- Read each reply back before you send it, and check the customer's question was answered.
- If you need time, say so once, then reply. Don't go silent without a note.
- Keep your examples short: situation, action, result, in two or three sentences.
- Save the reply templates you would normally use. Don't copy them without changing them to the case.
- Watch for requests to share personal documents, money, or to move to another app. Pause and check first.

## Sources

- Provided documents: your message, and the recruiter's message as you pasted it.
- Web search: not run. Two searches were attempted and refused by permission in this session: "Lumenvale Software careers Customer Support Specialist" and "Marcus Hale Lumenvale Software talent".

**Research tier:** L0, no searches run, no pages fetched.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale values` | unavailable | Would have moved the values cheat sheet. Not included in this pack |
| 2. `Lumenvale interview process customer support` | unavailable | Would have moved the loop structure. Not included |
| 3. `Lumenvale strategy / recent news` | unavailable | Would have moved the company research section. Not included |
| 4. Interviewer name | n/a | No interviewer name given. Recruiter is not the interviewer |
| 5. Representative JD | skipped | Your summary of the ad fixes the fit snapshot and requirement coverage |

## Upgrade menu

- The full job ad text → the requirement rows become quoted from the ad, not from your summary
- The team lead's name → a tailored reverse question and persona weights from public information
- Confirmation that the application exists on the careers page or in a company email → clears the verification check above
- Web search allowed in this session → company values, the interview process, and current news
- Any Zendesk, escalation or writing example you have actually done → each gap row can be upgraded from its current state
