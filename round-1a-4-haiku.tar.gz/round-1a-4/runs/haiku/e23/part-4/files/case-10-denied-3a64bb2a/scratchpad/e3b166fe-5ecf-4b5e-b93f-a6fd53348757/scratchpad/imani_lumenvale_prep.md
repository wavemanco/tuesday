# Interview prep: Customer Support Specialist (remote), Lumenvale Software

**Format:** text chat on Telegram with the support team lead, arranged by recruiter Marcus Hale (talent team)
**Built from:** your summary of the job ad and your background. No web research run (L0). Assumption: the ad requirements you listed are complete.

## 0. Verify before you share anything

This hiring process is unusual in a way that matters: recruitment, interview, offer and onboarding all happen in one Telegram chat. Fully chat-based hiring that moves to "offer and onboarding in this chat" is a common pattern in job scams. Check it before you go further.

- **Confirm the posting.** Find the Customer Support Specialist role on Lumenvale's official website, not via the Telegram message. Confirm the careers page you applied through is the company's own.
- **Confirm the recruiter.** Find Marcus Hale on Lumenvale's official site or LinkedIn. Ask for a company email address and continue the process by email.
- **Ask for a video call.** A genuine employer will generally agree to a video interview for a support role. Their refusal is information.
- **Do not share** passport or ID scans, bank details, tax or social security numbers, or your home address for "contracts" until you have verified the employer.
- **Do not pay** anything (equipment, training, background-check or "processing" fees), and do not install software or open links they send.

If any of this checks out, carry on with the prep below.

## 1. Fit snapshot

| Requirement (job ad) | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| 2+ years in customer support | "3 years as a customer service advisor at an energy supplier" | high | none | Met. Say it plainly. |
| Experience with Zendesk or a similar ticketing tool | "I use Freshdesk every day" | medium | tool | Freshdesk is a similar ticketing tool, so the requirement is met in substance. Zendesk itself is not shown, and you should say so. |
| Clear written communication | "answering around 60 calls and emails a day" | medium | evidence | Volume is shown, but writing quality is not. The chat interview is itself the evidence, so keep your written replies clear and well structured. |
| Confidence handling escalations | Not stated in your summary. Adjacent: "trained four new starters on our refunds process" | low | evidence | Escalations are not evidenced yet. Pull a real example from your own work before the interview (see the question bank). |
| Software company experience (implied by the role) | "never worked for a software company" | high | domain | Gap is product knowledge, not support skill. Bridge through transferable experience and a credible plan to learn the product. |

## 2. Prohibited claims (built locally)

These are claims a candidate reaches for under pressure. Do not make them:

- Any Zendesk experience, or any Zendesk-specific feature knowledge, unless you have it.
- Any knowledge of Lumenvale's product, unless you have researched it and can name what you learned.
- Any escalation story you did not personally handle. If you have no example, say how escalations worked in your role.
- Numbers beyond the ones you gave: "around 60 calls and emails a day" stays "around 60," and no higher figures.
- Owning the refunds process if you followed it rather than wrote it.

## 3. Persona weights

The round is a text chat with a support team lead, so the likely mix is:

- **Operational practitioner (about 60%).** Checks how you handle tickets, escalations and tools. Most questions come from here.
- **Skeptic (about 25%).** Probes the gaps: no Zendesk, no software company. Tests whether you overstate.
- **Culture and fit (about 15%).** Checks how you work remotely and communicate in writing.

## 4. Question bank

**Type labels:** background, tool, escalation, written, skeptic, motivation.

**Q1. Tell me about your support experience.** *(background)*
- *Provenance:* "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day."
- *Guidance:* Give a 30-second version. Cover channels (phone and email), volume, and what the role covered. Stop there and let them ask.
- *Rationale:* The opener sets the frame, and a clear, short answer is the first writing sample.

**Q2. You have used Freshdesk, not Zendesk. How would you get up to speed?** *(tool, skeptic)*
- *Provenance:* "I use Freshdesk every day."
- *Guidance:* Be direct: you have not used Zendesk. Then explain what transfers: tickets, statuses, macros or canned replies, views, and SLAs or response targets. Name one concrete step, such as Zendesk's public documentation or a trial account.
- *Rationale:* This is the most likely objection. Honest and specific beats defensive.

**Q3. Walk me through an escalation you handled.** *(escalation)*
- *Provenance:* Answer slot. Your summary does not show an escalation example.
- *Guidance:* If you have a real case, pick one and cover the trigger, what you did, who you passed it to, and the outcome. If you do not, say how escalations were routed in your role and what you would do with a case you cannot resolve. Do not invent one.
- *Rationale:* The ad asks for confidence with escalations, and this is the weakest evidenced requirement.

**Q4. A customer is angry because a refund is late. Write your first reply.** *(written)*
- *Provenance:* "trained four new starters on our refunds process last year."
- *Guidance:* Keep it short. Acknowledge the frustration, state what you know and what you are doing, give a specific next step and a timeframe. Use the refunds process you trained others on.
- *Rationale:* Asking for written replies in the chat tests the requirement directly, and the refund scenario uses your strongest material.

**Q5. Show us how you would reply to this ticket.** *(written)* — live exercise
- *Provenance:* None. This is a scenario, not a claim about your past.
- *Guidance:* Slow down. Read the message twice, answer every question, and avoid promising anything you cannot confirm. End with a clear next step.
- *Rationale:* The most likely exercise in a text-only round. Writing quality is the main thing being scored.

**Q6. You trained four new starters. Did you write the refunds process, or follow it?** *(skeptic)*
- *Provenance:* "trained four new starters on our refunds process last year."
- *Guidance:* Answer precisely. If you followed it, say so and describe what you added: the training, the explanations, the questions you answered. Do not claim authorship.
- *Rationale:* Tests whether you shrink an inflated claim gracefully.

**Q7. Why do you want to work at a software company?** *(motivation)*
- *Provenance:* "never worked for a software company."
- *Guidance:* Give a real reason, such as wanting to see how support feeds product improvement, or wanting to learn a product. Acknowledge that you have not worked in software before, and name what you would do to get up to speed.
- *Rationale:* Tests the domain gap and the honest answer to it.

## 5. Reverse questions (for the team lead)

- **What does a typical day look like for this role, and how many tickets does a specialist handle?** *Why it lands:* Shows you are thinking about the workload, and lets you compare with your 60-a-day baseline.
- **How do escalations reach engineering, and what does a good handoff look like?** *Why it lands:* Directly tests the escalation requirement and shows how you think about it.
- **Which ticketing tool does the team use, and what does onboarding on it involve?** *Why it lands:* Covers the Zendesk gap openly.
- **How is written quality measured here?** *Why it lands:* Signals you care about the requirement the chat is testing.
- **Could we continue with a video call, and could the rest of the process move to a company email address?** *Why it lands:* A verification question that also tests whether the employer is genuine. Ask it before any offer stage.

## 6. Values cheat sheet

Not included. Lumenvale's values were not researched (no web search run), so there is nothing verified to map against.

## 7. Delivery coaching

Not included. No working-style assessment was provided.

## 8. Upgrade menu

- **Full job ad text:** lets the fit snapshot check every requirement, not only the four you listed.
- **Team lead's name and title:** lets the interviewer read sharpen the questions.
- **Any exercise, test or time limit the recruiter has mentioned:** lets the pack prepare for a graded deliverable.
- **Research on Lumenvale (L1):** adds official values, product basics and recent company context, and lets the reverse questions mention specifics.
- **Deep research (L2):** adds team-lead public writing and role-family interview reports. Offered once, costs more time.
- **Tuesday dossier (`tuesday-dossier.md`):** adds a sourced evidence map and a verified list of claims to avoid.
