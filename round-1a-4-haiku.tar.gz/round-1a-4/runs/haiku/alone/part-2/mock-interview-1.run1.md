Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-1-denied-65b61c57/f94d340e-5046-40f3-a506-ca4493ef5baa/scratchpad/northwind_senior-gtm-strategy-lead_interview_pack.md`. It's built on one 60-minute conversation with Dan as a peer, which is how you described it. Web search was refused in this session, so the pack rests on your material alone.

# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer on the same VP's team. **Session:** one 60-minute conversation.

Built on one assumption: the single session is a conversation with Dan as peer, as your message states. The JD is your highlights, not the full posting, so requirement quotes come only from those highlights.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** not used, because no values-style round is established. **EXP** tests the work she did. **JD** tests the posted role. **CO** tests company and strategy knowledge. **CASE** is a live problem.
- Guidance is scaffolding, not a script. Each cell should be speakable in 90 to 120 seconds.
- An **answer slot** is an instruction for the interview, not a question to me. Where a slot says "if you did X, say how," the honest branch is always available: "if it was not yours, say so plainly."

## Fit snapshot

Quotes in the Evidence column come from her material. "The coach's notes" means the candidate facts in your message. "Your message" means the JD highlights and the research note.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "partner-motion design experience required" — your message | "Built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The notes show a model built and used in carrier negotiations. They do not show a partner motion designed end to end, so the bridge stays at the model: "I built a partner-level revenue model, and it was used in carrier negotiations." Answer slot: the partner-motion line makes a probe on how partners are enabled or paid likely. If you designed any part of that, say which part and how you decided; if you did not, say so plainly and return to the model. |
| F2 | "own GTM strategy for two new product lines" — your message | "9 years at a large consumer-tech company in product strategy and ops" — the coach's notes | medium | [grounded] | transferability | Product strategy and ops is adjacent to owning GTM for new lines. It does not say GTM was owned. Words: "I spent nine years in product strategy and ops at a large consumer-tech company." Answer slot: if you set the go-to-market plan for any launch, name it and what you decided; if you worked alongside the owner of that plan, say that and what you contributed. |
| F3 | "identify whitespace across land/adopt/expand/renew" — your message | none given | none | [grounded] | discovery | Silence, not a stated absence: the material does not show whitespace work. Answer slot: name the stage of land, adopt, expand or renew you have worked on most and the evidence you used. If none, say so, then say how you would find whitespace in the first month, as a plan. |
| F4 | "independent analysis in SQL and Tableau" — your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | presentation | The quote reaches the tools; independence is not shown. Words: "I'm skilled in SQL and Tableau." Answer slot: name an analysis you ran end to end and what you checked before you trusted it. If you did not run it yourself, say so. |
| F5 | "AI experience a plus" — your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | none | The quote already reaches the requirement in usage terms. Words: "I use AI tools daily." Probe likely on which tools and what for. Answer slot: name one tool and one task it changed. |
| F6 | "strong cross-functional influence" — your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Words: "I set annual volume targets with cross-org consensus." Answer slot: say what part was yours in reaching that consensus, and what you did when a team disagreed. If no part was singled out as yours, say so. |
| F7 | headline figure on the CV, no JD line — the coach's notes | "proposed a store-surface change credited with ~$400M ARR uplift" — the coach's notes | medium | [grounded] | none | The figure is credited, which is shared attribution. Words stay at the quote: "I proposed a store-surface change, credited with about $400M ARR uplift." The defend-the-number slots are in B1. |
| F8 | sales planning, quota or target-setting — role-family pattern, not from your inputs | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A negative stated in the notes. Words, for you to confirm: "I haven't done classic sales-ops or quota-setting." No slot: this is a plain acknowledgment. Never a claim to quota work. |

**Gap types above:** transferability (F1, F2), discovery (F3), presentation (F4, F6), none (F5, F7), capability (F8). No gate row appears: your highlights name no location, work-authorization or travel requirement. The full JD may add one (see upgrade menu).

## Prohibited claims

These are not coached anywhere in this pack. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for new product lines | Inflated form of F2 | F2's quote at its own scope: product strategy and ops. The limit is my observation: the notes say product strategy and ops, not GTM ownership. |
| Designed a partner motion | Inflated form of F1 | F1's quote: a partner-level revenue model, used in carrier negotiations. |
| Drove the $400M | Inflated form of F7, which says "credited with" | F7's quote at its own scope. The figure is credited, shared attribution. |
| Set the volume targets alone | Inflated form of F6, which says "with cross-org consensus" | F6's quote, with "with cross-org consensus" kept in. |
| Independent SQL and Tableau analysis | Inflated form of F4, which says "skilled in" | F4's quote at its scope. Independence is an answer slot, not a claim. |
| Quota-setting experience | Negative stated in the notes, F8 | "I haven't done classic sales-ops or quota-setting." A plain acknowledgment. No slot. |

## Reading the interviewer

**Source:** your message only. Dan's public footprint was not established (see Sources).

- **Career pattern:** pricing and monetization roles at the core, with one early-stage-startup chapter.
- **Self-description:** "relentlessly data-driven."

Practical implications:

1. Every headline figure will be probed to its assumptions. The $400M (B1, B4) and the volume targets (B2) are the likely targets.
2. Pricing and monetization is their native language. Case questions lean toward pricing (C1, C3). The partner-level revenue model (F1) is the nearest shared vocabulary. Use only the quote's own words.
3. The startup chapter suggests skepticism about big-company pace. Priya's material has no startup chapter, so no shared professional jump is offered.
4. Shared professional ground is the revenue-model and pricing vocabulary, not shared identity. Use that ground; do not build on any personal affinity.

## Persona weights

**Relationship prior, peer:** Peer Evaluator and Data-Driven Prober dominate. **Interviewer signals:** "data-driven" lifts the Prober. The pricing spine tilts case questions toward pricing. The startup chapter adds a Skeptic angle on pace. **Loop:** your message establishes a single conversation with Dan, so no archetype fallback applies. No loop source names a values round, so no values-style round is detected and no VAL bank is written.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Peer Evaluator | Seams between teams, what she would need from them, credit | High. Peer relationship prior, and the JD's cross-functional line | Seam principles, not claimed knowledge of their seam. Reciprocity. A disagreement story with spine and tact | 5 (A) |
| Data-Driven Prober | Every number traced to its inputs | High. Self-described "relentlessly data-driven"; $400M and volume targets are headline figures | Say what she knows of each figure's counting; name the weakest assumption first; say plainly when she does not know | 5 (B) |
| Case / Strategist | Pricing-tilted live problems | Medium. Pricing career spine; land/adopt/expand/renew and partner-motion lines in the JD | Clarify, structure, state the framework briefly, challenge one premise | 3 (C) |
| Skeptic | Partner-motion and quota gaps | Medium. F1 and F8 are the thinnest matches to the JD; a peer hears them as load | Hold, then concede, on partner work; plain acknowledgment on quota | 3 (D) |
| Pressure / Stress | "How much of it was actually you?" | Low to medium. No stress signal, but the $400M figure invites one | Pause, hold a position the quote carries, concede only what she cannot back | 2 (E) |
| Conversational / Rapport | Casual opener, casual AI question | Low to medium. Peer rapport; casual questions are still scored | A 90-second arc from the two background sentences | 2 (F) |
| Values / Behavioral | — | Not weighted. No loop source names a values round, and the loop is one conversation | No bank; confirm with the recruiter (upgrade menu) | 0 |

## Highest-ROI prep

**D1, the partner-motion objection.** The JD requires partner-motion design, and her only partner evidence (F1) sits at transferability. A peer will test where her partner claim stops. Rehearse D1 to three levels of follow-up before anything else in this pack.

## Question banks

Total: 20 questions across six personas.

### A. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between emerging products and sales strategy, and what happens when we disagree?" | JD | [generic] "set annual volume targets with cross-org consensus" — the coach's notes | Propose seam principles rather than claim to know their seam: who sets price and packaging, who sets the motion, and how a disagreement is escalated once and then closed. For the disagreement, pick a time the outcome was genuinely contested and name what she did to reach agreement. Answer slot: if she handled a disagreement with another team well, say what it was and what changed; if none comes to mind, say so, then give the consensus story from F6, at the quote's scope. | Peer stem. The seam is the peer's question. The F6 quote is the only cross-functional evidence and it is the fallback story. The question presupposes nothing about her. |
| A2 | "How do you handle credit when work spans teams?" | JD | [grounded] "set annual volume targets with cross-org consensus" — the coach's notes | Story map from F6: the targets, set across orgs, by consensus. The consensus belongs to the group; her share is what she did within it. Answer slot: say what part was hers in reaching consensus. If none was singled out, say that, and say how the targets were shared. | Peer probe on credit, using the one cross-functional sentence she has. F6 is the evidence and its limit is named. |
| A3 | "Walk me through the partner-level revenue model you built for the carrier negotiations." | EXP | [grounded] "Built a partner-level revenue model used in carrier negotiations" — the coach's notes | Story map from F1: built, partner-level, revenue model, used in carrier negotiations. Tell those beats in her own words, at their scope. Answer slot: if she chose what the model covered or how its inputs were set, say which and how she decided. If the carrier side set those, or she did not build the inputs, say so and describe what the model did in the negotiation. | Premised question: the premise is the quote itself. EXP tests attribution. Dan's pricing lens makes a model walk-through a likely probe. |
| A4 | "If you joined, what would you need from my team in the first ninety days?" | JD | [generic] "Built a partner-level revenue model used in carrier negotiations" — the coach's notes | Reciprocity framing. Name one thing she would need from their team and one thing she would bring. Keep the bring-side to the quote: the partner model, at its own scope. Answer slot: name the one input she needs from their side, with a reason. | Peer test of whether the hire adds to load. Reciprocity is what she brings the peer's team, not only what she needs. |
| A5 | "Pricing and packaging for a new line: who should decide which, and where does your work stop?" | JD | [grounded] "own GTM strategy for two new product lines" — your message; "9 years at a large consumer-tech company in product strategy and ops" — the coach's notes | Seam principle first: separate who sets price and packaging from who sets the go-to-market motion, and say which one she would bring evidence to. Her product strategy and ops work is the adjacent part; owning GTM for a new line is the part the JD asks her to take on. Answer slot: if she set price or packaging for any product, say which and what she decided; if not, say so and say what evidence she would bring to that decision. | A peer seam on pricing, which is Dan's career spine. The JD line is the raising source; F2's limit is named. |

### B. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that $400M was counted." | EXP | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" — the coach's notes | Three defend-the-number slots, in her own words. First, the counting: answer slot, if she knows how it was counted say it; if not, say the figure is credited and that she does not know its counting method. Second, the weakest assumption: name it before they do; answer slot, name it or say she does not know which assumption carries most weight. Third, her part: she proposed the change; the figure is credited to it. | F7 is the headline figure and the Prober's first target. Naming the weakest assumption before it is asked converts a gotcha into credibility. |
| B2 | "Which assumption behind the volume targets would you defend least?" | EXP | [grounded] "set annual volume targets with cross-org consensus" — the coach's notes; "No classic sales-ops or quota-setting experience" — the coach's notes | Weakest-assumption move on F6: name the assumption behind the targets, and what it took from consensus. Answer slot: name the assumption, or say she does not know how the targets were built. Do not call them quotas; if asked, use F8's plain acknowledgment, "I haven't done classic sales-ops or quota-setting." | Metric probe on a second figure. The F8 negative is in the coach's notes, so the plain acknowledgment has its source. |
| B3 | "Walk me through the last analysis you ran end to end in SQL or Tableau. What did you check before you believed it?" | JD | [grounded] "independent analysis in SQL and Tableau" — your message; "skilled in SQL/Tableau" — the coach's notes | Open prompt. Selection scaffold: pick an analysis she ran herself, from question to chart, and say what she checked before trusting the number. Her material carries only the tools; the story has to be hers. Answer slot: if the analysis was hers from start to finish, say so; if she ran part of it, say which part; if she has not run one end to end, say so and describe the nearest one she did run. | Open prompt on the JD's analysis line. F4 gives the tools; independence is the slot. Scores the verification habit Dan will test. |
| B4 | "How do you know the store change caused the uplift, and not the season?" | EXP | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" — the coach's notes | Premise: the uplift is attributed to the change. Answer slot: if she knows how attribution was done, say which method and what it could not rule out; if not, say so and say who would know. The figure is credited to the change in her material; do not describe how it was attributed. | A causal probe on F7. Dan's standard test. |
| B5 | "What did you use AI tools for last week, concretely?" | JD | [grounded] "uses AI tools daily" — the coach's notes; "AI experience a plus" — your message | Plus-item asked casually and then probed. Name one tool and one task where it changed what she produced. The daily use is the fact; the task is the slot. Answer slot: if she names a task, give one concrete output. If not, say she uses the tools daily and stop there. | The JD plus-item. Compass makes AI usage a natural lead for Dan. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A new product line has no pricing history. How would you size its whitespace across land, adopt, expand and renew?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" — your message | Structure in order: clarify the line's goal and buyer; define whitespace as accounts and motions not yet served; segment; choose an approach that tests segments first; name the metric for each stage; name one risk. Say the framework aloud, briefly. Challenge one premise if they supply one. No past project here; the case is live. | Live problem from the JD line. Dan's pricing lens makes price-led segmentation likely. No claim about her, so nothing to fabricate. |
| C2 | "Compass is launching, and a much larger platform vendor is bundling a similar copilot into its suite. Where does a new product line win or lose?" | CO | [grounded] "an AI copilot launch ('Compass')" — your message; "bundling by a much larger platform vendor" — your message | Clarify first: does win or lose mean revenue, retention or adoption? Name which two of the three stated priorities the bundle presses on, and form a hypothesis for each. Say what she would need to know about the bundle's price before sizing the threat. Do not describe Compass's features; the material has only the launch name. | CO from your research note. Undated, so kept at the note's level. Price anchoring is ground Dan knows well. |
| C3 | "A bundled competitor anchors its price at zero for a similar feature. How would you think about pricing the partner motion?" | CASE | [grounded] "partner-motion design experience required" — your message | Structure: what a zero anchor changes for the partner's economics, what else the partner gets besides price, the margin that can be afforded, and the first test to run. Give a framework and a first test, not a price. | Raising source: the JD's partner-motion line. A case, so no claim about her. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" — your message; "Built a partner-level revenue model used in carrier negotiations" — the coach's notes | **Highest-ROI prep.** The objection is the partner motion. Hold: the partner-level revenue model she built is the partner work she has done, said at that scope. Hold through two follow-ups. Concede only what she cannot back: answer slot, if she has designed any part of a partner motion, say which and how she decided; if she has not, say so plainly. Then give the ramp as a plan: what she would learn first. Second follow-up: return to the model, do not add to it. | The JD's one headline requirement with thin evidence. The Skeptic tests where her partner claim stops. The deepest rehearsal in the pack: three levels. |
| D2 | "I don't see quota-setting or sales-ops in your background. How would you set targets for a new line?" | JD | [grounded] "No classic sales-ops or quota-setting experience" — the coach's notes; "set annual volume targets with cross-org consensus" — the coach's notes | Plain acknowledgment first: "I haven't done classic sales-ops or quota-setting." Then the bridge at the quote's scope: "I set annual volume targets with cross-org consensus." Then how she would set targets for a new line, as a method. Answer slot: say what the targets she set were for, and whether they directed sales work; if they did not, say so. | The gap F8 is a stated negative, so the plain acknowledgment has its source. The material does not show whether the earlier targets were quotas, and the answer must not claim they were. |
| D3 | "Tell me about the stage of the land, adopt, expand, renew cycle where you have the most evidence of finding whitespace." | JD | [grounded] "identify whitespace across land/adopt/expand/renew" — your message | Open prompt, selection scaffold: pick the stage where she has a named example. If none, say so plainly, then say how she would find whitespace in the first month, as a plan. Do not claim an example the material does not carry; the material does not show whitespace work. | F3 is discovery. This is the Skeptic's cross-examination of a headline requirement, with the honest branch ready. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That answer depends on the $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" — the coach's notes | Hold, then concede. Hold: "I proposed the change," the quote's verb, at its scope. Second follow-up: hold again; the figure is credited, not sole. Concede specifically, only what she cannot back. Answer slot: if she knows her share, give it and how she knows; if not, say she does not know it. Never offer a share she has not got. | Pressure stem. A held position must be one the quote carries; the concession is her share of a credited figure. |
| E2 | "Sixty seconds: why would Northwind need someone whose background is consumer tech?" | JD | [grounded] "9 years at a large consumer-tech company in product strategy and ops" — the coach's notes; "Built a partner-level revenue model used in carrier negotiations" — the coach's notes | Pause, restate the question, then anchor: nine years in product strategy and ops, and the partner model used in carrier negotiations, both at their scope. Hold through two follow-ups. Answer slot: give the reason she believes the fit is real, in her own words; if she does not yet hold one, say so. Do not claim B2B experience; the material does not carry it. | Sixty-second composure test. The answer's anchor is two quotes. |

### F. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" — the coach's notes; "9 years at a large consumer-tech company in product strategy and ops" — the coach's notes | Pre-scripted 90-second arc: two years of strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company, then why this role. Each beat is one of the quoted sentences. Answer slot: the "why" in her own words; if the reason is still forming, say so. | A casual opener that is scored for economy. The arc is built only from the two background sentences. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" — the coach's notes | Treat it as scored. One tool, one sentence on what she used it for, then stop. Answer slot: if she has a second example, give it; if not, stop there. | The JD plus-item asked casually. The specifics come from her, not from the pack. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | A5, D1 |
| identify whitespace across land/adopt/expand/renew | C1, D3 |
| independent analysis in SQL and Tableau | B3 |
| partner-motion design experience required | D1, C3, A3 |
| strong cross-functional influence | A1, A2, B2 |
| AI experience a plus | B5, F2 |

Stated gap, not in the JD highlights: quota-setting, D2 (sourced to the notes). Headline figure, no JD line: B1, B4, E1.

## Reverse questions

R1 ties to Dan's own path; R2 is the reciprocity question for a peer.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You moved from an early-stage startup into pricing and monetization. What did that move show you about where a new product's revenue model breaks first?" | Ties to Dan's own path (your profile). It turns a monetization probe into a peer conversation about how they think. |
| R2 | "What would a new person on your team do in the first month that would genuinely help?" | Reciprocity for a peer. It signals she is thinking about the hire's contribution, not only her own needs. |
| R3 | "Where do pricing decisions for a new line get made today, and where does sales strategy's input come in?" | Shows she has thought about the seam (A1, A5) and asks Dan to name it. |
| R4 | "How does the team read the bundling threat: as a pricing response or a product one?" | Tests the research note with the person who owns the answer. |
| R5 | "Compass: which customer decision do you expect it to change first?" | Anchors the AI copilot priority in a decision, not a feature. |
| R6 | "What does the profitability priority mean for how a new line is measured in its first year?" | Connects to the third stated priority and to how Dan's pricing lens measures outcomes. |

## Sources

**Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Would have set the values names. No values-style round is established, so no cheat sheet is built either way. |
| 2. Northwind Data interview process, sales strategy | unavailable | Would have checked the loop against public sources. Your message already establishes it: one 60-minute conversation with Dan. Nothing lost. |
| 3. Northwind strategy and recent news | skipped | Your research note fixes the three stated priorities and the competitive threat, which feed C2 and R4 to R6. The note is undated, so that content is cited as your message and not checked against recent news. |
| 4. Dan Kovac and Northwind | unavailable | Would have added public talks, posts and self-descriptions. Reading uses only your profile ("relentlessly data-driven"; pricing and monetization career; one startup chapter). Recurring themes are unestablished. |
| 5. Representative JD | skipped | Your JD highlights fix the fit snapshot and the JD-tagged questions. The full JD is still missing (upgrade menu). |

Queries sent, all refused:
- "Northwind Data values operating principles" (target 1): refused
- "Northwind Data interview process sales strategy" (target 2): refused
- "Dan Kovac Director of Sales Strategy Northwind Data" (target 4): refused

**Provided documents:** your message (JD highlights, research note, interviewer profile, candidate background). No dossier present. No assessment provided.

## Upgrade menu

- The full JD text → any requirement beyond the six highlights gets a row, and any location, work-authorization or travel line is checked as a gate.
- A recruiter's note on the 60 minutes, if anything was pre-declared (a presentation, a written point of view, a take-home) → graded deliverable build sections.
- Search access, or Dan's public talks and posts pasted in → recurring themes sharpen B and D questions and the reverse questions. Search was refused this session.
- Confirmation from the recruiter of whether the round includes a values question → values cheat sheet and VAL questions.
- A strategy brief under six months old → a grounding section and sharper C2 and R4 to R6.
- A deeper research pass (up to 6 more searches and 2 more fetches, several minutes) would add a company strategy brief. Search was refused this session, so it would need access first.
- `tuesday-dossier.md` → prior verified evidence and a prohibited-claims list from earlier review, in place of the local list above.

---

Say the word and I'll run a live drill as the Skeptic on D1, the partner-motion objection.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for Priya to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you send the full JD text, including any location, work-authorization or travel line? It changes which requirements get rows and whether any gate exists.
2. Did the recruiter pre-declare anything for the 60 minutes, such as a presentation, a written point of view or a take-home? If so, it gets its own build section.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer on the same VP's team. **Session:** one 60-minute conversation.

Built on one assumption: the single session is a conversation with Dan as peer, as your message states. The JD is your highlights, not the full posting, so requirement quotes come only from those highlights.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** not used, because no values-style round is established. **EXP** tests the work she did. **JD** tests the posted role. **CO** tests company and strategy knowledge. **CASE** is a live problem.
- Guidance is scaffolding, not a script. Each cell should be speakable in 90 to 120 seconds.
- An **answer slot** is an instruction for the interview, not a question to me. Where a slot says "if you did X, say how," the honest branch is always available: "if it was not yours, say so plainly."

## Fit snapshot

Quotes in the Evidence column come from her material. Cited as "the coach's notes" are the candidate facts in your message. Cited as "your message" are the JD highlights and the research note.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "partner-motion design experience required" — your message | "Built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The notes show a model built and used in carrier negotiations. They do not show a partner motion designed end to end, so the bridge stays at the model: "I built a partner-level revenue model, and it was used in carrier negotiations." Answer slot: the partner-motion line makes a probe on how partners are enabled or paid likely. If you designed any part of that, say which part and how you decided; if you did not, say so plainly and return to the model. |
| F2 | "own GTM strategy for two new product lines" — your message | "9 years at a large consumer-tech company in product strategy and ops" — the coach's notes | medium | [grounded] | transferability | Product strategy and ops is adjacent to owning GTM for new lines. It does not say GTM was owned. Words: "I spent nine years in product strategy and ops at a large consumer-tech company." Answer slot: if you set the go-to-market plan for any launch, name it and what you decided; if you worked alongside the owner of that plan, say that and what you contributed. |
| F3 | "identify whitespace across land/adopt/expand/renew" — your message | none given | none | [grounded] | discovery | Silence, not a stated absence: the material does not show whitespace work. Answer slot: name the stage of land, adopt, expand or renew you have worked on most and the evidence you used. If none, say so, then say how you would find whitespace in the first month, as a plan. |
| F4 | "independent analysis in SQL and Tableau" — your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | presentation | The quote reaches the tools; independence is not shown. Words: "I'm skilled in SQL and Tableau." Answer slot: name an analysis you ran end to end and what you checked before you trusted it. If you did not run it yourself, say so. |
| F5 | "AI experience a plus" — your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | none | The quote already reaches the requirement in usage terms. Words: "I use AI tools daily." Probe likely on which tools and what for. Answer slot: name one tool and one task it changed. |
| F6 | "strong cross-functional influence" — your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Words: "I set annual volume targets with cross-org consensus." Answer slot: say what part was hers in reaching that consensus, and what she did when a team disagreed. If no part was singled out as hers, say so. |
| F7 | headline figure on the CV, no JD line — the coach's notes | "proposed a store-surface change credited with ~$400M ARR uplift" — the coach's notes | medium | [grounded] | none | The figure is credited, which is shared attribution. Words stay at the quote: "I proposed a store-surface change, credited with about $400M ARR uplift." The defend-the-number slots are in B1. |
| F8 | sales planning, quota or target-setting — role-family pattern, not from your inputs | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A negative stated in the notes. Words, for her to confirm: "I haven't done classic sales-ops or quota-setting." No slot: this is a plain acknowledgment. Never a claim to quota work. |

**Gap types above:** transferability (F1, F2), discovery (F3), presentation (F4, F6), none (F5, F7), capability (F8). No gate row appears: your highlights name no location, work-authorization or travel requirement. The full JD may add one (see upgrade menu).

## Prohibited claims

These are not coached anywhere in this pack. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for new product lines | Inflated form of F2 | F2's quote at its own scope: product strategy and ops. The limit is my observation: the notes say product strategy and ops, not GTM ownership. |
| Designed a partner motion | Inflated form of F1 | F1's quote: a partner-level revenue model, used in carrier negotiations. |
| Drove the $400M | Inflated form of F7, which says "credited with" | F7's quote at its own scope. The figure is credited, shared attribution. |
| Set the volume targets alone | Inflated form of F6, which says "with cross-org consensus" | F6's quote, with "with cross-org consensus" kept in. |
| Independent SQL and Tableau analysis | Inflated form of F4, which says "skilled in" | F4's quote at its scope. Independence is an answer slot, not a claim. |
| Quota-setting experience | Negative stated in the notes, F8 | "I haven't done classic sales-ops or quota-setting." A plain acknowledgment. No slot. |

## Reading the interviewer

**Source:** your message only. Dan's public footprint was not established (see Sources).

- **Career pattern:** pricing and monetization roles at the core, with one early-stage-startup chapter.
- **Self-description:** "relentlessly data-driven."

Practical implications:

1. Every headline figure will be probed to its assumptions. The $400M (B1, B4) and the volume targets (B2) are the likely targets.
2. Pricing and monetization is their native language. Case questions lean toward pricing (C1, C3). The partner-level revenue model (F1) is the nearest shared vocabulary. Use only the quote's own words.
3. The startup chapter suggests scepticism about big-company pace. Your material has no startup chapter, so no shared professional jump is offered. None exists in the material to pair with theirs.
4. Shared professional ground is the revenue-model and pricing vocabulary, not shared identity. Use that ground; do not build on any personal affinity.

## Persona weights

**Relationship prior, peer:** Peer Evaluator and Data-Driven Prober dominate. **Interviewer signals:** "data-driven" lifts the Prober. The pricing spine tilts case questions toward pricing. The startup chapter adds a Skeptic angle on pace. **Loop:** your message establishes a single conversation with Dan, so no archetype fallback applies. No loop source names a values round, so no values-style round is detected and no VAL bank is written.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Peer Evaluator | Seams between teams, what she would need from them, credit | High. Peer relationship prior, and the JD's cross-functional line | Seam principles, not claimed knowledge of their seam. Reciprocity. A disagreement story with spine and tact | 5 (A) |
| Data-Driven Prober | Every number traced to its inputs | High. Self-described "relentlessly data-driven"; $400M and volume targets are headline figures | Say what she knows of each figure's counting; name the weakest assumption first; say plainly when she does not know | 5 (B) |
| Case / Strategist | Pricing-tilted live problems | Medium. Pricing career spine; land/adopt/expand/renew and partner-motion lines in the JD | Clarify, structure, state the framework briefly, challenge one premise | 3 (C) |
| Skeptic | Partner-motion and quota gaps | Medium. F1 and F8 are the thinnest matches to the JD; a peer hears them as load | Hold, then concede, on partner work; plain acknowledgment on quota | 3 (D) |
| Pressure / Stress | "How much of it was actually you?" | Low to medium. No stress signal, but the $400M figure invites one | Pause, hold a position the quote carries, concede only what she cannot back | 2 (E) |
| Conversational / Rapport | Casual opener, casual AI question | Low to medium. Peer rapport; casual questions are still scored | A 90-second arc from the two background sentences | 2 (F) |
| Values / Behavioral | — | Not weighted. No loop source names a values round, and the loop is one conversation | No bank; confirm with the recruiter (upgrade menu) | 0 |

## Highest-ROI prep

**D1, the partner-motion objection.** The JD requires partner-motion design, and her only partner evidence (F1) sits at transferability. A peer will test where her partner claim stops. Rehearse D1 to three levels of follow-up before anything else in this pack.

## Question banks

Total: 20 questions across six personas.

### A. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between emerging products and sales strategy, and what happens when we disagree?" | JD | [generic] "set annual volume targets with cross-org consensus" — the coach's notes | Propose seam principles rather than claim to know their seam: who sets price and packaging, who sets the motion, and how a disagreement is escalated once and then closed. For the disagreement, pick a time the outcome was genuinely contested and name what she did to reach agreement. Answer slot: if she handled a disagreement with another team well, say what it was and what changed; if none comes to mind, say so, then give the consensus story from F6, at the quote's scope. | Peer stem. The seam is the peer's question. The F6 quote is the only cross-functional evidence and it is the fallback story. The question presupposes nothing about her. |
| A2 | "How do you handle credit when work spans teams?" | JD | [grounded] "set annual volume targets with cross-org consensus" — the coach's notes | Story map from F6: the targets, set across orgs, by consensus. The consensus belongs to the group; her share is what she did within it. Answer slot: say what part was hers in reaching consensus. If none was singled out, say that, and say how the targets were shared. | Peer probe on credit, using the one cross-functional sentence she has. F6 is the evidence and its limit is named. |
| A3 | "Walk me through the partner-level revenue model you built for the carrier negotiations." | EXP | [grounded] "Built a partner-level revenue model used in carrier negotiations" — the coach's notes | Story map from F1: built, partner-level, revenue model, used in carrier negotiations. Tell those beats in her own words, at their scope. Answer slot: if she chose what the model covered or how its inputs were set, say which and how she decided. If the carrier side set those, or she did not build the inputs, say so and describe what the model did in the negotiation. | Premised question: the premise is the quote itself. EXP tests attribution. Dan's pricing lens makes a model walk-through a likely probe. |
| A4 | "If you joined, what would you need from my team in the first ninety days?" | JD | [generic] "Built a partner-level revenue model used in carrier negotiations" — the coach's notes | Reciprocity framing. Name one thing she would need from their team and one thing she would bring. Keep the bring-side to the quote: the partner model, at its own scope. Answer slot: name the one input she needs from their side, with a reason. | Peer test of whether the hire adds to load. Reciprocity is what she brings the peer's team, not only what she needs. |
| A5 | "Pricing and packaging for a new line: who should decide which, and where does your work stop?" | JD | [grounded] "own GTM strategy for two new product lines" — your message; "9 years at a large consumer-tech company in product strategy and ops" — the coach's notes | Seam principle first: separate who sets price and packaging from who sets the go-to-market motion, and say which one she would bring evidence to. Her product strategy and ops work is the adjacent part; owning GTM for a new line is the part the JD asks her to take on. Answer slot: if she set price or packaging for any product, say which and what she decided; if not, say so and say what evidence she would bring to that decision. | A peer seam on pricing, which is Dan's career spine. The JD line is the raising source; F2's limit is named. |

### B. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that $400M was counted." | EXP | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" — the coach's notes | Three defend-the-number slots, in her own words. First, the counting: answer slot, if she knows how it was counted say it; if not, say the figure is credited and that she does not know its counting method. Second, the weakest assumption: name it before they do; answer slot, name it or say she does not know which assumption carries most weight. Third, her part: she proposed the change; the figure is credited to it. | F7 is the headline figure and the Prober's first target. Naming the weakest assumption before it is asked converts a gotcha into credibility. |
| B2 | "Which assumption behind the volume targets would you defend least?" | EXP | [grounded] "set annual volume targets with cross-org consensus" — the coach's notes; "No classic sales-ops or quota-setting experience" — the coach's notes | Weakest-assumption move on F6: name the assumption behind the targets, and what it took from consensus. Answer slot: name the assumption, or say she does not know how the targets were built. Do not call them quotas; if asked, use F8's plain acknowledgment, "I haven't done classic sales-ops or quota-setting." | Metric probe on a second figure. The F8 negative is in the coach's notes, so the plain acknowledgment has its source. |
| B3 | "Walk me through the last analysis you ran end to end in SQL or Tableau. What did you check before you believed it?" | JD | [grounded] "independent analysis in SQL and Tableau" — your message; "skilled in SQL/Tableau" — the coach's notes | Open prompt. Selection scaffold: pick an analysis she ran herself, from question to chart, and say what she checked before trusting the number. Her material carries only the tools; the story has to be hers. Answer slot: if the analysis was hers from start to finish, say so; if she ran part of it, say which part; if she has not run one end to end, say so and describe the nearest one she did run. | Open prompt on the JD's analysis line. F4 gives the tools; independence is the slot. Scores the verification habit Dan will test. |
| B4 | "How do you know the store change caused the uplift, and not the season?" | EXP | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" — the coach's notes | Premise: the uplift is attributed to the change. Answer slot: if she knows how attribution was done, say which method and what it could not rule out; if not, say so and say who would know. The figure is credited to the change in her material; do not describe how it was attributed. | A causal probe on F7. Dan's standard test. |
| B5 | "What did you use AI tools for last week, concretely?" | JD | [grounded] "uses AI tools daily" — the coach's notes; "AI experience a plus" — your message | Plus-item asked casually and then probed. Name one tool and one task where it changed what she produced. The daily use is the fact; the task is the slot. Answer slot: if she names a task, give one concrete output. If not, say she uses the tools daily and stop there. | The JD plus-item. Compass makes AI usage a natural lead for Dan. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A new product line has no pricing history. How would you size its whitespace across land, adopt, expand and renew?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" — your message | Structure in order: clarify the line's goal and buyer; define whitespace as accounts and motions not yet served; segment; choose an approach that tests segments first; name the metric for each stage; name one risk. Say the framework aloud, briefly. Challenge one premise if they supply one. No past project here; the case is live. | Live problem from the JD line. Dan's pricing lens makes price-led segmentation likely. No claim about her, so nothing to fabricate. |
| C2 | "Compass is launching, and a much larger platform vendor is bundling a similar copilot into its suite. Where does a new product line win or lose?" | CO | [grounded] "an AI copilot launch ('Compass')" — your message; "bundling by a much larger platform vendor" — your message | Clarify first: does win or lose mean revenue, retention or adoption? Name which two of the three stated priorities the bundle presses on, and form a hypothesis for each. Say what she would need to know about the bundle's price before sizing the threat. Do not describe Compass's features; the material has only the launch name. | CO from your research note. Undated, so kept at the note's level. Price anchoring is ground Dan knows well. |
| C3 | "A bundled competitor anchors its price at zero for a similar feature. How would you think about pricing the partner motion?" | CASE | [grounded] "partner-motion design experience required" — your message | Structure: what a zero anchor changes for the partner's economics, what else the partner gets besides price, the margin that can be afforded, and the first test to run. Give a framework and a first test, not a price. | Raising source: the JD's partner-motion line. A case, so no claim about her. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" — your message; "Built a partner-level revenue model used in carrier negotiations" — the coach's notes | **Highest-ROI prep.** The objection is the partner motion. Hold: the partner-level revenue model she built is the partner work she has done, said at that scope. Hold through two follow-ups. Concede only what she cannot back: answer slot, if she has designed any part of a partner motion, say which and how she decided; if she has not, say so plainly. Then give the ramp as a plan: what she would learn first. Second follow-up: return to the model, do not add to it. | The JD's one headline requirement with thin evidence. The Skeptic tests where her partner claim stops. The deepest rehearsal in the pack: three levels. |
| D2 | "I don't see quota-setting or sales-ops in your background. How would you set targets for a new line?" | JD | [grounded] "No classic sales-ops or quota-setting experience" — the coach's notes; "set annual volume targets with cross-org consensus" — the coach's notes | Plain acknowledgment first: "I haven't done classic sales-ops or quota-setting." Then the bridge at the quote's scope: "I set annual volume targets with cross-org consensus." Then how she would set targets for a new line, as a method. Answer slot: say what the targets she set were for, and whether they directed sales work; if they did not, say so. | The gap F8 is a stated negative, so the plain acknowledgment has its source. The material does not show whether the earlier targets were quotas, and the answer must not claim they were. |
| D3 | "Tell me about the stage of the land, adopt, expand, renew cycle where you have the most evidence of finding whitespace." | JD | [grounded] "identify whitespace across land/adopt/expand/renew" — your message | Open prompt, selection scaffold: pick the stage where she has a named example. If none, say so plainly, then say how she would find whitespace in the first month, as a plan. Do not claim an example the material does not carry; the material does not show whitespace work. | F3 is discovery. This is the Skeptic's cross-examination of a headline requirement, with the honest branch ready. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That answer depends on the $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" — the coach's notes | Hold, then concede. Hold: "I proposed the change," the quote's verb, at its scope. Second follow-up: hold again; the figure is credited, not sole. Concede specifically, only what she cannot back. Answer slot: if she knows her share, give it and how she knows; if not, say she does not know it. Never offer a share she has not got. | Pressure stem. A held position must be one the quote carries; the concession is her share of a credited figure. |
| E2 | "Sixty seconds: why would Northwind need someone whose background is consumer tech?" | JD | [grounded] "9 years at a large consumer-tech company in product strategy and ops" — the coach's notes; "Built a partner-level revenue model used in carrier negotiations" — the coach's notes | Pause, restate the question, then anchor: nine years in product strategy and ops, and the partner model used in carrier negotiations, both at their scope. Hold through two follow-ups. Answer slot: give the reason she believes the fit is real, in her own words; if she does not yet hold one, say so. Do not claim B2B experience; the material does not carry it. | Sixty-second composure test. The answer's anchor is two quotes. |

### F. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" — the coach's notes; "9 years at a large consumer-tech company in product strategy and ops" — the coach's notes | Pre-scripted 90-second arc: two years of strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company, then why this role. Each beat is one of the quoted sentences. Answer slot: the "why" in her own words; if the reason is still forming, say so. | A casual opener that is scored for economy. The arc is built only from the two background sentences. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" — the coach's notes | Treat it as scored. One tool, one sentence on what she used it for, then stop. Answer slot: if she has a second example, give it; if not, stop there. | The JD plus-item asked casually. The specifics come from her, not from the pack. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | A5, D1 |
| identify whitespace across land/adopt/expand/renew | C1, D3 |
| independent analysis in SQL and Tableau | B3 |
| partner-motion design experience required | D1, C3, A3 |
| strong cross-functional influence | A1, A2, B2 |
| AI experience a plus | B5, F2 |

Stated gap, not in the JD highlights: quota-setting, D2 (sourced to the notes). Headline figure, no JD line: B1, B4, E1.

## Reverse questions

Each one lands for a stated reason. R1 ties to Dan's own path; R2 is the reciprocity question for a peer.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You moved from an early-stage startup into pricing and monetization. What did that move show you about where a new product's revenue model breaks first?" | Ties to Dan's own path (your profile). It turns a monetization probe into a peer conversation about how they think. |
| R2 | "What would a new person on your team do in the first month that would genuinely help?" | Reciprocity for a peer. It signals she is thinking about the hire's contribution, not only her own needs. |
| R3 | "Where do pricing decisions for a new line get made today, and where does sales strategy's input come in?" | Shows she has thought about the seam (A1, A5) and asks Dan to name it. |
| R4 | "How does the team read the bundling threat: as a pricing response or a product one?" | Tests the research note with the person who owns the answer. |
| R5 | "Compass: which customer decision do you expect it to change first?" | Anchors the AI copilot priority in a decision, not a feature. |
| R6 | "What does the profitability priority mean for how a new line is measured in its first year?" | Connects to the third stated priority and to how Dan's pricing lens measures outcomes. |

## Sources

**Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Would have set the values names. No values-style round is established, so no cheat sheet is built either way. |
| 2. Northwind Data interview process, sales strategy | unavailable | Would have checked the loop against public sources. Your message already establishes it: one 60-minute conversation with Dan. Nothing lost. |
| 3. Northwind strategy and recent news | skipped | Your research note fixes the three stated priorities and the competitive threat, which feed C2 and R4 to R6. The note is undated, so that content is cited as your message and not checked against recent news. |
| 4. Dan Kovac and Northwind | unavailable | Would have added public talks, posts and self-descriptions. Reading uses only your profile ("relentlessly data-driven"; pricing and monetization career; one startup chapter). Recurring themes are unestablished. |
| 5. Representative JD | skipped | Your JD highlights fix the fit snapshot and the JD-tagged questions. The full JD is still missing (upgrade menu). |

Queries sent, all refused:
- "Northwind Data values operating principles" (target 1): refused
- "Northwind Data interview process sales strategy" (target 2): refused
- "Dan Kovac Director of Sales Strategy Northwind Data" (target 4): refused

**Provided documents:** your message (JD highlights, research note, interviewer profile, candidate background). No dossier present. No assessment provided.

## Upgrade menu

- The full JD text → any requirement beyond the six highlights gets a row, and any location, work-authorization or travel line is checked as a gate.
- A recruiter's note on the 60 minutes, if anything was pre-declared (a presentation, a written point of view, a take-home) → graded deliverable build sections.
- Search access, or Dan's public talks and posts pasted in → recurring themes sharpen B and D questions and the reverse questions. Search was refused this session.
- Confirmation from the recruiter of whether the round includes a values question → values cheat sheet and VAL questions.
- A strategy brief under six months old → a grounding section and sharper C2 and R4 to R6.
- A deeper research pass (up to 6 more searches and 2 more fetches, several minutes) would add a company strategy brief. Search was refused this session, so it would need access first.
- `tuesday-dossier.md` → prior verified evidence and a prohibited-claims list from earlier review, in place of the local list above.
