Your prep pack is saved at `/var/tmp/tuesday-measure/1a4/runs/haiku/alone/part-2/rooms/case-8-denied-1ed87e83/Ashgrove_Credit_Union_member-experience-lead_interview_pack.md`.

The pack has 20 questions across the three rounds, a fit snapshot against the JD, a values cheat sheet, five reverse questions, and a 20-minute escalation case.

Three things to focus on:

- **Contact centre (C1) is the highest-return prep.** You've never worked in one, and the JD names it. Your honest answer is a plan for learning it, not a past. Rehearse that until it sounds natural, then practise the two follow-ups.
- **Senior presenting (C2, E1) is the second gap.** Your material says you haven't presented above regional level. Don't stretch that. Prepare a plan for how you'd get ready.
- **Hub consolidation and digital shift (C3, D3, D4) are the strategy questions to expect.** The panel may ask what happens to an open complaint when a branch closes into a hub.

Points to know:

- Every story in the pack comes from your own sentences. The pack doesn't claim you owned the complaints process end to end, ran reporting on resolution times, or coached supervisors. Where the material is silent, the guidance is a question you answer from your own experience, including "I haven't done that yet."
- The escalation case (D1) is a generic scenario I wrote. It isn't from Ashgrove. Use it to practise the structure: clarify, protect the deadline, find why it bounced between channels, explain it in plain words, coach, and record it.
- I didn't search the web. Your pasted values, strategy brief and recruiter email already covered what I'd have looked up.
- Round 2 and panel names aren't known, so there's no interviewer-specific read yet. If you get the names, I can add it.

Would you like me to play the Skeptic on C1, the contact-centre question, or run the 20-minute escalation case as the panel would? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove_Credit_Union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**For:** Dara
**Interviews:** 3 December 2026, three rounds
- **Round 1:** Recruiter, 30 minutes. Screen.
- **Round 2:** Head of Member Services, 45 minutes, mostly behavioural. Your future manager. Name not yet given.
- **Round 3:** Panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case. Scored against the four values. Names not yet given.

---

## How to use this pack

Personas describe how a question arrives. Types describe what it scores.

- **VAL**: behavioural and values alignment
- **EXP**: your experience, checked in depth
- **JD**: a requirement from the job description
- **CO**: company and strategy
- **CASE**: a live problem

Guidance is scaffolding, not a script. Say it in your own words, and only as far as your own experience goes.

**Answer slots** are instructions for the interview. They ask you to answer from what you did, and to say plainly when a practice was not yours. They are not questions to me, and you do not need to reply to them here.

---

## Fit snapshot

Source for the candidate's evidence: your message ("your message"). Requirements are quoted from the job description you pasted ("JD").

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says the branch's log, and nothing past it. Words: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the stages after the log likely. If you set or ran any stage beyond the branch log, say which and how, in your own words. If none of them was yours, say so and stay with the log. |
| F2 | "the contact centre" (JD, duty line) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | You stated this absence. Words: "I've never worked in a contact centre." Then say how you would learn contact-centre complaint handling, as a plan and never as a past. Nothing is added to make the gap smaller. |
| F3 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Training tellers is adjacent to coaching supervisors, and the bridge stops at tellers. Words: "I trained new tellers on our escalation script." Answer slot: if you have coached a supervisor on an escalation, say what and how. If you have not, say so, and say what you would coach first. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | Monthly complaints reporting is in your material. It does not show which measures the spreadsheet held, so resolution times are unshown. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if the spreadsheet held resolution times, say which and how they were counted. If it did not, say so and say what you would add first. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches reporting in other terms. It does not name Excel. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it was built in Excel, say so. If it was built in another tool, name that tool. |
| F6 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | You stated this absence. Words: "I haven't presented to anyone above regional level." Then say how you would prepare for a senior presentation, as a plan and never as a past. |
| F7 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | low | [inferred] | discovery | Derivation: "formal" is the nearest word in your material to regulated handling, and the word is not "regulated". Complaints work is shown. Whether any of it was regulated is not shown. Words: "I handled the branch's formal complaints log." Answer slot: if any of those complaints carried an external review or a regulatory timescale, say which and what it required of you. If none did, say so. |
| F8 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | The quote reaches the years and the sector in role-relevant terms. Whether a branch counts as customer operations is for the interviewer to judge, so say the years as your sentence says them. Words: "6 years in retail banking, the last 3 as a branch supervisor." |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material has nothing on digital teams or self-service journeys. This is silence, not a stated absence. Answer slot: if you have worked with a digital team on any journey, say which and what your part was. If you have not, say so and say how you would start. |

**Reading the rows.** F2 and F6 are the two places where you have stated an absence yourself. Everything else is either a quote at its own scope or an answer slot. No row adds a practice to your history.

**Gate rows.** The JD states no gate (no licence, credential or location term). So there is no hard-gate row. The hub plan may add one (see the upgrade menu).

---

## Prohibited claims

These are claims the pack will not coach, because the material does not support them or does not support them at this strength. Each one shows its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the complaints process end to end across branches and the contact centre | Inflated form of F1 | "I handled the branch's formal complaints log." The limit is the pack's own observation: your material says the branch log. |
| Has regulated complaints experience | Inflated form of F7 | "I handled the branch's formal complaints log." The pack observes that regulated status is not shown. |
| Built reporting that tracks resolution times | Inflated form of F4 | The spreadsheet sentence at its own scope. The answer slot asks only which measures it held. |
| Coached branch supervisors on escalations | Inflated form of F3 | "I trained new tellers on our escalation script." |
| Wrote the escalation script | Inflated form of "our escalation script" in F3 | Your material says you trained tellers on it. It does not say you wrote it. |
| Has worked in a contact centre | Stated negative (F2) | "I've never worked in a contact centre." Plain acknowledgment. |
| Has presented to senior leaders | Stated negative (F6) | "I haven't presented to anyone above regional level." Plain acknowledgment. |

---

## Grounding brief

Company material you pasted: the 2026 strategy brief (July 2026) and the values page (copied 24 November 2026). Nothing in the material is stale.

| Item | Working detail | Provenance |
|---|---|---|
| Member-owned | "member service", "member complaints" | [grounded] JD wording |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | [grounded] your message, from the strategy brief |
| Digital shift | "move 40% of member service to digital channels by 2028" | [grounded] your message, from the strategy brief |
| Small-business lending | "launch a small-business lending product in Q1 2027" | [grounded] your message, from the strategy brief |
| Competitive pressure | App-only banks | [grounded] your message, from the strategy brief |
| Why it matters for complaints | A consolidated branch network and a digital shift both change where a complaint starts and where it ends. That is the link the strategy questions test. | [inferred] derived from the two strategy items above |

Use the company's own words: "member service", "hubs", "digital channels". Say "complaint" and "escalation" where the JD does.

---

## Persona table

Relationship priors and loop shape decide the weights. No interviewer profile exists, so no interviewer-signal adjustment is made.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly recruiter screen: pay, notice, location and reason for leaving. Casual questions still scored. | High for Round 1. A recruiter screen is a logistics screen first. | Keep the arc short. Give each logistics answer in your own words. |
| Values / Behavioural | Scored questions mapped to Members First, Plain Words, Neighbours, Not Numbers and Own the Fix. | Highest overall. Round 2 is "mostly behavioural", and Round 3 is a values round. | One story per value where a sentence carries one. Otherwise the selection scaffold and its honest branch. |
| Skeptic | Probes the contact-centre gap, the senior-presenting gap and the "formal" log. | High for Round 2. Your own message names both gaps, and a manager will test them. | Rehearse the contact-centre objection until it is plain. Concede the gap; do not bluff. |
| Case / Strategist | The 20-minute escalation case, and hub and digital questions. | High for Round 3. The case is announced. | Clarify before you structure. Use the company's vocabulary. |
| Pressure | Time-boxed "why you" questions. Holds position through follow-ups. | Low to mid. No Pressure round is named, but a manager may press. | Pause, restate, hold through two follow-ups, then concede the specific gap. |

---

## Question banks

Question IDs are letter by persona. Depth follows weight: Conversational 5, Values 5, Skeptic 4, Case 4, Pressure 2. Total: 20.

### Bank A. Conversational (Round 1, recruiter screen)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); "I handled the branch's formal complaints log" (your message); "trained new tellers on our escalation script" (your message); "I built the monthly complaints spreadsheet our regional manager uses" (your message) | A 90-second arc in your own words: the six years, the three as a branch supervisor, then the complaints log, the escalation-script training and the spreadsheet. Stop at the spreadsheet. Do not add a contact-centre or senior-presenting claim. | F8 is the spine of the arc. The other three quotes are its only later beats. |
| A2 | "What are your pay expectations?" | JD | [generic] | Logistics slot. Your material gives no figure. Give your own number, or ask for the band before you give one. Say it once. | Pay is a logistics term your material does not state, so the slot asks for yours and supplies none. |
| A3 | "What is your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period. | Notice is a logistics term your material does not state. |
| A4 | "Where would you be able to work?" | JD | [generic] | Logistics slot. Say where you can work, in your own words. If the hub plan changes the office pattern, ask the recruiter what the pattern will be before you answer. | Location is a logistics term, and the 2027 hub plan makes it live. The material gives no office pattern. |
| A5 | "Why are you thinking of leaving your current role?" | EXP | [generic] | Logistics slot. Give your actual reason, in your own words. Keep it short and true. | Reason for leaving is a logistics slot. No reason is stated, so none is supplied. |

### Bank B. Values / Behavioural (Round 2 and Round 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you put a member's view ahead of a process." | VAL | [grounded] "I handled the branch's formal complaints log" (your message, F1) | Members First. Open prompt. Pick one complaint from the log where what the member wanted and what the process allowed were different. Say what you did and how it ended. If no such complaint comes to mind, say so plainly, then give the nearest thing your material carries: a complaint handled through the log. | Members First is the headline value. The log is the only sentence carrying a member story, and F1 sets its limit. |
| B2 | "Tell me about a time you had to explain something to a member more than once." | VAL | [grounded] "trained new tellers on our escalation script" (your message, F3) | Plain Words. Say how you taught the script to new tellers, and what made it clear or unclear to them. If you never changed how the script was worded, say so, and say what you would change first. | F3 is the only quote touching explanation. Training is the nearest story, and it is teaching, not writing. |
| B3 | "Tell me about a time a decision in one branch affected the people around it." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message, F8) | Neighbours, Not Numbers. Pick a time you saw a branch decision land on its town or its customers. Say what changed and who you spoke to. If none comes to mind, say so plainly, then give the nearest thing your material carries: the branch you supervised, and only what you did there. | Neighbours is the value the hub plan tests most. F8 holds the only branch-level sentence, so the story selection is thin. Say that. |
| B4 | "Tell me about a time you found a problem and stayed with it until it was fixed." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message, F4) | Own the Fix. Pick a problem you found and stayed with until it was solved. If the spreadsheet showed a problem, say what it showed, what you did, and whether it was solved. If it showed none, say so, then say what time you did hold a problem to the end, or that none comes to mind. | Own the Fix is the value closest to the JD's end-to-end line. The spreadsheet is the only quote, and the answer must not outrun it. |
| B5 | "Tell me about a time you had to tell someone senior something they did not want to hear." | VAL | [grounded] "I've never presented to anyone above regional level" (your message, F6) | Hard truth, landed. Pick a time you raised an unwelcome point with someone senior to you. If the most senior person you raised one with was above your branch, say who and what happened. If not, say so, and say how you would raise a hard point with a senior leader. Hold one plain sentence on your limit: "I haven't presented to anyone above regional level." | This is the Values stem most likely in the panel round. F6 means the answer stays at regional level. |

### Bank C. Skeptic (Round 2; lighter in Round 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never worked in a contact centre, and this role covers one. What's your answer to that?" | JD | [grounded] "Never worked in a contact centre" (your message, F2) | **Highest-ROI prep in this pack.** Plain acknowledgment: "I've never worked in a contact centre." Then the part you can answer is the plan: how you would learn contact-centre complaint handling in the first month. Hold through two follow-ups by returning to the plan. Do not add a contact-centre past, and do not present the branch log as contact-centre work. Concede specifically: name the part you would not know on day one. | This will be raised in some form. F2 is the widest gap against a duty line the JD states. A plan is the only honest answer, and it is worth rehearsing until it sounds natural. |
| C2 | "You've never presented above regional level. This role presents to senior leaders. How would you handle that?" | JD | [grounded] "I've never presented to anyone above regional level" (your message, F6) | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan: what you would do before your first senior presentation, said as a plan. Hold through two follow-ups and concede the gap plainly. Do not describe a presentation above regional level, a senior audience or a deck shown to one. | F6 is a capability gap you stated yourself. The JD's "confident presenting to senior leaders" is the raising source. |
| C3 | "Your complaint work has been in branches. Eight of them become five hubs during 2027. What carries across for you?" | CO | [grounded] "I handled the branch's formal complaints log" (your message, F1); "consolidate eight branches into five hubs over 2027" (your message, strategy brief) | Say what carries: the log handling. Say what you would have to learn at hub scale. Keep your work at branch scope. Do not claim experience across a hub or a consolidation. | The strategy brief makes the hub question likely. F1 sets the scope you can speak to. |
| C4 | "What made a complaint 'formal' in your branch's log?" | JD | [grounded] "I handled the branch's formal complaints log" (your message, F1, F7) | Answer slot. Say what the formal category meant, in your own words. Say whether it carried a timescale or an external review. If it did, say what it required of you. If it carried neither, or the rule was not yours, say so. Do not turn "formal" into "regulated" unless the rule was. | F7 is a discovery gap on regulated complaints. The JD raises it. The question asks about the word in the quote, not a practice. |

### Bank D. Case / Strategist (Round 3, panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Here's a live problem. A member's fee complaint has been escalated three times. The contact centre marks it resolved, and the member says it is not. A reply is due in four days. You're the complaints lead. Walk me through what you do." | CASE | [generic] | **Twenty-minute escalation case.** Hold one clarifying question before you propose anything. Then, in about two minutes each: (1) Clarify what the member was told, in writing, and who owns the case now. (2) Protect the deadline: a holding reply and a named owner. (3) Find why it bounced between the branch and the contact centre, and fix that, not only this case. (4) Explain the outcome to the member in plain words. (5) Coach the branch supervisor on the escalation as a teaching step. (6) Record it for the monthly report. Describe each step as what you would do. | The JD's escalation and end-to-end lines are both in this case. The values round scores Own the Fix and Plain Words here. The case is generic because it is a pattern, not a fact about Ashgrove. |
| D2 | "Walk me through the monthly complaints spreadsheet you built. What does it count?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message, F4, F5) | Answer slot. Say what the spreadsheet holds, in your own words. If it holds resolution times, say which, and how they were counted. If it does not, say so, and say what you would add first. If it was built in Excel, say so. If not, say what it was built in. Hold: do not describe a formula, figure or method you cannot repeat. | F4 is discovery on resolution times, and F5 is presentation on Excel. The JD states both. The question asks what the sheet holds, which the quote does not carry. |
| D3 | "Eight branches are becoming five hubs in 2027. When a complaint is open and its branch closes, who owns it?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (your message, strategy brief) | Name the risk: an open complaint can sit between a closing branch and a hub. Say who you would expect to own it, and what you would check on the first day, as a plan. Keep your past at the branch log, since a hub is not in your material. Say what the town would notice first. | The hub handover is the most likely strategy-to-complaints question. Own the Fix and Neighbours are both tested here. |
| D4 | "The brief moves 40% of member service to digital channels by 2028. How would you change the complaints process for a member who's stuck in the app?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your message, strategy brief) | Name the first thing you would check: where the complaint starts in the digital journey, and who sees it. Answer slot on digital work: if you have worked with a digital team on a self-service journey, say which and your part in it. If you have not, say so, then describe how you would start. Do not claim self-service experience. | F9 has no quote. This question is the JD's digital requirement in its strategy form. The honest answer is the second branch. |

### Bank E. Pressure (Round 2; low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why this role, and why should it be you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message, F8) | Sixty seconds: your years, the three as a supervisor, the complaints log, and the parts of the role you can speak to. Hold through two follow-ups. When pushed on the contact centre or senior presenting, say the gap in one sentence and return to the plan. Concede specifically: name the part you have not done yet. | F8 is the only sentence for this answer. F2 and F6 are where the follow-ups will land. |
| E2 | "You've spent three years as a branch supervisor. What would you change about how complaints run across branches, if you led them?" | JD | [grounded] "the last 3 as a branch supervisor" (your message, F8) | Name two or three changes you would make, framed as what you would do. Do not claim you have already made any of them. If challenged, concede what you have not yet seen. | A "what would you change" question presupposes nothing about your past. The pressure is in the follow-up. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | C1, D1, D3 |
| Report monthly on complaint volumes and resolution times | D2 |
| Coach branch supervisors on escalations | D1 only. A thin spot: the coaching step is one line of the case. |
| Work with digital teams on self-service journeys | D4 |
| 4+ years in financial-services customer operations | A1, E1 |
| Experience handling regulated complaints | C4 |
| Confident presenting to senior leaders | C2, E1 |
| Comfortable with Excel reporting | D2 |

Strategy lines (branch consolidation, digital shift) are covered by C3, D3 and D4.

**Highest-ROI prep:** C1, the contact-centre objection. Rehearse the plan answer until it is plain. Then run the two follow-ups.

---

## Values cheat sheet

The panel round scores against the four values, so each value maps to a fit row or a selection scaffold.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | F1: "I handled the branch's formal complaints log." Pick one complaint from the log and say what the member's side was. If none showed it, say so, then say how you would check it. |
| Plain Words | If a member needs it explained twice, the wording was wrong. | F3: "trained new tellers on our escalation script." Say how you taught the script and what you changed in how it was said. If you changed nothing, say so, and say what you would change first. |
| Neighbours, Not Numbers | Every branch is part of its town. | No fit row carries a story. Selection scaffold: pick a time a branch decision reached its town or its customers. If none comes to mind, say so plainly, then give the nearest thing your material carries: F8, "6 years in retail banking, the last 3 as a branch supervisor", with only what you did there. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F4: "I built the monthly complaints spreadsheet our regional manager uses." If the spreadsheet showed a problem, say what, what you did, and whether it was solved. If it showed none, say so, and give a time you kept hold of a problem, or say none comes to mind. |

---

## Reverse questions

Your material has no interviewer profile, so none ties to an interviewer's own path. No peer round is named, so no reciprocity question is needed. Each question below has a "why it lands."

1. **Round 1, recruiter:** "How is the panel's score recorded, value by value?" **Why it lands:** it shows you read the values as a scored round.
2. **Round 2, Head of Member Services:** "When a complaint crosses from a branch to the contact centre today, who owns it until it is solved?" **Why it lands:** it asks for the Own the Fix and end-to-end answer, and tells you how the handoff works now.
3. **Round 2:** "What does the monthly complaints report look like now, and which figure does the senior team read first?" **Why it lands:** it tests what reporting means in practice, and it bears on F4 and F5.
4. **Round 2:** "How will the hub plan change the way complaints are handed on?" **Why it lands:** it shows you read the strategy brief, and it invites the manager to say where the risks are.
5. **Round 3, panel:** "Which of your branches has the most escalations, and what do the teams there say they need from a complaints lead?" **Why it lands:** it puts Neighbours, Not Numbers into a question, and it invites the panel to speak about their own towns.
6. **Round 2 or 3:** "What would a new complaints lead be expected to have fixed by day 90?" **Why it lands:** it asks for the honest path for a candidate who is new to the contact centre and to senior presenting.

---

## Sources

**Provided documents**
- The job description, pasted in your message
- The values, pasted in your message (copied from the company's values page, 24 November 2026)
- The 2026 strategy brief, pasted in your message (July 2026)
- The recruiter's email on the three rounds
- Your background, in your message

**No dossier was present.** Nothing in this pack comes from a dossier.

**Research tier: L1, searches 0 of 6, fetches 0 of 2. No searches or fetches were sent.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | skipped | The pasted values page fixes section 10 (values cheat sheet). |
| 2. Interview process | skipped | The recruiter's email fixes the three rounds and the panel's values scoring, so the loop structure and persona weights follow them. |
| 3. Company strategy and recent news | skipped | The pasted 2026 strategy brief fixes the current priorities and recent moves. |
| 4. Interviewer name and profile | n/a | No interviewer name was given, so no query could be formed. The interviewer read is absent. |
| 5. Representative JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

---

## Upgrade menu

- The Head of Member Services' name and the two branch managers' names → an interviewer read, persona weights per panel member, and tailored reverse questions. Public professional footprint only.
- Any deliverable the recruiter announces (none so far) → a graded build section.
- The office or hub pattern for this role → A4 becomes a checked fit row. If the recruiter states it as a term, it becomes a gate row.
- The fields the spreadsheet holds, in your words (not figures) → F4 moves from discovery to presentation, and D2's answer slot gets its answer.
- Any contact-centre, digital or regulated-complaint work, if you have done any → F2, F7 and F9 get a grounded bridge in your own sentences.
- The complaints policy or external review that applies to the branch log → C4 can name the framework. Currently it names none.
- A tuesday-dossier.md from the job-underwriter skill → adds verified evidence and a prohibited-claims list built from more than this message.
