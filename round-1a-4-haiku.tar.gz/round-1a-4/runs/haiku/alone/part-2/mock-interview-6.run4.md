Several references are loaded. Per the skill's research tier, company values, loop structure, and strategy need to come from sources rather than memory, so I'm running the default L1 searches now.
Web search was refused by the permission prompt, so no company research ran. I'll build the pack on your own material and label what research would change.
Your prep pack covers all three rounds in one file: `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-6-denied-ac70f090/645d378e-4f93-40f7-8ccd-05327300fe27/scratchpad/larkfield-systems_engineering-manager_interview_pack.md`

I built it on your message and the role description in it, since no posting was supplied. Web search was refused by the permission prompt, so no company research ran. Larkfield's values, interview process and strategy are not in the pack. The values cheat sheet is omitted for that reason, and the VP round's questions rest on the recruiter's "values and leadership philosophy" phrase alone.

The pack has:
- **Shared fit snapshot:** eight rows. Your two real gaps are the manager-of-managers gap and the hardware-adjacent roadmap, both in your own words. Device-management services is a gap your material is silent on.
- **Round 1 (hiring manager, 45 min):** nine questions. Weighted toward Case/Strategist and Skeptic. The highest-return prep is R1-S1, "Which part of this role would you be weakest at on day one?" Rehearse it until the concession is worded before the interview.
- **Round 2 (panel, 60 min):** ten questions. Staff engineers are weighted toward Peer Evaluator and Data-Driven Prober, and the product manager toward Values and Conversational.
- **Round 3 (VP, 30 min):** eight questions, weighted to Values/Behavioral, with Pressure and Case behind it.
- **Prohibited list:** the claims the pack will not coach, such as "I've managed managers," "I led two squads," and "the quarter cut on-call by 60%." Each entry gives the honest version.
- **Reverse questions:** five per round, each with why it lands. Round 2 includes a reciprocity question for the peers.

Your 60% figure is the one quantified claim in your material, so expect probes on how it was counted. The pack gives you answer slots for that rather than a method you would have to defend.

I can run a drill on any question, or save a `tuesday-dossier.md` that records the gaps this prep exposed for later sessions. I can also convert the pack to Word if you want it.

Two questions would shape the next version:
1. Can you paste the full posting, plus any recruiter note on what each round covers or any take-home? The posting would turn the role-summary rows into quoted requirements.
2. Where is the role based, and does it involve travel? Your material is silent on this, and it would change the gate rows.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems

**For:** Yusuf
**Role:** Engineering Manager, Larkfield Systems (industrial IoT, about 600 people). Leads two squads building device-management services; owns delivery, hiring and growth for 11 engineers; partners with hardware and product on roadmap.
**Rounds (loop mode):**
1. Hiring manager: Director of Engineering, 45 min
2. Panel: two staff engineers and a product manager, 60 min
3. VP Engineering, 30 min, described by the recruiter as "values and leadership philosophy"

**Changelog:** first version.
**Basis:** your message, and the role description in it. No posting text was supplied. No company research ran (see Sources).
**Interviewer read:** omitted. No interviewer names were given, so personas fall back to round priors.

---

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** VAL = values and leadership, scored against the stated focus. EXP = your past work, tested for attribution. JD = the role's own requirements. CO = company knowledge (none in this pack, because no company research ran). CASE = a live problem from the role.
- **Guidance is scaffolding, not a script.** Answer slots are instructions for the interview: answer from your own experience, or say plainly that the practice was not yours. Never answer a slot with the practice it names.
- **Rehearse only what you actually did, in your own words.**

---

## Fit snapshot (shared across rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "owns delivery" (role description, your message) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | none | Your sentence, unchanged: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." The 60% carries the defend-the-number slots in R1-P1. |
| F2 | "own ... hiring" (role description, your message) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | transferability | Your material reaches hiring for backend roles, not hiring ownership across 11 engineers. Bridge: "For backend roles I run our hiring loop — about 40 interviews last year." Answer slot: if you set the loop's bar or made the hire-or-no-hire calls, say how; if the loop was set for you, say so. |
| F3 | "growth for 11 engineers" (role description, your message) | none given | none | [grounded] | discovery | Your material says nothing on growing people. Answer slot: if you have developed people's careers as a lead, say what you did; if you have not, say so, and say what you would do first, as a plan. |
| F4 | "lead two squads building device-management services" (role description, your message) | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material shows one team of six for three years, not two squads. Bridge: "For three years I was a team lead of 6." Answer slot: if you have led more than one team at once, say how; if not, say so, and say how you would split your attention across two squads, as a plan. |
| F5 | "building device-management services" (role description, your message) | none given | none | [grounded] | discovery | Your material does not show device-management or fleet work. Answer slot: if you have built or run services that manage devices or fleets of endpoints, say which; if not, say so plainly and say what you would need to learn first. |
| F6 | "partner with ... product on roadmap" (role description, your message) | "I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | Derivation: the quote shows roadmap pressure, not a partnership, so it is a lead and not a claim. Answer slot: how you worked with product on that quarter. If you partnered on the roadmap, say how; if the pressure came from elsewhere, say where. |
| F7 | "partner with ... hardware ... on roadmap" (role description, your message) | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | You stated the absence. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn the constraint, said as a plan and never as a past. |
| F8 | manager of managers (not in the role text; your flag) | "I've never managed managers" — your message | none | [grounded] | capability | You stated the absence. Words: "I've never managed managers." The role text is silent on managers, but your own message names the gap, so treat the probe as likely. Then a plan for the first 90 days, said as a plan. |

---

## Prohibited list (shared)

| Not coached | Basis | Honest form |
|---|---|---|
| "I've managed managers" | Negative you stated (F8) | "I've never managed managers." Plain acknowledgment; no slot. |
| "I've owned a hardware-adjacent roadmap" | Negative you stated (F7) | "I've never owned a hardware-adjacent roadmap." Plain acknowledgment; no slot. |
| "I led two squads" or "I led eleven engineers" | Inflated form of F4 | "3 as a team lead of 6," at its own scope. Limit, as the pack's observation: your material shows one team of six. R1-S2's slot stays inside that. |
| "I owned hiring for the organisation" | Inflated form of F2 | "I run our hiring loop for backend roles." R2-E2's slot asks only about the loop's bar. |
| "I drove the roadmap with product and hardware" | Inflated form of F6 and F7 | "I pushed a reliability quarter through against roadmap pressure." Limit, as the pack's observation: the material does not show a partnership. |
| "The reliability quarter cut on-call by 60%" | Inflated form of F1: a causal claim the quote does not carry | "dropped 60% after I pushed a reliability quarter through." The attribution question is R1-P1's slot. |

Not listed: running device-management services. Your material is silent on it, so it is an answer slot (F5), not a claim to suppress.

---

## Round 1: Hiring manager (Director of Engineering), 45 min

**Relationship and weights.** Hiring manager prior: Case/Strategist and Skeptic. They are buying capability and testing your two gaps. Data-Driven Prober sits at 2 because of the single quantified claim (F1). Nine questions.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (4) | Live problems from the first 90 days: two squads, hardware and product waiting | Top weight. The role's hardware and product partnership is the first thing a hiring manager tests | Clarify, then objective, segmentation, approach, metrics, risks. Name one premise to challenge |
| Skeptic (3) | Quiet probes on the two gaps you named: managers and the hardware roadmap | Mid-high weight. Both gaps are in your own message, so they are predictable | Plain acknowledgment, then the nearest adjacent evidence, then a plan. Hold through two follow-ups |
| Data-Driven Prober (2) | The 60% figure, read off your CV line | Mid weight. One headline number is enough to test attribution | Defend the number in your own words. Say plainly if you do not know how it was counted |

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-C1 | "Walk me through the first 90 days: two squads, a device-management backlog, hardware and product both waiting. What do you need to know first?" | CASE | [generic] | Clarify what is committed and what is a request. Ask who depends on whom. Then objective, segmentation by squad, approach, the two metrics you would watch, and the risks. Name one premise you would challenge before you answer. Speakable in about two minutes. No claim about your past. | The partnership problem the role names is the live test a hiring manager runs first. Tagged generic because it is a pattern for the problem, not this team's backlog. |
| R1-C2 | "Hardware says the release slips two weeks unless your squads absorb the device-side work. What do you do?" | CASE | [grounded] "never owned a hardware-adjacent roadmap" — your message | Clarify what "absorb" would cost and who decides. Structure two or three options and what you would tell product. Say plainly, in your own words, that you have never owned a hardware-adjacent roadmap, then say how you would learn the constraint, as a plan. Do not claim a hardware decision you did not make. | F7 is the gap this problem tests. The acknowledgment is your own sentence; everything after it is a plan. |
| R1-C3 | "Device check-ins from the field fell 20% last month. Diagnose it." | CASE | [generic] | Clarify the metric's definition and window. Segment by device type, region and firmware before looking for a cause. Check whether the instrumentation itself changed. Then say what you would rule out first. | Diagnosis is a standard case format for a device-management team. Generic because the figure is a practice number, not this company's data. |
| R1-C4 | "A strong engineer on one squad asks for a promotion path the company doesn't yet have. What do you do?" | CASE | [generic] | Clarify what the level criteria are and what is blocking the path. Name who calibrates and when. Say what you would do this month and what you would bring to the director. | Growth for eleven engineers is a role requirement (F3), and your material is silent on it. This tests the approach, as a plan. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-S1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers" — your message; [grounded] "3 as a team lead of 6" — your message | Highest-ROI prep in this pack. Open with the plain acknowledgment: "I've never managed managers." Then the nearest thing your material carries: "3 as a team lead of 6," in those words. Then the first-90-days plan, said as a plan. Hold through two follow-ups. Concede that managing leads is the part you have not done. Do not say you would be fine. | F8 is the most predictable objection to you. Deepest rehearsal: three follow-ups, with the concession worded before the interview. |
| R1-S2 | "Your background is one team of six. How would you know when the scope is too big for you?" | JD | [grounded] "3 as a team lead of 6" — your message | Use the quote's scope: a team of six, for three years. Answer slot: if you have split work across more than one team at once, say how and what changed; if you have not, say so plainly and name the signal you would watch for, as a plan. Do not stretch the scope to two squads. | F4: the role leads two squads and your material shows one team of six. The question presupposes only the scope the quote states. |
| R1-S3 | "Why move from a payments company into industrial devices?" | JD | [grounded] "currently at a payments company" — your message | Answer slot: say the reason in your own words. The material gives none for device work, so do not reach for a reason you cannot stand behind. If you have a reason you can name, name it and say what you would want to learn. | The skeptic's why-now probe. Your one sentence about your current company is the only thing the material gives about where you are. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-P1 | "Walk me through how that 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | Defend the number. Say what you counted, over what period, and from where, in your own words. If you do not know how it was counted, say so plainly. Name the assumption you would defend least, if you know one. Answer slot: if you drove the quarter, say which decisions were yours; if someone else ran it, say so. Keep "after", not "because". | F1: the one quantified claim, and the target a prober chooses. Every figure raises these slots. The pack does not supply a method, baseline or attribution model. |
| R1-P2 | "How were the trade-offs on that quarter decided?" | EXP | [grounded] "pushed a reliability quarter through against roadmap pressure" — your message | Say who you had to convince and what they conceded, in your own words. Hold that you pushed the quarter through. Concede specifically where the decision was not yours. Do not say what the quarter gave up unless you can name it. | F6 is a lead, not a partnership. The probe finds out whether the trade-off story is larger than the quote. |

### Reverse questions for Round 1

1. "What would you need to see from me in the first 90 days to call the hire a good one?" Why it lands: asks for the bar in their words, and shows you are planning against it.
2. "Which squad has the harder delivery problem right now, and what makes it hard?" Why it lands: tests the scope split and shows you read it as two problems.
3. "When device and software plans conflict, who decides today?" Why it lands: decision rights are where hardware partnership breaks, and the question gets you the answer without a confession.
4. "What would make the first year feel successful for someone who hasn't managed managers before?" Why it lands: turns the managers gap into a development question, not a defence.
5. "What did the last person in this role do well that you want kept?" Why it lands: shows continuity, and the answer names what they value.

---

## Round 2: Panel (two staff engineers, one product manager), 60 min

**Relationship and weights.** The panel prior blends the top two personas of each member. Staff engineers are peers: Peer Evaluator and Data-Driven Prober. The product manager is cross-functional: Values/Behavioral and Conversational. Roadmap questions for the product manager are case-shaped, so they sit under Values with a roadmap theme. Ten questions.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (3) | Staff engineers ask about seams and disagreement | Peer prior: they price what you add to their load | Propose seam principles rather than a seam you have not seen. Reciprocity. Disagreement with spine and tact |
| Values/Behavioral (3) | The product manager asks behavioural roadmap questions | Cross-functional prior: a scored conversation by someone outside the function | Selection scaffolds. Name the stake and the call you made. Hard truths landed, or say none landed |
| Data-Driven Prober (2) | A staff engineer tests the reliability claim against its assumptions | Mid weight. Staff engineers verify numbers | Name the weakest assumption if you know one; say plainly if you do not |
| Conversational (2) | The product manager's opener | Low weight, but scored, and casual | A 90-second arc drawn only from your own sentences |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-E1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a seam you have not seen: how work is handed across, and who decides when two plans collide. If you have a disagreement with an equal in your own experience, say it in your words. If not, say how you would handle one. | The peer seam probe. The guidance offers principles, not a story, so it claims nothing about you. |
| R2-E2 | "You run hiring loops. How do you decide who on a loop is the one who says no?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" — your message | Story-map: you run the loop, for backend roles, with about forty interviews last year. Answer slot: if you set the bar or made the hire-or-no-hire calls, say how; if the calibration was set by someone else, say so and say how you worked within it. | F2: hiring is a role requirement, and this probe tests whether the loop is yours. Keep the answer in the backend loop's scope. |
| R2-E3 | "What's the hardest technical trade-off a device-management service would force on the team?" | CASE | [generic] | Answer slot: if you have built or run systems that manage devices or other fleets of endpoints, say which and what it taught you. If not, say so plainly, and say what you would want to know first about the fleet, the connectivity and the update path. Do not guess at device constraints. | F5: your material does not show device-management work. The honest form is the slot, not a claim. |

### Values/Behavioral (product manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-V1 | "Tell me about a time you had to push back on a product partner's roadmap." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" — your message | Selection scaffold: pick a time you disagreed with product about what the roadmap should carry. It needs a stake, a call you made, and the working relationship at the end. The nearest thing your material carries is the reliability quarter: say where the pressure came from, in your own words. If there was no such time, say so plainly and describe how you would push back. | The role names product partnership, so the theme has a raising source. The quote does not say who applied the pressure, so the guidance does not either. |
| R2-V2 | "Describe a time a dependency slipped and you had to change the plan." | VAL | [generic] | Open prompt. Pick a dependency that slipped. Say what changed in the plan and who you told first. If nothing comparable comes to mind, say so plainly and say how you would handle a slip with hardware. | The role's hardware dependency is the raising source. The prompt asks for an instance you choose, and the guidance adds no event. |
| R2-V3 | "What would you need from me in the first month to make roadmap calls you can defend?" | JD | [generic] | Name what you would need: decision rights, the priorities behind the roadmap, and the data on what is shipping. Say it as your plan. Make no claim about past roadmap decisions. You can then ask how those decisions get made now. | The product manager asks what you would need. The answer is a plan. |

### Data-Driven Prober (staff engineers)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-D1 | "Which assumption behind that on-call number would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60%" — your message | Name the weakest assumption in your own words, if you know one. If you do not know how the figure was counted, say so plainly. Do not reconstruct a method you cannot repeat under a second question. Answer slot: which part of the quarter was yours. | F1: the staff engineers verify the figure against its assumptions. The answer is yours to name. |
| R2-D2 | "What usually pages your on-call?" | EXP | [grounded] "My team's on-call burden dropped 60%" — your message | If you tracked what paged the team, say what it was. If you did not track it, say so. | The denominator probe: what the load was made of. The question presupposes only that your team had on-call, which the quote states. |

### Conversational (product manager opener)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-C1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | Pre-scripted 90-second arc: nine years of engineering; three as a team lead of six; now at a payments company. Then, in your own words, what drew you to this role. Use only those beats. | Casual openers are scored. The arc is drawn from one sentence, so it cannot grow in the telling. |
| R2-C2 | "What made you want this role?" | JD | [generic] | Answer slot: say the reason in your own words. The material gives none, so do not borrow the job description's phrases as your reasons. Keep to what you can stand behind. | A casual question about the role is scored. The reason sits outside your material, so the guidance supplies none. |

### Reverse questions for Round 2

1. (Peer, reciprocity) "What could a new engineering manager do in their first month that would genuinely help your squads?" Why it lands: you offer, and do not only ask.
2. (Peer) "Where does the seam between your teams and the squads cause the most rework today?" Why it lands: it makes you a collaborator on the seam.
3. (Product manager) "How do product and hardware decide what the squads build next quarter?" Why it lands: tests the process you would be partnering inside.
4. (Product manager) "What is one roadmap call from last quarter you would want handled differently?" Why it lands: candour, and it shows you ask about the hard case.
5. (Staff engineer) "What is a technical decision from the last year that you wish a manager had been part of?" Why it lands: shows where a manager adds value to engineers.

---

## Round 3: VP Engineering, 30 min: values and leadership philosophy

**Relationship and weights.** The recruiter named this round's focus, and that names the values round in a loop source, so it overrides the executive prior's strategy lean. Values/Behavioral is top weight. Pressure tests composure at executive altitude. Case/Strategist is light, because no company strategy is in hand. Eight questions.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (4) | Leadership philosophy and scored stories | Top weight: the recruiter's own description of the round | Ground each belief in one decision. Say where a value stopped being a slogan |
| Pressure (2) | Time-boxed challenges on the gap and the headline figure | Executive prior. Composure, not content | Hold, then concede. Restate the question first |
| Case/Strategist (2) | Judgement at executive altitude | Light weight. Without company research the case is generic | Structure, metrics, and label the case as generic |

**Values cheat sheet: omitted.** This round is detected as values-style, but Larkfield's published values were not in hand and research was refused. The VAL questions below rest on the recruiter's phrase, not on named values. Paste the values page to add the cheat sheet.

### Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-V1 | "What's your leadership philosophy? Give it in a sentence, then tell me where it came from." | VAL | [grounded] "values and leadership philosophy" — your message | Scaffold: state the philosophy in your own words, and ground it in one leadership decision you made, if you have one. If the origin is a decision you watched rather than made, say so. Do not borrow a slogan you cannot back with a decision. | The recruiter named the round this way, so the theme is theirs. The guidance does not claim a philosophy your material does not carry. |
| R3-V2 | "Tell me about a time you protected a team's time from the roadmap." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" — your message; [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through" — your message | Story-map from the quotes: the reliability quarter, pushed through against roadmap pressure, and the 60% after it. Answer slot: if the quarter cost something, say what and who paid; if it cost nothing you can name, say so and do not supply an ending. If a hard truth landed in that work, say which. | The VP's values question, answered with the nearest sentence you have. Where the material shows no hard truth, the guidance does not supply one. |
| R3-V3 | "How do you decide when to hold a standard and when to let a team find its own way?" | VAL | [generic] | Name the standard, the cost of holding it, and the cost of letting go. Give one decision where you chose; if you cannot name one, give the rule you would use and what would make you change it. | A judgement question. The guidance uses a pattern, so it makes no claim about your past. |
| R3-V4 | "Tell me about a hiring decision that didn't go the way you planned." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" — your message | Selection scaffold: pick a hiring decision that did not go as planned, such as a close call or a candidate you would now judge differently. Say what you changed in the loop afterwards, if you changed it. If none comes to mind, say so plainly and describe how you would check a loop's calls. | The role owns hiring, and your loop sentence is the nearest raising line. The question asks for an instance you choose, so the guidance adds none. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-P1 | "Someone who has managed managers would be ahead of you on day one. Why should we hire you?" | JD | [grounded] "I've never managed managers" — your message; [grounded] "3 as a team lead of 6" — your message | Hold, then concede. Pause, restate the question in your own words, and anchor in "3 as a team lead of 6" and what you actually did with that team. Concede plainly: "I've never managed managers." Do not argue the gap away. Hold the position through two follow-ups. The concession is the gap, not the case for you. | The composure test on the same gap as R1-S1. The question's premise, a rival with manager experience, is the gap your own sentence carries. |
| R3-P2 | "That result — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through" — your message | Hold, then concede. Hold that you pushed the quarter through. Concede specifically, in your own words, any part of the 60% you cannot attribute to the quarter, and say what you do not know about how it was counted. Do not fold on the push itself. | Pressure on the headline figure. The held position is the quote's; the concession is attribution you can name. |

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-C1 | "Device-management is three quarters behind plan, and hardware says the delay is theirs. What do you do in your first thirty days?" | CASE | [generic] | Clarify whose plan and whose delay. Set one objective for the thirty days. Segment the delay by squad and dependency. Name the two risks you would raise first. No claim about your past. | Executive altitude on the role's central problem. Generic because the scenario is a pattern, and no delivery history is given to draw on. |
| R3-C2 | "How would you tell in a year whether a device-management service is working?" | CASE | [generic] | Name two leading measures and one lagging one. Say which measure you would distrust first, and why. Say how you would check the measure's counting before you trust it. | Metric judgement at executive altitude. Generic because no company metric is in hand. |

### Reverse questions for Round 3

1. "What would you want the next manager of these squads to change in six months?" Why it lands: shows you plan for their change.
2. "Where does the company's leadership philosophy hold under pressure, and where does it bend?" Why it lands: candour, and it lets the VP answer your values question in their own terms.
3. "What would make you say, a year from now, that you hired the right manager?" Why it lands: asks for the standard in their words.
4. "How does the company decide when a delivery commitment outranks a roadmap item?" Why it lands: tests the judgement the reliability quarter raised, in their words.

---

## Requirement coverage

| Requirement (role description) | Question IDs |
|---|---|
| Own delivery | R1-P1, R1-P2, R3-V2 |
| Own hiring | R2-E2, R3-V4 |
| Growth for 11 engineers | R1-C4, and F3's answer slot |
| Lead two squads building device-management services | R1-C1, R1-S2, R3-C1 |
| Device-management services (domain) | R1-C3, R2-E3, R3-C2 |
| Partner with product on roadmap | R2-V1, R2-V3, R1-P2 |
| Partner with hardware on roadmap | R1-C2, R2-V2, R3-C1 |
| Manager of managers (your gap; not in the role text) | R1-S1, R3-P1 |

No requirement is left uncovered.

---

## Sources

**Provided documents:** your message: your background, the role description, the round structure, and the recruiter's description of Round 3. No posting text, no interviewer names, no recruiter guidance on focus areas or deliverables.

**Research tier: L1, searches 3 of 6, fetches 0 of 2.** Every call was refused by the permission prompt.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Values cheat sheet (section 10) omitted. Round 3's VAL questions rest on the recruiter's phrase alone. Query refused. |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Loop structure. Your own round descriptions already name three sessions, with who runs each, so no archetype fallback was needed. Query refused. |
| 3. `Larkfield Systems industrial IoT device management strategy news` | unavailable | The CO bank. No CO question is grounded in current strategy; device-management CASE questions are generic. Query refused. |
| 4. `{interviewer name} {company}` | n/a | No interviewer name was given, so there was no query to form. |
| 5. representative `{role title}` JD | skipped | The role description in your message fixes the requirement rows. A full posting would upgrade them (upgrade menu). |

No call returned a result, so no target is marked `yes`. No unattributable results were used. Nothing about Larkfield in this pack comes from research.

---

## Upgrade menu

- **Full posting text** → the eight fit rows move from role-summary wording to quoted posting lines. The JD-tagged questions then quote the posting's own words.
- **Recruiter's note on what each round covers, and any take-home or presentation** → adds graded-deliverable sections for any assignment, and sharpens the round weights.
- **Larkfield's published values or principles, pasted** → adds the values cheat sheet, and maps VAL questions to named values instead of the recruiter's phrase.
- **Permission for web search** → reruns targets 1 to 3 (values, interview process, strategy): three calls, at L1. Those rows would move the cheat sheet, the loop detail, and the CO bank.
- **Names of the Director, the two staff engineers, the product manager and the VP** → per-person personas, an interviewer read, and reverse questions tied to each person's public path. Public footprint only.
- **Where the role is based, and whether it involves travel** → sets the gate rows. Your material is silent on both, so none are set yet.
- **Whether any of the 11 engineers are leads** → shows whether manager of managers is part of the role, which changes F8's wording and how likely R1-S1 and R3-P1 are.
- **Hours you have before each round** → adds a prep triage section, ordering the questions by time.
- **Your answers to the answer slots, given outside a drill** → become quoted material in the fit snapshot, and the rows that drew on them regenerate.
- **A `tuesday-dossier.md`, if you have one** → would add verified evidence and a prohibited-claims list from outside this pack, replacing the local list above.
