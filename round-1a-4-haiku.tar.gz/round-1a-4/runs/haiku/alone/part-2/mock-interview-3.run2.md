Your prep pack is saved as /var/tmp/tuesday-measure/1a4/runs/haiku/alone/part-2/rooms/case-3-denied-04deb6bc/stripe_product-operations-manager_interview_pack.md. I had no CV, job description, or details of the round, so the personas are weighted equally and every requirement is generic. Web search was refused in this run, so Stripe's values and interview loop are not in the pack, and I did not fill them in from memory.

Say the word and I'll play the Skeptic on E1, "Which part of this role would you be weakest at on day one?", the most predictable objection and the pack's highest-return prep.

I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting in the final round, and how do they relate to the role: hiring manager, peer, cross-functional partner, or someone else? Include any focus areas or deliverable the recruiter gave you.
2. Could you paste the job description and a short CV or background summary? I can proceed without them, but the pack stays generic until I have them.
3. How many days do you have before the interview?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe: Product Operations Manager, final round. Prep pack

Status: first version. Built with no CV, no job description and no details of the round or its interviewer. Web search was refused in this run, so Stripe's published values and interview loop are not in this pack. Nothing here is filled in from memory.

## How to use this pack

- **Personas** describe how a question arrives (friendly, time-boxed, sceptical, and so on). **Types** describe what is being scored.
- **Type key:** VAL = behavioural / values alignment. EXP = deep-dive on your experience. JD = the role's own requirements. CO = company and strategy knowledge. CASE = a live problem.
- Guidance is scaffolding, not a script. A spoken answer should run 90 to 120 seconds.
- An **answer slot** is an instruction for the interview. Answer it from your own experience, or say plainly that the practice was not yours. It is not a question to answer here.

## Fit snapshot (worksheet variant)

No CV and no JD were provided, so no evidence cell holds a quote and every confidence is `none`. The requirements below are the usual shape of a Product Operations role. They come from the role family, not from a posting, so they are unquoted and labelled `[generic]`. Silence is `discovery`, never `capability`: none of these gaps is a finding about you.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run the operating cadence for planning and reviews across product, engineering and go-to-market (role family) | none given | none | [generic] | discovery | Strong evidence is one recurring review you designed and ran, and what it decided. Selection scaffold: pick the cadence you have had most hands-on with. If you have run none, say so and describe how you would set one up in your first month. |
| F2 | Define, instrument and track outcome measures, and be fluent with data (role family) | none given | none | [generic] | discovery | Strong evidence is a metric you chose, where its data came from, and what you did when it moved. Selection scaffold: name one measure you owned end to end and what it was sensitive to. If you have owned none, say so and name the first measure you would check. |
| F3 | Launch processes, programmes or tooling and drive adoption across teams (role family) | none given | none | [generic] | discovery | Strong evidence is one rollout with an adoption figure you can explain. Selection scaffold: pick one rollout and say who adopted it and what did not stick. If none comes to mind, say so and describe how you would drive adoption. |
| F4 | Brief and influence senior leaders in writing and in person (role family) | none given | none | [generic] | discovery | Strong evidence is one briefing that changed a decision. Selection scaffold: pick a briefing you wrote or gave and say what it asked for and what happened. If none comes to mind, say so. |
| F5 | Build or improve internal tooling and automation for operational work (role family) | none given | none | [generic] | discovery | Strong evidence is one tool you built or specified and what it replaced. Selection scaffold: name the most manual process you have touched and what replaced it. If none, say so. |
| F6 | Make prioritisation calls under ambiguity with incomplete data (role family) | none given | none | [generic] | discovery | Strong evidence is a decision made on partial information, and what you would check afterwards. Selection scaffold: pick a decision you would now make differently. If none, say so and walk through how you would decide one today. |

No row is a hard gate: no requirement was given as a knock-out, so none is surfaced as one.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| None listed | No sentence from you exists yet, so there is nothing to stretch into an inflated claim. | The pack's own observation: your material does not show any of F1 to F6 yet. The answer slots carry the risk until you send your CV. This list fills when you do. |

## Persona table

Weights are flat. The round's relationship is unknown, and no loop source establishes the loop, so the fallback archetype is Generic, which says flat weights rather than assuming a pattern. Each persona gets three questions. Every persona is still rehearsed, so no style meets you for the first time live.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Reads every figure and asks how it was counted | Equal (A1 to A3). Product Operations is metric-heavy, so the probe is likely whatever the round is. | Name the weakest assumption before they do. Say plainly what you do not know about a figure. |
| Pressure / Stress | Interrupts, time-boxes, plays devil's advocate | Equal (B1 to B3). Common in senior rounds. | Pause, restate, hold the core through two follow-ups, then concede the specific point that is wrong. |
| Values / Behavioural | Scenario probes, STAR-shaped stories | Equal (C1 to C3). No published values are in hand, so these themes come from the persona itself, not from Stripe's values. | "We" for context, "I" for what you did. Choose stories where the hard truth actually landed. |
| Case / Strategist | A live problem from the role | Equal (D1 to D3). | Clarify, then objective, segments, approach, metrics, risks. Think aloud. |
| Skeptic | Probes the gaps and asks why now | Equal (E1 to E3). E1 is the most predictable objection, so it gets the deepest rehearsal, with three levels of follow-up. | Calibrated candour over bluffing. Name the weakest area and a concrete ramp. |
| Conversational / Rapport | Casual openers that are still scored | Equal (F1 to F3). | Pre-script a 90-second arc. Treat casual questions on the role's topics as scored. |
| Peer Evaluator | Seam-splitting, credit, what they would need from you | Equal (G1 to G3). Reciprocity framing applies if the interviewer is a peer. | Propose seam principles rather than pretending to know the seam. Say what you would bring to their team. |

## Question banks

Provenance comes before guidance. With no CV or JD, every provenance cell is a label alone, and no row's guidance claims anything about your past. Where a row touches your experience, it is an open prompt with a selection scaffold and an honest branch.

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "How would you count whether a process change actually worked?" | JD | [generic] | Name the first measure you would pick, what it is sensitive to, and the assumption you would defend least. If you have measured a process change before, say how it was counted in your own words. If you have not, say so and describe how you would count it. | A generic metric probe that the role makes likely. No figure is assumed. |
| A2 | "Think of a number from your past work. How was it counted?" | EXP | [generic] | Open prompt: choose one figure you can defend. Cover how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you have no figure you can account for, say so and name the nearest one you can. | An open prompt, so the guidance supplies no figure. It becomes a premised question once your CV is in. |
| A3 | "Which metric would you stop trusting first, and what broke it?" | JD | [generic] | Name one metric you would retire and the assumption that failed. If you have not watched a metric break, say so and name the one you would audit first. | Tests judgement about metrics, which is what the role family asks for. No past claim is presupposed. |

### B. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why should we hire you over an internal candidate?" | JD | [generic] | Pause, restate the question, then answer with the one or two things you can point to. Answer slot: name the closest thing you have done, in your own words. If nothing is close, say so and name how you would close the gap in your first 90 days. Hold through two follow-ups and concede a specific gap, never the whole case. | A classic time-boxed probe. No CV line exists, so the guidance quotes none. |
| B2 | "Think of a result you are proud of. How much of it was actually you?" | EXP | [generic] | Open prompt. Name your part precisely, concede the team's part plainly, and hold your part through two follow-ups. If you have no result to point to, say so, then give the nearest thing you did. | Tests attribution under pressure. |
| B3 | "Your plan for the first quarter is wrong. Defend it in two minutes." | CASE | [generic] | State the plan's core claim. Concede one specific point the moment it is valid. Hold the core through two follow-ups and never fold on the whole plan just to restore harmony. | Hold-then-concede structure. No past claim is involved. |

### C. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Open prompt. Choose one where the hard truth actually landed. Use "we" for context and "I" for what you did. If none comes to mind, say so plainly, then give the nearest one or how you would handle it. | A behavioural theme from the persona. Not mapped to a Stripe value, since none are in hand. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Open prompt. Pick a decision where a user's need and a team target pointed different ways. Say what you chose and what it cost. If none comes to mind, say so and give the nearest one. | Same basis as C1. |
| C3 | "Describe a process you changed that people resisted. What did you do in the first month?" | VAL | [generic] | Open prompt. Pick one change and say who resisted, what you did first, and what stuck. If you have not changed a process against resistance, say so and describe how you would approach it. | Connects to F3's rollout requirement. |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sketch the plan for a new review process across three product teams. What do you need to know first?" | CASE | [generic] | Clarify first: the goal, who decides, and the current cadence. Then objective, segments, approach, metrics and risks. Think aloud and challenge one premise respectfully. | A live problem from the role. Presupposes nothing about your past. |
| D2 | "A checkout-conversion metric dropped 20% in one week. Diagnose it." | CASE | [generic] | Check instrumentation and the data pipeline before the business. Then segment by device, region and release. State the assumption you are testing at each step. | A generic diagnostic. No company data is presupposed. |
| D3 | "What is the first operating decision you would make in your first 30 days, and what would change your mind?" | JD | [generic] | Name one decision, the evidence you would gather first, and the observation that would reverse it. | Tests judgement without a past claim. |

### E. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the weakest area specifically, then a concrete 30-60-90 ramp. Hold it through two follow-ups and do not bluff a competency you lack. If you have done part of that area, say which. If you have not, say so. | The highest-ROI prep in this pack. This objection will come in some form, and a calm, specific answer changes the interview. Deepest rehearsal: three levels. |
| E2 | "Tell me where your background is thinnest for this role, and how you would handle that here." | EXP | [generic] | Open prompt. Name the thinnest area in your own words, then the one thing you would do in the first month to cover it. Do not argue the gap away. | A skeptic's standard opener. No gap is asserted for you. |
| E3 | "Why are you leaving where you are, why here, and why now?" | EXP | [generic] | Give three reasons, each one you can check against your own history. If a reason is weak, drop it for a stronger true one rather than stretching it. | Tests motivation consistency. No reason is supplied. |

### F. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | Pre-script a 90-second arc in three beats: where you started, the turn that mattered, and why this role. The beats come from your own material, which is not here yet. Until then, use the turns you are most sure of. | Casual register, but still scored. |
| F2 | "What are you actually playing with in product ops these days?" | JD | [generic] | Name one tool or practice you have used, in your own words, and what it did. If you have only read about it, say so. | A casual probe on a role-family topic. |
| F3 | "What have you read lately about how product teams make decisions?" | CO | [generic] | Name one source you have read and what you took from it. Do not name reading you did not do. | Casual and scored. No strategy research ran, so this is generic. |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam, such as who decides and how disagreements escalate, rather than claiming to know it. Give one disagreement where you held a position and stayed collegial. If none comes to mind, say so. | Seam-splitting between adjacent teams. |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name one shared outcome and the credit you gave. If you have none, say so and describe how you would handle it. | Partnership fit. |
| G3 | "What would you need from my team in the first month?" | JD | [generic] | Name two specific inputs, such as a data source, a standing meeting or a decision owner. Name what you would bring to their team too. | Reciprocity framing for a peer. |

Session total: 21 questions across seven personas, three each.

### Requirement coverage

| Requirement (role family, not a posting) | Covered by |
|---|---|
| F1 cadence | A1, D1, G1 |
| F2 measures and data | A1, A2, A3, D2 |
| F3 rollouts and adoption | C3, E2 |
| F4 senior communication | B1, C1, E3 |
| F5 tooling and automation | F2 |
| F6 judgement under ambiguity | B3, D3, E1 |

## Reverse questions

No interviewer profile exists, so none of these ties to the interviewer's own path.

| Question | Why it lands |
|---|---|
| "What does a strong first six months look like in this role, and which part is hardest to get right?" | Shows you are planning for the job and not the title, and surfaces the real problem. |
| "Who sets this function's priorities, and how much say does it have over product and go-to-market decisions?" | The authority question shows you understand the role's limits, and tests the altitude of the answer. |
| "Which process here is most overdue for redesign, and what has stopped it so far?" | Friction is the real content of operations work. A candid answer tells you what you would walk into. |
| "How will this role's success be measured after the first year, and who agrees on that measure?" | Reveals whether the metric is shared or contested. |
| "What would make you regret this hire six months from now?" | A direct risk question. The answer tells you what E1 is really about. |

## Sources

- **Provided documents:** the request text. No CV, job description, invite or prior dossier was provided, and none was found in the working directory.
- **Searches sent, all refused, none returned results:**
  - "Stripe company values operating principles": refused
  - "Stripe interview process final round product operations manager": refused
  - "Stripe strategy news 2026": refused
- **Fetches sent:** none.

Research tier: L1 — searches 0 of 6 (3 attempted, all refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet (section 10) not built. Not detected as a values-style round, and no published values are in hand. Calls refused. |
| 2. Stripe interview process, product operations | unavailable | Loop structure. Persona weights are flat because no loop source establishes the loop. Calls refused. |
| 3. Stripe strategy / recent news | unavailable | Would have grounded the CO questions. F3 is generic as a result. Calls refused. |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative Product Operations Manager JD | unavailable | Would have supplied `[inferred]` requirements for the fit snapshot. Host search refused. |

## Upgrade menu

- A job description (paste the text) → F1 to F6 become quoted, `[grounded]` requirements, and the JD-tagged questions gain raising sources.
- Your CV or a short background summary → the evidence column fills with your own sentences, the answer slots become story maps, and the prohibited list fills.
- The round's relationship to you (manager, peer, cross-functional or other), and any focus areas or deliverable the recruiter named → persona weights reweight, the reverse questions are retuned, and any pre-declared deliverable gets its own build section.
- Permission to run web search → the values, loop and strategy targets run. Stripe's published values replace the empty cheat sheet, and the CO questions are grounded in current strategy.
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes. It runs only on your go-ahead, and covers a company strategy brief, the interviewer's public footprint if named, role-family loop reports and recent organisational context.
- Days until the interview → a prioritised prep triage, sized to the time you have.
- The interviewer's name → an interviewer read and a tailored reverse question, drawn from public professional footprint only.
- A `tuesday-dossier.md` → verified evidence and graded gaps in place of the worksheet rows.
