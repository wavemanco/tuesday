Your prep pack is saved as /var/tmp/tuesday-measure/1a4/runs/haiku/alone/part-2/rooms/case-7-denied-e029b40d/saltmarsh_live_operations_producer_interview_pack.md. I built it on a hiring-manager round, one 60-minute session, and no pre-declared exercise. Web search was refused in this session, so there are no company values, loop structure, strategy or interviewer footprint in it. I did not retry the refused searches.

# Live Operations Producer, Saltmarsh Games: interview prep pack

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager, not yet confirmed. Format: one 60-minute session. Built on the job description and background you gave. Web research was unavailable this session, so the company facts, loop and interviewer read are absent (see Sources).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **JD** = stated job requirement. **EXP** = your own experience, checked for attribution. **CASE** = live problem from the role. (No VAL or CO questions: no values round was detected and no company research ran.)
- Guidance is scaffolding, not a script. Say the parts you can back up in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one main title and weekly content drops, not live events across two titles. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you planned live events, or a calendar for a second title, say which and how you decided, in your own words; if you did neither, say so plainly and describe how you would build the second title's calendar. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message); "Never led a team, and never worked on a game with in-app purchases." (your message) | low | [inferred] | discovery | Your material touches QA coordination only. Nothing shows coordinating design, art, engineering or community on an update. The team-leadership negative is yours and must not be widened into coordination experience. Answer slot: describe one content drop and who you had to bring along for it, what each team needed from you, and whether it went smoothly; if none of that was yours to run, say so plainly. |
| F3 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote already reaches this requirement in other terms. Words: "Presented the monthly retention numbers to the studio head." Your material does not show how those numbers were calculated or what you concluded from them. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | transferability | Presenting monthly retention is reporting. It is not owning a post-event review or the KPIs behind it. Words: "Presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs were reported, or ran any review after an event, say how; if you did not, say so plainly. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | No gap. Expect a probe, since this is a CV line with nothing inspected behind it. Words: "Wrote the release checklist our QA team still uses." The quote says you wrote it and QA uses it. It does not say you ran release sign-offs, so do not say you did. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | Four years of production at a puzzle-game studio is what the quote carries. Your material does not establish that the title was a live-service game. Words: "4 years as an associate producer at a puzzle-game studio." Answer slot: if the main title ran on a live model, say how; if you are unsure what counts as live-service here, say so and say what you would check. |
| F7 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote already reaches this requirement. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Expect a probe on cadence and on what the calendar contained. Hold to the quote. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The checklist is a written artifact that others use. Words: "Wrote the release checklist our QA team still uses." The pack has no sample of your writing to show. |
| F9 | In-app purchase monetisation (role-family pattern, not quoted from the JD) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A gap you stated. Words: "I have never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as past experience. This row raises no answer slot. |

## Prohibited claims

Built from the fit snapshot. These claims will not be coached, in any answer, hold or bridge.

| Not coached | Basis | Honest form |
|---|---|---|
| Plans live events across two titles | Inflated form of F1 | The quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Observation, not words for you: the material says one title and content drops, not live events across two. |
| Owns the post-event review and the KPIs | Inflated form of F4 | "Presented the monthly retention numbers to the studio head." Observation: the material shows presenting, not ownership. |
| Led or managed cross-functional teams | Inflated form of F2 | "Wrote the release checklist our QA team still uses." Observation: the material shows no team leadership. |
| Ran release sign-offs | Inflated form of F5 | "Wrote the release checklist our QA team still uses." Observation: the material shows writing the checklist, not running sign-offs. |
| Live-service game experience | Inflated form of F6 | "4 years as an associate producer at a puzzle-game studio." Observation: the material does not say the title was live-service. |
| Experience with in-app purchase monetisation | Stated by you (F9) | Plain acknowledgment: "I have never worked on a game with in-app purchases." No answer slot. |

## Persona weights

| Persona | Weight | How it shows up | Why this weight | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | 5 | Live problems on the calendar, cross-team handoffs and QA gates | Hiring-manager prior. The role runs a roadmap, so the interviewer buys capability | Clarify, then structure, then answer. Name the inputs you would confirm first |
| Skeptic | 5 | Probes two titles, live events and the in-app purchase gap | Hiring-manager prior. Your gaps sit on the JD's headline items | Rehearse the single most predictable objection until it is calm. Concede the gap plainly, then show what you can back up |
| Data-Driven Prober | 4 | Retention numbers, KPIs and how figures were counted | The JD names retention metrics and KPIs, and your CV carries a retention line | Say how each figure was counted, or say you do not know. Name the weakest assumption before they do |
| Pressure / Stress | 2 | Time-boxed challenge on the IAP gap and on credit for the checklist | Low prior for this round. Depth is kept because the gaps are exposed | Pause, restate the question, hold for two follow-ups, then concede only what is true |
| Conversational / Rapport | 2 | Opening biography and a casual question about their titles | Friendly openers are still scored | Use a 90-second arc in your own words. Do not claim knowledge of their titles |

Values / Behavioral: no weight. No values-style round was detected. Interviewer signals: none, since the research target was refused.

## Question banks

**Requirement coverage**

| JD requirement | Covered by | Note |
|---|---|---|
| Plan and run live-events calendar for two titles | A2, B1, F1 | |
| Coordinate design, art, engineering, community | A3, B3, B5 | |
| Own post-event review and KPIs | A5, C3 | |
| Manage release checklist with QA | A4, C4 | |
| 3+ years live-service | B2 | |
| Content calendar experience | B1, E1 | |
| Player-retention metrics | C1, C2 | |
| Clear written communication | none, and why: the loop has no written exercise; F8 is the only evidence and is covered by the checklist sample in the upgrade menu | |
| In-app purchase monetisation (role-family, not in JD) | B4, D1 | |

**A. Case / Strategist (weight 5)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our second title's live-events calendar dipped on retention over the last month. What do you check first?" | CASE | [generic] | Ask whether the dip sits in one event or across the calendar. Segment the players, new against returning. Compare each event to its own baseline. Name the risk in your first guess. Speak it in about 90 seconds | A live problem on the role, not a question about your past, so it carries no claim |
| A2 | "You have six weeks to plan live events for one of our two titles. What do you need to know before you lock the calendar?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" | List the inputs: art lead time, QA window, engineering release, community messaging, and what the event is for. Say which you would confirm first | Raised by the JD's own calendar line. Tests planning, not history. Covers F1's gap by method |
| A3 | "Where does a live event most often go wrong between design, art, engineering and community?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" | Name two handoffs and the checkpoint you would add to each. If you have seen one fail, say it in your own words. Hold to what you saw, not a general lesson | JD2 is the raising source. F2 is the gap, so the method answer carries it |
| A4 | "How do you decide whether a content drop ships on its date or waits for QA?" | JD | [grounded] "manage the release checklist with QA"; [grounded] "Wrote the release checklist our QA team still uses." | Name the hold criteria: severity of open defects, what the checklist covers, and what QA cannot cover in the window. Answer slot: if the checklist you wrote had a hold criterion, say what it was; if it had none, say so plainly | F5 is your strongest fit row. The question tests whether your checklist is a gate or only a list |
| A5 | "Walk me through how you would run the post-event review for a live event that missed its target." | JD | [grounded] "own the post-event review and the KPIs it reports" | Fix the target and the metric before the event. Name the comparison you would use. Name what you would not conclude from one event. Say who gets the write-up. No claim about your past | F4 is the gap. This is method, not history, so the answer does not borrow a review you never ran |

**B. Skeptic (weight 5)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have run one title's calendar, and this role plans events across two. What in your background is actually like that?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Give the quote's scope: one title, weekly content drops, two years. Name what transfers: the cadence and the checks you ran. Answer slot: if you planned live events or a second title's calendar, say which and how you decided; if not, say so plainly and describe how you would build the second. Hold through two follow-ups by returning to the calendar you ran | Highest-ROI prep in this pack. F1 is transferability, and the two-title gap is the likeliest probe. Rehearse the hold until it is boring |
| B2 | "This role asks for three years producing live-service games. Your title is a puzzle game. How do you meet that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Say the four years and the weekly content-drop cadence in the quote's words. If the main title ran on a live model, say how. If unsure what counts as live-service here, say so and name what you would check | F6. Concede the classification plainly if the material does not show it |
| B3 | "You have never led a team. How do you get design, art, engineering and community to move on one date without authority?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Acknowledge: "I have never led a team." Answer slot: if you got a team to move on a date without authority, say how, in your own words; if not, say so plainly and describe the nearest thing your material carries: the release checklist QA still uses | F2 is discovery. The acknowledgment is yours. Do not widen it into a claim about coordination |
| B4 | "What would you need to learn about in-app purchases to plan an event for one of our titles?" | JD | [grounded] "I have never worked on a game with in-app purchases." (your message) | Acknowledge: "I have never worked on a game with in-app purchases." Then the plan: who owns the monetisation numbers, what they have tested, and what you would read first. No claim about the company's revenue | F9 is a stated gap. The answer is an acknowledgment and a learning plan, not a claim |
| B5 | "Tell me about a time a team you depended on pushed back on a date." | JD | [grounded] "coordinate design, art, engineering and community teams on each update" | Open prompt. Pick a time a team pushed back on a date. If you have one, the story is the decision you made, in your own words. If none comes to mind, say so plainly, then the nearest thing your material carries: the release checklist QA still uses and how you handled QA's gates | Raised by JD2. Tests the coordination gap F2 leaves open |

**C. Data-Driven Prober (weight 4)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were calculated." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you calculated them, say how, in your own words. If you presented numbers someone else produced, say so and say what you checked before presenting | F3. You gave no figure, so the slot is the honest branch, not a method to supply |
| C2 | "Which retention metric would you defend least, and why?" | JD | [grounded] "comfortable with player-retention metrics" | Name the metric and the assumption behind it that you would defend least, in your own words. If you cannot name one, say you do not know how that figure was counted | Weakest-assumption move. Your material gives no figure, so the guidance supplies no assumption |
| C3 | "How would you tell whether a live event worked, a week after it ended?" | JD | [generic] | Name the target fixed before the event, the baseline, the comparison group, and one thing you would not conclude from a week of data | JD3's review. The method is general, not drawn from your history |
| C4 | "How do you plan QA's time across a content drop?" | JD | [grounded] "manage the release checklist with QA" | Name the QA window, what the checklist covers, and what you would take out of the window. Answer slot: if you set QA's window before, say how; if someone else set it, say so | F5 and JD4. Asks about planning the window, which A4 does not |

**D. Pressure / Stress (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire someone with no in-app purchase experience over someone who has it?" | JD | [grounded] "I have never worked on a game with in-app purchases." (your message) | Hold, do not fold. Name what you can show now: the calendar you ran and the checklist QA uses. Concede the specific gap: in-app purchases are untested for you. Name how you would close it | F9. Hold-then-concede. Do not claim IAP experience |
| D2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it," and QA still uses it. If others edited it, say so and say what you wrote. Hold through two follow-ups | F5. The honest answer is the quote's scope, held under pressure |

**E. Conversational / Rapport (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the last four years." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; [grounded] "Presented the monthly retention numbers to the studio head." | A 90-second arc in this order: the puzzle studio, the content calendar, the checklist, the retention presentations, and what you want next. Use the quotes' own scope | Casual opener, still scored. The arc is built only from your own sentences |
| E2 | "What have you been playing on mobile lately, and what would you change about how its events run?" | CASE | [generic] | Name one title and one event mechanic you would change, and why, in your own words. Do not claim knowledge of their titles | Light register, but scored as an informal read on the JD's live events |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a post-event review look like here, and who writes it?" | Tests whether the ownership JD3 names is the team's practice |
| R2 | "Which two titles does the calendar cover, and how differently do they run events?" | Shows you have read the scope, and surfaces the actual gap |
| R3 | "When design, art, engineering and community each need a date, who sets the order?" | Surfaces the coordination model behind JD2 |
| R4 | "Which KPIs does leadership see from live events today?" | Ties to F4, and shows you want the reporting line |
| R5 | "What would the first 90 days look like, and what would you need from me first?" | Gives you a route to say what you would do, and shows you plan the ramp |

## Sources

- Provided documents: the job description and background in your message. No links were read.
- Research tier: L1, searches 4 of 6, fetches 0 of 2. Every search was refused by the session's search permission. None were retried.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet. Refused: "Saltmarsh Games values" |
| 2. Saltmarsh Games interview process, live operations producer | unavailable | Loop structure and persona weights. Refused: "Saltmarsh Games interview process live operations producer" |
| 3. Saltmarsh Games strategy / recent news | unavailable | CO bank. Refused: "Saltmarsh Games mobile studio strategy news" |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read, tailored reverse question. Refused: "Tobias Wrenfield Saltmarsh Games Head of Live Operations" |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Saltmarsh's careers or values page, pasted → values cheat sheet and VAL questions
- Tobias Wrenfield's public profile or talks, pasted → interviewer read, tuned persona weights, and a tailored reverse question
- The recruiter's note on the round (panel, or Tobias alone; any exercise) → confirms the relationship and reweights every bank
- Recent Saltmarsh news or a strategy note, pasted → CO questions, which are absent now
- A redacted sample of the release checklist → lets an interviewer see F5 and F8 rather than take them on trust
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several minutes. It needs search permission to run
- tuesday-dossier.md, if you keep one: it would carry this pack's gaps into later rounds

---

Two offers, neither pushed:
- I can play the Skeptic on B1, the two-title question the pack names as highest-ROI prep, and give feedback against its guidance.
- I can save a tuesday-dossier.md recording the gaps this prep exposed, for later rounds.

If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, or is this a panel or an exercise round? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep pack

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager, not yet confirmed. Format: one 60-minute session. Built on the job description and background you gave. Web research was unavailable this session, so the company facts, loop and interviewer read are absent (see Sources).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **JD** = stated job requirement. **EXP** = your own experience, checked for attribution. **CASE** = live problem from the role. (No VAL or CO questions: no values round was detected and no company research ran.)
- Guidance is scaffolding, not a script. Say the parts you can back up in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one main title and weekly content drops, not live events across two titles. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you planned live events, or a calendar for a second title, say which and how you decided, in your own words; if you did neither, say so plainly and describe how you would build the second title's calendar. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message); "Never led a team, and never worked on a game with in-app purchases." (your message) | low | [inferred] | discovery | Your material touches QA coordination only. Nothing shows coordinating design, art, engineering or community on an update. The team-leadership negative is yours and must not be widened into coordination experience. Answer slot: describe one content drop and who you had to bring along for it, what each team needed from you, and whether it went smoothly; if none of that was yours to run, say so plainly. |
| F3 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote already reaches this requirement in other terms. Words: "Presented the monthly retention numbers to the studio head." Your material does not show how those numbers were calculated or what you concluded from them. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | transferability | Presenting monthly retention is reporting. It is not owning a post-event review or the KPIs behind it. Words: "Presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs were reported, or ran any review after an event, say how; if you did not, say so plainly. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | No gap. Expect a probe, since this is a CV line with nothing inspected behind it. Words: "Wrote the release checklist our QA team still uses." The quote says you wrote it and QA uses it. It does not say you ran release sign-offs, so do not say you did. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | Four years of production at a puzzle-game studio is what the quote carries. Your material does not establish that the title was a live-service game. Words: "4 years as an associate producer at a puzzle-game studio." Answer slot: if the main title ran on a live model, say how; if you are unsure what counts as live-service here, say so and say what you would check. |
| F7 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote already reaches this requirement. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Expect a probe on cadence and on what the calendar contained. Hold to the quote. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The checklist is a written artifact that others use. Words: "Wrote the release checklist our QA team still uses." The pack has no sample of your writing to show. |
| F9 | In-app purchase monetisation (role-family pattern, not quoted from the JD) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A gap you stated. Words: "I have never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as past experience. This row raises no answer slot. |

Gap types follow the routing rule in the reference, applied to the quotes above.

## Prohibited claims

Built from the fit snapshot. These claims will not be coached, in any answer, hold or bridge.

| Not coached | Basis | Honest form |
|---|---|---|
| Plans live events across two titles | Inflated form of F1 | The quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Observation, not words for you: the material says one title and content drops, not live events across two. |
| Owns the post-event review and the KPIs | Inflated form of F4 | "Presented the monthly retention numbers to the studio head." Observation: the material shows presenting, not ownership. |
| Led or managed cross-functional teams | Inflated form of F2 | "Wrote the release checklist our QA team still uses." Observation: the material shows no team leadership. |
| Ran release sign-offs | Inflated form of F5 | "Wrote the release checklist our QA team still uses." Observation: the material shows writing the checklist, not running sign-offs. |
| Live-service game experience | Inflated form of F6 | "4 years as an associate producer at a puzzle-game studio." Observation: the material does not say the title was live-service. |
| Experience with in-app purchase monetisation | Stated by you (F9) | Plain acknowledgment: "I have never worked on a game with in-app purchases." No answer slot. |

## Persona weights

| Persona | Weight | How it shows up | Why this weight | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | 5 | Live problems on the calendar, cross-team handoffs and QA gates | Hiring-manager prior. The role runs a roadmap, so the interviewer buys capability | Clarify, then structure, then answer. Name the inputs you would confirm first |
| Skeptic | 5 | Probes two titles, live events and the in-app purchase gap | Hiring-manager prior. Your gaps sit on the JD's headline items | Rehearse the single most predictable objection until it is calm. Concede the gap plainly, then show what you can back up |
| Data-Driven Prober | 4 | Retention numbers, KPIs and how figures were counted | The JD names retention metrics and KPIs, and your CV carries a retention line | Say how each figure was counted, or say you do not know. Name the weakest assumption before they do |
| Pressure / Stress | 2 | Time-boxed challenge on the IAP gap and on credit for the checklist | Low prior for this round. Depth is kept because the gaps are exposed | Pause, restate the question, hold for two follow-ups, then concede only what is true |
| Conversational / Rapport | 2 | Opening biography and a casual question about their titles | Friendly openers are still scored | Use a 90-second arc in your own words. Do not claim knowledge of their titles |

Values / Behavioral: no weight. No values-style round was detected. Interviewer signals: none, since the research target was refused.

## Question banks

**Requirement coverage**

| JD requirement | Covered by | Note |
|---|---|---|
| Plan and run live-events calendar for two titles | A2, B1, F1 | |
| Coordinate design, art, engineering, community | A3, B3, B5 | |
| Own post-event review and KPIs | A5, C3 | |
| Manage release checklist with QA | A4, C4 | |
| 3+ years live-service | B2 | |
| Content calendar experience | B1, E1 | |
| Player-retention metrics | C1, C2 | |
| Clear written communication | none, and why: the loop has no written exercise; F8 is the only evidence and is covered by the checklist sample in the upgrade menu | |
| In-app purchase monetisation (role-family, not in JD) | B4, D1 | |

**A. Case / Strategist (weight 5)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our second title's live-events calendar dipped on retention over the last month. What do you check first?" | CASE | [generic] | Ask whether the dip sits in one event or across the calendar. Segment the players, new against returning. Compare each event to its own baseline. Name the risk in your first guess. Speak it in about 90 seconds | A live problem on the role, not a question about your past, so it carries no claim |
| A2 | "You have six weeks to plan live events for one of our two titles. What do you need to know before you lock the calendar?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" | List the inputs: art lead time, QA window, engineering release, community messaging, and what the event is for. Say which you would confirm first | Raised by the JD's own calendar line. Tests planning, not history. Covers F1's gap by method |
| A3 | "Where does a live event most often go wrong between design, art, engineering and community?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" | Name two handoffs and the checkpoint you would add to each. If you have seen one fail, say it in your own words. Hold to what you saw, not a general lesson | JD2 is the raising source. F2 is the gap, so the method answer carries it |
| A4 | "How do you decide whether a content drop ships on its date or waits for QA?" | JD | [grounded] "manage the release checklist with QA"; [grounded] "Wrote the release checklist our QA team still uses." | Name the hold criteria: severity of open defects, what the checklist covers, and what QA cannot cover in the window. Answer slot: if the checklist you wrote had a hold criterion, say what it was; if it had none, say so plainly | F5 is your strongest fit row. The question tests whether your checklist is a gate or only a list |
| A5 | "Walk me through how you would run the post-event review for a live event that missed its target." | JD | [grounded] "own the post-event review and the KPIs it reports" | Fix the target and the metric before the event. Name the comparison you would use. Name what you would not conclude from one event. Say who gets the write-up. No claim about your past | F4 is the gap. This is method, not history, so the answer does not borrow a review you never ran |

**B. Skeptic (weight 5)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have run one title's calendar, and this role plans events across two. What in your background is actually like that?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Give the quote's scope: one title, weekly content drops, two years. Name what transfers: the cadence and the checks you ran. Answer slot: if you planned live events or a second title's calendar, say which and how you decided; if not, say so plainly and describe how you would build the second. Hold through two follow-ups by returning to the calendar you ran | Highest-ROI prep in this pack. F1 is transferability, and the two-title gap is the likeliest probe. Rehearse the hold until it is boring |
| B2 | "This role asks for three years producing live-service games. Your title is a puzzle game. How do you meet that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Say the four years and the weekly content-drop cadence in the quote's words. If the main title ran on a live model, say how. If unsure what counts as live-service here, say so and name what you would check | F6. Concede the classification plainly if the material does not show it |
| B3 | "You have never led a team. How do you get design, art, engineering and community to move on one date without authority?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Acknowledge: "I have never led a team." Answer slot: if you got a team to move on a date without authority, say how, in your own words; if not, say so plainly and describe the nearest thing your material carries: the release checklist QA still uses | F2 is discovery. The acknowledgment is yours. Do not widen it into a claim about coordination |
| B4 | "What would you need to learn about in-app purchases to plan an event for one of our titles?" | JD | [grounded] "I have never worked on a game with in-app purchases." (your message) | Acknowledge: "I have never worked on a game with in-app purchases." Then the plan: who owns the monetisation numbers, what they have tested, and what you would read first. No claim about the company's revenue | F9 is a stated gap. The answer is an acknowledgment and a learning plan, not a claim |
| B5 | "Tell me about a time a team you depended on pushed back on a date." | JD | [grounded] "coordinate design, art, engineering and community teams on each update" | Open prompt. Pick a time a team pushed back on a date. If you have one, the story is the decision you made, in your own words. If none comes to mind, say so plainly, then the nearest thing your material carries: the release checklist QA still uses and how you handled QA's gates | Raised by JD2. Tests the coordination gap F2 leaves open |

**C. Data-Driven Prober (weight 4)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were calculated." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you calculated them, say how, in your own words. If you presented numbers someone else produced, say so and say what you checked before presenting | F3. You gave no figure, so the slot is the honest branch, not a method to supply |
| C2 | "Which retention metric would you defend least, and why?" | JD | [grounded] "comfortable with player-retention metrics" | Name the metric and the assumption behind it that you would defend least, in your own words. If you cannot name one, say you do not know how that figure was counted | Weakest-assumption move. Your material gives no figure, so the guidance supplies no assumption |
| C3 | "How would you tell whether a live event worked, a week after it ended?" | JD | [generic] | Name the target fixed before the event, the baseline, the comparison group, and one thing you would not conclude from a week of data | JD3's review. The method is general, not drawn from your history |
| C4 | "How do you plan QA's time across a content drop?" | JD | [grounded] "manage the release checklist with QA" | Name the QA window, what the checklist covers, and what you would take out of the window. Answer slot: if you set QA's window before, say how; if someone else set it, say so | F5 and JD4. Asks about planning the window, which A4 does not |

**D. Pressure / Stress (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire someone with no in-app purchase experience over someone who has it?" | JD | [grounded] "I have never worked on a game with in-app purchases." (your message) | Hold, do not fold. Name what you can show now: the calendar you ran and the checklist QA uses. Concede the specific gap: in-app purchases are untested for you. Name how you would close it | F9. Hold-then-concede. Do not claim IAP experience |
| D2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it," and QA still uses it. If others edited it, say so and say what you wrote. Hold through two follow-ups | F5. The honest answer is the quote's scope, held under pressure |

**E. Conversational / Rapport (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the last four years." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; [grounded] "Presented the monthly retention numbers to the studio head." | A 90-second arc in this order: the puzzle studio, the content calendar, the checklist, the retention presentations, and what you want next. Use the quotes' own scope | Casual opener, still scored. The arc is built only from your own sentences |
| E2 | "What have you been playing on mobile lately, and what would you change about how its events run?" | CASE | [generic] | Name one title and one event mechanic you would change, and why, in your own words. Do not claim knowledge of their titles | Light register, but scored as an informal read on the JD's live events |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a post-event review look like here, and who writes it?" | Tests whether the ownership JD3 names is the team's practice |
| R2 | "Which two titles does the calendar cover, and how differently do they run events?" | Shows you have read the scope, and surfaces the actual gap |
| R3 | "When design, art, engineering and community each need a date, who sets the order?" | Surfaces the coordination model behind JD2 |
| R4 | "Which KPIs does leadership see from live events today?" | Ties to F4, and shows you want the reporting line |
| R5 | "What would the first 90 days look like, and what would you need from me first?" | Gives you a route to say what you would do, and shows you plan the ramp |

## Sources

- Provided documents: the job description and background in your message. No links were read.
- Research tier: L1, searches 4 of 6, fetches 0 of 2. Every search was refused by the session's search permission. None were retried.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet. Refused: "Saltmarsh Games values" |
| 2. Saltmarsh Games interview process, live operations producer | unavailable | Loop structure and persona weights. Refused: "Saltmarsh Games interview process live operations producer" |
| 3. Saltmarsh Games strategy / recent news | unavailable | CO bank. Refused: "Saltmarsh Games mobile studio strategy news" |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read, tailored reverse question. Refused: "Tobias Wrenfield Saltmarsh Games Head of Live Operations" |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Saltmarsh's careers or values page, pasted → values cheat sheet and VAL questions
- Tobias Wrenfield's public profile or talks, pasted → interviewer read, tuned persona weights, and a tailored reverse question
- The recruiter's note on the round (panel, or Tobias alone; any exercise) → confirms the relationship and reweights every bank
- Recent Saltmarsh news or a strategy note, pasted → CO questions, which are absent now
- A redacted sample of the release checklist → lets an interviewer see F5 and F8 rather than take them on trust
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several minutes. It needs search permission to run
- tuesday-dossier.md, if you keep one: it would carry this pack's gaps into later rounds
