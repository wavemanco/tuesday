I have what I need to build the pack. Before writing it, I'll load the reference files the skill requires and check the web tools for the company and interviewer research.
I've read the required references. Now the L1 research: company values, interview process, recent strategy, and the interviewer's public footprint.
I have the research results and the reference rules. I'll write the pack to the working directory now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/haiku/alone/part-2/rooms/case-7-canned-3e08a331/saltmarsh_live-operations-producer_interview_pack.md`. I built it for the hiring-manager round, since the careers page says the Outage Hour is run by the hiring manager and I've taken that to be Tobias.

The highest-ROI prep is C1: "You have never led a team." Start with a plain "I haven't led a team," then give a plan for coordinating four teams, not a past you don't have. The Outage Hour is a live-incident tabletop followed by a values conversation, so the case bank (A1 to A5) gets the most time.

Say the word and I'll play the Skeptic on C1 with follow-ups. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Saltmarsh Games, Live Operations Producer: interview prep pack

**Role:** Live Operations Producer · **Company:** Saltmarsh Games (mobile, about 350 people) · **Interviewer:** Tobias Wrenfield, Head of Live Operations, treated as the hiring manager · **Format:** the Outage Hour, one 60-minute interview (see Sources)

## How to use

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script. Speak each answer in your own words and stop at what you actually did.

Type key: **VAL** behavioral and values · **EXP** your experience, probed · **JD** the job's own requirements · **CO** company and strategy · **CASE** a live problem from the role.

Answer slots are instructions for the interview, not questions. Each one gives both an honest branch and a branch for when the practice was not yours.

## Reading the interviewer

Public footprint only. Source: the GDC 2026 talk listing (search snippet, not fetched).

- **Career pattern:** QA lead at a console studio, then Head of Live Operations at Saltmarsh.
- **Self-described thesis:** "Patch Notes Are a Promise." The talk argues a live team is judged by how often its patch notes describe what actually shipped.
- **Implications:**
  1. The values conversation will likely test announcements. "Ship the Patch Not the Promise" is his own argument, so expect B3 and A2 to land on it.
  2. His QA background means the release checklist and go/no-go questions (A3, E2) will be technical. Say the checklist in QA's terms.
  3. Mirror opportunity: the checklist (F4, F8) is the one QA-facing artifact in your material.
- **Shared jump:** none offered. No quoted row carries a QA-lead step for you, so no jump is claimed.

## Prep triage

Prep time is not stated, so no schedule is given. Start with C1, the highest-ROI rehearsal in this pack, then A1 and B1. Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your message and marked as such. Confidence, provenance and gap type each hold one token.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material shows a content-drop calendar on one title, not a live-events calendar across two. Keep the words at their scope: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned live events, or any calendar across more than one title, say which and how; if not, say what the content-drop calendar covered and stop there. |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | The quote reaches the line in its own terms. Expect a probe on what the calendar held and how far ahead it was set. Lead with the quote's terms. |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | The material does not show how you worked with any of those four teams on an update. Answer slot: name which of the four you worked with on a content drop, what each had to deliver, and what you did to get the update through. If you did not work with one of them, say so plainly. |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Rewording only the quote: "I wrote the release checklist our QA team still uses." The JD's word "manage" is not yours and does not go in your sentence. Expect a probe on how QA came to use it and what has changed since. |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | low | [inferred] | discovery | The years are there. Whether any of them were live-service is not in the material. Answer slot: say whether any of the four years was on a title with live updates after launch, and what those updates were. If none was, say so plainly and point to the nearest live work your material carries (F2). |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | Your quote reaches the requirement in other terms. Reworded only: "I presented the monthly retention numbers to the studio head." No figure is in your material, so none is offered. |
| F7 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | transferability | Derivation: reporting numbers is adjacent to owning the KPIs and the review, and the quote does not show who set the KPIs or ran a review. Bridge stays at the quote: "I presented the monthly retention numbers to the studio head." Answer slot: say which KPIs you chose to report and why, and which were set for you. If you ran a post-event review, say what it covered; if not, say so plainly. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The checklist is the one written artifact in your material. Reworded only: "I wrote the release checklist our QA team still uses." Nothing more is claimed. No writing sample is in the material; the upgrade menu asks for one. |
| F9 | Team leadership: [generic], not a quoted JD line (the JD asks for coordination) | "Never led a team" — your message | none | [grounded] | capability | You stated the absence. Plain acknowledgment: "I haven't led a team." Then the plan for coordinating four teams, given as a plan and never as a past. See C1. |
| F10 | Monetization in the role's terms: [generic], not a quoted JD line (the JD names KPIs, not revenue) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | You stated the absence. Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the plan for learning the monetization side, given as a plan. See C2. |

Gate rows: none. The JD states no location, visa, schedule or credential bar, and your message names none.

## Prohibited claims

These will not be coached, in any answer, hold, bridge or drill feedback.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is this pack's observation: your material says one title and content drops, not live events across two. |
| Owned the post-event review and the KPIs it reports | Inflated form of F7 | F7's quote at its own scope: "Presented the monthly retention numbers to the studio head." |
| Managed the release checklist with QA | Inflated form of F4 | "Wrote the release checklist our QA team still uses." |
| Live-service producing for four years | Inflated form of F5 | "4 years as an associate producer at a puzzle-game studio." |
| Led a team | Negative you stated, F9 | Plain acknowledgment: "I haven't led a team." No slot. |
| Monetization experience from in-app purchases | Negative you stated, F10 | Plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot. |

## Persona table

Relationship prior: hiring manager. The careers page describes the Outage Hour as an interview with the hiring manager, which is the loop source that establishes this session. Weights: 5 / 4 / 3 / 3 / 2 / 2, for 19 questions.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (weight 5) | The live-incident tabletop: an outage during a live event | High. The careers page names the tabletop as half the session. | Clarify, name decision owners, then options. Announce only what is built. (A1–A5) |
| Values/Behavioral (weight 4) | The values conversation, against three published values | High. The careers page names it, and the values are published by name. | Map each value to a story or give the honest branch. (B1–B4) |
| Skeptic (weight 3) | The two stated gaps: team leadership and in-app purchases | High. Both gaps are in your message, and the JD asks for coordination across four teams. | Plain acknowledgment first, plan second. Never claim a past you did not state. (C1–C3) |
| Data-Driven Prober (weight 3) | Retention and KPI ownership | Medium-high. The JD names KPIs; your message names reporting only. | Say what was counted and who set it. Say plainly when you do not know. (D1–D3) |
| Pressure (weight 2) | Challenge on the gaps | Medium-low. The page does not say the format is time-boxed, but a 60-minute slot is short. | Hold the quoted position through two follow-ups; concede the gaps exactly. (E1–E2) |
| Conversational (weight 2) | An opener and the content-calendar question | Medium. Casual openers are scored too. | A 90-second arc built only from your stated facts. (F1–F2) |

## Question banks

Provenance carries each candidate sentence the guidance rests on. Rationale refers to your history only by fit-snapshot row ID.

### Persona A, Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A patch shipped an hour ago and a share of players can no longer finish the event's first stage. Walk me through your first ten minutes." | CASE | [grounded] "a live-incident tabletop on a simulated outage during a live event, then a values conversation." (careers page) | Clarify first: which title, how many players are affected, whether the event timer is still running. Then name the decision owners and the options: hotfix, rollback, pause the event. Give the player-facing message last, once you know what is built. Speakable in about two minutes. | The tabletop is the core of the session, named on the careers page. The scenario is a live problem from the role and makes no claim about your past. |
| A2 | "Community says the event reward never arrived. Engineering says the fix is two days out. What do you tell players, and when?" | CASE | [grounded] "we announce what is built, not what is hoped" (values page) | Announce only what is built. Give a date only when it is in a build. Name who reviews the message before it goes out. Do not speculate about cause. | The values page sets the standard the answer is judged against. The scenario is generic and claims nothing about you. |
| A3 | "On release day, QA marks one checklist item as a no-go and the event is scheduled for tonight. Who decides, and what do you record?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." (F4) | Structure it: what the item protects, who can waive it, what the event's timing costs if it slips, and what goes in the record. Name the decision owner before the options. Answer slot: if you have made or shared a go/no-go call before, say what you decided and who signed off; if you have not, say so plainly and describe how you would decide. | The JD's release-checklist line is covered by F4 only. This question tests the decision that sits on top of a checklist you wrote, not the checklist itself. |
| A4 | "Saltmarsh is putting two titles on one shared events calendar under a single live-ops group. What changes for how you would plan a quarter, and what would you protect on each title?" | CO | [grounded] "Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027" (company news) | Name the gains of a shared calendar: one set of dependencies, shared capacity. Name the costs: fewer per-title decisions. Name one thing you would protect per title, and why. Do not claim experience of a season-pass model. | Larkspur is the company's current move and may match the JD's "two of our mobile titles". The match is a reading, not a fact, so the answer speaks to the strategy and not to a title list. |
| A5 | "You have two titles and one hour before a live event goes out. Name the first two numbers you would check and why those two." | CASE | [generic] | Pick one player-facing metric and one operational metric. Name the assumption each one rests on. Say what result would make you hold the event. | A metric-and-diagnosis case from the JD's KPI line. It is a pattern for live operations, not a fact about this team. |

### Persona B, Values/Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "when the calendar and the players disagree, the players win" (values page); "I ran the weekly content-drop calendar for our main title for the last two years." (F2) | Open prompt. Pick a real instance where a date or slot clashed with what players needed. Tell it in order: the clash, what you chose, the cost. If no such time comes to mind, say so plainly, then give the nearest case your material carries (F2) or how you would handle it. | Players Before Plans is the value this prompt tests. The prompt is raised by the published value, not by an assumption that you were there. The guidance cannot supply the ending. |
| B2 | "Tell me about a document other people used long after you wrote it. What changed because of it?" | VAL | [grounded] "every release leaves the codebase and the checklist better than it found them" (values page); "Wrote the release checklist our QA team still uses." (F4) | Story-map: the checklist you wrote and the QA team still uses. The beat the quote does not state is whether each release left it better. Answer slot: if you revised the checklist after release, say what changed and why; if QA changed it, or it has not changed, say so plainly and say what you would revise first. | Leave the Build Greener is the value this story tests. The checklist is the one place your material shows a document others depend on. |
| B3 | "Tell me about a time you had to tell a player or a partner that something you had promised was late." | VAL | [grounded] "we announce what is built, not what is hoped" (values page) | Open prompt. Pick a real instance where a date slipped. Give the sequence: when you knew, what you said, who heard it first, what they did. If there was no such moment, say so plainly, then say how you would announce a delay in the first hour. | Ship the Patch Not the Promise is the value this prompt tests. No row shows a delayed promise, so the guidance cannot supply one. |
| B4 | "Write the two-sentence player notice you would post for a delayed reward. Say it aloud before you write it." | JD | [grounded] "clear written communication" (JD) | Start with what players lose and what is being fixed. Give a date only if it is in the build. Read the notice aloud and check for any sentence that promises what has not shipped. | The JD requires clear written communication. No row shows a player-facing notice, so the task tests the writing live and claims nothing about your past. |

### Persona C, Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have never led a team. How would you coordinate design, art, engineering and community on each update without direct authority over any of them?" | JD | [grounded] "Never led a team" (F9); "coordinate design, art, engineering and community teams on each update" (JD) | Start with the plain acknowledgment: "I haven't led a team." Then give the plan as a plan, not as a past: the first update you would run, one owner per decision, how each team's blocker reaches you. Hold the plan through two follow-ups. When pressed on authority, say what you would ask each lead for, and concede that you have not done it. Never claim the coordination as experience. | This is the highest-ROI prep in the pack. The objection is in the JD's own line and in your stated negative, and a hiring manager will test it. Deepest rehearsal: the first follow-up asks what you did; the second asks what you would do when a lead says no. |
| C2 | "Your background has no in-app purchases. What do you know about live revenue, and how would you learn the rest?" | JD | [grounded] "never worked on a game with in-app purchases" (F10) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then name what you know about retention, and link it to revenue only where your material shows the link. Give the learning plan: which dashboards you would read first, which person you would ask. Do not claim revenue knowledge. | The gap you stated is the one a Head of Live Operations is likely to test where revenue meets retention. The acknowledgment comes first, the plan second. |
| C3 | "Four years at a puzzle-game studio. Which of those titles had live updates after launch, and what did they look like?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (F5); "I ran the weekly content-drop calendar for our main title for the last two years." (F2) | Answer slot: if you worked on a title with live updates after launch, say which and what the updates were, in your own words. If the title was mostly launch-and-done, say so plainly and point to the weekly content-drop calendar, the nearest live work your material carries. | The JD asks for three years of live-service work. Your years are on a puzzle-game studio, and the live part is what the interviewer will check. |

### Persona D, Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented the monthly retention numbers to the studio head. Walk me through how one of them was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (F6) | Answer slot: if you know how the count was built, say what it counted in your own words. If you did not build the count, say so, and name the assumption you would defend least. Your material gives no figure, so do not supply one. | Retention reporting is the JD's named metric. The probe tests whether you can say what sits behind a number you presented to a senior audience. F6 is the evidence. |
| D2 | "The role owns the post-event review and the KPIs it reports. Which KPIs have you chosen to report yourself, and which were set for you?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." (F7); "own the post-event review and the KPIs it reports" (JD) | Answer slot: if you chose any KPI you reported, name it and say why you chose it. If the KPIs were set for you, say so plainly, and say which one you would propose first for a live event. Do not describe a post-event review you did not run. | The JD's ownership line is the hardest KPI requirement. F7 shows reporting, not ownership, so the honest answer is a split one. |
| D3 | "After a live event, what goes in the post-event review, and which number decides whether you run the event again?" | CASE | [generic] | Structure it: what was planned against what shipped, what players did, what the team would change, and the one number that decides. Name the assumption behind that number before the interviewer does. | The JD line this answers is "own the post-event review". The guidance is a pattern, not a claim about you. |

### Persona E, Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds. Why hire you over someone who has led a team on a monetized title?" | JD | [grounded] "Never led a team" (F9); "never worked on a game with in-app purchases" (F10); "Presented the monthly retention numbers to the studio head." (F6) | Hold: say what you did, using your quotes: four years as an associate producer, the weekly content-drop calendar for two years, the checklist, the retention presentations. Hold through two follow-ups without pleading. Concede the two gaps in your own words: you have not led a team, and you have not worked on a game with in-app purchases. Do not claim the other candidate's experience as something you will match. | Pressure tests whether you can hold a position your quotes carry and concede the two gaps exactly. |
| E2 | "That checklist. How much of it was actually yours?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (F4) | Hold: say what you wrote and that QA uses it. Concede what changed after you wrote it: QA's later edits are not yours. Do not say you own the release process. | Pressure on attribution. The checklist is the quote the interviewer is most likely to test, given the QA background in the reading above. |

### Persona F, Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey to here." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." (F5); "I ran the weekly content-drop calendar for our main title for the last two years." (F2); "Wrote the release checklist our QA team still uses." (F4); "Presented the monthly retention numbers to the studio head." (F6) | A 90-second arc in order: four years at a puzzle-game studio, the weekly content-drop calendar for two years, the checklist QA still uses, the monthly retention numbers you presented. Stop there and leave the gaps to the questions that ask about them. | Casual openers are scored. The arc uses only your stated facts, in order. |
| F2 | "Tell me about the hardest part of running the weekly content-drop calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (F2) | Pick one real difficulty: a slip, a cadence clash, a team that missed a deadline. Tell it in order: what happened, what you did, what it cost. Do not add a team or a number you did not give. If none stands out, say so plainly and name the cadence itself. | This is the JD's content-calendar line (F2) in a casual register. A conversational slot scores the same as a formal one. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A4, C3 |
| Coordinate design, art, engineering and community teams on each update | C1, A2 |
| Own the post-event review and the KPIs it reports | D2, D3 |
| Manage the release checklist with QA | A3, E2 |
| 3+ years producing live-service games or apps | C3 |
| Experience running a content calendar | F2 |
| Comfortable with player-retention metrics | D1 |
| Clear written communication | B4 |

## Values cheat sheet

Round type: the careers page documents a values conversation inside the Outage Hour, so a values-style round is detected. The three values are from the official values page, fetched once.

| Value | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | Scaffold. No row carries a player-facing call. Pick a time the calendar and the players disagreed, and say what you chose. If none comes to mind, say so plainly, then give the nearest case from F2 or how you would handle it. |
| Ship the Patch Not the Promise | We announce what is built, not what is hoped. | Scaffold. No row carries a delayed promise. Pick a time you gave a date before it was certain. If none comes to mind, say so plainly, then say how you would announce a delay in the first hour. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | F4: "Wrote the release checklist our QA team still uses." (your message). The story is the checklist. Whether each release left it better is an answer slot: if you revised it after release, say what changed and why; if QA changed it, or it has not changed, say so plainly and say what you would revise first. |

## Reverse questions

Each one has a reason it lands.

1. **"With Project Larkspur putting Tidepool Tactics and Lantern Row on one shared events calendar from February 2027, which decisions stay with the title teams and which move to the live-ops group?"** Lands because it shows you read the September 2026 news and want the scope before you are hired.
2. **"Your talk argues a live team is judged by how often its patch notes describe what actually shipped. What does that look like in your team's last three releases?"** Lands because it ties to his own published argument and turns the interview into a peer conversation.
3. **"You came to live operations from QA. What did that change about how you plan a live event?"** Lands because it is his own path, asked as a question about his work and not a probe.
4. **"When a release item is a no-go on the day, who can waive it, and where is the waiver recorded?"** Lands because it tests the checklist process this role would own.
5. **"How do player-facing notices from community get signed off before an event goes out?"** Lands because it tests the coordination line of the JD with the community team.
6. **"What would a strong first ninety days look like in this role, and which title or decision would you want the person to own first?"** Lands because it asks what success means here, and it gives you a plan to test against C1.

## Sources

**Provided documents:** your message (background and the gaps you named); the JD text.

**Searches and fetches, in order:**

1. "Saltmarsh Games values": returned saltmarshgames.com/values. Fetched.
2. "Saltmarsh Games interview process live operations producer": returned saltmarshgames.com/careers/interviewing. Fetched.
3. "Saltmarsh Games strategy news mobile games": returned saltmarshgames.com/news/project-larkspur. Search snippet only, not fetched.
4. "Tobias Wrenfield Saltmarsh Games": returned talks.gdconf.example/2026/patch-notes-are-a-promise. Search snippet only, not fetched.

Only what the snippets state is used from items 3 and 4.

**Research tier:** L1, searches 4 of 6, fetches 2 of 2. User links read: 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | yes | Values cheat sheet: three values by official name |
| 2. Saltmarsh interview process | yes | Loop: a recruiter call, then one 60-minute Outage Hour with the hiring manager (tabletop, then values). Sets session mode and detects a values round. |
| 3. Strategy and recent news | yes | Project Larkspur (September 2026). Moved A4 and reverse question 1. |
| 4. Interviewer name and company | yes | GDC 2026 talk listing. Moved the interviewer read and reverse question 2. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Persona weighting: reasoning

The careers page gives the session's shape, so no archetype fallback is used. One session, with the hiring manager, consisting of a tabletop and a values conversation. The tabletop weights Case/Strategist highest. The values conversation keeps Values/Behavioral second. Skeptic and Prober sit at 3 because your two stated gaps and the KPI line are where the JD is most likely to press.

## Upgrade menu

- **Which two titles the role covers** → tells whether Project Larkspur's shared calendar is this role's calendar, which sharpens A4 and reverse question 1.
- **A sample of the release checklist, or any player-facing text you wrote** → moves F4 and F8 from presentation to an inspectable artifact, and gives B4 a real comparison.
- **Any live-event experience, even a small one** → answer slots F3 and F5 can be answered from a fact, not a branch.
- **A deeper research pass (L2)**: a Saltmarsh strategy brief, the text of Tobias's talks, role-family loop reports, recent org changes. Up to 6 more searches and 2 more fetches, several more minutes. Want it?
- **Confirmation from the recruiter** of whether Larkspur changes this role's scope → turns A4 and the Larkspur reverse question from strategy to role-specific.
- **A `tuesday-dossier.md`** would carry the gaps this prep exposed (team leadership, monetization) into later sessions.
