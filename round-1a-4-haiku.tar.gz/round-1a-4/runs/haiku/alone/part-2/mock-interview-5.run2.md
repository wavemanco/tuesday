Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-5-denied-4a5a1c83/94ead519-e51b-4b9b-ae4f-441e6b2306bc/scratchpad/kelverton_rail_senior_partnerships_manager_interview_pack.md`.

Web search was refused by a permission prompt, so the pack has no company values, interview-process, strategy or interviewer research. It rests on your message and the recruiter's email as you quoted it. Section 10 lists each refused search.

The pack puts the 15-minute POV first. Build it from one thesis, with its concession stated early, and close on what it means for the operator's planner. Next come Ross's commercial questions (Bank B), where the £4M figure and the lack of a quota are the likely pressure points. Your four-hour split is in section 2.

Offers, neither pushed:
- I can play Deepa or Ross for a drill, starting with B2 (the £4M question), which the pack names as the highest-return prep.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.

Two questions:
1. Could you paste the key points of the market report: its shortlist and the headline numbers? The panel has read it too, so the POV has to differ from it, and I can't do that without its contents.
2. Would you like me to retry the research if you grant search permission? It would cover Kelverton's values, the interview process, and the public footprints of Deepa and Ross.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton_rail_senior_partnerships_manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, panel of two, 60 minutes
**Panel:** Deepa (VP Partnerships, your future manager); Ross (Commercial Director)
**Format:** first 15 minutes a spoken point of view on operator partnerships over the next 18 months (no slides); remaining time Q&A, with Ross pushing on commercials
**Built on:** your message, the recruiter's email as you quoted it, and no JD (none supplied). No interviewer profiles were available. Research did not run (see Sources).

---

## 1. How to use this pack and type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: rehearse the shape, then say it in your own words.

| Tag | Name | What is scored |
|---|---|---|
| VAL | Values / behavioural | Whether past behaviour shows a published value |
| EXP | Experience deep-dive | Whether your stated claims survive scrutiny |
| JD | Role / requirement | Whether you can do the listed job, including its gaps |
| CO | Company knowledge | Whether you think at the company's level (limited here, see Sources) |
| CASE | Live problem | Structure and reasoning on a problem from the role |

---

## 2. Prep triage (about 4 hours)

In priority order:

1. **Build the 15-minute POV (about 75 min).** Section 5. Pick one thesis, write the operator-side consequence in three sentences, and say it aloud twice, timed. This is the only part of the interview you must get right.
2. **Commercial pushback for Ross (about 60 min).** Bank B. Rehearse B1 and B2 until the hold-then-concede shape is automatic. These are the questions most likely to go badly.
3. **Defend the £4M figure (about 30 min).** Question A3 and B2. Write down how the influenced revenue was counted, the assumption you would defend least, and which part was yours. Stop if you cannot answer these from memory.
4. **Operator and rail gap (about 30 min).** Questions A2, A4 and A5. Practise the plain acknowledgment and your learning plan.
5. **Reverse questions and close (about 15 min).** Section 7.

Everything else is insurance.

---

## 3. Fit snapshot

Requirements come from the recruiter's email, quoted. No JD was supplied, so there is no `[grounded]` JD row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships" (recruiter email) | "running the ISV channel" (your message) | medium | [grounded] | transferability | Your material says you ran the ISV channel at a payments company. It does not show operator partnerships. Words: "I ran the ISV channel at a payments company." Answer slot: if any part of the operator relationship was yours to shape, say which and how; if none was, say so and describe what carried over. |
| F2 | "what it means for the operators themselves" (recruiter email) | "so I know the operator world from the other side" (your message) | medium | [grounded] | presentation | Your sentence reaches the operator side in other terms. Words: "I know the operator world from the other side." Keep the planning side of that: your transport work was on bus and light rail network planning, and nothing in your material says you bought or ran the operator's scheduling. |
| F3 | "Ross will push on commercials" (recruiter email) | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | You have stated the absence. Words: "I've never carried a direct quota." Then what you did carry: influenced revenue. Never describe a quota you did not hold. |
| F4 | "sell scheduling software to train operating companies" (recruiter email) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | You have stated the absence. Words: "I've never sold into rail specifically." Then how you would learn it, as a plan. |
| F5 | "rail-tech, ~600 staff" (recruiter email) | No quote given | none | [grounded] | discovery | Your material is silent on rail-tech product and buyers. Answer slot: if you have followed rail-tech buyers in any role, name what you know; if not, say so and name the first three things you would read. |
| F6 | Commercial figure, senior partnerships role (recruiter email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | presentation | The figure reaches the commercial requirement in other terms. Words: "I took it from six partners to forty." Hold the £4M as "influenced", not "drove". |

Note on F3: the material says you never held a quota. That is a plain negative you stated, so it is yours to say. Do not present influenced revenue as quota attainment.

---

## 4. Prohibited claims

Built here from the fit snapshot. These are the claims a candidate reaches for under pressure. No answer, hold, bridge or rationale in this pack asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Stated negative, F4 | "I've never sold into rail specifically." No slot. |
| Carried a quota or hit one | Stated negative, F3 | "I've never carried a direct quota." No slot. |
| Owned the ISV channel strategy | Inflated form of F1 | "I ran the ISV channel." The limit is this pack's observation: your material says you ran it, not that you set its commercial terms. Slots stay inside the running of it. |
| Knows operator scheduling economics | Inflated form of F2 | "I know the operator world from the other side", at its planning scope. The limit is this pack's observation: your material shows the planning side. |
| Drove £4M of revenue | Inflated form of F6 | "Roughly £4M of influenced revenue." The word "drove" is not used. |

---

## 5. Graded deliverable: the 15-minute POV

Recruiter named this as the first 15 minutes. No slides. The close they asked for: **what it means for the operators themselves**.

**Grounded facts to build on**
- F2, quoted: "I know the operator world from the other side." Use it as the reason the operator view comes first. Do not add operator experience.
- F1, quoted: "I ran the ISV channel at a payments company." Use it only for the mechanics of partner growth, not for operator relationships.

**Three defensible theses, each with its concession**

| Thesis | Operator consequence | Concession |
|---|---|---|
| 1. Operators buy disruption avoided, not software. Partnerships should be built around the cost of a disrupted timetable. | A planner's Monday morning changes when a disruption is predicted and handled earlier. | I do not yet know their cost base. I would test this with two operators before building anything. |
| 2. Partnerships should be co-designed with planners, not sold to a buyer. | The operator keeps control of the planning rules and gets a say in the roadmap. | This is slower, and it may cost early deal volume. |
| 3. Distribution through planning consultancies, not direct sales alone. | Operators get an independent party to test the software's fit before committing. | The consultancies have their own incentives, and I would need to see how they are paid. |

**Consensus answer and differentiation.** The likely consensus is more integrations, a partner marketplace, and a larger direct sales team. Bring one consensus item to show you know it, then depart from it with a reason: do not build a marketplace until the planning workflow is proven with an operator. This is the anti-pick, and it is the place where saying no is part of the job.

**Structure (about 12 minutes spoken, then take questions)**
1. The operator's problem in one sentence, in their terms.
2. Your one thesis, with the concession stated early.
3. What it means for the operator's planner, specifically.
4. What you would test first, in 90 days.
5. Close on the operator's benefit: what is different for them, and how they would know.

---

## 6. Question banks

Each question carries its provenance (the quoted sentence the guidance rests on). Guidance is speakable in about 90 to 120 seconds.

### Bank A: Deepa (Case/Strategist + Skeptic), weight 5 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What would you need to know about an operator before proposing a partnership?" | CASE | [generic] | Clarify before you structure: who decides on the planning side, what they measure, what a bad disruption costs them, and what they would not give up. Ask one question back before you answer. This asks nothing about your past. | Likely live problem from the operator focus of the POV. Generic because it is a pattern for the problem, not a fact about this employer. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" | The plain acknowledgment: "I've never sold into rail specifically." Then how you would learn it, as a plan, not as a past. Keep to two named sources of learning. | F4 is the largest gap and this is its most likely form. Scored for honest self-assessment. |
| A3 | "Walk me through how you took the ISV channel from six partners to forty." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Story-mapped on F6: the count, the scale, the influenced revenue, in those terms. Answer slot: how you counted the influence, the assumption behind the £4M you would defend least, and which part was yours, in your own words. If you did not set the partner terms, say so. | F6 is the strongest evidence in the material and the likeliest place to be probed. EXP because it tests what you actually did. |
| A4 | "Operators are not payments merchants. What tells me you understand them?" | JD | [grounded] "so I know the operator world from the other side" | Story-mapped on F2: your transport work was on bus and light rail network planning. Say that, then say what you did not do on the operator's buying side. | F2 is the bridge to the operator focus. The question presses the planning-versus-buying gap, so do not bridge it past the quote. |
| A5 | "Why would an operator trust a partnership run by someone who has never sold into rail?" | JD | [grounded] "Never sold into rail specifically" | Hold through two follow-ups: operator trust comes from what the software does for their planners, and you can show that with a pilot. Concede the rail gap specifically: you have no rail sales record, and the pilot is how you would earn trust without one. Never fold on the core claim. | F4 is the objection that will come back in Ross's round too. Hold-then-concede. |

### Bank B: Ross (Pressure + Data-Driven Prober, commercial), weight 5 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a quota. Why should I believe you'd hit one here?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | The plain acknowledgment: "I've never carried a direct quota." Then what you did carry: influenced revenue, and the numbers attached to it. Do not claim a quota history. Hold the point that influence is a measurable contribution, then concede that you have not been measured against a target in this form. | F3 is where Ross will press hardest. Pressure bank: hold, then concede specifically. |
| B2 | "Roughly £4M of influenced revenue. How much of that was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Defend-the-number: how the influence was counted, the assumption you would defend least, and which part was yours, each in your own words. Answer slot: if you set any of the attribution, say so; if the attribution was the company's, say so plainly. Never supply a method you cannot repeat. | Ross is a commercial prober; the figure will be taken apart. This is the highest-ROI prep in the pack and the most predictable objection. |
| B3 | "An operator says the tool costs more than the disruption it prevents. How do you respond?" | CASE | [generic] | Structure it: ask what disruption costs them today, in their terms; test the claim with a measure they already track; propose a pilot tied to that measure; say what you would not promise. | Commercial live problem from Ross's push on commercials. The question presupposes nothing about your past. |
| B4 | "How would you price a partnership where the operator pays, but the value sits in the company's revenue?" | CASE | [generic] | Clarify who pays for what and what each side's value is. Name two structures, say what each gives up, and state which you would test first. | Pricing angle is Ross's natural ground; generic because it is a structure, not a claim. |
| B5 | "Revenue share, referral or resale: which model would you choose for operator partners, and what would you give up?" | CASE | [generic] | Pick one, state its cost to you, and name the condition under which you would change it. Do not pretend a model has no downside. | Tests judgment on the commercial model the POV implies. |
| B6 | "An operator asks for a discount that costs us margin. What do you do?" | JD | [generic] | Say what the discount buys them, what it costs you, and whether it can be traded for something (term, volume, a pilot). Name the level at which you would say no and why. | Ross will test whether you hold a commercial line. Generic: no past claim is made. |

### Bank C: Rapport opener, weight 2 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | JD | [grounded] "5 years in transport consulting" and "last 4 at a payments company" | A 90-second arc in your own words: transport network planning, then the payments company and the ISV channel, then why operator partnerships. Do not add a role or an event. | Casual openers are scored. The arc should lead the panel to F1 and F2 without any claim you have not stated. |
| C2 | "What does this mean for the operators themselves?" | JD | [grounded] "so I know the operator world from the other side" | Return to the POV's close in one sentence: the operator's planner, what changes for them, how they would know. Do not extend the claim about your operator experience. | Recruiter asked for this to land. Repeat the POV close; do not improvise a new one. |

---

## 7. Reverse questions

Each one has a reason it lands.

1. **To Deepa:** "Which operator relationship would you most want the new partnerships lead to change in the first six months?" Why it lands: it shows you are thinking about operators by name, and it asks her priority.
2. **To Deepa:** "What did the last person in this role get right, and what did they get wrong?" Why it lands: it tells you where the role has been tested, and it shows you expect to learn from the answer.
3. **To Ross:** "How are operator commercial terms set today: per contract, per seat, or per scheduled train?" Why it lands: it shows you want to understand the commercial model before you propose a change, which is the question Ross is most likely to value.
4. **To Ross:** "Which operator account is most at risk right now, and what is the commercial reason?" Why it lands: it asks for the specific commercial problem, and it invites him to talk about what he is measured on.
5. **To either:** "What would a good first 90 days look like for this role?" Why it lands: it turns the close into a planning conversation and gives you a checkable measure for your ramp plan.

Note: no interviewer profile was available, so no reverse question ties to their career path. The upgrade menu says what a profile would add.

---

## 8. Persona weights

| Panel member | Dominant personas | Reasoning |
|---|---|---|
| Deepa, future manager | Case/Strategist (weight 5), Skeptic (weight 4) | A VP buying capability and derisking a gap. Live problems on the operator roadmap, and the F4 gap. |
| Ross, Commercial Director | Pressure (weight 5), Data-Driven Prober (weight 4) | He is named in the recruiter's email as the commercial push. Pressure on F3, probing on F6. |

Rapport openers carry weight 2 (Bank C). The reasoning is from the recruiter's own words and the relationship priors, not from interviewer research.

---

## 9. Requirement coverage

| Stated requirement | Question IDs |
|---|---|
| Operator partnerships, next 18 months (recruiter) | POV (section 5), A1, C2 |
| What it means for the operators (recruiter) | POV close, A4, C2 |
| Rail and operator selling (F4) | A2, A5 |
| Commercial pushback (recruiter) | B1 to B6 |
| Influenced revenue and attribution (F6) | A3, B2 |
| Partner growth mechanics (F1) | A3, C1 |

---

## 10. Sources

**Provided documents:** your message (background, figures, gaps); the recruiter's email as quoted in your message; the internal market report, which you have read but which is not in this session.

**Research tier:** L1, but the search calls were refused by permission (see below).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have moved the values cheat sheet, which was not built. Search was refused. |
| 2. Kelverton Rail interview process | unavailable | Would have moved the loop structure. Search was refused. |
| 3. Kelverton Rail strategy / recent news | unavailable | Would have moved the CO questions. The market report is not in this session, so the strategy grounding is missing. |
| 4. Deepa and Ross public footprint | unavailable | Would have moved the interviewer read and a reverse question tied to their careers. Search was refused. |
| 5. Representative JD for the role | unavailable | Would have fixed JD-tagged rows; the recruiter's words stand in for now. Search was refused. |

Queries sent, all refused by the host's search permission:
- "Kelverton Rail scheduling software train operating companies": refused
- "Kelverton Rail company values": refused
- "UK rail train operating companies software partnerships scheduling 2026": refused

No values cheat sheet was built, because the values were not in hand.

---

## 11. Upgrade menu

- The market report's key points (the shortlist, headline numbers, and the three to four items they name) → a differentiated POV thesis and a consensus-versus-anti-pick check in section 5. The report is equally available to the panel, so it matters.
- The JD text → the JD rows become `[grounded]`, and JD-tagged questions cover every requirement.
- Permission to retry the searches → company values, interview process, strategy, and a representative JD, each of which can upgrade the rows above.
- Public footprint of Deepa and Ross (names are enough) → an interviewer read, persona weights tuned to each person, and a reverse question tied to their career path.
- The recruiter's prep email, if one exists → coverage of any deliverable beyond the POV.
