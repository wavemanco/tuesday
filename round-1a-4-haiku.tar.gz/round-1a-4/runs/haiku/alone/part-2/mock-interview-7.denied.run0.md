Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-7-denied-b5b56313/5640a994-2119-43c7-9170-a081fc95a7a4/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`.

I built it for a hiring-manager round, since your note didn't say who you're meeting. The web searches were refused, so it has nothing on Saltmarsh's values, interview process or strategy, or on Tobias. The values section and the run-of-show are missing for that reason.

Say the word and I'll play the Skeptic on B1, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.
One thing beyond the pack's spec: a 60-minute run-of-show with timed blocks for the question banks. It fits the length of this round. Say so and I'll build it.

Is Tobias your future manager, or a peer on the team? The answer reweights every bank.

Was the puzzle title you worked on live-service, meaning it shipped ongoing content after launch? That decides whether your 3+ years requirement is met on paper.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep for Femi

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations (relationship not yet confirmed; a hiring-manager round is assumed). Format: 60 minutes, Friday.
Research: none completed. The four searches were refused, so nothing here about the company or the interviewer is sourced beyond your message. See Sources.

## How to use this pack

Personas are how a question arrives: a probe, a challenge, a casual opener. Types are what the question scores.

- **CASE**: a live problem from the role, judged on structure.
- **EXP**: what you actually did, probed for attribution.
- **JD**: the listed job's requirements.
- **CO** and **VAL** do not appear here: company knowledge and values need the research that was refused.

The guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material shows one main title's weekly calendar, for two years. It does not show two titles or live events. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the second title and the live events make a probe likely. If you ran either, say which and how, in your own words. If not, say so and say what you would take from the first title. |
| F2 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | low | [grounded] | hard_gate | Your material does not establish that the puzzle title was live-service. The years are stated, the model is not. This gate is asked in the message that delivers this pack, and nothing is said about it here until it is answered. |
| F3 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | high | [grounded] | none | No gap. The quote reaches the requirement directly. Expect a probe on how the calendar was run. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Bridge: "I presented the monthly retention numbers to the studio head." It adds no figure and no method. A probe on how they were counted is C1's answer slot. |
| F5 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | low | [grounded] | discovery | The quote touches KPIs. Presenting is not owning, and no post-event review appears. Answer slot: if you owned a post-event review or the KPIs it reported, say which and how. If you presented numbers others built, say so plainly. |
| F6 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you wrote the checklist, and QA still uses it. Bridge: "I wrote the release checklist our QA team still uses." It adds no account of managing the checklist. |
| F7 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating these teams on an update. Answer slot: if you coordinated more than one team on a content update, name the teams and your part. If none of that was yours, say so plainly and describe the work you did do. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [grounded] | discovery | The quote touches writing without showing whether it reaches the requirement. Answer slot: name a written thing others acted on without you in the room, and what it said. |

Pack observation, as analysis and not as words for you: your material shows a two-year weekly calendar for one main title, a release checklist QA still uses, and retention numbers presented upward. It does not show post-event ownership, cross-team coordination, a second title, or a live-service model.

## Prohibited claims

Not coached in any answer, hold or slot in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the calendar for two titles | Inflated form of F1 | F1's quote at its own scope. Your material says one main title. B1's slot stays inside that scope. |
| Owned the post-event review and its KPIs | Inflated form of F5 | "Presented the monthly retention numbers to the studio head." B5's slot asks only what you owned. |
| Managed the release checklist as the process owner | Inflated form of F6 | "Wrote the release checklist our QA team still uses." |
| Ran a live-service title | Inflated form of F2, not yet established | Nothing until the gate is answered. B4 asks it. |
| Led a team | Negative you stated | The plain acknowledgment: "Never led a team." |
| Built or worked on in-app purchase or monetization systems | Negative you stated | The plain acknowledgment: "never worked on a game with in-app purchases." |

## Persona table

This is a hiring-manager round by assumption. The archetype fallback is generic, so the weights are flat within the top two personas, and no loop source establishes the rounds.

| Persona | How it shows up | Likelihood, and why | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems on the calendar and on a single update | High. A hiring manager buys capability, and the JD is their roadmap. | Clarify, then structure, then metrics and risks. Think aloud. |
| Skeptic | Probes the scope gaps: one title against two, no leadership, no monetization | High. Three gaps are visible from the JD alone. | Rehearse B1 until it is plain. Acknowledge only the negatives you stated. |
| Data-Driven Prober | Asks how the retention numbers were counted | Medium-high. Retention metrics are a stated requirement, and F4 has no figure behind it. | Say what you know. Name the assumption you would defend least. Say plainly when you do not know. |
| Pressure | Time-boxed challenges to your role | Low-medium. A 60-minute slot allows room for depth, but the round is unconfirmed. | Pause, restate the question, hold through two follow-ups, then concede the specific point. |
| Conversational | A walk-through opener, a casual question about the role | Medium. Openers are common, and casual questions are still scored. | A 90-second arc built from your quoted sentences. |

## Question banks

Depth follows weight: Case 5, Skeptic 5, Prober 4, Pressure 2, Conversational 2. Total 18.

### A. Case/Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Plan the next six weeks of content for one of the two titles. What do you need to know first?" | CASE | [generic] | Clarify first: which title, its current retention, team capacity, dependencies. Then objective, cadence, the teams each update needs, the metrics, the risks. | A live problem from the JD's calendar line. The label is generic because it is a pattern, not a fact about this employer. |
| A2 | "Walk me through one content update end to end, from idea to live." | CASE | [generic] | Structure the steps: scope, design, art, engineering, community, the QA gate, the live date, the post-event review. Name the handoffs. Claim nothing about your past. | The JD names those teams and the QA checklist. |
| A3 | "Your update lands the same week as an engineering bug fix. How do you decide what goes first?" | CASE | [generic] | Clarify severity and player impact, the calendar's commitments, and the QA gate. Name who decides, and say what you would tell the other team. | A live trade-off of the kind the calendar role makes. |
| A4 | "Retention dropped 20% after last week's event. Diagnose it." | CASE | [generic] | Clarify the cohort and what changed. Segment by cohort, device, and exposure to the event. Say what you would check first, and ask for the baseline before you conclude. | A metric stem. The 20% is an example, not a fact. |
| A5 | "Forty minutes before a release, QA flags a crash on one device tier. What happens?" | CASE | [generic] | Triage: severity, how much of the player base the device tier is, whether to hold, who signs off, what the checklist says. State the decision and its owner. | The JD's release checklist with QA. |

### B. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role runs the calendar for two titles. Your experience is one main title. What would you do on the second?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; JD: "Plan and run the live-events calendar for two of our mobile titles" | **Highest-ROI prep in this pack.** Hold to your sentence: you ran the calendar for your main title for two years. Answer slot: if you ran a calendar for another title, say which and for how long. If you did not, say so plainly, then say how you would learn the second title and what you would bring from the first. Hold through two follow-ups by returning to the main title. Concede the gap specifically, never by claiming the second title. | F1 is where the two-title requirement presses hardest, and this objection will arrive in some form. |
| B2 | "You've never led a team. What makes you ready for this one?" | JD | [grounded] "Never led a team" | Acknowledge plainly: "Never led a team." Then give what you did coordinate, using only your quoted sentences. Do not describe coordinating people as leading them. Answer slot: if you coordinated people on a piece of work, name it and your part. If not, say so. | F7 is the coordination requirement, and this is where a stated negative meets it. |
| B3 | "Have you worked on a game with in-app purchases? How would you plan around monetization?" | JD | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment: "Never worked on a game with in-app purchases." Then say how you would learn the monetization side, as a plan and never as a past. Do not describe your puzzle title's economy, since your material says nothing about it. | The stated negative. The plan is future tense. |
| B4 | "Was your puzzle title live-service? Did it ship ongoing content after launch?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | Answer slot: if the title shipped ongoing content after launch, say what you ran in your own words. If it did not, say so, and point to the content-drop calendar you ran: "I ran the weekly content-drop calendar for our main title for the last two years." Do not use the phrase live-service unless it is accurate. | F2 is a gate, and this is its interview form. |
| B5 | "Post-event reviews and the KPIs they report: did you own those, or present them?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Hold to the quote: you presented the monthly retention numbers to the studio head. Answer slot: if you owned a review that produced a KPI, say which and how. If you presented numbers someone else built, say so plainly. | F5 is the post-event ownership requirement, the one with the least behind it. |

### C. Data-Driven Prober (weight: 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you know: the report and the cohort window. Answer slot: if you built the calculation, give the method in your own words. If someone else built it, say so and say what you checked. | F4 is the metrics requirement. No figure is quoted, so the defend-the-number slot applies. |
| C2 | "Which assumption behind that retention number would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Name the weakest assumption in your own words before they do. If you cannot name one, say you do not know how it was counted and what you would check first. | The weakest-assumption move, applied to a figure you have not quoted. |
| C3 | "How would you define retention for a live event?" | JD | [generic] | Name the cohort definition, the baseline, the window, the event exposure against a comparison group, and what would count as a result. | The JD asks for retention metrics. The guidance is general method, not a claim about your past. |
| C4 | "A content drop won on daily actives but lost on retention. Which do you trust?" | CASE | [generic] | Name the trade-off. Say which view the cohort data would settle, and which metric is the guardrail. Decide, then say what would change your mind. | A metric trade-off in the role's own terms. |

### D. Pressure (weight: 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run a live title for years?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | Pause and restate. Hold what the quote carries: four years, and the calendar you ran for two. Concede the gap plainly: "Never led a team." Do not guess at their experience. | A time-boxed challenge. Holding and conceding are both the skill. |
| D2 | "That calendar: how much of the result was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold to your sentence: you ran it. Answer slot: say what the team decided and what you decided. If the cadence was set by others, say so plainly. Hold through two follow-ups, then concede the specific point. | F3 is the strongest line you have, and this probe tests whether you claim more of it than you ran. |

### E. Conversational (weight: 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | A 90-second arc with three beats, each one of your quoted sentences: the four years, the weekly calendar you ran, the release checklist QA still uses. Stop there. | A casual opener is still scored. Every beat is one of your own sentences. |
| E2 | "What do you think a good live event looks like from the player's side?" | JD | [generic] | Answer from the player's side, with one example from a game you have played. Connect it to the calendar only after the example. | Casual in register, scored for content judgment. Claims nothing about your past. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, B1 |
| Coordinate design, art, engineering and community teams on each update | A2, B2 |
| Own the post-event review and the KPIs it reports | B5, C1 |
| Manage the release checklist with QA | A5, E1 |
| 3+ years producing live-service games or apps | B4, D1 |
| Experience running a content calendar | D2, E1 |
| Comfortable with player-retention metrics | C1, C2, C3, C4 |
| Clear written communication | none, and why: a spoken round cannot score a written sample. Its only evidence is F8's quote. |

## Reverse questions

No interviewer profile was available, so none of these ties to Tobias's own career path.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first quarter on the second title look like?" | Turns the two-title gap into a shared plan rather than a test. |
| R2 | "How do post-event reviews feed the next calendar today, and who acts on their findings?" | Tests whether the KPI ownership is a real loop. Their answer tells you whether F5 is a gap for this team. |
| R3 | "Who can hold a release, and where does QA's checklist sit against the calendar?" | Shows you understand release authority, which the JD's QA line puts in this role. |
| R4 | "Which parts of an update does this role decide alone, and which need design or engineering sign-off?" | Scopes the authority the role carries, a question an owner asks. |
| R5 | "Which KPI decides whether a live event counts as a success here?" | Shows you think in outcomes, and leads into the retention questions they are likely to ask. |
| R6 | "What would make you say six months from now that this was the right hire?" | Asks for their scoring sheet directly. |

## Sources

Provided documents: the job description and your background, both in your message. No other document was provided.

Research tier: L0. The L1 searches were attempted and refused by permission. Searches 0 of 6 completed, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Values cheat sheet, not built. No values round is detected. Query refused. |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Loop structure. Without it the persona weights rest on the hiring-manager prior. Query refused. |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have fed CO questions, which are absent. Query refused. |
| 4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations` | unavailable | Interviewer read and a reverse question on his path. Query refused. |
| 5. Representative JD | skipped | Your JD was supplied. |

## Upgrade menu

- Permission to search, or pasted text from Saltmarsh's values page, a recent news item, and any interview-process details your recruiter gives → values cheat sheet, strategy questions, the real loop, and sharper persona weights.
- A bio or public profile text for Tobias Wrenfield that you paste → an interviewer read, persona weights for him, and a reverse question on his career path.
- Your answer to the live-service question in the message below → F2 and B4 get their real answer.
- Describing any post-event review or KPI ownership, in your own words → F5 and B5 get quoted material.
- Describing any coordination across design, art, engineering or community teams → F7 gets quoted material.
- Describing any second-title or live-event work → F1 and B1 get quoted material.
