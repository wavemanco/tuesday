Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-8-canned-16c26c23/8d040037-f850-45e1-8f95-562ace90909d/scratchpad/ashgrove_member-experience-lead_interview_pack.md. I built it as three rounds in loop mode, from your recruiter's email, with no searches, since the values, process and strategy brief you sent already cover what research would have checked.

The most useful prep is B1 in the Round 2 bank. It's the objection that puts your two stated gaps together: no contact-centre experience and no presenting above regional level. The pack gives you a hold-then-concede structure for it, with the held position built only from your own sentences.

Say the word and I'll run a drill on B1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview prep pack

**Rounds:** three on 3 December 2026 (loop mode, built from the recruiter's email)
1. Recruiter screen, 30 min
2. Head of Member Services (your future manager), 45 min, mostly behavioural
3. Panel of two branch managers, 60 min, including a 20-minute complaint-escalation case; the panel scores against the four values
**First version.** No earlier pack.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **Type key:** VAL = values and behaviour against Ashgrove's published values. EXP = your own past work, and whether it survives a probe. JD = the listed job and its requirements. CO = company and strategy knowledge. CASE = a live problem from the role.
- **Guidance is scaffolding, not a script.** Say what happened, in your words. Never add to it.
- **Answer slots** are instructions for the interview. Each has an honest branch: if the thing was yours, say how; if it was not, or did not happen, say so plainly.
- Sections left out, because the material does not support them: prep triage (no prep time given), graded deliverables (none declared), interviewer read (no names yet), delivery coaching (no assessment given).

## Fit snapshot

Requirements are quoted from the job description you sent. Evidence is quoted from your message. Where your material is silent, the row says so and does not fill the gap.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material shows one branch's log, not the process end to end. Words: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" makes a probe on what you controlled after a complaint was logged likely. If you decided outcomes or followed cases to closure, say which steps and how you decided. If not, say so and stay with the log. |
| F2 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | You stated the absence, so the words come from it: "Never worked in a contact centre." Then how you would learn the contact-centre side, said as a plan and never as a past. Nothing added to make the gap smaller. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Your material reaches monthly complaint reporting in other words. Words: "I built the monthly complaints spreadsheet our regional manager uses." No figure added. Resolution times are row F4. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | Your material does not show whether the sheet timed resolutions. Answer slot: if it recorded how long complaints took to close, say which measure it used. If it did not, say so plainly and say what you would add first. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | Your material does not name the tool. Answer slot: say which tool the sheet was in and which functions you used, in your own words. If it was lists and totals only, say so. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message); "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | Words: "trained new tellers on our escalation script." Limit: tellers, not supervisors. Your material does not show you coaching supervisors. Answer slot: if you ever coached a colleague through a specific escalation, say what the case was and what you changed. If you did not, say so and say how you would coach a supervisor first. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show digital or self-service work. Answer slot: if you have worked on a member-facing online or app journey, say what you did. If you have not, say so and say what you would look at first. |
| F8 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | No gap on years. Words: "6 years in retail banking, the last 3 as a branch supervisor." Expect a probe on the customer-operations part, since your material says branch. |
| F9 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says formal complaints, not regulated ones. Words: "I handled the branch's formal complaints log." Answer slot: the JD raises regulated complaints, so expect a probe on the rules the log followed. If you worked to set timescales or referral rules, say which and how you applied them. If the log ran to branch practice only, say so plainly. |
| F10 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | You stated the absence above regional level, so the words come from it: "I've never presented to anyone above regional level." Then how you would build that skill, as a plan. Nothing added to close the gap. |

**Pack observation, not words for you:** your material does not show contact-centre work, digital or self-service work, presenting above regional level, regulated timescales, or a named spreadsheet tool.

## Prohibited claims

Claims this pack will not coach. Each entry names its basis and gives the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned the complaints process end to end" | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The pack's observation: your material says one branch's log. |
| "I've worked in a contact centre" | Negative you stated (F2) | "Never worked in a contact centre." |
| "I've handled regulated complaints" | Inflated form of F9 | "I handled the branch's formal complaints log." The pack's observation: the material says formal, not regulated. |
| "I report resolution times every month" | Inflated form of F4 | The spreadsheet quote at its own scope. Resolution times come only through F4's slot. |
| "I coach supervisors on escalations" | Inflated form of F6 | "trained new tellers on our escalation script." |
| "I'm an Excel specialist" | Inflated form of F5 | "I built the monthly complaints spreadsheet our regional manager uses." |
| "I've presented to senior leaders" | Negative you stated (F10) | "I've never presented to anyone above regional level." |

Not listed: F7 (digital work). Your material is silent there, so it is an answer slot, not a claim to avoid.

## Grounding brief

From the strategy brief you sent (July 2026, about four months old, inside the six-month freshness line).

- **Digital:** 40% of member service moves to digital channels by 2028. The main pressure named is app-only banks.
- **Network:** eight branches consolidate into five hubs over 2027.
- **Product:** a small-business lending product launches in Q1 2027.

The brief has no stale framings to flag. Use its vocabulary as written: digital channels, hubs, app-only banks.

## Values cheat sheet

A values-style round is documented by the recruiter's email (the panel scores against the four values). Values are your copy from ashgrovecu.org/about/values, from this morning.

| Value | Working meaning | Mapped story, or scaffold with its honest branch |
|---|---|---|
| Members First, Always: "we decide from the member's side of the counter" | Decide from the member's side | Mapped to F1: "I handled the branch's formal complaints log." Scaffold: pick a complaint where what the member needed decided the outcome, not what closed the file fastest. If the log never showed you the member's side, say so, then give the nearest case it does carry. |
| Plain Words: "if a member needs it explained twice, we wrote it wrong" | Explain once, clearly | Mapped to F6: "trained new tellers on our escalation script." Scaffold: if you checked tellers could explain the script in their own words, say how. If you did not check, say so and say what you would check first. |
| Neighbours, Not Numbers: "every branch is part of its town" | Keep the town in view | Mapped to F3: "I built the monthly complaints spreadsheet our regional manager uses." Scaffold: pick a time a count pointed at a place or group of members you had to think about differently. If the sheet only ever held totals, say so and say how you would keep the town in view. |
| Own the Fix: "whoever finds the problem keeps hold of it until it is solved" | Keep hold until solved | Mapped to F1: "I handled the branch's formal complaints log." Scaffold: pick a complaint you kept hold of until it was solved. If the log did not let you follow cases to the end, say so and describe the nearest case you did follow. |

## Persona weights, with reasoning

Loop mode. The recruiter screen, the manager round and the panel each get their own weights, from the relationship priors and the round's stated focus.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Asks about the gaps: contact centre, presenting upward, regulated timescales | **Top weight in round 2.** Your manager is the person most likely to test the two stated gaps (F2, F10). Light in round 1 and touched in round 3. | Name the gap first, hold what your material does carry, concede specifically, then give the plan. |
| Values / Behavioural | Scored stories mapped to the four values | **Top weight in round 3**, because the panel scores against the values. Round 2 is "mostly behavioural", so this is weighted third there. | Map a story to a value where a quote carries one. Where none does, use the selection scaffold and say so when none comes to mind. |
| Case / Strategist | The escalation case and live problems from the role and strategy | Round 3's 20-minute case, and two live problems in round 2. | Clarify before you structure. Name the first decision. Say what you would check first. |
| Data-driven Prober | Attribution and definitions on your monthly report | Round 3, two questions. Round 2, one. | Say what the sheet did and did not count. Name the weakest assumption before they do. |
| Conversational | Background walk-through, motivation, first six months | Round 1 only, because the recruiter's register is friendly but scored. | Give a ninety-second arc from your own sentences. Do not add to it. |
| Peer Evaluator | Seams between branches and the contact centre, credit-sharing | Round 3, two questions, from the two branch managers. | Reciprocity first: what you bring their teams. Propose principles, not a past claim. |
| Pressure | Interrupts, time-boxes | Not weighted. Touched through round 2's two follow-ups and round 3's time box. | Pause, restate the question, hold through two follow-ups before any concession. |

## Round 1: recruiter screen (30 min)

**Weights:** Conversational 3, Skeptic (light) 1, logistics 4. Logistics is the recruiter's own check, so pay, notice, location and reason for leaving are asked here. Nothing in your material states any of them, so each slot is yours to fill in your own words.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background in about two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); "I handled the branch's formal complaints log" (your message); "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Three beats, in your sentences' order: six years in retail banking, the last three as a branch supervisor; the formal complaints log; the monthly spreadsheet your regional manager uses. Stop there and leave the contact centre for A7. Under 90 seconds. | The opening arc is built from F8, F1 and F3. Your recruiter checks that your story is one you can tell twice. |
| A2 | "What made you apply for this role?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Give your own reason in one sentence. If the complaints work is part of it, connect it to the log at its own scope. Do not claim the end-to-end scope. | Motivation consistency. The honest connection is F1. |
| A3 | "Why are you leaving your current role?" | EXP | [generic] | Logistics slot. Give your own reason in one plain sentence. The pack does not supply one. | Recruiter's logistics check. Nothing in your material states it. |
| A4 | "What pay are you looking for?" | JD | [generic] | Logistics slot. Say the figure you want, in your own words, or ask first for the band the role carries. The pack supplies no figure and no range. If asked about current pay, you may decline and redirect to the figure you want. | Recruiter's logistics check. |
| A5 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period, in your own words. | Recruiter's logistics check. |
| A6 | "Where could you work from?" | JD | [generic] | Logistics slot. Name the branches or hubs you can reach, in your own words. State any limit once, plainly. No reason is required. | Recruiter's logistics check. Hubs are on the brief's list for 2027. |
| A7 | "You've never worked in a contact centre. What's your read of how one runs differently?" | JD | [grounded] "Never worked in a contact centre" (your message) | Say plainly that you have not worked in one. Name one difference you would expect, labelled as an expectation, not experience. Then the branch-side work you do have, at its own scope: "I handled the branch's formal complaints log." | A light Skeptic check on the stated gap (F2). The gap is known, so name it early. |
| A8 | "What would you want done in the first six months?" | JD | [grounded] "Never worked in a contact centre" (your message) | Order the learning: the branch-side process first, the contact-centre side second, stated as a plan. Do not promise results. | Conversational in tone, but scored. It tests the ramp that F2 needs. |

**Reverse questions, round 1**

| Question | Why it lands |
|---|---|
| "How do the three rounds connect, and does the panel score against the same four values?" | Confirms what each round is scoring before 3 December. |
| "What would a strong first three months look like in this role?" | Asks for the ramp, which is where your gaps matter most. |

## Round 2: Head of Member Services (45 min, mostly behavioural)

**Weights:** Skeptic 5 (top, deepest rehearsal), Values / Behavioural 3, Case / Strategist 2, Prober 1. Relationship priors for a hiring manager are Case and Skeptic. The recruiter's "mostly behavioural" moves Values up.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked in a contact centre, and you've never presented above regional level. Why should I put you in front of our contact-centre team and our executives?" | JD (EXP premise) | [grounded] "Never worked in a contact centre" (your message); "I've never presented to anyone above regional level" (your message); "I handled the branch's formal complaints log" (your message); "I built the monthly complaints spreadsheet our regional manager uses" (your message) | **Highest-ROI prep in this pack. Hold, then concede.** Open with what is real: "I handled the branch's formal complaints log, and I built the monthly complaints spreadsheet our regional manager uses." Hold that position through two follow-ups. Follow-up one returns to the log. Follow-up two returns to the sheet. After the second, concede specifically: "I've never worked in a contact centre, and I haven't presented above regional level." Then give the plan: how you would learn the contact-centre side first, and how you would prepare for an executive room. Both are plans, not past events. Do not add a presentation or a contact-centre shift you did not do. | This objection is aimed at F2 and F10, the two stated gaps, and it will come in some form. A held-then-conceded answer changes the round. It is the deepest rehearsal in the pack. |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" (your message) | Name the contact centre first, plainly, as the weakest part. Then the plan. Do not name a second weakness to look balanced. | Skeptic stem. F2 answered in one breath is what this interviewer listens for. |
| B3 | "How much of that spreadsheet was you, and how much was your regional manager's?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | You built it. Say what you decided it would hold, and where your manager set it. Answer slot: if you chose what it counted, say which. If that was set elsewhere, say so. | Attribution probe, the Skeptic's stem for "how much was actually you". The sheet is the evidence for F3 and F5. |
| B4 | "Tell me about a time you kept a member complaint going until it was actually fixed." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt. Choose one complaint from the log. Say what you did at each step. If you followed it to a fixed outcome, say what fixed meant. If the log did not let you follow cases to the end, say so, and describe the nearest case you did follow. Do not describe a closed-loop process the log did not show. | Own the Fix is a published value. F1 is the only sentence that carries the story, so the answer stays in its scope. |
| B5 | "Tell me about a time you had to raise a problem with someone above you." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Open prompt, from the values persona's stem. Pick a time with a named stake and a moment the message was unwelcome. If none comes to mind, say so plainly. If you used the sheet to raise a problem, say how. If not, say that and give the nearest thing you have. | The scaffold holds the honest branch. Your material carries no raised-problem story. |
| B6 | "When did you put a member ahead of an internal target?" | VAL | [generic] | Open prompt. Pick a time a member's need cost you a measure your branch was tracking, with a named stake. If none, say so plainly. Do not supply the target or the outcome. | Values stem, with no claim about your past. |
| B7 | "A branch's complaint volume doubles in a week after a fee change. What do you do in the first 48 hours?" | CASE | [generic] | Clarify first: what changed, which members, what the complaints say. Then one containing action, one member-facing message in plain words, and one escalation path. Name the rule to check, not a rule. | A live problem from the role. No claim about your past. |
| B8 | "Walk me through the monthly report you'd send me on complaint volumes and resolution times." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Describe the report you built, in your words: what it counted and how often it went out. Answer slot: resolution times. If the sheet recorded how long complaints took to close, say which measure. If not, say so and say what you would add first. Name the tool you used. | Skeptic-style probe of the JD's reporting line. F3 is presentation, and F4 and F5 are the discovery rows. |
| B9 | "How would you decide which complaints move to self-service, and which stay with a person?" | CASE | [generic] | Structure: the member's need, the complaint types, what goes wrong when the wrong one moves, and who checks. No past digital work is claimed. Answer slot: your material does not show digital or self-service work (F7). If you have worked on an online or app journey, say what you did. If not, say so and say what you would look at first. | A live problem from the JD's digital line and the brief's 40% target. |
| B10 | "How would you keep a regulated complaint on time when the branch is short-staffed?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Name the discipline: track due dates, flag what is at risk, hand over with the file. Answer slot: the JD raises regulated complaints. If you worked to set timescales or referral rules, say which and how you applied them. If the log ran to branch practice only, say so plainly. | Premised on the JD's regulated-complaints line. F9 cannot reach regulated timescales without this slot. |
| B11 | "You have three minutes with our executive team on complaint trends. What do you lead with?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | If the sheet gives you a figure you can defend, lead with it. Then one member's story, then the one decision you need. Say plainly that this would be your first room above regional level. Do not name a figure you do not have. | Confident presenting to senior leaders. F10 is the stated gap, and your honesty about it comes first. |

**Reverse questions, round 2**

| Question | Why it lands |
|---|---|
| "What does the complaints process look like today across branches and the contact centre, and where does it break?" | Shows you think about the process, not only the people. It matches the JD's scope. |
| "How will moving eight branches into five hubs in 2027 change complaints in the towns that lose one?" | Ties the brief's network change to the Neighbours value. It shows you read the brief. |
| "As more member service moves to digital by 2028, which complaints do you want to stay with a person?" | Links the 40% target to the complaints work. It asks her judgement, not a fact. |

## Round 3: panel of two branch managers (60 min, values scored, 20-min case)

**Weights:** Values / Behavioural 4, Case / Strategist 3 (the escalation case plus follow-ups), Peer Evaluator 2, Prober 2. The relationship prior for a panel is the top two personas of each member. Branch managers are closest to peers, so the peer and prober stems come from them. The values scoring is the panel's stated purpose.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you put a member's need ahead of what was quickest for the branch." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Pick a complaint where the member's need set the outcome, not the fastest close. Say what you did, in order. If no such complaint comes to mind, say so plainly, then give the nearest case the log carries. | Members First is the raising value. F1 is the only sentence that carries a story here. |
| C2 | "Tell me about a time you had to explain something to a member twice." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | If you checked that tellers could explain the script in their own words, say how and what changed. If you did not check, say so and say what you would check first. Do not claim a member-facing rewrite. | Plain Words is the raising value. F6 carries the teaching, not member letters. |
| C3 | "Tell me about a time a number pointed at a place or a group of members you had to think about differently." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | If a count pointed at a town or a group, say which, and what you did about it. If the sheet only ever held totals, say so and say how you would keep the town in view. | Neighbours, Not Numbers is the raising value. The sheet is the count the panel will test against it. |
| C4 | "Tell me about a time you found a problem nobody had asked you to fix, and what you did about it." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | If the sheet surfaced a pattern, say what it showed, what you did next, and what you kept hold of until it was solved. If no problem of yours comes to mind, say so plainly. Do not add a fix you did not carry through. | Own the Fix is the raising value. Whoever finds the problem keeps hold of it. |
| C5 | "Here is the escalation. A member's second complaint about a fee reaches you from a supervisor who says the member won't accept the explanation. Talk us through what you do, for twenty minutes." | CASE | [generic] | Use the case script below. Its structure is the answer; do not memorise its wording. | The panel's 20-minute case. It covers the JD's escalation coaching and the contact-centre side without claiming either from your past. |
| C6 | "What do you need to know before you decide?" | CASE | [generic] | Clarify: what the member needs, what the first complaint got, which rule applies and its timescale, and whether the supervisor spoke to the member. | Clarify before structure is what a case panel scores first. |
| C7 | "What would you coach the supervisor on, and how?" | CASE | [generic] | Coach the decision and the explanation separately: what to say to the member, how to check the member understood, and what the supervisor does next time. Do not take the case off them. Answer slot: if you have coached a colleague through an escalation before, say how. If not, say so. | JD coaching line. F6's slot. |
| C8 | "We're two branch managers. What would you need from us to take complaints off our desks?" | JD | [generic] | Reciprocity first: say what you would bring their teams, such as the complaints workload you would take. Then what you would need, as principles. Do not pretend to know the seam. | Peer Evaluator stem. |
| C9 | "When work spans branches and the contact centre, who gets the credit?" | VAL | [generic] | Say the principle: the team that solved the member's problem gets the credit, and the team that dropped it does not. If you have a past instance, give it in your own words, nothing more. | Peer stem on credit-sharing. A principle, not a past claim. |
| C10 | "How does your monthly report define a complaint as resolved?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: if the sheet had a definition of resolved, say it in your words. If not, say so and say which definition you would propose first. Do not name a definition the sheet did not have. | Prober stem. Resolution times are the JD's line, and F4 is the discovery row. |
| C11 | "Which assumption behind your monthly report would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | If the sheet made an assumption, name the one you would defend least, before they ask. If you set none, say so. | The weakest-assumption move. No figure is given, so no defend-the-number slot arises. |

**Case script for C5 (20 minutes, [generic], not drawn from Ashgrove's real cases)**

Scenario, as given to you: a member's second complaint about a fee reaches you. The supervisor who passed it up says the member "won't accept the explanation." The first complaint was logged three weeks ago. A rule for that fee changed last month. The contact centre has a note of one call. The panel has twenty minutes.

| Time | What to do | Scored against |
|---|---|---|
| 0 to 3 min | Clarify: what the member is asking for, what the rule says and its timescale, what the supervisor actually told the member. | Clarify before structure |
| 3 to 8 min | Decide now: a decision the member can act on this week, and one message written in plain words. | Members First |
| 8 to 13 min | Root cause and coaching: why the explanation failed. Coach the supervisor on the explanation, not overrule them. | Plain Words; the JD's coaching line |
| 13 to 17 min | Report and track: what you would count each month, and agree the definition of resolved before you count. | Neighbours, Not Numbers; the JD's reporting line |
| 17 to 20 min | Values check: name the value your decision served, in that value's words. | The four values |

Hold-then-concede on the rule change: "I'd check the rule before I say the member is wrong." Concede the uncertainty about the rule specifically.

Honest branch: if you have not run a live escalation of this kind, say so, then walk the steps as a plan. Never describe a run you did not do.

**Reverse questions, round 3**

| Question | Why it lands |
|---|---|
| "What does a good escalation from a branch to the complaints lead look like?" | Shows how you would work with the branches, and surfaces their expectations of the role. |
| "What could someone new do in their first month that would genuinely help your branches?" | Reciprocity, the question that turns a panel into a peer conversation. |
| "What do branches want from complaints data that the monthly report does not give them today?" | Asks for the judgement the report misses. It ties to Excel reporting without claiming a tool. |

**Interviewer-path reverse question:** none. No interviewer profile exists yet, so the reverse questions are role-generic.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the complaints process end to end across branches and the contact centre | A7, A8, B1, B4, C5 |
| Contact-centre side specifically | A7, B1, B2 |
| Report monthly on complaint volumes and resolution times | B8, C10, C11 |
| Coach branch supervisors on escalations | C5, C7 |
| Work with digital teams on self-service journeys | B9 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B10 |
| Confident presenting to senior leaders | B1, B11 |
| Comfortable with Excel reporting | B8 (tool named in guidance), C10 |
| Logistics: pay, notice, location (recruiter's check, not a requirement) | A4, A5, A6 |

## Sources

**Provided documents, used as given:**
- The job description and the role, as pasted in your message.
- The recruiter's email on the three rounds and the panel's scoring.
- Ashgrove's four values, copied by you from ashgrovecu.org/about/values on 24 November 2026.
- The 2026 strategy brief from July 2026, as sent by the recruiter.
- Your background, as stated in your message.

**Research tier: L1.** Searches 0 of 6 used. Fetches 0 of 2 used. No searches or fetches were sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet. The pasted values fix this output. Verify the exact names on the official page before the panel. |
| 2. Ashgrove interview process | skipped | Loop structure: the recruiter's email names the three rounds and what each holds. Persona weights follow those rounds. |
| 3. Ashgrove strategy and recent news | skipped | Grounding brief and the Case questions on strategy. The July 2026 brief you sent is inside the six-month freshness line. |
| 4. Interviewer name and company | n/a | No names given yet. The interviewer read and interviewer-specific reverse questions are absent; the upgrade menu says what a name would unlock. |
| 5. Representative JD for this title | skipped | The job description you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- **Interviewer names (round 2 and the panel)** → persona weights set from their public footprint, an interviewer read, and reverse questions tailored to each person's career path.
- **Your answers to the answer slots (F1, F4, F5, F6, F7, F9, B3, B8, B9, B10, C10), in your own words, outside a drill** → those rows and banks regenerate with your words as quoted evidence. A drill answer stays a lead until you say it outside the drill.
- **Your CV, if it says anything about the contact centre, digital work, presenting above regional level, or the spreadsheet's tool** → rows F2, F5, F7 and F10 take a quote, and their bands can rise.
- **Hours you have before 3 December** → a prioritised prep schedule, placed ahead of the question banks.
- **Recruiter's note on any round focus or written brief for the case** → the case section and round weights adjust.
- **Official values page check** → confirm the four names on ashgrovecu.org/about/values. Your copy is from this morning, so the exact names are not yet verified against the live page.
- **A deeper research pass, offered once:** up to 6 more searches and 2 more fetches, several more minutes. It would add recent organisational context and role-family loop reports. The strategy brief is already in hand.
- **A tuesday-dossier.md, if you have one,** would add verified evidence for rows F1 to F10, so the answer slots could be checked against it.
