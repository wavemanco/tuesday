Your prep pack is written, but I couldn't publish the page. Publishing uploads it to claude.ai and needs your approval, so the HTML is in the scratchpad for now. The markdown version is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-8-canned-be07cd03/938a7530-7958-4716-b468-c5dbb320da1f/scratchpad/ashgrove_member_experience_lead_interview_pack.md`, and the page is at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-8-canned-be07cd03/938a7530-7958-4716-b468-c5dbb320da1f/scratchpad/ashgrove_interview_prep.html`. Say the word and I'll publish it. (I also first tried the Dashboard type, which was wrong for a reading page, so I dropped it.)

I built the pack for your three rounds as your recruiter described them. The panel and the Head of Member Services aren't named yet, so rounds 2 and 3 are written for the role. I didn't search. Everything about Ashgrove comes from the values and strategy summary you pasted.

**What the pack says:**

- **Biggest gap: contact centre.** You've never worked in one, and the JD makes this role own complaints across one. Rehearse B2 hardest. Say the plain fact, then hold a plan for your first month through two follow-ups.
- **Presenting above regional level** is the second gap (B6). Don't claim experience you don't have.
- **Strongest fit:** six years in retail banking, the last three as a supervisor, and the complaints spreadsheet your regional manager uses. That spreadsheet covers the monthly reporting requirement, but nothing in your material shows resolution times.
- **Round 3 values:** you have no quoted story for any of the four values. Each has a scaffold that ends with "if none comes to mind, say so." Don't invent one.
- **Round 1 logistics:** pay, notice, location and reason for leaving are all blank in your material. Answer them in your own words. The pack gives no figures.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

Would you like me to run a live drill on the B2 contact-centre question? After a pack, I can also save a `tuesday-dossier.md` with the gaps this prep exposed, for later sessions. Both are optional.

----- file the response produced: ashgrove_member_experience_lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview prep pack

**Role:** Member Experience Lead
**Company:** Ashgrove Credit Union
**Rounds (3 December 2026):** Round 1, 30 min, recruiter. Round 2, 45 min, Head of Member Services (your future manager; name not given), mostly behavioural. Round 3, 60 min, panel of two branch managers (names not given), with a 20-minute complaint-escalation case, scored against the four values.
**Changes:** First version, built 24 November 2026.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural and values alignment. **EXP** your own experience, checked closely. **JD** the listed job's requirements. **CO** company and strategy knowledge. **CASE** a live problem.
- Guidance is scaffolding, not a script. Rehearse the shape and your own words, not the sentences.
- Rounds 2 and 3 are written for a role, not for named people, because the interviewers are not yet assigned.
- Rule for every answer: say only what you did. Where the guidance says "if none, say so", that branch is an honest answer, not a failure.

## Fit snapshot

Requirements come from the JD you pasted. Evidence is quoted from your message. Nothing in the pack says more about your past than these quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log. It does not show the process end to end. Words: "I handled the branch's formal complaints log." Answer slot: the JD asks for the whole process, so expect a probe on who set how a complaint moved from first contact to close. If you set any of that, say which step and how you decided. If it was set for you, say so and stay with the log you ran. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | You stated this absence, so you may say it. Words: "I've never worked in a contact centre." Then how you would learn the contact centre, said as a plan and never as a past. |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | Your material already reaches monthly reporting, in other words. Reword only that: "I built the monthly complaints spreadsheet our regional manager uses." It is an inspectable artifact, so expect the panel to ask what it counts. |
| F4 | "report monthly on complaint volumes and resolution times" — JD | none given | none | [grounded] | discovery | Your material does not show resolution times. Answer slot: if the spreadsheet tracked how long complaints took to close, say what it counted and how. If it did not, say so, and say what you would add first. |
| F5 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | Your material says spreadsheet, not Excel. Name the tool as you used it. Words: "I built the monthly complaints spreadsheet our regional manager uses." |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | presentation | Reword only the quote: "I handled the branch's formal complaints log." Answer slot: the JD names regulated complaints, so expect a probe on the rules behind the log. If a regulator's timescales or rules applied, say which and how you tracked them. If none did, say so plainly. |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "the last 3 as a branch supervisor" — your message | low | [inferred] | transferability | Derived: training tellers is the nearest analogue to coaching supervisors. Words: "I trained new tellers on our escalation script." Limit: tellers, not supervisors. Answer slot: if you coached another supervisor on an escalation, say how. If you did not, say so and say how you would approach it. |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show work with digital teams. Answer slot: if you worked with one, say what you did. If you did not, say so, and say what you would bring from complaints into a self-service journey. |
| F9 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking" — your message; "the last 3 as a branch supervisor" — your message | medium | [grounded] | none | The quotes reach the requirement in role terms. Words: "6 years in retail banking, the last 3 as a branch supervisor." |
| F10 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | You stated this absence, so you may say it. Words: "I've never presented to anyone above regional level." Then how you would prepare for a senior audience, said as a plan and never as a past. |

**Confidence** grades your evidence. **Provenance** grades what this pack wrote about it. **Gap type** is a separate call from the routing rule: a quote that reaches a requirement is `none` or `presentation`, a quote that does not reach it is `transferability`, silence is `discovery`, and a negative you stated is `capability`.

## Grounding brief

Built from your one-paragraph summary of the July 2026 strategy brief. I have not read the brief itself, and I did not search.

- Digital: 40% of member service to digital channels by 2028. Use "digital channels", and expect questions on it in Round 2 and the panel.
- Branches: eight branches consolidating into five hubs over 2027. Expect questions on what that does to complaint volume.
- Small-business lending: a product launch in Q1 2027. This affects the complaints mix, so it is worth one sentence if asked.
- Competition: app-only banks are the main pressure. Your self-service answers (B5) should be built against that.

## Persona table

| Round | Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| 1, recruiter | Conversational / Rapport Builder | Friendly, unstructured openers; logistics questions asked casually | High. Recruiter screens use this register, and logistics are scored | Treat logistics as scored. Answer each in your own words with the slot's figure |
| 1, recruiter | Skeptic (light) | "Why this role, why now?" | Medium. The recruiter screens for motivation and fit | Anchor in what you stated and keep answers short |
| 2, Head of Member Services | Values / Behavioural | STAR-shaped prompts | Highest weight. Your round is stated as mostly behavioural | Give the honest branch where your material is thin |
| 2, Head of Member Services | Skeptic | Probes the contact-centre gap and the presenting gap | High. The hiring-manager prior is Skeptic, and F2 and F10 are the gaps | Hold the stated absence, then a plan. Never a claimed experience |
| 2, Head of Member Services | Case / Strategist (light) | Digital self-service design | Medium. Digital is one of four JD responsibilities | Clarify first, then structure |
| 3, branch-manager panel | Values / Behavioural | Scored against the four values | Highest weight. The panel is a values round by stated design | Map each value to a story, or say none comes to mind |
| 3, panel | Case / Pressure | The 20-minute escalation case, with interruptions | High. The case is 20 minutes of the round | Structure first, then hold your plan through two follow-ups |
| 3, panel | Peer Evaluator | Seam between branches and contact centre; credit when work spans teams | Medium. Two branch managers are peers of the role | Propose seam principles, not a claim you know their seam |
| 3, panel | Data-Driven Prober | Asks what the spreadsheet counted, and what is behind resolution times | Medium. Excel reporting and resolution times are JD lines | Name what the spreadsheet tracked and what it left out |

## Question banks

Type is one tag. Provenance leads with one label, then every quote the guidance rests on. `[generic]` rows make no claim about you.

### A. Recruiter screen (Round 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about the last 3 years as a branch supervisor." | EXP | [grounded] "the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | Name the three years and the complaints log, in your words. Answer slot: if the log was yours to run day to day, say what that involved. If any part was someone else's, say so. | F9 is your clearest fit line, and F1 is its nearest complaint line. The question is premised on the supervisor years, which your quote states |
| A2 | "What are your pay expectations?" | JD | [grounded] none beyond the JD | Logistics slot. Give your own figure, or ask what band the role is advertised at before you name one. Your material states no figure, so the figure is yours to give. | Pay is a logistics term. The recruiter scores the answer, not the figure |
| A3 | "What notice would you need to give?" | JD | [grounded] none beyond the JD | Logistics slot. Give your actual notice period in your own words. Your material states none. | Notice is a knockout check, scored only for consistency |
| A4 | "Where are you able to work from?" | JD | [grounded] none beyond the JD | Logistics slot. Say where you can work in your own words. Your material states no location. | Location matters more with hub consolidation, but the answer is yours |
| A5 | "Why are you looking to leave your current role?" | EXP | [grounded] none beyond your own message | Logistics slot. Give your reason in your own words. Your material states none. Do not criticise your current employer. | The recruiter checks motivation against the role. The reason is yours to give |

### B. Head of Member Services (Round 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through a formal complaint you handled, from first contact to close." | EXP | [grounded] "I handled the branch's formal complaints log" | Story-map on the log. Say what you did, in your words, one step at a time. Answer slot: the JD asks for the whole process, so if any step was yours to set, say which and how you decided. If none was, say so and describe how the log ran. | F1 is where the JD's "end to end" line presses hardest |
| B2 | "You've never worked in a contact centre, and this role runs complaints across one. How would you get a complaint from the contact centre to a branch decision in your first month?" **Highest-ROI prep in this pack.** | Skeptic, JD | [grounded] "Never worked in a contact centre" | Hold-then-concede. Say the plain fact first: "I've never worked in a contact centre." Hold through two follow-ups with a plan: what you would learn first, from whom, and what you would test. Concede specifically: name the part you do not yet know. Never claim contact-centre work. | F2 is the largest gap against the JD's end-to-end line. The question is premised on your own stated absence and the JD's line, which is all it may presuppose |
| B3 | "What did the regulator's rules add to the complaints log you ran?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: if a regulator's timescales or rules applied, say which and how you tracked them. If none did, say so plainly and describe how you kept the log. | F6 holds the regulated-complaints requirement. The question presupposes a rule set only as the JD raises it |
| B4 | "Tell me about a time you helped a supervisor through a complaint escalation." | VAL | [inferred] "trained new tellers on our escalation script" | Open prompt. Pick a time you helped someone through an escalation. Your nearest material is training tellers on the script. If no supervisor was involved, say so and give the nearest thing: the script training. | F7 is low confidence, so the story is a selection scaffold, not a claim about supervisors |
| B5 | "A member has been chasing a complaint through the app and then calls the branch. Design the self-service journey that stops that." | CASE | [generic] | Structure it: the member's journey, where it breaks, what the app should show, and what a branch would need to see. Make no claim about your past. Say what you would test first. | Digital self-service is a JD line that your material does not show. The question is a live problem, so it presupposes nothing about you |
| B6 | "You've never presented above regional level. Sixty seconds: why should senior leaders trust a monthly complaints figure from you?" | Pressure, JD | [grounded] "I've never presented to anyone above regional level" | Hold-then-concede. Say the plain fact first. Hold the figure's basis: name the spreadsheet you built and what it tracks. Concede what you have not yet presented. Name how you would prepare for a senior audience, as a plan. | F10 is the presenting gap, and the question's premise is your stated absence |

### C. Branch-manager panel (Round 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | Twenty-minute case (see below). | CASE | [generic] | Structure: confirm the facts, decide who owns it now, plan the member contact, plan the supervisor coaching, and record the outcome. Say your order before you start. Hold your plan through two follow-ups. Concede what depends on Ashgrove's escalation policy, which you do not know. | A complaint escalation is the panel's stated case. The scenario below is invented for rehearsal, not Ashgrove's |
| C2 | "Tell me about a time you kept hold of a complaint until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt, theme from the value Own the Fix. Story-map on the log: you kept it, and say what you did when it passed on. If no complaint stayed with you to the end, say so and give the nearest thing: the log you ran. | Own the Fix is one of the four values the panel scores |
| C3 | "Tell me about a time you saw a complaint from the member's side and it changed what you did." | VAL | [generic] | Open prompt, theme from Members First. Describe one decision, the member's side of it, and what changed. If none comes to mind, say so plainly, then give the nearest thing your material carries: the log you handled. | Members First is scored. The answer must be a decision, not the value's slogan |
| C4 | "What did the monthly complaints spreadsheet track, and what did it leave out?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Name what it tracked, in your words. Name what it left out. Answer slot for resolution times: if it tracked how long complaints took to close, say how. If it did not, say so. | F3 and F4 are the reporting rows. The question asks what it tracked, which the quote does not state, so the answer is yours |
| C5 | "Tell me about a time a member had to hear something twice. What did you change?" | VAL | [generic] | Open prompt, theme from Plain Words. Describe one explanation you changed. If you did not change the wording, say so. Give the nearest thing: the escalation script you trained tellers on. | Plain Words is scored. Keep the answer to what changed, in the words you used |
| C6 | "Tell me about a branch number you read against its town." | VAL | [generic] | Open prompt, theme from Neighbours, Not Numbers. Describe one figure you read against the branch's local context. If you did not, say so plainly. Do not make the spreadsheet a town story. | The value is scored. The spreadsheet is numbers, and the answer must not claim more than your material shows |
| C7 | "Where does a complaint's ownership pass between a branch and the contact centre, and where would you draw the line?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" — JD | Propose principles: one owner per complaint, with the handoff written down. Say you do not know the seam yet. Give the principle you would start with. | F1 and F2 are the seam between branches and the contact centre. The panel's peers probe this, so the answer is a principle, not a claim to know their seam |

**The twenty-minute case (C1, invented for rehearsal, `[generic]`):** A member complained that a fee was charged on their account. The complaint has been with a frontline supervisor for three weeks. The supervisor offered a partial refund. The member says it is not enough and asks for someone senior. You are the branch manager. What do you do, and in what order?

**Requirement coverage.** Each JD requirement mapped to the questions that cover it:

| JD requirement | Questions |
|---|---|
| Own the complaints process end to end, across branches and the contact centre | B1, B2, C7 |
| Report monthly on volumes and resolution times | C4 |
| Coach branch supervisors on escalations | B4, C1 |
| Work with digital teams on self-service journeys | B5 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B3 |
| Confident presenting to senior leaders | B6 |
| Comfortable with Excel reporting | C4 |

## Values cheat sheet

Round 3 is a values round by stated design, so this section applies. Each value's mapped story draws on a fit row. Where no quote carries a story, the selection scaffold ends in its honest branch.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quote carries a member-side decision. Scaffold: pick one decision where you chose an outcome because of how it looked to the member. Name the step and what the member's side was. If none comes to mind, say so. The nearest thing your material carries is "I handled the branch's formal complaints log" (F1) |
| Plain Words | If a member needs it explained twice, it was written wrong | No quote carries a plain-words change. Scaffold: pick one explanation you changed because it did not land first time. If the escalation script was reworded, say what. If not, say so, and give the nearest thing: "trained new tellers on our escalation script" (F7) |
| Neighbours, Not Numbers | Every branch is part of its town | No quote carries a town. The spreadsheet is numbers (F3). Scaffold: pick one figure you read against a branch's local context. If you did not read figures that way, say so plainly |
| Own the Fix | Whoever finds the problem keeps hold of it until solved | "I handled the branch's formal complaints log" (F1) is near this, but no quote says a complaint stayed with you until it closed. Scaffold: pick one complaint you kept until it closed, including what you did when it passed on. If none did, say so and give the log you ran |

## Reverse questions

Your interviewers are not yet named, so these are role-generic.

1. **"How do complaints move between a branch and the contact centre today, and where does the handoff most often break?"** Why it lands: it shows you are already thinking about the end-to-end ownership the JD asks for.
2. **"As the eight branches consolidate into five hubs during 2027, how do you expect complaint volumes to move, and who will own the complaints process through that change?"** Why it lands: it shows you read the strategy brief and that you see the complaints work as part of consolidation.
3. **"As digital takes a larger share of member service, what does a complaint raised in the app look like, and who owns it?"** Why it lands: it names the self-service journey the JD asks you to shape, and the app-only pressure the company faces.
4. **"What would you need the complaints picture to show in the first 90 days?"** Why it lands: it asks the Head of Member Services what success looks like, which a future manager will answer in detail.
5. **"How are complaint resolution times reported today, and which figures do the senior people read first?"** Why it lands: it shows you care about the reporting the JD makes monthly, and it tests the gap in F4 from their side.
6. **Reciprocity, for the panel (peers):** "What would make the first month easy for a branch manager working alongside this role?" Why it lands: it asks what you would bring to their work, not only what you need from it.

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned the complaints process end to end" | Inflated form of F1. Your material says one branch's log | "I handled the branch's formal complaints log." Your material says the log, not the process |
| "Coached branch supervisors on escalations" | Inflated form of F7. Your material says tellers | "I trained new tellers on our escalation script." |
| "Handled complaints under the regulator's standard" | Inflated form of F6. Your material does not name a standard | "I handled the branch's formal complaints log." |
| "Worked in a contact centre" | Negative you stated, F2 | "I've never worked in a contact centre." |
| "Presented above regional level" | Negative you stated, F10 | "I've never presented to anyone above regional level." |

## Sources

- **Provided documents:** your message, which holds the JD text, the Ashgrove values as you pasted them, the recruiter's round description, your summary of the July 2026 strategy brief, and your background.
- **Searches and fetches:** none run. Every target below is either fixed by an input you gave or is not an output this pack needs.
- **Dossier:** none present. Nothing was consumed from one.

**Research tier:** L0, provided documents only. No search ran.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Fixed by the values you pasted. The values cheat sheet uses them |
| 2. Ashgrove interview process, member services | skipped | Fixed by the recruiter's round description. The persona weights follow the three rounds |
| 3. Ashgrove strategy and recent news | skipped | Fixed by your summary of the strategy brief. I have not read the brief itself |
| 4. Interviewer name and Ashgrove | n/a | No names were given, so there was no query to form |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the questions |

## Upgrade menu

- The names of the Head of Member Services and the two branch managers → persona weights read from their public footprint, and a tailored reverse question for each.
- Your full CV → more fit rows with quotes in place of the four lines above, and firmer answers in A1 and B1.
- The complaints spreadsheet itself, or a redacted copy of its headers → F3 and F4 checked against the artifact, and C4 rehearsable column by column.
- Your own words on the answer slots (F1, F4, F6, F8) → each row upgrades, and the questions that draw on it (B1, B3, C4) can be tightened.
- The recruiter's case brief for Round 3, if one exists → C1 becomes `[grounded]` instead of `[generic]`, and the rehearsal uses the real scenario.
- The days you have before 3 December → a prioritised prep triage in place of the full pack.
- A `tuesday-dossier.md` → would add verified evidence and the objection to rehearse, in place of the inferred ones.
