Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-1-denied-683eb7a4/8436f68a-a70f-4ccc-afdb-75015ad50cf4/scratchpad/northwind_senior-gtm-strategy-lead_interview_pack.md. I couldn't create an outputs folder in the project, so it's in the scratchpad.

It's built on your message and research note. Web search was refused in this session, so Northwind's values, the interview format and Dan's public footprint are not established. The pack marks where that matters. Dan is treated as a peer with a data-driven, pricing-led profile. No source describes the session format, so the persona weights are a flat judgment.

Say the word and I'll play the Skeptic on D1, the question the pack names as the highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.

Can you paste the full JD text? The six JD rows rest on your highlights until I have it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead_interview_pack.md -----
# Mock interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer, reporting to the same VP. **Round:** one 60-minute conversation.
**Candidate:** Priya. **Built from:** your message (JD highlights, background, interviewer note, research note). No full JD text, no CV document, no dossier.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Question IDs are letter-by-persona (A1, B2 and so on). Guidance is scaffolding, not a script: say it in your own words, and stop where the material stops.

| Tag | Name | What it scores |
|---|---|---|
| JD | Role and JD-driven | Whether she can do a stated requirement, gaps included |
| EXP | Experience deep-dive | Whether her past claims hold up, and what she actually did |
| CO | Company and strategy | Whether she thinks at Northwind's altitude, using the research note |
| CASE | Live problem | Structure and reasoning on a problem from the role, with no claim about her past |
| VAL | Values alignment | Not used. No values-style round was detected |

Provenance labels: `[grounded]` traces to your message or research note. `[inferred]` is derived from a grounded fact, with the derivation named. `[generic]` is a role-family pattern with no claim about this candidate or company.

## Fit snapshot

The JD lines below are from your JD highlights, not full JD text. "Your message" means what you wrote about Priya.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "9 at a large consumer-tech company in product strategy & ops" (your message) | low | [grounded] | transferability | Your material says product strategy and ops, not go-to-market ownership. Keep it at that scope: "9 at a large consumer-tech company in product strategy & ops." Answer slot: if you made a go-to-market decision for a product, say which and how you decided; if not, say so and say what from strategy and ops work carries over. |
| F2 | "whitespace across land/adopt/expand/renew" (JD highlights) | none given | none | [grounded] | discovery | Nothing in your material covers whitespace, so the words are an answer slot. If you have sized an unclaimed segment or motion, say how you counted it in your own words; if not, say so and say how you would define the denominator first. |
| F3 | "independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (your message) | medium | [grounded] | presentation | The quote reaches the tools but not independence. Say the tools at the scope you stated them. There is no inspectable artifact yet, so expect a probe on what you ran yourself. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | At its own scope this is partner economics: a model used in carrier negotiations, not a partner motion you designed. Answer slot: if you designed any part of how partners sell or get paid, say which and how you decided; if not, say so and say what the model was for. |
| F5 | "cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Expect a probe on whose targets these were and where the consensus came from; say which part was yours. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (your message) | medium | [grounded] | transferability | Your material shows daily use of AI tools, not AI features built or shipped. Keep those two apart. Answer slot: name one task you run with AI tools; if you have built or shipped anything AI-based, say what; if not, say so. |
| F7 | Headline figure, not a JD line (your message) | "proposed a store-surface change credited with ~$400M ARR uplift" (your message) | medium | [grounded] | none | Keep "proposed" and "credited with" as written. Limited inspectable proof, so expect defend-the-number probes: how it was counted, what it is sensitive to, the assumption she would defend least, and which part was hers. |
| F8 | Sales-ops and quota-setting, not a JD line (your message) | "No classic sales-ops or quota-setting experience." (your message) | none | [grounded] | capability | Words: "I don't have classic sales-ops or quota-setting experience." Then the nearest sentence she carries, at its own scope: "set annual volume targets with cross-org consensus". Say where that stops. Never call volume targets quotas. |

Confidence grades her evidence. Provenance grades what this pack wrote. Gap type is the routing call. No row is a gate: no location, pay, authorization or credential term appears in the material.

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. No answer, hold, bridge or rationale in this pack asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM for a product line | Inflated form of F1 | Quote F1 at its own scope. The limit is this pack's observation: your material says product strategy and ops. No slot names this wording. |
| Set quotas, or ran sales-ops | Inflated form of F5 and F8 | Volume targets are not quotas. Use the F8 acknowledgment, then the F5 sentence at its scope. |
| Negotiated with carriers, or led the carrier talks | Inflated form of F4 | Quote F4 at its own scope: the model was used in carrier negotiations. |
| Drove the ~$400M, or the uplift was mine | Inflated form of F7 | Quote F7 at its own scope: proposed, and credited with the figure. The attribution is the limit. |
| Designed partner motions | Inflated form of F4 | F4's quote at its own scope, plus the answer slot in F4. |
| Built or shipped AI features | Inflated form of F6 | F6's quote at its own scope, plus the answer slot in F6. |

## Reading the interviewer

Public signals only, from your note. Career pattern: a pricing and monetization spine, with one early-stage startup chapter. Self-described as "relentlessly data-driven." His public footprint was not searched (see Sources).

Practical implications:

1. Every number will be taken back to its assumptions. Prepare the defend-the-number answers (A1, E1, A4).
2. Pricing is his native language. Case questions tilt toward pricing, packaging and unit economics (C1, C2).
3. The startup chapter means builder stories land, and he may test big-company pace. Lead with what she did, not what the company did (A2, F1).
4. He is a peer. Seam and reciprocity questions are likely (B1, B5, R4).

Mirror opportunities: none offered. No shared professional path is established on her side.

## Grounding brief

Your research note lists Northwind's stated priorities and main threat. Quoted as you wrote them, tagged `[grounded]`:

- Priorities: "enterprise expansion", "AI copilot launch ('Compass')", "reaching profitability"
- Threat: "bundling by a much larger platform vendor"

The note is undated, so freshness is not established. Use these terms when speaking. Do not present them as current until you have checked them.

## Persona table

| Persona | How it shows up here | Weight and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Data-Driven Prober | Two-level follow-ups on the ~$400M figure, the SQL work and the partner model | 5. Peer relationship prior, raised by his "relentlessly data-driven" self-description | Defend the number precisely. Name the weakest assumption before he does. Say plainly when you do not know how a figure was counted | A1 to A5 |
| Peer Evaluator | Seam between the new lines and his team, credit, disagreement | 5. Peer relationship prior. Seam and credit are how peers test a hire's load | Offer seam principles, not a map. Show what she brings his team | B1 to B5 |
| Case / Strategist | A stalled product line, the Compass pricing call, the bundling threat | 3. His pricing career tilts case questions toward pricing and packaging. No loop source establishes a case round | Clarify before structuring. Price and packaging before channel | C1 to C3 |
| Skeptic | No sales-ops or quota work, no pricing record, why GTM and why now | 3. The gap in F8 is the most predictable objection, so the Skeptic bank holds the deepest rehearsal | Hold, then concede the gap exactly as stated | D1 to D3 |
| Pressure / Stress | "How much of it was actually you?" and a sixty-second case for her over an internal candidate | 2. A peer is not usually a stress relationship, but a time-boxed moment is possible | Hold the proposal claim through two follow-ups. Concede only what she does not know | E1, E2 |
| Conversational | Opening journey, and AI asked casually | 2. Casual openers are still scored, and the AI plus is a JD line | A 90-second arc. Name one real task, not a capability | F1, F2 |
| Values / Behavioral | Not used | 0. No values-style round detected: no loop source, and the generic fallback has none | Not applicable | none |

Loop: not established. Your message names a single 60-minute conversation, but no source describes its format, so the weights above are a flat judgment, not a documented process.

Depth: 5, 5, 3, 3, 2, 2 = 20 questions, inside the 18 to 26 range.

## Question banks

Provenance comes first in each row. The guidance and the rationale refer only to quoted sentences or to fit-snapshot rows.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" (your message) | Say "credited with", not "caused". If you know how the figure was counted, walk through it in your own words, naming any baseline or period you know. If you don't, say so plainly and say what you proposed. Follow-up: name the assumption you would defend least before he does. Answer slot: the counting is yours to describe only if you know it. | F7 is the headline figure. Probers follow counted numbers two levels deep, so this is the likeliest probe in the session. EXP because it tests what she actually did. |
| A2 | "Tell me about an analysis you ran in SQL or Tableau, from question to decision. What did you run yourself?" | JD | [grounded] "skilled in SQL/Tableau" (your message); "independent analysis in SQL and Tableau" (JD highlights) | Open prompt: pick one analysis and walk it from question to decision. Mark which steps she ran herself. Answer slot: if she ran it end to end, say which steps; if she handed off a step, say which; if she has no analysis of that kind, say so and name the nearest one. | F3 is presentation: the quote says skilled, not independent. The JD asks for independence, so the probe lands here. JD because it scores the stated requirement. |
| A3 | "Our brief is whitespace across land, adopt, expand and renew. How do you find it, and how do you size it?" | JD | [grounded] "whitespace across land/adopt/expand/renew" (JD highlights) | Live problem about the role, so no past claim is needed. Structure: define the denominator (which accounts, which motion), the signal for each motion, then sizing. Answer slot: if she has sized an unclaimed segment, say how she counted it, in her own words; if not, say so and say how she would define the denominator first. | F2 is discovery: no quote covers whitespace. This is the clearest place the JD scores something she has no prepared story for. |
| A4 | "Your partner-level revenue model: which assumption would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Weakest-assumption move: name, in her words, the assumption she would defend least. Answer slot: the assumptions are hers to name only if she set them; if she set them, say which; if the inputs came from elsewhere, say so. Keep the model's use at "used in carrier negotiations". Do not describe the talks or her role in them. | F4 is the best partner-economics evidence, and the attribution is the real probe. EXP because it tests her own model's assumptions. |
| A5 | "How would you check a partner motion's numbers before you commit a quarter to it?" | JD | [grounded] "partner-motion design experience required" (JD highlights) | Structure: the unit of a partner motion, the economics per partner, the leading indicator, and the kill criterion. Answer slot: if she designed any part of how partners sell or get paid, say which and how she decided; if not, say so and say what from the carrier model carries over, at the scope it had. | The JD requires partner-motion design, and F4 is transferability only, so a rehearsed answer matters. Dan will test economics first, given his pricing background. |

### B. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between your two new lines and what my team owns, and what happens when we disagree?" | JD | [grounded] "cross-functional influence" (JD highlights) | Offer seam principles, not a map: "I don't know your seam yet, so here's the principle I would use", for example deciding by who makes the decision, not by the org chart. Reciprocity: name what she brings his team. Do not pretend to know the seam. | Peer probes test seam-splitting and disagreement style. It is the JD's cross-functional requirement in its peer form. |
| B2 | "When work spans our teams, how do you handle credit?" | JD | [grounded] "set annual volume targets with cross-org consensus" (your message) | Use "we" for the consensus process and "I" for what she proposed. Answer slot: if she led the cross-org process, say so and how; if she was one voice in it, say what she contributed and what she did not decide. | F5 is the closest evidence of cross-functional work. The answer is an attribution probe, not a new claim. |
| B3 | "Who had to agree to those annual volume targets?" | JD | [grounded] "set annual volume targets with cross-org consensus" (your message) | Name the groups who agreed, in her words. Answer slot: if someone pushed back, say who and what she did; if nobody did, say so and say what made consensus hold. | Tests the F5 claim at its scope, and the consensus word is the quote's own. |
| B4 | "Tell me about a time two peers disagreed on a plan you were in. Where did you stand, and what happened after?" | JD | [generic] open prompt, theme from the JD's cross-functional requirement | Selection scaffold: pick a time two peers disagreed, with a named stake, a position she held, and a relationship that was intact after. If no such time comes to mind, say so plainly, then give the nearest thing her material carries (B2's process) or how she would handle it. | No quoted sentence carries a disagreement story, so this is a scaffold, not a story map. Peer Evaluator tests disagreement style. |
| B5 | "Where do sales strategy and a new product line's go-to-market usually clash?" | JD | [generic] pattern for launches of this kind, not a claim about Northwind | Ask for his view first. Typical clash points are pricing ownership and account assignment, named as patterns. Say which one you would settle by decision, not by seniority. | Generic by design: it asks about a pattern, and her history is not in it. It opens the seam conversation B1 starts. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A product line you launched six months ago is flat on expansion. Walk me through the first three questions you'd ask before you touch the plan." | CASE | [generic] live problem, no claim about her past | Clarify, then objective, segmentation, approach, metrics, risks. Tilt: ask about price and packaging before channel, since expansion often turns on what each tier includes. Name one premise you would challenge. | A live problem from the JD's new-product-lines requirement. The pricing tilt matches the interviewer's career. |
| C2 | "Compass launches as an AI copilot. How would you decide whether it is priced into the core product or sold separately?" | CO | [grounded] "AI copilot launch ('Compass')" (your research note) | Name the two options and the trade-off in each: cost to serve, who uses it, what core customers would pay for, and the unit economics. Say what data you would need. Do not assert a Northwind decision. | Compass is a stated priority in the research note, and pricing is his ground, so expect it. |
| C3 | "Our biggest competitive threat is a much larger platform vendor bundling. How does a data product avoid becoming a feature?" | CO | [grounded] "bundling by a much larger platform vendor" (your research note) | Give a point of view: what is hard to bundle (switching costs, data gravity, a partner channel) and what is easy. Concede one thing the bundle wins, such as the low end. Ask how his team sees the threat. | The threat is from the research note. Differentiate rather than recite it. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your background shows no classic sales-ops or quota-setting work. What makes you credible to own go-to-market for two new lines?" | JD | [grounded] "No classic sales-ops or quota-setting experience." (your message) | Hold, then concede. Open with the gap as stated: "I don't have classic sales-ops or quota-setting experience." Then the nearest sentence she carries: "set annual volume targets with cross-org consensus", and say where that stops. Hold through two follow-ups by returning to that sentence and to how she would learn quota mechanics, a plan rather than a past. Concede the gap as stated. Never call the volume targets quotas. | Highest-ROI prep in the pack. This is the most predictable objection, aimed at the gap a sales-strategy peer will test first. The volume targets are the nearest evidence and the likeliest place to be inflated. |
| D2 | "What's your pricing or packaging experience, if any?" | EXP | [inferred] the question's theme comes from the interviewer's pricing career (your note); [grounded] "9 at a large consumer-tech company in product strategy & ops" (your message) | Answer slot: if she made a pricing or packaging decision, name it; if not, say so plainly, then give the nearest sentence she carries, at its own scope: "built a partner-level revenue model used in carrier negotiations". Do not claim pricing. | Pricing is his native ground and the material is silent on it, so this is a probe to prepare for, not a concession. |
| D3 | "Two years in consulting, then nine in consumer tech. Why GTM for emerging products, and why now?" | EXP | [grounded] "2 yrs strategy consulting at a top firm" (your message); "9 at a large consumer-tech company in product strategy & ops" (your message) | Give the arc in those two sentences, at their own scope. Answer slot: the reason for GTM and for now, in her own words; the material does not carry one yet. Do not invent an interest in sales. | Motivation consistency is a Skeptic test. The "why now" is silent in her material, so it is a slot. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That ~$400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" (your message) | Hold, then concede. Hold through two follow-ups: "I proposed the change; the figure is credited to it." Concede specifically: "I don't know how much of the uplift the change alone drove, and I can't tell you how it was counted." Never fold the proposal claim. Never offer a share percentage. | Stress tests composure, and F7's figure is the most probed claim. The hold is the quote, and the concession is the limit. |
| E2 | "Sixty seconds: why you over an internal candidate for this?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message); "set annual volume targets with cross-org consensus" (your message) | A 60-second arc: the two quoted sentences at their own scope, no adjectives, and a close on what she would do first. Answer slot: the reason over an internal candidate, in her words; if her material does not carry one, say so and name the nearest. | A time-boxed fit question. It must not exceed what the quotes carry. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 yrs strategy consulting at a top firm" (your message); "9 at a large consumer-tech company in product strategy & ops" (your message) | A 90-second arc: the two sentences in order. Then one line, in her words, on what the consumer-tech years taught her that bears on GTM. Answer slot: if she has a line, use it; if not, say so. | Casual register is still scored, and this is the first thing a peer hears. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message); "AI experience a plus" (JD highlights) | Name one task she runs with AI tools, specifically. If she has built or shipped anything AI-based, say what; if not, say so. Do not say "I work with AI" as if it meant building. | The AI plus is a JD line asked casually. The candidate's sentence is use, not building (F6). |

### Coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| own GTM strategy for two new product lines | C1, B1, D1 | F1 is transferability; D1 holds the deepest rehearsal |
| whitespace across land/adopt/expand/renew | A3 | F2 is discovery, so the answer is a slot |
| independent analysis in SQL and Tableau | A2 | F3 is presentation |
| partner-motion design experience required | A5, A4 | F4 is transferability |
| cross-functional influence | B1, B2, B3, B4 | F5 is none |
| AI experience a plus | F2 | F6 is transferability |
| Not a JD line, but a named gap: sales-ops and quota-setting | D1 | F8 |
| Not a JD line, but a headline figure | A1, E1 | F7 |

## Reverse questions

Each with why it lands.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came up through pricing and monetization. Which pricing decision did you most want to be in the room for, and what did it teach you?" | Tied to his own path. It turns an interview into a peer conversation and shows you researched him. |
| R2 | "What did the early-stage chapter teach you about pricing that a larger company still gets wrong?" | Ties to his one startup chapter and invites him to tell a story, which is how peers talk. |
| R3 | "Where does the Compass launch plan and the way sales is set to sell it still disagree?" | Shows you read the launch priority. It asks for his view of the seam without asking him to confirm anything. |
| R4 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity: it reverses the evaluation and tells him you are thinking about his load. |
| R5 | "How does your team see the bundling threat showing up in deals?" | Connects the research note's main threat to his own work, so the question is about his team and not about the company in general. |

## Sources

Provided documents: your message (JD highlights, background, interviewer description), your research note. No CV document, no full JD text, no dossier.

Searches and fetches (Research tier: L1 — searches 0 of 6 (3 sent, all refused), fetches 0 of 2):

- "Northwind Data company values": refused (web search not permitted this session)
- "Northwind Data interview process sales strategy": refused
- "Dan Kovac Director of Sales Strategy Northwind Data": refused
- Fetches: none sent

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Values cheat sheet. The values round was not detected, so there is no values bank. Query refused |
| 2. Interview process, sales strategy | unavailable | Loop structure. No loop source established the loop, so the weights are a flat judgment. Query refused |
| 3. Strategy and recent news | skipped | Your research note already supplies the priorities and threat (grounding brief, C2, C3). Undated |
| 4. Dan Kovac public footprint | unavailable | Talks, posts, recurring themes and a sharper reverse question. Query refused |
| 5. Representative JD | skipped | JD highlights supplied, which fix the fit rows as provided. Full text would change them (upgrade menu) |

## Upgrade menu

- Full JD text → the six JD rows (F1 to F6) and the coverage check rest on highlights now; with the full text, the requirement list can be checked completely.
- Priya's own words for "No classic sales-ops or quota-setting experience." → F8 and D1 rest on your note, not on her sentence. Her wording replaces it.
- Web search, once granted → Northwind's values page: a values bank only if a source documents a values round. Its interview process: confirms the format of the 60 minutes. Dan's public talks or posts: recurring themes as likely questions, and a reverse question tuned to his writing.
- The exact wording of the ~$400M attribution, in her own words (what she proposed, what the credit covers) → F7 and E1 tighten. The counting slots stay open until then.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several minutes. It needs web search, which this session did not have, so it is not run.
- tuesday-dossier.md, if you have one from an earlier run → its verified evidence would replace the note-level quotes with confirmed ones.
