I built a starter pack from what you've given me. It's generic, so please treat it as a structure to fill in, not a Stripe-specific prep. The full pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-3-denied-5a476677/8352bead-c6d5-469f-a987-825016b66f10/scratchpad/stripe-product-ops-pack.md`.

**What it's built on:** No job description, CV, round details, or interviewer names were provided, and web search was not permitted in this session. So nothing here is verified about Stripe. Every item is labeled `[generic]`, and I've assumed a final round with a hiring manager plus one or two cross-functional partners.

## Question bank

**Hiring manager**
- **Q1 (Behavioral):** Tell me about a process you designed that other teams adopted. Name the problem, your part, the before-and-after metric, and what you'd change now.
- **Q2 (Behavioral):** Walk me through a cross-team project that went off track. Separate what you controlled from what you didn't.
- **Q3 (Operational):** How do you decide which processes to build and which to leave alone? Give a criterion and one example of something you chose not to build.
- **Q4 (Situational):** You inherit 40 requests from three PMs with conflicting priorities. What do you do in week one? Clarify who owns the decision, then sort by impact and reversibility.

**Cross-functional partner**
- **Q5 (Behavioral):** Tell me about pushing back on a partner team. Show how you got the data and how the relationship held afterward.
- **Q6 (Operational):** How would you tell whether an operational change worked? Define the metric before the change and name a guardrail metric.

**Skeptic**
- **Q7:** Of your last project's results, how much was actually you? Credit the team once, then state your own part plainly, without shrinking it.
- **Q8:** What did you get wrong on that project? Name one real mistake and what you changed.

**Values**
- **Q9:** Which principles matter most to you here? Pull the names from Stripe's official values page before the interview. Don't rely on memory.

## Reverse questions
1. What does a successful first six months look like in this role?
2. Where does product operations sit relative to finance and go-to-market, and who decides when they disagree?
3. What process problem is the team most frustrated by right now?

## Prohibited claims for this pack
- No outcome numbers you can't source from your own records.
- No team size, budget, or scope larger than what you personally owned.
- No claimed familiarity with Stripe's products or internal tools unless you've actually used them.
- No Stripe values stated from memory.

## Biggest prep wins
Rehearse Q1, Q4, and Q7 out loud first. They're the most likely to come up in some form, and Q7 is the one most likely to be pressed on.

## What would make this much sharper
- **Paste the job description.** I can then grade your fit against each requirement and turn the gaps into skeptic questions.
- **Paste your CV or three to five stories.** Answers would be built from your real experience rather than scaffolds.
- **Tell me the round format:** who is interviewing, how long, and whether there's a take-home or presentation.
- **Allow web search,** so I can verify Stripe's values, loop structure, and current strategy.
- **Give me the interviewer names,** and I'll read their public professional background.

## Questions for you
1. Who are the interviewers in the final round, and what is each person's role relative to yours?
2. Can you paste the job description and your CV, or three to five of your stories?
3. Can you allow web search? If not, check Stripe's official values page and careers page yourself before the interview.

If you want to rehearse, I can play the hiring manager and run one question with follow-ups, then give feedback.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe-product-ops-pack.md -----
# Mock-interview pack: Stripe, Product Operations Manager, final round

**Built without:** a JD, a CV, round details, interviewer names, or company research (web search was not permitted in this session). Everything below is **[generic]**: a common shape for this kind of loop, not a fact about Stripe. Verify before relying on it.

**Assumed loop:** final round with a hiring manager plus one or two cross-functional partners (engineering, finance, or go-to-market).

## How to use this pack

- **Personas** = how the question is asked (hiring manager, cross-functional partner, skeptic).
- **Types** = what is being scored:
  - **Behavioral:** what you did in the past
  - **Situational:** what you would do in a new case
  - **Values:** how you fit the company's principles
  - **Operational:** how you measure and run ops work
  - **Skeptic:** challenges to your claims
- Guidance is scaffolding, not a script. Use your own words.

## Prep triage

Prep time was not stated, so no schedule is given. If time is short, prioritize Q1, Q4 and Q7 (the three most likely to come up in some form), then the reverse questions.

## Fit snapshot (self-assessment worksheet)

No JD or CV was provided. For each requirement a Product Operations Manager role usually carries, write one sentence of your own evidence in your words:

| Likely requirement | Your evidence (one sentence, your words) | Gap? |
|---|---|---|
| Process design that other teams adopt | | |
| Cross-functional leadership without authority | | |
| Metrics, and judging whether an ops change worked | | |
| Scaling operations (volume, tooling, handoffs) | | |
| Written communication to executives | | |

Where you cannot write a sentence, that is your gap. Rehearse a bridge: what you did adjacent to it, and how you would close it.

## Prohibited claims (built locally)

Do not say in the interview:
- Any outcome number you cannot source from your own records.
- Any team size, budget, or scope larger than what you personally owned.
- Any familiarity with Stripe's products, internal tools, or strategy unless you have actually used or studied them.
- Any Stripe value or principle recalled from memory. Use the official page.

## Question bank

### Hiring manager persona

**Q1. [Behavioral] Tell me about a process you designed that other teams adopted.**
- Guidance: name the problem, your specific part, the metric before and after, and what you would change now.
- Provenance: [generic]. Open with your own story, not the framework.

**Q2. [Behavioral] Walk me through a cross-team project that went off track.**
- Guidance: separate what you controlled from what you did not. Name the decision you would reverse.
- Provenance: [generic].

**Q3. [Operational] How do you decide which processes to build and which to leave alone?**
- Guidance: give a criterion (volume, cost of error, frequency). Give one example where you chose not to build something.
- Provenance: [generic].

**Q4. [Situational] You inherit a backlog of 40 requests from three PMs with conflicting priorities. What do you do in week one?**
- Guidance: clarify who owns the decision, sort by impact and reversibility, and name who you would talk to first.
- Provenance: [generic].

### Cross-functional partner persona

**Q5. [Behavioral] Tell me about a time you pushed back on a partner team and were right, or wrong.**
- Guidance: show the disagreement, how you got the data, and how the relationship held afterward.
- Provenance: [generic].

**Q6. [Operational] How would you tell whether an operational change actually worked?**
- Guidance: define the metric before the change, name a guardrail metric, and say how long you would wait before judging.
- Provenance: [generic].

### Skeptic persona

**Q7. [Skeptic] Of the results from your last project, how much was actually you?**
- Guidance: be precise about your role. Credit the team once, then state your own part plainly. Do not shrink it below what you did.
- Provenance: [generic].

**Q8. [Skeptic] What did you get wrong on that project?**
- Guidance: name one real mistake, what it cost, and what you changed afterward. A rehearsed "weakness" answer will be noticed.
- Provenance: [generic].

### Values

**Q9. [Values] What are the principles that matter most to you here, and which one do you hold most strongly?**
- Guidance: pull the names from the official Stripe values page before the interview. Do not guess. Then tie one principle to a story you can tell in two minutes.
- Provenance: [generic]. Values not verified.

## Reverse questions

1. "What does a successful first six months look like in this role?" Why it lands: it shows you plan around outcomes.
2. "Where does product operations sit relative to finance and go-to-market, and who decides when they disagree?" Why it lands: it surfaces the real decision structure.
3. "What is the process problem the team is most frustrated by right now?" Why it lands: it invites an honest answer you can act on.

## Upgrade menu

- **Paste the JD** → fit snapshot becomes evidence-graded, and the gaps become the skeptic questions.
- **Paste your CV or three to five stories** → answers become story-mapped rather than scaffolds.
- **Tell me the round format** (who, how long, any take-home or presentation) → persona weights and loop structure.
- **Allow web search** → Stripe's values, loop structure and recent strategy verified, replacing the [generic] labels.
- **Give interviewer names** → interviewer read, based on public professional footprint only.
