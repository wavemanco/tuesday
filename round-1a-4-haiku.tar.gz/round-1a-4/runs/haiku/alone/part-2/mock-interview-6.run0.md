Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-6-denied-95aee0d6/ecc137b6-a9d9-445b-b3f6-994ca16ab910/scratchpad/Larkfield_Systems_engineering-manager_interview_pack.md. It covers all three rounds: one shared fit snapshot, then a bank of eight questions per round. I built it from your role summary and your message. I had no full JD and no names for the interviewers.

Web search was refused in this session, so the pack has no Larkfield values page and no strategy research. The values cheat sheet is left out, and the VP round uses the recruiter's own words instead. You can grant search permission and I'll rerun those two lookups.

The highest-return prep is question A4, the hardware objection. Your biggest gap is that you've never owned a hardware-adjacent roadmap, and a skeptical hiring manager will press on it. The pack gives you the plain acknowledgment, the nearest real story, and a plan for learning hardware.

Say the word and I'll play the Skeptic on A4. I can also save a tuesday-dossier.md that records the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two questions would reshape the pack:
1. Do either of the two squads have a team lead of its own under you? If so, A5 and the manager-of-managers row stay. If not, they close.
2. Did the recruiter name any focus areas, or a take-home or presentation for any round? That would add a build section and change the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield_Systems_engineering-manager_interview_pack.md -----
# Larkfield Systems, Engineering Manager: interview prep pack (loop of three rounds)

**Candidate:** Yusuf
**Loop:** Round 1, Director of Engineering (hiring manager), 45 min, Tuesday. Round 2, panel of two staff engineers and a product manager, 60 min, the Thursday after. Round 3, VP Engineering, 30 min, the following Monday, described by the recruiter as "values and leadership philosophy".
**Built from:** your role summary and your message. No full JD, no CV, no interviewer names, no recruiter notes, and no research (see Sources).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **JD** role requirement. **EXP** what you actually did, and whether it survives a probe. **CASE** live problem, structure and reasoning. **VAL** behavioural or values story. **CO** company and strategy knowledge (none in this pack, because no research ran).
- Guidance is scaffolding, not a script. Each cell is about 90 to 120 seconds spoken.
- **Answer slots** are instructions for the interview. They are not questions to me. Where a slot says "if you did this, say how", the honest second branch is always allowed: "that was not mine", or "I haven't done this".
- Every claim about your past is a sentence you wrote, quoted. Where the material does not show something, the pack says so and leaves the words to you.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from your role summary. Your evidence is quoted from your message. Confidence grades your evidence. Provenance grades what this pack wrote. Gap type is one of the six in the taxonomy.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" building device-management services. Your role summary | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Say it at its own scope: three years as a team lead of six. Your material shows one team of six, not two squads. Answer slot: if you have run two groups at once, say how; if you have not, say so, and say how you would run two squads. |
| F2 | "building device-management services". Your role summary | "9 years engineering" (your message) | low | [grounded] | discovery | Your material says nine years of engineering and nothing about device or fleet work, so it does not show whether that experience exists. Answer slot: if any of those years touched device or fleet work, say which and what it was; if none did, say so, and say what you would study first. |
| F3 | "own delivery, hiring and growth for 11 engineers". Your role summary | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Team of six, not eleven. Say it as three years as a team lead of six. Answer slot: what you would have to change in how you run delivery at eleven that you do not yet run at six. Say what you know, or that you have not run a group that size. |
| F4 | "own delivery, hiring and growth for 11 engineers", hiring part. Your role summary | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | none | The quote reaches hiring in role terms, so no bridge is needed. Say it at its scope: backend roles. The figure is defended in A8. |
| F5 | "own delivery, hiring and growth for 11 engineers", growth part. Your role summary | none given | none | [grounded] | discovery | Your material is silent on growing engineers. Answer slot: how you have grown someone, if you have, in your words; if you have not, how you would find out what each engineer needs. |
| F6 | "partner with hardware and product on roadmap", hardware part. Your role summary | "I've never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Plain acknowledgment, in your words: "I haven't owned a hardware-adjacent roadmap." The nearest thing your material carries is at its own scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: how you would learn hardware-adjacent work, said as a plan and never as a past. |
| F7 | "partner with hardware and product on roadmap", product part. Your role summary | "after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | The quote shows pushing back on roadmap pressure, not partnering with product on a roadmap. Say the quarter in those words and stop there. Answer slot: how you worked with product on that quarter: which part you did and which product did; if you did not work with product on it, say so. |
| F8 | "Lead two squads" where either squad has a lead of its own. Your role summary; whether leads exist is question 1 below | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Conditional on question 1. Plain acknowledgment: "I've never managed managers." The nearest thing your material carries is the quote in F1, at its own scope. If neither squad has a lead under you, this row closes and A5 drops out. |

No gate row: your role summary names no location, work pattern, or right-to-work term. If one applies, it becomes a hard-gate row.

## Persona weights

Relationship priors set the start. Interviewer profiles were not supplied, so the adjustments are the round-level ones only. Round 2 blends its members' relationships; the member-level weights are shown in the rows.

| Round | Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| 1, Director of Engineering | Case/Strategist | Live problems on your two squads and the hardware roadmap | High. A hiring manager is buying capability and checking gaps, and your role summary is a roadmap-heavy spec | Clarify before structuring. Name the hardware dependency early |
| 1, Director of Engineering | Skeptic | "Where is your device and hardware experience?" | High. F2, F5, F6 and F8 are the thin rows, and they are where a hiring manager presses | Plain acknowledgment, then the bridge, then a plan. Never describe hardware work you have not done |
| 1, Director of Engineering | Data-Driven Prober | Counting the 60% and the 40 interviews | Medium. A director reads headline figures, and both figures are in your message | Say what each figure counts, name its weakest assumption, and say plainly when you do not know |
| 2, staff engineers | Peer Evaluator | Seam between squads, credit, disagreement | High. Peers price what the hire costs their own work | Seam principles, not claimed knowledge of their seam. Offer reciprocity |
| 2, staff engineers | Data-Driven Prober | The on-call figure, measured against its assumptions | High. Staff engineers read the CV line by line, and the 60% is the line most likely to be checked | Counting, sensitivity, the weakest assumption, and which part was yours |
| 2, product manager | Peer Evaluator | Roadmap seam with hardware and product | High. The PM owns the roadmap side of the partnership | Name who decides, and how a disagreement gets raised early |
| 2, product manager | Case/Strategist | A roadmap trade-off under a hardware date | Medium. The PM's native question is a trade-off, and it is less likely to be a full case | Clarify scope first, then the trade-off |
| 3, VP Engineering | Values/Behavioral | Leadership philosophy, an unpopular truth, a choice between values | High. The recruiter's own words name this round, and it is the round's stated purpose | Map each story to a quoted sentence, or give a selection scaffold ending in the honest branch |
| 3, VP Engineering | Pressure/Stress (skip-level) | "Why you?", "How much of that was actually you?" | Medium to high. Skip-level rounds lean on composure and time-boxed answers | Pause, restate, hold through two follow-ups, then concede the specific limit |
| 3, VP Engineering | Case/Strategist (altitude) | A trade-off between a reliability quarter and a roadmap commitment, at company level | Medium. Altitude cases are common at this level | State a position, then the one fact that would change it |

## Values and leadership: the VP round

The recruiter's words ("values and leadership philosophy") make this a values-style round, so the VAL questions in round 3 are written against them. **No company values were in hand**: research did not run (see Sources), so there is no values cheat sheet in this pack. Where a VAL question needs a published value, the pack uses the recruiter's own words instead.

## Round 1: Director of Engineering (hiring manager), 45 min

Personas, weighted: Case/Strategist 3, Skeptic 3, Data-Driven Prober 2.

### Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You'd inherit two squads on device-management services. What do you need to know in your first two weeks, before you change anything?" | JD, CASE | [grounded] "Lead two squads building device-management services" (your role summary) | Clarify before structuring: what each squad owns, what is already committed, where the hardware dependencies sit, and who you would meet first. Then name one thing you would write down before deciding. No claim about your past | Covers the two-squad and device-service requirements. It presupposes only the role summary's own words |
| A2 | "The hardware team has a date and product has a feature on it. Your squad says it can't hold both. What do you do this week?" | CASE, JD | [grounded] "partner with hardware and product on roadmap" (your role summary) | Structure it: what the date is tied to, what the feature trades against, who decides, and what you would put in front of them. Say the trade-off aloud before you pick a side. Answer slot: if you have made a call like this, say what you decided and how, in your words; if you have not, say how you would decide and what you would want to see first | This is the role's named friction. A live case tests structure on it, and the answer slot keeps your past out of the case |
| A3 | "How would you grow an engineer who is ready for more scope than their current role gives?" | JD | [grounded] "own delivery, hiring and growth for 11 engineers" (your role summary) | Describe the mechanism: the conversation, the scope you would test, and how you would know it worked. Answer slot: if you have done this, say whom and what you did, in your words; if you have not, say how you would find out what each engineer needs | F5 is silent on growth. This turns that discovery row into an answer slot |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A4 | "You haven't owned a hardware-adjacent roadmap. Why should we believe you'll partner with hardware on ours?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." (your message) | **Highest-ROI prep in this pack.** Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then the nearest thing: "I pushed a reliability quarter through against roadmap pressure." Then how you would learn hardware-adjacent work, said as a plan: name the hardware lead you would ask first, and the one thing you would want to understand before the first roadmap review. Hold through two follow-ups by returning to the acknowledgment and the plan. Concede specifically what you do not know about hardware. Never describe hardware work you have not done | F6 is the largest gap, and a Skeptic will ask it in some form. The non-defensive answer is the acknowledgment with a plan, rehearsed until it is boring |
| A5 | "Have you ever led people who lead teams?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Conditional on question 1. If neither squad has a lead under you, this question drops out of the round. Plain acknowledgment: "I've never managed managers." Then the nearest thing: "3 as a team lead of 6", at its own scope. Answer slot: how you would prepare to lead leads, said as a plan, not as a past | F8. The negative is yours, so the acknowledgment is yours. The rest is a plan |
| A6 | "Why leave a payments company for device management?" | EXP | [grounded] "currently at a payments company" (your message) | Selection scaffold: give your own reason in your own words. Your material carries none, so check that the reason you give is true before the round. Do not borrow a reason from the job posting | Reason for leaving is a Skeptic motivation probe. The material carries no reason, so the guidance is a slot, not a story |

### Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A7 | "Walk me through how the on-call burden was measured." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Say what the 60% counts and the period it covers, in your words. Name the assumption you would defend least. Answer slot: which part of the drop was yours and which was not; if you do not know how it was counted, say so plainly | Headline metric: defend-the-number slot. The pack supplies no counting method, because none is in your message |
| A8 | "What did the forty interviews last year actually count, and which part of the loop was yours, and which was already set?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Say what the figure counts: interviews, candidates, or hires. If the count is approximate, say it is approximate. Answer slot: if you set a step of the loop, say which and how you decided; if you did not, say so, and describe how you ran it | Headline figure: defend-the-number slots, including which part was yours. No counting method is supplied |

**Round 1 reverse questions**

- "What does a good first six months look like for the two squads, and what would tell you early that it isn't going well?" Why it lands: you show you plan to be measured from the start.
- "Which part of the device-management roadmap is most exposed to hardware timing this year?" Why it lands: you name the dependency your gap sits on, and asking about it shows you found it.

## Round 2: panel (two staff engineers and a product manager), 60 min

Personas, weighted: Peer Evaluator 3, Data-Driven Prober 3, Case/Strategist 2. The staff engineers carry Peer and Prober. The PM carries Peer and Case.

### Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side with hardware and product. Where's the seam between your squads and ours, and what happens when we disagree?" | JD | [grounded] "partner with hardware and product on roadmap" (your role summary) | Propose seam principles, not knowledge of their seam: who decides on an interface change, how you would surface a disagreement early, and what you would escalate. Answer slot: if you have resolved a disagreement with an equal team, say how; if you have not, say how you would handle one | Peer pricing of the hire, on the partnership the role names. Their team is not described in the material, so the guidance says nothing about it |
| B2 | "How do you handle credit when work spans teams?" | JD | [grounded] "own delivery, hiring and growth for 11 engineers" (your role summary) | Give the principle first: name the people who did the work, and the order they did it in. Then one example, only if you have one | Peer version of the delivery requirement. No claim about your past is made |
| B3 | "Tell me about a time a peer disagreed with a call you had made. How did it end?" | VAL | [grounded] "after I pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt. Pick a time a peer disagreed with you and it mattered. Say whose call it was and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, in your words: "I pushed a reliability quarter through against roadmap pressure", and say what the disagreement was | Peer persona stem as an open prompt. The nearest sentence is the only story your material carries |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B4 | "Walk me through how the 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Say what the 60% measures and the period, and what it is sensitive to, in your words. Name the assumption you would defend least. Answer slot: if you do not know how it was counted, say that plainly | Defend-the-number slot. No method is supplied |
| B5 | "What metric would you put on device-management delivery in the first six months, and what would it not tell you?" | JD | [grounded] "own delivery, hiring and growth for 11 engineers" (your role summary) | Name one metric you would defend and what it counts. Say the weakest assumption behind it. Answer slot: if you have not chosen a metric for device delivery, say so, and say who you would choose it with | Prober asks for the denominator. Device metrics are where your record is thinnest |
| B6 | "Which assumption behind the on-call number would you defend least, and which part of it was yours?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Name the weakest assumption in your own words before they do. Then separate what was yours, the push, from what you cannot attribute. Hold on "I pushed the quarter through", which is your sentence, and concede the rest specifically | Second follow-up on the same figure: the weakest-assumption move and the hold-then-concede structure |

### Case/Strategist (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B7 | "Devices in the field drop off after a firmware rollout, and product wants the roadmap date kept. What do you do in the first 48 hours?" | CASE | [generic] | Clarify scope: how many devices, which firmware version, whether a rollback is safe, and who owns the rollout. Treat the roadmap date as a decision to revisit with product and hardware on data, not as a fixed point. Name one thing you would not promise yet | Live problem tied to the role's hardware and product partnership. Generic, so it makes no claim about you |
| B8 | "What would you ask the hardware lead in your first meeting?" | JD | [grounded] "partner with hardware and product on roadmap" (your role summary) | Ask about interface contracts first, then release cadence, then who owns device-side behaviour. Say what you do not yet know about their stack, and ask about it | Tests what you would ask, not what you know. It is the hardware requirement in its most direct form |

**Round 2 reverse questions**

- "What could a new engineering manager do in the first month that would genuinely help your teams?" Why it lands: peers weigh reciprocity, and it turns a test into a collegial conversation.
- "Where does the roadmap get decided when hardware and product disagree?" Why it lands: it shows you care who decides, which is the PM's own territory.

## Round 3: VP Engineering, 30 min ("values and leadership philosophy")

Personas, weighted: Values/Behavioral 4, Pressure/Stress 2, Case/Strategist 2.

### Values/Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "after I pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt. Pick a time you told leadership something they did not want to hear: a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, in your words, and say what you told them | The values theme comes from the recruiter's own words. The nearest sentence is the only story your material carries |
| C2 | "When did you put the long-term health of a system ahead of a short-term commitment?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Name the commitment you set aside, and the stake on each side, in your words. Hold the outcome to the sentence: the 60% is your team's figure, and add no cost you cannot name. If you did not have to choose, say so | Values theme, with the one story your material carries. The outcome is the quoted figure and nothing more |
| C3 | "What's your leadership philosophy, in one sentence, and where did it come from?" | VAL | [grounded] "values and leadership philosophy" (the recruiter's words, relayed by you) | Give one sentence, then one decision that shows it. Do not recite a borrowed framework. If you have not put it in a sentence before, state the principle you actually use, and give one decision that shows it | The recruiter's term is the raising source. The answer is yours, so the guidance makes no claim about you |
| C4 | "How would you decide which of eleven engineers gets the next promotion when there's one slot?" | VAL | [grounded] "own delivery, hiring and growth for 11 engineers" (your role summary) | Name the criteria you would use, and how you would tell someone no. Answer slot: if you have made a promotion decision on a real team, say the criteria you used, in your words; if you have not, say how you would decide, and what evidence you would want | Growth and fairness at the scale the role names. The slot keeps a decision you did not make out of the answer |

### Pressure/Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" and "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Pause, restate the question, then answer from what you did: nine years, three as a team lead of six, and the hiring loop. Hold through two follow-ups without adding figures. When pressed, concede a specific limit: hardware, and the two-squad scope | Skip-level composure probe. The answer uses only quoted sentences, and the concession is the gap you already named |
| C6 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold-then-concede. Hold the part your sentence carries: you pushed the quarter through. Concede, specifically and in your words, the part of the drop you cannot attribute to yourself. Do not fold on the push itself | Pressure version of the attribution probe. The hold is your own sentence |

### Case/Strategist (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C7 | "Hardware wants a launch date, product wants a feature, and your squads can't do both. What's your position in the room?" | CASE | [generic] | State a position first, then the one fact that would change it. Name what you would ask each side to commit to. Do not claim a past resolution | Altitude case at executive level. Generic, because it draws on no past |
| C8 | "Where could device-management services create a reliability problem for the company, and what would you check first?" | JD | [grounded] "Lead two squads building device-management services" (your role summary) | Name the reliability surface you would check first, in the order you would check it, and the question you would put to each. Keep it to what you would verify, not what you have seen | Puts reliability on the role's own product. The reliability quarter in F7 is your one relevant story, and it stays at its own scope |

**Round 3 reverse questions**

- "How does the company choose between a reliability quarter and a roadmap commitment when both have senior backers?" Why it lands: it tests altitude, and the VP's answer shows the philosophy the round is about.
- "What did the last person in this role get right, and what do you want the next one to change?" Why it lands: it signals humility and gives you the role's real problem in the VP's words.

**Reverse questions, all rounds:** no interviewer profile was supplied, so none is tied to an interviewer's own career path. The upgrade menu says what a name would add.

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| "Lead two squads building device-management services" | A1, A5 (conditional on question 1), C8 |
| "building device-management services" | A1, B5, C8 |
| "own delivery, hiring and growth for 11 engineers", delivery | A2, B5, C4 |
| "own delivery, hiring and growth for 11 engineers", hiring | A8, F4 (closed) |
| "own delivery, hiring and growth for 11 engineers", growth | A3, C4 |
| "partner with hardware and product on roadmap", hardware | A2, A4, B8 |
| "partner with hardware and product on roadmap", product | A2, B1, C7 |
| Leads under you (the manager-of-managers question) | A5, conditional on question 1; none, and why, if neither squad has a lead |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| "I led two squads" | Inflated form of F1. Your sentence is about one team of six | The quote at its own scope: "3 as a team lead of 6". The limit is the pack's own observation: your material shows one team, not two squads. A1 and F1's slot stay inside that scope |
| "I've owned a hardware-adjacent roadmap" or "I've partnered with hardware on a roadmap" | Sourced negative, F6. You stated it | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." A4's plan answers the rest |
| "I've managed managers" | Sourced negative, F8. You stated it | Plain acknowledgment: "I've never managed managers." A5 applies only if question 1 says the squads have leads |
| "I designed the reliability programme" or "I fixed the on-call problem" | Inflated form of "I pushed a reliability quarter through against roadmap pressure". No sentence says you designed or fixed anything | The quote at its own scope. How the drop was achieved is not supplied. A7 and B6 ask who did what, in your words |
| "I've run hiring for all eleven engineers" or "I've hired device engineers" | Inflated form of "I run our hiring loop for backend roles". The sentence is about backend roles | The quote at its scope: backend roles. F4 closes on that |
| A counting method for the 60% or the 40 interviews | No sentence in your message gives one. Any method would be supplied | Answer slot only: what you know, and "I don't know how it was counted" when that is true (A7, A8, B4) |

## Sources

**Provided documents:** your role summary (the Engineering Manager description, quoted as requirements), and your message (your background, the three rounds, and the recruiter's description of round 3).

**Research tier: L1, searches 2 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Searched and refused: the search permission was not granted in this session. No values page was read. It would have moved the values cheat sheet (section 10) and the round 3 VAL wording |
| 2. `Larkfield Systems engineering manager interview process` | unavailable | Searched and refused, as above. Loop structure rests on your own round list, which is a loop source; the pack needs no archetype fallback. A search would have confirmed or corrected the loop |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Not sent after the first two calls were refused. It would have moved the CO questions, and this pack has none |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Engineering Manager` JD | unavailable | Not sent. Your role summary stands in for the JD, so the requirements are your words, not a fetched posting. A representative JD would have moved the JD requirement wording |

Searches were sent for targets 1 and 2 and returned no result, so both refusals are listed under their queries. No other call was sent.

## Upgrade menu

- **The full JD text** → the requirement rows become `[grounded]` from the posting's own wording, and the JD questions can be tied to its lines
- **The two squads' team leads, if any** (question 1) → A5, F8 and the manager-of-managers row either stay or close
- **The recruiter's prep email** → coverage of any focus areas, and a build section for any take-home or presentation it names
- **Any hardware-adjacent work, described in your words, even if you did not own the roadmap** → F6 could move from capability to transferability, if the material shows it; no words are added for you
- **The company's values page, pasted** → the values cheat sheet, and VAL questions in round 3 written against its named values instead of the recruiter's words
- **Search permission for this session** → targets 1 to 3 and 5 run; the two refused calls can be retried
- **The three interviewers' names and public profiles** → persona weights from their public footprint, and one reverse question tied to each person's path
- **A `tuesday-dossier.md` from job-underwriter** → its `prohibited_claims` and evidence map replace the local prohibited list and the fit grades
