Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-8-denied-f2a2e3c1/8609f414-87ca-4362-beb2-3ac3f6f9d9c8/scratchpad/Ashgrove-Credit-Union_member-experience-lead_interview_pack.md`.

It has 18 questions across the three rounds, grounded in your message, the JD, the recruiter's email, the values and the strategy summary. The one I'd rehearse hardest is C2, presenting to senior leaders. The JD asks for it, and you've said you haven't done it above regional level, so the pack gives you a plain acknowledgment followed by a plan.

The complaint-escalation case is D1, with a timed structure and an honest branch. It's a generic scenario because the recruiter hasn't said what the real case is.

I used the provided material only, with no web research, since your inputs already covered the values, loop structure, strategy and JD. The pack has no interviewer read or delivery coaching, because there's no interviewer profile or assessment.

Would you like me to play the Skeptic on C2 as a live drill? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove-Credit-Union_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview prep pack

**Interviews:** 3 December 2026, three rounds. Interviewers not yet named, so the pack is written to the roles.
- **Round 1, 30 min:** recruiter screen.
- **Round 2, 45 min:** Head of Member Services, your prospective manager. Mostly behavioural.
- **Round 3, 60 min:** panel of two branch managers, including a 20-minute complaint escalation case. The panel scores against the four values.

**Built from:** the JD you pasted, the four values you copied from the values page this morning, the recruiter's email, your summary of the July 2026 strategy brief, and your background. No interviewer profile, no interviewer research, no dossier. First version, so no changelog.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores.

- **VAL:** values, tested against the four published values
- **EXP:** your own experience, and whether it holds up under a follow-up
- **JD:** the listed job, including its gaps
- **CO:** company and strategy knowledge
- **CASE:** a live problem from the role

Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview: answer from what you actually did, in whichever branch it gives. It is not a question for me. Aim to speak each guidance cell in 90 to 120 seconds.

## Fit snapshot

Confidence grades your evidence. Provenance grades this pack's labelling. The quotes are your words, from your message or the JD as pasted. There are no gate rows: the material raises no term-type requirement such as location, pay or a licence.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | Say the span in your message's words: six years in retail banking, the last three as a branch supervisor. The JD's label belongs to the JD. Do not attach it to your years. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your message says formal. It does not show a regulatory timescale or an external referral. Answer slot: if any complaint on the log carried one, say which and how you tracked it. If none did, say so plainly and return to the log you ran. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The log is adjacent work at one branch. It does not reach end to end, nor the contact centre. Bridge: "I handled the branch's formal complaints log." Answer slot: which steps from intake to closing were yours to set. If none were, say so and stay with the log. |
| F4 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | low | [inferred] | transferability | Teller training is adjacent to coaching supervisors. Nothing in the material shows supervisor coaching. Keep the bridge at the training's own scope. Answer slot: if someone on your team escalated and you coached them through it, say what you did. If the training was for tellers only, say so and say what you would do first with a supervisor. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The sentence reaches the monthly report in other terms. The material shows no resolution times. Bridge: say the sentence as written, with no added figure. Answer slot: if the spreadsheet tracked resolution times, say which and how they were counted. If it did not, say so and say what you would add first. |
| F6 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | Your message says spreadsheet and does not name Excel. Answer slot: name the tool you built it in, and what you did with it each month, in your own words. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Your words: "I've never presented to anyone above regional level." Then say how you would learn it, as a plan and never as a past. |
| F8 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your words: "I've never worked in a contact centre." Then say how you would learn the contact-centre side, as a plan and never as a past. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Nothing in the material shows digital or self-service work. Answer slot: if you worked on a digital or self-service change, say what it was and your part in it. If you did not, say so and say how you would approach it. |

**Gap type, in short:** presentation means the evidence is there and needs stating plainly. Discovery means the material is silent. Transferability means the work is adjacent. Capability means you have said you have not done it.

## Prohibited list

These are the claims this pack will not coach. Each has a basis and an honest form. The limits are the pack's own observations; they are not words for you.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F3 | "I handled the branch's formal complaints log." Your material says the log, not the process. Slots in B4 and D1 stay inside the log. |
| Has experience handling regulated complaints | Inflated form of F2 | "I handled the branch's formal complaints log." Your material does not show a regulatory timescale. |
| Presented to senior leaders | Negative you stated, F7 | "I've never presented to anyone above regional level." No slot. |
| Worked in a contact centre | Negative you stated, F8 | "Never worked in a contact centre." No slot. |
| Wrote the escalation script | Inflated form of F4 | "trained new tellers on our escalation script." |
| Coached branch supervisors | Inflated form of F4 | Teller training, at its own scope. |
| Built the reporting in Excel | Inflated form of F5 and F6 | "I built the monthly complaints spreadsheet our regional manager uses." |

## Persona weights

**Reasoning:** the recruiter's email names the rounds, lengths and interviewers' roles, so the loop is established by a loop source. Round 3 is documented as scoring against the values, so a values-style round is detected. No interviewer signals exist, so weights come from relationship priors alone.

| Persona | Where, and weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Conversational | Round 1, top: 5 questions | Friendly walk-through, with logistics asked casually | High. Recruiter screens are the logistics round, and the risk is treating them as unscored. | A 90-second arc built from your own sentences. Answer each logistics question in your own words. |
| Values/Behavioral | Round 2, top: 4 questions. Round 3: within D2, E2 | Scenario probes mapped to the four values, expecting STAR-shaped stories | High. Round 2 is mostly behavioural, and round 3 scores against the values. | Map a story to a value only where one of your sentences carries it. Otherwise give the honest branch. |
| Skeptic | Round 2, mid: 3 questions | Quiet probing of the regulated-complaints, senior-presenting and contact-centre gaps | High on the senior-presenting gap, which your message states. The Head of Member Services is your prospective manager. | Lead with your plain words, then the plan. Hold through two follow-ups. |
| Case/Strategist | Round 3, mid: 3 questions | The 20-minute escalation case, and a strategy question on hubs and digital | High. The case is announced, and the strategy brief is in hand. | Clarify, structure, decide, record. The scenario is generic until you have the real case brief. |
| Pressure | Round 3, low-mid: 3 questions | Probes on the spreadsheet and on a supervisor error | Medium. Composure is the panel's test, and the spreadsheet is the one figure-like claim you gave. | Hold once, concede one specific thing, and never fold on the sentence you built. |
| Data-Driven Prober | Inside E1 and E3 | How the spreadsheet was built and what it counts | Medium. The JD asks for reporting, and the spreadsheet is your only figure-like claim. | Say what the spreadsheet cannot show. Name the tool and any part someone else set. |

## Question banks

Question IDs are letter by persona: A for the recruiter screen, B and C for round 2, D and E for the panel.

### Bank A: Conversational (round 1, recruiter screen)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background in about two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); "I handled the branch's formal complaints log" (your message); "trained new tellers on our escalation script" (your message) | Speak in the order your message gives: the six years and the three as a supervisor, then the formal complaints log, then training tellers on the escalation script. Use those words. Do not add a title or a scope the sentences do not carry. | Opens round 1 and sets your first version of the story. F1, F3 and F4 are the evidence it draws on. |
| A2 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give your own figure, or ask what the band is before you give one. Your message gives no figure, so none appears here. | Pay is a knockout check, and the figure is yours alone. The material offers nothing to say. |
| A3 | "What is your notice period?" | JD | [generic] | Logistics slot: give the notice you actually owe. Your message gives no figure, so none appears here. | Notice is a knockout check. The answer is a fact about your own contract. |
| A4 | "Which location could you work from, and how often can you be on site?" | JD | [generic] | Logistics slot: answer from your own situation, in your own words. Your message gives no location or pattern, so none appears here. | Location and on-site pattern are knockout checks for a branch-based role. |
| A5 | "Why are you leaving your current role?" | EXP | [generic] | Logistics slot: give the reason in your own words, short and true. Your message gives no reason, so none appears here. Say what you would say to a manager you respect. | The screen's motivation check, asked in a friendly register. The guidance refers to no past. |

### Bank B: Values/Behavioral (round 2, top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you decided something from the member's side of the counter, when the procedure pointed the other way." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold: a case where the member's need and the procedure pulled apart. It needs a named stake, the decision you made, and what it cost. If none comes to mind, say so plainly, then give the nearest thing your material carries: one case from the formal complaints log. Use I for what you did and we for context. | Members First, Always is the published value. The log is the nearest sentence about complaints, so the story has to come from you, not from the sentence. |
| B2 | "Tell me about a time you explained something to a customer and had to explain it again. What changed?" | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Story selection: a time a member needed the explanation a second time. Answer slot: say what you did when you trained tellers on the escalation script, and whether a member ever needed it explained twice. If no such case comes to mind, say so plainly. | Plain Words is the published value on test. Your training sentence is the nearest story, and the slot keeps it at the scope you trained. |
| B3 | "Tell me about a time a number told you one thing and the people involved told you another." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Scaffold: a case where a figure in a report hid a person's situation. Say what you did about it and what happened to the figure. If no such case exists, say so, then say what the spreadsheet shows and what it cannot show. | Neighbours, Not Numbers is the value on test. The spreadsheet is the nearest sentence, and the honest branch keeps the figure from becoming the story. |
| B4 | "Tell me about a complaint you kept hold of until it was solved. What did you do when it stalled?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Story selection: a complaint you carried to a close, with the stall and your next step. If no complaint on the log stayed with you that far, say so plainly, then give the nearest case you handled. | Own the Fix is the published value on test. The sentence gives you the log, not an outcome, so the stall and the fix must come from you. |

### Bank C: Skeptic (round 2, mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Have you handled any complaints that carried a regulatory timescale or an external referral?" | JD | [grounded] "I handled the branch's formal complaints log" (your message); "experience handling regulated complaints" (JD) | Answer slot: if any complaint on the log carried a regulatory timescale or an external referral, say which and how you tracked it. If none did, say so plainly and return to the log you ran. Do not add a timescale you cannot describe. | The JD's regulated-complaints line is the likeliest probe, and your message says "formal", not "regulated". The honest answer is the branch you have. |
| C2 | "How would you present a complaints trend to a room of senior leaders who do not know the detail?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | The hold: open with your own words, "I've never presented to anyone above regional level," then give the plan. Lead with the one figure and the decision you want, then the detail on request. Say the plan as a plan. Hold through two follow-ups by returning to the plan, and never describe a senior presentation you did not give. | **Highest-ROI prep in this pack.** The JD lists senior presenting, your message says you have never done it, and the Head of Member Services will check whether you say so cleanly. Rehearse this one to the second follow-up. |
| C3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" (your message); "I've never presented to anyone above regional level" (your message) | Name one part of the JD in your own words, specifically: the contact centre, which you have never worked in, or senior presenting, which you have not done. Then say what you would do in the first month. Do not offer a strength to balance it. | A skeptic's stem. The answer that scores is calibrated candour with a ramp plan. Your material shows two plain gaps, and the answer names one. |

### Bank D: Case/Strategist (round 3, panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | Case, 20 minutes: "A member phones the contact centre about a reversed charge. The next day they go to their home branch and are told it is the same problem. On the third contact they say they will take it to the ombudsman. Walk me through what you do in the next hour." | CASE | [generic] | Rehearsal scenario. The real case may differ, so drill the structure. Timing: about 2 minutes to clarify, 3 to structure, 10 to decide and act, 5 to record and close. Clarify the promise made, the timescale, and who holds the case now. Decide who owns the case end to end and what happens today. Fix the handoff between contact centre and branch. Say what you would record for the monthly report. Answer slot: if you have run a case that crossed a channel, say which and what you did. If not, say so and say how you would apply the structure. | The panel's 20-minute case, scored against Members First and Own the Fix. It presses on F3 and F8, the two gaps the material shows most clearly, so the honest branch matters most here. |
| D2 | "Eight branches are becoming five hubs during 2027, and a growing share of member service moves to digital channels by 2028. What happens to complaints, and what would you do about it?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (strategy summary, July 2026); "move 40% of member service to digital channels by 2028" (strategy summary, July 2026); "every branch is part of its town" (published value, Neighbours, Not Numbers) | Structure: which complaints move with a branch closure, which move to the app or phone, and what gets lost in each shift. Name one measure you would watch first. Frame the town-level impact as a question you would ask, not a finding. Do not claim to know the hubs' volumes; your material has no such data. | Strategy is the differentiator, and the brief sets up this question. The Neighbours value makes the town the test, so a volume answer alone will score low. Covers the digital requirement. |
| D3 | "Tell me how you would coach a branch supervisor who keeps escalating complaints that should close at branch level." | JD | [generic] | Structure: find out why the escalations happen (training, authority, the script, or the case itself). Coach on one case at a time, naming the supervisor's own decision. Then check the next three cases together. Answer slot: if a member of your team escalated and you coached them through it, say what you did. If only tellers were trained, say so and say what you would do first with a supervisor. | Coaching branch supervisors is a JD line that no quote carries directly. Your nearest sentence is teller training (F4, low confidence), so the guidance does not lean on it. |

### Bank E: Pressure (round 3, panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That spreadsheet. How much of the reporting was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Hold: say first, in your words, that you built it and that the regional manager uses it. Concede one specific thing: name any part someone else set, and the tool it runs in. Answer slot: if resolution times were in it, say how they were counted. If they were not, say so. Do not defend a figure you cannot explain. | The one figure-like claim in your material, and the JD asks for both the report and Excel. Hold once. Concede a specific thing. Do not fold on "I built it." |
| E2 | "Tell me about a complaint you got wrong as a supervisor. What did it cost the member?" | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Selection scaffold: an error with a named stake, what you did about it, and what the member got in the end. Say the error plainly and what you kept hold of. If you have no such case, say so, then give the nearest complaint from the log and what you would do differently. Hold once. Concede the mistake specifically. | A pressure question that checks composure and the Own the Fix value. Your material shows the supervisor years but no error, so the honest branch carries real weight. |
| E3 | "You are going to tell me the branch's complaints numbers are good. Why should I believe a spreadsheet you built?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Hold: the spreadsheet is what you built, and the regional manager uses it. Name what it cannot tell them, including whether its figures are right. Do not argue the numbers are good. The material gives no figure you can defend. | Tests whether you can say what a number cannot show. That is the honest form of a figure, and it is what a prober looks for. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Own the member complaints process end to end across branches and the contact centre | B4, D1 |
| Report monthly on complaint volumes and resolution times | E1 |
| Coach branch supervisors on escalations | D3 |
| Work with digital teams on self-service journeys | D2 |
| Experience handling regulated complaints | C1 |
| Confident presenting to senior leaders | C2, C3 |
| Comfortable with Excel reporting | E1 |

Session total: 18 questions, within the 18 to 26 range.

## Values cheat sheet

Each published value is mapped to a story where one of your sentences carries it. Where none does, the cell gives a selection scaffold that ends in the honest branch.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No sentence of yours carries a member-side decision. Scaffold B1, which uses F2's log sentence: "I handled the branch's formal complaints log." If no case comes to mind, say so plainly. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | F4 gives "trained new tellers on our escalation script," at low confidence. Scaffold B2. If no member ever needed a second explanation, say so. |
| Neighbours, Not Numbers | Every branch is part of its town | F5 gives "I built the monthly complaints spreadsheet our regional manager uses." Scaffold B3, a figure that hid a person. If none comes to mind, say what the spreadsheet cannot show. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F3 gives "I handled the branch's formal complaints log." Scaffold B4, a complaint held to its close. If none stayed with you that far, say so. |

## Grounding brief

Your strategy summary, July 2026, is four months old, so it is current. Nothing in it is stale. Items are quoted from your summary, not checked against Ashgrove's published copy. The right-hand column is for preparation: it asks what to be ready to discuss, and claims nothing about Ashgrove.

| Item (quoted from your summary) | What to be ready to discuss, for complaints | Question |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | What happens to complaints that arrive through the app or phone instead of a counter? | D2 |
| "consolidate eight branches into five hubs over 2027" | What happens to a branch's complaint history when the branch closes, and who hears the decision? | D2, D3 |
| "launch a small-business lending product in Q1 2027" | New products can bring new complaint types. Not rehearsed here. | None |
| "the main competitive pressure is app-only banks" | Members who leave for an app bank may complain on the way out. Not rehearsed here. | None |

## Reverse questions

Each has a one-line reason. No interviewer profile exists, so these are role-generic. The panel's branch managers are not presented as peers, so no reciprocity question is included.

| Ask | Who | Why it lands |
|---|---|---|
| "What would make the first six months in this role a clear success for you?" | Recruiter | Shows you are thinking about outcomes, not your first desk. |
| "What has the complaints process changed about in the last year, and what did that change cost?" | Recruiter | Shows you are thinking about the process as it runs. |
| "Which complaint measure do you read first each month, and what question does the spreadsheet not answer yet?" | Head of Member Services | Shows you will own the reporting, and points straight at the Excel requirement. |
| "When a branch supervisor brings you an escalation, what do you want them to decide themselves first?" | Head of Member Services | Shows you are thinking about coaching, which is a stated requirement. |
| "When a complaint crosses from the contact centre to a branch, who holds it until it is solved?" | Panel | Shows you understand the handoff and the Own the Fix value. |
| "As branches move into hubs, which members do you expect complaints to change most for?" | Panel | Connects the interview to the strategy brief. |

## Sources

**Provided documents, all used:**
1. The JD text, pasted in your message
2. Ashgrove's four values, copied from ashgrovecu.org/about/values on 24 November 2026
3. The recruiter's email on the round structure
4. Your summary of the July 2026 strategy brief
5. Your background, in your message

**Searches and fetches:** none. No dossier was consumed.

**Research tier: L0, no searches.** The values, loop and strategy targets were fixed by the inputs above, so no search was needed.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The four values you pasted fix the names and working meanings in the values cheat sheet. |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email names the three rounds, their lengths and what each holds. That establishes the loop, and the persona weights follow it. |
| 3. Ashgrove strategy and recent news | skipped | Your July 2026 strategy summary fixes current priorities. The grounding brief uses it. |
| 4. Interviewer name and company | n/a | No interviewer is named, so no query can be formed. |
| 5. Representative JD for the role | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- **Your CV, or any document you can show.** The fit-snapshot quotes can then cite a document, and a line a document backs may raise F5 and F6 from medium.
- **Your answers to the answer slots, written here.** Each becomes new quoted material. Rows F1 to F9 and the banks that draw on them are then regenerated.
- **Your notice, pay and location.** If you tell me them, they are quoted into A2 to A4, and no figure is supplied for you.
- **The recruiter's case brief for round 3, if one exists.** It replaces the rehearsal scenario in D1 with the real case.
- **The names of the Head of Member Services and the two branch managers.** This adds per-interviewer persona weights and reverse questions tailored to each.
- **A deeper research pass,** up to 6 more searches and 2 more fetches, several more minutes. It would add recent organisational context and loop reports for credit unions of this kind, with forum-sourced claims labelled as inferred. Offered once; say so if you want it.
- **A tuesday-dossier.md,** if one exists. It would replace the locally built prohibited list with one checked against the evidence.
