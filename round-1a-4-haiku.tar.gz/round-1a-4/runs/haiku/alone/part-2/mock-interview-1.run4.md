Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-1-denied-dcc2c1ca/0ac48969-43af-4c02-9611-088774d0994b/scratchpad/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It has 21 questions across seven personas, tabled by question type, with a fit snapshot, prohibited claims, reverse questions and sources.

Web search was refused in this session, so the Northwind strategy and Dan Kovac lookups did not run. The Compass and bundling questions rest on your research note, which I have not verified.

The highest-ROI prep is D1, the question about which part of sales-side planning she would be thinnest on. Dan's peer status and sales-strategy role make that the most likely objection. A1 to A3, the $400M attribution questions, are a close second, because Dan is a data-driven prober.

Say the word and I'll play the Skeptic on D1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

Two things would sharpen the pack:
1. Could you paste the full JD text, and Priya's CV or her own sentences about her work? Right now every quote comes from your notes.
2. Did Priya herself say she has no sales-ops or quota-setting experience? Your notes say so, but if she says it, the gap becomes a plain acknowledgment and the pack can give her words for it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Northwind Data: Senior GTM Strategy Lead, Emerging Products

**Candidate:** Priya
**Conversation:** one 60-minute conversation with Dan Kovac, Director of Sales Strategy at Northwind. Dan is a peer, on the same VP.
**Changelog:** first pack. No earlier version.

## How to use, and the type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Where a guidance cell says "answer slot", the answer is Priya's to give in her own words, from her own experience.

| Tag | Type | What it scores |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows the behavior the question names |
| EXP | Experience deep-dive | Whether her claims survive scrutiny, and what she actually did |
| JD | Role / JD-driven | Whether she can do the listed job, gaps included |
| CO | Company and strategy | Whether she thinks at Northwind's altitude, using its own terms |
| CASE | Live problem | Structure and reasoning on a problem from the role |

**Evidence sources in this pack.** "The coach's notes" means your message: her background, the JD highlights, Dan's profile and your research note. No CV, full JD or Priya's own sentences were provided, so every quote below is from the coach's notes. Confidence grades those notes. Nothing is yet confirmed in Priya's own words.

## 1. Prep triage

Omitted. No prep time was stated.

## 2. Fit snapshot

Requirements are the JD highlights from your message. The full JD was not supplied, so the requirement cells quote the highlights only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | medium | [grounded] | transferability | The notes say product strategy and ops, not GTM strategy for a product line, so the bridge stays at that scope: "Nine years in product strategy and ops at a large consumer-tech company." Answer slot: the JD asks for GTM strategy for two new product lines. If you set go-to-market direction for any product, say which product and what you decided. If you did not, say so and say what your product strategy work covered. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | low | [inferred] | discovery | The quote is about revenue modelling, not the four lifecycle stages. The bridge is this pack's reading, not a claim about her. Answer slot: if you mapped where revenue was won or lost by lifecycle stage, say what the stages were and what you found. If you did not, say so and say how you would start. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (the coach's notes) | low | [grounded] | discovery | The notes say skilled, not that she ran analysis to a conclusion. Answer slot: if you have run an analysis yourself in SQL or Tableau, say what it answered and what it did not. If you have not, say so and say what you would build first. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | medium | [grounded] | transferability | At its own scope: a partner-level model, built and used in carrier negotiations. The limit is this pack's observation: the material shows partner economics modelled, not a partner motion designed and run. Answer slot: if you shaped how partners were engaged, not only how their economics were modelled, say what and how you decided. If the model was an input and the motion was not yours to design, say so, and say what partner-economics knowledge you would bring to the design. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (the coach's notes) | medium | [grounded] | presentation | Reword only the quote: "I set annual volume targets with cross-org consensus." It adds no practice. The sentence says consensus, not influence, so expect a probe on whether anyone resisted. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (the coach's notes) | low | [grounded] | presentation | Reword only the quote: "I use AI tools daily." It adds no practice. The plus item is likely to come up casually. |
| F7 | Impact evidence (no JD line; the figure Dan's profile makes most likely to be tested) | "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | medium | [grounded] | none | No requirement gap. This row is the figure the interview will test. Say it at its scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Attribution and counting are the risk. Rehearse the slots in A1 to A3. |
| F8 | Sales-ops and quota-setting experience (no JD line; the sales-side world Dan works in) | "No classic sales-ops or quota-setting experience" (the coach's notes) | none | [grounded] | discovery | The notes state the absence; Priya has not stated it herself. The pack's observation: the material does not show quota-setting or sales-ops work. Answer slot: if you have set or been held to a target of any kind, say what it was and how it was agreed. If not, say so and say what you would check first. If Priya herself says she has no such experience, this row becomes a plain acknowledgment with gap type capability (see the upgrade menu). |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own GTM strategy for two new product lines | F1, A5, D2, C2 |
| Whitespace across land/adopt/expand/renew | F2, C1 |
| Independent analysis in SQL and Tableau | F3, A5 |
| Partner-motion design experience required | F4, A4, B3, C3 |
| Strong cross-functional influence | F5, B2, E1 |
| AI experience a plus | F6, F2 (bank F, question F2) |
| No JD line: sales-side planning and quota-setting | F8, D1, E1 |

## 3. Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. None may be coached in any cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the partner motion | Inflated form of F4 | F4's quote at its own scope. The pack's observation: the material shows a model built and used, not a motion designed. |
| Drove the $400M ARR | Inflated form of F7 | "proposed a store-surface change credited with a ~$400M ARR uplift." The pack's observation: the material says proposed and credited with, not drove. |
| Set quotas | Inflated form of F5 and F8 | "set annual volume targets with cross-org consensus," at its scope. The word quota does not appear in her material. |
| Ran independent analysis end to end in SQL and Tableau | Inflated form of F3 | "skilled in SQL/Tableau," at its scope. |
| Expert in AI | Inflated form of F6 | "uses AI tools daily." |

## 4. Reading the interviewer

**Source:** the coach's notes only. A public-footprint search for Dan Kovac was refused (see Sources), so nothing here is verified against his public record.

- **Career pattern:** a pricing and monetization spine, with one early-stage-startup chapter. He is Director of Sales Strategy at Northwind.
- **Self-description:** "relentlessly data-driven."
- **Practical implications:**
  1. Expect every number Priya gives to be probed to its assumptions. The $400M figure will be the first target (A1 to A3).
  2. Tilt case and metric answers toward pricing, packaging and unit economics. That is his native language (C1).
  3. The startup chapter means builder stories land with him. Expect a scrappiness probe on big-company pace. Priya has no startup chapter, so she should not claim one.
  4. As a peer, he will test the seam between his team and hers: what each side needs from the other (B1, B3).
- **Mirror opportunities:** none offered. Priya has no startup chapter, so there is no shared professional jump. Shared vocabulary exists only in the word revenue; F4 is the one sentence to lead with on pricing ground.

## 5. Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (bank A) | Asks for denominators, counts and assumptions, two levels deep | Highest. Relationship prior for a peer, and his self-description raises it | Know how each figure was counted, or say you do not. Name the weakest assumption first. |
| Peer Evaluator (bank B) | Seam questions, credit-sharing, what she needs from his team | High. Peer prior | Propose seam principles rather than pretending to know the seam. Reciprocity: what she brings his team. |
| Case / Strategist (bank C) | Live whitespace and pricing problems on the role's own terms | Medium. The JD's whitespace and GTM items, tilted toward pricing by his career | Clarify, then segment by lifecycle stage, then test pricing and unit economics, then name the metric |
| Skeptic (bank D) | Quiet probing of the sales-side gap and the motivation for the move | Medium-high. The sales-side gap is the most predictable objection | Rehearse D1 until it is plain. Calibrated candor over bluffing. |
| Pressure (bank E) | Time-boxed challenges to the $400M figure and to the hold on "set targets" | Low-medium. Peer rounds rarely press this hard, but a data-driven peer may | Hold through two follow-ups. Concede specific uncertainty, never the core claim. |
| Conversational (bank F) | A friendly opener and a casual AI question | Medium. Casual questions still score | A 90-second arc from her two career sentences. Treat the AI question as scored. |
| Values / Behavioral (bank G) | A pointed question about truths to leadership or customers | Low. No values-style round is established for a single peer conversation | Selection scaffold, with the honest "none" branch |

**Weights:** A 5, B 4, C 3, D 3, E 2, F 2, G 2. Total 21.

## 6. Question banks

Provenance quotes are exact copies of the fit snapshot's evidence cells. Question-type tags are the type key's. Questions written as answer slots carry no question mark. They are instructions for the interview.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the $400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Start from the sentence as written: proposed, credited with. Then answer the defend-the-number slots in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you know how it was counted, say so in those terms. If you do not, say so plainly and say who would know. Do not give a method you cannot repeat. | F7 is the most probed figure in the pack. Dan's self-description makes a counting probe near-certain. EXP because it tests attribution. |
| A2 | "Which assumption behind that uplift would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | The weakest-assumption move: name the one you would defend least before he does, in your own words. The pack names no assumption, because no quote does. Answer slot: if you know one, name it. If none comes to mind, say so, and say what you would test first. | A metric-probe move. Converts a gotcha into a credibility gain. |
| A3 | "Of that uplift, what part was actually yours?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Hold at proposed and credited with. Answer slot: if you led the decision, say so. If you proposed and others decided, say that plainly. Hold through two follow-ups by returning to the proposal, never by adding to it. | The attribution probe. The point is to say the proposal was hers without inflating it to ownership. |
| A4 | "Walk me through how the partner-level revenue model was built, and what it was sensitive to." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Say what the model was for, at its own scope: built, used in carrier negotiations. Answer slot: if the inputs were yours to set, say which and how you decided. If they were not, say so. A bring-the-model answer is strongest if she can show it, anonymised. | F4's most useful test, and the one artifact that could raise its confidence. |
| A5 | "What analysis in SQL or Tableau would you walk through in the room, and what was its denominator?" | JD, EXP | [grounded] "skilled in SQL/Tableau" (the coach's notes) | Open prompt, theme from the JD's SQL and Tableau line. Pick one analysis she ran herself. Say what it answered and what it did not. Answer slot: if none comes to mind, say so, and say what she would build first. | F3 is the thin row a prober reaches first. The denominator probe is the one Dan will ask. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] persona stem | Propose seam principles rather than claiming to know the seam: who decides what the sales plan assumes about product, and how disagreements get settled. Then give reciprocity: what she brings his team. This cell makes no claim about her past. | The peer prior. Seam probes come collegially. |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Use the sentence as the story: targets set with consensus across the organization. Say what the consensus rested on. Answer slot: if a moment was contested, say what held it. If it was not contested, say so and say what each side brought. | F5. Credit-sharing is a standard peer probe, and the sentence carries shared credit. |
| B3 | "Partner-motion design touches sales strategy. What would you need to know from our side before proposing one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | State the model's scope in her words: built, used in carrier negotiations. Then name what she would need from his side before proposing a motion: partner terms, account ownership, what sales already commits. The question presupposes nothing about her past. | F4. This is how she turns a gap into a seam conversation. |
| B4 | "Where has a go-to-market plan broken between product and sales, and what would you have changed?" | VAL | [generic] persona stem | Open prompt. Name a break she has seen, or say none comes to mind and describe what she would check first. The pack supplies no event. | Peer seam probe in a form that tests judgment, not history. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A new product line has strong trial sign-ups and weak expansion. Where is the whitespace, and what do you check first?" | CASE | [generic] live problem | Clarify the objective. Segment by land, adopt, expand and renew. Check pricing, packaging and unit economics before anything else. Name the metric for each stage and its denominator. Name one risk. This is a live problem and makes no claim about her past. | JD whitespace requirement. Pricing tilt from the interviewer read. |
| C2 | "Northwind has three stated priorities: enterprise expansion, the Compass AI copilot, and reaching profitability. Which one does this role depend on most, and what would you trade away for it?" | CO | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), reaching profitability" (your research note) | Use Northwind's own terms. Take a position. Name the trade. Caveat: the list is from your research note and was not checked against a current source, because search was refused. Say the priorities in your words, not as a recited list. | CO is required, and the research is the only source for it. Unverified, so it stays conditional on the upgrade. |
| C3 | "The biggest threat is a much larger platform vendor bundling. How would a new product line compete against a bundle?" | CO, JD | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | Take a position: differentiate, or partner. The partner option links to F4. Name what you would not know about the bundle's pricing, and say so specifically. Hold the position through two follow-ups. | CO on the competitive frame, with the partner-motion requirement built in. |

### D. Skeptic (weight 3). Highest-ROI prep in this pack.

**The highest-ROI prep is D1.** A sales-side gap is the most predictable objection to this candidate. It will come in some form. Rehearse D1 with four follow-up levels until a non-defensive answer is plain. A1 to A3 are a close second, because Dan is a prober.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role's sales-side planning would you have the least direct history with on day one?" | JD | [generic] persona stem | Name the thinnest part of your sales-side experience in your own words. Use the nearest thing your material carries: "set annual volume targets with cross-org consensus," at its own scope. Answer slot: if the part is quota-setting or sales ops, say so plainly and say what you would learn first. Hold through two follow-ups. Concede the gap specifically. Never claim the experience. | F8. Motivation and honest self-assessment. The most likely objection, so the deepest rehearsal. |
| D2 | "Your background is strategy consulting and consumer tech. Why would a go-to-market role be a step you would defend?" | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | Name the two sentences' work at their scope. Say what she would bring to go-to-market, and say what she would have to learn. Do not claim sales experience. | Motivation consistency. The two sentences are the whole arc. |
| D3 | "What from consumer tech would survive a B2B data-infrastructure sales motion, and what would not?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | Name one thing that transfers and one that does not, at its own scope. Answer slot: if you have no view on what survives, say so and say what you would test first. | F1 and the transferability gap. Honest limits score well here. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should this role be yours over someone who has run a sales plan?" | JD | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Pause. Restate the question. Hold at the sentence's scope, and concede specifically: if others have more direct sales planning, say so, then say what she brings. | F5 and F8 under time pressure. Hold, then concede specifically. |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Hold at proposed and credited with through two follow-ups. Concede the uncertainty about attribution specifically. Never fold on the proposal itself. | The pressure version of the attribution probe. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | A 90-second arc from the two career sentences, nothing else. | An opener is scored. Keep it to what is quoted. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (the coach's notes) | Name the tools, and what she uses them for, in her own words. Do not say expert. Answer slot: if she has built anything with them, say what. If not, say that she uses them. | The JD's AI plus item, asked casually. Treat it as scored. |

### G. Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] persona stem | Selection scaffold: pick a time she held a position against senior pressure, with a named stake, a moment she did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly. The nearest thing her material carries, the consensus-setting sentence, does not show an unpopular truth, so do not use it as one. | No values-style round is established. Touched so the pack covers the persona. |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] persona stem | Selection scaffold, with the same honest branch. The material shows no such time. Say so if it holds, and do not supply an ending. | Covers the persona. Low weight. |

Bank count: 21 questions. Coverage is complete against the requirements table above.

## 7. Reverse questions

Each has a "why it lands." At least one ties to his path, and one is reciprocity.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your work has been pricing and monetization. How does that shape the way you would test a new product line's plan?" | Ties to his own path without presupposing a move. Turns the interview into a peer conversation about method. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, as a peer. Shows she is thinking about his load, not only her own. |
| R3 | "Where does the sales-strategy plan most often disagree with product's numbers?" | Asks about the seam directly. Shows she knows the seam exists. |
| R4 | "Which of the three priorities, enterprise expansion, Compass or profitability, is this team most accountable for?" | Shows she has read the priorities and wants to place her role inside them. |
| R5 | "How would you know, six months in, that the bundling threat is being answered?" | Puts the competitive frame in a measurable form, the kind a data-driven peer will answer. |

## 8. Sources

**Provided documents:** the coach's notes, which are your message. They cover Priya's background, the JD highlights, Dan's profile and your research note on Northwind's priorities and threat. No CV, full JD or Priya's own sentences were provided.

**Searches sent:**
- "Northwind Data strategy Compass AI copilot enterprise expansion profitability": refused (permission not granted).
- "\"Dan Kovac\" Northwind Data Director Sales Strategy": refused (permission not granted).

**Fetches:** none sent.

**Research tier: L1, searches 2 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | skipped | A single peer conversation with no loop source documenting values establishes no values-style round, so section 10 is omitted. No search could change the output. |
| 2. Interview process, role family | skipped | Your message establishes the loop: one 60-minute conversation with Dan. No search could change the output. |
| 3. Northwind strategy / recent news | unavailable | Refused. Would have checked C2 and C3 against a current source, and sharpened the Compass and bundling framing. Those rows rest on your research note, unverified. |
| 4. Dan Kovac, Northwind | unavailable | Refused. Would have read his public footprint into the persona weights, the interviewer read, and R1. The read rests on your profile alone. |
| 5. Representative JD | skipped | JD highlights were supplied. |

## 9. Upgrade menu

- **The full JD text** → the requirement cells quote the posting's own lines instead of your highlights, and any requirement the highlights omit gets its own row.
- **Priya's CV, or her own sentences about her work** → evidence quotes become "your CV", and each medium row can be confirmed in her words.
- **Whether Priya herself says she has no sales-ops or quota-setting experience** → F8 becomes a plain acknowledgment with gap type capability, and D1 and E1 use her words.
- **The carrier revenue model, anonymised, and the readout behind the $400M figure** → F4 and F7 move toward high confidence, because each is an inspectable artifact.
- **Web search permission** → reruns targets 3 and 4. Checks C2 and C3 against a current source and reads Dan's public footprint into the reverse questions and persona weights.
- **Any public talks or writing by Dan** → recurring themes become questions in the banks.
- **Deep research (L2), offered once:** up to 6 more searches and 2 more fetches, several minutes. Adds a strategy brief, his public talks and writing, role-family loop reports, and recent org context. Want it?
