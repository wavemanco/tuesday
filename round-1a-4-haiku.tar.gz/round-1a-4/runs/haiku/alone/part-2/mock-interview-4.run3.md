Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-4-denied-465f03f8/6322e773-0783-4736-a7e5-f089e4f76dbc/scratchpad/quartzline_platform-apis-pm_interview_pack.md`. I built it for a 45-minute hiring-manager round from your dossier.

Three things to know before Thursday:

- **Your objection is A1.** It's the dossier's "never held the PM title or owned a roadmap" question. The pack gives it the deepest rehearsal: open with the limit, hold through two follow-ups on what the integration work shows, then concede the roadmap gap and give a ramp plan.
- **The company research didn't run.** The web searches were refused for lack of permission, so the pack has no Quartzline values, interview loop or strategy. The question banks are built on the hiring-manager pattern instead, and the file says so.
- **Two things differ from the dossier.** It's dated 14 August, so confirm the JD hasn't changed. Also, "seven years of integration leadership" isn't in any verified entry, so the pack doesn't use that figure. I also classed R2 (shipped API products) as a transferability gap, which the dossier doesn't list, so it's worth checking with whoever wrote the dossier.

Want me to play the Skeptic on A1 so you can rehearse it out loud? I can also save a `tuesday-dossier.md` with the gaps this prep exposed, and convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_platform-apis-pm_interview_pack.md -----
# Interview prep: Product Manager, Platform APIs at Quartzline

Round: hiring-manager conversation, 45 minutes, Thursday 26 November 2026.
Interviewer: not named. Built from `tuesday-dossier.md` (decision: conditional_go, dossier version 1.1, dated 14 August 2026).
Changelog: first version.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored:

- **VAL**: behavioural and values alignment
- **EXP**: deep-dive on your own experience and what you actually did
- **JD**: the listed responsibilities and qualifications, including the gaps
- **CO**: company and strategy knowledge (not built, see Sources)
- **CASE**: a live problem from the role

Guidance is scaffolding for a spoken answer, not a script. Evidence keys: **V1**, **V2**, **V3** are the dossier's `verified_candidate_evidence` entries 1 to 3, in the order the dossier lists them. Quoted text is the dossier's wording.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | low | [inferred] | transferability | The bridge is the underwriter's derivation from V1 and V3, at their own scope. The limit is that no entry shows product-management years. Words for that limit: "I haven't held a product manager title or role." Give the years of integration work in your own figure, not a product-management figure. |
| F2 | "Owning a roadmap and prioritization authority" — dossier uncertain_or_weak_areas, R1 sub-claim | none given. V3 is roadmap-adjacent input, not ownership | none | [grounded], the negative is the dossier's prohibited_claims item | capability | Acknowledgment only, named by its field: "I haven't owned a product roadmap." No bridge. V3 is about input, not ownership, so it does not answer this row. Say how you would learn ownership, as a plan. |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs" — dossier V1 | high | [inferred] | transferability | V1 is API work at its own scope. The material does not show whether a product was shipped, or whether you shaped the API itself. This classification is this pack's reading. The dossier does not list R2 as a weak area, so it is flagged for the underwriter. Answer slot: if you shaped any part of the API surface, say which and how; if you did not, say so and stay with the integrations. |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Wrote the internal integration playbook her team uses" — dossier V2 | high | [inferred] | discovery | V2 touches documentation but does not show API docs or schemas. Answer slot: if you wrote or reviewed API docs or schemas, name them; if you did not, say so and name the playbook as what you did write. |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs" — dossier V1 (customers); "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 (product). Medium confidence on V3: confirmed, limited inspectable proof, expect a probe | medium | [grounded], caveat visible: V3 is the seam a prober will find | discovery | Customers and product are shown. Engineering and sales are not. Answer slot: if you worked with engineering or sales on an integration, name who and how; if not, say so and stay with the clients and product you dealt with. |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [inferred] | discovery | Clarify strategy, dossier uncertain_or_weak_areas. No verified entry speaks to it. Probe slot in A5. |
| F7 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given. V1's go-live is a milestone, not an adoption measure | none | [inferred] | discovery | Silence, not a negative, so no plain acknowledgment. Answer slot: if you tracked anything after go-live, say what; if you did not, say so and say what you would start with. |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | V1 reaches requirements, not squads. Answer slot: if you have worked with engineering teams building what you specified, name which; if not, say so. Squad decision rights are an open risk, not a claim (see B1). |

Gate rows: none. The dossier records no hard gates and no severe red flags.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier prohibited_claims, named by field | "I haven't held a product manager title or role." No answer slot. |
| Having owned a product roadmap | dossier prohibited_claims, named by field (also F2) | "I haven't owned a product roadmap." No answer slot on ownership. |
| Having set prioritization for an engineering squad | dossier prohibited_claims, named by field | "I haven't set prioritization for an engineering squad." No answer slot. |
| Shipped API or platform products | inflated form of V1 (R2) | V1 at its own scope. The limit is the pack's observation, not words for you: the material shows integrations, not a shipped product. |
| Seven years of integration leadership | inflated form: the dossier decision prose, which no verified entry carries | No tenure figure in your words. Use your own figure for the years of integration work. |

## Interviewer read

Not built: no interviewer name was given, so there is no public footprint to read.

## Persona table

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Skeptic | The PM-title gap, roadmap ownership, day-one weakness | 5 (depth 5). The hiring-manager prior is Case and Skeptic. The dossier names the objection, so the Skeptic is weighted highest | Hold the core, concede the gap plainly, give a ramp plan (A1, A2) |
| Case / Strategist | Live roadmap problems: squad decision rights, low adoption, adoption definition | 5 (depth 5). The hiring-manager prior: they expect live problems on their roadmap | Clarify who decides first, then structure (B1 to B5) |
| Data-Driven Prober | The 30+ count, adoption counts, the client-evidence seam | 4 (depth 4). Adoption is a JD responsibility with no evidence in the material | Name the weakest assumption; say what was not counted (C1 to C4) |
| Pressure | Title challenge, "how much was actually you" | 2 (depth 2). Sharpened by the objection's wording | Hold through two follow-ups, then concede precisely (D1, D2) |
| Conversational | Opener, the journey, API docs | 2 (depth 2). Casual questions are scored | A 90-second arc; the limit said once at its end (E1, E2) |

Weights are the relationship prior, not a company-specific loop. No loop source was established (see Sources), so the loop is a generic fallback and the weights are flat within the hiring-manager prior, stated plainly.

## Question banks

Questions run 18 in total. Each row shows its Provenance before its guidance.

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD (EXP delivery) | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; the negatives from dossier prohibited_claims | **Highest-ROI rehearsal in this pack. Named by the underwriter.** Open with the limit: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Then the quotes, at their own scope. Concede plainly: a PM with three years of the job has roadmap practice you do not have. Say how you would close that in the first months, as a plan, not a past. Hold through two follow-ups by returning to what V1 and V3 show. Do not add to either. | F1 and F2 are the rows this objection presses hardest. The underwriter derived this objection from evidence you confirmed. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] dossier prohibited_claims, "Having owned a product roadmap" | Name roadmap ownership first and in the plain words: "I haven't owned a product roadmap." Then decision rights with the squad leads, as a question you would settle first. Then the ramp plan. No bridge on ownership. | Skeptic stem. Covers F2 and F8. |
| A3 | "What part of product work have you done yourself, and what only sat beside it?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Say what the sessions were: client evidence to product, in those words. Say what product did with it only if you saw it. Answer slot: if you saw what product decided from the evidence, say so; if you did not, say so. | F5 and V3's medium confidence. The seam is where a prober looks. |
| A4 | "Your JD asks for three years of product management. How many years of that work do you have?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Give your own figure for the years of integration work. Claim no product-management years. The limit is R1's, and it is a plain statement, not a bridge. | F1. The question premise is the JD's line, which is a raising source. |
| A5 | "How have you run delivery on a sprint cadence?" | JD | [grounded] dossier role_profile R5, "Agile delivery experience". No candidate sentence carries it | Clarify. If you ran delivery against sprints, say how, in your own words. If you never worked that way, say so, then say what you would want to confirm about how this team defines agile delivery. | F6, clarify strategy. Nothing about your past goes in except what you say. |

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two squads want different things from the same partner API this quarter. Walk me through how you'd decide." | CASE | [generic] | Before choosing, ask who decides: "I'd want to know which of these calls are mine and which sit with the squad leads." Then objective, partner segments, approach, metrics, and risks, in that order. Say the framework aloud once. | Tests the squad decision-rights risk the dossier lists as unverified. F4 and F8. |
| B2 | "A partner integration went live last quarter and almost nobody uses it. Diagnose it." | CASE | [generic] | Ask what adoption was measured against: the baseline. Then structure the diagnosis. Make no claim about any integration you have run. | F7 and the dossier's unanswered adoption-baseline question. |
| B3 | "How would you define adoption for a new endpoint family?" | JD | [generic] | Name the baseline you would need first and the weakest assumption in the definition. | F7 is a JD responsibility with no evidence in the material. |
| B4 | "Walk me through how you'd run discovery with an integration partner you've never worked with." | JD | [grounded] "scoping, requirements, architecture, UAT, go-live" from dossier V1 | Tell the scoping and requirements steps from V1 in your own words. Describe partner discovery as the method you would apply, labelled that way. | JD responsibility; V1 is the nearest evidence. |
| B5 | "Which spec would you write first for a new partner capability, and what would you leave out?" | CASE | [grounded] "requirements" from dossier V1 | Structure the answer. If you have written requirements for an integration, say which; if spec work of this kind is new to you, say so. | F8. |

### Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was adoption counted on the integrations you led?" | EXP | [grounded] "go-live" from dossier V1 | Answer slot: if you counted anything after go-live, say what and how; if nothing was counted, say so and say what you would start counting. The question presupposes a count, so the second branch must stay open. | F7. |
| C2 | "Thirty-plus integrations: which of those would you defend least, and why?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" from dossier V1 | Name the weakest assumption in the count, in your own words: what counts as one integration. Keep the number attached to its noun, integrations, not clients. Also the rehearsal for the R2 probe (F3): this count is the most likely place it comes back. | Headline number; defend-the-number. |
| C3 | "What happened to the client evidence after it reached product?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" from dossier V3 | Say what you sent. Say what product did with it only if you saw that. Answer slot: if you saw the decision, say so; if you did not, say so. | V3 is medium confidence; expect the probe. |
| C4 | "How would you know six months after launch that a partner API is working?" | JD | [generic] | Name the baseline you would need, then the weakest assumption in the measure. | Adoption measure; the dossier's baseline risk. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we give this role to someone without the title?" | EXP | [generic] | Do not argue the title. Name what you bring from V1 and V3, at their own scope. Hold through two follow-ups. Never claim the title. | Pressure register on the same objection as A1. |
| D2 | "That integration count — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" from dossier V1 | Hold what you led: name the parts you ran. Concede the team's share plainly. Do not fold on the part you led. | Hold-then-concede. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | VAL-adjacent (EXP) | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc: integrations (V1), the playbook (V2), roadmap input (V3). Name the limit once, at the end: "I haven't held a product manager title or role." | Casual openers are scored. |
| E2 | "What are you working with in API docs and schemas these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" from dossier V2 | Answer slot: if you have written or reviewed API docs or schemas, name them; if not, say so and name the playbook as what you did write. | F4. |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1 3+ years product management | A1, A4, D1 |
| R1 sub-claim: roadmap ownership and prioritization | A1, A2, A3 |
| R2 shipped API or platform products | C2, D2. The shipped-product probe is F3's answer slot, which C2 guidance carries |
| R3 API docs and schemas | E2 |
| R4 stakeholder management | A3, B1, C3 |
| R5 agile delivery | A5 |
| Adoption metrics (JD responsibility) | B2, B3, C1, C4 |
| Squad decision rights (JD responsibility) | B1, A2 |
| Partner discovery (JD responsibility) | B4 |
| Specs and delivery with two squads (JD responsibility) | B5, A2 |

## Reverse questions

Each has a "why it lands". The first two are the dossier's unresolved risks, written from their own hypotheses.

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** Why it lands: the decision-authority risk is asserted in the JD and not evidenced. This question is diligence, and it answers something you need to know before accepting.
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: adoption is a named responsibility with no stated baseline. The answer shows you what a first 90 days would be measured against.
3. **"How do partners give roadmap input today, and what happens to it after that?"** Why it lands: the input you have done is V3's work. This shows where input is decided.
4. **"What would the first 90 days need to produce for the squad leads and this role together?"** Why it lands: it makes the success definition visible before you are measured against it.
5. **"What would make you say in six months that hiring someone without the PM title was the right call?"** Why it lands: it turns the central objection into criteria you can meet, and it makes the hiring manager name the bar.

## Sources

- **Provided document:** `tuesday-dossier.md`, consumed in these sections: `role_profile` (requirements, responsibilities, unknowns); `handoff_to_mock_interview` (all: verified evidence, weak areas and their strategies, the likely objection, risks, employer questions, prohibited claims); `decision` (context only). The decision prose's "seven years of integration leadership" is not in any verified entry, so it is not used as a claim.
- **Dossier age:** dated 14 August 2026, three months before this pack. Confirm the stage and that the JD has not changed. If it has, the fit snapshot regenerates.
- **Research:** three L1 searches were sent: "Quartzline values", "Quartzline interview process product manager platform APIs", and "Quartzline strategy recent news". All three were refused by the host (WebSearch permission not granted), so no results came back.
- **Research tier:** L1, searches 0 returned (3 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet not built. No values-style round is detected, so none was required |
| 2. Quartzline interview process, product role family | unavailable | Loop not established. Persona weights are the relationship prior, stated as generic, not this company's documented process |
| 3. Quartzline strategy and recent news | unavailable | No CO questions. Company-strategy fluency is absent from the banks |
| 4. Interviewer name and Quartzline | n/a | No name given, so there was no query to form |
| 5. Representative Product Manager, Platform APIs JD | skipped | The dossier's `role_profile` fixes the requirements |

## Upgrade menu

- Your own account of the integration work, or your CV → turns V1 to V3 from the dossier's wording into your sentences; upgrades the F4 and F5 slots.
- The current JD text → confirms that the eight rows still match the posting; if the wording changed, F1 to F8 regenerate.
- The interviewer's name → their public footprint; re-weights the personas and adds a tailored reverse question.
- A recruiter email naming the round's agenda or focus areas → checks the coverage of the question banks against it.
- Permission to retry the research searches → fills the values, loop and strategy lines this pack could not establish.
