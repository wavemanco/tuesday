Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-3-denied-353b0f06/4a5dfe28-5d4b-4a05-bfc5-3496c4dcd4c9/scratchpad/stripe_product-operations-manager_interview_pack.md`. You haven't shared a job description, CV or interviewer details, so this version is a generic worksheet. It assumes a single final-round session with flat persona weights. It has 19 practice questions across seven interviewer styles, plus reverse questions to ask them. Nothing about Stripe's values or current strategy is in it, because I haven't researched those yet.

Want a live drill? I can play the pressure interviewer on question E1, the "sixty seconds, why you" question. I can also save a dossier file of the gaps this prep exposed, or convert the pack to Word if you'd like that.

Two questions would change the pack most:

1. Who are you meeting, and what's their role relative to yours (hiring manager, peer, skip-level, cross-functional)? Is the final one session or several, and has the recruiter named a take-home or presentation?
2. Could you paste the job description and your CV, or a few lines per role with the numbers you'd stand behind? If you'd rather not, I'll keep going with the generic version.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe, Product Operations Manager: final-round prep pack (version 1)

**Role:** Product Operations Manager
**Company:** Stripe
**Interviewer:** not given
**Round:** final round, relationship to you unknown, session count unknown

This version is built without a job description, a CV, interviewer details or research. Every requirement below is role-family generic, no evidence is quoted, and persona weights are flat. It works as a worksheet until you add the inputs in the upgrade menu.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral and values alignment. **EXP** your experience, tested for accuracy. **JD** the role's stated responsibilities. **CO** company and strategy knowledge. **CASE** a live problem to solve out loud.
- Guidance is scaffolding, not a script. Each answer should run about 90 to 120 seconds spoken.
- Sections not in this version: prep triage (prep time unknown), graded deliverables (none declared), grounding brief and values cheat sheet (no research run), interviewer read (no interviewer named). Each one's input is in the upgrade menu.

## Fit snapshot

No evidence is quoted in this version. Each row names a generic role-family requirement, which is not a quote from a posting. Gap type is `discovery` throughout, because the material is silent rather than showing a gap. The bridge column says what strong evidence looks like, then gives a selection scaffold that ends in an honest branch.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Runs a recurring operating cadence that several teams depend on (role family, unquoted) | none given | none | [generic] | discovery | Strong evidence: a planning or review cadence you ran or took part in, with its inputs, outputs and the people who relied on it. Selection scaffold: pick one recurring review or planning process; say what it decided and who depended on it. If you have none, say so, then say how you would set one up |
| F2 | Defines, builds and maintains metrics and dashboards for an area (role family, unquoted) | none given | none | [generic] | discovery | Strong evidence: a metric you defined, with its definition, source and owner. Selection scaffold: pick one metric you defined or maintained; say how it was defined and where the data came from. If you have none, say so, then name the measure you would define first |
| F3 | Makes and unblocks cross-team prioritization decisions (role family, unquoted) | none given | none | [generic] | discovery | Strong evidence: a decision between competing teams, with who decided and what happened. Selection scaffold: pick a time two teams wanted the same thing; say how it was settled. If none comes to mind, say so, then say how you would decide it |
| F4 | Diagnoses unexpected changes in performance (role family, unquoted) | none given | none | [generic] | discovery | Strong evidence: a metric change you traced to a cause. Selection scaffold: pick one unexplained change; say what you checked first and what you ruled out. If none, say so, then give your approach |
| F5 | Judges whether a claimed result is real (role family, unquoted) | none given | none | [generic] | discovery | Strong evidence: a claim you tested, with the comparison you used. Selection scaffold: pick a result someone claimed; say how you checked it. If none, say so, then give your approach |
| F6 | Coordinates launches and rollouts across functions (role family, unquoted) | none given | none | [generic] | discovery | Strong evidence: a launch you coordinated, with who was involved and what readiness meant. Selection scaffold: pick a launch or rollout; say what you owned and what others owned. If none, say so, then give your approach |
| F7 | Communicates tradeoffs and bad news to senior leaders (role family, unquoted) | none given | none | [generic] | discovery | Strong evidence: a message to leadership you wrote or delivered, and the decision it changed. Selection scaffold: pick a time you had to tell leadership something they did not want to hear; say how you said it. If none, say so, then say how you would frame it |
| F8 | Learns a new domain quickly and names its own gaps (role family, unquoted) | none given | none | [generic] | discovery | Strong evidence: an area you learned fast, with how you learned it. Selection scaffold: name one area you had to learn; say how. Name one area you still need to learn, and how you would start |

## Prohibited claims

No entries in this version. The pack has no sentence of yours to stretch, and you have not stated any negatives. Its guidance coaches no claim about your experience, so nothing is prohibited yet. This list fills when a CV or message arrives.

## Persona weights

No relationship is known, so the weights are flat priors for a final round. Every persona is covered at the depth the weight gives.

| Persona | How it shows up here | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Live operating problems: diagnose, prioritize, design a cadence | Top, 4 questions | Product-ops roles are scored on structured diagnosis, and final rounds often include a live problem | Clarify, then structure, then answer. Think aloud and name your first check |
| Data-Driven Prober | Asks how a number was counted and what it is sensitive to | 3 questions | Ops roles are judged on whether their metrics survive scrutiny | Name the weakest assumption before they do. Say plainly what you do not know |
| Values / Behavioral | Scenario questions about truth, customers and collaboration | 3 questions | A final round often ends with a behavioral read. Published values are not yet known, so the stems are generic | Use "we" for context and "I" for your part. Choose a story where the hard part is real |
| Skeptic | Quiet probing of gaps and motivation | 3 questions | Every gap row above is a likely probe | Answer only from what you know you have. Give a plan for what you do not |
| Pressure / Stress | Interrupts and time-boxes answers | 2 questions | Tests composure under challenge | Pause, restate, anchor. Hold a position through two follow-ups before conceding anything |
| Peer Evaluator | Seams with adjacent teams, credit, disagreement | 2 questions | Ops roles sit between teams, so peer probes are likely | Propose seam principles rather than claiming to know theirs. Offer reciprocity |
| Conversational / Rapport | Opens with journey and interest questions | 2 questions | Casual questions are still scored | Keep a 90-second arc ready. Treat "what are you playing with lately" as a scored question |

## Question banks

### Case / Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product's weekly active usage dropped 20 percent over three weeks. Walk me through how you would diagnose it." | CASE | [generic] | Clarify the metric definition and the time window first. Split by segment, surface and recent release. Separate what changed in the product from what changed outside it. Name two or three hypotheses, the data that would confirm or kill each, and the first check you would run | Covers F4. Structured diagnosis is the core of the role, and this is a generic stem |
| A2 | "Two product teams want the same operations engineer next quarter. How do you decide?" | CASE | [generic] | Ask what each commitment protects and what delay costs. Ask whether the constraint is capacity or priority. Propose a decision rule, a tie-break owner and a time-boxed compromise. Say what you would escalate, and to whom | Covers F3. Cross-team prioritization is a generic stem for this role family |
| A3 | "You are asked to design the operating cadence for a new product area with six teams. Where do you start?" | CASE | [generic] | Start from the decisions the cadence must support. Map inputs, owners and decision forums. Keep the cadence minimal. Define the artifact each meeting produces. Plan a 60-day check on whether it is working | Covers F1 and F6. A design question with no claim about your past |
| A4 | "Which three metrics would you put on a dashboard for a new product in its first quarter, and why those three?" | CASE | [generic] | One leading metric, one adoption metric and one guardrail. Define each in one sentence. Say which decision each one supports | Covers F2. Shows whether you pick metrics for decisions rather than for display |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a metric you reported to leadership. How was it counted?" | EXP | [generic] | Open prompt: pick one metric you reported. Give its definition, its source and what it is sensitive to. Name the assumption you would defend least, and say which part of the figure was yours to set. If you reported no metric, say so, then describe the nearest measure you tracked and how you knew it was right | Covers F2 and F5. A probe on any number you cite will likely follow, so the defend-the-number slots apply to whatever you choose |
| B2 | "How would you know a process you set up is actually working?" | JD | [generic] | Name one leading signal and one lagging signal. Say what baseline you would capture first. Name the check that would show the process is failing even when its metrics look fine | Covers F1 and F2. Asks about method, not about a past event |
| B3 | "A launch team says its change lifted conversion. How would you test that claim?" | CASE | [generic] | Ask what else changed in the same window. Name the comparison group, the sample size and the time window. Name the confound you would check first | Covers F5. A live problem, so it presupposes nothing about you |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Open prompt. Pick a time you had evidence leadership did not want to hear. Say what you said, how you said it and what happened next. Use "we" for context and "I" for your contribution. If none comes to mind, say so plainly, then give the nearest one you have, or how you would handle it | Covers F7. A stem from the values persona. Published values are not yet known, so no value is mapped |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Open prompt. Pick one time a customer outcome and an internal number pointed different ways. Say which you chose, why, and what it cost. If none comes to mind, say so, then describe how you would decide | Covers F3 and F7. Tests judgment on a real tradeoff |
| C3 | "Tell me about a cross-team project that went sideways. What did you do in the first 48 hours?" | VAL | [generic] | Open prompt. Pick one project that slipped. Say what you did first, who you talked to and what you changed. If none comes to mind, say so, then say what you would do first | Covers F1 and F6. Tests coordination under pressure |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one skill area honestly, not a polished weakness. Say how you would close it in 30 days. Do not claim a skill you have not used | Covers F8. The likeliest skeptic probe, and it has no source to presuppose |
| D2 | "Which responsibilities of this role would you have to learn rather than already do?" | JD | [generic] | Answer only from what you know you have. Name the learning path for anything you do not. Name what you would ask a manager to hand you first | Covers F8. Asks the skeptic's question without assuming a gap in your record |
| D3 | "Why this role now, and not a bigger scope or a different function?" | EXP | [generic] | State the motivation in terms of the work. Keep it consistent with the reasons you would give anywhere else. If the reason is scope or pay, say it plainly | Motivation consistency, which a final round checks |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has already done this job?" | JD | [generic] | Pause, then restate the question. Anchor in one thing you can show. Hold the position through two follow-ups. If you concede a limit, do it in words you choose from your own experience, and do not fold on the core claim | Covers F7. The pressure stem itself; the composure is what is scored |
| E2 | "That answer sounds rehearsed. What did you actually do?" | EXP | [generic] | Answer with one concrete action from your own experience. If the answer was thin, say so and stop. Do not elaborate under pressure | Tests the honesty that the attribution rule of this pack exists for |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-P1 | "Our teams sit side by side. Where is the seam with yours, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than claiming to know theirs. Name what you would need from their team. Give one disagreement story, with spine and tact together | Covers F1 and F3. Peer probes come in collegial packaging |
| F-P2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Open prompt. Pick one time credit was shared. Say how it was decided. If none comes to mind, state your rule and say why | Covers F3. Tests attribution habits |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey." | EXP | [generic] | Keep a 90-second arc: one sentence per role on what you did there, then why this role now | Casual openers are scored for economy and interest |
| G2 | "What are you playing with in operations tooling these days?" | JD | [generic] | Name one tool or method you have actually used, and what you did with it. Do not name a tool you have not used | Casual questions about JD topics are scored |

## Coverage

Requirements F1 to F8 are generic, so coverage is against the role family, not a posting.

| Requirement | Questions |
|---|---|
| F1 operating cadence | A3, B2, F-P1 |
| F2 metrics and dashboards | A4, B1, B2 |
| F3 cross-team prioritization | A2, C2, F-P2, F-P1 |
| F4 diagnosing performance changes | A1 |
| F5 judging claimed results | B1, B3 |
| F6 launches and rollouts | A3, C3 |
| F7 leadership communication | C1, E1 |
| F8 learning a new domain | D1, D2 |
| Company knowledge (CO) | none, and why: no research was run, so no strategy question is grounded |

## Reverse questions

No interviewer profile exists, so none is tied to a career path. Each one is a question you can ask any interviewer.

1. "What does a strong first 90 days look like in this role?" Why it lands: it shows the scope they expect, and you can check your plan against it.
2. "Which decisions does this team make with the most friction today?" Why it lands: it shows you are thinking about the operating problem, not only the job description.
3. "How does this role work with product and engineering when they disagree about priorities?" Why it lands: it maps the seam, and the answer shapes how you present your own approach.
4. "What has the best person in this role done that you would want to see more of?" Why it lands: it signals that you would build on what works rather than reset it.
5. "How will success in this role be measured at the end of the first year?" Why it lands: the answer is the measure you will be judged against.
6. "What would you most want me to ask you that I have not asked?" Why it lands: it gives the interviewer a turn, and it is often where the real concern comes out.

## Sources

- Provided documents: the request text only.
- Research tier: L0, with no searches and no fetches. Deep research was not offered in a form you could consent to in this version; it is in the upgrade menu.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Values cheat sheet, and the VAL questions would map to published values |
| 2. `Stripe interview process product operations` | unavailable | Loop structure; persona weights would follow the named rounds |
| 3. `Stripe strategy` / recent news | unavailable | Company knowledge bank (CO), which has no questions in this version |
| 4. interviewer name | n/a | No name was given, so there was no query to form |
| 5. representative Product Operations Manager JD | unavailable | Would have turned F1 to F8 from generic to `[inferred]` quoted requirements |

## Upgrade menu

- A job description pasted in full → F1 to F8 become quoted requirements, and the JD-tagged questions are checked against the posting's own list
- A CV, or a few lines per role with the numbers you would stand behind → the evidence column fills, and the open prompts become story-mapped answers
- Who you are meeting and their relationship to you → persona weights are set, and the reverse questions are tuned
- Whether the final is one session or several, with the schedule → per-session mini-packs
- Any take-home or presentation the recruiter named → a build section for that deliverable
- Consent to research at the default tier (six searches, two page fetches) → Stripe's published values, the loop structure and current strategy: the values cheat sheet, the grounding brief and the CO questions
- An interviewer's name → an interviewer read and a reverse question tied to their path
- A dossier from the prep suite's underwriter → verified evidence, and the requirement mapping it grades
