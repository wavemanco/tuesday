Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-4-denied-331da2f7/70b821b9-ba91-4ab6-9811-c58959c35ece/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md. It is built on your dossier. I couldn't run any web research, because the search tool was not permitted here, so the pack has no company values, interview-loop structure or strategy. I didn't need to ask about the round: your dossier and note already say it's the hiring manager.

The most important prep is A1, the objection the dossier named. Open with the plain acknowledgment that you haven't held a PM title or owned a roadmap. Then state the nearest work at its real scope: you led 30+ client integrations from scoping to go-live, and you ran roadmap-input sessions. Finish with a ramp plan, stated as a plan. Hold the integration claim through two follow-ups, and concede the PM time specifically rather than folding on the work.

Two reverse questions carry your open risks: which roadmap decisions this PM makes alone versus the squad leads, and what the current partner-API adoption baseline is.

Would you like me to run the Skeptic on A1 with you now? I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep: Product Manager, Platform APIs, Quartzline

Round: 45-minute conversation with the hiring manager, Thursday 26 November 2026. Interviewer: not named. Built on your `tuesday-dossier.md` (decision: conditional_go). No live research ran (see Sources).

## How to use this pack

- **Personas** describe how a question will be asked. **Types** describe what is being scored: JD (the listed job), EXP (your experience), CASE (a live problem), CO (company), VAL (values).
- Guidance is scaffolding, not a script. Say it in your own words. Anything in quotation marks is your own material, quoted from your dossier.

## Prep triage (Tuesday to Thursday)

1. **A1, the likely objection.** Rehearse it aloud until the plain acknowledgment comes out flat and unapologetic. This is the highest-return block in the pack.
2. **F1, F2 and F6 (fit snapshot).** Learn the three quotes word for word, so your examples stay at their real scope.
3. **Reverse questions 1 and 2.** These test the two open risks in your dossier: decision authority and the adoption baseline.
4. **B2 and B1.** Practise the clarify-first habit on one case each.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [grounded] | transferability | Your material shows integration leadership on the vendor's APIs, from scoping to go-live. It does not show product management time. Say the work at its own scope and name the limit yourself. The dossier treats this as a transferability gap, not a capability gap. |
| F2 | "Shipped API or platform products" (dossier role_profile R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Wrote the internal integration playbook" — dossier V2 | medium | [grounded] | transferability | Integrating clients onto an API is adjacent to shipping an API product. Describe the integrations and the playbook as they happened. Do not describe a product release. Answer slot: if any part of an API product's release was yours to decide, say which and how you decided; if none was, say so plainly and stay with the integrations. |
| F3 | "Technical fluency: API docs, schemas" (dossier role_profile R3, important) | "Wrote the internal integration playbook" — dossier V2 | low | [grounded] | discovery | The playbook is your documentation evidence. Your material does not show whether it covered schemas. Answer slot: if it covered schemas or doc standards, say what it covered; if it did not, say so plainly and say what you would check first. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [grounded] | transferability | Your quotes reach clients and product. They do not reach engineering or sales. Answer slot: if you worked with an engineering team or sales on any of those integrations, say how and what you decided, in your own words; if you did not, say so plainly. |
| F5 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [grounded] | discovery | Your material is silent on agile delivery. Clarify strategy: answer slot on the requirement's own wording. If the interviewer asks how agile delivery worked for you and you have not worked that way, say so, and say what you would want to confirm about how they run it. |
| F6 | "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibilities; R1 sub-claim) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [grounded] | capability | The dossier records that you have not owned a roadmap or set prioritization for an engineering squad. Plain acknowledgment: "I haven't owned a product roadmap or set prioritization for an engineering squad." No answer slot here. Describe the roadmap-input sessions at their own scope, then give a ramp plan, stated as a plan. |

Gap types follow the routing rule in the output template. The dossier's evidence map was not in the handoff, so the grading of F2, F3, F4 and F5 is this pack's reading, and the confidence values for those rows are set here, not by the underwriter.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims, named by field | Plain acknowledgment: "I haven't held a product manager title or role." No slot. |
| Having owned a product roadmap | Dossier acknowledge_gap area (R1 sub-claim), named by field | Plain acknowledgment as F6. Roadmap-input sessions at their scope (V3). |
| Having set prioritization for an engineering squad | Dossier prohibited_claims and acknowledge_gap, named by field | Same as above. |
| Shipped API or platform products | Inflated form of F2: the R2 wording stretched over V1 and V2 | V1 and V2 at their own scope. The limit is this pack's observation, not words for you: your material says integrations and a playbook, not a shipped product. |
| Ran discovery with integration partners | Inflated form of the JD responsibility, stretched over V1's "scoping, requirements" | V1 at its own scope. The pack's observation: your material says scoping and requirements, not discovery programmes. |

## Persona table

Hiring manager relationship prior: Case/Strategist and Skeptic, because the hiring manager is buying capability and derisking gaps, and expects live problems on the real roadmap. The dossier's named objection moves the Skeptic weight up. No interviewer profile exists, so no adjustment from career pattern applies.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of the PM-title gap and the roadmap | High. The dossier names this exact objection as the likeliest. | Rehearse the objection until it is boring. Use the acknowledgment, the nearest quotes and a ramp plan. No slots on the roadmap gap. | 5 (A) |
| Case/Strategist | Live problem on the partner API roadmap or adoption | High. Hiring managers run live problems on their own roadmap. | Clarify before structuring. Say the question you would ask first. | 4 (B) |
| Data-Driven Prober | Asks how the 30+ figure was counted, and what the playbook's use was | Medium. The figure and the playbook are both headline-ish claims. | Defend-the-number answers from your own words. Say the weakest assumption before they do. | 3 (C) |
| Pressure | Time-boxed challenge to the PM gap or to "how much was you" | Medium. The dossier's weak areas invite it. | Pause, restate, hold the integration claim through two follow-ups, concede the authority question specifically. | 3 (D) |
| Conversational | Opener and a casual question on schemas | Low to medium. Casual questions are still scored. | A 90-second arc. Treat casual questions on the JD's terms as scored. | 3 (E) |

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] dossier V1 "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; dossier V3 "Ran quarterly roadmap-input sessions feeding client evidence to product"; the negatives are the dossier's prohibited_claims and acknowledge_gap items, named by field | The underwriter named this objection. Open with the plain acknowledgment: "I haven't held a product manager title, and I haven't owned a roadmap." Then the nearest work at its scope, in your words: you led 30+ integrations from scoping to go-live, and you ran roadmap-input sessions that fed client evidence to product. Then a ramp plan, stated as a plan: what you would confirm with the squad leads in the first month. Hold the integration claim through two follow-ups. Concede specifically that the PM tenure is missing. Do not add any roadmap decision you did not make. | Highest-ROI rehearsal. The underwriter derived it from your confirmed evidence. The negatives are sourced by the dossier's fields, so you may say them. F1 and F6 are the rows it tests. |
| A2 | "Walk me through the roadmap-input sessions. How did client evidence reach product, and what happened next?" | EXP | [grounded] dossier V3 "Ran quarterly roadmap-input sessions feeding client evidence to product" | Describe the mechanism: quarterly, client evidence, product. Volunteer the limit before it is extracted: you can describe the sessions, but you cannot show their output. No answer slot, because roadmap decisions are the acknowledged gap. | F6. V3 is medium confidence, so the seam is coached: name it before a prober finds it. |
| A3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] dossier acknowledge_gap item "Owning a roadmap and prioritization authority (R1 sub-claim)"; stem from the Skeptic persona | Answer with the roadmap and prioritization gap, using the plain acknowledgment from A1, then the ramp plan. Do not name an area the dossier does not list. | F6 and F5 are the day-one candidates. The honest answer is the one already sourced. |
| A4 | "How would you work with two squad leads who each have a view on the roadmap?" | JD | [grounded] JD line "Write specs and drive delivery with two engineering squads" (dossier role_profile) | Describe how you would find out which decisions each squad lead holds before taking a position. This is a plan. Do not claim the two-squad experience. | F4 and the decision-authority risk. The reverse question on the same point is Q1. |
| A5 | "Why move from integration leadership into a product role now?" | generic | [generic] | Say your own reason in one sentence. The material gives no motive, so the guidance supplies none. Keep it to the move itself, not to the title. | Motivation is a standard Skeptic probe. Sourcing a motive here would be invention. |

### B. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Adoption of the partner API dropped 20% this quarter. Diagnose it." | CASE | [generic] | Clarify first: what counts as adoption, and how it is measured today. Then segment by partner and by integration stage. Then state two hypotheses, the metrics you would check, and one risk. Think aloud. | Adoption metrics are a named responsibility with no baseline. Pairs with reverse question 2. |
| B2 | "Sketch the first ninety days on the partner API roadmap — what do you need to know first?" | JD | [generic] | Clarify first: which decisions the squad leads hold, the current adoption baseline, and which partners to speak to first. Then a discovery plan, as a plan. For agile delivery (F5), if asked how you would run the work with the squads, say you would confirm their cadence first and how they define it. | Covers R4 and the responsibility to run discovery. R5 is preferred, so it is covered inside this answer, not by a separate question. |
| B3 | "A partner needs an event the API does not expose. Do you build it?" | JD | [generic] | Structure it: how many partners ask, cost to build, how it is versioned, and what you would say no to. Describe your reasoning. Do not claim a past release. | R2 in case form. The answer tests the gap without asking you to claim a shipped product. |
| B4 | "A schema change will break two partners on their next release. How do you decide what to ship?" | CASE | [generic] | Clarify the deprecation window and the partners' release dates. Then state the options and the one you would take, with the communication you would send and when. | R3 in case form. A live problem, so it presupposes nothing about your past. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30 integrations were counted." | EXP | [grounded] dossier V1 "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: say in your own words how the count was made, what it is sensitive to, the assumption you would defend least, and which of those integrations were yours to lead. If you did not count them yourself, say so plainly. | The figure raises the defend-the-number slots, and none beyond them. |
| C2 | "How is your integration playbook used, and how would you know if it weren't?" | EXP | [grounded] dossier V2 "Wrote the internal integration playbook" | Answer slot: if you can show people used it, say what you can show; if you cannot show usage, say so plainly. Do not supply a usage figure. | F3. This is the probe that tests the documentation gap. |
| C3 | "The role defines adoption metrics for partner APIs. Which one would you start with, and why?" | JD | [generic] | Name one metric, say what it is sensitive to, and name the assumption you would defend least. Then say the baseline you would need first. | The adoption baseline is an open risk. Your answer leads to reverse question 2. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM with three years of the job?" | JD | [grounded] dossier V1 "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; the negatives are the dossier's prohibited_claims, named by field | Pause. Restate the question. Hold the integration claim: that work is what you can point to, and the PM tenure is the gap. Hold through two follow-ups. Concede specifically that the PM time is missing, and do not fold on the integration work. | F1. The hold is the one the quote supports, nothing more. |
| D2 | "That 30-integration result: how much of it was actually you?" | EXP | [grounded] dossier V1 "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: say which parts you led and which the vendor or your own team did, in your own words. Hold "led" only where your quote says it. | Attribution probe. The answer must match the quote's scope. |
| D3 | "You haven't owned a roadmap. Why would the squads take direction from you?" | JD | [grounded] dossier acknowledge_gap item "Owning a roadmap and prioritization authority (R1 sub-claim)" | Do not argue the premise. Say you have not owned a roadmap, then name the decision authority you would confirm before accepting: which calls the squad leads hold. Concede that point specifically. | The dossier lists decision authority as unverified. Conceding it is the honest hold. |

### E. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | VAL | [grounded] dossier V1, V2 and V3, each at its own scope | A 90-second arc: integration leadership on the vendor's APIs, the playbook, the roadmap-input sessions, then your reason for the move in one sentence. Say the limit once, early. | Opener, scored. The arc is the same material as A1, so the two answers stay consistent. |
| E2 | "What are you playing with in API docs and schemas these days?" | JD | [grounded] dossier V2 "Wrote the internal integration playbook" | Answer slot: name any spec or schema tool you have used. If you have not used one, say which you would learn first. | F3. Casual register, scored on the JD's terms. |
| E3 | "Anything you'd like to ask me?" | VAL | [generic] | Ask one reverse question from the bank below, and make it one of the two risk questions. | The reverse-question slot is weighted heavily as a preparation signal. |

**Requirement coverage**

| Requirement | Questions | Note |
|---|---|---|
| R1, 3+ years PM | A1, A3, D1 | Covered. |
| R2, shipped API or platform products | B3 | Covered. |
| R3, API docs and schemas | B4, C2, E2 | Covered. |
| R4, stakeholder management | A4, B2 | Covered. |
| R5, agile delivery (preferred) | none, and why: preferred, and covered inside B2's guidance by the clarify branch | |
| Own the roadmap, prioritization authority | A1, A2, A3, D3 | Covered. |
| Adoption metrics | B1, C3 | Covered. |

## Reverse questions

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: the JD asserts decision authority and nothing in your material evidences it. You need this answer before you accept.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: adoption is a named responsibility with no baseline stated. A role with no baseline is a different job.
3. "What would a PM need to deliver with the two squads in the first ninety days?" Why it lands: it turns your ramp plan into the interviewer's own expectation.
4. "What does success on this roadmap look like at six months?" Why it lands: it tests whether the hiring manager has a concrete target.
5. "What comes after this conversation in the process?" Why it lands: it shows you are planning for the rounds ahead.

No interviewer profile exists, so no reverse question is tied to the interviewer's own path.

## Prohibited claims check

No guidance cell above asserts a claim on the prohibited list. Where the list names a negative, it is said as a plain acknowledgment sourced to the dossier's fields. Inflated wordings are not used.

## Sources

- Provided: `tuesday-dossier.md`, dossier_version 1.1, decision conditional_go. Sections consumed: `role_profile` (JD tier satisfied), `handoff_to_mock_interview` (verified evidence V1 to V3, the weak-area strategies, the named objection, prohibited claims, risks and employer questions). The `evidence_map` and `evidence_state` sections were not supplied.
- Research tier: L1. Searches 0 of 6 (2 attempted, both refused: "Quartzline company values" and "Quartzline interview process product manager platform APIs"). Fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet. Not included: no values-style round is detected. |
| 2. Quartzline interview process, product role | unavailable | Loop structure. Persona weights come from the hiring-manager prior and the dossier, not from a named loop. |
| 3. Quartzline strategy and recent news | unavailable | Company-strategy questions for the CO type. None are in this pack. |
| 4. Interviewer name and company | n/a | No name given. |
| 5. Representative JD | skipped | The dossier's role_profile supplies the JD lines. |

## Upgrade menu

- The interviewer's name: a tailored reverse question, and persona weights read from their public footprint.
- Permission to search, or the company's values page pasted: a values cheat sheet, the interview-loop structure and strategy questions.
- The full JD text: confirms the dossier's requirement lines.
- Your raw CV behind the confirmed claims: a fuller story map for F1 and F4.
- Your recruiter's note on the round format: confirms whether anything is graded beyond this conversation.
