Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-6-denied-c087b55b/ae28a123-8504-4c97-a3c7-f62951981cdd/scratchpad/larkfield_engineering-manager_interview_pack.md`. I built it as one loop pack, because you have three scheduled rounds. Web search was not permitted in this session, so the pack has no company values, strategy or loop-structure research, and no interviewer profiles.

# Larkfield Systems: Engineering Manager, interview pack (three rounds)

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people)
**Rounds:**
- Tuesday: 45 min, hiring manager (Director of Engineering, your would-be boss)
- Thursday: 60 min panel, two staff engineers and a product manager
- Following Monday: 30 min, VP Engineering ("values and leadership philosophy", per the recruiter)

**Built on:** your role summary and your background note. No job description text, no interviewer names, no web research. Assumption: the role summary's four clauses are the job's requirements.

---

## How to use + type key

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **VAL**: behavioral / values alignment. **EXP**: deep-dive on your own experience. **JD**: the role's stated responsibilities. **CO**: company strategy knowledge. **CASE**: a live problem from the role.
- No CO questions appear, because no company research ran. The values cheat sheet is also absent, for the same reason.
- Guidance is scaffolding, not a script. Say it in your own words, and stop when you have answered.

---

## Prep triage

1. **H1, H2, H3.** The "never managed managers" and "hardware roadmap" objections. These are the most likely to come up in some form, so rehearse the plain acknowledgments out loud until they are boring.
2. **H4, H5, H9.** The 60% and the 40 interviews. Know how each figure was counted, and which assumption you would defend least.
3. **P1, V1, V5.** The seam with peer teams, the unpopular-truth story, and the "eleven people, six led" challenge.
4. **Everything else is insurance.**

---

## Fit snapshot

Requirements come from your role summary, quoted. Evidence comes from your own sentences, quoted. Your message is the source for every quote.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own delivery, hiring and growth for 11 engineers" (your note) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | transferability | Real and specific, but it is the interview loop for backend roles, not owning hiring and growth for a team. Say it in your words: "I run our hiring loop for backend roles." Answer slot: if you have made a hiring or growth decision that was yours, say what and how you decided; if you have not, say so plainly. |
| F2 | "11 engineers" (your note) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows three years leading six. The role is eleven across two squads. Keep the numbers as they are: "I was a team lead of six for three years." Answer slot: how you would structure eleven people across two squads, said as a plan. Do not describe an eleven-person structure you have not run. |
| F3 | "partner with hardware and product on roadmap" (your note) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | high | [grounded] | capability | A gap you stated. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F4 | Managing managers, the scale gap you flagged (your note) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | high | [grounded] | capability | A gap you stated. Words: "I've never managed managers." Then how you would lead leaders, said as a plan. |
| F5 | "own delivery" (your note) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | presentation | Already in role-relevant terms: delivery under pressure, with a measured result. Say it as written. Caveat: the work was on payments systems, not device fleets, so expect a probe on transfer. |
| F6 | "partner with hardware and product on roadmap" (your note) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Adjacent: you have held a roadmap trade-off under pressure, not negotiated a hardware roadmap. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: who was on the other side of that pressure, and what they wanted. If it came from product alone, say so. |
| F7 | "device-management services" and industrial IoT (your note) | none given | none | [grounded] | discovery | Your material does not show device, fleet or IoT work. Answer slot: if you have built or run anything touching devices, fleets or edge connectivity, say what; if not, say so and say how you would learn the domain first. |

**Gap types, in brief:** F3 and F4 are stated gaps (capability). F1, F2 and F6 are adjacent work (transferability). F5 is evidence already in role terms (presentation). F7 is silence (discovery).

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I have managed managers" | Sourced entry: your stated negative (F4) | "I've never managed managers." |
| "I owned a hardware roadmap" | Sourced entry: your stated negative (F3) | "I've never owned a hardware-adjacent roadmap." |
| "I set what the reliability quarter contained" | Inflated form of F5 | Your material says you pushed the quarter through, not that you set its scope. Say it at that scope. |
| "I designed the hiring loop" | Inflated form of F1 | Your material says you run the loop, not that you designed it. Say it at that scope. |
| "I scaled a team from six to eleven" | Inflated form of F2 | Your material says three years leading six. Nothing in it shows a scale change. |

---

## Persona weights and reasoning

Loop mode: three scheduled rounds, so one shared fit snapshot and one mini-pack per round.

| Round | Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Tue, hiring manager | Skeptic (top) | Probes the managers and hardware gaps | High. He is buying capability and derisking the gaps in F3 and F4 | Plain acknowledgment first, then a plan |
| Tue, hiring manager | Data-Driven Prober | Asks how the 60% and the 40 were counted | Medium. Your headline numbers are the first things a manager checks | Say how each was counted, or that you don't know; name the weakest assumption |
| Tue, hiring manager | Case / Strategist | Live problem on the device roadmap | Medium. A director tests structure on the roadmap they actually own | Clarify, then structure, then state a decision |
| Thu, panel: staff engineers | Peer Evaluator | Seams with their teams, credit, disagreement | High. Staff engineers price what you add to their work | Propose seam principles; don't pretend to know their seam |
| Thu, panel: staff engineers | Data-Driven Prober | Asks how the 60% was counted, and whether it held | Medium. Technical peers verify the number | As for the Tuesday prober |
| Thu, panel: PM | Case / Strategist | Roadmap trade-offs with hardware | High. The PM owns the trade-off you have not owned | Clarify the objective; name what you would need to know |
| Thu, panel: PM | Conversational | Journey question, casual register | Medium. Casual, but scored | A 90-second arc, pre-scripted |
| Mon, VP | Values / Behavioral (top) | "Unpopular truth", "customer over metric", leadership philosophy | High. The round is named as values and leadership | Map a story where your quotes carry one; otherwise a selection scaffold with an honest branch |
| Mon, VP | Pressure (mid) | "Why you, with eleven people?", "how much was actually you?" | Medium. Leadership rounds test composure on the scale gap | Hold the position through two follow-ups, then concede precisely |
| Mon, VP | Conversational (low) | Open-ended leadership questions | Low-medium | Short, specific answers |

---

## Question banks

### Round 1: Hiring manager (Tuesday, 45 min)

Depth: Skeptic 4 (top), Data-Driven Prober 3, Case 2.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You've never managed managers. How would you run two squads and eleven engineers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message); "3 as a team lead of 6" (your message) | Open with the negative in your words: "I've never managed managers." Then the six you have led: "I was a team lead of six for three years." Then the plan for eleven, as a plan. Answer slot: if you have led more than six people, or set up a structure above one team, say what and how you decided; if you have not, say so plainly. Hold through two follow-ups by returning to the plan, never by adding to the past. | F4 and F2 are the sharpest gap, and this is the highest-ROI rehearsal in the pack: it will be asked in some form. JD because it scores the role's scale. |
| H2 | "Sixty seconds: why should we hire someone who has never managed managers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message); "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Pressure. Hold: the quote shows you pushed a reliability quarter through against roadmap pressure, with a measured result. Hold through two follow-ups. Concede exactly: "I haven't managed managers, and that is the gap I'd have to close first." Never fold on the quarter itself. | F4 returns in pressure form. The hold is the quote; the concession is the stated gap. |
| H3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." (your message) | Say the gap first, in those words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it: who owns the hardware constraints, what you would ask in week one. A plan, not a past. | F3 is a stated gap, so the plain acknowledgment is the whole answer. No slot needed. |
| H4 | "Walk me through how the 60% on-call number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Defend-the-number. Say what on-call burden was measured as, over what period, and against what baseline, in your own words. Answer slot: if you did not set the measure, say so and say what you know of it. | F5 is the most likely place to be probed. A figure you gave raises these four slots, and only these. |
| H5 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Name the weakest assumption before they do, in your words. Answer slot: if you do not know what that assumption is, say so plainly. | The second defend-the-number slot. Converts a gotcha into a credibility gain. |
| H6 | "The device fleet backlog says one thing, product says another, and a hardware partner needs a firmware change. How do you decide what goes first?" | CASE | [generic] | Clarify the objective and who decides. Then structure: the constraints, the options, the criteria, the risks. Think aloud. Challenge one premise respectfully. No past claim. | A live problem from the role's partner-with-hardware line. The question presupposes nothing about you. |
| H7 | "What do you need to know about the device fleet before you'd commit a quarter?" | CASE | [generic] | List what you would need: fleet size, failure modes, update constraints, who owns the release path. Say what you would not commit without. | Live problem on the role's device domain. Generic because the question is a pattern, not a fact about Larkfield. |
| H8 | "Tell me about the last engineer whose growth you worked on. What did you do?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Open prompt. Pick a time you worked on someone's growth and name the decision you made. If none comes to mind, say so plainly, then give the nearest thing your material carries: the hiring loop. Stay with what you did. | The role's growth requirement has no quote in your material (F1 and F7), so this is a selection scaffold with an honest branch. |
| H9 | "The about 40 interviews last year: how were they counted, and whose were they?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Defend-the-number. Say what the 40 counted, whether the loop was yours alone, and which part was yours. Answer slot: if the loop was shared, say so. | F1's figure, and the one place a prober asks "yours or the team's". |

**Requirement coverage, Round 1:** "own delivery" → H1, H2, and H4 (via F5). "hiring and growth" → H8, H9, H1. "11 engineers" → H1, H2. "partner with hardware and product on roadmap" → H3, H6. "device-management services" → H7 (F7, discovery).

### Round 2: Panel (Thursday, 60 min)

Depth: Peer 2 and Prober 2 (staff engineers), Case 2 and Conversational 2 (product manager). Each member's style differs, so the panel mixes them.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side. Where's the seam between your squads and ours, and what happens when we disagree?" | JD | [generic]; [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Propose seam principles, not a seam you have not seen. For disagreement: pick a time you disagreed with a peer team, name the disagreement, what you did, how it ended. Answer slot: if no such time comes to mind, say so plainly, then give the nearest thing your material carries: pushing the reliability quarter through against roadmap pressure. | Peer Evaluator's seam probe. The disagreement story has no quote, so the guidance is a selection scaffold. |
| P2 | "How do you handle credit when work spans two teams?" | VAL | [generic] | Selection scaffold: pick a time credit was shared across a team boundary. Say who got it and what you said. If no such time comes to mind, say so plainly. | Peer Evaluator's credit probe. No quote carries a credit story. |
| P3 | "Walk me through how the 60% was counted, before and after." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Defend-the-number. Say what was counted, over what period, against what baseline. Answer slot: if you did not set the measure, say so and say what you know of it. | Staff engineers verify the number. Same four slots as H4, asked in a peer's register. |
| P4 | "What would tell you the reliability gain held after the quarter?" | CASE | [generic] | Name the signals you would watch, what would count as the gain holding, and what would prove it had not. No past claim. | A live problem on the verification of a result. |
| P5 | "A hardware partner needs a firmware change that slips your roadmap a quarter. What do you need before you say yes?" | CASE | [generic] | Clarify the objective and the cost of the slip. Then the options and the criteria. Say what you would tell product before you decide. | PM's trade-off probe, aimed at the role's partner-with-hardware line. |
| P6 | "Which device-management feature would you take first, and why?" | CASE | [generic] | Clarify what success looks like for the device team. Name the criteria, the risks, and what you would not start. | PM's native question. Generic: no device work in your material. |
| P7 | "So, walk us through the journey. How did you get to payments?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." (your message) | A 90-second arc: nine years of engineering, three as a team lead of six, now at a payments company. Keep it to what is quoted. | Conversational opener, scored for communication economy. |
| P8 | "Which part of device management are you most curious about?" | JD | [generic] | Be honest: say which part you would learn first and how. If you have no device work, say that plainly. | A casual JD-topic stem. The honest answer is a plan, not a past. |

**Requirement coverage, Round 2:** "device-management services" → P4, P6, P8 (F7). "partner with hardware and product on roadmap" → P5. "own delivery" → P3, P4. Seam with peer teams → P1, P2.

### Round 3: VP Engineering (Monday, 30 min)

Depth: Values / Behavioral 4 (top), Pressure 3, Conversational 2. The recruiter named this round as values and leadership philosophy, so it is values-style.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Open prompt. If the roadmap pressure came from leadership, the reliability quarter is your story: say what you said and what you held to. If it came from elsewhere, pick the nearest time you told leadership something unwelcome. If none comes to mind, say so plainly. | Values round's signature probe. Your quote carries a story only if the pressure came from leadership. |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time the customer's need and a team target pulled apart. Say what you chose and why. If no such time comes to mind, say so plainly. | Values probe with no quote behind it. |
| V3 | "How do you think about leading leaders, when you haven't done it yet?" | VAL | [grounded] "I've never managed managers." (your message) | Say it plainly first. Then your approach as a plan: what you would look for, how you would learn it, what you would not do. No claim of past practice. | The leadership-philosophy question premised on your stated gap. Honest answer: a plan. |
| V4 | "What does leadership mean to you, in one sentence?" | VAL | [generic] | One sentence, then one example. The example must be a real one, or say you do not have one. | Values framing, generic. |
| V5 | "Sixty seconds: why should we trust you with eleven people when you've led six?" | JD | [grounded] "3 as a team lead of 6" (your message) | Pressure. Hold: "I've led six for three years." Hold through two follow-ups. Concede precisely: "I haven't led eleven, and I'd be learning the scale." Never fold on what the quote carries. | The scale gap under pressure. Hold-then-concede is the structure. |
| V6 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Pressure. Hold: you pushed the quarter through, and the result was your team's. Concede the parts that belonged to the team. Name what you did only as your quote states it. | The attribution probe. Honest answer: what the quote says, nothing more. |
| V7 | "Why are you leaving now?" | EXP | [generic] | Give your own reason in your words. If you have one you are not ready to say, say that plainly. No reason is supplied here. | Motivation probe. Your material holds no reason, so the guidance is a slot for your own answer. |
| V8 | "What's the hardest part of your current job?" | EXP | [generic] | Name one specific thing. No quote carries it, so the answer is yours to supply. | Conversational, scored for specificity. |
| V9 | "What would your team say is your blind spot?" | VAL | [generic] | Name one real blind spot. Describe what you do about it, or say you are working on it. | Self-assessment probe. Honest answer only. |

**Requirement coverage, Round 3:** Leadership philosophy → V3, V4. Unpopular truth and values → V1, V2, V9. Scale and gap → V5, V3. Attribution → V6.

---

## Reverse questions

Each with a "why it lands". No interviewer profiles were given, so none is tied to a career path.

**Round 1 (hiring manager):**
1. "What would make someone in this role succeed in six months, and what would make them struggle?" Why it lands: shows you are testing the role, not just the interview.
2. "Where does this role sit in decisions about the device fleet roadmap?" Why it lands: tests the partner-with-hardware line directly.
3. "How many of the eleven engineers are new in the last year?" Why it lands: scale and growth in one question.
4. "What's the one thing you would want a new manager to change in the first 30 days?" Why it lands: asks for the director's own priority.
5. "What does a good first quarter look like, concretely?" Why it lands: gives you a plan to rehearse against.

**Round 2 (panel):**
1. For staff engineers: "Where do the two squads' services meet the device-facing code today?" Why it lands: names the seam concretely.
2. For staff engineers: "What decision does your team keep reopening?" Why it lands: shows you want the friction, not the slogan.
3. For the PM: "How is the device-side roadmap set, and who says no, and how often?" Why it lands: asks about the trade-off process.
4. Reciprocity, for the peers: "What could a new engineering manager do in the first month that would genuinely help your teams?" Why it lands: shifts the conversation to what you bring them.
5. For the PM: "What does a good hardware-product decision look like here?" Why it lands: asks for the standard the PM holds.

**Round 3 (VP):**
1. "What does leadership look like here when things go wrong?" Why it lands: tests the values in practice.
2. "What do the managers you admire here share?" Why it lands: asks for values by example.
3. "How does the company decide between reliability work and new features?" Why it lands: ties to your strongest story and asks for the real rule.
4. "What would you want me to have figured out in my first 90 days?" Why it lands: a concrete target for the first months.
5. "What leadership question are you still working on?" Why it lands: signals you value the VP's own growth.

---

## Sources

- Provided documents: your role summary and your background note (the whole of your input).
- Research tier: L1 requested. Web search was not permitted in this session, so no search or fetch ran.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Search refused (permission not granted). Would have fixed the values cheat sheet and the VP round's values questions. |
| 2. Larkfield interview process, engineering manager | unavailable | Search refused. Would have confirmed the three-round loop and its formats; persona weights rest on your description instead. |
| 3. Larkfield strategy / recent news | unavailable | No search sent. Would have moved the CO bank, which is absent for this reason. |
| 4. Interviewer name and company | n/a | No names given. |
| 5. Representative engineering manager JD | unavailable | No search sent. Would have given a representative `[inferred]` requirement list in place of your role summary. |

- Searches attempted: two (values; interview process), both refused.

---

## Upgrade menu

- Full job description text → requirements become quoted `[grounded]` rows, and the coverage line becomes complete.
- Larkfield's values page, pasted → a values cheat sheet, and the VP round's VAL questions map to the company's named values.
- Permission for web search → loop check, values and strategy research, and the CO bank.
- Interviewer names → persona weights and a reverse question tied to each interviewer's path.
- Recruiter's note on what each round assesses → reweights the three mini-packs.
- A deeper research pass is available on consent: up to six more searches and two more fetches, several more minutes.

---

If you want to rehearse, I can play the Skeptic on H1, the question the pack names as its highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

Two questions that would restructure the pack:
1. Can you paste the full job description? Your role summary's four clauses are the only requirement text I have, so a full posting would turn them into quoted rows and fill in the coverage line.
2. Does the role carry a location, office-days or work-authorization condition? The material says nothing about one, and if it is a condition it needs its own row.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering-manager_interview_pack.md -----
# Larkfield Systems: Engineering Manager, interview pack (three rounds)

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people)
**Rounds:**
- Tuesday: 45 min, hiring manager (Director of Engineering, your would-be boss)
- Thursday: 60 min panel, two staff engineers and a product manager
- Following Monday: 30 min, VP Engineering ("values and leadership philosophy", per the recruiter)

**Built on:** your role summary and your background note. No job description text, no interviewer names, no web research (see Sources). Assumption: the role summary's four clauses are the job's requirements.

---

## How to use + type key

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **VAL**: behavioral / values alignment. **EXP**: deep-dive on your own experience. **JD**: the role's stated responsibilities. **CO**: company strategy knowledge. **CASE**: a live problem from the role.
- No CO questions appear in this pack, because no company research ran. Section 6 (values cheat sheet) is also absent, for the same reason.
- Guidance is scaffolding, not a script. Say it in your own words, and stop when you have answered.

---

## Prep triage

Prioritized for the time between now and Tuesday:

1. **H1, H2, H3.** The "never managed managers" and "hardware roadmap" objections. These are the most likely to come up in some form, so rehearse the plain acknowledgments out loud until they are boring.
2. **H4, H5, H9.** The 60% and the 40 interviews. Know how each figure was counted, and which assumption you would defend least.
3. **P1, V1, V5.** The seam with peer teams, the unpopular-truth story, and the "eleven people, six led" challenge.
4. **Everything else is insurance.**

---

## Fit snapshot

Requirements come from your role summary, quoted. Evidence comes from your own sentences, quoted. Your message is the source for every quote.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own delivery, hiring and growth for 11 engineers" (your note) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | transferability | Real and specific, but it is the interview loop for backend roles, not owning hiring and growth for a team. Say it in your words: "I run our hiring loop for backend roles." Answer slot: if you have made a hiring or growth decision that was yours, say what and how you decided; if you have not, say so plainly. |
| F2 | "11 engineers" (your note) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows three years leading six. The role is eleven across two squads. Keep the numbers as they are: "I was a team lead of six for three years." Answer slot: how you would structure eleven people across two squads, said as a plan. Do not describe an eleven-person structure you have not run. |
| F3 | "partner with hardware and product on roadmap" (your note) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | high | [grounded] | capability | A gap you stated. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F4 | Managing managers, the scale gap you flagged (your note) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | high | [grounded] | capability | A gap you stated. Words: "I've never managed managers." Then how you would lead leaders, said as a plan. |
| F5 | "own delivery" (your note) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | presentation | Already in role-relevant terms: delivery under pressure, with a measured result. Say it as written. Caveat: the work was on payments systems, not device fleets, so expect a probe on transfer. |
| F6 | "partner with hardware and product on roadmap" (your note) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Adjacent: you have held a roadmap trade-off under pressure, not negotiated a hardware roadmap. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: who was on the other side of that pressure, and what they wanted. If it came from product alone, say so. |
| F7 | "device-management services" and industrial IoT (your note) | none given | none | [grounded] | discovery | Your material does not show device, fleet or IoT work. Answer slot: if you have built or run anything touching devices, fleets or edge connectivity, say what; if not, say so and say how you would learn the domain first. |

**Gap types, in brief:** F3 and F4 are the stated gaps (capability). F1, F2 and F6 are adjacent work (transferability). F5 is evidence already in role terms (presentation). F7 is silence (discovery).

---

## Prohibited claims

Claims this pack will not coach, built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have managed managers" | Sourced entry: your stated negative (F4) | "I've never managed managers." |
| "I owned a hardware roadmap" | Sourced entry: your stated negative (F3) | "I've never owned a hardware-adjacent roadmap." |
| "I set what the reliability quarter contained" | Inflated form of F5 | Your material says you pushed the quarter through, not that you set its scope. Say it at that scope. |
| "I designed the hiring loop" | Inflated form of F1 | Your material says you run the loop, not that you designed it. Say it at that scope. |
| "I scaled a team from six to eleven" | Inflated form of F2 | Your material says three years leading six. Nothing in it shows a scale change. |

---

## Persona weights and reasoning

Loop mode: three scheduled rounds, so one shared fit snapshot and one mini-pack per round.

| Round | Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Tue, hiring manager | Skeptic (top) | Probes the managers and hardware gaps | High. He is buying capability and derisking the gaps in F3 and F4 | Plain acknowledgment first, then a plan |
| Tue, hiring manager | Data-Driven Prober | Asks how the 60% and the 40 were counted | Medium. Your headline numbers are the first things a manager checks | Say how each was counted, or that you don't know; name the weakest assumption |
| Tue, hiring manager | Case / Strategist | Live problem on the device roadmap | Medium. A director tests structure on the roadmap they actually own | Clarify, then structure, then state a decision |
| Thu, panel: staff engineers | Peer Evaluator | Seams with their teams, credit, disagreement | High. Staff engineers price what you add to their work | Propose seam principles; don't pretend to know their seam |
| Thu, panel: staff engineers | Data-Driven Prober | Asks how the 60% was counted, and whether it held | Medium. Technical peers verify the number | As for the Tuesday prober |
| Thu, panel: PM | Case / Strategist | Roadmap trade-offs with hardware | High. The PM owns the trade-off you have not owned | Clarify the objective; name what you would need to know |
| Thu, panel: PM | Conversational | Journey question, casual register | Medium. Casual, but scored | A 90-second arc, pre-scripted |
| Mon, VP | Values / Behavioral (top) | "Unpopular truth", "customer over metric", leadership philosophy | High. The round is named as values and leadership | Map a story where your quotes carry one; otherwise a selection scaffold with an honest branch |
| Mon, VP | Pressure (mid) | "Why you, with eleven people?", "how much was actually you?" | Medium. Leadership rounds test composure on the scale gap | Hold the position through two follow-ups, then concede precisely |
| Mon, VP | Conversational (low) | Open-ended leadership questions | Low-medium | Short, specific answers |

---

## Question banks

### Round 1: Hiring manager (Tuesday, 45 min)

Persona depth: Skeptic 4 (top), Data-Driven Prober 3, Case 2.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You've never managed managers. How would you run two squads and eleven engineers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message); "3 as a team lead of 6" (your message) | Open with the negative in your words: "I've never managed managers." Then the six you have led: "I was a team lead of six for three years." Then the plan for eleven, as a plan. Answer slot: if you have led more than six people, or set up a structure above one team, say what and how you decided; if you have not, say so plainly. Hold through two follow-ups by returning to the plan, never by adding to the past. | F4 and F2 are the sharpest gap, and this is the highest-ROI rehearsal in the pack: it will be asked in some form. JD because it scores the role's scale. |
| H2 | "Sixty seconds: why should we hire someone who has never managed managers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message); "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Pressure. Hold: the quote shows you pushed a reliability quarter through against roadmap pressure, with a measured result. Hold through two follow-ups. Concede exactly: "I haven't managed managers, and that is the gap I'd have to close first." Never fold on the quarter itself. | F4 returns in pressure form. The hold is the quote; the concession is the stated gap. |
| H3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." (your message) | Say the gap first, in those words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it: who owns the hardware constraints, what you would ask in week one. A plan, not a past. | F3 is a stated gap, so the plain acknowledgment is the whole answer. No slot needed. |
| H4 | "Walk me through how the 60% on-call number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Defend-the-number. Say what on-call burden was measured as, over what period, and against what baseline, in your own words. Answer slot: if you did not set the measure, say so and say what you know of it. | F5 is the most likely place to be probed. A figure you gave raises these four slots, and only these. |
| H5 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Name the weakest assumption before they do, in your words. Answer slot: if you do not know what that assumption is, say so plainly. | The second defend-the-number slot. Converts a gotcha into a credibility gain. |
| H6 | "The device fleet backlog says one thing, product says another, and a hardware partner needs a firmware change. How do you decide what goes first?" | CASE | [generic] | Clarify the objective and who decides. Then structure: the constraints, the options, the criteria, the risks. Think aloud. Challenge one premise respectfully. No past claim. | A live problem from the role's partner-with-hardware line. The question presupposes nothing about you. |
| H7 | "What do you need to know about the device fleet before you'd commit a quarter?" | CASE | [generic] | List what you would need: fleet size, failure modes, update constraints, who owns the release path. Say what you would not commit without. | Live problem on the role's device domain. Generic because the question is a pattern, not a fact about Larkfield. |
| H8 | "Tell me about the last engineer whose growth you worked on. What did you do?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Open prompt. Pick a time you worked on someone's growth and name the decision you made. If none comes to mind, say so plainly, then give the nearest thing your material carries: the hiring loop. Stay with what you did. | The role's growth requirement has no quote in your material (F1 and F7), so this is a selection scaffold with an honest branch. |
| H9 | "The about 40 interviews last year: how were they counted, and whose were they?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Defend-the-number. Say what the 40 counted, whether the loop was yours alone, and which part was yours. Answer slot: if the loop was shared, say so. | F1's figure, and the one place a prober asks "yours or the team's". |

**Requirement coverage, Round 1:** "own delivery" → H1, H2 (no quote for delivery beyond F5, covered by H4). "hiring and growth" → H8, H9, H1. "11 engineers" → H1, H2. "partner with hardware and product on roadmap" → H3, H6. "device-management services" → H7 (F7, discovery).

### Round 2: Panel (Thursday, 60 min)

Persona depth: Peer 2 (staff engineers), Prober 2 (staff engineers), Case 2 (product manager), Conversational 2 (product manager). Each member's style differs, so the panel mixes them.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side. Where's the seam between your squads and ours, and what happens when we disagree?" | JD | [generic]; [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Propose seam principles, not a seam you have not seen. For disagreement: pick a time you disagreed with a peer team, name the disagreement, what you did, how it ended. Answer slot: if no such time comes to mind, say so plainly, then give the nearest thing your material carries: pushing the reliability quarter through against roadmap pressure. | Peer Evaluator's seam probe. The disagreement story has no quote, so the guidance is a selection scaffold. |
| P2 | "How do you handle credit when work spans two teams?" | VAL | [generic] | Selection scaffold: pick a time credit was shared across a team boundary. Say who got it and what you said. If no such time comes to mind, say so plainly. | Peer Evaluator's credit probe. No quote carries a credit story. |
| P3 | "Walk me through how the 60% was counted, before and after." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Defend-the-number. Say what was counted, over what period, against what baseline. Answer slot: if you did not set the measure, say so and say what you know of it. | Staff engineers verify the number. Same four slots as H4, asked in a peer's register. |
| P4 | "What would tell you the reliability gain held after the quarter?" | CASE | [generic] | Name the signals you would watch, what would count as the gain holding, and what would prove it had not. No past claim. | A live problem on the verification of a result. |
| P5 | "A hardware partner needs a firmware change that slips your roadmap a quarter. What do you need before you say yes?" | CASE | [generic] | Clarify the objective and the cost of the slip. Then the options and the criteria. Say what you would tell product before you decide. | PM's trade-off probe, aimed at the role's partner-with-hardware line. |
| P6 | "Which device-management feature would you take first, and why?" | CASE | [generic] | Clarify what success looks like for the device team. Name the criteria, the risks, and what you would not start. | PM's native question. Generic: no device work in your material. |
| P7 | "So, walk us through the journey. How did you get to payments?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." (your message) | A 90-second arc: nine years of engineering, three as a team lead of six, now at a payments company. Keep it to what is quoted. | Conversational opener, scored for communication economy. |
| P8 | "Which part of device management are you most curious about?" | JD | [generic] | Be honest: say which part you would learn first and how. If you have no device work, say that plainly. | A casual JD-topic stem. The honest answer is a plan, not a past. |

**Requirement coverage, Round 2:** "device-management services" → P4, P6, P8 (F7). "partner with hardware and product on roadmap" → P5. "own delivery" → P3, P4. Seam with peer teams (JD line 1) → P1, P2.

### Round 3: VP Engineering (Monday, 30 min)

Persona depth: Values / Behavioral 4 (top), Pressure 3, Conversational 2. This round is values-style: the recruiter named the round as values and leadership philosophy.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Open prompt. If the roadmap pressure came from leadership, the reliability quarter is your story: say what you said and what you held to. If it came from elsewhere, pick the nearest time you told leadership something unwelcome. If none comes to mind, say so plainly. | Values round's signature probe. Your quote carries a story only if the pressure came from leadership. |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time the customer's need and a team target pulled apart. Say what you chose and why. If no such time comes to mind, say so plainly. | Values probe with no quote behind it. |
| V3 | "How do you think about leading leaders, when you haven't done it yet?" | VAL | [grounded] "I've never managed managers." (your message) | Say it plainly first. Then your approach as a plan: what you would look for, how you would learn it, what you would not do. No claim of past practice. | The leadership-philosophy question premised on your stated gap. Honest answer: a plan. |
| V4 | "What does leadership mean to you, in one sentence?" | VAL | [generic] | One sentence, then one example. The example must be a real one, or say you do not have one. | Values framing, generic. |
| V5 | "Sixty seconds: why should we trust you with eleven people when you've led six?" | JD | [grounded] "3 as a team lead of 6" (your message) | Pressure. Hold: "I've led six for three years." Hold through two follow-ups. Concede precisely: "I haven't led eleven, and I'd be learning the scale." Never fold on what the quote carries. | The scale gap under pressure. Hold-then-concede is the structure. |
| V6 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Pressure. Hold: you pushed the quarter through, and the result was your team's. Concede the parts that belonged to the team. Name what you did only as your quote states it. | The attribution probe. Honest answer: what the quote says, nothing more. |
| V7 | "Why are you leaving now?" | EXP | [generic] | Give your own reason in your words. If you have one you are not ready to say, say that plainly. No reason is supplied here. | Motivation probe. Your material holds no reason, so the guidance is a slot for your own answer. |
| V8 | "What's the hardest part of your current job?" | EXP | [generic] | Name one specific thing. No quote carries it, so the answer is yours to supply. | Conversational, scored for specificity. |
| V9 | "What would your team say is your blind spot?" | VAL | [generic] | Name one real blind spot. Describe what you do about it, or say you are working on it. | Self-assessment probe. Honest answer only. |

**Requirement coverage, Round 3:** Leadership philosophy → V3, V4. Unpopular truth and values → V1, V2, V9. Scale and gap → V5, V3. Attribution → V6.

---

## Reverse questions

Each with a "why it lands". No interviewer profiles were given, so none is tied to a career path.

**Round 1 (hiring manager):**
1. "What would make someone in this role succeed in six months, and what would make them struggle?" Why it lands: shows you are testing the role, not just the interview.
2. "Where does this role sit in decisions about the device fleet roadmap?" Why it lands: tests the partner-with-hardware line directly.
3. "How many of the eleven engineers are new in the last year?" Why it lands: scale and growth in one question.
4. "What's the one thing you would want a new manager to change in the first 30 days?" Why it lands: asks for the director's own priority.
5. "What does a good first quarter look like, concretely?" Why it lands: gives you a plan to rehearse against.

**Round 2 (panel):**
1. For staff engineers: "Where do the two squads' services meet the device-facing code today?" Why it lands: names the seam concretely.
2. For staff engineers: "What decision does your team keep reopening?" Why it lands: shows you want the friction, not the slogan.
3. For the PM: "How is the device-side roadmap set, and who says no, and how often?" Why it lands: asks about the trade-off process.
4. Reciprocity, for the peers: "What could a new engineering manager do in the first month that would genuinely help your teams?" Why it lands: shifts the conversation to what you bring them.
5. For the PM: "What does a good hardware-product decision look like here?" Why it lands: asks for the standard the PM holds.

**Round 3 (VP):**
1. "What does leadership look like here when things go wrong?" Why it lands: tests the values in practice.
2. "What do the managers you admire here share?" Why it lands: asks for values by example.
3. "How does the company decide between reliability work and new features?" Why it lands: ties to your strongest story and asks for the real rule.
4. "What would you want me to have figured out in my first 90 days?" Why it lands: a concrete target for the first months.
5. "What leadership question are you still working on?" Why it lands: signals you value the VP's own growth.

---

## Sources

- Provided documents: your role summary and your background note (the whole of your input).
- Research tier: L1 requested; web search was not permitted in this session, so no search or fetch ran.
- Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Search refused (permission not granted). Would have fixed section 6 and the VP round's values questions. |
| 2. Larkfield interview process, engineering manager | unavailable | Search refused. Would have confirmed the three-round loop and its formats; persona weights rest on your description instead. |
| 3. Larkfield strategy / recent news | unavailable | No search sent. Would have moved the CO bank, which is absent for this reason. |
| 4. Interviewer name and company | n/a | No names given. |
| 5. Representative engineering manager JD | unavailable | No search sent. Would have given a representative `[inferred]` requirement list in place of your role summary. |

- Searches attempted: two (values; interview process), both refused.

---

## Upgrade menu

- Full job description text → requirements become quoted `[grounded]` rows; the coverage line gets complete.
- Larkfield's values page, pasted → the values cheat sheet (section 6) and the VP round's VAL questions map to the company's named values.
- Permission for web search → loop check, values and strategy research, and the CO bank.
- Interviewer names → persona weights and a reverse question tied to each interviewer's path.
- Recruiter's note on what each round assesses → reweights the three mini-packs.
- A deeper research pass is available on consent: up to six more searches and two more fetches, several more minutes.
