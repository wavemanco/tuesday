Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-2-denied-754a269b/cdb951d7-5e56-42fb-821b-94827009bfe6/scratchpad/atlas-freight_operations-manager_interview_pack.md. I built it for a hiring-manager round, since your note didn't say who you're meeting. Web search was refused in this session, so it has no company values, interview-loop or strategy material.

The three gaps the pack is built around:
- **Scale:** you lead 3 supervisors and the role leads 12 across four sites. Question A2 is the highest-ROI prep. Concede the scale directly and don't fold on the three-supervisor record.
- **Power BI:** say "I haven't used Power BI" before they ask, then give a plan for learning it.
- **Metrics:** your 40% mis-pick cut is accuracy, not on-time performance or cost per shipment. Expect a prober on how it was counted. Name the assumption you'd defend least.

I'd also rehearse your Green Belt answer: the pack only lets you claim the certificate, so be ready to say whether a project was yours.

I can play the Skeptic on A2 for a live drill. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like a Word version of the pack, say so and I'll convert it.

Two questions, and the pack adjusts to both:
1. Who are you meeting: your future manager, a peer, or a panel?
2. The JD requires five years of operations leadership. Does your leadership time meet that, and since when?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Atlas Freight, Operations Manager: interview prep pack

Interviewer: not known. Relationship: not stated, so this pack uses a hiring-manager prior (see the persona table). Built from your message only; web research was refused in this session, so no company values, interview-loop or strategy material is included.

## How to use

Personas describe how a question will be asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

Type key:
- **VAL**: values and behaviour (not used; no published values were found)
- **EXP**: your experience, tested for what was actually yours
- **JD**: can you do the listed job, gaps included
- **CO**: company and strategy knowledge (not included; no research ran)
- **CASE**: a live problem from the role

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows one site. Say it at its scope: "I ran the site's peak-season surge plan two years running." Answer slot: if you coordinated anything across sites, say what and how; if you did not, say so and describe how you would set up daily control across four sites. |
| F2 | "drive on-time performance ... down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | low | [grounded] | transferability | Your figure is accuracy, not timeliness, so say it as that: "I cut mis-pick rate 40%." Answer slot: if you tracked on-time performance, say what it was and how it moved; if you did not, say so and say what you would measure first. |
| F3 | "drive ... cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | low | [grounded] | transferability | A quality rate is not a cost per shipment, so do not stretch it. Answer slot: if you tracked cost per shipment, say what was counted and how; if you did not, say so and say what you measured in its place. |
| F4 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors, not twelve. Say that scope in your own words. Answer slot: if you have led a layer larger than three, say how it ran; if not, say so and describe how you would structure twelve supervisors across four sites. |
| F5 | "build reporting in Excel/Power BI" (JD), Excel half | "solid Excel" (your message) | medium | [grounded] | presentation | Your quote reaches the Excel half in other words. Say it as your material does: "solid Excel." |
| F6 | "build reporting in Excel/Power BI" (JD), Power BI half | "never used Power BI" (your message) | none | [grounded] | capability | A gap you stated, so the words are yours to give: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. |
| F7 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" (your message) | low | [grounded] | hard_gate | Your material does not establish five years of leadership: it gives seven years of operations and a current role leading three supervisors, with no start date for leadership. Not bridged here; Step 1 asks it. |
| F8 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | high | [grounded] | none | Your quote already meets the requirement. Say it as your material does: "green belt certified." |

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. No answer, hold, bridge or reverse question below asserts any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran daily operations across four sites | Inflated form of F1 | The one-site quote at its own scope: "ran the site's peak-season surge plan two years running." The pack's own observation: your material shows one site. |
| Led twelve supervisors | Inflated form of F4 | "currently a senior shift manager over 3 supervisors" |
| Built reporting in Power BI | Negative you stated (F6) | "I haven't used Power BI." |
| Improved on-time performance or cost per shipment | Inflated form of F2 and F3 | "cut mis-pick rate 40% by redesigning the pick path," kept to a mis-pick rate |
| Five years of operations leadership | Inflated form of F7 | Your quotes as written. Your leadership start date is not in your material. |
| Led a Green Belt project | Inflated form of F8 | "green belt certified," and nothing beyond it |

## Persona weights

No interviewer is named and the relationship is unknown, so the weights start from the hiring-manager prior: they are buying capability and will probe the gaps. The JD's reporting and metric requirements also invite a prober. Weights are shown so you can correct them.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| The Skeptic | Quiet, persistent probing of the gaps: scale, Power BI, leadership years | Highest. Your material has three clear gaps against the JD | Name each gap yourself, first; rehearse the 3-versus-12 objection until it is plain | 5 questions (A1 to A5) |
| The Data-Driven Prober | Asks how the 40% was counted and what the assumptions were | High. Your one hard number invites it | Name the assumption you would defend least; say plainly when you do not know | 4 (B1 to B4) |
| The Case / Strategist | Live problems: first 90 days, an on-time dip, a cost rise | Medium. The JD names both metrics | Clarify, then structure by site and by cadence | 3 (C1 to C3) |
| The Pressure / Stress Interviewer | Time-boxed challenge on the three-supervisor record and the 40% | Medium. Likely if the panel is senior | Pause, restate, hold through two follow-ups, then concede the specific gap | 2 (D1 to D2) |
| The Conversational / Rapport Builder | Opens with "walk me through the journey" and casual Power BI talk | Medium for a first conversation | A 90-second arc from quoted sentences only | 2 (E1 to E2) |
| The Peer Evaluator | Seam questions and credit-sharing | Lower; no peer round is known | Seam principles, not claimed history | 2 (F1 to F2) |

## Question banks

### Bank A: The Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Name the gap first: "I haven't used Power BI." Then the plan, as a plan: which reports you would build first and how you would learn the tool. Do not dress the gap up. | F6 is the only stated absence, and a Skeptic opens with the weakest requirement. Saying it first costs less than being shown it. |
| A2 | "You lead three supervisors today. This role leads twelve across four sites. Why should we believe you can?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Answer with the scope you run, in your words. Concede the scale directly: twelve is four times the three you lead. Then describe how you would structure the layer. Answer slot: if you have led a layer larger than three, name it and how it ran; if you have not, say so plainly, then describe how you would set up twelve supervisors across four sites. Hold through two follow-ups by returning to three, then concede the scale gap. | **Highest-ROI prep in this pack.** F4 is the largest gap and this objection will come in some form. Most rehearsed answers fold on the second follow-up. |
| A3 | "How would you run daily control across four sites when your current experience is one site?" | JD | [grounded] "ran the site's peak-season surge plan two years running" | Give what you ran at that site, at its scope. Answer slot: if you coordinated anything across sites, name it and how; if you did not, say so and describe how you would set up daily control across four sites. | F1: the JD's four-site line is the raising source, and the quote holds one site. |
| A4 | "Name the reporting you would need in Power BI in month one, and how you would learn it." | JD | [grounded] "never used Power BI"; [grounded] "solid Excel" | Name the reports you would need, and say that Excel is where you are solid today. Then how you would learn Power BI to build them, as a plan. Make no claim to past reports. | F5 and F6: Excel is presented, Power BI is absent. The JD's reporting line is the raising source. |
| A5 | "Lean and Six Sigma is a plus here. Walk me through your Green Belt project." | JD | [grounded] "green belt certified" | Say what the certification is and what you applied it to. Answer slot: if a Green Belt project was yours, say which and what you did; if the certificate was training without a project of your own, say so plainly. | F8 is high on the certificate and nothing more. The premise of a project is the interviewer's, so the second branch must allow it did not happen. |

### Bank B: The Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Give the measure and the period in your own words. Name the assumption you would defend least, before they do. If you do not know how it was counted, say that plainly. | The 40% is your one hard number and the main target for a prober. The weakest-assumption move is the credibility gain. |
| B2 | "What was on-time performance at that site over the same period?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you tracked on-time performance, give the figure and how it moved; if you did not, say so and say what you would measure first. | F2: this is the JD's on-time line, and your quote is about accuracy. |
| B3 | "What did cost per shipment do at your site over the surge?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Answer slot: if cost per shipment was tracked, say what was counted and how; if it was not, say so and say what you measured in its place. | F3: the JD's cost line, and your surge plan is the only scope the quote carries. |
| B4 | "Which number in your background would you defend least, and why?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pick the mis-pick figure and name the weakest assumption behind it, in your own words. Say what you can defend and what you cannot. | A metric question includes the weakest-assumption move by design. |

### Bank C: The Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch your first 90 days across these four sites. What do you need to know first?" | CASE | [generic] | Clarify before structuring: which sites are weakest, what volume they handle, which measures leadership tracks now. Then objective, structure by site and by daily cadence, risks, and the first measure you would set. Make no claim about your past. | A live problem from the JD's four-site scope. Generic because no company material was researched. |
| C2 | "On-time performance fell at one of your four sites last week. Diagnose it." | CASE | [generic] | Clarify the window and the baseline. Split by lane, carrier, dock and shift. Name one premise to test first. Ask for the data rather than guessing figures. | Tests the on-time requirement as a live problem, with no past claim needed. |
| C3 | "Cost per shipment rose while volume held flat. What would you check?" | CASE | [generic] | Split cost into its parts, such as labour hours, overtime and rework. Choose one to check first and say why. | The JD names cost per shipment, and your material does not show that cost work, so the structure carries the answer. |

### Bank D: The Pressure / Stress Interviewer (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who already manages twelve supervisors?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Pause. Restate the question. Answer from the scope you run now. Hold through two follow-ups. Concede the gap specifically: "I have not yet run twelve." Do not fold on the three-supervisor record. | The pressure form of F4. The hold is the one your material carries. |
| D2 | "That 40% result. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say which part was yours, in your words. If you redesigned the path, say what you changed. If the redesign was shared, say which part was yours and which was not. Hold the part that was yours; concede the rest. | Attribution under pressure. The hold-then-concede structure applies. |

### Bank E: The Conversational / Rapport Builder (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; [grounded] "cut mis-pick rate 40% by redesigning the pick path" | A 90-second arc: seven years in warehouse and distribution, now a senior shift manager over three supervisors, the pick-path work, then the surge plan. Stop, and ask what they would like more on. | Casual openers are scored. The arc uses only sentences you gave. |
| E2 | "What are you actually playing with in Power BI these days?" | JD | [grounded] "never used Power BI" | Say that you have not used it, then how you would start. | A casual question on a JD topic is still scored; the honest answer is short. |

### Bank F: The Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our four sites share dock time with the next region. Where is the seam, and what happens when you disagree with a peer site lead?" | JD | [generic] | Propose principles, not history: who owns dock slots, who escalates, how a disagreement gets decided. Do not claim a past disagreement. | Peer-style seam probe. Generic because no peer round is known. |
| F2 | "When a surge plan spans teams, how do you handle credit?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Say whose plan it was and what your role in it was, in your words. Answer slot: if other teams built parts of it, name what they did; if you ran it alone, say so. | Credit without inflation, anchored on the one plan your material carries. |

Total: 18 questions (A 5, B 4, C 3, D 2, E 2, F 2).

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A3, C1, F1 |
| Drive on-time performance down | B2, C2 |
| Drive cost-per-shipment down | B3, C3 |
| Lead a team of 12 supervisors | A2, D1 |
| Build reporting in Excel/Power BI | A1, A4, E2 |
| 5+ years operations leadership required | A2 (gate, asked in Step 1) |
| Lean/Six Sigma a plus | A5 |

## Reverse questions

1. "What does a strong first 90 days look like for this role?" Why it lands: it shows you plan from the outcome backward.
2. "How are on-time figures reported across the four sites today, and who reads them?" Why it lands: it shows you care about reporting, and tells you where Power BI fits.
3. "What is the hardest thing about running these sites that does not show up in the numbers?" Why it lands: it invites the interviewer's own view and reads as curiosity, not interrogation.
4. "How does the company define cost per shipment?" Why it lands: it shows metric literacy before you are asked to move the number.
5. Reciprocity, if the interviewer is a peer: "What could someone in this role do in the first month that would genuinely help your sites?" Why it lands: it turns the conversation toward what you bring.

Answer to "any questions for me?": ask question 1 first, then 2.

## Sources

- Provided documents: your message (the JD text, and your background as written).
- Searches: two standard searches were sent (company values, and the operations-manager interview process). Both were refused by the host, so no results came back.

Research tier: L1, with 0 of 6 searches and 0 of 2 fetches completed.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values section, which was dropped; would have built a values cheat sheet. Search refused. |
| 2. Atlas Freight interview process, operations | unavailable | Loop structure and persona weights; the weights here rest on the hiring-manager prior. Search refused. |
| 3. Atlas Freight strategy / recent news | unavailable | Would have grounded CO questions and a grounding brief. No strategy brief was supplied. |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. |
| 5. Representative operations-manager JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

Sections dropped, because their condition does not hold: prep triage (no prep time stated), graded deliverables (none declared), grounding brief (research did not run), reading the interviewer (no interviewer), values cheat sheet (no values round detected or values in hand), delivery coaching (no assessment provided).

## Upgrade menu

- The interviewer's name → a tailored reverse question, and persona weights from their public footprint
- Who you are meeting and the round type (asked in this message) → reweights every bank
- Your leadership start date → resolves the 5-year gate in F7 and sharpens A2
- Web search allowed → company values, interview loop and current strategy, with a CO question grounded in them
- Your CV → turns your message quotes into CV lines, and the grounded rows gain a source
- The recruiter's prep email → any pre-declared deliverable gets its own build section
