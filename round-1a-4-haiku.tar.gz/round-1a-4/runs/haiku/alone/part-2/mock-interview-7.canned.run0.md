Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-7-canned-cfa33598/7b307354-da62-4885-8a97-5bbb7ed85109/scratchpad/saltmarsh_games_live_operations_producer_interview_pack.md`. The Outage Hour format changes the prep, so read the Sources section first.

# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager, per Saltmarsh's published loop (the Outage Hour, see Sources).
**Interview:** Friday 27 November 2026, 60 minutes. Format: a live-incident tabletop, then a values conversation.
**Candidate:** Femi. Changelog: first version.

## How to use + type key

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding, not a script. Say the answers in your own words, and use only what you did.

Type key: **VAL** behavioral and values fit. **EXP** a deep-dive into your own experience. **JD** the role's stated requirements. **CO** company and strategy knowledge (none in this pack: company strategy research found nothing). **CASE** a live problem.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "Ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title, a weekly content-drop calendar, two years. It does not say two titles or live events. Say the one title in those words. Answer slot: if you planned across a second title or a live event, say what and how; if not, say so and say how you would plan across two. |
| F2 | "experience running a content calendar" (JD) | "Ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | No gap. Expect a probe on what "ran" covered: describe the calendar in your own words. |
| F3 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | discovery | Four years is in your words. Your material does not show that the title was live-service in the sense this role means. You said it likely counts; the facts should carry that, not the word. Answer slot: say what the title's model was after launch. If it kept shipping content on a schedule, say so and for how long; if not, say so and say what you ran instead. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | none | No gap. Presenting numbers is not owning how they were made. Expect a probe on how they were counted: if you know, say; if you do not, say so. |
| F5 | "own the post-event review and the KPIs it reports" (JD) | none given | none | [grounded] | discovery | Your material does not show a post-event review or a KPI report. Answer slot: if you reviewed a drop after it shipped and reported figures from it, say what you measured and how; if not, say so and say what you would review first. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show how you worked with those teams on a drop. Answer slot: if you coordinated any of them on a drop, say which and how; if not, say so and say how you would set up the first update. |
| F7 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | No gap. Say "wrote" and "still uses" as your sentence does. Do not say you ran QA. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | The checklist is one written artifact in use. Your material does not show written communication beyond it. Answer slot: name a written thing you produced for people outside your team, who read it, and what they did next; if none, say so and name the checklist. |
| F9 | people leadership, not in the JD text; you flagged it | "Never led a team" (your message) | high | [grounded] | capability | Your own negative. Words: "I haven't led a team." Then how you would learn to coordinate without a reporting line, said as a plan, never as a past. |
| F10 | monetization on mobile titles, not in the JD text; you flagged it | "Never worked on a game with in-app purchases" (your message) | high | [grounded] | capability | Your own negative. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan. |

Rows F9 and F10 are not JD requirements. They are the two gaps you named, and the interview may probe them anyway.

## Reading the interviewer

- **Career pattern:** QA lead at a console studio, then Head of Live Operations at Saltmarsh (GDC 2026 talk page).
- **Self-described stance:** his GDC 2026 talk, "Patch Notes Are a Promise," argues a live team is judged by how often its patch notes describe what actually shipped.
- **Implications:**
  1. Expect the tabletop to test whether what gets announced matches what is built. Use the release checklist as your bridge, and say only what it does.
  2. Expect questions about release accuracy and QA, since his background is QA.
  3. Read the value "Ship the Patch Not the Promise" as his own line of argument.
- **Mirror opportunity:** the release checklist (F7). A shared professional path is not offered: your work has been producer-side, not QA.

## Persona table

Weights follow the loop, a 60-minute hiring-manager session that is a live tabletop followed by a values conversation. Depth is 5, 4, 3, 2 by weight; the total is 19 questions.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The Outage Hour tabletop: a live incident during an event | High. The loop names this format (careers page). Weight 5 | Clarify, decide, name who you bring in, announce only what is confirmed |
| Values/Behavioral | The values conversation, against three published values | High. The loop names it. Weight 4 | Map a story only where a quote carries one; otherwise use the selection scaffold and its honest branch |
| Skeptic | Probes the gaps: no team led, no in-app purchase work | High. A hiring manager derisks gaps. Weight 3 | Rehearse the leadership objection until it is plain; acknowledge the negatives exactly |
| Data-Driven Prober | Retention numbers and KPIs; how they were counted | Medium. The JD names retention and KPIs. Weight 3 | Say what you know about how the numbers were built, and say so when you do not |
| Pressure | Time-boxed challenges on the leadership gap and the calendar | Medium. Hiring managers vary. Weight 2 | Pause, restate, hold through two follow-ups, concede specifically |
| Peer Evaluator | Seams with design, and credit across four teams | Low. Weight 2 | Propose seam principles rather than claiming their seam |

Conversational is touched by the opener V1, not given a separate bank.

## Question banks

Provenance comes first in each row. A row with no candidate claim carries its label alone.

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event is running and players report a reward granted twice. Talk me through the first hour." | CASE | [grounded] "a live-incident tabletop on a simulated outage during a live event" (careers page) | Clarify scope: how many players, which reward, is it still happening. Decide whether to pause the event. Name who you bring in (engineering, QA, community) and what each does. Announce only what is confirmed. Use Players Before Plans as the tie-break. Speak it in about 90 seconds. | The loop's published format. The question makes no claim about your past. |
| A2 | "Plan the next six weeks of content for one title with two updates and a live event. What do you need to know first?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Clarify the event's goal, the KPI it moves, which teams it needs and by when, and what gets cut first. Name your assumptions aloud. | JD calendar requirement. Covers F1 as a plan, not a claim. |
| A3 | "Retention dips two weeks after a drop. Diagnose it." | CASE | [generic] | Define the metric first. Split by cohort. Ask what changed in the drop. Name the data you would need. | JD retention requirement. A pattern, not a fact about your history. |
| A4 | "Walk me through the content-drop calendar you ran. What decided what went into each week?" | EXP | [grounded] "Ran the weekly content-drop calendar for our main title for the last two years" (your message) | Tell the calendar's cadence and span in those words. Answer slot: if you chose what went into a week, say how you decided; if someone else set it, or there was no weekly decision, say so plainly. | F2. Tests whether "ran" was your decision. |
| A5 | "Two titles, one calendar: how would you split your week?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD); "Ran the weekly content-drop calendar for our main title for the last two years" (your message) | Answer structurally. Say what you ran for one title and what you would need to learn for the second. Do not claim two-title experience. | F1 at its own scope. Asks for the limit honestly. |

### Values/Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Walk me through how you got to this interview: the four years, the calendar, the checklist." | VAL | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | A 90-second arc using only those facts. Answer slot: why this role now, in your own words. Stay conversational; this is scored. | Opener that touches the conversational persona. |
| V2 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [generic] (theme from the published value Players Before Plans, values page) | Selection scaffold: pick a time a planned date or drop conflicted with what players were asking for, with a choice you made or influenced and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. Your material does not show a conflict. | The value has no mapped story in your material. |
| V3 | "Tell me about a time an announcement and the build did not match. What did you do?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" (your message) | The checklist is the artifact you can name. Answer slot: if you checked announcements against the build with it, say how; if you did not, say so and say what you checked. | Ship the Patch Not the Promise. Maps to the checklist only as your sentence states it. |
| V4 | "Tell me about a time you changed a process so the next release was easier." | VAL | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Map to the checklist only as the sentence states: you wrote it, and it is still used. Answer slot: if you changed the checklist after writing it, say what changed and why; if you changed nothing after writing it, say so and say what you would change first. | Leave the Build Greener. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You've never led a team, and this role coordinates four teams that don't report to you. How does that work?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD); "Never led a team" (your message) | Open with "I haven't led a team." Then describe the coordination you actually did, in your own words. Answer slot: if you coordinated any of those teams on a drop, say which and how; if not, say so and say how you would set up the first update. Hold through two follow-ups by returning to what you did and what you would do first. Concede specifically: the uncertainty about four teams' priorities, not the leadership claim. | Highest return in this pack. It meets the JD's coordination line and your own gap, and it will be asked in some form. |
| S2 | "You haven't worked on a game with in-app purchases. How would you handle that in this role?" | JD | [grounded] "Never worked on a game with in-app purchases" (your message) | "I haven't worked on a game with in-app purchases." Then what you would learn first. Do not say your retention or content work carries in-app purchase knowledge. | F10. The acknowledgment is your own words. |
| S3 | "Your title ran on a content-drop model. Was it live-service in the sense this role means?" | EXP | [grounded] "Ran the weekly content-drop calendar for our main title for the last two years" (your message) | Say the title's model after launch, in your own words. Answer slot: if it kept shipping content on a schedule, say so and for how long; if not, say what you ran instead. Do not use the word "live-service" for it unless the facts carry it. | F3. The JD's three-year bar is met only if the facts show it. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Which of your retention numbers would you defend least, and why?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Name the weakest assumption you know of before they do. If you do not know how the figures were counted, say so. Answer slot: if you built or checked the calculation, say which step; if someone else produced it, say so. | F4. You gave no figure, so no figure slot is raised. |
| P2 | "How would you know a content drop worked?" | JD | [generic] | Name the KPI, the baseline, the window, and what else changed. Answer slot: if you measured a drop after it shipped, say what you looked at; if you did not, say so and say what you would look at first. | F5. The question is general. The answer slot is yours. |
| P3 | "What does your release checklist check that is easy to miss?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Name two items in your own words and say why they are there. If you cannot name items, say so. | F7. A probe on the artifact you wrote. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Q1 | "Sixty seconds: why you over someone who has led a team?" | JD | [grounded] "Never led a team" (your message) | Pause. Restate the question. "I haven't led a team." Then what you bring, in your own words: the calendar and the checklist. Hold through two follow-ups; concede the leadership gap specifically; do not fold on the calendar. | F9 under time pressure. |
| Q2 | "That calendar you ran: how much of what went into it was actually you?" | EXP | [grounded] "Ran the weekly content-drop calendar for our main title for the last two years" (your message) | Say what you ran and what others set, in your own words. Answer slot: if you set what went into it, say how; if others did, say so plainly. Hold through two follow-ups. | F2 under attribution pressure. |

### Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where's the seam between your team and design, and what happens when you disagree?" | JD | [generic] | Propose a principle: who decides the date, who decides the scope, what gets escalated. Do not claim to know their seam. | JD coordination, in a peer's register. |
| E2 | "How do you handle credit when a drop succeeds across four teams?" | JD | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Credit what you wrote; name the others by what they did. Do not claim their work. | F7 in a credit frame. |

**Requirement coverage.** Plan and run the calendar: A2, A5. Coordinate four teams: S1, E1, E2. Own the post-event review and KPIs: P2, R4. Manage the release checklist with QA: P3, V3, R5. 3+ years live-service: S3. Content calendar: A4, A5. Retention metrics: P1, P2. Clear written communication: P3 only. No dedicated question. The upgrade menu asks for a written sample.

**Values cheat sheet.** The values round is detected in the loop, and the values page is in hand.

| Value | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quoted sentence carries a story. Selection scaffold ends in its honest branch (V2). |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | "Wrote the release checklist our QA team still uses" (your message). Whether it gated announcements is not in the sentence; answer slot in V3. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better | "Wrote the release checklist our QA team still uses" (your message). A change after writing is not in the sentence; answer slot in V4. |

## Reverse questions

1. "Your GDC 2026 talk argues a live team is judged by how often its patch notes describe what shipped. What does that look like at the release gate today?" Why it lands: it shows you read his public talk and turns a check into a conversation.
2. "You came up through QA before running live ops. What did that make you check first on an update?" Why it lands: it ties to his own path, QA lead to Head of Live Operations, and gives him a reason to talk.
3. "What would a good first ninety days look like for this role?" Why it lands: it shows you plan in cadence, not in goals.
4. "What does the post-event review report today, and which KPI does it move first?" Why it lands: it tests the KPI ownership the JD asks for, and shows you read the role closely.
5. "Where does the release checklist break first when a live event slips?" Why it lands: it names the QA seam, and it follows from the checklist you wrote.

## Prohibited list

Claims this pack will not coach, built here from the fit snapshot. Each carries its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar for two titles | Inflated form of F1 | "Ran the weekly content-drop calendar for our main title for the last two years." This pack's own observation: your material shows one title, not two. |
| Led the release process with QA | Inflated form of F7 | "Wrote the release checklist our QA team still uses." |
| Owned the retention KPIs | Inflated form of F4 | "Presented the monthly retention numbers to the studio head." |
| Ran live-service titles | Inflated form of F3 | "4 years as an associate producer at a puzzle-game studio." |
| Led a team | Negative you stated, F9 | "I haven't led a team." No answer slot. |
| Has in-app purchase experience | Negative you stated, F10 | "I haven't worked on a game with in-app purchases." No answer slot. |

## Sources

Provided documents: your message (the JD text and your background).

1. Search "Saltmarsh Games mobile studio live operations": no results.
2. Search "Tobias Wrenfield Saltmarsh Games Head of Live Operations": returned https://talks.gdconf.example/2026/patch-notes-are-a-promise. Fetched: GDC 2026 talk, "Patch Notes Are a Promise," by Tobias Wrenfield, Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio.
3. Search "Saltmarsh Games values": returned https://saltmarshgames.com/values. Fetched: three values, Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener, with their meanings as quoted in the Values cheat sheet.
4. Search "Saltmarsh Games interview process live operations producer": returned https://saltmarshgames.com/careers/interviewing. Snippet only, not fetched: a recruiter call, then the Outage Hour, a single 60-minute interview with the hiring manager, a live-incident tabletop on a simulated outage during a live event, then a values conversation; no take-home.

**Research tier:** L1, searches 4 of 6, fetches 2 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet; V2 to V4 |
| 2. Saltmarsh Games interview process | yes | Loop structure; persona weights and the 60-minute format |
| 3. Saltmarsh Games strategy / recent news | yes | Query 1 returned no results, so the CO bank stays generic and no strategy is claimed |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Interviewer read; the talk theme; reverse questions 1 and 2 |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot |

The L2 targets (strategy brief, interviewer talks and writing, role-family loop reports, recent org context) did not run.

## Upgrade menu

- Your CV or résumé → quotes move from "your message" to "your CV", and the F1 and F4 confidence can be regraded.
- A post-event review or a KPI report you wrote → F5 and P2 move from an answer slot to an evidenced answer.
- Any second-title or live-event work, however small → F1 and A5 move from transferability.
- A description of the puzzle title's content model after launch → F3 moves from discovery.
- A written sample for people outside your team → F8 moves from low, and a written-communication question is added.
- Deep research (L2): a strategy brief, Tobias's other talks and writing, recent Saltmarsh news. Six more searches and two more fetches.

---

A live rehearsal is one line away: I can play the Pressure interviewer on S1, the leadership objection, which the pack names as the highest-return prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed (F5, F6, F9, F10) for later sessions. Say so if you want the pack as a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_games_live_operations_producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager, per Saltmarsh's published loop (the Outage Hour, see Sources).
**Interview:** Friday 27 November 2026, 60 minutes. Format: a live-incident tabletop, then a values conversation.
**Candidate:** Femi. Changelog: first version.

## How to use + type key

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding, not a script. Say the answers in your own words, and use only what you did.

Type key: **VAL** behavioral and values fit. **EXP** a deep-dive into your own experience. **JD** the role's stated requirements. **CO** company and strategy knowledge (none in this pack: company strategy research found nothing). **CASE** a live problem.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "Ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title, a weekly content-drop calendar, two years. It does not say two titles or live events. Say the one title in those words. Answer slot: if you planned across a second title or a live event, say what and how; if not, say so and say how you would plan across two. |
| F2 | "experience running a content calendar" (JD) | "Ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | No gap. Expect a probe on what "ran" covered: describe the calendar in your own words. |
| F3 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | discovery | Four years is in your words. Your material does not show that the title was live-service in the sense this role means. You said it likely counts; the facts should carry that, not the word. Answer slot: say what the title's model was after launch. If it kept shipping content on a schedule, say so and for how long; if not, say so and say what you ran instead. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | none | No gap. Presenting numbers is not owning how they were made. Expect a probe on how they were counted: if you know, say; if you do not, say so. |
| F5 | "own the post-event review and the KPIs it reports" (JD) | none given | none | [grounded] | discovery | Your material does not show a post-event review or a KPI report. Answer slot: if you reviewed a drop after it shipped and reported figures from it, say what you measured and how; if not, say so and say what you would review first. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show how you worked with those teams on a drop. Answer slot: if you coordinated any of them on a drop, say which and how; if not, say so and say how you would set up the first update. |
| F7 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | No gap. Say "wrote" and "still uses" as your sentence does. Do not say you ran QA. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | The checklist is one written artifact in use. Your material does not show written communication beyond it. Answer slot: name a written thing you produced for people outside your team, who read it, and what they did next; if none, say so and name the checklist. |
| F9 | people leadership, not in the JD text; you flagged it | "Never led a team" (your message) | high | [grounded] | capability | Your own negative. Words: "I haven't led a team." Then how you would learn to coordinate without a reporting line, said as a plan, never as a past. |
| F10 | monetization on mobile titles, not in the JD text; you flagged it | "Never worked on a game with in-app purchases" (your message) | high | [grounded] | capability | Your own negative. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan. |

Rows F9 and F10 are not JD requirements. They are the two gaps you named, and the interview may probe them anyway.

## Reading the interviewer

- **Career pattern:** QA lead at a console studio, then Head of Live Operations at Saltmarsh (GDC 2026 talk page).
- **Self-described stance:** his GDC 2026 talk, "Patch Notes Are a Promise," argues a live team is judged by how often its patch notes describe what actually shipped.
- **Implications:**
  1. Expect the tabletop to test whether what gets announced matches what is built. Use the release checklist as your bridge, and say only what it does.
  2. Expect questions about release accuracy and QA, since his background is QA.
  3. Read the value "Ship the Patch Not the Promise" as his own line of argument.
- **Mirror opportunity:** the release checklist (F7). A shared professional path is not offered: your work has been producer-side, not QA.

## Persona table

Weights follow the loop, a 60-minute hiring-manager session that is a live tabletop followed by a values conversation. Depth is 5, 4, 3, 2 by weight; the total is 19 questions.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The Outage Hour tabletop: a live incident during an event | High. The loop names this format (careers page). Weight 5 | Clarify, decide, name who you bring in, announce only what is confirmed |
| Values/Behavioral | The values conversation, against three published values | High. The loop names it. Weight 4 | Map a story only where a quote carries one; otherwise use the selection scaffold and its honest branch |
| Skeptic | Probes the gaps: no team led, no in-app purchase work | High. A hiring manager derisks gaps. Weight 3 | Rehearse the leadership objection until it is plain; acknowledge the negatives exactly |
| Data-Driven Prober | Retention numbers and KPIs; how they were counted | Medium. The JD names retention and KPIs. Weight 3 | Say what you know about how the numbers were built, and say so when you do not |
| Pressure | Time-boxed challenges on the leadership gap and the calendar | Medium. Hiring managers vary. Weight 2 | Pause, restate, hold through two follow-ups, concede specifically |
| Peer Evaluator | Seams with design, and credit across four teams | Low. Weight 2 | Propose seam principles rather than claiming their seam |

Conversational is touched by the opener V1, not given a separate bank.

## Question banks

Provenance comes first in each row. A row with no candidate claim carries its label alone.

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event is running and players report a reward granted twice. Talk me through the first hour." | CASE | [grounded] "a live-incident tabletop on a simulated outage during a live event" (careers page) | Clarify scope: how many players, which reward, is it still happening. Decide whether to pause the event. Name who you bring in (engineering, QA, community) and what each does. Announce only what is confirmed. Use Players Before Plans as the tie-break. Speak it in about 90 seconds. | The loop's published format. The question makes no claim about your past. |
| A2 | "Plan the next six weeks of content for one title with two updates and a live event. What do you need to know first?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Clarify the event's goal, the KPI it moves, which teams it needs and by when, and what gets cut first. Name your assumptions aloud. | JD calendar requirement. Covers F1 as a plan, not a claim. |
| A3 | "Retention dips two weeks after a drop. Diagnose it." | CASE | [generic] | Define the metric first. Split by cohort. Ask what changed in the drop. Name the data you would need. | JD retention requirement. A pattern, not a fact about your history. |
| A4 | "Walk me through the content-drop calendar you ran. What decided what went into each week?" | EXP | [grounded] "Ran the weekly content-drop calendar for our main title for the last two years" (your message) | Tell the calendar's cadence and span in those words. Answer slot: if you chose what went into a week, say how you decided; if someone else set it, or there was no weekly decision, say so plainly. | F2. Tests whether "ran" was your decision. |
| A5 | "Two titles, one calendar: how would you split your week?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD); "Ran the weekly content-drop calendar for our main title for the last two years" (your message) | Answer structurally. Say what you ran for one title and what you would need to learn for the second. Do not claim two-title experience. | F1 at its own scope. Asks for the limit honestly. |

### Values/Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Walk me through how you got to this interview: the four years, the calendar, the checklist." | VAL | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | A 90-second arc using only those facts. Answer slot: why this role now, in your own words. Stay conversational; this is scored. | Opener that touches the conversational persona. |
| V2 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [generic] (theme from the published value Players Before Plans, values page) | Selection scaffold: pick a time a planned date or drop conflicted with what players were asking for, with a choice you made or influenced and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. Your material does not show a conflict. | The value has no mapped story in your material. |
| V3 | "Tell me about a time an announcement and the build did not match. What did you do?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" (your message) | The checklist is the artifact you can name. Answer slot: if you checked announcements against the build with it, say how; if you did not, say so and say what you checked. | Ship the Patch Not the Promise. Maps to the checklist only as your sentence states it. |
| V4 | "Tell me about a time you changed a process so the next release was easier." | VAL | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Map to the checklist only as the sentence states: you wrote it, and it is still used. Answer slot: if you changed the checklist after writing it, say what changed and why; if you changed nothing after writing it, say so and say what you would change first. | Leave the Build Greener. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You've never led a team, and this role coordinates four teams that don't report to you. How does that work?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD); "Never led a team" (your message) | Open with "I haven't led a team." Then describe the coordination you actually did, in your own words. Answer slot: if you coordinated any of those teams on a drop, say which and how; if not, say so and say how you would set up the first update. Hold through two follow-ups by returning to what you did and what you would do first. Concede specifically: the uncertainty about four teams' priorities, not the leadership claim. | Highest return in this pack. It meets the JD's coordination line and your own gap, and it will be asked in some form. |
| S2 | "You haven't worked on a game with in-app purchases. How would you handle that in this role?" | JD | [grounded] "Never worked on a game with in-app purchases" (your message) | "I haven't worked on a game with in-app purchases." Then what you would learn first. Do not say your retention or content work carries in-app purchase knowledge. | F10. The acknowledgment is your own words. |
| S3 | "Your title ran on a content-drop model. Was it live-service in the sense this role means?" | EXP | [grounded] "Ran the weekly content-drop calendar for our main title for the last two years" (your message) | Say the title's model after launch, in your own words. Answer slot: if it kept shipping content on a schedule, say so and for how long; if not, say what you ran instead. Do not use the word "live-service" for it unless the facts carry it. | F3. The JD's three-year bar is met only if the facts show it. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Which of your retention numbers would you defend least, and why?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Name the weakest assumption you know of before they do. If you do not know how the figures were counted, say so. Answer slot: if you built or checked the calculation, say which step; if someone else produced it, say so. | F4. You gave no figure, so no figure slot is raised. |
| P2 | "How would you know a content drop worked?" | JD | [generic] | Name the KPI, the baseline, the window, and what else changed. Answer slot: if you measured a drop after it shipped, say what you looked at; if you did not, say so and say what you would look at first. | F5. The question is general. The answer slot is yours. |
| P3 | "What does your release checklist check that is easy to miss?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Name two items in your own words and say why they are there. If you cannot name items, say so. | F7. A probe on the artifact you wrote. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Q1 | "Sixty seconds: why you over someone who has led a team?" | JD | [grounded] "Never led a team" (your message) | Pause. Restate the question. "I haven't led a team." Then what you bring, in your own words: the calendar and the checklist. Hold through two follow-ups; concede the leadership gap specifically; do not fold on the calendar. | F9 under time pressure. |
| Q2 | "That calendar you ran: how much of what went into it was actually you?" | EXP | [grounded] "Ran the weekly content-drop calendar for our main title for the last two years" (your message) | Say what you ran and what others set, in your own words. Answer slot: if you set what went into it, say how; if others did, say so plainly. Hold through two follow-ups. | F2 under attribution pressure. |

### Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where's the seam between your team and design, and what happens when you disagree?" | JD | [generic] | Propose a principle: who decides the date, who decides the scope, what gets escalated. Do not claim to know their seam. | JD coordination, in a peer's register. |
| E2 | "How do you handle credit when a drop succeeds across four teams?" | JD | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Credit what you wrote; name the others by what they did. Do not claim their work. | F7 in a credit frame. |

**Requirement coverage.** Plan and run the calendar: A2, A5. Coordinate four teams: S1, E1, E2. Own the post-event review and KPIs: P2, R4. Manage the release checklist with QA: P3, V3, R5. 3+ years live-service: S3. Content calendar: A4, A5. Retention metrics: P1, P2. Clear written communication: P3 only. No dedicated question. The upgrade menu asks for a written sample.

**Values cheat sheet.** The values round is detected in the loop, and the values page is in hand.

| Value | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quoted sentence carries a story. Selection scaffold ends in its honest branch (V2). |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | "Wrote the release checklist our QA team still uses" (your message). Whether it gated announcements is not in the sentence; answer slot in V3. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better | "Wrote the release checklist our QA team still uses" (your message). A change after writing is not in the sentence; answer slot in V4. |

## Reverse questions

Five are needed. Each has a why-it-lands.

1. "Your GDC 2026 talk argues a live team is judged by how often its patch notes describe what shipped. What does that look like at the release gate today?" Why it lands: it shows you read his public talk and turns a check into a conversation.
2. "You came up through QA before running live ops. What did that make you check first on an update?" Why it lands: it ties to his own path, QA lead to Head of Live Operations, and gives him a reason to talk.
3. "What would a good first ninety days look like for this role?" Why it lands: it shows you plan in cadence, not in goals.
4. "What does the post-event review report today, and which KPI does it move first?" Why it lands: it tests the KPI ownership the JD asks for, and shows you read the role closely.
5. "Where does the release checklist break first when a live event slips?" Why it lands: it names the QA seam, and it follows from the checklist you wrote.

## Prohibited list

Claims this pack will not coach, built here from the fit snapshot. Each carries its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar for two titles | Inflated form of F1 | "Ran the weekly content-drop calendar for our main title for the last two years." This pack's own observation: your material shows one title, not two. |
| Led the release process with QA | Inflated form of F7 | "Wrote the release checklist our QA team still uses." |
| Owned the retention KPIs | Inflated form of F4 | "Presented the monthly retention numbers to the studio head." |
| Ran live-service titles | Inflated form of F3 | "4 years as an associate producer at a puzzle-game studio." |
| Led a team | Negative you stated, F9 | "I haven't led a team." No answer slot. |
| Has in-app purchase experience | Negative you stated, F10 | "I haven't worked on a game with in-app purchases." No answer slot. |

## Sources

Provided documents: your message (the JD text and your background).

Searches and fetches, with what came back:

1. Search "Saltmarsh Games mobile studio live operations": no results.
2. Search "Tobias Wrenfield Saltmarsh Games Head of Live Operations": returned https://talks.gdconf.example/2026/patch-notes-are-a-promise. Fetched: GDC 2026 talk, "Patch Notes Are a Promise," by Tobias Wrenfield, Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio.
3. Search "Saltmarsh Games values": returned https://saltmarshgames.com/values. Fetched: three values, Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener, with their meanings as quoted in the Values cheat sheet.
4. Search "Saltmarsh Games interview process live operations producer": returned https://saltmarshgames.com/careers/interviewing. Snippet only, not fetched: a recruiter call, then the Outage Hour, a single 60-minute interview with the hiring manager, a live-incident tabletop on a simulated outage during a live event, then a values conversation; no take-home.

**Research tier:** L1, searches 4 of 6, fetches 2 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet; V2 to V4 |
| 2. Saltmarsh Games interview process | yes | Loop structure; persona weights and the 60-minute format |
| 3. Saltmarsh Games strategy / recent news | yes | Query 1 returned no results, so the CO bank stays generic and no strategy is claimed |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Interviewer read; the talk theme; reverse questions 1 and 2 |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot |

The L2 targets (strategy brief, interviewer talks and writing, role-family loop reports, recent org context) did not run.

## Upgrade menu

- Your CV or résumé → quotes move from "your message" to "your CV", and the F1 and F4 confidence can be regraded.
- A post-event review or a KPI report you wrote → F5 and P2 move from an answer slot to an evidenced answer.
- Any second-title or live-event work, however small → F1 and A5 move from transferability.
- A description of the puzzle title's content model after launch → F3 moves from discovery.
- A written sample for people outside your team → F8 moves from low, and a written-communication question is added.
- Deep research (L2): a strategy brief, Tobias's other talks and writing, recent Saltmarsh news. Six more searches and two more fetches.
