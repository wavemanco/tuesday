Your prep pack is saved here: `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-5-denied-f2809088/275f9955-a4ae-4765-9617-61114ab8d44e/scratchpad/kelverton_senior-partnerships-manager_interview_pack.md`

**What's in it**

- **The POV is the priority.** It's a graded deliverable, so I built three theses, each with a concession. Thesis 1: operators' scarce resource is recovery time, not seats. Thesis 2: move to a joint roadmap with a few anchor operators. Thesis 3 is the anti-pick: decline some operator bids. Each one closes on a concrete operator benefit, which is what the recruiter asked for.
- **Ross's highest-return question is B1:** "You've never carried a direct quota. Why would we give you operator revenue targets?" Hold the £4M influenced-revenue figure at its own scope, then concede specifically. Rehearse it until the order is automatic.
- **Your gaps are stated, not inferred.** You've never carried a direct quota and never sold into rail. The pack gives you plain sentences for both, so you aren't improvising a denial under pressure.
- **Prohibited claims:** don't say you ran operator partnerships, owned the £4M, or carried a target. The pack lists these with the honest form of each.
- **Triage for your four hours:** about an hour on the POV, 45 minutes on Ross's pressure questions, 45 on commercials, then Deepa's case questions and the reverse questions.

**Limits of this pack**

- I haven't seen the market report. Without its shortlist, I can't say what the consensus answer is, so the differentiation step is unfinished. This is the biggest gap.
- No job description was supplied, so the requirement mapping rests on the recruiter's wording. If the JD makes rail selling or quota ownership a gate, the gap rows change.
- No research has run, and the interviewers' profiles are unknown. The values and strategy sections are generic until that's done.

**Three questions, in order of value**

1. Can you paste the market report's headline shortlist (findings only)? That unlocks the POV's differentiation.
2. Can you paste the JD text? Does it list rail selling or direct quota ownership as a requirement?
3. Do you want me to run a light research pass (up to 6 searches, 2 page fetches) on Kelverton's published values, current interview process and recent strategy? Deepa and Ross's public profiles would also help, if you share them.

Other options:
- I can play Ross on B1 as a live drill. Rehearsing it aloud will show you where the hold breaks.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, so they carry into later sessions.
- I can convert the pack to a Word document if you'd like one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

Round: second round, panel of 60 minutes. Deepa (VP Partnerships, future manager) and Ross (Commercial Director). First 15 minutes: spoken POV on operator partnerships over 18 months, no slides, landing on what it means for the operators. Remaining time: Q&A, with Ross pressing on commercials.

Built on: the recruiter's email as you quoted it, and your background as you described it. No job description, no market report text, no interviewer profiles, and no research were available. Research tier is L0.

## How to use this pack

- Personas describe how a question arrives. Types describe what is being scored.
- Type key: **EXP** work-experience deep-dive. **JD** role-driven. **CO** company and commercial knowledge. **CASE** live problem. **VAL** values (not detected in this round).
- Guidance is scaffolding, not a script. Say it in your own words. Anything you did not do, do not say you did.

## Prep triage (about 4 hours)

1. **60 min: build the POV.** Write the three theses in the graded-deliverable section in your own words, each with its concession. Time yourself out loud at 12 to 14 minutes.
2. **45 min: Ross's pressure.** Rehearse B1 and B5 until the hold-then-concede order is automatic. B1 is the highest-return prep in this pack.
3. **45 min: commercials.** B2 (how the £4M was counted), B3 and B4 (a pilot with no budget line, a long contract cycle).
4. **30 min: Deepa's case and skeptic questions.** A1, A3 and A5.
5. **20 min: the opener and the reverse questions.** A6 as a 90-second arc, then R1 to R5 out loud.
6. **Remaining time: check the fit snapshot's gaps.** Everything else is insurance.

## The fit snapshot

Requirements come from the recruiter's email, quoted from what you pasted. No job description was supplied, so no requirement is quoted from a JD. Confidence and provenance follow the suite's vocabulary.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "what it means for the operators themselves" — recruiter's email | "so I know the operator world from the other side" — your message | medium | [grounded] | presentation | Your material already reaches the operator view in your own words: "I know the operator world from the other side." Say it once, and do not add a transport project you did not describe. Answer slot: if a transport project changed how an operator bought or planned something, say which and what you did, in your own words; if none did, say the view is from the consultant's side of the table. |
| F2 | "Senior Partnerships Manager" — the role title | "took it from 6 partners to 40" — your message; "9 years in partnerships" — your message | high | [grounded] | none | No gap. Lead with the count in your own terms: six partners to forty, in the ISV channel. |
| F3 | "will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | presentation | Your material says influenced revenue, and that is the figure to say. The pack's own observation is that the material does not show how it was counted. Answer slot: the attribution rule, if you know it, in your own words; if you do not, say so, and say what you can see. |
| F4 | commercial accountability for partnerships (raised by "push on commercials") | "never carried a direct quota, only influenced revenue" — your message | high | [grounded] | capability | Stated absence. Words: "I've never carried a direct quota." Then the figure at its own scope: "roughly £4M of influenced revenue." Do not describe a quota, a target or a closed deal you did not own. |
| F5 | selling scheduling software to train operating companies — recruiter's email | "Never sold into rail specifically" — your message | high | [grounded] | capability | Stated absence. Words: "I've never sold into rail specifically." Pair it with F1 for the operator view, but never claim rail selling from it. If the JD makes rail selling a requirement or gate, this row becomes hard_gate; the JD is the one thing that would change it. |

## The prohibited list

Claims this pack will not coach, with the basis for each.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operator partnerships | Inflated form of F1 and F2: the material shows ISV-channel partnerships and transport consulting, not operator partnerships | F2's quote at its own scope: "took it from 6 partners to 40," in the ISV channel |
| Carried or owned a revenue target | Inflated form of F4 | "I've never carried a direct quota." Plain acknowledgment from F4 |
| Generated the £4M | Inflated form of F3: the figure is influenced revenue, and the material does not say it was yours alone | "roughly £4M of influenced revenue," at its own scope. B2's slot asks how it was counted |
| Sold into rail or knows rail buyers | Sourced negative, F5 | "I've never sold into rail specifically." Plain acknowledgment from F5 |

## The graded deliverable: 15-minute spoken POV

The recruiter's email pre-declares this deliverable. It is graded.

**Grounded facts to build on.** F1: "so I know the operator world from the other side" (your message). F2: "took it from 6 partners to 40" (your message). Both are quoted from your own words; the POV should not go beyond them.

**Thesis 1: the operator's scarce resource is recovery time, not seats.** Partnership value is measured in how quickly an operator can absorb a timetable change and recover from disruption. For an operator's operations director, the benefit is fewer weeks lost per change, and a recovery figure they can take to their own board.
- *Concession:* operators are measured under their own contracts and regulator terms. Kelverton may not control the outcome, and the metric may sit partly outside its reach.

**Thesis 2: move from vendor-and-customer to a joint roadmap with a small set of anchor operators.** The partnership is a standing working group, and operator planners shape what gets built. For the operator, the benefit is a say in what they will run next year.
- *Concession:* anchor operators can capture the roadmap and crowd out the rest. Year one trades breadth for depth.

**Thesis 3 (the anti-pick): decline some operator bids.** The role's real job includes saying no. Partnerships should focus on operators whose network mix the product serves best, and turn down the rest.
- *Concession:* this looks like narrowing the revenue base in front of a commercial director. Say why it is the better bet, with the operator's benefit first.

**Differentiation.** Cannot be finished yet. The consensus answer to "where to take operator partnerships" is probably more partners, outcome-based pricing and AI-assisted scheduling. I have not seen last quarter's market report, so I do not know its shortlist. Once you paste its headline shortlist, I can name the one consensus item to acknowledge and set the divergence against it.

**Close.** The recruiter asked you to land on what it means for the operators. End on one concrete operator benefit per thesis, in the operator's terms: weeks saved, a say in the roadmap, a bid they will not have to chase.

## Question banks

Weights come from the panel's known composition. Ross is pressing on commercials, so he takes the heavier bank. Deepa, as future manager, takes the case and skeptic bank. No public profile was available, so the persona weights rest on the round and the recruiter's note only.

### Persona table

| Persona | Who | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | Ross | Asks how the £4M was counted and which assumption you would defend least | High. The recruiter named commercials, and the figure is the likeliest thing he will test | Name the weakest assumption before he does. Say plainly when you do not know how a figure was counted |
| Pressure | Ross | Challenges the quota gap and the rail gap, and time-boxes answers | High, for the same reason as the Prober: F4 and F5 are stated absences, and they are the obvious probes | Hold the position through two follow-ups by returning to your own quote. Concede the gap specifically, never the whole claim |
| Case / Strategist | Deepa | Live problem about an operator with a timetable-change pain | High. As the hiring manager, she is buying capability and the POV is the first place she will test it | Clarify, then segment, then state what you would check first. Do not claim a past here |
| Skeptic | Deepa | Asks what carries over from payments and why now | Medium-high. Her first question will likely be about the gap between ISV channels and operators | Name one carryover and one thing you would do differently, as a plan |
| Conversational | Deepa or Ross | Opens with "walk me through the journey" | Medium. Casual register, still scored | A 90-second arc: transport consulting, then partnerships, then the channel, then operators |

### Bank B: Ross (Prober, Pressure, commercial)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a direct quota. Why would we give you operator revenue targets?" | JD, Pressure | [grounded] "never carried a direct quota, only influenced revenue" — your message | **Highest-ROI prep in this pack.** Hold-then-concede. Restate the figure at its own scope: "roughly £4M of influenced revenue." Hold through two follow-ups by returning to that figure. Concede specifically: you have not been measured on a direct quota. Then say what you would want to be measured on in the first quarter. Answer slot: if a target was ever set on an influenced figure, say what it was; if none was set, say so plainly. | F4 is the stated absence Ross will press on under commercials. The hold is only what the quote carries. |
| B2 | "Roughly £4M of influenced revenue. How was it counted, and which assumption would you defend least?" | EXP, Prober | [grounded] "roughly £4M of influenced revenue" — your message | Name, in your own words, the assumption behind the figure you would defend least, before he does. If you know the attribution rule, say it. If you do not, say you do not know how the figure was counted, and name what you can see. Answer slot: which part of the figure was yours, in your own words. | F3's figure is the one a figure raises; the pack does not supply a method. "I don't know" is an honest branch. |
| B3 | "An operator wants a pilot, but has no budget line for it. Walk me through what you'd propose." | CASE | [generic] | Clarify who owns the budget and what the pilot has to prove. Then propose a stage-gated scope, and leave pricing open until you have read the market report. Name the sign-off you would need. | A live commercial problem from the role. It asks about no past, so the guidance makes no claim about you. |
| B4 | "What commercial model would you propose for an operator with a long contract cycle?" | CO | [generic] | Start from the operator's budget year, not from your pricing. Say what you would test first, and what would change your mind. Do not name a price. | Ross is pressing on commercials, and this tests whether you can think at the operator's pace. |
| B5 | "Why would a train operator take your partnership seriously, when you've never sold into rail?" | EXP, Pressure | [grounded] "Never sold into rail specifically" — your message; "so I know the operator world from the other side" — your message | Plain acknowledgment: "I've never sold into rail specifically." Then the operator-side quote. Concede that the first months are about learning the buyer. Hold through two follow-ups. | F5 is the stated absence. The pack gives you the words, and the second quote is the one thing you can say in its own scope. |
| B6 | "Where do you think an operator's commercial priorities differ from its operations team's?" | CO | [generic] | Name the seam: operations feels the cost of disruption, and finance or the franchise team feels the contract penalty. Say which of those you would want to reach first. | Tests whether you can see the buyer's internal split. The guidance is role-family knowledge, not a claim about you. |
| B7 | "Sixty seconds: why you over someone who has sold into rail?" | Pressure | [grounded] "Never sold into rail specifically" — your message | Pause. Restate the question. Say the gap in one sentence, then the operator view in one sentence. Concede specifically. Do not apologize twice. | A pressure question about F5. Composure is what is scored. |

### Bank A: Deepa (Case / Strategist, Skeptic, Conversational)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A train operator's operations director says every timetable change costs them weeks and blames the vendor. Where do you start?" | CASE | [generic] — raised by "what it means for the operators themselves" (recruiter's email) | Clarify which changes, and whether the weeks are lost in planning, in testing or in rollout. Segment by change type. Then ask who owns the delay. Name what you would check first. Make no claim about your past. | The POV's own subject, set as a live problem. Tests structure before answers. |
| A2 | "What do you need to know about our operator customers before proposing anything?" | CO | [generic] | Name the segments you would ask about: franchise or concession type, the network they run, and how often they change timetables. Ask, do not answer. | Tests whether you know which questions matter in this market. |
| A3 | "Nine years of partnerships, four of them at a payments company. What carries over, and what doesn't?" | JD, Skeptic | [grounded] "9 years in partnerships" — your message; "last 4 at a payments company running the ISV channel" — your message | Carryover: partner recruitment and enablement, which the record "took it from 6 partners to 40" carries. Non-carryover: the buyer is a train operator, not a software-buying partner. Answer slot: name one thing you would do differently with an operator, if you have a view; if you do not, say so. | F2 and F1 are the carryover. The non-carryover is a general claim about buyers, not about you. |
| A4 | "Why this role, and why now, after four years on a payments channel?" | JD, Skeptic | [grounded] "so I know the operator world from the other side" — your message | Motivation from the operator side: the transport consulting, then what made you want to sell into it. Keep it short and true. | A motivation probe. The quote is your own; the rest is the story you tell. |
| A5 | "What would you do in your first 90 days with our operator partnerships?" | JD | [generic] | A plan, not a past. Start with listening to two or three operators. Then name one thing you would test from the POV, and what would make you drop it. | A standard question that the POV answers in part. Keep it consistent with theses 1 and 2. |
| A6 | "Walk me through the journey so far." | Conversational | [grounded] "5 years in transport consulting" — your message; "9 years in partnerships" — your message | A 90-second arc: transport consulting, then partnerships, then the ISV channel, then why operators. Keep the order and the numbers exactly as quoted. | Casual openers are scored. The arc is pre-set so you do not freeze. |

## Reading the interviewers

No public profiles were available. Deepa and Ross are named by the recruiter only, so no career pattern or self-described style is read here. The upgrade menu says what their profiles would add.

## Reverse questions

| # | Question | Ask | Why it lands |
|---|---|---|---|
| R1 | "What would a strong first six months look like for you?" | Deepa | Turns into a shared scorecard. Signals you will be measured, and that you want to be. |
| R2 | "Which two or three operators matter most over the next 18 months, and what do they need that they don't get today?" | Deepa | Tests your POV directly, and she can answer it with more than the report says. |
| R3 | "How are partnerships credited today: influenced, sourced, or split?" | Ross | Shows you know the difference between influence and direct revenue, and it tells you what the commercial model needs from you. |
| R4 | "Where has an operator deal stalled most often recently, and at what stage?" | Ross | Shows you think in cycles, and gives you the real procurement pattern. |
| R5 | "Which finding in last quarter's market review are you least sure of?" | Deepa | Shows you read the report critically, without reciting it. |

Note: the pack has five reverse questions and no interviewer-path question, because no profile was supplied.

## Sources

- Provided: the recruiter's email, as you quoted it in your message. The market report was described as read by you, but its text was not supplied, so no finding from it is used.
- Research: none run. Tier L0. Consent to research is asked in the message that presents this pack.

**Research tier: L0** — searches 0 of 0, fetches 0 of 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Values cheat sheet, which is absent because no values round was detected in the material. Would name the published values if research ran |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Loop structure and persona weights. Would confirm whether the panel is the whole second round |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Grounding brief and CO questions. Would make B4 and A2 current. Research not consented |
| 4. `Deepa` / `Ross` plus `Kelverton Rail` | unavailable | Interviewer read and an interviewer-path reverse question. Only names were given, so the query is formable; not run pending consent |
| 5. Representative `Senior Partnerships Manager` JD | unavailable | Would turn the requirement rows into `[inferred]` and give a coverage line. Not run pending consent |

## Requirement coverage

No job description was supplied, so no requirement could be mapped to a question. The recruiter's own requirements are covered: "what it means for the operators themselves" by A1, B3 and B4; "push on commercials" by B1 to B5; the title and the seniority by A3 and A6.

## Upgrade menu

- **The job description text** → the fit snapshot's requirement rows become `[grounded]`; the coverage line maps every requirement to question IDs; and it shows whether rail selling or direct quota ownership is a gate (F4 and F5 would change to `hard_gate` if it is).
- **The market report's headline shortlist** (paste the findings only, not the whole document) → the differentiation step, naming the consensus item to acknowledge and the one divergence to make. This is the most valuable missing input for the POV.
- **Deepa's and Ross's public profiles** (LinkedIn or published talks, if you have them) → persona weights from their career pattern, and an interviewer-path reverse question.
- **Research at L1 (up to 6 searches, 2 fetches)** → Kelverton's published values, the current interview process, and recent strategy and news, so the POV and the commercial questions sound current.
- **Your prep time** is already accounted for in the triage above. If the second round is at a different time, the triage re-sizes.
