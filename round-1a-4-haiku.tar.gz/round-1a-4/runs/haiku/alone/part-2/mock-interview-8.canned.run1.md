Your prep pack is saved as /var/tmp/tuesday-measure/1a4/runs/haiku/alone/part-2/rooms/case-8-canned-b7dacc97/ashgrove_member-experience-lead_interview_pack.md. It has three mini-packs, one per round, because the three rounds are on the same day and each has a different interviewer type.

I built it from your JD, your background as you wrote it, the values you pasted, the strategy summary, and the recruiter's round structure. I ran no web searches because your inputs already cover every target. The biggest gaps the pack finds are the contact centre, presenting above regional level, and digital work. Round 2's highest-return rehearsal is R2-1, the "which part would you be weakest at on day one" question. Round 3's 20-minute case is in section 10, and it is generic: check your firm's own complaint timescales before the day.

Would you like a live drill? I can play the Head of Member Services on R2-1 and give feedback against that question's guidance. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead. Interview prep pack

**Role:** Member Experience Lead
**Company:** Ashgrove Credit Union (member-owned, about 900 staff)
**Candidate:** Dara
**Interview date:** 3 December 2026, three rounds
**Round 1:** 30 minutes with the recruiter
**Round 2:** 45 minutes with the Head of Member Services, your future manager, mostly behavioural. Name not given.
**Round 3:** 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation. Scored against the four values. Names not given.

Loop mode: one shared fit snapshot and sources block, then one mini-pack per round with its own persona weights, bank and reverse questions.

---

## 1. How to use this pack, and the type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script. Rehearse the shape of each answer in your own words, and never memorise a sentence that claims more than you did.

| Type | Meaning |
|---|---|
| VAL | Behavioural and values: does past behaviour show the published values |
| EXP | Experience deep-dive: does what you did survive scrutiny |
| JD | Role-driven: can you do the listed job, including its gaps |
| CO | Company and strategy: do you know where the business is heading |
| CASE | Live problem: how you structure and reason through one problem from the role |

**Sources of quotes.** Every quoted sentence about you comes from your message, marked "your message". Every requirement comes from the job description you supplied, marked "JD". Values are the ones you pasted from ashgrovecu.org/about/values on 24 November 2026. The strategy points are from the July 2026 brief as you summarised it for me.

---

## 2. Requirement coverage

Each JD requirement, the question IDs that cover it, and what is not covered.

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | R1-1 |
| Experience handling regulated complaints | R2-3 |
| Confident presenting to senior leaders | R2-2 |
| Comfortable with Excel reporting | R2-7 |
| Own the member complaints process end to end across branches and the contact centre | R2-1, R3-5, R3-9 |
| Report monthly on complaint volumes and resolution times | R2-7, R2-11 |
| Coach branch supervisors on escalations | R2-6, R3-7 |
| Work with digital teams on self-service journeys | R2-8 |

Nothing in the JD is left without a question.

---

## 3. Fit snapshot

Requirements are quoted from the JD. Your evidence is quoted from your message, verbatim. Gap and bridge language uses only those quotes, plus the gaps you stated yourself.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | The quote reaches the requirement. Say it in those words: six years in retail banking, the last three as a branch supervisor. Expect a probe on whether a branch counter counts as customer operations; answer in your own words about what the branch did with customers. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | The material shows a formal complaints log. It does not show whether that log was regulated or what timescales governed it. Answer slot: if the log followed set regulatory or internal timescales, say which, and what you did to meet them. If no such rule applied, say so plainly, and describe how the log ran. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material shows one branch's log, not the process end to end across branches. Words: "I handled the branch's formal complaints log." Any wider step is an answer slot inside the branch: which stages of a complaint you decided, and how. |
| F4 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never worked in a contact centre." Then how you would learn the contact-centre side, as a plan, never as something you have done. |
| F5 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never presented to anyone above regional level." Then how you would prepare to present to senior leaders, as a plan. |
| F6 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Say it as written: "I built the monthly complaints spreadsheet our regional manager uses." Do not name Excel unless you used Excel. |
| F7 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | The quote shows a monthly complaints report. It does not show whether volumes or resolution times were in it. Answer slot: which measures it carried. If resolution times were in it, say how they were counted. If not, say so plainly, and say what you would add. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Your material shows coaching at teller level, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: whether you coached supervisors on escalations, in your own words. If not, say so, and say what you would do with supervisors. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show digital-team work. Answer slot: if you worked with a digital or self-service team, say what you did in your own words. If you did not, say so, and say what you would bring. |

**What the snapshot shows.** Your strongest ground is six years of retail banking, three of them as a supervisor, and the complaints log and spreadsheet. The three weakest areas are the contact centre (F4), presenting above regional level (F5) and digital work (F9). The regulated-complaints question (F2) and the resolution-time measures (F7) are where a prober will go next, because your material does not show them yet.

---

## 4. Prohibited claims

These are wordings this pack will not coach, because your material does not support them. Each is built from the fit snapshot. The basis is given for each.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end across branches and the contact centre | Inflated form of F3. Your sentence says one branch's log. | F3's quote at its own scope: "I handled the branch's formal complaints log." The limit is this pack's observation: the material shows one branch's log, not the process end to end. |
| Handled regulated complaints | Inflated form of F2. Your sentence does not say regulated. | F2's quote at its own scope. The regulatory question is an answer slot, not a claim. |
| Has worked in a contact centre | Negative you stated, F4 | Plain acknowledgment: "I've never worked in a contact centre." No slot. |
| Has presented to senior leaders | Negative you stated, F5 | Plain acknowledgment: "I've never presented to anyone above regional level." No slot. |
| Tracked and reported resolution times | Inflated form of F7. Your sentence does not name resolution times. | F7's quote at its own scope. What the spreadsheet carried is an answer slot. |
| Trained branch supervisors on escalations | Inflated form of F8. Your sentence says tellers. | "I trained new tellers on our escalation script." |
| Used Excel | Tool named that you did not name. | "I built the monthly complaints spreadsheet our regional manager uses." |

---

## 5. Grounding brief: what to sound current on

Source: the July 2026 strategy brief, as you summarised it.

- **Digital shift.** Move 40% of member service to digital channels by 2028. Expect this to come up in round 2 and round 3.
- **Branch consolidation.** Eight branches become five hubs over 2027. Your branch-supervisor background makes this a real topic for you, not an abstract one.
- **Small-business lending.** Launch in Q1 2027.
- **Competitive pressure.** App-only banks.
- **Values as the spine.** Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix. Round 3 scores against them.

Use the company's words: "member service", "digital channels", "hubs", "members". Do not repeat the brief back to the interviewers as though you were quoting it.

---

## 6. Values cheat sheet

Detected: round 3 is scored against the four values. Official names are used. Each value maps to a quote where one of your sentences carries a story. Where none does, a selection scaffold ends in an honest branch.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F3: "I handled the branch's formal complaints log" (your message). Pick a complaint from the log where the member's side changed your decision. If none did, say so, and give the nearest case you handled. |
| Plain Words | If a member needs it explained twice, the writing was wrong | F8: "trained new tellers on our escalation script" (your message). Pick a time an explanation had to be given again, and what changed. If nothing changed, say so, and say what you would check first. |
| Neighbours, Not Numbers | Every branch is part of its town | No quote carries a story. Pick a decision where you knew how it would land on the people that branch served. If none comes to mind, say so, then say how you would test a hub decision against the town. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F7: "I built the monthly complaints spreadsheet our regional manager uses" (your message). Pick a problem you found and kept hold of until it was fixed. If the spreadsheet showed you one, say so. If not, say so, and give the nearest case. |

---

## 7. Round 1: recruiter screen

**Weights.** The recruiter prior is conversational, with a light skeptic. Round 1 covers pay, notice, location and reason for leaving, and each of those is a logistics slot. Conversational carries five questions, Skeptic carries two. Round 1 is screened as a knockout round.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured openers; logistics asked casually | High. This is the recruiter's stated register. | Practise your 90-second arc. Treat casual logistics as scored. |
| Skeptic (light) | Motivation and the contact-centre gap, asked lightly | Medium. The recruiter's prior, and F4 is the obvious gap. | Say the negative plainly, then the plan. |

**Round 1 bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-1 | "Walk me through your background, the short version." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | Open with the six years and the three as a supervisor, then the complaints log, in those words. Add nothing. Stop at about 90 seconds. | F1 and F3 are the arc. This is the most likely opener. |
| R1-2 | "What drew you from branch work to member complaints?" | EXP | [grounded] "I handled the branch's formal complaints log" | Answer slot: say what drew you to the complaints work itself, in your own words. The material does not say why. | Motivation is a Skeptic probe. The answer has to be your own. |
| R1-3 | "You've never worked in a contact centre. How do you approach that?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then answer slot: if you have had work close to a contact-centre queue, say what it was. If not, say so, and say how you would learn the operation, as a plan. | F4 is the gap. Name it first, then the plan. |
| R1-4 | "What are your pay expectations for this role?" | JD | [generic] logistics slot | Logistics slot: give your own figure, in your own words, or ask for the role's band first. No figure is in your material, so the pack supplies none. | Pay is a recruiter knockout. You decide the number. |
| R1-5 | "What is your notice period?" | JD | [generic] logistics slot | Logistics slot: give your actual notice period. Say it once, plainly. | Notice is a knockout. No figure is in your material, so none is supplied. |
| R1-6 | "The bank is consolidating eight branches into five hubs in 2027. Which locations could you work from?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" (your strategy summary); logistics slot | Logistics slot: say which locations you can work from, in your own words. If you have a limit, state it once, in the same words. | Location matters more with hubs. The question is the recruiter's, from the brief. |
| R1-7 | "Why are you looking to leave your current role?" | EXP | [generic] logistics slot | Logistics slot: give the reason you would give a colleague, in your own words. Keep it about the work, not about people. | Reason for leaving is a standard screen question. Your answer, not the pack's. |

**Reverse questions for the recruiter (round 1)**

1. "What happens between this screen and the panel, and what is the decision timeline?" Why it lands: it shows you are planning, and it tells you whether the 3 December date is firm.
2. "Who is the Head of Member Services, and how much of the round-two focus is on complaints?" Why it lands: it tells you what the manager wants covered, and you can prepare for it.
3. "What does the panel score, and is there a written scale for the four values?" Why it lands: a written scale tells you exactly where round three is scored.
4. "Which parts of the role are changing with the digital shift and the hubs?" Why it lands: it signals you have read the brief, and gets you the answer from the person who knows it.
5. "What would the first 90 days look like for someone starting in this role?" Why it lands: it shows you are already thinking about the job, and the answer tells you what the manager needs first.

---

## 8. Round 2: Head of Member Services (your future manager)

**Weights.** The hiring-manager prior is case and strategy, with skeptic. The recruiter says this round is mostly behavioural, so values and behaviour move up and case moves down. Skeptic stays high because the JD gaps are where the manager will probe.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Scenario questions about past handling, scored against the company's values | High (weight 3). The recruiter says the round is mostly behavioural. | Use the story shapes in section 6. Say "we" for context and "I" for what you did. |
| Skeptic | Probes on the gaps: scope, presenting, regulated complaints | High (weight 3). A future manager is buying capability and checking for gaps. | Rehearse the highest-return objection until it is plain. Name the gap before it is named for you. |
| Data-Driven Prober | Asks how the spreadsheet's numbers were counted | Medium (weight 2). The JD names monthly reporting. | Name the weakest assumption before it is named for you. Say what you don't know. |
| Case / Strategist | Digital shift and hub consolidation, applied to complaints | Medium (weight 2). Strategy is in the brief. | Clarify first, then structure. Use the company's own words. |
| Conversational | A casual opener | Touch only. The round is behavioural, so the round-one arc carries over. | Use the round-one arc. |

**Round 2 bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-1 | "You've handled one branch's complaints log. This role owns the process across branches and the contact centre. Which part would you be weakest at on day one?" | JD | [grounded] "I handled the branch's formal complaints log"; plain acknowledgment "I've never worked in a contact centre." | **The highest-return rehearsal in this pack.** Hold: "I handled the branch's formal complaints log." Concede specifically: "I've never worked in a contact centre." Then your plan for the first 90 days on the cross-branch and contact-centre side, as a plan. Hold through two follow-ups by returning to the log. Do not add a contact-centre story. | This is the single most likely objection. F3 and F4 are the gap. Rehearse until the concession is calm. |
| R2-2 | "The role needs confidence presenting to senior leaders. You've never presented above regional level. How would you handle that?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Then how you would prepare, as a plan: what you would practise, and with whom. | F5 is the gap. Say it as a fact, then the plan. |
| R2-3 | "Tell me about the regulated complaints you've handled." | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: if the log followed set regulatory or internal timescales, say which, and what you did to meet them. If no such rule applied, say so plainly, and describe how the log ran. | F2 is the premise the JD raises. The second branch lets the premise be false. |
| R2-4 | "Tell me about a time you made a decision from the member's side that the branch didn't want." | VAL | [grounded] "I handled the branch's formal complaints log"; value "Members First, Always" | Story scaffold: pick a complaint from the log where the member's side changed the decision. If none did, say so, and give the nearest case. Say what you did, not what the branch did. | Members First is the first value. Open prompt, from the published value. |
| R2-5 | "When have you taken hold of a problem until it was fixed, even when it wasn't yours to fix?" | VAL | [grounded] value "Own the Fix"; "I built the monthly complaints spreadsheet our regional manager uses" | Scaffold: pick a problem you found and kept hold of until it was solved. If the spreadsheet showed you one, say so. If not, say so, and give the nearest case. | Own the Fix. Do not claim a problem you did not find. |
| R2-6 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story scaffold: the nearest is training tellers on the escalation script. Answer slot: if you coached a supervisor on an escalation, say what you did, in your own words. If not, say so, and say what you would do with supervisors first. | F8. The JD asks about supervisors, so the honest answer may be the teller case. |
| R2-7 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say it as written. Answer slot: which measures it carried, in your own words. If resolution times were in it, say how they were counted. If not, say so plainly, and say what you would add. Do not describe any figure you did not track. | F6 and F7. EXP because it tests what you did. |
| R2-8 | "This role works with digital teams on self-service journeys. What did you do with digital channels?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Answer slot: if you worked with a digital or self-service team, say what you did, in your own words. If you did not, say so, and say what you would bring. Do not describe digital work you did not do. | F9 is the gap. Honest either way. |
| R2-9 | "Forty percent of member service moves to digital by 2028. What stays human in the complaints process?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your strategy summary); reasoning [generic] | Think aloud: name the complaints that need judgement and a person, and the ones that can go through a self-service route. Use the company's words. Do not invent a digital statistic. | The digital shift is the company's own stated strategy. |
| R2-10 | "Eight branches become five hubs in 2027. What happens to open complaints when a branch closes?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (your strategy summary); reasoning [generic] | Structure it: open complaints keep their deadlines, each member keeps a named contact, and records move with the case. Say what you would check first, and what would not change. | Your branch-supervisor background is the honest ground for this. |
| R2-11 | "The role reports monthly on resolution times. What would you check before trusting that figure?" | JD | [grounded] "report monthly on complaint volumes and resolution times" (JD); "I built the monthly complaints spreadsheet our regional manager uses" | The weakest-assumption move: name the assumption you would defend least, in your own words. If you have never produced a resolution-time figure, say so plainly. | F7. A metric question, so name the assumption before it is named for you. |

**Reverse questions for the Head of Member Services (round 2)**

1. "What does a good first six months look like in this role, and what would make you say it went badly?" Why it lands: it shows you are planning to be measured, and gets the manager's own yardstick.
2. "Which of the eight branches is the first to become a hub, and what do you need the complaints process to do for it?" Why it lands: it ties the question to the consolidation, and shows you are thinking about members in that town.
3. "How do you want escalations handled between the branches and the contact centre today?" Why it lands: it shows you have looked at the seam that the role owns.
4. "Where do you see the complaints process going when the digital share reaches 40 percent?" Why it lands: it invites the manager to say what they are measuring toward.
5. "What did the last person in this role get right, and what would you change?" Why it lands: it gives you the manager's view of the role without asking about the person.

---

## 9. Round 3: panel of two branch managers

**Weights.** The values-round prior is values and behaviour, with conversational. The 20-minute case adds case and strategy. The top two personas are values and case, blended for a panel. Pressure and skeptic appear as follow-ups, since two managers will each push a little. The panel's names are unknown, so the weights are blended and not assigned per member.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Scored scenarios against the four values | High (weight 4). The recruiter says the panel scores against the values. | One story per value, section 6. Say the hard truth where it landed. |
| Case / Strategist | The 20-minute complaint escalation, plus a strategy question | High (weight 3). The case is in the panel. | Clarify, then structure, then the member's side, then the fix. Think aloud. |
| Pressure | "That result — how much of it was actually you?" | Medium (weight 2). Two managers can each push. | Hold the position through two follow-ups. Concede the specific part you do not know. |
| Skeptic | Scale: branch to network | Medium (weight 1). Branch managers test whether a branch habit scales. | Say what you handled, and what you would check before scaling it. |

**Round 3 bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-1 | "Tell me about a time you made a decision from the member's side that cost the branch something." | VAL | [grounded] "I handled the branch's formal complaints log"; value "Members First, Always" | Story scaffold: a complaint from the log where the member's side changed the decision and it cost something. If none did, say so, and give the nearest. | Members First. Say the cost honestly. |
| R3-2 | "Tell me about a time someone needed a thing explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script"; value "Plain Words" | Story scaffold: an explanation that had to be given again, and what changed. If nothing changed, say so, and say what you would check first. | Plain Words. The teller training is the nearest material. |
| R3-3 | "Tell me about a decision where you knew how it would land on the people in one town." | VAL | value "Neighbours, Not Numbers" | Story scaffold: a decision where you knew the town's side. If none comes to mind, say so, then say how you would test a hub decision against the town. | Neighbours. The hubs will test this value. |
| R3-4 | "Tell me about a problem you stayed with until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses"; value "Own the Fix" | Story scaffold: a problem you found and kept hold of until it was solved. If the spreadsheet showed you one, say so. If not, say so, and give the nearest case. | Own the Fix. Do not claim a problem you did not find. |
| R3-5 | "A member has complained three times about the same charge. The branch supervisor closed it twice. The member says they'll take it further. Talk us through the next twenty minutes." | CASE | [generic] case; [grounded] value "Own the Fix" | **The escalation case.** See the case structure below. | Round 3 has a 20-minute case, and this is the most likely shape. |
| R3-6 | "What does a branch supervisor usually get wrong about escalations?" | CASE | [grounded] "coach branch supervisors on escalations" (JD); "trained new tellers on our escalation script" | Answer slot: say what you have seen go wrong, if you have. If you have not, say so, and say what you would check first with a supervisor. | Coaching supervisors is the JD's line. |
| R3-7 | "That spreadsheet your regional manager uses. How much of the result is actually yours?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold: "I built the monthly complaints spreadsheet our regional manager uses." Concede the specific part: how the manager uses it is theirs, and you do not know what they do with it. Hold through two follow-ups by returning to the sentence. | Pressure. The honest answer is the part you built and the part you cannot see. |
| R3-8 | "Our digital target is 40 percent by 2028. What would you keep human in complaints?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your strategy summary); reasoning [generic] | Think aloud: keep a person on the complaints that need judgement, and say what you would check before moving a route to self-service. | Strategy at the panel's altitude. |
| R3-9 | "We run eight branches and you've run one log. Why should we trust you across all of them?" | JD | [grounded] "I handled the branch's formal complaints log"; "consolidate eight branches into five hubs over 2027" | Hold: "I handled the branch's formal complaints log." Concede: scale is the part you have not done. Then what you would check first before trusting a branch habit across the network. | Pressure on scope. Concede specifically, never fold on the log. |

**Reverse questions for the panel (round 3)**

1. "How do you decide a complaint is fair to the member when policy says otherwise?" Why it lands: it turns the values into a real decision, and you see how the panel reasons.
2. "What separates a supervisor who escalates well from one who doesn't?" Why it lands: it shows you are thinking about coaching the people in the role.
3. "What did the best complaint outcome in your branch look like, and who decided it?" Why it lands: it asks for a story from the panel, and tells you what they count as a good fix.
4. "What could a new Member Experience Lead do in their first month that would genuinely help your branches?" Why it lands: this is the reciprocity question for a panel that works across branches.
5. "Which of the four values do you find hardest to hold day to day, and why?" Why it lands: it shows you have thought about the values as work, not slogans.

---

## 10. The 20-minute case: structure

This case is generic. It is a pattern for the problem, not a fact about Ashgrove. Check your firm's own complaint timescales and policy before the day.

1. **Clarify (about 2 minutes).** What the member asked for. What has been done. What the supervisor said. What the complaint timescales are. Ask before you structure.
2. **Stop the next contact going wrong (about 2 minutes).** One named owner. One plain-words contact with the member. Say what happens next and when.
3. **Check for a pattern (about 4 minutes).** Is this one member, or the same charge at other branches? Say what you would look at. If your report carries that measure, say so. If it does not, say what you would add.
4. **Decide from the member's side (about 5 minutes).** Separate "what the policy says" from "is it fair to this member". Say which one you are deciding on, and why.
5. **Own the fix (about 4 minutes).** Keep the complaint until it is closed. Set a date you will report back on.
6. **Coach (about 3 minutes).** Name what the supervisor needs: how to read the member's side of an escalation.

**Hold.** If a panellist says "policy says no", hold the member's side, and concede the policy point specifically: "You're right about the policy. I'd still want to check whether the member understood it."

---

## 11. Sources and research

**Provided documents.**
- The job description, as you pasted it.
- Ashgrove's values, as you pasted them from ashgrovecu.org/about/values on 24 November 2026.
- The recruiter's process email: three rounds on 3 December, the round structure, and the panel's values scoring.
- The July 2026 strategy brief, as you summarised it.
- Your background, as you wrote it in your message.

**Searches and fetches.** None were run. Every target is answered by the inputs above.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page fixes the values cheat sheet (section 6). |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the loop structure and the persona weights. |
| 3. Ashgrove strategy and recent news | skipped | The pasted strategy brief fixes the grounding brief (section 5). |
| 4. Interviewer name | n/a | No names were given, so there is no query to form. The interviewer read is absent. |
| 5. Representative JD for the role | skipped | The supplied JD fixes the fit snapshot and the JD questions. |

---

## 12. Upgrade menu

- **Head of Member Services' name** → a persona read from their public footprint, and a tailored reverse question for round two.
- **Round 3 panel names** → persona weights for each panel member, and a tailored reverse question for each.
- **Any real contact-centre work, even small** → turns F4 from a stated gap into a worked example, and R1-3 and R2-1 can rest on it.
- **Any regulated-complaints detail, such as the timescales or rules your branch worked under** → turns F2 from a discovery gap into a stated answer, and R2-3 becomes a story.
- **The column list of the monthly spreadsheet** → turns F7 from a discovery gap into a stated answer, and R2-7 and R2-11 become precise.
- **Any figure or constraint you're prepared to state on pay, notice or location, in your own words** → fills R1-4 to R1-6 without changing the guidance.
- **A deep-research pass at L2** → the full strategy brief, the interviewers' published talks, role-family loop reports and recent organisation news. Offered once. It would cost up to six further searches and two further fetches.
- **A `tuesday-dossier.md`** → would record the evidence this pack leans on, and keep the prohibited list tied to verified evidence.
