I'll read the skill's reference files before building the pack, starting with the ones it names for synthesis and delivery.
The skill's rules are specific, so I'm checking the research targets before writing anything: the company's strategy and the interviewer's public footprint. Values only matter if a values-style round exists, and this one is a peer conversation.
Both searches were refused, so this session has no research and the pack will rest on your inputs alone. Before writing, I'm reading the output-discipline rules, since they govern the message and the saved file.
I have what I need. Both searches were refused, so the pack rests on your inputs and your research note. Writing the pack file now.
Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-2-rooms-case-1-denied-91c175f5/a6a4e92c-6af9-449a-ae8b-d28fa38f86c5/scratchpad/northwind-data_senior-gtm-strategy-lead_interview_pack.md, and I've attached it above. It has 22 questions across seven personas, with the fit snapshot, answer guidance and rationale for each question.

Both web searches were refused, so the company facts come only from your research note, which is undated. Please confirm it's current before using the Compass and priorities lines.

The biggest prep item is D2, "How would you set the first-year volume target for a new product line that has no sales history?" Priya has no quota-setting or sales-ops experience, and a sales-strategy peer is the most likely person to press on that. The pack gives her no words for that gap until she confirms it in her own voice; your note is the only source for it.

Two other points to rehearse: the ~$400M figure (she "proposed" the change, which was "credited with" the uplift, so how the figure was counted and who credited it are both likely probes), and the B2B gap, since her background is consumer-tech.

Say the word and I'll play the Skeptic on D2.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Northwind Data: Senior GTM Strategy Lead, Emerging Products

**Interview:** Dan Kovac, Director of Sales Strategy. Peer, same VP. One 60-minute conversation.
**Candidate:** Priya. Built from your message only. No company research ran (both searches were refused), so the company facts here come from your research note.

---

## 2. How to use this pack

- **Personas** describe how a question is asked. **Types** describe what it scores.
- **Type key:**
  - **VAL**: values or behavioral. Does past behavior show the trait?
  - **EXP**: experience deep-dive. Do her claims survive scrutiny, and what was hers?
  - **JD**: role-driven. Can she do the listed job, gaps included?
  - **CO**: company and strategy knowledge. How deep is her homework?
  - **CASE**: live problem. Is her structure and reasoning sound?
- **IDs:** A (Peer), B (Prober), C (Case), D (Skeptic), E (Pressure), K (Conversational), V (Values). F1 to F8 are fit-snapshot rows.
- **Guidance is scaffolding, not a script.** Say only what you did, in your own words.
- **Highest-ROI prep: D2.** It is where the material is thinnest and where a sales-strategy peer is most likely to press.

---

## 4. Fit snapshot

No requirement in the JD highlights is a gate (no location, work authorization, pay or credential is stated), so no row is a `hard_gate`. The full JD may add some (see the upgrade menu).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights you supplied) | "9 at a large consumer-tech company in product strategy & ops" (coach's notes); "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | transferability | The material shows product strategy and ops, not GTM ownership of a launch, and no GTM decision of yours. Words: "For nine years I worked in product strategy and ops at a large consumer-tech company." Answer slot: if you made a go-to-market decision for a launch, say which and how you decided. If you did not, say so and stay with the store-surface change, at its own scope. |
| F2 | "run independent analysis in SQL and Tableau" (JD highlights you supplied) | "skilled in SQL/Tableau" (coach's notes) | low | [inferred] | discovery | The material says skilled, not that you ran analyses alone. Answer slot: name one analysis you ran in either tool, from raw data to decision. If the work was shared, say which part was yours. If there was no such analysis, say what you have done in either tool. |
| F3 | "partner-motion design experience required" (JD highlights you supplied) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | Words: "I built a partner-level revenue model used in carrier negotiations." The material shows a model used in negotiations, not partner-motion design. Answer slot: if you shaped partner terms or channel rules beyond the model, say which. If you did not, say the model was the part you built. |
| F4 | "identify whitespace across land/adopt/expand/renew" (JD highlights you supplied) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | low | [inferred] | transferability | The model is adjacent: it sits in negotiations, not in a stage-by-stage whitespace map. Nothing in the material shows whitespace work. Answer slot: if you have mapped revenue by stage, say which stages and what you found. If you have not, say how you would find whitespace first. |
| F5 | "strong cross-functional influence" (JD highlights you supplied) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | presentation | Reword only the quote: "I set annual volume targets with cross-org consensus." Consensus is the material's word, not a record of influence over a decision you did not own. A probe on who disagreed is likely; the honest answer is whatever happened. |
| F6 | "AI experience a plus" (JD highlights you supplied) | "uses AI tools daily" (coach's notes) | low | [inferred] | discovery | Words: "I use AI tools daily." The material shows use, not building. Answer slot: if you built something with them, name it and what it produced. If you have only used them, say so and say for what. |
| F7 | "B2B data-infrastructure SaaS" (your company description, not a JD line) | none given | none | [grounded] | discovery | The material shows no B2B work. That is silence, not a stated absence, so the words are an answer slot: if you have worked with business or enterprise customers, name them. If your work was consumer-side only, say so, name the part that transfers, and say what you would learn first. |
| F8 | Sales-ops and quota-setting experience (no JD line; your note names it as absent) | none given (coach's note: "No classic sales-ops or quota-setting experience") | none | [grounded] | capability | Your note is the only source for this absence; Priya has not said it herself. Once she confirms it in her own words, the words are: "I haven't done classic sales ops or quota-setting." Until then, use no words for it. See prohibited-list row 7. |

**Gap-type notes.** F1, F3 and F5 each have a quote that reaches the requirement in role terms, or reaches it partly. F2, F4, F6 and F7 are discovery rows because the material is silent or the quote does not show whether it reaches the requirement. F8 is the only capability row, and it rests on your note, not on her statement.

---

## 6. Grounding brief (from your research note)

| Item | Source | Status |
|---|---|---|
| Stated priorities: "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | your research note | Use the note's words. The note is undated, so confirm it is current before relying on it. |
| Main competitive threat: "bundling by a much larger platform vendor" | your research note | Same caveat. |
| Competitor names, financials, leadership changes, recent moves | none | Not established. No research ran. Do not add them. |

---

## 7. Reading the interviewer

Public basis only: the self-description and career outline you gave.

| Signal | Public basis | What it means for the session |
|---|---|---|
| Pricing and monetization career | your note | Case questions lean toward pricing and packaging. C1 is written that way. |
| Self-described "relentlessly data-driven" | his profile, as you read it | Every metric you give will be probed to its assumptions. Section B rehearses that. |
| One early-stage startup chapter | his profile | Builder stories land well, and scrappiness probes are likely ("with no data, what did you do?"). Priya has no startup in her material, so those answers are answer slots. |
| Mirror opportunities | none | No shared professional path is established between her record and his. Do not offer one. |

No talks, posts or writing were checked (search refused).

---

## 8. Persona table and weights

**Relationship prior:** peer. Peer Evaluator and Data-Driven Prober lead.
**Interviewer-signal adjustment:** the self-described data focus moves the Prober up. The pricing career moves the Case questions toward pricing.
**Loop:** no loop source establishes a structure for this session, and no archetype fallback is applied. Weights rest on the peer prior, the interviewer read and the round type, not on a documented process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Peer Evaluator | Seam questions, reciprocity, disagreement with an equal | Top weight. A peer prices what the hire costs his own work. | Name seam principles, not a map. Give reciprocity. Tell one disagreement with spine and tact. | A1 to A5 (5) |
| Data-Driven Prober | Denominators, attribution, assumptions | Top weight. The self-description is the strongest signal in the read. | Say what you can and cannot say about how each figure was counted. Name the weakest assumption first. | B1 to B5 (5) |
| Case / Strategist | Pricing and lifecycle problems live | Mid weight. The pricing career tilts the cases. | Clarify, then structure, then metrics, then risks. | C1 to C3 (3) |
| Skeptic | The gaps: B2B, sales strategy, GTM ownership | Mid weight. The sales-strategy gap is the one a peer in that seat is most likely to press. | Rehearse D2 until it is boring. Concede exact limits, not the whole claim. | D1 to D3 (3) |
| Pressure | Composure on the $400M and on fit | Low weight. A peer chat is not a stress round, but one hold is still needed. | Hold the quoted position, then concede only what she does not know. | E1 to E2 (2) |
| Conversational | Biography, AI | Low-mid. Casual openers are scored. | A 90-second arc. Treat AI as scored. | K1 to K2 (2) |
| Values / Behavioral | Disagreement, customer-first | Low. No values round is detected here. | A selection scaffold ending in the honest branch. | V1 to V2 (2) |

**Total: 22 questions.**

---

## 9. Question banks

### A. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between your work and ours, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Name the seam as a principle: who decides what, and which numbers each team reads. Do not claim to know his team's seam. Reciprocity: say what you would bring to his team. On disagreement, tell one time it was settled, in your own words. For the targets, say how you set them with cross-org consensus. | Peer seam probe. F5 is the only story the material carries, so the answer stays at its scope. |
| A2 | "Walk me through the partner-level revenue model you built for carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Describe what the model was and how negotiators used it, in your words. Answer slot: if you set its inputs, say which and how you decided. If you did not, say what you did build. | F3 is the partner-motion evidence and the likeliest peer probe. EXP because it tests what was hers. |
| A3 | "What would you need from my team in your first 90 days to make the two new lines work?" | JD | [generic] | Name two things you would need and one thing you would give his team back. Keep the needs general until you have seen his team's data. Do not claim an inventory of it. | Reciprocity is expected from a peer. His side of the cost is what he is pricing. |
| A4 | "Where does GTM strategy for the two new lines stop, and pricing work on my side begin?" | JD | [inferred] derived from the JD line "own GTM strategy for two new product lines" and his pricing career (your note) | Propose a principle: who decides price and packaging, who owns channel and target choice, and which numbers each side reads. Do not claim knowledge of his team's current split. | The seam at pricing is the likeliest turf probe from a pricing peer. Labelled inferred because the seam is derived from the JD line and his career, not stated by anyone at Northwind. |
| A5 | "Northwind's stated priorities are enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability. Which should the two new lines serve first, and what would you give up?" | CO | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your research note, undated) | Pick one, justify it in one sentence, and name the cost. Use the note's own words for the priorities. Do not add current facts you have not checked. | Peer homework signal. The answer is only as current as the note. |

### B. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that store-surface change's uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Defend-the-number slots, in your words: how the figure was counted (if you do not know, say so), what it is sensitive to, the assumption you would defend least, and which part was yours. Hold to "I proposed the store-surface change." | F1 holds the figure. The first move on any headline number. No counting method is supplied here; the answer comes from her. |
| B2 | "Who credited the ~$400M to that change, and on what basis?" | EXP | [grounded] "credited with a ~$400M ARR uplift" (coach's notes) | Answer slot: if you know who made the attribution and how, say so. If you do not, say that plainly. Do not name a method, and do not restate the figure as your result. | The credit is a second claim, separate from the count, and a prober tests it after the count. |
| B3 | "Walk me through one analysis you ran in SQL or Tableau, from raw data to the decision it fed." | JD | [inferred] derived from the JD line "run independent analysis in SQL and Tableau"; "skilled in SQL/Tableau" (coach's notes) | Answer slot: if you ran one yourself, walk through the source data, the denominator, and the check you did. If the work was shared, or someone else wrote the query, name your part. If you have not run one, say what you have done in either tool. | F2 is low confidence: the material shows skill, not an analysis. JD type because the probe scores the stated requirement. |
| B4 | "Which input to that partner model would you trust least, and how would you know?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Name the weakest input you know of, before he does, in your words. If you did not test the inputs, say so plainly and say what you would check first. | Weakest-assumption move on F3. Only the model's existence is presupposed. |
| B5 | "AI experience is a plus here. What have you built with AI tools, as opposed to used?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Answer slot: if you built something, name it and what it produced. If you have only used the tools, say so and say for what. Do not call daily use a build. | F6 is low. The question makes the gap explicit, and the honest branch is the answer. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass launches as an AI copilot. How would you price it for existing enterprise accounts versus new logos?" | CASE | [grounded] (your research note, undated) | Clarify first: what the copilot is bundled with, and what the pricing unit is. Then objective, segmentation (existing versus new), approach, metrics and risks. Think aloud, and challenge one premise. | The pricing lens is his native language (section 7). A live problem, so it presupposes nothing about her past. |
| C2 | "A much larger platform vendor starts bundling a data-infrastructure product into its suite at no extra cost. What do you do with the two new product lines?" | CASE | [grounded] (your research note: "bundling by a much larger platform vendor") | Clarify the bundle's scope and which customers it reaches. Weigh three responses: compete on price, differentiate, or partner through the platform. Name the trade in each. The partner route connects to the JD's partner-motion line. | The main competitive threat from your note. The answer links the partner requirement to the threat. |
| C3 | "Where is the whitespace for the two new lines across land, adopt, expand and renew? Which stage would you look at first?" | CASE | [grounded] (JD highlights you supplied: "identify whitespace across land/adopt/expand/renew") | Name the data you would need for each stage, and the first cut you would make. Do not invent a baseline or a number. Say what you would check first, in the order you would check it. | Covers the JD's whitespace line, which no quote in the material reaches. The answer is structure, not history. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What in your background transfers to enterprise B2B data infrastructure, and what would you have to learn on day one?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (coach's notes); "B2B data-infrastructure SaaS" (your company description) | Answer slot: if you have worked with business or enterprise customers, name them in your own words. If your work was consumer-side only, say so, name the part that transfers, and say what you would learn first. | F7 is discovery: the material is silent on B2B, which is not the same as a stated absence. The question presupposes only the consumer-tech career the quote states. |
| D2 | "How would you set the first-year volume target for a new product line that has no sales history?" | CASE | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Answer slot, first: say what the nearest thing you did was, in your own words: the annual volume targets you set with cross-org consensus. Then how you would set a first-year target with no history: the inputs, the check, the owner. If you have not set quotas or run sales operations, say so in your own words, and only once you have confirmed that yourself (prohibited-list row 7). Do not call target-setting quota-setting. Hold the target-setting process. Concede the quota gap plainly. Three follow-up levels to rehearse: "which inputs?", "who signed off?", "what would you not know until a quarter in?" Answer each from the quote or from "not mine." | **Highest-ROI prep.** F5 and F8 are where this objection lands. The seat's sales-strategy work is his, and the material shows no quota or sales-ops history. The question presupposes nothing about her past, so it stays inside what the material carries. The concession words are hers to confirm before rehearsal. |
| D3 | "Why would the team trust that product strategy and ops carries over to GTM strategy for two new lines?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | Answer slot: name a go-to-market decision you made or shaped, in your own words. If there is none, say so, then give the nearest decision your material carries: the store-surface change, at its own scope. Do not argue the carry-over. | F1 gap, transferability. The question presupposes only the product-strategy career the quote states. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That ~$400M ARR uplift: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Pause and restate the question. Hold: "I proposed the store-surface change," through two follow-ups. Concede only what you do not know, named specifically, such as how the credit was divided, if you do not know. Never fold on having proposed it. | Composure test on F1's headline figure. The hold is the quote itself. A stronger hold than the quote carries would fail the second follow-up. |
| E2 | "Sixty seconds: why should we pick you over someone who has sold B2B infrastructure?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" and "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | A 60-second arc using those quotes, in order: consulting, then product strategy and ops, then the partner model and the cross-org targets. Hold the partner model. On B2B selling, say what your selling experience is. If you have none, say so plainly and move to the first-90-day plan. | Time-boxed fit pressure. The comparator is hypothetical, and the concession is an answer slot, not a claim. |

### K. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | A 90-second arc with two beats, each at the quote's scope: consulting, then product strategy and ops. End on the role you want, in your words. Do not add a reason for leaving; the material does not state one. | Casual biography is still scored. The words stay at the quotes' scope. |
| K2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Name the tools you use and the tasks, and one place they failed you. Say "use," not "build." | AI is a plus on the JD, and a casual question about a JD plus is scored. F6 is the evidence. |

### V. Values / Behavioral (weight 2)

No values-style round is detected, so this bank is low-weight and uses no published values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you had to hold a position with a peer who disagreed." | VAL | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Selection scaffold: pick a target-setting moment where a peer or another org disagreed. The beats the quote states are targets set and cross-org consensus. Say what you held and what moved, in your own words. If the consensus came without a dispute, say so. If no such time comes to mind, say so and give the nearest one. "We" for context, "I" for your part. | F5 carries the story shell. The dispute is not in the material, so the honest branch covers it. |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time a customer's need changed a target you were holding. If none comes to mind, say so plainly, then say how you would handle it. | Values-style persona stem. No quote carries a customer story, so this is a scaffold, and it makes no claim about her. |

### Requirement coverage

| JD or stated requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | A4, C1, D3 |
| identify whitespace across land/adopt/expand/renew | C3 |
| run independent analysis in SQL and Tableau | B3 |
| partner-motion design experience required | A2, B4, C2 |
| strong cross-functional influence | A1, V1 |
| AI experience a plus | B5, K2 |
| B2B data-infrastructure SaaS (your company description, not a JD line) | D1 |
| Sales-ops and quota-setting (your note, not a JD line) | D2 |

---

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career has run through pricing and monetization and one early-stage chapter. What did that chapter change about how you price something before the data exists?" | Ties to his own path, from his public profile. It turns an interrogation into a conversation and shows you researched him, not just the company. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, which a peer expects. |
| R3 | "Where do you see the two new lines in the Compass launch?" | Shows you read the launch and ties the new lines to a stated priority. |
| R4 | "What would make you say in six months that this hire was the right call?" | Exposes his success criteria, peer to peer. |
| R5 | "Is this one conversation, or does a second round follow, and what would it test?" | The answer sets how deep the next prep needs to go. |

---

## 13. Prohibited claims

Built here from the fit snapshot, before the banks. None of the banks, reverse questions or guidance asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for the two new lines | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's analysis, not words for her: the material shows product strategy and ops, not GTM ownership. D3's slot stays within that scope. |
| The $400M was mine, or I drove the $400M | Inflated form of "proposed a store-surface change credited with a ~$400M ARR uplift" | "I proposed the store-surface change." The figure was credited to it. Attribution is the slot in B2. |
| Built a partner program or partner motion | Inflated form of "built a partner-level revenue model used in carrier negotiations" | The model, at its scope. The limit is the pack's analysis: a model used in negotiations, not partner-motion design. |
| Ran independent SQL or Tableau analysis | Inflated form of "skilled in SQL/Tableau" | The quote as it stands. B3's slot. |
| Led the cross-org consensus | Inflated form of "set annual volume targets with cross-org consensus" | The quote at its own scope. |
| Built AI tools | Inflated form of "uses AI tools daily" | The quote as it stands. F6's slot. |
| Set quotas, or ran sales operations | Negative from your note, not yet stated by Priya | Plain acknowledgment only after she confirms it in her own words. Until then, no words for it. |

---

## 14. Sources

**Provided documents:** your message. It contains her summary (cited in this pack as "coach's notes"), the JD highlights, the interviewer's profile as you described it, and the research note (priorities and competitive threat).

**Searches sent:**
- "Northwind Data Compass AI copilot launch": refused (permission not granted).
- "Dan Kovac Director of Sales Strategy Northwind Data": refused (permission not granted).

**Research tier:** L1 requested. Searches: 0 of 6 returned results (2 refused). Fetches: 0 of 2. Effective tier: L0.

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | No call was sent. Would have moved the values cheat sheet. No values-style round is detected here, so no values section is in the pack. |
| 2. Northwind Data interview process, sales-strategy peer | unavailable | No call was sent. Would have established whether a loop exists. Without it, weights rest on the peer prior. |
| 3. Northwind Data strategy and recent news | unavailable | Call sent: "Northwind Data Compass AI copilot launch", refused. Would have checked the currency of your note and moved C1 to C2 and A5. |
| 4. Dan Kovac, Northwind Data | unavailable | Call sent: "Dan Kovac Director of Sales Strategy Northwind Data", refused. Would have added to the interviewer read beyond the profile you gave. |
| 5. Representative JD | skipped | Your JD highlights supply the requirement lines for the fit snapshot. They are highlights, not the full text. |

---

## 15. Upgrade menu

- **Full JD text** → the requirement quotes replace the highlights, and any gate rows (location, work pattern, authorization) would surface. Currently none.
- **Your own words on quota and sales operations (F8), the $400M attribution (B2), and any B2B work (F7)** → those rows move off your note and onto her statements, and prohibited-list row 7 can be rehearsed.
- **The CV, or a deck with the store-surface figures** → F1 and F5 can rise, and B1 can be answered from inspectable proof.
- **The date of your research note** → confirms that the grounding brief, C1, C2 and A5 are current.
- **Search permission, or a pasted company values page** → the company checks (targets 1 to 4) can run.
- **Deep research, once:** up to 6 more searches and 2 more fetches, several minutes. Strategy brief and interviewer footprint. Want it?
- **Interviewer's public talks or posts** → recurring themes become likely questions.
- **Whether this is one conversation or a multi-round loop** → loop mode, with per-round weights.
- **A tuesday-dossier.md from an earlier run** → verified evidence and checked objections would replace the inferred ones.
