# Engineering Manager, Larkfield Systems: three-round prep pack

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, about 600 people)
**Rounds (loop mode):**
- Round 1, Tuesday, 45 min, hiring manager (Director of Engineering). Name not given.
- Round 2, the Thursday after, 60 min, panel: two staff engineers and a product manager. Names not given.
- Round 3, the following Monday, 30 min, VP Engineering. The recruiter describes it as "values and leadership philosophy". Name not given.

**Built on:** your role description and your message. Company research was refused for this session, so nothing here describes Larkfield's values, interview loop or strategy. Where the pack would need those facts, it says so.
**Changes:** first generation, no changelog.

## How to use and the type key

Personas are how a question arrives: the register and the pressure. Types are what the question scores. Guidance is scaffolding, not a script. Each guidance cell is meant to be speakable in 90 to 120 seconds.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values alignment: what past behavior shows about how you lead |
| EXP | Experience deep-dive: what you actually did, and how a figure was counted |
| JD | The role's stated responsibilities, including the ones you cannot yet show |
| CO | Company and strategy knowledge (none researched this session, so CO items are generic) |
| CASE | A live problem from the role, solved aloud |

## Fit snapshot (shared across all three rounds)

No full job description or CV was supplied. Requirements are quoted from your role description. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role description) | "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | medium | [grounded] | transferability | Your material shows one team, not two squads. Say it at that scope: "3 as a team lead of 6." Answer slot: if you have led work across more than one team, say how, in your own words. If you have not, say so plainly, then say how you would split one leadership role across two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role description), hiring part | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | none | No gap on hiring. The quote already reaches it in role terms. Lead with the verb in your sentence: "I run our hiring loop for backend roles." The 40 is a figure you will be asked to defend (A6). |
| F3 | "own delivery, hiring and growth for 11 engineers" (role description), delivery part | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Your material shows delivery under pressure through a reliability quarter, not delivery of a roadmap to a date. Say it at that scope. Answer slot: if you set the quarter's scope or its order, say what you chose and why. If it was set for you, say so and describe what you did with it. |
| F4 | "growth for 11 engineers" (role description) | none given | none | [grounded] | discovery | Your material says nothing about developing engineers. Answer slot: if you have developed an engineer's career, say how, in your own words. If your material does not carry one, say so plainly, then say how you would begin with eleven engineers. |
| F5 | "partner with hardware and product on roadmap" (role description) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | The words you can use: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan, never as a past. |
| F6 | "no manager-of-managers experience" (your message, gap note) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | The words you can use: "I've never managed managers." Then how you would learn to lead leads, said as a plan. The role description does not say whether there are leads under you. Upgrade menu asks. |
| F7 | "first time at 600-person scale with multiple squads" (your message, gap note) | none given | none | [grounded] | discovery | You listed scale as a gap, but your material does not give the size of your current company or the number of teams. Answer slot: say the largest organisation you have worked in and how many teams you worked across. If you have not worked across multiple teams, say so. |

There are no gate rows: your material names no legal, credential or location term that the role sets.

## Round 1: hiring manager (Director of Engineering), Tuesday, 45 min

**Persona weights.** The relationship prior for a hiring manager is Case/Strategist plus Skeptic: they are buying capability and checking the two gaps you named. The Prober comes in lower because your two headline figures are the metrics a manager will check.

| Persona | Weight | Items | Why |
|---|---|---|---|
| Case/Strategist | top, 3 of 8 | A1, A2, A7 | Hiring-manager prior; the role's roadmap partnership is a live problem |
| Skeptic | top, 3 of 8 | A3, A4, A8 | Hiring-manager prior; F5 and F6 are the gaps they will test |
| Data-Driven Prober | mid, 2 of 8 | A5, A6 | The 60% and the 40 interviews are headline figures (F2, F3) |

**Question bank, round 1**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two squads, eleven engineers, and a roadmap that hardware and product both touch. What would you need to know before you changed anything?" | CASE | [grounded] "partner with hardware and product on roadmap" (role description) | Clarify before you structure. Ask who sets the roadmap order, what hardware has committed to, and what delivery looks like across both squads now. Name two questions and say what each would change. Then describe the first 30 days as listening, not as change. Make no claim about your past. | Tests altitude on the role's own partnership without asking you to claim experience you do not have. F5 is where this bites. |
| A2 | "Two squads are behind on a device-management release, and hardware says the date is fixed. Product wants the scope kept. What do you do this week?" | CASE | [grounded] "partner with hardware and product on roadmap" (role description) | Separate the date from the scope and find out what is fixed and why. Put the two partners in one conversation with the trade-off stated, and say who decides. Name the assumption you would test first. | A live version of the role's partnership. Scores the trade-off and the decision path, not an outcome. |
| A3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Name the gap first, plainly: you have never owned a hardware-adjacent roadmap. Say what you know about it and how you would learn it in the first month, as a plan. Do not reach for a nearby example to close the gap. | F5 is the gap the hiring manager is most likely to test. Naming it first lets you set the terms. |
| A4 | "You haven't managed managers and you haven't owned a hardware-adjacent roadmap. Why is that a bet worth making?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) "3 as a team lead of 6" (your message) "after I pushed a reliability quarter through against roadmap pressure" (your message) | **Highest-ROI prep in this pack.** Start with the plain acknowledgment: "I've never managed managers and never owned a hardware-adjacent roadmap." Then give the closest thing your material carries, in your words: three years as a team lead of six, and a reliability quarter you pushed through against roadmap pressure. Hold that position through two follow-ups. Do not stretch either point into the missing thing. At the second follow-up, concede specifically: say what you do not yet know, and what you would do in the first month. Do not argue that the bet is good. | This objection is born from F5 and F6 and is the one the hiring manager's gaps make close to certain. Its premise is your own negative, so the acknowledgment needs no slot. Rehearse it to three follow-ups with the concession wording set in advance. |
| A5 | "How was that 60% counted: over what window, against what baseline, and what counted as on-call?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Name the assumption you would defend least before they do. Answer slot: if you know the window, the baseline and what counted as on-call, say them in your own words. If you do not know how it was counted, say so plainly. Then say which part was yours: the push, and what you did in it. The drop followed the push. | Headline figure: the defend-the-number slot in its strongest form. F3 is the row it draws on, and the figure is the one a manager will check. |
| A6 | "About 40 interviews last year. What did you own in that loop, and what did you not own?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Give the scope in your own words: the loop for backend roles, and about 40 interviews. Name the assumption you would defend least: whether the 40 counts interviews you ran, sat in on, or scheduled. Answer slot: if you ran panels, say so. If you scheduled and others interviewed, say so. If you did not count, say so. Keep the verb at "run". | Headline figure. F2 is the requirement it draws on, and "run" is the verb a manager may test against "design". |
| A7 | "What would you want to learn about our product before your first planning cycle?" | CO | [generic] | Name two things about the device-management services you would ask about, and what you would do with each answer. Your material says nothing about this product, so make no claim about it. | Research was refused, so the CO questions in this pack are generic and labelled so. The question makes no claim about the company's strategy. |
| A8 | "How have you developed an engineer who was not ready for the next step?" | JD | [grounded] "own delivery, hiring and growth for 11 engineers" (role description) | Open prompt. Answer slot: if you have developed an engineer's career, say how, in your own words. If your material does not carry one, say so plainly, then say how you would begin with eleven engineers. | Growth is a stated responsibility and F4 is silent on it. The honest answer is ready before the probe arrives. |

**Reverse questions, round 1**

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "What would make the first ninety days a success in your eyes?" | Shows you plan to be judged on something specific, and tells you what gets measured. |
| R1-2 | "When hardware's input conflicts with product's, who decides, and how does that get decided?" | Surfaces decision rights on the seam you would own. |
| R1-3 | "What has made this role hard to fill so far?" | Gets the concern the hiring manager has in their own words, which is the Skeptic's concern. |
| R1-4 | "What would you need to see from me in the first month to feel the bet was right?" | Turns the A4 objection into a shared test. |
| R1-5 | "How do the squads' commitments get tracked against what hardware has promised?" | Shows you already expect the seam to exist. |

## Round 2: panel (two staff engineers and a product manager), Thursday, 60 min

**Persona weights.** Names are not given, so the pack cannot assign personas per person. The relationship priors are: staff engineers are peers (Peer Evaluator plus Data-Driven Prober); the product manager is cross-functional (Values/Behavioral plus Conversational). Expect the staff engineers to probe depth and the product manager to test how you talk about trade-offs.

| Persona | Weight | Items | Why |
|---|---|---|---|
| Peer Evaluator (staff engineers) | top, 3 of 8 | B1, B3, B5 | Peer prior: they price your load on their work and check the seam |
| Data-Driven Prober (staff engineers) | mid, 2 of 8 | B2, B4 | Staff engineers read the CV closely |
| Values/Behavioral (product manager) | mid, 2 of 8 | B6, B8 | Cross-functional prior: scored stories |
| Conversational (product manager) | low, 1 of 8 | B7 | The opener is scored too |

**Question bank, round 2**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where's the seam between your squads and the hardware team, and what happens when you disagree?" | JD | [grounded] "partner with hardware and product on roadmap" (role description) | Name seam principles, not a seam you have not seen. Say how a disagreement with an equal gets settled: who writes it down and who decides. Answer slot: if you have settled a disagreement with a peer, say how, in your own words. If you have not, say so plainly, then give the principle you would use. | JD-tagged on the partnership requirement. Peer Evaluator test, close to F5. |
| B2 | "What would you have to check before you trusted the 60%?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Name the assumption you would defend least, first. Then the answer slot from A5: the window, the baseline and what counted, in your words, or a plain "I do not know". | Staff engineers go two levels deep on a figure. Same figure as A5, asked from a different angle, so the answer does not sound rehearsed. |
| B3 | "What did you do with the roadmap pressure during that quarter?" | EXP | [grounded] "after I pushed a reliability quarter through against roadmap pressure" (your message) | Describe your part in your own words: what you pushed, and what you did with the pressure. Answer slot: if you made a roadmap concession, say what it was. If you made none, say so plainly. Do not add a stakeholder reaction you did not see. | Peers ask what was traded. The answer has to trace back to your push and nothing wider. |
| B4 | "Two teams want the same engineer next quarter. How do you decide?" | CASE | [generic] | Clarify what each team's commitment is, who holds the authority, and what each team would lose. Give one decision rule and say what you would tell the team that loses. Make no claim about your past. | A generic peer-allocation problem. The role's two squads make it plausible; no quote carries it, so the label stays generic. |
| B5 | "What's the closest you've come to hardware-adjacent work?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Open prompt. Answer slot: say plainly that your material shows no ownership of a hardware-adjacent roadmap. Then name the nearest work you have done that touched devices or their interfaces, in your own words, if there is any. If there is none, say so. | The panel's engineers will test the hardware line. "Adjacent" must not stretch to cover the absence. |
| B6 | "Tell me about a time you told product no and it stuck." | VAL | [generic] "after I pushed a reliability quarter through against roadmap pressure" (your message) | Selection scaffold: pick a time you held a position under pressure from a senior person or an equal, with a named stake, a moment you did not fold, and a relationship intact at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries, in your own words: the reliability quarter you pushed through against roadmap pressure. | Cross-functional values stem. The scaffold makes no claim; the nearest-thing branch keeps it honest. |
| B7 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | A 90-second arc in your own words, built on those three facts: nine years in engineering, three as a team lead of six, now at a payments company. Say why you want this role only in terms you can stand behind. | Conversational openers are scored. The arc quotes your message and nothing else. |
| B8 | "What did you learn from a team you led that did not ship?" | VAL | [generic] "after I pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt. Selection scaffold: pick a team of yours that missed or dropped a commitment, and the decision you would change now. If none comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter, and what you would change about how you pushed it. | Cross-functional values stem. Answers that name a failure they would now change land better than a clean record. |

**Reverse questions, round 2**

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What could a new engineering manager do in their first month that would genuinely help your teams?" | Reciprocity with peers. Shows you are pricing your own load on their work. |
| R2-2 | "Where do your squads and the hardware team step on each other most?" | Gets the seam from the people who live in it. |
| R2-3 | "When your team disagrees with product, what does that usually look like?" | Tests the disagreement norm, which is what the product manager cares about. |
| R2-4 | "What's one thing about how the squads work with product that you would change if you could?" | Candid answers here show what they want from a new manager. |
| R2-5 | "When a staff engineer and a product manager disagree, how does the call get made?" | Tests decision rights between peers, which the squads will live with. |

## Round 3: VP Engineering, Monday, 30 min

**Persona weights.** The recruiter named this round "values and leadership philosophy", so Values/Behavioral is the top persona. Pressure is mid-weight because the relationship is skip-level and the time box is 30 minutes.

| Persona | Weight | Items | Why |
|---|---|---|---|
| Values/Behavioral | top, 4 of 8 | C1, C2, C4, C7 | The recruiter's own description of the round |
| Pressure | mid, 2 of 8 | C3, C5 | Skip-level prior; a 30-minute time box |
| Case/Strategist | low, 2 of 8 | C6, C8 | Altitude check on the role's partnership and on company pattern |

**Question bank, round 3**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What's your leadership philosophy, in three sentences?" | VAL | [grounded] "values and leadership philosophy" (recruiter's description, as you relayed it) | Three sentences: the principle, a decision it governs, and what it costs. Use the reliability push as the decision, in your own words. Answer slot: if the push cost something you can name, say it. If you cannot name a cost, say so plainly rather than inventing one. | The recruiter's own words name the round. The decision is quoted from your message, so nothing is added. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] "after I pushed a reliability quarter through against roadmap pressure" (your message) | Selection scaffold: pick a time you chose a customer outcome over an internal number, what you gave up, and who noticed. If none comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter, and only what you can say about who it served. | Values stem. Your material does not show a customer outcome, so the scaffold asks rather than supplies one. |
| C3 | "How much of that reliability result was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold-then-concede. Hold through two follow-ups: you pushed the quarter through, and the drop followed it. At the second follow-up, concede specifically: say you cannot say how much of the drop the quarter alone accounts for, and what you would need to check to know. Do not fold on the push itself. | The pressure item on your headline figure. Folding on the push breaks the loop; holding it and conceding attribution precisely is the rehearsal. |
| C4 | "What does a manager owe the engineers who report to them, and what can they not owe?" | VAL | [grounded] "values and leadership philosophy" (recruiter's description, as you relayed it) | No past claim needed. Give one principle for what a manager owes, and one limit you hold on what they cannot owe. Two sentences each. | Leadership philosophy in the recruiter's words, answered without a story. |
| C5 | "You're leading two squads and eleven engineers, and you've led six. What changes in how you lead?" | JD | [grounded] "Lead two squads building device-management services" (role description) "3 as a team lead of 6" (your message) | Structure it: what you would delegate, what you would keep, and how you would know it was working. Answer slot: if you have led across more than one team, say how. If your material shows one team of six, say so plainly, then say what you would check first. | The scale gap (F1, F7) in the form a VP will put it. |
| C6 | "Where does engineering leadership at a company like this usually go wrong?" | CO | [generic] | Name one failure pattern and what you would watch for. Label it as a pattern. Make no claim about this company, since no research was run. | A generic company-altitude question. Labelled so it is not mistaken for research. |
| C7 | "What's a leadership decision you would reverse?" | VAL | [generic] | Open prompt. Selection scaffold: pick a decision you would now reverse, what you would do instead, and what it taught you. If none comes to mind, say so plainly, then give the nearest thing your material carries, and only the cost you can name. | Values stem. Gives you a way to talk about error without inventing one. |
| C8 | "A hardware release slips a quarter, and you have to recommend a plan by Friday. What do you say?" | CASE | [grounded] "partner with hardware and product on roadmap" (role description) | Clarify what slipped, what the customer commitment is, and what hardware can and cannot move. Recommend one option, name the cost of each, and say what you would tell product and hardware the same day. Make no claim about your past. | A live problem from the role's partnership, the one a VP tests for altitude. |

**Reverse questions, round 3**

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What does this leadership team say no to, and how do you know?" | Tests the values in practice rather than the slogan. |
| R3-2 | "When a reliability investment and a roadmap bet compete, how do you decide?" | Puts the trade-off the recruiter's framing points at on the table. |
| R3-3 | "What's a principle you hold that new managers push back on?" | Opens a candid conversation about values under friction. |
| R3-4 | "What would make you wish you had made a different call on this hire in six months?" | Surfaces their real risk, which answers the Skeptic question in a form you can use. |
| R3-5 | "What does good hiring look like to you at this level, and what does it tend to miss?" | Ties to the hiring loop you run (F2) and invites a view you can build on. |

## Requirement coverage

| Requirement (source) | Covered by |
|---|---|
| "Lead two squads building device-management services" (role description) | A1, C5 |
| "own delivery" (role description) | A5, B2, B3 |
| "hiring" (role description, "own delivery, hiring and growth for 11 engineers") | A6 |
| "growth for 11 engineers" (role description) | A8, C4 |
| "partner with hardware and product on roadmap" (role description) | A1, A2, A3, B1, B5, C8 |
| Manager of managers (your gap note) | A4, C5 |
| Hardware-adjacent roadmap (your gap note) | A3, A4, B5 |
| Scale across multiple squads (your gap note) | C5 |
| "values and leadership philosophy" (recruiter, as you relayed it) | C1, C2, C4, C7 |

No requirement is left uncovered.

## Prohibited claims

These are the claims this pack will not coach. None of the banks, reverse questions or guidance cells asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Having managed managers | A negative you stated (F6) | "I've never managed managers." Plain acknowledgment, no slot. |
| Having owned a hardware-adjacent roadmap | A negative you stated (F5) | "I've never owned a hardware-adjacent roadmap." Plain acknowledgment, no slot. |
| Having designed the hiring loop | Inflated form of "I run our hiring loop for backend roles" (F2) | "I run our hiring loop for backend roles." Limit, as the pack's own observation: your material says run, not design. |
| Having cut on-call by 60% yourself | Inflated form of the 60% sentence (F3) | "After I pushed a reliability quarter through against roadmap pressure." Limit, as the pack's own observation: your material says the drop followed your push, not that it was yours alone. |
| Having led two squads | Inflated form of "3 as a team lead of 6" (F1) | "3 as a team lead of 6." Limit, as the pack's own observation: your material says one team. |

## Sources

- **Provided documents:** your message (role description, background, round details, gap note), and the recruiter's wording as you relayed it. No CV or full job description was supplied.
- **Searches sent:** three. All three were refused by the host, so none returned results. No fetches were sent.
  1. "Larkfield Systems values": refused
  2. "Larkfield Systems interview process engineering manager": refused
  3. "Larkfield Systems industrial IoT device management strategy news": refused

**Research tier:** L1, searches 0 of 6 ran (3 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Search refused. No values cheat sheet, since the company's published values are not in hand. VAL questions rest on the recruiter's wording instead. |
| 2. Larkfield interview process | unavailable | Search refused. Loop structure comes from your own round details, so no archetype fallback was needed. Would have confirmed round formats. |
| 3. Larkfield strategy or recent news | unavailable | Search refused. CO and CASE items are generic and labelled so. Would have grounded the CO bank. |
| 4. Interviewer name and company | n/a | No names were given, so no query could be formed. The interviewer read is absent. |
| 5. Representative JD for the title | unavailable | Search refused. Your role description is not a full JD, so the requirements stay [grounded] from your text rather than [inferred] from a fetched posting. |

## Upgrade menu

- **Full job description** → the role requirements move from your summary into quoted rows, and the coverage table is checked against the full list.
- **Your CV** → the fit snapshot draws on lines beyond your message, and probes on specific CV entries become prepared answers.
- **Company values page, pasted** → the values cheat sheet (section 10) is built, and the VAL questions in round 3 map to your stories.
- **Permission to run web research** (search was refused this session) → company values, interview loop and strategy are checked, and the CO and CASE items are grounded.
- **Interviewer names, all five people** → the interviewer read, per-person persona weights, and reverse questions tied to each person's path.
- **Size of your current company and number of teams** → F7 becomes a quoted row, and the answer slot in C5 gets material.
- **Whether the role has leads under the two squads** → F6's requirement becomes sourced, and A4 and C5 can be tightened.
- **How the 60% and the 40 interviews were counted** (window, baseline, what counted) → the defend-the-number slots in A5, A6 and B2 become quoted answers you can give without rehearsing around them.
- **Recruiter's note on what each round focuses on** → persona weights are recomputed per round.
- **A `tuesday-dossier.md`** → adds verified evidence and a prohibited-claims list, in place of the inferred ones above.
