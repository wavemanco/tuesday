# Stripe: Product Operations Manager, final-round prep pack

Role: Product Operations Manager. Company: Stripe. Round: final, relationship to interviewers unknown. Changelog: first pack. No CV, JD or round details were in the working folder, so persona weights are flat and every requirement is a role-family guess marked [generic].

## How to use

Personas are how a question is asked. Types are what it scores:

- **VAL**: behavioral and values alignment, past behavior
- **EXP**: work-experience deep-dive, whether claims survive scrutiny
- **JD**: role responsibilities and qualifications
- **CO**: company and strategy knowledge (not included: research was not run)
- **CASE**: a live problem from the role, solved aloud

The guidance is scaffolding, not a script. Where the pack says "answer slot", it means an instruction for the interview: answer from your own experience, or say plainly that the practice was not yours.

## Fit snapshot (worksheet: no background in the conversation yet)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | Designing and improving operating processes across product teams (role-family) | none given | none | [generic] | discovery | Your material does not show this yet. Strong evidence looks like one process you designed or changed, what it replaced, and who used it. Selection scaffold: pick one process you set up or changed, and say what it replaced and how you would know it worked. If you have not designed one, say so plainly and describe how you would start. |
| R2 | Launch and cross-functional program coordination with engineering, legal and support (role-family) | none given | none | [generic] | discovery | Not shown yet. Strong evidence looks like one launch you ran across functions, your part, and the dates it met or missed. Selection scaffold: pick a launch that involved several functions, and say what you owned and what you did not. If none comes to mind, say so plainly, then give the nearest thing you did. |
| R3 | Metrics and dashboards that inform product decisions (role-family) | none given | none | [generic] | discovery | Not shown yet. Strong evidence looks like a metric you defined, what it counted, and a decision it changed. Selection scaffold: pick one metric you used to make a decision, and say what it counted and what it could miss. If you have not used one for a decision, say so plainly. |
| R4 | Influencing senior stakeholders and handling tradeoffs (role-family) | none given | none | [generic] | discovery | Not shown yet. Strong evidence looks like one disagreement with a senior person, how it was settled, and what you did next. Selection scaffold: pick a time you disagreed with someone senior, and say what the tradeoff was and where you ended up. If none comes to mind, say so plainly. |
| R5 | Working with tooling and workflow systems such as planning, data or ticketing tools (role-family) | none given | none | [generic] | discovery | Not shown yet. Strong evidence looks like a tool you configured or rebuilt, and what changed for the people who used it. Selection scaffold: name one system you set up or changed, and what you did yourself versus what the vendor or IT team did. If you have not done this, say so plainly. |

## Prohibited claims

No entries. No sentence of yours is in the pack, so there is no claim to stretch and no inflated form to list. A requirement the material is silent on is an answer slot, not a prohibited claim. The pack will not coach any claim about your past until one of your own sentences enters the fit snapshot.

## Persona table

Weights are flat because the round and relationship are unknown. Each persona gets three questions, the depth a flat-weight pack needs. Total: 21.

| Persona | How it shows up | Likelihood (flat) | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Asks how a number or result was counted | Medium: a final round often includes a metrics probe, but nothing shows this one does | Name the weakest assumption you know before they do; say plainly when you don't know how something was counted |
| Pressure / Stress | Interrupts, plays devil's advocate, time-boxes | Medium: common in final rounds, and not confirmed for this one | Pause, restate, hold a position through two follow-ups, then concede the specific point |
| Values / Behavioral | Scenario prompts about how you worked with people | Medium: many final rounds include one, and no source confirms it | Choose a story where the hard truth actually landed; "we" for context, "I" for your part |
| Case / Strategist | Live problems: plan this, diagnose that | High: product operations roles often include a live problem | Clarify, then structure, then metrics, then risks; say the structure aloud |
| Skeptic | Probes gaps and motivation: why this role, why now | High: a final round is where the gaps get tested | Rehearse the most likely objection until it is plain; never bluff a gap |
| Conversational / Rapport | Friendly, open questions that are still scored | Medium: the casual opener is common, and casual questions are scored too | Have a 90-second arc ready; treat casual questions on the role as scored |
| Peer Evaluator | Seams between teams, credit, what they would need from you | Medium: depends on whether a peer is in the panel | Propose seam principles rather than claiming to know the seam; say what you bring their team |

## Question banks

Highest-ROI prep: **E1**. The weakest-part question will come in some form, and nothing in your material answers it yet. Rehearse it before the others.

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about a time you used a metric to decide whether to keep a process change." | EXP | [generic] | Open prompt. Pick one change you measured. Name the metric, what it counted, and the assumption you would defend least. If no such time comes to mind, say so plainly, then give the nearest thing you did and how you would measure the rest. Do not supply a baseline or figure. | Prober's stem. Tied to R3, which has no quote yet, so the guidance names no measure. |
| A2 | "Which number from your work would you least want to defend, and why?" | EXP | [generic] | Open prompt. Name a figure you actually used, the assumption behind it, and who else could have counted it differently. If you have not used a figure you would defend, say so and describe how you would check one. | Most likely probe on any figure you give. Tied to R3. |
| A3 | "An adoption metric dropped 20 percent in a launch's second week. How would you diagnose it?" | CASE | [generic] | Clarify what changed and what counted as adoption first. Split by segment and by time. Name the two hypotheses you would test first and the data you would need. Speak it aloud in that order. | A live problem for the role. It asks about no past of yours. Tied to R2 and R3. |

### B. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why should we hire you over someone who has run this function longer?" | JD | [generic] | Pause, then restate the question in your words. Name the one thing you can show, and say what you have not yet done. Do not claim seniority you lack. Hold your position through two follow-ups, then concede the specific gap they name. | Pressure stem. Tied to R4 and the seniority question no source raises. |
| B2 | "Your process idea sounds like one every ops team tries. Why would this one survive?" | CASE | [generic] | Hold your position if you have one. Concede the part that is common, then say what would make the idea fail, and how you would find out early. | Tests hold-then-concede. Tied to R1. |
| B3 | "Name one result you are proudest of, and how much of it was yours." | EXP | [generic] | Open prompt. Name the result in your own words, the part you did, and any part you shared. If you were one of several people, say so. Never fold on your own part under follow-up. | Attribution under pressure. Tied to R2. |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you told a leader something they did not want to hear." | VAL | [generic] | Pick a time the hard truth actually landed. Use "we" for the context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest time you disagreed upward. | Standard behavioral stem. Tied to R4. |
| C2 | "When did you put a user's or customer's need ahead of an internal metric?" | VAL | [generic] | Pick one decision where the customer's need won and say what the metric showed. Name the cost honestly. If you have not made that call, say so plainly, then describe how you would weigh it. | Behavioral stem, no published values in hand to map to. Tied to R3. |
| C3 | "Tell me about a process you owned that failed. What did you change?" | VAL | [generic] | Name the failure plainly, what you changed, and what you would still do the same way. Keep the scope to what you did. If you have no such example, say so, then give the nearest failure you learned from. | Tests ownership and candor. Tied to R1. |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Plan the first 90 days of a product operations function for a team that just doubled in size." | CASE | [generic] | Clarify what the doubling changed and which problems hurt first. Set the objective, then sequence the work, the metrics, and the risks. Say the structure aloud before you use it. | Tests structure at the role's own altitude. Tied to R1 and R5. |
| D2 | "A launch is slipping, and three teams disagree on what done means. What do you do this week?" | CASE | [generic] | Clarify who owns the definition of done. Get the three positions written down. Propose one decision rule and a date. Name the risk of waiting. | Tied to R2. |
| D3 | "Design a review process for a product decision that is expensive to reverse." | CASE | [generic] | Clarify the decision, who makes it, and how reversible it really is. Set the criteria before the meeting. Challenge one premise of the question respectfully. | Tests judgment on process design. Tied to R1 and R4. |

### E. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the weakest part specifically. Say what you would do in the first two weeks to close it. Calibrated candor, not a bluff. Make no claim about experience you have not stated. | Highest-ROI prep in this pack. The likeliest probe, and nothing in your material answers it yet. Tied to R1 through R5. |
| E2 | "Why this role, and why now?" | EXP | [generic] | Answer in one sentence about the work itself, then one about what you have read about the company, in your own words. If you cannot yet name specifics, say so and name what you would look at first. | Motivation consistency is scored. No posting or research was available to quote. |
| E3 | "What would make you leave this role within a year?" | EXP | [generic] | Name one specific, honest condition. Do not criticize any past or present employer. Keep it short. | Tests honest self-assessment and stability. |

### F. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your journey." | EXP | [generic] | Use a 90-second arc: where you started, the turn, what you do now, and why this role. Use your own words for each step. | Opening stem. Casual openers are scored. |
| F2 | "What's the most interesting process problem you've been chewing on lately?" | JD | [generic] | Name one real problem, why it matters, and what you have tried. Keep it to one problem. | Casual register, scored on communication and interest. Tied to R1. |
| F3 | "Do you have any questions for me?" | JD | [generic] | Use a reverse question from section 11. Never answer "I think you've covered everything." | The reverse-question slot is scored as a signal of preparation. |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Propose seam principles rather than claiming to know the seam. Name one disagreement pattern you handle well, and what you do when it stalls. | Peer seam probe. Tied to R2 and R4. |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name the rule you use: contributors named specifically, and the stage shared. If you have no example, say so and state the rule you would use. | Peer credit probe. |
| G3 | "What would you need from my team to be effective in the first month?" | JD | [generic] | Name two specific inputs. Say what your work gives their team in return, so the exchange runs both ways. | Reciprocity, which peers weight heavily. Tied to R5. |

### Requirement coverage

The requirements are role-family guesses, so this line is provisional.

- R1: D1, D3, B2, E1
- R2: A3, D2, B3, G1
- R3: A1, A2, C2
- R4: B1, C1, D3, G1
- R5: D1, G3
- No question covers any other stated requirement, because none has been stated yet.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How does this team decide which operational problems get solved first, and who makes that call?" | Shows you think about prioritization as an operator, not just a task-doer. |
| 2 | "What does a strong first six months look like in this role?" | Turns the conversation toward success criteria, which hiring managers value answering. |
| 3 | "Where do product and operations currently disagree about ownership?" | Shows you expect the seam to be real and want to see it early. |
| 4 | "What has the team tried in the last year that did not work, and what changed because of it?" | Invites candor and signals that failure is a normal input. |
| 5 | "What would you want the person in this role to change in their first 90 days?" | Surfaces the real priority behind the job description. |

## Sources

- Provided documents: the company and role from your message. No CV, JD, round details or prep email was supplied, and no tuesday-dossier.md was present.
- Research tier: L1 by default. Web search was refused by permission in this session, so every search target ran at L0.

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have set the values cheat sheet and VAL themes. The cheat sheet is dropped because no values-style round is detected; the VAL bank uses behavioral stems instead. |
| 2. Stripe interview process, Product Operations Manager | unavailable | Would have named the loop and moved the persona weights. Weights stay flat. |
| 3. Stripe strategy or recent news | unavailable | Would have fed the CO bank, which is therefore absent. |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so there is no query to form. |
| 5. Representative Product Operations Manager JD | unavailable | Would have replaced the role-family rows with [inferred] requirements. |

Queries sent, each refused by permission:
- "Stripe company values operating principles" (targets 1)
- "Stripe interview process Product Operations Manager final round" (target 2)
- "Stripe recent news strategy 2026" (target 3)

## Upgrade menu

- Your CV or a paragraph about your background → the fit rows gain quoted evidence, the question banks gain story maps, and the prohibited list gets built from your own words
- The job description → the role-family rows become [grounded] requirements, and JD-tagged questions are added for each
- Whether this is one session or several, and who you meet → persona weights are reweighted and reverse questions are tuned
- The recruiter's prep email → coverage of any pre-declared deliverable
- Web search permission for this session → the values, loop and strategy targets run and the rows above change accordingly. A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) is available once, if you want it
- The interviewer's name → an interviewer read and a tailored reverse question
- A tuesday-dossier.md, if you have one → verified evidence and risks feed the banks
