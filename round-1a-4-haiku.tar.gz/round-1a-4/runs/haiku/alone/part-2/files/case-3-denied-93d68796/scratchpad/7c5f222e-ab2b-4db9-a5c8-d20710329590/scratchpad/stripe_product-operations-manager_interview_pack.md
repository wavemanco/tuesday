# Stripe: Product Operations Manager, final round. Prep pack

Built with no CV, no JD, no round details and no search results. Every row that would have drawn on those is generic or an answer slot. Assumed: a hiring-manager-style final, so persona weights are flat (see Persona table).

## How to use + type key

Personas = how the question is asked. Types = what is being scored.

- **CASE**: live problem from the role, scored on structure and reasoning
- **EXP**: your past work, scored on whether it survives scrutiny
- **JD**: the role's responsibilities and gaps
- **CO**: company and strategy knowledge (none in this pack; see Sources)
- **VAL**: past behavior against values (no company values in hand, so generic)

Guidance is scaffolding, not a script.

## Fit snapshot (worksheet variant)

No CV or JD was supplied, so the requirements are role-family prose, not quotes. Evidence is `none given` on every row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run cross-functional operating processes (role family) | none given | none | [generic] | discovery | Answer slot: name one process you ran across teams, what it was for, and your part in it, in your own words. If you did not run one, say so and describe how you would learn to. |
| F2 | Define and track operating metrics (role family) | none given | none | [generic] | discovery | Answer slot: name a metric you have tracked, what it measured and what it hid. If you have never tracked one, say so and say which one you would start with. |
| F3 | Handle controls or compliance inside a launch process (role family) | none given | none | [generic] | discovery | Answer slot: describe a control you have worked within and where it slowed things down. If you have not worked with one, say so. |
| F4 | Influence teams without line authority (role family) | none given | none | [generic] | discovery | Answer slot: name a time you got a team to change something without owning it. If there was none, say so and say how you would approach it. |
| F5 | Learn a new domain quickly (role family) | none given | none | [generic] | discovery | Answer slot: describe how you got up to speed on something unfamiliar, and what you did in the first month. |

Confidence is `none` on every row because nothing about you is on the page yet. Supplying a CV or JD changes this table.

## Persona table

Relationship unknown, so weights are flat and stated as such. The round type is the one thing that would shift them most.

| Persona | Weight | How it shows up | Why this weight | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | High (4) | Live operations problems | Hiring-manager finals usually test judgment on the role's work | Clarify, then structure, then one metric, then risks. Think aloud |
| Skeptic | High (4) | "Where would you be weakest?" | Finals usually test gaps | Name one specific weakness, then your ramp plan. Do not bluff |
| Values / Behavioral | Mid (3) | Scored past-behavior stories | Common in finals, but no values round is established | Use a story with a named stake and an honest ending |
| Peer Evaluator | Mid (3) | Seams between teams | Likely if a peer is on the panel | Propose seam principles; do not claim to know their seam |
| Data-Driven Prober | Low (2) | "How was that counted?" | Possible if the panel reads metrics closely | Name the weakest assumption before they do |
| Pressure / Stress | Low (2) | Interruptions, time-boxing | Unknown style | Pause, restate, hold through two follow-ups |
| Conversational | Low (2) | Casual openers that are scored | Common opener | Have a 90-second arc ready |

Loop: no loop source established the rounds, so the archetype is Generic and the weights are said plainly as a pattern, not as this company's documented process.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Launches keep slipping and the approval queue has doubled. Where do you start?" | CASE | [generic] | Clarify first: what counts as slipped, and which launches. Then objective, segments, one or two approaches, metrics, risks. Speak the structure aloud | Generic live problem for an ops role. Tests structure, not a remembered answer |
| A2 | "What do you need to know in your first 30 days before proposing a change?" | JD | [generic] | Name three questions you would ask, not solutions. Say who you would ask | Scores clarify-before-structure. No claim about you |
| A3 | "Pick one metric that would tell you this operation is healthy. What would it hide?" | JD | [generic] | Name the metric, its definition, and the assumption you would defend least, before they ask | Metric questions score the weakest-assumption move. F2 has no evidence, so the metric is yours to choose |
| A4 | "A launch is ready but the compliance check is not finished. What do you do?" | CASE | [generic] | Decide what can proceed and what cannot, who you involve, and what you record. Name the trade-off | Tests judgment on controls (F3). Generic |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI prep in this pack.** Name one specific weakness, not a vague one. Then your ramp: what you would learn first and from whom. Hold the answer; do not bluff a competency. Answer slot: if you have a real example of closing a gap, say it in your own words; if not, say so and give the plan | Will be asked in some form. Deepest rehearsal, because the honest answer is what changes the interview. F1 to F5 have no evidence |
| B2 | "Why this role, and why now?" | EXP | [generic] | One reason tied to the job's own content, from the posting or the recruiter, not from memory of the company. One reason about your own direction. Keep it under 60 seconds | Motivation consistency is a Skeptic test. No claim about your past |
| B3 | "What part of your past work might someone read as bigger than your share of it?" | EXP | [generic] | Pick the piece you are least sure of your share in. Say which part was yours, in your own words. If none was clearly yours, say so | Honest attribution under probe. Answer slot, not a claim |
| B4 | "Give me the strongest argument against hiring you for this role." | JD | [generic] | State the honest limit first. Hold your position for two follow-ups. Concede one specific thing, never the whole case | Pressure on the Skeptic's favorite opening. Tests composure without folding |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you disagreed with someone senior and said so." | VAL | [generic] | Selection scaffold: pick a time you disagreed with someone above you. Name the stake, what you said, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing you have and how you would handle it | Open prompt, no claim supplied. Generic behavioral |
| C2 | "When did you put a user's need ahead of an internal target?" | VAL | [generic] | Same scaffold. Use "we" for context, "I" for your own call | Tests a common values theme without assuming one |
| C3 | "Tell me about a process you ran that failed. What did you do next?" | EXP | [generic] | Pick a process you ran, not one you watched. Say what failed, what you changed, what you would keep. If you have none, say so and give the closest case | Tests ownership and candor. Open prompt |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not an answer about their team. Name how you would surface disagreement early | Peer test of turf awareness |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name the practice you use to make contributions visible. Say what you do when someone else takes credit | Peer test of collaboration |
| D3 | "What would you bring to my team that it doesn't already have?" | JD | [generic] | Name one way of working you would bring, as a principle. Do not claim a history you have not stated | Reciprocity framing. No claim about your past |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how you would count whether this operation got better." | EXP | [generic] | Name the measure, the baseline you would use, and the assumption you would defend least. If you do not know how a figure would be counted, say so | Metric probe. Tests the weakest-assumption move |
| E2 | "Suppose you give me a figure today. What's the first assumption I should push on?" | EXP | [generic] | Name the assumption before they do. Say which part of any figure you could explain, and which you could not | Prober move. Generic |

### F. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why should we hire you over someone who has done this before?" | JD | [generic] | Pause, restate the question. Name the closest thing you have, and what you would do to close the gap. Hold through two follow-ups. Concede one specific point, not the core | Pressure test of composure |
| F2 | "That sounded rehearsed. What did you actually do?" | EXP | [generic] | Answer with one concrete step you took, in your own words. If you did not take one, say so | Tests honesty under a rehearsal challenge |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: role, the one thing you are proudest of, why you are here. Stop at 90 seconds | Casual opener that is still scored |
| G2 | "What have you been reading about in operations lately?" | JD | [generic] | Name one thing, and say what you took from it. Do not name something you have not read | Casual, but tests curiosity |

## Requirement coverage

| Requirement (generic) | Covered by |
|---|---|
| Run cross-functional operating processes | A1, D1, D2 |
| Define and track operating metrics | A3, E1, E2 |
| Handle controls inside a launch process | A4 |
| Influence teams without line authority | C1, D2 |
| Learn a new domain quickly | A2, B1 |
| Explain why this role | B2 |
| Be candid about gaps | B1, B3, B4 |

## Prohibited claims

Nothing can be listed yet. A claim is listed when it stretches a sentence you have actually said, and you have not yet said one. Until you give one, this pack coaches no claim about your past. Every answer slot here asks you to supply the fact, or to say it was not yours.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first six months look like in this role?" | Shows you plan around outcomes |
| R2 | "What is the operational problem the team most wants solved this year?" | Shows you are asking about priorities, not perks |
| R3 | "How do product ops and the teams it supports decide what gets a process and what does not?" | Tests how decisions are made, which is a Skeptic-proof question |
| R4 | "How is success in this role measured in the first year, and who decides it?" | Reveals the scoring standard |
| R5 | "Who would I work with most closely in the first month?" | Signals you are planning the first month |

No interviewer profile exists, so no reverse question is tied to a career path. No reciprocity question, since the peer relationship is not established.

## Sources

Provided documents: the request text only. No CV, JD, values page or strategy brief was supplied.

Searches sent:

- `Stripe company values principles official`. Refused: the host did not grant search permission.
- `Stripe interview process Product Operations Manager final round`. Refused: same reason.

Research tier: L1. Searches 0 of 6 completed, fetches 0 of 2. The search permission was refused, so no retry was made.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Values cheat sheet, section 10. Omitted, since no values were in hand |
| 2. `{company} interview process {role family}` | unavailable | Loop structure. Persona weights stay flat instead of following named rounds |
| 3. `{company} strategy` / recent news | unavailable | CO bank would have had current strategy. Currently CO is absent |
| 4. `{interviewer name} {company}` | n/a | No interviewer name was given |
| 5. representative `{role title}` JD | unavailable | Would have grounded the fit snapshot in an `[inferred]` JD. Rows stay `[generic]` |

## Upgrade menu

- Round type and who you are meeting → persona weights, a tied reverse question
- Your JD text → the fit snapshot rows become quoted; generic rows become `[grounded]`
- Your CV or background sentences → evidence quotes, and story maps for C1 to C3 and B3
- The recruiter's prep email → coverage of any pre-declared deliverable
- Search permission granted → values, loop structure and strategy: a values cheat sheet and CO questions
- The interviewer's name → an interviewer read and a tailored reverse question
- A deeper research pass (6 more searches, 2 more fetches, several minutes), offered once. Want it?
