# Quartzline: Product Manager, Platform APIs. Hiring-manager prep pack

**Role:** Product Manager, Platform APIs
**Company:** Quartzline
**Round:** Hiring manager, 45 minutes, Thursday 2026-11-26
**Interviewer:** not named
**Built from:** tuesday-dossier.md, dossier_version 1.1 (job-underwriter, generated 2026-08-14, decision conditional_go). No job description or CV was in this session; the dossier supplies the role profile and the verified evidence.
**Research:** not run. Search permission was not granted, so company values, the interview process and current strategy are not in this pack.

---

## How to use

Personas describe how a question arrives. Types describe what is being scored.

- **JD**: role and job-description fit
- **EXP**: whether what you did survives scrutiny
- **CASE**: a live problem from the role, reasoned aloud
- **VAL**: values alignment (not detected here; no values bank)
- **CO**: company and strategy knowledge (not built; research did not run)

The guidance is scaffolding, not a script. Aim for 90 to 120 seconds per answer.

---

## Prep triage (two days)

1. **Before Wednesday evening:** check the dossier is still true (see Dossier freshness below). If a verified claim or a prohibited line has changed, tell me and the pack is rebuilt.
2. **Wednesday:** run B1, the objection, aloud three times, including two follow-ups. This is the highest-return prep in the pack.
3. **Wednesday:** run C1 and C2 aloud. They are the live problems most likely to arrive as the interviewer's roadmap question.
4. **Thursday morning:** run P1 once, the sixty-second opener, and V1 once. Read the reverse questions out loud.

Everything else is insurance.

---

## Dossier freshness

The dossier is about fourteen weeks old and predates the interview stage. Before Thursday, check:

- **The role profile.** The requirements and responsibilities came from the posting as it stood in August. Compare the posting you have against R1 to R5 and the four responsibilities.
- **The three verified claims.** Confirm each is still true and that you can refer to the integration playbook in the interview.
- **The prohibited lines.** Confirm the three negatives (no product manager title, no owned roadmap, no set squad prioritization) are still true. The pack will not coach past them.
- **The two open risks.** Squad decision authority and the adoption baseline were unknown in August. The recruiter or the posting may have answered them since. If you learn either answer, tell me.
- **The decision.** conditional_go rests on August evidence. Nothing in this pack re-scores it.

---

## The fit snapshot

Requirements are quoted from the dossier's role profile. Evidence is quoted from the dossier's verified evidence.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile, R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence) | low | [grounded] | transferability | Your material shows integration leadership, not product management tenure. Words at the quote's own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The pack's own observation: the material does not show a product manager title or PM years. |
| F2 | "Shipped API or platform products" (dossier role_profile, R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence) | medium | [grounded] | transferability | The go-live stage is the nearest thing to shipping. Keep to it: "Led 30+ end-to-end client integrations ... go-live." Answer slot: if you decided what went live for a partner, say so and how; if not, say so and stay with the integration go-lives. |
| F3 | "Technical fluency: API docs, schemas" (dossier role_profile, R3, important) | "Wrote the internal integration playbook her team uses" (dossier verified evidence) | high | [grounded] | discovery | The playbook is integration guidance; the material does not show schema or API documentation work. Answer slot: if you wrote or reviewed API docs or schemas, say which and what you checked; if the playbook is the nearest thing, describe what it covers and say what schema work you have not done. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile, R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified evidence) | medium | [grounded] | discovery | The quotes reach customers and product. Sales and engineering appear in no quote. Bridge reworded only from the quote: "Ran quarterly roadmap-input sessions feeding client evidence to product." Medium confidence: limited inspectable proof, so expect a probe. |
| F5 | "Define and track adoption metrics" (dossier role_profile, responsibility) | none given | none | [grounded] | discovery | The material does not show any adoption metric you defined or tracked. Answer slot: if you defined or tracked a usage figure, say what it counted; if not, say so plainly and say what you would measure first. |
| F6 | "Own the roadmap for the partner-facing API platform" (dossier role_profile, responsibility; R1 sub-claim) | none given | none | [grounded] | capability | Plain acknowledgment, sourced to the dossier's acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)" and prohibited_claims "Having owned a product roadmap": "I haven't owned a product roadmap." No slot. |
| F7 | "Agile delivery experience" (dossier role_profile, R5, preferred) | none given | low | [grounded] | discovery | The material does not show agile delivery inside a product org. Clarify strategy (dossier uncertain area "Agile delivery inside a product org (R5)"). Answer slot: if you ran sprints or planning with engineering, say how; if not, say so and describe how you would learn the squads' cadence. |
| F8 | "Write specs and drive delivery with two engineering squads" (dossier role_profile, responsibility) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence) | medium | [grounded] | discovery | Spec and delivery work with partner integrations is in the quote; work with two engineering squads is not. Squad decision authority is an open risk in the dossier. Answer slot in B5. |

Confidence is the candidate's evidence grade. Provenance is the pack's label for its own statement. Gap type is the routing result.

---

## Prohibited claims

The pack will not coach these, in any answer, slot, hold or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| Held a product manager title or role | Sourced: dossier prohibited_claims "Having held a product manager title or role" | "I haven't held a product manager title." Plain acknowledgment. No slot. |
| Owned a product roadmap | Sourced: dossier prohibited_claims "Having owned a product roadmap" and acknowledge_gap area | "I haven't owned a product roadmap." Plain acknowledgment. No slot. |
| Set prioritization for an engineering squad | Sourced: dossier prohibited_claims "Having set prioritization for an engineering squad" | "I haven't set prioritization for an engineering squad." Plain acknowledgment. No slot. |
| Shipped an API platform as the owner | Inflated form of F2, built locally | The go-live quote at its own scope: "Led 30+ end-to-end client integrations ... go-live." Pack observation: the material shows go-lives, not a platform you owned. |
| Ran the roadmap input process | Inflated form of F4, built locally | "Ran quarterly roadmap-input sessions feeding client evidence to product." Pack observation: the material says you fed evidence to product, not that you decided what went in. |

---

## Persona weights

No interviewer profile exists, so there is no interviewer read. Weights come from the hiring-manager prior, adjusted by the dossier's named objection.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the PM-title gap and the roadmap question | 5 (top). A hiring manager is buying capability and derisking gaps; the underwriter named this objection. | Rehearse B1 until it is plain. Acknowledge first, then bridge at the quote's scope. |
| Case/Strategist | Live problems on the partner API roadmap | 5 (top). The hiring-manager prior is live problems on their actual roadmap. | Clarify, then objective, segmentation, approach, metrics, risks. Say a decision is not yours alone where that is unknown. |
| Data-Driven Prober | Counts the 30+ integrations; probes the medium-confidence roadmap-input line | 3. The figure and the medium evidence are the probe targets. | Defend-the-number slots. Volunteer the limited proof before it is found. |
| Pressure | "Sixty seconds: why you over a PM with three years?" | 3. The dossier's objection can arrive as a time-boxed challenge. | Pause, restate, hold through two follow-ups, concede specifically. |
| Conversational | "So, walk me through the journey." | 2. Hiring managers open warm but still score the arc. | A 90-second arc built only from quoted sentences. |

---

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] dossier prohibited_claims "Having held a product manager title or role" and "Having owned a product roadmap"; dossier uncertain_or_weak_areas "Owning a roadmap and prioritization authority (R1 sub-claim)" | Open with the plain acknowledgment: "I haven't held a product manager title, and I haven't owned a product roadmap." Then bridge at the quote's scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Say what that gives this role and where it stops. Then a 90-day plan in your own words, stated as a plan. Hold the integrations through two follow-ups; never hold the title. Concede specifically: roadmap and prioritization authority is the gap. | This is the underwriter's named objection, so it gets the deepest rehearsal. F1 and F6 carry it. |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] dossier uncertain_or_weak_areas "Owning a roadmap and prioritization authority (R1 sub-claim)" and "Agile delivery inside a product org (R5)" | Name the roadmap and prioritization authority first, in plain words. Second, the delivery cadence inside a product org, with a plan to learn it with the squads early. Name no third weakness you cannot defend. | The skeptic's stem targets the weakest point. The underwriter flagged these two areas, so name them yourself. |
| B3 | "I don't see a product roadmap in your background. How would you handle roadmap decisions here?" | JD | [grounded] "Having owned a product roadmap" (dossier prohibited_claims) | Acknowledge plainly first. The answer is how you would approach it, not a past. Bridge: "Ran quarterly roadmap-input sessions feeding client evidence to product." Say what those sessions fed and what you would want to learn about how product decided. Answer slot: if you have seen how a roadmap decision was made with input from your sessions, say what you saw; if you have not, say so. | F6 is the acknowledgment; F4 is the bridge. The interviewer's negative is sourced by the dossier, so the question may keep it. |
| B4 | "Make the case that the integrations you led should make you the owner of a partner API roadmap." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Make the case from those two quotes only, in your own words, and say what you would bring from them. Then the limit: the case is for partner-facing judgment, not for prioritization authority you have not held. | This tests whether integration work gets inflated into roadmap ownership. F1 and F4 carry it. |
| B5 | "Who on the two squads would have to agree to a partner-facing change, and what happens when they disagree with you?" | JD | [grounded] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibility) | Answer slot: squad decision authority is unknown in the material. If you have had to get engineering to act on a decision that was not yours, say how. If you have not, say so plainly, and say how you would reach agreement with the squad leads on a call. | Squad authority is an open dossier risk. F8 is the evidence; the slot keeps both branches honest. |

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A partner's integration stalls at UAT. Walk me through how you'd diagnose it." | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Clarify which partner and which UAT step before you structure anything. Then objective, segments of partner failure, approach, the metrics you would check, and risks. The integration stages are the frame. Do not say you have diagnosed this before unless you have. | A live problem from the role. F1 supplies the stage vocabulary; the scenario asks about no past. |
| C2 | "Partner API adoption is flat after go-live. What would you look at first?" | CASE | [generic] | Ask first for the current baseline and how adoption is counted today; you do not know either. Name what you would count and the one assumption you would test first. Supply no baseline and no number. | F5 and the adoption-baseline open risk. The raising source is the role_profile responsibility "Define and track adoption metrics," which makes this a fair question. |
| C3 | "Two squads disagree on sequencing for a partner feature. How do you decide?" | CASE | [generic] | Clarify who holds the call; that is the question to ask. Name the decision rule you would use and what you would need to know first. If the call is not yours, say whose it is. | Squad authority is an open risk. The scenario asks about no past. |
| C4 | "Sales wants a custom endpoint for a large prospect. Engineering says no. What do you do?" | CASE | [grounded] "Stakeholder management across engineering, sales, customers" (dossier role_profile, R4) | Structure it: who decides, the effect on other partners, the cost, the alternatives, and the stakeholders you would bring in. Say you would not decide this alone unless the role says you do. | R4 covers three functions; this question puts two of them in conflict. |
| C5 | "What would you put in the first spec for a partner-facing endpoint?" | JD | [grounded] "Wrote the internal integration playbook her team uses" | Use the playbook as the nearest material and name what it covers, in your own words. Answer slot: if you have written or reviewed API schemas or docs, say what they covered. If the playbook is the nearest thing, say so and describe how you would build the spec with the squads. | R3 is not shown in the material. F3 is the discovery gap; the slot keeps the honest branch. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the 30+ integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say the count in your words and what it included. Name the assumption you would defend least: what counted as end-to-end. Say which of those integrations you led yourself. Answer slot: if a register or list supports the count, say which; if no one counted by a rule, say so. | The headline figure is a magnet for probing. The slot covers how it was counted, its weakest assumption, and what was yours. |
| D2 | "How do you know the integration playbook is actually used?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Say what you know of its use, in those words. Answer slot: if you have a usage signal, say what it is; if you do not, say so plainly. | F3 and F4. The question presupposes nothing beyond the quote. |
| D3 | "What happened to the client evidence you fed into the quarterly roadmap-input sessions?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Say where the evidence went, in those words. Volunteer the limit: this is the medium-confidence line, and what you can show is limited. Answer slot: if you have a record of what product did with it, say what it was; if you do not, say so. | Medium confidence with limited inspectable proof; coach the candidate to name the limit before it is found. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over a PM with three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; dossier prohibited_claims "Having held a product manager title or role" | Pause. Restate the question in your own words. Open with the plain acknowledgment, then the integrations as the case. Hold the position through two follow-ups: the integrations are your strongest evidence for partner work, not a PM title. If pushed, concede the roadmap gap specifically. | The sixty-second version of B1. Practise the hold and the concession together. |
| P2 | "That integration result — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Separate what you led from what the team did, stage by stage, in your words. Hold the stages you led; concede the ones shared. | The attribution probe. Pressure on credit tests whether the candidate separates led from shared. |
| P3 | "How would you know the adoption metrics you'd define actually mean something?" | JD | [grounded] "Define and track adoption metrics" (dossier role_profile responsibility) | Answer slot: if you have defined or tracked a usage figure, say what it counted and its weakest assumption. If you have not, say so plainly, and say what you would measure first and how you would test it. Do not defend a metric you have not built. | F5. The held position has to be one the material carries, so the hold here is the honest "not yet." |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built only from those two quotes, in whichever order is true for you. Then one sentence on why this role. No chronology beyond the quotes. | Casual openers are scored. The arc is the rehearsal, not the content. |
| V2 | "What are you most curious about in partner APIs right now?" | JD | [generic] | Name one question about partner needs you would want answered, and why. Do not claim you have already answered it. | A casual version of partner discovery. The question asks for curiosity, not a past. |

---

## Requirement coverage

| Requirement | Covered by |
|---|---|
| R1: 3+ years PM experience | B1, B2, P1 |
| R2: shipped API or platform products | B4, P2 (go-live stage only; no question on owning a shipped product, because the material shows go-lives) |
| R3: API docs and schemas | C5 |
| R4: stakeholder management | C4, B5 |
| R5: agile delivery | B2 (clarify strategy) |
| Own the partner roadmap | B1, B3 |
| Run partner discovery | V2, C1 |
| Write specs and drive delivery with two squads | B5, C5 |
| Define and track adoption metrics | C2, P3 |

---

## Reverse questions

Each question carries a "why it lands." Six are included, and none is generic.

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** Why it lands: it tests the open decision-authority risk and reads as diligence.
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: it tests the adoption-baseline risk and shows you want the number before you commit to a target.
3. **"Where does sales sit in decisions about partner-facing changes, and who has the final say?"** Why it lands: R4 puts sales beside engineering; the answer shows how conflicts resolve here.
4. **"How do the two squads and partner discovery divide the next two quarters?"** Why it lands: it asks for the working split behind the job description, which answers the squad-authority question in practice.
5. **"What would a good first 90 days look like for the person in this role?"** Why it lands: it shows you are planning for the role as it is, not as you wish it were.
6. **"What did the last person in this role get right, and what would you want the next one to do differently?"** Why it lands: it gives the interviewer a chance to describe the job honestly, which is the best evidence you will get on authority.

No interviewer profile exists, so no reverse question is tied to the interviewer's path. The reciprocity question applies only for a peer round and is not used here.

---

## Values cheat sheet

Not built. No values-style round was detected, and company values could not be researched.

---

## Sources

- **Provided documents:** tuesday-dossier.md, dossier_version 1.1. Sections consumed: role_profile (requirements, responsibilities, unknowns), handoff_to_mock_interview (verified_candidate_evidence, uncertain_or_weak_areas, likely_interviewer_objections, opportunity_risks_to_validate, questions_for_employer, prohibited_claims). decision was read as context only.
- **Research tier:** L1. Searches 0 of 6 completed; fetches 0 of 2. Three searches were attempted and all were refused because search permission was not granted: "Quartzline values", "Quartzline platform APIs partners 2026", "Quartzline product manager interview process."

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet (section 10), which is not built. Query refused. |
| 2. Quartzline interview process, product manager | unavailable | Loop structure and persona weights. Query refused. |
| 3. Quartzline strategy and recent news | unavailable | Current-strategy questions (CO bank) and the dossier freshness check. Query refused. |
| 4. Interviewer name and Quartzline | n/a | No name given; no query could be formed. |
| 5. Representative product-manager JD | skipped | The dossier's role_profile fixes the requirements. |

---

## Upgrade menu

- **Permission to run web search** → values cheat sheet, interview-process persona weights, and current-strategy questions at L1. A deeper L2 pass is available on request.
- **The posting as it stands now** → confirms R1 to R5 and the four responsibilities against the August dossier.
- **The interviewer's name** → persona weights read from their public footprint, and a tailored reverse question.
- **Your CV** → quoted sentences beyond the three verified claims, so the bridges and story maps can carry more.
