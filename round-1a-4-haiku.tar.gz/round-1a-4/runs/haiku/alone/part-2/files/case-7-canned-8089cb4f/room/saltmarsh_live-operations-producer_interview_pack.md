# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Role:** Live Operations Producer
**Company:** Saltmarsh Games (mobile games, about 350 people)
**Interviewer:** Tobias Wrenfield, Head of Live Operations (hiring-manager relationship)
**Round:** The Outage Hour, one 60-minute interview with the hiring manager. Saltmarsh's careers page describes it as a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.
**Candidate:** Femi

---

## 1. How to use this pack and type key

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: rehearse the shape, then answer in your own words.

| Type | Meaning |
|---|---|
| VAL | Behavioral / values: does past behavior show Saltmarsh's published values |
| EXP | Experience deep-dive: does what you did survive scrutiny |
| JD | Role / JD-driven: can you do the listed job, gaps included |
| CO | Company knowledge: Saltmarsh's published strategy and recent moves |
| CASE | Live problem: structure and reasoning on a problem from the role |

Answer slots are instructions for the interview. They are not questions to answer here. Where an answer slot asks you what you did, the honest branch ("if there was no such step, say so plainly") is a complete answer.

---

## 2. Fit snapshot

Requirements come from the JD you pasted, quoted. Evidence is quoted from your message, verbatim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title's weekly content-drop calendar, not a live-events calendar across two titles. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title line makes a probe on the second title likely. If you planned or decided anything for a second title, say which and what you decided; if you did not, say so and describe how you would sequence two. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | Your material touches coordination with QA, not with design, art, engineering or community. Answer slot: if you coordinated any of those four on an update, say which and what you did; if you did not, say so and say how you would set that coordination up. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Your material says you presented the numbers, not that you owned the review or chose its KPIs. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which numbers went into a review, say which; if you only presented numbers others chose, say so. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | No gap: the quote reaches the requirement in role terms. Words: "I wrote the release checklist our QA team still uses." |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | low | [grounded] | hard_gate | Your material does not establish this requirement. It shows four years at a puzzle-game studio and does not say whether the title was live-service. Surfaced, not bridged. Step 1 asks the one question that settles it. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | No gap: the quote reaches the requirement directly. Words: "I ran the weekly content-drop calendar for our main title for the last two years." |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you presented retention numbers. Words: "I presented the monthly retention numbers to the studio head." Adds no practice, figure or event. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | transferability | The checklist shows writing that a team uses. It does not show written communication across audiences. Words: "I wrote the release checklist our QA team still uses." Any wider step is an answer slot: if you have written something other teams acted on, name it; if not, say so. |

**Pack observation, not words for you:** the material shows one title, one calendar and one checklist. It does not show live-service years, coordination across four teams, or ownership of KPIs. Those three are where the interview is most likely to press.

---

## 3. Prohibited claims

These are claims this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Sourced negative: "Never led a team" (your message) | "I haven't led a team." No answer slot. |
| Monetization or in-app purchase experience | Sourced negative: "never worked on a game with in-app purchases" (your message) | "I haven't worked on a game with in-app purchases." No answer slot. |
| Three years producing live-service | Inflated form of F5 | Quote at its own scope: "4 years as an associate producer at a puzzle-game studio." Limit stated in analysis: the material does not show the title was live-service. |
| Ran the live-events calendar for two titles | Inflated form of F1 | Quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Limit in analysis: one title, weekly content drops. |
| Owned the post-event review and its KPIs | Inflated form of F3 | Quote at its own scope: "Presented the monthly retention numbers to the studio head." |

---

## 4. Persona table and weights

No interviewer profile is verified, so weights come from the hiring-manager prior and from the loop. The loop is documented: Saltmarsh's own careers page names a live-incident tabletop, then a values conversation, in one 60-minute session.

| Persona | How it shows up | Weight and reasoning | Counter-strategy (rehearsal method) |
|---|---|---|---|
| Case/Strategist | The Outage Hour tabletop: a live incident on a live event | 5, top. The loop source documents it as the first half of the one session. The hiring-manager prior also favours it | Clarify, then structure, then decide, then communicate. Think aloud and name who decides |
| Values/Behavioral | The values conversation, against the three published values | 4. The loop source documents it as the second half | Map a story to each value where a sentence of yours carries one. Where none does, use the selection scaffold and its honest branch |
| Skeptic | Probes the gap against the JD: live-service years, four teams, KPI ownership | 3. Hiring managers derisk gaps, and F5 and F2 are the largest | Know the most likely objection and hold it for two follow-ups before conceding |
| Data-Driven Prober | Asks how the retention figure was counted | 2. F7 is the only headline number on your material | Say what you know about the counting and the assumption you would defend least. If you do not know, say so |
| Pressure | Time-boxed challenges to your claims | 2. Plausible in the values half | Pause, restate, hold through two follow-ups, then concede the specific gap |
| Conversational | A casual opener and a casual question about Saltmarsh's titles | 2. Casual questions are still scored | Have a 90-second arc ready and treat the title question as scored |
| Peer Evaluator | Seams between your calendar and design, after the Larkspur change | 2. Kept low because the interviewer is the hiring manager, not a peer | Propose seam principles rather than claiming to know the seam |

---

## 5. Question banks

Session total: 20 questions, inside the 18 to 26 range. Depth follows weight.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's a live event, Saturday evening, and checkout has been failing for twenty minutes. Walk me through your first fifteen minutes." | CASE | [generic] | Clarify first: which players and platforms, and what "failing" means in numbers. Then name who can roll back, who must hear within five minutes, and what goes to players. Announce what is confirmed, not what is hoped. Makes no claim about your past. | This is the Outage Hour's format, from the careers page. It also gives the first written message to players, which is where written communication shows in this round. |
| A2 | "The event is live, tomorrow's content drop has a QA blocker, and players are asking. What do you tell the player-facing team, and when?" | CASE | [generic] | Structure: what the blocker stops, who it affects, who decides, then the message. The calendar follows the players, not the reverse. | A live drop-versus-QA decision. CASE primary, JD secondary (the checklist requirement). |
| A3 | "You have two titles and one live-events calendar. How would you sequence the next six weeks?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Structure first: constraints, QA gates, committed events, then the sequence. If you draw on calendar work, say what you ran in your own words. Answer slot: the JD's two-title line makes a probe on the second title likely. If you planned for any second title, say which and what you decided; if you did not, say so and describe how you would sequence two. | F1 is the evidence for the two-title requirement. JD because it scores the stated requirement. CASE delivery. |
| A4 | "Larkspur puts both titles on one shared calendar from February. What does the first version of that calendar have to get right?" | CO | [grounded] Saltmarsh news, Project Larkspur (search result). Makes no claim about you. | Name what a shared calendar must reconcile: release cadence, QA gates, and the season-pass timing the news describes. Ship the Patch Not the Promise: only built things go on the calendar. | Saltmarsh's own published strategy. Shows you read the company's recent move. |
| A5 | "You have one post-event review. Which three numbers go in it, and what decision does each one change?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head." | Start from the decision, then the number. Retention is a number you presented, so you can start there, but say what decision it changed. Answer slot: if a number you presented changed a decision, say which; if not, say so. | The post-event review and its KPIs are a stated responsibility. CASE primary, JD secondary. |

### B. Values/Behavioral (weight 4)

Values from saltmarshgames.com/values: **Players Before Plans**, **Ship the Patch Not the Promise**, **Leave the Build Greener**.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Open prompt: choose one time a dated drop had to move because players needed something else. Tell it in order: what players needed, what the calendar said, what you decided, who you told. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your calendar work carries, or how you would handle it. | Players Before Plans is the published value. The calendar sentence is the nearest material. EXP secondary. |
| B2 | "Tell me about a time you had to say a build wasn't ready when someone wanted to announce it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: a time you held an announcement because the thing was not built. If the checklist is what let you hold it, say what it caught. If no such time comes to mind, say so plainly, then give the nearest thing. | Ship the Patch Not the Promise. The checklist is the nearest material; the guidance does not claim it stopped anything. |
| B3 | "Tell me about a change you made to a release process after it was in use." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Open prompt. If you changed the checklist after it went into use, say what changed and why. If you did not change it, or it was not yours to change, say so plainly and describe what you did keep. | Leave the Build Greener. An open prompt, so the guidance supplies no change for you. |
| B4 | "Tell me about a time you presented bad numbers to someone senior." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Open prompt. If the numbers were bad and you said so to the studio head, say what you said and what came back. If they were not bad, or you did not raise it, say that and give the nearest instance. Add no ending. | Hard-truth landing for the values conversation. Your sentence carries the presenting, not a bad-numbers moment. |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The JD asks for three years producing live-service games. Which of your experience meets that, and which doesn't?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." | **Highest-ROI prep in this pack.** This requirement is the gate, and the first thing a hiring manager tests against the JD. Hold the position the quotes carry: four years as an associate producer at a puzzle-game studio, and two years running the weekly content-drop calendar for the main title. Hold through two follow-ups. Then concede the exact thing: your material does not show the title was live-service. Answer slot: if you were asked whether the title kept getting new content after launch, say what that looked like; if not, say so. Never state that the years were live-service. | F5 is the gate, and the hold is only what the quotes carry. Hold-then-concede is the structure. This is the deepest rehearsal in the pack: three follow-ups. |
| C2 | "You ran the content calendar. Who had the final say on what went into it?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if you set what went into the calendar, say which parts and how you decided; if others decided, or it was not yours, say so plainly and describe what you ran. | "Ran" is the claim under test. The question tests the decision boundary. EXP primary. |
| C3 | "Tell me about an update where you had to bring design, art, engineering or community along." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Open prompt. The JD names four teams and your material names QA. If you coordinated any of design, art, engineering or community on an update, say which and what you did. If the nearest is the QA checklist, say so and tell that. If none applies, say so plainly. | F2's gap. The JD's line raises the four teams, and QA is the only one your material shows. |

### D. Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented the retention numbers to the studio head. How was retention counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Defend-the-number slot. Say the definition you used, if you know it, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so. Do not reconstruct a method you cannot repeat. | Retention is the headline figure, and F7 is the evidence. The slot asks about the counting; it does not supply a method. |
| D2 | "Which KPIs would you own in the post-event review, and which would you only report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you chose which numbers went into a review, say which; if you only presented numbers others chose, say so and name them. | Owning the KPIs is a JD requirement. F3 is the evidence, and it shows presenting, not owning. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why hire you over someone who has run a live-service title for three years?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Pause, then restate the question. Hold with what you did, in the quote's words. Hold through two follow-ups, then concede the specific gap: your material does not show live-service years. Do not argue with a comparison you cannot see. | Composure under a time-boxed challenge. The question is a comparison, not a claim about you. |
| E2 | "You have never worked on a game with in-app purchases. Why would the team trust you on a season pass?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then hold on what you would bring, the calendar and the checklist, and what you would do to learn the monetization side. Hold through two follow-ups, then concede. Do not claim season-pass experience. | The negative is one you stated, so the plain acknowledgment is yours to say. The season pass comes from the Larkspur news, which the JD does not mention. |

### F. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey. How did you end up in games?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Prepare a 90-second arc from your own sentences, in this order: the studio and role; the calendar; the checklist QA still uses; the retention numbers you presented. Each beat is a quoted sentence, told in your words. | The casual opener is still scored, on communication economy and clarity. |
| F2 | "What have you been playing in Tidepool Tactics or Lantern Row lately?" | CO | [grounded] Saltmarsh news, Project Larkspur (search result), naming both titles. Makes no claim about you. | Answer slot: if you have played either, say what you noticed; if not, say so and say what you would check first. | A casual question on a title the company has just named. Your answer is scored. |

### G. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Under Larkspur there's one live-ops group. Where's the seam between your calendar and our design team's?" | CO | [grounded] Saltmarsh news, Project Larkspur (search result). Makes no claim about you. | Propose seam principles, not a map: the calendar owns dates and gates; design owns what goes into each drop; disagreements go to one named owner. Do not claim to know their seam. | The Larkspur change makes the seam real. Peer-style probe kept at low weight. |
| G2 | "When a release goes well, whose credit is it? The calendar, QA, or design?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say whose part was whose: the checklist was yours; name the other parts a release needed. Do not claim credit for others' work. | Credit-sharing probe, scoped to the checklist sentence. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A3, A4 |
| Coordinate design, art, engineering and community teams | A2, C3, G1 |
| Own the post-event review and the KPIs | A5, D2 |
| Manage the release checklist with QA | B2, B3, G2 |
| 3+ years producing live-service games or apps | C1, E1 (gate; Step 1 question settles it) |
| Experience running a content calendar | A3, C2 |
| Comfortable with player-retention metrics | D1, A5 |
| Clear written communication | A1 (the first message to players). No dedicated written-artifact question: the Outage Hour is a live tabletop, so writing shows in A1 |

---

## 6. Values cheat sheet

Values from saltmarshgames.com/values, quoted by name. Working meanings paraphrase the page.

| Value | Working meaning | Your story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold, B1. Nearest material: "I ran the weekly content-drop calendar for our main title for the last two years." If no such time comes to mind, say so plainly, then give the nearest thing. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold, B2. Nearest material: "Wrote the release checklist our QA team still uses." If no such time comes to mind, say so plainly. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | Open prompt, B3. Nearest material: "Wrote the release checklist our QA team still uses." If you changed the checklist after it went into use, say what changed; if not, say so plainly. |

---

## 7. Reverse questions

Your interviewer's public footprint could not be verified, so these are role-generic. Each has a reason it lands.

1. "Under Larkspur, what does this role own that the per-title event teams did not?" Why it lands: it shows you read the company's recent move and asks the scope question the restructure raises.
2. "After February, which KPIs does leadership read first, and what decision does each one change?" Why it lands: it turns the post-event review into a conversation about decisions.
3. "The Outage Hour tests the first five minutes of an incident. What separates a strong first five minutes here from a weak one?" Why it lands: it shows you know the format before you are in it.
4. "After the change, where does release-checklist ownership sit between QA and the live-ops group?" Why it lands: the checklist is a stated responsibility, and the answer decides whether you can own it.
5. "What would make you say no to this hire?" Why it lands: it asks for the real bar and shows you are candid.
6. "What would someone need to have done in their first ninety days to be judged a success in this role?" Why it lands: it turns the interview toward the job's first milestones.

---

## 8. Sources

**Provided documents:** your message (the JD and your background).

**Searches and fetches sent:**

- Search "Saltmarsh Games values": saltmarshgames.com/values
- Search "Saltmarsh Games interview process Live Operations Producer": saltmarshgames.com/careers/interviewing
- Search "Saltmarsh Games strategy news mobile games": saltmarshgames.com/news/project-larkspur (search snippet, not fetched)
- Search "Tobias Wrenfield Saltmarsh Games Head of Live Operations": talks.gdconf.example/2026/patch-notes-are-a-promise. **Not established:** the domain is a reserved example domain and cannot be checked as GDC's or the interviewer's. Nothing from it is used.
- Fetch saltmarshgames.com/values: the three published values
- Fetch saltmarshgames.com/careers/interviewing: the Outage Hour

**Target accounting:**

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | yes | Values cheat sheet, section 6; B1 to B4 |
| 2. Saltmarsh interview process, Live Operations Producer | yes | Loop established: one 60-minute Outage Hour with the hiring manager. Persona weights 5 and 4 |
| 3. Saltmarsh strategy / recent news | yes | Project Larkspur, September 2026, from the search snippet. Moved A4, F2, G1 and reverse questions 1 and 4 |
| 4. Tobias Wrenfield with Saltmarsh | yes | One result, not established (reserved domain). No interviewer read; no interviewer-specific reverse question |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## 9. Upgrade menu

- Whether the puzzle title was live-service, meaning new content after launch → settles the gate row F5, and sharpens C1 and E1
- Your own sentences on coordinating design, art, engineering or community → upgrades F2 and C3
- Your own sentences on the post-event review or its KPIs → upgrades F3 and D2
- Any written work other teams acted on → upgrades F8 and the written-communication coverage
- Confirmation of the GDC 2026 talk on GDC's own site → adds an interviewer read and a reverse question on their path from QA lead to live operations. The only result found sits on a reserved example domain, so it is not used.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes. Adds a Larkspur strategy brief and role-family loop reports, which would strengthen A4, F2, G1 and the reverse questions. Want it?
- A `tuesday-dossier.md` would add verified evidence and any prohibited claims from a sourcing pass; none is present, so this is a single line, not a prerequisite.
