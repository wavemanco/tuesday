# Interview pack: Member Experience Lead, Ashgrove Credit Union

Prepared 24 November 2026 for Dara. Interviews on 3 December 2026 in three rounds, run as a loop: recruiter (30 min), Head of Member Services (45 min, your future manager, mostly behavioural), panel of two branch managers (60 min, including a 20-minute complaint-escalation case; the panel scores against the four values). Interviewers beyond the recruiter and the Head of Member Services are not yet named.

## How to use + type key

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **VAL**: behavioural and values alignment. Does past behaviour show the published values?
- **EXP**: work-experience deep-dive. Does what you did survive a follow-up?
- **JD**: role-driven. Can you do what the posting lists, gaps included?
- **CO**: company and strategy knowledge, at the level the brief states it.
- **CASE**: a live problem from the role, reasoned out loud.
- Guidance is scaffolding, not a script. Say it in your own words. Where a cell says "answer slot", the answer is yours to give, and it may be "that was not mine".

## Fit snapshot

Requirements are quoted from the JD you sent, or from the recruiter's email. Your sentences are quoted from your message to me. Nothing in this section is a claim I made up about you.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD you sent) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | Your six years are stated, not yet checked against documents. Lead with them: "Six years in retail banking, the last three as a branch supervisor." |
| F2 | "experience handling regulated complaints" (JD you sent) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The log is formal complaints work at branch level. Your material does not say whether it followed set timescales or a referral route; the JD does say "regulated." Answer slot: if your log ran to set timescales or a referral route, say which and how you tracked them; if it did not, say so and say what the log did carry. |
| F3 | "own the member complaints process end to end across branches and the contact centre" (JD you sent) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material shows one branch, not several. The bridge stays at that scope: "For my branch I handled the formal complaints log." Answer slot: if you ever followed a complaint from first contact to close across more than one site, say how; if you did not, say so. |
| F4 | "own the member complaints process end to end across branches and the contact centre" (JD you sent), contact-centre part | "Never worked in a contact centre" (your message) | none given | [grounded] | capability | A gap you stated, so the words are yours: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. |
| F5 | "report monthly on complaint volumes and resolution times" (JD you sent) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The spreadsheet already reaches the reporting line in other terms. Bridge reworded only: "I built the monthly complaints spreadsheet our regional manager uses." Add no measure, figure or event. |
| F6 | "comfortable with Excel reporting" (JD you sent) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | transferability | Your material shows a spreadsheet, not which software it was. Answer slot: say which tool you built it in, in your own words; if it was not Excel, say so. |
| F7 | "coach branch supervisors on escalations" (JD you sent) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | The training was for tellers, not supervisors. Bridge at that scope: "I trained new tellers on our escalation script." Answer slot: if you coached anyone on judgement in escalations, not only the script, say how; if not, say so and say how you would coach supervisors. |
| F8 | "confident presenting to senior leaders" (JD you sent) | "I've never presented to anyone above regional level" (your message) | none given | [grounded] | capability | A gap you stated: "I've never presented to anyone above regional level." Then how you would prepare, as a plan and never as a past. |
| F9 | "work with digital teams on self-service journeys" (JD you sent) | none given | none given | [grounded] | discovery | Your material does not show digital or self-service work. Answer slot: if you have worked on a change to how customers do something, say what it was and your part in it; if not, say so and say how you would start with the digital team. |

Limits the pack observes in its own analysis: your material does not show a contact centre, presentation above regional level, or digital work. Those are gaps, and the pack does not supply words that close them.

## Prohibited claims

The pack will not coach these. Each entry names its basis and gives the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3 and F4 | F3's quote at its own scope: "I handled the branch's formal complaints log." F4's acknowledgment: "Never worked in a contact centre." |
| Presented complaint reporting to senior leaders | Inflated form of F5 and F8 | F5's quote at its own scope. The pack's observation: your material shows a spreadsheet the regional manager uses, not a presentation. F8's acknowledgment: "I've never presented to anyone above regional level." |
| Designed the measures the team reports on | Inflated form of F5 | F5's quote. The pack's observation: your material does not say what the spreadsheet measured. R2-6's slot asks that, nothing more. |
| Trained branch supervisors | Inflated form of F7 | F7's quote: "trained new tellers on our escalation script." |

## Grounding brief: the company, as its brief states it

Sourced from the July 2026 strategy brief as your recruiter summarised it to you. I have not read the brief itself, and this section uses only the four points you gave.

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- The main competitive pressure is app-only banks.

How to talk about it without overclaiming: you can say what you know of the brief, and what you would want to see. You cannot say which branches are in the plan, how the hubs will work, or what members will experience. You have no digital experience in your material; say so when asked, and do not describe the 40% target as something you have run. The "Neighbours, Not Numbers" value is the tension to prepare: a branch-to-hub move can look like numbers beating neighbourhood. Answer it as a principle with a question attached, not as a verdict on the plan.

## Persona table

| Round | Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| 1, recruiter | Conversational / Rapport Builder | Friendly biography, logistics checks | High: the recruiter relationship prior is conversational, and pay, notice, location and reason for leaving are asked casually | Pre-scripted 90-second arc; treat casual questions as scored; give your own words on each logistics item |
| 1, recruiter | Skeptic (light) | "Why now?" and "why this role?" | Medium: the recruiter screens for motivation consistency | Give the true reason plainly |
| 2, Head of Member Services | Skeptic (top) | "You haven't worked in a contact centre" and "one branch is not end to end" | High: the fit snapshot's biggest gaps are F4 and F3, and a future manager will test them | Plain acknowledgment, then a plan; hold the evidence you have through two follow-ups; concede exactly what is missing |
| 2, Head of Member Services | Case / Strategist (3) | Live escalation and coaching problems | Medium: the manager is buying capability and the JD names escalation coaching | Clarify, then structure, then answer; say the structure aloud |
| 2, Head of Member Services | Values / Behavioral (3) | STAR-shaped prompts on members and rules | Medium: the recruiter says the values are scored in round 3, so round 2 tests them lightly | Story from the quoted sentences, or say none came to mind |
| 2, Head of Member Services | Data-Driven Prober (2) | "Walk me through the spreadsheet" | Lower: the spreadsheet is a JD line the manager will check | Say what it held, and only that |
| 3, panel | Values / Behavioral (top, 5) | The four values, one question each | High: the recruiter states the panel scores against the four values | One story per value, or the honest branch |
| 3, panel | Case / Strategist (4) | The 20-minute escalation case | High: a 20-minute case is in the loop | Clarify facts and timescales first; decide what the member needs; name the coaching and the report |
| 3, panel | Pressure / Stress (3) | "Every candidate says they'll learn it" | Medium: two branch managers will test the presentation and contact-centre gaps | Hold the evidence through two follow-ups; concede the gaps plainly |
| 3, panel | Data-Driven Prober (2) | Volumes and times in the report | Lower: branch managers see the numbers daily | Say how you would count, not a figure you do not have |

Weights: round 2 leans on Skeptic because the gaps in your fit snapshot are the gaps a future manager is most likely to test. Round 3 leans on Values because the recruiter says that round scores the values.

## Question banks

Each round is a mini-pack. Within each, the question with the most rehearsal is named first.

### Round 1, recruiter (30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Six years in retail banking, the last three as a branch supervisor. Then the formal complaints log, the escalation training for tellers, and the monthly spreadsheet, in your words. Stop near 90 seconds. | F1, F2, F5 and F7 are the four facts the rest of the loop rests on; this is the first place they are heard. EXP because the arc has to hold under a follow-up. |
| R1-2 | "What salary are you looking for?" | JD | [generic] | Give the figure you want, in your own words. If you would rather see the band first, say that. Do not give a figure you have not chosen. | A logistics slot. No figure is in your material, so none appears in the pack. |
| R1-3 | "What notice would you need to give?" | JD | [generic] | Give your actual notice period in your own words. | A logistics slot. The answer is yours, not the pack's. |
| R1-4 | "Where could you work from, and how often would you be in the office?" | JD | [generic] | Give your own answer on where and how often you can work. The JD you sent does not state an office pattern, so ask the recruiter for it if it matters to you. | A logistics slot. The office pattern is not stated in the material. |
| R1-5 | "Why are you looking to move now?" | EXP | [generic] | Give your reason in your own words, at the size it really is. A true reason stated plainly is stronger than a polished one. | Motivation is screened in round 1; no reason is in your material, so the answer is yours to give. |

### Round 2, Head of Member Services (45 min, mostly behavioural)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-1 | "You haven't worked in a contact centre. Which part of this role would you find hardest on day one?" | JD | [grounded] "Never worked in a contact centre"; "trained new tellers on our escalation script" | The plain acknowledgment: "I've never worked in a contact centre." Then a plan, not a past: name the parts you would learn first and how you would learn them. Bridge only from the adjacent evidence you stated: "The nearest I've done is an escalation script for tellers, and I'd map what changes when complaints come through the contact centre rather than the branch." Hold through two follow-ups, then concede the gap exactly. | F4 is the largest gap and the likeliest probe. The question's premise is your own negative, so it can be used. Highest-ROI prep in this pack. |
| R2-2 | "The role covers branches and the contact centre, and your material is one branch. Why is that enough?" | JD | [grounded] "I handled the branch's formal complaints log" | Hold the scope you have: "I've handled one branch's formal complaints log. I'm not claiming multi-site ownership." Then concede what is missing: "I haven't owned a process across sites, and I'd build that from the one I know." Do not stretch the log. | F3's scope. The objection is aimed exactly where the material is thin, so the hold is only what the quote carries. |
| R2-3 | "Tell me about a complaint you had to escalate beyond your branch. What did you do?" | JD | [grounded] "I handled the branch's formal complaints log" | Open prompt. If one comes to mind, tell it from your own role: what you handled, what you passed on, and where it ended. If none comes to mind, say so plainly, then give the nearest thing your material carries: the formal complaints log you handled. Answer slot: if the escalation was yours to make, say so; if it went through someone else, say that. | The JD names escalations. Your material supports the log, not the escalation story. |
| R2-4 | "When did a member's need conflict with a process rule? What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt with a selection scaffold: pick a time you put the member's need first, and say what the rule said. If none comes to mind, say so plainly, then give how you handled a complaint from the member's side. | The Members First value tested in round 2. |
| R2-5 | "How would you coach a branch supervisor on an escalation they are unsure about?" | JD | [grounded] "trained new tellers on our escalation script" | Map the training to coaching: you taught tellers the escalation script. Answer slot: if you coached anyone on judgement in escalations rather than the script alone, say how; if not, say so and say how you would coach a supervisor who is unsure. | F7 is the nearest story. The JD says "supervisors"; you trained tellers. |
| R2-6 | "Walk me through the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what you built, in its own terms. Answer slot: if it recorded complaint volumes or resolution times, say which and how you counted them; if it recorded something else, say what it held. Do not describe a measure you did not track. | F5 and F6 are the reporting requirements. The figures are not in your material, so the pack does not supply them. |
| R2-7 | "The strategy brief moves 40% of member service to digital by 2028. What would you need to see before a complaint moves to a self-service route?" | CO | [generic] | Principle first: a member should still be able to reach a person, and the route should show when a complaint needs one. Answer slot: if you have worked on a change to how customers do something, say what it was and your part; if you have not, say so and say how you would start with the digital team. | F9 is the gap; the honest answer is a principle with a plan, not a past. |

### Round 3, panel of two branch managers (60 min, including a 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. If one comes to mind, tell it: what the member wanted, what you decided, and what happened. If not, say so plainly, then give the nearest thing your material carries: the complaints log. | Members First, scored by the panel. |
| R3-2 | "Tell me about a time you had to explain something to a member more than once." | VAL | [grounded] "trained new tellers on our escalation script" | Open prompt. If you explained the script in plain words to tellers, say how. If you did not, say so, then say what you would do first. | Plain Words, tested by a question about explaining. |
| R3-3 | "The strategy brief consolidates eight branches into five hubs over 2027. What happens to the members in the three that close?" | VAL | [generic] | Do not claim insight into the plan's detail. Say what you would want to know: where members travel from, which complaints move, and how members are told. Name the principle: the member is part of the town. | Neighbours, Not Numbers meets the brief's consolidation. The panel is checking whether you read the value as principle. |
| R3-4 | "Tell me about a problem you found that was not yours to fix. What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Pick a time you found a problem and carried it until it was solved, or say so, then give the nearest: the complaints log, if it carried a case to close. | Own the Fix, scored by the panel. |
| R3-5 | Case (20 minutes): "A member has complained three times about the same fee. The branch says it is resolved; the member says it is not. Walk us through the next 20 minutes." | CASE | [generic] | Clarify first: what was each complaint, what dates, what was the outcome of each. Then the member's side: what they need. Then who decides and what the timescales are. Then what you would coach the supervisor to do, and what goes into the monthly report. Say the structure aloud. Do not assume a process you have not been told. | The 20-minute case is the escalation case the recruiter named. It is generic, so the pack asserts nothing about Ashgrove's process. |
| R3-6 | "The board will see complaint volumes rise next quarter. How would you present that to them?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Then the plan: one page, the number, what it means for members, and the decision you need. Give the plan, not a past. | F8 is the second gap. The panel will test whether you can own it without inflating it. |
| R3-7 | "Every candidate tells us they will learn it. Why should we trust you on the contact centre and presenting?" | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I've never presented to anyone above regional level"; "Never worked in a contact centre" | Hold what you have: six years, three as a branch supervisor, the complaints log, the spreadsheet. Concede exactly what is missing: "I haven't worked in a contact centre, and I haven't presented above regional level." Name how you would close each. Hold through two follow-ups. | Pressure: the hold is only what you have stated, and the concession is the two gaps you stated. |

### Coverage of the JD

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | R1-1 |
| Experience handling regulated complaints | R2-2, R2-3, R3-5 |
| Own the complaints process across branches and the contact centre | R2-1, R2-2, R3-7 |
| Report monthly on complaint volumes and resolution times | R2-6, R3-6 |
| Coach branch supervisors on escalations | R2-5, R3-5 |
| Work with digital teams on self-service journeys | R2-7, R3-3 |
| Confident presenting to senior leaders | R3-6, R3-7 |
| Comfortable with Excel reporting | R2-6 |

## Values cheat sheet

Detected because the recruiter's email names the panel as the values round and says it scores against the four values.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F2: "I handled the branch's formal complaints log." Pick a complaint you decided from the member's side. If none comes to mind, say so plainly, then give the log. |
| Plain Words | If a member needs it explained twice, the wording was wrong | F7: "trained new tellers on our escalation script." Say whether you taught the script in plain words. If the script was not plain, say so and say what you would change. |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries a story. Selection scaffold: pick a time you thought about a branch's place in its community. If none comes to mind, say so plainly, then answer the R3-3 principle. |
| Own the Fix | Whoever finds the problem keeps hold of it until solved | F2: the complaints log. Pick a problem you carried to resolution. If the log ended with a case open, say so. |

## Reverse questions

Each has a "why it lands." No interviewer profile exists, so none is tied to a career path. The recruiter is not a peer, so no reciprocity question is included.

1. Head of Member Services: "What would a strong first 90 days look like for you?" Why it lands: it shows you plan to earn the role, not assume it.
2. Head of Member Services: "When service moves to digital, how will complaints be routed, and who owns that routing?" Why it lands: it names the JD's digital line as a process question, not a challenge.
3. Head of Member Services: "How will the move to five hubs change how complaints reach the team?" Why it lands: it names the 2027 move without guessing its outcome, and leaves room for the manager to say what is known.
4. Panel: "What does an escalation done well look like from a branch manager's side?" Why it lands: it asks for the panel's own standard, which is what they will score against.
5. Recruiter: "What happens after the panel, and is there a decision date?" Why it lands: it shows you track the loop without pressing for an answer.

## Prohibited claims check

Built from the fit snapshot. Each entry above names its basis. No question, slot or reverse question asserts a claim in that table.

## Sources

- Provided documents: the JD text you sent; the recruiter's email (three rounds, 3 December, round descriptions, values round); the four values as you copied them from ashgrovecu.org/about/values on 24 November 2026; the July 2026 strategy brief as your recruiter summarised it to you; your background as you wrote it.
- Searches and fetches this turn: none run.

Research tier: L0 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text you pasted fixes the values cheat sheet, so no search was needed |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email fixes the three rounds and the values round |
| 3. Ashgrove strategy / recent news | skipped | The brief you supplied fixes the grounding brief; a fuller read would add the brief's own wording |
| 4. Interviewer name plus Ashgrove | n/a | No interviewer name has been given; the Head of Member Services and the panel are unnamed |
| 5. Representative Member Experience Lead JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The Head of Member Services' name → a tailored reverse question and persona weights from their public footprint.
- The panel branch managers' names → persona weights per member.
- The full July 2026 strategy brief, not the summary → CO questions in its exact wording, and a fuller grounding brief.
- A sentence from you about any contact-centre work, even a small one → rows F4 and R2-1 get a quote and their slot narrows.
- A sentence from you about any digital or self-service work → row F9 and R2-7 get a quote.
- A sentence from you about presenting, even to a small group above your own level → row F8 and R3-6 get a quote.
- Which software you built the spreadsheet in, and what it held → row F6 and R2-6 become grounded.
- Your pay figure, notice period, office pattern and reason for leaving, once you have decided them → the round 1 logistics slots become your own words.
- A deeper research pass (the full brief, interviewer talks, recent news; at most 6 searches and 2 fetches) → it takes about one more search round; say yes and I'll run it.
