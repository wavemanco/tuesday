# Member Experience Lead, Ashgrove Credit Union: interview prep pack (loop mode)

**Role:** Member Experience Lead. **Company:** Ashgrove Credit Union (member-owned, about 900 staff).
**Loop:** three rounds, all on 3 December 2026: (1) recruiter, 30 min; (2) Head of Member Services, 45 min, your future manager, mostly behavioural; (3) panel of two branch managers, 60 min, including a 20-minute complaint-escalation case, scored against the four values.
**Interviewers:** the Head of Member Services and the two panel members are not yet named, so no interviewer read is included. Persona weights come from round-type priors.
**Pronouns:** they/them, as you asked.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behaviour shows the four published values |
| EXP | Work-experience deep-dive | Whether what you did survives follow-up, and whether the attribution is precise |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge | Whether you know where Ashgrove is going |
| CASE | Hypothetical / live problem | How you structure a problem from the role |

The guidance is scaffolding, not a script. Lines marked "answer slot" are instructions for the interview, not questions for me. Where a slot has an honest branch ("if none was yours, say so"), use it. Do not fill a slot with a practice you did not do.

## Prep triage

You have nine days (24 November to 3 December). In order:

1. **B1, the contact-centre objection.** It is the most predictable challenge to you, so it gets the most time. Rehearse it aloud three times, each with two follow-ups.
2. **C1 and C2, the escalation case and the Friday report.** Practise the structure out loud, then time one full run at 20 minutes.
3. **A1 to A4, the logistics.** Decide your own figures, notice period, locations and reason for leaving before the recruiter call. The pack supplies none of them.
4. **Values.** Work through the cheat sheet. For each value, either use the mapped story or rehearse the honest branch. Do not invent a story to fill a gap.
5. **B6 and C6, presenting and the seam with the contact centre.** Plan a three-point complaints-trends talk as a plan. Do not describe past presentations.
6. **Read the strategy brief** and rehearse B8 and B9, which are the questions the July 2026 plans will prompt.

Everything else is insurance.

## The fit snapshot

Requirements are quoted from the job description you pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | Reword only the quote: six years in retail banking, the last three as a branch supervisor. Do not add a customer-operations title you did not hold. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Answer slot: say in your own words what handling the formal complaints log involved. If any regulatory timescales applied to those complaints, say which. If none did, or you are not sure, say so plainly. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message); "Never worked in a contact centre" (your message) | medium | [grounded] | capability | Plain acknowledgment first: "I've never worked in a contact centre." Then the branch side, from your quote. The contact-centre side is what you would learn first, and you can say how, as a plan. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | Answer slot: say what the spreadsheet tracked. If it tracked how long complaints took to resolve, say so. If it did not, say that. The material does not show either. |
| F5 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Reword only the quote: you trained new tellers on the escalation script. The material does not show coaching supervisors, so say what you did as a branch supervisor, in your own words. |
| F6 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Answer slot: if you have worked with a digital or self-service channel, say what it was and what your part was. If you have not, say that plainly, then say how you would learn it with the digital team. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Plain acknowledgment: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. |
| F8 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | Describe the spreadsheet in your own words. Do not say "Excel" unless you used Excel. The JD's word is not yours. |

**Reading the snapshot.** The strongest parts of your material are F1 and F5: six years in branches, and a training role on the escalation script. The weakest parts are F3 and F7, both of which you stated yourself. Expect the panel to probe F3 hardest, because it sits on the centre of the JD.

## Grounding brief: the company, from the documents you supplied

Source: the July 2026 strategy brief, sent by the recruiter, and the values page copied on 24 November 2026.

- **Digital shift:** 40% of member service moves to digital channels by 2028. [grounded, strategy brief]
- **Branch network:** eight branches consolidate into five hubs over 2027. [grounded, strategy brief]
- **New product:** a small-business lending product launches in Q1 2027. [grounded, strategy brief]
- **Competitive pressure:** app-only banks. [grounded, strategy brief]
- **Values:** Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix. [grounded, values page]

Use their current vocabulary: "member service", "digital channels", "hubs". Refer to the 2027 network as hubs, not as branches. Do not correct an interviewer who uses the older language.

## Persona weights per round

| Persona | Round 1, recruiter | Round 2, Head of Member Services | Round 3, panel |
|---|---|---|---|
| Conversational / Rapport | 75% | 0% | 0% |
| Skeptic | 25% | 35% | 0% |
| Values / Behavioral | 0% | 40% | 30% |
| Case / Strategist | 0% | 25% | 30% |
| Peer Evaluator | 0% | 0% | 40% |

**Reasoning.**
- Round 1: recruiter screens use a friendly register but score logistics and motivation. Conversational carries the weight; Skeptic covers the contact-centre gap.
- Round 2: a manager who said the round is mostly behavioural. Values leads, with the contact-centre and presenting gaps as the Skeptic's natural targets, and the monthly reporting and digital work as the Case items.
- Round 3: the panel is scored against values, so Values is a third of it. The escalation case is 20 of the 60 minutes, so Case is the largest single weight. Branch managers are peers to a branch-level role, so Peer Evaluator carries the rest. The panel members' names are unknown, so no per-member assignment.
- Depth follows weight: Round 2 has four Values questions, three Skeptic and three Case; Round 3 has three Case, three Values and two Peer. Round 1 has seven conversational-register and one Skeptic.

## Round 1: recruiter screen (30 min, 3 December)

**Weights:** Conversational 75%, Skeptic 25%. The recruiter's job is logistics and motivation, asked warmly.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations for this role?" | JD | [generic] | Logistics slot. Give your own figure in your own words, or ask the recruiter for the role's band before you name one. Do not give a figure you have not chosen. | The recruiter screen asks pay first; the JD states no pay, so the slot is yours to fill. |
| A2 | "What notice period do you need to give your current employer?" | JD | [generic] | Logistics slot. Give your actual notice period. | Notice is a knockout question in a screen; the material does not state it. |
| A3 | "Which of our locations could you work from, and how often would you need to be on site?" | JD | [generic] | Logistics slot. Name the locations you can reach and your own on-site pattern. | The hub consolidation makes location a live topic in 2027; the material states no location. |
| A4 | "What's your reason for looking to move?" | EXP | [generic] | Logistics slot. Give a reason in one or two sentences, in your own words, without criticising your current employer. If you would rather not give it, say so. | Motivation consistency is scored in a screen, and the reason is yours to give. |
| A5 | "What drew you to Ashgrove?" | CO | [grounded] The published values on ashgrovecu.org/about/values | Name one of the four values and say why it matters to you in your own words. Do not claim knowledge of the strategy beyond the brief. | Easy to answer generically; the values are published and scored later, so using them here sets up round 3. |
| A6 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" and "I handled the branch's formal complaints log and trained new tellers on our escalation script" | A 90-second arc: six years in retail banking, the last three as a branch supervisor; then the complaints log and the escalation training, in those words. Stop there. | A conversational opener is scored on economy. The arc uses only what you wrote. |
| A7 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then the branch experience from A6, and how you would learn the other side. | This is the gap the recruiter will check first. Answer it early and plainly. |
| A8 | "You've spent six years in retail banking. What appeals to you about a member-experience role?" | CO | [generic] | Talk about the member-experience work itself, not about the branch network. Do not criticise branches. | The question is asked to test whether the move is a choice or an exit. |

**Reverse questions, round 1**

- "What does a successful first 90 days look like in this role?" Why it lands: it turns a screen into a scope conversation and shows you are already planning.
- "How does the 2027 hub work change the complaints workload?" Why it lands: it uses the strategy brief and signals you have read it.

## Round 2: Head of Member Services, future manager (45 min, 3 December)

**Weights:** Values 40%, Skeptic 35%, Case 25%. "Mostly behavioural" makes Values the largest weight.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked in a contact centre, and this role owns complaints across one. Why would we trust you with that?" | JD | [grounded] "Never worked in a contact centre" and "I handled the branch's formal complaints log" | Hold, then concede. Open with the plain acknowledgment: "I've never worked in a contact centre." Then the branch side, from the quote. First follow-up: say what you would learn first, as a plan. Second follow-up: return to the complaints log. Concede explicitly: "On the contact-centre side I'd be learning, and I'd say so in the first month." | This is the most predictable objection to you, because F3 is your largest gap. Rehearse it until it is not surprising. A rehearsed plain answer beats a defensive one. |
| B2 | "Tell me about a time you put a member's situation ahead of the escalation script." | VAL | [grounded] "trained new tellers on our escalation script" | Open prompt. Pick a time a member's case did not fit the script and say what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: how you taught the script to tellers, and what you told them to do when it did not fit. | Maps to Members First, Always. The honest branch matters: the material shows the script, not a case where you set it aside. |
| B3 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Pick a complaint you followed through to a closed outcome and say how you knew it was closed. If none stands out, say so plainly and describe how the log tracked open items. | Maps to Own the Fix. Ask yourself, before the interview: did I see it through, or did I pass it on? Say which. |
| B4 | "Tell me about a time a number and a customer pointed in different directions." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Open prompt. Pick a case where the spreadsheet's figure and the member's experience disagreed. If there was none, say so and describe how you would check the figure against the member. | Maps to Neighbours, Not Numbers. Your spreadsheet is the number; the question asks you to say where the number misled. |
| B5 | "Tell me about a time you explained something to a member who needed it explained twice." | VAL | [grounded] "trained new tellers on our escalation script" | Open prompt. Pick a time an explanation did not land first time and say what you changed. If none, say so, and describe how you taught the script so tellers could repeat it. | Maps to Plain Words. The honest form is the explanation you changed, not the one you wrote. |
| B6 | "How would you present a complaints trend to our senior leadership team?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment first: "I've never presented to anyone above regional level." Then a plan for three points, the audience and the decision you would ask for. Keep it a plan throughout. | The JD asks for confidence with senior leaders. The gap is stated, so the answer is the plan. |
| B7 | "How would you coach a branch supervisor who escalates complaints that could be resolved at the counter?" | CASE | [grounded] "the last 3 as a branch supervisor" and "trained new tellers on our escalation script" | Structure: what you would check first (the cases, the escalation rules, the supervisor's own authority), what you would coach, and how you would check it had changed. Use your supervisor time as context, in your own words. Do not say you coached supervisors. | Tests the JD's coaching requirement. Your evidence is adjacent: you supervised, and you trained tellers. |
| B8 | "The strategy moves 40% of member service to digital by 2028. How would you work with the digital team on a self-service journey?" | CO | [grounded] "40% of member service to digital channels by 2028" from the strategy brief | Answer slot: if you have worked with a digital or self-service channel, say what it was and your part. If not, say so, then describe how you would start with the digital team and what you would bring from the complaints side. | The digital target is the most likely strategic probe, and F6 is your empty row. Rehearse the honest branch. |
| B9 | "We're consolidating eight branches into five hubs. What happens to complaints from a branch that closes?" | CASE | [grounded] "the last 3 as a branch supervisor" and the strategy brief's hub plan | Clarify first: which complaints are open at closure, and who holds them. Then the member's route: where they go and who tells them. Use your branch-supervisor time to say what you have seen happen to open cases. | Tests whether you can think at the company's altitude. The Neighbours value is in play here. |
| B10 | "Take me through how a formal complaint moved through your branch's log, from receipt to final answer." | EXP | [grounded] "I handled the branch's formal complaints log" | Walk the steps in your own words. If any regulatory timescales or reporting rules governed a step, name them. If none did, or you are not sure, say that plainly. Do not add a step you did not handle. | This is the regulated-complaints probe. The JD's word "regulated" is theirs; your log's rules are yours to state. |

**Reverse questions, round 2**

- "What does the Head of Member Services look at first each month, and what would tell you the complaints work is going well?" Why it lands: it sets the reporting bar and shows you plan to be measured on it.
- "How do you want the contact-centre and branch complaints handled to meet in the middle during the hub work?" Why it lands: it names the seam you were worried about, and asks your manager to own its design.

## Round 3: panel of two branch managers (60 min, 3 December, with a 20-minute escalation case)

**Weights:** Case 40%, Values 30%, Peer Evaluator 30%. The case is a third of the session and the panel scores values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member has been waiting six weeks for a reply to a formal complaint. They are at the counter, angry, and the teller can't answer. You own the complaints process. Walk us through what you do." | CASE | [generic] | Clarify first: what the member is owed, what the teller can say today, and what the six weeks cost. Then the order of actions: stabilise the member, find the case, set a reply date you can keep, and tell the teller what to say. Name the risk you would watch. | The live case, with the panel scoring structure and values together. Own the Fix and Members First are both in play. |
| C2 | "The regional manager needs complaint volumes and resolution times by Friday. What do you build first, and in what tool?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say the tool you used, in your own words. If you used a spreadsheet, say so; do not say Excel unless you did. Then the first two measures: the volume and how long each case took. Name the weakest assumption in the second. | Covers the JD's reporting and Excel requirements. The quote is the only thing you can build on here. |
| C3 | "Tell me about a time you took ownership of a problem you did not cause." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Pick a case you kept hold of after it stopped being yours, and say what you did. If none, say so, then describe how you would keep a complaint with an owner across two teams. | Maps to Own the Fix. The panel wants the hand-off refused, not described. |
| C4 | "How would you make sure hub consolidation still feels local to each town?" | VAL | [grounded] "eight branches into five hubs over 2027" from the strategy brief; Neighbours, Not Numbers from the values page | A plan, not a past. Start with the member: which town, which route to a person, how the hub tells them. Name one thing you would check after the move. | Maps to Neighbours, Not Numbers and tests the CO altitude. Use the hub language. |
| C5 | "A member calls back the next day, having been told by the contact centre that the branch owns the case. Who owns it, and what do you tell them?" | CASE | [generic] | Clarify who holds the case in the system and who can close it. Then the call: one owner, one date, one number to call. Say what you would do if the two teams disagree. | Tests the seam directly. The question is a live problem and assumes nothing about your past. |
| C6 | "Our contact centre and the branches disagree about who owns a complaint once it's logged. What do you do?" | Peer | [grounded] "Never worked in a contact centre" | Say first: "I've never worked in a contact centre." Then a principle for the seam, not a solution: one owner per case, named at logging. Ask what each team needs from the other. | Peer Evaluator probe. The plain acknowledgment protects you; the principle shows judgement. |
| C7 | "Tell me about a disagreement with a manager at your level and how it ended." | Peer | [generic] | Open prompt. Pick a disagreement you kept the relationship through and say what you changed. If none comes to mind, say so plainly and describe how you would handle one. | Peer credit and turf probes. Do not invent a disagreement; the honest branch is the strong answer if it is true. |
| C8 | "How do you check that a member has understood a written complaint response?" | VAL | [grounded] "trained new tellers on our escalation script" | Plan, then the example. Describe how you would test a letter with a member before sending. If you have explained something and checked it landed, say so in your own words; if not, say how you would check. | Maps to Plain Words. Tests the value in a practical way. |

**Reverse questions, round 3**

- "Where do your branch teams most often feel a complaint has been handed to them without an owner?" Why it lands: it asks the peer where the seam is, which is what the panel will remember.
- Reciprocity question, because the panel are peers: "What could a new person do in their first month that would genuinely help your branch team?" Why it lands: it turns the panel's own load into the conversation.

## Values cheat sheet

Condition met: the recruiter says the panel scores against the four values, and the values page is in hand. Stories come from the fit snapshot. Where none carries the value, the honest branch is given.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | F5: "trained new tellers on our escalation script." Your material shows the script, not a case where a member's situation overrode it. Selection scaffold: pick a time a member's case did not fit the rule and what you did. If none comes to mind, say so plainly and give how you taught the script. |
| Plain Words | If a member needs it explained twice, the writing was wrong. | F5: "trained new tellers on our escalation script." Selection scaffold: pick a time an explanation had to be repeated and what you changed. If none, say so and describe how you taught the script so it could be repeated. |
| Neighbours, Not Numbers | Every branch is part of its town. | F4: "I built the monthly complaints spreadsheet our regional manager uses." Selection scaffold: pick a case where the number and the member disagreed. If none, say so and say how you would check a figure against the member. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F2: "I handled the branch's formal complaints log." Selection scaffold: pick a complaint you took through to a closed outcome and how you knew. If none, say so and say how the log tracked open items. |

## Prohibited claims

These are the claims this pack will not coach, and the basis for each. Nothing in any answer, slot, hold or reverse question asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3. Your material states the branch side only. | Your quote at its own scope, with the plain acknowledgment "I've never worked in a contact centre." The pack's own observation: the material does not show the contact-centre side. |
| Presented to senior leaders | Negative you stated (F7). | "I've never presented to anyone above regional level." No slot. |
| Owned the monthly reporting and set its resolution-time measure | Inflated form of F4. Your material says you built the spreadsheet; it does not say what it tracks or who set the measure. | Your quote at its own scope. The pack's observation: the material does not show what the spreadsheet tracked. F4's slot asks only that. |
| Coached branch supervisors on escalations | Inflated form of F5. Your material says you trained tellers. | Your quote at its own scope: you trained new tellers on the escalation script. |
| Handled regulated complaints | Inflated form of F2. Your material says "formal complaints log"; it does not say regulated or which rules applied. | Your quote at its own scope. B10's slot asks which rules, if any, governed the log. |
| Contact-centre experience of any kind | Negative you stated (A7, F3). | "I've never worked in a contact centre." No slot. |

Not listed: the digital self-service work (F6). The material is silent, not negative, so it is an answer slot (B8), not a prohibited claim.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A6 |
| experience handling regulated complaints | B10 |
| confident presenting to senior leaders | B6 |
| comfortable with Excel reporting | C2 |
| Own the member complaints process end to end across branches and the contact centre | A7, B1, C5, C6 |
| report monthly on complaint volumes and resolution times | C2 |
| coach branch supervisors on escalations | B7 |
| work with digital teams on self-service journeys | B8 |
| Pay, notice and location, the listed job's terms | A1, A2, A3 |

Values, all four: B2 to B5, C3, C4, C8.

## Sources

**Provided documents:** the job description you pasted; your background, in your message; the values page copied on 24 November 2026 (ashgrovecu.org/about/values); the recruiter's email describing the three rounds and the values scoring; the July 2026 strategy brief, sent by the recruiter.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | skipped | The values copy in hand fixes the cheat sheet's four principles and their wording. |
| 2. Interview process | skipped | The recruiter's email fixes three rounds, their lengths, and the values scoring, so the loop structure is in hand. |
| 3. Strategy and recent news | skipped | The July 2026 strategy brief supplies the current priorities. A recent-news search would move the Round 2 and Round 3 CO items only, and the L2 offer covers it. |
| 4. Interviewer name and profile | n/a | No interviewer was named. |
| 5. Representative JD | skipped | The job description you supplied fixes the fit snapshot and the JD questions. |

No search or fetch was sent. Nothing in this pack comes from model memory about Ashgrove.

## Upgrade menu

- The Head of Member Services' name → public-footprint persona weights for Round 2 and one tailored reverse question.
- The two panel members' names → a per-member persona assignment for Round 3.
- Whether the formal complaints log followed regulatory timescales → turns F2 and B10 from answer slots into grounded answers.
- What the monthly spreadsheet tracked, including whether it counted resolution times → turns F4 and C2 into grounded answers, and removes the Prohibited claims entry on reporting.
- Any digital or self-service work, however small → turns F6 and B8 into grounded answers.
- The case brief, if the recruiter sends one for the escalation case → replaces the generic C1 framing with the case's own facts.
- Deep research (L2), offered once: it adds recent Ashgrove news, interviewer and panel public writing, and loop reports for branch-manager panels. Cost: at most six further searches and two fetches, with a few minutes' wait. Say yes to run it.
- `tuesday-dossier.md` from an earlier session, if you have one: it would add verified evidence bands and a prohibited-claims list from a prior underwriting. It is not needed for this pack.
