# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager, since the title sits over the role. Session length: 60 minutes.
First version. Company research did not run (see Sources), so there are no company values, loop structure or interviewer background in this pack.

## How to use

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and stop where your own experience stops.

| Type | Meaning |
|---|---|
| VAL | Behavioural / values: past behaviour against a company's published values |
| EXP | Experience deep-dive: whether your stated work survives scrutiny |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack; no research) |
| CASE | Live problem from the role, solved aloud |

Question IDs are by persona letter: A to G. "Answer slot" means an instruction for the interview, not a question to me.

## Persona table

| Persona | How it shows up | Weight | Why | Counter-strategy |
|---|---|---|---|---|
| A. Case / Strategist | Live planning problems on the calendar, drops and QA | 5 | A hiring manager buys capability; this JD is almost all planning and coordination | Clarify, then structure, then metrics and risks; think aloud |
| B. Skeptic | "Where is the two-title experience? Have you led anyone?" | 5 | Your stated gaps sit on JD lines, and a hiring manager derisks gaps | Rehearse the one objection until it is boring; concede by name |
| C. Data-Driven Prober | Asks how the retention numbers were counted, and what you owned | 4 | Retention and KPIs are JD requirements and the likeliest place to be probed | Know the definitions you can defend; name the weakest assumption first |
| D. Pressure | Time-boxed "why you, from a puzzle studio" | 3 | Mid weight: the transfer from puzzle to live service is the obvious pressure point | Pause, restate, hold through two follow-ups, concede specifically |
| E. Values / Behavioural | Generic "tell me about a time" | 2 | No company values in hand, so generic | Selection scaffolds with honest branches |
| F. Conversational | "Walk me through the journey" | 2 | Casual openers are still scored | A 90-second arc built from your own sentences |
| G. Peer Evaluator | Seams with design, art, engineering, community | 2 | Four-team coordination is the job; reweights up if Tobias is a peer | Propose seam principles, not invented history |

Totals: 23 questions (A 5, B 5, C 4, D 3, E 2, F 2, G 2).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Your material gives four years and a puzzle studio, not that the title was live-service. Answer slot: if the title ran ongoing updates you planned and tracked, say which; if it was not live-service, say so plainly and say what you ran there. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | high | [grounded] | presentation | Words: "I ran the weekly content-drop calendar for our main title for the last two years." |
| F3 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | Words: "I presented the monthly retention numbers to the studio head." Answer slot: how those numbers were counted; if you did not set the definition, say so. |
| F4 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | Words: "I wrote the release checklist our QA team still uses." A checklist shows written output, not clarity by itself. The interview is spoken, so no bank tests writing directly. |
| F5 | "plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title" (your message) | low | [grounded] | transferability | Your material says one main title. "Main" does not say whether there were others, and nothing shows a second title's calendar. Words: "I ran the weekly content-drop calendar for our main title." Answer slot: planning across more than one title, if you did, and how you would plan two if not. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Answer slot: name the teams you worked with on a drop and what you did with each, in your own words; if one was not part of it, say so plainly. |
| F7 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | low | [grounded] | transferability | Presenting numbers is adjacent to owning a review, not the same. Words: "I presented the monthly retention numbers to the studio head." Answer slot: did you review a drop's results before presenting; if not, say so and say how you would run the review. |
| F8 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | high | [grounded] | presentation | Words: "I wrote the release checklist our QA team still uses." Your material carries authorship and QA's use. It does not carry managing QA's sign-off. |
| F9 | Not in the JD: a likely probe from the coordination line | "Never led a team" (your message) | none | [grounded] | capability | Words: "I haven't led a team." Plain acknowledgment. |
| F10 | Not in the JD: a likely probe for a mobile role | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Words: "I haven't worked on a game with in-app purchases." Plain acknowledgment. |

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. None of the guidance below asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events, or planned across two titles | Inflated form of F2 and F5 | F2's quote at its own scope. Your material says one main title's weekly content-drop calendar. |
| Owned the post-event review and its KPIs | Inflated form of F7 | F7's quote. Your material shows presenting numbers, not owning the review. |
| Managed QA's release process | Inflated form of F8 | F8's quote: you wrote the checklist, and QA uses it. |
| Defined the retention metric | Inflated form of F3 | F3's quote. The definition is an answer slot only. |
| Led a team | Your stated negative, F9 | "I haven't led a team." |
| Has worked with in-app purchases | Your stated negative, F10 | "I haven't worked on a game with in-app purchases." |

## Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you would plan the live-events calendar for two titles. What do you need to know first?" | CASE, JD | [generic]; if you draw on the weekly calendar: "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Clarify first: update cadence per title, team load per drop, what each KPI measures, what QA must sign off. Then objective, calendar shape with buffers for slips, coordination points with design, art, engineering and community, then metrics and risks. Use your weekly calendar as a method, not as two-title experience. | The JD's first responsibility. Tests planning before experience. F5 is the gap it exposes. |
| A2 | "A content drop goes live and retention falls three days later. Diagnose it with me." | CASE, JD | [generic] | Structure: what changed and when. Check the assumption that the drop caused the dip: cohort mix, timing, a concurrent release. Segment by cohort. Say what you would check first and what would change your mind. Then the action. No history needed. | Retention is a JD requirement (F3). Diagnosis is what a live-ops manager tests. |
| A3 | "Plan one quarter of live events for a title. What goes on the calendar, and what stays off?" | CASE, JD | [generic] | Set a rule for what earns a slot: a player-facing reason, a QA window, an engineering ready date. Make the trade-off explicit. Hold a buffer. Name one thing you would drop first. | JD line: "plan and run the live-events calendar." |
| A4 | "An update is ready, but the QA checklist does not cover what changed. What do you do?" | CASE, JD | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Story-mapped on F8: you wrote the checklist and QA still uses it. Answer slot: if a release ever exposed a gap in it, say what changed; if none did, say so plainly and walk through how you would decide what to add before sign-off. | F8 is the requirement "manage the release checklist with QA"; this is its likeliest live form. |
| A5 | "Community wants a fix in next week's drop. Engineering says it will slip the calendar. How do you decide?" | CASE, JD | [generic] | Name the decision owner. Put each option's cost in player terms and calendar terms. Test whether the fix can ship in a smaller form. Agree the trade-off in one message to engineering and community. Say what you would tell players. | The JD's four-team coordination line, with community named. |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role plans the calendar for two titles. How have you planned across more than one?" | JD, CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | **Highest-ROI prep in this pack.** The hold is only what the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you planned across more than one title, or part of one, say which and what you did; if you did not, say so plainly, then say how you would plan two, starting from the weekly cadence. Hold through two follow-ups by returning to the main title. Concede the scope gap by name. Never claim a second title. | F5 is the biggest scope gap in the first responsibility, and this objection is near certain. "Our main title" does not say whether other titles existed, so the pack does not assume it. |
| B2 | "You would coordinate design, art, engineering and community on every update. Have you led a team?" | JD, Skeptic | [grounded] "Never led a team" (your message) | Plain acknowledgment: "I haven't led a team." Then answer slot: name the teams you worked with on a drop and what you did to move them, in your own words. If you did not coordinate one of those functions, say so. Do not claim coordination you did not do. | F9 is your stated gap. Four-team coordination invites the leadership probe. |
| B3 | "How would in-app purchases change what goes on a live-events calendar?" | JD, CASE | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say what you would need to learn first: which purchase events, offers or sales would affect a drop, and who you would ask. Claim no knowledge of how they work. | F10 is your stated gap. The question is generic, so it carries no premise about your past. |
| B4 | "Take me through how you would run a post-event review." | JD, CASE | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: if you looked at a drop's results before presenting, say what you looked at and what you left out. If you did not, say so plainly, then walk through the review you would run: the KPI set agreed before the drop, the comparison window, and what counts as a miss. | F7 is the transferability gap. Presenting numbers is adjacent to owning the review. |
| B5 | "Why this role, and why now?" | Skeptic stem | [generic] | Answer in your own words. Nothing in your material gives a reason yet, so the answer is yours to supply: what about live operations you want to do that the work you do now does not give you, if that is true. | Motivation consistency is the Skeptic's test. The pack cannot supply the reason. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the monthly retention numbers you presented." | EXP, JD | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Defend-the-number slot. Answer in your own words: the definition, the cohort or window, and the assumption you would defend least. Answer slot: if you did not set the definition, say so plainly. | F3. Retention is a JD requirement. |
| C2 | "Which of those retention numbers did you produce yourself, and which came from someone else?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: say which part was yours. If the numbers came from another team's data, say so. | Attribution honesty, tested on F3. |
| C3 | "After a content drop, which KPIs did you track, and what did you do when one moved?" | JD, EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Answer slot: name the KPIs you tracked after a drop, if any, and what you did when one moved. If you tracked none after a drop, say so, and name the KPI you would set first. | F7. The JD says the role owns post-event KPIs. The question's premise is an answer slot with a false-premise branch. |
| C4 | "A retention metric dips, and you have two possible causes. Which assumption would you check first?" | CASE, JD | [generic] | Name the assumption most likely wrong: cohort mix, timing, or the counting window. Say what check would separate the two causes. No history claimed. | The Prober's test, asked as a live problem. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone from a puzzle-game studio for a live-service role?" | JD, Pressure | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Pause. Restate the question in your head. Hold the calendar: the claim is only what the quote says. Hold through two follow-ups. Concede the specific gaps by name: two titles, leading a team, in-app purchases. Never fold on the calendar. | F1 is the transfer point, and a live-service manager presses there. |
| D2 | "That calendar: how much of it was actually you?" | EXP, Pressure | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Answer slot: name the parts you set and the parts set for you, in your own words. If you set none of the calendar, say so plainly and say what you did run. Hold to the quote: do not reach for "owned" or "built". | Attribution pressure on F2. |
| D3 | "You haven't led a team. Why should we trust you to coordinate four functions on an update?" | JD, Pressure | [grounded] "Never led a team" (your message); "Wrote the release checklist our QA team still uses" (your message) | Plain acknowledgment: "I haven't led a team." Hold the one thing your material carries: "I wrote the release checklist our QA team still uses." Concede the leadership gap by name. Do not invent a coordination example you cannot name. | F9 pressed directly. The hold is the quote, not a claim about coordinating. |

### E. Values / Behavioural (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to tell a senior person something they did not want to hear." | VAL | [generic]; nearest sentence: "Presented the monthly retention numbers to the studio head" (your message) | Open-prompt scaffold: pick a time with a named stake, a moment you did not soften it, and how it ended. If none comes to mind, say so plainly, then give the nearest thing your material carries: what you showed the studio head, and what you chose to say about it, only as far as that happened. | No company values are in hand, so the probe is generic. |
| E2 | "When have you put a player ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a time a number pointed one way and the player experience the other. Name the decision, its cost, and what you chose. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | A live-ops decision theme, generic. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | Conversational, JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years" (your message); "Wrote the release checklist our QA team still uses" (your message); "Presented the monthly retention numbers to the studio head" (your message) | A 90-second arc in that order, each step in your own words, no additions. End by naming the two gaps in one clause: "I haven't led a team, and I haven't worked on a game with in-app purchases." | Rapport openers are scored. The arc uses only your sentences. |
| F2 | "What is a live-ops change in a mobile game you have played that you would copy, and why?" | Conversational, JD | [generic] | Pick one change you have actually seen in a game you played. Say what it did to how you played, and why you would copy it. Name nothing you did not play. | A casual question on a live-ops topic. Still scored. |

### G. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Design, art, engineering and community sit side by side. Where's the seam, and what happens when you disagree?" | Peer, JD | [generic] | Propose seam principles, not a known seam: who decides scope, who decides timing, how a disagreement is escalated and how fast. Do not name a dispute you did not have. | F6 is the coordination requirement. |
| G2 | "How do you handle credit when a drop spans teams?" | Peer | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Say who did what, in your own words. If the checklist's use by QA was shared work, name the share as you saw it. Claim none of QA's work. | Peer credit probe on F8. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 3+ years producing live-service games or apps | D1, B1 (F1 answer slot) |
| Experience running a content calendar | F1, D2, A1 |
| Comfortable with player-retention metrics | C1, C2, C4, A2 |
| Clear written communication | none, and why: the interview is spoken, so no bank tests writing. Your checklist appears in A4 and G2 |
| Plan and run the live-events calendar for two titles | A1, A3, B1 |
| Coordinate design, art, engineering and community on each update | A5, B2, D3, G1 |
| Own the post-event review and the KPIs it reports | B4, C3 |
| Manage the release checklist with QA | A4, G2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Of the two titles, which is further from its next big update, and what calendar constraint sits on it?" | Shows you read the two-title scope and want the work, not the perks. |
| 2 | "What does a post-event review look like here: who writes it, who reads it, and what happens when a KPI misses?" | Tests how KPI ownership works before you say you would own it. |
| 3 | "When an update slips, how does QA sign-off change the release checklist's steps?" | Shows you already treat the checklist and sign-off as one process. |
| 4 | "When community asks for a change, where is it decided against the calendar, and who has the final say?" | Names the coordination line directly. |
| 5 | "What would someone starting in this role need to have done by the end of their first quarter?" | Asks for the bar, which a hiring manager answers gladly. |

No reverse question is tied to Tobias's own path, because no profile was available. That needs the research or a public footprint (see the upgrade menu).

## Sources

Provided documents: the job description and background note in your message. Nothing else was supplied.

Search attempts (all refused by the host, so each returned nothing):
- "Saltmarsh Games mobile studio": refused
- "Tobias Wrenfield Saltmarsh Games Live Operations": refused
- "Saltmarsh Games company values": refused

Research tier: L1, searches 0 of 6 (3 attempted, all refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, section 10, not built. E1 and E2 stay generic |
| 2. Saltmarsh Games interview process, live ops | unavailable | Loop structure. Persona weights stayed on the relationship prior |
| 3. Saltmarsh Games strategy / recent news | unavailable | CO bank, which this pack does not contain |
| 4. Tobias Wrenfield Saltmarsh Games | unavailable | Interviewer read and a reverse question tied to his path |
| 5. Representative live-ops producer JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions |

Sections dropped because their input is absent: prep triage (no prep time stated), grounding brief (no L2), reading the interviewer (no interviewer information beyond the name), values cheat sheet (no values in hand, no values-style round detected), graded deliverables (none declared), delivery coaching (no assessment).

## Upgrade menu

- Search access → Saltmarsh's published values (a values cheat sheet, and E1 and E2 become mapped), its interview loop (persona weights), recent strategy (a CO bank), and Tobias's public footprint (an interviewer read and a reverse question about his path)
- Whether the 60 minutes is one conversation with Tobias or a panel → persona weights per member
- Whether the puzzle title ran ongoing updates you planned and tracked → resolves the F1 answer slot, and sharpens D1
- A recruiter's prep note → coverage of any deliverable they name
- A `tuesday-dossier.md` from an earlier session → would add checked evidence and a prohibited-claims list from someone other than this pack
