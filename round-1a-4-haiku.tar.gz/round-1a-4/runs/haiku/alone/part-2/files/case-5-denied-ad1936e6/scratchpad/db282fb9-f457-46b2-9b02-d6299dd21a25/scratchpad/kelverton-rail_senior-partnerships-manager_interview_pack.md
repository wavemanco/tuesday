# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

Round: second round, panel, 60 minutes. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: a spoken point of view on operator partnerships over 18 months, no slides. Remaining 45 minutes: Q&A, with Ross pushing on commercials.

Built with no job description, no research (see Sources), and your own background plus the recruiter's email as the only sources.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (the role), CO (company and strategy), CASE (a live problem).
- Guidance is scaffolding, not a script. Say it in your own words.
- Answer slots are instructions for the interview, not questions for you. Each one has an honest branch. Use it.

## Prep triage (about 4 hours)

1. **0:00 to 1:30. The POV (section 5).** Build it, then say it aloud twice, timed to 15 minutes. It is the only graded deliverable the recruiter named, and it opens the round.
2. **1:30 to 2:45. Ross's commercials (bank B).** Rehearse B1 and B2 until the holds are boring. B2 is the quota gap; it will come up.
3. **2:45 to 3:30. The rail objection (bank C).** C1 is the highest-return prep in this pack. Rehearse the hold, the concession and the plan, in that order.
4. **3:30 to 4:00. Deepa's model and your reverse questions (banks A and D, section 11).** Then one drill (see the offers at the end).

Everything else is insurance.

## 1. Fit snapshot

Requirements come from the recruiter's email, quoted, or are marked [generic] where no source states them. Evidence is quoted from your own words. Nothing here is a claim you have not made.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "what it means for the operators themselves" — recruiter email | "so I know the operator world from the other side" — your message; "bus and light rail network planning" — your message | medium | [grounded] | transferability | Your material says you know the operator world from the consultant's side, not from an operator's seat. Words: "I know the operator world from the other side, from the consultant's seat on bus and light rail network planning." Answer slot: if you have sat in an operator's planning or buying decision, say what you saw; if not, say so and say how you would test the operator's view before deciding anything. |
| F2 | "our operator partnerships" — recruiter email | "Never sold into rail specifically" — your message | high | [grounded] | capability | A gap you stated, so the pack may give your words back. Words: "I haven't sold into rail specifically." Then how you would close it, said as a plan for the first 90 days, never as a past. |
| F3 | "Ross will push on commercials" — recruiter email | "never carried a direct quota, only influenced revenue" — your message; "roughly £4M of influenced revenue" — your message | high | [grounded] | capability | A stated absence: no direct quota. Words: "I haven't carried a direct quota. I have influenced roughly £4M of revenue." The figure is influenced, and the pack will not describe it as sourced or closed. Expect a defend-the-number probe (B1). |
| F4 | [generic] a partner network that grows | "took it from 6 partners to 40" — your message | medium | [grounded] | none | No gap against the requirement. Words: "I took it from 6 partners to 40." The count raises a probe: how many were active (B3). Confidence is medium because the figure has no inspectable record behind it in this material. |
| F5 | [generic] how operators buy scheduling software | "so I know the operator world from the other side" — your message | low | [inferred] | discovery | Your material does not show whether you have seen an operator choose a supplier. Answer slot: if you have been in a room where an operator chose a system, say what you saw; if not, say what you would ask operators first. |
| F6 | [generic] where the role is based and how often it is office-based | none given | none | [generic] | hard_gate | Your material does not establish this. It is asked in the message that delivers this pack, not coached here. |

## 2. Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. No answer, hold, bridge or drill feedback may assert, soften or imply them.

| Not coached | Basis | Honest form |
|---|---|---|
| Sold into rail, or rail sales experience | Negative you stated, F2 | "I haven't sold into rail specifically." No slot about a rail deal. |
| Carried a quota or owned bookings | Negative you stated, F3 | "I haven't carried a direct quota." Then the influenced-revenue quote at its own scope. |
| Owned the operator partnerships, or the commercial P&L | Inflated form of "took it from 6 partners to 40" and "running the ISV channel", which is a payments channel, not an operator book | The quote at its own scope. The limit is this pack's observation: your material says the ISV channel, not operators. |
| Closed or generated the £4M | Inflated form of "roughly £4M of influenced revenue" | "Influenced revenue" as your words. Not sourced, not closed. |
| Built the partner model or designed the 40-partner programme | Inflated form of "took it from 6 partners to 40" | "Took it from 6 partners to 40." Nothing about who designed the model. |
| Knows how operators buy schedulers | Inflated form of "I know the operator world from the other side" | The consultant's view, at its own scope. |

## 3. Persona weights

| Interviewer | Persona blend | Why | Counter-strategy |
|---|---|---|---|
| Ross (Commercial Director) | Data-Driven Prober + Pressure | The recruiter says he will push on commercials, and your commercial record is influenced revenue, which invites a denominator question and a challenge to the quota gap | Know how the £4M was counted, or say plainly that you would need to check. Hold the position through two follow-ups, then concede the quota gap specifically. |
| Deepa (future manager) | Case/Strategist + Skeptic | A hiring-manager round: she is buying capability and checking the gaps (rail, direct sales, operator buyers). The POV is the case. | Structure before answering. Name the rail gap before she does. Make your plan concrete for the first 90 days. |
| Both | Conversational opener | Panels open with a biography question, which is scored | Pre-scripted 90-second arc (D1). |

No values-style round was detected, so no values bank or cheat sheet is included. No interviewer public footprint was available, so no interviewer read is included.

Persona depth: Ross's bank B (top weight) has 6 questions; Deepa's bank A (Case) has 5; her bank C (Skeptic) has 4; the opener bank D has 4.

## 4. Question banks

Provenance comes before the guidance. Where guidance says what you did, the quote it rests on sits in the Provenance cell.

### Bank A: Case/Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you'd work out which operators to partner with over the next 18 months. What do you need to know first?" | CASE | [generic] | Clarify, then objective, then segments, approach, metrics, risks. Ask what the operators' planning cycle is before you name any operator. Say the first two things you would check, out loud, before the plan. | A live problem from the POV's own subject. Presupposes nothing about your past. |
| A2 | "You talked about operators. What does a planner at an operator need from us first, and how would you find out whether they agree?" | CASE | [generic] | Name the planner's problem before the product. Say how you would test it with three or four operator conversations. Do not name an operator need you have not heard from one. | Follows the POV. Tests the "what it means for the operators themselves" close. |
| A3 | "Pick one of those operators. Tell me the first 90 days." | JD | [generic] | A sequence with a named outcome at each step. Say what would make you stop and reconsider. | Forces the POV into a plan. Plans are not past claims. |
| A4 | "Walk me through the ISV channel going from 6 partners to 40." | EXP | [grounded] "took it from 6 partners to 40" — your message | Story beats the quote states: the start at 6, the end at 40, the four years. Tell it in your words. Answer slot: if you can say how the partners were recruited, say it; if the decision was not yours, say so and describe what you ran. | The clearest proof of channel-building. It is also the figure B3 probes. |
| A5 | "A partner you signed stops sending you opportunities in month four. Diagnose it." | CASE | [generic] | Segment the partners first: which stopped, and which were ever active. Say what data you would check before you guess. | A live problem from the ISV work, asked as a case, so no claim about your past is needed. |

### Bank B: Pressure and Prober (Ross, commercials)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Roughly £4M of influenced revenue. How was that counted?" | EXP | [grounded] "roughly £4M of influenced revenue" — your message | The figure in your words, as influenced. Name the weakest assumption you know of before he does. Answer slot: if you know the attribution rule, say it. If you do not, say you would need to check it, and say what you would check. Do not describe a method you have not stated. | F3 is the figure's own limit. The question is a defend-the-number slot the figure raises, so the method stays the candidate's to give. |
| B2 | "You've never carried a direct quota. Why should we believe you can?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" — your message | Hold: restate what you did in the partner motion, in the quote's terms, and what it moved. Second follow-up: return to the influenced number and what it does and does not prove. Concede: name the direct-quota gap specifically, then give a plan for closing it, as a plan. Never fold on the core claim to restore harmony. | This is the highest-ROI objection on the commercial side. The hold is only what you stated. |
| B3 | "Of the 40 partners, how many were actually producing revenue?" | EXP | [grounded] "took it from 6 partners to 40" — your message | Give the active count if you know it. Answer slot: if you do not know it, say so. Name the assumption behind the 40 that you would defend least. | Partner counts are where probers go. F4's figure raises this slot. |
| B4 | "Year one. What forecast would you put in front of me for operator partnerships, and what assumption is it sitting on?" | CASE | [generic] | Say you would forecast from operator-level data you do not yet have. Name the one assumption you would test first. Do not produce a number. | A commercial question with no past claim. An honest "I need the data first" scores. |
| B5 | "What would you trade to win an operator, and what would you never trade?" | JD | [generic] | Two lists, each with a reason. Name one item you would hold firm on. | Commercial judgment under a trade-off, which Ross will test. |
| B6 | "Where do you think the operator partnership motion is weakest today?" | CO | [generic] | Name the weakness you can see from the outside and say how you would check it. Do not diagnose a weakness you have not seen the data for. If the market report is pasted, draw on it (see the upgrade menu). | Commercial altitude. Without the report, the answer must stay honest about its source. |

### Bank C: Skeptic (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't sold into rail. What do you do about that on day one?" | JD | [grounded] "Never sold into rail specifically" — your message | Plain acknowledgment: "I haven't sold into rail specifically." Hold: say what transfers from the operator-side work (F1's quote) and stop there. Second follow-up: say what you would do in the first 30 days, as a plan. Concede: name what you do not yet know about rail procurement. Never claim rail experience. | This is the single most predictable objection to this candidate and the highest-return prep in the pack. The concession is what makes the hold credible. |
| C2 | "You know operators from the consultant's seat. Why would an operator talk to a vendor's partnerships lead?" | JD | [grounded] "so I know the operator world from the other side" — your message | Say the consultant's seat is a real view of how operators plan, and that it is not a view of how they buy. Answer slot: if you have seen a supplier decision from either side, say what you saw; if not, say what you would ask the operator first. | This is F1's limit. It turns the consulting background from a claim into a question you can answer. |
| C3 | "Payments and rail. What transfers, and what doesn't?" | JD | [grounded] "Last 4 at a payments company running the ISV channel" — your message | Transfers: partner recruitment and enablement, in the channel's own terms. Does not transfer: anything you have not run. Name one thing you think will not transfer. | Transferability. The honest answer is a list with a limit, not a claim of equivalence. |
| C4 | "Why leave a payments company where the channel works?" | EXP | [grounded] "Last 4 at a payments company running the ISV channel" — your message | Give your reason in your own words. Answer slot: the material does not give a reason for leaving, so say it plainly, and do not invent one. | A motivation probe. The pack does not supply your reason. |

### Bank D: Conversational and the management question (both)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | JD | [grounded] "9 years in partnerships" — your message; "5 years in transport consulting" — your message | A 90-second arc: transport consulting first, from the consultant's seat; then the nine years in partnerships; then the ISV channel from 6 to 40; then why operators now. Use the quotes' own words. | The opener is scored. A pre-scripted arc avoids a rambling answer. |
| D2 | "How would you split the operator partnership team? Who does what with us?" | JD | [generic] | A shape: who owns operator relationships, who owns the commercial terms, who owns the operator's outcome. Say what you would decide in the first month. | Deepa's partnership-model question. No past claim. |
| D3 | "How would you want me to run this team in its first month?" | JD | [generic] | Say what you would want from her, as a manager, and what you would report back. | A management question. Keep it about the team, not your history. |
| D4 | "A team member thinks operators are a backlog. How do you handle that?" | JD | [generic] | Say what you would ask first. Say how you would decide whether the view is wrong. Say what you would do if it is right. | A management judgment with no past claim. |

## 5. The 15-minute point of view (graded deliverable)

The recruiter asked for "a short POV on where you'd take our operator partnerships over the next 18 months" and asked you to "land on what it means for the operators themselves". No slides.

**The facts you can build on:**

- F1: "so I know the operator world from the other side". This is the one sentence about operators, and it is from the consultant's seat. Say so.
- F4: "took it from 6 partners to 40". Use it only as evidence that you have built a channel. Do not describe it as an operator channel.
- You have not sold into rail (F2). Say so once, early, and move on.

**Three theses, each with a concession you must say aloud:**

1. **Start from the operator's planning problem, not the product.** Concession: the planners who need the product are not in the partnership meetings. You would have to reach them directly, and you have not yet tested how.
2. **A few operator-facing partnerships, not a broad channel.** The 6-to-40 logic built your last channel. Concession: operators buy differently from ISVs, and the 40-partner playbook may not transfer. Say what you would test first.
3. **Make an operator outcome the thing you sell.** Concession: an outcome needs operator data that you do not have yet. Say how you would get it.

**The anti-pick.** The market report's shortlist is the consensus answer a prepared candidate would also give. This pack has not seen the report, so it cannot say what the consensus is. Once you paste the report's operator findings (upgrade menu), this section gets its anti-pick: the one consensus item to acknowledge, and the one place you depart from it, with a reason.

**Timing (15 minutes):**

- 3 minutes: the operator's problem, in the planner's words.
- 6 minutes: the three theses, each with its concession.
- 4 minutes: the first 90 days, the next six months, and the 18-month shape. Plans only; no past claim is needed.
- 2 minutes: what it means for the operators themselves. Name one operator outcome you would measure, and say who would feel it first. **Answer slot:** if you can name the outcome from the operators' side, say it; if not, say which operator you would ask first.

## 6. Reverse questions

Each one has a "why it lands". There is no interviewer profile, so none is tied to a path.

| # | Question | To | Why it lands |
|---|---|---|---|
| R1 | "What has the operator team got wrong in the last year that the next hire should not repeat?" | Deepa | Shows you are thinking about the team's history, not pitching yourself. |
| R2 | "How do operator partnerships and product plan the roadmap together today?" | Deepa | Finds the seam between the two teams. You will need this in the first 90 days. |
| R3 | "Which of the operator numbers you see do you trust least?" | Ross | Opens the commercial argument on the number he cares about, and tells you what he would test. |
| R4 | "What would a good first-year operator deal look like to you, commercially?" | Ross | Tests your commercial frame against his, before you have to defend one. |
| R5 | "What would make the 18-month plan fail, in your view?" | Deepa | Asks for her risk list. It signals you plan for failure, not only success. |

## 7. Sources

Research tier: L1 — searches 4 of 6, fetches 0 of 2; all 4 searches refused by permission

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | The search was refused, so no values were found. No values bank or cheat sheet was built; the company's own values are not in hand. |
| 2. Kelverton Rail interview process, partnerships | unavailable | The search was refused, so the loop structure is not established. Persona weights rest on the recruiter's email and the round type. |
| 3. Kelverton Rail strategy and recent news | unavailable | No search sent: search permission was not granted. The market report is not in hand either, so this pack has no current strategy to draw on. |
| 4. Deepa and Ross, Kelverton Rail | unavailable | Two searches refused. No public footprint for either is established, so there is no interviewer read and the reverse questions are not tied to their paths. |
| 5. Representative partnerships job description | unavailable | No search sent: search permission was not granted. No job description was supplied, so the fit snapshot's requirements come from the recruiter's email and are marked [generic] where no source states them. |

I did not retry the refused searches. Everything in this pack that is not quoted from your message or the recruiter's email is marked [generic].

Provided documents: your background as stated in your message; the recruiter's email, as quoted above. The internal market report was not pasted, so nothing in this pack draws on it.

## 8. Upgrade menu

- The job description text → turns the [generic] requirement rows into [grounded] ones, and adds JD-tagged questions that test each line of the role.
- The market report's operator findings, pasted → sets the POV's anti-pick and lets B6 draw on the current picture.
- Permission to run the searches, or the company's values page pasted → adds the values cheat sheet and the company's current language.
- Ross's and Deepa's public professional profiles, if you name them to search, or paste them → adds an interviewer read and reverse questions tied to their paths.
- Where the role is based and how often it is office-based → closes F6 (the gate row).
