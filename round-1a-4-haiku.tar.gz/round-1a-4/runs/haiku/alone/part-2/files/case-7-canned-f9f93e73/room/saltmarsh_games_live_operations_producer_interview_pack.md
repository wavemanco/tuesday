# Saltmarsh Games: Live Operations Producer interview prep pack

**For:** Femi · **Round:** hiring manager, 60 minutes, the Outage Hour · **Interviewer:** Tobias Wrenfield, Head of Live Operations (relationship: hiring manager, per the careers page)

Built on: the JD you supplied, your background as you described it in your message, Saltmarsh's values and interviewing pages, one news item, and one public talk listing. Research tier: L1 (targeted).

## How to use this pack

- **Personas** are how a question arrives. **Types** are what is being scored: **VAL** values, **EXP** your experience, **JD** the listed job, **CO** company knowledge, **CASE** a live problem.
- Guidance is scaffolding for a spoken answer, not a script. Rehearse only what you did, in your own words.
- Every "[grounded]" quote is either a sentence from your message or a Saltmarsh page. "[generic]" means a pattern for this kind of problem, not a fact about Saltmarsh.

## Interview format

Saltmarsh's interviewing page describes the loop as a recruiter call, then "the Outage Hour: a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home." So you are preparing for one session with two halves: a live problem, then values.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | Covered in role terms. Limited inspectable proof, so expect a probe on what the calendar held. Say it in your words: "I ran the weekly content-drop calendar for our main title for two years." |
| F2 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | Your material says you wrote the checklist and QA still uses it. It does not say you managed the release process. Bridge only the quote: "I wrote the release checklist our QA team still uses." Answer slot: the JD says "manage," so expect a probe on whether you ran any release sign-off. If you did, say which step and how; if you did not, say so plainly. |
| F3 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Four years and the role are in your material. Whether the game was live-service is not. Bridge: "I was an associate producer for four years at a puzzle-game studio." Answer slot: if the game ran on weekly content drops, say that in those terms; if you cannot describe its live model, say what it was. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | low | [grounded] | transferability | Presenting numbers is adjacent to owning the review and its KPIs. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran a review after any event, or defined what a KPI measured, say so; if you did not, say so plainly and say what you would bring. |
| F5 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Your material shows you presented the numbers, not that you analysed them. Bridge only the quote. No figure was given, so there is no defend-the-number slot. Answer slot: if you know how the retention figure was defined, say so; if not, say that and say how you would check. |
| F6 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | low | [grounded] | discovery | Your material shows one title. It does not say whether you have ever planned across two. Bridge: say the one title. Answer slot: if you have planned across two titles, or shared a calendar between them, say how; if you have not, say so and say how you would set up the first month. |
| F7 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses" (your message); "Never led a team" (your message) | low | [grounded] | transferability | The only cross-team work in your material is with QA. Bridge: the QA checklist, in your own words. Plain acknowledgment, if asked about leading: "I've never led a team." Answer slot: which teams beyond QA you coordinated on a release, and how; if none, say so and describe how you would run an update across the four. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [grounded] | discovery | A written artifact others act on is evidence, but your material does not show the writing itself. Answer slot: name one document you wrote that someone else acted on, and what happened. |
| F9 | Monetisation, from Saltmarsh's season-pass news (search result, not fetched) | "I've never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A gap you stated, and the news item makes it relevant. Plain acknowledgment: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan. |

Gate check: the JD states no location, schedule, legal or credential requirement. No row is a hard gate.

Seven rules the table enforces: quotes are your sentences, not paraphrases; gap language never adds practice; "wrote" is not "managed"; "presented" is not "owned"; "for our main title" is not "two titles"; no figure is invented; no monetisation experience is claimed.

## Prohibited claims

These will not be coached in any answer, hold, or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the calendar for two titles | Inflated form of F6. The material says "our main title." | "I ran the weekly content-drop calendar for our main title for two years." |
| Owned the post-event review or the KPIs | Inflated form of F4. The material says "presented." | "I presented the monthly retention numbers to the studio head." |
| Analysed or defined retention | Inflated form of F5. The material says "presented." | "I presented the monthly retention numbers." Plus F5's answer slot. |
| Led or managed a team | Stated negative, your message. | "I've never led a team." |
| Monetisation or in-app purchase experience | Stated negative, your message. | "I've never worked on a game with in-app purchases." |
| A live-service game, labelled as one | Not stated. Your material gives a puzzle game with a weekly content-drop calendar. | "A puzzle-game studio, with a weekly content-drop calendar." |

## Values cheat sheet

The Outage Hour's values conversation makes this a values-style round, and the three values below are from Saltmarsh's published page.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | No quoted sentence carries a story here. Selection scaffold: pick a time a planned date conflicted with what players needed. If none comes to mind, say so plainly, then give the nearest thing your material carries: the content-drop calendar, and what you did when a drop had to move. Say only what you did. |
| Ship the Patch Not the Promise | We announce what is built, not what is hoped. | Your material does not show a release where an announcement changed. Selection scaffold: a release where what you announced had to match what shipped. If none, say so, then describe the checklist: "Wrote the release checklist our QA team still uses." |
| Leave the Build Greener | Every release leaves the codebase and checklist better than it found them. | "Wrote the release checklist our QA team still uses." The quote carries the story: the checklist is still in use. Say what you changed on it, if anything; if not, say that it is still in use. |

## Reading the interviewer

Public footprint only. Your search found a GDC 2026 talk titled "Patch Notes Are a Promise," by Tobias Wrenfield, Head of Live Operations at Saltmarsh, described in the listing as previously a QA lead at a console studio. Its argument, from the listing: a live team is judged by how often its patch notes describe what actually shipped.

Practical implications:

1. The QA line matters to them. F2's quote, "Wrote the release checklist our QA team still uses," will be heard by someone who has been a QA lead.
2. Expect questions on whether announced claims match builds. That is the value Ship the Patch Not the Promise, in the talk's own terms.
3. You can mention the talk only if you have read it. Do not claim familiarity beyond that.

Mirror opportunity: release checklists and QA sit on both sides of the table. Quote your F2 sentence, not a summary of it.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The Outage Hour tabletop and a two-titles calendar problem | Highest. The careers page names a live-incident tabletop, and a hiring manager buys the capability they need. | Clarify, then structure: scope, decision, communication, review. Think aloud. |
| Skeptic | "You haven't led," "you've never run two titles," "where is the IAP experience" | High. Your gaps are visible on the page, and the hiring manager is the one deciding them. | Rehearse the single predictable objection (B2) until it is plain. Hold the plan, acknowledge the gap. |
| Values / Behavioral | The values conversation after the tabletop | Medium-high. The careers page documents it. | Map a story to each value where a quote carries one, and use a selection scaffold with an honest branch where none does. |
| Data-Driven Prober | Follow-ups on the retention numbers and what the calendar held | Medium. Your retention claim is one line, and probers follow lines. | Say the one figure's definition if you know it; say so if you do not. |
| Pressure | Time-boxed challenge on the team-leadership gap | Lower. Not a stated style, but a hiring manager may test composure on the sharpest gap. | Pause, restate, hold the QA fit, concede the leadership gap specifically. |
| Conversational | An opening "walk me through your journey" | Medium. Casual openers are still scored. | Keep a 90-second arc built only from your quotes. |

## Question banks

Persona weights: Case 5 (depth), Skeptic 4, Values 3, Prober 3, Pressure 2, Conversational 1. Total 19. The **highest-ROI prep** is **B2**: this objection is the most likely to be asked in some form, and the honest answer is short.

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event is running and a reward is not granting for some players. You have 45 minutes. What do you do first?" | CASE | [generic] | Clarify first: how many players, which build, which event, what the reward row says. Decide whether to pause the event or hold a patch. Say what you would tell players and in what order. Name the review afterwards. The question needs no claim about your past. | The Outage Hour is a live-incident tabletop, per the careers page. A pattern for the problem, not a fact about Saltmarsh's incidents. |
| A2 | "Two titles move to one shared events calendar from February. What do you check in the first two weeks?" | CO | [grounded] "Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027" (Saltmarsh news, search result) | Structure: dependencies across design, art, engineering, community and QA; which release checklist applies to each title; which KPIs stay per title. Make no claim about your own past. | The news sets the calendar question. Answering it at the company's altitude is the point. |
| A3 | "Day-7 retention on one title dropped three points after the last event. Diagnose it." | CASE | [generic] | Clarify the cohort, the event date and what else shipped. Name the denominator as the weakest assumption before they do. Propose two checks. | F5 is your retention line; the question is a pattern, not a claim about your past. |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never led a team. How would you coordinate design, art, engineering and community on an update?" | JD | [grounded] "Never led a team" (your message); "Wrote the release checklist our QA team still uses" (your message) | Plain acknowledgment: "I've never led a team." Then the QA checklist, in its own words. Answer slot: which teams beyond QA you coordinated on a release, and how; if none, say so and describe how you would run one update across the four. Hold the plan; claim no leadership. | F7 is the coordination requirement. The leadership question is premised on your own stated negative. |
| B2 | "You've run a calendar for one title. Plan and run two. What's your evidence?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message); "Plan and run the live-events calendar for two of our mobile titles" (JD) | **The highest-ROI prep.** Hold on the one-title fact: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you have planned across two titles or shared a calendar, say how; if not, say so, and describe the plan for the first month as a plan, not a past. Hold through two follow-ups by returning to the one title. | F6 is the most likely objection. The honest answer is short, and a rehearsed one stops the follow-ups. |
| B3 | "Our season pass runs on in-app purchases. You've never worked on one. Why should we believe you'd be useful?" | JD | [grounded] "I've never worked on a game with in-app purchases." (your message) | Plain acknowledgment, then how you would learn it, said as a plan: which monetisation numbers you would read first and who you would ask. No claim of monetisation knowledge. | F9. The question's premise matches your stated gap. |
| B4 | "You presented retention numbers. Did you own the KPI?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Presenting is the sentence you can say. Answer slot: if you set or defined the KPI, say so; if you presented a figure someone else defined, say so plainly. | F4. "Own" is the JD's word, not your sentence. |
| B5 | "Show me something you wrote that someone else acted on." | JD | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Name the checklist, what it covers, and who uses it. Answer slot: if you have a different document that others acted on, name it. | F8: the JD's "clear written communication" needs a document, not an adjective. |

### Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Selection scaffold: pick a time a planned date conflicted with what players needed. If none comes to mind, say so plainly, then give the nearest thing your material carries: the calendar, and what you did when a drop had to move. Say only what you did. | Players Before Plans. No quote carries that story, so the honest branch is written in. |
| C2 | "Tell me about a release where what you announced had to change." | VAL | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Selection scaffold: a release where what you announced had to match what shipped. If none, say so, then describe the checklist: what it checks, and whether it has caught an announcement before the build. Answer slot: do not invent a catch. | Ship the Patch Not the Promise. Your interviewer's own talk is on this value. |
| C3 | "What have you left in better shape than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Story-mapped: the checklist, which is still in use. Say what you changed on it, if you changed anything. If you did not change it, say that it is still in use and why. | Leave the Build Greener. "Still uses" is the sentence's own weight. |

### Experience (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the content-drop calendar. How was it built?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | The calendar, the weekly cadence and the two years, in those words. Answer slot: what the calendar held, and who set each date; if you set the dates, say so; if not, say whose they were. | F1 is your calendar line; the prober asks what was in it. |
| D2 | "Which retention figure did you present, and how was it defined?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | No figure is given, so no defend-the-number slot. Answer slot: if you know the definition, say it in your words; if you do not, say so and say how you would check it before the next review. Never explain a method you did not use. | F5. The prober's question is the honest answer's test. |
| D3 | "Walk me through how the release checklist is used. Who signs off against it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Describe the checklist and its users, in those words. Answer slot: if you ran a sign-off step, say which and how; if QA owned sign-off and you wrote the checklist, say that. | F2. "Signs off" is the prober's premise, so the second branch must allow that you did not run it. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why hire someone who has never led a team, over someone who has?" | JD | [grounded] "Never led a team" (your message); "Wrote the release checklist our QA team still uses" (your message) | Pause, then restate. Hold through two follow-ups on the QA fit: "I wrote the checklist QA still uses." Concede the leadership gap specifically: "I've never led a team." Do not fold on the fit. | F7. Hold-then-concede: hold what you did, concede what you have not done. |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Hold: "I wrote it." Concede specifically what you cannot claim: "I don't know how much of it survives unchanged." Answer slot: if you have revised it, say what changed; if you have not, say so. | Attribution pressure. The quote is the position, so hold it, and do not add to it. |

### Conversational (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | A 90-second arc from your quotes only: four years as an associate producer at a puzzle-game studio, the calendar, the checklist, the retention presentation. Nothing else. | F3, F1, F2, F4. Casual openers are still scored. |

### Requirement coverage

| JD requirement | Covered by | Note |
|---|---|---|
| Plan and run the live-events calendar for two of our mobile titles | B2, A2 | |
| Coordinate design, art, engineering and community teams on each update | B1, E1 | |
| Own the post-event review and the KPIs it reports | B4, D2 | |
| Manage the release checklist with QA | D3, E2, B5 | |
| 3+ years producing live-service games or apps | D1, F1 | Via F3 |
| Experience running a content calendar | D1, C1 | |
| Comfortable with player-retention metrics | D2, A3 | |
| Clear written communication | B5 | |

## Reverse questions

1. "Your GDC talk argues a live team is judged by how often its patch notes describe what actually shipped. Where does that drift most often happen in practice?" *Why it lands: it shows you read their own argument, and it opens the values conversation on their terms.*
2. "Project Larkspur puts two titles on one events calendar from February. Which decisions does the single live-ops group own, and which stay with each title?" *Why it lands: it asks about the role's actual shape under the reorganisation, and you can ask it without implying anything about the reorg's reasons.*
3. "In the Outage Hour, what does a strong tabletop look like, and where do candidates usually go wrong?" *Why it lands: it tells you what they score, and it is a question a hiring manager likes to answer.*
4. "What would the first 90 days need to deliver for you to say this hire worked?" *Why it lands: it turns the gaps into specific criteria.*
5. "Who in QA owns the release checklist day to day, and how often does it change?" *Why it lands: it names the one relationship you have already built, and it tests whether the checklist is theirs.*

## Sources

Provided documents: your message (the JD and your background). No other documents were pasted.

| Query | What came back |
|---|---|
| "Saltmarsh Games values" | saltmarshgames.com/values, fetched: three values named and defined. |
| "Saltmarsh Games interview process live operations producer" | saltmarshgames.com/careers/interviewing, fetched: the Outage Hour format. |
| "Saltmarsh Games mobile studio news" | saltmarshgames.com/news/project-larkspur, search snippet only, not fetched. Dated September 2026. |
| "Tobias Wrenfield Saltmarsh Games Head of Live Operations" | "Patch Notes Are a Promise (GDC 2026)" listing, search snippet only. Names Tobias Wrenfield as Head of Live Operations at Saltmarsh Games. |

Research tier: L1, searches 4 of 6, fetches 2 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | yes | Values cheat sheet: three named values, with their definitions. |
| 2. Saltmarsh interview process | yes | Interview format: one 60-minute Outage Hour with the hiring manager. Makes the values round documented. |
| 3. Strategy and recent news | yes | Project Larkspur: calendar question A2, reverse question 2, F9's relevance. |
| 4. Interviewer footprint | yes | Interviewer read: GDC 2026 talk and QA-lead background; reverse question 1; persona weights. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- **Your CV, or a line-by-line version of your background** → lifts F1, F3 and F4 from medium or low confidence to confirmed claims, and tells the prober what to check first.
- **One de-identified calendar or checklist sample** → lifts F1 and F2 to high confidence, since a document is inspectable proof.
- **The recruiter's note on the Outage Hour, if you have one** → confirms the format and whether any part is pre-set.
- **A deeper research pass (L2):** up to 6 more searches and 2 more fetches, several more minutes, for a strategy brief, the talk's full text, role-family loop reports, and recent org context. Want it?
- **tuesday-dossier.md** → would carry the gaps this prep exposed into later sessions.
