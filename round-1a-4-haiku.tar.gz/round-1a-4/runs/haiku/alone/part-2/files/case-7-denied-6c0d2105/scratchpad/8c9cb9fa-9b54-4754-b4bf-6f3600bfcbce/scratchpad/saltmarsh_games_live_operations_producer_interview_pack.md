# Saltmarsh Games: Live Operations Producer interview prep (Femi)

Role: Live Operations Producer, Saltmarsh Games (mobile, about 350 people)
Round: 60 minutes, Friday. Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager; not yet confirmed.
Research: none. Web search was refused in this session, so company values, loop structure and strategy are not established. Everything about the company below is `[generic]` or from your JD.

## 1. How to use, and the type key

Personas describe how a question arrives. Types describe what is being scored.

- **EXP**: work-experience deep-dive. Tests whether your claims survive scrutiny.
- **JD**: role and JD-driven. Tests the listed responsibilities and gaps.
- **CASE**: live problem. Tests structure and reasoning.
- **CO**: company and strategy. Not in this pack (no research, no strategy notes yet).
- **VAL**: values. Not in this pack (no values page, no values round detected).

Guidance is scaffolding, not a script. Say it in your own words.

## 2. Fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your message. Nothing is added to either.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | none | Say the years and the title as they are. Caveat: expect a probe on whether you were producing, and whether the game ran live drops (B2). |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | No gap. Caveat: nothing has been inspected. A dated sample of the calendar would raise this to high. |
| F3 | "comfortable with player-retention metrics" (JD) | "Presented monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Presenting numbers is adjacent to owning them. Bridge: the sentence, at its own scope. Answer slot C1: if you chose or counted the numbers, say how; if not, say so and say who did. |
| F4 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The checklist is your written evidence and it reaches the line in other terms. Bridge: say you wrote it and that QA still uses it, in those words. |
| F5 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | One title, weekly content drops. Bridge: that sentence at its own scope. Answer slot B3 covers a second title and any live events. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | The material does not show this. Answer slots A5 and D1: if you coordinated those teams on an update, say how; if not, say so and describe the principle you would use. |
| F7 | "own the post-event review and the KPIs it reports" (JD) | "Presented monthly retention numbers to the studio head." (your message) | low | [grounded] | discovery | The material is silent on post-event reviews. Answer slot A4: if you ran a post-event review, say what it changed; if you did not, say so and describe the review you would run first. |
| F8 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the line: QA still uses it. Caveat: "manage" is not stated, so do not add to it. Answer slot D2: if QA asked for changes, say which. |
| F9 | Not a JD line. Likely probe from the role: leading four teams. `[inferred]` | "Never led a team, and never worked on a game with in-app purchases." (your message) | high | [grounded] | capability | Stated absence. Words: "I haven't led a team." Then how you would coordinate without authority, as a plan, never as a past. |
| F10 | Not a JD line. Likely probe from the role family: in-app purchases on mobile titles. `[inferred]` | "Never led a team, and never worked on a game with in-app purchases." (your message) | high | [grounded] | capability | Stated absence. Words: "I haven't worked on a game with in-app purchases." Then a plan for learning how purchases change event timing and KPIs. |

No requirement here is a gate. "3+ years" is a length-of-experience requirement, so it is graded on fit and gap like the others.

## 3. Persona weights

Relationship prior: hiring manager. The weights below assume that. Confirm the round in the closing questions.

| Persona | How it shows up in this loop | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the calendar, the release and the retention dip | 5. Top weight. A hiring manager is buying live capability and will test it on their own roadmap. | Clarify, then objective, segmentation, approach, metrics, risks. Speak the structure aloud. |
| Skeptic | The team-lead gap, the in-app purchase gap, the associate title | 4. These are the three gaps the snapshot exposed. | Plain acknowledgment, then a bridge built only from quoted evidence, then a ramp plan. |
| Data-Driven Prober | Retention numbers you presented | 3. You presented numbers, so they will be checked. | Name the weakest assumption before they do. |
| Peer Evaluator | Seams between design, art, engineering, community and QA | 3. The role coordinates four teams, and their leads will ask about the seams. | Propose seam principles. Do not claim a seam you have not seen. |
| Pressure / Stress | "Why you?" and "how much of it was actually you?" | 2. Likely time-boxed in a 60-minute slot. | Pause, restate, hold through two follow-ups. |
| Conversational / Rapport | Opening biography | 2. Casual openers are scored. | A 90-second arc from your own sentences. |
| Values / Behavioral | Not weighted | 0. No values round detected: no loop source, and the generic fallback says no. If one appears, add it. | Not applicable in this pack. |

## 4. Question banks

Provenance carries every sentence the guidance rests on. Answer slots end without a question mark and ask for no reply here.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you would plan the live-events calendar for two titles for the next quarter. What do you need to know first?" | CASE | [generic] | Clarify before planning: what each title's events are for, how often, what each team needs, and what retention says now. Then one objective, two or three options, the metrics you would check, and the risks. Speak the structure aloud in about 90 seconds. | Live version of the calendar requirement (F5). No claim about your past, so no quote. |
| A2 | "Day-one retention on a live event came in 15% under plan. Diagnose it." | CASE | [generic] | Split first: which segment, platform and day. Then check what changed: content, timing, a build, an outage. Name one metric assumption before they do. Stop before proposing a fix. | Retention requirement (F3) asked live. No claim about your past. |
| A3 | "Two of your titles launch in the same week and engineering says the build will slip two days. What do you do?" | CASE | [generic] | Use the release checklist as the gate: which items are must-pass, who signs off a slip, and what the community hears and when. Name the decision owner out loud. | Release requirement (F8) as a live decision. No claim about your past. |
| A4 | "The role owns the post-event review and the KPIs it reports. How would you tell an event worked?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Name the KPIs before launch, then decide keep, change or stop. Answer slot: if you ran a post-event review, say what it changed; if you did not, say so plainly and describe the review you would run first. | F7 is a discovery gap, so the honest answer must be ready before the probe arrives. |
| A5 | "Design wants a new season and art says the pipeline cannot deliver it on time. Who decides, and how?" | JD, CASE | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Name the decision owner, the trade-off (scope, date or quality), the dependencies, and who hears what. Answer slot: if you have decided a cross-team conflict on an update, say how, in your own words; if not, say so and describe the decision path you would use. | F6 is a discovery gap, and this is the coordination requirement asked as a decision. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't led a team. How would you coordinate design, art, engineering and community on an update without managing any of them?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." Plain acknowledgment: "I haven't led a team." | **Highest-ROI prep in this pack.** Say the plain line first: "I haven't led a team." Then how you coordinate without authority: one calendar, one decision log, a named owner per update, and the checklist as the shared gate. Hold through two follow-ups by returning to the calendar and the checklist, never to a team you did not lead. Concede in specifics: name the part you have not done, managing people, and what you would do to learn it. Answer slot: if you have coordinated people who did not report to you, say how, in your own words; if you have not, say so and give your first 30 days. | F9 is the objection most likely to come up in some form. A non-defensive answer changes the interview. |
| B2 | "The JD asks for three years producing live-service games. Your title was associate producer. Were you producing?" | JD, EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | Say the years and the title exactly. Then what you did on the live game, in your words: the calendar and the drops. Answer slot: if you were the producer on a drop, say which and what you decided; if you worked to another producer's plan, say so and what you did within it. | F1 is medium. The title is the probe. |
| B3 | "This role plans two titles. Your calendar covered one. What is the gap?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say one title, weekly content drops, two years, in those words. Answer slot: if you ever planned events across a second title, or any live events beyond the weekly drop, say what; if not, say so and say how you would split the load across two titles. | F5. Transferability, so the limit is said plainly. |
| B4 | "You have not worked on in-app purchases. How would you plan a live event on a title that sells in-app?" | JD, CASE | [grounded] "Never led a team, and never worked on a game with in-app purchases." Plain acknowledgment: "I haven't worked on a game with in-app purchases." [generic] premise: mobile titles often sell in-app. | Say the plain line. Then a plan, as a plan and not a past: what you would learn about how purchases change event timing, the KPI set and what the community hears. Never describe an in-app purchase result you did not see. | F10. The premise is about the role family, not your history. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your retention numbers went to the studio head each month. Which of them did you choose, and how were they counted?" | EXP, JD | [grounded] "Presented monthly retention numbers to the studio head." | Say what you presented, in those words. Defend-the-number slot: how the figure was counted, the assumption you would defend least, and which part was yours. Answer slot: if you did not choose or count them, say so plainly and say who did. | F3 and F7. The question presumes you chose the numbers. The second branch allows that you did not. |
| C2 | "Which assumption behind your retention numbers would you defend least?" | EXP | [grounded] "Presented monthly retention numbers to the studio head." | Name the weakest assumption in your own words before they press. Answer slot: if you cannot name one for those numbers, say so, and name the one you would check first. | Weakest-assumption move for the retention figure (F3). |
| C3 | "Walk me through how the weekly content drops were measured against plan." | EXP, JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what the drop calendar tracked, in your words. Answer slot: if drops were measured against a plan, say which measure and what you did with the result; if they were not, say so and say what you would measure first. | F2 and F3. The question presumes a plan existed. The second branch allows that it did not. |

### D. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Design, art and engineering each own part of an update. Where is the seam, and what happens when they disagree?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Propose seam principles, not a seam you have not seen: who signs off each part, the checklist as the shared gate, and who breaks a tie. Answer slot: if you have mediated a disagreement between these teams, say what you did; if not, say so and describe the principle you would propose. | F6. A discovery gap, so the principle is the honest answer. |
| D2 | "The QA team still uses the release checklist you wrote. How did it get to that point?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Say what you wrote and that QA still uses it. Answer slot: if QA asked for changes, say which and what you did; if the checklist was taken up without changes, say that plainly. | Covers the written-communication requirement (F4) and the release requirement (F8). |
| D3 | "What should community hear about an update, and when?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Propose a concrete practice: community gets the update notes at checklist sign-off and has one named contact per update. This is a proposal, not a past. | F6. The question asks about the role, so it claims nothing about you. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause, restate the question, then anchor in that sentence. Hold through two follow-ups: return to the calendar and the checklist, never to a claim you did not make. | Time-boxed opener under pressure. |
| E2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say which parts you set and which were set for you, in your words. Answer slot: if you set part of the calendar, name it; if the schedule was set for you, say so plainly and say what you ran inside it. Concede one specific thing rather than folding on the whole calendar. | Attribution probe. The hold is on what you ran, not on what you set. |

### F. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented monthly retention numbers to the studio head." | A 90-second arc using only these four sentences, in your words: the years, the calendar, the checklist, the retention presentation, then why this role. Do not add to them. | Casual register, scored. |
| F2 | "What are you actually playing in mobile live ops these days?" | JD | [generic] | Name what you actually play and what you notice in its events and updates. If you do not play live-service mobile, say so and name what you do play. | Casual question on a JD topic. Scored, so it gets a prepared answer. |

Session total: 19 questions across six personas.

### Requirement coverage

| JD requirement | Questions |
|---|---|
| 3+ years producing live-service games or apps | B2, F1 |
| Experience running a content calendar | B3, C3 |
| Comfortable with player-retention metrics | C1, C2 |
| Clear written communication | D2 |
| Plan and run the live-events calendar for two titles | A1, B3 |
| Coordinate design, art, engineering and community teams | A5, D1, D3 |
| Own the post-event review and the KPIs it reports | A4, C1 |
| Manage the release checklist with QA | A3, D2 |
| Not in the JD, likely probes: leading a team, in-app purchases | B1, B4 |

## 5. Reverse questions

Each one has a reason it lands. No interviewer profile exists, so none is tied to Tobias's path.

1. "What does a strong first 90 days look like for whoever runs these two calendars?" Why it lands: it shows you plan scope from the top.
2. "How is the post-event review run today: who writes it, who reads it, and what decision does it feed?" Why it lands: it tests whether KPI ownership is clear before you accept it.
3. "Which retention metric does the live team argue about most right now?" Why it lands: it shows you read the numbers, not only the headline.
4. "Where does the release checklist with QA slip most often?" Why it lands: it opens the checklist as a shared gate and shows you have read its weak point.
5. "How do in-app purchases and live events interact on these titles today?" Why it lands: it asks about your biggest gap as a learning question, not as a defence.
6. "What would you want the person in this role to change in their first six months?" Why it lands: it gets you the real priority.

## 6. Prohibited claims

Not coached anywhere in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team, or managed people | Negative you stated (F9) | "I haven't led a team." Then the plan. |
| Owned the live-events calendar across two titles, or ran live events | Inflated form of F2 and F5 | The content-drop sentence at its own scope. Observation, in this analysis only: the material says one title's weekly drops, not live events. |
| Producer, not associate producer | Inflated form of F1 | "4 years as an associate producer at a puzzle-game studio." at its own scope. |
| Defined or owned the retention KPIs | Inflated form of F3 and F7 | "Presented monthly retention numbers to the studio head." Observation, in this analysis only: the material says presented, not defined. |
| Managed QA's release process | Inflated form of F8 | "Wrote the release checklist our QA team still uses." at its own scope. |
| Experience with in-app purchases | Negative you stated (F10) | "I haven't worked on a game with in-app purchases." Then the plan. |

## 7. Sources

- Provided: your message (the JD text and your background).
- Research attempts, all refused by permission, so each returned nothing:
  - "Saltmarsh Games values": refused
  - "Saltmarsh Games interview process live operations producer": refused
  - "Saltmarsh Games mobile studio news strategy": refused
  - "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused

Research tier: L0 (provided documents only). Searches 0 of 6 returned results, 4 refused. Fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have fed the values cheat sheet. Dropped: no values round detected, so there is no cheat sheet. |
| 2. Saltmarsh Games interview process | unavailable | Would have named the loop. Persona weights rest on the hiring-manager prior, not on a documented loop. |
| 3. Saltmarsh Games strategy and recent news | unavailable | Would have fed the CO bank. No CO questions in this pack. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have produced an interviewer read and a tailored reverse question. Dropped: the reverse questions are generic. |
| 5. Representative Live Operations Producer JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

## 8. Beyond the spec: 60-minute run-of-show

You asked for one. It is an extra, not part of the standard pack.

| Minutes | Segment | Questions |
|---|---|---|
| 0 to 5 | Introductions and your 90-second arc | F1 |
| 5 to 20 | Live problems | A1, A2, A3 (pick the one they start with) |
| 20 to 35 | Skeptic and peer | B1 first, then B2, B3, D1 |
| 35 to 45 | Data | C1, C2 |
| 45 to 50 | Pressure | E1, E2 |
| 50 to 57 | Your questions | Reverse questions 1 to 3, then the one from their answers |
| 57 to 60 | Close | Restate the one thing you want them to remember: the calendar, the checklist, and the honest gaps |

## 9. Upgrade menu

- Confirm Tobias is the hiring manager for this round, and whether any exercise or presentation is set → reweights the persona table, and adds a graded-deliverable section if one exists.
- Paste the Saltmarsh values page → a values cheat sheet, and value-mapped VAL questions. Research was refused this session.
- Paste recent news, a strategy note or product-update notes → CO questions grounded in current strategy.
- Paste Tobias's public talks, posts or profile → an interviewer read, and a reverse question tied to his path.
- The release checklist, or a page of it → F4 and F8 move from medium to high confidence, because the checklist is inspectable.
- A dated sample of the content-drop calendar → F2 and B3 get a named artifact to rehearse from.
- A retention figure you presented, with how it was counted → C1 and C2 get defend-the-number answers you can repeat.
- Any event or planning work across a second title → F5 moves up from transferability.
