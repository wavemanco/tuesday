# Interview prep: Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager, Thursday 26 November 2026.
**Built from:** the pasted `tuesday-dossier.md` (version 1.1, decision `conditional_go`, dated 2026-08-14). The dossier is about three months old. Confirm the posting and responsibilities have not changed before Thursday; if they have, the fit snapshot needs regenerating.
**Interviewer:** hiring manager, name not given. No interviewer read.

---

## How to use this pack

- **Personas** describe how a question arrives (its tone and style). **Types** describe what is being scored.
- Guidance is scaffolding, not a script. Say it in your own words. Rehearse only what you actually did.

**Type key**

| Tag | Name | What it scores |
|---|---|---|
| **JD** | Role / JD-driven | Whether you can do the listed job, including its gaps |
| **EXP** | Work-experience deep-dive | Whether your claims survive scrutiny |
| **CASE** | Hypothetical / live problem | Structure and reasoning on a problem from the role |

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row 1 | low | [inferred] | transferability | This is adjacent work: client integration leadership, not product management. Say it at its own scope: "I led end-to-end client integrations of the vendor's REST APIs." Name the limit first: no PM title and no product roadmap. Any step beyond integration is an answer slot inside that scope. |
| F2 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row 1 | low | [inferred] | discovery | The quote touches APIs but does not show whether you shipped a product. Answer slot: "Which API or platform product did you ship, if any? If you shipped one yourself, say which and what you did. If the work was client integration of the vendor's APIs, say so plainly and stay with that." |
| F3 | "Agile delivery experience" — dossier role_profile R5 (preferred) | none given | low | [inferred] | discovery | Silent in the material. Clarify, don't bridge. Answer slot: "Describe how delivery ran on one integration, step by step. If agile practice was part of it, name the practice. If the work ran another way, say so." |
| F4 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row 3; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row 1 | medium | [grounded], expect a probe on row 3 | discovery | Client and product stakeholder work is shown. Engineering and sales work is not. Answer slot: "Name any engineering or sales stakeholder you worked with on those integrations, and what you did with them. If none, say so and stay with client and product." |
| F5 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Wrote the internal integration playbook her team uses" — dossier row 2 | high | [grounded] | discovery | The playbook is inspectable and high-confidence, but it does not show schemas. Answer slot: "Say what the playbook covered. If you worked on schemas directly, say which. If not, say so." |
| F6 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [inferred] | discovery | No evidence in the material. Dossier unknown: how adoption is measured today. Answer slot: "If you tracked an adoption metric, name it and how it was counted. If you did not, say so and say what you would measure first." |

**Hard gates:** none, per the dossier.

**Observations (the pack's own analysis, not words for you):**
- R2 ("Shipped API or platform products") is a must-have. The dossier does not list it among its weak areas. Your verified evidence shows integration work, not a shipped product. Treat F2 as a gap to verify before Thursday.
- R4 names engineering and sales. The verified evidence shows client and product work only (F4).

---

## Prohibited claims

Not coached in any answer, hold, bridge or reverse question. Honest forms are given.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` item | Plain acknowledgment: "I haven't held a product manager title or role." |
| Having owned a product roadmap | Dossier `prohibited_claims` item and `acknowledge_gap` area | Plain acknowledgment: "I haven't owned a product roadmap." |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` item and `acknowledge_gap` area | Plain acknowledgment: "I haven't set prioritization for an engineering squad." |
| Ran roadmap-input sessions as roadmap input or decisions | Inflated form of dossier row 3 | Quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." The limit is the pack's observation: the material says sessions fed evidence to product, not that you decided anything. |
| Owned the API product or its platform | Inflated form of dossier rows 1 and 2 | Quote at its own scope. The material shows integration leadership and a playbook, not product ownership. |
| Owns API docs and schemas | Inflated form of dossier row 2 | Quote at its own scope: the playbook. Schemas are an answer slot (F5). |

---

## Persona table

| Persona | Weight | Why | How it shows up | Counter-strategy |
|---|---|---|---|---|
| **Skeptic** (A) | 5 | Hiring-manager prior, plus the dossier's named objection on the PM-title gap | "Why hire you into a PM seat?" | Rehearse the plain acknowledgment, then the bridge at its scope. Hold through two follow-ups. |
| **Case / Strategist** (B) | 5 | Hiring-manager prior: live problems on the role's real work | Diagnose adoption; plan discovery; decide roadmap calls | Clarify before structuring. Name the baseline you lack. |
| **Data-Driven Prober** (C) | 4 | JD names adoption metrics; "30+" is a headline figure; row 3 is a medium-confidence probe | "How did you count it?" | Name the weakest assumption in your own words. Answer slots where you did not track. |
| **Pressure** (D) | 2 | Low prior for this round; the objection can still be asked with pressure | "Sixty seconds: why you?" | Hold the core claim, concede only what is true. |
| **Conversational** (E) | 2 | Opener risk: a casual question is still scored | "Walk me through the journey." | A 90-second arc from quoted sentences only. |

---

## Question banks

Provenance comes before guidance. Each Provenance cell quotes every sentence the guidance rests on.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1); "Having held a product manager title or role" and "Having owned a product roadmap" (dossier `prohibited_claims`) | **Highest-ROI prep in this pack.** The underwriter named this objection. Open with the plain acknowledgment: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Then the bridge at its scope: "What I have done is lead end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." Name the limit yourself before they press: "The part I'd need to prove is prioritization authority." Hold the integration claim through two follow-ups. Concede only what is true: a PM with three years of the job starts ahead on roadmap ownership. Then your ramp plan, framed as a plan, never as past work. | The underwriter's objection, asked as written. Both negatives come from the dossier's `prohibited_claims` field. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibility) | Name roadmap ownership and prioritization authority, using the plain acknowledgment from A1. Then one ramp plan. Do not name R5 unless asked. | The dossier's `acknowledge_gap` area is the honest answer to this stem. |
| A3 | "Who decided the order of work on the integrations you led?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1) | Answer slot: if you decided any part of the order, say which part and how, in your own words. If the order was set by someone else, or by the client, say so plainly and describe how the integrations ran. | The most likely prober on the roadmap gap. The second branch allows that no order was set by you. |
| A4 | "I don't see roadmap ownership in your background — how would you handle that in this role?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibility); the `acknowledge_gap` area for roadmap ownership (dossier) | Acknowledge the gap in one sentence, then give your ramp plan as a plan: what you would learn first, from whom, and how you would check the squad calls. Do not claim a roadmap track record. | The interviewer may state the gap themselves. The rehearsal is the ramp plan, not the negative. |
| A5 | "Which API or platform product did you ship, if any?" | JD | [grounded] "Shipped API or platform products" (dossier role_profile R2); "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier row 1) | Answer slot. If you shipped one yourself, name it and your part. If not, say so and describe the integration work in its own scope. Do not bridge a product claim from integration work. | R2 is a must-have and is not in the dossier's weak areas. See observation in the fit snapshot. |

### B. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner's integration has stalled at UAT. Walk me through what you'd do in the first two weeks." | CASE | [generic] | Clarify the objective first: which partner, what is blocking, and what done means. Then structure: the blocker, the partner, the internal teams, the decision. Think aloud. Say what you would need to know before deciding. | A live problem from the role's partner work. No claim about your past. |
| B2 | "Partner API adoption dropped 20% quarter over quarter. Diagnose it." | CASE | [grounded] "Define and track adoption metrics" (dossier role_profile responsibility) | Clarify the baseline first, because none is stated: how adoption is counted and what the current number is. Then segment the drop: partner, endpoint, new versus existing integrations. Name your weakest assumption about the counting. | The dossier's unknown, asked as a live problem. The honest first move is to ask for the baseline. |
| B3 | "Sketch how you'd run discovery with three integration partners at once." | JD | [grounded] "Run discovery with integration partners" (dossier role_profile responsibility); "scoping, requirements" (dossier row 1) | Use the beats your integration work states: scoping, then requirements. Add the sequencing and the questions you would ask each partner. Do not claim a discovery track record. | JD responsibility. The beats come only from the quoted row. |
| B4 | "Which roadmap decisions would you make alone, and which would the squad leads make?" | JD | [grounded] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibility) | Answer slot. Name the decisions you would expect to own and the ones you would expect the squad leads to own, as a proposal. If you have worked this split before, say how. If not, say so and propose how you would find out. | The dossier's top unknown: decision authority versus the squad leads. Asked as the interviewer's question, not as a claim. |
| B5 | "Describe how delivery ran on one of those integrations, step by step." | JD | [grounded] "Agile delivery experience" (dossier role_profile R5) | Clarify, don't bridge. Answer slot: if agile practice was part of the work, name the practice and its cadence. If the work ran another way, say so. Then say what you would confirm about how the role defines agile. | R5 is preferred, and the dossier rates it low. Clarify strategy only. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you count the 30+ integrations, and what counted as done?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1) | Defend the number. Say how it was counted in your own words. Name the weakest assumption before they do, for example whether a go-live counts the same as a stable integration. If you cannot say how it was counted, say so. Do not reconstruct a method. | A headline figure is a magnet for probers. The count is the one the dossier's verified line carries. |
| C2 | "The JD says you define and track adoption metrics. Which adoption metric have you tracked?" | JD | [grounded] "Define and track adoption metrics" (dossier role_profile responsibility) | Answer slot. If you tracked a metric, name it, how it was counted, and whose it was. If you did not, say so and say what you would measure first. | F6: no evidence in the material. The honest answer is the one you have. |
| C3 | "What does adoption mean on your side — how would you know a partner had adopted?" | JD | [generic] | Define adoption in your own terms: first call, sustained calls, a use case in production. Say what you would need from partners to know. No past claim. | A pattern for the question, not a fact about this employer. |
| C4 | "Your roadmap-input sessions fed client evidence to product. How did you know what product did with it?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row 3) | Answer slot. If you tracked what product did with the evidence, say how. If you did not, say so: the sessions fed evidence to product, and you did not track its use. | The dossier rates row 3 medium with limited proof; expect this probe. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM with three years of the job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier row 1); "Having held a product manager title or role" (dossier `prohibited_claims`) | Pause. Restate the question. Plain acknowledgment: "I haven't held a PM title or role." Then the bridge at scope. Hold through two follow-ups. Concede: the PM has ownership you lack. | A composure test on A1's objection. |
| D2 | "That integration work — how much of the outcome was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row 1) | Answer slot. Name which of those stages were yours alone, which were shared, and which were not yours. Do not claim the whole outcome. | Attribution honesty under pressure. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier row 1); "Wrote the internal integration playbook her team uses" (dossier row 2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row 3) | A 90-second arc in this order: integrations, the playbook, the roadmap-input sessions. Quote each sentence, then stop. Close with the bridge line, not an ambition. | Casual openers are scored. The arc uses only quoted sentences. |
| E2 | "What are you actually working with in API docs and schemas these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" (dossier row 2) | Answer slot. Name the docs and schemas you have worked with, in your own words. If the playbook is the most you have touched, say that. | R3's schema depth is not shown (F5). |

---

## Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| R1, 3+ years PM experience | A1, A2, D1 | Bridge and acknowledgment only |
| R2, Shipped API or platform products | A5 | Answer slot; the dossier does not flag it |
| R3, Technical fluency: API docs, schemas | E2, C1 | F5 gap |
| R4, Stakeholder management: engineering, sales, customers | B4, C4 | Sales: none, and why: the material shows no sales work |
| R5, Agile delivery | B5 | Clarify only |
| Define and track adoption metrics | B2, C2, C3 | F6 gap |
| Own the roadmap for the partner-facing API platform | A2, A4, B4 | Dossier unknown |
| Run discovery with integration partners | B3 | |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R-1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Tests the dossier's top unknown. You need the answer before accepting. |
| R-2 | "How is partner API adoption measured today, and what is the current baseline?" | Answers the adoption unknown. It is the B2 question, asked back to them. |
| R-3 | "What would make you say in six months that hiring someone without the PM title was the right call?" | Turns A1 into a conversation about success criteria. |
| R-4 | "Where do the two squads' priorities collide with partner requests today?" | Shows you know the seam, and gives you the real conflict. |
| R-5 | "Which partner integrations are hardest to get through UAT right now?" | Signals interest in the integration work the dossier verified. |
| R-6 | "What would you want this hire to decide in the first month?" | Shows you are thinking about the job, not the title. |

---

## Sources

- **Provided document:** `tuesday-dossier.md`, version 1.1, decision `conditional_go`, dated 2026-08-14, pasted in this conversation. Consumed sections: `handoff_to_mock_interview` (verified evidence rows 1–3, weak areas, likely objection, prohibited claims, risks, employer questions); `role_profile` (requirements R1–R5 and responsibilities). `evidence_map` and `risk_register` were not in the pasted summary and were not used.
- **Research tier: L0.** No searches or fetches were run for this pack. Company values, the loop structure and Quartzline's recent strategy are absent from the pack.

**Target accounting**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Values cheat sheet (not run this pass) |
| 2. `Quartzline interview process product manager` | unavailable | Loop structure and persona weights (not run this pass) |
| 3. `Quartzline strategy` / recent news | unavailable | Grounding brief and a strategy-grounded CASE question (not run this pass) |
| 4. Interviewer name and Quartzline | n/a | No name was given |
| 5. Representative JD | skipped | The dossier's `role_profile` fixes the JD lines |

---

## Upgrade menu

- The hiring manager's name → personas weighted from public footprint, and a tailored reverse question.
- An L1 research sweep on Quartzline → values, the interview process and recent strategy, which would move B2 and the grounding section.
- Confirmation that the posting has not changed since 2026-08-14 → the fit snapshot stays as written, or regenerates if it has changed.
- Whether you shipped an API or platform product → upgrades F2 and A5 from answer slot to a grounded line.
- Your CV, or the figure behind "30+" → makes C1 answerable from a record, not from memory.
