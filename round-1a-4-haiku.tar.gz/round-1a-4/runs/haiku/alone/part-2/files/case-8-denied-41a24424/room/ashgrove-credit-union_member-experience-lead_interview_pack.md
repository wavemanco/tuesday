# Interview prep: Member Experience Lead, Ashgrove Credit Union

Three rounds on 3 December 2026, run as a loop: a recruiter screen, a behavioural round with the Head of Member Services (your future manager), and a panel of two branch managers with a 20-minute complaint-escalation case.

Names of the three interviewers were not given, so there is no interviewer read. The upgrade menu says what a name would unlock.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** behavioural and values. **EXP** your own past work. **JD** the listed job. **CO** company and strategy. **CASE** a live problem.
- Question IDs are by round: **A** for the recruiter screen, **B** for the Head of Member Services round, **C** for the panel.
- Guidance is scaffolding, not a script. Each cell is speakable in 90 to 120 seconds.
- An **answer slot** is an instruction for the interview, not a question. Where your material does not show something, the slot tells you to say so plainly.
- Everything about your past comes from your own sentences, quoted in the fit snapshot or in each row's provenance.

## Grounding brief

These are the strategy points as you summarised them from the July 2026 brief. I have not seen the brief itself.

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- The main competitive pressure is app-only banks.

Use these as your understanding. Paste the brief into the conversation and the CO questions can use its exact vocabulary.

## Fit snapshot

Requirements are the JD's own words. Evidence is your sentences, verbatim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log. Say that: "I handled the branch's formal complaints log." The end-to-end scope across branches is not in it, so do not claim it. Answer slot: if you set how complaints moved from one step to the next, say which and how you decided; if you did not, say so and stay with the log. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | Plain acknowledgment: "I've never worked in a contact centre." Then how you would learn contact-centre complaint flow, said as a plan, never as a past. |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | Your material says a monthly complaints spreadsheet that you built and your regional manager uses. It does not say which measures it carries, so name volumes or resolution times only if the spreadsheet carried them. |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | The sentence says spreadsheet, not Excel. Say the tool you built it in, in your own words, and let the monthly reporting carry the point. |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Training tellers and being a supervisor are adjacent to coaching supervisors, and the bridge stops there. Say: "I trained new tellers on our escalation script." Answer slot: if you have coached another supervisor on an escalation, say what you did; if you have not, say so and say how you would start. |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if you have worked with a digital team on a self-service journey, say what it was and your part in it; if you have not, say so and say how you would start from the complaints you see. |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Say it as your material does: six years in retail banking, the last three as a branch supervisor. The sector label is the one part of the requirement your sentence reaches in other words. |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Your material does not show whether the log was regulated: "formal" is not the same as regulated. Answer slot: if the log carried regulatory timescales or regulator reporting, say which and your part in them; if it did not, say so and say what the log did. |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Your own words: "I've never presented to anyone above regional level." Then how you would prepare for a senior audience, said as a plan, never as a past. |

No row is a gate. The JD's requirements are experience and skills, not terms, so the four-year requirement is graded like any other.

## Prohibited claims

These are not coached anywhere in this pack, because each one stretches or contradicts what you said.

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned the member complaints process end to end across branches and the contact centre" | Inflated form of F1 and F2 | F1's quote at its own scope. Pack observation, in analysis: your material shows one branch's log and no contact centre. |
| "Worked in a contact centre" | Negative you stated, F2 | "I've never worked in a contact centre." Plain acknowledgment. |
| "Presented to senior leaders" | Negative you stated, F9 | "I've never presented to anyone above regional level." Plain acknowledgment. |
| "Reported resolution times every month" | Inflated form of F3 | F3's quote at its own scope. Pack observation: the measures the spreadsheet carries are not in your material. |
| "The whole region runs on the reporting I built" | Inflated form of F3 and F4 | "I built the monthly complaints spreadsheet our regional manager uses." |
| "Coached branch supervisors on escalations" | Inflated form of F5 | "I trained new tellers on our escalation script." |
| "Handled regulated complaints" as a fact | Inflated form of F8 | F8's quote at its own scope. The regulated question is an answer slot. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | A8, B1, C1 |
| The contact centre part of that requirement | A7, B6, B7, C7 |
| Report monthly on complaint volumes and resolution times | B4, C9 |
| Coach branch supervisors on escalations | B3 |
| Work with digital teams on self-service journeys | B9, C5, C6 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | C1 |
| Confident presenting to senior leaders | B5 |
| Comfortable with Excel reporting | B4, C9 |

## Persona weights by round

Weights are shown as reasoning, so you can correct any of them if you know something I don't.

| Round | Persona | Looks like | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 Recruiter, 30 min | Conversational / Rapport | Friendly opener, "walk me through", pay and notice asked casually | High. Recruiter screens run in this register, and the logistics are checked casually. | A 90-second arc for the opener. Treat casual questions about the JD's topics as scored. |
| 1 Recruiter, 30 min | Skeptic (light) | One sharp question on the contact centre | Medium. It is the JD's most visible gap, and a recruiter may test it early. | Plain acknowledgment, then the nearest sentence you have, then the plan. |
| 2 Head of Member Services, 45 min | Values / Behavioral | Scenario prompts tied to the four values | High. You were told the round is mostly behavioural, and this is the scoring language for both later rounds. | STAR-shaped stories from quoted sentences. "I" for what you did, "we" for the team. |
| 2 Head of Member Services, 45 min | Skeptic | "Which gap would you close first?" | High. A future manager's job here is to test the contact-centre and senior-presentation gaps. | Rehearse the contact-centre objection until it is routine (B6). |
| 2 Head of Member Services, 45 min | Case / Strategist | Live problem on digital journeys | Medium. The JD's self-service requirement is live work, so expect one problem. | Clarify, then plan, then measure. Name what you do not know. |
| 3 Panel, 60 min | Values / Behavioral | Scored against the four values | High. The panel has said it scores against the four values. | Map each value to a quoted sentence, or give the selection scaffold and its honest branch. |
| 3 Panel, 60 min | Case / Strategist | 20-minute complaint-escalation case | High for the case, which is the stated format. | Run the timed structure in C1. |
| 3 Panel, 60 min | Peer Evaluator | Seam questions between branch and contact-centre complaints | Medium. Branch managers sit beside the complaints role, so a seam probe is likely. Their seniority to you is not given; the upgrade menu asks for it. | Seam principles, not a claimed knowledge of their seam. Reciprocity in your reverse questions. |

## Round A: recruiter screen (30 min)

Eight questions. Logistics slots (A3 to A6) are instructions in your own words, not blanks to fill in. Your inputs contain no pay, notice, location or reason for leaving, so the pack supplies none.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP, JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message; "I handled the branch's formal complaints log" — your message; "trained new tellers on our escalation script" — your message | A 90-second arc in three beats: six years in retail banking, the last three as a branch supervisor; the formal complaints log; training tellers on the escalation script. Say each in your own words, then stop. | F7, F1 and F5 are the evidence for the arc. It covers the four-year requirement, so it is also a JD question. |
| A2 | "What is drawing you to Ashgrove?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter" — Ashgrove values, your message; "I handled the branch's formal complaints log" — your message | Give one reason you can stand behind, in your own words. If the complaints log is that reason, use only its sentence: "I handled the branch's formal complaints log." | A values-style opener. The recruiter's screen checks motivation against the published values. |
| A3 | "Why are you leaving your branch role now?" | EXP | [generic] | Logistics slot, reason for leaving. Your reason is not in your inputs, so the pack gives none. Say it in one sentence, in your own words, about what you are moving toward. | Reason for leaving is one of the four logistics the recruiter will check. The answer is yours alone. |
| A4 | "What salary are you looking for?" | JD | [generic] | Logistics slot, pay. Your figure is not in your inputs, so the pack gives none. Before the call, decide whether to give your own figure or to ask for the role's band first. Do not give a range or floor you have not decided. | Pay is the first logistics question in most screens. |
| A5 | "What notice do you need to give?" | JD | [generic] | Logistics slot, notice. Give the notice period you actually owe, once, plainly. | Notice is a logistics check. |
| A6 | "Where would you need to be based, and how often in the office?" | JD | [generic] | Logistics slot, location. Say where and how often you can work. The role's location and pattern are not in your inputs, so if the recruiter has not stated them, ask for them before you answer. | The JD gives no location. The recruiter may. |
| A7 | "The role runs complaints across the contact centre. What's your experience there?" | JD, EXP | [grounded] "Never worked in a contact centre" — your message; "I handled the branch's formal complaints log" — your message | Plain acknowledgment first: "I've never worked in a contact centre." Then the nearest sentence you have: "I handled the branch's formal complaints log." Then a plan for learning contact-centre complaint flow, said as a plan. | F2 is the largest gap in the snapshot, and a recruiter may test it at once. The plain acknowledgment is one you stated, so you can say it without defending it. |
| A8 | "What would you look at first in this role?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" — JD | Answer as a plan, not a past: name the first thing you would look at, such as where complaints are logged and how long they wait, and say why. | The JD's first requirement is the raising source. The question asks for a plan and presupposes no past. |

Reverse questions for this round. Each has a "why it lands."

| # | Question | Why it lands |
|---|---|---|
| RA1 | "Is the role's location and working pattern fixed, or does it move with the branch consolidation?" | It gets the logistics the pack cannot supply, and shows you know the consolidation is coming. |
| RA2 | "Your email says the panel scores against the four values. Which one usually separates candidates?" | It shows you read the process closely, and asks where to put your effort. |
| RA3 | "How much of the complaints work sits in branches today, and how much in the contact centre?" | It shows you know the split between the two matters for the role. |
| RA4 | "What does the 40% digital target mean for complaint volumes in the first year?" | It ties the question to the July strategy brief. |
| RA5 | "Which of the three rounds carries most weight in the decision?" | It shows you are thinking about the decision, not just the interview. |

## Round B: Head of Member Services (45 min, future manager)

Nine questions. This round is mostly behavioural, so the values and skeptic banks are deepest here.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you handled a complaint that wasn't straightforward." | VAL, EXP | [grounded] "I handled the branch's formal complaints log" — your message | One case from the log: the member, what they complained about, what you did, how it ended. Say only what you did on that case, in your own words. If you have no case you can describe in those terms, say so plainly, then give how you handled the log in general, using only its sentence. | Open prompt, with the JD's complaints requirement as its theme. F1 is the scope to stay inside. |
| B2 | "Tell me about a time a member needed something explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" — your message; "Plain Words — if a member needs it explained twice, we wrote it wrong" — Ashgrove values, your message | If you changed the script, or how you taught it, say what and why. If you did not change it, say so plainly, then say what you would change. | Plain Words. F5 is the training sentence, and the honest branch is part of the answer. |
| B3 | "How would you coach a branch supervisor who is escalating complaints too late?" | JD, CASE | [grounded] "coach branch supervisors on escalations" — JD; "trained new tellers on our escalation script" — your message; "the last 3 as a branch supervisor" — your message | Structure: what you would look at in the escalation record first, the conversation you would have, and what you would check two weeks later. Say what you would do, not what you did. Answer slot: if you have coached another person on an escalation, say what you did; if you have not, say so and say how you would start. | F5 is transferability. This is the case behind the JD line, and the slot keeps any coaching claim to what you did. |
| B4 | "Walk me through the monthly complaints spreadsheet. How do you know a figure in it is right?" | EXP, JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Say what the spreadsheet reports and who uses it. For any figure you give, say how it was counted and the assumption you would defend least. If you cannot say how a figure was counted, say so and offer to send the spreadsheet. Answer slot: if you ran checks before the regional manager saw it, say which; if you did not, say so. | F3 and F4. This is a defend-the-number question: the counting method and the weakest assumption are the slots. |
| B5 | "How would you prepare to present complaint trends to senior leaders?" | JD, CASE | [grounded] "confident presenting to senior leaders" — JD; "I've never presented to anyone above regional level" — your message | If asked whether you have presented above regional level, say: "I've never presented to anyone above regional level." Then your plan: what you would put on one page, and who you would rehearse it with first. | F9. The question asks about a plan, so it presupposes no past. The honest answer is already in your own words. |
| B6 | "I don't see the contact centre in your background. How would you own complaints across it from your first month?" | JD | [grounded] "Never worked in a contact centre" — your message; "Own the member complaints process end to end across branches and the contact centre" — JD | Highest-ROI prep in this pack. Hold: "I've never worked in a contact centre." Then the nearest thing you have: the complaints log, at branch scope, in its sentence. Then your plan for the first month: what you would learn from contact-centre staff, which complaints you would read first, whom you would ask. Hold through two follow-ups by returning to the plan. Where a follow-up asks for a contact-centre example, the honest branch is: "I haven't done that." | F2 is the capability gap, and this is the most likely objection because the JD is built around it. The plain acknowledgment is one you stated. |
| B7 | "Sixty seconds: why should we give this role to someone with no contact-centre years?" | JD, EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message; "Never worked in a contact centre" — your message | Pause, then restate the question in one line. Hold your position through two follow-ups: six years in retail banking, the last three as a branch supervisor, and the complaints log. Concede the one thing that is true: you have not worked in a contact centre. Do not argue that it does not matter. | Pressure. The stated negative makes a hold-then-concede structure possible, and the hold uses only your own sentences. |
| B8 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved" — Ashgrove values, your message; "I built the monthly complaints spreadsheet our regional manager uses" — your message | Scaffold: pick a problem you found and kept hold of until it was solved. Name the problem, what kept you on it, and how it ended. Use the spreadsheet only if it showed a problem you followed through. If no such time comes to mind, say so plainly, then give how you handled a case on the log. | Own the Fix is scored directly. No sentence of yours carries this story, so the answer is a scaffold with its honest branch. |
| B9 | "How would you approach a self-service journey that is generating complaints?" | JD, CASE | [grounded] "work with digital teams on self-service journeys" — JD; "move 40% of member service to digital channels by 2028" — strategy summary, your message | Plan: start from the complaint data (which journey, which step, how often members come back), agree the fault with the digital team before you change anything, then measure the journey after. Answer slot: if you have worked with a digital team on a journey, say what it was and your part; if you have not, say so and give the plan. | F6 is discovery. The case is the JD's requirement, and the 40% target is why it will come up. |

Reverse questions for this round.

| # | Question | Why it lands |
|---|---|---|
| RB1 | "What has the move from eight branches to five hubs changed about how complaints reach your team?" | It shows you have read the brief, and asks for the operating fact that matters to the role. |
| RB2 | "How do you decide a complaint is resolved: the first reply, or the member saying so?" | It shows you think about Own the Fix in measurement terms. |
| RB3 | "Which part of the complaints process produces the most escalations that go nowhere?" | It invites the problem you would own, and shows you want the work. |
| RB4 | "What would you want the monthly complaints report to show that it does not show now?" | It tests the reporting link directly, and shows you expect the report to change. |
| RB5 | "What would make you say, six months in, that this hire was the right call?" | It shows you plan to succeed on their terms. |

## Round C: panel of two branch managers (60 min, including a 20-minute case)

Nine questions. The panel scores against the four values. The values cheat sheet sits here, because this round is the values round.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member's complaint about a declined small-business loan has reached you as a second escalation. The first reply promised a call-back within ten working days, and no call came. Talk us through the next hour." | JD, CASE | [generic] the case; [grounded] "Own the member complaints process end to end across branches and the contact centre" — JD | 20-minute timing. Minutes 0 to 4: clarify what was promised, by whom and when, what the member is owed, and whether a regulatory deadline applies. Minutes 4 to 10: act: contact the member today with a date you can keep, find out why the call-back was missed, and tell the branch manager who owns the fix. Minutes 10 to 16: fix the promise so it cannot be missed again: a logged date, a named owner, a reminder. Minutes 16 to 20: a values check, saying how the member's side of the counter shaped each step, then a summary. Say the next step, not the outcome. If interrupted, restate the step you are on. | F8 is the regulated-complaints requirement, tested here as a case. The case presupposes nothing about your past. |
| C2 | "The branch manager says the call-back was never logged. What changes?" | JD, CASE | [generic] | Name the fix as a process change: where the promise is recorded, who checks it, and when the check runs. Say which of these you would own yourself and which you would agree with the branch manager. | The follow-up probe on the case, in the way a branch manager would ask it. No past is claimed. |
| C3 | "Tell me about a decision you made on a complaint because of what the member needed, not what the process said." | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter" — Ashgrove values, your message; "I handled the branch's formal complaints log" — your message | Scaffold: pick a decision where the member's side changed what you did. Name the decision, what the process said, and what you chose. If no such decision comes to mind, say so plainly, then give the nearest case from the log, in its sentence. | Members First is scored directly. The log sentence is the only sentence of yours this story can rest on, so do not stretch it into a decision. |
| C4 | "Tell me about a time a number pulled you away from the people it measured." | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town" — Ashgrove values, your message | Scaffold: pick a time a figure on a report pointed one way while a member or a branch needed another. If none comes to mind, say so plainly, then say how you would keep the monthly report honest about who it measures. | No sentence of yours carries this story. The scaffold ends with its honest branch. |
| C5 | "The brief says 40% of member service moves to digital by 2028. What does that do to complaints?" | CO | [grounded] "move 40% of member service to digital channels by 2028" — strategy summary, your message | Analysis, not a claim about your past. Say which complaint types move channel first, what you would measure in the first two quarters, and what you would not assume. | A CO question on the brief. The answer is reasoning, so it makes no claim about you. |
| C6 | "The brief consolidates eight branches into five hubs over 2027. How do you keep complaint handling close to each town?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" — strategy summary, your message | Plan, said as a plan: a named contact per town, how a member knows who is handling their complaint, and what the hub does that the branch did. | Neighbours, Not Numbers meets the hub plan. This is the question most likely to test that value. |
| C7 | "Our teams sit side by side. Where is the seam between branch and contact-centre complaints, and what happens when we disagree?" | JD, EXP | [grounded] "Own the member complaints process end to end across branches and the contact centre" — JD | A seam principle, not a claim to know their seam: who owns a complaint that starts in a branch and ends in the contact centre, and how that decision is recorded. For disagreement: if you have disagreed with a peer, say what you did and how it ended; if you have not, say so and say how you would settle it. | Peer Evaluator. A seam probe is the likeliest peer question. |
| C8 | "How do you handle credit when work spans teams?" | VAL | [generic] | Scaffold: pick a piece of work that crossed teams, name who got the credit, and what you did about it. If none comes to mind, say so plainly, then say how you would agree credit before the work starts. | No sentence of yours carries this story. The scaffold ends with its honest branch. |
| C9 | "Show us how you would check a monthly figure before it goes to the regional manager." | JD, CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Defend-the-number, as a plan: the checks you would run on any figure, such as totals against the case list, a sample of cases, and the one number you would doubt most. If you ran checks on your spreadsheet before it went out, say which; if you did not, say so. | F3. The question asks how a figure is checked, so the checks you actually ran are the only ones you can describe. |

Reverse questions for this round.

| # | Question | Why it lands |
|---|---|---|
| RC1 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity with peers. It shows you want to contribute to their work, not only to take a role. |
| RC2 | "When a complaint starts in a branch and lands in the contact centre, who decides how it is closed?" | It names the seam and asks for the answer, which shows you have thought about it. |
| RC3 | "What do branch managers ask the complaints team for most, and what do they never get?" | It finds the real demand on the team, and shows you plan to serve the branches. |
| RC4 | "Where do you see the four values pulling against each other in a branch week?" | It shows you have read the values closely, and asks for their judgement, not a slogan. |
| RC5 | "How will the five hubs change who signs off a complaint response?" | It ties the question to the brief and to a real decision in the role. |

## Values and principles cheat sheet

For the panel's values round. Each row is either a mapped story, a selection scaffold ending in its honest branch, or both.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | Scaffold, C3. Your only sentence here is "I handled the branch's formal complaints log" (F1). Do not stretch it into a decision. If no decision comes to mind, say so plainly. |
| Plain Words | If a member needs it explained twice, we wrote it wrong. | Scaffold, B2, from F5: "trained new tellers on our escalation script." If you changed the script or how you taught it, say what and why. If you did not, say so and say what you would change. |
| Neighbours, Not Numbers | Every branch is part of its town. | No row carries a story. Scaffold, C4 and C6. If none comes to mind, say so plainly, then say how you would keep the town in view. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Scaffold, B8. From F3: "I built the monthly complaints spreadsheet our regional manager uses" carries a story only if it showed a problem you followed through. |

## Prep order

The pack is built for three rounds on one day, nine days out. Work in this order: the fit snapshot and the prohibited list first, so you know which sentences you can say. Then B6 and B7 as the highest-ROI rehearsal. Then the C1 case timing, out loud, twice. Then the values scaffolds, which need your own examples.

## Sources

- Provided documents: the JD and your background (your message); the values, as you pasted them, copied on 24 November 2026 from ashgrovecu.org/about/values (not fetched by me); the recruiter's process email (summarised in your message); the July 2026 strategy brief (summarised in your message, not in hand).
- No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values cheat sheet. The four values are in hand, pasted. |
| 2. Ashgrove interview process | skipped | The loop structure. The recruiter's email fixes the three rounds. |
| 3. Ashgrove strategy / recent news | skipped | The grounding brief. The strategy summary in hand gives the current priorities; the full brief would sharpen the vocabulary. |
| 4. Interviewer name and Ashgrove | n/a | No names were given, so there was no query to form. |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The recruiter's name, and the role's location and working pattern → a named recruiter in the title block, and a location line that replaces the ask-first step in A6.
- The July 2026 strategy brief pasted in full → exact vocabulary for the CO questions (C5, C6, RA4) and a sharper grounding brief.
- The Head of Member Services' name → a public-footprint read for the Round B persona weights, and reverse questions tied to their career path.
- The two branch managers' names, and whether either is senior to you → Round C persona weights, in place of the peer assumption.
- A description of the spreadsheet's columns → F3 and F4 can move from presentation to grounded detail, and B4's defend-the-number slots become specific.
- Any contact-centre or senior-presentation experience not in this message, told in your own words → F2, F9, B5 and B6 regenerate with it as quoted material.
- Whether the complaints log carried regulatory timescales or regulator reporting, in your own words → F8 becomes grounded, and C1 adds your part.
- Your prep time before 3 December → a prioritised schedule, sized to the time you have.
- A `tuesday-dossier.md` → it would carry verified evidence and prohibited claims into the fit snapshot, replacing the locally built list.
