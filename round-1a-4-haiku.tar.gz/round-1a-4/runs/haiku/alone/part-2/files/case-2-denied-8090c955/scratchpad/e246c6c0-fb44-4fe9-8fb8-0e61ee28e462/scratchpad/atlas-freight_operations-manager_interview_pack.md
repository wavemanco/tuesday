# Operations Manager, Atlas Freight: interview prep pack

Built for a hiring-manager round, which I assumed because your note didn't say who you're meeting. Company facts are absent: web search was refused, so nothing about Atlas Freight's values, interview process or strategy is in this pack.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values), EXP (your experience, deep-dived), JD (the job's stated requirements), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Answer slots are instructions for the interview: answer from your own experience, in your own words, and say plainly when something was not yours.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "currently a senior shift manager over 3 supervisors" (your message); "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material describes one site and one shift. The four-site scope is not in it. Bridge: "I run a shift at one site, with three supervisors." Answer slot: if you have run anything across more than one site, say what and how, in your own words; if not, say so plainly and say how you would learn the other sites. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows accuracy work, not on-time or cost-per-shipment. Bridge stays at its own scope: "I cut the mis-pick rate by 40% by redesigning the pick path." Answer slot: if you have measured on-time or cost per shipment at a site you ran, say what you measured and what moved; if not, say which measure you would track first. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Three supervisors, and your material shows no larger span. Bridge: "I'm over three supervisors now." Answer slot: if you have led a larger group, name the size and what you did; if not, say so and describe how you would organise twelve. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | low | [grounded] | discovery | Seven years of operations is stated; how many of them were leadership is not. Length of experience is not a gate, so this row is graded rather than screened out. Bridge: "I have 7 years in warehouse and distribution operations." Answer slot: say how many of those years you led people, in your own words. Do not add the seven to a leadership figure. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | low | [grounded] | transferability | "Solid" is your word and has not been inspected. Excel reaches part of the requirement, not the reporting itself. Bridge: "Solid Excel," as you said it. Answer slot: name one Excel report you built and what it was for; if none, say so. |
| F6 | "build reporting in Excel/Power BI" (JD), Power BI part | "never used Power BI" (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The credential reaches the requirement. Words: "I'm Green Belt certified." Expect a probe on whether you used it (A4). |

**Confidence** grades your evidence. **Provenance** grades what this pack wrote. Gap types follow the routing rule: no requirement here is a gate (none is a term you meet or do not, such as a licence or a right to work), so no row is `hard_gate`.

## Persona table

Weights are shown so you can correct them. Round type was not given, so the relationship prior is a hiring manager's. No loop source establishes the loop, so the fallback is the generic archetype: flat weights, said plainly, and no values round is detected.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of the span, the years and the Power BI gap | Highest. A hiring manager is buying capability and derisking gaps, and F1, F3 and F4 are the three largest gaps in the fit snapshot | Rehearse A1 until it is boring; bridges from what you stated, with a plan for the rest | 5 (top) |
| Case / Strategist | Live problems on operations: on-time, cost, peak, scorecards | High. The JD names on-time and cost as outcomes to drive down, so expect a live problem on them | Clarify, then structure, then one hypothesis to test first | 4 |
| Data-Driven Prober | Asks how the 40% was counted and what it is sensitive to | Medium-high. The JD's reporting line and your one headline figure both invite it | Name the weakest assumption before they do; say plainly where you do not know | 3 |
| Pressure / Stress | Interrupts, time-boxes, asks "how much of that was actually you" | Medium. Common for hiring managers under pressure to fill a senior role | Pause, restate, hold through two follow-ups, concede only the specific uncertainty | 3 |
| Conversational / Rapport | Casual opener, "walk me through the journey", "what are you playing with" | Low-medium. Casual questions still score the JD's plus-skill | Pre-scripted 90-second arc; treat casual questions on Lean as scored | 2 |
| Peer Evaluator | Seam questions between sites and neighbouring teams, credit-sharing | Low. Only if the round is with a peer | Propose seam principles rather than claimed knowledge of their process | 2 |

## Question banks

Question IDs are letter-by-persona. Each guidance cell is speakable in 90 to 120 seconds.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role runs four sites and twelve supervisors. You lead three. Why should we believe you can scale that?" | JD | [grounded] "Own daily terminal operations across 4 sites" (JD); "lead a team of 12 supervisors" (JD); "currently a senior shift manager over 3 supervisors" (your message) | Say the true number first: three supervisors, on one shift, at one site. Then the nearest thing your material does carry, in your own words. Answer slot: the JD's span is the probe most likely to come. If you have led people or sites beyond that, say how many and how it was run. If you have not, say so plainly and describe how you would structure twelve people across four sites. Hold through two follow-ups by returning to the three supervisors and the shift you run, never by adding to them. | **Highest-ROI prep in this pack.** The span is the largest gap the fit snapshot finds (F1, F3), and the Skeptic presses it first. A rehearsed, non-defensive answer changes the interview. |
| A2 | "The role requires five-plus years of operations leadership. How many of your years have been in a leadership role?" | JD | [grounded] "5+ years operations leadership required" (JD); "7 years in warehouse and distribution ops" (your message) | Keep the two numbers apart. Seven years in operations is what your material states; how many were leadership is not. Say the seven as the seven. Answer slot: if you can name the year you first led people, say it and count from there. If leadership came later than operations, say so and give the years that were leadership. Never add the seven to a leadership figure. | F4 is a discovery gap on a length requirement. Length is not a gate, so the row is graded, and the trap is merging the two numbers. |
| A3 | "You list Excel. The role needs Power BI. What would your first dashboard look like?" | JD | [grounded] "build reporting in Excel/Power BI" (JD); "solid Excel" (your message); "never used Power BI" (your message) | Open with the plain acknowledgment: "I haven't used Power BI." Then one Excel report you have built, named in your own words; if you have built none, say so. Then the plan, as a plan and not a past: the data a dashboard would start from, the refresh it needs, and the first view it would show. Never describe Power BI work. | F5 and F6. The Power BI gap is one you stated, so its words are the acknowledgment. Excel is the bridge, and "solid" has not been inspected. |
| A4 | "You're Green Belt certified. Which project did you apply it to?" | JD | [grounded] "Lean/Six Sigma a plus" (JD); "green belt certified" (your message) | Say the credential as the credential: "I'm Green Belt certified." Answer slot: if you applied it to a project, name the project and your part, in your own words. If the training stood alone, say so plainly. | F7. The plus is met by the credential, but the question tests use. Its premise is the interviewer's, and the second branch allows it to be false. |
| A5 | "Why are you leaving your current role for this one?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Give the reason in your own words. Your material gives the role and the step, not the reason. Answer slot: name the reason you actually have, in one sentence, then why this role is the next step, in terms the JD's own lines give. | The Skeptic's "why now". No reason is in the material, so none is supplied. |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of your four terminals has dropped sharply over the last six weeks. Walk me through how you would find out why." | JD | [generic] | Clarify first: what counts as on time, which lanes, shifts and carriers, and whether the drop is at one site or all of them. Then split it by shift, dock or lane, and by time, before naming a cause. Name the one hypothesis you would test first and what would disprove it. | The JD's "drive on-time performance ... down" line is the raising source. A live problem, so it presupposes nothing about you. Scored on clarifying before structuring. |
| B2 | "Cost per shipment is up at one of your four sites while volume is flat. Where would you look first?" | JD | [generic] | Ask how cost per shipment is defined and what it includes before answering. Then break it into labour hours, overtime, agency use and mix. Name the first lever and what you would check before pulling it. | The JD's cost line is the raising source. Same structure as B1; the definition question is the one a strong answer always asks. |
| B3 | "Peak starts in six weeks and volume is forecast up sharply. What is your plan across the sites?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Clarify the forecast and which sites carry the peak. Then the sequence: staffing, cover, cut-off times, escalation. If you refer to your own peak plan, say it is the one you ran, at the site you ran it at, and name what it was built from in your words. | F1. Your surge plan is the strongest material you have on peak, and the sentence scopes it to one site. The multi-site plan is a plan, not a past. |
| B4 | "How would you set one operating scorecard that works across four sites run differently?" | CASE | [generic] | Start with how the sites differ: volume, mix, facility, labour model. Then the few measures every site reports the same way, and what each site may tune. Say how you would keep the scorecard from becoming a league table. | The JD's four-site line is the raising source. This asks for the scale your material does not show, and the answer is a structure, which is what the case scores. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say what was measured, over which period, against which baseline, in your own words. Name the assumption behind the figure you would defend least, before they do. Then say which part was yours: the redesign, the rollout, the measurement. Answer slot: if you did not set the baseline, say so and say what you used instead. | The defend-the-number slot for the one headline figure on your material. F2 is the only metric you have, and it is accuracy, not the on-time or cost measures the JD names. |
| C2 | "How do you know the pick-path change caused the drop, and not peak volume or staffing?" | EXP | [grounded] "by redesigning the pick path" (your message) | Name one confounder you know was in the period, in your own words. Answer slot: if you checked for it, say how. If you did not, say so plainly and say what you would compare against. Do not claim a control you did not run. | The second defend-the-number probe on C1: attribution to the redesign is the one the quote carries. |
| C3 | "Show me the first dashboard you would build for on-time performance in Power BI." | JD | [grounded] "never used Power BI" (your message) | Open with the acknowledgment: "I haven't used Power BI." Then describe the design, not a past build: the source data, the refresh, the one view a site manager would open first, and the drill-down. | F6. The gap is stated, so the words are the acknowledgment; the design is a plan. The prober tests whether the plan has a source and a denominator. |

### D. Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, over someone who has run four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Pause, restate the question in your own words, then answer in the order your material gives: the shift you run, the peak plan you ran, the 40% you cut by redesigning the pick path. Hold that position through two follow-ups. If pressed beyond that, concede uncertainty about the span, specifically and in your own words. Never concede the core result. | The stress form of A1. The Pressure interviewer scores composure. The concession is the span only, the one thing the material does not show. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name your share in your own words, at the scope the sentence gives. Answer slot: if others set parts of it, say which parts and what you did. If the redesign was not yours to set, say so plainly and say what you did carry. | The stress form of the attribution probe. The honest answer is your precise share, which is the test. |
| D3 | "Your peak plan ran two years running. What would you change about the first year?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Answer slot: if you would change something, say what and why, in your own words. If you would change nothing, say so plainly and name the one thing you would watch for next time. Never describe a shortfall you did not have. | The pressure probe on the surge plan. It asks for a judgment the quote does not contain, so the second branch allows there was nothing to change. |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc: the seven years in warehouse and distribution, the step to senior shift manager, the three supervisors, the pick-path result and the surge plan, in that order. Each beat is one of your quoted sentences; add nothing between them. | Casual openers are scored. The arc is built from your own sentences, and it touches F1 and F3 without adding to them. |
| E2 | "What are you playing with in Lean these days?" | JD | [grounded] "green belt certified" (your message) | Say the credential as the credential, then the one Lean tool you have used at work, in your own words. Answer slot: if you used Lean tools on a project, name the tool and the project. If the training is the extent of it, say so. | F7: the JD's "a plus", asked casually. Casual questions are still scored. |

### P. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side. Where's the seam between your sites and the teams around them, and what happens when we disagree?" | JD | [generic] | Propose a seam principle, not a fact about their teams: who owns the cut-off, who escalates a missed slot, how disagreements get settled, in your own words. Do not claim knowledge of their process. | A generic peer probe; no source names their seams, so the guidance gives principles. |
| P2 | "When a surge plan spans teams, how do you handle credit?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Name who did which part, in your own words, at the scope of your sentence: the plan you ran, at the site you ran it at. Credit others by role. | F1. Your surge plan is the nearest cross-team material you have; the material does not show how much of it spanned teams. |

**Requirement coverage**

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, B3, B4, D1 |
| Drive on-time performance and cost-per-shipment down | B1, B2, C1, C2 |
| Lead a team of 12 supervisors | A1, D1 |
| Build reporting in Excel/Power BI | A3, C3 |
| 5+ years operations leadership required | A2 |
| Lean/Six Sigma a plus | A4, E2 |

## Reverse questions

No interviewer profile exists, so these are role-generic.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would success look like for this role at the end of year one?" | Shows you plan toward the outcome, not the job description. |
| R2 | "Which of the four sites is furthest from its on-time target today, and what is the main reason?" | Shows you want the real problem, not the summary. |
| R3 | "How is cost per shipment defined and reported today?" | Shows you will check the definition before you try to move the number. |
| R4 | "What reporting exists now, and what would a Power BI setup replace or add to?" | Shows you have heard the reporting line and want the current state. |
| R5 | "How are the twelve supervisors spread across the four sites?" | Tests the span before the interview ends. |

## Prohibited claims

What this pack will not coach, and why. Built locally from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran terminal operations across four sites | Inflated form of F1: your material describes one site | "currently a senior shift manager over 3 supervisors." The limit is this pack's observation: the material shows one site. A1's slot stays inside one site. |
| Led a team of twelve supervisors | Inflated form of F3 | "currently a senior shift manager over 3 supervisors" |
| Seven years of operations leadership | Inflated form of F4: the seven years are operations, not leadership | "7 years in warehouse and distribution ops." A2's slot asks how many were leadership. |
| Built Power BI dashboards | Negative you stated: "never used Power BI" | "I haven't used Power BI." |
| Expert-level Excel | Inflated form of "solid Excel" | "solid Excel," as you said it |

## Sources

- **Provided documents:** the job description and your background, both in your message. No CV was supplied.
- **Searches sent:**
  - "Atlas Freight regional logistics company values": errored (web-search permission not granted).
  - "Atlas Freight operations manager interview process": errored (web-search permission not granted).

Research tier: L0. L1 was planned; both calls errored.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Would have grounded the values cheat sheet. No values-style round is detected, so the section is dropped either way. |
| 2. Atlas Freight interview process | unavailable | Would have named the loop. Without it, the loop falls back to the generic archetype, with flat weights. |
| 3. Atlas Freight strategy / recent news | unavailable | No call sent. Would have grounded the CO bank, which is absent for that reason. |
| 4. Interviewer name and company | n/a | No interviewer name given. |
| 5. Representative operations manager JD | skipped | Your JD was supplied and fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Web-search permission → one research pass on Atlas Freight's values, interview process and strategy. This turns the `[generic]` rows into grounded ones and makes a company-strategy question possible.
- The number of people you have led directly, across how many sites, for how many years → answer slots A1, A2, D1 and F1 and F3 become your own quoted sentences.
- An Excel report you built and what it was for → slot A3 gets a quote, and F5 moves from low confidence.
- The interviewer's name → a tailored reverse question and persona weights from their public footprint.
- A `tuesday-dossier.md` → verified evidence and the objection the pack should rehearse hardest.
- The recruiter's email on focus areas, or any assignment → coverage of anything they have said they will test.
