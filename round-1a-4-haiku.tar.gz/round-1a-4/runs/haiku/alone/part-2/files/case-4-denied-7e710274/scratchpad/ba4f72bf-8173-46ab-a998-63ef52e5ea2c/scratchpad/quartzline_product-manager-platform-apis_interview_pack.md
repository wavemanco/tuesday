# Quartzline: Product Manager, Platform APIs. Hiring-manager interview pack

**Interviewer:** hiring manager (name not given). **Round:** 45 minutes, hiring manager.
**Built from:** `tuesday-dossier.md` (dossier_version 1.1, job-underwriter, generated 2026-08-14). Sections consumed: `role_profile`, `handoff_to_mock_interview`, `decision` (context only).
**Changelog:** first version.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | Meaning |
|---|---|
| **JD** | Can you do the listed job, including its gaps |
| **EXP** | Do your past claims hold up under scrutiny |
| **CASE** | Live problem from this role; structure and reasoning |
| **VAL** | Not used: no values round detected |
| **CO** | Not used: no company research ran |

The guidance is scaffolding, not a script. Say it in your own words. Speak each answer in 90 to 120 seconds.

**The one rule:** rehearse only what you actually did. The pack quotes your verified evidence and nothing else. Where the material is silent, the pack gives you an answer slot, not a claim.

## Run of the 45 minutes

You did not give prep hours, and a run-of-show was not in the standard skeleton. I added it because you asked for one.

| Minutes | What happens | Pack IDs |
|---|---|---|
| 0 to 3 | Intro. Give the 90-second arc. | E1 |
| 3 to 12 | The "why hire you into a PM role" objection and the closest-PM-work question. This is the most likely hard part. | A1, A2 |
| 12 to 22 | Shipped-product and stakeholder questions, then the API-schema scenario. | A3, A4, E2 |
| 22 to 32 | Live problem: flat partner adoption, and who decides on competing requests. | B2, B3 |
| 32 to 40 | Metrics and the adoption baseline. Agile delivery, as a clarify. | B5, C3, A5 |
| 40 to 45 | Your reverse questions. Ask RQ1 and RQ2 before anything else. | RQ1, RQ2 |

**Prep order, if time is short:** A1 aloud (deepest rehearsal), then A2 and A3, then RQ1 and RQ2, then C1 and C2 (the medium-confidence probes). The rest is insurance.

## The fit snapshot

Evidence quotes are the dossier's `verified_candidate_evidence` and `role_profile` text, verbatim. The dossier does not include an `evidence_map`, so confidence comes from the handoff entries and `uncertain_or_weak_areas`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (R1, must_have), dossier `role_profile` | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row, medium); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row, high) | low | [grounded] | transferability | Your material shows integration work and roadmap input. It does not show product management, and the bridge stays at that scope. Say the adjacent work in its own words, then name the limit. The title and role are not in the material. |
| F2 | "Shipped API or platform products" (R2, must_have), dossier `role_profile` | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row, high) | high | [grounded] | transferability | The integrations are adjacent to shipping an API product. The material shows delivery of integrations on the vendor's APIs, not a product you shipped. Answer slot: if you shipped an API or platform product yourself, name it and your part in it. If not, say so plainly and name the nearest integration you led. The dossier does not list R2 as a weak area; this grade is the pack's reading, and it goes to `pack_feedback`. |
| F3 | "Technical fluency: API docs, schemas" (R3, important), dossier `role_profile` | "Wrote the internal integration playbook her team uses" (dossier row, high) | high | [grounded] | discovery | The playbook touches documentation but does not show schema work. Answer slot: if you wrote or read API docs or schemas as part of an integration, say which. If you did not, say so plainly, then say how you would check a schema change before it reached a partner. |
| F4 | "Stakeholder management across engineering, sales, customers" (R4, important), dossier `role_profile` | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row, high) | high | [grounded] | transferability | The material shows client-side work and an architecture step. It shows no sales work, and engineering only as the architecture step. Say the client work at its scope. Sales is not in the material, so do not stretch the bridge to it. |
| F5 | "Agile delivery experience" (R5, preferred), dossier `role_profile` | none given | low | [grounded] | discovery | No quote speaks to agile delivery, so the words are a clarify slot. Answer slot: if you have worked in sprints or with an engineering squad, say how. If not, say so plainly, then say how you define agile delivery. |
| F6 | Sub-claim of R1: "Owning a roadmap and prioritization authority" (dossier `role_profile` unknowns and `uncertain_or_weak_areas`) | none given | none | [grounded] | capability | Plain acknowledgment only, named by its field: `prohibited_claims`, "Having owned a product roadmap". Say: "I haven't owned a product roadmap." Then a ramp plan, said as a plan. No bridge. |

**How the gap types were routed.** F1, F2 and F4 are `transferability`: a quote carries adjacent work that does not reach the requirement. F3 and F5 are `discovery`: the evidence may exist and the material does not show it. F6 is `capability`: the negative is stated in the dossier's own field. No row is `hard_gate`; the dossier lists no hard gates.

## Prohibited claims

These claims are not coached, in any cell, answer slot or drill. Each entry has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Held a product manager title or role | Sourced: dossier `prohibited_claims` | Say the adjacent work at its scope (F1). Plain acknowledgment, named by its field: "I haven't held a product manager title or role." |
| Owned a product roadmap | Sourced: dossier `prohibited_claims` | F6's plain acknowledgment and ramp plan. |
| Set prioritization for an engineering squad | Sourced: dossier `prohibited_claims` | F6's plain acknowledgment. Decision rights go to B3, as a question to ask, not a claim. |
| Shipped an API or platform product of your own | Inflated form of F2's quote | F2's quote at its own scope. Answer slot: name what you shipped, if anything. |
| Set the roadmap from your roadmap-input sessions | Inflated form of F1's quote ("Ran quarterly roadmap-input sessions feeding client evidence to product") | Say what you brought to product, to whom, and how often. Pack observation, not for you to say: the material shows input, not decisions. |

The dossier's decision text ("seven years of integration leadership") is not used. It is not a verified entry and nothing in the pack quotes it.

## Persona weights

Relationship prior, hiring manager: Case/Strategist and Skeptic. The dossier names the objection, and a hiring manager is buying capability and de-risking gaps. No interviewer profile exists, so there is no signal adjustment.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Weight and depth |
|---|---|---|---|---|
| Skeptic | Quiet probing of the PM-title gap and of the shipped-product gap | High. The dossier names the objection, and R1 and R2 are must-haves | Rehearse A1 until it is plain. Use bridges built only from quoted work, with the limit named, plus a ramp plan | Top, 5 questions (A) |
| Case/Strategist | Live roadmap problems: adoption, competing requests, discovery | High. The JD's responsibilities are live problems | Clarify, then objective, segments, approach, metrics, risks. Say the decision-rights question out loud | Top, 5 questions (B) |
| Data-Driven Prober | Counts the 30+, asks how roadmap-input work changed anything, asks the adoption baseline | Medium. E3 is medium confidence, and no adoption baseline is stated | Say how you counted, which assumption you would defend least, and say plainly when you do not know | 3 questions (C) |
| Pressure | "Why hire you into a PM role without PM experience?" | Medium. The gap is the strongest hook, and the loop is unknown | Hold the adjacent work through two follow-ups, then concede the roadmap gap | 3 questions (D) |
| Conversational | Opener, biography, and a casual question about the R3 scenario | Low to medium. Opening register, but scored | 90-second arc from quoted work only | 2 questions (E) |

## Question banks

Provenance comes first. Each cell's claims about you rest on the quote in its row.

### A. Skeptic (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] dossier `likely_interviewer_objections`; negatives sourced by `prohibited_claims`: "Having held a product manager title or role"; "Having owned a product roadmap" | Open with the plain acknowledgment: "I haven't held a product manager title or role." Then the adjacent work at its scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live," and "Ran quarterly roadmap-input sessions feeding client evidence to product." Hold that this work is the basis for the hire, through two follow-ups, by returning to those quotes. Concede: "I haven't owned a product roadmap, and decision rights are what I'd ramp on first." Do not say you are ready to own a roadmap. | The dossier named this objection, so it is the highest-ROI prep. The deepest rehearsal goes here: three follow-up levels, and the concession worded in advance. |
| A2 | "Which of your past work is closest to product management, and where does it stop?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; "Wrote the internal integration playbook her team uses" | Name the closest piece in those words. Then say where it stops: it feeds product, and it does not set what product builds. Answer slot: if you set any roadmap priority, say which and how you decided. If you did not, say so plainly, and stay with the roadmap input. | Open prompt on R1 (the JD's "3+ years product management experience" as the raising source). F1's bridge carries the limit. |
| A3 | "Tell me about an API or platform product you shipped, and your part in shipping it." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Give the integration work at its scope: scoping, requirements, architecture, UAT, go-live. Answer slot: if you shipped an API or platform product of your own, name it and your part. If not, say so plainly, then name the nearest integration you led and what you did on it. | Open prompt on R2 (the JD's "Shipped API or platform products"). F2 is the adjacent case, not a shipped product. |
| A4 | "Tell me about a time a client, a sales lead or an engineer disagreed with a plan you were running." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Tell one disagreement from client integrations, at that scope, in your own words. Answer slot: if you worked through a disagreement with sales or with engineering, say how it went. If you did not, say so plainly and stay with the client case. | R4 asks for three audiences. The material shows clients, not sales. Keep the answer inside what the quote carries. |
| A5 | "What does agile delivery mean to you, and how do you run it with an engineering squad?" | JD | [generic] R5, the JD's "Agile delivery experience" | Clarify slot: say how you define agile delivery in your own words. If you have worked in sprints or with an engineering squad, say how. If you have not, say so plainly and say what you would want to confirm about how these squads work. | R5 is the discovery gap, and the dossier's clarify strategy applies. No quote speaks to it, so there is nothing to bridge. |

### B. Case/Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner's integration team says the API is hard to adopt. What do you need to know before you propose anything?" | CASE | [generic] | Clarify first: which partners, which integration stage, what "hard" means to them. Then objective, segments, approach, metrics, risks. Say the one premise you would test first. | A live problem from the JD's partner discovery. It needs no claim about your past. |
| B2 | "Partner API adoption is flat this quarter. Diagnose it." | CASE | [generic] | Say the diagnosis needs a baseline. Ask how adoption is counted today before you name a cause. Then segments, then approach. Do not invent a baseline or a number. | The JD names adoption metrics as a responsibility, and the dossier says no current baseline is stated. The honest first move is to ask for it. |
| B3 | "Two partner requests compete for the same engineering squad next quarter. How do you decide?" | CASE | [generic] | Name your criteria. Then say which part of this decision is yours and which belongs to the squad leads. Say you would confirm that before choosing. Do not claim decision authority. | This is the authority unknown in the dossier. The question tests whether you know where your decision rights stop. |
| B4 | "Sketch how you would run discovery with integration partners in your first 60 days." | CASE | [generic] "Run discovery with integration partners" (JD responsibility) | Plan, not history. Choose partners by integration stage. Set the questions before the calls. Say what you would do with the answers, and who you would bring them to first. | Responsibility from the JD, asked as a plan. Keeps the answer off your past. |
| B5 | "Which single metric would tell us the platform is working for partners, and what would you not trust about it?" | CASE | [generic] "Define and track adoption metrics" (JD responsibility) | Name one metric and the weakest assumption behind it, before the interviewer does. Say what counts as adoption in that metric, and that you would confirm the current baseline first. | Metric question on the JD's adoption requirement. The weakest-assumption move is the credibility move here. |

### C. Data-Driven Prober (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ integrations. How did you count them, and what counted as one?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot on the figure: say how you counted, in your own words. Name the assumption you would defend least. Say which of the 30+ you led end to end. If you do not know exactly how it was counted, say so plainly. | "30+" is a headline figure. The defend-the-number slots apply. The pack supplies no counting method. |
| C2 | "What happened to the client evidence from your roadmap-input sessions, and how would you know?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Say what you brought to product, how often, and to whom. Volunteer the limit before it is extracted: the proof for these sessions is limited, and you can show that you ran them. Answer slot: if you can show a roadmap item that changed because of them, name it. If you cannot, say so plainly. | E3 is medium confidence, and the dossier says to expect a probe. Coach the limit to be volunteered. |
| C3 | "How would you check that partner adoption is counted the same way across integrations?" | JD | [generic] "Define and track adoption metrics" (JD responsibility) | Name the definition you would confirm first: which integration counts as adopted, and over what window. Say you do not know the current baseline and would confirm it before setting a target. | The JD's adoption requirement, and the dossier's unknown about baseline. |

### D. Pressure (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 30+. How much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the quote: you led them end to end. Answer slot: say which parts were yours to set and which belonged to the team. If you cannot split it, say so plainly. Hold through two follow-ups. | Pressure on the headline figure. Attribution at the quote's own scope. |
| D2 | "I don't see product management anywhere in your background. Why are we the place to learn it?" | JD | [grounded] dossier `prohibited_claims`: "Having held a product manager title or role"; "Having owned a product roadmap" | Hold the adjacent work: "Ran quarterly roadmap-input sessions feeding client evidence to product." Concede: "I haven't held a product manager title or role, and roadmap decision rights would be my first ramp." Hold through two follow-ups, then concede the specific gap. Do not fold on the adjacent work. | Pressure on R1. The position held is the one the quotes carry. |
| D3 | "Name one thing from an integration that reached product." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Name one item, in your words, from the roadmap-input sessions. Answer slot: if you cannot name one, say so plainly and describe what you brought to product. | A premised question. The premise is the quote's own: client evidence fed product. The second branch allows that nothing changed. |

### E. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through your path to this role, in about ninety seconds." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Scripted 90-second arc: the integration work at its scope, the playbook, the roadmap input, then the limit in one sentence. End on the role you want, in your words. | The opener is scored. The arc is built only from quoted work. |
| E2 | "A partner's integration breaks after a REST schema change. What do you check first?" | CASE | [generic] "Technical fluency: API docs, schemas" (JD requirement R3) | Structure it: which partner and which change, whether the change was documented, what the API docs and schema say, what you would test before you tell the partner. Do not claim schema work you did not do. | R3 has no quote that shows schema work. This question tests the reasoning, not the past. |

## Coverage

| JD requirement | Questions | Notes |
|---|---|---|
| R1: 3+ years product management (must) | A1, A2, D2, D3 | Covered. The gap is named each time. |
| R2: Shipped API or platform products (must) | A3, B4 | Covered. |
| R3: Technical fluency, API docs and schemas (important) | E2, F3 | Covered as a case. Your past is answered in the slot only. |
| R4: Stakeholder management, engineering, sales, customers (important) | A4, B3 | Clients and engineering. Sales: not covered. The material shows no sales work, and no question is written for it. |
| R5: Agile delivery (preferred) | A5 | Clarify, as the dossier directs. |
| Unknown: decision authority vs squad leads | B3, A1, RQ1 | Covered. |
| Unknown: adoption metrics and baseline | B2, B5, C3, RQ2 | Covered. |

Session total: 18 questions (A 5, B 5, C 3, D 3, E 2).

## Reverse questions

Five questions. None has a profile to tie to, so none is tied to the interviewer's own path.

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | This is the dossier's authority unknown. The answer sets the honest limit for every bridge in the pack. |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | This is the dossier's adoption unknown. Your answer to B2 and C3 depends on it. |
| RQ3 | "What does a good first 90 days look like for this role?" [generic] | Converts the ramp plan into their definition of success. |
| RQ4 | "Where does partner input go today, and how often does it change a roadmap decision?" [generic] | Tests whether roadmap input is an existing process. If it is, you can say how your work would plug in. |
| RQ5 | "What is the biggest risk to the platform roadmap over the next two quarters?" [generic] | Tests the risks the dossier lists, and shows you are thinking about the platform, not only the job. |

## Sources

- **Provided:** `tuesday-dossier.md` (dossier_version 1.1, major version 1, read in full). Consumed: `role_profile` (requirements R1 to R5, unknowns), `handoff_to_mock_interview` (verified evidence, weak areas and strategies, objection, risks, employer questions, prohibited claims). `decision` was read as context only. No `evidence_map` or `evidence_state` was present.
- **Research:** one web search was attempted (`Quartzline Platform APIs product manager partner API`, standard mode). The host refused it. No fetches ran.
- **Research tier:** L1 requested by default. Searches 0 of 6 (one refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Values cheat sheet. Not built, since no values round was detected. The search was not sent for this target, so no query is listed. |
| 2. `Quartzline interview process product manager` | unavailable | Loop structure. Persona weights use relationship priors, not a loop source. |
| 3. `Quartzline strategy` / recent news | unavailable | Grounding brief and CO bank. Neither was built. Refused query: `Quartzline Platform APIs product manager partner API` (refused). |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form. |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` fixes the requirement set and the JD-tagged questions. |

## Upgrade menu

- The interviewer's name, or a link to their public profile → persona weights and a reverse question tied to their own path.
- Web search access in a later session, or the company's own careers or strategy page pasted here → a company-strategy bank (CO) and a grounding brief.
- The recruiter's note on the round format → whether the 45 minutes includes a take-home or a graded piece. None is in the material now.
- The dossier's `evidence_map` → confidence grades for F2 and F4, which the handoff does not grade.
- A raw CV line behind the integration work → a `[grounded]` upgrade for F2 beyond the dossier's entries. The dossier's `verified_candidate_evidence` is the only source for those quotes now.
