# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** Second round, panel, 60 min. Deepa (VP Partnerships, future manager) and Ross (Commercial Director).
**Structure:** First 15 min is a spoken POV, no slides, on where you'd take operator partnerships over 18 months. It must land on what it means for the operators. The remaining time is Q&A, and Ross will push on commercials.
**Research tier:** L0. Provided material only: your message, the recruiter's email, and the internal market report (read by you, not pasted here). No web research has run. Sector statements below are marked `[generic]` and must be checked against the report before Tuesday.

## How to use + type key

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **VAL** values alignment · **EXP** experience deep-dive · **JD** role-driven · **CO** company and strategy · **CASE** live problem
- Guidance is scaffolding, not a script. Speak it in your own words, in 90 to 120 seconds.

## Prep triage (about 4 hours)

1. **Hour 1: the POV spine.** Write the three theses in section 5 in one page each. Mark each concession out loud. Check each thesis lands on an operator benefit (A0).
2. **Hour 2: Ross's commercial bank.** Drill A1 to A5 aloud, especially the no-quota answer (A2). This is the highest-risk exchange.
3. **Hour 3: Deepa's bank.** Drill B1 to B4, centred on the 6-to-40 story and the first-90-days answer.
4. **Hour 4: timed run.** Deliver the 15-minute POV once, recorded, with a timer. Then run ten minutes of Q&A with a friend. Fix the two weakest answers and stop.

Everything else is insurance.

## Fit snapshot

No JD was supplied. Requirements come from the recruiter's own words (quoted, `[grounded]`) or are role-family prose (`[generic]`, no quote, no answer slot).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The partner-building record is in payments ISVs, not operators. Say what carries over (recruiting, enabling and running partners at scale) and say plainly that operators are a different buyer. |
| F2 | "what it means for the operators themselves" — recruiter email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | You know the operators' planning problems from advising them. The material does not show you have sold to them or sat in their buying decisions. Keep the two apart. |
| F3 | Commercial pressure: Ross "will push on commercials" — recruiter email | "Never sold into rail specifically and never carried a direct quota, only influenced revenue" — your message | high | [grounded] | capability | Words: "I've never carried a direct quota, and I've never sold into rail." Then how you would test your commercial read before you own a number. Never a claim to quota or closed rail deals. |
| F4 | "18 months" plan with a sales target — `[generic]` | none given | none | [generic] | discovery | Answer slot: what the first 90 days would be, and which metric you would commit to. Only your own words may fill this. |
| F5 | Use of the internal market report — recruiter email | none given (you have read it; its contents are not in this conversation) | none | [grounded] | discovery | Answer slot: which two findings from the report you would build the POV on, and where it conflicts with your operator experience. |

## Graded deliverable: the 15-minute POV

Build sections. Each thesis carries a mandatory concession. The close must state the operator benefit (the recruiter asked for it).

**Consensus answer (the one to avoid):** "Operators need better timetable-change tooling and disruption recovery, so we partner with them and integrate." Do not lead with this, and do not say "digital transformation."

**Thesis 1: operators are paid for performance and penalty avoidance more than for software.** `[generic]` Many operator contracts carry performance-linked payment regimes, so the partnership value is in reducing penalty exposure, not in a feature list.
- Concession: I'm inferring the penalty exposure from how these contracts generally work. The report may show it differently, and I'd test that before relying on it.
- Operator benefit: fewer penalty minutes after timetable changes and fewer cancelled services during disruption.

**Thesis 2: the budget sits with the contract owner, so the partner case has to be one the operator can take upstairs.** `[generic]` Operators often manage services under government contracts, so they need a business case the funder will accept.
- Concession: the buying chain is an inference. I haven't checked how Kelverton's current deals were approved.
- Operator benefit: an operator gets a cost and risk case it can defend to its funder without needing new budget of its own.

**Thesis 3: integration across the network matters more as operators consolidate or move to public ownership.** `[generic]` Partners who can deliver one standard across several operators become more valuable as the operator base changes.
- Concession: consolidation could also push operators to build in-house, and then the partner role shrinks. I'd say that as a risk, not a reassurance.
- Operator benefit: one set of tools and one process across a changing operator estate, without a rebuild every time an operator changes hands.

**Differentiation:** give the operator benefit as a number or named outcome in each thesis, not as a feature. The consensus answer does not do this.

**Anti-pick:** do not frame the POV as a partner-recruitment plan. Deepa is buying a view of the operators, not a channel plan.

## Persona table

| Persona | How it shows up | Likelihood (reasoning) | Counter-strategy |
|---|---|---|---|
| Commercial skeptic (Ross) | Presses on quota, margin and attribution; asks for numbers you have not owned | High. The recruiter named commercials, and your record is influenced revenue only | Concede the gap early, then show how you would test the commercial read. Use A2. |
| Hiring manager (Deepa) | Probes how you would build and run the operator motion; asks about team shape and the first 90 days | High. She is the future manager and owns the outcome | Answer with a sequence (listen, test, commit), not a plan. Use B1 to B3. |
| Operator-literate probe | Asks about timetable changes, penalties or Network Rail interfaces | Medium. Either panellist may test the consulting background | Stay with what you saw from the planning side. Use A4. |

## Question banks

Ordered by weight. Each row: question, type, provenance, guidance, rationale.

### Bank A: Ross (commercial)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A0 | "Walk us through the POV: where would you take operator partnerships, and what does it mean for operators?" | CO, CASE | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Open with the operator benefit, then the theses. Keep to 90 seconds per thesis. | This is the graded deliverable. |
| A1 | "How would you size the operator opportunity?" | CASE | [generic] | Build from the operators you could reach and their contract structure. Name the assumptions and say which one you would test first. | Tests structure under commercial pressure. |
| A2 | "You've never carried a quota. Why should we believe you can close operator deals?" | JD, EXP | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Concede directly. Then say what you did own: the influenced-revenue number and how it was measured. Say how you would test the commercial read in the first quarter. Do not claim closed deals. | Highest-risk exchange. The honest answer is the strongest one here. |
| A3 | "Your £4M is influenced revenue. What share of that did you actually source?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Say what influenced means in your last role, and how it was attributed. If you cannot split sourced from influenced, say so. Never convert it to sourced. | Attribution honesty. |
| A4 | "What does an operator pay for, and how does that change your partner margin?" | CO, CASE | [generic] | Name the buyer and the payment logic, labelled as inference until checked against the report. Say what you would need to know to set a margin. | Operator procurement economics. |
| A5 | "What would you do if an operator asked for a discount to renew?" | CASE | [generic] | Structure: what the discount buys, what it costs, and what you would trade for it. Do not commit to a number. | Commercial judgement under pressure. |

### Bank B: Deepa (hiring manager)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you do in your first 90 days?" | JD | [generic] Answer slot: no candidate sentence yet covers this | Sequence: listen to the team and the top operators, test the commercial read, then commit to one metric. Say which early decision you would not make. | The recruiter's 18-month framing makes this likely. |
| B2 | "How have you built partner programmes, and what did you learn about running one from zero?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Tell one story with a named decision and a named mistake. Say what you would do differently with operators, where the buyer is different. | Tests real ownership of the 6-to-40 build. |
| B3 | "A partner is also a competitor. How do you handle that?" | CASE | [generic] | Separate the co-sell from the data and product boundaries. Say what you would write down before signing. | Common in rail and payments channels alike. |
| B4 | "Tell us about a partner relationship that failed. What did you do?" | EXP | [grounded] "took it from 6 partners to 40" (your message); the failure itself is an answer slot | Pick a real failure from your own record. If none is in your record, say so and describe the pattern you watch for. | Probes self-awareness. Do not invent a failure. |

### Bank C: Operator-literate probes (either panellist)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you explain a timetable change to an operator who has just had penalties?" | CO, JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | Speak from the planning side: what you saw, not what you sold. Name the penalty logic as your understanding, and check it. | Tests whether the consulting background is real. |
| C2 | "Where do Network Rail and the operator's own systems meet in your view?" | CO | [generic] | Keep it at the level you can defend. Say where you would ask an operator to show you. | Tests how far the knowledge goes. |

## Prohibited claims

These are the claims this pack will not coach, because the material does not support them.
- **Rail or operator sales experience.** You have never sold into rail. Do not imply you have.
- **Quota attainment or closed deals.** You carried no direct quota. Do not say or imply otherwise.
- **Sourced revenue.** The £4M is influenced revenue. Do not call it sourced, closed or booked.
- **Insider knowledge of Kelverton.** Do not claim knowledge of its product internals, its current deals or its team beyond what the panel tells you.
- **Operator buying-committee experience.** Your consulting work was on the planning side. Do not describe it as buying experience.

## Reverse questions

1. "Are Deepa and Ross measured on the same partnership number, or on different ones?" *Why it lands:* shows you understand commercial alignment, and tests whether the quota expectation is clear.
2. "How much of current revenue runs through operators today, and how much through partners?" *Why it lands:* sizes the role and shows you are thinking in revenue terms.
3. "Where does partner-sourced revenue get attributed, and who owns that decision?" *Why it lands:* tests the influenced-versus-sourced issue directly.
4. "Is any direct quota expected in this role, and is that expected to change?" *Why it lands:* the honest question on your biggest gap. Ask it plainly.
5. "How does the strategy team's view of operators compare with what the operators say they need?" *Why it lands:* signals that you have read the report, without quoting it.

## Sources

- Provided: recruiter email (quoted above); your message with background; the internal market report, read by you and not reproduced here.
- Research: none run. Sector statements are `[generic]`.
- **Target accounting:** Research tier L0. Company values, loop structure and current strategy are unverified. Interviewer public footprint: not researched (names only).

## Upgrade menu

- **The market report's key findings (two or three sentences each)** → the POV theses rebuilt on Kelverton's own numbers, and the `[generic]` rows become `[grounded]`.
- **The JD** → the fit snapshot gets real requirements, and the first-90-days answer gets a source.
- **The interviewers' public profiles** → persona weights for Deepa and Ross, and a tailored reverse question.
- **A research pass (L1, at most 6 searches and 2 page fetches)** → checks the operator contract and penalty claims in Theses 1 and 2.
