# Ashgrove Credit Union: Member Experience Lead interview pack

**Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
**Rounds, 3 December 2026:** (1) recruiter, 30 min; (2) Head of Member Services, your future manager, 45 min, mostly behavioural; (3) panel of two branch managers, 60 min, including a 20-minute complaint-escalation case, scored against the four values.
**Interviewer names:** not yet known, so there is no interviewer read and no personal persona weighting yet.
**Built on:** the JD text you pasted, the values page copied 24 November 2026, the recruiter's email, your summary of the July 2026 strategy brief, and your background message. No CV and no dossier were provided.

---

## 2. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** VAL = values and behaviour. EXP = work-experience deep-dive. JD = role requirement. CO = company and strategy. CASE = live problem.
- **Guidance is scaffolding, not a script.** Say it in your own words. Where it says "answer slot", answer from what actually happened, including "it was not mine" or "I have not done that."
- **Provenance** shows which of your own sentences a claim rests on. If a sentence is not quoted, the pack is not claiming it about you.

---

## 4. Fit snapshot

Your material is your message, not a CV, so every evidence quote is from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end. Words: "I handled the branch's formal complaints log." Answer slot: if you owned any step beyond the branch log, say which and how you decided; if you did not, say so plainly and stay with the log. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material shows formal complaints handled; it does not show whether they ran to a regulator's timelines. Words: "I handled the branch's formal complaints log." Answer slot: if formal complaints ran to a regulator's timelines, say which; if not, say so and say what you would check first. |
| F3 | "4+ years in financial-services customer operations" (JD, gate) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | high | [grounded] | none | The gate is shown met. Words: "6 years in retail banking, the last 3 as a branch supervisor." Say "retail banking" in your own words; whether branch work counts as customer operations is the panel's call. |
| F4 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A stated absence, so the pack gives back your words and no more. Words: "I've never presented to anyone above regional level." Then how you would learn it, as a plan and never as a past. |
| F5 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A stated absence. Words: "I've never worked in a contact centre." Then how you would learn the contact centre, as a plan. |
| F6 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Say the spreadsheet in your own words, and name the tool if it was Excel. |
| F7 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | Monthly reporting is shown; volumes and resolution times are not. Answer slot: if resolution times were in the spreadsheet, say how they were measured; if they were not, say so and say what you would add first. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | low | [inferred] | transferability | Teller training is adjacent to coaching supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you coached anyone above teller level on escalations, say whom and how; if not, say so and say how you would start. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if you have worked on a digital journey, say what you did; if not, say so plainly and say how you would work with a digital team on one. |

**Gap-type routing note:** F3 is a gate the material shows met, so it routes by its evidence like any other row. F4 and F5 are stated absences, so they are `capability`. F7, F9 are silent, so they are `discovery`. F1, F2, F8 are adjacent work that does not reach the requirement, so they are `transferability`.

---

## 6. Grounding brief

The strategy brief was supplied as your summary, not as the document. Check it against the original before 3 December.

- **Vocabulary to use:** "member service", "digital channels", "hubs", "self-service journeys".
- **Headline points:** 40% of member service to digital channels by 2028. Eight branches consolidated into five hubs over 2027. A small-business lending product in Q1 2027. Main competitive pressure from app-only banks.
- **Sensitive point, read this first:** the consolidation of eight branches into five hubs is the item most likely to land on the panel personally. Two branch managers may run branches in this plan, and your future manager is the one who would carry it out. Do not criticise the plan, and do not claim you agree with it unless you can say why. You have not managed a branch merger; do not imply that you have.
- **Digital shift:** the JD asks you to work with digital teams, and your material is silent on digital work (F9). Keep the answers to the plan you would follow, not to experience.
- **Small-business lending:** nothing in the JD or your material connects to it. Treat it as insurance only.
- **Do not coach you to correct an interviewer's framing.** If a panel member describes the strategy differently from the brief, use the brief's words and move on.

---

## 8. Persona table

Weights start from the round-type priors for each round, then adjust for the loop. There are no named interviewers, so the weights apply to the whole loop.

| Persona | Round(s) | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|---|
| Conversational (E) | 1, recruiter | Friendly opener, logistics checks: pay, notice, location, reason for leaving | Certain. A recruiter screen always checks these, and the first 30 minutes sets the record for the rest | Short, complete answers. Give logistics in one sentence each. Treat the chat as scored | 5 |
| Values/Behavioral (A) | 2 and 3 | Behavioural prompts; the panel scores against four named values | Very high. Round 2 is mostly behavioural, and round 3 is the values round | Map a real story to each value, or say plainly where none exists | 5 |
| Skeptic (B) | 2, and any round | Probes the gaps: contact centre, presenting, coaching, reporting, digital | High. Three JD requirements are stated gaps or silent in your material | Rehearse the contact-centre question until it is calm. Hold, plan, concede | 5 |
| Case/Strategist (C) | 3 | The 20-minute escalation case, and a strategy question | Certain in round 3. Expect the case to take most of the round's time | Clarify, then structure, then think aloud | 3 |
| Peer Evaluator (D) | 3, branch managers | Seam and turf questions about their branches, and whose complaint it is when it spans two | Medium-high. The panel are peers to the role; their branches are part of the plan | Offer what you bring to their branches before what you need. Name the seam as a principle, not as knowledge you lack | 2 |
| Pressure (F) | 2 or 3 | Time-boxed challenges on the contact centre and on consolidation | Medium. Likely on the two stated absences and on the sensitive strategy point | Pause, restate, hold the position the record supports, concede the specific gap | 2 |

**Weighting reasoning:** the recruiter round is a Conversational screen with logistics checks, so E is weighted high in that round. The Head of Member Services round is behavioural, so A rises above the Case weight you would expect from a hiring manager. The panel is values-scored and includes peers, so A and D carry round 3, with C carrying the escalation case.

---

## 9. Question banks

Session total: 22 questions. Highest-weight persona first.

### E. Conversational / recruiter (round 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through your background in a couple of minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); "I handled the branch's formal complaints log" (your message) | Ninety-second arc in the order your quotes give: six years in retail banking, the last three as a branch supervisor, then the formal complaints log you handled. Say the rest only if asked, in your own words. | F3 meets the years requirement and F1 is the nearest complaints evidence. EXP because the recruiter will read the CV against your answer. |
| E2 | "What is your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in one sentence. | Notice is a logistics question on the recruiter screen. No past claim is made, so nothing needs a quote. |
| E3 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give your own figure in one sentence, or ask first what the band for the role is. Do not give a range you have not decided. | Pay is a logistics slot. Your material states no figure, so none is supplied. |
| E4 | "Where are you based, and how often could you be in an office?" | JD | [generic] | Logistics slot: say where you live and the office pattern you can work, in your own words. | Location is a logistics slot. The office pattern will come from the recruiter. |
| E5 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: give the true reason, in your own words, in one or two sentences. Nothing here supplies one. | Reason for leaving is a logistics slot. Your material does not state it. |

### A. Values / Behavioral (rounds 2 and 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about a time you had to tell a senior person something they did not want to hear." | VAL | [generic]; nearest material: [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold: pick a time you told someone senior an unwelcome truth. It needs a named stake, a moment you did not back down, and a working relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries: the complaints you logged and handled, in those words. | A persona stem. No sentence of yours carries this story, so the guidance is a scaffold with its honest branch. |
| A2 | "Tell me about a time you stayed with a complaint until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Story map: the log carries that you handled formal complaints on it. Answer slot: if you took one case from the log through to resolution yourself, walk the steps you took in your own words. If the case was handed on or closed by others, say so and describe the part that was yours. | Maps to Own the Fix. F1 is the evidence; the answer slot keeps the story to what the log carries. |
| A3 | "Tell me about a complaint where the member's side changed what you decided." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold: pick a formal complaint where what the member needed moved your decision away from your first answer. Name the member's need, what you decided, and what you did. If no such case comes to mind, say so, and say how you check which side of the counter a decision comes from. | Maps to Members First. The log is the nearest sentence, so the guidance supplies no ending. |
| A4 | "When did you look past the figures on a complaint to what was happening in the branch's town?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Selection scaffold: a time the local situation in a branch changed how you read its complaints. If none comes to mind, say so. If the figures come up, say in your own words what the spreadsheet counted. | Maps to Neighbours, Not Numbers. The spreadsheet is the panel's most likely hook for "numbers", so F6 is where this answer is grounded. |
| A5 | "Tell me about a time you changed how something was explained to someone." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Story map: you trained tellers on the escalation script. Answer slot: if you changed how the script was explained to tellers or members, say what changed and why. If you did not, say so and describe the training you gave. | Maps to Plain Words. F8 carries the training; the answer slot keeps the change to what it did. |

### B. Skeptic (round 2, and any round)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never worked in a contact centre. How would you run complaints that come in through one?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I've never worked in a contact centre." Then a plan, said as a plan: before changing any process, spend time in the contact centre's complaint queue to see how complaints arrive and where they stall. Hold through two follow-ups: you have not worked in one, and you would learn it first. Concede specifically: volumes, call-handling systems, and staffing are what you do not yet know. Do not fold on "you could do it anyway." | **Highest-ROI prep in this pack.** The JD names the contact centre in its headline duty, and your material states the absence (F5). Expect it in some form. |
| B2 | "You have never presented to anyone above regional level. How would you present a monthly complaints report to a senior leadership team?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Plain acknowledgment: "I've never presented to anyone above regional level." Then the plan: one page, one decision asked for, rehearsed first with your regional manager. Say what you would do, not what you have done. | F4 is a stated gap. A plan answer shows how you would learn it. |
| B3 | "A branch supervisor you coach sends escalations a day late, most weeks. What do you do?" | JD | [grounded] "trained new tellers on our escalation script" (your message) | Answer slot: if you coached a supervisor on escalations, say what you did and what happened, in your own words. If you have not, say so plainly, then say how you would start: find out why, go through the script with them, and agree a date for the next check. Do not claim a result. | Covers the coaching requirement. F8 is low confidence, and the tellers' script is the only escalation training your material states. |
| B4 | "Walk me through the monthly complaints report you built. What does it count, and how sure are you of it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Defend-the-number slot: say in your own words what the spreadsheet counts. Weakest-assumption move: name, before they do, the assumption you would defend least. Answer slot: if resolution times are in it, say how they are measured; if not, say so and say what you would add first. | Covers the reporting requirement and Excel (F6, F7). Resolution times are not in your material, so that half is an answer slot, not a claim. |
| B5 | "Have you worked on a digital self-service journey? If so, what did you do?" | JD | [generic] | Answer slot: if you have worked on a digital journey, say what you did in your own words. If not, say so plainly and say how you would work with a digital team on one: start from the member's complaint route, and agree which points in the journey must hand over to a person. | The JD names digital self-service and your material is silent on it (F9). Discovery, so the answer slot carries both branches. |

### C. Case / Strategist (round 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | Illustrative escalation case, the real case will differ: "A member has complained about the same fee three times. Their latest message says they are moving their account to an app. You have 20 minutes: what do you do?" | CASE | [generic] | Think aloud in this order: clarify what happened, which regulator timelines apply, and whether the member is vulnerable. State the member's need in their own words. Name yourself as the one owner until it is solved. Set a plain-words update with a date. Check whether the same fee has hit other members. Name what you would measure and what you would tell the branch. Challenge one premise you think is wrong, respectfully. Treat the app move as the member's decision, not something to win back by pitch. | A live problem from the escalation case the recruiter describes. It asks about no past, so it claims nothing about you. Scores Own the Fix and Members First. |
| C2 | "Which regulatory timelines would govern the complaints you'd own here, and how would you track them?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Answer slot: say which timelines applied to the formal complaints you handled, in your own words. If you did not track them against a timeline, say so plainly and say how you would set up that tracking. Do not name a timeline you were not working to. | Covers regulated complaints (F2). The answer is about what the log carried, and the honest branch is the limit. |
| C3 | "Our strategy moves 40% of member service to digital channels by 2028. What does that mean for complaints?" | CO | [grounded] the strategy brief, July 2026, as you summarised it (no sentence of yours) | Say what changes for complaints, in your own words: which complaints move to a digital route, who keeps hold of them, and what reaches a person. Use the brief's target as stated, and add no figure. | The most likely CO question. Your material says nothing about digital work, so the answer rests on the brief and on reasoning about the role, not on your past. |

### D. Peer Evaluator (round 3, branch managers)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our branches are part of their towns. One of our branch managers says they should keep their own complaints. What do you say to them?" | VAL | [generic] | Reciprocity: say what you would bring their branch, such as escalation support and a plain-words template, before what you would need from them. Propose a principle for where a complaint sits, not a process you have not seen. Say you do not yet know the seam and how you would find it. | Peer seam question under Neighbours, Not Numbers. Nothing in your material shows this exchange, so the guidance claims nothing about you. |
| D2 | "When a complaint spans two branches, whose complaint is it?" | VAL | [generic] | Say that whoever finds the problem keeps hold of it until it is solved, then name who signs off the handover. Say how the two branches would share the update the member receives. Use a past case only if one is in your log, and if so use A2's quote. | Own the Fix as a seam question. The peer's real test is whether the hire adds to their load or removes it. |

### F. Pressure (rounds 2 or 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why should we hire you over someone who has worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message); "I handled the branch's formal complaints log" (your message) | Pause and restate the question. Hold: you handled formal complaints on a branch log, and you would learn the contact centre first. Plain acknowledgment: "I've never worked in a contact centre." Concede specifically: the contact centre is what you know least, and you would say so on day one. Hold through two follow-ups. Do not fold on "you're the best choice." | The timed version of B1. The held position is the one the log carries. |
| F2 | "The strategy consolidates eight branches into five hubs over 2027. How do you keep complaints from getting worse while that happens?" | CO | [grounded] the strategy brief, July 2026, as you summarised it (no sentence of yours) | Pause. Do not criticise the plan, and do not claim you agree with it. Name the risk you would watch and one thing you would measure. Answer slot: if you have handled complaints through a branch change, say what you did in your own words. If you have not, say so plainly, then say how you would keep the member's side in view. | Sensitive: the panel are branch managers and may run branches in this plan. The question tests consistency of stance. It makes no claim about your past. |

---

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches and the contact centre | A2, B1, D2, F1 |
| Report monthly on complaint volumes and resolution times | B4 |
| Coach branch supervisors on escalations | B3 |
| Work with digital teams on self-service journeys | B5, C3 |
| 4+ years in financial-services customer operations | E1 (gate met, F3) |
| Experience handling regulated complaints | C2, A2 |
| Confident presenting to senior leaders | B2, F1 |
| Comfortable with Excel reporting | B4 |

---

## 10. Values cheat sheet

Only the four published values, as the round-3 panel will score them.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No sentence of yours carries a decision story. Selection scaffold: pick a formal complaint from your log where the member's side changed your decision. If none comes to mind, say so, and say how you check which side a decision comes from. (A3) |
| Plain Words | If a member needs it explained twice, we wrote it wrong | F8: "trained new tellers on our escalation script" (your message). Selection scaffold: a time you changed how something was explained. If none, say so and describe the training you gave. (A5) |
| Neighbours, Not Numbers | Every branch is part of its town | No story carried. Selection scaffold: a time a branch's local situation changed how you read its complaints. Expect the panel to press on the spreadsheet (F6). Say what it counted. (A4) |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log" (your message). Selection scaffold: a complaint you kept hold of until it was solved. If the case was handed on, say so and describe your part. (A2) |

**Escalation case (round 3, 20 minutes):** the case is scored against Own the Fix and Members First (C1). Rehearse it aloud with a timer. The first two minutes are clarify and name the member's need; the rest is one owner, a dated update, and what you would measure.

---

## 11. Reverse questions

No interviewer profile exists yet, so none ties to a career path. Add the names and this will change (upgrade menu).

1. **To the Head of Member Services:** "What would you need the monthly complaints report to answer in its first quarter that it cannot answer now?"
   *Why it lands:* ties your spreadsheet to their decision use, and shows you read reports as tools.
2. **To the Head of Member Services:** "Where does a complaint most often stall between a branch and the contact centre today?"
   *Why it lands:* shows you think end to end, and asks where the seam is before proposing a fix.
3. **To the Head of Member Services:** "What does a good first six months look like in this role?"
   *Why it lands:* a standard question, but a scored one. Listen for the measure they name, and use it in the next answer.
4. **To the Head of Member Services:** "How do complaints figure in the digital self-service plan?"
   *Why it lands:* shows you know the 40% target and see complaints as part of it, without criticising the plan.
5. **To the panel (peer reciprocity):** "What could a new person do in their first month that would genuinely help your branches?"
   *Why it lands:* turns the interview toward their needs. This is the peer reciprocity question.
6. **To the panel:** "When a complaint is escalated from your branch, what do you wish had reached you sooner?"
   *Why it lands:* shows you think about escalation from the branch's side, which is the panel's own experience.

Do not ask about branch consolidation unless the Head of Member Services raises it first.

---

## 13. Prohibited claims

Built locally from the fit snapshot. Each entry is a claim this pack will not coach, with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 | "I handled the branch's formal complaints log." Limit, in the pack's analysis: your material says the log, not the process, and nothing about the contact centre. A2 and C2 stay inside the log. |
| Coached branch supervisors on escalations | Inflated form of F8 | "I trained new tellers on our escalation script." Limit: your material says tellers, not supervisors. B3 stays in its answer slot. |
| Reported monthly on resolution times | Inflated form of F7 | The spreadsheet you built, at its own scope. Limit: your material does not say it held resolution times. B4 asks only what it held. |
| Designed the regional complaints reporting | Inflated form of F6 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Worked in a contact centre | Stated negative, F5 | "I've never worked in a contact centre." No answer slot. |
| Presented to senior leaders | Stated negative, F4 | "I've never presented to anyone above regional level." No answer slot. |

---

## 14. Sources

**Provided documents:**
- JD text, as you pasted it.
- Ashgrove values, copied from ashgrovecu.org/about/values on 24 November 2026.
- Recruiter email describing the three rounds.
- Strategy brief, July 2026, as your summary. The original was not provided.
- Your background, as a message. No CV was provided.

**Research:** no searches or fetches were run. Every target was covered by the inputs above.

**Research tier: L1, searches 0 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet, section 10. The values were pasted, so no search was needed |
| 2. Ashgrove interview process | skipped | Loop structure. The recruiter's email gives the three rounds |
| 3. Ashgrove strategy and recent news | skipped | The grounding brief. Your summary of the July 2026 brief covers the current priorities |
| 4. Interviewer name and Ashgrove | n/a | No names given, so there was no query to form |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

---

## 15. Upgrade menu

- **Panel names** (Head of Member Services and the two branch managers) → persona weights for each member, and a reverse question tailored to their public career.
- **The original strategy brief** → checks the grounding brief against the document, and corrects any figure I carried from your summary.
- **A case brief from the recruiter**, if one exists → C1 moves from [generic] to [grounded] and gets the actual facts.
- **Your CV** → the values cheat sheet gets quoted stories where the four selection scaffolds now stand, and the fit snapshot's evidence cells get more quotes.
- **The complaints measures your spreadsheet held** (volumes, resolution times, anything else) → B4 gets quoted material and its answer slot can be answered in your own words.
- **Deep research (L2)**: six further searches and two fetches, for the strategy brief itself, the interviewers' public talks, and recent Ashgrove news. Offered once; it runs only if you say so.
- **A `tuesday-dossier.md`** → carries verified evidence into any later round.
