# Operations Manager, Atlas Freight: interview prep pack

Role: Operations Manager (regional logistics, 800 employees). Company: Atlas Freight. Interviewer: not known. Round: not stated, so this pack is built for a hiring-manager round and every persona weight is set on that assumption.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior fits the company's published values |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what you actually did |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy | Homework depth; none was possible this session (see Sources) |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

Guidance is scaffolding, not a script. "Answer slot" lines are instructions for the interview, meant for the answer you give in the room. They are not questions for you to answer here.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message. Nothing here adds to what you wrote.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "ran the site's peak-season surge plan two years running" (your message); "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows one site and a shift-level role, not four sites. Your words: "ran the site's peak-season surge plan two years running." Answer slot: the four-site line makes a probe on multi-site ownership likely. If you coordinated work across more than one site, say how, in your own words; if you did not, say so plainly and describe how you would take on four. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows an accuracy metric, not on-time performance or cost per shipment. Your words: "cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time or cost per shipment, say which and how; if you did not, say so and name the metric you would start with. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors, and the JD asks for twelve. Your words: "currently a senior shift manager over 3 supervisors." Answer slot: if you have led people through supervisors beyond your direct three, say how; if not, say so and describe how you would build a twelve-supervisor structure. |
| F4 | "build reporting in Excel/Power BI" (JD), Excel half | "solid Excel" (your message) | medium | [grounded] | none | The Excel half is reached in role-relevant terms. Expect a probe on a report you have built; see A4 and C4. |
| F5 | "build reporting in Excel/Power BI" (JD), Power BI half | "never used Power BI" (your message) | none | [grounded] | capability | A gap you stated, so it can be acknowledged. Your words: "I've never used Power BI." Then a plan, said as a plan and never as a past: what you would build first in it and how you would learn it. |
| F6 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | low | [inferred] | discovery | Seven years is operations time, not years of leadership, and your material gives no start date for supervising. The requirement is not a gate, so it is graded on fit. Answer slot: state how long you have led people, from your own record, and the role you held at each step. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The requirement is reached in role-relevant terms. Expect a probe on what the Green Belt involved; see B5. |

Gap types used here: transferability (F1, F2, F3), capability (F5), discovery (F6), none (F4, F7). No row is a hard gate. Length of experience is not a gate under the suite's rules, so the five-year line is graded like any other requirement.

## Prohibited claims

Not coached in any cell of this pack, with the basis and the honest form for each.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns terminal operations across four sites | Inflated form of F1; your material shows one site | The F1 quote at its own scope. The limit is this pack's observation: your material shows one site. |
| Leads twelve supervisors | Inflated form of F3; your material shows three | The F3 quote at its own scope. The limit is this pack's observation. |
| Cut on-time performance or cost per shipment | Inflated form of F2; your material shows mis-pick rate | The F2 quote at its own scope. |
| Five years of operations leadership | Inflated form of F6; your material shows seven years of operations | The F6 quote at its own scope, and the answer slot for leadership years. |
| Led the pick-path redesign | Inflated form of "cut mis-pick rate 40% by redesigning the pick path"; the material does not say who designed it | The quote at its own scope. If you designed the path, say so; if you led a change others designed, say that. |
| Built or has used Power BI | Stated negative, F5 | The plain acknowledgment: "I've never used Power BI." |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Case / Strategist | Live operations problems from this role: a site slipping on on-time performance, a peak season arriving short of supervisors | High. A hiring manager buys capability and tests it on the roadmap. Top weight. | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. | 4 |
| Skeptic | Quiet probing of the scale gap, the four sites, and Power BI. "Where are you weakest on day one?" | High. Three gaps are visible from the JD against your material: scale, multi-site, and Power BI. Co-top weight. | Rehearse the most predictable objection until it is calm. Name the gap, then the ramp plan. Do not bluff. | 5 |
| Data-Driven Prober | Asks how the 40% was counted and which assumption you would defend least | High. The 40% is a headline number and the JD names Excel and Power BI reporting. | Know what you can and cannot say about how the figure was counted. Say plainly when you do not know. | 4 |
| Pressure / Stress | Time-boxed challenges to the scale and the credit for the 40% | Medium. Common for senior operations roles. | Pause, restate, hold through two follow-ups, concede specifically. | 3 |
| Conversational / Rapport | Friendly openers that still score the journey, the Excel work, and interest in the company | Low to medium. Casual questions are still scored. | A 90-second arc for the journey. Never answer the reverse-question slot with "I think you've covered everything." | 2 |

Total: 18 questions. The persona weights are a shown judgment, not a hidden score. If you know the round is a peer or panel, say so and they will be recomputed.

## Question banks

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A site's on-time rate has dropped for three weeks while cost per shipment rises. Where do you start?" | CASE | [generic] | Clarify first: what changed, when, and whether the drop is one site or several. Then set an objective, segment by shift, lane or customer, and name the two or three metrics you would check. Think aloud. Challenge one premise of the question. No claim about your past. | Live problem from the JD's on-time and cost line (F2's requirement). Generic: a pattern for the problem, not a fact about Atlas. |
| A2 | "You are responsible for four terminals on one network. What do you change in your first ninety days?" | CASE | [generic] | Structure: learn the four sites' baselines first, then the supervisor structure, then the one or two bottlenecks the data shows. Name what you would not change yet. Say the sequence aloud. | Tests the four-site line (F1) as a decision. Presupposes nothing about your past. |
| A3 | "How would you measure on-time performance and cost per shipment across four terminals?" | JD | [generic] | Define each metric before the target: cut-off times, what counts as on time, what goes into cost per shipment. Name where the data comes from and who owns it. Say which you would trust least. | The JD's two headline metrics. Tests method, not your record. |
| A4 | "Tell me about the peak-season surge plan you ran two years running." | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Story-mapped on F1: the plan, and the two years, which are the beats the quote states. Tell it in your own words. Answer slot: if you set any step of the plan, say which and how you decided; if the steps were set for you, say so and describe how you ran them. | A premised question on the one operational plan your material carries. The probe will be "what was yours?" |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); "never used Power BI" (your message) | Name the gap directly: supervisors, scale, and Power BI, in that order of weight to the role. Then the ramp: what you would do in the first thirty days for each. Do not defend against the gap; name it and move to the plan. | F3 and F5 are the gaps the material shows. A direct answer disarms the Skeptic. |
| B2 | "You run three supervisors and this role leads twelve across four sites. Why should we believe you can do it?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); "ran the site's peak-season surge plan two years running" (your message) | Highest-ROI prep in this pack. Hold the one claim the quotes carry: you run a shift with three supervisors and ran a site's peak season two years running. Concede the scale gap explicitly and specifically: twelve supervisors and four sites are untested for you. Then the ramp. Hold through two follow-ups by returning to the quote. Never fold into a claim of twelve. | F3 and F1 are the scale objection the JD raises. It will be asked in some form, and this is where the material is thinnest. |
| B3 | "This role requires five or more years of operations leadership. How many years have you led people?" | JD | [inferred] derived from the JD line; "7 years in warehouse and distribution ops" (your message) | Answer slot: give the number from your own record, and the role at each step. If it is shorter than five, say so plainly and say what the seven years of operations covers. Do not round up. | F6. The question's premise is the JD's, and the guidance does not adopt a leadership figure. |
| B4 | "Tell me about your Power BI experience." | JD | [grounded] "never used Power BI" (your message) | Plain acknowledgment: "I've never used Power BI." Then a plan, as a plan: what you would build first and how you would learn it. Keep the Excel reporting you did in your own words. | F5. The honest answer is the one that closes fastest. |
| B5 | "What did your Green Belt project actually change?" | EXP | [grounded] "green belt certified" (your message) | Answer slot: if the Green Belt included a project, name what it was and which part was yours; if it did not, or the part was not yours, say so plainly. Do not attach your pick-path work to the Green Belt unless you led it under that framework. | F7. Certification is the quote; the project is the probe. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% reduction in mis-picks was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Defend-the-number. Say how the count was taken, in your own words. Answer slot: if you know the baseline period and the count, say them; if you do not, say so plainly. Do not supply a method you do not remember. | A headline figure is the likeliest target for a prober. |
| C2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the weakest assumption before they do, in your own words. Answer slot: if you cannot name one, say so; if you know which part of the reduction you are least sure of, say that. | Weakest-assumption move. A gotcha becomes a credibility gain when you raise it yourself. |
| C3 | "Which part of that 40% was yours, and which part came from the redesign's owner?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: if you designed the pick path, say so and how; if you led a change others designed, say that. Ambiguity resolves downward: take the reading that claims less. | Attribution probe. Your sentence does not say who redesigned the path. |
| C4 | "Tell me about a time you used Excel to build a report someone acted on." | JD | [grounded] "solid Excel" (your message) | Open prompt. Choose one instance; if one comes to mind, tell it in your own words. If none comes to mind, say so plainly, then give the nearest thing your material carries, which is solid Excel, and how you would build the first report for this role. | F4. The JD asks for reporting; the material shows Excel skill and no named report. |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone who already runs a multi-site team?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Pause, restate, then hold the one thing you can say: you run a shift with three supervisors and ran a site's peak season. Concede that a multi-site team is the gap. Then the ramp. Hold through two follow-ups. | Pressure on the scale gap. The question assumes a rival you cannot see; do not argue with the premise, answer for yourself. |
| D2 | "That 40% you cut. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold-then-concede. Hold the part you can name. Concede specifically where the design came from, if it was not yours. Never fold the whole claim to restore calm. | Attribution under pressure. A held position you can back is the only one that survives a second follow-up. |
| D3 | "You have run one site. Why are you ready for four?" | JD | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Hold what the quote carries: one site, one peak season, two years. Concede that four sites is untested. Then the plan for the first quarter. | Pressure on multi-site ownership. |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to here." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc, in order: the warehouse and distribution years, the move into shift management, the current role over three supervisors. Stop there unless asked for more. | Casual opener, scored for communication economy. |
| E2 | "What is it about Atlas Freight that appeals to you?" | CO | [generic] | No company facts were researched, so do not claim any. Name what the JD tells you: four terminals, on-time and cost goals, reporting. Say why those fit your work, and say you would like to learn more. | CO without research is generic and labeled as such. Replace this once research is available (see Sources). |

Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own daily terminal operations across 4 sites | A2, B1, D3, A4 |
| Drive on-time performance and cost-per-shipment down | A1, A3, C1 |
| Lead a team of 12 supervisors | B2, D1, B1 |
| Build reporting in Excel/Power BI | C4, B4 |
| 5+ years operations leadership required | B3 |
| Lean/Six Sigma a plus | B5 |

## Reverse questions

Each has a reason it lands. The interviewer is not known, so these are role-generic.

1. "What does on-time performance look like at your weakest terminal right now, and what do you think is driving it?" Why it lands: it shows you read the JD's on-time line, and it invites the manager's diagnosis.
2. "How are the supervisor roles set up across the four sites today, and who reports to whom?" Why it lands: it turns the scale gap into a structural question, and the answer tells you how much the role inherits.
3. "What would make someone clearly successful in the first ninety days, from where you sit?" Why it lands: it asks for the scorecard, which is what a hiring manager is scoring against.
4. "How does the team use Power BI today, and what do you want reporting to answer that Excel does not?" Why it lands: it names the tool gap in their terms and shows you know the difference.
5. "What is the biggest operations decision waiting for whoever takes this role?" Why it lands: it reveals priorities and signals you want to work on the real problem.

## Prohibited claims and Sources

Sources

- Provided documents: the JD text and the background you wrote in your message.
- Research tier: L1, with search permission refused. Searches 2 of 6, fetches 0 of 2. Both calls were refused by the host.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Refused. Would have moved the values cheat sheet (section 10), which is not built: no values round was detected. |
| 2. Atlas Freight interview process, operations manager | unavailable | Refused. Would have set the loop structure and the persona weights; the weights here rest on the hiring-manager prior. |
| 3. Atlas Freight strategy / recent news | unavailable | Not sent, because search was refused. Would have moved the CO questions, which are generic in this pack (E2). |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. The interviewer read is absent. |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Queries sent, both refused: "Atlas Freight values"; "Atlas Freight interview process operations manager".

## Upgrade menu

- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint.
- Your recruiter's note on the round format and who you are meeting → confirms the persona weights and the round type, and sets the reverse questions.
- Atlas Freight's published values, and the interview process, once search is allowed → a values cheat sheet, and CO questions grounded in current strategy in place of E2.
- A copy of your Green Belt certificate → raises F7 from medium to high, because the certificate is an inspectable artifact.
- A sample of an Excel report you have built, which you can show → raises F4 from medium to high and gives C4 a named artifact to rehearse.
- A deeper research pass on Atlas Freight's strategy and loop reports → up to 6 more searches and 2 more fetches, several more minutes, if you want it.
