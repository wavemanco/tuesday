# Operations Manager, Atlas Freight: interview prep pack

Built from your message (the JD text and your background). Round and interviewer are unknown, so persona weights are flat. Research ran at L0: no search or fetch.

## How to use

Personas describe how a question is asked. Types describe what is being scored: **JD** (a stated requirement), **EXP** (your past, probed), **CASE** (a live problem). CO and VAL are absent: no research ran and no values-style round is known. The guidance is scaffolding, not a script. An answer slot is an instruction for the interview, not a question to me.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows seven years in warehouse and distribution operations and one site's surge plan, not four sites. Say: "I ran the site's peak-season surge plan two years running." Answer slot: if you ran daily operations across more than one site, or ran any step across sites, say which and how. If you ran one site, say so and say how you would take the daily routine to four. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | low | [grounded] | transferability | Three supervisors is adjacent to twelve, not the same scope. Say: "currently a senior shift manager over 3 supervisors." Answer slot: if you have led more people than that, say how many and what you were accountable for. If not, say so and say how you would grow the team to twelve. |
| F3 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | low | [grounded] | hard_gate | Your material does not establish five years of operations leadership. It gives seven years in operations and a current role over three supervisors, but not how long you have led people. This cell asks nothing. The one question about this gate is in the message that presents the pack. |
| F4 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows a quality result, a 40% cut in mis-pick rate, not on-time performance or cost per shipment. Say it at its own scope: "cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time performance or cost per shipment, say what you tracked and how it moved. If you did not, say so and say what you would measure first. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | medium | [grounded] | presentation | Your own words are "solid Excel." Say: "solid Excel." |
| F6 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | Words: "I have never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work. F5 meets the Excel half of this requirement. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote reaches the requirement. Say it in its own terms: green belt certified. Expect a probe on the project behind it; the material names none. Answer slot: if you led a project under the belt, say which and what changed. If not, say so. |

Gap types in play: transferability (F1, F2, F4), hard_gate (F3), presentation (F5), capability (F6), none (F7).

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Running daily operations across four sites | Inflated form of F1 | "ran the site's peak-season surge plan two years running," at its own scope. Your material says one site. |
| Leading twelve supervisors, or any team larger than three supervisors | Inflated form of F2 | "currently a senior shift manager over 3 supervisors," at its own scope |
| Five or more years of leading people | Inflated form of F3 | "7 years in warehouse and distribution ops." How long you have led people is A3's answer slot. |
| Owning on-time performance or cost-per-shipment results | Inflated form of F4 | "cut mis-pick rate 40% by redesigning the pick path," at its own scope |
| Any Power BI experience | Negative you stated (F6) | "I have never used Power BI." Then a plan, not a past. |
| Delivering Six Sigma projects beyond the Green Belt | Inflated form of F7 | "green belt certified," at its own scope |

## Persona table

Built flat, because the round and the relationship are unknown. The weights are set by the fit snapshot's gaps, not by a relationship prior. They will shift once you answer the first question below.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A, depth 4) | Scale and tool gaps: twelve supervisors, four sites, Power BI | High. The JD names all three, and your material shows three supervisors and no Power BI. | Rehearse the limit plainly, then a ramp plan. Do not bluff the scale. |
| Data-Driven Prober (B, depth 4) | The 40%, the Green Belt project, the reporting line | High. A headline number draws the first probe. | Defend the number: how it was counted, its weakest assumption, which part was yours. |
| Case / Strategist (C, depth 4) | Late departures, a four-site first month, a surge plan | Medium to high. Operations loops often open with a live problem. Without research, the problems are generic. | Clarify, then structure, then measure before you change anything. |
| Pressure (D, depth 3) | Why you over an internal candidate; how much was really you | Medium. A stress interviewer reaches for the weakest claim. | Hold through two follow-ups, then concede a specific part. Never the core. |
| Conversational (E, depth 2) | "Walk me through the journey" | Medium. Casual openers are scored. | A 90-second arc built only from your sentences. |

## Question banks

Question types are one token each. Provenance quotes every sentence a guidance cell rests on.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); "never used Power BI" (your message) | Name the two gaps the material shows, the larger first. Scale: "currently a senior shift manager over 3 supervisors," then how you would grow to twelve. Tools: "I have never used Power BI," then how you would learn it. Do not add to either to make the gap smaller. | F2 and F6 are the gaps a Skeptic reaches first. Likelihood high. |
| A2 | "I don't see twelve supervisors or four sites in your background. How would you handle that on this job?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Hold the scale as it is: 3 supervisors, in your words. Answer slot: if you have led beyond three supervisors, or across more than one site, say which and how many. If not, say so plainly, then give the ramp you would run: the first 90 days, the first measure, and how you would hand off supervisors. Hold through two follow-ups by returning to three. Concede the gap as a gap, never as a strength. | The highest-ROI prep in this pack. F1 and F2 are the premise, and the JD raises both. The scale gap is the most predictable objection, and a clean concession is what the Skeptic scores. |
| A3 | "You have seven years in operations. How long have you had people reporting to you?" | EXP | [grounded] "7 years in warehouse and distribution ops" (your message) | Give the number of years in your own words, from when. Answer slot: if it is shorter than the seven years of operations, say so plainly and say what you did in that time. Do not round up to reach five. | F3 is the five-year gate. The material does not show how long you have led people, so this probe will come. |
| A4 | "Your headline result is a quality measure. What have you tracked on on-time performance and cost per shipment?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Give the mis-pick result at its own scope: you cut the rate 40% by redesigning the pick path. Answer slot: if you tracked on-time performance or cost per shipment, say what and how it moved. If not, say so plainly, then what you would measure first. | F4 is transferability. The quality result reaches part of the JD's list, not the two named measures. |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say how the rate was measured, in your own words. If you can name the measure and the period, say both. If you cannot say how it was counted, say that plainly. Do not reconstruct a method on the spot. | The headline number is where a prober goes first (F4). The defend-the-number slot is how it was counted. |
| B2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the assumption you are least sure of, before they do, in your own words. If you cannot name one, say so plainly. Then say which part of the 40% was yours. | The weakest-assumption move converts a gotcha into a credibility gain. |
| B3 | "The role builds reporting in Excel and Power BI. Which report would you build first, and from what data?" | JD | [grounded] "solid Excel" (your message); "never used Power BI" (your message) | Start with the Excel side, in your words, since "solid Excel" is what you can stand behind. On Power BI, say "I have never used Power BI," then the plan: what you would learn first and how you would test it on one real report. Never describe a Power BI report as built. | F5 and F6: the reporting line has an Excel half you can meet and a Power BI half you cannot yet. The question asks for a choice, which tests the plan. |
| B4 | "You hold a Green Belt. Show me the project it came from." | EXP | [grounded] "green belt certified" (your message) | Name the project in your own words, if you led one under the belt. Answer slot: if the belt did not come with a project you led, say so, and say what you would apply it to first. | F7 is a certificate with no project behind it in the material. This covers the Six Sigma plus. |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Departures are late at two of our four sites this month. Where do you start?" | CASE | [generic] | Clarify first: which sites, which lanes, what "late" means, and since when. Then structure: split late departures by site, shift and step of the day before any fix. Name one measure you would check first and one you would not trust yet. | A live problem from the JD's on-time line. The method is generic; it makes no claim about your past. |
| C2 | "You are taking over four sites with uneven cost per shipment. What do your first 30 days look like?" | CASE | [generic] | Clarify what "uneven" means and what cost per shipment includes. Then sequence: measure each site on the same basis, talk to supervisors before changing anything, then test one change at one site. Do not claim a 30-day result. | F1's gap is four sites. This asks for the scope as a plan and claims no past. |
| C3 | "Peak season is eight weeks away across four sites. What would your surge plan look like?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Describe the surge plan you ran, in your own words, then what would change at four sites. Answer slot: if you did not set the plan's steps, say which you ran and which you did not. | The surge plan is the nearest four-site-adjacent work in your material (F1). The honest answer keeps the single-site record intact. |
| C4 | "What three numbers go on a daily dashboard for these four sites?" | JD | [grounded] "drive on-time performance and cost-per-shipment down" (JD); "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name on-time performance and cost per shipment, since the JD names them. Add the mis-pick rate as a quality measure you have moved before. Say what each measures, in one clause each. | Covers the JD's two named measures and F4's quality result. The premise is the JD's line. |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate for this role?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | Lead with the record: seven years in warehouse and distribution operations, and the current role over three supervisors. Make the one result you can defend, the mis-pick cut. Do not claim twelve or four. If pressed on the gap, concede it plainly and say how you would close it. | Composure on a short clock. The pressure interviewer leans on the gaps (F2, F3), so the answer must not reach past them. |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold the claim through two follow-ups: you cut the rate 40% by redesigning the pick path. Concede a specific part, in your own words, never the core claim. If others carried a step, name the step. | F4 is the headline result. Pressure tests whether you fold on the core claim. |
| D3 | "The role leads twelve supervisors. What is the largest team you have led, and why should we take the chance?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Give the largest team in your own words. Answer slot: if a larger group has ever reported to you, say how many. If not, say so, and say why the step would hold, in terms of what you would do first. | F2's gap under time pressure. The premise is the JD's line, and the second branch allows that no larger team exists. |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "ran the site's peak-season surge plan two years running" (your message); "green belt certified" (your message) | A 90-second arc: seven years in warehouse and distribution operations; shift manager now; the pick-path redesign and its 40% cut; the surge plan; the Green Belt; why this role. Use your own words. Your sentences are the stops. | Casual openers are scored. The arc uses only what you gave me. |
| E2 | "What are you actually playing with in Excel these days?" | JD | [grounded] "solid Excel" (your message); "never used Power BI" (your message) | Name the Excel work you have done, in your own words. Answer slot: the material does not say what it was. Then: "I have never used Power BI," and what you would do to learn it. | The reporting line, asked casually. F5 and F6. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A2, C2 |
| Drive on-time performance and cost-per-shipment down | A4, C1, C4 |
| Lead a team of 12 supervisors | A2, D3 |
| Build reporting in Excel/Power BI | B3, C4, E2 |
| 5+ years operations leadership required | A3, and the gate question in the message |
| Lean/Six Sigma a plus | B4 |

## Reverse questions

No interviewer profile exists, so none is tied to an interviewer's own path.

| Question | Why it lands |
|---|---|
| "What does the first 90 days look like in this role, and which measure would you check first?" | It shows you think in measures and do not assume a plan. |
| "How are on-time performance and cost per shipment tracked across the four sites today?" | It reveals the reporting tools in use and whether the Power BI gap matters here. |
| "Which of the four sites is the hardest to run right now, and why?" | It asks for the problem, not the brochure. |
| "How are the supervisors structured, and how do they report into this role?" | It tests the twelve-supervisor picture before you promise anything. |
| "How does the site handle peak season today, and who owns the surge plan?" | It opens the one piece of experience you have that is directly on point. |
| "What would make someone in this role successful in the first year?" | It is standard, but it gives you criteria to tie your answers to. |

## Sources

Provided documents: your message (the JD text and your background). No dossier was consumed.

Research tier: L0, provided documents only. No search or fetch ran.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet, section 10. Not built: no values-style round is known, and research has not been consented to. |
| 2. Atlas Freight interview process, operations manager | unavailable | Loop structure; persona weights would follow the named rounds |
| 3. Atlas Freight strategy and recent news | unavailable | The CO bank. This pack has no CO questions. |
| 4. {interviewer name} Atlas Freight | n/a | No name was given, so there is no query. |
| 5. Representative operations manager JD | skipped | Your JD fixes the fit snapshot and the JD questions. |

## Upgrade menu

- Your round and who you are meeting → reweights every persona bank, and can add a relationship-specific reverse question
- Your years of leading people → resolves the F3 gate and sharpens A3
- Any on-time or cost-per-shipment figure you tracked → turns F4's answer slot into a quoted bridge and gives B1 and B2 something to defend
- The interviewer's name → persona weights from their public footprint, and a reverse question tied to their career path
- Atlas Freight's website or careers page, read yourself → any published values and recent sites or results, for a values cheat sheet and CO questions
- Research consent at L1 (up to 6 searches and 2 page fetches) → the same targets as above, plus the interview process
- A recruiter's prep email → any declared focus areas or deliverables
