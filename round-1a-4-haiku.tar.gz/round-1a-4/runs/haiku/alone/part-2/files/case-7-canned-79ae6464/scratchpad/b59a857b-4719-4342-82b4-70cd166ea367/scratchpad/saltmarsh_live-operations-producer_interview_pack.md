# Saltmarsh Games: Live Operations Producer interview pack

**For:** Femi. **Interviewer:** Tobias Wrenfield, Head of Live Operations (relationship assumed to be hiring manager; see the upgrade menu). **Round:** 60 minutes, Friday. **Version:** first pass.

**Built on:** the JD paragraph you pasted, and your background note. No research was run this time, and no CV was supplied.

## 1. How to use, and the type key

Personas describe how a question arrives. Types describe what is being scored. This is scaffolding, not a script: rehearse the beats and the honest branch, not the wording.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Values / behavioral | Past behavior against published values. Not included: no values were supplied |
| EXP | Experience deep-dive | Whether your claims survive scrutiny, and what you actually did |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company knowledge | Not included: no company research was run |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Answer slots are instructions, not questions. They tell you what to be ready to say. Where a slot says "if none, say so", that branch is always honest and always available.

## 2. Fit snapshot

Your words are in double quotes, with the source after each dash. Confidence grades your evidence. Provenance grades what this pack wrote. Gap type says what kind of gap, if any, sits between the JD and your material.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material shows one title's weekly content-drop calendar, not live events and not two titles. Bridge: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you planned live events, or ran a calendar for more than one title, say so and how. If not, say what you ran and how you would approach two titles. |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [grounded] | discovery | Your material does not show how you coordinated design, art, engineering or community on a drop. Answer slot: describe one drop that needed time from one of those teams: who you asked, what you asked for, and how it went. If none needed it, say so. |
| F3 | "own the post-event review and the KPIs it reports" — JD (KPI part) | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting is not owning. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs were reported, or how they were counted, say which. If someone else set them, say so and say what you did with them. |
| F4 | "own the post-event review and the KPIs it reports" — JD (post-event review part) | none given | none | [grounded] | discovery | Your material does not mention a post-event review. Answer slot: if you ran or took part in one, describe what it covered and what changed. If not, say so and say how you would run one. |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap. The quote already reaches the requirement. Lead with the checklist in your own terms: what it covers, and how QA uses it. Expect a probe, because nothing has been inspected. |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | transferability | The length is not a gate, so it is graded on the evidence. Bridge: "I was an associate producer at a puzzle-game studio for four years." Your material does not say whether that title ran live content as a service, which the JD names. Answer slot: if it did, say how it was run and what your part was. If not, say which live work you did do. |
| F7 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. The quote reaches the requirement directly. Expect probes on cadence and on what "ran" meant in practice. |
| F8 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | Bridge rewords only the quote: "I presented the monthly retention numbers to the studio head." Expect a probe on how the figures were counted. |
| F9 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Bridge rewords only the quote: "I wrote the release checklist our QA team still uses." It is one written artifact in your material, so expect a request for another. |

Notes on the snapshot:

- **Gate rows:** the JD you pasted names no location, work arrangement, pay or right-to-work requirement, so no gate row is built. If the full posting names one, send it.
- **Not a JD requirement, but you flagged it:** "never worked on a game with in-app purchases" is not in the JD text. It is covered in the prohibited list and in bank B, because the interviewer may raise it.

## 3. Prohibited list

Claims this pack will not coach, and why. Each entry gives its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have led a team" | Negative you stated: "Never led a team" | "I haven't led a team." No slot. |
| "I owned the KPIs the post-event reviews report" | Inflated form of F3 and F4 | F3's quote at its own scope: "Presented the monthly retention numbers to the studio head." |
| "I planned live events for two titles" | Inflated form of F1 | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." |
| "I know how in-app purchases work" or any monetization experience | Negative you stated: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." No slot. |
| "I ran a live-service title" | Inflated form of F6 | F6's quote at its own scope. The live-service question is an answer slot. |

## 4. Persona table

Relationship prior: hiring manager. That gives Case/Strategist and Skeptic the top weights. Weights are shown with reasons so you can recalibrate if you know something the pack doesn't.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: leadership, ownership, the title | High. The hiring-manager prior, and the JD's two thinnest areas for you are team coordination and KPI ownership | Rehearse A2 until it is boring. Hold on the calendar and the checklist. Concede the leadership gap plainly |
| Case/Strategist | Live drop problems from the role | High. The JD's plan-and-run line means a hiring manager will test live problems | Clarify, objective, structure, metrics, risks. Think aloud |
| Data-Driven Prober | Asks how the retention figure was counted | Medium. The JD asks for comfort with retention metrics; your evidence is presenting them | Say what you know about counting. Name the assumption you are least sure of, before they do |
| Pressure / Stress | Time-boxed challenges | Medium-low. Less usual from a hiring manager, but "Never led a team" invites it | Pause, restate, hold through two follow-ups before conceding anything real |
| Values / Behavioral | Scenario probes against published values | Unknown. No values were supplied, so no bank is built | Deferred. See the upgrade menu |
| Conversational | Friendly opener; casual questions about JD topics | Low, but casual questions about JD topics are still scored | A 90-second arc for "walk me through your path" |
| Peer Evaluator | Seam questions between teams | Low for a hiring manager. Rises if you meet the design or engineering leads | Propose seam principles rather than claiming seam facts |

## 5. Question banks

Provenance comes first and carries every quote the guidance rests on. The guidance says only what those quotes say, and any slot is marked as one.

### Bank A: Skeptic (top weight, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your title has been associate producer. What did you own, and what did you support?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" — your message; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Hold on what you ran: the weekly content-drop calendar for the main title. Name it as yours in your own words. Then name the support. Answer slot: where a decision was yours, say which. Where work was supported rather than owned, say so. | F6 and F1 meet here. This is the most predictable opening for the Skeptic. |
| A2 | "You've never led a team. How would you get design, art, engineering and community to move on a drop when you have no authority over them?" | JD | [grounded] "Never led a team" — your message; [grounded] "Wrote the release checklist our QA team still uses." — your message | **Highest-ROI rehearsal in this pack.** The hold: "I haven't led a team." Then return to what you have: a checklist QA still uses, and a calendar you ran. Answer slot: describe a drop that needed time from another team: who you asked, what you asked for, how it went. If none did, say so and say how you would get the time. Hold through two follow-ups by returning to the checklist and the calendar, never by adding a team. | This is the likeliest objection for a live-ops hire with no team lead history. F2 is the gap it hits. Rehearse it aloud, several times. |
| A3 | "Presenting numbers and owning them are different things. Which KPIs would you have set yourself?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Separate presenting from owning, in those words. Answer slot: if you chose which KPIs were reported, or how they were counted, name them. If someone else set them, say so, and say what you did with the numbers you were given. Never describe a KPI you did not track. | F3. The question's premise is the JD's, and the guidance does not adopt it. |
| A4 | "You haven't worked on a game with in-app purchases. What does that leave you unable to do in this job?" | JD | [grounded] "never worked on a game with in-app purchases" — your message | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then name the transferable part from what you did: the calendar and the retention reporting. Say how you would learn monetization. No slot needed for the acknowledgment. | The JD does not name monetization. Say so only if asked, and do not argue the point. |
| A5 | "Walk me through a post-event review you've run. What changed because of it?" | JD | No candidate claim. Answer slot only | Answer slot: if you ran or took part in one, describe what it covered and what changed. If not, say so plainly and say how you would run one. | F4: discovery. The honest answer is a plan, not a past. |

### Bank B: Case/Strategist (high weight, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Plan the next six weeks of live events across two titles. What do you need to know first?" | CASE | [generic] pattern for live-ops planning, not a claim about you | Clarify first: team capacity, QA windows, what each title's players are reacting to, what the events are for. Then structure: objective, segments, approach, metrics, risks. Think aloud. | JD's plan-and-run line. The question makes no claim about your past. |
| B2 | "A drop went out on Tuesday, and day-7 retention is down. How do you diagnose it?" | CASE | [generic] pattern for a retention diagnosis, not a claim about you | Structure: what changed in the release, whether the drop or something else moved, the cohort split, timing against other events, what QA covered. Name the assumption you would check first. | Tests the retention competence in the JD without asking for a past claim. |
| B3 | "Design wants the event in the same week as engineering's migration. What do you do?" | CASE | [generic] pattern for a cross-team clash, not a claim about you | Clarify who owns which decision. Name the constraint, then the options, then the one you would recommend and why. Say how QA's gate affects it. | Tests F2 without asking about your history. Do not claim you have resolved this before. |
| B4 | "What does your release checklist cover, and how does QA use it?" | JD | [grounded] "Wrote the release checklist our QA team still uses." — your message | Describe the checklist in your own words, only what you know it contains. Do not claim anything beyond "QA still uses it". Offer to show the checklist itself if you can share it. | F5. Easy to answer, and a good place to be concrete. |

### Bank C: Data-Driven Prober (medium weight, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Say what you know about the counting, in your own words. If you do not know how a figure was counted, say so plainly. Do not invent a method. | F8. The honest answer is "I presented them. I know this part, and not that part". |
| C2 | "Which assumption behind that retention number would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Name the assumption you are least sure of, before they find it. If you have no assumption you can name, say so, rather than inventing one. | Tests whether you know your own numbers' limits. |
| C3 | "Across two years of content drops, did a number ever change what you shipped?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Answer slot: if a number changed a drop, say which, and how you know. If none did, say so. | F7 meets F8. Tests whether the metrics were used or only reported. |

### Bank D: Pressure / Stress (low weight, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone who has never led a team, over someone who has?" | JD | [grounded] "Never led a team" — your message | Pause. Restate the question. Hold: you have not led a team. Then name what you bring from your own work: the calendar and the checklist. Concede the gap plainly. Do not claim leadership to close it. | Composure test. Hold through two follow-ups before any concession. |
| D2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Say what you ran, and what others set. Name one decision that was yours, if there was one. If the honest answer is "some", say that. | Attribution honesty under pressure. |

## 6. Reverse questions

Questions for Tobias, each with why it lands. No profile was supplied, so these are role-specific rather than tailored.

1. **"What does a good first ninety days look like for whoever owns the calendar?"** Why it lands: it shows you think about ramp, and it lets Tobias name the gaps directly.
2. **"How are post-event reviews run today, and who owns the KPIs they report?"** Why it lands: it asks about F3 and F4 in the JD's own words, and tells you whether the role is owning or presenting.
3. **"When design, art, engineering and community disagree on a drop, who decides?"** Why it lands: it tests the seam, and it is the question A2 and B3 are built around.
4. **"How is the QA release checklist used across the two titles?"** Why it lands: it shows you have read the JD closely, and it ties to the work you have already done.
5. **"What would make you say, six months in, that this hire was the right one?"** Why it lands: it gives you the success criteria, and it surfaces any leadership expectation early.

## 7. Interview run-of-show (added at your request)

This is beyond the standard sections, and added because you asked for it. Times are a plan, not a schedule.

| Time | Segment | Use |
|---|---|---|
| 0:00 to 0:05 | Opening and your 90-second arc | Your path: four years as an associate producer, the content-drop calendar, the checklist, the retention reporting. Quote only what the fit snapshot holds |
| 0:05 to 0:20 | Your experience | A1, then A2 (the highest-ROI rehearsal). Give A2 the most time |
| 0:20 to 0:35 | Live problems | B1, then B2. Think aloud, and clarify before you structure |
| 0:35 to 0:45 | Teams and the release checklist | B3, B4, then D1 if the pressure turns up |
| 0:45 to 0:55 | Metrics and KPIs | A3, C1, C2, C3 |
| 0:55 to 1:00 | Your questions | Two or three of the reverse questions, chosen on the spot. Leave time for Tobias to answer |

Everything else is insurance. The highest-value rehearsal is A2, and you should run it aloud before Friday.

## 8. Sources

Provided documents: the JD paragraph you pasted, and your background note.

**Research tier:** L0. No search or fetch was run this pass, because the consent item gave way to the upgrade menu.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, section 10. Not built, because no published values were supplied |
| 2. Saltmarsh Games interview process | unavailable | Loop structure and persona weights. Persona weights rest on the hiring-manager prior |
| 3. Saltmarsh Games strategy and recent news | unavailable | Company knowledge bank. Not built |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read and tailored reverse questions. Not run |
| 5. Representative Live Operations Producer JD | skipped | The JD you pasted fixes the fit snapshot |

## 9. Upgrade menu

- The round's format, and whether Tobias is your future manager → persona weights recalculated, with the Skeptic and Case weights set against the real relationship
- Saltmarsh's published values (paste the page) → a values cheat sheet mapping each value to one of your quoted sentences, or a selection scaffold where none fits
- Tobias Wrenfield's public profile → an interviewer read and a tailored reverse question
- A redacted copy of the content calendar you ran → F1 and F7 move from medium toward high, and you have something concrete to show
- A redacted copy of the release checklist → F5 and F9 move from medium toward high
- Whether the puzzle title ran live content as a service → F6 gets a grounded bridge in place of an answer slot
- The full JD posting, if it names a location, work arrangement or pay → gate rows are built
- Examples of post-event reviews, if you ran or took part in any → F4 moves from discovery to a grounded bridge
- Deep research on Saltmarsh's public materials → a grounding brief and a current-vocabulary section for the Case bank
