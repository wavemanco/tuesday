# Larkfield Systems, Engineering Manager: interview pack (loop mode)

Three rounds: hiring manager (Director of Engineering, 45 min), panel (two staff engineers and a product manager, 60 min), VP Engineering (30 min, "values and leadership philosophy"). No interviewer is named, so persona weights come from round priors.

Built on your summary of the role, since no job description came with it, and on your descriptions of the rounds.

## How to use

- **Personas** are how a question arrives. **Types** are what it scores: VAL (behavioral and values), EXP (your experience, probed), JD (the role's own requirements), CO (company knowledge, not included because research did not run), CASE (a live problem).
- Guidance is scaffolding, not a script. Each cell should be speakable in 90 to 120 seconds.
- Provenance quotes are your own sentences from your message, verbatim. Answer slots are instructions for the interview, not questions to answer here.

## Fit snapshot

Shared across all three rounds.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (your message) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six, not two squads. Bridge: say it as your message does, "three years as a team lead of six." Answer slot: if you have led more than one group, or split one team's work across two, say how; if not, say so and describe how you would split the two squads. |
| F2 | "device-management services" (your message) | none given | none | [grounded] | discovery | Your material does not show device, fleet or IoT work. Answer slot: if any past work touched devices, say what it was and your part in it; if none did, say so and describe how you would learn the domain. |
| F3 | "own delivery, hiring and growth for 11 engineers" (your message) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | The strongest delivery evidence you have, at team-of-six scale, with one figure nobody has inspected: expect a probe (A4, A5). Keep "after" as your sentence has it. Answer slot: how you would carry delivery across two squads and eleven people, as a plan. |
| F4 | "own delivery, hiring and growth for 11 engineers" (your message) | "I run our hiring loop for backend roles — about 40 interviews last year" (your message) | medium | [grounded] | transferability | Interviewing on backend roles, not hiring decisions past the interview. Bridge: the sentence as written. Answer slot: which decisions beyond the interview were yours, if any; if none, say so. |
| F5 | "own delivery, hiring and growth for 11 engineers" (your message) | none given | none | [grounded] | discovery | Your material does not show growth outcomes for people you led. Answer slot: name one thing you did for a specific person on your team, in your own words; if you can name none, say so and describe your approach as a plan. |
| F6 | "partner with hardware and product on roadmap" (your message) | "pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Roadmap pressure in a payments setting, not hardware. Bridge: the sentence as written. Answer slot: who the pressure came from and what you agreed to; if you agreed to nothing, say so. |
| F7 | "partner with hardware and product on roadmap" (your message) | "I've never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | Stated absence. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn hardware constraints, as a plan. No claim to hardware roadmap work. |
| F8 | Managing managers: [inferred] from "Lead two squads", since squad leads are not stated | "I've never managed managers" (your message) | none | [grounded] | capability | Stated absence. Words: "I've never managed managers." Then what you would do in your first month with managers, as a plan. |
| F9 | "values and leadership philosophy" (the recruiter's words, relayed in your message) | none given | none | [grounded] | discovery | Your material states no leadership philosophy. Answer slot: name the first leadership decision you would make in this role, in your own words; if you describe a principle instead, label it as one. |

No gate rows. Your message names no location, schedule, pay, authorization or credential requirement. If the posting names one, it needs its own row.

## Prohibited claims

Not coached in any cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Having managed managers, or coached one | Negative you stated, F8 | "I've never managed managers." No slot for managing managers as past work. |
| Owning a hardware-adjacent roadmap | Negative you stated, F7 | "I've never owned a hardware-adjacent roadmap." |
| Hiring 40 engineers, or making 40 hiring decisions | Inflated form of F4 | "I run our hiring loop for backend roles — about 40 interviews last year." |
| The reliability quarter caused the 60% drop | Inflated form of F3 | Your sentence, with "after." The pack's observation, not a claim for you: the material says after, not because. |
| Leading eleven engineers, or two squads | Inflated form of F1 | "3 as a team lead of 6." |
| Growing people, or having a growth record | Inflated form of F5 | None in the material; the slot in F5 asks for what you did, if anything. |

## Round 1: hiring manager (Director of Engineering), 45 min

**Persona weights.** Relationship prior for a hiring manager is Case plus Skeptic. You named both gaps yourself in your message, so Skeptic leads: 4 questions. Case 2 (they are buying capability and derisking the two gaps with live problems). Prober 1 (the 60%). Conversational 1 (the opener). Eight in all.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never managed managers. How would you handle that in this role?" | JD | [grounded] "I've never managed managers" (your message) | Open with the sentence as you said it. Then the closest thing you have: "3 as a team lead of 6." Answer slot: name what you would do in your first month with managers, as a plan. Never claim you have coached or appraised a manager. | F8 is the gap most likely to be raised in any round, and this round asks it first. The squad structure is inferred from "Lead two squads", so the question names the gap, not the structure. |
| A2 | "I don't see hardware in your background. How would you handle the hardware side of this roadmap?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap" (your message) | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then the closest sentence, at its own scope: "pushed a reliability quarter through against roadmap pressure", which was payments roadmap, not hardware. Answer slot: how you would learn the hardware constraints, who you would ask and what you would need to see first, as a plan. | F7 and F6. The bridge is a plan, not a record. JD because it scores the partnership requirement. |
| A3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers" and "I've never owned a hardware-adjacent roadmap" (your message) | Pick one of the two gaps you have already stated and say how you would ramp it first. Say the acknowledgment in your words, then the plan. Do not present both as settled. | A stem that lets you choose the gap. Both quotes are yours, and the answer draws only on them. |
| A4 | "Your team's on-call burden dropped 60%. How much of that was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | **Highest-ROI prep in this pack.** Say what you pushed, in your words: the reliability quarter, against roadmap pressure. Then say what you cannot claim: the share of the 60% that was yours and the share that was the team's. Concede that specifically: "I can't separate my part from the team's." Hold it through two follow-ups. Do not fold into "the team did it", and do not claim the whole figure. Name the assumption you would defend least, in your words. Answer slot: if you know what else changed in that period, say so; if you don't, say you don't know. | F3 is the only figure in your material, and this question is the attribution test. The concession is the part an interviewer checks. |
| A5 | "Walk me through how that number was counted." | EXP | [grounded] "My team's on-call burden dropped 60%" (your message) | Say, in your own words, how the figure was counted. If you do not know, say that plainly: "I don't know how it was counted" is an honest branch. Name the weakest assumption before it is asked for. | A Prober check on the same figure, from the counting side. Repeating the figure back is not an answer; the counting is. |
| A6 | "A device-management release is three weeks late and the hardware side says the firmware is the blocker. What do you do in week one?" | CASE | [generic] | Clarify first: what "late" is measured against, and what the firmware is blocking. Then the objective, two or three options (scope, date, a fix on the hardware side) and what you would check first. Name one risk and one thing you would stop doing. No claim about any past incident. | A pattern for the role's live problems. It is [generic] because it is a pattern, not a fact about Larkfield. Scored on structure. |
| A7 | "Two squads, eleven engineers, and a backlog of open roles. Where do you start?" | JD | [grounded] "own delivery, hiring and growth for 11 engineers" (your message); [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" (your message) | Clarify which roles block what. Then sequence: what gates delivery, and which hires unblock it. Keep the loop experience to its scope: you run the loop for backend roles, about 40 interviews. Name what you would verify before assuming it carries over to these roles. | F3 and F4 are the only evidence on delivery and hiring. The bridge does not go past the interviews. |
| A8 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | A 90-second arc in your order, using only those facts: nine years, three as a team lead of six, now at a payments company. Answer slot: your reason for this move, in your words. Add no titles or scope. | Casual openers are scored. The arc is F1 and F3 told in order. |

**Reverse questions for this round**

| Question | Why it lands |
|---|---|
| "What would the first ninety days need to look like for the two squads to be on track?" | Shows you are planning around delivery, not around the org chart. |
| "Where does the hardware roadmap call get made today, and who holds the trade-off?" | Sizes the partnership requirement with the person who sets it. |
| "What has made this role hardest in the last year?" | Surfaces the real problem, and signals that you plan for it. |

## Round 2: panel (two staff engineers and a product manager), 60 min

**Persona weights.** Names are not known, so there is no per-member assignment. Panel members blend the top two personas of their relationship: staff engineers get Prober plus Peer Evaluator; the product manager gets Peer Evaluator plus Case. Peer Evaluator 3 (the seam with hardware and product is the panel's core), Prober 2 (staff-level depth), Case 2 (roadmap trade-offs), Pressure 1. Eight in all.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam with hardware, and what happens when you disagree?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap" (your message) | Name the seam principle first: who decides what, and how a disagreement is settled. Don't pretend to know their seam. Then the disagreement you can describe, at its scope: a reliability quarter pushed through against roadmap pressure. Answer slot: if you have disagreed with another team on a hardware-adjacent seam, say how it went; if not, say so and give the principle you would use. | F6 and F7. The seam is what the role asks for, and this is a peer-style probe. |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through" (your message) | Separate the team's result from your push, in those terms: the 60% belongs to the team's on-call load, and the push was yours. Do not claim the whole figure. Answer slot: name who else contributed, in your own words; if no one else did, say so. | The same figure as A4, now asked about credit rather than attribution. |
| B3 | "What would you need from the staff engineers to make the first six months work?" | JD | [generic] | Name two asks you can defend: a ramp into device-domain work (F2) and an explanation of hardware constraints (F7). Frame them as plans, not as things you have been asked for before. | A peer's reciprocity-style question. [generic] because it is a pattern for the role, not a fact about the panel. |
| B4 | "You run the backend hiring loop. Which decisions in it were yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" (your message) | Say what "run" covered, in your words, and name the decisions set by others. Answer slot: if any decision in the loop was yours to set, say which and how you decided; if none was, say so plainly and describe what you did run. Forty interviews are not forty hires. | Staff engineers will ask for the denominator. F4 is the only hiring evidence. |
| B5 | "How would you judge whether a device-management service is reliable enough to ship?" | CASE | [generic]; [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Name the one measure you would trust least, and what would change your mind. Structure it: what reliable means for a fleet of devices, which measures, and what you would check first. Use your reliability quarter only as an analogy, with the sentence at its own scope. | F2 is the gap: the pack has no device evidence, so the answer rests on structure, not on a claimed domain. |
| B6 | "A hardware team asks for a feature that isn't on the roadmap. How do you decide?" | CASE | [grounded] "partner with hardware and product on roadmap" (your message) | Clarify what the request blocks and who it affects. State the principle you would decide by. Name the one trade you would not make. Do not present a hardware decision as one you have made. | A live problem from the role's partnership line. Scored on how you think, not on a past call. |
| B7 | "Reliability or features for the next two quarters, for a team of six. Which way?" | CASE | [grounded] "3 as a team lead of 6" and "pushed a reliability quarter through against roadmap pressure" (your message) | Name the split you would propose and the assumption it rests on, then the trade you would accept. Your reliability quarter shows you have held that line once; say so at its scope. Name the condition under which you would change the call. | A product manager's question, premised on your team size and your one reliability quarter, both quoted. |
| B8 | "Who was pushing back on that quarter, and did you give any ground?" | EXP | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Hold then concede. State the decision and why, in your words, and hold it through two follow-ups. Concede specifically: name what you gave ground on, if anything. Answer slot: if you conceded nothing, say so plainly. Concede uncertainty, never the core of the call. | A pressure probe on the quote. Held positions are the ones a second follow-up tests. |

**Reverse questions for this round**

| Question | Why it lands |
|---|---|
| To the PM: "How do hardware-driven roadmap requests reach the priority list today?" | Names the mechanism the role would sit inside. |
| To the staff engineers: "What reliability or on-call work is already queued for the next two quarters?" | Shows delivery thinking at the level staff engineers care about. |
| Reciprocity: "What would a new person do in their first month that would genuinely help your team?" | A peer question. It signals you are offering, not only asking. |

## Round 3: VP Engineering, 30 min ("values and leadership philosophy")

**Persona weights.** The recruiter's own words name this round as values and leadership philosophy, so a values-style round is detected. Values/Behavioral 4 (the round's stated purpose), Case/Strategist 1 (the VP's altitude), Pressure 1 (composure at senior level). Six questions in 30 minutes.

**Values cheat sheet: not rendered.** No published Larkfield values are in hand, so there is nothing to map your stories to by name. The VAL questions below take their theme from the recruiter's words, and each answer draws on your quoted sentences or on a selection scaffold ending in an honest branch.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you put a customer's or an operator's need ahead of a roadmap date." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Tell the reliability quarter in your sentence order: the roadmap pressure, what you pushed, what changed after, and the 60%, keeping "after". If the stake was your team's on-call load, say that; it is in your sentence. If no customer or operator stake was in it, say so; do not add one. If no such time comes to mind, say so plainly, then give the reliability quarter at its scope. | An open prompt, with a persona stem as its theme. F3 and F6 are the only stories in the material. |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message), as the candidate story | Selection scaffold: pick a time you held a position under pressure from someone senior. It needs a named stake, a moment you did not fold, and a working relationship at the end. If the reliability quarter fits, tell it. If it does not, say so plainly and give the nearest thing your material carries. | Scaffold, because the material does not show the senior person or what they said. |
| C3 | "What's your approach to developing the people on your team?" | VAL | [generic] | No growth outcome is in your material (F5). Answer slot: name one thing you did for a specific person, in your own words. If you can name none, say so and describe your approach, labeled as a plan. | Theme from the recruiter's "leadership philosophy". Growth is the requirement the material is silent on. |
| C4 | "How do you decide, in a loop, what counts as enough evidence to say no?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" (your message) | Name the bar and the evidence that meets it, in principle. Then what you do when a panel disagrees with a no. Draw on the loop only at its scope: you run the loop for backend roles. Answer slot: if a panel has ever disagreed with one of your calls, say how it was settled; if not, say so and describe the rule you would hold. | Hiring is the role's requirement, and the loop is your only hiring evidence. |
| C5 | "Where do you put your time in the first quarter: the two squads, the hardware partnership, or the hiring?" | CASE | [generic] | Choose one, defend it against the other two, and name what you would stop doing. Speak the trade-off in your own words. No claim about what you have done before. | Altitude check. The answer is judgment, not history. |
| C6 | "Sixty seconds: why should I trust you with a layer of managers you haven't run?" | JD | [grounded] "I've never managed managers" and "3 as a team lead of 6" (your message) | Hold: the strongest true answer is the record in the quotes, three years as a team lead of six. Concede the gap plainly: "I haven't managed managers." Hold through two follow-ups, then concede specifically rather than defending as if you had. Answer slot: name what you would do in your first month with managers, as a plan. | Pressure on F8. The same gap as A1, now at VP altitude. Repeating it is deliberate: the VP is the likeliest to press. |

**Reverse questions for this round**

| Question | Why it lands |
|---|---|
| "What does a good decision look like at this level, from last quarter?" | You want the philosophy in practice, not in slogans. |
| "What does an engineering manager here look like three years in, and what usually stalls them first?" | Shows you are planning for the role's real failure mode. |

## Requirement coverage

| Stated requirement | Covered by | Story in material |
|---|---|---|
| Lead two squads building device-management services | A2, A3, B5, B6 | F1 (partial); F2 gap |
| Own delivery for 11 engineers | A6, A7, B7, C5 | F3 |
| Own hiring for 11 engineers | A7, B4, C4 | F4 |
| Own growth for 11 engineers | C3 | None; F5 is a discovery gap |
| Partner with hardware and product on roadmap | A2, B1, B6, B8 | F6; F7 is a stated gap |
| Managing managers (inferred from "Lead two squads") | A1, A3, C6 | F8 is a stated gap |
| Values and leadership philosophy (recruiter's words) | C1, C2, C3, C4 | F9 is a discovery gap |

## Persona table

| Round | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 | Skeptic | Probes the two gaps you named, and the on-call figure | High: a hiring manager's relationship prior, and your message names both gaps | Rehearse A1 and A4 until they are plain. Concede specifically. |
| 1 | Case/Strategist | Live problems on the squads' real work | High: the hiring manager is buying capability | Clarify, then structure. Use only your quoted facts. |
| 1 | Prober | Asks how the 60% was counted | Medium: a single figure invites it | Say plainly what you do not know. |
| 1 | Conversational | The opener, "walk me through the journey" | Medium: a casual open still scores | A 90-second arc, using only your facts. |
| 2 | Peer Evaluator | The seam with hardware and product; credit | High: the panel's core is partnership | Name seam principles, not invented seams. |
| 2 | Prober | Staff-level depth on the figure and the hiring loop | High: two staff engineers | Name the assumption you would defend least. |
| 2 | Case | Roadmap trade-offs from the product manager | Medium: one PM on the panel | Clarify, then state the trade. |
| 2 | Pressure | Who pushed back on the quarter | Low to medium: one probe, not a theme | Hold, then concede the specific point. |
| 3 | Values/Behavioral | Stories against the recruiter's theme | High: the recruiter named it | Scaffolds where your material is silent. |
| 3 | Case/Strategist | First-quarter trade-off | Medium: VP altitude | Choose and defend. |
| 3 | Pressure | Why trust you with managers | Medium: senior composure | Hold the record, concede the gap. |

## Sources

- Provided documents: your message (the role summary, the three rounds, your background, and the recruiter's phrase "values and leadership philosophy").
- Searches: "Larkfield Systems values", and "Larkfield Systems interview process engineering manager". Both were refused by the tool permission, so neither returned results.

Research tier: L1 — searches 2 of 6, fetches 0 of 2 (both searches refused)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet (section dropped, since no published values are in hand). The VAL questions use the recruiter's words instead. |
| 2. Larkfield Systems interview process engineering manager | unavailable | Loop structure. Your message establishes the three rounds, so persona weights follow them; no archetype fallback is used. Values-style round detected from the recruiter's words. |
| 3. Larkfield Systems strategy / recent news | unavailable | Would have moved CO questions. None are included, because no strategy source is in hand. |
| 4. Interviewer name and company | n/a | No interviewer is named, so there is no query to form. |
| 5. Representative engineering manager JD | unavailable | Would have moved the requirement sources from your summary to a posting. Not sent. |

## Upgrade menu

- A full job description → the requirement quotes become the posting's own words, and F1 to F9 are rechecked against it.
- The recruiter's note on the panel's focus, or any take-home → the panel weights and a build section if a deliverable is named.
- Larkfield's published values page, or the recruiter's copy → a values cheat sheet for round 3, mapping each value to a quoted story.
- The hiring manager's, the staff engineers' and the product manager's names → per-interviewer reads and persona assignments.
- How the 60% was counted, and over what period, in your own words → A4 and A5 become answers you can defend, rather than slots you have to say you cannot fill.
