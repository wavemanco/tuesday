# Operations Manager, Atlas Freight: interview prep pack

Role: Operations Manager. Company: Atlas Freight (regional logistics, 800 employees). Interviewer: not known. Round: not known, so this pack is built for a hiring-manager round. Built from the JD text and your background in your message. No research run yet.

## How to use

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and stop where your material stops.

Type key:
- **EXP**: what you actually did, tested for attribution
- **JD**: the job's stated requirements, gaps included
- **CASE**: a live problem from the role, answered live
- **VAL** and **CO**: not used in this pack. No company values or research are in hand yet.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "ran the site's peak-season surge plan two years running" — your message; "7 years in warehouse and distribution ops" — your message | medium | [grounded] | transferability | Your material shows one site and a peak-season plan, not four sites run day to day. The bridge stays at its scope: "For two years I ran the site's peak-season surge plan." Answer slot: the four-site scope makes a probe likely. If you have run daily operations across more than one site, say which and how many, in your own words. If not, say what you would do first at a second site. |
| F2 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Three supervisors is the scale your material shows; twelve is the JD's. Bridge: "I'm a senior shift manager over three supervisors now." Answer slot: if you have led more supervisors, or a larger group, say how many and when, in your words. If not, say so and say how you would build the team in your first ninety days. |
| F3 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Your material gives seven years in the work and a current supervisory role. It does not say how many of those years were leading people. The bridge is a question, not a figure. Answer slot: say how many of your years have been leading people, and in which roles, in your own words. If that is under five, say the number and what you would bring. |
| F4 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material shows accuracy, a mis-pick rate. It does not show on-time performance or cost per shipment. Bridge: "The 40% is a mis-pick rate." Answer slot: if you moved an on-time or cost measure, name it and how it was counted. If not, say what you would measure first. |
| F5 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid" is your word for Excel, and the material does not show what you built in it. The bridge stays a question. Answer slot: name one report you built in Excel, what it reported, and who used it. If you have built none, say so. |
| F6 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A stated absence, so the words are yours: "I haven't used Power BI." Then a plan, never a past: how you would learn it, and by when. Never claim Power BI work. |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | The quote already reaches the requirement. The certificate has not been inspected, so expect a probe. Lead with it in your words: "I'm green belt certified." Do not extend it to projects you ran; that is a slot, and it is on the prohibited list. |

No row is a hard gate. None of the JD's requirements is a legal or credential bar, so "5+ years" is graded as experience (F3), not as a gate.

## Persona weights

Relationship prior: hiring manager (assumed, since the round is unknown). Hiring managers buy capability and derisk gaps, so Case and Skeptic lead. The metric figures and the JD's named metrics make the Prober strong. Interviewer signals: none, since no interviewer is named.

| Persona | How it shows up here | Likelihood and reasoning | Depth | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Live problems on on-time and cost per shipment | High. The JD's headline asks are operational, and a hiring manager scores how you structure a live problem | 4 | Clarify, then measure, segment, act on the largest cause, and say what you would report |
| Skeptic | The scale gap (3 supervisors against 12), the four-site scope and Power BI | High. Three visible gaps in the fit snapshot (F1, F2, F6), and the Skeptic finds them first | 4 | Rehearse the one predictable objection (B1) until it is plain. Concede the scale gap precisely, and hold on the facts you have |
| Data-Driven Prober | The 40% figure, and the two JD metrics it does not cover | High. One headline number, and a JD that names two metrics it does not reach (F4) | 4 | Know how the 40% was counted, or say you don't. Name its weakest assumption before they do |
| Pressure | "Why you?" in sixty seconds, and "how much was actually you?" | Medium. A hiring manager may push on scale; the time box is common | 3 | Pause, restate the question, answer from the quotes, hold through two challenges, concede once |
| Values/Behavioral | Open behavioral prompts; no values are published | Medium. With no values in hand, the story is scored on the behaviour itself | 2 | Choose a story with a named stake; say plainly when none comes to mind |
| Conversational | A warm opener: "walk me through the last seven years" | Medium. Most interviews open this way, and casual questions are still scored | 2 | A 90-second arc in your own sentences, in order |
| Peer Evaluator | Seam and credit probes | Low. A prior for a peer, kept for the cross-functional partners you'd work with | 2 | Propose principles for seams; say who did the work |

Total: 21 questions, inside the 18 to 26 range.

## Question banks

### A. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Four terminals, and one has missed its on-time target for six weeks. What do you do in your first week?" | CASE | [grounded] | Clarify before you structure: which terminal, what "missed" is measured against, and whether the miss is one lane, one shift or the whole site. Then structure: measure first, segment by shift, dock and lane, act on the largest cause, and say what you would report and to whom each week. Name no past event; this is a live problem. | The headline JD requirement is on-time performance, and the first-week structure is what gets scored. It asks nothing about your history. |
| A2 | "Cost per shipment has gone up this quarter across the network. Where do you start?" | CASE | [generic] | Clarify what "up" is measured against. Then break cost per shipment into its parts: labour hours per shipment, overtime, temporary cover and rework. Say what you would check first. The case gives no figure, and the guidance supplies none. | Cost per shipment is the JD's second headline metric. A pattern for the problem, with no claim about you or this employer. |
| A3 | "Our site leads build their reporting in Excel and Power BI. How would you have a daily report running at a site in your first month?" | JD | [grounded] "build reporting in Excel/Power BI" — JD; "solid Excel" — your message; "never used Power BI" — your message | Start with Excel, which your message calls solid, and say what daily report you would build first. Then give Power BI as a plan: "I haven't used Power BI." Say how you would learn it, and by when. Never describe Power BI work you have not done. | F5 and F6 make this an honest sequence: Excel as the starting point, Power BI as a plan. The question scores the stated tool requirement. |
| A4 | "Your surge plan will run again next peak. What would you change first?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" — your message | Name the one change you would make, in your words, and the evidence that would point to it. If you have no such evidence, say so, and say what you would measure. Add no figure for the peak. | The surge plan is the one operating-scale story in your message, and a follow-on about it is likely. It asks for a change, not a past event. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You manage three supervisors. This role leads twelve across four sites. Why should we believe you can make that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message; "lead a team of 12 supervisors" — JD | **Hold, then concede.** Open with the fact in your own words: "I'm a senior shift manager over three supervisors." Concede the gap exactly: "Twelve across four sites is a bigger team than I lead today." Then say what your quotes carry and no more: the pick-path change and the surge plan, both at one site. Hold this through two follow-ups by returning to the scale fact. If pushed past that, concede the uncertainty, never the core. Answer slot: if you have led more supervisors or a larger group, name the number and when. If not, say what you would do in your first ninety days. | **The highest-ROI prep in this pack.** The scale gap (F2) and the four-site scope (F1) are the likeliest objection to this candidate. The rehearsal is a non-defensive concession with the facts held. |
| B2 | "The role needs five years of operations leadership. How many of your seven years have been leadership?" | JD | [grounded] "7 years in warehouse and distribution ops" — your message; "5+ years operations leadership required" — JD | Answer slot: say how many years you led people, from the roles you held, in your own words. If it is under five, say the number and then what you would bring. Do not round up. If none of the years were leading people, say so. | F3 is a discovery gap: the material gives years in the work and no leadership years. The question's premise is the JD's, and the second branch lets it be answered plainly. |
| B3 | "You've listed Excel. Show me a report you built, and what it reported." | EXP | [grounded] "solid Excel" — your message | Answer slot: name a report you built in Excel, what it reported, and what, if anything, it changed. If you have not built one, say so plainly, and say what you would build first. Do not describe a figure. | F5 is a discovery gap: "solid" is the only Excel evidence the material has, so the question tests it. The premise is answerable either way. |
| B4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI" — your message; "Own daily terminal operations across 4 sites" — JD | Name the weakest part honestly, from your own sentences: the reporting tool, or the four-site scope. For the tool, say "I haven't used Power BI," then how you would learn it. Keep to one part, and say what you would do in week one. | An open Skeptic probe. It tests honest self-assessment, and its guidance uses only F6 and the scope of F1. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick cut was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Answer slot: say how it was counted, in your own words. If you do not know how it was counted, say so plainly. Name the weakest assumption behind the 40% before they do, and say which part of the redesign was yours. Do not supply a baseline, a period or a method. | Defend-the-number on F4's headline figure. The honest branch, "I don't know how it was counted", is allowed. |
| C2 | "The 40% is a mis-pick rate. What did the pick-path change do to on-time performance and cost per shipment?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message; "drive on-time performance and cost-per-shipment down" — JD | Answer slot: if you measured the pick-path change against on-time or cost per shipment, say what it showed and how it was counted. If you did not, say so plainly, and say what you would measure first. Do not link the two figures. | F4 is a transferability gap. Accuracy is adjacent to the JD's two metrics, and the answer must not imply a link the material does not show. |
| C3 | "Two years of a peak-season surge plan. What did you track to call it a success?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" — your message | Answer slot: name what you tracked, if anything, and which parts of the plan were yours to set. If you tracked nothing, say so, and say what you would track next peak. Do not name a measure the plan did not have. | The surge plan is a second place a prober looks for a measure. The success measure is a practice your quotes do not state, so the answer is a slot. |
| C4 | "What would be in the one report you send every morning across four sites?" | JD | [grounded] "build reporting in Excel/Power BI" — JD; "never used Power BI" — your message | Name the measures the JD names, on-time performance and cost per shipment, and say which you would show first. Say what you would build in Excel, and how you would learn Power BI, as a plan. Use "I haven't used Power BI" for the tool. Claim no report you have built. | Reporting is a JD requirement, and a prober's natural follow-up on F5 and F6. The answer is labelled as a plan. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, over someone who has already run four sites?" | JD | [grounded] "ran the site's peak-season surge plan two years running" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message | Pause, then restate the question in your own words. Answer in the quotes' terms: the surge plan and the 40% cut, both at one site, and your plan for the wider scope. Hold that through two challenges. Concede the scope gap once, precisely, and do not argue the other candidate down. | A time-boxed composure test. The bridge rests on F1 and F4 only. |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Answer slot: say which part of the redesign was yours, in your words, and which was someone else's, if any was. If the redesign was not yours to set, say so plainly. If you did nothing to it, say that. Do not claim the whole change. | Attribution under pressure, which is what this probe is for. The premise is F4's quote, at its own scope. |
| D3 | "Green belt is a course. What have you applied it to?" | EXP | [grounded] "green belt certified" — your message | Answer slot: name what you applied the Green Belt method to, and what you did, in your own words. If you hold the certification and have not applied it to a project, say so plainly, and say what you would apply it to first. Do not name a project you did not run. | F7 is covered by its certificate. This probe tests the gap between certification and application, which the prohibited list guards. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the last seven years." | EXP | [grounded] "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message; "ran the site's peak-season surge plan two years running" — your message; "green belt certified" — your message | A 90-second arc in the order your quotes give: the seven years in warehouse and distribution ops; the current role as senior shift manager over three supervisors; the pick-path change and its 40% cut; the peak-season surge plan, run two years running; then the green belt. Use your own words for each beat, and add nothing between them. | Rapport openers are scored. The arc is a map of your own sentences, in order, with no beat your quotes do not carry. |
| E2 | "What are you playing with in Power BI these days?" | JD | [grounded] "never used Power BI" — your message | Answer with the plain acknowledgment: "I haven't used Power BI." Then say, as a plan, what you are doing to learn it, and only if that is true. Do not answer as if you already use it. | A casual question about a JD requirement is still scored. It presumes use you have not stated, so the answer is the acknowledgment and the plan. |

### F. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to your own managers." | EXP | [generic] | Selection scaffold: pick a time you told a manager something they did not want to hear, with a named stake, a point where you did not soften it, and a working relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | An open prompt from the persona's stem. No values are published, so the story is scored on the behaviour. No claim about you is made. |
| F2 | "Tell me about a time you put a customer ahead of an internal number." | EXP | [generic] | Selection scaffold: pick a time a customer's need and an internal metric pointed different ways, and you chose the customer, with the stake named. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | A second open prompt. Customer seams are common in logistics, and no quote covers this one, so the honest branch is built in. |

### G. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam between operations and the next function, and what happens when we disagree?" | JD | [generic] | Propose principles before pretending to know the seam: ask where it is drawn today, agree who decides when two metrics conflict, and say how you would escalate a disagreement between equals. Do not describe a past disagreement you cannot quote. | The seam probe from the Peer persona. The answer is judgement, not history, and it makes no claim about this team. |
| G2 | "When work spans two sites, how do you handle credit?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Answer slot: say who else worked on the pick-path change, and what each person did, in your words. If you led it alone, say so. If it was not yours to lead, say so plainly. Credit goes to the people who did the work named, not to the role. | A credit-sharing probe on F4's work. The slot names no collaborator, because your quotes do not carry one. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A1, B1, B4, D1 |
| Drive on-time performance and cost-per-shipment down | A1, A2, C2, C4 |
| Lead a team of 12 supervisors | B1, D1 |
| Build reporting in Excel/Power BI | A3, B3, C4, E2 |
| 5+ years operations leadership required | B2 |
| Lean/Six Sigma a plus | D3 |

No requirement is left without a question.

## Reverse questions

No interviewer profile, so none is tied to their path. Each one says why it lands.

1. "Where is on-time performance furthest from target across the four sites today?" Why it lands: it shows you have started on the job's number, not the brochure.
2. "How is cost per shipment calculated, and who checks it?" Why it lands: you learn whether the figures can be trusted, and you invite the definition conversation that F4 needs.
3. "What does reporting look like at the sites now: Excel, a system, or someone's spreadsheet?" Why it lands: it tells you where the Power BI gap actually matters.
4. "What would make you say in six months that this hire was the right call?" Why it lands: you get the success measure before you are measured by it.
5. "What did the last person in this role leave unfinished?" Why it lands: it shows you are thinking about the handover.
6. If your interviewer is a peer: "What could a new person do in their first month that would genuinely help your team?" Why it lands: a reciprocity question a peer answers on the record.

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran daily terminal operations across four sites | Inflated form of F1 | F1's quote at its own scope: "ran the site's peak-season surge plan two years running". Observation in this pack: your material says one site and a seasonal plan. |
| Led twelve supervisors | Inflated form of F2 | "currently a senior shift manager over 3 supervisors", at its own scope. Observation: three is the scale your material shows. |
| Five years of operations leadership | Inflated form of F3 | "7 years in warehouse and distribution ops", at its scope. F3's slot asks how many of those years were leading people. |
| Improved on-time performance or cost per shipment | Inflated form of F4 | "cut mis-pick rate 40% by redesigning the pick path": a mis-pick rate, and nothing else. |
| Built Power BI reporting | Negative you stated, F6 | "I haven't used Power BI." No slot. |
| Applied Six Sigma to the pick-path redesign | Inflated form of F7 | "green belt certified": the certification only. C1 and D3 ask what was applied. |

## Sources

- Provided documents: the JD text and your background, both in your message. No other documents.
- No searches or fetches were run.

Research tier: L0. Research has not been consented to; the question below offers L1.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Values cheat sheet, not included. No values in hand, and no research run |
| 2. `Atlas Freight interview process operations manager` | unavailable | Loop structure; persona weights would firm up from named rounds |
| 3. `Atlas Freight strategy` / recent news | unavailable | Grounding brief and CO questions, not included |
| 4. `{interviewer name} Atlas Freight` | n/a | No name given, so no query could be formed |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you are meeting → persona weights reweighted to the round, and an interviewer read if you give a name
- Your CV → the quotes checked against a document, and F-rows may move toward high confidence
- A copy of your Green Belt certificate → F7 moves from medium toward high
- How the 40% was counted (baseline, period, method) → C1 and F4 get answers grounded in your own figures
- Any on-time or cost-per-shipment figure you have moved → C2 and F4 move from transferability
- Team and site numbers over time (supervisors led, sites run) → B1, B2, F1, F2 and F3 get concrete answers
- A recruiter email with focus areas → persona weights tightened to what they will test
- Research at L1 (up to six searches on Atlas Freight) → values cheat sheet, interview loop structure, current strategy and company questions
- `tuesday-dossier.md`, if you have one → verified evidence and sharper strategy for the weakest areas
