# Kelverton Rail: Senior Partnerships Manager, round 2 prep pack

Panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes. First 15 minutes: spoken POV, no slides, on where to take operator partnerships over the next 18 months, landing on what it means for the operators. Remaining 45 minutes: Q&A, with commercial pushback from Ross.

Built from: your message and the recruiter's brief as you quoted it. No JD text and no market report text were in this session, so the fit snapshot uses role-family requirements and the POV has no differentiation against the report yet (see the upgrade menu). Research tier: L0.

## 2. How to use, and type key

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **A** bank = Deepa. **B** bank = Ross. **C** = the opener.
- Types: **VAL** values, **EXP** experience deep-dive, **JD** role-driven, **CO** company and commercial knowledge, **CASE** live problem.
- Guidance is scaffolding, not a script. Answer slots are instructions for the interview, not questions to answer here.
- This pack has 13 questions, under the usual 18 to 26, because of the four-hour budget. The highest-weight ones are the ones to rehearse.

## 3. Prep triage (about 4 hours)

1. **The POV, about 75 min.** Build it from section 5, speak it aloud three times, and cut it to about 12 minutes so the 15-minute slot has room. Everything else is insurance until this is solid.
2. **B2 and B1, about 45 min.** The quota and the £4M figure, aloud, until the hold-then-concede in B2 comes without thinking. B2 is the highest-ROI prep in this pack: Ross will push on commercials, and a folded answer here costs the most.
3. **A2 and A3, about 30 min.** "You've never sold into rail." Plain, unhedged, then the bridge.
4. **Remaining questions, about 45 min.** One pass each, about 90 seconds per answer.
5. **Reverse questions, about 10 min.** Pick your top three from section 10.

Total about 3 hours 25 minutes. The remaining 35 minutes are buffer. Everything else is insurance.

## 4. Fit snapshot

No JD supplied, so requirements are role-family prose (`[generic]`) unless quoted from your message. Evidence cells quote your words only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Sell into train operating companies (role family) | "Never sold into rail specifically" — your message | high | [grounded] | capability | Your stated absence, so the words are yours: "I haven't sold into rail." No rail win is implied. The adjacent ground is F5. Answer slot: if you have operator contacts from the consulting years, say what they were; if none, say so. |
| F2 | Carry a revenue number and own it (role family) | "never carried a direct quota" — your message; "roughly £4M of influenced revenue" — your message | high | [grounded] | capability | Your stated absence: "I haven't carried a direct quota." Then the figure as you gave it: "My revenue figure is influenced revenue, roughly £4M." |
| F3 | Grow a partner or channel base (role family) | "took it from 6 partners to 40" — your message | high | [grounded] | presentation | The quote already reaches channel growth. Reword only: "I took it from 6 partners to 40." No added practice. |
| F4 | Defend commercial results: how they were counted, and what was yours (role family) | "roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | Your material gives the figure and the word "influenced", not how it was counted or which part was yours. Answer slot: how the figure was counted, the assumption you would defend least, and which part was yours, in your own words. If you do not know how it was counted, say so. |
| F5 | Understand how operators plan and buy (role family) | "5 years in transport consulting" — your message; "bus and light rail network planning" — your message; "so I know the operator world from the other side" — your message | medium | [grounded] | transferability | The quote carries adjacent work: planning on the operator's side, not a sale to one. Words: "I spent five years in transport consulting on bus and light rail network planning." Any wider step is an answer slot inside that scope: which planning decisions you supported, and whose they were. |
| F6 | Run a long, procurement-led sales cycle (role family) | none given | none | [generic] | discovery | Silence is not a negative. Answer slot: if you have run a cycle longer than a few months, say what it was and what you did in it; if not, say so, and say how you would learn it. |

Seven rules are enforced in this table's gap types. Each gap type is set by the evidence cell, not by how the row feels.

## 5. Graded deliverable: the 15-minute POV

**Grounded facts to build on:** F5 ("bus and light rail network planning") and F3 ("took it from 6 partners to 40"). Use these two as the only past material in the POV. Do not use rail sales as proof of anything.

**Structure (about 12 minutes spoken):**
1. **The operator's problem (about 2 minutes).** Describe a planning day from the operator's side: the timetable change window, who signs off, what goes wrong. Use the language a planner would use, not partnership language.
2. **Thesis 1 (about 4 minutes).** *Partnerships should start from the operator's planning calendar, not our product roadmap.*
   - *Operator consequence:* a planner gets something usable in the next change window, not a feature to wait for.
   - *Mandatory concession:* I haven't sold into rail (F1), and I don't yet know the procurement windows. I would test this with two or three operators before committing to it.
3. **Thesis 2 (about 4 minutes).** *Partner value in rail should be measured in operator outcomes, and the commercial model should follow.*
   - *Operator consequence:* the operator pays for a planning result it can measure, not for seats or licences.
   - *Mandatory concession:* outcome-based pricing is hard to attribute and may not fit how publicly funded operators buy. Ross will push here, so have the concession ready in your own words.
   - *Anti-pick:* the consensus answer is whatever the market report's shortlist says. I can't name it until you paste the report (see the upgrade menu). Differentiate from it, and say where you depart from it and why.
4. **Close (about 1 minute).** Requested by the recruiter: what it means for operators. One sentence per thesis, in the operator's terms, with no partnership vocabulary.

**Context you should check before you say it aloud:** the UK rail operator landscape has been moving toward public ownership and a more centralised planning model. That is my general knowledge, marked `[generic]`, not a checked fact. Confirm the current position before using it in the POV.

## 7. Reading the interviewers

Only titles are known: Deepa, VP Partnerships, your future manager; Ross, Commercial Director. No public footprint was researched (L0), so no career pattern or mirror opportunity is offered. Persona weights below use their roles.

## 8. Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Pressure (Ross) | Pushes on the quota and the £4M | High. A Commercial Director on a round 2 panel, with the recruiter flagging commercial pushback. | Hold-then-concede (B2). Hold the bridge through two follow-ups; concede the quota plainly. |
| Data-Driven Prober (Ross) | Asks how the influenced revenue was counted | High for any headline figure. Every CV number gets a defend-the-number slot. | Defend-the-number slot (B1). Name the weakest assumption before he does, or say you don't know how it was counted. |
| Case/Strategist (Deepa) | Live operator planning problem | High. Hiring-manager prior, and she is buying capability. | Clarify, structure, metrics. Name the operator constraint before proposing a plan (A1, A6). |
| Skeptic (Deepa) | "You've never sold into rail" | High. The biggest gap (F1) sits in the hiring manager's core requirement. | Plain acknowledgment, bridge at its own scope, ramp plan (A2, A3). |
| Conversational (both) | Opener, "walk me through your background" | Medium. The opener sets the frame for the rest of the hour. | 90-second arc (C1), ending on the bridge toward operators. |

**Weights:** Deepa's bank (A, six questions) and Ross's bank (B, six questions) are both weighted high because the panel splits the two roles evenly. The opener is one question.

## 9. Question banks

### Bank A: Deepa (Case/Strategist and Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "An operator's planning team says they would rather build scheduling in-house than buy it. What do you do?" | CASE | [generic] | Clarify first: what the in-house build covers, what it leaves out, who signs off. Then structure: the decision the planning team owns, the cost of getting it wrong in a change window, and the test you would propose. Make no claim about your past. About 90 seconds. | A live operator-side problem, which is the role's core. Generic because it is a pattern, not a fact about Kelverton. Case/Strategist prior. |
| A2 | "You've never sold into rail. Why would an operator take a call from you?" | JD | [grounded] "Never sold into rail specifically" — your message; [grounded] "so I know the operator world from the other side" — your message | Plain acknowledgment: "I haven't sold into rail." Then the bridge, at the scope of F5: the operator view you got from planning work. Answer slot: if you have operator contacts from the consulting years, say what they were; if none, say so. Hold the bridge once; do not argue the rail point. | Highest-ROI in the Skeptic bank after B2. It is the most predictable objection, and it sits in the hiring manager's core requirement. |
| A3 | "What would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" — your message | Name the rail sales cycle and regulated procurement as the gap, in your own words: "I haven't sold into rail." Then a ramp plan you would actually run: three operator conversations, what you would learn from each, and what you would bring back in 90 days. A plan, not a past. | Skeptic stem aimed at F1 and F6. |
| A4 | "Your background is payments. What transfers to operators, and what doesn't?" | JD | [grounded] "a payments company running the ISV channel" — your message | Say what does not transfer first; it lands better. Buyers' decision timelines in payments are not operator timelines. Then what does transfer: "took it from 6 partners to 40" — your message, quoted at its own scope. No claim about what the channel did beyond the quote. | Tests fit on the role's own terms. Both halves rehearsed, so the honest answer is ready before the probe. |
| A5 | "Walk me through how you took the channel from 6 partners to 40." | EXP | [grounded] "took it from 6 partners to 40" — your message | Story-mapped to the quote only: the six, the forty, and the last four years at the payments company. Answer slot: which steps you set and decided, and which were the company's or other people's; if you can't separate them, say so. Do not add partner names or deals. | Partner scale is your strongest number. Deepa will want the operating model behind it. Premised only on the quote. |
| A6 | "Where would you start in your first 90 days?" | JD | [generic] | Three things, as a plan: the operators you would meet first and why, the internal data you would need, and the one metric you would report. No past claim. | Manager-level question, generic because it tests planning, not history. |

### Bank B: Ross (Pressure and Data-Driven Prober)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "£4M of influenced revenue. How was that counted, and how much of it was yours?" | EXP | [grounded] "roughly £4M of influenced revenue" — your message | Defend-the-number slots: how it was counted, the assumption you would defend least, and which part was yours, in your own words. Answer slot: if you do not know how it was counted, say so plainly. Do not offer a method. Do not turn "influenced" into "booked". | The headline figure and the most likely commercial probe. The pack adds no method, because the material has none. |
| B2 | "You've never carried a quota. Why should I trust you with a revenue target?" | Pressure, JD | [grounded] "never carried a direct quota" — your message; [grounded] "roughly £4M of influenced revenue" — your message | **Hold-then-concede.** Hold: "My revenue figure is influenced revenue, roughly £4M." Through the second follow-up, do not argue the quota point. Concede plainly: "I haven't carried a direct quota, and that is a real gap for this role." Then one measure you would propose for your first 90 days. | **Highest-ROI prep in this pack.** A folded answer here costs the most, and Ross will push on commercials. |
| B3 | "Operators are funded through government contracts. How would you price a partnership with one?" | CO | [generic] | Clarify who pays, and on what contract terms, before naming a price model. Then test the price against the operator's own budget line. No past claim. Say what you would verify first, since you don't yet know the current contract terms. | Tests commercial altitude on the operator's economics. Generic because the funding structure is outside the material. Check it before you rely on it. |
| B4 | "Rail sales cycles are long and procurement-led. What in your experience says you can sustain that?" | JD | [grounded] "last 4 at a payments company running the ISV channel" — your message | Honest branch: if you have a real figure for the length of cycles at the payments company, say it in your own words. If the cycle was not one you were measured on, say so: "I haven't sold into rail," then the bridge to F5. | Pressure on F6. The honest branch is the answer; a stretched one is the failure. |
| B5 | "Give me a deal you lost, and why." | EXP | [generic] | Selection scaffold: pick a time you did not get the outcome you pushed for, name what you would change, and say what you learned. If you cannot name a lost deal, say so plainly and give the nearest partner or channel outcome you can stand behind. | Open prompt, not premised on any event. Tests candour under pressure. |
| B6 | "What does 'influenced' mean in your number, and would your own finance team agree?" | EXP | [grounded] "roughly £4M of influenced revenue" — your message | Defend-the-number slot: say what "influenced" meant in your own counting, in your own words. Answer slot: if the finance team never reviewed the number, say so. Do not claim their agreement. | A second, sharper probe on F4. Ross tests whether the figure survives someone else's review. |

### Opener

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through your background." | EXP | Open prompt. [grounded] "9 years in partnerships" — your message; "5 years in transport consulting" — your message; "last 4 at a payments company running the ISV channel" — your message | 90-second arc: operator-side planning first, then the channel, then the influence number, ending on the bridge toward operators. Do not claim rail. | Sets the frame for both panellists. Pre-scripted so the opener doesn't run long. |

### Requirement coverage (role-family, no JD)

| Requirement | Covered by |
|---|---|
| Sell into train operating companies | A2, A3, B4 |
| Commercial ownership and a revenue number | B1, B2, B6 |
| Channel and partner growth | A4, A5 |
| Operator planning knowledge | A1, C1 |
| Commercial model and pricing | B3 |
| Long sales cycles | A3, B4 |
| 90-day plan | A3, A6 |

## 10. Reverse questions

Each has a "why it lands."

1. **To Deepa:** "What does a first-year win look like in this role, and who signs it off?" *Why it lands:* separates the sponsor from the scorecard, and shows you are planning for the job.
2. **To Deepa:** "Which of your current operator partnerships would you hold up as the model, and why?" *Why it lands:* asks for her bar, not a pitch.
3. **To Ross:** "How is influenced revenue credited on an operator deal today, and where does that break?" *Why it lands:* shows you already know the commercial problem his pushback is about.
4. **To Ross:** "What would make the commercial case for an operator partnership clear enough to close?" *Why it lands:* thinks in deal terms.
5. **To Deepa:** "What have your operator partnerships been missing that you'd want this role to fix?" *Why it lands:* turns the hiring manager into a collaborator. A tie to her own career path needs her public profile (see the upgrade menu).

## 13. Prohibited claims

Built from the fit snapshot. The honest form is what you can say.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have sold into rail" | Your stated negative: "Never sold into rail specifically" | "I haven't sold into rail." |
| "I have carried a quota" | Your stated negative: "never carried a direct quota" | "I haven't carried a direct quota." |
| "I owned" or "closed" £4M | Inflated form of "roughly £4M of influenced revenue" | The quote at its own scope. The limit is the pack's observation: your material says influenced revenue, not booked or owned revenue. |
| "I built the ISV channel" | Inflated form of "took it from 6 partners to 40" | "I took it from 6 partners to 40." |
| "I have operator relationships" | Inflated form of "so I know the operator world from the other side" | The quote at its own scope: planning work, and the operator view it gave you. No contacts claimed. |

## 14. Sources

- Provided: your message (background and the panel brief as you quoted it from the recruiter's email).
- Not provided in this session: the market report. You read it; this pack has not used it.
- **Research tier: L0.** No searches or fetches were run.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Kelverton values | unavailable (L0) | The POV's vocabulary and close |
| 2. Kelverton interview process, Senior Partnerships Manager | unavailable (L0) | Loop weights beyond this round |
| 3. Kelverton strategy and recent news | unavailable (L0) | The POV theses; the rail landscape, checked now and not from memory |
| 4. Deepa and Ross public footprint | unavailable (L0) | Interviewer read; reverse questions tied to their paths |
| 5. Representative JD | unavailable (L0) | Fit snapshot rows from `[generic]` to `[inferred]` |

## 15. Upgrade menu

- **Market report key points** (the segments, headline numbers and the shortlist) → the POV's anti-pick and differentiation, and a concrete answer to the "consensus" thesis.
- **JD text** → fit snapshot requirements become `[grounded]`; JD-tagged questions are checked against the list.
- **Research at L1** (up to 6 searches and 2 page fetches, your consent needed) → current company strategy, and the rail landscape as it stands now.
- **Deepa's and Ross's public profiles** → an interviewer read, and a reverse question tied to Deepa's path.
- **The recruiter's prep email**, if it names a graded deliverable beyond the POV → a build section for it.
- **`tuesday-dossier.md`** → would record the gaps this prep exposed, for later sessions.
