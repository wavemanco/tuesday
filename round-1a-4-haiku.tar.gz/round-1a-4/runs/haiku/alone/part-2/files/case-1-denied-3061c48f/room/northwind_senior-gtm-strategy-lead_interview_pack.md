# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer, reports to the same VP. **Round:** one 60-minute conversation.

**Assumption this pack is built on:** a peer round in one session, built from your JD highlights, Priya's background as you described it, Dan's profile as you described it, and your research notes. No full JD text, no recruiter guidance and no searches were used.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script.

| Type | Name | What it scores |
|---|---|---|
| EXP | Work-experience deep-dive | Whether the CV's claims survive scrutiny, and what Priya actually did |
| JD | Role and JD-driven | Whether she can do the listed job, including its gaps |
| CO | Company and strategy knowledge | Whether she thinks at Northwind's altitude, from current strategy |
| CASE | Live problem | Structure and reasoning on a problem from the role, delivered live |
| VAL | Behavioral and values | Not used here: this is not a values round, and no published values were supplied |

Answer slots in the guidance are instructions for the interview. They are not questions to you, and they ask for no reply in this conversation.

## 2. Fit-gap map

Requirements are your JD highlights, quoted as you supplied them. The full posting may use different words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — coach's notes | medium | [grounded] | transferability | The notes show a revenue model and its use in carrier negotiations. They do not show a go-to-market plan for a product line, so the bridge stays at the model's scope: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you set launch scope, targets or sequencing for a product line, say which and how you decided; if none of that was yours, say so and stay with the model. |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "set annual volume targets with cross-org consensus" — coach's notes | medium | [grounded] | transferability | Target-setting is adjacent to whitespace work, not the same analysis. Say the targets in those words and do not call it whitespace. Answer slot: if you set the targets from a view of where volume was and was not, say which stages it covered; if the targets came from elsewhere, say so. |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — coach's notes | low | [inferred] | discovery | "Skilled" is a self-description. The notes do not show an analysis run from start to finish, so the bridge stays a lead. Answer slot: name one analysis you ran in SQL or Tableau, if you did, and the input that would have changed its answer; if you did not, say so and say how you would scope one for this role. |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — coach's notes | medium | [grounded] | discovery | The word "required" makes this the largest gap. The notes do not show designing a partner motion, and the revenue model is the nearest sentence. Answer slot: if you designed a partner arrangement, name it and how its terms were set; if you did not, say so plainly, then say what the revenue model does carry. |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — coach's notes | medium | [grounded] | none | The quote already reaches influence across functions. Expect a probe on how consensus was reached, because a consensus claim has nothing inspected behind it. |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — coach's notes | low | [inferred] | discovery | Daily use is not building. Say it as use. Answer slot: if you have built something with AI, name it and your part; if you only use the tools, say that. |
| F7 | Headline figure, not a JD requirement | "proposed a store-surface change credited with a ~$400M ARR uplift" — coach's notes | medium | [grounded] | none | No gap in the row itself, but the figure is the CV's largest claim. It raises the defend-the-number slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. |
| F8 | No JD line; the interviewer's title is Director of Sales Strategy — your message | "No classic sales-ops or quota-setting experience" — coach's notes | none | [grounded] | capability | A gap you stated, so the words can be given back: "I don't have classic sales-ops or quota-setting experience." Confirm that wording is hers before the interview. Never claim quota or sales-ops work. |

**Pack's own observation:** the material shows no go-to-market plan for a product line and no partner-motion design. Those are the JD's two most specific lines, so they will likely be the first probes. The pack prepares for them directly.

## 3. Prohibited claims

These claims are not coached anywhere in this pack. Each entry gives its basis and the honest form to use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns go-to-market for product lines | Inflated form of F1 | F1's quote at its own scope. The notes show a revenue model, not a product-line plan. |
| Designed partner motions | Inflated form of F4 | F4's quote at its own scope. The notes do not show partner-motion design. |
| Set quotas or ran sales ops | Negative she stated (F8) | "I don't have classic sales-ops or quota-setting experience." No slot. |
| Volume targets are quotas | Inflated form of F2 | "Set annual volume targets with cross-org consensus," described as target-setting. |
| The $400M was hers alone | Inflated form of F7 | "Credited with," with the answer naming which part was hers. |
| Expert in SQL, Tableau or AI | Inflated form of F3 and F6 | "Skilled in SQL/Tableau" and "uses AI tools daily," said as the notes say them. |

## 4. Reading the interviewer

**Career pattern (your notes):** pricing and monetization roles, with one early-stage startup chapter. **Self-description:** "relentlessly data-driven." Public footprint was not checked, so talks, writing and career details beyond your notes are unverified.

**Practical implications:**

1. Every number Priya gives will be treated as a claim to test. Expect denominators and attribution on F1, F2, F4 and F7.
2. Case questions will come through a pricing and monetization lens, including the bundling threat.
3. The startup chapter suggests builder stories will land with him. Expect a probe on big-company pace, and answer it from what she did, not from a defence of the company.
4. Same VP means disagreements have a real escalation path. Credit and seam questions are likely.

**Mirror opportunities:** no shared career jump exists, because Priya has no startup chapter. The shared vocabulary is monetization. F1's quote, "built a partner-level revenue model used in carrier negotiations," is the sentence to use in that vocabulary, at its own scope. Do not build on affinity.

## 5. Grounding brief (your research notes)

Treat these as your notes, not verified facts. Use the names as written, and do not describe product features beyond the names.

| Item | Source | Status |
|---|---|---|
| Three stated priorities: enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability | your research notes | grounded in your notes; unverified |
| Main competitive threat: bundling by a much larger platform vendor | your research notes | grounded in your notes; unverified |
| Current segmentation language, leadership, recent moves | none supplied | not established; L1 would check |

## 6. Persona weights and bank plan

Relationship prior for a peer: Peer Evaluator and Data-Driven Prober. Dan's self-described data-driven style moves the Prober up. His pricing spine moves the case questions toward pricing and packaging. The startup chapter adds builder-story weight.

| Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Data-Driven Prober | Attribution and denominator probes on the CV figures | Highest. He describes himself that way, and the peer reads the CV closely | Name the weakest assumption before he does; say plainly when you do not know how a figure was counted | A1 to A5 (5) |
| Peer Evaluator | Seam, credit and division-of-work questions | High. Same VP, so the seam is live | Propose seam principles, not a map of his team; credit precisely | B1 to B4 (4) |
| Case / Strategist | Bundling, expansion whitespace, profitability, Compass | Medium-high. His pricing spine and the three priorities make these his questions | Clarify, then structure, then challenge one premise aloud | C1 to C4 (4) |
| Skeptic | The JD's required partner line and product-line GTM | Medium. The two gaps in the fit map are the likeliest peer objections | Hold to the quote's scope; concede only what she did not do | D1 to D3 (3) |
| Pressure | Attribution of the $400M; the partner line | Low. A peer round, not a stress round, but the figure is the one most likely to be pressed | Pause, restate, hold, concede one named thing | E1 to E2 (2) |
| Conversational | Journey opener; AI plus asked casually | Low, but scored. Casual openers still carry weight | Pre-scripted 90-second arc; answer the AI question as use | G1 to G2 (2) |

Total: 20 questions. The Prober, Peer and Case banks carry most of the round.

## 7. Question banks

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Say what the figure measures and over what period, only as far as you can say it. Name the assumption you would defend least before he does. Answer slot: if you know how the uplift was attributed to the store-surface change, say how in your own words; if you do not know how it was counted, say so plainly and name who would. Keep "credited with," not "drove." | Top-weight question on the headline figure (F7). EXP because it tests attribution. The defend-the-number slots are the ones a figure raises. |
| A2 | "Which input in the partner-level revenue model would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Name the input and what changes in the answer if it is wrong. Say which inputs you built and which you took as given. Answer slot: if you built the inputs, say which; if they came from others, say whose, in your words. Do not describe inputs you cannot repeat under a second follow-up. | The question presupposes only the quoted model. Assumptions and attribution are where a monetization peer goes next (F1 and F4). |
| A3 | "Walk me through how the annual volume targets were set, and what the cross-org group agreed on." | EXP | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Describe the sequence: the question the target answered, who had to agree, and what they agreed on. Answer slot: if a figure you analysed set the target, name the source and what you checked; if someone else's model set it, say so. Do not call the targets quotas. | F2's quote, and the denominator behind a consensus claim (F5). The guidance says "targets," so the answer does not blur into quota work, which D3 raises. |
| A4 | "Which analysis in SQL or Tableau would you walk me through start to finish?" | EXP | [inferred] "skilled in SQL/Tableau" (coach's notes) | Answer slot: name one analysis you ran in SQL or Tableau, end to end, and the input that would have changed its answer; if you have none to name, say so and say how you would scope one for this role. "Skilled" is a self-description, not an analysis. Do not turn it into one. | F3 is discovery: the skill is named and the independent work is not shown. A monetization analyst will ask for the analysis itself. |
| A5 | "How do you decide a Tableau number is ready to act on?" | JD | [grounded] "run independent analysis in SQL and Tableau" (JD highlights, your message) | Describe how you check a number before acting. If your check is a habit you have run, say so; if it is a plan, say it is a plan. Keep it to two minutes. | Covers R3 (the JD's analysis line) with a method question that asks for judgement, not an event. The premise is the JD's line. |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between your work and mine, and what happens when we disagree?" | JD | [grounded] "strong cross-functional influence" (JD highlights, your message) | Propose seam principles, not a map of his team: how a price or package decision gets made, who owns the pipeline call, and how a disagreement between equals goes to the shared VP. Answer slot: if you disagreed with an equal and changed the outcome, say what the disagreement was and what landed; if you have not, say how you would raise it first. | Peer stem. R5 is the JD's influence line, and the shared VP makes the escalation path real. |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Separate what you proposed from who shaped it and who shipped it. Use "credited with," as the notes do. Answer slot: if the change needed other teams to ship, name them and what each did, in your words. Never claim the uplift alone. | A peer credit probe, aimed at F7 because that is where a credit question lands. EXP, because the answer is about what was hers. |
| B3 | "What would you need from the sales side in your first 90 days to build the two product-line plans?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights, your message) | Name two or three inputs you would need from the sales side and what each unblocks. Make it a request, not a grievance. | The peer's load question: whether the hire adds to his work or reduces it. A specific request shows you have thought about the seam. |
| B4 | "Partner motions cross sales and product. How would you divide that work with a sales strategy team?" | JD | [grounded] "partner-motion design experience required" (JD highlights, your message) | Give a division principle: who decides what a partner sells, who sets its terms and coverage, who measures it. Answer slot: if you have divided partner work with a sales team, say how, in your words; if not, say the principle you would start from, and say it is a plan. | R4 from the peer side. The principle-not-past structure keeps the honest branch open, and it is the seam a pricing lead will care most about. |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our biggest threat is a much larger platform vendor bundling. How would you build a go-to-market for a new product line against that?" | CASE | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research notes) | Clarify first: is the bundle a price, a feature or a contract term? Then objective, segments, approach, metrics and risks, thinking aloud. Challenge one premise, respectfully. Lead with what bundling does to unit economics. Do not name the vendor or its products. The notes are unverified. | Bundling is his native problem, and R1 is the JD line the case tests. The quote comes from your notes and is unverified. |
| C2 | "Enterprise expansion is a stated priority. Where is the whitespace across land, adopt, expand and renew?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights, your message); [grounded] "enterprise expansion" (your research notes) | Frame the whitespace by lifecycle stage. Name the data you would need first, and do not assume it exists. Name one metric that moves at each stage you pick. Price behaviour at expansion is the pricing angle. This answer makes no claim about her past. | R2 is the JD's whitespace line, and expansion is a stated priority. The lifecycle language is the JD's, so mirror it in the answer's structure, not in her history. |
| C3 | "Compass is our AI copilot launch. How would you position it to the sales team?" | CO | [grounded] "an AI copilot launch ('Compass')" (your research notes) | Know only what the name tells you. Do not describe features. Say what you would need to learn first: who buys it, which lifecycle stage it touches, and whether it sits inside something bigger or is sold on its own. | Current company strategy from your notes. CO because it tests current strategy. Unverified, so the answer stays generic beyond the name. |
| C4 | "We need to reach profitability. Where does a GTM plan add margin without costing us expansion?" | CASE | [grounded] "reaching profitability" (your research notes); [grounded] "enterprise expansion" (your research notes) | State the tension first: margin against expansion. Name the metric you would watch on each side. Challenge one premise: a margin gain that costs expansion is not yet a gain. Use the same structure as C1. | Profitability and expansion are two of the three stated priorities, and the tension between them is the case. |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This role requires partner-motion design. Which partner arrangement have you designed, and how did you set its terms?" | JD | [grounded] "partner-motion design experience required" (JD highlights, your message); [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Hold: the model you built, at its scope, a revenue model used in carrier negotiations. Answer slot: if you designed a partner arrangement, name it and how its terms were set; if you did not, say so plainly, then say what the revenue model does carry and how you would design the motion. Hold through two follow-ups by returning to the model's scope. Concede only the design you did not make. | **Highest-ROI prep in this pack.** "Required" is the JD's strongest word, and F4 is the gap a peer is most likely to press. Candidates are most tempted to thicken the story here. |
| D2 | "The role owns go-to-market for two new product lines. Which launch have you owned from plan to result?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights, your message); [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Answer slot: if you ran a launch's plan from start to result, name it and say which parts were yours; if no launch of yours went that far, say so plainly and say what in the revenue model carries over. Keep the carry-over at the model's scope. Do not call the model a launch plan. | R1 is the requirement the JD leads with. F1 is transferability at most, so the bridge stays at the model's scope. |
| D3 | "You haven't set quotas before. Why should a sales strategy team trust your numbers on them?" | EXP | [grounded] "No classic sales-ops or quota-setting experience" (coach's notes); [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Start with the plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." Then the nearest thing you have done, at its own scope: "set annual volume targets with cross-org consensus," and say it is target-setting, not quota-setting. Then how you would approach quotas, as a plan, not a past. Concede that quota mechanics are new to you. | F8, a gap she stated, so the acknowledgment is allowed. The question rests on her stated negative, and its likelihood comes from the role's sales-strategy remit. |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has built partner programmes for years?" | JD | [grounded] "partner-motion design experience required" (JD highlights, your message) | Pause and restate the question. Hold to what you can back: "built a partner-level revenue model used in carrier negotiations" and "set annual volume targets with cross-org consensus." Concede the one thing you would concede in advance: if you have not built a partner programme, say so in those words and go to your plan. Do not claim years of partner programmes. | A stress stem on the required partner line. The hold uses only quoted claims, and the concession is named before it is needed. |
| E2 | "That ~$400M, how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Hold the claim you can back: you proposed the store-surface change, and the uplift was credited to it. Concede the exact boundary: name which part of the credit is yours and which is shared, in your words. Answer slot: name the part that was yours; if the proposal went through others' decisions, say which. Hold through two follow-ups. Never fold on "proposed." | Pressure on the most consequential claim in the CV. Keep the hold (the proposal) and the concession (the credit) separate. |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" (coach's notes); [grounded] "built a partner-level revenue model used in carrier negotiations" and "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | A 90-second arc in this order: consulting, then product strategy and ops at a consumer-tech company, the revenue model and the store-surface change, and why this role. Each beat is a sentence from above. Add nothing. | A casual opener that is still scored for economy. The arc is fixed in order, and every beat is a quoted sentence. |
| G2 | "What are you actually playing with in AI these days?" | JD | [inferred] "AI experience a plus" (JD highlights, your message); "uses AI tools daily" (coach's notes) | Name the tools you use daily and what you use them for. Say it as use. Answer slot: if you have built something with AI, name it and your part; if you only use the tools, say that and say what you would want to test with Compass. | A plus asked casually, and still scored. The low confidence in F6 is why the label is inferred and the answer stays at use. |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| R1 own GTM strategy for two new product lines | B3, C1, D2 |
| R2 identify whitespace across land/adopt/expand/renew | C2 |
| R3 run independent analysis in SQL and Tableau | A4, A5 |
| R4 partner-motion design experience required | B4, D1, E1 |
| R5 strong cross-functional influence | B1, B2 |
| R6 AI experience a plus | G2 |

Other coverage: the $400M figure (A1, B2, E2), the volume targets (A3), the revenue model (A2, D1, D2, G1), the missing quota experience (D3), and the stated priorities (C2, C3, C4, RQ4).

## 8. Reverse questions

Each question has a reason it lands. RQ1 ties to Dan's own path, and RQ2 is the reciprocity question for a peer.

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Your career has run through pricing and monetization, with an early-stage startup along the way. What from that startup still shapes how you price?" | Built from his profile, so it turns an interview into a peer conversation about his path. Use only what you have read; his profile is unverified beyond your notes. |
| RQ2 | "What could someone in this role do in the first month that would genuinely help your team?" | Reciprocity: it shows you think about what you bring to his team, not only what you need. |
| RQ3 | "Where do sales strategy and product disagree most on pricing or Compass, and how does that get settled?" | Asks about the seam directly, and the answer shows the escalation path through the shared VP. |
| RQ4 | "Of enterprise expansion, Compass and profitability, which one gets traded off against the others right now?" | Names the tension in the priorities and shows you read the notes. Priority wording comes from your notes, so use Northwind's own wording if you find it. |
| RQ5 | "How do you expect the bundling threat to land first: on pricing, on packaging, or on the sales motion?" | Connects the threat to his pricing home, and it works as a case question too. |
| RQ6 | "What does success look like for the two product lines at the end of year one?" | Shows you think in outcomes, and it asks the JD's own question back. |

## 9. 60-minute conversation plan

You asked for a timing plan, which sits outside the pack's standard sections. Times are a plan. Dan sets the pace, so the top-weight questions matter most.

| Minutes | Segment | Questions | Notes |
|---|---|---|---|
| 0 to 4 | Open, journey | G1 | Give the 90-second arc, then stop. |
| 4 to 12 | Experience deep-dive | A1, A2, A3 | Defend the $400M and the model. Hold each answer to its quote. |
| 12 to 22 | Case | C1, C4 | Clarify first. C2 and C3 if time allows. |
| 22 to 30 | Skeptic and partner gap | D1, D2 | Highest-ROI prep. Hold through two follow-ups. |
| 30 to 38 | Peer seam | B1, B4 | Propose principles, not a map of his team. |
| 38 to 44 | Quotas and credit | D3, B2 | Acknowledge the stated gap in those words. |
| 44 to 48 | Analysis and AI | A4, A5, G2 | Answer in use, not in claims of building. |
| 48 to 55 | Reverse questions | RQ1, RQ2, RQ3 | RQ1 and RQ2 first. |
| 55 to 60 | Close | RQ4 or RQ5 | Hold E2 for whenever A1 or B2 is pressed. |

Not every question gets time. If he presses a point, follow the pressure. If the pressure is on the partner line or the $400M, go to D1 or E2.

## 10. Sources

- **Provided documents:** your message, which holds the role, JD highlights, candidate background, interviewer profile and research notes. No dossier was used.
- **Searches and fetches:** none. This pack is built on provided documents only.

**Research tier: L0 — no searches**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | skipped | No values-style round was detected and no published values were supplied, so there is no values section to move. |
| 2. Northwind interview process, GTM | skipped | The single 60-minute conversation you described fixes the structure as one session. |
| 3. Northwind strategy and recent news | unavailable | You chose L0. A search would verify the three priorities and bundling threat that C1 to C4 and the grounding brief rest on. |
| 4. Dan Kovac, public footprint | unavailable | You chose L0. A search would read his public talks and writing, which would sharpen RQ1 and the persona read. |
| 5. Representative GTM strategy lead JD | skipped | Your JD highlights fix the requirement lines, so no representative JD was needed. |

## 11. Upgrade menu

- **Full JD text** → the six highlights become the posting's own requirement lines, and the fit map's quotes come from the posting rather than your highlights.
- **Dan's public footprint, at L1** (up to six searches and two page fetches; you consent) → persona weights and RQ1 check against his own words, and the shared-jump check becomes real.
- **Northwind's strategy and recent news, at L1** → verifies the three priorities and the bundling threat that C1 to C4 currently rest on your notes.
- **L2 deep research** (four further targets, up to six more searches and two more fetches; offered once, run only with your go-ahead) → adds role-family loop reports and recent org context.
- **A recruiter's note on focus areas or a pre-declared assignment** → a build section for any graded deliverable.
- **Your own wording for the sales-ops negative** → D3's acknowledgment in your words, not mine.
- **Work arrangement or location, if it is a requirement you must meet** → a gate row in the fit map.
