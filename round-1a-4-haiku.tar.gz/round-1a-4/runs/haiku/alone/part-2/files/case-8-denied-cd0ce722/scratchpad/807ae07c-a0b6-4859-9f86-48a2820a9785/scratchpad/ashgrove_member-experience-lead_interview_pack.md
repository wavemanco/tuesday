# Member Experience Lead, Ashgrove Credit Union: interview prep pack

Prepared for Dara, 24 November 2026. Interviews are on 3 December 2026.

**Loop: three rounds on one day**
1. Recruiter screen, 30 min
2. Head of Member Services, 45 min. This is your manager, and the round is mostly behavioural.
3. Panel of two branch managers, 60 min. It includes a 20-minute complaint-escalation case, and the panel scores you against the four values.

Interviewers beyond the recruiter and the Head of Member Services are not assigned yet.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

- **VAL**: behavioural, values alignment. Does past behaviour show the four published values?
- **EXP**: experience deep-dive. Do your CV's claims hold up when probed?
- **JD**: role-driven. Can you do the listed job, gaps included?
- **CO**: company and strategy. Can you think at their altitude?
- **CASE**: a live problem from the role.

Guidance is scaffolding, not a script. Text in quotation marks is your own sentence, copied from what you told me. An **answer slot** is an instruction for the interview: answer from what you did, or say plainly that it was not yours or did not happen.

## Sources and research tier

Research tier: L1, but no search or fetch ran. Your inputs fixed every target (see the accounting at the end).

Provided documents:
- Your job description, as pasted.
- Ashgrove's values, as pasted from ashgrovecu.org/about/values on 24 November 2026.
- The recruiter's process email. It says: "The panel is also the values round - they score against the four values."
- Four strategy lines from the July 2026 brief, as you pasted them. **I have not read the full brief.** Nothing here goes beyond those lines.
- Your background, as you described it.

## Fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your own message. There are no gate rows: the JD names no licence, credential or eligibility term, and location, notice and pay are not in the JD at all (they are Round 1 logistics slots).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" - JD | "6 years in retail banking, the last 3 as a branch supervisor" - your message | medium | [grounded] | presentation | Say it in those words: six years in retail banking, the last three as a branch supervisor. Your message gives no inspectable proof, so expect a probe. |
| F2 | "experience handling regulated complaints" - JD | "I handled the branch's formal complaints log" - your message | medium | [grounded] | transferability | Your material shows formal complaints handled at branch level. It does not show a regulated framework. Words: "I handled the branch's formal complaints log." Answer slot: if the log followed a complaint-handling rule set, name it and what it required of you; if it did not, say so and describe how you handled the log. |
| F3 | "confident presenting to senior leaders" - JD | "I've never presented to anyone above regional level" - your message | none | [grounded] | capability | Your own words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan, never as a past. |
| F4 | "comfortable with Excel reporting" - JD | "I built the monthly complaints spreadsheet our regional manager uses" - your message | medium | [grounded] | presentation | Your message says spreadsheet, not Excel. If it was built in Excel, say so; if it was another tool, say that. |
| F5 | "Own the member complaints process end to end across branches" - JD | "I handled the branch's formal complaints log" - your message; "trained new tellers on the escalation script" - your message | medium | [grounded] | transferability | Your material shows one branch's log, not the process across branches. Answer slot: which stages were yours to run and how you decided them; if the process was set elsewhere, say so. |
| F6 | "and the contact centre" - JD | "Never worked in a contact centre" - your message | none | [grounded] | capability | Your own words: "I have never worked in a contact centre." Then how you would learn the contact-centre flow, said as a plan. |
| F7 | "report monthly on complaint volumes and resolution times" - JD | "I built the monthly complaints spreadsheet our regional manager uses" - your message | low | [inferred] | discovery | Monthly reporting is shown; resolution times are not. Answer slot: if the spreadsheet tracked resolution times, say how they were counted; if it did not, say so and say which measure you would track first. |
| F8 | "coach branch supervisors on escalations" - JD | "trained new tellers on the escalation script" - your message | medium | [inferred] | transferability | The nearest sentence is teaching tellers. Answer slot: if you coached supervisors on escalations, say what that looked like; if your teaching was for tellers, say so and how you would carry it to supervisors. |
| F9 | "work with digital teams on self-service journeys" - JD | none given | none | [grounded] | discovery | Your material does not show digital or self-service work. Answer slot: if you have worked with a digital or self-service team, name the team and your part; if you have not, say so and how you would learn the journeys. |

## Prohibited claims

Not coached in any cell of this pack. The honest form of each is shown.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned the complaints process end to end." | Inflated form of F5 | "I handled the branch's formal complaints log." Limit, in analysis: your material shows one branch's log, not the process across branches. |
| "I have contact-centre experience." | Stated negative, F6 | "I have never worked in a contact centre." No slot. |
| "I've presented to senior leaders." | Stated negative, F3 | "I've never presented to anyone above regional level." No slot. |
| "I tracked resolution times." or "I set the spreadsheet's measures." | Inflated form of F4 and F7 | "I built the monthly complaints spreadsheet our regional manager uses." Limit, in analysis: your material does not show resolution times. |
| "I trained branch supervisors on escalations." | Inflated form of F8 | "trained new tellers on the escalation script." |
| "I ran a regulated complaints process." | Inflated form of F2 | "I handled the branch's formal complaints log." |
| "I have Excel expertise." | Inflated form of F4 | "I built the monthly complaints spreadsheet our regional manager uses." |

No pay, notice or location figure appears anywhere in this pack, because you gave none. Silence on digital work is not listed here: the pack asks about it in an answer slot (B8, C5) instead.

## Grounding brief

Ashgrove's strategy lines, as you pasted them (July 2026 brief):
- "move 40% of member service to digital channels by 2028"
- "consolidate eight branches into five hubs over 2027"
- "launch a small-business lending product Q1 2027"
- The main competitive pressure is app-only banks.

Vocabulary to use: member service, digital channels, hubs, member-owned.

Implications (analysis, not claims about you):
- [inferred] Self-service journeys, which the JD asks about, sit inside the 40% digital target. Expect the strategy question to ask what happens to members who stay at the counter (C5).
- [inferred] Five hubs mean complaints move between fewer, larger sites. Expect questions about handover (C6).
- [inferred] A small-business lending product could add complaint types. Ask rather than assume.
- [generic] App-only banks as the pressure usually means questions about speed of resolution, which is a volumes-and-times question (F7).

## Persona table

| Persona | How it shows up here | Weight, Round 1 / Round 2 / Round 3 | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly biography, motivation, logistics | Top / low / low | Have a 90-second background arc ready. Casual questions are scored. |
| Skeptic | Probes the contact-centre and senior-presentation gaps | Light / high / medium | Rehearse B3 until it is plain. Acknowledge the gap, then give a plan. |
| Values / Behavioural | Scenario probes mapped to the four values; STAR-shaped stories | None / top / top | One story per value where your sentences carry one; a scaffold where they do not. Say so plainly where none exists. |
| Case / Strategist | The 20-minute escalation case; strategy questions | None / low / top | Clarify, contain, find the break, one owner. Think aloud. |
| Pressure | Time-boxed challenges to your figures or claims | None / medium / medium | Hold a position through two follow-ups, then concede the specific uncertainty. |
| Data-Driven Prober | Asks how the spreadsheet counted things | Low / medium / low | Say what the spreadsheet counted. If it did not count resolution times, say so. |
| Peer Evaluator | Seams between branches and the contact centre | None / low / medium | Name seam principles. Do not pretend to know their seam. |

Reasoning: the recruiter is a screen, so the conversational and light-skeptic priors apply. The Head of Member Services is your manager, which normally tilts toward Case and Skeptic, but the round is described as mostly behavioural, so Values/Behavioural takes the top weight. The panel is two branch managers, who are your peers across the seam, so Peer Evaluator is in the mix, with Values and the escalation case on top. No per-person interviewer signals exist yet, so none are applied.

## Round 1: Recruiter screen (30 min)

Persona weights: Conversational top, light Skeptic.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | Tell it in about 90 seconds: six years in retail banking, the last three as a branch supervisor, then the complaints work in your words. Stop there; depth comes if asked. | Opening question, scored on economy. It anchors F1 and F2 in your own sentences. |
| A2 | "This role asks for four years in financial-services customer operations. Where does your experience fit that?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Answer with those six years in those words. Do not rename retail banking as another function. | The JD's first requirement, read back as a knockout check. F1. |
| A3 | "What's drawing you to a member-owned credit union?" | CO | [grounded] pasted value: "Members First, Always - we decide from the member's side of the counter." | Name one published value in your own words, and say why it matters to you only if it does. The values page gives the words, not your history. | Tests whether you read their values page. Your reason is yours to give. |
| A4 | "What's your notice period?" | JD | none (logistics slot) | Give your actual notice period. | Logistics. You gave no figure, and none is coached. |
| A5 | "What are your pay expectations?" | JD | none (logistics slot) | Give your own figure, or ask what the band is before you name one. | Logistics. No figure is coached. |
| A6 | "Where are you able to work, and how often?" | JD | none (logistics slot) | State where and how often you can work, in your own words. | Logistics. The JD gives no location. |
| A7 | "Why are you leaving your current role?" | EXP | none (logistics slot) | Give your own reason in one or two sentences. Do not criticise your employer. | Standard screen question. No reason was given, so none is coached. |
| A8 | "What have you read about our 2026 strategy?" | CO | [grounded] "move 40% of member service to digital channels by 2028" | Name one line you have read, in your own words, and what it means for complaints work. If you have seen only the summary, say so. | Homework at recruiter level. The line is in hand. |

## Round 2: Head of Member Services (45 min, your manager, behavioural)

Persona weights: Values / Behavioural top, Skeptic high, Data-Driven Prober medium.

**Highest-ROI prep in this pack: B3.** It is the objection most likely to be asked in some form, and your own sentence says it is true. B5 and C8 are its variants.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a formal complaint you stayed with until it was closed." | VAL, JD | [grounded] "I handled the branch's formal complaints log" | Tell one complaint from the log in your own words, and what you did at each step you took yourself. Answer slot: if you held it to closure, say what closed it; if you handed it on, say to whom and what you passed on. | Open prompt on the JD's end-to-end line and the Own the Fix value. F5. |
| B2 | "What rules did your complaints log have to follow?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: if the log followed a complaint-handling rule set, name it and what it required of you; if it did not, say so and describe how you handled the log. Do not name a rule you did not work to. | The JD asks for regulated complaints. This probe checks whether the log was one. F2. |
| B3 | "You have never worked in a contact centre, and this role owns complaints that run through one. Why should we trust your judgement on that half?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgement first: "I have never worked in a contact centre." Then answer from your own record (the branch complaints you handled) and a plan for learning the contact-centre flow. Hold through two follow-ups by returning to the plan. | The Skeptic's obvious probe. The JD names the contact centre, and your sentence says you have not worked there. Highest-ROI prep. F6. |
| B4 | "Walk me through the monthly complaints spreadsheet. How did you count resolution times?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Name what the spreadsheet counted, in your words. Answer slot: if it tracked resolution times, say how they were counted and which assumption behind them you would defend least; if it did not, say so and which measure you would track first. | Defend-the-number probe. The JD asks for resolution times, and your sentence does not show them. F7. |
| B5 | "You have never presented to anyone above regional level. How would you present a monthly complaints picture to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgement: "I've never presented to anyone above regional level." Then a plan, said as a plan: what you would show, who would check it first, what you would rehearse. Do not describe presentations you did not give. | "Confident presenting to senior leaders" is the gap they will test. Your negative is stated, so the acknowledgement is yours to give. F3. |
| B6 | "How did you train new tellers on the escalation script?" | JD | [grounded] "trained new tellers on the escalation script" | Story from your sentence: how you taught the script, in your words. Answer slot: if you coached branch supervisors on escalations, say what that looked like; if your teaching was for tellers, say so and how you would carry it to supervisors. | The JD asks about supervisors; your sentence is about tellers. The bridge is adjacent, with its limit named. F8. |
| B7 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] pasted value: "Members First, Always - we decide from the member's side of the counter." | Selection scaffold: pick a real decision in your branch work where the member's view changed what you did. If none comes to mind, say so plainly, then give the nearest thing in your material: the complaints log you handled. | Values round in a manager interview. No candidate sentence carries a member decision, so this stays a scaffold. |
| B8 | "Tell me about a time you worked with a team outside your branch on a process change." | JD | [grounded] JD line: "work with digital teams on self-service journeys" | Open prompt on the JD's theme. Your material shows no such case. If you have one, tell it in your own words with your part named. If not, say so, and how you would approach a digital team on a self-service journey. | Open prompt. F9's gap, rehearsed so the honest answer is ready before the probe. |
| B9 | "What would you change first about how complaints move from a branch to the contact centre?" | CASE | [generic] | Structure it: what you would look at first (where complaints stall), what you would fix first, and who owns it until it is solved. Make no claim about your past. | A live problem from the JD's end-to-end line, asked as a decision. A generic pattern. |

## Round 3: Panel of two branch managers (60 min, including a 20-minute case)

Persona weights: Case / Strategist top, Values / Behavioural top, Peer Evaluator medium, Pressure medium.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | CASE, the escalation case: "A member has been told twice that their complaint is closed. The branch logged it; the contact centre has no record of it. What do you do in the first 24 hours?" | CASE, VAL | [generic] | Clarify first: what the member was told, and what each side holds. Contain: stop the member being told it is closed. Find where the record broke. Name one owner until it is solved. Write the member's next message in plain words. Say the structure aloud before you use it. | The escalation case the recruiter named. Tests structure and ownership (Own the Fix). Generic, so no claim about your past. |
| C2 | "Two branch supervisors disagree about who owns the fix. What do you do?" | CASE | [generic] | Settle the owner first, then the disagreement. Say what you would decide and what you would write down. Challenge one premise of the question aloud if it helps. | Follow-up pressure on C1. Peer Evaluator seam. |
| C3 | "Tell me about a complaint the numbers didn't show." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold: give one complaint the spreadsheet did not show, in your words, and what you did about it. If none comes to mind, say so plainly, then say what a monthly count would miss about a branch's town. | Values scoring on Neighbours, Not Numbers. Your spreadsheet is the numbers, so expect this. |
| C4 | "Tell me about a time you explained something to a member who needed it twice." | VAL | [grounded] "trained new tellers on the escalation script" | Scaffold: the nearest sentence is training tellers, not explaining to members. If you changed the wording of anything members read, say so. If you did not, say how you taught the script and how you checked it landed. If you have no member case, say so plainly. | Plain Words, scored by the panel. |
| C5 | "Ashgrove plans to move 40% of member service to digital channels by 2028. What would you protect for members who stay at the counter?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (brief line, as pasted) | No claim about you. Structure: who stays at the counter and why, what you would measure for them, and what you would not let the digital shift do to them. Ask one question back about how the target is measured. | Strategy question from the pasted brief. The panel tests altitude. |
| C6 | "Eight branches become five hubs in 2027. Where do complaints go when a branch closes?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (brief line, as pasted) | Plan, not claim. Say what would route to a hub, what would stay local, and who owns the complaint at handover. | The consolidation is a live operational problem for the complaints role. |
| C7 | "Our branches and the contact centre sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Name seam principles rather than pretending to know their seam. If you have disagreed with a peer team, say what you did; if not, say so and how you would settle it. | Peer Evaluator stem. Branch managers are your peers across this seam. |
| C8 | "You haven't worked in a contact centre. Which parts of the complaints process will you need to learn first, and how fast?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgement: "I have never worked in a contact centre." Then a plan: the parts you would learn first and in what order. Do not claim contact-centre knowledge you do not have. | The panel's time-boxed version of B3. F6. |
| C9 | "On day one, what would you report monthly on complaint volumes and resolution times?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Plan, said as a plan: volumes first, then resolution times, with how each would be counted. Say what your spreadsheet already did for volume, if it did, and say that resolution times were not in it, if they were not. | The JD's reporting line. The spreadsheet is the only sentence you have on it. F7. |

**Requirement coverage**

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | A2 |
| Experience handling regulated complaints | B1, B2 |
| Confident presenting to senior leaders | B5 |
| Comfortable with Excel reporting | B4, C9 |
| Own the complaints process end to end across branches | B1, B9, C1 |
| ...and the contact centre | B3, C8 |
| Report monthly on volumes and resolution times | B4, C9 |
| Coach branch supervisors on escalations | B6 |
| Work with digital teams on self-service journeys | B8, C5 |

## Values / principles cheat sheet

The panel scores against these four values. Working meanings are paraphrased from the pasted page.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold. No sentence of yours carries a member decision. Pick a complaint you handled from the member's side. If none comes to mind, say so, then give the nearest thing you have: "I handled the branch's formal complaints log." Describe one decision you made in that log, only if you made one. |
| Plain Words | If a member needs it explained twice, the writing was wrong | Scaffold. "trained new tellers on the escalation script" is teaching, not member-facing writing. If you changed the wording of anything members read, say so. If you did not, say how you taught the script and how you checked it landed. |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold. "I built the monthly complaints spreadsheet our regional manager uses" carries the numbers. Give one complaint the numbers did not show, in your words. If none comes to mind, say so plainly, then say what a monthly count misses. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Nearest sentence: "I handled the branch's formal complaints log." Scaffold: a complaint you kept hold of until it was solved, and what closed it. If it was handed on, say so and to whom. |

## Reverse questions

Each has a "why it lands." None is tied to an individual interviewer's path yet, because no interviewers are named. Question 5 is the reciprocity question for the peer panel.

1. **Recruiter:** "What does the monthly complaints picture look like today, and who reads it?" Why it lands: you are asking about the reporting role the way its readers would.
2. **Recruiter:** "How will the 2027 hub consolidation change where complaints are handled?" Why it lands: uses the brief line you were given, and shows you read the strategy as operational.
3. **Head of Member Services:** "What would success look like for this role at six months?" Why it lands: asks for the manager's own measure of the job.
4. **Head of Member Services:** "Which complaint trend worries you most right now?" Why it lands: invites their roadmap, and lets you show awareness without pretending to know their data.
5. **Panel, peer reciprocity:** "What could a new person do in their first month that would genuinely help your branch teams?" Why it lands: moves from interview to partnership. It is the question a peer answers most candidly.
6. **Panel:** "Where do complaints get stuck between the branches and the contact centre today?" Why it lands: names the seam and asks them to show where the pain is.

## Sources: target accounting

Research tier: L1, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page already fixes the values cheat sheet. |
| 2. Ashgrove interview process, operations role | skipped | Your recruiter's email fixes the three rounds and their weights. |
| 3. Ashgrove strategy / recent news | skipped | The four pasted strategy lines already supply the current priorities, which is what the CO questions need. The full brief would add more (see the upgrade menu). |
| 4. Interviewer name and Ashgrove | n/a | No names were given, so there was no query to form. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- **The full strategy brief** (not only the four lines you pasted) → the grounding brief is checked against the whole document, and C5 and C6 are retuned.
- **The names of the Head of Member Services and the two branch managers** → the interviewer read, per-person persona weights, and interviewer-specific reverse questions.
- **Your CV, as text** → the F-rows move from your message to CV quotes. Confidence can rise only with inspectable proof. A template of the monthly report with no member data would count.
- **Whether the branch's formal complaints log followed a complaint-handling rule set** → answers B2 and lifts F2.
- **Whether the monthly spreadsheet tracked resolution times, and how** → answers B4 and lifts F7.
- **Your working hours before 3 December** → a prep triage sized to the time you have.
- **Your notice period, pay and where you can work, only if you want them rehearsed** → fills the logistics slots in your own words. The pack will not supply them.
- **Deep research (L2)**, once: about six more searches and two fetches, covering Ashgrove's recent news, the full strategy brief, and any published talks by the panel once names are known. It takes some time and is offered once.
- **A tuesday-dossier.md** → would turn the weak areas in F2, F3, F6 and F9 into evidence-graded rows, and would give the pack a firm list of claims to avoid.
