# Saltmarsh Games: Live Operations Producer interview prep

**Role:** Live Operations Producer, Saltmarsh Games (mobile studio, about 350 people)
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be senior manager; not confirmed. Round: 60 minutes, format not confirmed.
**Candidate:** Femi

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored:

- **VAL**: behavioral and values alignment
- **EXP**: deep-dive on your own experience
- **JD**: the job's stated responsibilities, including the gaps
- **CO**: company and strategy knowledge (not covered here; see Sources)
- **CASE**: a live problem from the role

The guidance is scaffolding for a spoken answer, not a script. Quotes in the Provenance and evidence columns are your own sentences. Where a cell says "answer slot", the honest answer is either branch of it, and you say which one is yours.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title and weekly content drops, so the bridge stays there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD asks about live events across two titles. If you planned across more than one title, say which and how; if you did not, say so plainly and describe the one calendar you ran. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | No gap in the quote's own terms. Expect a probe on what the calendar held and how each drop was decided. Your material shows no inspectable calendar, so say what you can show. |
| F3 | "Manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | transferability | Writing the checklist is adjacent to managing it with QA, and the bridge stops there: "Wrote the release checklist our QA team still uses." Answer slot: if you ran release sign-off with QA, say how; if you only wrote the checklist, say so and say how you would run it with QA. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | low | [inferred] | discovery | Presenting numbers is not owning a review, and the bridge does not stretch to it. Answer slot: if you set the KPIs a review reported, or ran a review after a drop, say which and how; if you only presented figures someone else defined, say so and say what you would own first. |
| F5 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | none | No gap in the quote's terms. Expect a defend-the-number probe: how the figure was counted, and the assumption you would defend least. Name it only if you know it. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | The years are in range. Whether a puzzle-game associate producer role counts as producing live-service is the interviewer's reading, not something your material settles. Say the title and the years as written. Answer slot: if asked whether the game ran live content, say what it did after launch in your own words. This is a length-of-experience requirement, not a gate. |
| F7 | "Coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material is silent on coordinating those teams. Answer slot: if you coordinated any of them on a content drop, name the team and the decision you made with them; if you did not, say so and say how you would set up the handoffs. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | A checklist is written work that a team relies on, but the material does not show how clearly it reads to people outside QA. Answer slot: if you can name a written update that people acted on, say what it was; if you cannot, say so and name the document you would show. |
| F9 | Leading a team (not in the JD text; raised in your gap list) | "Never led a team" (your message) | none | [grounded] | capability | Words: "I haven't led a team." Then a plan, never a past: how you would learn to lead one. |
| F10 | Monetization on a game with in-app purchases (not in the JD text; raised in your gap list) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Words: "I haven't worked on a game with in-app purchases." Then a plan, never a past: how you would learn the monetization side. |

**Requirement coverage**

| Requirement | Covered by |
|---|---|
| Plan and run the calendar for two titles | A2, A5, B3 |
| Coordinate design, art, engineering and community teams | A1, A3 |
| Own the post-event review and KPIs | B4, C1 |
| Manage the release checklist with QA | A4, C3 |
| 3+ years live-service | C4 |
| Content calendar experience | B5, C2 |
| Retention metrics | C1, D2 |
| Clear written communication | none, and why: no question tests written output directly; see the upgrade menu for a sample |

## Prohibited claims

These are not coached, in any cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. Your material says one title, which is the pack's observation, not words for you. A2's slot stays inside the one calendar. |
| Owned post-event reviews and the KPIs they report | Inflated form of F4 | "Presented the monthly retention numbers to the studio head," at its own scope. |
| Wrote, then ran, release sign-off with QA | Inflated form of F3 | "Wrote the release checklist our QA team still uses," at its own scope. |
| Led a team or managed people | Negative you stated (F9) | "I haven't led a team." |
| Monetization or in-app purchase experience | Negative you stated (F10) | "I haven't worked on a game with in-app purchases." |

## Persona weights

Relationship prior: a senior manager on the function is most likely the hiring manager or a skip-level. Interviewer signals: none, because no public footprint was retrieved. Loop: no loop source was retrieved, so this is a flat fallback, not a documented process. Weights therefore rest on the role's shape and your gaps, not on this company's loop.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems on the two-title calendar and the update cycle | High: the JD is written as scope to run, so expect live planning | Clarify before structuring; name the owner of each decision |
| B. Skeptic | Probes on people leadership, monetization and the review you have not owned | High: these are your three stated gaps and the JD's scope exceeds your one-title record | Rehearse the one-title objection until it is plain; use the quote, then the honest branch |
| C. Data-Driven Prober | Defend-the-number on the retention figure and the calendar | Medium-high: the CV's one metric is a magnet | Say how the figure was counted if you know; name the weakest assumption you know of |
| D. Pressure | Time-boxed challenges on fit against a candidate with two titles | Medium: a 60-minute senior round often includes one | Hold the one-title record through two follow-ups; concede the gap plainly |
| E. Conversational | Casual openers and a "what do you play" check | Low to medium: casual questions are still scored | Give the 90-second arc; treat the casual question as scored |

Depth follows weight: A and B carry the most questions, then C, then D and E.

## Question banks

### A. Case / Strategist (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A content drop for one title is due the week the design team wants to move it. Walk me through what you do." | CASE | [generic] | Clarify what is fixed: store dates, the release checklist, community commitments. Name who decides the move. Lay out each option with what it costs design, art, engineering and community. Decide what you would tell players. This makes no claim about your past. | A live version of the JD's "coordinate design, art, engineering and community teams on each update." [generic] because it is a pattern for the problem, not a fact about this studio. |
| A2 | "Plan the next six weeks of live events for a puzzle title whose retention fell after its last event. What do you need to know first?" | CASE | [generic] | Clarify the retention baseline, the event cadence, and what the last event changed. Set an objective, then the calendar. Name the metric you would watch and the risk you would accept. | Tests the JD's "plan and run the live-events calendar" and the retention requirement. Clarify-first scores well here. |
| A3 | "Design, art, engineering and community all have a stake in an update that ships in ten days. How do you run it?" | JD | [grounded] "Coordinate design, art, engineering and community teams on each update" (JD) | Name a single owner for the update's checklist, the dependency each team hands over, and the date each handover is due. Answer slot: if you coordinated any of those teams on a drop, name the team and the decision you made with them; if you did not, say so and describe how you would set up the handoffs. | F7 is the gap. The JD line is the raising source, so the question may ask about it. |
| A4 | "How would you decide between shipping an event on schedule and holding it for a QA issue?" | CASE | [generic] | Name the checklist as the gate, the severity that would hold a release, and who signs. Say what you would tell the community if you held. | The JD's release checklist line. The question is a decision problem, not a claim about your past. |
| A5 | "This role plans two of our mobile titles. How would you split your time between them?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Propose a split by lifecycle and risk, and name what you would not do. Answer slot: if you have planned a calendar across more than one title, say how; if you ran one, say so, then say how you would learn the second. | F1 is the gap. Expect this in some form. |

### B. Skeptic (weight: top, highest-ROI prep)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you do first with a team of designers and artists who do not report to you?" | JD | [grounded] "Never led a team" (your message) | Words: "I haven't led a team." Then a plan, stated as a plan: the first two conversations you would have and what you would ask. Do not describe a past team. | F9 is the gap. The question is open, so it presupposes nothing about your past. |
| B2 | "Have you worked on a game with in-app purchases? How would you handle the monetization side of an update?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Words: "I haven't worked on a game with in-app purchases." Then the questions you would bring to the monetization lead before an update touches store offers. | F10 is the gap. The monetization side is not a JD line, so the question is asked as the gap your interviewer may probe. |
| B3 | "Your calendar ran for one title. What have you run across two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message); [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Hold through two follow-ups by returning to that one calendar. Concede plainly: you have not run two. Then name what would carry over and what you would have to learn. Never describe a second title you did not run. | This is the highest-ROI prep in the pack: the JD's two-title scope meets your one-title record in the first question. The hold is only what the quote carries. |
| B4 | "The role owns the post-event review and the KPIs it reports. Which part of that have you done?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" (your message); [grounded] "own the post-event review and the KPIs it reports" (JD) | Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you set the KPIs a review reported, or ran a review after a drop, say which and how; if you only presented figures someone else defined, say so and say what you would own first. | F4 is the gap, the raising source is the JD line, and the question's premise is the JD's, not yours. |
| B5 | "What in your puzzle-game work carries over to a live-ops role on two mobile titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Name the weekly content-drop calendar and the monthly retention presentation, each at its own scope. Name the limit: one title, and a puzzle game. | Transferability (F1, F5). Answering with the quote's own scope is the strongest move. |

### C. Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was the retention number you presented counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Say what the figure measured, in your own words. Name the assumption you would defend least, if you know it. Answer slot: if you do not know how it was counted, say so plainly, and say which part of the figure was yours. | F5 is the evidence. Defend-the-number applies because the figure is a headline. |
| C2 | "Which drop on your calendar would you defend as a success, and by what measure?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Name one drop and the measure you reported on it, if you reported one. Answer slot: if you did not measure drops, say so, and say what you watched instead. | F2's probe. The quote carries the calendar, not any success measure. |
| C3 | "How is the release checklist used today?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Words: "I wrote the release checklist our QA team still uses." Then what you know of how QA uses it now. Answer slot: if it caught an issue you know of, say what; if you do not know of one, say so. | F3's probe. Your quote states authorship and use, not sign-off. |
| C4 | "The JD asks for three years producing live-service games or apps. How do you count your four years?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); [grounded] "3+ years producing live-service games or apps" (JD) | Say the title and the years as written. Answer slot: if asked whether the game ran live content, say what it did after launch, in your own words. | F6. The count is the interviewer's reading, so the answer states the facts and leaves the reading to them. |

### D. Pressure (weight: mid-low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Hold the position the quote carries: one calendar, two years, and the work you can describe. Concede the gap plainly: you have not run two. Do not argue the comparison. | Pressure on B3. Hold-then-concede. |
| D2 | "That retention figure. How much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Hold: "I presented the monthly retention numbers to the studio head." Concede uncertainty specifically: which part of the figure you influenced, if any, and which you did not. Do not fold on the presentation itself. | C1's pressure version. |

### E. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | VAL | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message); [grounded] "Wrote the release checklist our QA team still uses" (your message); [grounded] "Presented the monthly retention numbers to the studio head" (your message) | A 90-second arc in the order of the four quotes, each told at its own scope. Stop at the last quote. | The biography opener is scored. The arc is only what your sentences carry. |
| E2 | "What are you playing at the moment?" | JD | [generic] | Name a live-service game you play, and say what its event or content cadence is like, in your own words. Keep it to what you have seen. | Casual, but a plus signal for a live-ops role. Scored. |

## Reverse questions

Each one has a reason it lands. No interviewer profile exists, so none is tied to Tobias's own path (see the upgrade menu).

1. "What does a good first 90 days look like for whoever takes this role?" Why it lands: it shows you are already planning the two-title handover.
2. "How is the calendar split between the two titles today, and who owns each?" Why it lands: it maps the scope the JD describes.
3. "Where does the post-event review sit today, who writes it, and which KPIs does it report?" Why it lands: it tests the F4 scope with the right people.
4. "When an update is late, how does the release checklist work with QA?" Why it lands: it shows you know QA is a gate, not a formality.
5. "Which team is hardest to get a decision from on an update, and why?" Why it lands: it shows you expect coordination to be the hard part.
6. "Is this role expected to manage people, or to coordinate teams without line authority?" Why it lands: it settles the leadership gap directly, and it is your most important question.

## Prep triage

Not included: prep time was not stated. Ask for it and a schedule can be sized to it.

## Sources

**Provided documents:** the JD and your background, as pasted in your message. No CV was provided.

**Searches and fetches:** this session's web search was refused by the permission setting. I sent four searches, each refused, and did not retry them. No fetches were sent.

- "Saltmarsh Games values": refused.
- "Saltmarsh Games live operations producer interview": refused.
- "Tobias Wrenfield Saltmarsh Games": refused.
- "Saltmarsh Games mobile studio news": refused.

**Research tier:** L1, searches 4 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, section 10: not produced. No values-style round is detected, so the section is dropped. |
| 2. Saltmarsh Games interview process, live operations | unavailable | Loop structure: not established. Persona weights rest on the role's shape and your gaps, not the company's documented loop. |
| 3. Saltmarsh Games strategy or recent news | unavailable | Grounding brief and CO questions: not produced. The bank has no company-strategy question. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read and a reverse question tied to his path: not produced. |
| 5. Representative live-operations producer JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Permission to run web search, or a pasted Saltmarsh values page → values cheat sheet, company loop structure and a grounding brief for the CO questions.
- Tobias's public profile or published talks → interviewer read, persona weights for him, and a reverse question tied to his own career path.
- The recruiter's note on the round format (one conversation or a panel, and what it will cover) → whether any graded deliverable exists, and the weights for each session.
- Any quotable line about a review or KPI you set, or a drop you measured → F4 and C2 move from a slot to a grounded row.
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → company strategy brief, interviewer footprint in depth, and recent org context.
- A tuesday-dossier.md → verified evidence, prohibited claims and sharper gap rows for this pack.
