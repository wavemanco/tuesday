# Mock-interview pack: Stripe, Product Operations Manager, final round

**Built without:** a JD, a CV, round details, interviewer names, or company research (web search was not permitted in this session). Everything below is **[generic]**: a common shape for this kind of loop, not a fact about Stripe. Verify before relying on it.

**Assumed loop:** final round with a hiring manager plus one or two cross-functional partners (engineering, finance, or go-to-market).

## How to use this pack

- **Personas** = how the question is asked (hiring manager, cross-functional partner, skeptic).
- **Types** = what is being scored:
  - **Behavioral:** what you did in the past
  - **Situational:** what you would do in a new case
  - **Values:** how you fit the company's principles
  - **Operational:** how you measure and run ops work
  - **Skeptic:** challenges to your claims
- Guidance is scaffolding, not a script. Use your own words.

## Prep triage

Prep time was not stated, so no schedule is given. If time is short, prioritize Q1, Q4 and Q7 (the three most likely to come up in some form), then the reverse questions.

## Fit snapshot (self-assessment worksheet)

No JD or CV was provided. For each requirement a Product Operations Manager role usually carries, write one sentence of your own evidence in your words:

| Likely requirement | Your evidence (one sentence, your words) | Gap? |
|---|---|---|
| Process design that other teams adopt | | |
| Cross-functional leadership without authority | | |
| Metrics, and judging whether an ops change worked | | |
| Scaling operations (volume, tooling, handoffs) | | |
| Written communication to executives | | |

Where you cannot write a sentence, that is your gap. Rehearse a bridge: what you did adjacent to it, and how you would close it.

## Prohibited claims (built locally)

Do not say in the interview:
- Any outcome number you cannot source from your own records.
- Any team size, budget, or scope larger than what you personally owned.
- Any familiarity with Stripe's products, internal tools, or strategy unless you have actually used or studied them.
- Any Stripe value or principle recalled from memory. Use the official page.

## Question bank

### Hiring manager persona

**Q1. [Behavioral] Tell me about a process you designed that other teams adopted.**
- Guidance: name the problem, your specific part, the metric before and after, and what you would change now.
- Provenance: [generic]. Open with your own story, not the framework.

**Q2. [Behavioral] Walk me through a cross-team project that went off track.**
- Guidance: separate what you controlled from what you did not. Name the decision you would reverse.
- Provenance: [generic].

**Q3. [Operational] How do you decide which processes to build and which to leave alone?**
- Guidance: give a criterion (volume, cost of error, frequency). Give one example where you chose not to build something.
- Provenance: [generic].

**Q4. [Situational] You inherit a backlog of 40 requests from three PMs with conflicting priorities. What do you do in week one?**
- Guidance: clarify who owns the decision, sort by impact and reversibility, and name who you would talk to first.
- Provenance: [generic].

### Cross-functional partner persona

**Q5. [Behavioral] Tell me about a time you pushed back on a partner team and were right, or wrong.**
- Guidance: show the disagreement, how you got the data, and how the relationship held afterward.
- Provenance: [generic].

**Q6. [Operational] How would you tell whether an operational change actually worked?**
- Guidance: define the metric before the change, name a guardrail metric, and say how long you would wait before judging.
- Provenance: [generic].

### Skeptic persona

**Q7. [Skeptic] Of the results from your last project, how much was actually you?**
- Guidance: be precise about your role. Credit the team once, then state your own part plainly. Do not shrink it below what you did.
- Provenance: [generic].

**Q8. [Skeptic] What did you get wrong on that project?**
- Guidance: name one real mistake, what it cost, and what you changed afterward. A rehearsed "weakness" answer will be noticed.
- Provenance: [generic].

### Values

**Q9. [Values] What are the principles that matter most to you here, and which one do you hold most strongly?**
- Guidance: pull the names from the official Stripe values page before the interview. Do not guess. Then tie one principle to a story you can tell in two minutes.
- Provenance: [generic]. Values not verified.

## Reverse questions

1. "What does a successful first six months look like in this role?" Why it lands: it shows you plan around outcomes.
2. "Where does product operations sit relative to finance and go-to-market, and who decides when they disagree?" Why it lands: it surfaces the real decision structure.
3. "What is the process problem the team is most frustrated by right now?" Why it lands: it invites an honest answer you can act on.

## Upgrade menu

- **Paste the JD** → fit snapshot becomes evidence-graded, and the gaps become the skeptic questions.
- **Paste your CV or three to five stories** → answers become story-mapped rather than scaffolds.
- **Tell me the round format** (who, how long, any take-home or presentation) → persona weights and loop structure.
- **Allow web search** → Stripe's values, loop structure and recent strategy verified, replacing the [generic] labels.
- **Give interviewer names** → interviewer read, based on public professional footprint only.
