**Not a waste of time, but it's a stretch on the title and on product ownership. The technical and stakeholder side of your background is strong.** `conditional_go`: apply, with the three conditions below.

**Fit ledger.**

- `must_have`: direct: R3, R4 · adjacent: R1, R2 · unclear: R5
- `important`: adjacent: R7, R9 · unclear: R8 · absent: R6

R1 (3+ years product management), R2 (shipped API or platform products) — adjacent, limits named in the map. R5 (agile delivery) — the CV is silent. R6 (own the roadmap) — absent as ownership; your roadmap-input work is the closest. R8 (adoption metrics) — unclear, nothing on the CV.

**Opportunity ledger.** The posting is specific: one platform, two squads, named responsibilities (RR3). Three things are open: whether the 3-year PM requirement is a hard screen (RR2), whether the live posting exists on Quartzline's own careers page (RR1), and whether the role has an adoption target (RR4).

- **Hard gates:** none stated by the posting; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can name one product decision you drove or materially shaped, confirmed in the loop (R6, R1); (2) the recruiter says whether equivalent product-owned years count (RR2); (3) the posting is confirmed live on Quartzline's own careers site (RR1).
- **What would change this:** a 3-year screen that is strict and treated as pass/fail moves this to `hold_pending_answers`, and no product-owned evidence at all would make the title a poor fit.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform | `[grounded]` JD |
| Scope read | One platform, two engineering squads, five named responsibilities | `[inferred]` from the JD's responsibility list |
| Market calibration | Not run: both searches were refused, so no band | — |
| Unknowns | Whether 3+ years PM is a screen; pay; level; adoption targets; agile cadence | `[grounded]` JD silence |
| Contradictions | None visible, but only the pasted JD was read | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience | must_have | adjacent | medium | transferability | No PM title. Seven years of integration, requirements and roadmap-input work is the closest. Limit: no period where you owned a roadmap | `[grounded]` CV; `[inferred]` the reading that this counts as adjacent | RR2, recruiter question |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST API integrations delivered end to end. Limit: you shipped client integrations, not a platform your team decided what to build | `[grounded]` CV | R6 question (Q1) |
| R3 | Technical fluency: API docs and schemas | must_have | direct | medium | presentation | Postman, SQL, OpenAPI reading and integration architecture are on the CV, but in a tools line | `[grounded]` CV | E1 |
| R4 | Stakeholder management: engineering, sales, customers | must_have | direct | medium | presentation | Coordinated vendor engineers, client engineers and PMs on custom builds; ran client workshops | `[grounded]` CV | E2 |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | The CV says nothing about sprints, cadence or release process | `[grounded]` CV silence | Q2 |
| R6 | Own the roadmap for a platform | important | absent | low | discovery | You collected client feedback for product's roadmap; the CV doesn't show you setting priorities | `[grounded]` CV | Q1 |
| R7 | Run partner discovery; write specs for engineering | important | adjacent | medium | transferability | Scoping workshops and requirements documents. Limit: discovery without a mandate to prioritize | `[grounded]` CV; `[inferred]` the discovery reading | Upgrade menu |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | No adoption or usage measure on the CV | `[grounded]` CV silence | Upgrade menu |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-live and UAT for 30+ clients. Support isn't on the CV. Limit: client go-lives, not an internal product launch | `[grounded]` CV | Upgrade menu |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Roadmap ownership (R6, R1) | discovery | Client feedback into product planning, not a decision you made | Roadmap ownership is the title's core; a real decision moves R6 and R1 | Choosing which integration gap product fixed next; a partner request that became a shipped feature because you scoped it | A roadmap doc, a Jira or Linear ticket trail, a release note | `[grounded]` CV; `[inferred]` that this moves R6 |
| G2 | Agile delivery (R5) | discovery | Silent on process | A must-have, and cheap to answer | Sprints, release trains, a handoff model | Sprint or release calendar, a process doc | `[grounded]` CV silence |
| G3 | Adoption metrics (R8) | discovery | Nothing on the CV | Would move R8 and support R2 | Integration go-live time, error rates, time to first call | A dashboard, a go-live tracker | `[generic]` that adoption metrics are standard for this role family |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not checked | unknown | — | "Product Manager, Platform APIs — Quartzline" | The posting may be live, stale, or not on the company's own site | `[grounded]` JD header; research did not run | Is this role live on your careers page, and who would I interview with? | unresolved |
| RR2 | 3+ years PM is a must-have, and you have no PM title | risk_signal | medium | "3+ years product management experience (must-have)" | The screen may filter on title years before the work is read | `[inferred]` from the must-have wording | Is 3+ years of PM experience a pass/fail screen, or would equivalent product-owned work count? | unresolved |
| RR3 | Scope is named | positive_signal | — | "Own the roadmap for our partner-facing API platform" | Role scope is defined | `[grounded]` JD | Which two or three decisions will this role make in its first 90 days? | noted |
| RR4 | No adoption target stated | unknown | — | "define and track adoption metrics" | The role may define targets itself, or the company may not have them yet | `[inferred]` from the JD's silence on targets | What adoption target is this role measured against in year one? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move "Postman, SQL, OpenAPI reading" into the first integration bullet, wording unchanged | R3 | `[grounded]` CV tools line | resume_edits_pending_approval |
| E2 | Move "Ran quarterly roadmap-input sessions collecting client feedback for product" up, wording unchanged. Don't add "prioritized" or "owned" | R4, R6 | `[grounded]` CV | resume_edits_pending_approval |
| P1 | Cover-note line, proposed: "I haven't held a PM title. For seven years I've been on the client side of our REST APIs, and each quarter I've fed client feedback into product planning." Clause check: each clause traces to your CV; no "product manager" claim | R1, R2 | `[grounded]` CV | Positioning advice — pending your approval |
| A1 | Ask the recruiter the RR2 question before investing in the loop | RR2 | `[grounded]` RR2 | pending your approval |
| A2 | Prepare one story from G1 with its limits stated (you collected and carried feedback; you did not set priorities) | R6 | `[grounded]` G1 | pending your approval |

**Evidence status**

Verified: none yet. Unverified leads: a request-triage tool that support agents adopted, from earlier notes. It is unconfirmed and is not evidence; it prompts Q3 only.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Quartzline were refused by permission, so the live posting and the company's footprint are unchecked (RR1) |
| 2. Role-family sweep | unavailable | The title-years norm and pay band for this seniority were not checked (RR2, RR4) |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Upgrade menu**

- Grant search permission and I'll run targets 1 and 2 once: Quartzline's live posting and a role-family check on the PM-years norm and pay band (closes RR1, RR4).
- A roadmap doc or a release note with your name on a decision (Q1's answer) → R6 to medium, R1 closer to direct.
- A sprint calendar or release process doc → R5 to medium.
- One adoption number you tracked, in any form → R8 to medium.
- A screenshot or doc of the triage tool → R2 and R8 move, if it's real.
- The hiring manager's name → positioning for that reader.

I can also save this as `tuesday-dossier.md` to carry into prep.

**Questions**

Q1 — R6 (roadmap ownership): Have you ever decided what got built next, even under a different title? What did you own, who else decided, and what happened?

Q2 — R5 (agile delivery): What delivery cadence did you work to in your last role: sprints, releases, or a handoff model?

Q3 — G3 / R2 (memory lead, unconfirmed): Earlier notes mention a request-triage tool that support agents adopted. Did you build it? What did it do, how many agents used it, and do you have a screenshot or doc?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.