**Yes, worth applying, on two checks first: `conditional_go`.** The fit is strong on everything the posting names except the BigQuery specifics. The employer is not yet verified, which caps the decision.

**Fit ledger.**
- `hard_gate` — unclear: R1 (Remote (US) or Denver office)
- `must_have` — direct: R2, R3, R4, R6, R7 · unclear: R8 (ingestion from our app and CRM)
- `important` — adjacent: R5 (warehouse in BigQuery) · unclear: R9 (data contracts analysts depend on)

R5 (`medium`) — dbt work carries over, BigQuery specifics unused; R8 — no ingestion in your material; R9 — no data-contract work in your material.

**Opportunity ledger.** Concrete scope and posted pay (RR5, RR4) read well; the employer is not yet verified (RR1), and equity and the hiring manager are unknown (RR2, RR3).

- **Hard gates:** none failed (R1 is unconfirmed, not failed); unconfirmed: R1 (remote US or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** Conditions for go: (1) RR1 closes, meaning the posting is live on Pellucid's own careers page; (2) R1 is confirmed; (3) your base-pay floor sits at or below the $166,000 top of the posted range (Q3). It moves to `no_go` if R1 fails (no US work authorization and no Denver option) or your floor sits above $166,000.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` About page as you pasted it; not checked online |
| Mandate | Build and run ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Scope read | Ownership of pipelines and contracts across the reporting stack; no team or reports mentioned | `[inferred]` from the listed responsibilities against the posting's silence on team |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, IQR $139,000–$163,500; "senior" typically 5–8 years; scope usually one domain's pipelines, no direct reports | `[generic]` Datawright 2026 report (n=2,310, US), as your recruiter sent it; not independently checked |
| Compensation | Posted $148,000–$166,000 base plus equity. The range sits inside the IQR, its low end above the median, and its top just above the upper quartile | `[grounded]` JD range; band `[generic]` as above |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Unknowns | Hiring manager; equity size and vesting; team size; whether ingestion and contracts are new builds or existing systems | — |
| Contradictions | None found between the JD and the About page | `[grounded]` both as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization are not in the material; the posting's remote-US term is what the gate tests | `[grounded]` JD; your side not stated | Q1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; stated, no artifact yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no sample yet | `[grounded]` your background | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | About 180 dbt models on Snowflake, a cloud warehouse; the posting names no specific warehouse here | `[grounded]` your background | none |
| R5 | Warehouse in BigQuery (role description) | important | adjacent | medium | transferability | Same dbt work carries over; you have never used BigQuery; BigQuery-specific features and cost model are unexercised | `[grounded]` your background; carry-over reading `[inferred]` | G1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration, stated | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite, stated | `[grounded]` your background | none |
| R8 | Ingestion from our app and CRM | must_have | unclear | none | discovery | Not mentioned in your material | `[grounded]` JD; silence in your material | Q2 |
| R9 | Data contracts analysts depend on | important | unclear | none | discovery | Not mentioned in your material | `[grounded]` JD; silence in your material | Q2 |

Every candidate claim here is at `medium` at most: prose intake has no inspectable artifact yet, so nothing reaches `high`.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R5, important) | transferability | dbt models and warehouse design on Snowflake; no BigQuery use | Bridge: dbt and warehouse work carries over; limit: BigQuery's partitioning, clustering and bytes-billed cost model are unexercised; a short BigQuery exercise narrows that limit | Any dbt model you ran on Snowflake with partitioning or cost tuning | A sandbox BigQuery project, or a short note on the first month's ramp | `[inferred]` bridge from your Snowflake work; `[generic]` that these BigQuery features are the usual ramp |
| G2 | Ingestion and data contracts (R8, R9) | discovery | Neither appears in your material | R8 is a must-have, so it is the first thing an interviewer will test | Ingestion from a product database or a CRM export; any schema agreement an analyst relied on | A pipeline diagram or a description of one owned source | `[grounded]` JD; silence in your material |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | Verification did not run: both searches were refused, so this is unverified, not a finding against the employer. The employer may be too new or small for a web footprint, the posting may be stale, or it may not represent a real hiring employer; none is ranked as likely | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at this role on your own careers page, and who would I interview with?" | unresolved |
| RR2 | Equity unsized | unknown | — | "plus equity" | Equity could be material or token; the posting gives no size, vesting or strike | `[grounded]` JD | "What is the equity grant for this role, and what is its vesting schedule?" | unresolved |
| RR3 | Hiring manager and team not named | unknown | — | Posting names no hiring manager | Reporting line and team size bear on the scope read | `[grounded]` posting as provided | "Who would I report to, and how many engineers would I work alongside?" | unresolved |
| RR4 | Posted base within market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is disclosed and sits inside the band; the top runs just past the upper quartile | `[grounded]` JD range; `[generic]` band as above | "How does the base range vary by level and location?" | noted |
| RR5 | Scope named concretely | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | Ownership is defined, and the systems are named | `[inferred]` from the JD's concrete responsibilities; `[generic]` scope norm | "Which of these pipelines would I own end to end, and which are shared?" | noted |

Severe red flags: none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Use the Snowflake facts as written: "Built our dbt project on Snowflake — about 180 models — with Airflow orchestration." No BigQuery claim, no added verb | Covers R4 and R6 without adding a claim | `[grounded]` your background; every clause traces to your sentences | resume_edits_pending_approval |
| E2 | State the BigQuery limit in your own words: "I haven't used BigQuery. The dbt and warehouse work carries over, and I'd spend my first weeks on BigQuery's partitioning and cost model." | Names the limit instead of hiding it | `[inferred]` carry-over reading; the ramp is advice | pending your approval |
| A1 | Confirm the posting on Pellucid's own careers page, and apply through that listing | RR1 | `[generic]` standing entry | your action |
| A2 | Check your location and work authorization against the posting, and your base floor against $148,000–$166,000 | The two checks that could change the status | `[grounded]` JD | your action |
| A3 | Optional before interviews: one dbt model on a sandbox BigQuery dataset, partitioned and clustered, with bytes billed checked | Closure path for G1 | `[generic]` path, not a claim about this employer | your action |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Pellucid Learning live online tutoring K-12 Denver Series C" and "Pellucid Learning senior data engineer careers BigQuery dbt") were refused by a permission prompt, so no result came back. Would have moved RR1 and confirmed the posting is live |
| 2. Role-family sweep | skipped | The Datawright 2026 report is pasted in full, so its band and scope norm are already in hand. Caveat: it came from your recruiter, and its source is unchecked |
| 3. Hiring manager's public footprint | n/a | No name given |

## Upgrade menu

- Web search permission for the two company searches above → RR1 closes, or stays open with a reason; the posting's live status gets checked.
- Your location and work authorization → R1 resolves, and the hard-gate line clears or fails.
- A SQL or Python sample, or a dbt snippet you can share → R3 and R4 move from `medium` toward `high`.
- A BigQuery sandbox artifact → G1 narrows R5's limit.
- The hiring manager's name → the scope read and which story to lead with for that reader.
- A deeper pass on Pellucid (funding, leadership, reports; up to 5 more searches and 2 more fetches) — say the word, once search is allowed.

If you want this kept as a file, I can write `tuesday-dossier.md` with the full analysis.

1. **Q1 (R1):** Are you based in the US, or able to work from Denver, and do you have US work authorization without sponsorship?
2. **Q2 (R8, R9):** Have you built ingestion from a product app and a CRM, or owned data contracts analysts relied on? If so, what did you own?
3. **Q3 (RR4):** What is the lowest base salary you would accept?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.