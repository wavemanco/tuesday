**Probably yes, but I can't call it until two facts are in: `hold_pending_answers`.** Your fit on the stated must-haves is strong. Whether the hard gates clear depends on your location and pay floor, which you haven't given me.

## Decision snapshot

**Status: `hold_pending_answers`.** Waiting on R7 (location) and R8 (pay floor).

**Fit ledger.**
- `hard_gate` — unclear: R7 (Remote US or Denver office), R8 (Pay $148,000–$166,000 base)
- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — adjacent: R6 (BigQuery, not used)

R1, R2, R3, R4, R5 — direct; R6 — adjacent, the BigQuery gap; R7, R8 — gates, awaiting your answers.

**Opportunity ledger.** RR4 (posted pay sits in the upper half of the market band) and RR5 (scope is named in three components) read positive. RR1 is the standing employer check: the company's own site confirms it, and I found no outside corroboration. RR2 (equity) and RR3 (hiring manager) are unknowns.

- **Hard gates:** none failed; unconfirmed: R7 (Remote US or Denver office), R8 (Pay $148,000–$166,000 base); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** if you're in the US (or Denver) and the $148,000 floor works, the status moves to `conditional_go`, with one condition: the BigQuery gap (R6) is named honestly. If you're outside the US and not near Denver, R7 becomes `hard_gate_fail` and the status is `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, Feb 2026 | `[grounded]` pellucidlearning.com/about, fetched; matches your paste |
| Mandate | Build and run reporting pipelines: app and CRM ingestion, a dbt-modelled warehouse, data contracts for analysts | `[grounded]` JD and careers page, fetched; both match |
| Scope read | One domain (reporting) with three named components | `[inferred]` from the JD's three components; typical for the title per `[generic]` pattern below |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Compensation | Posted $148,000–$166,000 base plus equity; midpoint $157,000 | `[grounded]` JD |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, IQR $139,000–$163,500. The posted range sits across the median and in the upper half of the band. The band is for the title and stage, not this employer's offer | `[generic]` Datawright 2026 pay report; the figures match your recruiter's text, but I read only the search snippet, not the full report |
| Unknowns | Equity value; hiring manager; team size; first-year outcomes (none stated) | — |
| Contradictions | None between the JD and the careers page | `[grounded]` careers page, fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-stated; not yet probed | `[grounded]` your stated background | Confirm the six years' titles and dates on the CV |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated; no artifact yet, so expect a probe | `[grounded]` your stated background | Prepare a sanitized model or script (see upgrade menu) |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | About 180 dbt models on Snowflake, a cloud warehouse. Met on the Snowflake side; BigQuery is R6 | `[grounded]` your stated background | None beyond the upgrade menu |
| R4 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration, stated | `[grounded]` your stated background | None beyond the upgrade menu |
| R5 | Data quality testing | must_have | direct | medium | none | Great Expectations suite set up, stated. "Set up" may mean authored or owned; confirm which | `[grounded]` your stated background | Ask what the suite covered and who ran it |
| R6 | Warehouse in BigQuery (named in the JD's description, not its requirement list) | important | adjacent | medium | transferability | dbt-on-Snowflake work carries over. BigQuery itself was never used, which is the limit | `[inferred]` tier from the JD's body against its requirements list; `[generic]` dbt skills transfer across warehouses | G1 |
| R7 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location is not given | `[grounded]` JD; candidate location not given | Question R7 (closing block) |
| R8 | Pay $148,000–$166,000 base plus equity | hard_gate | unclear | none | hard_gate | Your pay floor is not given. The posted range sits in the band's upper half | `[grounded]` JD; `[generic]` band | Question R8 (closing block) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Warehouse in BigQuery (R6, important) | transferability | Snowflake dbt across about 180 models; no BigQuery | BigQuery is named in the JD's description, so it will come up | Warehouse cost or performance tuning on Snowflake; any GCP or cloud-storage exposure, however small; dbt model design that moves across adapters | A sanitized dbt model folder; a sandbox BigQuery dataset, if you have one | `[inferred]` adjacency from the Snowflake work; `[generic]` that dbt skills transfer across warehouses |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer corroboration only from its own site (standing check) | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools" | The company's own site confirms it and the posting is live; one outside search found nothing else. A thin outside footprint is normal at this size, so this is a gap in corroboration, not a warning | `[generic]` pattern for companies of this size; `[grounded]` official site fetched | Who is the hiring manager, and is this req on your open headcount plan? | reduced |
| RR2 | Equity unquantified | unknown | — | "plus equity" | Equity could be material or token; the posting doesn't size it | `[grounded]` JD | What is the equity grant at this level, with its vesting schedule and strike price? | unresolved |
| RR3 | Hiring manager not named | unknown | — | "Remote (US) or our Denver office" | The reporting line is unknown, so the scope read can't be checked against manager support | `[grounded]` posting names no one | Who would I report to, and how big is the team? | unresolved |
| RR4 | Posted pay inside the market band | positive_signal | — | "$148,000–$166,000" | Pay is priced in the upper half of the band for this title and stage, which points to a funded budget for the role | `[grounded]` JD and report snippet; `[generic]` band | Is $166,000 the top of the approved range, or is there room above it? | noted |
| RR5 | Scope defined by three named components | positive_signal | — | "ingestion from our app and CRM … dbt-modelled warehouse … data contracts" | Ownership of one domain's pipelines is the typical scope for the title, and the JD says what the role owns | `[inferred]` from the JD's components; `[generic]` typical scope | Which of these three does this role own end to end, and who signs off the analysts' data contracts? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put the dbt project (about 180 models, Snowflake) and the Great Expectations suite at the top of your summary, in your own words | R3, R5 | `[grounded]` your stated background | pending your approval |
| E2 | Name the BigQuery gap in one plain sentence: "I've run dbt on Snowflake, and I haven't used BigQuery." | R6 | `[grounded]` your statement that you never used BigQuery | pending your approval |
| A1 | Confirm your location and pay floor against R7 and R8 before you apply | Hard gates | `[grounded]` JD | your action |
| A2 | Ask RR1–RR3 in the first conversation | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is self-stated; no claim has been probed.

Research tier: L1 — searches 2 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched pellucidlearning.com/careers/senior-data-engineer (posting live; text matches the JD you pasted) and pellucidlearning.com/about (matches your paste). Searched "Pellucid Learning live online tutoring K-12 Denver": no results beyond the company's own site. Moved the organization row and RR1 |
| 2. Role-family sweep | yes | Searched "Senior Data Engineer salary 2026 Series B D company base median": returned datawright.example/2026-data-engineering-pay-report, whose snippet matches your recruiter's figures. Moved the market calibration row and RR4. Basis is the snippet only; I did not open the full report |
| 3. Hiring manager's public footprint | n/a | No name given |

## Upgrade menu

- Your location and pay floor → R7 and R8 close, and the status moves to `conditional_go` or `no_go` (see the decision snapshot).
- A sanitized dbt model folder or a test config → R2, R3 and R5 move from `medium` to `high`.
- A sandbox BigQuery dataset or any GCP work, however small → R6 moves from `adjacent` toward `direct`.
- The equity figure and vesting terms → RR2 closes.
- The hiring manager's name → RR3 closes, and the application can lead with the story that fits that reader.
- A deeper company pass (funding and leadership changes, hiring patterns, public employee reports): up to 5 more searches and 2 more fetches. Say the word and it runs.

If you want this as a file, I can write `tuesday-dossier.md` with the full evidence map and register.

1. For R7: Are you based in the US, or near Denver? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. For R8: Is $148,000 base at or above your floor? If not, what is your floor? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.