**Worth applying, conditionally. Status: `conditional_go`.** Stage assumed: evaluating.

**Fit ledger.**

- `hard_gate`: unclear: R10, R11
- `must_have`: direct: R1, R2, R3, R4, R5, R6
- `important`: adjacent: R7 · unclear: R8, R9

- **Hard gates:** none failed; unconfirmed: R10 (location: remote US or Denver), R11 (pay against your floor). Your constraints weren't given, so these checks are unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** Sound on the facts given. The base range sits inside the market band (RR5). Equity has no terms (RR3), no hiring manager is named (RR4), and the employer and posting are unchecked live (RR1).
- **Conditions for go:**
  1. The employer and posting are confirmed live (RR1). This caps the verdict until then.
  2. Your location, work authorization and pay floor clear R10 and R11.
  3. BigQuery is presented as not yet used, with the Snowflake-to-BigQuery transfer named (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` text you pasted from the about page, not checked live |
| Mandate | Build and run pipelines behind tutoring-platform reporting: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts for analysts | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Three areas (ingestion, warehouse, contracts) against a norm of one domain's pipelines with no reports; broader than typical | `[inferred]` from the JD's scope against `[generic]` norm |
| Market calibration | Base median $151,000, IQR $139,000–$163,500 for Senior Data Engineers at Series B–D companies. The posted $148,000–$166,000 midpoint ($157,000) sits inside the IQR; the top of range is $2,500 above its upper bound | `[generic]` Datawright 2026 report; `[grounded]` JD range |
| Seniority fit | "Senior" typically means 5–8 years; six years is inside that | `[generic]` Datawright report |
| Unknowns | Equity terms; hiring manager; whether the BigQuery warehouse exists and is being run or migrated; who owns data contracts | — |
| Contradictions | None between the JD and the about-page text you pasted; neither was checked against live pages | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, as you stated it; no CV or artifact inspected yet | `[grounded]` user-stated | none |
| R2 | Strong SQL | must_have | direct | medium | none | Daily SQL use, as stated | `[grounded]` user-stated | none |
| R3 | Strong Python | must_have | direct | medium | none | Daily Python use, as stated | `[grounded]` user-stated | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake, a cloud warehouse | `[grounded]` user-stated | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration, as stated | `[grounded]` user-stated | none |
| R6 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite; how far it ran in production isn't stated | `[grounded]` user-stated | none |
| R7 | BigQuery warehouse (role description, not a listed requirement) | important | adjacent | medium | transferability | Snowflake and dbt transfer; BigQuery itself never used. The adjacency is the Snowflake and dbt side, not BigQuery | `[inferred]` transfer from Snowflake and dbt | G1 |
| R8 | Data contracts analysts depend on (role description) | important | unclear | low | discovery | Nothing stated; may exist as dbt model contracts or schema tests | `[inferred]` | G2 |
| R9 | Ingestion from app and CRM (role description) | important | unclear | low | discovery | Nothing stated about source-system ingestion | `[inferred]` | G3 |
| R10 | Location: remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization weren't given | — | Q2 |
| R11 | Pay against your floor ($148,000–$166,000 base, plus equity) | hard_gate | unclear | none | hard_gate | No floor given; equity terms unstated | `[grounded]` JD range | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7) | transferability | Snowflake and dbt at scale; no BigQuery use stated | Named in the role's warehouse description | Any cloud-warehouse cost, permissions or partitioning work on Snowflake; any dbt adapter or profile work; any BigQuery sandbox time | A dbt project excerpt, or migration or scoping notes | `[inferred]` transfer; `[generic]` that BigQuery-specific cost and partitioning are the usual ramp-up areas |
| G2 | Data contracts (R8) | discovery | Nothing stated | Analysts depend on these contracts | dbt model contracts, schema tests, or agreed schemas with downstream consumers | A contract definition or the config that enforces it | `[inferred]` |
| G3 | Ingestion from app and CRM (R9) | discovery | Orchestration stated; source ingestion not | Two of the three named areas | ELT connectors, CDC, API pulls, CRM sources | Pipeline descriptions for any source system | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not checked live | risk_signal | medium | "Series C ($52M, February 2026)" | Three reasons, none ranked as likely: the company is smaller or newer than its stated facts, the posting is stale, or the employer isn't a live hiring company as described. The check resolves all three | `[grounded]` the live checks did not run; provided text only | Can you send the recruiter's email domain or a link to the live posting? | unresolved; caps the verdict at `conditional_go` |
| RR2 | Scope may cover more than one domain | risk_signal | low | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be the team's only data engineer across three areas | `[inferred]` from the scope read | Is there a data team, and how many engineers own these pipelines? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | Equity may be the least certain part of the package | `[grounded]` JD | What equity is offered, and on what terms? | unresolved |
| RR4 | No hiring manager named | unknown | — | — | — | `[grounded]` posting | Who is the hiring manager? | unresolved |
| RR5 | Base range sits inside the market band | positive_signal | — | "$148,000–$166,000" | Midpoint $157,000 is inside the $139,000–$163,500 IQR | `[grounded]` JD; `[generic]` IQR | — | noted |
| RR6 | Stated stack matches four named requirements | positive_signal | — | "dbt and a cloud warehouse; orchestration with Airflow; data quality testing" | The requirements fit your stated stack closely | `[grounded]` self-reported | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Resume lines, each traced to your sentences: "Built a dbt project on Snowflake, about 180 models"; "Set up the Great Expectations test suite"; "Used Airflow for orchestration" | Covers R4, R5, R6 | `[grounded]` your sentences | resume_edits_pending_approval |
| A2 | Lead with the dbt, Airflow and Great Expectations work. Name BigQuery as not yet used, with the Snowflake transfer as the honest bridge. Don't imply BigQuery experience | R7 and the reframing audit | `[grounded]` R4–R7 rows | pending your approval |
| A3 | Before applying, get the recruiter's email domain or the live posting link | RR1 | `[grounded]` RR1 | proposed |
| A4 | Prepare answers for the BigQuery, data-contract and ingestion questions | G1–G3 | `[inferred]` | proposed |

## Evidence status

Verified: none yet. Every candidate claim here is self-reported, and the company and posting facts come from text you pasted, not from live pages.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both web searches were refused, so the employer and the live posting are not checked. This is the RR1 check |
| 2. Role-family sweep | unavailable | The refused search would have added a second source for the market calibration beyond the Datawright report |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- A live posting link or the recruiter's email domain → RR1 closes and the `conditional_go` cap lifts.
- Your location, work authorization and pay floor → R10 and R11 resolve.
- A dbt excerpt or migration notes touching BigQuery → R7 moves toward `direct`.
- Examples of data contracts (R8) and source ingestion (R9) → both move from `unclear`.
- The hiring manager's name → the scope read and the positioning in A2 can be sharpened.
- Equity terms from the recruiter → RR3 closes.
- Web search was declined in this session. If you grant it, the two L1 checks can run.

I can also emit this assessment as a `tuesday-dossier.md` file so it carries into a later interview-prep session.

**Questions**

1. **[R7 / G1]** Has any of your work touched BigQuery, even a sandbox, a dbt profile, or a migration you scoped? Or would it be starting from scratch?
2. **[R10, R11]** What are your constraints on location, work authorization and base pay, and do you need equity terms to be defined?
3. **[RR1]** Can you send the recruiter's email domain or a link to the live posting?

You can answer any, all or none of these. "Skip" is an answer, and a skipped question stays open in the register.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.