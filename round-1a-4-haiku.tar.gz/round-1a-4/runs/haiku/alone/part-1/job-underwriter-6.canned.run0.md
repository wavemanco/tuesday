**Worth applying, on three conditions. Status: `conditional_go`.** You meet most of the must-haves directly. The two real gaps are owning the forecast and billing data, and the posting doesn't say whether this role takes the forecast over from finance. Ask that before you invest in the process.

**Fit ledger.**

- `hard_gate`: unconfirmed: R10 (Bristol hybrid, two days a week in the office)
- `must_have`: direct: R1, R3, R4 · adjacent: R2, R5 · unclear: R6
- `important`: direct: R7a, R8 · adjacent: R9 · absent: R7b (billing data)

R1 and R3 are direct, and R2 and R5 are adjacent with their limits named. R5 is pipeline work, not forecast ownership. R6 is unclear because the CV is silent on finance collaboration.

- **Hard gates:** none failed; unconfirmed: R10 (Bristol hybrid, two days a week in the office); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the forecast scope is confirmed, meaning whether the forecast moves from finance to this role (RR1); (2) the posting is confirmed live on Quillfield's own careers page (RR2); (3) you confirm you can do Bristol two days a week and that the salary works for you (R10).

**Opportunity ledger.** The employer checks out and the scope is defined. Quillfield is a real Bristol company, and the posting's £61.5k–£67k sits inside the UK band from one pay guide (RR3, RR4). The forecast ownership boundary is unstated (RR1), and the posting isn't on Quillfield's careers page in search (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) in April 2025 | `[grounded]` search snippet from quillfield.co.uk/about, not fetched |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Bristol office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options; share options unquantified | `[grounded]` posting |
| Market calibration | UK revenue operations lead, B2B software: median £64,200, IQR £57,800–£70,400 (n=438). The posting sits inside the IQR | `[generic]` Ledgerline 2026 pay guide |
| Scope read | Scope is defined, but the forecast role is unclear: it is written as owned, while the finance team may still run it | `[inferred]` from the posting against the CFO line |
| Unknowns | Whether forecast ownership moves from finance; whether billing data access is read-only or write; the reporting line; your constraints (location, salary floor, contract type) | — |
| Contradictions | None found between the posting and the search results. The posting wasn't found on the company's careers page in search | `[grounded]` search |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years in revenue ops, sales ops or analytics | must_have | direct | high | none | Five years in sales ops, the last two running revenue ops for the UK team | `[grounded]` CV | none |
| R2 | At a B2B software company | must_have | adjacent | medium | transferability | B2B payments, not software. Quillfield's own product is invoicing and payments, which is the nearest bridge | `[grounded]` CV; `[inferred]` the bridge | State the payments link in the application |
| R3 | HubSpot or Salesforce administration | must_have | direct | high | none | Salesforce admin certified; rebuilt pipeline and renewal dashboards | `[grounded]` CV | Certificate can be checked |
| R4 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily. "Modelling" isn't shown in the CV | `[grounded]` CV | Offer a model sample (W1) |
| R5 | Experience owning a forecast | must_have | adjacent | medium | transferability | Runs the monthly pipeline review with the sales director, which feeds forecasting. Never owned the company forecast; finance did | `[grounded]` CV; `[inferred]` the bridge | Question Q1 |
| R6 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | The CV says nothing about finance collaboration | `[grounded]` CV silence | Question Q3 |
| R7a | Own CRM data | important | direct | high | none | Salesforce admin; dashboard rebuilds | `[grounded]` CV | none |
| R7b | Own billing data | important | absent | high | capability | Never worked on billing data. Payments-company data is the nearest, but no billing data is in the CV | `[grounded]` CV | Question Q3 |
| R8 | Build pipeline and renewal reporting | important | direct | high | none | Rebuilt the pipeline and renewal dashboards | `[grounded]` CV | none |
| R9 | Run the quarterly revenue forecast with the CFO | important | adjacent | medium | transferability | Same limit as R5, plus no CFO-facing forecast work | `[inferred]` | Question Q1 |
| R10 | Hybrid, two days a week in the Bristol office | hard_gate | unclear | none | hard_gate | Your location and constraints weren't given, so there's nothing to grade yet | `[grounded]` posting | Question Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R5, R9) | transferability | Pipeline reviews, not the company forecast | Likely first objection; a clear answer may move this to `direct` | Any forecast you contributed to, even as the pipeline input | A pipeline-to-forecast bridge sheet, or a pipeline review pack | `[inferred]` bridge |
| G2 | Billing data (R7b, R6) | capability | None in the CV | Required, and the posting puts billing data in scope | Any payments-company reporting that touched invoices, settlements or collections | A sanitized report or data dictionary | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership boundary unstated | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may own the forecast or may just feed finance's version | `[inferred]` from the posting against its silence on the finance split | Does this role take over the forecast from finance, or build its inputs? | unresolved |
| RR2 | Posting not located on the company's careers page | unknown | — | Search for the title on Quillfield's careers found no results | The posting may be stale or aggregated, or the careers page may not have it yet. Search doesn't prove absence | `[generic]` pattern for job-board postings | Which page should I apply through, and who is the hiring manager? | unresolved |
| RR3 | Employer verifiable | positive_signal | — | "Founded 2018 in Bristol; 96 employees. Series A (£11M) closed in April 2025" | The company is real and has funding | `[grounded]` About page snippet | — | noted |
| RR4 | Defined scope and pay inside band | positive_signal | — | "£61,500–£67,000 plus share options" | The pay is in line with the UK band | `[generic]` band against `[grounded]` posting | What does the share option package look like? | noted |

**Severe red flags:** none found. The posting asks you for nothing (no fees, deposits or bank details).

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with Salesforce admin, pipeline and renewal dashboards, and weekly SQL. Describe the pipeline review as forecast input, not forecast ownership | Honest framing of R5 and R9 | `[grounded]` CV | pending your approval |
| A1 | Check the posting on Quillfield's careers page before you apply | RR2 | `[grounded]` search | pending your approval |
| A2 | Decide whether Bristol two days a week and the salary work for you | R10 | `[grounded]` posting | pending your approval |
| A3 | Raise the forecast scope with the recruiter or hiring manager before the first interview | RR1 | `[inferred]` | pending your approval |
| W1 | A sanitized pipeline or renewal dashboard as a work sample | R4, R8 confidence | `[grounded]` CV | pending your approval |

**Positioning note.** The hiring manager's public profile (search snippet) shows four years in sales operations at a payments company. Lead with payments pipeline and renewal work. This is a choice about emphasis, not a claim about the person.

## Evidence status

Verified: none yet. Your CV claims are self-reported. The Quillfield facts and the pay band come from search snippets I haven't checked against the source pages.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company" → About Quillfield (quillfield.co.uk/about), snippet only. Searched "Quillfield Revenue Operations Lead Bristol careers" → no results, so the posting isn't confirmed on the careers page. Careers page not fetched. Moved RR2 and RR3 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B software Bristol" → Ledgerline 2026 UK Revenue Operations Pay Guide (ledgerline.example), snippet only. Moved the market calibration line and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" → LinkedIn profile snippet (linkedin.example/in/tamsin-achebe): Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years. Moved the positioning note |

## Upgrade menu

- The posting confirmed live on Quillfield's careers page (fetch it) → RR2 and A1 resolve.
- Your non-negotiables: location, salary floor, contract type → R10 and the decision.
- A pipeline or renewal dashboard, or a model sample → R4 and R8 confidence rises.
- Any billing or invoice data exposure, even read-only reports → R7b and R6.
- Deeper research on Quillfield (funding history, leadership changes, employee reviews): up to 5 more searches and 2 more fetches. Say the word and I'll run it.

If you want this saved for later, I can write it to a `tuesday-dossier.md`.

**Questions** (response modes: answer in text, paste a voice transcript, attach a document, drop a link, or say skip):

- **R5:** Does this role take the quarterly forecast over from finance, or build the pipeline inputs finance uses?
- **R10:** Can you work two days a week in Bristol, and what salary floor do you need?
- **R6 and R7b:** Have you had any access to billing or invoice data at the payments company, even read-only reporting? Who did you work with on it?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.