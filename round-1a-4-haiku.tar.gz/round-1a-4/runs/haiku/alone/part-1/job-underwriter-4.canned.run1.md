## Decision snapshot

**Decision: conditional_go.** Your evidence matches the stated requirements well. The open question is the opportunity itself: I could not confirm that Brindlemoor exists as described.

- **Fit ledger (candidate):** Must-haves are met on your stated record: pricing analytics years, SQL/Python, GLM, presenting to underwriting. Pet insurance is not a requirement. Management is unclear, not failed.
- **Hard gates:** Fully remote UK: unknown. Your location isn't in your background. Nothing shows a failure.
- **Opportunity:** Employer unverified (medium risk, caps a `go`). Compensation not stated.

## Role reality

- **Role:** Senior Pricing Analyst, pet-insurance product, Brindlemoor (insurtech). Builds and monitors rating models, designs and reads price tests, turns results into recommendations for underwriting and product. Reports into Odile Varga, Director of Pricing `[grounded]`, from your JD.
- **Scope read:** "Own pricing analytics" reads as ownership of a function's analytical work. The JD does not state direct reports `[inferred]`.
- **Contradictions:** None found in the JD itself. The company could not be found in search (see evidence status).
- **Market calibration:** Not run. The role-family sweep was skipped.
- **Compensation:** Unstated. The posting withholds it, which is itself worth a question.

## Evidence map

| # | Priority | Fit | Requirement | Evidence (your background) | Confidence | Gap |
|---|---|---|---|---|---|---|
| 1 | Must | Met | 4+ yrs pricing or actuarial analytics | 5 yrs pricing analytics, last 2 senior | medium (CV-stated) | none |
| 2 | Must | Met | Strong SQL and Python | Daily use | medium | none |
| 3 | Must | Met | GLM experience | Built and maintained young-driver GLM | medium | none |
| 4 | Must | Met | Presenting to underwriting or actuarial leads | Quarterly pricing review to head of underwriting | medium | none |
| 5 | Responsibility | Met | Design and read price tests | 14 tests last year with underwriting | medium | none |
| 6 | Responsibility | Partial | Build and monitor rating models | Built and maintained; monitoring not described | low | discovery: say whether you ran monitoring |
| 7 | Plus | Met | Insurance experience | UK motor insurer | medium | pet not required |
| 8 | Implied | Unknown | Direct reports / leadership | No management experience | n/a | capability: scope unclear |
| 9 | Hard gate | Unknown | Fully remote, UK | Location not stated | n/a | hard-gate: confirm |

Your claims rest on your CV. They are leads until something outside it backs them, such as model documentation or a reference.

## Gap recovery queue

- **Row 6 (monitoring):** Gap type *discovery*. Closes with a description of how you tracked model performance after build.
- **Row 8 (leadership):** Gap type *capability*. Depends on whether the role manages people, which the JD does not say.
- **Row 9 (location/eligibility):** Gap type *hard-gate*. Closes with a one-line confirmation.
- **Pet insurance:** Gap type *transferability*. Not a requirement. Your motor pricing, testing and GLM work transfer directly; it is a framing point, not a barrier.

## Opportunity risk register

- **Failed attribution — medium, standing.** Public search for "Brindlemoor insurtech pet insurance" returned no company results. Possible reasons, none ranked as more likely: the company is too new or small to be indexed, the posting is stale, or the employer is not a real hiring company. This caps the decision at conditional_go until verified. To resolve: a link to the live posting, the company's own careers page, or the recruiter's email domain.
- **Compensation unstated — medium.** Cannot compare to your floor.
- **Scope unclear — medium.** Direct reports unknown; affects whether "Senior" here means the role you have held.

**Positive signal:** The hiring manager has a public professional footprint (a search snippet, not an opened page): Director of Pricing at Brindlemoor, a prior head of pricing analytics role, and a 2025 talk on monitoring rating models in small books. That overlaps with the monitoring gap in row 6.

## Application plan

- **Lead with:** GLM ownership, price-test design and reading, and presenting to an underwriting head. These are your verified-in-CV strengths for this reader.
- **Don't claim:** pet experience, or any management.
- **Resume edits:** None proposed yet. Any CV wording needs your approval before it goes anywhere.

## Evidence status

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | Search returned no company results; no official site found |
| 2 | Role-family sweep (scope, title, pay) | skipped | Not run in this pass |
| 3 | Hiring manager public footprint | yes | Query "Odile Varga Director of Pricing Brindlemoor"; result: a profile listing and conference talk, read from the search snippet only, not an opened page |

## Dossier offer

If you want, I can write a `tuesday-dossier.md` file holding this analysis for later sessions.

## Upgrade menu

- **Live posting or careers page:** verifies the employer and would clear the failed-attribution cap.
- **Model documentation or a work sample (anonymised):** raises rows 3 and 6 from medium/low to high.
- **Deeper company check:** an offer, once: up to 5 more searches and 2 more fetches, on your say-so. It covers funding, leadership changes and public candidate reports.

## Questions

1. Does this role manage any people, or does "own" mean owning the analytics work alone?
2. Can you send the live posting link, the careers page, or the recruiter's email, so I can confirm the employer?
3. Is there a salary range, and are you UK-based (confirming the remote gate)?

Reply with answers, say "skip" to any, or ask for the deeper check.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.