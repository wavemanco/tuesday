**Yes, worth applying, on conditions: `conditional_go`.** On your stated experience, R3, R4, R5, R7 and R8 read `direct`. R6 (BigQuery) is adjacent, and the two hard gates, R1 (location) and R2 (pay floor), are unconfirmed until you state your constraints.

## Decision snapshot

**Answer: yes, on conditions. Status: `conditional_go`.**

**Fit ledger**

- `hard_gate`: unclear: R1 (remote US or Denver office), R2 (base $148,000–$166,000)
- `must_have`: direct: R3 (5+ years data engineering), R4 (SQL and Python), R5 (dbt and a cloud warehouse), R7 (Airflow or similar), R8 (data quality testing)
- `important`: adjacent: R6 (BigQuery warehouse); unclear: R9 (ingestion from app and CRM), R10 (data contracts)

R6 — Snowflake and dbt carry over, BigQuery never used; R9, R10 — background silent, not a fit call either way; R1, R2 — the gates, unknown until you state your location and floor.

**Opportunity ledger.** Clean on the posting: a live page, a stated pay range inside the market band, and no requests of you (RR4). Open items are scope (RR1), the unnamed hiring manager and team (RR2), the unstated equity amount (RR3), and attribution resting on the company's own site (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver office), R2 (base $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location fits R1; (2) the base range fits your floor, R2; (3) RR5 clears through the company's own careers page or a recruiter email on pellucidlearning.com; (4) R6 is framed as adjacent with the BigQuery limit named.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 states, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` about page on the company's site |
| Mandate | Build and run reporting pipelines: ingestion from app and CRM, a dbt warehouse in BigQuery, and data contracts analysts rely on | `[grounded]` JD and live careers page |
| First-year outcomes | Not stated | — |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Three named areas for one reporting function, with no direct reports stated | `[inferred]` from the three areas (RR1) |
| Market calibration | Posted $148,000–$166,000 sits inside the middle half of the band (median $151,000, IQR $139,000–$163,500) for this title and stage; your six years are within the typical 5–8 years for "Senior" | `[generic]` Datawright 2026 report, search snippet only; `[grounded]` JD range |
| Unknowns | Hiring manager, team size, equity amount, first-year outcomes, whether ingestion is built or inherited | — |
| Contradictions | None between the JD and the company's about page | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No location stated; nothing in the background settles it | `[grounded]` JD terms | Question 1 |
| R2 | Base $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor stated; the range sits inside the market band (RR4) | `[grounded]` JD; `[generic]` band | Question 2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-reported at intake; medium is the intake ceiling | `[grounded]` intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Used daily, self-reported; no artifact inspected | `[grounded]` intake | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project on Snowflake, about 180 models; BigQuery is named separately (R6) | `[grounded]` intake | none |
| R6 | BigQuery warehouse (role description) | important | adjacent | medium | transferability | Snowflake and dbt carry over; BigQuery never used, so its specifics are not claimed | `[grounded]` intake; `[inferred]` adjacency | G1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration, self-reported | `[grounded]` intake | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, self-reported; no artifact inspected | `[grounded]` intake | none |
| R9 | Ingestion from app and CRM | important | unclear | none | discovery | Background does not say whether you built ingestion from these sources | `[grounded]` CV silence | G3 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Background silent on contracts | `[grounded]` CV silence | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R6, important) | transferability | Snowflake and dbt at about 180 models; no BigQuery | The posting names BigQuery; a Snowflake background will be asked about it | Any dbt or SQL work on another warehouse, or a migration between platforms | A small dbt project run on BigQuery, or a migration note | `[grounded]` intake; `[generic]` that a platform question is a likely probe |
| G2 | Data contracts (R10, important) | discovery | Background silent | Named as something analysts depend on | Schema agreements, breaking-change processes, data SLAs you ran with analysts | A sanitized contract spec or analyst-facing change log | `[grounded]` JD and CV silence |
| G3 | Ingestion from app and CRM (R9, important) | discovery | Background silent | Named first in the scope | Building or running connectors from an app database or CRM | A sanitized pipeline diagram | `[grounded]` JD and CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope spans three areas | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse … and the data contracts" | One role may own all three, wider than one domain's pipelines | `[inferred]` from the three areas against typical scope | Which of these three areas does this role own outright, and which are shared with analysts or other engineers? | unresolved |
| RR2 | Hiring manager and team unnamed | unknown | — | The posting names no hiring manager | Team size and reporting line are not visible | `[grounded]` posting silence | Who would I report to, and how many data engineers are on the team? | unresolved |
| RR3 | Equity amount unstated | unknown | — | "$148,000–$166,000 plus equity" | Equity value cannot be judged | `[grounded]` JD | What is the equity range for this level, and what is the vesting schedule? | unresolved |
| RR4 | Pay range posted and within band | positive_signal | — | "$148,000–$166,000" | The posted range sits inside the middle half of the market band | `[grounded]` JD range; `[generic]` Datawright band | Does this range reflect the level you're hiring at? | noted |
| RR5 | Employer attributable only through its own site | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | Three searches found no third-party coverage beyond the company's about page. Reasons, none ranked: too new or small to have a footprint; a stale or aggregated posting (the careers page is live); or no real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Who would I be interviewing with, and can you confirm this role from the company's own careers page? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the R3, R7 and R8 stories, stated as Snowflake work at about 180 models | Verified intake, named as it happened | `[grounded]` intake | pending your approval |
| A2 | For BigQuery, say you have not used it and that the Snowflake dbt experience carries over, with no more claimed | R6's limit, named | `[grounded]` R6 | pending your approval |
| A3 | Put RR1, RR2 and RR3 to the recruiter before investing in the loop | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A4 | Confirm the role on the careers page and the recruiter's email domain | RR5 | `[grounded]` RR5 | pending your approval |

Every row is a proposal. Nothing here is final, and no CV or outreach wording changes, until you approve it.

## Evidence status

Verified: none yet. Every claim above is intake, self-reported and unprobed.

Research tier: L1 — searches 3 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results) and "Pellucid Learning Series C funding 2026" (returned only the about page). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): posting live, text matches yours. Fetched "About Pellucid Learning" (pellucidlearning.com/about): facts match yours, with no independent corroboration. Moved RR5 and the contradictions row (none) |
| 2. Role-family sweep | yes | Searched "senior data engineer salary Series B D company 2026 base median"; returned the Datawright 2026 Data Engineering Pay Report (datawright.example/2026-data-engineering-pay-report) by snippet only; its method was not read. Moved the market calibration `[generic]` and RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. The upgrade menu names what a name would unlock |

## Upgrade menu

- A small dbt project run on BigQuery, or a migration note, if it is yours → R6 moves toward `direct`.
- A sanitized contract spec or analyst change log → R10 confirmed or closed.
- A sanitized ingestion diagram → R9 confirmed or closed.
- Your location and pay floor → R1 and R2 resolved.
- The equity range and the hiring manager's name → RR3 closed; a name unlocks the public-footprint check (target 3).
- A deeper company pass (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches). I'd offer this once: say the word and it runs.

If you want this kept for interview prep, I can write it up as `tuesday-dossier.md`; say the word.

**Questions**

1. R1 — What's your location, and can you work remotely from the US, or do you need the Denver office?
2. R2 — Is $148,000 your floor, and does the top of the range ($166,000) work for you?
3. G2/G3 — Who defined and enforced the data contracts your analysts relied on, and did you build ingestion from the app or CRM?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.