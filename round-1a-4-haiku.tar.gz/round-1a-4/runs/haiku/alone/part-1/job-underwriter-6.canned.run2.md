**Research tier: L0, no searches; user links read 1**

## Decision snapshot

- **Decision: conditional_go.** Apply, but treat the forecast and billing requirements as the interview's main test, not a footnote.
- **Fit ledger (requirements, not a score):**
  - Meets: Salesforce admin (R2); SQL and Excel use (R3).
  - Partial: 4+ years at a B2B software company (R1).
  - Gap: owning a forecast (R4); working with finance on billing or revenue data (R5).
- **Hard gates:** Location and pay are unknown against your constraints. You haven't given your location or a salary floor, so I can't check either. Bristol, two office days a week, is the location term. £61,500–£67,000 plus share options is the pay term.
- **Confidence:** Medium across the board. Everything rests on your CV claims. Nothing is document-checked yet.

## Role reality

- **Role** [grounded]: Revenue Operations Lead, Quillfield, Bristol, hybrid (two days a week in the office). You would own CRM and billing data, build pipeline and renewal reporting for sales and finance, and run the quarterly revenue forecast with the CFO.
- **Pay** [grounded]: £61,500–£67,000 plus share options. The band against role-family norms is not calibrated; that needs research.
- **Scope read** [inferred]: This is one role covering CRM, billing data, reporting for two departments, and the forecast. The posting leans toward finance as much as sales ops. Team size and reporting line are not stated.
- **Contradiction** [grounded]: The posting asks for "B2B software" experience. Your background is B2B payments. That's a close but not identical match.

## Evidence map

| # | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|
| R1 | 4+ years RevOps, sales ops or analytics at B2B software | Partial | Medium | Transferability | 5 years sales ops at a B2B payments company; last 2 running UK revenue ops |
| R2 | HubSpot or Salesforce admin | Meets | Medium | None | Salesforce admin certified; rebuilt pipeline and renewal dashboards |
| R3 | Strong SQL and spreadsheet modelling | Meets (SQL, Excel); partial (modelling) | Medium | None | SQL weekly, Excel daily; "modelling" not described |
| R4 | Experience owning a forecast | Gap | n/a | Capability | You run the monthly pipeline review with the sales director. Finance owned the company forecast. |
| R5 | Experience working with finance on billing or revenue data | Gap | n/a | Capability | Never worked on billing data |
| H1 | Location: Bristol, hybrid | Unknown | n/a | Hard gate | Your location not given |
| H2 | Pay: £61.5k–£67k plus shares | Unknown | n/a | Hard gate | Your floor not given |

## Gap recovery queue

- **R4, forecast ownership:** You haven't owned the company forecast. What would close it: evidence of forecast-adjacent work (see the question below). If there is none, say so plainly; don't stretch the pipeline review into forecast ownership.
- **R5, billing data:** You haven't worked on billing data. What would close it: any touchpoint with invoices or revenue data, even indirect.
- **R1, transferability:** Payments and software overlap in B2B sales ops. Frame it as B2B sales ops at a payments company, not as software experience.

## Opportunity risk register

- **Scope stretch** (medium, inferred): One role covering CRM, billing data, reporting for two departments and the forecast. Ask about team size and who the role reports to.
- **Employer not checked** (medium, standing): The posting is consistent and specific, but I have not confirmed Quillfield or the role independently. This caps the decision at conditional_go until it is verified.
- **Red flags in the posting:** None found. It doesn't ask for money, deposits or bank details.

## Application plan

- **Lead with:** Salesforce admin certification; pipeline and renewal dashboards you rebuilt; SQL and Excel in daily use; a UK revenue team; the monthly pipeline review with your sales director.
- **Don't claim:** Forecast ownership or billing-data experience. Describe the pipeline review as what it was: you ran it with the director.
- **Before applying:** Ask the recruiter who owns the forecast in practice, whether billing data sits in the same systems you'd manage, and who the role reports to.
- **Interview prep:** Be ready to explain how you would build a forecast you didn't previously own, and what you'd want to learn from finance first.

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Quillfield official site and careers page | skipped | Research not yet consented |
| 2 | Role-family sweep (scope, title, pay for this seniority) | skipped | Research not yet consented |
| 3 | Hiring manager's public footprint (Tamsin Achebe) | skipped | Research not yet consented |

Research costs up to 5 searches and 2 page fetches at L1.

## Dossier offer

I can save this analysis as `tuesday-dossier.md` so it carries into interview prep, if you'd like.

## Upgrade menu

- **Your location and pay floor:** Unlocks the hard-gate check (H1, H2), which is currently unknown.
- **Your CV:** Moves R1–R3 from CV claims to document-checked evidence.
- **Salesforce certificate:** Upgrades R2 to high confidence.
- **Research (L1):** Checks that Quillfield exists as described and is hiring this role, the pay band against role-family norms, and the hiring manager's public background.

## Questions

1. (R4) In the monthly pipeline review, did you have any say in the forecast numbers, such as setting stage weightings or building a commit or best-case view? Or were you presenting numbers that finance or the director produced?
2. (R5) Has any of your work touched invoices, billing or revenue data, even indirectly? For example, reconciling bookings to invoices with finance, or pulling billing exports for your renewal dashboards.
3. (H1, H2) Where are you based relative to Bristol? And what's the lowest base salary you'd accept?

Answer any of these, say "skip" to leave one (I won't re-ask), or say "research" to run the L1 checks.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.