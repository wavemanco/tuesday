**Decision: conditional_go.** Apply, but as a targeted application with honest positioning, not a volume push. You're not wasting your time, but the must-have PM requirement is a real screen risk, and nothing in your materials closes it yet.

**Fit ledger** (fit only; the posting itself raises no red flags in what you pasted)

| Priority | Fit | Requirement | Evidence |
|---|---|---|---|
| Must-have | Gap | 3+ years product management | No PM title or PM-owned roadmap in your materials |
| Must-have | Partial | Shipped API or platform products | You implemented 30+ REST API integrations for clients; you didn't own a product through to release |
| Strong | Strong | Technical fluency with API docs and schemas | Postman, SQL, OpenAPI, integration architecture |
| Strong | Strong | Stakeholder management across eng, sales, customers | Coordinated vendor engineers, client engineers and PMs on custom builds |
| Strong | Partial | Discovery with partners | Scoping workshops and quarterly roadmap-input sessions are close, but you collected input rather than setting direction |
| Strong | Partial | Specs and delivery | Requirements documents and UAT; you didn't drive a squad's sprint plan |
| Preferred | Gap | Adoption metrics | None in your materials |
| Preferred | Unknown | Agile delivery | Not on your resume |

Hard gates: none identified in the posting. Length of experience is a must-have gap, not a gate, so it doesn't block you outright.

Confidence: everything here rests on your resume alone, so it's a lead to test, not verified evidence.

**Honest read on the PM years.** Your strongest material is the implementation-to-product path: you know how clients use the API, where integrations break, and what product teams need to hear. That's a real asset for a platform PM role. But "ran roadmap-input sessions" can't be described as "owned the roadmap." Keep the wording to what you did: you collected and synthesized client feedback into quarterly product inputs. Anything stronger will be checked in the first technical conversation.

**Gap recovery queue** (what each gap is, and what would close it)
- **G1, PM years (transferability):** Closed only by evidence of decisions you owned, even informal ones: a backlog you prioritized, a scope call you made that shipped. Rewording won't close it.
- **G2, shipped product (partial):** Closed by one case where you drove an API change or feature from request to adoption.
- **G3, adoption metrics (capability):** Closed by any number you tracked, such as go-live time per integration, client count, or support volume per integration.
- **G4, agile (unknown):** Closed by a plain yes or no, with the team setup.

**Risk register**
- Company existence, stage (~150 people, Series B) and whether the posting is live are not yet checked. Those come from your description, not a source. Until verified, this stays an open item.

**Application plan**
1. Ask the recruiter directly how flexible the 3-year PM requirement is. Ask about the scope split between the two squads, too.
2. Lead with the integration-ownership story, quantified: 30+ integrations, end to end, from scoping to go-live.
3. Name the PM gap yourself in the cover note, and pair it with the adjacent decision-making you did own.
4. Prefer referrals and roles titled technical PM, platform PM, or integrations PM, where the bar is closer to your experience.
5. If the request-triage tool is real, it's your best PM-adjacent proof. Don't use it until you've confirmed the details.

**Evidence status**

Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | Research not run in this turn; available on request |
| 2 | Role-family sweep (scope, title, pay) | skipped | Research not run in this turn; available on request |
| 3 | Hiring manager's public footprint | n/a | No name given |

If you want, I can run the company check and market sweep. That would verify whether Quartzline and this posting are real and current, and give you a pay band to compare against.

Dossier: I can save this analysis as `tuesday-dossier.md` for later use.

Upgrade menu, what each input would unlock:
- Triage-tool details (what it did, who adopted it, how you measured it) would move the PM-adjacent evidence from unverified to usable.
- A PM-scope example would address G1 directly.
- Agile experience would close G4.
- The company check would close the existence and stage questions.

Questions:
1. **G1:** Have you ever owned a prioritization or scope decision for a product or feature, even informally? What did you decide, and what happened?
2. **G4:** Have you worked in sprints with an engineering team (backlog, planning, reviews)? How often, and in what role?
3. **Triage tool:** Did you build it yourself? What did support agents adopt, and how did you measure that?

Answer in prose, or say "skip" on any question.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.