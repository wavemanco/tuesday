**Decision: conditional go.** Apply only if you can truthfully point to forecast or finance-facing work. The posting names two must-haves you haven't done, and the rest of your background fits well.

Research tier: L0, no searches. Everything below comes from the posting you pasted and your background as you described it. Posting facts are `[grounded]`; anything about fit is my inference.

**Hard gates:** none confirmed failed. Two are unknown to me: Bristol hybrid (two days a week in the office) and whether £61,500–£67,000 meets your floor. Please tell me both.

**Fit by requirement**

| Requirement (from posting) | Your evidence | Fit |
|---|---|---|
| 4+ years RevOps / sales ops / analytics at a B2B software company | 5 years sales ops at a B2B payments company, last 2 running RevOps | Likely met. Whether a payments company counts as "software" is a judgment call. `[inferred]` |
| HubSpot or Salesforce administration | Salesforce admin certified; rebuilt pipeline and renewal dashboards | Met |
| Strong SQL and spreadsheet modelling | SQL weekly, Excel daily | Likely met. "Modelling" depth is unverified. |
| Experience owning a forecast | Finance owned the company forecast; you run the monthly pipeline review with the sales director | **Not met.** Adjacent, not equivalent. Gap type: transferability. |
| Experience working with finance on billing or revenue data | No billing data; unknown whether your revenue reporting touched finance | **Not met as stated.** Possibly closable if your revenue or renewal work reconciled with finance. Gap type: discovery. |

**Role reality** `[grounded]`: owns CRM and billing data, builds pipeline and renewal reporting for sales and finance, runs the quarterly revenue forecast with the CFO. This is company-wide ownership, a step up from running one country team. It also takes you into billing, which is new to you.

**Opportunity risks** (from the posting only, no outside checks):
- The forecast is a named CFO-facing responsibility, so you would be judged on it from the start.
- Pay is stated; share options are unquantified.
- I have not verified that Quillfield exists as described, or that this posting is current. Checking the company's own careers page would settle that.

**Application plan**
- Lead with the pipeline and renewal dashboards and the monthly pipeline review as your closest forecast-adjacent work.
- Do not claim forecast ownership or billing experience. Describe the finance-adjacent work only as accurately as you can document it.

**Dossier offer:** If you want, I can save this assessment as `tuesday-dossier.md` for a later interview-prep pass.

**Upgrade menu** (what would change the call):
- Forecast or finance evidence: any work where your pipeline or renewal numbers fed the company forecast, or where you reconciled them with finance. This is the main thing that moves the decision.
- The live posting or Quillfield's careers page, to confirm the role is current.
- Public research on Quillfield (funding, leadership, recent news). I can run that if you say yes.

**Questions:**
1. Did your pipeline or renewal reporting ever feed the company forecast, or get reconciled with finance? If so, how?
2. Can you do Bristol two days a week, and is £61.5k–£67k above your floor?
3. Do you want me to run a light research check on Quillfield (up to 5 searches and 2 page fetches) to confirm the company and posting are real?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.