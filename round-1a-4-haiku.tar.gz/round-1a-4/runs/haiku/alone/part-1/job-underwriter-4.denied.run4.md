## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R9 (fully remote, UK-based; your location and right to work were not given)
- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: adjacent: R6 (pet-insurance product)
- `preferred`: direct: R7

**Opportunity ledger.** The role is clearly scoped: rating models, price tests, and recommendations to underwriting and product. Three things are unknown: whether it line-manages anyone, the salary (not stated), and whether Brindlemoor exists as described. I could not check the last one because search was not permitted (see Evidence status).

- **Hard gates:** none failed; unconfirmed: R9 (fully remote, UK-based). Your other constraints were not given, so checks against them are unknown.
- **Severe red flags:** none found in what you pasted. The employer check did not run, so this is not a clearance.
- **Conditions for go:**
  1. Confirm Brindlemoor is a real hiring employer as described (RR3).
  2. Confirm whether the role manages people (RR1).
  3. Present pet insurance as a transfer from motor, not as pet experience (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; the role supports its pet-insurance product | `[grounded]` JD header. Existence not checked (RR3) |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Decision rights | The role recommends. Who decides on rates and tests is not stated | `[inferred]` from "recommendations" against silence on decision rights |
| Level | Same level as your current senior analyst role, not a step up | `[inferred]` from matching titles |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing. Public footprint not researched | `[grounded]` JD |
| Market calibration | No band. The salary and role-family searches did not run | — |
| Unknowns | Line management; salary; decision rights; team size; whether this replaces someone | — |
| Contradictions | None within what you gave me. The careers page was not checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, the last two as senior analyst, at a UK motor insurer | `[grounded]` your statement in this chat | Confirm with a CV or reference |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Used daily in the current role | `[grounded]` your statement | Work sample would raise to high |
| R3 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. The requirement does not name a product, so motor counts | `[grounded]` your statement | Rating-model summary would raise to high |
| R4 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your statement | Pack or slide sample would raise to high |
| R5 | Designing and reading price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your statement | Test-results summary would raise to high |
| R6 | Pet-insurance product knowledge (implied by "for our pet-insurance product") | important | adjacent | medium | transferability | The rating and test method carries over. Pet-specific factors and claim patterns were not exercised | `[inferred]` adjacency from motor pricing work. `[generic]` that pet pricing differs in claim patterns | G1 |
| R7 | Insurance experience | preferred | direct | medium | none | Motor insurer pricing | `[grounded]` your statement | None |
| R9 | Fully remote, UK-based (location and right to work) | hard_gate | unclear | low | hard_gate | Your location and right to work were not given | — | Confirm your location and eligibility |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R6, important) | transferability | Motor pricing work is clear. Nothing on pet-specific rating or claims | The role is for a pet product, so the question will come up. A clear bridge answers it | Any rating work on a non-motor line; any claims-frequency or severity work where the drivers differed from motor | A sanitized rating-factor summary, or a short note on how you handled a claim pattern unlike motor's | `[inferred]` bridge from your motor work. `[generic]` that pet claim patterns differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Line management not stated, and you have never managed people | unknown | — | JD silent on reports | The role may lead analysts, given it owns the product's pricing analytics | `[inferred]` from the JD's scope against its silence on reports | Does this role line-manage anyone, now or in its first year? | unresolved |
| RR2 | Salary not stated | unknown | — | JD silent on pay | The figure may be withheld until interview | `[inferred]` from the posting's silence | What is the salary band for this role? | unresolved |
| RR3 | Employer not verified | risk_signal | medium | "Brindlemoor (insurtech)" | The posting may be live and the employer real but unconfirmed. Reasons side by side, none ranked likely: too new or small; a stale posting; not a real hiring employer | `[inferred]`. Research did not run | Can you send the live posting link, the company's careers page, and the recruiter's email domain? | unresolved |
| RR4 | Concrete responsibilities and named hiring manager | positive_signal | — | "build and monitor rating models, design and read price tests" | The scope is defined, so the work is checkable at interview | `[grounded]` JD | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send the live posting link and the recruiter's email domain so the employer can be checked | RR3 | `[grounded]` RR3 | proposed |
| A2 | Ask the recruiter whether the role line-manages anyone | RR1 | `[grounded]` RR1 | proposed |
| A3 | Ask for the salary band before the first call | RR2 | `[grounded]` RR2 | proposed |
| A4 | Lead with the GLM and price-test record (R3, R5). Describe pet as a transfer from motor (R6), not as experience | R3, R5, R6 | `[grounded]` evidence map | proposed |

Nothing here changes your CV or outreach. Any wording for either needs your approval first.

## Evidence status

Verified: none yet. Your statements in this chat are the only sources for R1 to R7, so they stay at medium confidence until a document or reference backs them.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was not permitted, so Brindlemoor's existence as described is unconfirmed (RR3) |
| 2. Role-family sweep | unavailable | The search was not permitted, so there is no market band for pay or scope (RR2 and market calibration) |
| 3. Hiring manager's public footprint | unavailable | The search was not permitted. Odile Varga's public background would have shaped A4 |

## Upgrade menu

- The live posting link and the recruiter's email domain → RR3 closes, or the employer check runs.
- Search access granted → targets 1 to 3 run, starting with the employer check and the salary band.
- Your location, right-to-work status and pay floor → R9 closes and the hard-gates line updates.
- A sanitized rating-factor or claims summary from a non-motor project → R6 rises to high.
- Deeper company diligence (funding, leadership changes, candidate reports; up to 5 more searches and 2 more fetches). It needs search access first.

If you want it, I can save this assessment as `tuesday-dossier.md` whenever you like.

**Questions**

RR1: Does this role line-manage anyone, now or in its first year?

G1: Have you worked on a non-motor product, or on a rating project using claims data from a line other than motor? What did you own, and how did the claims differ from motor?

R9: What are your non-negotiables on pay, contract type and location? Is the UK-remote arrangement fixed for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.