**Research tier: L1 — searches 1 of 5, fetches 0 of 2; user links read 0**

## Decision snapshot

**Yes, probably worth applying, but not yet. Status: `hold_pending_answers`.** Your must-haves line up with your stack and the stated pay sits near the market median. Two hard gates are unchecked, and I could not verify that the employer and posting are real.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Location: remote US or Denver office), R2 (Pay $148,000–$166,000 against your floor)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5a (dbt), R6 (Airflow or similar), R7 (data quality testing); adjacent: R5b (cloud warehouse, BigQuery named in the JD body)
- `important` — unclear: R8 (data contracts analysts depend on), R9 (ingestion from app and CRM)

R3, R4, R5a, R6 and R7 are `medium` because they rest on your own account, with nothing inspected yet. R5b is the one real gap: Snowflake counts as the cloud warehouse, but you have never used BigQuery.

**Opportunity ledger.** The posting is clear about scope and pay, and its stated pay is inside the market band (RR2, positive). What is missing is who owns what and who you would report to (RR1, unknown), and the employer itself has not been checked (RR3, the standing entry).

- **Hard gates:** none failed; unconfirmed: R1 (Location: remote US or Denver office), R2 (Pay $148,000–$166,000 against your floor); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** Answers to Q1 and Q2 plus a live posting from the employer's own careers page would move the status to `conditional_go` (the BigQuery gap and the unverified data-contract ownership stay open). If you are outside the US and not willing to relocate to Denver, R1 becomes `hard_gate_fail` and the status is `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` employer's about page, as pasted; not checked independently |
| Mandate | Build and run ingestion from the app and CRM, a dbt warehouse in BigQuery, and data contracts for analysts | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Senior, one domain's pipelines and contracts, with no team or reporting line stated | `[inferred]` from the JD's scope language against its silence on team and authority |
| Market calibration | Base median $151,000, IQR $139,000–$163,500; the posting's $148,000–$166,000 range sits inside that IQR, with a midpoint of $157,000 | `[generic]` Datawright 2026 report (Series B–D, n=2,310), supplied by your recruiter and not checked; `[grounded]` posting range |
| Unknowns | Hiring manager; team structure; who owns contracts today; whether pay is negotiable within the range; your location eligibility | — |
| Contradictions | None between the JD and the about page. The JD names BigQuery and your warehouse is Snowflake; that is a gap, not a contradiction | `[grounded]` both documents |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: remote US or Denver office | hard_gate | unclear | none | hard_gate | Your location and eligibility were not given, so the gate is not settled | `[grounded]` JD; no candidate statement | Q1 |
| R2 | Pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor was given, so the check cannot run. The range is inside the market IQR | `[grounded]` JD; `[generic]` band | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-reported and not yet inspected | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Used daily; "strong" is your self-assessment | `[grounded]` your background | none |
| R5a | dbt | must_have | direct | medium | none | Built a dbt project of about 180 models on Snowflake | `[grounded]` your background | Offer a sanitized excerpt (upgrade menu) |
| R5b | Cloud warehouse (BigQuery named in JD body) | must_have | adjacent | medium | transferability | Snowflake is a cloud warehouse; BigQuery was never used. Limit: no BigQuery work | `[grounded]` your background; `[generic]` that warehouse switches usually carry SQL and modelling over | G1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations test suite | `[grounded]` your background | Offer a sanitized suite excerpt |
| R8 | Data contracts analysts depend on | important | unclear | none | discovery | Not in your background | `[inferred]` from the JD's wording; `[grounded]` absence in your background | Q3 |
| R9 | Ingestion from app and CRM | important | unclear | none | discovery | Not in your background | `[inferred]` from the JD; `[grounded]` absence | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Cloud warehouse, BigQuery (R5b, must_have) | transferability | Snowflake is production experience; BigQuery is absent | This is the one must-have the posting names specifically. A bridge with a stated limit answers it | Any dbt project's warehouse migration; partitioning and cost tuning on Snowflake that transfers conceptually | A short BigQuery project or a dbt-on-BigQuery sample; a course if you want a formal closure | `[grounded]` your background; `[generic]` that a short BigQuery project is a common closure path |
| G2 | Data contracts and ingestion (R8, R9, important) | discovery | Neither appears in your background | These are the two JD duties not yet covered by your evidence. They decide whether you are the owner or a builder | Schemas or SLAs you published; syncs or CDC from an app or CRM | A published schema, a contract doc, or an ingestion DAG (sanitized) | `[grounded]` absence; `[inferred]` that the JD's duties are the right lens |

Q3 covers G2's contracts side. The ingestion side stays open until your next answer.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Ownership, reporting line and hiring manager unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the sole owner of one domain, or one builder among several | `[inferred]` from the JD's scope language against its silence on team | Who else owns pipelines and contracts here, and who would I report to? | unresolved |
| RR2 | Stated pay sits inside the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is set near the median for this seniority | `[grounded]` posting range; `[generic]` band from the pay report | How is this range set, and is it the budgeted figure? | noted |
| RR3 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states." | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Not checked: the one search was refused permission | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR4 | Stage and size company-stated, not verified | positive_signal | — | "Series C ($52M, February 2026)"; "264 employees" | The company is funded and mid-sized, if the page is accurate | `[grounded]` employer's own about page, unverified | How big is the data team, and who leads it? | noted |

**Severe red flags:** none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your location against the posting's "Remote (US) or Denver" before applying | Q1 answer | `[grounded]` R1 | pending your approval |
| A2 | Find the live posting on the employer's own careers page, using contact details from its website rather than the recruiter's email | Closes RR3 | `[generic]` standing-entry pattern | pending your approval |
| A3 | Describe the warehouse as Snowflake, and say BigQuery is new to you. Do not claim BigQuery experience | Keeps R5b honest | `[grounded]` R5b | pending your approval |
| A4 | Put RR1's question to the employer verbatim in the first conversation | Register doubles as interview prep | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet. Your background and the pasted documents are all self-report or as-pasted material; nothing is inspected.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The one search (employer name, K-12 tutoring, careers) was refused permission, so no external check ran. It would have moved RR3, whether the employer and posting are real |
| 2. Role-family sweep | skipped | The pay report you sent already fixes the market band and the scope norm; a search would repeat it. Fixes the market calibration line and the mismatch check |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

## Upgrade menu

- Your answers to Q1 and Q2 → R1 and R2 leave `unclear`; the status moves to `conditional_go`, or to `no_go` if the location gate fails.
- The live posting from the employer's careers page → RR3 closes and the failed-attribution cap lifts.
- A sanitized dbt excerpt or Great Expectations suite → R5a and R7 move from `medium` toward `high`.
- A contract or ingestion example → R8 and R9 get evidence.
- Permission to retry the employer check: one search and up to two page fetches to confirm the employer and the live posting.
- Deeper employer diligence (funding, leadership changes, recent news): up to 5 more searches and 2 more fetches. Say the word once and it runs.

I can also write this up as `tuesday-dossier.md` with the full map and register, if you want a file.

**Questions**

Q1 (R1) — Are you eligible to work in the US, and would you be fine with remote work from anywhere in the US, or only with Denver-area presence?

Q2 (R2) — What is your base-pay floor, and is $148,000–$166,000 above it?

Q3 (R8) — Have you owned a data contract, such as a published schema or SLA, that analysts or downstream teams depended on? What did it cover, and who approved changes?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.