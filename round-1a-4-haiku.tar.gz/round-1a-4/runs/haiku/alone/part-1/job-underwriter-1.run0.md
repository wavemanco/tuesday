## Decision snapshot

**Yes on fit, with conditions: `conditional_go`.** R1, R2, R3, R4 and R9 read as direct matches to your background. The role is not `go` yet because the employer check did not run (SE1), and the compensation and PHI-access questions are open (RR3, RR2).

**Fit ledger.**

- `must_have` — direct: R1 (5+ years product analytics), R2 (Expert SQL), R3 (Experiment design at scale), R4 (Looker or similar BI), R9 (Strong written communication with non-technical stakeholders)
- `important` — direct: R6 (Partner with PMs to turn analysis into roadmap decisions) · adjacent: R5 (Metrics layer definition and maintenance), R7 (Partner with clinicians) · unclear: R8 (Mentor two junior analysts)
- `preferred` — adjacent: R10 (Healthcare data experience, HIPAA)

R3 — strong, with the 11% lift's method not yet stated; R5 — metric definitions are implied by your governed dashboards, not stated as owned; R7 — stakeholder partnership transfers, the clinical domain does not; R8 — nothing in your background covers mentoring; R10 — consent and PII work is adjacent, and HIPAA is a different regime.

**Opportunity ledger.** The JD names concrete deliverables (RR4), and no severe red flags are found. Open items are compensation (RR3), PHI access (RR2), and metrics-layer ownership (RR1), plus the unverified employer (SE1).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) Harborlight is confirmed on its own careers page with the role live (SE1); (2) the pay range is disclosed and checked against your floor (RR3); (3) PHI access and clinician involvement are described as normal scope (RR2, R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, about 400 people, Series C | `[grounded]` pasted JD; not checked externally (research did not run) |
| Role | Senior Product Analyst for the care-navigation app | `[grounded]` JD |
| Scope | Own the metrics layer, design and analyze A/B tests, build self-serve Looker dashboards, partner with PMs and clinicians, mentor two junior analysts | `[grounded]` JD |
| Scope read | One senior post combining metrics ownership, experiment leadership, BI build, clinical partnership and people management is broad | `[inferred]` from the responsibility list |
| Market calibration | Not established: the role-family sweep did not run, so no band | — |
| Compensation | No pay figure in the pasted JD | `[grounded]` absence in the JD text |
| Unknowns | Pay; contract type; location or remote terms; whether PHI sits in the analytics warehouse; clinician involvement; reporting line; whether the metrics layer is yours or data engineering's | — |
| Contradictions | None found in the pasted JD; no second source checked | — |

## Research tier

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches were refused, because WebSearch permission was not granted in this session. Would have moved the organization row, the contradictions row, and SE1 |
| 2. Role-family sweep | unavailable | Refused with the rest. Would have moved the market calibration and the pay band |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company, stated; no artifact | `[grounded]` user-stated | Upgrade menu |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake, stated. "Expert" is your own word; daily use at warehouse scale is what the evidence shows | `[grounded]` user-stated | Upgrade menu: query sample |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran 30+ tests a year, including the pricing test behind an 11% retention lift. Method and significance are not stated | `[grounded]` user-stated | Upgrade menu: test readout |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the company's Looker instance; 40+ governed dashboards | `[grounded]` user-stated | Upgrade menu: dashboard list |
| R5 | Metrics layer definition and maintenance | important | adjacent | medium | transferability | Governed dashboards and the monthly metrics memo imply metric definitions. Owning a semantic layer is not stated | `[inferred]` from governed dashboards and the memo | Gap queue G3 |
| R6 | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | Presents monthly to the VP Product; the exec memo drives decisions | `[grounded]` user-stated | None |
| R7 | Partner with clinicians | important | adjacent | medium | transferability | Stakeholder partnership with executives transfers. No clinical counterpart stated | `[inferred]` from executive partnership | Gap queue G2 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Nothing in the background about mentoring | `[grounded]` absence in input | Gap queue G1 |
| R9 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | The monthly metrics memo is read by the exec team | `[grounded]` user-stated | None |
| R10 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | No healthcare work. GDPR/CCPA consumer PII handling and a consent-state model are the nearest evidence; HIPAA is a different regime | `[inferred]` from the consent-model work | Gap queue G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Mentoring (R8, important) | discovery | No mention of mentoring in the background | An explicit responsibility of the role, and the one row with no evidence either way | Informal onboarding or review of junior analysts' SQL or work; training others on the Looker build | A named example of one junior analyst you coached | `[inferred]` from the JD's mentoring line |
| G2 | Healthcare and clinician work (R7, R10) | transferability | Consumer PII and consent-state work; no clinical or PHI exposure stated | Two rows, one important and one preferred; the clinician side is the bigger objection | Allergy, dietary-restriction or nutrition fields in meal-kit data; any health-adjacent subscription work | A sanitized description of the consent-state model | `[inferred]` from the meal-kit context |
| G3 | Metrics layer ownership (R5, important) | transferability | Governed dashboards and a monthly memo; no semantic-layer ownership stated | Defining and maintaining the metrics layer is the first responsibility in the JD | Canonical metric definitions in Looker; a metric dictionary you maintained | A metric dictionary excerpt, sanitized | `[inferred]` from the Looker build |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Broad scope in one senior post | risk_signal | low | "Mentor two junior analysts," alongside metrics ownership and clinician partnership | The role may be broader than one senior analyst can carry alongside metrics ownership | `[inferred]` from the JD's responsibility list | Which of these responsibilities does the role own from day one, and which are shared with data engineering or clinical teams? | unresolved |
| RR2 | PHI access not described | unknown | — | "healthcare data (HIPAA) a plus" | Analysts may or may not query PHI directly; the access model changes the job | `[inferred]` from the HIPAA mention, silent on access | Do analysts query identifiable patient data directly, and under what controls? | unresolved |
| RR3 | Pay not stated in the pasted JD | unknown | — | No compensation line in the pasted text | The band may sit below the market for this scope, or the figure is simply absent from this copy. No band was calibrated this run | `[generic]` pattern for withheld pay; band not established | What is the base salary range for this role? | unresolved |
| RR4 | Concrete deliverables | positive_signal | — | "build self-serve dashboards in Looker"; "design and analyze A/B tests" | Outcomes are specific enough to test interview claims against | `[grounded]` JD | What would success look like at six months for the metrics layer and the test programme? | noted |
| SE1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Not checked in this run; a refused check is an open item, not evidence of absence. Possible reasons: too new or small for a footprint, a stale posting, or not a real hiring employer; none ranked as likely | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on Harborlight's own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the experiment programme (30+ tests a year, the pricing test) and the Looker build | Strongest direct matches; be ready to explain the 11% lift's method and significance | `[grounded]` R3, R4 | pending your approval |
| A2 | Describe privacy work as consent and PII governance under GDPR/CCPA, never as healthcare experience | R10 is adjacent with its limit named | `[grounded]` R10 | pending your approval |
| A3 | Say "daily SQL on Snowflake" rather than "expert SQL" unless a query sample backs the word | A self-rated "expert" invites a probe | `[generic]` how interviewers probe SQL claims | pending your approval |
| A4 | Confirm Harborlight on its careers page before spending application effort | SE1 caps the decision at conditional_go | `[generic]` standing entry | pending your approval |
| A5 | Put RR1–RR3 to the employer in the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Every row rests on your statement in this message, and no artifact has been inspected.

## Upgrade menu

- Permission to use web search: the company check and role-family sweep run (up to 2 more searches and 2 fetches within L1's budget). SE1 and RR3 move; the market band gets set.
- A query sample or a dashboard list: R2 and R4 rise to `high`.
- The pricing test's readout (design, sample, significance): R3 rises to `high`.
- A sanitized metric dictionary excerpt: R5 rises from adjacent toward direct.
- The posted or budgeted pay range: RR3 closes and is set against the band.

If you want, I can save this assessment as `tuesday-dossier.md` so you can keep it.

1. Have you mentored or formally trained junior analysts? If so, can you name one example? (R8)
2. Did you handle any health-adjacent data at the meal-kit company, such as allergy, dietary-restriction or nutrition fields, or any clinical or regulated data? (R7, R10)
3. What are your pay floor, location and contract-type constraints? Hard-gate checks against them stay unknown until you answer.

Answer in text, paste a voice transcript, or say skip for any of these.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.