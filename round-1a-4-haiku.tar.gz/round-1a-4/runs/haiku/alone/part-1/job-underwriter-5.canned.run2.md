## Decision snapshot

**Worth applying, on conditions: `conditional_go`.** All five must-haves (R3, R4, R5, R6, R7) are direct on your CV. What's open is two hard-gate checks (R1, R2), BigQuery (R8), two ingestion and contracts questions (R9, R10), and whether the employer is real beyond its own website (RR1).

**Fit ledger.**

- `hard_gate` — unclear: R1 (remote US or Denver), R2 (base $148,000–$166,000)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (orchestration with Airflow or similar), R7 (data quality testing)
- `important` — adjacent: R8 (dbt-modelled warehouse in BigQuery); unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R8 — a transferable case, with BigQuery itself as the limit; R9 and R10 — no evidence on your CV yet, waiting on Q2.

**Opportunity ledger.** Scope is one domain and the posted base sits at the market median (RR4). RR1, the employer confirmed only by its own pages, caps this at `conditional_go`. RR2 (no hiring manager named) and RR3 (equity unquantified) are unknowns.

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver), R2 (base $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** R1 and R2 confirmed met (Q1); RR1 verified through a source other than the company's own pages; R9 and R10 answered with real experience (Q2). BigQuery stays a stated limit, not a condition.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 states; 264 employees; Series C ($52M, February 2026) | `[grounded]` company About page; self-reported, not independently confirmed |
| Mandate | Build and run the pipelines behind tutoring-platform reporting: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Scope read | One domain's pipelines, which matches the usual remit for this title | `[generic]` the Datawright norm; `[grounded]` JD |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, IQR $139,000–$163,500. The posted $148,000–$166,000 brackets the median and runs past the top of the IQR by $2,500 | `[generic]` Datawright 2026 report, as pasted by your recruiter; `[grounded]` posted figure |
| Unknowns | Hiring manager, team size, equity amount and vesting, your location against R1, your pay floor against R2 | — |
| Contradictions | None between the JD you pasted and the live careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location is not in the material | `[grounded]` JD | Q1 |
| R2 | Base $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your pay floor is not in the material | `[grounded]` JD | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; CV only | `[grounded]` CV | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use; CV only | `[grounded]` CV | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake; Snowflake is a cloud warehouse | `[grounded]` CV | Offer: sanitized model excerpt, which would raise to `high` |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration; CV only | `[grounded]` CV | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite; CV only | `[grounded]` CV | Offer: sanitized suite excerpt, which would raise to `high` |
| R8 | Dbt-modelled warehouse in BigQuery (JD description, not the requirements list) | important | adjacent | medium | transferability | dbt modelling carries over; you have not used BigQuery | `[inferred]` adjacency from R5 against the JD's BigQuery mention | G1 |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | CV is silent on the sources you have ingested | `[grounded]` CV silence | Q2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | CV is silent; Great Expectations is testing, not contracts | `[grounded]` CV silence | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | Snowflake dbt work; no BigQuery use | The JD names BigQuery; the limit is the platform, not the modelling | Any BigQuery use, even a personal project; dbt materializations or partitioning on any warehouse | A short note mapping your Snowflake setup to BigQuery | `[inferred]` bridge from R5; `[generic]` that a platform switch is usually learnable |
| G2 | Ingestion and data contracts (R9, R10) | discovery | No mention of source ingestion or analyst-facing contracts | Both are named in the role's first sentence | Pipelines from a product database or a CRM; a schema agreement or breaking-change notice with analysts | A pipeline diagram, a contract doc, or a schema-change example | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer established only by its own pages | risk_signal | medium | "Pellucid Learning runs live online tutoring … 264 employees" | The company may be too new or small for third-party coverage, its figures are self-reported, or the posting may not represent a hiring team | `[generic]` pattern for companies of this size, not a claim about this one | Who would I be interviewing with, and can you point me to an independent listing for the company? | unresolved |
| RR2 | Hiring manager and team not named | unknown | — | "Remote (US) or our Denver office" | Solo owner or a team; this changes the scope read | `[inferred]` from the JD's silence | Who would I report to, and how many people build and run these pipelines? | unresolved |
| RR3 | Equity unquantified | unknown | — | "plus equity" | Equity may be a small part of total pay | `[inferred]` from the JD's silence on grant size | What is the equity grant size, its vesting schedule, and the valuation it's based on? | unresolved |
| RR4 | Posted base sits at the market median | positive_signal | — | "$148,000–$166,000" | The base is in line with the market band | `[grounded]` posted figure against `[generic]` band | Is $166,000 the top of the budgeted range, or can it move? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the 180-model dbt project and the Great Expectations suite | The two strongest rows, R5 and R7 | `[grounded]` CV | pending your approval |
| A2 | Say BigQuery is new to you, and that dbt modelling and Airflow carry over, not the warehouse itself | Keeps R8's limit visible in the first screen | `[grounded]` R8; this claims no BigQuery work | pending your approval |
| A3 | Ask RR2 and RR3 in the first recruiter screen; ask RR1 of the employer | The register doubles as screen prep | `[grounded]` register | pending your approval |
| A4 | Check the employer through a source other than the company's own pages before you invest in the application | Clears RR1 | `[generic]` pattern for companies of this size | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results) and "Pellucid Learning Series C funding February 2026" (returned only pellucidlearning.com/about). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): the posting is live and matches your JD. Entity not independently confirmed, since no third-party source came back. Moved RR1 and the contradictions row |
| 2. Role-family sweep | skipped | The Datawright figures you pasted fix the market calibration line and the mismatch check; another search would not change either |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you want this kept for later, I can save it as `tuesday-dossier.md`.

## Upgrade menu

- Independent confirmation of the employer (a third-party listing, coverage of the Series C, or your recruiter's email domain) → RR1 closes, and the cap on `go` lifts.
- Your location and pay floor → R1 and R2 close.
- Hiring manager or team size → RR2 closes and the scope read firms up.
- Equity terms → RR3 closes and total pay can be compared.
- A sanitized dbt model or Great Expectations suite excerpt → R5 and R7 move from `medium` to `high`.
- Any BigQuery work, even personal → narrows R8's limit (G1).
- Deeper company research (funding history, leadership changes, employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

**Q1 (R1, R2)** — Can you work remotely from the US or from Denver, and is a base of $148,000 above your pay floor?

**Q2 (G2)** — Have you built ingestion from a product database or a CRM, or owned a data contract with analysts, such as a schema agreement or a breaking-change notice? Give one concrete example if you have one.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.