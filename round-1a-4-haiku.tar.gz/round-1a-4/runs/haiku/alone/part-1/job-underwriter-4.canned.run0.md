**Yes, worth applying, provided the location works for you. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: direct: R8 · adjacent: R9 (Pet-insurance product)

R2–R7 are all six must-haves and each reads `direct`. R9 (`medium`) is the one row that needs a bridge: motor pricing carries over, pet-specific risk does not yet.

**Opportunity ledger.** The role is clearly scoped and the posting is live on the company's own careers page, but the posting contradicts itself on location (RR1). Salary is not stated in what I could read (RR2), and whether the role line-manages anyone is unknown (RR3). One entry runs the other way: the hiring manager's public talk matches the monitoring part of the JD (RR4).

- **Hard gates:** unconfirmed: R1 (Fully remote, UK); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) location is confirmed as fully remote, or four days a week in Leeds is workable for you (RR1, R1); (2) your base-salary floor sits within reach of the market band (RR2); (3) pet insurance is framed as adjacent experience, never as product expertise (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` JD; careers page |
| Role | Senior Pricing Analyst, reporting to the Director of Pricing (Odile Varga) | `[grounded]` careers page |
| Mandate | Own pricing analytics; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` JD |
| Working pattern | Conflict: JD says fully remote (UK); careers page says Leeds office four days a week | `[grounded]` both sources |
| Scope read | Individual-contributor or lead; the posting does not say which | `[inferred]` from the absence of any stated team |
| Market calibration | Pricewell 2026 UK survey (n=612, UK insurers and insurtechs): senior pricing analyst median £58,400, interquartile range £52,100–£64,900. This is a band, not this employer's offer | `[generic]` role-family sweep, 2026 survey |
| Unknowns | Salary; line management; location | — |
| Contradictions | Location (JD vs. careers page) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK (JD) | hard_gate | unclear | medium | hard_gate | Posting conflicts with itself. Your location and remote needs are not stated | `[grounded]` JD vs. careers page | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two as senior analyst. Years are graded, not gated | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both | `[grounded]` your statement | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM | `[grounded]` your statement | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R6 | Build and monitor rating models | must_have | direct | medium | none | Build is direct. "Maintained" covers monitoring only if you ran checks on live performance | `[grounded]` your statement; `[inferred]` that maintenance includes monitoring | Confirm monitoring in your answer to Q2 |
| R7 | Design and read price tests | must_have | direct | medium | none | Fourteen price tests last year with underwriting | `[grounded]` your statement | none |
| R8 | Insurance experience (a plus) | important | direct | medium | none | Motor insurance, UK | `[grounded]` your statement | none |
| R9 | Pet-insurance product (implied by the role) | important | adjacent | medium | transferability | Motor pricing and test design carry over. Pet-specific risk drivers, claims patterns and product rules do not appear in your background | `[inferred]` from the JD's product line against your motor background | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product (R9, important) | transferability | Motor pricing analytics with GLMs and price tests. Nothing pet-specific | The likeliest objection to a motor candidate is "does this transfer to a different risk?" | Any non-motor pricing, rating or test work; any work on claims frequency or severity drivers that differ by policy type | A non-motor analysis, a short note on what would change for a pet book, or an extract of your model-review process | `[inferred]` bridge from the motor background; `[generic]` that this is the likeliest objection |

The question for G1 sits in the closing block, not here.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location term conflicts between sources | risk_signal | medium | JD: "Fully remote (UK)." Careers page: "Leeds office four days a week." | The role may be hybrid with a Leeds requirement, and the JD may be out of date | `[grounded]` both sources; the reason for the conflict is unknown | Is this role fully remote as the JD says, or four days a week in the Leeds office as the careers page says? | unresolved |
| RR2 | Salary not stated | unknown | — | No salary in the JD or the careers page I could read | The figure may sit below the band in Role reality, or the company may not publish salaries | `[inferred]` from the posting's silence, against the `[generic]` band | What is the budgeted base salary for this role? | unresolved |
| RR3 | Line-management scope not stated | unknown | — | "reports to the Director of Pricing" with no reports mentioned | The role may carry no direct reports. Or it may, and you have not managed anyone | `[inferred]` from the absence of any stated team | Does this role line-manage analysts, or is it individual-contributor? | unresolved |
| RR4 | Hiring manager's public talk matches the monitoring part of the JD | positive_signal | — | Talk listing: "Small Books, Loud Errors", on monitoring rating models in small books | Odile cares about monitoring rating models, which matches R6 | `[grounded]` search snippet, not fetched | How does the monitoring process work for the pet book today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the location term with the recruiter, or in writing, before investing in the application | RR1, R1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with GLM build-and-maintain, price-test design, and the underwriting presentation: the must-haves, which read `direct` | R3–R7 | `[grounded]` map rows | pending your approval |
| A3 | Describe pet as adjacent. Say what carries over from motor, and name what does not | R9 | `[inferred]` R9 | pending your approval |
| A4 | Use the monitoring work to meet Odile's stated interest, and only if your monitoring evidence is real | RR4, R6 | `[generic]` a talk's topic is not a hiring preference | pending your approval |

Nothing here is final CV or outreach language. Any wording for an application needs your approval before it is used.

## Evidence status

Verified: R2–R8 claims, from your own specific statements in this conversation. Verified is about the claim, not the fit. R9 is adjacent, and its limits stay named. R1 is unverified: your location and remote needs are not yet stated.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor careers Senior Pricing Analyst" and fetched brindlemoor.co.uk/careers/senior-pricing-analyst: the posting is live, and it contradicts the JD on location (RR1). Searched "Brindlemoor insurtech pet insurance": no results. No footprint for the company beyond its careers page was found, so the company rests on that one source |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary", which returned the Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved the market calibration band |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing": a profile snippet (linkedin.example/in/odile-varga) and a conference talk listing. Moved the scope read and positioning (RR4). Not fetched |

## Upgrade menu

- Your location and remote needs → R1 can close, and the decision likely moves to `go` or `no_go`.
- A non-motor analysis, or a short note on what changes for a pet book → R9 can move from `adjacent` to `direct`.
- Your base-salary floor → RR2 can be set against the band.
- A deeper pass on Brindlemoor (funding, leadership changes, candidate reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

I can also write the full assessment to `tuesday-dossier.md` for later use.

1. Location: are you based in the UK, and can you work four days a week in Leeds, or do you need fully remote? (R1, RR1)
2. Management: does this role line-manage analysts? You've never managed anyone, so this matters for the scope. (RR3)
3. Salary: what base-salary floor would you need? That lets me set it against the £52k–£65k interquartile band. (RR2)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.