**Decision: no_go as posted.** Two hard gates fail on the posting's own terms, and wording can't close either. Your fit is real, but it doesn't change this.

**Decision snapshot**
- **Hard gates (failed):**
  1. Pay: the posted base is $70–85k [grounded, from the JD]. Your floor is $150k. Even the top of the range is $65k short, so this fails outright.
  2. Location: the role is on-site in Austin five days a week, "no exceptions" [grounded]. You need remote-only from Portland. This fails outright.
- **Fit ledger (candidate-stated, unverified):** Paid acquisition, lifecycle/CRM, experimentation, team building, SQL/GA4/Braze, scaling ARR, and 9 years against the 8+ requirement all look strong on your account. Confidence is medium because it rests on your description, not on documents.
- **Gaps:** SEO/content, PR, brand, partnerships, and sales ops are in the scope but not in your stated experience. The posting names them as owned from day one.
- **What would change the decision:** a base of at least $150k and remote eligibility. Both would have to change; neither is an interpretation.

**Role reality**
- Scope: eight functions with "a team of one to start" [grounded]. That is an unusually wide remit for one person [inferred].
- Terms: "evenings and weekends when it matters is just who we are" [grounded]. This is an expectation of unpaid hours, stated as culture [inferred from the wording].
- Compensation: "meaningful equity" with no figure or vesting details [grounded]. Equity can't offset a base that fails your floor.
- Market calibration: not established. I have not checked role-family pay (that needs research, not memory).

**Why it feels off (opportunity ledger)**
- The base is far below your floor, yet the posting asks for 8+ years, a Series A scope, and a five-day in-office commitment. Those terms don't match each other [inferred].
- The posting combines "team of one," "no bench," "no exceptions," and "success metrics will evolve." Together these describe a role with unclear accountability and an unstable definition of success [inferred]. Treat this as a risk to test, not a conclusion.
- Unverified claims: "Series A" and "profitable since day one" are not checked. Failed attribution is not assessed, because research has not run.

**Evidence status**
Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Novaline's official site and careers page | skipped | Research not yet consented |
| 2 | Role-family sweep for Head of Growth pay and scope | skipped | Research not yet consented |
| 3 | Hiring manager's public footprint | n/a | No name given |

**Upgrade menu**
- Running L1 (up to 5 searches, 2 page fetches) would check: whether Novaline exists as described, whether the posting is live, and whether $70–85k is typical for this seniority.
- The live posting link or the recruiter's email domain would also settle the attribution question.

**Questions** (response modes: answer, skip, or say "run L1")
1. Where did this posting come from: a link, a recruiter, or a job board? If you have a link, I can read it without using research budget.
2. Have you already spoken with anyone at Novaline, and at what stage are you?
3. Should I run the L1 check on Novaline and the pay range? It won't change the decision, but it will tell you whether the company exists as described.

If you want, I can also write up a dossier (`tuesday-dossier.md`) with this analysis for later use.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.