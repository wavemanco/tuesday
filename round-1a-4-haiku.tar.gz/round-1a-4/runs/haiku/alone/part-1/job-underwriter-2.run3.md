**Not a waste of time, but a stretch on the must-have you named.** You have no titled PM years, so R1 is `adjacent`, not `direct`. Your seven years of product-adjacent client integration work is the case you can make. Decision: `conditional_go`.

**Fit ledger**

- `hard_gate`: none stated in the JD
- `must_have`: `direct` none · `adjacent`: R1 (3+ years product management experience), R2 (own the platform roadmap), R3 (discovery with integration partners), R4 (write specs, drive delivery with squads), R5 (shipped API or platform products)
- `important`: `direct`: R6 (technical fluency), R7 (stakeholder management) · `adjacent`: R9 (launch coordination) · `unclear`: R8 (adoption metrics), R10 (agile delivery)

R1 — no titled years, seven years of adjacent work; R2 — roadmap input, not ownership; R5 — client go-lives, not a product you owned; R8 — no adoption metric on the CV.

**Opportunity ledger.** Scope is clearly stated, with roadmap authority and metrics named (RR2, positive). The employer is unverified (RR1, medium) and the salary is withheld (RR3, unknown).

- **Hard gates:** none stated in the JD; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears: the posting is confirmed on Quartzline's own careers page; (2) your answers to the questions below show what you actually owned, and you present R2 and R5 as adjacent work; (3) you never present the years as PM years.
- **What would change this:** a titled-PM answer to Q1 moves R2 toward `direct`. A confirmed triage tool with adoption evidence moves R5 further. Failing to verify the posting caps the decision at `conditional_go`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` JD header, as you stated it |
| Mandate | Own the roadmap for the partner-facing API platform; discovery with partners; specs and delivery with two squads; adoption metrics; launch coordination | `[grounded]` JD |
| Scope read | A platform PM with two squads and named metrics is a defined, full scope | `[inferred]` from the JD's listed responsibilities |
| Market calibration | Not run. Search was refused this session, so no band exists | — |
| Unknowns | Salary, location, reporting line, contract type, which roadmap decisions the role makes alone | — |
| Contradictions | None found within the JD | `[grounded]` JD |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management | must_have | adjacent | medium | transferability | No titled PM years. About seven years of product-adjacent, client-facing work. The posting marks this a must-have, so it is graded, not a gate | `[grounded]` CV; `[inferred]` that implementation work is adjacent | Lead with the adjacent case and state the limit (Q1 ties in) |
| R2 | Own the platform roadmap | must_have | adjacent | medium | transferability | "Ran quarterly roadmap-input sessions" shows input to the roadmap, not sequencing or ownership of it | `[grounded]` CV | Q1 |
| R3 | Discovery with integration partners | must_have | adjacent | medium | transferability | Scoping workshops for each client integration. The purpose was one client's build, not platform-wide discovery | `[grounded]` CV; `[inferred]` adjacency | None beyond the proposed summary line (E2) |
| R4 | Specs and delivery with engineering squads | must_have | adjacent | medium | transferability | Wrote requirements documents; coordinated engineers on custom builds. No squad-level delivery on the CV | `[grounded]` CV | G3 |
| R5 | Shipped API or platform products | must_have | adjacent | medium | transferability | Client integrations taken to go-live on a vendor's REST API, which you did not own as a product. The triage tool is a `memory_lead`, not counted | `[grounded]` CV; memory lead unconfirmed | Q2 |
| R6 | Technical fluency: API docs, schemas | important | direct | medium | none | Postman, SQL, OpenAPI, integration architecture on the CV. Self-reported, no artifact | `[grounded]` CV | None |
| R7 | Stakeholder management: engineering, sales, customers | important | direct | medium | none | Coordinated vendor engineers, client engineers and PMs; customer workshops and UAT. Sales is not on the CV | `[grounded]` CV | None |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | Go-live counts only. No adoption measure on the CV, which does not mean none exists | `[grounded]` CV silence | Q3 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | UAT, go-live and the integration playbook. No sales or support launch coordination named | `[grounded]` CV; `[inferred]` adjacency | None |
| R10 | Agile delivery | important | unclear | low | discovery | CV silent on sprints, backlogs or squads | `[grounded]` CV silence | Upgrade menu: sprint artifacts |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | Roadmap ownership (R2, must_have) | transferability | Roadmap input on the CV, no decision you drove | Most likely objection to R2 | Evidence you chose what got built, or pushed a priority that was acted on | `[grounded]` CV |
| G2 | Adoption metrics (R8) | discovery | No adoption measure on the CV | Named in the JD as something the role defines and tracks | A measure you used on any integration or tool | `[grounded]` CV silence |
| G3 | Squad delivery (R4, R10) | transferability | Coordinated engineers on builds; no sprint work shown | Two squads are the operating model | Sprint artifacts, a backlog, or retro notes from any squad | `[grounded]` CV silence; `[generic]` that squad delivery is typically tested in interviews |
| G4 | Shipped product (R5) | transferability | Client go-lives on a vendor's API; the triage tool is unconfirmed | An internal tool with adoption would strengthen R5 | Confirmed build, the adoption figure, and whether it went past a prototype | `memory_lead`, unconfirmed |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Research could not run this session, so the employer and the posting's liveness are unchecked. This is a standing entry, not a finding about the employer | `[generic]` pattern for companies of this size, not a claim about this one | Is this posting live on your careers page, and who would I be interviewing with? | unresolved |
| RR2 | Authority and metrics stated | positive_signal | — | "Own the roadmap for our partner-facing API platform"; "define and track adoption metrics" | Authority over the roadmap and its metrics is explicit, and two squads are named | `[grounded]` JD | Which roadmap decisions does this role make alone, and which need the squads' leads or the executive team to sign off? | noted |
| RR3 | Salary not stated | unknown | — | No compensation line in the JD | The figure may be withheld or budgeted below your expectation; no market band was researched | `[inferred]` from the posting's silence | What is the budgeted base range for this role? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move your existing line "Ran quarterly roadmap-input sessions collecting client feedback for product." up into the summary, unchanged | see R2 | `[grounded]` CV, verbatim | resume_edits_pending_approval |
| E2 | Summary opener: "Seven years leading end-to-end REST API integrations for enterprise clients: scoping workshops, requirements documents, integration architecture, UAT, go-live." | Traces to "Led 30+ client integrations of the company's REST APIs end to end: scoping workshops, requirements documents, integration architecture, UAT, go-live." and "7 years as a solutions engineer." Audit: "our" becomes "the company's," nothing else changed | `[grounded]` CV | resume_edits_pending_approval |
| E3 | Positioning advice: say plainly that you have not held a PM title, then name the adjacent work. Do not describe the triage tool as shipped unless you confirm it | Prevents the years claim and R5 from drifting upward in the interview | `[grounded]` CV and the memory lead's unconfirmed status | pending your approval |
| A1 | Before applying, confirm the posting on Quartzline's own careers page | see RR1 | `[generic]` standing entry | pending your approval |

Reframing audit: no line above describes product ownership, the triage tool, or PM years. Every clause in E2 traces to a sentence you wrote.

**Evidence status**

Verified: none yet. Every claim is CV self-report. Unverified lead: the request-triage tool, from a prior conversation, not counted.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused this session. Would have checked RR1 and whether the posting is live |
| 2. Role-family sweep | unavailable | Refused. Would have set the market band for R1 and the salary check for RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

**Upgrade menu**

- A quarterly roadmap-input summary or a PRD you wrote → R2 moves from `adjacent` toward `direct`, with an artifact behind it.
- Adoption figures for an integration or the triage tool → R8 and R5 strengthen.
- Sprint artifacts or retro notes from any squad → R10 and R4 resolve.
- Your salary floor → RR3 can be checked against a market band.
- The live posting link, and Quartzline's careers page → RR1 can clear. A later session with search permitted would run targets 1 and 2.

If you want it, I can save this assessment as `tuesday-dossier.md` at the end of the engagement.

1. Q1 (R2, R1): Have you ever decided what got built next, or set a priority that the engineers acted on? If so, name the product, the call you made and what happened.
2. Q2 (R5): Did you build the request-triage tool that support agents adopted? What did it do, who used it, did it go beyond a prototype, and is there a usage figure or a copy I can see?
3. Q3 (R8): For the client integrations you led, how did you know one was being used: go-live sign-off, API call volume, or something else?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.