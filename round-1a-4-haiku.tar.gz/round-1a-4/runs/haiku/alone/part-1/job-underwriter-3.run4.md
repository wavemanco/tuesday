**Decision: no_go on the terms as posted.** Two hard gates fail on the posting's own text, and neither can be solved by wording.

**Decision snapshot**

- **Hard gates (failed):**
  - **Pay:** the posted base is $70–85k [grounded, JD]. Your floor is $150k. The gap is at least $65k even at the top of the range. Equity is not base, so it can't close the gap.
  - **Location:** "On-site in our Austin office 5 days a week — no exceptions" [grounded, JD]. You are remote-only.
- **Fit (for the role, not the employer):** Partial. Strong on paid, lifecycle, experimentation, and your 9 years against the "8+ years" requirement. Weaker on sales ops, PR, partnerships, and brand, which your record doesn't show. Your team-building (3–7 people) doesn't carry over to "a team of one to start," though it's transferable. Your $8M→$40M ARR scale-up was B2C subscription, not e-commerce enablement.
- **Confidence:** the hard-gate failures are high confidence because they come from the posting itself.

**Role reality**

- Scope is broad: paid, SEO/content, lifecycle, brand, PR, partnerships, and sales ops, all owned alone. That is a multi-function job being paid like a mid-level one [inferred from the stated comp].
- "Evenings and weekends when it matters is just who we are" [grounded, JD] is a culture signal worth weighing. `red_flag`? No, `risk_signal`, severity medium [inferred].
- "Success metrics will evolve as we learn" and "must thrive on ambiguity" [grounded, JD] suggest undefined goals. This is an opportunity risk, not a hard gate.
- Whether $70–85k is low for this seniority is a market claim. I have not checked it, so it is `[generic]` at best. Your floor is your own constraint, so the mismatch stands regardless.

**Evidence map (summary)**

| Requirement | Fit | Confidence |
|---|---|---|
| 8+ years growth leadership | Met (9 years) | High, stated |
| Paid acquisition, lifecycle, experimentation | Strong | Medium, CV-stated only |
| SEO/content | Partial | Low |
| Brand, PR, partnerships, sales ops | Gap | Not evidenced |
| Team of one, no bench | Gap in your record | Medium |
| E-commerce enablement domain | Transferable, not direct | Medium |
| SQL, GA4, Braze | Strong | Medium, stated |

**Opportunity risk register**

- **Hard gate: pay** — high, confirmed against your floor.
- **Hard gate: on-site 5 days, "no exceptions"** — high, confirmed.
- **Evenings/weekends culture** — medium, inferred.
- **Undefined success metrics** — medium, inferred.
- **Company existence and posting currency not checked** — medium. I didn't run research, so I can't confirm Novaline exists as described or that the posting is live.

**Application plan:** none recommended. Reconsider only if both gates change: base at or above $150k and remote. "No exceptions" makes the location change unlikely. Don't spend effort tailoring a CV for this role.

**Research tier:** L0 — no searches. I worked only from the posting and your message.

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | No consent to research yet; the hard gates decide the result without it |
| 2. Role-family sweep (comp and scope) | skipped | Same reason; the comp band would be `[generic]` in any case |
| 3. Hiring manager footprint | n/a | No hiring manager named |

**Dossier offer:** If you want, I can save this assessment as `tuesday-dossier.md` for later use with mock-interview.

**Upgrade menu:**
- Live posting link, or the recruiter's email domain: would let me check that Novaline exists and the posting is current.
- Research at L1 (up to 5 searches and 2 page fetches): verifies the company and gives a market comp band for this seniority, labeled `[generic]`.
- Your CV or any work samples: would move the paid, lifecycle, and SQL rows from stated to verified.

**Questions:**
1. Do you want me to run L1 research (up to 5 searches and 2 page fetches) to verify Novaline and the comp band before you decide?
2. Do you have a link to the live posting, or do you know whether it came through a recruiter or the company's own site?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.