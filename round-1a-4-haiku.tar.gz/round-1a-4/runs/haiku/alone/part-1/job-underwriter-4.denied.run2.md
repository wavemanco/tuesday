**Yes, apply, with three things to check first. Status: `conditional_go`.** Your must-haves are well evidenced by your motor work. The gaps are pet-insurance specifics and three things the posting doesn't say. I could not check the employer, because web search was denied in this session.

**Fit ledger.**

- `hard_gate` — unclear: R1 (UK-based, for a UK-remote role)
- `must_have` — direct: R2, R3, R4, R5 · adjacent: R6
- `important` — direct: R7 · adjacent: R8, R10
- `preferred` — direct: R9

R2 through R5 rest on your own account, so they're `medium` until something inspectable backs them. R6 is `adjacent`: the method carries over from motor to pet, but pet rating is unexercised.

**Opportunity ledger.** The role is sound on its own terms, with no severe red flags found. The posting leaves the people-management scope, decision rights and pet data depth unstated (RR1–RR3), and gives no pay (RR4). The employer is unverified (RR5, standing entry).

- **Hard gates:** none failed; unconfirmed: R1 (UK-based, for a UK-remote role); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live and the employer checks out on Brindlemoor's own careers page (RR5); (2) RR1 confirms an individual-contributor role; (3) the pet gap is framed as transferable motor method, never as pet experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` your message; not verified |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Seniority | "Senior Pricing Analyst"; no reports or team mentioned | `[grounded]` JD title; `[inferred]` IC from silence |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message; footprint not checked |
| Market calibration | Not run; no pay or scope band | — |
| Unknowns | People responsibility; decision rights; pet claims depth; pay; contract type | — |
| Contradictions | None visible in the text you gave | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Based in the UK for a fully remote UK role | hard_gate | unclear | low | hard_gate | Your UK motor employment suggests it, but you haven't stated your location | `[grounded]` JD; `[inferred]` from employer | Confirm (Q3) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years, last 2 as senior analyst. The 4+ is experience length, so it's not a gate | `[grounded]` your account | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, no artifact yet | `[grounded]` your account | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM (motor) | `[grounded]` your account | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your account | none |
| R6 | Build and monitor rating models for the pet product | must_have | adjacent | medium | transferability | Same GLM method; pet risk drivers and claims behaviour not exercised | `[inferred]` from R4 | G1 |
| R7 | Design and read price tests | important | direct | medium | none | 14 tests run with underwriting last year | `[grounded]` your account | none |
| R8 | Pet-insurance pricing knowledge (implied by "our pet-insurance product") | important | adjacent | none | transferability | No pet evidence; motor pricing is the bridge | `[inferred]` from the JD's product line | G1 |
| R9 | Insurance experience | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your account | none |
| R10 | Turn results into recommendations for product, not only underwriting | important | adjacent | medium | transferability | Underwriting recommendations are evidenced; product-side decisions are not | `[grounded]` JD; `[inferred]` from your account | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Pet pricing (R6, R8) | transferability | Motor GLM and price-test work; no pet product | R6 is a must-have at `adjacent`; a stated limit plus a strengthener is the honest bridge | A sanitised note on any rating work where the risk drivers or claims pattern differed from the motor book, with what you did | `[inferred]` bridge from your motor work |
| G2 | Product recommendations (R10) | transferability | Recommendations to underwriting; none that changed product terms | Second half of the role's output | One example of a product or pricing-structure recommendation and its outcome | `[grounded]` JD; `[inferred]` from your account |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Reporting line and people scope unstated | unknown | — | "Senior Pricing Analyst" | This is an IC role. If it includes leading analysts, your lack of management experience becomes a gap | `[inferred]` from title and silence | Is this an individual-contributor role, or does it include leading or line-managing analysts? | unresolved |
| RR2 | Recommend-only or decide-too | risk_signal | low | "turn the results into recommendations" | The role may recommend price changes without owning the decision | `[inferred]` from the verb choice | Which pricing decisions does this role make itself, and which go to underwriting or product leadership? | unresolved |
| RR3 | Pet data depth | unknown | — | "our pet-insurance product" | A young pet book may have too little claims history to fit GLMs reliably | `[generic]` pattern for new pet books, not a claim about Brindlemoor | How many years of pet policy and claims history are available to fit rating models on? | unresolved |
| RR4 | Pay not stated | unknown | — | (no pay in the JD) | Pay may sit below your expectation, or may simply be unpublished | `[grounded]` posting silent | What is the base salary range for this role? | unresolved |
| RR5 | Employer not established | risk_signal | medium | "Brindlemoor (insurtech)" | Employer unverified because search was denied. Possibilities: too new or small for a footprint, a stale posting, or not a real hiring employer | `[generic]` pattern for companies of this size | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Clear, testable scope | positive_signal | — | "design and read price tests" | Your 14-test record maps directly to a stated deliverable | `[grounded]` JD and your account | Which price tests are running now, and what did the last one change? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the application with the GLM build and the 14 price tests, in the role's terms, and say plainly that the work was motor. Don't claim pet work | R4, R7, R6 | `[grounded]` your account | pending your approval |
| E2 | Check the live posting on Brindlemoor's careers page before any effort | RR5 | `[generic]` pattern | pending your approval |
| A1 | Ask RR1–RR4 verbatim before committing to a loop | Interview preparation | `[grounded]` register | pending your approval |
| A2 | Write up a sanitised note on a non-motor rating case for G1 | R6 | `[inferred]` from G1 | pending your approval |

No new facts are proposed for your CV. Every line in E1 restates something you've already said.

## Evidence status

Verified: none yet. Your background is self-reported in this message, so each row carries the confidence its specificity earns.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search was denied, so Brindlemoor's careers page and the live posting were not checked. Would have moved RR5 |
| 2. Role-family sweep | unavailable | Search was denied, so there is no pay or scope band. Would have moved RR4 and the market calibration |
| 3. Hiring manager's public footprint | unavailable | Name given (Odile Varga); search was denied. Would have moved the scope read and positioning |

Web search was refused twice in this session. Those refused calls are counted above.

Dossier offer: I can write this up as a `tuesday-dossier.md` you can keep and share.

## Upgrade menu

- Allowing web search would let me run the three L1 targets: the employer check, a pay and scope band, and Odile Varga's public footprint.
- The live posting link or the careers-page URL would settle RR5 directly.
- A sanitised pet-related or non-motor rating note would move R6 and G1.
- The budgeted salary would close RR4.
- A deeper research pass on Brindlemoor (funding, leadership changes, candidate reports; up to 5 more searches and 2 more fetches) is available once, if you want it.

1. **RR1:** Is this an individual-contributor role, or does it include leading or line-managing analysts?
2. **RR5:** Where did you see the posting: Brindlemoor's careers page, a job board, or a message from someone? If it was a message, which email domain did it come from?
3. **R1 and constraints:** Are you UK-based, and do you have a pay floor, contract-type requirement or other hard constraint I should treat as a gate?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.