**Worth pursuing, but hold for one answer: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Location and working pattern)
- `must_have`: direct: R2, R3, R4, R6
- `important`: direct: R5, R7; adjacent: R8 (Pet-insurance product knowledge)
- `preferred`: direct: R9 (Insurance experience)

R8 (pet insurance) is the one real capability gap, and motor pricing carries over to it. R1 is unresolved because the posting contradicts itself on location.

**Opportunity ledger.** The role is live and clearly scoped to one product and one reporting line, with a named hiring manager who has published on the same work (RR5, RR3). Two things are unresolved: the location conflict (RR1, severity medium) and the salary, which neither source states (RR2).

- **Hard gates:** none failed (R1 is `unclear`, not failed); unconfirmed: R1 (Location and working pattern); candidate constraints not given. Checks against your own location and office constraints are unknown.
- **Severe red flags:** none found.
- **What would change this:** the awaited answers are (1) whether the role is fully remote or Leeds four days a week (R1, RR1); (2) whether that pattern works for you (R1); (3) the salary (RR2). If four days in Leeds is required and you can't do it, this becomes `no_go` with R1 as the reason.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; its careers page is live and carries this posting | `[grounded]` careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product: rating models, price tests, recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page |
| Working pattern | Contradiction: JD says "Fully remote (UK)"; careers page says "Leeds office four days a week" | `[grounded]` both sources |
| Scope read | Single product, single reporting line, analyst-to-recommendation remit: a normal senior scope | `[inferred]` from the responsibilities list |
| Market calibration | UK senior pricing analyst, insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900 (2026 pay survey, n=612). This is a pattern, not this employer's offer | `[generic]` Pricewell 2026 survey |
| Unknowns | Base salary (RR2); whether the role owns rate decisions or only recommends them (RR4); whether it carries direct reports, and team size | — |
| Contradictions | Location, as above | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location and working pattern | hard_gate | unclear | none | hard_gate | JD and careers page disagree; your own constraint is not given, so there is nothing to check the role against | `[grounded]` both sources | Ask you your constraint (Q1); ask the employer which pattern is current (RR1) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics at a UK motor insurer, two as senior analyst. Stated in prose, not yet inspected, so medium | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Used daily; no artifact yet | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model for the young-driver book | `[grounded]` your background | none |
| R5 | Design and read price tests | important | direct | medium | none | Ran 14 price tests last year with underwriting. Listed in the duties, not the requirements | `[grounded]` your background | none |
| R6 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R7 | Build and monitor rating models | important | direct | medium | none | Built and maintained the young-driver model; monitoring is the part to show evidence for | `[grounded]` your background | Q2 would show monitoring practice |
| R8 | Pet-insurance product knowledge | important | adjacent | medium | transferability | Motor pricing method carries over. Pet claims, pet rating factors and cover design were not exercised | `[inferred]` from your background against the mandate | See gap G1 |
| R9 | Insurance experience | preferred | direct | medium | none | Motor insurer, UK | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R8, important) | transferability | Motor pricing only. Nothing on pet claims, pet rating factors, or cover design | The mandate is one pet product, so this is the objection most likely to come up | Any non-motor pricing or claims work; any frequency and severity analysis by cover feature; any rating factor you tuned for a product other than motor | An anonymised GLM write-up or price-test readout, even on motor data | `[inferred]` bridge from the motor work; `[generic]` that a pet-product employer will probe this line |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location conflict between JD and careers page | risk_signal | medium | "Fully remote (UK)" vs "Leeds office four days a week" | Either the posting is out of date or in-office attendance is expected in practice. Not a red flag by itself | `[inferred]` from the two sources | "The posting says fully remote; the careers page says Leeds four days a week. Which is current, and what in-office time does this role need?" | unresolved |
| RR2 | Base salary not stated | unknown | — | Neither the JD nor the careers page gives a figure | The figure may sit below the market band in role reality, or may simply not be published | `[inferred]` from the withheld figure, against `[generic]` band | "What is the base salary range for this post?" | unresolved |
| RR3 | Decision rights not stated | unknown | — | "Turn results into recommendations for underwriting and product" | The role may recommend rate and test changes while underwriting or a committee decides | `[inferred]` from "recommendations" against silence on authority | "For the rate changes and price tests this role runs, which decisions are its alone, and which go to underwriting?" | unresolved |
| RR4 | Team size and direct reports not stated | unknown | — | "Reports to the Director of Pricing" | You have not managed people, and the JD does not say whether this role does | `[grounded]` JD silence on reports | "Does this role line-manage anyone, and how large is the pricing team?" | unresolved |
| RR5 | Hiring manager has published on monitoring rating models | positive_signal | — | Talk title: "Small Books, Loud Errors" (2025 Insurance Pricing Forum), on monitoring rating models in small books | The Director of Pricing cares about monitoring, which is a stated part of the role | `[grounded]` public profile snippet | "What does model monitoring look like on this book today: which checks run, and how often?" | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter, in writing, which location pattern is current before investing in the application | see RR1, R1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with GLM build and maintenance, the 14 price tests, and the quarterly review to underwriting; map each to R4, R5, R6 | Those are your strongest direct matches | `[grounded]` rows R4, R5, R6 | pending your approval |
| A3 | Name the pet gap yourself, with the bridge: motor pricing method, applied to pet. Do not claim pet experience | see R8, G1 | `[inferred]` from R8 | pending your approval |
| A4 | Prepare one example of how you monitored the young-driver model, to answer RR5 | The hiring manager's public theme | `[grounded]` RR5 | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on what you have told me, which is CV-equivalent until you confirm specifics.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searches: "Brindlemoor careers Senior Pricing Analyst" (found the careers page); "Brindlemoor insurtech pet insurance" (no results). Fetched brindlemoor.co.uk/careers/senior-pricing-analyst. Confirms the posting is live and surfaces the location conflict (RR1) |
| 2. Role-family sweep | yes | Search: "senior pricing analyst UK pet insurance salary GLM". Result: Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (pricewell.example/2026-uk-pricing-analytics-pay-survey). Market calibration, `[generic]` |
| 3. Hiring manager's public footprint | yes | Search: "Odile Varga Director of Pricing". Result: public profile snippet (linkedin.example/in/odile-varga), not fetched. Informs RR5 and A4 |

## Upgrade menu

- A written location answer from the employer → R1 and RR1 close; the decision moves to `go` or `no_go`.
- Your own location and in-office constraint, stated → R1 can be checked.
- A budgeted salary → RR2 closes, set against the band in role reality.
- An anonymised GLM or price-test write-up → R4 and R5 move from `medium` to `high`.
- Any non-motor pricing or claims work → G1 narrows.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

I can also write this up as a `tuesday-dossier.md` if you want to keep it.

Two questions, both for you:

- **R1:** Can you work in Leeds four days a week, or is fully remote a firm requirement for you?
- **R8 / G1:** Have you worked with any non-motor pricing or claims data, such as another product or a non-motor frequency and severity analysis?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.