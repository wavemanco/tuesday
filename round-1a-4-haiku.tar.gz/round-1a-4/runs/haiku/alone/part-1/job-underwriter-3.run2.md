## Decision snapshot

**No, not as posted: R1 and R2, both hard gates, fail · `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1, R2
- `must_have` — direct: R3, R4, R5 · unclear: R6 (SEO and content), R7 (brand and PR), R8 (partnerships and sales ops)

R3, R4 and R5 are direct at `medium` confidence, since they rest on your own account. R6 to R8 have no evidence in what you gave me, so they are unknowns, not confirmed gaps.

**Opportunity ledger.** The posting's own terms carry four risk signals: always-on hours (RR1), seven functions with no bench (RR2), no defined success target (RR3), and a base that sits well below what this scope usually pays (RR4, market band unchecked). The one positive is the stated authority and reporting line (RR5). The company's funding and profitability claims are unchecked (RR6).

- **Hard gates:** failed: R1 (base pay floor) `hard_gate_fail`, R2 (remote from Portland) `hard_gate_fail`; met: none.
- **Severe red flags:** none found.
- **What would change this:** both gates would have to differ. The posted base would need to reach $150k, and the role would need to be remote-eligible from Portland. The posting says "no exceptions" on location, so that second change is unlikely. Only Novaline's own answer can move either gate.

Your sense that something is off is accurate. The two terms you can't accept are stated plainly in the posting, and the always-on and ambiguity wording comes on top of them.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting's own claim, unchecked |
| Mandate | All revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team | "A team of one to start" | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin, 5 days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` posting |
| Pay | $70–85k base plus equity, equity size not stated | `[grounded]` posting |
| Scope read | Seven functions in one head is broad for the title, and the posting names no budget or headcount for them | `[inferred]` from the scope list against "team of one" |
| Market calibration | Not run. Web search was refused in this session, so I have no sourced band and I won't give one from memory | — |
| Unknowns | Equity size, funding and profitability, success metrics, budget for the seven functions | — |
| Contradictions | None inside the posting. The scope-against-team tension is carried as RR2, not as a contradiction | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay of at least $150k (your floor) | hard_gate | hard_gate_fail | high | hard_gate | Posted base is $70–85k, and the top of the range is $65k under your floor | `[grounded]` posting's pay range and your stated floor | None. Only the employer changing the range would alter this |
| R2 | Remote-eligible from Portland, no relocation | hard_gate | hard_gate_fail | high | hard_gate | Posting requires on-site Austin, 5 days a week, "no exceptions" | `[grounded]` posting and your stated constraint | None. The posting closes this in its own words |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then Head of Growth at two B2C subscription companies | `[grounded]` your account, no artifact yet | None |
| R4 | Paid acquisition | must_have | direct | medium | none | Owned paid at both companies; controlled the budget at one | `[grounded]` your account | None |
| R5 | Lifecycle and CRM | must_have | direct | medium | none | Owned lifecycle; deep in Braze | `[grounded]` your account | None |
| R6 | SEO and content | must_have | unclear | low | discovery | Not in the inputs you gave me | `[grounded]` absence from your inputs | None now |
| R7 | Brand and PR | must_have | unclear | low | discovery | Not in the inputs you gave me | `[grounded]` absence from your inputs | None now |
| R8 | Partnerships and sales ops | must_have | unclear | low | discovery | Not in the inputs you gave me | `[grounded]` absence from your inputs | None now |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content, brand and PR, partnerships and sales ops (R6, R7, R8) | discovery | None of the three areas appears in what you gave me | They are must-haves under "own all revenue growth", but they cannot change the decision while R1 and R2 fail | Any SEO, content, PR or partner-led growth you drove, even as a contributor | A content calendar, a partner deal, a PR result, a sales-ops process doc | `[grounded]` absence in your inputs; `[inferred]` that the posting makes these must-haves |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Always-on expectation | risk_signal | medium | "Evenings and weekends when it matters is just who we are." | Evening and weekend work may be standing practice, not occasional | `[generic]` always-on pattern in startup postings; the quote itself is `[grounded]` | "What does a normal week look like here, and how often is evening or weekend work actually expected?" | unresolved |
| RR2 | Seven functions with no bench | risk_signal | medium | "You will be a team of one to start — we believe in players who don't need a bench." | Accountable for seven functions with no budget or headcount in sight | `[inferred]` from the scope list against "team of one" | "Which of these functions get budget or headcount in the first year, and in what order?" | unresolved |
| RR3 | Success metrics undefined | risk_signal | medium | "Must thrive on ambiguity; success metrics will evolve as we learn." | Accountable for revenue growth with no agreed target yet | `[inferred]` from the wording | "What revenue target will this role be measured against in year one, and who sets it?" | unresolved |
| RR4 | Base below the seniority band | risk_signal | medium | "$70–85k base plus meaningful equity upside" | The base may sit well below what a revenue-owning Head-level hire usually earns | `[generic]` role-family pattern; the market sweep did not run | "How was the base range set, and how does it compare with your other Head-level hires?" | unresolved |
| RR5 | Stated authority and reporting | positive_signal | — | "Report to the CEO with a dotted line to the board." | Decision rights and visibility are stated, not implied | `[grounded]` posting | "Which decisions does this role make without sign-off?" | noted |
| RR6 | Company claims unchecked | unknown | — | "Series A, profitable since day one" | Funding and profitability are the employer's own claims and are unverified | `[grounded]` posting wording; not checked | "Can you share the latest funding round and profitability position?" | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply to the posting as written | R1 and R2 fail on terms the posting states | `[grounded]` R1, R2 | proposed |
| A2 | If you want to test it, send one written question through Novaline's own careers page: can the base reach $150k, and is remote from Portland possible? | The employer's answer is the only thing that could move either gate. Expect a no on location | `[grounded]` the "no exceptions" wording; `[inferred]` that a no is likely | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would have checked that Novaline exists as described and that the posting is live. Web search was not granted in this session: three searches were refused |
| 2. Role-family sweep | unavailable | Would have set the base band for this title and scope against the posting's $70–85k, and fed RR4. Same refusal |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Because research did not run, the standing employer-not-established entry is not triggered. This is an unchecked claim, not a finding that the employer is unattributable.

Dossier offer: I can write this up as a `tuesday-dossier.md` file you can keep.

## Upgrade menu

- A link to the posting on Novaline's own careers page → confirms the role exists as described, which clears or confirms the employer check and RR6.
- Web search permission for this session → a sourced market band for RR4, and a check on Novaline's funding and profitability. It will not change the decision, since R1 and R2 are gates.
- Any recruiter message about this role → the only route that could show whether pay or location actually flex, which is the one thing that could change R1 or R2.
- Deeper diligence on Novaline (leadership churn, reviews, past hiring): up to 5 more searches and 2 more fetches. Offered once; it runs on your word, and only once search permission is granted.
- Evidence for SEO/content, brand and PR, or partnerships and sales ops → moves R6 to R8 off unclear. It does not change the decision.

I have no questions for you. The decision is settled by the two gates, so nothing you could add would move it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.