**Decision: conditional go.** The role is worth applying for, but the forecast-ownership requirement is a real gap, and the employer isn't verified yet. Two checks before you apply would settle most of the open questions.

**Decision snapshot**

- **Candidate fit (per requirement, not a score):** Strong on tooling and core ops. Partial on company type, SQL/modelling depth and finance-facing work. Missing on forecast ownership and billing data.
- **Opportunity quality:** The posting is specific and shows no red flags. Scope is larger than the title suggests (CRM and billing data ownership, plus a quarterly forecast run with the CFO).
- **Hard gates:** Bristol, two days a week in office. Your location and right-to-work status are not in the material you gave me, so this gate is unverified.
- **Research tier:** L0, no searches. I read the posting you linked; I did not check the company's own site, pay benchmarks or the hiring manager.

**Role reality** [grounded from the posting]

- Revenue Operations Lead at Quillfield, Bristol, hybrid (two days a week in office).
- £61,500–£67,000 plus share options.
- Owns CRM and billing data, builds pipeline and renewal reporting for sales and finance, and runs the quarterly revenue forecast with the CFO.
- Market calibration: not established. I have no pay or role-family benchmark at L0.
- Scope read [inferred]: this is a company-wide, finance-facing role. Your current remit is one regional team's operations. The forecast and billing items are a step up in ownership, not just a new skill.

**Evidence map**

| # | Priority | Requirement | Fit | Evidence | Confidence | Gap |
|---|---|---|---|---|---|---|
| 1 | Must | 4+ yrs RevOps / sales ops / analytics at a B2B software company | Partial | 5 yrs sales ops, last 2 running RevOps, at a B2B payments company | Medium | Company type is close, not identical. Years met. |
| 2 | Must | HubSpot or Salesforce administration | Met | Salesforce admin certified; rebuilt pipeline and renewal dashboards | Medium (high once the certificate is in hand) | None |
| 3 | Must | Strong SQL and spreadsheet modelling | Partial | SQL weekly, Excel daily | Medium | Daily Excel use is not the same as financial modelling. Confirm the depth. |
| 4 | Must | Experience owning a forecast | Not met | Ran the monthly pipeline review; finance owned the company forecast | High that it is absent | Capability gap, partly transferable. The pipeline review is the nearest adjacent work. |
| 5 | Must | Experience working with finance on billing or revenue data | Not met | No billing data work; finance contact unknown | High that billing is absent | Discovery gap: any finance-facing revenue reconciliation may count. |

**Gap recovery queue**

- **G1 (forecast, row 4):** Did you contribute to the company forecast in any way, such as deal-stage or commit calls, forecast-versus-actual tracking, or inputs to finance, even if finance owned the output? If yes, that is the bridge. If no, do not claim it.
- **G2 (billing, row 5):** Any exposure to revenue or billing data: reconciliation with finance, invoice or renewal exports, or revenue reporting you signed off?

**Opportunity risk register**

- **Unverified employer (medium, standing):** I have not confirmed that Quillfield exists as described. The posting is on a job board, and the recruiter's email domain and the company's careers page are unchecked. Causes to rule out: a small or new company, a stale posting, or a non-hiring listing. Resolve by checking Quillfield's own careers page and the recruiter's email domain.
- **Pay not calibrated (low):** The posted range is grounded, but I cannot say whether it is market-normal for this scope at L0.
- **Scope step-up (low, inferred):** Billing data and the CFO-facing forecast are above your current level. Ask what the first-year ownership looks like.

**Application plan**

- **Lead with:** Salesforce certification, pipeline and renewal dashboards, SQL weekly use, and the monthly pipeline review with the sales director.
- **Bridge:** Describe the pipeline review as forecast-adjacent only if G1 confirms you fed forecast inputs.
- **Do not claim:** Forecast ownership, or billing data experience.
- **Proposed CV language (pending your approval, not for sending):** "Ran monthly pipeline review with the sales director" is accurate. "Owned forecasting" and "managed billing data" are not, so leave them out.

**Evidence status**

Research tier: L0 — no searches; user links read 1

| Target | Status | Reason |
|---|---|---|
| L1-1: company site and careers page | skipped | Not run at L0 |
| L1-2: role-family pay and scope sweep | skipped | Not run at L0 |
| L1-3: hiring manager's public footprint | skipped | Not run at L0; name given by recruiter only |

**Dossier offer:** At the end of this engagement, I can save everything above as a `tuesday-dossier.md` for later use with mock-interview.

**Upgrade menu**

- **L1 research (up to 5 searches, 2 fetches):** Verify the employer and careers page, benchmark the £61.5–67k band for this scope, and check Tamsin Achebe's public professional background (roles and published work only).
- **Salesforce certificate:** Upgrades row 2 from medium to high.
- **Sanitised dashboard example:** Strengthens row 2 and the positioning. Share only what your employer permits.

**Questions**

1. On the forecast: did you contribute any inputs, such as commit calls, forecast-versus-actual tracking or figures to finance, even if finance owned the number? (G1)
2. On billing: do you have any exposure to revenue or billing data, such as reconciliations with finance, renewal billing exports or revenue reporting?
3. Can you work in Bristol two days a week, and is £61.5–67k plus options within your range?

Response modes: answer each question, say "skip", or tell me to run L1 research.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.