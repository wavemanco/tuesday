**Decision: `conditional_go`.** You're a strong fit on the core analytics requirements. The real gaps are healthcare data and clinician work, and neither is a hard gate. Research didn't run, so the employer is unverified, and that alone caps the decision at `conditional_go`.

**Fit ledger.**
- `hard_gate`: none stated in the JD
- `must_have`: direct: R1, R2, R3, R4, R5; unclear: R6
- `important`: adjacent: R7, R8; unclear: R10; absent: R9
- `preferred`: adjacent: R11 (HIPAA, healthcare data)

R1–R5 are your core, all `direct`. R6 (metrics layer ownership) is the open must-have, R9 (clinicians) is the clearest absence, and R11 is a bridge with its limit named.

**Opportunity ledger.** Thin but no severe red flags in what you pasted. The employer is not yet established (RR1, standing entry), no pay is stated (RR3), and the care-navigation domain may carry clinical-data ownership you haven't touched (RR2).

- **Hard gates:** none stated in the JD; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) confirm the role is live on Harborlight's own careers page (RR1); (2) confirm the basis of the 11% lift before quoting it (R3); (3) decide whether you can accept a healthcare and clinician learning curve (R9, R11).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD header and your input; not yet verified |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker self-serve, PM and clinician partnership, mentor two juniors | `[grounded]` JD |
| Scope read | A senior IC-plus-mentor role: standard for the title, with a clinical product domain | `[inferred]` from the listed duties against the title |
| Market calibration | Not run — no salary or scope sweep completed | — |
| Compensation | Not stated in the JD as pasted | `[grounded]` JD |
| Unknowns | Pay, location and contract basis, clinical data ownership, how many metrics this role owns | — |
| Contradictions | None found in what was provided; no careers-page check ran | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years stated at a subscription company; no artifact yet | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake for six years; "expert" is the claim to show | `[grounded]` your background | sample query if asked |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and an 11% retention lift; the lift's basis (relative or points, window, method) is unconfirmed, so expect a probe | `[grounded]` your background, caveat visible | Q1 below |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the instance from scratch, 40+ governed dashboards | `[grounded]` your background | dashboard screenshot would raise to high |
| R5 | Written communication to non-technical stakeholders | must_have | direct | medium | none | Monthly exec memo; monthly VP Product presentations | `[grounded]` your background | a sanitized memo would raise to high |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | Governed dashboards suggest metric definitions, but you haven't said you owned them | `[inferred]` from "governed dashboards" | ask whether you owned metric definitions (see the discovery question on R6) |
| R7 | Self-serve dashboards | important | adjacent | medium | transferability | Built Looker dashboards; self-serve enablement not stated | `[grounded]` background, `[inferred]` link | none |
| R8 | Partner with PMs to drive roadmap decisions | important | adjacent | medium | transferability | Present to VP Product monthly; PM partnership not described | `[inferred]` from the VP Product presentations | none |
| R9 | Partner with clinicians | important | absent | none | capability | No clinical stakeholders in your background | `[grounded]` absence | G1 |
| R10 | Mentor two junior analysts | important | unclear | low | discovery | Not stated either way | `[grounded]` silence | Q3 below |
| R11 | Healthcare data, HIPAA | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model; no PHI or HIPAA work | `[inferred]` adjacency from privacy work | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Clinician partnership (R9, important) | capability | No clinical stakeholders in your background | Care navigation depends on clinical input | Any work with ops, legal or compliance stakeholders whose requirements shaped your analysis | A sanitized example of a shaped analysis | `[generic]` that clinical partnership is the likeliest objection |
| G2 | HIPAA and healthcare data (R11, preferred) | transferability | Consumer privacy work, no PHI | Named as a plus, not a gate | Consent-state modeling, PII governance, data-access controls | A short write-up of the consent model | `[inferred]` bridge from the privacy work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources (standing entry) | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Clinical product domain | unknown | — | "care-navigation app" | Clinical outcome data may sit with clinical teams, limiting what this role's metrics can reach | `[inferred]` from the product description | Which outcome metrics does this role own, and which clinical data do they depend on? | unresolved |
| RR3 | Compensation not stated | unknown | — | (no pay line in the JD as pasted) | Pay may sit below or above the role-family band; the band wasn't checked | `[grounded]` absence in the JD | What is the base salary range for this role? | unresolved |

**Severe red flags:** none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Confirm the role is live on Harborlight's careers page before investing in an application | see RR1 | `[generic]` pattern | pending your approval |
| E2 | Confirm whether the 11% lift is relative or percentage points, the window, and the method before quoting it | see R3 | `[grounded]` your background | pending your approval |
| E3 | Prepare one inspectable artifact: a sanitized memo, an experiment readout, or a dashboard screenshot | raises R3–R5 from medium toward high | `[grounded]` gap queue | pending your approval |
| E4 | Describe the privacy work as consumer PII and consent-model work, never as healthcare experience | see R11; claims must stay inside what you've done | `[grounded]` your background | pending your approval |
| E5 | Claim metric-definition ownership (R6) only if you can show it | see R6 | `[inferred]` | pending your approval |

Nothing above goes into a CV or outreach text until you approve it.

## Evidence status

**Verified:** none yet. Everything above rests on what you told me and the JD as pasted.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched for Harborlight's company profile and careers posting; every call was refused because web search permission was not granted. Would have moved RR1 (employer attribution, whether the posting is live) |
| 2. Role-family sweep | unavailable | Searched for senior product analyst pay in digital health; refused for the same reason. Would have moved the market calibration line and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Target 1 and 2 would close the employer check and the pay check, so the decision would likely move once they run.

Dossier offer: I can write this assessment to a `tuesday-dossier.md` so you can carry it into later sessions. Say so if you want it.

## Upgrade menu

- A sanitized memo, experiment readout or dashboard screenshot → R3, R4 and R5 to `high`.
- The live careers-page link or the recruiter's email domain → RR1 closes.
- Web search permission granted → L1 runs (up to 5 searches and 2 fetches, 3 already spent on refused calls), covering the employer and the pay band.
- A mentoring example → R10 resolves.
- Your hard constraints (location or remote, work authorization, pay floor, permanent or contract) → the hard-gate checks run.

## Questions

1. (R3) Was the 11% retention lift relative or percentage points, over what window, and how did you test significance?
2. (R6) Did you own metric definitions (a metrics layer or semantic layer), or did you consume them?
3. (Hard-gate checks) What are your hard constraints: location or remote, work authorization, minimum pay, and permanent versus contract?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.