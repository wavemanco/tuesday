**Yes, worth applying, once the employer checks out.** Status: `conditional_go`. Your must-have evidence matches the JD, the pay is disclosed inside the market band, and the role is specific. Three things are still open: the employer could not be verified from here, your location and pay floor are unknown, and BigQuery is the one stack gap.

**Fit ledger.**

- `hard_gate`: unclear: H1 (Remote (US) or Denver office), H2 (Base pay $148,000–$166,000)
- `must_have`: direct: R1 (5+ years data engineering), R2 (strong SQL and Python), R3 (dbt and a cloud warehouse), R4 (orchestration with Airflow or similar), R5 (data quality testing)
- `important`: adjacent: R6 (dbt-modelled warehouse in BigQuery); unclear: R7 (ingestion from our app and CRM), R8 (data contracts our analysts depend on)

R6 — Snowflake and dbt carry over, BigQuery itself unexercised; R7, R8 — no ingestion or contract work stated; H1, H2 — your location and floor not given. Confidence is `medium` on R1–R6 because nothing is inspectable yet.

**Opportunity ledger.** The posting is specific and its pay is disclosed inside the market band (RR3), but the employer is unverified (RR1) and the scope may be broad for this pay (RR2).

- **Hard gates:** none failed; unconfirmed: H1 (Remote (US) or Denver office), H2 (Base pay $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears: the role is live on Pellucid's careers page and the recruiter's email domain matches; (2) H1 and H2 pass against your location and floor; (3) R6 is presented as transferable Snowflake/dbt work, with BigQuery named as not used.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` your pasted About page; not re-checked live (search refused) |
| Mandate | Build and run ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and analyst data contracts | `[grounded]` JD |
| Scope read | Three areas (ingestion, warehouse, contracts) against the report's norm of one domain's pipelines for this band: broader than typical | `[inferred]` JD scope against `[generic]` report norm |
| Market calibration | Base median $151,000; IQR $139,000–$163,500. The posted $148k–$166k sits inside the IQR; its midpoint ($157k) is about $6k above median; its top is $2.5k above the IQR top. Series C falls in the report's Series B–D set | `[generic]` Datawright 2026 report (US, n=2,310), supplied by your recruiter, not independently checked; `[grounded]` posted range |
| Seniority | "Senior" typically means 5–8 years; your six years fit | `[generic]` report |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Unknowns | Equity amount and vesting; authorization (the JD is silent); team size and reporting line; whether ingestion is owned here or elsewhere; no hiring manager named | — |
| Contradictions | None between the JD and the About page as pasted; the careers page could not be read to confirm | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| H1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location is not given, so the gate is not established | `[grounded]` JD; no candidate statement | Q3 |
| H2 | Base pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Range is stated; your floor is not given | `[grounded]` JD; band in role reality | Q3 |
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; self-report, no artifact | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no sample yet | `[grounded]` your background | A sanitized query or pipeline sample would raise to high |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project on Snowflake, about 180 models; Snowflake is a cloud warehouse | `[grounded]` your background | A sanitized project outline would raise to high |
| R4 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow stated | `[grounded]` your background | none |
| R5 | Data quality testing | must_have | direct | medium | none | Great Expectations suite set up, stated | `[grounded]` your background | none |
| R6 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | dbt and warehouse work transfer; BigQuery never used, so its specifics are unexercised | `[grounded]` your background; `[inferred]` that the transfer holds | G1 |
| R7 | Ingestion from our app and CRM | important | unclear | low | discovery | Your background is silent on source ingestion | `[grounded]` silence | G2 |
| R8 | Data contracts analysts depend on | important | unclear | low | discovery | Not mentioned; dbt tests and Great Expectations are the nearest adjacency | `[inferred]` from R5 | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | dbt and cloud-warehouse work on Snowflake; no BigQuery use | Likely interview probe; the limit must be stated, not papered over | A sandbox or personal BigQuery project; any GCP work | A sandbox query history or a dbt profile for BigQuery | `[grounded]` background; `[inferred]` that this is the likely probe |
| G2 | Ingestion and data contracts (R7, R8, important) | discovery | No source ingestion or contract ownership in your background | Could be a must-have in practice given the JD's first sentence | Connectors or CDC from app or CRM; schema agreements with analyst consumers; dbt model contracts | A pipeline diagram, a contract doc, or a tool list | `[grounded]` silence; `[generic]` that ingestion roles probe source ownership |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified: search refused, so the live posting and the employer's identity are unconfirmed | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | The posting may be stale or aggregated, or the employer may be too new or small for a public footprint. Standing entry; no finding about this employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to the live role on your careers site, and who would I interview with? | unresolved |
| RR2 | Scope spans ingestion, warehouse and contracts; no team, reports or budget named | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | This role may own all three areas, broader than the one-domain norm; or a team may already carry some of them | `[inferred]` JD scope against `[generic]` report norm | Which of these three areas does this role own alone, and what team and budget support it? | unresolved |
| RR3 | Base pay disclosed inside the market band | positive_signal | — | "$148,000–$166,000 plus equity" | Transparent pay; the posted range sits in the IQR | `[grounded]` JD; `[generic]` band | Is $148,000–$166,000 the offer range for this level? | noted |
| RR4 | Equity amount and vesting not stated | unknown | — | "plus equity" | Total compensation is unknown until the grant is stated | `[inferred]` from the JD's silence on grant size | What equity comes with this role, and on what vesting schedule? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the role is live on pellucidlearning.com's careers page and the recruiter's email domain matches | RR1 caps the decision at `conditional_go` until it verifies | `[grounded]` RR1 | proposed |
| A2 | Confirm your location and pay floor against H1 and H2 before investing in the loop | Hard-gate rows are unknown | `[grounded]` H1, H2 | proposed |
| A3 | Present BigQuery as untried, with transferable Snowflake/dbt experience alongside it | R6; claiming BigQuery work would be inflation | `[grounded]` R6 | proposed |
| A4 | Ask the recruiter how ingestion and data contracts split between this role and the analysts (outreach text pending your approval) | RR2, R7, R8 | `[grounded]` RR2 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Pellucid's company and careers pages were refused by the permission prompt, so no page was read. Would have moved RR1 and the contradictions row. I did not retry |
| 2. Role-family sweep | unavailable | One search for senior data engineer pay at Series B–D companies was refused. Would have checked the recruiter's single report against a second source |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Permission to run search (refused above): would close RR1 and check the band beyond your recruiter's report.
- The live posting link, or the recruiter's email address: closes RR1 directly.
- Your location and base floor: moves H1 and H2 from unclear to direct or failed.
- A sanitized dbt project outline or a query sample: raises R2 and R3 from medium to high.
- Any BigQuery work, even a sandbox: moves R6 toward direct.
- The equity grant and vesting terms: closes RR4.

If you want this kept, I can write it to `tuesday-dossier.md` for reuse in a later session.

1. **G2 (R7, R8):** Have you owned ingestion from an application database or a CRM, or put data contracts in front of analysts who depended on them? If so, which tools, and what did you own?
2. **H1, H2:** Are you based in the US or able to work from Denver, and does a base of $148,000 to $166,000 sit above your floor?
3. **G1 (R6):** Have you ever worked in BigQuery, even in a sandbox or personal project? If so, what did you run there?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.