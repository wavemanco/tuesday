**Status: `conditional_go`. It's not a waste of your time, but the title is a real stretch.** R3 and R4a are direct. R1, R2, R6 and R7 are adjacent. The must-have that matters most is R1, the 3+ years of product management, and nothing on your resume meets it yet.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your examples show you owned roadmap or prioritisation decisions, not just collected input (R1, R7; Q1); (2) the employer verifies on its own careers page (RR1); (3) you can speak to sales-side stakeholder work, or the gap is named honestly (R4b; Q3).

**Fit ledger**

- `must_have` — direct: R3, R4a · adjacent: R1 (3+ years product management experience), R2 (shipped API or platform products), R6 (run discovery with partners, write specs), R7 (own the platform roadmap) · unclear: R4b (stakeholder management with sales)
- `important` — adjacent: R9 (launch coordination) · unclear: R5 (agile delivery), R8 (define and track adoption metrics)

R1 and R7 — the years and the roadmap ownership — carry the decision; R4b and R8 are open until you answer.

**Opportunity ledger**

- RR2 is a positive signal: the duties and the two squads are concrete.
- RR3 is an unknown: no compensation stated.
- RR1 is a standing risk that caps the decision at `conditional_go` until the employer is verified.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header |
| Mandate | Own the partner-facing API platform roadmap; drive delivery with two engineering squads; define adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Scope read | Normal for a platform PM with two squads; the scope is defined | `[inferred]` from the duties against the squad count |
| Market calibration | Not run; the salary and scope searches were refused | — |
| Unknowns | Decision rights against the squads and sales; agile practice; salary; who owns the metrics | — |
| Contradictions | None inside the JD; the careers page was not checked | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience | must_have | adjacent | low | transferability | Roadmap-input sessions and requirements documents are product work, but there is no PM title and nothing yet shows you owned prioritisation | `[grounded]` CV; `[inferred]` adjacency | Q1; G1 |
| R2 | Shipped API or platform products | must_have | adjacent | low | transferability | 30+ REST integrations delivered end to end; you shipped client builds, not the platform itself | `[grounded]` CV | Q2; G2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | low | none | Postman, SQL, OpenAPI reading, integration architecture | `[grounded]` CV | none |
| R4a | Stakeholder management: engineering and customers | must_have | direct | low | none | Coordinated vendor engineers, client engineers and PMs on custom builds; ran client workshops | `[grounded]` CV | none |
| R4b | Stakeholder management: sales | must_have | unclear | low | discovery | The CV is silent on sales | `[grounded]` CV silence | Q3 |
| R5 | Agile delivery | important | unclear | low | discovery | The CV does not name sprints or agile practice | `[grounded]` CV silence | Q3 |
| R6 | Run discovery with partners; write specs | must_have | adjacent | low | transferability | Scoping workshops and requirements documents are discovery and specs, for one client at a time | `[grounded]` CV; `[inferred]` adjacency | G2 |
| R7 | Own the platform roadmap | must_have | adjacent | low | transferability | You collected quarterly client input for product; the CV does not show you owned the roadmap | `[grounded]` CV; `[inferred]` adjacency | Q1; G2 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | No metrics on the CV; the triage-tool note is an unconfirmed lead | `[grounded]` CV silence; memory lead | Q2; G3 |
| R9 | Coordinate launches with sales and support | important | adjacent | low | transferability | Go-live and UAT coordination for integrations; sales and support launches not stated | `[grounded]` CV | Q3 |

Every confidence is `low` because nothing has been confirmed yet; the CV is self-reported. Fit is separate from confidence: R3 is `direct` at `low` until you confirm it.

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product ownership (R1, R7) | transferability | Requirements and roadmap input, with no decision rights shown | The years requirement is most likely screened on a literal read of titles, `[generic]` | A feature or integration pattern you specified that changed what engineering built | A requirements doc with its outcome, or a roadmap-input summary showing the final call | `[grounded]` CV; `[generic]` screening pattern |
| G2 | Shipped platform product (R2, R6) | transferability | Shipped client integrations, not platform releases | This is the strongest bridge: you know the API from the customer side | An integration pattern that became a reusable template or playbook item | The integration playbook, redacted | `[grounded]` CV |
| G3 | Adoption metrics (R8) | discovery | Nothing on metrics; the triage-tool lead is unconfirmed | Metrics are a named responsibility of the role | Any tool, template or playbook whose use you tracked | Usage numbers, if you have them | `[grounded]` CV silence; `[inferred]` value of the lead |

The queue holds no questions. The questions are in the closing block, tagged to their rows.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The employer may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Is this role posted on your own careers page, and who would I interview with? | unresolved |
| RR2 | Clear scope and resourcing | positive_signal | — | "Own the roadmap for our partner-facing API platform … two engineering squads" | Scope and resources are concrete | `[grounded]` JD | Does this role set the roadmap alone, or with the squad leads and sales? | noted |
| RR3 | Compensation withheld | unknown | — | Not stated in the JD | Pay may sit below the band for this title, or the company may not publish pay | `[inferred]` from the absence; band not run | What is the base salary range for this role? | unresolved |

RR1 is a standing entry. It caps the decision at `conditional_go` until verified. Say what clears it: the live posting on Quartzline's own careers site.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Pick one integration where your requirements changed what shipped, and write it up as a product decision | Answers R1 and R7 with evidence | `[grounded]` CV | pending your approval |
| P2 | Position yourself as a technical product manager who knows the API from the customer side, without claiming PM years | Leads with R3 and R4a, the direct rows | `[inferred]` from the map | pending your approval |
| P3 | Verify the posting on Quartzline's own careers page before investing effort | Clears RR1 | `[generic]` pattern | pending your approval |
| P4 | Ask the recruiter directly whether product-adjacent experience without a PM title is considered | Tests the years requirement before the loop | `[generic]` screening pattern | pending your approval |

Every row is a proposal. Nothing goes into a CV or outreach without your approval, and the wording in P2 has to pass the reframing check before you use it.

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches for Quartzline were refused, so the employer and posting are not established. Would have settled RR1 |
| 2. Role-family sweep | unavailable | The salary and scope search was refused, so the market calibration did not run. Would have set the band and the scope read |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Dossier offer:** I can write this assessment to a `tuesday-dossier.md` file for you to keep and update later, if that would help.

**Upgrade menu**

- Allow web search and I can check Quartzline's posting and the salary band, which closes RR1 and RR3 and sets the market calibration. The remaining L1 budget covers these.
- A link to the live posting or Quartzline's careers page → RR1 closes or stays open.
- Roadmap-input summaries, or a requirements doc with its outcome → R1 and R7 move toward `direct` if the artifact shows you made the call.
- Your integration playbook, redacted → R2 and R6 confidence rises from `low`.
- A deeper research pass on Quartzline (funding, leadership changes, reports from candidates and employees; up to 5 more searches and 2 more fetches). Say the word and it runs.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. **R1, R7:** Think of the last time your input changed what went into a roadmap. Did you set the priority yourself, or collect the feedback and pass it on? Name the decision and who made the final call.
2. **R8, R2:** Did you build an internal request-triage tool that support agents adopted? If so, what did it do, who decided to use it, and how did you measure whether people used it?
3. **R5, R9:** Did you work in sprints with engineering, and did you ever own the sales or support side of a launch?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.