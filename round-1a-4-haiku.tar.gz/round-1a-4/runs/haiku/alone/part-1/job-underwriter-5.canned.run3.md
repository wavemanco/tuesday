**Decision: conditional_go.** Apply. Your fit is strong, and the pay and scope look normal for the role. The one condition is that the company's existence and funding rest only on its own website so far.

Research tier: L1 — searches 2 of 5, fetches 2 of 2; user links read 0

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | Fetched pellucidlearning.com/careers/senior-data-engineer (posting is live and matches your JD text) and pellucidlearning.com/about. Searches: "Pellucid Learning live online tutoring K-12 Denver Series C"; "Pellucid Learning $52M Series C funding tutoring". Both searches returned only the company's own about page. |
| 2 | Role-family sweep | skipped | The Datawright pay report came from your recruiter, so I used it as provided rather than searching. |
| 3 | Hiring manager footprint | n/a | No hiring manager is named in the posting. |

**Snapshot**

- **Fit:** Strong on every listed requirement except one transferability gap (BigQuery). Confidence: medium, because all of it is from your own account.
- **Opportunity:** Pay sits inside the market IQR. Scope matches a typical senior role. Nothing in the posting asks for payment or sensitive details.
- **Hard gates:** Location (remote US or Denver), work authorization, and your pay floor are all **unknown**. You haven't told me these.
- **Decision:** conditional_go, capped there because the employer is verified only by its own site.

**Role reality**

- Title and scope: Senior Data Engineer, owning ingestion (app and CRM), a dbt warehouse, and data contracts. The posting doesn't say how many pipelines or whether there's a team.
- Market calibration `[generic]`: The provided report puts the base median at $151,000 (IQR $139,000–$163,500). The posting's $148,000–$166,000 midpoint is $157,000, slightly above the median. Equity is unquantified.
- Stated seniority: "Senior" is typically 5–8 years in that report. Your 6 years is in range.
- Contradictions: none found between the JD and the careers page `[grounded]`.

**Evidence map**

| # | Priority | Requirement | Fit | Evidence (your account) | Confidence | Gap |
|---|---|---|---|---|---|---|
| 1 | Must | 5+ years data engineering | Meets | 6 years at a B2B payroll company | high (stated) | none |
| 2 | Must | Strong SQL | Meets | Daily use | medium-high (stated) | none |
| 3 | Must | Strong Python | Meets | Daily use | medium (stated) | none |
| 4 | Must | dbt and a cloud warehouse | Meets | dbt project of ~180 models on Snowflake | high (stated; verify model count if asked) | BigQuery specifics (see 7) |
| 5 | Must | Airflow or similar | Meets | Airflow orchestration | medium (stated) | none |
| 6 | Must | Data quality testing | Meets | Set up the Great Expectations suite | medium (stated; depth of ownership to confirm) | none |
| 7 | Stated in JD body | BigQuery warehouse | Gap | None | — | transferability: dbt skills carry over; BigQuery dialect and tooling don't |
| 8 | hard_gate | Location: remote US or Denver | Unknown | Your location isn't provided | — | — |
| 9 | hard_gate | Work authorization | Unknown | Not provided | — | — |
| 10 | hard_gate | Pay floor vs $148k–$166k | Unknown | Your floor isn't provided | — | — |

**Opportunity risk register**

- **R1 — medium (standing).** Verification: the posting is live and matches your JD `[grounded]`, but the company's existence and its funding are confirmed only by its own about page; my two searches found no independent report. Possible reasons, none ranked as likely: the company is newer or smaller than its site states; the posting is stale; or the funding news hasn't been reported independently yet. This caps the decision at conditional_go. To resolve: the recruiter's email domain matching the company site, a link to the live posting, or an independent funding report.
- **R2 — low to medium.** BigQuery is a stated tool with no experience on your side. The gap is real but transferable, and it would be the first thing an interviewer probes.
- **R3 — low.** No hiring manager named, so the scope read stays unconfirmed.
- **R4 — low.** Equity is unquantified; treat it as zero for comparison.

**Application plan**

- Lead with scale: a ~180-model dbt project on Snowflake, plus the Airflow and Great Expectations work. Those match four of the six listed requirements.
- Name BigQuery as the one gap. Don't claim familiarity with it. Something like: "Strong dbt and Snowflake background; ramping on BigQuery, and I'd treat it as a short onboarding task." `resume_edits_pending_approval`. Nothing has been written to a resume.
- Before an interview, get some hands-on BigQuery time (partitioning and clustering, cost-aware queries, the dbt-bigquery adapter differences) so the gap is a stated plan rather than a surprise.
- Before applying, check the recruiter's email domain against pellucidlearning.com.

Dossier offer: If you want, I can write this up as `tuesday-dossier.md` so a later mock-interview prep pass can pick it up.

**Upgrade menu**

- Your location and work authorization → closes hard gates 8 and 9.
- Your pay floor → closes gate 10 and sharpens the comp comparison.
- The recruiter's email domain or a second source for the Series C → resolves R1; with a clean result, the decision can move to go.
- A small BigQuery project or example → R2 moves from low–medium to something you can show.
- The hiring manager's name → the scope read and which story to lead with for that reader.
- A deeper research pass (L2): funding and leadership changes, hiring patterns, and candidate reports on Pellucid. Up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions**

1. Are you based in the US, and do you need visa sponsorship now or later? (Tagged to gates 8 and 9.)
2. What's your floor for base pay, and is remote-only or Denver a constraint for you? (Tagged to gate 10.)
3. Who is the recruiter, and can you forward the email? I'll compare the sending domain against the company site. (Tagged to R1.)

Response mode: answer each question directly, or say "skip" and I'll keep the current analysis.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.