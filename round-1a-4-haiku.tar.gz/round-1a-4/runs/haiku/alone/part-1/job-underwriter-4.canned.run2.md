**Decision: conditional_go.** Apply, but confirm three things before you put much effort into it: whether the role manages people, the pay range, and that you're eligible to work in the UK.

**Fit ledger (candidate side, from what you've told me; nothing verified against documents)**
- **Met, stated:** 4+ years pricing analytics (you have 5), SQL and Python daily, GLM experience (built and maintained one), presenting to underwriting leads (quarterly review to the head of underwriting).
- **Strong, stated:** designing and reading price tests (14 last year, with underwriting).
- **Partial:** pet-insurance domain. You have none. Insurance is only a "plus" in the JD, and the methods transfer.
- **Unknown:** people leadership, pay, location eligibility.

**Hard gates:** No failed gate found. UK remote is unknown until you confirm your location and right to work.

**Role reality** [grounded, from the JD]
- Senior individual-contributor role: owns pricing analytics, builds and monitors rating models, designs and reads tests, and turns results into recommendations.
- No direct reports are named, and no pay is stated. Withholding pay is itself worth a question.

**Evidence map** (your claims as stated)

| # | Priority | Fit | Requirement | Evidence | Confidence | Gap |
|---|---|---|---|---|---|---|
| 1 | Must | Met | 4+ yrs pricing/actuarial analytics | 5 yrs, last 2 senior | Stated | None |
| 2 | Must | Met | Strong SQL and Python | Daily use | Stated | None |
| 3 | Must | Met | GLM experience | Built and maintained young-driver GLM | Stated | Motor, not pet |
| 4 | Must | Met | Presenting to underwriting/actuarial leads | Quarterly review to head of underwriting | Stated | None |
| 5 | Core | Strong | Design and read price tests | 14 tests with underwriting | Stated | None |
| 6 | Core | Partial | Pet-insurance product knowledge | None | n/a | Domain, transferability |
| 7 | Plus | Met | Insurance experience | UK motor insurer | Stated | None |

**Gap recovery queue**
- **Pet domain (row 6):** Closes with evidence that you can learn pet pricing quickly, such as a short self-study project or a comparable product you've priced. It is not a hard gate.
- **People leadership (not in JD):** Closes once the role is confirmed as non-managerial. If it does manage people, you have no track record to point to.

**Risk register**
- **Pay not stated (medium):** Unknown fit until a range appears.
- **Possible people management (medium):** You have never managed anyone. This matters only if the role includes reports.
- **Motor-to-pet transfer (low–medium):** Pet books usually differ on claim frequency and lifetime versus annual cover, so expect a learning curve. [inferred]
- **Employer not checked:** I have not verified that Brindlemoor exists as described or that the posting is live. Nothing found yet, nothing ruled out.

**Application plan**
- Lead with the price tests and the GLM work, framed as pricing and underwriting partnership. Both apply to any book.
- Describe the motor GLM as transferable method. Don't imply pet experience.
- Any CV wording or outreach text is proposed for your approval before it's used.

**Evidence status**
Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | Research awaits your consent |
| 2. Role-family pay and scope sweep | skipped | Research awaits your consent |
| 3. Hiring manager's public footprint | skipped | Research awaits your consent |

**Dossier offer:** If you want, I can produce a `tuesday-dossier.md` from this assessment, to carry into later sessions.

**Upgrade menu**
- A light research pass (up to 5 searches and 2 page fetches) on Brindlemoor's site, careers page and posting, and on the pay band for this seniority.
- The full posting link, so I can check it against the pasted JD.
- Odile Varga's public professional profile, if you want to know what she has published.

**Questions**
1. Does this role have direct reports or a team to lead? *(people leadership)*
2. What's the pay range, and are you eligible to work in the UK? *(hard gates)*
3. Should I run the light research pass described above? *(research consent)*

Reply with answers, "skip" for any question, or "more research" to run the pass.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.