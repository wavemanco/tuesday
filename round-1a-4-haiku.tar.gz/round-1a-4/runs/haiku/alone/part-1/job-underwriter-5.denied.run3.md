**Probably worth applying, but hold until two of your answers come in: `hold_pending_answers`.** Fit on the must-haves is strong: R3, R4, R5, R6 and R7 are `direct`. The main stack gap is BigQuery (R8). The hold rests on your location and pay floor (R1, R2), which I don't have, and on the employer check (RR4), which didn't run.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (orchestration with Airflow or similar), R7 (data quality testing)
- `important` — adjacent: R8 (BigQuery warehouse); unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R3, R4, R5, R6, R7 — direct, all from your stated background, none inspected yet; R8 — transfer from Snowflake, limit named; R9, R10 — absent from what you gave me, so unknown rather than missing.

**Opportunity ledger.** No red flags. Positives: the scope is concrete (RR5) and the posted pay sits inside the market band rather than under it (RR6). Unknowns, none of them alarms: team scope (RR1), equity terms (RR2), the unnamed hiring manager (RR3), and the employer check, which did not run (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the hold waits on your location against R1 and your pay floor against R2. If both clear, the status moves to `conditional_go`, with conditions: the posting confirmed live on the employer's own careers page (RR4), team scope confirmed (RR1), and the BigQuery gap stated plainly in applications (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C ($52M, Feb 2026) | `[grounded]` your pasted About page; not checked against any other source this run |
| Role | Owns the pipelines behind platform reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts analysts depend on | `[grounded]` JD |
| Scope read | Three layers (ingestion, modelling, contracts) spanning two source systems. Whether that is one domain or the whole reporting estate is unstated | `[inferred]` from the JD's three named layers |
| Market calibration | Senior Data Engineer at Series B–D companies, per the Datawright 2026 report you pasted: base median $151,000, IQR $139,000–$163,500; typical scope is one domain's pipelines with no direct reports | `[generic]` pattern from the pasted report, not verified at source |
| Pay against band | Posted $148,000–$166,000: midpoint about $157,000, above the median; low end just under the median, high end above the upper quartile | `[grounded]` JD figures against `[generic]` band |
| Unknowns | Hiring manager; team size and direct reports; equity amount, form and vesting; your location relative to the Denver office | — |
| Contradictions | None found between the JD and the About text as you pasted them | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | Your location isn't in what you gave me, so the gate isn't established | `[grounded]` JD; location not given | Q1 below |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor isn't given; the posted range sits at market | `[grounded]` JD; `[generic]` band | Q2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated by you; no artifact to inspect, so medium is the ceiling | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Used daily, as you stated it | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project on Snowflake, about 180 models; Snowflake meets "a cloud warehouse" as the JD words it | `[grounded]` your background; `[inferred]` that Snowflake meets the wording | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow stated | `[grounded]` your background | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite; ownership over time not stated, so the claim may be narrower | `[grounded]` your background | none |
| R8 | BigQuery warehouse (named in responsibilities, not in requirements) | important | adjacent | medium | transferability | Snowflake modelling carries over; BigQuery itself never used | `[grounded]` Snowflake work; `[inferred]` transfer; `[generic]` that BigQuery-specific ramp is what Snowflake engineers usually need | G1 below |
| R9 | Ingestion from our app and CRM | important | unclear | none | discovery | Not in your background as given | `[grounded]` absence | G2 below |
| R10 | Data contracts our analysts depend on | important | unclear | none | discovery | Not in your background as given | `[grounded]` absence | G2 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R8, important) | transferability | Snowflake dbt work at about 180 models; no BigQuery | BigQuery is the warehouse this role builds on; a clear bridge narrows the likely objection | Any BigQuery exposure, including a sandbox or course project; Snowflake performance and cost work that maps to BigQuery concerns | A sandbox project, a sanitized dbt model, or a course certificate | `[inferred]` bridge from Snowflake work; `[generic]` that BigQuery ramp is the usual objection |
| G2 | App and CRM ingestion; data contracts (R9, R10, important) | discovery | Your background as given doesn't mention ingestion sources or contracts | Both are named responsibilities; if your work covers them, fit moves to direct | Pulling from an application database or event stream into a warehouse; syncing from a CRM; agreed schemas or breaking-change handling with analysts | A pipeline diagram, a sanitized schema or contract doc, a dbt model with tests | `[grounded]` the absence; `[generic]` what ingestion and contract work usually involves |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team scope and ownership unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | May own one domain's pipelines with no direct reports, the typical senior scope; or the whole reporting estate | `[inferred]` from scope against silence on team; `[generic]` typical scope | Who else builds and maintains these pipelines, and which parts would I own end to end? | unresolved |
| RR2 | Equity unquantified | unknown | — | "plus equity" | Could be material to total pay or nominal; no terms given | `[grounded]` JD wording | What equity is offered, in what form, and what is the vesting schedule? | unresolved |
| RR3 | Hiring manager not named | unknown | — | No hiring manager named in the posting | Could be a standard requisition or mean no clear owner | `[inferred]` from the posting's silence | Who would I report to, and who owns the data platform roadmap? | unresolved |
| RR4 | Employer and live posting not checked this run | unknown | — | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states." | Every employer claim so far rests on the About text you pasted; the posting's live status is unverified. This is a refused check, not a failed one | `[grounded]` search refused this run | Is this posting live on your careers site, and who would I interview with? | unresolved |
| RR5 | Scope and stack are concrete | positive_signal | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | Named, bounded deliverables on a coherent stack | `[grounded]` JD | What would a strong first six months look like on this pipeline? | noted |
| RR6 | Posted pay at the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Range sits near the pasted report's median and above its upper quartile; no under-band mismatch | `[generic]` pasted band; `[grounded]` JD figures | What is budgeted within the range? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Answer the two gate questions (location, pay floor) before investing in the application | They decide hold versus go | `[grounded]` R1, R2 | waiting on your answer |
| P2 | Confirm the posting is live on the employer's careers page before applying | RR4 | `[grounded]` RR4 | pending your approval |
| P3 | Lead with the must-haves: six years, Snowflake dbt at about 180 models, Airflow, Great Expectations, daily SQL and Python | R3–R7 | `[grounded]` your background | pending your approval |
| P4 | Name the BigQuery gap yourself. Draft: "I built our dbt project on Snowflake, about 180 models. I haven't used BigQuery, and I expect the modelling to carry over." | R8; the second sentence is an inference, so check it before using it | `[grounded]` your statements; `[inferred]` transfer | pending your approval; check the second sentence against your own experience |
| P5 | Ask RR1 to RR3 verbatim in the first call | Interview preparation as much as diligence | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Pellucid Learning live online tutoring K-12 Denver"; "Pellucid Learning senior data engineer careers Series C") were refused because web search permission was not granted. Would have checked the entity and whether the posting is live (RR4). |
| 2. Role-family sweep | skipped | The pay report you pasted fixes the band, median, IQR and scope norm. Its content is in hand, so no search was needed. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form. |

## Upgrade menu

- Allowing web search: I'd check the live posting and the company's public footprint, which closes RR4 and lets the employer-existence caveat drop. Cost: up to 5 searches and 2 fetches.
- Your location (R1) and pay floor (R2): these resolve the hold to go or no-go.
- A BigQuery artifact, such as a sandbox project or course certificate: R8 moves from transfer to demonstrated.
- A sanitized dbt model or pipeline diagram covering ingestion or contracts: R9 and R10 move from unknown to evidenced.
- The hiring manager's name: RR3 closes, and I can check their public professional footprint for positioning.
- Equity terms: RR2 closes.

If you want, I can save this as `tuesday-dossier.md`, so the map and open questions carry into a later session.

**Questions** (answer in text, paste a voice transcript, attach a document, drop a link, or say skip):

1. **R1:** Are you based in the US, or could you work from the Denver office?
2. **R2:** Does a base salary of $148,000 meet your floor?
3. **G2:** Have you built ingestion from an application database or a CRM, or owned data contracts analysts relied on? If so, what did you build and who depended on it?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.