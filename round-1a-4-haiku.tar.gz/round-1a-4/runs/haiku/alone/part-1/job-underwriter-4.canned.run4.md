**Yes, go for it, on three conditions.** Status: `conditional_go`. The role fits your evidence well. Two things need checking before you invest in the application: the posting contradicts itself on remote working, and the pet-insurance domain is new to you.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK) working)
- `must_have`: direct: R2, R3, R4, R5, R7; adjacent: R6 (Build and monitor rating models)
- `important`: adjacent: R9 (Pet-insurance product knowledge)
- `preferred`: direct: R8 (Insurance experience)

R6, the rating-model method, carries over from motor; R9, pet insurance, is the limit you would need to name; R1 is unresolved because the two sources disagree.

**Opportunity ledger.** The employer checks out and the remit is clear. Two open items: the remote-versus-office contradiction (RR1) and no salary in the text you shared (RR3). One entry runs the other way: the employer is established (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK) working); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this (conditions for go):** (1) remote working confirmed in writing, or you confirm that four days a week in Leeds works for you (RR1, R1); (2) the salary checked against the band below once a figure is known (RR3); (3) the pet-insurance gap presented as adjacent, never as domain experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, a Series B insurtech founded 2019, Leeds-based, about 143 employees, selling pet insurance through veterinary practices | `[grounded]` brindlemoor.co.uk/about (search snippet) |
| Mandate | Own pricing analytics for the pet-insurance product; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` JD and careers page |
| Reporting line | Director of Pricing | `[grounded]` careers page |
| Working pattern | Contradicted: "Fully remote (UK)" in the JD; "Leeds office four days a week" on the careers page | `[grounded]` both sources |
| Scope read | A standard senior analyst remit; no team size or decision rights stated | `[inferred]` from the JD's silence on both |
| Market calibration | Senior pricing analyst, UK insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900 (n=612) | `[generic]` Pricewell 2026 pay survey; a pattern, not this employer's offer |
| Unknowns | Salary; whether pet pricing has its own team; decision rights on product changes | — |
| Contradictions | Remote versus Leeds four days a week | `[grounded]` both sources |

The JD does not ask for people management, so the fact that you have never managed anyone is not a gap against this role.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) working | hard_gate | unclear | medium | contradiction | JD says remote; careers page says Leeds four days a week | `[grounded]` both sources | Q1 / RR1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, last two senior | `[grounded]` your background (self-reported) | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Both used daily | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model for the young-driver book | `[grounded]` your background | none |
| R5 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with underwriting | `[grounded]` your background | none |
| R6 | Build and monitor rating models (pet product) | must_have | adjacent | medium | transferability | Method is the same; the product so far is motor | `[inferred]` from your motor work against the pet product | G1 |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurer pricing | `[grounded]` your background | none |
| R9 | Pet-insurance product knowledge | important | adjacent | medium | capability | No pet work; motor is the closest | `[inferred]` from the JD's product line against your background | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance knowledge (R6, R9) | capability | Motor pricing only | `important` priority; the first thing an interviewer will probe | Any non-motor pricing work; animal-health or vet data; claims-frequency modelling of any kind | A motor-to-pet pricing comparison, or a sanitized price-test write-up | `[inferred]` from your background against the JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Remote working contradicted across sources | risk_signal | medium | JD: "Fully remote (UK)." Careers page: "Leeds office four days a week." | One source may be stale, or the role may be hybrid | `[inferred]` from the two sources | Is this role fully remote, or is it based in the Leeds office four days a week? | unresolved |
| RR2 | Employer established | positive_signal | — | Careers page: "Accepting applications." | The employer exists as described and the posting is live | `[grounded]` careers page and About page | Which team would I be joining, and how many analysts sit in it today? | noted |
| RR3 | No salary in the text you shared | unknown | — | None in the JD text | The budgeted figure may sit inside or outside the band | `[generic]` band, against an unstated figure | What base salary is budgeted for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Ask the remote question before investing in the application | see RR1, R1 | `[grounded]` RR1 | pending your approval |
| P2 | Lead with GLM and price-test evidence; describe motor as the method bridge to pet, never as pet experience | see R4, R5, R6, R9 | `[inferred]` from the rows | pending your approval |
| P3 | Ask for the posted salary first; use the band as your reference | see RR3 | `[generic]` band | pending your approval |
| P4 | Put the register's questions to the interviewer verbatim | see the register | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your claims rest on your own account and are not yet checked against an artifact.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results), "Brindlemoor careers Senior Pricing Analyst" (found brindlemoor.co.uk/careers/senior-pricing-analyst, fetched), and "Brindlemoor Ltd UK company" (found brindlemoor.co.uk/about, from its search snippet). Moved the employer check (RR2) and the remote contradiction (RR1) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary", which returned the Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (pricewell.example/2026-uk-pricing-analytics-pay-survey). Sets the market calibration line |
| 3. Hiring manager's public footprint | skipped | Odile Varga was named, but no search was sent: the last search went to confirming the employer first. The upgrade menu offers it |

The standing employer-not-established entry is not triggered: the employer's own careers page and About page both resolve.

## Dossier offer

If you want, I can save this as `tuesday-dossier.md` so you can keep it and bring it to a later session.

## Upgrade menu

- The remote answer from the employer → R1 and RR1 close; the decision likely becomes `go`.
- The posted salary → RR3 closes, and the figure is set against the band above.
- A pet or veterinary project, even a side one → R9 moves from adjacent toward direct.
- A sanitized price-test write-up → R5 moves to `high` confidence.
- Odile Varga's public professional footprint → the scope read for this reader, and which story to lead with.
- A deeper pass on Brindlemoor (funding, leadership changes, public candidate reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. **R1 / RR1:** Do you need fully remote working as a non-negotiable, and would four days a week in Leeds rule the role out?
2. **RR3:** Do you have a minimum salary in mind for this role?
3. **R9:** Have you had any exposure to pet or veterinary data, even outside work?

Answer in text, paste a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.