## Decision snapshot

**Worth applying to, with conditions. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R6 · adjacent: R5
- `important`: direct: R7 · absent: R8 · unclear: R9
- `preferred`: adjacent: R10

Your core analytics requirements are covered on the CV. The gaps are a people-management question (R9), clinician partnership (R8) and healthcare data (R10). R10 is a stated preference, not a requirement.

- **Hard gates:** none stated in the posting, so none failed. Your own constraints (work authorization, location, pay, contract) were not given, so checks against them are unknown.
- **Severe red flags:** none found in the posting.
- **Conditions for go:**
  1. Confirm the employer and live posting exist as described (RR1). Web search was refused, so this is still unverified.
  2. Establish whether the role has formal people management, and whether you have mentoring evidence (R9, RR2).
  3. Frame the healthcare gap honestly as adjacent consumer-privacy work, never as HIPAA experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, ~400 people, Series C | `[grounded]` JD as you pasted it; not verified externally |
| Mandate | Own product analytics for the care-navigation app: metrics layer, experiments, self-serve Looker, PM and clinician partnership, mentoring two juniors | `[grounded]` JD |
| Scope read | Senior individual-contributor scope with a people component, broader than a single-analyst role | `[inferred]` from six named responsibilities including mentoring |
| Market calibration | Not established. The role-family search was refused, so I have no pay or scope band for this title | — |
| Unknowns | Contract basis, location, salary, whether mentoring is formal, clinician access, which data is regulated (PHI or not) | — |
| Contradictions | None found, but there was no second source to compare the JD against | — |

## Evidence map

Every candidate claim is CV-only, so confidence stays at `medium`. `high` needs an inspectable artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years stated, in the same function | `[grounded]` CV | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake for six years. "Expert" is your call to make, not mine | `[grounded]` CV | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran the program: 30+ tests a year, one pricing test tied to an 11% retention lift | `[grounded]` CV | sanitized test write-up would raise to `high` |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the company's Looker instance from scratch, 40+ governed dashboards | `[grounded]` CV | none |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governed dashboards and the monthly metrics memo show metric definitions in use. No evidence of a formal metrics layer or semantic model | `[inferred]` from the dashboards and memo | Ask whether you owned metric definitions |
| R6 | Strong written communication to non-technical stakeholders | must_have | direct | medium | none | You write the monthly exec metrics memo and present to the VP Product monthly | `[grounded]` CV | a sanitized memo would raise to `high` |
| R7 | Turn analysis into roadmap decisions with PMs | important | direct | medium | none | Monthly VP Product presentations, and the pricing test informed a decision | `[grounded]` CV | none |
| R8 | Partner with clinicians | important | absent | none | discovery | Nothing in the CV. It may exist and be unstated | `[grounded]` CV silence | question G3 |
| R9 | Mentor two junior analysts | important | unclear | low | discovery | CV silent on mentoring or managing | `[grounded]` CV silence | question G1 |
| R10 | Healthcare data (HIPAA), a plus | preferred | adjacent | medium | transferability | No healthcare work. GDPR/CCPA consumer PII and the consent-state model are adjacent, not health data | `[grounded]` CV; adjacency `[inferred]` | question G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Mentoring (R9, important) | discovery | No mentoring or managing in the CV | Named responsibility, and the one most likely to be probed | Informal onboarding or reviewing a colleague's analysis, if it happened | A concrete example of onboarding or reviewing someone's work | `[grounded]` CV silence |
| G2 | Healthcare data (R10, preferred) | transferability | Consumer PII and consent work only | HIPAA is a plus, but care data will be a constant backdrop | Consent-state modelling, PII handling, data minimization | An example of how consent state was modelled and enforced | `[inferred]` adjacency |
| G3 | Clinician partnership (R8, important) | discovery | No clinician or patient-facing work in the CV | Clinicians are named as partners in roadmap decisions | Any work with ops, care or support teams that shaped a decision | One example of a non-PM stakeholder shaping analysis | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not confirmed | risk_signal | medium | "Harborlight Health (digital-health scale-up…)" | Standing entry. Possible reasons, none ranked as likely: too new or small, a stale posting, or not a real hiring employer | `[grounded]` web search refused, so nothing was checked | Can you share the live posting or the company's careers page? | unresolved |
| RR2 | Mentoring and people scope | unknown | — | "mentor two junior analysts" | The role may be a formal lead with direct reports, or informal mentoring. Each changes the story | `[inferred]` from the responsibility list against CV silence | Is mentoring formal, with reports? | unresolved |
| RR3 | Salary, contract basis and location withheld | unknown | — | Not stated in the JD | Cannot test any pay, contract or location constraint yet | `[grounded]` JD silence | What are the salary, contract type and location? | unresolved |
| RR4 | Regulated-data expectations | risk_signal | low | "healthcare data experience (HIPAA) a plus" | A care-navigation app likely handles health information. Your PII work is consumer, so the bar may differ | `[inferred]` from the app's domain | Does the role touch PHI directly, or de-identified data? | unresolved |
| RR5 | Defined scope | positive_signal | — | Six named responsibilities | The role is specified, so expectations can be tested in interview | `[grounded]` JD | Who owns the metrics layer today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the experimentation program and the Looker build, the strongest direct matches | Covers R3 and R4 first | `[grounded]` CV | pending your approval |
| P2 | Describe the consent-state and PII work as consumer-privacy (GDPR/CCPA) work, not health data | Frames R10 honestly, without implying HIPAA experience | `[grounded]` CV | pending your approval |
| P3 | Offer a sanitized monthly metrics memo or pricing-test write-up as a work sample | Would raise R3 and R6 to `high` | `[grounded]` CV | pending your approval |
| P4 | Ask the recruiter for salary, contract type and location before investing in the loop | RR3 | `[generic]` common hiring practice | pending your approval |

Positioning language in P1 and P2 is limited to what your own sentences say. It adds no scope, outcomes or healthcare experience.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Harborlight Health care navigation digital health Series C" and "Harborlight Health Senior Product Analyst careers" were refused because web search permission is not granted. Would have confirmed the employer exists as described and that the posting is live (RR1) |
| 2. Role-family sweep | unavailable | Search "senior product analyst digital health salary experimentation Looker HIPAA" was refused. Would have set the market calibration for scope and pay (RR3) |
| 3. Hiring manager's public footprint | n/a | No name given |

## Dossier offer

If you want it, I can emit a `tuesday-dossier.md` with this assessment, ready for mock-interview to pick up.

## Upgrade menu

- Grant web search permission and I'll rerun the three declared searches (at L1, up to 5 searches and 2 fetches). That checks the employer, the live posting and a pay band.
- A live posting link or the careers page: closes or sharpens RR1.
- A sanitized monthly metrics memo or pricing-test write-up: raises R3 and R6 to `high`.
- A deeper pass at L2 (up to 5 more searches and 2 more fetches): funding, leadership changes, public employee reports, recent news. I'll run it only if you say so.
- Any evidence of mentoring or managing analysts: resolves R9 and G1.

## Questions

1. **[R9 / G1]** Have you mentored or managed analysts? If so, how many, and what did it involve?
2. **[RR1]** Can you share the live posting or the company's careers page, so I can check the employer against what you were sent?
3. **[R10 / G2]** Have you worked with health or care data at all, such as a partner's data, a clinical feed or anything under a BAA? If so, what did you do with it?

Answer any of these in prose, or say skip. A skip counts as an answer, and I won't ask again.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.