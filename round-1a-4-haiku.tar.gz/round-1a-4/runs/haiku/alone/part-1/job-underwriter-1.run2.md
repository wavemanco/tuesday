**Apply, on conditions. Status: `conditional_go`.** On the analytics core you fit: R1, R2, R3, R4 and R5 are direct. You are not yet a fit on the healthcare piece (R9), metrics-definition ownership (R6), clinician partnership (R7) or mentoring (R8). Close the conditions below before you invest in an application.

**Fit ledger.**
- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — adjacent: R6 (metrics layer), R7 (PM and clinician partnership) · unclear: R8 (mentoring junior analysts)
- `preferred` — adjacent: R9 (healthcare data, HIPAA)

Ledger reading, one list: R6 — governance work carries over, ownership of definitions unconfirmed; R7 — PM partnership carries over, clinician work absent; R8 — no mentoring on record; R9 — consumer-privacy work carries over, HIPAA and clinical data absent.

**Opportunity ledger.** RR1 (`risk_signal`, `severity: medium`) is the employer check: the search that would have attributed Harborlight was refused in this session, so the employer is unverified, not failed. RR2 and RR3 are open unknowns: whether the role touches identifiable patient data, and its pay, location and contract. RR4 is a positive signal, since the mandate is written concretely.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR1 — confirm the role and employer on Harborlight's own careers site before applying; (2) RR3 — check the pay, location and contract against your constraints, which you haven't given yet; (3) R8 — mentoring is either evidenced or framed as not yet done; (4) R6 and R9 — healthcare framed as consent and consumer-privacy work, never as HIPAA or clinical experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD header; not checked against the company's site |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| Scope read | Five distinct responsibilities for one app, plus two direct reports' worth of mentoring | `[inferred]` from the JD's responsibility list |
| Market calibration | Not run: the role-family sweep was refused, so no band for title, scope or pay | — |
| Unknowns | Pay; location and remote policy; contract type; start date; reporting line; whether analysts touch identifiable patient data; what the clinician partnership involves | `[grounded]` JD silence |
| Contradictions | None visible in the one JD provided; the careers page could not be read | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a subscription company, as stated; self-reported, not inspected | `[grounded]` CV | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on Snowflake; "expert" is a self-judgment, not tested | `[grounded]` CV | Upgrade: one query sample |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year; the 11% retention lift is self-reported, and its method is unseen | `[grounded]` CV | Upgrade: one sanitized test readout |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the Looker instance; 40+ governed dashboards | `[grounded]` CV | none |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Writes the monthly exec metrics memo; presents to VP Product monthly; the memo itself is not inspected | `[grounded]` CV | Upgrade: a sanitized memo |
| R6 | Define and maintain the metrics layer | important | adjacent | medium | transferability | Governed dashboards carry over; the CV does not say who owned canonical definitions | `[inferred]` from the JD's responsibility against the CV's governance claims | G3 |
| R7 | Partner with PMs and clinicians | important | adjacent | medium | transferability | PM and exec partnership is stated; clinician work is absent | `[grounded]` CV for PM; `[inferred]` for the adjacency | G4 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | CV silent on mentoring | `[grounded]` CV silence | Q1 in the closing block |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Never worked in healthcare; GDPR/CCPA consumer PII and the consent-state model carry over; HIPAA and PHI are absent | `[grounded]` CV; `[generic]` that HIPAA and consumer privacy regimes differ | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Healthcare data (R9, preferred) | transferability | Consumer consent and PII work under GDPR/CCPA; no HIPAA, PHI or clinical data | The JD names it, and an interviewer may test whether consumer privacy work transfers | Consent or retention logic applied to sensitive categories; any privacy review that covered health-adjacent data | A short description of the consent model's scope | `[inferred]` bridge from the consent work; `[generic]` that HIPAA differs materially from consumer regimes |
| G2 | Mentoring two junior analysts (R8, important) | discovery | Not on record | Mentoring is a stated part of the role | Onboarding or reviewing analyst work; running SQL or Looker training; informal coaching | A documented onboarding plan, or a manager's note | `[grounded]` CV silence |
| G3 | Metrics-layer ownership (R6, important) | transferability | Built governed dashboards; definition ownership not stated | Defining and maintaining the metrics layer is the role's core job, and the limit is ownership | Owning metric definitions; running a metric review; keeping a canonical KPI list | A metrics dictionary or metric-review document | `[inferred]` |
| G4 | Clinician partnership (R7, important) | transferability | PM and exec partnership; no clinician work | Clinicians are named in the JD | Analysis work with a non-product function | An example brief or request from a non-product partner | `[inferred]` |

The queue holds no questions. The questions for G2 and G3 are in the closing block.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Not checked: the search that would attribute the employer was refused in this session, so it is unverified, not failed. The employer may be too new or small for a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Patient-data exposure unknown | unknown | — | "healthcare data experience (HIPAA) a plus" | The role may query identifiable patient data, which changes the privacy work it needs | `[inferred]` from the JD's HIPAA reference | Will this role query identifiable patient data, and what access controls and training apply? | unresolved |
| RR3 | Pay, location, contract and start not stated | unknown | — | JD gives none of these | Checks against your constraints cannot run until these are known | `[grounded]` JD silence | What is the base salary range, the work location and schedule, and the contract type? | unresolved |
| RR4 | Scope and outcomes written concretely | positive_signal | — | "Own product analytics for our care-navigation app" | The mandate is specified, so success can be assessed | `[grounded]` JD | What does success look like for this role at twelve months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Describe the consent-state model as consent and consumer-PII work under GDPR and CCPA; no HIPAA or clinical framing | see R9 | `[grounded]` CV wording | pending your approval |
| A2 | Lead with the experiment program and the Looker build as the anchor evidence | see R3, R4 | `[grounded]` CV | pending your approval |
| A3 | Confirm metric-definition ownership before applying (G3) | see R6 | `[inferred]` | pending your approval |
| A4 | Confirm the employer and live posting on Harborlight's own careers site before applying | see RR1 | `[generic]` | pending your approval |
| A5 | Put the RR1–RR3 verification questions to the employer in the first screen | the register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Every claim above is CV-level self-report, so the intake ceiling of `medium` applies. Stage assumed: evaluating.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both employer searches were refused permission, so nothing came back. Would have moved RR1 (existence, and whether the posting is live) |
| 2. Role-family sweep | unavailable | Refused in the same way. Would have moved the market calibration line (no pay band yet) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Permission to run web search. Two employer and market searches were refused; with them, RR1 gets checked and the market calibration line gets a band.
- The posted pay, location, contract type and start date → RR3 closes, and your constraints become checkable hard-gate rows.
- Your own constraints (pay floor, location, contract, start) → the hard-gates line gets real checks.
- One sanitized piece of work: a query sample, a test readout, or the monthly memo → R2, R3 and R5 move from `medium` toward `high`.
- An onboarding plan or training material you ran → R8 moves from unclear.
- The hiring manager's name → row 3 of the research table becomes available.

If you want, I can write this up as `tuesday-dossier.md` to keep or pick up in a later session.

1. **G2** — Have you mentored, onboarded or formally coached junior analysts? If so, how many, over what period, and what did you own?
2. **G3** — At the meal-kit company, who defined and maintained the canonical metric definitions, and what part did you own?
3. **Structural** — Which of these matter for this search: your pay floor, location or remote requirement, contract type, and earliest start date?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.