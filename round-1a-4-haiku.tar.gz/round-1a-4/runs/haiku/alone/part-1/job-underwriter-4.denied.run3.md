**Yes, apply, once the employer checks out.** Status: `conditional_go`. Your must-haves map well to this role. The open items are the employer itself, which I couldn't verify, and the pet-insurance transfer.

**Fit ledger.**

- `hard_gate`: unclear: R1 (fully remote, UK-based)
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: direct: R7, R9a · adjacent: R8 (pet-insurance pricing) · unclear: R9b (product recommendations)
- `preferred`: direct: R10

R2–R6 are direct on your own account; R8 is the one real stretch, and R9b is the other open item. R8 is a transfer from motor, with the limit named.

**Opportunity ledger.** The role itself reads as well scoped, but the employer is unestablished (RR1, `risk_signal`, `severity: medium`), and the JD gives no salary (RR2) or management scope (RR3). RR4 is positive: the three responsibilities and two outcomes are concrete.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote, UK-based); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the employer and live posting are verified on the employer's own site (RR1, which also caps the decision at `conditional_go`); (2) R1 is confirmed; (3) the pay and contract basis are acceptable once stated (RR2).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech writing pet insurance | `[grounded]` JD header; not verified (no research ran) |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message; not verified |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Senior individual-contributor scope on the pricing function; the JD asks for no direct reports | `[inferred]` from the responsibility list and its silence on people management |
| Market calibration | Not run: no role-family sweep this session, so I can't give a pay band | — |
| Unknowns | Base salary and bonus; contract type; whether the role line-manages; whether the posting is live | — |
| Contradictions | None found within the JD as provided | `[grounded]` JD |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based (location gate) | hard_gate | unclear | medium | hard_gate | Your location isn't in your intake, and the JD states the gate | `[grounded]` JD | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, last two as senior analyst; self-reported, so `medium` | `[grounded]` your intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your intake | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM rating model | `[grounded]` your intake | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your intake | none |
| R6 | Designing and reading price tests | must_have | direct | medium | none | Ran 14 price tests last year with underwriting. "Design" is implied by "ran", so I haven't counted it as separately evidenced | `[grounded]` your intake | none |
| R7 | Building and monitoring rating models | important | direct | medium | none | Built and maintained one; monitoring is implied, not stated | `[grounded]` your intake | none |
| R8 | Pricing for a pet-insurance product (pet-specific drivers) | important | adjacent | medium | transferability | Motor GLM and price-test work carries over. Limit: no pet, vet-cost or lifetime-cover pricing | `[inferred]` from the JD's product and your motor work | G1 |
| R9a | Turning results into recommendations for underwriting | important | direct | medium | none | Quarterly review to underwriting | `[grounded]` your intake | none |
| R9b | Turning results into recommendations for product | important | unclear | low | discovery | Nothing in your intake touches product | `[grounded]` intake silence | G2 |
| R10 | Insurance experience (preferred) | preferred | direct | medium | none | Motor insurer, UK | `[grounded]` your intake | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance pricing (R8, important) | transferability | GLM and price-testing experience in motor; no pet, vet-cost or lifetime-cover work | The JD names the pet product, so this is the likeliest objection | Any non-motor pricing or claims analysis; any work on frequency and severity drivers that differ by line | A short note on a non-motor model or test you've seen | `[inferred]` bridge from your motor work; `[generic]` that this is the likeliest objection |
| G2 | Product recommendations (R9b, important) | discovery | No product-facing recommendation in the intake | The JD names product as a recipient of your analysis | A product change you proposed or evaluated (cover limits, excess, pricing structure) and what happened | A product brief or a test readout | `[grounded]` intake silence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Senior Pricing Analyst — Brindlemoor (insurtech)" | The employer may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I interview with? | unresolved |
| RR2 | Base salary not stated | unknown | — | JD gives no pay | Pay may be withheld, or simply absent from this copy of the JD | `[inferred]` from the JD's silence | What base salary and bonus are budgeted for this role? | unresolved |
| RR3 | Line management not stated | unknown | — | "Own pricing analytics" (no reports mentioned) | The role may be individual-contributor, or may include reports that the JD omits | `[inferred]` from the JD's silence | Does this role line-manage anyone now or in its first year? | unresolved |
| RR4 | Defined responsibilities and outcomes | positive_signal | — | "build and monitor rating models, design and read price tests, turn results into recommendations" | The scope is concrete, which suggests a real remit | `[grounded]` JD | Which pricing decision would I own in the first quarter? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with GLM build-and-maintain, the 14 price tests read through to underwriting, and the quarterly review to underwriting leads | Matches R4, R6, R5, R9a; the strongest evidence in your intake | `[grounded]` intake | pending your approval |
| E2 | Describe pet work as motor transfer with its limit named, not as pet expertise | See R8. Avoid "pet pricing experience" in any form | `[grounded]` R8 row | pending your approval |
| A1 | Verify the posting on Brindlemoor's own careers site before investing in the application | RR1 caps the decision at `conditional_go` | `[generic]` standing entry | pending your approval |
| A2 | Ask RR2 and RR3 at first contact | Pay and management scope are open | `[grounded]` register | pending your approval |

Each row above is a proposal. Nothing goes into a CV or outreach text until you approve it.

**Evidence status**

Verified: none yet. Your intake is self-report, so every claim sits at `medium` at most (R2–R7, R9a, R10). R8 is `medium` as well, because the motor claims are self-reported.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; the three search calls were refused, so nothing returned

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Every search call was refused (permission not granted this session). Would have checked that Brindlemoor exists as described and that the posting is live (RR1) |
| 2. Role-family sweep | unavailable | Every search call was refused. Would have set a market band for the role's title and seniority (not given, since none was run) |
| 3. Hiring manager's public footprint | unavailable | Every search call was refused. A name was given, so a query could be formed. Would have shown Odile Varga's public professional role and background, for positioning |

**Upgrade menu**

- Grant web search and I'll run the three checks above (up to 5 searches and 2 fetches). That moves RR1, the pay band, and the positioning for this hiring manager.
- A test readout or sanitized GLM documentation from one of the 14 price tests → R4 and R6 to `high`.
- Any non-motor pricing or claims analysis → R8 toward `direct`.
- The budgeted salary → RR2 closes and can be set against a band (none run yet).
- If you want to keep this assessment, I can write it up as `tuesday-dossier.md`.

Q1 (R1): Are you based in the UK, with the right to work here, so the fully remote UK condition is met?

Q2 (RR3): Does this role line-manage anyone? You said you've never managed anyone, so the answer decides whether that gap matters.

Q3 (G1): Have you ever priced or analysed a non-motor product, or pet-related data such as vet costs or claims by breed or age?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.