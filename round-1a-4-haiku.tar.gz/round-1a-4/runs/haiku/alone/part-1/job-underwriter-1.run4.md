**Yes, apply, but as a conditional go.** On the background you gave, you meet the core requirements: the years, SQL, experiment design, Looker and written communication all read as direct. The gaps are the metrics-layer ownership, mentoring, clinician partnership and healthcare data. I could not verify the employer, because the web searches were refused.

**Research tier: L1, searches refused, fetches 0 of 2; user links read 0.** I did not retry the refused searches.

## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**
- `must_have`: direct R1, R2, R3, R4, R7a, R8 · adjacent R5 (define and maintain the metrics layer)
- `important`: adjacent R6 (self-serve dashboards for non-analysts) · absent R7b (partner with clinicians on analysis) · unclear R9 (mentor two junior analysts)
- `preferred`: adjacent R10 (healthcare data (HIPAA))

R5 — the metrics layer is adjacent until you say who owned the canonical definitions; R9 — no mentoring is on record, so it is unclear; R10 — consumer privacy work is a bridge, not HIPAA.

**Opportunity ledger.** Nothing in the posting text is a red flag, but the employer is not established: no search could check the company or the posting (RR1). Scope is broad for one role (RR2). The pasted JD shows no pay (RR3), and it names HIPAA without saying who owns it (RR4). The posting does name a specific mandate (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR1 clears: the live posting appears on Harborlight's own careers page; (2) R5 resolves: you owned canonical metric definitions, not only consumed them; (3) RR4 clears in interview: scope of PHI ownership is stated.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD header as pasted; not verified (RR1) |
| Mandate | Own product analytics for the care-navigation app | `[grounded]` JD |
| First-year outcomes | None stated | — |
| Scope read | One senior role carrying metrics ownership, experimentation, dashboards, stakeholder partnership and mentoring | `[inferred]` from the JD's own list |
| Market calibration | Not run. The role-family search was refused, so I have no sourced pay or scope band and won't supply one from memory | — |
| Unknowns | Pay, team size, reporting line, whether the two junior analysts exist, decision rights, location, PHI scope | — |
| Contradictions | None visible within the JD text; no careers-page check ran | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company, stated at intake, not yet checked against a document | `[grounded]` your stated background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake, stated; "expert" is not shown by a sample | `[grounded]` stated background | Upgrade menu: a sanitized query |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year and an 11% retention lift from a pricing test, stated; design rigour unshown | `[grounded]` stated background | Upgrade menu: one test design or readout |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the company's Looker instance; 40+ governed dashboards, stated | `[grounded]` stated background | Upgrade menu: dashboard screenshot |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governed dashboards and a monthly metrics memo are credible adjacency. Limit: canonical definitions owned across teams is not stated | `[grounded]` stated; `[inferred]` adjacency | Question Q1 |
| R6 | Self-serve dashboards for non-analysts | important | adjacent | medium | transferability | Builds governed dashboards; whether non-analysts used them without you is not stated | `[grounded]` stated; `[inferred]` adjacency | Confirm in interview |
| R7a | Partner with PMs and executives to turn analysis into roadmap decisions | must_have | direct | medium | none | Monthly memo read by the exec team; monthly presentation to VP Product, stated | `[grounded]` stated background | none |
| R7b | Partner with clinicians on analysis | important | absent | none | discovery | Nothing in your background names clinical or care-team partners; it may exist | `[grounded]` absence in background | Question Q2 |
| R8 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo read by the exec team, stated | `[grounded]` stated background | Upgrade menu: a sanitized memo excerpt |
| R9 | Mentor two junior analysts | important | unclear | none | discovery | Nothing stated about mentoring or managing analysts | `[grounded]` absence in background | Question Q3 |
| R10 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Consumer PII under GDPR/CCPA and a consent-state model carry over. Limit: no PHI or HIPAA-specific work stated | `[grounded]` stated; `[inferred]` adjacency | Describe as adjacent (A4) |

There are no `hard_gate` rows: the JD states no gate, and no candidate constraints were given.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, must_have) | transferability | Governed dashboards and a monthly memo; no statement that you owned canonical definitions | A must-have; if you owned them, R5 moves to direct | Defining "active subscriber" or "retention" once for the company; a metric-definitions doc or a semantic-layer model you wrote | A metric dictionary, a LookML or dbt model excerpt | `[grounded]` stated background; `[inferred]` that it moves the status |
| G2 | Clinician partnership (R7b, important) | discovery | No named clinical or care-team partners | Clinicians are named in the JD; expect it as a probe | Analysis for ops, support or care teams that changed a decision | A brief or a decision memo | `[grounded]` absence; `[generic]` that interviewers probe this line |
| G3 | Mentoring (R9, important) | discovery | Nothing stated | Two direct reports for mentoring are in the JD | Onboarding or code review for junior analysts; a mentee's outcome | Nothing needed beyond a clear example | `[grounded]` absence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Here no check ran at all, so this is unverified, not a finding of absence | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Scope breadth for one senior role | risk_signal | low | "Own product analytics…" with "mentor two junior analysts" | The role may be stretched across more than one job | `[inferred]` from the JD's list against its silence on team size | Which of these responsibilities does someone else own today, and what do the two junior analysts handle now? | unresolved |
| RR3 | Pay absent from the pasted JD | unknown | — | (none; no pay figure appears) | Pay may be published elsewhere or set on application | `[generic]` pattern for postings | What is the base range for this role, and how is it set? | unresolved |
| RR4 | HIPAA named as a plus, owner unstated | unknown | — | "healthcare data experience (HIPAA) a plus" | The team may not yet own PHI handling | `[inferred]` from the requirement's wording | Who owns HIPAA-scoped data access and reporting here, and would this role touch PHI directly? | unresolved |
| RR5 | Specific mandate with a partnership to decisions | positive_signal | — | "partner with product managers and clinicians to turn analysis into roadmap decisions" | The role is set to influence the roadmap, not only report on it | `[inferred]` from the JD's stated partnership | Which roadmap decisions did last year's analysis change? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the posting on Harborlight's own careers page before applying | RR1 | `[grounded]` standing entry | proposed |
| A2 | Ask the recruiter for the pay range, and whether the role manages a team or only mentors | RR3, R9 | `[grounded]` RR3, R9 | proposed |
| A3 | Lead with the experimentation program and the Looker build, using the 11% pricing result as proof | R3, R4 | `[grounded]` stated background | pending your approval |
| A4 | Describe the consumer privacy work as adjacent to HIPAA, not as healthcare experience | R10 | `[grounded]` R10 row | pending your approval |
| A5 | Don't claim clinician partnership or mentoring until you have a specific example | R7b, R9 | `[grounded]` rows | proposed |

## Evidence status

Verified: none yet. Everything you've stated is a self-report at `medium`, awaiting an artifact.

**Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Harborlight Health care navigation app company"; "Harborlight Health careers Senior Product Analyst") were refused by permission. Would have confirmed the employer and that the posting is live; feeds RR1 |
| 2. Role-family sweep | unavailable | One search ("senior product analyst salary product analytics experimentation Looker") was refused. Would have set the market calibration and the scope read |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Permission to search: runs targets 1 and 2 — the employer check and the pay and scope band.
- The live posting's link or Harborlight's careers-page URL: closes RR1 if it matches the JD.
- A sanitized query or dashboard screenshot: R2 and R4 to `high`.
- One test design or readout, sanitized: R3 to `high`.
- A memo excerpt, sanitized: R8 to `high`.
- The recruiter's pay range: closes RR3.
- The hiring manager's name: sharpens the scope read and which story to lead with.

If you want, I can write this assessment to a `tuesday-dossier.md` file to keep.

**Questions**

R5 — Did you own the canonical metric definitions (where "active subscriber" or "retention" gets defined), or did another team own them while you consumed them?

R9 — Have you mentored or managed junior analysts? Give one example: who, what you did, and what changed for them.

R7b — Have you worked directly with non-product domain experts (clinicians, care-team leads, support or ops) on analysis that changed a decision? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.