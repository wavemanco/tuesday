## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R7 (Bristol hybrid, two office days a week; right to work not stated)
- `must_have`: direct: R1, R2, R3, R4 · adjacent: R5 (owning the quarterly forecast) · unclear: R6 (finance work on billing or revenue data)
- `important`: none listed
- `preferred`: none listed

The core RevOps work fits you directly. The two gaps are forecast ownership and billing data, and both sit in the JD's own list of responsibilities.

**Opportunity ledger.** Sound and well-funded, with the scope partly undefined. The pay is inside the market band, and the hiring manager's background is close to yours. Three things are unknown: how the forecast is built, whether billing is in scope from day one, and whether this listing is live on Quillfield's own site. None of these is a red flag.

- **Hard gates:** none failed; unconfirmed: R7 (Bristol hybrid, two office days a week; right to work not stated). Candidate constraints were not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the recruiter confirms how the quarterly forecast is built and whether RevOps owns the model or supplies inputs to finance (RR1); (2) the recruiter confirms billing system scope (RR2); (3) the posting is confirmed from Quillfield's own site or a company-domain recruiter email (RR3); (4) you can meet the Bristol office days and the salary is above your floor (R7).

Failed attribution is not triggered. The company exists as described (see Research tier below), so the cap on `go` does not apply. The unconfirmed listing is handled as RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; Bristol; founded 2018; 96 employees; Series A (£11M) closed April 2025 | `[grounded]` Quillfield's own About page (self-described) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern | Hybrid, two days a week in the Bristol office | `[grounded]` JD |
| Scope read | Broader than the current RevOps job. Forecasting and billing data are both new to you, and they are stated responsibilities, not nice-to-haves | `[inferred]` from the JD's responsibility list against the stated history |
| Reporting line | The post probably reports to the Head of Revenue Operations, Tamsin Achebe | `[inferred]` from her title |
| Hiring manager | Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years | `[grounded]` public profile search result |
| Market calibration | Median base £64,200; interquartile range £57,800–£70,400 for UK RevOps leads at B2B software companies (vendor survey, n=438). The JD's midpoint of £64,250 sits on the median | `[generic]` Ledgerline 2026 pay guide (search snippet, not fetched); `[grounded]` JD for the posted figure |
| Unknowns | Share option terms; whether forecast ownership sits with RevOps or finance; billing system scope; right to work and location | — |
| Contradictions | None between the JD and the About page. The JD's Bristol location matches. The posting was not found on Quillfield's careers URL (see RR3); this is an unverified listing, not a contradiction | `[grounded]` careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years in RevOps, sales ops or analytics at a B2B software company | must_have | direct | medium | none | Five years in sales ops, the last two running UK revenue ops. Your employer is a B2B payments company. Payments is close enough to software to count, but the recruiter may ask | candidate-stated; `[grounded]` JD requirement | State the employer description plainly in applications |
| R2 | HubSpot or Salesforce administration | must_have | direct | high | none | Salesforce admin certified; the certificate is checkable | candidate-stated; certification is inspectable | Keep the certificate ID on record |
| R3 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly and Excel daily establish the query side. "Modelling" is not specified, so forecasting models are not evidenced | candidate-stated | A sample query or model raises this to high |
| R4 | Pipeline and renewal reporting that sales and finance run on | must_have | direct | medium | none | You rebuilt the pipeline and renewal dashboards. The finance audience is not stated | candidate-stated | Confirm who used the dashboards |
| R5 | Owning a quarterly revenue forecast with the CFO | must_have | adjacent | medium | transferability | You have never owned the company forecast; finance did it. You run the monthly pipeline review with the sales director, which is the nearest input | candidate-stated; `[inferred]` adjacency | See G1 |
| R6 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | You have never worked on billing data. Whether payments transaction or settlement data counts is unknown | candidate-stated; `[grounded]` JD requirement | See G2 |
| R7 | Bristol, two office days a week; right to work | hard_gate | unclear | none | hard_gate | Your location and right-to-work status were not provided | `[grounded]` JD; candidate constraint not given | Closing question 3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning the forecast (R5, must_have) | transferability | Pipeline review with the sales director; no forecast ownership | The forecast is a named quarterly responsibility, the largest step beyond your current role | Any forecast or commit number you contributed to; pipeline-to-forecast bridging; scenario work | A forecast template, or a pipeline review pack with forecast figures | `[inferred]` bridge from the pipeline review; `[generic]` that this is the likeliest objection |
| G2 | Finance work on billing or revenue data (R6, must_have) | discovery | No billing data work | The JD says you will own billing data | Payments transaction, settlement or reconciliation work done with finance | A reconciliation or settlement report, sanitized | `[inferred]` from the payments employer; not yet established |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership is a new responsibility | risk_signal | medium | "run the quarterly revenue forecast with the CFO" | The role may sit closer to finance's forecasting than your current RevOps job, with RevOps owning inputs only | `[inferred]` from the JD's bullet against your stated history | Recruiter to confirm how the forecast is built and who owns the model | unresolved |
| RR2 | Billing data scope is new | risk_signal | medium | "You will own our CRM and billing data" | Billing system knowledge may be expected from day one | `[inferred]` from the JD bullet against your stated history | Recruiter to confirm whether billing is in scope for the first months | unresolved |
| RR3 | Posting not found on the company's own careers page | unknown | — | Quillfield's careers URL returned no page | The listing may run through the aggregator only, or sit at another URL. This is not failed attribution: the company itself is confirmed | `[grounded]` fetch of quillfield.co.uk/careers | Recruiter to confirm the listing from Quillfield's own site or a recruiter email on the company domain | unresolved |
| RR4 | Salary sits in the market band | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is in line with the market; the share option terms are the open part | `[grounded]` JD; `[generic]` band, midpoint £64,250 against median £64,200 | Share option terms, to be confirmed by the recruiter | noted |
| RR5 | Hiring manager's background is close to yours | positive_signal | — | Head of Revenue Operations; previously sales operations at Corvane Payments | A shared payments-side RevOps path, which helps in the interview | `[grounded]` profile result; reporting line `[inferred]` | Confirm the reporting line | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the pipeline and renewal dashboard work and the SQL and Excel modelling. Describe forecast experience only as pipeline-review input, never as ownership | Avoids inflating R5 | `[grounded]` CV; `[inferred]` positioning | pending your approval |
| E2 | Prepare a short proposal for how you would build the quarterly forecast and what you would need from finance. Label it as a plan, not prior experience | Turns R5 into a credible answer without new claims | `[generic]` interview preparation pattern | pending your approval |
| E3 | Ask the recruiter about the forecast process, billing scope and the employer-side listing before investing in the full loop | RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| E4 | If it exists, describe payments reconciliation or settlement work with finance as billing-adjacent, using your own words for what you did | R6 | `[inferred]` | pending your approval |
| E5 | Frame the shared background with the hiring manager, both coming from payments-side sales operations, and lead with payments pipeline work | RR5 | `[inferred]` | pending your approval |

## Evidence status

Verified: none yet. Your CV claims rest on your statement. The Quillfield facts rest on the company's own About page and the public profile result. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" and "Quillfield careers Revenue Operations Lead" (no results). Fetched "About Quillfield" (quillfield.co.uk/about) and quillfield.co.uk/careers (no page at that address). Moved: the entity exists as described (Bristol, founded 2018, 96 employees, Series A April 2025). The posting was not found on the careers page, so RR3 was raised |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Snippet only, not fetched. Moved: market calibration `[generic]` and the pay read in RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned her public profile (linkedin.example/in/tamsin-achebe). Moved: the scope read and the reporting line, and the positioning in E5 |

## Upgrade menu

- A pipeline-to-forecast example, or a reconciliation report → R5 and R6 move.
- The recruiter's answers on forecast process, billing scope and the employer-side listing → RR1–RR3 close, and the decision may move to `go`.
- Share option terms → RR4 completes.
- The full Ledgerline pay guide, fetched rather than read from the snippet → the market band is confirmed beyond the snippet.
- A deeper pass on Quillfield (funding, leadership changes, hiring patterns, staff reports): up to 5 more searches and 2 more fetches. I can run it if you want it, and I will not offer it again after a decline.

If you want this kept, I can write it up as a `tuesday-dossier.md`.

1. (R6, G2) Did you ever work with payments transaction, settlement or reconciliation data alongside finance, even if you didn't own billing?
2. (R5, G1) Have you contributed any numbers to a forecast, even just as pipeline input to someone else's model?
3. (R7) Are you based within reach of Bristol for two office days a week?

Answer any or all of these, say skip to pass on one, or ask me to run the deeper research pass.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.