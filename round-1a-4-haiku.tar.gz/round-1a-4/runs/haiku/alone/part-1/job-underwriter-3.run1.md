## Decision: no-go as posted

Two of your hard constraints fail on the posting's own terms, so the role doesn't clear the bar regardless of how well your experience matches it.

- **Base pay:** the posted range tops out at $85k. Your floor is $150k. Equity doesn't close a base-salary gap, and the posting gives no equity figures.
- **Location:** on-site in Austin five days a week, "no exceptions," against remote-only from Portland. The "no exceptions" wording means a negotiation is unlikely to change it.

The feeling that something is off is pointing at a real pattern, not just the two gates. The posting asks for a Head-level leader with 8+ years, a team of one, every revenue function, evenings and weekends, and undefined success metrics, all for a $70–85k base. The scope and the pay don't line up, and the posting seems to expect you to absorb the difference.

**Fit, on its own ledger:** strong on the functions you've actually run. Paid, lifecycle, experimentation, SQL/GA4/Braze, team leadership, and the $8M to $40M ARR scale-up are all directly relevant. Five functions in the posting (SEO/content, brand, PR, partnerships, sales ops) don't appear in what you wrote. Those are gaps to confirm, not disqualifiers.

**Hard gates:** two failed (pay, location). These can't be fixed by how you present yourself.

## Role reality

- **Title and scope:** Head of Growth, reporting to the CEO with a dotted line to the board. Owns paid, SEO/content, lifecycle, brand, PR, partnerships and sales ops, starting as a team of one.
- **Pay:** $70–85k base plus equity. Stated in the posting, so `[grounded]`.
- **Market calibration:** not established. Research didn't run (see Evidence status), so I can't say whether $70–85k is low for this title and seniority. I'm not going to assert a market figure from memory.
- **Contradictions and tensions:**
  - 8+ years required, but a team of one and a $70–85k base for a Head title `[inferred]`.
  - "Profitable since day one" is a claim in the posting, not something verified `[grounded]`.
  - "Evenings and weekends when it matters is just who we are" is a stated culture expectation `[grounded]`.

## Evidence map

| # | Priority | Fit | Confidence | Gap | Requirement |
|---|---|---|---|---|---|
| 1 | must-have | meets | medium | none | Paid acquisition ownership (stated) |
| 2 | must-have | meets | medium | none | Lifecycle/CRM (Braze, stated) |
| 3 | must-have | meets | medium | none | Experimentation and ambiguity (stated) |
| 4 | must-have | meets | medium | none | 8+ years growth leadership (9 years, stated) |
| 5 | preferred | meets | medium | none | Team leadership (3–7 people, stated) |
| 6 | must-have | gap | low | discovery | SEO/content ownership |
| 7 | must-have | gap | low | discovery | Brand and PR |
| 8 | must-have | gap | low | discovery | Partnerships |
| 9 | must-have | gap | low | discovery | Sales ops |
| 10 | hard_gate | fails | high | hard-gate | On-site Austin, 5 days a week, no exceptions |
| 11 | hard_gate | fails | high | hard-gate | Base at least $150k (posted top is $85k) |

Confidence is medium on the stated evidence because nothing has been verified.

## Gap recovery queue

- **SEO/content, brand, PR, partnerships, sales ops:** if you've done any of these, even as part of a broader role, a concrete example (what you did, the result) would move the row from gap to meets. These gaps don't change the decision, because the hard gates already decide it.

## Opportunity risk register

| Class | Severity | Status | Risk |
|---|---|---|---|
| hard-gate mismatch | high | confirmed | Location: on-site five days a week versus remote-only |
| hard-gate mismatch | high | confirmed | Pay: posted range tops out at $85k versus your $150k floor |
| scope/pay mismatch | medium | inferred | Head title and 8+ years for a team of one at $70–85k base |
| hours expectation | medium | inferred | Evenings and weekends expected as standard |
| ambiguity | low | inferred | Success metrics "will evolve," so the bar may keep moving |
| failed attribution | medium | standing | Novaline's existence and funding are unverified (standing entry; see Evidence status) |

## Decision and what would change it

**No-go as posted.** To change this, both would have to be true: a remote arrangement from Portland and a base of at least $150k, confirmed in writing. The posting's "no exceptions" makes the location change unlikely, so I'd treat this as a pass unless the recruiter says otherwise.

## Application plan

Not recommended. If you want to test it anyway, ask the recruiter two direct questions, remote-eligibility and the base salary, before spending time on a CV. That isn't applying, and it answers both gates cheaply.

## Evidence status

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | unavailable | The search needed permission, which wasn't granted. Novaline's existence, stage and the live posting are unverified. |
| 2. Role-family pay and scope sweep | unavailable | Same permission block. The market calibration line is missing. |
| 3. Hiring manager footprint | n/a | No hiring manager was named. |

Because target 1 couldn't run, the employer's existence is not established, and the standing failed-attribution entry applies. The decision doesn't depend on it, since the gates fail either way.

## Upgrade menu

- **Allow web search:** I can verify Novaline exists, check for a live posting, and pull a role-family pay band to calibrate the $70–85k figure.
- **Share the live posting link** or Novaline's careers page, if you have them.
- **Share your CV** for a fuller evidence inventory. The fit read above is based only on your message.

## Questions

1. Would you consider this if the location were remote and the base were at least $150k, or are both firm for you?
2. Do you have a link to the live posting or Novaline's careers page?

Want me to save this as `tuesday-dossier.md`? It would capture this assessment for later use.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.