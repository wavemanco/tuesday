## Decision snapshot

**Worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear. Location (remote US or Denver) and your pay floor are not in your background, so the checks are not yet run.
- `must_have`: direct. 5+ years of data engineering, strong SQL and Python, dbt and a cloud warehouse (Snowflake), Airflow orchestration, data quality testing (Great Expectations).
- `important`: adjacent. BigQuery, which the posting body names as the warehouse. Unclear: ingestion from the app and CRM, and the data contracts analysts depend on.
- `preferred`: none stated in the posting.

**Opportunity ledger.** Sound, with no red flags. The posted $148,000–$166,000 range sits around the Datawright median of $151,000 and inside its interquartile range. The live careers page matches the JD word for word. The open questions are the equity value, whether BigQuery is a day-one requirement, and who owns ingestion and contracts.

- **Hard gates:** none failed. Unconfirmed: location and pay floor. Your constraints were not given, so checks against them are unknown.
- **Severe red flags:** none found. Nothing in the posting or the material asks you to pay, deposit, or give financial details.
- **Conditions for go:**
  1. Confirm your pay floor and location against the posting (Q1).
  2. Ask the recruiter whether BigQuery is required from day one or learnable, since the requirement itself says "a cloud warehouse" (RR2).
  3. Ask who owns ingestion and data contracts (Q2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 US states, founded 2016, Denver | `[grounded]` company About page, found by search |
| Scale and funding | 264 employees; Series C of $52M, February 2026 | `[grounded]` company's own About page only; no independent source found in search |
| Mandate | Build and run the pipelines behind tutoring-platform reporting: ingestion from app and CRM, a dbt warehouse on BigQuery, data contracts | `[grounded]` JD, identical on the careers page |
| Stack | dbt, BigQuery, Airflow or similar, data quality testing | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | One domain's pipelines plus contracts for analysts; normal for a senior title | `[generic]` Datawright scope norm: "ownership of one domain's pipelines with no direct reports" |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, IQR $139,000–$163,500; "senior" typically 5–8 years | `[generic]` Datawright 2026 pay report, n=2,310. Your six years sit in that band. |
| Pay comparison | Posted range midpoint is about $157,000, inside the IQR. The top, $166,000, is above its upper quartile. | `[grounded]` JD against `[generic]` band |
| Equity | Stated as "plus equity", with no value or grant terms | `[grounded]` JD: unstated |
| Hiring manager | Not named | `[grounded]` JD |
| Unknowns | Equity value; BigQuery as day-one or learnable; ingestion and contract ownership; hiring manager; your location and pay floor | — |
| Contradictions | None between the JD and the careers page | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: remote US or Denver | hard_gate | unclear | low | hard_gate | Your location is not in the material | `[grounded]` JD; your location not stated | Q1 |
| R2 | Pay: $148k–$166k against your floor | hard_gate | unclear | low | hard_gate | Your floor is not in the material | `[grounded]` JD range; floor not stated | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated in your background; CV-only, so a lead until artifacts | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake, stated. The requirement says "a cloud warehouse", which Snowflake meets. | `[grounded]` your background; JD wording | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, stated | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite, stated | `[grounded]` your background | none |
| R8 | BigQuery (named in the JD body) | important | adjacent | medium | transferability | No BigQuery use. The dbt modelling and warehouse work transfers. BigQuery-specific areas (partitioning, clustering, cost model, GCP IAM) are not covered. | `[inferred]` from your Snowflake and dbt work; no BigQuery use stated | G1 |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your background. Implied by the mandate. | `[grounded]` JD mandate; background silent | Q2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your background | `[grounded]` JD mandate; background silent | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake dbt work at about 180 models, no BigQuery use | The posting names BigQuery in its own body, so the recruiter will probably test it | Any GCP work, even partial; dbt project logic; warehouse cost work on Snowflake, which transfers in principle | A small dbt project on BigQuery in a sandbox, or a recruiter's statement that BigQuery is learnable | `[inferred]` transferability; `[generic]` that this is the likeliest interview probe |
| G2 | Ingestion and contracts (R9, R10) | discovery | Not in the material | These are the mandate's own duties, and the posting asks for neither by name | Ingestion from a SaaS API or a CRM; any analyst-facing schema or contract | A pipeline description or the project's scope note | `[grounded]` JD mandate |

The queue holds no questions. The questions for G1 and G2 are in the closing block, tagged by row.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity stated without value | unknown | — | "plus equity" | Equity may be modest or undefined at this stage; the total may be below the base-only comparison suggests | `[generic]` pattern for late-stage private companies | What is the equity grant size, vesting, and current valuation? | unresolved |
| RR2 | BigQuery named in the body, while the requirement says "a cloud warehouse" | unknown | — | "a dbt-modelled warehouse in BigQuery" against "dbt and a cloud warehouse" | BigQuery may be a current preference rather than a day-one need, or the posting may be loose | `[inferred]` from the JD's two phrasings | Is BigQuery required from day one, or would a strong Snowflake dbt engineer be expected to learn it? | unresolved |
| RR3 | Posted pay sits near the role-family median | positive_signal | — | "$148,000–$166,000" | Pay is stated and in range, so the comparison is clean | `[grounded]` JD; `[generic]` band | — | noted |
| RR4 | Live posting matches the JD | positive_signal | — | "Accepting applications" | The role is open and consistent with the advert | `[grounded]` careers page fetched | — | noted |
| RR5 | Company facts self-reported only | unknown | — | "Series C ($52M, February 2026)" | The funding and headcount are from the company's own page; independent confirmation was not found | `[grounded]` the company's own page; no third-party source | Can you point me at the funding announcement or a leadership contact? | unresolved |
| RR6 | No hiring manager named | unknown | — | none | Normal for this posting style; the manager's footprint would sharpen positioning | `[grounded]` JD | — | unresolved |

The standing "employer not established" entry is not raised. The employer's own careers and About pages are attributable, and the posting is live. RR5 records that the footprint is thin.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before applying, check your pay floor and location against the posting | R1, R2 hard gates | `[grounded]` rows R1, R2 | pending your approval |
| A2 | Ask the recruiter whether BigQuery is day-one or learnable, and whether equity has a stated value | RR1, RR2 | `[grounded]` register | pending your approval |
| A3 | Build a small dbt project on a BigQuery sandbox before the first technical screen | G1: turns a transferability gap into shown work | `[inferred]` from R8 | pending your approval |
| A4 | Lead with the Snowflake dbt and Great Expectations work, stated at its real scale | R5, R7; the most defensible story | `[grounded]` background | pending your approval |
| A5 | Prepare a plain account of ingestion and contract ownership in your current role | R9, R10, G2 | `[grounded]` JD mandate | pending your approval |

Every row is a proposal. Nothing goes outward until you approve it.

## Evidence status

Verified: none yet. Every claim above comes from your background as stated in this conversation, and no artifact has been checked.

Research tier: L1; searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searches "Pellucid Learning live online tutoring K-12 Denver" (no results) and "\"Pellucid Learning\" Series C funding" (returned pellucidlearning.com/about). Fetched pellucidlearning.com/careers/senior-data-engineer. Organization, live posting, and no contradiction with the JD. Funding and headcount rest on the company's own page alone. |
| 2. Role-family sweep | yes | Searched "Datawright 2026 Data Engineering Pay Report senior data engineer salary", which returned datawright.example/2026-data-engineering-pay-report. Market calibration and the pay comparison. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

## Upgrade menu

- A sandbox BigQuery dbt project, or any GCP work → G1 moves from transferability toward shown capability.
- Your pay floor and location → R1 and R2 close, and the decision is either `go` or `no_go`.
- The recruiter's answer on BigQuery and equity → RR1 and RR2 close.
- A description of ingestion or contract work → R9 and R10 move from unclear.
- The hiring manager's name → positioning for this reader.
- A deeper research pass on Pellucid Learning (funding, leadership, public employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you want, I can also write a dossier, `tuesday-dossier.md`, that carries this assessment forward.

**Questions**

1. **R1, R2:** What is your pay floor, and do you need Denver, or can you work remotely from the US? Answer in text, or say skip.
2. **R9, R10:** Have you owned ingestion from a CRM or product database, or defined data contracts with analysts, even in part? Answer in text, or say skip.
3. **G1:** Have you used GCP at all, even in a side project or a BigQuery-adjacent task at your payroll company? Answer in text, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.