**Yes, on conditions. `conditional_go`.** Your record covers the must-haves. The gaps are the pet-insurance domain, the decision rights and pay the posting doesn't state, and an employer I couldn't verify.

**Fit ledger.**

- `hard_gate` — unclear: R9 (fully remote, UK-based)
- `must_have` — direct: R1, R2, R3, R4, R6 · adjacent: R5 (build and monitor rating models for the pet product)
- `important` — adjacent: R7 (turn results into recommendations for product)
- `preferred` — direct: R8 (insurance experience)

R5 — a credible bridge from your motor GLM work, with the pet-specific limit named; R7 — the underwriting half is evidenced, the product half isn't.

**Opportunity ledger.** Authority (RR1), team and line management (RR2) and pay (RR3) are unstated. RR4 is the standing entry: the employer is unverified. RR5 runs the other way: the described work matches your record.

- **Hard gates:** none failed; unconfirmed: R9 (fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R9 holds: you're UK-based with the right to work here; (2) RR4 clears: the role appears on Brindlemoor's own careers site; (3) RR1 and RR2 come back as a role you'd take on.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` your JD |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations | `[grounded]` JD |
| First-year outcomes | None stated | `[inferred]` from the JD's silence |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Senior individual-contributor analytics role; no team described | `[inferred]` from the JD's wording |
| Market calibration | Not run. The role-family search was refused, so there is no scope or pay band | — |
| Unknowns | Decision rights, team and line management, pay, company stage | — |
| Contradictions | None; only the JD was provided | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years' pricing analytics, two as senior analyst. Years are not a gate, so this is graded on fit | `[grounded]` your statement | Share a CV to confirm dates |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both | `[grounded]` your statement | Share a query or script sample |
| R3 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model for the young-driver book. The method transfers; the book is motor | `[grounded]` your statement | None |
| R4 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your statement | None |
| R5 | Build and monitor rating models for the pet product | must_have | adjacent | medium | transferability | Motor GLM build and maintenance is the bridge. Limit: no pet rating work; pet-specific factors aren't in your account | `[inferred]` from R3; `[generic]` that pet risk factors differ from motor | Closing question Q3 |
| R6 | Design and read price tests | must_have | direct | medium | none | 14 price tests last year, run with the underwriting team | `[grounded]` your statement | None |
| R7 | Turn results into recommendations for underwriting and product | important | adjacent | medium | transferability | Underwriting recommendations are evidenced; product recommendations aren't | `[grounded]` your statement; `[inferred]` on the product half | Gap queue G2 |
| R8 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your statement | None |
| R9 | Fully remote, UK-based | hard_gate | unclear | low | hard_gate | Your location and right to work weren't given. A UK motor insurer suggests UK employment but doesn't establish it | `[grounded]` JD; `[inferred]` from your employer's location | Closing question Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance rating (R5, must_have) | transferability | Motor GLM work; no pet or other non-motor rating | The likeliest objection in the interview | Any non-motor pricing review, spike, or peer check; any rating-factor work where breed, species or vet costs came up | A sanitised model-documentation extract, or a review note | `[inferred]` bridge from R3; `[generic]` that this is the likeliest objection |
| G2 | Product-side recommendations (R7, important) | transferability | Underwriting recommendations evidenced; product ones not | Product owns part of what the role recommends to | Any recommendation that changed a product feature, cover limit or pricing structure | A short readout from a price test | `[inferred]` from the JD's pairing of underwriting and product |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Decision rights unstated | unknown | — | "Own pricing analytics … turn the results into recommendations" | You may recommend while rate and product decisions sit with the Director of Pricing or a committee | `[inferred]` from "recommendations" against silence on decision rights | Which rate and product decisions does this role make itself, and which go to the Director or a committee? | unresolved |
| RR2 | Team and line management unstated | unknown | — | "Senior Pricing Analyst" | The role may carry people responsibilities you haven't held | `[inferred]` from the absence of team detail | Does this role line-manage anyone, and who would I report to day to day? | unresolved |
| RR3 | Pay not stated | unknown | — | No salary in the JD | Pay may be withheld until interview; no band has been checked | `[inferred]` from the JD's silence | What is the base salary range and bonus structure for this role? | unresolved |
| RR4 | Employer not established | risk_signal | medium | "Brindlemoor (insurtech)" | Possible reasons, none ranked: the company is too new or small to have a footprint, the posting is stale or aggregated, or it isn't a real hiring employer. Research didn't run, so this is unverified rather than disproved | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the live role on your own careers site, and who would I be interviewing with? | unresolved |
| RR5 | Concrete, matching scope | positive_signal | — | "build and monitor rating models … design and read price tests" | The described work matches your record: GLMs, price tests and a standing review to underwriting | `[grounded]` JD against your statement | What would a strong first year look like, and how are results judged? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your location and right to work before you apply | R9 | `[grounded]` gate row | pending your approval |
| A2 | Verify Brindlemoor and the live posting on its own careers site, then send me the link | RR4 | `[generic]` pattern | pending your approval |
| A3 | Lead with the 14 price tests and the GLM build. Say plainly that you haven't priced pet insurance, and name the bridge yourself | R5, R6 | `[grounded]` R5, R6 | pending your approval |
| A4 | Ask RR1, RR2 and RR3 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on your statement and the JD.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches were sent and each was refused, so nothing returned. It would have verified RR4 and checked the JD against the careers page |
| 2. Role-family sweep | unavailable | The same refusals. It would have set the scope and pay band for RR3 and the market calibration line |
| 3. Hiring manager's public footprint | unavailable | No search was sent. Odile Varga's name is given, so the query could be formed. It would have shown which story to lead with for this reader |

## Upgrade menu

- Permission to run web search. If you grant it, I'll retry the Brindlemoor and role-family checks: this closes RR4, gives a pay band for RR3, and sets the scope read.
- The live posting link, or the careers page. This closes RR4 and checks the JD against the careers page.
- A CV. This confirms R1's dates and firms up R2 and R3.
- Any non-motor pricing or rating work, even a spike or review. This moves R5 toward direct.
- A deeper pass on Brindlemoor: funding, leadership changes, reviews. It is available once, at up to 5 more searches and 2 more fetches.

Would you like this assessment saved as `tuesday-dossier.md` for later use?

Closing questions. Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**R9** — Are you based in the UK, with the right to work here without sponsorship?

**RR1** — Does this role set rate and product decisions itself, or recommend them to the Director of Pricing or a committee?

**G1 (R5)** — Have you done any non-motor or pet rating work, even a review, spike or peer check? If not, what do you already know about how pet risk differs from motor?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.