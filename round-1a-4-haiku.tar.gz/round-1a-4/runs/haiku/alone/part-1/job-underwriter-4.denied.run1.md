**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (UK-based, fully remote, right to work)
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: adjacent: R8 (pet-insurance pricing)
- `preferred`: direct: R9 (insurance experience)

R8 is the one real gap, and it is a domain gap, not a capability gap. R1 is unconfirmed, not failed.

**Opportunity ledger.** The posting is clear about scope: build and monitor rating models, design and read price tests, and turn results into recommendations. Its outcomes are stated, but the pay is withheld, and the people-management expectation is unstated.

- **Hard gates:** none failed; unconfirmed: R1 (UK-based, fully remote, right to work); candidate location and right to work not given, so checks against them are unknown.
- **Severe red flags:** none found. Not checked this run: whether Brindlemoor exists as described, and whether the posting is live (search was refused).
- **Conditions for go:** (1) confirm R1; (2) confirm the company and posting are real, via the live posting link or the recruiter's email domain (RR1); (3) confirm whether the role manages people (RR3); (4) present the pet-insurance gap as adjacent, never as direct experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` JD |
| Mandate | Own pricing analytics for one pet-insurance product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD |
| Outcomes | None stated beyond the mandate | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | One product, with pricing analytics owned end to end. This suggests a small team, possibly building from early stage. | `[inferred]` from "own ... for our ... product" against the absence of team size |
| Market calibration | Not checked: the role-family sweep was refused. No band is given here. | — |
| Compensation | Withheld; "salary on application" is not in the JD, so it is unstated | `[grounded]` JD silence |
| Unknowns | Company stage and existence, team size, people management, pay, pricing-model maturity, hiring manager's background | — |
| Contradictions | None found within the JD. Not checked against a careers page. | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | UK-based, fully remote, right to work | hard_gate | unclear | low | hard_gate | Remote UK is the posting's term. Renata's location and right to work were not stated. | `[grounded]` JD; candidate not stated | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in UK motor pricing analytics, the last two as senior analyst. Stated, no artifact yet. | `[grounded]` user-stated background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Used daily. Stated, no artifact yet. | `[grounded]` user-stated background | a sanitized query or script would raise this to high |
| R4 | Build and monitor rating models; GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM rating model. Covers both build and monitor. | `[grounded]` user-stated background | a sanitized model-monitoring pack would raise this to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting. | `[grounded]` user-stated background | none |
| R6 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team. | `[grounded]` user-stated background | a test readout would raise this to high |
| R8 | Pet-insurance pricing (product-specific) | important | adjacent | medium | transferability | Pricing a non-motor product carries over: GLM rating, test design, and the underwriting dialogue. It does not carry over the pet-specific drivers, such as species, breed, vet-cost severity, and lifetime-versus-annual claims. | `[inferred]` from the overlap between motor and pet pricing | G1 |
| R9 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer. Covers the "insurance experience" plus. | `[grounded]` user-stated background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance pricing (R8, important) | transferability | Motor pricing work with GLMs, price tests and underwriting presentations. No pet, health or lifetime-cover pricing. | Important, and the most likely objection in interview. Adjacency narrows it; it does not close it. | Any pricing work on a non-motor or multi-cover product; any analysis of claim-frequency or severity drivers that were not motor-specific; any product-design input into a new product | A pricing memo or test readout from a non-motor project, even partly sanitized | `[inferred]` bridge from the motor-to-pet overlap; `[generic]` that pet-specific drivers are the likeliest objection |

The question that would close G1 is in the closing block, tagged G1.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Company existence and posting status not checked | unknown | — | — | The employer could be an early-stage company, a stale posting, or a real hiring employer; this run cannot tell which | `[inferred]` from search refusal | Q3 | unresolved |
| RR2 | Pay withheld | unknown | — | "salary on application" | The figure may sit below the candidate's floor, or the company may simply not publish pay | `[inferred]` from the posting's silence | Ask the recruiter for the budgeted band before the loop | unresolved |
| RR3 | Line-management expectation not stated | unknown | — | "Senior Pricing Analyst"; "own pricing analytics" | The role may be individual-contributor, or it may expect leading a team; Renata has never managed anyone | `[inferred]` from the silence against the title | Q2 | unresolved |
| RR4 | Single-product, likely small pricing function | risk_signal | medium | "our pet-insurance product" | The role may build the pricing function from scratch, with thin data, a small team, and few peers | `[inferred]` from the single-product scope | Ask how many pricing staff sit under this role and what data exists for the product | unresolved |
| RR5 | Explicit scope | positive_signal | — | "build and monitor rating models... design and read price tests... turn results into recommendations" | The role is genuinely defined and matches Renata's core work | `[grounded]` JD | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with R4, R5 and R6, the direct matches, then frame R8 as adjacent with its limit named | Keeps the strongest evidence first and the gap honest | `[grounded]` R4, R5, R6, R8 rows | pending your approval |
| P2 | Ask the recruiter for the budgeted pay band and whether the role has direct reports | Closes RR2 and RR3 before investing in the loop | `[grounded]` RR2, RR3 | pending your approval |
| P3 | Verify the company and posting before applying | Closes RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet. Renata's background is user-stated; no CV or artifact has been checked.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would have checked company existence, stage and whether the posting is live (RR1). Four searches were refused, so this target was not reached. |
| 2. Role-family sweep | unavailable | Would have set a market band for pay and scope (RR2, market calibration). |
| 3. Hiring manager's public footprint | unavailable | Would have shown Odile Varga's public background, to shape the positioning. Name was given, so this is not `n/a`. |

## Upgrade menu

- A live posting link or the recruiter's email domain → RR1 can be checked, and the company research target can run.
- A search permission grant → the three targets above can run, starting with company existence and the pay band.
- A pet, health or lifetime-cover pricing example, even partly sanitized → R8 moves from adjacent toward direct, and G1 closes.
- A sanitized model-monitoring pack, SQL or Python sample, or test readout → R3, R4 and R6 move from medium to high.

Would you like me to build the full dossier file from this? It is one sentence: I can emit `tuesday-dossier.md` so you can keep this assessment and carry it into any later recovery turn.

**Questions**

**R1** — Are you UK-based, with the right to work in the UK, and is fully remote working from the UK workable for you?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**RR3** — Does this role line-manage anyone, or is it an individual-contributor role?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**RR1** — Can you send the live posting link or the recruiter's email domain, so the company and posting can be checked?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.