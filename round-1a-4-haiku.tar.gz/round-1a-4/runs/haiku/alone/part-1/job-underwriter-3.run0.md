**Decision: no_go as posted.** Two hard gates fail on their own, and no framing changes either one. Your core experience fits the role well, but this posting doesn't meet your two constraints. Fit and opportunity are scored separately below.

**Decision snapshot**

- **Candidate fit, by priority:**
  - Must-have, strong: paid acquisition, lifecycle/CRM, experimentation, SQL/GA4/Braze, 8+ years growth leadership, team management (3–7).
  - Must-have, not evidenced: SEO/content, brand, PR, partnerships, sales ops.
  - Implied, unknown: thriving on ambiguity, "team of one" scope.
- **Hard gates:** FAILED: base pay ($70–85k vs your $150k floor, $65–80k short). FAILED: on-site Austin 5 days, "no exceptions", vs remote-only from Portland.
- **Opportunity:** conditional on verification. The company's existence is unconfirmed (see risk register). Scope and pay don't match the title.
- **What would change the decision:** base of at least $150k and remote-eligible from Portland, plus a verified employer.

**Role reality** [grounded from the JD unless marked]

- Title: Head of Growth. Organization: Novaline, e-commerce enablement, Series A, "profitable since day one" (unverified claim).
- Scope: seven functions (paid, SEO/content, lifecycle, brand, PR, partnerships, sales ops), one person to start, reporting to the CEO with a dotted line to the board.
- Pay: $70–85k base plus unquantified "meaningful equity".
- Schedule: evenings and weekends "when it matters"; Austin on-site 5 days/week.
- Market calibration: not established. Research was denied, so I can't give a role-family pay or scope band. Treat any pay comparison as open until we have data.
- Contradiction: "Head of Growth" with "team of one" covering seven functions at this pay is internally inconsistent [inferred].

**Evidence map** (candidate-stated unless noted)

| # | Priority | Fit | Confidence | Gap | Requirement / evidence |
|---|---|---|---|---|---|
| 1 | Hard gate | Fails | high | hard-gate | Base pay $70–85k vs $150k floor [grounded] |
| 2 | Hard gate | Fails | high | hard-gate | Austin on-site 5 days vs remote-only Portland [grounded] |
| 3 | Must-have | Meets | medium | none | 8+ years growth leadership: 9 years, growth lead then Head of Growth at two B2C subscription companies |
| 4 | Must-have | Meets | medium | none | Paid acquisition, lifecycle/CRM, experimentation owned |
| 5 | Must-have | Meets | medium | none | SQL, GA4, Braze |
| 6 | Must-have | Meets | medium | none | Scaled one company $8M→$40M ARR over three years with a budget he controlled |
| 7 | Must-have | Unevidenced | low | capability or discovery | SEO/content, brand, PR, partnerships, sales ops: not in your inventory |
| 8 | Implied | Unknown | low | discovery | "Thrives on ambiguity": no evidence either way in what you shared |
| 9 | Stated | Unknown | low | hard-gate (pending) | Equity: "meaningful", unquantified |

Verifiability: rows 3–6 rest on your own account. Reference checks or public records would raise them.

**Gap recovery queue**

- Row 7 closes with a concrete example of SEO, PR, or partnerships work, even informal, with an outcome.
- Row 8 closes with one example of a period with unclear goals and what you did.
- Row 9 closes with the equity terms (percentage, vesting, strike price) if the employer ever gets past the hard gates.

**Opportunity risk register**

- **Failed attribution (standing, medium):** research was denied, so I could not confirm Novaline exists as described. Candidate reasons, none ranked as likely: too new or small, a stale posting, or not a real hiring employer. This caps any `go` at `conditional_go` until verified. To resolve: the live posting link, Novaline's own careers page, or the recruiter's email domain.
- **Pay mismatch (medium):** $70–85k base against a Head of Growth title and a seven-function scope [grounded JD vs inferred scope].
- **Scope/title mismatch (medium) [inferred]:** the role as written looks more like a generalist or individual-contributor job with a senior title, or a budget that doesn't match the ask.
- **Schedule and location (high, hard gate):** on-site "no exceptions" plus evenings and weekends.
- **Vague success criteria (low):** "success metrics will evolve as we learn."

**Application plan**

Don't apply as posted. If Novaline confirms a remote-from-Portland option and a base of at least $150k, and the employer verifies, re-underwrite; the plan would then be a targeted application leading with paid, lifecycle, and the $8M→$40M scale story. Any CV or outreach language would need your approval first.

**Evidence status**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Novaline official site and careers page | unavailable | Search permission denied |
| 2 | Role-family sweep (title, scope, pay band) | unavailable | Search permission denied |
| 3 | Hiring manager footprint | skipped | No name given |

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

**Dossier offer:** If you'd like, I can write a `tuesday-dossier.md` capturing this assessment for later use.

**Upgrade menu**

- Live posting link or recruiter's email domain: resolves the failed-attribution entry.
- Granting search permission: lets me run the company check and the pay-band sweep (up to 5 searches and 2 fetches).
- Equity terms, if the role ever passes the hard gates.
- A concrete example for SEO, PR, or partnerships: raises row 7.

**Questions**

1. Would Novaline consider remote work from Portland, or is "no exceptions" literal? *(hard gate; rows 1–2)*
2. Can you paste the live posting link or the recruiter's email domain? *(failed attribution)*
3. Have you run SEO, PR, or partnerships work yourself, even informally, with any outcome? *(row 7)*

Reply in prose or skip any question; skipping is an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.