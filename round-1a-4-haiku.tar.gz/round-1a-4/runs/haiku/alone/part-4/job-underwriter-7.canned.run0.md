## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**
- `hard_gate`: direct: R1, R2 (both stated by you, not checked)
- `must_have`: direct: R3 · unclear: R4
- `important`: direct: R5, R7, R9, R13 · adjacent: R6, R11, R12 · unclear: R8, R10
- `preferred`: absent: R14

R3 (`high`) is your strongest row. R12 (`medium`, adjacent) is the one most likely to come up at interview.

**Opportunity ledger.** Sound. The employer exists as described, the pay is stated, and I found no severe red flags. The posting itself could not be confirmed live (RR4), and caseload support is unstated (RR2).

- **Hard gates:** none failed. Met as stated: R1 and R2 (`direct`, `medium`). You check both yourself: your NMC register entry and your driving record.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You confirm your NMC registration and licence against your own records.
  2. The posting is confirmed live, through the employer's careers page or the recruiter's link (RR4).
  3. At the informal chat, you learn what caseload support a new community nurse gets (RR2, R12).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff; four locality hubs | `[grounded]` calderbrookhealth.example/about |
| Mandate | District nursing for housebound adults in their own homes; hold a small caseload with senior community nurse support | `[grounded]` JD |
| Scope read | A normal-scope Band 5 caseload with supervision | `[inferred]` from "small caseload" and "supported by a senior community nurse" |
| Pay | £31,050–£37,800 a year, plus mileage; pool cars provided | `[grounded]` JD |
| Market calibration | Wardround 2026 survey (England, n=1,240) for Band 5 community staff nurses: median £34,300, interquartile range £32,400–£36,600; 61% paid mileage | `[generic]` role-family sweep, not a claim about this employer's offer |
| Named contact | Rhiannon Mabbott, Community Nursing Team Lead; leads the Halifax district nursing team after eleven years as a district nurse | `[grounded]` communitynursingforum.example speaker profile (professional footprint only) |
| Unknowns | Caseload size; out-of-hours or on-call expectations; whether Doppler training is provided; which electronic record is used | — |
| Contradictions | None found between the JD and the about page. The careers page I tried did not load, so the posting's liveness is unconfirmed | `[grounded]` fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | Stated active. Nothing inspected here; the register entry is the artifact | `[grounded]` user-stated | You check your register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated, category B. Pool cars are provided, so this term is required | `[grounded]` user-stated | You check your licence and driving record |
| R3 | At least one year post-registration experience | must_have | direct | high | none | Five years as a staff nurse on an acute medical ward | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | CV says nothing about documentation or the electronic record used | `[grounded]` CV silence | Q1 |
| R5 | Wound care: pressure ulcers and surgical wounds | important | direct | medium | none | Stated on the CV; no artifact | `[grounded]` CV | none |
| R6 | Leg-ulcer wound care | important | adjacent | medium | transferability | Wound care is established, but leg ulcers are not named. Limit: no venous or arterial leg-ulcer management stated | `[inferred]` from R5 | see G5 |
| R7 | Catheter and continence care: catheter | important | direct | medium | none | Catheter care stated on the CV | `[grounded]` CV | none |
| R8 | Continence care | important | unclear | low | discovery | Only catheter care is stated | `[grounded]` CV silence | none (upgrade menu) |
| R9 | Insulin administration | important | direct | medium | none | Stated on the CV | `[grounded]` CV | none |
| R10 | End-of-life visits | important | unclear | low | discovery | Not on the CV | `[grounded]` CV silence | Q3 |
| R11 | Care planning | important | adjacent | medium | transferability | Discharge planning for first-week needs. Limit: not ongoing care planning over months | `[inferred]` from the home-visit role | none |
| R12 | Own small caseload with senior support | important | adjacent | medium | transferability | Home visits in the first week after discharge. Limit: no caseload you held over time | `[inferred]` from the CV | see G2 |
| R13 | Home-based work with housebound adults | important | direct | medium | none | 18 months of home visits | `[grounded]` CV | none |
| R14 | Doppler assessment for leg ulcers | preferred | absent | none | capability | Not on the CV | `[grounded]` CV silence | see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | No documentation or electronic-record detail on the CV | An essential term, and the posting weights it | Notes on the ward or in discharge-to-assess visits; any electronic record used; any audit of your notes | A redacted note, a record-system name, or an audit or feedback letter | `[grounded]` CV silence |
| G2 | Own caseload (R12, important) | transferability | Home visits in the first week, not a caseload you held | The posting names it; it is the likeliest interview probe | Patient lists you were responsible for after a first visit, even briefly | A caseload or handover record | `[inferred]` |
| G3 | End-of-life visits (R10, important) | discovery | Not on the CV | A listed duty; you may have experience from the ward | Deaths on the ward you cared for; discharge or home planning for dying patients | A short description or a reference | `[grounded]` CV silence |
| G4 | Doppler (R14, preferred) | capability | Absent | Desirable only, so a minor risk. Closure path: formal Doppler training | A talk by the team lead covered Doppler training for staff new to community work | Ask whether the employer provides it | `[inferred]` from the speaker profile's topic list |
| G5 | Leg-ulcer care (R6, important) | transferability | Wound care is stated; leg ulcers are not | Leg ulcers are named in the posting's core duties | Any leg-ulcer dressing or review you did on the ward | A wound-care training record or a sanitized case note | `[grounded]` CV and JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, with mileage | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The band spans the survey's interquartile range; mileage is common | `[generic]` survey; `[grounded]` posting | — | noted |
| RR2 | Caseload support unstated | risk_signal | medium | "hold a small caseload of your own, supported by a senior community nurse" | Early months may be heavily supervised, or the caseload may build quickly | `[inferred]` from the posting's silence on supervision | see Q2 | unresolved |
| RR3 | Employer confirmed as a real CIC | positive_signal | — | "410 staff working from four locality hubs" | Established employer with an NHS contract | `[grounded]` about page | — | noted |
| RR4 | Posting not confirmed live | unknown | — | Careers page URL returned no page | The posting may have closed, or the link may be incorrect | `[grounded]` fetch result | Send the live link | unresolved |
| RR5 | Doppler training may be offered | positive_signal | — | Talk title "Doppler training for staff new to community work" | Training may be available for a Doppler gap | `[inferred]` from a conference talk title | see G4 | unresolved |

The standing failed-attribution entry does not apply: the employer is confirmed. The posting, RR4, is the open item.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV summary with "visiting patients at home in their first week after discharge" in your own words | R13 is direct; the home-visit line is your strongest community evidence | `[grounded]` CV | res436_edits_pending_approval |
| E2 | Name your record system in one line, only once you confirm it (answer to Q1) | R4 | `[grounded]` CV silence; the answer is needed first | pending your answer |
| A1 | Ask the team lead at the informal chat about caseload size, supervision and Doppler training | RR2, R14, RR5 | `[grounded]` posting | pending your approval |
| A2 | Ask the recruiter or employer for the live posting link before applying | RR4 | `[grounded]` | pending your approval |

Every row is proposed. Nothing is applied until you approve it.

## Evidence status

Verified: none yet. R1, R2, and R13 are stated by you, not checked. The other CV claims are self-reported.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health Community Staff Nurse Band 5 district nursing careers". Fetched calderbrookhealth.example/about ("About Calderbrook Community Health"), which confirmed the employer. Fetched calderbrookhealth.example/careers, which returned no page, so RR4 stays open |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary UK", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Feeds the market calibration and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned the speaker profile at communitynursingforum.example/speakers/rhiannon-mabbott. Feeds the application plan (A1) and RR5 |

## Dossier offer

If you want, I can write this up as `tuesday-dossier.md`.

## Upgrade menu

- Your electronic record system and one redacted note, or an audit letter → R4 `high` candidate; G1 closes.
- A caseload or handover record, even from a short period → R12 raises; RR2 narrows.
- Any leg-ulcer training record or a sanitized case note → R6 raises.
- The live posting link, from the careers page or the recruiter → RR4 closes.
- A deeper research pass on Calderbrook Community Health (leadership changes, recent CQC or NHS contract reports, staff reviews; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

Q1 (R4): In your staff nurse and discharge-to-assess roles, which electronic record did you write notes in, and how were your notes checked or audited?

Q2 (RR2): In the discharge-to-assess role, did you keep a patient list you were responsible for after the first visit, and what happened when a plan needed follow-up?

Q3 (R10): Have you been involved in end-of-life care at home or on the ward, and what did your part involve?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.