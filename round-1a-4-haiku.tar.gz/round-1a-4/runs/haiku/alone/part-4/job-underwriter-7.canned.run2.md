## Decision snapshot

**Worth applying for. Status: `go`.** Apply, after checking that the posting is still live on the employer's careers page (see RR1).

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R8 (see the fit table below). Adjacent: none. Unclear: R4
- `important`: direct: R8. Adjacent: R5, R6, R7, R9. Unclear: R10
- `preferred`: absent: R11

R5 is the largest gap that matters, and it is a transferability gap. R11 (Doppler) is a desirable item you have not done. Neither blocks an application.

- **Hard gates:** none failed. Stated and unchecked by me: R1 (NMC registration), R2 (driving licence). Please check both yourself.
- **Severe red flags:** none found.
- **Conditions for go:** confirm the vacancy is live on the careers page; do not claim caseload or Doppler experience in any application or interview.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, a community interest company running adult community nursing across Calderdale under an NHS contract, with 410 staff across four locality hubs | `[grounded]` employer's about page |
| Role | Community Staff Nurse, Band 5: district nursing for housebound adults, with a small personal caseload supported by a senior community nurse | `[grounded]` advert |
| Duties | Wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration, care planning, EPR documentation | `[grounded]` advert |
| Working pattern | Home visits, pool cars provided, mileage paid | `[grounded]` advert |
| Pay | £31,050–£37,800 a year plus mileage | `[grounded]` advert |
| Market calibration | Community staff nurse, Band 5, England: median basic pay about £34,300, interquartile range £32,400–£36,600. The advertised range sits across most of that band | `[generic]` Wardround 2026 community nursing pay guide (wardround.example/2026-uk-community-nursing-pay-guide, n=1,240) |
| Entity check | Exists as described: a CIC on an NHS contract, founded 2015 | `[grounded]` about page |
| Unknowns | Caseload size; the level of clinical autonomy; the record system; end-of-life and Doppler support or training; whether the posting is live | — |
| Contradictions | None found between the advert and the about page | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | PIN and active status stated; not checked | `[grounded]` CV, stated | You check the NMC register under your own PIN |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B stated; pool cars mean the licence is what counts | `[grounded]` CV, stated | You confirm the licence is current |
| R3 | At least one year post-registration experience | must_have | direct | high | none | Five years as a staff nurse on an acute medical ward | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | The CV is silent on record-keeping and the EPR system. Home visits after discharge imply documented notes, which is not the same thing | `[inferred]` from the discharge visits | Question G4 |
| R5 | Own small caseload | important | adjacent | medium | transferability | Visited patients alone at home in the first week after discharge. Never held a caseload, and the level of decision-making she had is unstated | `[inferred]` from the discharge-to-assess role | Question G1 |
| R6 | Wound care, including leg ulcers | important | adjacent | medium | transferability | Pressure ulcers and surgical wounds are direct. Leg ulcers are not stated | `[grounded]` wound work; `[inferred]` transfer to leg ulcers | Gap queue G2 |
| R7 | Catheter and continence care | important | adjacent | medium | transferability | Catheter care is direct. Continence assessment is not stated | `[grounded]` catheter care; continence not stated | Gap queue G2 |
| R8 | Insulin administration | important | direct | high | none | Stated in the CV | `[grounded]` CV | none |
| R9 | Care planning | important | adjacent | medium | transferability | Discharge planning is adjacent. Community-based care planning is not stated | `[inferred]` | Discuss at the informal chat |
| R10 | End-of-life visits | important | unclear | low | discovery | Not in the CV, so not yet established | `[grounded]` CV silence | Gap queue G3 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | low | capability | No evidence. It is a desirable item, not a requirement | `[grounded]` CV silence | Closure path in gap queue G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload (R5, important) | transferability | Home visits after discharge, with autonomy unstated | Caseload is the main change for you; the bridge needs a stated limit | Any visit where you chose the dressing, decided on a catheter change, or adjusted insulin on your own judgment | A visit summary showing the number of visits per week and the decisions you made | `[inferred]` bridge from the discharge-to-assess role |
| G2 | Leg ulcers and Doppler (R6, R11) | transferability, then capability | Wound care is direct; leg ulcers and Doppler are absent | Leg ulcers are core to the role. Doppler is desirable | Compression or leg-ulcer dressings within your wound work. Doppler has no evidence yet | A Doppler course or booking, if you are willing to take one | `[grounded]` CV; `[inferred]` closure path |
| G3 | End-of-life visits (R10, important) | discovery | Not in the CV | Named in the duties, so it needs a clear answer | Any palliative or end-of-life care you have given at home or on the ward | A brief description of the palliative care you have given | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting live status not verified | unknown | — | "For an informal chat… contact Rhiannon Mabbott" | The advert may be stale; the careers page was not fetched | `[inferred]` from the research tier | Is the vacancy listed on the careers page now? | unresolved |
| RR2 | Pay sits within the Band 5 range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The offer should land in a normal band-5 position | `[generic]` band vs `[grounded]` advert | none needed | noted |
| RR3 | Caseload size not stated | unknown | — | "a small caseload" | The number of patients may matter as much as the title | `[inferred]` | Ask Rhiannon at the informal chat | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the discharge-to-assess home visits, then wound, catheter and insulin care, all as direct experience | Those are your strongest matches to the duties | `[grounded]` CV | pending your approval |
| P2 | State leg ulcers and Doppler as not yet done, and say you would train for them | Stating this is safer than implying experience | `[grounded]` R6, R11 | pending your approval |
| P3 | Use the informal chat with Rhiannon to ask about caseload size, clinical support, EPR, end-of-life work and Doppler training | Each question is a risk or gap from this assessment | `[inferred]` from RR3, G2, G3 | pending your approval |
| P4 | Check the posting on the careers page before you apply | RR1 is open | `[grounded]` RR1 | pending your approval |

Every proposed phrase above keeps to what your CV says. Do not describe the discharge visits as "managing a caseload", and do not describe any leg-ulcer or Doppler work as done.

## Evidence status

Verified: none yet. Employer existence is verified from its published about page; your CV claims are stated and not yet checked.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC community staff nurse Band 5 jobs"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). Confirmed the entity; the careers page was not fetched, so RR1 stays open |
| 2. Role-family sweep | yes | Searched "NHS Agenda for Change Band 5 pay scale 2026 community nurse", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration line and RR2 |
| 3. Hiring manager's public footprint | unavailable | Not run. The named person is a team lead for an informal chat, not a confirmed hiring manager. It would only move positioning |

## Upgrade menu

- A visit summary from the discharge-to-assess role (visits per week, decisions you made alone) → R5 to `high`, and G1 closes.
- The name of the EPR system you used, with a sanitised example note → R4 to `high`.
- A Doppler course booking or certificate → R11 moves from absent to a stated closure path.
- The careers page link to the live posting → RR1 closes.
- A deeper research pass on Calderbrook (inspection reports, staffing, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want this assessment kept for later, I can write it to a `tuesday-dossier.md` file.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G1 — In your discharge-to-assess visits, did you make the clinical decisions on your own (choosing dressings, deciding on a catheter change, adjusting insulin), and roughly how many patients did you see in a week?

G4 — Which electronic record system have you written visit notes on, and how did you keep them up to date during a shift?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.