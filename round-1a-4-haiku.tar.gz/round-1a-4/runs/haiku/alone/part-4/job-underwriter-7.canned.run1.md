**Yes, it's worth applying for, on conditions.** Status: `conditional_go`. Your gates look met on your own statements, the fit is real but adjacent in places, and the posting itself is not yet confirmed.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R1, R2, R3
- `must_have`: direct: R4, R5a, R7; adjacent: R6 (wound and leg-ulcer care), R8 (caseload and care planning); unclear: R5b (continence care), R10 (clear, timely written records)
- `important`: adjacent: R12 (home-based community nursing); unclear: R9 (end-of-life visits)
- `preferred`: absent: R11 (Doppler assessment)

R8 — a real gap, carried as a limit; R6 — wound work carries over, leg-ulcer assessment not yet evidenced; R11 (`absent`) — a closure path, not a blocker.

**Opportunity ledger.** Pay and employer are sound and transparent (RR4, RR5, RR6). The posting and contract basis are not yet confirmed: RR1 and RR2 are unknowns to close, and RR3 (caseload size) is one to ask about.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:**
  1. Your NMC register entry and licence check out (R1, R2). This is your check to run.
  2. RR1 and RR2 close: the post is live on the careers page and its contract basis is one you can accept.
  3. The application presents caseload and Doppler as gaps with a closure path, not as experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, Calderdale; founded 2015, 410 staff, adult community nursing under an NHS contract | `[grounded]` calderbrookhealth.example/about |
| Mandate | Housebound adults at home: wounds and leg ulcers, catheter and continence, end-of-life, insulin, care planning, on an EPR | `[grounded]` JD |
| Scope read | A caseload role with senior support, not a team lead post | `[inferred]` from "hold a small caseload, supported by a senior community nurse" |
| Pay | £31,050–£37,800 plus mileage, stated | `[grounded]` JD |
| Market calibration | Survey of 1,240 community Band 5 staff in England, 2026: median £34,300, interquartile range £32,400–£36,600; 61% paid mileage. The stated range sits around that median | `[generic]` Wardround 2026 UK Community Nursing Pay Guide (wardround.example) |
| Working pattern | Home-based visits; pool cars provided | `[grounded]` JD |
| Contact | Rhiannon Mabbott leads the Halifax district nursing team; public speaker profile | `[grounded]` communitynursingforum.example speaker page |
| Unknowns | Caseload size, contract basis, EPR system, end-of-life workload, whether the post is live | — |
| Contradictions | None found between the JD and the employer's About page. The careers page the About page names returned no page at calderbrookhealth.example/careers, so the post is unconfirmed, not contradicted | `[grounded]` fetch results |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Stated on CV: PIN, active, revalidation March 2028. Self-report, so the register check is yours | `[grounded]` CV | Check your NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B stated, not checked; pool cars mean the licence is the gate | `[grounded]` CV | Confirm licence status yourself |
| R3 | Based in Halifax | hard_gate | direct | medium | none | You live in Halifax and the post is in Halifax | `[grounded]` CV, JD | none |
| R4 | At least one year post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length requirement, not a gate | `[grounded]` CV | none |
| R5a | Catheter care | must_have | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R5b | Continence care | must_have | unclear | low | discovery | Not on CV; catheter care does not establish it | `[grounded]` CV silence | Ask G3 |
| R6 | Wound care, including leg-ulcer care | must_have | adjacent | medium | transferability | Pressure ulcers and surgical wounds stated; leg ulcers not. The wound skill carries over; leg-ulcer assessment is the limit | `[grounded]` CV; `[inferred]` that wound skill transfers | Ask G2 |
| R7 | Insulin administration | must_have | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R8 | Holding a caseload and care planning | must_have | adjacent | medium | transferability | Discharge-to-assess visits involved planning first-week needs at home. You have never held an ongoing caseload, which is the limit | `[grounded]` CV; `[inferred]` that discharge planning carries to caseload work | Ask G1 |
| R9 | End-of-life visits | important | unclear | low | discovery | Not on CV | `[grounded]` CV silence | Ask G4 |
| R10 | Clear, timely written records on an EPR | must_have | unclear | low | discovery | Records not evidenced on CV; the EPR system is not named | `[grounded]` CV silence | Ask about records practice at interview |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | Never done; no adjacent evidence. Closure path is training; the team lead has spoken publicly about Doppler training for staff new to community work, which does not confirm it is offered here | `[grounded]` CV; `[grounded]` speaker page | G6 |
| R12 | Home-based nursing for housebound adults | important | adjacent | medium | transferability | Home visits in the first week after discharge, not ongoing community visits | `[grounded]` CV; `[inferred]` | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Caseload and care planning (R8, R12) | transferability | Home visits and first-week planning; no ongoing caseload | This is the role's core feature, so the limit is the one most likely to come up | Any post-discharge plan you shaped; any follow-up you carried beyond the first week | A discharge plan example, anonymised | `[inferred]` bridge from discharge visits |
| G2 | Leg-ulcer assessment (R6) | transferability | Wounds stated, leg ulcers not | Wound care is essential; leg ulcers are named specifically | Any dressing, compression or wound review on a ward or discharge visit | A wound assessment record, anonymised | `[grounded]` CV |
| G3 | Continence care (R5b) | discovery | Not on CV | Essential-tier care in the posting | Continence assessment, pad or catheter review on the ward | A care plan excerpt | `[grounded]` CV silence |
| G4 | End-of-life visits (R9) | discovery | Not on CV | Named in the role's responsibilities | Palliative or end-of-life care on the ward; planning a discharge home for someone dying | A care plan or discharge summary | `[grounded]` CV silence |
| G5 | Written records on EPR (R10) | discovery | Not evidenced | Essential, and the posting ties records to the role | Any EPR or structured documentation you used | Sample note, anonymised | `[grounded]` CV silence |
| G6 | Doppler assessment (R11) | capability | None | Desirable, not essential | Doppler training if offered; any vascular assessment | A training booking | `[grounded]` CV; `[generic]` that community teams often train new staff |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Post not confirmed live on careers page | unknown | — | "Current vacancies are listed on our careers page" | The post may be live but not on the page we could reach, or it may be stale | `[inferred]` from the failed fetch and the About page's unlinked careers reference | Is this post live on your careers page, and who would I be interviewing with? | unresolved |
| RR2 | Contract basis unstated | unknown | — | "Join our district nursing team" | The post may be fixed-term or tied to a funding stream | `[inferred]` from silence on contract basis | Is this post permanent or fixed-term, and what funds it? | unresolved |
| RR3 | Caseload size and senior support unquantified | unknown | — | "a small caseload, supported by a senior community nurse" | "Small" may mean something different from what you expect | `[generic]` pattern for community caseload posts | What is the typical caseload size, and how is senior support arranged day to day? | unresolved |
| RR4 | Salary stated, mileage paid | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The stated range sits around the survey median | `[generic]` Wardround 2026 survey, median £34,300 | | noted |
| RR5 | Employer established | positive_signal | — | "Calderbrook Community Health CIC, Halifax" | The employer is an established CIC with an NHS contract | `[grounded]` About page: founded 2015, 410 staff | | noted |
| RR6 | Named contact is public in the role | positive_signal | — | "contact Rhiannon Mabbott, Community Nursing Team Lead" | The contact's public role matches the post | `[grounded]` speaker profile: leads the Halifax district nursing team | | noted |

No request in the material asks you for money, deposits or bank details, so no request-based entry applies.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take up the informal chat with Rhiannon Mabbott and ask RR1, RR2 and RR3 | Closes the unknowns before you invest in the application | `[grounded]` register | your decision |
| A2 | Check your NMC register entry and licence yourself | R1, R2 gates | `[grounded]` CV | your check |
| A3 | Draft CV language leading with insulin, catheter, pressure and surgical wounds, and post-discharge home visits. No caseload, leg-ulcer or Doppler claims | R5a, R6, R7, R12 | `[grounded]` CV | pending your approval |
| A4 | State the caseload and Doppler gaps plainly, with a closure path | R8, R11 | `[generic]` that community teams often train new staff in Doppler; not confirmed for this employer | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned calderbrookhealth.example/about; fetched it. Fetched calderbrookhealth.example/careers: no page. Moved RR5 (grounded) and RR1 |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 pay scale 2026 England", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved market calibration and RR4 (generic) |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned communitynursingforum.example/speakers/rhiannon-mabbott. Moved RR6 and the Doppler closure path in R11 |

## Upgrade menu

I'd offer to write this up as a `tuesday-dossier.md` you can keep for later preparation.

- A copy of your NMC register entry → R1 toward `high`
- An anonymised discharge-to-assess plan or wound assessment → R6, R8 evidence
- Any leg-ulcer dressing or compression work, even on a ward → R6 from adjacent toward direct
- A continence assessment you did or did not carry out → R5b
- The live posting link, or the team's reply on caseload and contract → RR1, RR2, RR3 close
- A Doppler training booking, or a course you would take → R11 closure path
- A deeper research pass on Calderbrook (accounts, past postings, public inspection reports; up to 5 more searches and 2 more fetches). Say the word and it runs once.

**Questions**

G1 — On the discharge team, did you ever decide a patient's plan of care yourself, and what happened after the first week?

G2 — Have you ever assessed or dressed a leg ulcer, or applied compression, even on a ward or a discharge visit?

G4 — Have you done end-of-life or palliative visits, including planning a discharge home for someone who was dying?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.