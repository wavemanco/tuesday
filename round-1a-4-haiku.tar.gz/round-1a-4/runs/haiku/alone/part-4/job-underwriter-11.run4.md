**Short answer:** The Duinvaart Operations Analyst role is worth applying to, with conditions. The Kroonhaven Supply Planner role is not worth your time right now. Web search was refused in this session, so neither employer's existence nor its market pay was checked.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page (both employers) | unavailable | Both company searches were refused. Employer existence and whether each posting is live are unchecked. Would have moved RR2 in both roles. |
| 2. Role-family sweep (both roles) | unavailable | Both pay and scope searches were refused. Would have set the market calibration. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

## 1. Operations Analyst, Duinvaart Cold Chain, Rotterdam

**Decision snapshot — worth applying to, on conditions. Status: `conditional_go`.**

Your parcel-carrier background matches most of the must-haves directly. The gaps are cold-chain temperature work and the office location.

- **Fit ledger.**
  - `hard_gate` — unclear: R1 (Hybrid, three days a week in Rotterdam office)
  - `must_have` — direct: R2 (2+ years in operations analysis), R3 (strong SQL), R4 (Power BI or Tableau), R5a (on-time delivery tracking); adjacent: R5b (temperature compliance)
  - `important` — direct: R6 (weekly dashboards), R7 (route changes with depot managers)
  - `preferred` — adjacent: R8 (Dutch)

  R5b (`adjacent`, confidence `low`) is the one row the posting cares about that the evidence barely touches. R1 is `unclear`, and the candidate's commute limit has not been given.
- **Opportunity ledger.** The posting is specific and its scope is clear (RR4). Two things are unknown: the salary (RR3) and whether this role owns temperature compliance or only reports it (RR1). There are no red flags. The employer is not verified (RR2).
- **Hard gates:** unconfirmed: R1 (Hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** conditions for go —
  1. RR1: temperature compliance is at least analysis and follow-up, not only a report.
  2. R1: three days a week in Rotterdam is workable for you.
  3. RR2: the role appears on Duinvaart's own careers page, which you check yourself.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | `[grounded]` JD; not checked online (research refused) |
| Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; route changes with depot managers | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | Analyst-level, with reporting and advisory duties; no decision rights stated | `[inferred]` from the responsibilities list |
| Market calibration | Not run; no pay band | — (research refused) |
| Unknowns | Salary; whether temperature compliance is owned or reported; team size | — |
| Contradictions | None within the posting | `[grounded]` JD |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | Your location and commute limit were not given. Amsterdam to Rotterdam is a daily commute for some people, not for others. | `[grounded]` JD; candidate input missing | Your commute answer (question 1 below) |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as operations analyst at a parcel carrier. Stated by you, no artifact yet. | `[grounded]` CV | none |
| R3 | Strong SQL | must_have | direct | medium | none | Used daily. Stated by you, no artifact yet. | `[grounded]` CV | Optional: a sanitized query sample |
| R4 | Power BI or Tableau | must_have | direct | medium | presentation | Used daily, and the on-time dashboard depot managers use is your proof point. Your ownership of that dashboard is not confirmed. | `[grounded]` CV | E1 (pending your approval) |
| R5a | Track on-time delivery | must_have | direct | medium | none | Same measure, but parcel fleet, not refrigerated. | `[grounded]` CV | none |
| R5b | Track temperature compliance across a refrigerated fleet | important | adjacent | low | transferability | Threshold and exception monitoring from on-time reporting may carry over. Limit: no temperature telemetry or cold-chain compliance rules. | `[inferred]` from R5a | Question 2 below |
| R6 | Weekly dashboards in Power BI | important | direct | medium | presentation | You built and ran weekly reporting. Confirm ownership. | `[grounded]` CV | E1 (pending your approval) |
| R7 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review. | `[grounded]` CV | none |
| R8 | Dutch (a plus) | preferred | adjacent | low | transferability | Conversational Dutch. Limit: not fluent. | `[grounded]` CV | Say so plainly; do not claim fluency |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Temperature compliance ownership unstated | unknown | — | "track … temperature compliance across our refrigerated fleet" | The role may report temperature data without owning thresholds or follow-up | `[inferred]` from the JD's wording | "For temperature compliance, does this role own the thresholds and excursion follow-up, or report them?" | unresolved |
| RR2 | Employer not verified | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | Research was refused, so the employer and posting are unconfirmed. Possible reasons, none ranked as likely: the employer is too new or small for a footprint, the posting is stale or aggregated, or it is not a real hiring employer. | `[generic]` pattern for companies of this size | "Can you confirm this role on your own careers page, and who I would interview with?" | unresolved |
| RR3 | Salary not stated | unknown | — | (not stated) | The figure may sit below the market band, or simply not be published | `[inferred]` from the withheld figure | "What is the budgeted salary band for this role?" | unresolved |
| RR4 | Scope is concrete | positive_signal | — | "track on-time delivery and temperature compliance … build weekly dashboards" | Responsibilities are defined and measurable | `[grounded]` JD | — | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the on-time dashboard as a named outcome, and confirm your ownership before writing it | R4, R6 | `[grounded]` CV | pending your approval |
| E2 | Describe on-time tracking as the transferable part. Do not describe any work as cold-chain or temperature work. | R5b | `[grounded]` R5a and R5b rows | pending your approval |
| A1 | Confirm the posting on Duinvaart's own careers page before applying | RR2 | `[generic]` pattern | to do |
| Q1 | Ask RR1 verbatim in the first interview | Decides whether R5b is a real gap | `[grounded]` register | to do |

## 2. Supply Planner, Kroonhaven Foods, Utrecht

**Decision snapshot — not worth applying to now. Status: `no_go`.**

The must-haves are for three years of FMCG planning and ownership of a 13-week supply plan. Your background does not include planning. The gap is not closable with the evidence you have, and the closest adjacent work (the route-performance review) is execution, not planning.

- **Fit ledger.**
  - `hard_gate` — unclear: R1 (On-site in Utrecht)
  - `must_have` — absent: R2 (3+ years supply or demand planning in FMCG), R3 (own a 13-week supply plan), R4 (balance production capacity against forecast); unclear: R7 (SAP IBP or similar planning system), R6 (advanced Excel); adjacent: R5 (run a weekly S&OP meeting), R8 (fluent Dutch)
- **Opportunity ledger.** The posting is clear, with no red flags (RR1 is an authority question). The employer is unverified (RR2), and the salary is withheld (RR3).
- **Hard gates:** unconfirmed: R1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the facts that would have to differ — three years of FMCG planning, or a planning system and forecasting work you have actually owned.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your location and commute limit were not given. | `[grounded]` JD; candidate input missing | Question 1 |
| R2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You have never worked in planning. | `[grounded]` your statement | No realistic closure in the near term |
| R3 | Own the 13-week supply plan for chilled ready meals | must_have | absent | none | capability | Not in your background. | `[grounded]` your statement | As R2 |
| R4 | Balance production capacity against forecast | must_have | absent | none | capability | Not in your background. | `[grounded]` your statement | As R2 |
| R5 | Run the weekly S&OP meeting | must_have | adjacent | low | transferability | You ran a weekly cross-team review with depot managers. Limit: no forecast or production decisions in that review. | `[inferred]` from the route review | none |
| R6 | Advanced Excel | must_have | unclear | low | discovery | Not stated in your background. | `[grounded]` CV silence | Question 3 |
| R7 | SAP IBP or similar planning system | must_have | unclear | low | discovery | Not stated in your background. | `[grounded]` CV silence | Question 3 |
| R8 | Fluent Dutch | must_have | adjacent | low | transferability | Conversational, below the stated bar. | `[grounded]` CV | Say so plainly |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Ownership of capacity decisions unclear | unknown | — | "balance production capacity against the forecast" | The role may propose plans to production rather than decide capacity | `[inferred]` from the JD's wording | "Does this role approve production capacity changes, or propose them to production?" | unresolved |
| RR2 | Employer not verified | risk_signal | medium | "Kroonhaven Foods, Utrecht" | As in role 1 | `[generic]` pattern | "Can you confirm this role on your own careers page, and who I would interview with?" | unresolved |
| RR3 | Salary not stated | unknown | — | (not stated) | As in role 1 | `[inferred]` | "What is the budgeted salary band for this role?" | unresolved |

**Application plan.** There is no action to take now. If you move toward planning later, the closure path is a planning-adjacent analyst role at an FMCG company, where you would build planning-specific evidence (for example, a forecast-versus-actual analysis). `[generic]` — a pattern for career moves like this, not a claim about Kroonhaven.

## Upgrade menu

- Permission for web search → checks Duinvaart's and Kroonhaven's existence and pay bands, and closes RR2 in both roles.
- The careers-page link for each posting → RR2 closes for that role.
- Your commute limit and minimum pay → R1 (both roles) and RR3 close.
- A sanitized dashboard screenshot or query sample → R3, R4, R6 in role 1 to `high`.
- Any single project touching temperature or excursion data → R5b in role 1.
- Any forecasting, S&OP input or planning-system use → role 2 could move from `no_go`. If you have none, say so and I'll leave it at `no_go`.
- Your Dutch level, if you have a certificate or a work-language record → R8 in both roles.

I can also save this as a `tuesday-dossier.md` file if you want it kept.

Please answer these three questions in any order. Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. R1 (both roles): Can you work three days a week in Rotterdam, and in Utrecht on site? What is your commute limit?
2. R5b (role 1): Have you ever handled temperature or excursion data, or cold-chain alerts, even for one client?
3. R6 and R7 (role 2): Have you used a planning system such as SAP, or advanced Excel for forecasting?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.