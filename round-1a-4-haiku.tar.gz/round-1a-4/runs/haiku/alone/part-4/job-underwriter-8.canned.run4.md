## Decision: no-go on this posting as presented

**Fit and opportunity are separate verdicts.** On fit, your background matches the core duties well. On the opportunity, the messages you received ask for money and bank details at steps where a legitimate employer would not, so I would not proceed.

- **Fit (your side):** Strong for the day-to-day work. Customer-service volume (about 60 Zendesk tickets a day), training two new starters, and the Excel tracker all map directly onto "order processing" and "attention to detail." Written English and a quiet workspace are stated but not evidenced in what you've given me.
- **Pay (hard-gate check, unverified):** Not failed, but not met either. At €26/hr, 15 hours a week is about €20,300 a year and 30 hours is about €40,600. Commission is unstated, so the €30,000 floor depends on hours and commission nobody has committed to.
- **Opportunity:** Four high-severity red flags, each quoted from the messages:
  1. **Equipment payment:** "Please pay €349 by bank transfer to our equipment partner." Employers do not normally charge new staff for their own work kit.
  2. **Personal details before any offer:** "send your IBAN, your PPS number and a clear photo of your passport" before the chat interview.
  3. **Cheque and forwarding:** "We are posting you a cheque for €2,850 … transfer the rest to our equipment partner." A cheque can take days to clear and can be returned unpaid after you have already sent money out, which would leave you out of pocket.
  4. **Hiring entirely by chat:** "no calls or video interviews," with an offer delivered inside the same chat.

I can't verify who is behind these messages, and I'm not drawing a conclusion about them. The point is that the steps asked of you carry financial risk to you whatever the intent, and the posting's own terms don't need them.

**What would change this:** a written offer confirmed through contacts you find on Velloway's own website (not the ones in the messages), a live call or video interview, and no payment or cheque step. Even then, don't send bank or ID details until the employer is verified.

## Do now

- **Don't send** your IBAN, PPS number, passport photo or any money to @VellowayHiring or velloway.hr@postmail.example.
- **If a cheque arrives,** don't lodge it or transfer anything against it.
- **If you've already sent anything,** contact your bank now and report it to the Gardaí.
- **Report the posting** to the jobs site it came from.

## Evidence status

Research tier: L0 — no searches; user links read 0

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company's official site and careers page | skipped | Not run. The no-go doesn't depend on it, but a failed check would add a standing risk entry. |
| 2 | Role-family sweep (pay and scope norms) | skipped | Not run. The €26/hr figure is the posting's own. |
| 3 | Hiring manager's public footprint | n/a | No named hiring manager; only the @VellowayHiring handle was given. |

## Upgrade menu

- **Velloway's own website or careers page:** checks that the company exists as described and that this role is listed there (research target 1).
- **The jobs site and a link to the live posting:** confirms where the posting appeared and whether it is still live.
- **Role-family pay check:** shows whether €26/hr plus commission is normal for remote order processing (research target 2).

**Dossier offer:** I can save this assessment as `tuesday-dossier.md` if you want a record of it.

## Questions

1. Have you sent anything yet: the IBAN, PPS number, passport photo, or any money?
2. What's the jobs site, and can you share the posting link?
3. Should I run a web check on Velloway (up to 5 searches and 2 page fetches) to see whether the company and role exist?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.