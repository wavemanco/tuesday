**Yes, worth applying, and the company checks out on the public record. Status: `go`.** Fernquay's own careers page lists this exact role with the same pay, hybrid terms and "first design hire" wording, and its about page names the six-person Galway team and co-founders Ronan Kehoe and Saoirse Doyle. The WhatsApp message is a scheduling step, which is routine for a first-round call, not a warning sign.

**Fit ledger.**

- `hard_gate` — direct: R1
- `must_have` — direct: R2, R3, R5 · adjacent: R4 (own user research)
- `important` — adjacent: R6 (end-to-end booking flow) · unclear: R7 (working as the only designer)
- `preferred` — direct: R8 (one real project)

R4 — a credible bridge, its limit named; R7 (`low`) — no evidence either way, the question below settles it.

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given — checks against pay or equity expectations unknown.
- **Severe red flags:** none found.
- **What would change this:** a vesting or equity structure, or a pay ceiling, that you can't accept. Neither is stated as a deal-breaker yet.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, booking software for sea-kayak, surf and sailing schools; six people in Galway; founded 2023 | `[grounded]` fernquay.example/about |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting, matches careers page |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` posting and careers page |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting and careers page |
| Market calibration | Product designers with 3–5 years: median €57,000, interquartile range €51,500–€62,000. The stated range sits in the lower half of that band | `[generic]` Tillerby 2026 Ireland design salary report (n=520) |
| Scope read | Wide for one designer, normal for a six-person startup with no design hire yet | `[inferred]` from team size against duties |
| Unknowns | Equity vesting, option pool and strike price; whether Saoirse Doyle is CTO (the about page names her co-founder, no title) | — |
| Contradictions | None material between the posting, the careers page and the about page | `[grounded]` three pages read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Galway | hard_gate | direct | high | none | You moved back to Galway; the schedule works | `[grounded]` your statement | none |
| R2 | 3+ years product design | must_have | direct | medium | none | Four years stated; no artifact read yet | `[grounded]` your statement | none |
| R3 | Strong Figma | must_have | direct | medium | none | Daily use stated; no file inspected | `[grounded]` your statement | a Figma file would raise to high |
| R4 | Ran your own user research | must_have | adjacent | medium | transferability | Monthly usability sessions with customers carry over. Limit: no evidence you set product direction through discovery interviews with business owners. Strengthener: a session guide or synthesis | `[grounded]` your statement; `[inferred]` the carry-over | see A3 |
| R5 | Works directly with engineers | must_have | direct | medium | none | Squad of four engineers | `[grounded]` your statement | none |
| R6 | Own the booking flow end to end | important | adjacent | medium | transferability | You redesigned the checkout flow, which is part of booking. Limit: not the whole flow, and not owned alone. Strengthener: a before-and-after of checkout | `[grounded]` your statement | see E1 |
| R7 | Work as the only designer | important | unclear | low | discovery | Never been the sole designer; no evidence either way about deciding alone | `[grounded]` your statement | see Q1 |
| R8 | One real project to show | preferred | direct | medium | presentation | The checkout case study already reached Ronan and landed well | `[grounded]` Ronan's message | see E1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working alone as the designer (R7, important) | discovery | Team experience is in a squad of four with design peers | This is the probe most likely to come up on a six-person team | A decision you made without a design peer checking it; a stakeholder who overruled you and how you handled it | A decision log, a case study section, or a short example | `[grounded]` CV silence on solo decisions; `[generic]` that small teams probe this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | Equity may be worth little without vesting or a cap | `[generic]` pattern for early-stage equity offers | What are the vesting schedule, option pool and strike price? | unresolved |
| RR2 | Pay below the role-family median | risk_signal | low | "€52,000–€60,000" | The range may be fixed for a first hire, with little room to move | `[generic]` Tillerby band against `[grounded]` posting | Is there room in the range for someone with four years' experience? | unresolved |
| RR3 | Sole design remit in a small team | risk_signal | low | "You would be our first designer" | Little design review or peer feedback may be available | `[inferred]` from team size against duties | Who reviews design decisions, and how often? | unresolved |
| RR4 | Employer existence | positive_signal | — | fernquay.example careers and about pages | The employer is real and the posting is live | `[grounded]` official pages read | — | noted |

The WhatsApp scheduling message is routine (interview held elsewhere, invite sent by email); it takes no register entry.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the application with the checkout case study, stating what you did alone and what the squad did | see R6, R8 | `[grounded]` case study | pending your approval |
| A1 | Apply through the careers page's route, with one real project attached | the posting asks for one project | `[grounded]` careers page | pending your approval |
| A2 | Before the call, check the calendar invite comes from a Fernquay address and the video link is on Fernquay's domain. Ronan's public profile matches the co-founder role | routine check, advice only | `[grounded]` careers and about pages | your call |
| A3 | In the first call, ask about vesting and the option pool, and whether the range has room | see RR1, RR2 | `[grounded]` RR1, RR2 | pending your approval |

## Evidence status

Verified: Fernquay exists, the posting is live, and its pay, hybrid terms and contact route match the careers page. Verified: none of your own claims yet. Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Galway careers product designer"; fetched fernquay.example/careers/product-designer and fernquay.example/about. Confirms the employer exists and the posting is live |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3 years experience Dublin Galway", which returned the Tillerby 2026 Ireland Design Salary Report. Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned a public profile snippet (not fetched): co-founder at Fernquay, previously product lead at a Galway travel-software company for five years |

Dossier offer: I can save this as a `tuesday-dossier.md` you can reuse across applications if you want.

**Upgrade menu**

- Your pay floor and equity expectations → the hard-gate line gets real checks.
- A Figma file or the checkout case study as a file → R3 and R8 move to `high`.
- A usability session guide or synthesis → R4 moves from `medium` to `high`.
- A deeper diligence pass on Fernquay (funding, leadership, public staff reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

1. R7 — Think of a decision you made in your squad without a design peer checking it. What did you decide, and what happened?
2. RR1 — Do you know the vesting schedule, option pool and strike price? If not, would you want them in writing before you accept?
3. Is there a pay floor below which you wouldn't take this role? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.