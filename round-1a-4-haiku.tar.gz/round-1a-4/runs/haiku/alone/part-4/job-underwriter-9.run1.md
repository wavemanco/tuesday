**Yes, asking for bank details, PPS number and a passport scan after you accept is routine onboarding, and it is not a reason to hold off.** It is what happens after a written offer, and the interviews you attended in person at their office make the process checkable. Enter those details only in the portal reached from Marrowgate's own website, not from a link in an email, and check that the offer's sender domain matches that website before you reply. Status: `hold_pending_answers`. Three gate answers and one must-have decide it. Research was refused, so I could not confirm the employer exists, which is the one thing that would cap any `go` at `conditional_go`.

## Decision snapshot

- **Status:** `hold_pending_answers`. Waiting on your answers to R1, R2, R3 and R5 below.
- **Fit ledger:**
  - `hard_gate`: unclear: R1, R2, R3
  - `must_have`: direct: R4, R8, R9 · adjacent: R11 (pension changes, the limit being that you never ran them) · unclear: R5 (Irish PAYE, PRSI and USC)
  - `important`: direct: R6, R7 · adjacent: R10 (240 staff, monthly, against your 90 fortnightly) · unclear: R12 (staff payroll queries)
  - Reading: R5 and R11 are the must-have questions; R1–R3 are the gates you have not yet confirmed.
- **Opportunity ledger:** The role itself is clearly defined. The posting's duties match your experience, and the offer names the role, pay, reporting line and permanent status (RR2). The open item is RR1: the employer is not yet established from attributable sources.
- **Hard gates:** none failed; unconfirmed: R1 (right to work in Ireland), R2 (two days a week in Limerick), R3 (pay €38–42k); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** Answering R1, R2 and R3 moves the status to `conditional_go`, conditional on RR1 clearing. An answer that R1 or R2 is not met would make that gate a failure and the status `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, Limerick, 240 staff | `[grounded]` job ad |
| Role | Permanent Payroll Administrator, reporting to Declan Garvagh, Finance Manager | `[grounded]` offer email |
| Scope | Monthly payroll, starters, leavers and pension changes, monthly payroll-to-GL reconciliation, staff queries | `[grounded]` job ad |
| Pay | Posting: €38,000–€42,000. Offer: €40,000, inside that range | `[grounded]` job ad and offer |
| Working pattern | Hybrid, two days a week in the Limerick office | `[grounded]` job ad |
| Scope read | Monthly cycle over a larger headcount than you have run | `[inferred]` from 240 staff monthly against your 90 fortnightly |
| Market calibration | Not run. Search was refused, so there is no salary benchmark beyond the posting's own range | — |
| Unknowns | Pension scheme and process; staff query volume; who checks the reconciliation; whether the employer is established (RR1) | — |
| Contradictions | None found in the material you gave me | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Right to work in Ireland (offer's passport check) | hard_gate | unclear | none | hard_gate | Not stated anywhere in your material | `[grounded]` offer email | Q1 |
| R2 | Hybrid, two days a week in Limerick | hard_gate | unclear | none | hard_gate | Your location and commute not given | `[grounded]` job ad | Q2 |
| R3 | Pay €38–42k | hard_gate | unclear | none | hard_gate | Offer is €40k, inside the range. Your floor is not given | `[grounded]` job ad and offer | Upgrade menu |
| R4 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff, self-reported | `[grounded]` your message | none |
| R5 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | low | discovery | You never name these deductions. Your certificate may cover them, but that is not stated | `[grounded]` your message, silence | Q3 |
| R6 | Strong Excel | important | direct | medium | none | Daily pivot tables and XLOOKUP, self-reported | `[grounded]` your message | none |
| R7 | Payroll qualification or working towards | important | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your message | none |
| R8 | Starters and leavers | must_have | direct | medium | none | Ran this at the hotel group | `[grounded]` your message | none |
| R9 | Monthly payroll-to-GL reconciliation | must_have | direct | medium | none | Ran this monthly at the hotel group | `[grounded]` your message | none |
| R10 | Monthly payroll for 240 staff | important | adjacent | medium | transferability | Your experience is fortnightly, 90 staff. Limit: monthly cycle and headcount at this scale not run | `[inferred]` from the two sets of figures | G2 |
| R11 | Pension changes | must_have | adjacent | low | transferability | You never executed pension changes; your manager did. Starters and leavers touch the same records, so the adjacency is partial. Limit named | `[inferred]` adjacency from starters and leavers work | G1 |
| R12 | Staff payroll queries | important | unclear | low | discovery | Not in your account | `[grounded]` your message, silence | Upgrade menu |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R11, must_have) | transferability | Starters and leavers are yours; pension changes were your manager's | A must-have, and the one you asked about. It is closeable if the role is supported | Any pension-scheme or enrolment step you saw alongside starters and leavers; any reconciliation of scheme contributions | Her process notes (sanitized), or the employer's pension onboarding | `[inferred]` closure path from the adjacency |
| G2 | Monthly payroll at 240 staff (R10) | transferability | Fortnightly at 90 | The scale and cycle are the main day-to-day difference | Any monthly cycle or larger headcount you worked in | Your payroll calendar or cut-off checklist | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | Too new or small to have a footprint, a stale posting, or not a real hiring employer | `[generic]` pattern for employers of this size, not a claim about this one | Can you point me to this role on your own careers page, and confirm the address people@marrowgatehousing.ie belongs to your organization? | unresolved |
| RR2 | Scope and pay stated | positive_signal | — | "permanent post … at €40,000 a year, reporting to Declan Garvagh" | Role is defined and the pay is inside the posted range | `[grounded]` offer and job ad | What does the reconciliation review look like, and who signs it off? | noted |
| RR3 | Pension scheme and process not described | unknown | — | "pension changes" (job ad) | Process may sit with a pensions provider or another team | `[inferred]` from the posting's silence | Which pension schemes does Marrowgate run, and how are member changes processed and checked? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before replying, check the offer's domain against Marrowgate's own website | RR1 | `[grounded]` offer email | your action |
| A2 | Reply to accept only after R1–R3 are answered and A1 is done | Gates | `[grounded]` | your action |
| A3 | In that reply, ask what the right-to-work check needs (copy or view, retention) and what pension onboarding looks like | G1, RR3 | `[generic]` standard onboarding practice | pending your approval of wording |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Four searches were refused by the permission prompt. Would have moved RR1 (employer established) and the offer's domain check |
| 2. Role-family sweep | unavailable | Search refused. Would have set the market calibration line for the €38–42k band |
| 3. Hiring manager's public footprint | unavailable | Name given (Declan Garvagh). Search refused. Would have moved the scope read |

## Upgrade menu

- Your pay floor, if it is not €40k → R3 closes.
- Permission to web-search in this session → RR1, the market calibration line and the hiring manager's footprint can run, up to 5 searches and 2 fetches.
- A copy of the job ad or the careers-page listing → confirms the posting is live and matches the offer.
- Your payroll certificate (inspectable) → R7 rises from `medium` to `high`.
- Any pension-scheme or enrolment exposure, even indirect → G1 narrows.

A tuesday-dossier.md can be written from this analysis if you want one.

1. **R1 (right to work):** Do you have an unrestricted right to work in Ireland? A yes or no is enough. Nothing needs to be sent.
2. **R2 (location):** Can you do two days a week in the Limerick office from where you live?
3. **R5 (Irish payroll):** Have you run Irish PAYE, PRSI and USC deductions and Revenue payroll submissions yourself? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.