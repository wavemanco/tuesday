**Decision: `conditional_go`.** Apply, once you've confirmed the company and the role are real through channels you find yourself. I can't establish Fernquay from here, so that check is still open.

**Research tier: L1, searches 3 of 5, fetches 0 of 2.** I tried three web searches (the company, its registration, and Ronan), but the search permission was refused, so none ran. Every company fact below is from your message alone.

**Fit ledger (your evidence against the posting)**
- **Hard gates:** Location is met: you're in Galway and the hybrid pattern is two days a week in the office. Pay is unconfirmed: €52–60k against your floor, which you haven't told me. Equity isn't a gate, but its value isn't stated.
- **Must-have, direct:** 3+ years of product design (4 years). Strong Figma (daily use). Running your own research (monthly usability sessions).
- **Must-have, adjacent:** Owning the booking flow end to end. You redesigned checkout, but not the whole flow. Research with school owners is a different customer group from your travel customers.
- **Must-have, direct:** Working directly with engineers. You worked in a squad of four engineers.
- **Important, absent:** Being the only designer. You've never been the only designer anywhere. This is the real gap. It is not disqualifying, but you'd need to show you can set your own direction without design peers.

**Opportunity ledger (the role on its own terms)**
- **Positive signals:** The posting is specific: named co-founder and CTO, team size, what you'd own. It is candid about being small and rough, which is consistent with a six-person company.
- **Risk, `[generic]`:** A first-designer role at a six-person startup usually means no design review, no mentor and unclear priorities. That is a pattern for early-stage companies, not a finding about this one.
- **Pay and equity, `[generic]`:** I can't check the market band without research. Compare €52–60k with an Irish product-design salary survey yourself. Ask what 0.5–1% equity means in practice: share class, vesting, and the company's current valuation.
- **Unverified employer (`medium`, standing entry):** I can't confirm Fernquay exists as described. Small companies are often just small, so this isn't alarming by itself. It does mean you shouldn't spend significant effort before checking.

**The WhatsApp message**
Nothing in it asks you for money, bank details or an ID, or to deposit anything. It asks for a 45-minute video call and says the invite will come by email. Scheduling by chat for an interview held elsewhere is routine, so this doesn't trigger a warning by itself. Two checks are still worth doing:
- The calendar invite should come from an address on the same domain as Fernquay's own website, not a personal or free-mail address. Find the domain on their site yourself, not from the message.
- Don't send bank, tax or ID details until you've received a written offer, and then only through the employer's own portal at an address you found on their site.

**Upgrade menu (what would sharpen this)**
- A live check of Fernquay's company register entry and careers page. This would move the standing entry toward resolved.
- A salary-band check for this title and city, which would turn the `[generic]` pay line into something you can use.
- Your salary floor and your view on equity. This would settle the hard-gate line.

**Questions**
1. Did you apply to Fernquay yourself, and did you send them a checkout case study? Through which channel: their site, LinkedIn, or a job board?
2. Does the calendar invite come from an address on Fernquay's own domain?
3. What's your salary floor, and do you want the equity question on the call?

If you do go ahead, I can help you prepare for the 45-minute call and draft the questions above to ask on it.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | unavailable | Search permission refused |
| 2. Role-family sweep (title, pay, equity) | unavailable | Search permission refused |
| 3. Ronan Kehoe's public footprint | unavailable | Search permission refused |

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.