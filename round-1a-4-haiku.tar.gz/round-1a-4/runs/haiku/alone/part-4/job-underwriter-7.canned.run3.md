**Yes, worth applying, on two conditions. `conditional_go`.** You meet all four essential requirements on paper. Your gaps are in the role's scope (caseload, continence, end-of-life, Doppler), not in eligibility.

**Fit ledger.**
- `hard_gate`: direct: H1, H2, H4; unclear: H3 (pay band)
- `must_have`: direct: M1; unclear: M2 (written records)
- `important`: direct: I1, I3, I5; adjacent: I2 (leg-ulcer wound care), I8 (own caseload); unclear: I4 (continence care), I6 (end-of-life visits), I7 (care planning), I9 (electronic patient record)
- `preferred`: absent: P1 (Doppler assessment)

I2 and I8 are credible bridges with their limits named. H3 is unclear only because your pay floor isn't in what you've given me.

**Opportunity ledger.** The role is clearly described and the employer checks out: the named team lead is real and public, and the pay band sits around the role-family median. The open items are the contract basis (RR1) and the mileage terms. Severe red flags: none found.

**Hard gates:** none failed (H1 `direct`, H2 `direct`, H4 `direct`); unconfirmed: H3 (Pay £31,050–£37,800); candidate constraints not given (no pay floor or schedule limits), so checks against them are unknown.

**What would change this:**
- Conditions for go: (1) the post is confirmed permanent (RR1); (2) your pay floor sits at or below £31,050 (H3).
- Doppler is preferred, not a condition.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: an adult community nursing provider under an NHS contract in Calderdale, founded 2015, about 410 staff | `[grounded]` company about page |
| Mandate | District nursing for housebound adults: wounds, catheters, insulin, end-of-life visits, care planning, on the EPR | `[grounded]` JD |
| Caseload | A small personal caseload, supported by a senior community nurse | `[grounded]` JD |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` JD |
| Market calibration | Community staff nurse, Band 5, England: median basic pay £34,300, interquartile range £32,400–£36,600; 61% of respondents paid mileage | `[generic]` 2026 pay survey, n=1,240. The posted range covers the median. This is not this employer's offer. |
| Contact | Rhiannon Mabbott, Community Nursing Team Lead, leads the Halifax district nursing team | `[grounded]` JD, speaker page |
| Scope read | Ordinary for a band 5 district nurse with a caseload | `[inferred]` from the JD's listed duties |
| Unknowns | Contract basis, mileage rate, typical caseload size, EPR system | — |
| Contradictions | None found between the JD and the company's public pages. The live careers listing was not fetched. | `[grounded]` company about page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| H1 | NMC registration as Adult Nurse | hard_gate | direct | medium | none | Stated as active with revalidation due March 2028; not yet checked on the register | `[grounded]` CV as stated | You check your NMC register entry |
| H2 | Full UK driving licence | hard_gate | direct | medium | none | Stated as full, category B; as stated, not checked | `[grounded]` CV as stated | You check your licence record |
| H3 | Pay band £31,050–£37,800 plus mileage | hard_gate | unclear | none | hard_gate | Your pay floor is not given, so the constraint is not established | `[grounded]` JD figure | Give your pay floor (Q1) |
| H4 | Based in Halifax | hard_gate | direct | medium | none | You live in Halifax; the JD base is Halifax | `[grounded]` CV, JD | none |
| M1 | At least one year post-registration experience | must_have | direct | medium | none | Five years as staff nurse, stated; not yet probed | `[grounded]` CV | none |
| M2 | Clear, timely written records | must_have | unclear | low | discovery | The CV is silent on documentation | `[grounded]` CV silence | Q2 |
| I1 | Wound care, pressure ulcers and surgical wounds | important | direct | medium | none | Stated; expect a probe on assessment depth | `[grounded]` CV | none |
| I2 | Leg-ulcer wound care | important | adjacent | medium | transferability | General wound care carries over. Limit: no leg-ulcer work named | `[inferred]` adjacency from I1 | G1 |
| I3 | Catheter care | important | direct | medium | none | Stated | `[grounded]` CV | none |
| I4 | Continence care | important | unclear | low | discovery | Not stated | `[grounded]` CV silence | Q2 |
| I5 | Insulin administration | important | direct | medium | none | Stated | `[grounded]` CV | none |
| I6 | End-of-life visits | important | unclear | low | discovery | Not stated; the discharge work may have touched it | `[grounded]` CV silence | Q2 |
| I7 | Care planning | important | unclear | low | discovery | Assessment work implies some planning; not stated | `[inferred]` from discharge-to-assess role | Q2 |
| I8 | Holding and running your own caseload | important | adjacent | medium | transferability | Never held a caseload. Home visits and discharge assessment are the nearest. Limit: no ownership of ongoing patients | `[grounded]` CV; `[inferred]` adjacency | G1 |
| I9 | Electronic patient record | important | unclear | low | discovery | Which system you used is not stated | `[grounded]` CV silence | Add to Q2 if needed |
| P1 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No evidence. Closure path: training. The team lead spoke publicly on Doppler training for staff new to community work | `[grounded]` speaker page; `[inferred]` that this employer offers it | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload (I8), leg-ulcer care (I2) | transferability | Home visits and discharge assessment; no ongoing caseload or leg-ulcer work | The caseload is the core of the post | Any patient you followed beyond the first week; any leg-ulcer dressing or review you led | A caseload sheet, an assessment note | `[inferred]` bridge |
| G2 | Doppler (P1) | capability | None | Preferred only, minor risk | Any study day or competency on vascular or ulcer assessment | A training certificate, or confirmation the service trains staff | `[grounded]` speaker page; `[generic]` that Doppler is usually trained on the job |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Contract basis unstated against your permanent-only constraint (H3 and your permanent-only constraint are separate) | unknown | — | "Join our district nursing team" | The post may be fixed-term | `[inferred]` from the JD's silence on contract basis | Is this post permanent, or fixed-term? If fixed-term, to when? | unresolved |
| RR2 | Pay band covers the role-family median | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The band is in line with the market; the mileage rate is not stated | `[grounded]` JD; `[generic]` survey median | What is the mileage rate, and is it paid on top of the band? | noted |
| RR3 | Caseload with stated senior support | positive_signal | — | "You will hold a small caseload of your own, supported by a senior community nurse" | Support is defined; the role is not sink-or-swim | `[grounded]` JD | How many patients is a typical caseload, and who is the senior nurse? | noted |

Severity is `—` on these rows because none is a risk signal or red flag. No entries of `severity: high`.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your NMC register entry and licence record yourself before applying | H1, H2 are stated, not checked | `[grounded]` rows H1, H2 | proposed |
| A2 | Ask the contact (Rhiannon Mabbott) about contract basis, caseload size and Doppler training, in an informal chat | RR1, RR3, P1 | `[grounded]` JD | proposed |
| A3 | Lead your CV with discharge-to-assess home visits and wound, catheter and insulin care; name the caseload as adjacent, with its limit | I1, I8, G1 | `[grounded]` CV | pending your approval |
| A4 | Keep Doppler as a stated learning goal, not a claim | P1 | `[generic]` role-family practice | proposed |

Nothing in the CV wording is changed until you approve it.

## Evidence status

Verified: none yet. Everything so far is your CV's self-report. The NMC and licence checks would raise H1 and H2 to `high` once you have an inspectable record.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read none

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned the company about page (calderbrookhealth.example/about): an NHS-contracted adult community provider, founded 2015, 410 staff. Confirms the employer is attributable. The careers listing was not fetched, so posting consistency is unchecked. |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse salary NHS Agenda for Change 2026", which returned the Wardround 2026 pay guide (wardround.example/2026-uk-community-nursing-pay-guide). Sets the market calibration. |
| 3. Hiring contact's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Halifax", which returned a forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott): leads the Halifax district nursing team; spoke on leg-ulcer clinics and Doppler training. Feeds P1 and the chat agenda. |

## Upgrade menu

- Your pay floor → H3 closes.
- A copy of your NMC register entry or licence check → H1 and H2 move to `high`.
- Continence, end-of-life or care-planning examples from discharge work → I4, I6, I7 move.
- The contract basis from the team lead → RR1 closes; the decision likely simplifies.
- The live posting link from the company's careers page → confirms the listing is current and consistent with the JD.
- A deeper research pass on the company (leadership changes, past staffing reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you'd like, I can write this up as a `tuesday-dossier.md` you can keep.

1. Q1 (H3): What is the lowest annual pay you'd accept, and does mileage change that for you?
2. Q2 (M2, I4, I6, I7, I9): From your discharge-to-assess visits, have you done continence assessments, end-of-life visits or care planning, and which electronic record did you use? For each, what did you own?
3. Q3 (P1, I2): Have you had any leg-ulcer or Doppler training, even a study day?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.