**Decision: no_go.** Don't send the IBAN, PPS number, passport photo or any money, and don't deposit the cheque if one arrives. The requests you've quoted would be reason to stop even if everything else checked out.

I can't confirm this employer is legitimate. I haven't searched for it, so nothing here depends on the employer's identity. It depends on what they've asked you to do.

**Research tier: L0, no searches.** Everything below comes from the posting and messages you pasted. Labels show what is grounded in those documents and what is inference.

## Decision snapshot

- **Opportunity ledger:** no_go. Several quoted requests are disqualifying on their own.
- **Candidate fit ledger (scored separately):** moderate to strong on the stated skills. Your CV supports customer-service volume, training others and Excel tracking. Written English is not evidenced.
- **Hard gates:** pay is the one that bites. The posting's own range at 15–30 hours a week is €20,280–€40,560 a year before commission [grounded: 26 × 15 × 52 and 26 × 30 × 52]. Your floor is €30,000, so the low end misses it. Commission is unquantified.

## Red flags (quoted from the messages)

1. **Bank, PPS and passport details requested before any written offer** `[grounded]`, `severity: high`, `confirmed`. Sent in the first chat message.
2. **Payment demanded for equipment** `[grounded]`, `severity: high`, `confirmed`: "Please pay €349 by bank transfer to our equipment partner." A legitimate employer does not make a new hire pay for work equipment.
3. **Cheque instruction** `[grounded]`, `severity: high`, `confirmed`: lodge €2,850, keep €350, transfer €2,500 onward. Banks often credit a cheque before it clears. If it is returned, the shortfall comes out of your account, and any money you already sent on is gone.
4. **Hiring and offer entirely in chat** `[grounded]`, `severity: medium`. "Passed interview" and "the job is yours" came in Telegram, with no call, contract, company email or named manager.
5. **Contact address is not a company domain** `[grounded]`, `severity: medium`. `velloway.hr@postmail.example` is a generic mailbox, not an address on the company's own site.

## Role reality and mismatch

- Stated responsibilities are thin: "process orders," with no description of what that involves.
- Contradiction: "no calls or video interviews," but also a "chat interview" that required bank and ID details first.
- Pay: "up to €26/hr plus commission," with commission unstated. That leaves the €30,000 floor unverified at any hours (see the hard-gates line).

## Evidence map (candidate side)

| Requirement | Your evidence | Confidence |
|---|---|---|
| Customer service at volume | 3 years, ~60 Zendesk tickets/day (CV, stated) | Medium: stated, not verified |
| Attention to detail, spreadsheets | Maintains team weekly tracker in Excel (stated) | Medium |
| Training others | Trained two new starters (stated) | Medium |
| Good written English | Not evidenced in what you sent | Low: a gap |

## Application plan

1. **Stop replying to @VellowayHiring.** Screenshot the chat first if you want a record.
2. **Don't send the IBAN, PPS number, passport photo or any transfer.** If you've already sent any of these, contact your bank now and ask them to flag the account. Report the approach to the Gardaí.
3. **If a cheque arrives,** don't lodge it or spend against it. Ask your bank what to do with it.
4. **Keep applying** through job boards and directly to employers whose careers pages you can reach yourself. Your background fits customer-service and operations roles. I haven't checked market pay for those roles, so I can't tell you whether €30,000 is realistic.

## Evidence status

One declared target, not run: the employer's website and careers page. The decision doesn't depend on it, so I skipped it. A check there would only tell you whether the company exists, not whether these requests are acceptable.

## Upgrade menu

- A link to the live posting or the company's own careers page, to compare with what you received.
- The company's registered name and address from the Companies Registration Office register (CRO), if they are a registered Irish company. Any real company has a registered entry you can look up.
- Research at L1 (company site and role-family pay), if you want market figures for €30,000.

## Question

Have you sent anything yet, including a photo or your PPS number, or received the cheque? Answer in your own words, or say "skip."

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.