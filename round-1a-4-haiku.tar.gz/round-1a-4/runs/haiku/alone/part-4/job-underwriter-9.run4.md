**Decision snapshot: conditional_go.** Verify the employer and the offer before you send anything.

**Hard gates:** None are stated beyond location. Limerick, two office days a week, is unconfirmed for you: I don't know where you live or whether you can commute. No authorization or right-to-work status was given, so that check is unknown.

## Your question: is it normal to be asked for bank, PPS and passport?

Yes, in part. After a written job offer, an Irish employer does need your bank details for salary, your PPS number for Revenue and payroll, and some evidence of your right to work. Those requests are routine and get no red-flag entry [generic].

What matters is the order and the channel:

- **Sequence:** The offer came first, in writing, which is the right order. Sensitive details belong only after you have accepted and the employer's identity is verified.
- **Channel:** Submit details only through a portal reached from the company's own website or from a contact you found independently. Don't use a link from the offer email alone, and never send them by reply email, text or chat.
- **Verification:** The offer came from people@marrowgatehousing.ie. Confirm that address and the portal domain by calling the switchboard number on Marrowgate's own website, not a number in the email. If they are an Approved Housing Body, the public AHB register is another check [generic].
- **Passport:** Ask what the right-to-work check requires for your situation. Ask whether they need a scan now or only the original on day one, and how they store and delete the copy. Don't send a scan until those questions are answered.

Red flags would be a request for these details before any written offer, by phone, text or chat, or a portal on an unfamiliar domain. Nothing here shows that. I haven't established that the employer exists as described, though, because my search was refused (see the evidence table).

## Role reality and fit

- **Scope:** Monthly payroll for 240 staff, starters and leavers, pension changes, payroll-to-GL reconciliation, staff queries. Salary €40,000 sits inside the posted €38k–€42k band. The band is from the posting [grounded].
- **Strong matches:** 3 years of fortnightly payroll for 90 staff, starters and leavers, and monthly payroll-to-ledger reconciliation. Payroll Technician certificate (2024). Daily Excel with pivots and XLOOKUP. These meet the 2+ year, Excel and qualification requirements.
- **Gap, capability:** Pension changes. You have not handled them yourself; your manager did. Say that plainly. Ask in the offer conversation what training or supervision they provide for pension changes in the first months.
- **Unverified:** Working knowledge of Irish PAYE, PRSI and USC. Your experience is presumably Irish, but the CV doesn't say so, so confirm it before claiming it.

## Opportunity ledger

- **Risk, medium:** The employer's existence and the posting's live status are unverified. A `go` is capped at `conditional_go` until verified.
- **Positive:** A written offer, in-person interviews at the office, a clear role and salary.

**Conditions for moving to `go`:** (1) you confirm the employer and the offer through a contact you found yourself; (2) you confirm the portal and the passport request through the People Team; (3) you get a clear answer on pension-change training.

## Evidence status

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | unavailable | Web search permission was declined, so no company facts were checked. |
| 2 | Role-family sweep (scope, title, pay) | skipped | Not run because the search was refused. |
| 3 | Hiring manager's public footprint (Declan Garvagh) | skipped | Not run, same reason. |

I worked from your description and the skill's main guidance. I did not load its detailed reference tables, so this is a condensed first pass.

If you want to know whether a company like Marrowgate exists and is hiring, that check needs search access. You can enable it and I'll rerun it.

**Dossier:** I can save this assessment as a `tuesday-dossier.md` file if you want it for later.

**What would sharpen this (upgrade menu):**
- Web search access, to verify the employer and posting (target 1).
- The job advert link, if it's live, to compare the wording against the copy you were sent.
- Your work history on pension tasks, if any, so the gap can be described accurately.

**Questions:**
1. How did the offer reach you, and do you have a phone number for Marrowgate that you got from their own website?
2. What is your right-to-work status (for example Irish or EU citizen, or other)? This decides what the passport check actually requires.
3. Can you commute to the Limerick office two days a week?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.