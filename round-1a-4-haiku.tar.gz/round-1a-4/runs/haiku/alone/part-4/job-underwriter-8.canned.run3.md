**Decision: hold. Don't send anything to @VellowayHiring yet.** Don't send your IBAN, PPS number or passport photo, and don't pay or deposit anything.

**Why the hold**

The role may be real, but the process asks for money and identity details before any real hiring step, and each request below is one a hiring process doesn't need:

1. **Identity documents before any interview or written offer:** IBAN, PPS number and passport photo, requested before the chat interview.
2. **Payment for equipment:** €349 to a third party, with a refund promised "with your first wages."
3. **A cheque to lodge, then money sent on:** keep €350 and transfer the rest to the "equipment partner." A cheque can be returned unpaid days or weeks after the money has left your account, so you would be out of pocket.
4. **Hiring entirely through Telegram:** no calls or video, and you have only the sender's word for who they are.

**Fit (stated by you, not verified)**

Your background matches this kind of role well: customer service at volume, Zendesk, training new starters, and maintaining a tracker in Excel. Use that for real postings.

**Pay**

The posting says "up to €26/hr" for 15–30 hours a week, with no guaranteed figure. At 30 hours for 48 weeks that is about €37,000, and at 15 hours about €19,000. The €30,000 floor isn't assured by the posting.

**What to do**

- Find the company's own website through a search engine, not a link from the sender. Check that it exists, that it lists this role on its careers page, and that its contact details match what the recruiter gave you.
- Phone the switchboard number listed on that site, not one from the messages, and ask whether the role and recruiter are real.
- Ask for a live video or phone interview. A genuine employer will usually agree.
- If you have already sent details or money, contact your bank straight away and report it to the Gardaí.

**Research:** Research tier: L0, no searches run. The hold doesn't depend on research, and the checks above are yours to run. This is a condensed first pass, not the full evidence map.

**Question:** Do you have a link to the posting on the company's own careers page or website? That is the one thing that could change this hold.

I can save this assessment as a dossier file if you want it for later.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.