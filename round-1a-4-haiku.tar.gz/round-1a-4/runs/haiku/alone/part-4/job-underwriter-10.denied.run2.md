**Decision: `conditional_go`.** The role fits your stated background well. I could not confirm that Fernquay exists as described, because the web searches were refused.

Nothing in the posting or the messages asks you for money, bank details or personal information. A WhatsApp message to arrange a video call is ordinary, and the emailed invite is the second channel. The open question is the company itself, which you can check yourself (see the conditions below).

Answer to your question: "Is it legit?" I can't confirm it from here. "Is WhatsApp odd?" Scheduling by chat for an interview held elsewhere is routine `[generic]`, so it is not a warning sign.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (pay floor, €52,000–€60,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) confirm the company independently before sharing more: its registration on the Companies Registration Office (CRO) register, its own careers page, and that the invite came from a Fernquay email domain (RR1); (2) confirm your pay floor is met (R2); (3) the first-designer and solo-ownership points hold up on the call (R7, R8, RR3).

**Fit ledger**
- `hard_gate` — direct: R1 · unclear: R2 (pay floor)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (end-to-end booking flow)
- `important` — adjacent: R9 (school-owner research) · unclear: R8 (first and only designer)

R7 — the closest work is a checkout redesign, its limit named; R8 — untested, not yet a gap in evidence.

**Opportunity ledger.** The posting is transparent on salary and scope (RR5, positive), but equity terms are unstated (RR2), and the company's size, funding and the lack of a design lead are unknown (RR3, RR4). The employer-not-established entry (RR1) is the one that caps the decision at `conditional_go`.

## Research

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search was refused. Would have checked that Fernquay exists as described and that the posting is live (RR1) |
| 2. Role-family sweep | unavailable | Not sent after the first two calls were refused. Would have set a salary band; without it, the pay is uncalibrated |
| 3. Hiring manager's public footprint | unavailable | Search for Ronan Kehoe was refused. Would have checked his public professional footprint and link to the company (RR1) |

If you grant web search permission, I can run these three targets.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Six people in Galway; booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | First designer: own the booking flow end to end, run research with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Scope read | A first design hire at a six-person company usually means no design peer to review work | `[generic]` pattern for early-stage first hires |
| Market calibration | Not run — the search was refused, so the pay band against this seniority is unknown | — |
| Unknowns | Equity class and vesting; funding and runway; who reviews design decisions | — |
| Contradictions | None between posting and messages | `[grounded]` posting and WhatsApp message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work from Galway for the two office days | hard_gate | direct | medium | none | You moved back to Galway last year; the office is in Galway. Confidence grades your own statement | `[grounded]` your statement | none |
| R2 | Pay of €52,000–€60,000 (your floor) | hard_gate | unclear | none | hard_gate | No floor stated, so it cannot be met or failed yet | `[grounded]` posting silent on your floor | Q1 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as product designer at one company; CV only, not inspected | `[grounded]` CV | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use, self-reported; no file reviewed | `[grounded]` CV | Share a Figma file or screenshots |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers; confirmed, not inspected | `[grounded]` your statement | none |
| R6 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad | `[grounded]` your statement | none |
| R7 | Owns the booking flow end to end | must_have | adjacent | medium | transferability | Checkout redesign is the closest work; the material does not show whole-flow ownership | `[inferred]` from the checkout redesign | G1 |
| R8 | First and only designer | important | unclear | low | discovery | You have never been the only designer; untested, not a gap in evidence | `[grounded]` your statement | Q2 below |
| R9 | Research with school owners (small B2B buyers) | important | adjacent | medium | transferability | Research was with travel-booking customers, not the operators who buy | `[inferred]` from your research sessions | G3 |

**G1 (R7):** Your checkout redesign is real booking-flow work. The gap is whole-flow ownership. Closing it needs an example where you set the direction from research through launch, not only the checkout stage.

**G3 (R9):** Your research skills carry over. The limit is the buyer: school owners buy and run the software, so ask about their workflow, not only the customer journey.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | "Can you send the company registration number and the link to this role on your careers page?" | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The value depends on share class, vesting and exit terms, none of which the posting gives | `[inferred]` from the posting's silence on terms | "What class of shares is this, what is the vesting schedule, and what happens to unvested equity if I leave?" | unresolved |
| RR3 | First designer with no design lead | risk_signal | medium | "You would be our first designer" | There may be no one to review design decisions day to day | `[generic]` pattern for first design hires | "Who reviews design decisions day to day, and who owns product priorities?" | unresolved |
| RR4 | Funding and runway unknown | unknown | — | "We are six people" | Headcount alone does not show how long the company can fund this role | `[generic]` pattern for early-stage companies | "How is the company funded, and how many months of runway are there?" | unresolved |
| RR5 | Pay and scope stated plainly | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | Transparent pay and a defined scope are a good sign | `[grounded]` posting | "What would success look like in the first six months?" | noted |

**Routine steps (no entry):** the WhatsApp message and the emailed invite for a 45-minute video call are routine scheduling `[generic]`. Confirm the invite's sender domain against the company's own website; that is advice, not a warning.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Verify the company on the CRO register and its own website before sharing more | RR1 | `[grounded]` RR1 | pending your approval |
| P2 | Check the invite's sender domain matches the company's website | Routine check | `[generic]` routine scheduling | pending your approval |
| P3 | Ask RR2–RR4 on the call | Equity, first-designer risk, runway | `[grounded]` register | pending your approval |
| P4 | Lead with R5 and R6 in the call; name R7 and R9 as adjacent, with their limits | Honest framing of the gaps | `[grounded]` evidence map | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on your own statements, which are leads until you show artifacts. Unverified leads: none. Rejected inferences: none.

## Gap recovery queue

No questions here; the questions are in the closing block.

## Upgrade menu

- A Figma file or screenshots → R4 to `high`.
- Your pay floor → R2 resolves to met or failed.
- Web search permission → RR1 checked directly, plus the pay band (R2 calibration) and Ronan Kehoe's public footprint.
- The company's registration number and careers page link → RR1 closes or stays open.

**Questions** (3 in total):

1. R2 — Is €52,000 the bottom of what you would accept? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. R8 — Have you ever set design direction with no design peer around you, and what did that look like? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. R9 — Have you done any research with people who buy software for their business, rather than users? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Would you like me to write this assessment into a `tuesday-dossier.md` you can keep?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.