## Job 1: Operations Analyst, Duinvaart Cold Chain (Rotterdam)

**Worth applying to, on conditions. Status: `conditional_go`.** Your SQL, Power BI and depot-facing work match the stated must-haves. The open part is temperature compliance, which nothing you've told me covers. I could not check the employer this run.

**Fit ledger.**

- `hard_gate` — unclear: A9 (Hybrid, three days a week in Rotterdam office)
- `must_have` — direct: A1, A2, A3
- `important` — direct: A4, A5, A6; unclear: A7 (temperature compliance across refrigerated fleet)
- `preferred` — adjacent: A8 (Dutch a plus)

A1, A2 and A3 rest on your stated experience. A7 is the open one, since nothing you gave me touches cold-chain or temperature data. A9 stays unconfirmed until your location and schedule limits are known.

**Hard gates:** none failed; unconfirmed: A9 (Hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown

**Severe red flags:** none found.

**Opportunity ledger.** The posting is specific and its outcomes are measurable (RR3, positive). The temperature-compliance scope is undefined (RR1), and the employer is unverified this run (RR2).

**Conditions for go:**
1. RR2: you find the posting on Duinvaart's own careers site, using contact details from that site, and it is live.
2. RR1 / A7: temperature compliance means analysing data, not running refrigeration or operations you would need to already know.
3. A9: three office days in Rotterdam are workable for you.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, as named in the posting | `[grounded]` JD |
| Mandate | Track on-time delivery and temperature compliance across the refrigerated fleet; weekly Power BI dashboards; route changes with depot managers | `[grounded]` JD |
| Scope read | Reporting and depot-facing analysis; the posting does not say whether the role makes decisions | `[inferred]` from the duty list |
| Market calibration | Not established: the role-family search did not run | — |
| Unknowns | Whether temperature compliance is analysis or operations; contract type; salary (not stated) | — |
| Contradictions | None in the text you pasted; the employer's own site was not checked | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; user-stated, no artifact yet | `[grounded]` your background | none |
| A2 | Strong SQL | must_have | direct | medium | none | Daily use; expect a probe for depth | `[grounded]` your background | none |
| A3 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use; expect a probe | `[grounded]` your background | none |
| A4 | Weekly dashboards in Power BI | important | direct | medium | none | Same tool, same cadence as your depot dashboard | `[grounded]` your background | none |
| A5 | Track on-time delivery | important | direct | medium | presentation | Depot managers use the dashboard; whether you built it is not yet stated | `[grounded]` your background | Q3; then CV edit P2 |
| A6 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review | `[grounded]` your background | none |
| A7 | Temperature compliance, refrigerated fleet | important | unclear | none | discovery | No temperature or cold-chain evidence in what you gave me | — | Q2 |
| A8 | Dutch | preferred | adjacent | medium | transferability | Conversational, not fluent; the posting asks for a plus, not fluency | `[grounded]` your background | P3 |
| A9 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | Your constraints were not given, so the fit cannot be checked | — | Q1 |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Temperature-compliance scope undefined | unknown | — | "track ... temperature compliance across our refrigerated fleet" | The role may need cold-chain or food-safety know-how you lack, or may be data monitoring only | `[inferred]` from the duty against the absence of stated tools or background | What does temperature compliance involve day to day, and what data and tools do analysts use for it? | unresolved |
| RR2 | Employer not verified this run | unknown | — | "Duinvaart Cold Chain, Rotterdam" | The posting may be current or stale, and the employer may be small or new; not established either way | `[generic]` a check that could not run is not a finding about the employer | Can you point me to this posting on your own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Outcomes and scope stated | positive_signal | — | "build weekly dashboards in Power BI" | Defined outputs and measurable success | `[grounded]` JD | Which of these dashboards exist today, and who owns them? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check the posting on Duinvaart's careers site yourself before applying | RR2 | `[generic]` | proposed |
| P2 | Lead the CV with the on-time dashboard and route-performance review, worded to what you did | A5, A6 | `[grounded]` your background | `resume_edits_pending_approval` |
| P3 | Describe your Dutch as conversational, nothing more | A8 | `[grounded]` your background | proposed |
| P4 | Prepare an honest answer on temperature compliance: what you know, what you don't | RR1 | `[inferred]` | proposed |

## Job 2: Supply Planner, Kroonhaven Foods (Utrecht)

**Not worth applying to now. Status: `no_go`.** Three must-haves are absent or only adjacent in what you've given me: planning experience, a planning system, and owning a supply plan. A course will not close a 3+ year requirement.

**Fit ledger.**

- `hard_gate` — unclear: B7 (On-site in Utrecht)
- `must_have` — adjacent: B1 (3+ years of supply or demand planning in FMCG), B4 (fluent Dutch); unclear: B2 (advanced Excel); absent: B3 (SAP IBP or a similar planning system), B5 (own the 13-week supply plan)
- `important` — adjacent: B6 (run the weekly S&OP meeting)

B3 and B5 have no planning-system or plan-ownership experience behind them. B1 and B4 are adjacent with their limits named. B2 is not in what you gave me. B6 is the closest match, on meeting cadence only.

**Hard gates:** none failed; unconfirmed: B7 (On-site in Utrecht); candidate constraints not given — checks against them unknown

**Opportunity ledger.** Specific and internally consistent, with no red flags in the text (positive). The employer is unverified this run, as with Job 1.

**What would have to differ:** 3+ years of FMCG planning, hands-on work with a planning system, and fluent Dutch. Realistic closure is a planning-analyst or demand-analyst role built on your SQL and Power BI, then a move toward planning. That is a `[generic]` path, not a claim about this employer.

## Research accounting

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both company searches were refused permission, so no result came back. Would have checked that each employer exists as described and each posting is live (RR2, and the cap on Job 1) |
| 2. Role-family sweep | unavailable | Both salary and scope searches were refused. Would have set the `[generic]` market calibration for each title |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you want the dossier, I can write these findings to a `tuesday-dossier.md` you can carry into other applications.

**Upgrade menu**

- Your location, hours and right-to-work position → A9 resolves, and Job 1's decision firms up.
- Permission to web-search → the employer check for both postings (RR2) and the salary band stay open. One search is left in the budget.
- A sanitized sample of a dashboard you built, with no confidential figures → A2 and A3 move from `medium` to `high`.
- Any temperature or excursion reporting, even from parcel work → A7 moves off `unclear`.
- An Excel work sample → B2 resolves, but only matters if you reconsider Job 2.

**Questions**

- **A9 (hard gate):** Is there any term for Rotterdam you can't meet: three office days a week, the commute from where you live, or the right to work in the Netherlands without sponsorship?
- **A7 (discovery):** Have you worked with temperature data, cold-chain or food-safety compliance, even in parcel handling of temperature-sensitive goods or in reporting on excursions? What did you do?
- **A5 (presentation):** Did you build the on-time delivery dashboard depot managers use, or maintain it? What was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.