**Decision snapshot: conditional go.** Apply and take the call, after checking three things below. Nothing I found suggests this is a scam. The one thing I could not confirm is that this exact posting is live.

**Is it legit?** Partly confirmed:
- Fernquay's own about page says it makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland, has six people based in Galway, and was founded in 2023 by Ronan Kehoe and Saoirse Doyle. It is funded by its customers. [grounded]
- A LinkedIn result describes Ronan as co-founder and CEO, previously a product lead at a Galway travel-software company for five years. [grounded, from a search snippet; I did not open the profile]
- Saoirse is listed as a co-founder, and Ronan's message calls her CTO. That is consistent, not a contradiction. [grounded]
- The company's careers page at the address I tried does not exist. The posting therefore isn't confirmed live on their site. [grounded]
- A founder messaging on WhatsApp to say "the invite is in your email" is ordinary in small Irish companies. It is not a payment, bank or ID request. [inferred]

**Fit, by requirement**

| # | Requirement | Priority | Fit | Confidence | Evidence / gap |
|---|---|---|---|---|---|
| 1 | 3+ years product design | Must | Meets | Medium | Four years at a Dublin travel-booking company. CV claim, checkable by references. |
| 2 | Strong Figma | Must | Meets | Medium | Daily use, per your CV. No work sample yet. |
| 3 | Has run own user research | Must | Partial | Medium | Monthly usability sessions with travel customers. Gap: B2B research calls with school owners is a different audience. |
| 4 | Works directly with engineers | Must | Meets | Medium | Four-engineer squad. |
| 5 | Owns a flow end to end | Must | Partial | Medium | You redesigned checkout, which is part of booking, but not end-to-end ownership. |
| 6 | Sole or first designer | Implied | Gap | High | You have never been the only designer. This is a capability gap, not a presentation one. It closes with evidence of self-directed work. |
| 7 | Hybrid, Galway office | Stated | Meets | High | You live in Galway. [grounded, from your own statement] |
| 8 | €52k–€60k | Stated | Unknown | — | Depends on your floor, which I don't have. |
| 9 | 0.5–1% equity | Stated | Unknown | — | No outside valuation exists for a customer-funded company, so the value is hard to judge. [inferred] |

**Risks to check before or on the call**
1. **Solo-designer scope (medium).** The role is the company's first designer, with research, booking flow and engineering to work alongside. Ask what support exists: research budget, tooling, and whether Ronan does research himself.
2. **Equity terms (low to medium).** Ask for option type, strike price, vesting, and the approximate cap table. A 0.5–1% stake in a six-person company is worth little without these.
3. **Posting source (medium, unresolved).** Get the link to the live ad, or the email domain the recruiter writes from. Then check the calendar invite comes from that same domain before you accept it.
4. **Channel.** Keep scheduling in the email invite. Don't send bank, tax or ID details before a written offer. If anyone asks for those early, treat it as a warning sign.

**Before the call:** prepare the checkout redesign as one case study. Show the constraints you worked within and the decisions you made alone. That speaks to requirement 6 more than the team-based work does. The skill's mock-interview sibling can rehearse the 45 minutes if you want that.

**Research used:** Research tier: L1 — searches 3 of 5, fetches 2 of 2.

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | yes | About page read. Careers page not found. Queries: "Fernquay Galway booking software", "Fernquay sea kayak surf school booking". |
| 2. Role-family sweep | skipped | Not run. Salary band is unverified. |
| 3. Hiring manager's public footprint | yes | Search snippet only, for "Ronan Kehoe Fernquay co-founder". Page not opened. |

**Dossier offer:** I can write `tuesday-dossier.md` with the full evidence map if you want to keep working this role.

**What would raise confidence:** the checkout case study link (rows 3 and 5), a travel-company reference (rows 1 and 2), your salary floor (row 8), the equity terms (row 9), and the live posting link (the posting-source risk).

**Questions:**
1. What is your salary floor? Is €52k the bottom of what you'd accept?
2. Do you have the link to the live posting, or the email domain the recruiter writes from?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.