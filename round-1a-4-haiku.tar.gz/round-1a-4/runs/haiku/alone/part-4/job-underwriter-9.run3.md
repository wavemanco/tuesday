**Decision: `conditional_go`.** Yes, asking for bank details, a PPS number and a passport scan after a written offer is routine in Irish payroll practice [generic]. This offer names the role, the pay and the hybrid pattern, so it reads like normal onboarding, provided you enter those details only in the employer's own portal, at the address on their own website.
- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Limerick office two days a week), R3 (right to work in Ireland); candidate constraints not given, so checks against them are unknown.
- **Fit ledger:**
  - `hard_gate`: `direct` R1; `unclear` R2, R3 (Limerick office two days a week; right to work in Ireland)
  - `must_have`: `direct` R4, R6, R7, R8, R9; `unclear` R5 (working knowledge of Irish PAYE, PRSI and USC)
  - `important`: `adjacent` R10 (monthly run for 240 staff); `unclear` R12 (answering staff payroll queries); `absent` R11 (pension changes)
  - What matters: R5 is the must-have your background doesn't yet show; R11 is the one absent row, and it's learnable.
- **Opportunity ledger:** the offer matches the ad on role, pay (€40,000 inside the advertised €38,000–€42,000) and hybrid pattern, and you interviewed in person at the office (PS1, PS2). The standing entry RR1 is unresolved because web research was refused, so the employer has not been checked independently.
- **Severe red flags:** none found.
- **What would change this:** conditions. (1) You confirm R2 and R3. (2) The sender's domain matches the employer's own website, and the portal sits on that domain. (3) RR1 clears when you find the role on their careers page.

**Role reality**
- Organisation: Marrowgate Housing, a housing association in Limerick. Stated in the job ad [grounded]; not verified.
- Scope: monthly payroll for 240 staff, starters, leavers and pension changes, monthly reconciliation to the general ledger, staff payroll queries [grounded, job ad].
- Authority: reports to Declan Garvagh, Finance Manager [grounded, offer]. Team size and decision rights are not stated.
- Pay: €40,000 offered against a €38,000–€42,000 advertised band [grounded]. Market calibration was not run (research unavailable).
- Contradictions: none between the ad and the offer.
- Unknowns: pension scheme and provider, payroll system, start date, whether the two Limerick days are fixed.

**Evidence map**

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|---|
| R1 | hard_gate | Salary €38k–€42k | direct | high | n/a | Offer €40,000 | Inside the band | [grounded] |
| R2 | hard_gate | Limerick office two days a week | unclear | low | hard-gate | Not stated | Location not given | [grounded] |
| R3 | hard_gate | Right to work in Ireland | unclear | low | hard-gate | Not stated; offer asks for passport | Status not given | [grounded] |
| R4 | must_have | 2+ years running payroll | direct | medium | n/a | 3 years fortnightly, 90 staff | Self-reported | [grounded] |
| R5 | must_have | Working knowledge of PAYE, PRSI, USC | unclear | low | discovery | Not named in your background | Certificate may cover it; unconfirmed | [inferred] |
| R6 | must_have | Strong Excel | direct | medium | n/a | Daily use; pivots; XLOOKUP | Self-reported | [grounded] |
| R7 | must_have | Payroll qualification or working towards | direct | high | n/a | Payroll Technician certificate, 2024 | Verifiable | [grounded] |
| R8 | must_have | Monthly payroll-to-ledger reconciliation | direct | medium | n/a | Monthly reconciliation done | Self-reported | [grounded] |
| R9 | must_have | Starters and leavers | direct | medium | n/a | Handled in hotel role | Self-reported | [grounded] |
| R10 | important | Monthly run for 240 staff | adjacent | medium | transferability | 90 staff, fortnightly | Same work at larger scale and different cycle | [inferred] |
| R11 | important | Pension changes | absent | low | capability | Manager handled these | No personal experience | [grounded] |
| R12 | important | Answering staff payroll queries | unclear | low | discovery | Not in your background | Not stated | [grounded] |

**Gap recovery queue**
- R2: a commute and location check settles a hard gate. Closes by your confirmation.
- R3: a right-to-work check settles a hard gate. Closes by your confirmation.
- R5: Irish statutory deductions. Closes if your certificate or work covered PAYE, PRSI and USC.
- R10: scale and cycle. Closes by describing how you handled fortnightly runs and volume.
- R11: pension changes. Closes by learning the scheme's process, or by a reference from your manager's notes. Do not claim this experience.
- R12: staff queries. Closes if you have handled payroll queries before.

**Opportunity risk register**

| ID | Class | Severity | Signal | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | risk_signal | medium | Employer not established from attributable sources | "Marrowgate Housing, a housing association in Limerick" | The employer may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. Two in-person interviews at their office point the other way. | [generic] pattern for employers this size, not a claim about this one | Can you confirm the role on your careers page, and who I'd be meeting? | unresolved |
| PS1 | positive_signal | n/a | Interviews held in person at the employer's office | Your account: two in-person interviews | Real premises and named staff | [grounded] | n/a | n/a |
| PS2 | positive_signal | n/a | Offer matches the ad | Offer: "€40,000 a year … hybrid with two days a week in our Limerick office" | Consistent terms | [grounded] | n/a | n/a |

Routine steps, the portal and the link to it get no register entry. The check is advice, in the application plan below.

**Provisional decision:** `conditional_go`. The offer is credible, with conditions tied to R2, R3 and RR1.

**Application plan**
1. Before you accept, find the company's website yourself through a search. Don't use links from the email. Check the careers page lists this role, and phone the switchboard you find there to confirm the offer.
2. Accept by reply, with no bank, PPS or passport details in the email. Passport scans should not go by email.
3. When the portal link arrives, check its domain matches the site from step 1 before entering anything. Enter bank, PPS and passport details only there. Ask HR how the passport scan is stored, and confirm the original is checked on day one (in-person checks are normal).
4. Confirm the Limerick days and your commute before you accept (R2).
5. Positioning: lead with three years running payroll for 90 staff, monthly ledger reconciliation, starters and leavers, Excel (pivots, XLOOKUP) and the 2024 certificate. Say "moving from 90 fortnightly to 240 monthly", not "managed 240". Say you have not processed pension changes yourself, and that you would want a walkthrough in your first weeks. Claim PAYE, PRSI and USC only as far as your certificate or work covered them.

**Evidence status**

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | Web search permission was not granted; the one search was refused and not retried |
| 2 | Role-family sweep for pay and scope | unavailable | Same as above |
| 3 | Hiring manager's public footprint (Declan Garvagh) | unavailable | Same as above; a name was given |

If you want a record of this assessment, I can write it to `tuesday-dossier.md` once we're done.

**Upgrade menu**
- Web search permission: would verify the employer and posting (RR1) and give a pay check for R1.
- Your location and right-to-work status: would settle R2 and R3, which could change the decision.
- Your certificate's syllabus, or a line on Irish statutory deductions: would move R5.
- Pension scheme details (type and provider): would give R11 something concrete to check against.

**Questions**
1. (R2) Can you do two days a week in the Limerick office from where you live?
2. (R3) Do you have the right to work in Ireland without sponsorship?
3. (R5) Did your Payroll Technician course or your hotel work cover PAYE, PRSI and USC in Ireland?

Answer in a sentence, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.