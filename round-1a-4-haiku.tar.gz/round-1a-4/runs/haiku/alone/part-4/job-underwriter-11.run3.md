**Decision snapshot**

| Role | Decision | Why in one line |
|---|---|---|
| Operations Analyst, Duinvaart (Rotterdam) | **conditional_go** | Your core evidence matches closely. Open items are the cold-chain gap, Dutch, and the Rotterdam commute. |
| Supply Planner, Kroonhaven (Utrecht) | **no_go for now** | Two stated must-haves are missing (3+ years FMCG planning, fluent Dutch), and you have no planning-system experience. |

Hard-gate line: no hard gate has failed. Work authorization in the Netherlands is unknown for both roles, since neither posting nor your background states it. The Duinvaart hybrid schedule (three days a week in Rotterdam) is unknown against your constraints.

**Role reality**

- **Duinvaart [grounded]:** Tracks on-time delivery and temperature compliance for a refrigerated fleet, builds Power BI dashboards, and works with depot managers on route changes. The posting is specific and internally consistent. No compensation is stated.
- **Kroonhaven [grounded]:** Owns the 13-week supply plan, balances capacity against forecast, and runs the weekly S&OP meeting. This is a planning-ownership role. No compensation is stated.
- **Market calibration [generic]:** Ops-analyst and planner roles are normally sized by these kinds of requirement lists. I did not check salary bands.

**Evidence map** (confidence is `medium` for CV-only claims, since they are leads until verified)

| # | Priority | Fit | Requirement | Evidence | Confidence | Gap |
|---|---|---|---|---|---|---|
| D1 | must-have | Met | 2+ yrs logistics/ops analysis | 4 yrs as ops analyst, parcel carrier | medium | none |
| D2 | must-have | Met | Strong SQL | Daily use | medium | none |
| D3 | must-have | Met | Power BI or Tableau | Daily Power BI use | medium | none |
| D4 | must-have | Strong match | On-time delivery tracking | Built the on-time dashboard depot managers used | medium | none |
| D5 | must-have | Strong match | Work with depot managers on routes | Ran weekly route-performance review | medium | none |
| D6 | must-have | Gap | Temperature compliance, refrigerated fleet | None stated | — | capability (transferable: SLA monitoring, not temperature) |
| D7 | preferred | Partial | Dutch | Conversational | low | language |
| D8 | hard_gate | Unknown | Hybrid, 3 days/week Rotterdam | Based in Amsterdam, commute not discussed | — | schedule/location |
| D9 | hard_gate | Unknown | Work authorization | Not stated | — | authorization |
| K1 | must-have | Gap | 3+ yrs FMCG supply/demand planning | None. Route-performance review is operations, not planning | — | capability |
| K2 | must-have | Gap | Own a 13-week supply plan / S&OP | None | — | transferability (weekly review cadence only) |
| K3 | must-have | Gap | SAP IBP or similar | None | — | capability |
| K4 | must-have | Unknown | Advanced Excel | Not stated in your background | — | discovery |
| K5 | must-have | Gap | Fluent Dutch | Conversational | low | language |
| K6 | hard_gate | Unknown | On-site Utrecht; work authorization | Amsterdam–Utrecht is a short commute [generic]. Authorization not stated | — | location, authorization |

**Gap recovery queue** (no questions here; the questions are in the closing block)

- **D6 cold chain:** Would close with any temperature-monitoring or perishable-goods experience. Do not claim it without evidence.
- **D7 / K5 Dutch:** Would close with a verified level, such as a certificate or a work-language record. Conversational will not satisfy "fluent" for Kroonhaven.
- **K1–K3 planning:** No honest route to close this quickly. Demand or supply analyst roles that use the same tools would be a stronger target.
- **K4 Excel:** Closes if you can show advanced Excel work.

**Opportunity-side risk register**

- **Employer not verified [medium, standing]:** Web search was refused in this session, so I could not confirm either employer exists as described. This caps Duinvaart at conditional_go. A link to the live posting or the company's careers page would resolve it.
- **Duinvaart compensation not stated [medium]:** Cannot judge against your floor.
- **Kroonhaven compensation not stated [medium]:** Same.
- No red flags in either posting. Neither asks for payment or personal financial details.

**Application plan**

- **Duinvaart:** Lead with the on-time dashboard and route-performance review; those are direct matches. State the cold-chain gap plainly instead of stretching the SLA-monitoring work into temperature experience. Confirm the commute before applying.
- **Kroonhaven:** Do not apply now. Do not position route-performance review as supply planning. That would be an inflated claim.
- Resume edits: none drafted. Any wording for either role would need your approval before use.

**Evidence status**

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | unavailable | Web search permission was not granted; both attempts were refused |
| 2. Role-family sweep (scope, title, pay) | unavailable | Same |
| 3. Hiring manager's public footprint | n/a | No name given |

**Dossier offer:** If you want, I can save this as a `tuesday-dossier.md` so it carries into later sessions.

**Upgrade menu**

- Grant web search and I can verify both employers and check salary bands for these roles.
- A link to the live Duinvaart posting would close the employer-verification gap.
- A Dutch language certificate or a note on your working-language record would settle the Dutch questions.
- Any temperature-monitoring or perishable-goods experience would move D6.

**Questions**

1. Do you have the right to work in the Netherlands, and is three days a week in Rotterdam workable for you?
2. Did any of your parcel-carrier work involve temperature-sensitive or perishable shipments?
3. What is your minimum acceptable salary, so I can judge both offers against it once compensation is known?

Response modes: answer any of these, reply "skip" to leave one open, or ask for the dossier.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.