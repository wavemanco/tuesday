**Decision: conditional go.** Apply and take the call, but verify that Fernquay exists as described before you share more than you have. Your background fits the requirements on paper. The main gaps are being the only designer and a B2B customer group you haven't designed for.

Research tier: L0, no searches. Web search was not granted in this session, so I could not check the company, Ronan Kehoe or Saoirse. Everything below comes from the posting, your message and your background.

## Decision snapshot

- **Fit:** meets the stated years, Figma and user-research requirements on your own account. Partial on "work directly with engineers" (you had four engineers in a squad, not a two-engineer team with no design peer) and on "first designer." Unknown on the school-owner audience.
- **Hard gates:** pay is posted (€52,000–€60,000 `[grounded]`) but I don't know your floor. Location is met (Galway, hybrid, two days a week in the office). No failed hard gates.
- **Opportunity:** the posting is specific and plausible. The company's existence is unconfirmed, which caps this at conditional go.

## Role reality

- **Role:** Product Designer, first design hire, six-person company, owns the booking flow end to end, runs research calls with school owners, ships with two engineers. Works closely with the co-founder. `[grounded]` from the posting.
- **Scope read:** a generalist role at a very early stage. You would own research, flows and shipping with no design lead above you. `[inferred]`
- **Market calibration:** not established. I could not check typical pay or scope for this seniority in Galway, and I won't use memory for market values. `[generic]` pattern only: "first designer" roles often carry broad scope and lower process support.
- **Contradictions:** the posting says "3+ years" and "work directly with engineers"; your background matches both on paper. The posting describes a "messy real project" over a polished deck, which suits you, but it also means no design peers.

## Evidence map (summary)

| # | Priority | Fit | Requirement | Evidence | Confidence |
|---|---|---|---|---|---|
| 1 | must-have | meets | 3+ years product design | 4 years at a Dublin travel-booking company | high (CV) |
| 2 | must-have | meets | Strong Figma | Figma daily | high (CV) |
| 3 | must-have | meets | Own user research | Ran monthly usability sessions with customers; redesigned checkout | medium (CV, no artifacts) |
| 4 | must-have | partial | Works directly with engineers | Squad of four engineers | medium |
| 5 | must-have | gap | First / only designer | Never been the only designer | confirmed gap |
| 6 | preferred | unknown | School-owner audience (B2B, small operators) | Travel-booking consumers | unknown |
| 7 | hard gate | unknown | Pay floor vs €52k–€60k | Not stated | unknown |

## Gap recovery queue

- **Gap 5, sole designer:** the largest real gap. It is transferable: you have worked inside a design-and-engineering squad, not as the only designer. What would close it: an example of you setting your own process with no design lead.
- **Gap 6, school-owner audience:** discovery gap. Your usability work was with travel consumers. Owners running small operations need different research. What would close it: one example of research with a small-business or operator audience, or a note on how you would approach it.
- **Gap 7, pay:** you need your floor first.

## Opportunity risk register

- **Failed attribution (medium, standing):** I could not confirm the employer exists as described. Possible reasons, none ranked as likely: too new or small to be indexed, a stale posting, or not a real hiring employer. This caps the decision at conditional go until verified.
- **Channel (low):** a co-founder messaging on WhatsApp before email is common at very small companies. It is not a warning sign by itself. The check is whether the calendar invite comes from an address on the company's own domain.
- **Equity (medium, unknown terms):** 0.5–1% with no vesting, strike price or cap table information. Ask for the terms in writing before accepting any offer.
- **Red flags:** none found in the posting. Nothing asks you to pay, deposit money, or give bank or ID details before an offer.

## Application plan (as far as the evidence allows)

- **Lead with:** the checkout redesign and the monthly usability sessions. Those are your verified research and ownership claims.
- **Before the 45-minute call, check (advice, not research):**
  1. Ask Ronan for the company's website and careers page. Check that the posting and the team are there.
  2. Check that the invite comes from the company's domain, not a free email address.
  3. Look up the registered company name on the Irish Companies Registration Office (CRO) register. Check that the directors match Ronan and Saoirse.
  4. Look at public LinkedIn profiles for Ronan and Saoirse.
- **On the call:** ask about the first-year priorities, who reviews design work, and the equity terms.
- **Keep the CV factual.** Don't describe yourself as having led a design function or as the only designer; you haven't.

## Evidence status

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | unavailable | Web search not granted this session |
| 2. Role-family sweep (scope, title, pay) | unavailable | Web search not granted this session |
| 3. Hiring manager's public footprint (Ronan Kehoe) | unavailable | Web search not granted this session |

If you grant search in a later turn, I can run targets 1 to 3 at L1 (up to 5 searches and 2 page fetches).

For the 45-minute call itself, the mock-interview skill can rehearse it. This assessment doesn't cover that.

Offer: I can write a `tuesday-dossier.md` file with this assessment, the evidence map and the open questions, so the next session can pick it up.

Upgrade menu, what each missing input would unlock:
- **Company website or careers link:** verifies the employer and clears the failed-attribution entry.
- **Invite sender domain:** confirms the channel matches the company.
- **Your pay floor:** runs the hard-gate check against €52k–€60k.
- **One piece of research work with a small-business audience:** raises the school-owner row from unknown.
- **Search permission:** adds the market calibration and the Ronan Kehoe footprint.

Questions (answer any, or skip any):
1. What is your minimum base salary?
2. What domain did the calendar invite come from, and do you have a company website link?
3. Have you ever done research with small-business owners or operators, not consumers?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.