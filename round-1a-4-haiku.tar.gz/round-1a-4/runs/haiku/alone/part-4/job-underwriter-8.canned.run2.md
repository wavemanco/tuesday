**Decision: no_go on this offer as presented.** Don't send anything: no IBAN, PPS number, passport photo, payment, or cheque. Keep the IBAN to yourself. I haven't used it and don't need it.

**Hard gate, pay floor (not met on the posting's own numbers):** €26/hr × 48 weeks × 30 hrs ≈ €37,400 pre-tax at the top of the range. At 15 hrs it's about €18,700. Reaching €30,000 needs roughly 24+ hrs/week at full rate, and commission is unquantified [inferred]. The posting gives no base salary or hours guarantee.

**Fit ledger (separate from the decision):** Your evidence lines up well with the role's stated requirements.
- Customer service and ticket volume: 3 years, about 60 Zendesk tickets/day (stated, not verified).
- Spreadsheets: weekly Excel tracker (stated).
- Training others: trained two new starters (stated).
- Written English: your messages read clearly [inferred]. Nothing in the posting or messages tests it.
- Quiet place to work: unknown.

Your fit is fine. The problem is the offer's structure and pay.

**Red flags (quoted from the messages, severity high, held while you check):**
1. Before any interview: "send your IBAN, your PPS number and a clear photo of your passport."
2. "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages."
3. "We are posting you a cheque for €2,850. Lodge it to your account, keep €350… and transfer the rest to our equipment partner."
4. The whole process runs on Telegram with no calls or video, and the contact is a generic `postmail.example` address rather than a company domain.

Whatever the sender intends, the cheque step is a well-known way people get drawn into money laundering. Cheques often bounce days or weeks after the money has been paid out, and then the shortfall is yours. Don't deposit it or transfer anything from it.

**Research tier: L0, no searches run.** I haven't checked that Velloway Logistics exists or that this posting is live. That is the one check that would change the picture, so don't rely on the posting's own claims. Find the company through its own website or a directory, not through the Telegram account or the email in the messages, and confirm the role is listed there.

**If you've already shared details or paid anything:** contact your bank now, ask about stopping or reversing any transfer, and report the posting to the jobs site. Consider reporting to the Gardaí, especially if money or documents went out.

**Dossier offer:** I can save this assessment as `tuesday-dossier.md` if you want a record.

**Upgrade menu (what would change the decision):**
- The company's own website or careers page listing this role, with a matching contact domain.
- A written offer from a company-domain address, with the pay structure, hours and no payment or cheque steps.
- Confirmation that the role's pay can reach your €30,000 floor.

**Questions:**
1. Where did you find the posting? Please give the jobs site name and the listing link.
2. Can you find Velloway Logistics on its own website without going through Telegram?
3. Is the €30,000 floor firm, or would you consider a lower base if hours and rates were in writing?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.