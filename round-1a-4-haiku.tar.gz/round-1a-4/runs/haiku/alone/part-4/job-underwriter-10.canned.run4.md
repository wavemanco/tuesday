**Yes, probably worth applying to, once you've checked one number: your pay floor (R2). Status: `hold_pending_answers`.** Fernquay is a real, attributable company: its own site has a live careers page with the same terms as the posting, and the contact is on its own domain. The WhatsApp message asks for nothing but a call. Scheduling a call by chat is ordinary, and nothing in it asks for money, a deposit or bank details. I can't verify Ronan's or Saoirse's titles beyond what the company's own pages and listings say.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown
- **Fit ledger.**
  - `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
  - `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
  - `important` — adjacent: R8 (first designer, no design team around you), R9 (Booking for sea-kayak and surf schools)

  R5 — the method is direct, its audience isn't; R7 — checkout is the bridge, its limit named; R8 and R9 — squad work and travel booking, both limits named.
- **Opportunity ledger.** Clean, with no severe red flags. RR3 (salary inside the market band) and RR4 (employer attributable) are positive signals. RR1 (no visible design review) and RR2 (equity terms) are unknowns, not risks.
- **Severe red flags:** none found.
- **What would change this:** the awaited answer is your pay floor (R2). If it sits at or below €60,000, the status moves to `conditional_go`, with RR1, RR2 and G2 as the conditions. If it's above €60,000, R2 fails and the status is `no_go` unless the employer moves its range.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, booking software (product Kelproster) for sea-kayak, surf and sailing schools in Ireland and Scotland; six people in Galway; founded 2023 and funded by its customers | `[grounded]` fernquay.example/about |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting and careers page |
| First-year outcomes | Not stated | — |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` posting and careers page |
| Scope read | One designer covering the whole booking flow plus research is a broad remit for one hire, normal for a first design hire at a six-person company | `[inferred]` from the three responsibilities against the headcount |
| Market calibration | Product designers with 3–5 years in Ireland: median €57,000, interquartile range €51,500–€62,000. The posting's €52,000–€60,000 sits inside that range. The survey is Ireland-wide, not Galway-specific | `[generic]` Tillerby 2026 survey; `[grounded]` posting range |
| Unknowns | Equity vesting and option type; whether design decisions have a reviewer; research time and budget; Saoirse's title | — |
| Contradictions | None between the posting and the careers page. The CTO title comes only from the WhatsApp message; the about page names Saoirse Doyle as a co-founder and gives no title | `[grounded]` careers page and about page; WhatsApp message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year. Your statement is intake prose, so confidence stops at medium | `[grounded]` your intake message; posting | none |
| R2 | Salary €52,000–€60,000 (pay gate) | hard_gate | unclear | none | hard_gate | The range is stated, so the check is open only because you haven't given a floor. The market band sits inside it | `[grounded]` posting; `[generic]` market band | Q1: your pay floor |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company | `[grounded]` your intake message | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily Figma use; no file yet to inspect | `[grounded]` your intake message | Share one Figma file (upgrade menu) |
| R5 | Has run its own user research | must_have | direct | medium | none | Monthly usability sessions with customers. The method is direct; the audience differs, since school owners are business buyers and you haven't run calls with them | `[grounded]` your intake message; `[generic]` that B2B buyers differ from consumers | Q3 |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your intake message | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout at a travel-booking company. Checkout is part of a booking flow, and you didn't own the whole flow | `[grounded]` your intake message | G1 |
| R8 | First designer, with no design team around you (implied by the posting) | important | adjacent | medium | transferability | You have never been the only designer anywhere, so solo design has no direct evidence. Squad work is the nearest adjacency | `[inferred]` from the posting's "first designer"; `[grounded]` your intake message | G2 |
| R9 | Booking for sea-kayak and surf schools (implied) | important | adjacent | medium | transferability | Travel booking carries over to booking. Activity operators' needs are different | `[grounded]` posting; `[generic]` that activity operators have weather-driven cancellations and lessons | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own the booking flow end to end (R7) | transferability | Checkout redesign in a travel product; no record of owning a full flow | The posting's first responsibility; the bridge needs its limit stated | Owning a flow from first research through to shipped; a feature you scoped and shipped yourself | A case write-up or Figma file of the flow | `[grounded]` your intake message |
| G2 | Work as the only designer (R8) | transferability | Squad work with other designers; never the only designer | This is the role's defining condition | Freelance work, a side project, or a feature you shipped alone | A project you led alone | `[inferred]` from the posting |
| G3 | Booking for activity operators (R9) | transferability | Travel-booking work only | Affects how fast you can frame school owners' needs | Any work with operators who take bookings by phone or on a schedule | Research notes or a demo | `[generic]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Sole-designer review and resources unclear | unknown | — | "You would be our first designer" | No design peer may review decisions, and a first hire at six people may decide alone | `[inferred]` from the single-designer scope against the posting's silence on review | Who reviews design decisions, and what research time and budget is committed to this role? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | Vesting, option type and the valuation behind the percentage are unknown | `[generic]` early-stage equity terms vary; `[grounded]` the posting names no terms | What vesting schedule and option type apply, and what valuation is the percentage based on? | unresolved |
| RR3 | Salary stated and inside the band | positive_signal | — | "€52,000–€60,000" | Pay is published and sits inside the market band | `[generic]` Tillerby band; `[grounded]` posting | Is this range the budget for the hire, and how is the offer set within it? | noted |
| RR4 | Employer attributable on its own site | positive_signal | — | "Apply with one real project to jobs@fernquay.example" | The company is real and the posting is live | `[grounded]` fernquay.example about and careers pages | Which school owners did the team interview last quarter, and could I sit in on one? | noted |

The standing failed-attribution entry does not apply, since the employer was attributed. No register entry is made for the WhatsApp invitation, since scheduling a call by chat is routine.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Accept the call, and check the invite comes from a fernquay.example address | The careers page names jobs@fernquay.example; the invite is the one thing you can check in this process | `[grounded]` careers page | your call |
| A2 | Pick one real project to show; check your employer's confidentiality terms before using the checkout work | The posting asks for one messy real project | `[generic]` common confidentiality terms | your call |
| A3 | On the call: "I've never been the only designer; I worked in a squad with four engineers." | States R8's limit in your own words | `[grounded]` your intake message | pending your approval |
| A4 | Lead with the checkout redesign and the monthly usability sessions | Matches R5 and R7 | `[grounded]` your intake message | pending your approval |
| A5 | Ask RR1 and RR2 verbatim on the call | The register doubles as interview preparation | `[grounded]` register | your call |

Everything marked "pending your approval" is proposed wording or advice, not applied to anything.

## Evidence status

Verified: none yet. Your background is intake prose, so it counts as leads, and confidence stays at medium.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea-kayak surf schools" and "Fernquay Product Designer jobs Galway"; fetched fernquay.example/careers/product-designer and fernquay.example/about. Employer attributed; posting live and consistent with the JD; contact on the company domain |
| 2. Role-family sweep | yes | Searched "Product Designer salary Ireland 3 years experience Galway", which returned the Tillerby 2026 Ireland Design Salary Report (tillerby.example/2026-ireland-design-salary-report). Market calibration `[generic]`; the band is Ireland-wide |
| 3. Hiring manager's public footprint | yes | Name given: Ronan Kehoe. Searched "Ronan Kehoe Fernquay co-founder", which returned a LinkedIn listing (linkedin.example/in/ronan-kehoe), read from its snippet only. Lists him as co-founder and CEO, previously a product lead at a Galway travel-software company. Positioning: `[inferred]` lead with the flow and the research, not visual craft |

## Upgrade menu

- Your pay floor → R2 closes and the status moves, as described in the snapshot.
- The company's equity terms → RR2 closes.
- One inspectable project, such as a Figma file or case write-up (cleared with your employer if it's the checkout work) → R4, R5 and R7 move from medium toward high.
- Any design call you led alone, such as freelance work, a side project or a feature you shipped alone → R8 and G2 narrow.
- A deeper research pass on Fernquay (funding, leadership, hiring history; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want this written up as a file you can keep, I can produce a `tuesday-dossier.md` with the evidence map and register together.

1. **R2 —** What's the lowest salary you'd accept, and are there other hard limits I should check, such as contract type or office days beyond two?
2. **G2 —** Have you ever made a design call with no other designer to check it, such as freelance work, a side project, or a feature you shipped alone? What did you decide, and what happened?
3. **G1 —** Have you owned a flow from first research through to what shipped, and which parts were yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.