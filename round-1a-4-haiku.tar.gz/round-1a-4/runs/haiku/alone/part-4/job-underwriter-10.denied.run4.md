## Decision snapshot

**Conditional go, held until you verify the company exists as described.** The role fits your evidence well. I could not confirm the employer, so the decision is capped at conditional go.

- **Fit:** four of the five stated requirements are met by your background. The gaps are being the only designer and owning the booking flow end to end.
- **Hard gates:** location (two days a week in Galway) meets your stated situation. Pay (€52,000–€60,000) is **unknown**, because you have not told me your floor.
- **Failed rows:** none on the fit side. One standing risk entry: failed attribution (below).

Research tier: L1, with every search refused by permission, so nothing about Fernquay or Ronan Kehoe is verified.

## Role reality

- **Role:** Product Designer, first design hire at a six-person company building booking software for sea-kayak and surf schools, in Galway. Owns the booking flow, runs research with school owners, works alongside two engineers, reports most closely to co-founder Ronan Kehoe. `[grounded]` from the posting.
- **Pay:** €52,000–€60,000 plus 0.5–1% equity. The equity has no stated valuation, so its value is unknown. `[grounded]`
- **Market calibration:** not established. My research could not run, and I won't supply market figures from memory.
- **Scope read:** "own the booking flow end to end" is a larger scope than a checkout redesign. `[inferred]` from the wording.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Basis |
|---|---|---|---|---|---|---|
| 1 | 3+ years product design | Must-have | Meets | High | — | 4 years, Dublin travel-booking company. Stated, not checked. |
| 2 | Strong Figma | Must-have | Meets | Medium | — | Daily use stated. No work sample seen. |
| 3 | Has run own user research | Must-have | Meets | Medium | — | Monthly usability sessions with customers. Not research calls with school owners, so the domain is different. |
| 4 | Works directly with engineers | Must-have | Meets | Medium-high | — | Four-engineer squad. |
| 5 | Owns a booking flow end to end | Must-have | Partial | Medium | Capability | You redesigned checkout. End-to-end ownership is not shown. |
| 6 | Works as the only designer | Implied | Gap | Low | Transferability | You have never been the sole designer. No evidence either way. |
| 7 | Hybrid, two days in Galway | Hard gate | Meets as stated | Medium | — | You moved back to Galway. Confirm the office days are workable. |
| 8 | Pay €52,000–€60,000 | Hard gate | Unknown | — | — | Your floor is not stated, so this is not checked. |

## Gap recovery queue

- **Row 5 (end-to-end ownership):** closes with a concrete example of you deciding the scope of a flow, not just executing a redesign. The question for this is in the closing block.
- **Row 6 (sole designer):** closes with any evidence of working without a design peer, such as a side project, freelance work, or a time you were the one deciding. The question for this is in the closing block.

## Opportunity risk register

- **Failed attribution (standing, severity medium):** I could not confirm that Fernquay exists as described. Possible reasons, none ranked as likely: the company is too new or small to have a web presence; the posting is stale; or it is not a real hiring employer. This caps the decision at conditional go until verified. To resolve it:
  - Search the Companies Registration Office register for the company name. This is a check for you to run; I did not run it.
  - Find the live posting on a job board or the company's own careers page, and compare it with what you were sent.
  - Check that the email domain on Ronan's calendar invite matches the company's domain.
- **Early-stage company (opportunity signal):** six people, first designer hire, equity offered. These are normal for a startup, but they mean less structure and less support.
- **First contact by WhatsApp:** a co-founder reaching out by WhatsApp is informal. Arranging an interview by chat is routine, so I have not logged it as a red flag. Confirm the invite comes from the company's own domain, and keep the call on video.
- **Red flags:** none. Nobody has asked you to pay, deposit anything, or give bank, tax or ID details.

## Application plan

1. **Verify first, then engage.** Run the three checks above before the call. Don't share ID, bank, or tax details, and don't pay anything.
2. **Pick your lead story.** Lead with the checkout redesign and the monthly customer usability sessions. Those are verified facts about your work.
3. **Don't overclaim scope.** Say "redesigned the checkout flow", not "owned the booking flow", unless you did own its scope. Expect Saoirse, the CTO, to ask how you would work without a design peer; prepare a truthful answer.
4. **Pay.** Before the call, decide your floor. Then check whether €52,000 is above it.

## Evidence status

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | Web search permission was not granted, so the call was refused. |
| 2 | Role-family sweep (pay and scope norms) | unavailable | Same refusal. |
| 3 | Ronan Kehoe's public professional footprint | unavailable | Same refusal. |

## Dossier offer

If you'd like, I can save this assessment as a `tuesday-dossier.md` file to carry into later sessions.

## Upgrade menu

- **Web search permission:** would allow checks on the company and Ronan's public footprint, and would let me test the failed-attribution entry.
- **Your salary floor:** would settle the pay hard gate.
- **Checkout case study or a Figma sample:** would raise the confidence on your Figma and redesign claims.
- **Any example of working alone on a product area:** would move row 6 from "gap" to "partial".

## Questions

1. What is your salary floor? Is €52,000 above it?
2. Did you apply through a link on Fernquay's own site or job board, and what email address did Ronan's invite come from?
3. Have you ever owned a product decision alone, even on a side project or freelance piece?

Response modes: answer any of these in prose, or say "skip" to leave one open. If you grant web search permission, I'll run the three research targets.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.