## Decision snapshot

**Posting 1, Operations Analyst at Duinvaart: worth your time. Status: `conditional_go`.**
**Posting 2, Supply Planner at Kroonhaven: not worth your time now. Status: `no_go`.**

### Posting 1: Duinvaart Cold Chain

**Fit ledger.**
- `hard_gate`: unclear: A8 (hybrid, three days a week in Rotterdam)
- `must_have`: direct: A1–A5; adjacent: A6 (temperature compliance)
- `preferred`: adjacent: A7 (Dutch)

**Opportunity ledger.** Specific and close to your current work. No salary is stated. The employer is unverified (see RR1).

- **Hard gates:** none failed; unconfirmed: A8 (hybrid, three days a week in Rotterdam). Your location and schedule constraints were not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Rotterdam three days a week is workable for you; (2) the listing is live and the employer checks out on its own site, which I could not do here; (3) you accept that the cold-chain side is a real gap and say so honestly.

### Posting 2: Kroonhaven Foods

**Fit ledger.**
- `hard_gate`: unclear: B7 (on-site in Utrecht)
- `must_have`: absent: B1 (3+ years FMCG planning), B4 (SAP IBP or similar); adjacent: B3 (S&OP), B6 (fluent Dutch); unclear: B2 (13-week plan), B5 (advanced Excel)

**Opportunity ledger.** Clearly scoped, with no salary stated. The role is a planning job, and your evidence is in analysis and delivery performance.

- **Hard gates:** none failed; unconfirmed: B7 (on-site in Utrecht). Your location constraints were not given.
- **Severe red flags:** none found.
- **Why no_go:** the core of the role is planning. You have never worked in planning, and the 3+ years and planning-system requirements are must-haves with no evidence behind them. Years of experience is not a hard gate under this framework, but the gap is absent, not partial. The change that would reverse this is three years of FMCG planning, which you cannot add quickly.

## Role reality

| Element | Posting 1: Duinvaart | Posting 2: Kroonhaven | Provenance |
|---|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | Kroonhaven Foods, Utrecht; chilled ready meals | `[grounded]` postings. Not confirmed as real employers; see RR1 |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | Own the 13-week supply plan, balance capacity against forecast, run weekly S&OP | `[grounded]` postings |
| Scope read | Ordinary for an analyst role; close to your current job | Ordinary for a planner role, and a planning role, not an analyst one | `[inferred]` from the listed duties |
| Compensation | Not stated. Band unknown: no research available | Not stated. Band unknown: no research available | `[grounded]` postings (absent) |
| Unknowns | Cold-chain depth, team size, Dutch use day to day, schedule flexibility | Planning-system landscape, team structure, Dutch use in meetings | — |
| Contradictions | None found in what was provided | None found in what was provided | — |

## Evidence map

Your claims are from your own background as described in this session. They are CV-level, so confidence is `medium` where you have stated daily use, and nothing is `high` until a work sample or other artifact backs it.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | 2+ years logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier | `[grounded]` your background | Confirm dates and title when asked |
| A2 | Strong SQL | must_have | direct | medium | none | SQL daily | `[grounded]` your background | Work sample (see upgrade menu) |
| A3 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily; on-time delivery dashboard | `[grounded]` your background | Work sample; Q3 |
| A4 | Weekly dashboards | must_have | direct | medium | none | The on-time dashboard depot managers use | `[grounded]` your background | Q3: did you build it or use it? |
| A5 | Work with depot managers on route changes | must_have | direct | medium | none | Ran the weekly route-performance review | `[grounded]` your background | none |
| A6 | Track temperature compliance across refrigerated fleet | must_have | adjacent | low | transferability | On-time tracking transfers; no temperature or cold-chain evidence | `[inferred]` | Q2 |
| A7 | Dutch a plus | preferred | adjacent | medium | capability | Conversational, not fluent | `[grounded]` your statement | State it honestly |
| A8 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | low | discovery | Your location and schedule limits were not given | — | Q1 |
| B1 | 3+ years FMCG supply or demand planning | must_have | absent | none | capability | No planning role; you have never worked in planning | `[grounded]` your statement | None available in the short term |
| B2 | Own the 13-week supply plan, balance capacity against forecast | must_have | unclear | low | transferability | No evidence the route review balanced capacity against forecast | `[inferred]` | none |
| B3 | Run the weekly S&OP meeting | must_have | adjacent | low | transferability | Weekly cross-functional performance review is the nearest analogue | `[inferred]` | none |
| B4 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning system in your background | `[grounded]` your background | none |
| B5 | Advanced Excel | must_have | unclear | low | discovery | Excel not mentioned | — | Ask if you reconsider B |
| B6 | Fluent Dutch | must_have | adjacent | medium | capability | Conversational, not fluent | `[grounded]` your statement | State it honestly |
| B7 | On-site in Utrecht | hard_gate | unclear | low | discovery | Location limits not given | — | Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | What would close it |
|---|---|---|---|---|
| G1 | Temperature compliance (A6) | transferability | Delivery-performance tracking transfers; no temperature or cold-chain data | Any temperature-monitored or food or pharma work, even partial; a sanitized example of monitoring or reporting that involved temperature |
| G2 | Dutch (A7, B6) | capability | Conversational only | Dutch used at work in a meeting or with depots; a self-rating you can defend. This matters most for B, which is not recommended |
| G3 | Planning experience (B1, B4) | capability | None | Nothing in the short term. Closing this would take actual planning work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live listing unverified (both) | risk_signal | medium | — | Could be too new or small, a stale posting, or not a real hiring employer; none ranked as likely. Caps Posting 1 at `conditional_go` | `[generic]` standing entry. Research could not confirm the employer | Is the listing live at the company's own careers page, and what is the recruiter's contact domain? | unresolved |
| RR2 | Salary not stated (Posting 1) | unknown | — | "Hybrid, three days a week in our Rotterdam office" (no salary) | The posting may withhold salary; the band is unknown here | `[grounded]` posting (absent) | What is the salary range for this role? | unresolved |
| RR3 | Salary not stated (Posting 2) | unknown | — | (no salary) | Same as RR2 | `[grounded]` posting (absent) | What is the salary range for this role? | unresolved |
| RR4 | Specific, measurable duties (Posting 1) | positive_signal | — | "Track on-time delivery and temperature compliance across our refrigerated fleet" | Clear scope; success is measurable | `[grounded]` posting | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm Posting 1's listing is live and check the company's own site before applying | RR1 | `[generic]` | pending your approval |
| P2 | Lead your CV with the on-time dashboard and the route-performance review, then SQL and Power BI, with a work sample | A1–A5 | `[grounded]` your background | pending your approval |
| P3 | Describe cold-chain honestly: delivery-performance tracking that transfers, with no cold-chain experience claimed | A6, G1 | `[inferred]` | pending your approval |
| P4 | Describe Dutch as conversational, not fluent | A7 | `[grounded]` your statement | pending your approval |
| P5 | Ask the recruiter for the salary range and the Rotterdam schedule before a first interview | RR2, A8 | `[generic]` | pending your approval |
| P6 | Do not apply to Posting 2 now. Put the time into Posting 1 and into ops-analyst roles | B1–B4 | `[inferred]` | pending your approval |

Nothing above is external yet. Every row needs your approval before it is used.

Phrase the dashboard work as you actually did it. "Used" and "built" are different claims. Q3 is there because I cannot tell which one is true.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two web searches for the two employers were refused. Search permission is not granted in this session. These would have confirmed each employer exists and each posting is live (RR1) |
| 2. Role-family sweep | unavailable | Would have set a salary band for both roles (RR2, RR3) |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- **Turn on search permission** → a check that both employers exist and their postings are live, plus a role-family salary band for both roles. Both postings withhold salary, so this is the only way to calibrate it without asking the recruiter.
- **A sanitized work sample** of the on-time dashboard or route review → A2 and A3 move from `medium` to `high`.
- **Any cold-chain or temperature-monitored experience, even partial** → A6 moves from `adjacent` toward `direct`, and G1 closes.
- **Your Dutch level, described concretely** (where you use it, with whom) → A7 and B6 get a defensible rating.
- **Your salary floor** → RR2 and RR3 can be set against the band.

If you want, I can write this up as a `tuesday-dossier.md` that a later mock-interview session can pick up for interview prep.

**Questions**

1. (A8) Can you work in Rotterdam three days a week, and is that a firm limit?
2. (A6) Have you worked with temperature-controlled or cold-chain data, even partly?
3. (A2–A4) For the on-time dashboard, did you build it or use and maintain it, and which parts were yours?

Answer in prose, say skip, or say you don't know. A skip counts as an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.