**Decision: `conditional_go`.** Apply, but verify Fernquay before you give them more time. I could not confirm the company exists as described, and that caps the decision at conditional.

**Research tier: L1 — searches 2 of 5, fetches 0 of 2.** Both search calls were refused because web search permission was not granted, so nothing about Fernquay is established from outside sources.

## Decision snapshot

- **Fit (your CV, not research):** Strong on the stated requirements. Four years of product design, daily Figma, your own usability sessions, and squad work with four engineers each map directly to a requirement.
- **Fit gaps:** (1) You have never been the only designer, so "first designer" is a capability gap, not a credential gap. (2) Your research was with travel-booking customers, not with small business owners, so running calls with school owners is a transferability gap.
- **Hard gates:** Hybrid in Galway is compatible with where you live. Pay is unknown against your floor, because you have not told me your floor.
- **Opportunity:** The employer is unverified. The posting is specific (six people, a named co-founder, a named CTO, a salary band, equity, hybrid terms), which is a normal shape for an early-stage company. Nothing in the posting or the message asks you to pay, to send bank or ID details before an offer, or to be hired through chat alone.

## Role reality

- Product Designer, first design hire, owning the booking flow end to end, with research and engineering work. The scope is broad for one person, and you would be the sole design voice.
- Compensation: €52,000–€60,000 plus 0.5–1% equity. I could not check this against the market. Any comparison is `[generic]` and I have not made one. The equity figure is small, and its value depends on outcomes I cannot assess.

## Evidence map (condensed)

| # | Requirement | Fit | Evidence |
|---|---|---|---|
| 1 | 3+ years product design | Strong | 4 years, Dublin travel-booking company |
| 2 | Strong Figma | Strong | Daily use |
| 3 | Own user research | Strong | Monthly customer usability sessions |
| 4 | Work directly with engineers | Strong | Squad of four engineers |
| 5 | Own booking flow end to end | Partial | Checkout redesign; not full ownership |
| 6 | Research with school owners | Partial | Consumer research; B2B owners untested |
| 7 | Sole or first designer | Gap | Never been the only designer |

## Opportunity risk register

- **Unverified employer (medium).** I could not confirm that Fernquay exists as described, nor that the posting is live. Possible explanations include a very new or very small company, a stale posting, or an employer that is not hiring in the way described. None of these is ranked as likely. This becomes resolved once you check the items below.
- **WhatsApp first contact (low).** A co-founder reaching out by WhatsApp to arrange an interview is informal, not disqualifying, and common in small Irish companies. The email invite is the thing to verify.
- **Pay mismatch (unknown).** Depends on your floor, which is not stated.

## Application plan

1. **Verify before the call (30 minutes):**
   - Find the company's own website and check that the careers page carries this posting, word for word.
   - Check the email domain of the calendar invite. It should match the company's website domain, not a generic mail provider.
   - Look up Fernquay in the Companies Registration Office register and check that the name, the directors and the Galway address line up.
   - Check that Ronan Kehoe and Saoirse appear on LinkedIn with matching roles.
   - Do not reply with personal details beyond what you would share with any applicant.
2. **If those check out,** take the call. Lead with the checkout redesign and the usability sessions, since those are your verified evidence. Name the sole-designer question directly. Ask what support exists for a first designer.
3. **If they do not check out,** stop. Do not share more of your CV or any identity documents.

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | Web search permission was refused |
| 2 | Role-family sweep (market pay and scope) | unavailable | Web search permission was refused |
| 3 | Hiring manager's public footprint (Ronan Kehoe) | unavailable | Web search permission was refused |

## Upgrade menu

- **Live posting link or company website:** Lets me confirm the company exists and that the posting is consistent. This would move the employer item out of the register.
- **Your salary floor:** Lets me check €52,000 against it.
- **Grant web search permission:** Lets me run the three research targets above. I will run them on your go-ahead.
- **Email domain of the invite:** Lets you check it yourself, or lets me compare it to the company site once I have that.

I can also put what we have into a `tuesday-dossier.md` if you want a record for later.

Three questions:

1. Do you have a link to the live posting or the company's website?
2. What is your minimum acceptable salary?
3. Are you comfortable being the only designer, or is that a dealbreaker?

You can answer any of these, reply "skip", or reply "pass" to close the item.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.