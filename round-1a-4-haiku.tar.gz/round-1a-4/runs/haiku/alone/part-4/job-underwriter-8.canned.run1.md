**Don't go ahead on these terms, and don't send anything yet.** I can't confirm this employer is real from what you've shared, and the requests in the messages are ones a legitimate employer doesn't make.

**What's wrong with the process**

- **Paying for the job:** Asking you to pay €349 for a "work kit" before you start is the clearest warning sign. Employers supply equipment. They don't invoice new staff for it, and a promise of a refund "with your first wages" doesn't change that.
- **The cheque:** Being sent €2,850 and asked to lodge it, keep €350 and pass the rest to a third party is a common pattern. Cheques can take weeks to bounce. By then you've transferred your own money, and the bank will hold you responsible for it.
- **Your bank details and ID too early:** Asking for your IBAN, PPS number and passport photo before any written offer, contract or verified company is a serious risk. That's the information used for identity theft and fraudulent account activity.
- **Telegram-only hiring:** No call, no video, no company email domain, and a personal-looking handle for a logistics firm. The "chat interview" happened in the same app as everything else.
- **Vague pay:** "Up to €26/hour plus commission" with no contract, hours guarantee or employer details.

**Don't paste your IBAN into the chat**, even as a "test" or to "confirm" details.

**How to check it yourself**

1. Look up Velloway Logistics on the Companies Registration Office (cro.ie) and find its actual website, phone number and address. Don't use contacts supplied by the sender.
2. Call that number, or use the contact form on the company's own site, and ask whether @VellowayHiring and velloway.hr@postmail.example are theirs. Ask whether they're recruiting for this role.
3. If you have already sent any money or details, contact your bank now and report it. In Ireland, you can also report it to the Gardaí and through the Citizens Information service.

**On fit and pay**

Your background suits real customer operations and coordinator roles. Three years of Zendesk ticket volume, training new starters and keeping an Excel tracker are all things employers look for. At the stated rate, €30,000 a year needs roughly 23 paid hours a week at €26 flat, and the commission is unspecified, so it can't be relied on. Real roles with a salary band, a written contract and a named employer will be easier to compare. I can help you search for those or draft a reply asking Velloway to verify itself.

**Research tier: L0 — no searches.** This assessment is based only on the posting and messages you provided.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.