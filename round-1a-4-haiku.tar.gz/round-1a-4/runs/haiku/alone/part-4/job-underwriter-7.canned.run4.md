**Decision snapshot**

**Worth applying to, with conditions. Status: `conditional_go`.**

**Fit ledger** (confidence is in the evidence map below)

- `hard_gate`: direct, as you stated them: R1 (current NMC Adult registration), R2 (full UK driving licence), R3 (based in Halifax).
- `must_have`: direct: R4 (post-registration experience), R7 (insulin administration), R6 (catheter care). Adjacent: R5 (wound and leg-ulcer care), R8 (care planning). Unclear: R9 (end-of-life visits), R11 (clear written records and electronic record). Absent: R10 (holding your own caseload).
- `preferred`: absent: R12 (Doppler assessment).

**Hard gates:** none failed. R1 and R2 are met as stated. I haven't checked either: confirm both yourself on the NMC register and your driving record.

**Opportunity ledger:** Sound employer, under-specified role. The main unknowns are caseload size, out-of-hours expectations and whether Doppler training is provided. I found no red flags. The careers page I tried did not load, so I could not confirm the posting is live.

**Conditions for go:**
1. Confirm the advert is live, through the link you were sent or the recruiter.
2. Confirm your NMC registration and licence yourself.
3. Describe your discharge-to-assess work as home visits. Don't describe it as a caseload.

**Research tier: L1 — searches 3 of 5, fetches 2 of 2; user links read 0**

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff; four locality hubs | `[grounded]` organisation's About page |
| Mandate | Housebound adults at home; small caseload with senior community nurse support; end-of-life visits; electronic patient record | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage. Pool cars provided | `[grounded]` advert |
| Market calibration | Band 5 community staff nurses, England: median basic pay £34,300, interquartile range £32,400–£36,600; 61% of respondents paid mileage. The advert's band brackets the median. The figures come from a search snippet; I didn't open the full guide | `[generic]` Wardround 2026 pay guide |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. In 2025 she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker profile. Her interest in Doppler is `[inferred]` from that talk |
| Unknowns | Caseload size; out-of-hours and on-call; lone working; whether Doppler training is given; contract length (not stated) | — |
| Contradictions | None found between the advert and the About page | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC Adult registration | hard_gate | direct | medium | none | Stated as active, revalidation March 2028; not checked by me | `[grounded]` your CV, unchecked | Check your NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Stated as full, category B; not checked by me | `[grounded]` your CV, unchecked | Check your driving record |
| R3 | Based in Halifax | hard_gate | direct | high | none | You live in Halifax | `[grounded]` CV | none |
| R4 | One year or more post-registration | must_have | direct | high | none | Five years as a staff nurse | `[grounded]` CV | none |
| R5 | Wound and leg-ulcer care | must_have | adjacent | medium | capability | Pressure and surgical wounds are direct. Leg ulcers are not in your CV | `[grounded]` CV; `[inferred]` adjacency | Gap G2 |
| R6 | Catheter and continence care | must_have | adjacent | medium | capability | Catheter care is direct. Continence isn't in your CV | `[grounded]` CV | Gap G2 |
| R7 | Insulin administration | must_have | direct | high | none | Stated in CV | `[grounded]` CV | none |
| R8 | Care planning | must_have | adjacent | medium | transferability | Discharge planning for patients at home is the nearest match | `[inferred]` from CV | Gap G1 |
| R9 | End-of-life visits | must_have | unclear | low | discovery | Not in your CV | — | Gap G3 |
| R10 | Holding your own caseload | must_have | absent | medium | capability | You have never held a caseload. Home visits in discharge-to-assess are the nearest experience | `[grounded]` CV | Gap G1 |
| R11 | Clear, timely written records; electronic record | must_have | unclear | low | discovery | Your CV says nothing about records or EPR systems | — | Gap G3 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | high | capability | Your CV states you have never done one | `[grounded]` CV | Gap G2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload (R10), care planning (R8) | capability, transferability | Home visits and discharge planning, but no caseload | Holding a caseload is central to the role | Discharge-to-assess visits; planning each patient's first week at home | Example of a patient plan you led, anonymised | `[grounded]` CV; `[inferred]` bridge |
| G2 | Leg ulcers, Doppler (R5, R12) | capability | Pressure and surgical wounds only | Leg ulcers and Doppler are named in the advert, and the Doppler item is desirable | Wound assessment on the ward and at home | Any leg-ulcer or Doppler course, or a plan to train | `[grounded]` CV |
| G3 | End-of-life visits, records (R9, R11) | discovery | Not in CV | Essential for the role | Any palliative or end-of-life care on the ward; documentation on the ward and at home | Named examples of records you wrote | — |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload size not stated | unknown | — | "a small caseload" | Could be large, or with little support | `[grounded]` advert, silent on numbers | How many patients per nurse, and what support does the senior nurse give? | unresolved |
| RR2 | Posting may not be live | risk_signal | medium | advert provided; careers page did not load | Posting may be closed, or the link was misdirected | `[grounded]` my fetch failed | Can you send the live link or the recruiter's email? | unresolved |
| RR3 | Doppler training may be provided | positive_signal | — | Advert lists Doppler as desirable | Lead speaker has promoted Doppler training for new staff | `[inferred]` from the forum talk | Is Doppler training provided, and in what time frame? | noted |
| RR4 | Out-of-hours and on-call not stated | unknown | — | Not mentioned | Community roles often include on-call | `[generic]` | What is the on-call pattern? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the advert is live through its link or the recruiter | RR2 | `[grounded]` | You to do |
| A2 | Check your NMC register entry and driving record | R1, R2 | `[grounded]` | You to do |
| E1 | Frame discharge-to-assess home visits as community practice, with wound, catheter and insulin examples. Make no claim of caseload or Doppler | R3–R10 | `[grounded]` CV | Pending your approval |
| Q1 | Ask the contact (Rhiannon Mabbott, via the advert) about caseload size, support and Doppler training | RR1, RR3 | `[grounded]` advert | Pending your approval of the message |

**Evidence status**

Research tier: L1 — searches 3 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax"; fetched calderbrookhealth.example/about. Confirms the entity and its scale. The careers page address I tried returned no page, so the posting's liveness is unconfirmed. Moved the organisation row and RR2 |
| 2. Role-family sweep | yes | Searched the band and salary terms. Returned the Wardround 2026 pay guide (snippet only). Moved the market calibration row |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead". Returned a forum speaker profile. Moved the hiring-contact row and RR3 |

**Upgrade menu**

- Deep research at L2 (up to 5 more searches and 2 more fetches): Calderbrook's funding, leadership changes, public employee reports. Unlocks a sharper read of contract stability. Offered once; say if you want it.
- The live posting link or recruiter's email. Unlocks confirmation of RR2.
- A leg-ulcer, Doppler or end-of-life course, or a record of one. Unlocks R5, R9 and R12.
- A patient-plan example, anonymised. Unlocks G1 and R8.

If you'd like, I can write this assessment to `tuesday-dossier.md` so it can be reused later.

**Questions**

1. In discharge-to-assess, how many home visits did you do in a day, and how often did you go alone? (G1, R10)
2. Have you done any leg-ulcer assessment or Doppler training, even as a course? (G2)
3. Did you do any end-of-life or palliative home visits in your discharge work? (G3)

Answer in a line each, or say skip for any.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.