**Decision: conditional go.** Apply. The role fits your strongest skills, and the one real gap is that you've never been the only designer. Verify the company before the call, and treat the WhatsApp message as normal for a six-person Irish startup, not a warning sign.

**Fit**

| Requirement | Your evidence | Fit |
|---|---|---|
| 3+ years product design | 4 years at a Dublin travel-booking company | Strong |
| Strong Figma | Daily use | Strong |
| Own user research | Monthly usability sessions with customers | Strong (you ran these, but they were a recurring programme, not open-ended discovery with school owners, so say that clearly) |
| Works directly with engineers | Four-engineer squad | Strong |
| Own the booking flow end to end | Redesigned checkout, a closely related flow | Good, but booking is new to you |
| First or only designer | Never done it | Gap (capability, not a hard gate) |

The gap is about working without design peers, a design system, or a manager who knows design. Don't claim you've done it. Ask about it on the call.

**Legitimacy**

- The search found a Fernquay "About" page saying it makes booking software for sea-kayak, surf and sailing schools, has six people in Galway, and was founded in 2023 by Ronan Kehoe and Saoirse Doyle. It also found a LinkedIn profile listing Ronan as co-founder and CEO, previously a product lead at a Galway travel-software company.
- Those are search snippets. I haven't opened either page, so treat them as leads until you have.
- The posting's own details (salary, hybrid pattern, the dog) are specific and consistent with a small company. Nothing you've shared asks you to pay, buy equipment, or hand over bank or ID details before an offer.
- Founders messaging on WhatsApp to arrange a call is common in small Irish companies. What matters is whether the calendar invite arrives from a Fernquay address.

**Before the call (about 30 minutes)**

1. Open the company website and check that the careers page lists this role and that the contact details match.
2. Search the Companies Registration Office (cro.ie) for Fernquay and check the registered name, date and directors against Ronan and Saoirse.
3. When the invite arrives, check that it comes from a domain that matches the website. If it doesn't, ask Ronan to confirm by email before accepting.

**Questions to ask on the call**

- "Who will I work with day to day, and what does design support look like when I'm the only designer?"
- "What is the equity: share class, vesting, strike price, and what happens if I leave?"
- "What is your runway, and is the research budget funded?"

**Negotiation**

€52–60k is a stated band. Work out your floor before you talk to them. For equity, 0.5–1% at an early-stage company is normal only if the terms are written down, so ask for the option terms in writing before you accept.

Research tier: L1, two searches of five, no page fetches of two. I can open the About and LinkedIn pages if you want the details checked, or look up the Companies Registration Office entry.

Would you like me to fetch the About page and check the careers listing?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.