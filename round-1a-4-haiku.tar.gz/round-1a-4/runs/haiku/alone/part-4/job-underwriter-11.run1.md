**Duinvaart Cold Chain (Operations Analyst): yes, worth applying to, on one condition. `conditional_go`.**

**Kroonhaven Foods (Supply Planner): no, not worth your time now. `no_go`.**

I couldn't check either employer. The web search tool wasn't permitted in this session, so every "employer verified" question below is still open.

---

## Duinvaart Cold Chain, Operations Analyst

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, three days a week in our Rotterdam office)
- `must_have`: direct: R2, R3, R4, R5, R7; adjacent: R8 (work with depot managers on route changes)
- `important`: adjacent: R6 (track temperature compliance)
- `preferred`: adjacent: R9 (Dutch a plus)

R1, the one gate, is unconfirmed. R6 is the weakest must-level bridge, at low confidence. R8 and R9 are adjacent, with their limits named in the map.

**Opportunity ledger.** The role is clearly scoped, with named outcomes (RR3). Pay is withheld (RR2). The employer is unverified (RR1), which caps the decision at `conditional_go`.

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days a week in our Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** conditions for go are (1) R1 confirmed workable with your schedule, (2) RR1 cleared by finding the role on Duinvaart's own careers page, and (3) R6 framed as adjacent, never as cold-chain experience.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | `[grounded]` JD header; existence not verified (RR1) |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| First-year outcomes | None stated | `[grounded]` JD is silent |
| Working pattern | Hybrid, three days a week in Rotterdam | `[grounded]` JD |
| Scope read | Analyst role with depot-facing reach; no team or decision rights stated | `[inferred]` from the responsibilities list |
| Market calibration | Not run; the role-family search was refused | — |
| Unknowns | Salary; whether this role decides route changes or only proposes them; source of temperature data | — |
| Contradictions | None within the posting | `[grounded]` JD only; no careers page checked |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in our Rotterdam office | hard_gate | unclear | none | hard_gate | Your schedule and location constraints weren't given, so nothing settles this | `[grounded]` JD |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; CV-level, no artifact | `[grounded]` your background |
| R3 | Strong SQL | must_have | direct | medium | none | Daily use, per your background; no artifact | `[grounded]` your background |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use, per your background | `[grounded]` your background |
| R5 | Track on-time delivery across the refrigerated fleet | must_have | direct | medium | none | You run the on-time delivery dashboard for parcels; the fleet type differs | `[grounded]` your background; `[inferred]` that the method transfers |
| R6 | Track temperature compliance across the refrigerated fleet | important | adjacent | low | transferability | The monitoring method carries over; temperature data and cold-chain rules are not exercised anywhere in your background | `[inferred]` bridge from the on-time work |
| R7 | Build weekly dashboards in Power BI | must_have | direct | medium | discovery | Power BI daily and the depot dashboard are stated; whether you built it isn't | `[grounded]` your background |
| R8 | Work with depot managers on route changes | must_have | adjacent | medium | transferability | You ran the weekly route-performance review; nothing says you changed routes | `[grounded]` your background; `[inferred]` for the decision-rights gap |
| R9 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational, not fluent; "a plus" is the posting's own weight | `[grounded]` your background |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Schedule and location (R1) | hard_gate | No statement on Rotterdam days | Could change the status | — | Your answer to the closing question | `[grounded]` JD |
| G2 | Temperature compliance (R6) | transferability | Experience on on-time metrics only | A named responsibility in a new data domain | Threshold-based monitoring; exception reports; any temperature or reefer logs | A temperature-related report or data sample | `[inferred]` bridge |
| G3 | Building dashboards (R7) | discovery | Daily Power BI and the depot dashboard; no statement on who built it | Interviewers probe ownership | Building or maintaining a dashboard others read | A screenshot of your dashboard, anonymised | `[grounded]` your background |
| G4 | Route changes (R8) | transferability | Ran the route-performance review; no record of changing routes | This role may decide route changes | Route reviews that led to changes | A review pack or agenda | `[inferred]` |
| G5 | Dutch (R9) | transferability | Conversational | Stated as a plus, not a requirement | Dutch-language meetings or documents | A Dutch-language work sample or a language certificate | `[grounded]` your background |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Web search was refused, so this is unresolved, not a finding | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary withheld | unknown | — | (no pay line in the posting) | The pay may sit below market, or the employer simply doesn't publish it | `[inferred]` from the posting's silence | What is the salary range budgeted for this role? | unresolved |
| RR3 | Outcomes and measures named | positive_signal | — | "Track on-time delivery and temperature compliance across our refrigerated fleet" | The role has measurable accountability | `[grounded]` JD | How is temperature compliance measured today, and who sets the thresholds? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV line: "Ran the weekly route-performance review. Worked in SQL and Power BI daily, including the on-time delivery dashboard depot managers use." | Mirrors your own sentences, clause by clause; the one claim to avoid is "built" until Q3 answers it | `[grounded]` your background | resume_edits_pending_approval |
| E2 | State Dutch as "conversational" in the application | Stated plainly, the limit is what the reader checks | `[grounded]` your background | pending your approval |
| E3 | No cover-letter claim about temperature compliance until Q2 is answered | A bridge stated as experience would be tested in the first interview | `[grounded]` R6 | pending your approval |
| A1 | Ask the recruiter about the three-day Rotterdam schedule and the salary before a full application | R1 and RR2 are the cheapest to close early | `[grounded]` R1, RR2 | pending your approval |
| A2 | Find the role on Duinvaart's careers page before applying | Closes RR1 | `[generic]` standard check | pending your approval |

**Verification questions** for RR1 through RR3 are in the register, addressed to the employer.

---

## Kroonhaven Foods, Supply Planner

**Fit ledger.**

- `hard_gate`: unclear: K1 (On-site in Utrecht)
- `must_have`: adjacent: K5 (run the weekly S&OP meeting), K8 (fluent Dutch); unclear: K6 (advanced Excel); absent: K2 (3+ years of supply or demand planning in FMCG), K3 (own the 13-week supply plan), K4 (balance production capacity against the forecast), K7 (SAP IBP or a similar planning system)

K2, K3, K4 and K7 have no evidence behind them: you've never worked in planning. K5 and K8 are partial matches.

**Opportunity ledger.** The scope is specific and the outputs are named (KR2). Pay is withheld (KR3). The employer is unverified (KR1), which caps the decision at `conditional_go`, but the capability gaps decide the status below, not the opportunity.

- **Hard gates:** none failed; unconfirmed: K1 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** the facts that would have to be different are planning experience of at least three years (K2, K3, K4), use of a planning system (K7), and fluent Dutch (K8).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready-meals | `[grounded]` JD header; existence not verified (KR1) |
| Mandate | Own the 13-week supply plan, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` JD |
| First-year outcomes | None stated | `[grounded]` JD is silent |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A single product range with planning ownership and a standing meeting | `[inferred]` from the responsibilities list |
| Market calibration | Not run; the role-family search was refused | — |
| Unknowns | Salary; team size; who signs off the plan | — |
| Contradictions | None within the posting | `[grounded]` JD only |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| K1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your location wasn't given | `[grounded]` JD |
| K2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | No planning or FMCG work on record. This is length of experience, so it's not a gate | `[grounded]` your background; `[generic]` that this closes slowly |
| K3 | Own the 13-week supply plan for chilled ready-meals | must_have | absent | none | capability | No ownership of a forward plan on record | `[grounded]` your background |
| K4 | Balance production capacity against the forecast | must_have | absent | none | capability | No capacity or forecast work on record | `[grounded]` your background |
| K5 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review. It's the same cadence, not the same content (no production or forecast) | `[grounded]` your background; `[inferred]` for the content gap |
| K6 | Advanced Excel | must_have | unclear | none | discovery | Your background doesn't mention Excel | `[grounded]` CV silence |
| K7 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are reporting tools, not planning systems | `[grounded]` your background |
| K8 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent; the posting says fluent | `[grounded]` your background |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| H1 | Planning experience (K2, K3, K4) | capability | No planning work on record | Named must-haves with no evidence | Demand or supply analysis that fed a plan | Nothing realistic within this search | `[generic]` that these roles usually want planning experience |
| H2 | Planning system (K7) | capability | None on record | Named must-have | Any structured planning or forecasting tool | A course or project in one | `[generic]` |
| H3 | Excel (K6) | discovery | Not in your background | Named must-have | Forecasting or reporting work in Excel | A workbook you built | `[grounded]` CV silence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| KR1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | As for RR1: the entity may be too new or small, the posting stale, or it may not represent a real hiring employer. Unresolved, not a finding | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| KR2 | Scope and outputs named | positive_signal | — | "Own the 13-week supply plan for our chilled ready-meals range" | The accountability is defined | `[grounded]` JD | Who signs off the 13-week plan? | noted |
| KR3 | Salary withheld | unknown | — | (no pay line) | The pay may sit below market, or it may not be published | `[inferred]` from the posting's silence | What is the salary range budgeted for this role? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't apply to this posting now | K2, K3, K4 and K7 have no evidence behind them | `[grounded]` K2–K4, K7 | pending your approval |
| P2 | Look for planning-entry roles where your SQL, Power BI and operational review work carries the core | Demand or supply analyst roles often sit between ops analysis and planning | `[generic]` role-family pattern | pending your approval |

---

## Evidence status

Verified: none yet.
Unverified leads: none.
Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused: "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht". Would have moved RR1 and KR1 (does each employer exist, and is the posting live) |
| 2. Role-family sweep | unavailable | Two searches were refused: operations analyst salary and supply planner salary. Would have set the market calibration for both titles, and RR2 and KR3 |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you want the employer checks run, allow web search in this session. Alternatively, paste each employer's careers-page link. I can read a link you give me without a search.

Once you're ready, I can write `tuesday-dossier.md` with both maps, so the next round starts from these rows.

**Upgrade menu**

- Web search allowed, or each careers-page link → RR1 and KR1 close or stay open; the market calibration for both titles becomes `[generic]` and checkable.
- A salary range for either role → RR2 and KR3 close.
- An anonymised screenshot of the on-time dashboard you built or maintained → R7 moves to high confidence.
- Any temperature, reefer or cold-chain data, even a sample → R6 moves.
- A Dutch-language work sample or a language certificate → R9 and K8 move.
- Your answer on the Rotterdam schedule and on Utrecht → R1 and K1 close.

**Questions**

R1: Can you work three days a week in the Rotterdam office? Is that workable for you?
R6: Have you worked with temperature, cold-chain or reefer data, even in a side project or sample? If not, say so; that's a useful answer too.
R7: On the on-time delivery dashboard: did you build it, maintain it, or only use it? Which parts were yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.