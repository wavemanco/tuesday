**Status: `conditional_go`.** Take the call. The company looks real and the WhatsApp message is ordinary interview scheduling. Nothing here asks you to pay, deposit a cheque, or give bank or ID details. The one thing I could not confirm is that the role is live on Fernquay's own site.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (pay range against your floor)
- `must_have`: direct: R3, R4, R6, R8 · adjacent: R5 (own the booking flow end to end)
- `important`: adjacent: R7 (research calls with school owners) · unclear: R9 (own the design alone as first designer)

R5 — a credible bridge, its limit named; R9 (`medium`) — never been the only designer, waiting on your answer.

**Opportunity ledger.** The role is sound and the pay sits mid-band: €52k–€60k brackets the €57k median for 3–5-year designers. The equity has no stated terms, and the first-designer setup is the main thing to test on the call. The employer-not-established entry does not apply: the About page and Ronan's profile both match the posting.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (pay range against your floor); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) R9 holds up on the call, your comfort being the only designer (RR1); (2) your pay floor sits within the range (Q3); (3) R5 is framed as adjacent, never as end-to-end ownership.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: booking software for sea-kayak, surf and sailing schools in Ireland and Scotland; six people in Galway; founded 2023 by Ronan Kehoe and Saoirse Doyle; customer-funded | `[grounded]` search result from the company's About page (snippet, not opened) |
| Mandate | Own the booking flow end to end, run research with school owners, ship with two engineers; first design hire | `[grounded]` posting |
| Working pattern | Two days a week in the Galway office, otherwise remote | `[grounded]` posting |
| Scope read | A first-designer role with a whole product area is a broad scope for one person | `[inferred]` from the posting's own wording |
| Market calibration | Ireland, 3–5 years, product designers: median base €57,000, interquartile range €51,500–€62,000 (n=520) | `[generic]` Tillerby 2026 Ireland design salary report |
| Unknowns | Equity terms; whether a product manager or research budget exists; whether the booking flow exists or is greenfield | — |
| Contradictions | The posting calls Saoirse "our CTO"; the About page calls them a co-founder. Probably compatible, worth one question | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work from Galway two days a week | hard_gate | direct | high | none | You moved back to Galway last year | `[grounded]` your background | none |
| R2 | Pay range against your floor | hard_gate | unclear | low | discovery | Your floor was not given | `[grounded]` posting | Q3 |
| R3 | 3+ years product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company; CV claim only | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use; no artifact shared yet | `[grounded]` your background | none |
| R5 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout; the posting asks for the whole flow, search to manage | `[inferred]` adjacency from the checkout work | G1 / Q2 |
| R6 | Run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers | `[grounded]` your background | none |
| R7 | Research calls with school owners | important | adjacent | low | transferability | Your research was with travel customers, not operators running a business | `[inferred]` from audience difference | G3 |
| R8 | Ship alongside engineers | must_have | direct | medium | none | Squad of four engineers | `[grounded]` your background | none |
| R9 | Work alone as the first designer | important | unclear | low | discovery | You have never been the only designer | `[grounded]` your background | G2 / Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whole booking flow (R5) | transferability | Checkout redesign, which is one step of a booking flow | Must-have; decides whether the role reads as a stretch | Any booking-flow change beyond checkout: search, selection, changes, confirmation | Checkout case study, plus a short note on the boundary of your work | `[grounded]` your background; `[inferred]` on what the posting implies |
| G2 | Solo design (R9) | discovery | No record of deciding design alone | Decides whether the first-designer setup is a fit or a risk | Any project where you were the only one who decided | A short example of working without a design review | `[grounded]` your background |
| G3 | Operator research (R7) | transferability | Customer usability sessions, not owner interviews | Important; shows how close your research skill is | Research with any B2B or small-business user | Interview guide or synthesis from the usability sessions | `[inferred]` |

## Opportunity risk register

| ID | Class | Severity | Signal | Source quote | Provenance | Verification question |
|---|---|---|---|---|---|---|
| RR1 | risk_signal | low | Solo design ownership with no design peer | "You would be our first designer" | `[generic]` pattern for first design hires | "Who reviews design decisions day to day, and who sets priorities between engineering and design?" |
| RR2 | unknown | — | Equity terms not described | "plus 0.5–1% equity" | — | "What share class is this, what is the vesting schedule and strike price, and how was the 0.5–1% range set?" |
| RR3 | unknown | — | Posting not confirmed live on the company's site | "Product Designer — Fernquay" | `[grounded]` careers page not found at the address I tried | "Can you point me to this role on your careers page?" |
| RR4 | positive_signal | — | Pay within the market band | "€52,000–€60,000" | `[generic]` Tillerby 2026 Ireland survey | "Is the range fixed, and how are pay reviews handled?" |
| RR5 | positive_signal | — | Named, checkable leadership | Ronan's profile: co-founder and CEO, previously product lead at a Galway travel-software company for five years | `[grounded]` profile snippet | "What does the team look like at the point you'd be hiring a designer, and what is the runway?" |

## Application plan

- **Before the call:** join through the video link in the calendar invite, and check the invite comes from a Fernquay address. The WhatsApp message is routine scheduling for an interview held elsewhere, so no further check is needed on it.
- **Lead with:** the checkout redesign at a Dublin travel-booking company, the monthly customer usability sessions, daily Figma, and four engineers in a squad. Proposed wording: "Redesigned the checkout flow at a Dublin travel-booking company, and ran monthly usability sessions with its customers." `resume_edits_pending_approval`
- **Do not claim:** end-to-end ownership of a booking flow, research with school owners, or having led design alone.
- **Bridge for R5:** adjacent (checkout), limit (one step, not the whole flow), strengthener (a messy real project that shows a whole flow). Use the same framing in the case study.
- **For the call:** ask RR1, RR2 and RR3, and find out whether a product manager exists.
- For rehearsing the 45-minute call itself, `mock-interview` is the sibling skill.

## Evidence status

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | About page surfaced by search; the careers address I tried returned no page, so the live posting is not confirmed |
| 2 | Role-family sweep | yes | Tillerby 2026 Ireland design salary report |
| 3 | Hiring manager's public footprint | yes | Ronan Kehoe's public profile snippet |

## Upgrade menu

- **Your pay floor and non-negotiables** (notice, contract type, authorisation to work in Ireland): unlocks the pay gate, which is currently unconfirmed.
- **The live posting link from Fernquay's careers page:** confirms the role is live (RR3).
- **The equity terms in writing** (share class, vesting, strike price): lets the 0.5–1% be valued (RR2).
- **Deeper research** (up to 5 more searches and 2 more fetches): funding, hiring history and recent news, to test whether the company is funded beyond customers.

I can also save this as `tuesday-dossier.md` for your interview prep, if that would help.

1. **G2 (R9):** Have you ever been the only designer on a product, even briefly? If not, what did you do when you needed a second opinion on a decision?
2. **G1 (R5):** Beyond checkout, which parts of a booking flow have you shaped (search, selection, payment, confirmation, changes), and what did you personally decide in them?
3. **Hard gates (R2):** What is your pay floor, and is anything else non-negotiable for you, such as notice period, contract type or authorisation to work in Ireland?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.