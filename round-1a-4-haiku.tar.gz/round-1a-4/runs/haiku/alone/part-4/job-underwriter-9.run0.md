**Decision: conditional_go.** Take the role only after you've verified the employer through contacts you find yourself. Opportunity and candidate fit are separate verdicts, so both are shown.

**Is the onboarding request normal?** Largely yes. Once a written offer is in place, Irish employers normally need bank details for salary, your PPS number for PAYE/RTI reporting, and evidence of right to work. The request itself is not a red flag. What matters is how it's delivered and who is asking. Red flags would be paying for the job or equipment, depositing a cheque, giving bank or ID details before any offer, or being hired entirely over chat. None of those happened here: you had two in-person interviews at their office, and the offer is in writing. Your instinct is right about the principle, though. Your details should go only to an employer you've verified, through a channel you've verified.

**Fit ledger (candidate side)**

| Priority | Fit | Requirement |
|---|---|---|
| Must-have | Meets | 2+ years running payroll (3 years, fortnightly, 90 staff) |
| Must-have | Meets, verify depth | Working knowledge of Irish PAYE, PRSI, USC (your cert and daily payroll imply it; confirm you've run these in practice) |
| Must-have | Meets | Strong Excel (pivot tables, XLOOKUP daily) |
| Must-have | Meets | Payroll qualification (Payroll Technician, 2024) |
| Core duty | Meets | Monthly payroll-to-GL reconciliation |
| Core duty | Meets | Starters and leavers |
| Core duty | Gap | Pension changes (never done; manager handled them) |
| Core duty | Unverified | Answering staff payroll queries (not stated in your background) |
| Scale | Stretch | 240 staff vs your 90 |
| Hard gate | Meets | Hybrid, 2 days in Limerick (confirm you can commute) |
| Hard gate | Meets | Salary €40k within €38–42k band |

**Opportunity ledger.** Not researched in this pass (see evidence status). Based only on what you've given me:

- Stated salary is mid-band. Nothing is withheld.
- Not verified: that Marrowgate Housing exists as described, that the email came from its real domain, and that the portal link leads to it.
- Notice period is unspecified. Don't resign until you have a signed contract.

**Role reality (from the posting and offer only)**

- Permanent payroll administrator for a 240-person housing association, reporting to the Finance Manager.
- Scope is wider than your current job: it adds pension changes and a larger headcount.
- Hybrid two days a week.

**Gap recovery queue (no questions here)**

- **Pension changes:** Gap. Closes with a short run-through of the pension scheme's joiner/leaver/contribution-change process, or asking how the role is trained on it.
- **Scale (240 staff):** Stretch. Closes by asking the employer how payroll is run (system, team size, cut-off timetable).
- **Staff queries:** Unverified. Closes with an example of one you've handled.

**Risk register**

| Class | Severity | Item |
|---|---|---|
| Failed attribution (not yet verified) | medium | Employer existence, email domain and portal not confirmed. Caps the decision at conditional_go. |
| Process | low | Passport scan before any in-person check. Right-to-work checks usually require seeing the original, so a scan upfront is possible but not the only route. |

**Application plan (what to do before accepting)**

1. **Verify the employer yourself.** Go to the company's own website, not the email. Check that the People Team, Declan Garvagh and the phone number match. Call the switchboard from the website to confirm the offer. Check that the email domain matches the website exactly (watch for lookalike spellings).
2. **Verify the portal before entering anything.** Once you have the link, check its domain matches the company website. Never enter bank or PPS details into a link sent by email without that check.
3. **Passport:** share a scan only through the verified portal, and ask whether the check can be done in person against the original on your first day. Don't send ID before step 1 is done.
4. **Bank details:** only in the verified portal, and only into an account in your own name.
5. **Contract first.** Ask for the written contract and terms before you resign. Confirm start date, notice terms and hours.
6. **Accept in writing** once steps 1 and 5 are done.

**Evidence status**

Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | Not run in this pass; step 1 above is the check to do |
| 2 | Role-family sweep (scope, pay for this title) | skipped | Not run; the pay band above is from the posting only |
| 3 | Hiring manager's public footprint | n/a | No research run; Declan Garvagh named in the offer only |

**Upgrade menu.** What would raise confidence: the company's live careers page, its switchboard number, the written contract, and a short description of your Irish PAYE/USC work (rates, Revenue returns, RTI submissions).

**Dossier offer.** If you want, I can save this assessment as a `tuesday-dossier.md` for later reference.

**Questions (max 3)**

1. Does the company's own website list the People Team, Declan Garvagh and the phone number in the offer?
2. Have you personally run PAYE, PRSI and USC through to Revenue submission, or mainly calculated them?
3. How do you feel about learning pension changes on the job, given you haven't done them before?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.