**Warning before you reply:** Your invite says "your interview will be a text chat here with our support team lead, and if you are successful your offer and onboarding will be completed in this chat as well." A hiring process run entirely over Telegram chat, with the offer and onboarding also in chat, is a common pattern in job scams. It doesn't prove this is one. Before you share anything, check that Marcus Hale and the role exist by finding Lumenvale's contact details yourself (their official website or the careers page you applied through), not from this message. Don't send bank, tax or ID details, or any payment, in chat before a formal written offer. If you want an independent check, you can ask a job-underwriter to review the invite.

# Interview prep pack: Customer Support Specialist, Lumenvale Software (remote)

**Research tier: L0.** Built only from what you told me: the invite text, the job-ad requirements you summarised, and your background. No web research has been run, so company values and loop structure are unknown.

## 1. Fit snapshot

| Requirement (job ad) | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| 2+ years in customer support | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | High | None | "I have three years in customer service, handling around 60 calls and emails a day." |
| Zendesk or a similar ticketing tool | "I use Freshdesk every day" | Medium | Tool-specific | "I haven't used Zendesk, but I use Freshdesk every day, and the ticket workflow is the same kind of thing." |
| Clear written communication | Nothing in your material says this directly. Your daily email volume is the closest evidence. | Low | Unevidenced | Answer slot: give an example of a written reply you wrote that resolved a complaint. |
| Confidence handling escalations | Nothing in your material shows an escalation. | Low | Unevidenced | Answer slot: give a real escalation you handled, or say you haven't escalated and describe how you would decide. |
| Software / product support (implied by a software-company hire) | "I've never worked for a software company" | Low | Domain | "I haven't worked in software, but I've explained a complex service to customers who didn't know it, and that's the part I'd bring." |
| Training / quality (not in ad, useful signal) | "I trained four new starters on our refunds process last year" | High | None | "I trained four new starters on our refunds process last year." |

## 2. Prohibited claims

The pack will not coach you to make these claims, because your material doesn't support them:

- Any Zendesk experience, even light use.
- Any software or product knowledge beyond what you have actually done.
- Any escalation you did not handle yourself.
- A team size, volume or outcome bigger than your quoted sentences (for example, more than about 60 contacts a day, or training more than four people).

## 3. Interviewer read

Not available. The interviewer is a support team lead, and no name or profile was given.

## 4. Persona weights

The round is a text chat with a support team lead, so the team-lead manager persona gets the most weight, and the written-communication persona is close behind because your replies are the evidence.

| Persona | Weight | Reasoning |
|---|---|---|
| Team-lead manager | High | The team lead runs the round and will judge how you'd work in their queue |
| Written-communication assessor | High | The whole interview is typed |
| Skeptic (software gap) | Medium | Never worked for a software company; expect the question |
| Motivation / culture | Low | No culture information yet |

## 5. Question banks

Types: Behavioural, Situational, Technical, Written, Motivation.

**Team-lead manager**

**Q1. Tell me about a time you handled a difficult customer. What did you do?**
- Type: Behavioural
- Guidance: Use one real call or complaint from your energy-supplier work. Name the situation, what you did, and the result.
- Provenance: Based on "answering around 60 calls and emails a day"; the specific story is yours to supply.
- Rationale: Standard opener; shows how you handle pressure in a queue.

**Q2. How do you prioritise when you have a queue of tickets?**
- Type: Situational
- Guidance: Describe how you work the queue in your current job. Don't claim a system you don't use.
- Provenance: Based on "I use Freshdesk every day"; your own process fills the answer.
- Rationale: Tests whether you can run a queue on your own.

**Q3. You've used Freshdesk. How would you learn Zendesk?**
- Type: Technical
- Guidance: Say what you'd expect to transfer (tickets, statuses, macros, SLAs) and what you'd need to learn. Use the Tool-specific bridge.
- Provenance: Based on "I use Freshdesk every day"; the Zendesk part is a bridge, not an experience claim.
- Rationale: The job ad names Zendesk, so this will come up.

**Q4. Tell me about a time you escalated a case.**
- Type: Behavioural
- Guidance: Answer slot. If you have a real escalation, tell that story. If not, say so and describe how you'd decide when to escalate and to whom.
- Provenance: Answer slot; your material does not show an escalation.
- Rationale: The job ad asks for confidence handling escalations, and nothing you've given shows it.

**Q5. Why do you want to move into a software company?**
- Type: Motivation
- Guidance: Be specific about what you want from a product-support role. Don't claim you already know their product.
- Provenance: Based on "I've never worked for a software company."
- Rationale: Owns the domain gap before they raise it.

**Written-communication assessor**

**Q6. (If they set a typed exercise) Reply to this customer: "My refund still hasn't arrived after 10 days."**
- Type: Written
- Guidance: Acknowledge the wait, say what you'll check, give a realistic timeline, and end with a clear next step. Keep it short and plain.
- Provenance: Based on "I trained four new starters on our refunds process last year."
- Rationale: The whole interview is text, so the reply itself is the evidence.

**Q7. Explain something complicated to a customer who has no background in it.**
- Type: Written
- Guidance: Pick a real example from energy billing or tariffs. Use short sentences and one example.
- Provenance: Based on "answering around 60 calls and emails a day."
- Rationale: Tests plain written explanation.

**Skeptic (software gap)**

**Q8. You've never worked for a software company. Why should we take you on?**
- Type: Motivation
- Guidance: Use the Domain bridge from the fit snapshot. Don't overclaim software knowledge.
- Provenance: Based on "I've never worked for a software company."
- Rationale: The most likely objection to this candidate, so it gets the most rehearsal.

## 6. Reverse questions

1. "What does a typical week look like for a new Customer Support Specialist?" Why it lands: shows you're thinking about the job, not just the offer.
2. "How does the team handle escalations, and who owns them?" Why it lands: addresses the escalation requirement directly.
3. "Which tools does the team use day to day?" Why it lands: opens the Zendesk question on your terms.

## 7. Delivery coaching

Not included. No working-style assessment was provided.

## 8. Upgrade menu

- **Full job description text.** Adds exact requirement wording to the fit snapshot. Without it, this pack uses your summary.
- **Any Zendesk or ticketing exposure beyond Freshdesk.** Changes the Tool-specific row and Q3.
- **Research (L1).** Adds company values, loop structure and recent role information. Default caps: 6 searches and 2 page fetches.
- **Interviewer name, if you have it.** Adds an interviewer read and sharpens the reverse questions.

The pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-5-rooms-case-10-denied-f727e876/c8d4b3c8-8161-412d-bb53-1a2a71e1597a/scratchpad/lumenvale-customer-support-prep-pack.md`.

Two offers, neither pushed:
- **Drill:** I can play the team lead and run Q1–Q8 with follow-up questions, then give feedback against each question's guidance.
- **Dossier:** I can write a `tuesday-dossier.md` file with this pack's feedback for later use.

**Questions:**
1. Do you have the full job description text? If so, paste it and I'll tighten the fit snapshot.
2. Have you used any ticketing tool other than Freshdesk, even briefly? That changes the Zendesk row.
3. Should I run the L1 research pass now (up to 6 searches and 2 page fetches) for company values and interview structure? I'd only search for Lumenvale's public information, and I won't look up Marcus Hale's personal details.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-customer-support-prep-pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software (remote)

Research tier: L0. Built only from what you told me: the invite text, the job-ad requirements you summarised, and your background. No web research has been run, so company values and loop structure are unknown.

## 1. Fit snapshot

| Requirement (job ad) | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| 2+ years in customer support | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | High | None | "I have three years in customer service, handling around 60 calls and emails a day." |
| Zendesk or a similar ticketing tool | "I use Freshdesk every day" | Medium | Tool-specific | "I haven't used Zendesk, but I use Freshdesk every day, and the ticket workflow is the same kind of thing." |
| Clear written communication | Nothing in your material says this directly. Your daily email volume is the closest evidence. | Low | Unevidenced | Answer slot: give an example of a written reply you wrote that resolved a complaint. |
| Confidence handling escalations | Nothing in your material shows an escalation. | Low | Unevidenced | Answer slot: give a real escalation you handled, or say you haven't escalated and describe how you would decide. |
| Software / product support (implied by "software company" hiring) | "I've never worked for a software company" | Low | Domain | "I haven't worked in software, but I've explained a complex service to customers who didn't know it, and that's the part I'd bring." |
| Training / quality (not in ad, useful signal) | "I trained four new starters on our refunds process last year" | High | None | "I trained four new starters on our refunds process last year." |

Gap types are the ones the fit snapshot uses: Tool-specific, Unevidenced, and Domain.

## 2. Prohibited claims

These are claims the pack will not coach you to make, because your material does not support them:

- Any Zendesk experience, even light use.
- Any software or product knowledge beyond what you have actually done.
- Any escalation you did not handle yourself.
- A team size, volume or outcome bigger than your quoted sentences (for example, more than about 60 contacts a day, or training more than four people).

## 3. Interviewer read

Not available. The interviewer is a support team lead, and no name or profile was given.

## 4. Persona weights

Round type: text chat on Telegram with a support team lead. The team lead is a manager-type interviewer, so the weights lean toward the manager persona (behavioural and situational questions) with a heavier written-communication component, since the interview itself is text.

| Persona | Weight | Reasoning |
|---|---|---|
| Team-lead manager | High | Round is run by the team lead; they will judge how you'd work in their queue |
| Written-communication assessor | High | The whole interview is typed, so your replies are the evidence |
| Skeptic (software gap) | Medium | Never worked for a software company; expect the question |
| Motivation / culture | Low | No culture information yet |

## 5. Question banks

Types: Behavioural, Situational, Technical, Written, Motivation.

### Team-lead manager

**Q1. Tell me about a time you handled a difficult customer. What did you do?**
- Type: Behavioural
- Guidance: Use one real call or complaint from your energy-supplier work. Name the situation, what you did, and the result, in that order.
- Provenance: Based on your quote "answering around 60 calls and emails a day"; the specific story is yours to supply.
- Rationale: Standard opener; shows how you handle pressure in a queue.

**Q2. How do you prioritise when you have a queue of tickets?**
- Type: Situational
- Guidance: Describe how you work the queue at your current job. Don't claim a system you don't use.
- Provenance: Based on "I use Freshdesk every day"; your own process fills the answer.
- Rationale: Tests whether you can run a queue on your own.

**Q3. You've used Freshdesk. How would you learn Zendesk?**
- Type: Technical
- Guidance: Say what you'd expect to transfer (tickets, statuses, macros, SLAs) and what you'd need to learn. Use the Tool-specific bridge from the fit snapshot.
- Provenance: Based on "I use Freshdesk every day"; the Zendesk part is a bridge, not an experience claim.
- Rationale: The job ad names Zendesk, so this will come up.

**Q4. Tell me about a time you escalated a case.**
- Type: Behavioural
- Guidance: Answer slot. If you have a real escalation, tell that story. If you haven't escalated anything, say so and describe how you'd decide when to escalate and to whom.
- Provenance: Answer slot; your material does not show an escalation.
- Rationale: The job ad asks for confidence handling escalations, and nothing you've given shows it.

**Q5. Why do you want to move into a software company?**
- Type: Motivation
- Guidance: Be specific about what you want from a product-support role. Don't claim you already know their product.
- Provenance: Based on "I've never worked for a software company."
- Rationale: Pre-empts the domain gap by owning it.

### Written-communication assessor

**Q6. (Typed exercise, if they set one) Reply to this customer: "My refund still hasn't arrived after 10 days."**
- Type: Written
- Guidance: Acknowledge the wait, state what you'll check, give a realistic timeline, and end with a clear next step. Keep it short and plain.
- Provenance: Based on your refunds experience, "I trained four new starters on our refunds process last year."
- Rationale: The whole interview is text, so the reply itself is the evidence.

**Q7. Explain something complicated to a customer who has no background in it.**
- Type: Written
- Guidance: Pick a real example from energy billing or tariffs. Use short sentences and one example.
- Provenance: Based on "answering around 60 calls and emails a day."
- Rationale: Tests plain written explanation.

### Skeptic (software gap)

**Q8. You've never worked for a software company. Why should we take you on?**
- Type: Motivation
- Guidance: Use the Domain bridge from the fit snapshot. Don't overclaim software knowledge.
- Provenance: Based on "I've never worked for a software company."
- Rationale: The most likely objection to this candidate.

## 6. Reverse questions

1. "What does a typical week look like for a new Customer Support Specialist?" Why it lands: shows you are thinking about the job, not just the offer.
2. "How does the team handle escalations, and who owns them?" Why it lands: directly addresses the escalation requirement.
3. "Which tools does the team use day to day?" Why it lands: opens the Zendesk question on their terms.

## 7. Delivery coaching

Not included. No working-style assessment was provided.

## 8. Upgrade menu

- **Full job description text.** Adds exact requirement wording to the fit snapshot. Without it, I used your summary.
- **Any Zendesk or ticketing exposure beyond Freshdesk.** Changes the Tool-specific row and Q3.
- **Research (L1).** Adds company values, loop structure and recent role information. Default caps: 6 searches and 2 page fetches.
- **Interviewer name, if you have it.** Adds an interviewer read and sharpens the reverse questions.
