This message has several classic recruitment-scam markers, so I'll check the skill's guidance on suspicious invites before preparing anything.
The message has several warning signs, so I'd hold off on preparing until you've verified it.

Your invite says: "Everything, from the interview through to your contract, is done right here over WhatsApp messages, so no calls or video are needed." It also says they "found your profile online." A legitimate employer normally gives a company name and a work email address, and can be verified independently. Running the whole hiring process, including the contract, over an unknown WhatsApp number is a common pattern in job scams.

**Before you reply or share anything:**

- **Don't send money, pay for equipment or training, or share bank details, a tax number, or a copy of your ID or passport.** Any of those before a formal offer is a strong sign of fraud.
- **Don't install apps or open links they send**, and don't share one-time codes.
- **Check the company yourself.** Find it through its official website or LinkedIn, not through anything in the message. Look for the company and the recruiter's name on LinkedIn, and check whether the company has a real domain and a published contact.
- **If you want to check, contact them through details you found yourself,** not the number that messaged you. You can also ask Job Underwriter, a service that verifies job offers, to check the listing.

**What I'd send back, if you want to keep the option open:**

"Thanks, Jess. Before I confirm tomorrow, could you send the company's full name, the job title, and a work email address from its own domain? I'd also like a short call to talk through the role."

A genuine recruiter should be able to answer that without difficulty. If they dodge it, push for payment, or pressure you to decide quickly, treat the offer as fake.

Once you have the company and role title, I can put together a full prep pack for the interview. I'd need those details first because the pack is built around the specific company and role.