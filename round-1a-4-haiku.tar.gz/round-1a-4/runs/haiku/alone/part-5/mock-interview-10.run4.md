This invite has several red flags for a recruitment scam, so I'm loading the interview-prep skill first, since it covers suspicious invites.
I'll write the pack to a file first, then present it. The pack is built only from what you gave me, since I haven't run any research on Lumenvale.
**Before you reply to Marcus, check this.** The invite says "Our hiring process is fully remote and is carried out entirely on Telegram," and that your "offer and onboarding will be completed in this chat as well." A whole hiring process run in a chat app, with no video, phone or company email, is a common pattern in recruitment scams, and the careers-page application doesn't prove the Telegram account is Lumenvale's. Don't send ID, bank, tax or payment details here, and don't pay for anything. To verify, find Lumenvale's contact details on their official website, not from the invite, and ask them directly whether Marcus Hale is on their talent team. You can also ask a job-underwriter to check the posting. Interviews aren't a problem in themselves. Only reply once you've checked.

# Interview prep: Customer Support Specialist (remote), Lumenvale Software

Built on your job-ad summary, your CV summary and the invite. No full JD, no company research. Assumed round: a text-chat interview with the support team lead. Full pack saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-5-rooms-case-10-denied-e528f766/625be059-71e0-4b47-b8f6-8cc298808361/scratchpad/lumenvale-interview-prep.md`.

**Fit snapshot**

| Requirement | Your evidence | Gap and bridge |
|---|---|---|
| 2+ years support | "3 years as a customer service advisor… around 60 calls and emails a day" | None. "My three years were customer service at an energy supplier, mostly calls and emails at high volume." |
| Zendesk or similar | "I use Freshdesk every day" | Tool-specific. "I haven't used Zendesk itself, but I'd expect the core ticket workflow to transfer quickly." |
| Written communication | Volume of emails | Evidence-thin. Answer slot (Q5). |
| Escalations | None. Adjacent: trained four starters on refunds | The material says nothing about escalations. Answer slot (Q3). |
| No software background | "I've never worked for a software company" | "I'd expect to learn your product and tools fast." |

**Don't claim in the interview:** Zendesk experience, software or SaaS support, escalations you didn't own, figures you can't back up, or credit for designing the refunds process unless you did.

**Questions to rehearse**
- **Q1 Experience:** "Tell me about your current role." Give a 60-second version of what you actually did.
- **Q2 Skill-fit:** "How would you get up to speed on our tool?" Name what transfers, say you haven't used Zendesk, and give one concrete learning step.
- **Q3 Behavioural (answer slot):** "Tell me about a case you escalated." If you have an example, use situation, action, result. If not, say so and explain how you decide what to escalate.
- **Q4 Situational:** "A customer is angry that a refund is late." Acknowledge, state what you can do, give a specific time, and escalate if policy requires.
- **Q5 Written (answer slot):** Draft one short reply in the chat. Keep it short, name the next step, avoid jargon.
- **Q6 Motivation:** "Why software rather than energy?" Give your honest reason.
- **Q7 Skeptic:** "Why would you cope without software experience?" Name the gap in one sentence and bridge with your volume and training.

**Reverse questions**
- "What does a typical week look like in channels and volume?"
- "Once a case is escalated, who owns it?"
- "Which tools would I use on day one?"

**Upgrade menu:** the full job description; an escalation example (fills Q3); company research, offered once, adds up to 6 searches and 2 page fetches; round details from Marcus (time limit or written task); an optional dossier from job-underwriter.

**Drill:** I can play the team lead and run any of Q1 to Q7 with follow-ups, then give feedback.
**Dossier:** I can write a `tuesday-dossier.md` file from this pack if you want to carry it forward.

Three questions to sharpen the pack:
1. Have you handled escalations at your current job? If so, what was one example?
2. Did Marcus mention a time limit, a written task, or anything else about the chat format?
3. Can you paste the full job description?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-interview-prep.md -----
# Interview prep: Customer Support Specialist (remote), Lumenvale Software

**Built on:** your summary of the job ad, your CV summary, and the invite text. No full JD, no company research (L0, provided material only).
**Assumed round:** a text-chat interview on Telegram with the support team lead.

## Fit snapshot

| Requirement | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| 2+ years in customer support | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | High | None (title and sector differ) | "My three years were customer service at an energy supplier, mostly calls and emails at high volume." |
| Zendesk or a similar ticketing tool | "I use Freshdesk every day" | Medium-high | Tool-specific | "I use Freshdesk daily. I haven't used Zendesk itself, but I'd expect the core ticket workflow to transfer quickly." |
| Clear written communication | "answering around 60 calls and emails a day" | Low-medium | Evidence-thin | Answer slot: a written reply you are proud of (see Q5). |
| Confidence handling escalations | None quoted. Adjacent: "I trained four new starters on our refunds process last year" | Low | The material says nothing about escalations | Answer slot (see Q3). |
| Software-company background | "I've never worked for a software company" | High | Structural | "I haven't worked in software, so I'd expect to learn your product and tools fast." |

## Prohibited claims (built locally)

These are claims a candidate reaches for under pressure. Do not claim them in the interview:

- Hands-on Zendesk experience, or any Zendesk admin or macro work.
- Software or SaaS support experience.
- Owning escalations, unless you personally did so. Say what you actually did.
- Exact figures you can't back up, such as CSAT scores or ticket counts beyond "around 60 a day".
- Credit for the refunds process itself, unless you designed or wrote it. Training others on it is what you can claim.

## Question banks

Persona weight: **support team lead**, operational and practical. High weight on experience and escalation handling. Medium on motivation.

**Q1 · Experience** — "Tell me about your current role."
*Provenance: candidate-sourced: "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day."*
Guidance: Give a 60-second version. Cover the volume, the channels, and one thing you owned. Rehearse only what you did.

**Q2 · Skill-fit** — "You use Freshdesk. How would you get up to speed on our tool?"
*Provenance: candidate-sourced: "I use Freshdesk every day."*
Guidance: Name what transfers (queues, tagging, reply templates). Say plainly you haven't used Zendesk. Give one concrete learning step, such as working through the help docs or shadowing an experienced agent.

**Q3 · Behavioural (answer slot)** — "Tell me about a case you escalated. What did you check first, and what happened next?"
*Provenance: answer slot. Your material does not show escalations. If you have an example, give it as situation, action, result. If you don't, say so, and describe how you decide what to escalate under the refunds process you trained others on.*

**Q4 · Situational** — "A customer is angry that a refund is late. Walk me through your reply."
*Provenance: answer slot, with the adjacent sentence "I trained four new starters on our refunds process last year."*
Guidance: Acknowledge the frustration. State what you can do now. Give a specific time. Escalate if policy requires it, and say so.

**Q5 · Written communication (answer slot)** — "Draft a reply to this customer in the chat."
*Provenance: answer slot. Prepare one short written reply in advance, in your own words.*
Guidance: Keep it short. Name the next step and when it happens. Avoid jargon.

**Q6 · Motivation** — "Why support in software rather than energy?"
*Provenance: candidate-sourced: "I've never worked for a software company."*
Guidance: Give your honest reason. Don't invent enthusiasm for their product.

**Q7 · Skeptic** — "You haven't worked in software. Why would you cope?"
*Provenance: candidate-sourced: "I've never worked for a software company."*
Guidance: Name the gap in one sentence. Bridge with your volume and your training experience. Don't argue the point.

## Reverse questions

- "What does a typical week look like for this role, in channels and volume?" *Why it lands: shows you're weighing workload realistically.*
- "Once a case is escalated, who owns it?" *Why it lands: shows you understand escalation ownership.*
- "Which tools would I use on day one?" *Why it lands: connects your Freshdesk experience to their stack.*

## Values cheat sheet

Omitted. No company values were detected, because no research was run.

## Upgrade menu

- **Full job description:** tightens the fit snapshot and may add requirements.
- **An escalation example:** answers Q3 properly and turns an answer slot into a story.
- **Company research (L2, offered once):** adds company values, interview format, and recent strategy. Up to 6 further searches and 2 page fetches.
- **Round details from Marcus:** whether the chat has a time limit or a written task.
- **Optional dossier from job-underwriter:** adds verified evidence and risk notes, but is not required.
