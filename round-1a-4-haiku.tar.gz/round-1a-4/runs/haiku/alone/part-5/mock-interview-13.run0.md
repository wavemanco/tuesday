Your pack is saved here: /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-5-rooms-case-13-denied-6ed89fd1/3b4daec8-85fd-4260-8927-44c593ae696f/scratchpad/quillmoor-recruiter-screen-pack.md

It's built from the advert and your background only. I haven't researched Quillmoor yet.

**The invite:** Nothing suspicious. She's calling the number on your application, and she isn't asking for fees, equipment or bank details. Salary and notice questions are normal for a screen.

**What the pack covers:**

- **Fit:** Your 4 years of logistics coordination, the supplier chasing, and the stock-count work match the core of the role. The gaps are production scheduling and QA hand-offs, weekly on-time dispatch reporting, SAP (a plus, not required), and your actual Excel level.
- **Salary:** Expect "is £42k firm?" Say your figure once and give the reason it's based on the role's scope. Don't drop below £38k on the call. Don't mention your current pay.
- **Notice period:** State it once and plainly.
- **Why you're moving:** Say the Bristol closure and the Reading-only offer, then stop. No criticism of the employer.
- **Hybrid:** Two days at Avonmouth works. Three is your limit.
- **Pitch and SAP gap:** Short scripts are in the file, using only what you told me.
- **Reverse questions:** Five to ask her at the end, covering the week's structure, how dispatch is measured, the ERP, the hybrid pattern and next steps.

**Please don't say on the call:** that you've used SAP, that you've scheduled production or worked with QA, that you've produced on-time dispatch reports, or that you alone cut discrepancies by a third.

**One question:** What's your notice period? I left it out because you didn't say, and it's the one number she'll certainly ask for. If you also tell me your real Excel level and any on-time or dispatch tracking you've done, I can tighten those answers.

If you'd like, I can also run a short practice round where I play Hannah and push on the salary question.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-recruiter-screen-pack.md -----
# Recruiter Screen Prep: Operations Coordinator, Quillmoor Diagnostics

**Call:** Thursday 2pm, 30 min, by phone to the mobile on your application, with Hannah Lowther (Talent Partner)
**Built from:** the advert and your background as you described them. No company research run (L0).

## 1. Fit snapshot

| JD requirement | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| 2+ years in operations or logistics coordination | "4 years as a logistics coordinator at a building-supplies wholesaler" | High | None | Lead with this. |
| Coordinate production schedules between planning, warehouse and QA | "I schedule deliveries for our three depots" | Medium | Experience transfer | "My scheduling has been delivery-side across three depots, not production runs. I haven't scheduled production or worked alongside QA, so I'd be learning those hand-offs." |
| Track supplier deliveries; chase late orders | "chase suppliers when orders slip" | High | None | Give one concrete example. |
| Keep stock records accurate | "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year" | High | None | Say "I rebuilt" and "fell by about a third over a year." Do not credit the whole drop to the spreadsheet alone. |
| Weekly on-time dispatch reporting | Not in your material | None | Missing | "I haven't produced an on-time dispatch report. What I've tracked is [your actual tracking, if any]." Fill from your real practice only. |
| Confident with Excel | Rebuilt the stock-count spreadsheet | Medium | Level not stated | Confirm your actual Excel level (formulas, pivots, lookups) before the call. |
| SAP or similar ERP (plus) | "Never used SAP — we run our own in-house stock system" | None for SAP; partial for ERP-style | Missing, nice-to-have | "I haven't used SAP. I work daily in our in-house stock system, which covers [what it does]." |

## 2. Prohibited claims (do not say these)

- That you have used SAP or any ERP beyond your in-house stock system.
- That you have scheduled production runs, or worked with QA or planning in a manufacturing setting.
- That you have produced weekly on-time dispatch reporting, unless you have.
- That you alone reduced discrepancies by a third.
- Anything about your current salary or what you earn now.
- That you are willing to relocate to Reading.

## 3. Likely objections and how to answer

**The most likely objection: "You're asking £42k against a £38–44k range. Why this figure, and is it firm?"**
Rehearse this one hardest. Answer in your own words:
- "I'm hoping for £42,000. That's based on the role's scope and the range you've listed."
- If pushed on flexibility: "That's my working figure. I'd like to hear the full package before I say more." Do not go below £38k on the spot.

**Notice period:** Say the number once, plainly. Do not explain it unless asked.

**"What's prompting the move?"** Say what happened, then stop:
"Our Bristol office is closing next year. The only offer I've had is relocating to Reading, and I'm not looking to move. I'd like to stay in Bristol."
Do not add criticism of the employer.

**Hybrid:** "Two days at Avonmouth works for me. I live in north Bristol. I'd want to keep it to two, with three as my limit."
If she asks about commute time, answer from your actual journey, not an estimate.

**"Would you consider Reading, or more days in the office?"**
"I'd prefer to stay in Bristol with two days at Avonmouth. Three is the most I'd manage." Stop there.

**"Tell me about yourself" (opener):**
"I'm a logistics coordinator with four years at a building-supplies wholesaler. I schedule deliveries across three depots and chase suppliers when orders slip. I rebuilt our stock-count spreadsheet, and discrepancies fell by about a third over the year. I'm looking for coordination work in a manufacturing setting, and Quillmoor's role is closest to what I do now."

**SAP gap:** "I haven't used SAP. I work in our in-house stock system every day, and I'm keen to learn an ERP if the role needs one."

## 4. Reverse questions (ask at the end)

1. "What does a typical week look like for this role, across planning, the warehouse and QA?"
2. "How is on-time dispatch measured today, and who reviews the weekly report?"
3. "Which ERP does the team use, and how much of the role is in it?"
4. "How does the two-day Avonmouth pattern work in practice: which days, and is it fixed?"
5. "What are the next steps after this call, and roughly when?"

## 5. Upgrade menu

- **Notice period:** unlocks the notice-period answer (not in the material).
- **Excel level:** unlocks a stronger Excel line in the fit snapshot.
- **Real on-time or dispatch tracking:** unlocks a bridge for the reporting gap.
- **Company research (L1 or L2):** unlocks specifics on Quillmoor's sites and team for the reverse questions.
- **Tuesday dossier from job-underwriter (if you have one):** adds an evidence check and a stronger objection rehearsal.
