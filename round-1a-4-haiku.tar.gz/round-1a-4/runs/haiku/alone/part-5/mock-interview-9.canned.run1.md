Your SSN isn't needed for interview prep, so I left it out of everything here. Don't share it with the panel or in any prep material.

Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-5-rooms-case-9-canned-bfd78b87/1091a8ac-cfa2-44c6-bd55-414d4725e011/scratchpad/Halvering_fourth-grade-teacher_interview_pack.md`. It's built only from your invitation and resume. I didn't run any research, so there's no information on the district's values or interview format.

## Fit snapshot

| # | Requirement | Your evidence | Gap | What to say |
|---|---|---|---|---|
| F1 | Valid Illinois PEL with elementary endorsement (invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (CV) | None | Met. Say the license and expiry as written. |
| F2 | Fourth Grade Teacher position (invitation) | "Six years teaching third grade at a public elementary school in Joliet" (CV); "I've never taught fourth grade" (your message) | You've not taught fourth grade | "I haven't taught fourth grade." Then the third-grade years. |
| F3 | Grade 4 reading instruction (role-family, not from the invitation) | "I led our grade level's move to a new reading curriculum in 2024" (CV); "I've run the after-school reading club for the last two years" (CV) | No outcome data in your material | Describe what these sentences say. If you measured student results, say what and how. If not, say so and what you'd measure. |
| F4 | Family communication | "I write a weekly email to families" (CV) | None | Describe the email. Don't claim replies or outcomes you don't have. |

## Claims not to rehearse

- **"I've been a team lead."** You told me you haven't. Say "I haven't been a team lead," then describe the grade-level move as written.
- **"I've taught fourth grade."** Say "I haven't taught fourth grade," then your third-grade years.
- **"I led the reading curriculum across the school."** Your sentence says grade level. Use that.
- **"I started the reading club."** Your sentence says you've run it for two years.

## Highest-priority prep: A1

The principal will most likely ask: **"You haven't taught fourth grade. Why should we hire you for this class?"** Answer with what you've not done, then your six years in Joliet. Be ready for two follow-ups. Also prepare one thing from third grade you expect to carry over, and one thing you'd learn first.

## Question bank (by persona)

**Principal, Skeptic:**
- A2: "Which part of this role would you be weakest at on day one?" Name the honest weak spot, then your ramp plan.
- A3: "Tell us about a time you led a team." Start with the honest line, then the grade-level move.
- A4: "What changed for students?" Describe what you measured, or say you didn't and what you'd track.

**Team members, Peer Evaluator and Data-Driven Prober:**
- B1: "What would you need from us in your first month?" Name two concrete asks, then what you bring.
- B2: "When your team disagreed about a curriculum decision, how did you handle it?" If there was no disagreement, say so.
- B3: "Walk us through a weekly family email." Describe its purpose and contents.
- B4: "What did the reading club show about students' progress?" Say what you tracked, or that you didn't.

**Principal, Case/Strategist:**
- C1: "A fourth grader is reading two levels below peers by October. What is your first week?" Clarify, diagnose, group, adjust, contact the family.
- C2: "A parent says their child's reading dropped after the new curriculum. What do you say?" Check the data, then say what you'd do.

**Opener:**
- D1: "Walk us through your path to teaching." A 90-second arc from Joliet to fourth grade.

## Reverse questions to ask

1. What does a strong first year look like for a new fourth-grade teacher here?
2. How does the fourth-grade team plan reading instruction together?
3. What has the team changed recently, and what is still in progress?
4. For the team members: what could a new person do in their first month that would help your team?
5. For the principal: what do you most want this person to have accomplished by December?

## Upgrade menu

- The job posting → turns F2 and F3 into quoted requirements and adds questions on the listed duties.
- The two team members' names → tailored questions for each.
- Any focus areas or demo lesson from HR → a section for that task.
- Research on the district's values and interview format → a values sheet and loop structure. I can run that now if you want.
- Prep time before Thursday → a prioritized schedule.

I can also run a live mock interview: I'd play the principal or a team member, ask A1, and follow up based on your answers.

I need three things from you:
1. Can you paste the job posting?
2. Did HR share focus areas or ask you to prepare anything, like a demo lesson?
3. Do you want me to research the district's values and interview format before we rehearse? I recommend it.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. I can also convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Format: 45-minute panel. Principal Dolores Vantongeren, plus two members of the fourth-grade team (names not yet known). Thursday.
Built from: the invitation and your resume as stated in our conversation. No job posting, no research run.

## How to use + type key

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Types: **VAL** behavioral/values · **EXP** your experience, closely examined · **JD** the listed job · **CO** company knowledge (not included; no research run) · **CASE** live problem.
- Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | Met by your material. Say the license and its expiry in those words. Nothing to add. |
| F2 | "Fourth Grade Teacher position" (invitation) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | medium | [grounded] | capability | You stated the absence, so the words are yours: "I haven't taught fourth grade." Then the third-grade work, at its own scope. Your material does not show any fourth-grade planning or assessment. |
| F3 | Reading instruction for grade 4 (role-family, not quoted from a source) | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your CV) | medium | [generic] | presentation | Reword only what these sentences say. Your material does not show outcomes for either. Answer slot: if you measured anything about student reading, say what and how it was counted; if you did not, say so and say what you would measure first. |
| F4 | Family communication (role-family, not quoted from a source) | "I write a weekly email to families" (your CV) | medium | [generic] | none | Lead with the sentence as written. Describe what the email contains. Do not claim response rates or outcomes unless you have them. |

Team lead is not a requirement the invitation states, so it has no row. It is covered in the prohibited list and question A3.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I've been a team lead" | Negative you stated: "I've never been a team lead" | "I haven't been a team lead." Then the grade-level move, at its own scope. |
| "I've taught fourth grade" | Negative you stated: "I've never taught fourth grade" | "I haven't taught fourth grade." Then the third-grade years. |
| "I led the reading curriculum across the school" | Inflated form of "I led our grade level's move to a new reading curriculum in 2024" | Your sentence as written. The material says grade level, not school. |
| "I started the reading club" | Inflated form of "I've run the after-school reading club for the last two years" | "I've run it for two years." |

## Persona weights

| Persona | Who | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|---|
| Skeptic | Principal | "You haven't taught fourth grade." | high | Gap F2 is the obvious probe | Rehearse A1 until it is plain and unhurried |
| Peer Evaluator | Team members | "Where would you need us?" | high | A panel with fourth-grade teachers prices what the hire adds to their load | Ask for specifics; offer what you bring |
| Case/Strategist | Principal | A live fourth-grade reading problem | medium | Principals test planning under a problem | Clarify, then structure, then act |
| Data-Driven Prober | Team members | "What did the reading club show?" | medium | Team members read the resume closely | Know what you can and cannot say about how results were counted |
| Conversational | Opener | "Walk us through your path." | medium | Openers are scored too | Keep a 90-second arc ready |
| Values/Behavioral | Any | Scenario about a published value | low | No values were supplied or researched | Covered only by the generic questions here |

## Question banks

### A. Skeptic (principal), highest weight

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. Why should we hire you for this class?" | JD | [grounded] "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | **Highest-ROI prep.** Say "I haven't taught fourth grade," then your six years of third grade in Joliet. Hold through two follow-ups by returning to what you have done. Answer slot: name one thing from third grade you expect to carry over, and one thing you would learn first. | F2 is the gap this panel will most likely test. Asked by the principal, so it is the Skeptic's question. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] stem | Name the honest weak spot: fourth-grade content and pacing, which you have not taught. Then your ramp plan: what you would read, observe, and ask for first. | Skeptic stem; the answer is a plan, not a past claim. |
| A3 | "Tell us about a time you led a team." | VAL | [grounded] "I've never been a team lead" (your message); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Begin with the honest line: "I haven't been a team lead." Then the grade-level move, in your sentence. Answer slot: describe what you did on that move, in your own words. | Team lead is not in the invitation, but the prohibited list names it. The open prompt is a persona stem. |
| A4 | "Your resume says you led the grade-level reading move. What changed for students?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: if you measured student results, say what and how it was counted; if you did not, say so plainly and say what you would measure. Never describe a result you did not track. | F3. The question presupposes an outcome your material does not carry, so the honest branch is required. |

### B. Peer Evaluator (team members), highest weight among team

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We plan together as a fourth-grade team. What would you need from us in your first month?" | JD | [generic] stem | Name two concrete asks, such as planning time or shared reading materials. Then one thing you bring, using your curriculum work: "I led our grade level's move to a new reading curriculum in 2024." | Peer seam question. Reciprocity: what you bring as well as what you need. |
| B2 | "When your grade-level team disagreed about a curriculum decision, how did you handle it?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: if there was disagreement, say how it was settled and what part was yours. If there was no disagreement, say so plainly. | Peer probe into disagreement style. The premise of disagreement is not in your material, so the second branch must be available. |
| B3 | "Walk us through a weekly family email. What's in it?" | EXP | [grounded] "I write a weekly email to families" (your CV) | Describe the email's purpose and its typical contents, in your words. Do not claim replies or outcomes. | F4. A premised question on a sentence you stated. |
| B4 | "What did the reading club show about students' progress?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Answer slot: if you tracked anything, say what and how it was counted; if you did not track it, say so and say what you would track. | F3. Data-prober question on a club whose results your material does not show. |

### C. Case/Strategist (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader is reading two levels below peers by October. What is your first week?" | CASE | [generic] | Clarify first: which assessment, what the current reading program is. Then diagnose, group, adjust instruction, and contact the family. Think aloud. | Core fourth-grade reading problem. Needs no claim about your past. |
| C2 | "A parent says their child's reading dropped after the new curriculum. What do you say?" | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Acknowledge the concern, say how you would check the data, and say what you would do if the curriculum is the cause. Do not claim the change had no effect unless you know it. | Ties a live problem to your curriculum work without claiming results. |

### D. Conversational (opener)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk us through your path to teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've run the after-school reading club for the last two years" (your CV) | A 90-second arc: Joliet, six years of third grade, the reading curriculum move, the reading club, and why fourth grade now. | Openers are scored. Keep it to what you have done. |

## Reverse questions

1. "What does a strong first year look like for a new fourth-grade teacher here?" Why it lands: it asks them to define success in their own terms.
2. "How does the fourth-grade team plan reading instruction together?" Why it lands: it shows you want to work with the team.
3. "What has the fourth-grade team changed recently, and what is still being worked on?" Why it lands: it shows you have thought about what is current.
4. Peer reciprocity, for the team members: "What could a new person do in their first month that would genuinely help your team?" Why it lands: it turns the seam into a shared problem.
5. "What do you most want the person in this role to have accomplished by December?" Why it lands: it asks the principal to name the bar.

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| Valid Illinois PEL with elementary endorsement | none | Met by your material. The panel may verify it. |
| Fourth Grade Teacher position | A1, A2, C1 | Gap F2 |
| Reading instruction for grade 4 | A4, B4, C1, C2 | Gap F3 |
| Working with a grade-level team | B1, B2 | |
| Family communication | B3 | |

## Sources

- Provided: the invitation and your resume, as stated in our conversation.
- Research: none run (tier L0). School values, interview format, and recent context are not established. There is no values cheat sheet and no grounding brief.

Research tier: L0. No searches or fetches were run.

| Target | Status | What it would have moved |
|---|---|---|
| Halvering or Orrinsford values | unavailable | Values cheat sheet |
| Interview format for this role | unavailable | Loop structure and persona weights |
| Recent school or district news | unavailable | Grounding brief |
| Principal's public footprint | unavailable | Interviewer read |
| Representative job posting | unavailable | Requirements marked [inferred] |

## Upgrade menu

- The job posting text → turns F2 and F3 from role-family prose into quoted requirements, and adds JD-tagged questions.
- The names of the two team members → personas per member and more specific reverse questions.
- Any focus areas or a demo lesson from HR → a section for the graded piece.
- Research on the district's values and interview format → values cheat sheet and loop structure.
- Prep time before Thursday → a prioritized schedule.
