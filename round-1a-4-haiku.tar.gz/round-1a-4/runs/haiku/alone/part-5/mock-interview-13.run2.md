Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-5-rooms-case-13-denied-d47011a5/7029f518-8958-476e-a87a-5181a13061e8/scratchpad/quillmoor_operations_coordinator_interview_pack.md. I built it for the recruiter call with Hannah Lowther, and I used only the advert, her message and what you've told me. Web search was refused in this session, so there's no company or interviewer research in it.

The main points:

- **The call is mostly logistics.** Hannah has set the agenda: pay, notice, hybrid working and the reason for moving. The pack gives you the words for each, quoted from what you wrote.
- **Your notice period is missing.** Your material doesn't give it, so that answer is still a slot for you to fill in. Tell me the figure and I'll drop it in.
- **The biggest objection is production scheduling.** The advert asks you to coordinate production between planning, the warehouse and QA. Your experience is scheduling deliveries across three depots. Question B1 is the one to rehearse most. It has a hold-then-concede structure, and it doesn't claim production work you haven't done.
- **SAP:** the advert lists it as a plus, and you've said you haven't used it. The pack says that plainly and presents learning it as a plan, not a past.
- **The one-third figure:** expect "how was that counted?" and "how much of that was you?". The pack doesn't supply a counting method. Only you can answer those.

Say the word and I'll run a live drill on B1. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations_coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator recruiter screen prep

**Role:** Operations Coordinator, Quillmoor Diagnostics (diagnostic-test manufacturer, about 400 staff). Hybrid, two days a week at Avonmouth, Bristol. Advertised £38,000–£44,000.
**Interviewer:** Hannah Lowther, Talent Partner. 30-minute phone call, Thursday 2pm, to the mobile number on your application.
**Built from:** the advert, Hannah's LinkedIn message, and your background as you gave it. Search was refused this session, so no company or interviewer research is included.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural and values; **EXP** your work experience and how you did it; **JD** the advert's requirements; **CO** company knowledge; **CASE** a live problem. This pack uses EXP and JD only. A 30-minute recruiter screen has no values round, no case, and no company-strategy question that research would support here.
- Guidance is scaffolding, not a script. Each guidance cell is meant to be spoken in 90 to 120 seconds.
- Your own words are in quotation marks. Every claim about your experience rests on one of those quotes. Anything in an *answer slot* is for you to answer in your own words, and "I don't know" or "that wasn't me" are valid answers.

## Prep triage

Prep time was not stated, so this assumes one evening before Thursday.

1. **A1 to A4** (pay, notice, hybrid, reason for moving). Hannah has named these as the agenda, so they are the call. Know your words for each.
2. **B1** (production scheduling). This is the most likely objection to your background, and the highest-return rehearsal in the pack.
3. **B2 and D1** (SAP). The advert lists it as a plus, and you have stated you have not used it.
4. **C1 and D2** (the one-third figure). Know how far your share of it goes.

Everything else is insurance.

**Call checklist**
- Have your notice period in weeks or months. Your material does not give it, so A2 has no words yet.
- Say your pay figure once, in your words, then stop.
- Say your location limit once, in your words.
- Keep the reason for moving to the closure and the Reading offer. Don't add to it.
- Have your CV open but don't read it aloud.
- If you are asked something not covered here, say you will check and come back, rather than guessing.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | No gap. Say the four years and the title in those terms. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I chase suppliers when orders slip." (your message); "I schedule deliveries for our three depots" (your message) | medium | [grounded] | presentation | Your words reach this in other terms. Reword only: "I chase suppliers when orders slip." Tracking is not in your material beyond the depot deliveries, so don't add it. |
| F3 | "coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | low | [inferred] | transferability | Your material shows delivery scheduling across three depots. It does not show production scheduling, planning, warehouse or QA work. Words: "For our three depots I schedule deliveries." Answer slot: if you coordinated anything across planning, a warehouse or a quality check, say which and how, in your own words; if you did not, say so plainly and stay with the depot deliveries. |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | high | [grounded] | none | Quote it whole: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The defend-the-number slots in C1 and C2 apply. |
| F5 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | discovery | The rebuild is spreadsheet work, but your material does not show how confident you are or which features you used. Answer slot: name the Excel work in your own words; if you can't say how far your skills go, say that and give the one example. |
| F6 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | none | [grounded] | capability | Words: "I haven't used SAP. We run our own in-house stock system." Then how you would learn an ERP, said as a plan, never as a past. Do not describe the in-house system as ERP experience. |
| F7 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if you reported on how often deliveries arrived on time, say what you measured and how often, in your own words; if you did not, say so plainly. |
| F8 | "two days a week at our Avonmouth site in Bristol" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Quote it whole. This is a logistics slot (A3). |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Quote it whole. This is a logistics slot (A1). |

**Requirement coverage**

| Advert requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | F1, A6 |
| Track supplier deliveries and chase late orders | F2, C4 |
| Coordinate production schedules between planning, the warehouse and QA | F3, B1 |
| Keep stock records accurate | F4, C1, C2, C3 |
| Confident with Excel | F5, B3 |
| ERP experience (SAP or similar) a plus | F6, B2, D1 |
| Report weekly on on-time dispatch | F7, B4 |
| Hybrid, two days at Avonmouth | F8, A3, R4 |
| £38,000–£44,000 | F9, A1, R5 |

## Prohibited claims

Each entry is listed with its basis, and no guidance cell may assert it.

| Claim | Kind | Basis | Honest form |
|---|---|---|---|
| Production scheduling experience | Inflated form | Your quote is about scheduling deliveries for three depots | Quote the depot scheduling at its own scope. The pack's observation: your material does not show production scheduling. |
| SAP or ERP experience | Sourced | You said "Never used SAP" | "I haven't used SAP." Your in-house stock system is described as that and nothing more. |
| QA or quality-check experience | Inflated form | No quote supports it | Not coached. Answer slot only (B1). |
| Sole credit for the one-third fall | Inflated form | "Discrepancies fell by about a third" sits beside "I rebuilt" | Quote the sentence at its scope. How much was yours is your own answer (C2). |
| On-time dispatch reporting | Inflated form | No quote supports it | Not coached. Answer slot only (F7, B4). |

## Persona weights

| Persona | How it shows up in this call | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Friendly questions about pay, notice, hybrid working, the move, and your background | **High, and top weight.** Hannah has set the agenda, and recruiter screens score logistics even in a friendly register. | Say each logistics answer in your own words, then stop. Treat the "tell me about yourself" opener as scored. |
| Skeptic | Probes the production and SAP gaps, and why now and why here | **High to medium.** The advert's production and ERP lines are where your material is thinnest. | Hold what you did, concede the gap specifically, and never bluff a system you haven't used. |
| Data-driven prober | "How was that counted?" on the one-third figure | **Medium.** It is a headline figure. | Say what you know. "I don't know how it was counted" is a valid branch. |
| Pressure | "How much of that was actually you?" | **Low to medium.** Recruiter screens rarely push hard. | Pause, restate the question, and hold one follow-up before conceding anything real. |
| Case / strategist; values | Not included | No case in a recruiter screen. No values-style round is detected, so the values cheat sheet is omitted. | None. |

## Question banks

### A. Conversational / rapport (top weight)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | JD | "What are your salary expectations?" (Hannah's message) | [grounded] "I'm hoping for £42,000" (your message) | Say it in your own words: "I'm hoping for £42,000." Then stop and let Hannah respond. If Hannah asks for the band first, you can say you'd like to hear the band; the advert gives £38,000–£44,000. Don't add a range, a floor, flexibility or a counter-offer. None of those are in your material. | This is the pay slot Hannah has named. Your own figure fills it. It raises no probe. |
| A2 | JD | "What's your notice period?" (Hannah's message) | [grounded] "your notice period" (Hannah's message). Your material gives no notice figure. | Give your actual notice period in weeks or months. If the exact term is in your contract and you don't have it to hand, say so and give what you know. Don't guess. | This is a logistics slot with no figure yet. The pack cannot supply one. |
| A3 | JD | "How would the hybrid pattern work for you?" (Hannah's message) | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | Say the two days and your three-day limit in those terms. If asked how you would make the journey, your own words were: "I live in north Bristol." Nothing else about travel is in your material. | This is the location slot. Repeat your words; add nothing. |
| A4 | EXP | "What's prompting a move?" (Hannah's message) | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message) | Say the closure and the Reading offer in that scope. Don't add other reasons, and don't say what you are looking for next. | This is the reason-for-leaving slot. The scope stays whole. |
| A5 | EXP | Follow-up: "Would you consider relocating?" (likely, after A4) | [grounded] "the only offer is relocating to Reading, which I don't want." (your message) | If asked, your own words were: "the only offer is relocating to Reading, which I don't want." Say it once and stop. | The natural follow-up to A4, and a relocation probe is likely. |
| A6 | EXP | "Tell me about your background." (open prompt) | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message); "I schedule deliveries for our three depots" (your message); "I chase suppliers when orders slip." (your message) | A 90-second arc from those sentences: four years as a logistics coordinator; deliveries for three depots; chasing suppliers when orders slip; the stock-count rebuild (see C1 for the figure). Don't add a bigger role. | An opener is scored. Your own sentences give the arc. |

### B. Skeptic (second weight; deepest rehearsal on B1)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| **B1** | JD (CASE delivery) | "The advert asks you to coordinate production schedules between planning, the warehouse and QA. Your experience is delivery scheduling at building-supplies depots. How would you do this job?" | [grounded] "I schedule deliveries for our three depots" (your message); [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | **Hold:** say what your material shows, "I schedule deliveries for our three depots", and hold it through two follow-ups. **Concede** specifically. If you coordinated anything across planning, a warehouse or a quality check, say which and how, in your own words. If you did not, say so plainly and stay with the depot deliveries. Then name the first thing you would learn: how the handoffs between planning, the warehouse and QA run. Don't claim production work. Likely follow-ups: "Which part of that transfers?" and "How long before you'd be productive?" No time figure is in your material; give your own estimate, if you have one. | **Highest-return prep in this pack.** The advert's production line is the largest gap between your material and the job, and it will be asked in some form. |
| B2 | JD | "The advert lists SAP-style ERP as a plus. Your background is an in-house stock system. How would you get up to speed on an ERP?" | [grounded] "Never used SAP — we run our own in-house stock system" (your message) | Say: "I haven't used SAP. We run our own in-house stock system." Then say how you would learn it, as a plan. Don't describe the in-house system as ERP experience. | The advert lists ERP as a plus, and you have stated the absence. A plan is the honest answer. |
| B3 | JD | "How confident are you with Excel for this kind of planning work?" | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | Answer slot: name the Excel work you did, in your own words, and say how far you would go with it. If you can't say how confident you are, say that and give the one example. | "Confident with Excel" is a stated requirement. Your quote touches it but does not show the level. |
| B4 | JD | "Have you reported on on-time dispatch before?" | [grounded] advert: "report weekly on on-time dispatch" (advert). Your sentences: none given. | Answer slot: if you reported on how often deliveries arrived on time, say what you measured and how often, in your own words. If you did not, say so plainly, and say what a weekly report would need from you. | A duty with no quote behind it. |
| B5 | EXP | "Your office is closing. Why this role, and why now?" | [grounded] "our Bristol office is closing next year" (your message) | Answer slot: say what this role offers that your current one does not, in your own words. If it is the location and the hybrid pattern, say so. | A "why now, why here" probe. Your closure sentence gives the timing; the reason is yours to state. |

### C. Data-driven prober (third weight)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | EXP | "The one-third drop in discrepancies: how was that counted?" | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | Answer slot: how the discrepancies were counted, what the figure is sensitive to, and the assumption behind it you would defend least, all in your own words. If you don't know how it was counted, say so. | A headline figure on your material is a magnet for probers. The pack supplies no method. |
| C2 | EXP | "Which part of that drop was yours, and what else changed over the year?" | [grounded] same quote as C1 | Answer slot: say which part was yours, in your words. If other things changed that year, name them. If you can't separate your share, say so. | The attribution probe. It asks you to split the credit honestly. |
| C3 | JD | "How did you keep stock records accurate day to day?" (open prompt) | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | Answer slot: say what you did between counts, if anything. If the spreadsheet was the main control, say that. | The advert asks for accurate stock records. Your rebuild is the nearest sentence. |
| C4 | JD | "Walk me through the last time a supplier order slipped." (open prompt) | [grounded] "I chase suppliers when orders slip." (your message) | Pick one slipped order. Say what slipped, who you chased and what happened next, in your own words. If none comes to mind, say so plainly, then give the nearest thing your material carries: that you chase suppliers when orders slip. | The advert asks you to chase late orders. This is a story from a quoted sentence. |

### D. Pressure (lowest weight)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| D1 | JD | "Sixty seconds: why should we hire you over someone with SAP experience?" | [grounded] "Never used SAP — we run our own in-house stock system" (your message); [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | Pause and restate the question. **Hold** that four years of logistics coordination is your position, and that ERP is listed as a plus. Hold through two follow-ups. **Concede** specifically: "I haven't used SAP." Don't fold on the four years, and don't claim SAP. | A stress version of B2. The hold-then-concede structure matters here. |
| D2 | EXP | "That one-third figure: how much of it was actually you?" | [grounded] same quote as C1 | Pause. **Hold:** "I rebuilt our stock-count spreadsheet." Concede only what you can't separate: if you can't say how much of the drop was yours, say so. Don't give a share. | A pressure version of C2. |
| D3 | JD | "Sixty seconds: what would you do in your first month here?" | [generic] advert duties: "coordinate production schedules", "report weekly on on-time dispatch". No sentence from you is needed; the answer is a plan. | Name one plan, as a plan: learn the handoffs between planning, the warehouse and QA, and how the weekly dispatch report is built. Don't describe past results. | A plan answer keeps you out of claims you can't back. |

## Reverse questions

Hannah has no public profile in this pack, so these are role-generic. Each one is for you to ask.

| ID | Question | Why it lands |
|---|---|---|
| R1 | "What does a normal week look like across planning, the warehouse and QA?" | Asks about the handoffs in the advert, the part your material is thinnest on. |
| R2 | "How is on-time dispatch measured and reported today?" | Connects to the weekly report duty, and shows you read the advert closely. |
| R3 | "What planning or ERP system does the team use, and what would training involve?" | Turns the SAP gap into a question about learning it. |
| R4 | "Which days at Avonmouth are fixed, and which are flexible?" | Hannah said they would cover how the hybrid pattern works. This tests it. |
| R5 | "How is the salary band set for this role?" | Asks about the band Hannah has already put on the table. It is a question, not a counter-offer. |

## Sources

- **Provided documents:** the advert, Hannah's LinkedIn message, and your background as given in this conversation.
- **Searches:** two web searches (one for Quillmoor Diagnostics and Avonmouth, one for Hannah Lowther) were refused at a permission prompt in this session, so nothing was retrieved. They were not retried.
- **Research tier:** L0, provided documents only.
- **Target accounting:** company research and strategy brief, unavailable (search refused). Interviewer public footprint, unavailable (search refused). Representative JD, n/a (advert supplied). Values, n/a (no values-style round detected). Recent organisation context, unavailable (search refused).
- **Dossier:** none present.

## Upgrade menu

- Your notice period → A2 gets your own figure, in your words, instead of an instruction.
- Search permission for this session → company and Avonmouth details, any published values, and public background on Hannah's role, which would move the pack to the default research tier.
- Hannah's public profile or LinkedIn career path → one reverse question tied to her path, and persona weights from her public footprint.
- A longer version of the advert or the team's job spec → the requirement coverage table and B1 can name the real handoffs.
- Prep time before Thursday → a timed triage in place of the one above.
