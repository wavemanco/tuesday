Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-5-rooms-case-13-denied-69d474a7/e02d494b-8f20-41c0-a101-ee3e2b222d68/scratchpad/quillmoor_operations_coordinator_interview_pack.md`.

**The four topics Hannah named**

- **Salary:** "I'm hoping for £42,000." Then stop and let her respond. If she names the band, you can ask what it is before going further.
- **Notice period:** I don't have yours, so this is the one slot I couldn't fill. Give your contractual period. Check it before Thursday.
- **Hybrid:** "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three."
- **Reason for moving:** "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want."

**The likely knockout: SAP.** Prepare this one most. Say "I've never used SAP," then describe the in-house stock system you ran in your own words. If you have used any other ERP or planning system, name it.

**The other gap: production scheduling.** The advert wants you to coordinate production schedules with planning, the warehouse and QA. Your material shows delivery scheduling across three depots, not production or QA. Be ready to say how you would approach it if you haven't done it. Also be ready for "do you report weekly on dispatch?" — your message doesn't cover it.

**Questions to ask her:** what a typical week looks like across planning, the warehouse and QA; how on-time dispatch is reported today; what systems planning and the warehouse use; how the band is set within £38,000–£44,000; and what happens after this call.

Research didn't run. Two web searches for Quillmoor were refused for lack of permission, so the pack has nothing on their values, strategy or interview process.

Would you like a drill, where I play Hannah and push on the SAP answer? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later rounds. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations_coordinator_interview_pack.md -----
# Quillmoor Diagnostics — Operations Coordinator — Recruiter screen pack

Role: Operations Coordinator, Quillmoor Diagnostics (diagnostic-test manufacturer, about 400 staff), hybrid at Avonmouth, Bristol.
Interviewer: Hannah Lowther, Talent Partner. Round: 30-minute phone call, Thursday 2pm, she calls your mobile from the application.
Her stated agenda: salary expectations, notice period, how the hybrid pattern would work, what is prompting the move, then the team and next steps.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD (the advert's requirements), EXP (your past), LOG (a logistics term she will ask).
- Guidance is scaffolding, not a script. Say the parts in quotation marks in your own words; the quotes are your sentences.
- Question IDs (A1, B2 and so on) are used throughout.

## Research tier

No research ran. Two web searches for Quillmoor were refused (permission not granted), so this pack uses only the advert and your message. Nothing about Quillmoor's values, strategy or interview process is in it.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | high | [grounded] | none | No gap. Say the four years and the role in those words. |
| F2 | "coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material shows delivery scheduling across three depots, not production scheduling with planning or QA. Say the deliveries in those words. Answer slot: if you have worked to a schedule that involved a production, planning or QA team, say how, in your own words; if you have not, say so plainly and say how you would approach it. |
| F3 | "track supplier deliveries and chase late orders" — advert | "chase suppliers when orders slip" — your message | high | [grounded] | none | Say it in those words. This sentence reaches the requirement. |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | presentation | The quote already reaches the requirement. Say it in those words. Do not add the cause or the method beyond what the sentence says. |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [inferred] | discovery | Your material does not show any dispatch reporting. Answer slot: if you reported on delivery timeliness, say what you reported and how often; if you did not, say so plainly and say what you would report first. |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | medium | [grounded] | presentation | Your sentence says spreadsheet, not Excel. Say the spreadsheet in those words. Do not name Excel features you have not stated. |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP" and "we run our own in-house stock system" — your message | medium | [grounded] | transferability | You have not used SAP, and you have run a stock system. Say the stock system in its own words. The plain acknowledgment is "I've never used SAP." |
| F8 | "Hybrid: two days a week at our Avonmouth site" — advert | "two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Your stated limit. Say it in those words. |

Gate rows: none in this advert. ERP is marked a plus, not a requirement, so it is not a gate.

## Prohibited claims

Built locally from the fit snapshot. These are the wordings a candidate reaches for under pressure. No answer, hold or bridge in this pack asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned production scheduling with planning and QA | Widened form of F2: your sentence is about deliveries | "I schedule deliveries for our three depots." Your material says deliveries, not production scheduling. |
| Has used SAP or a similar ERP | Negative you stated for SAP (F7) | "I've never used SAP." Then the stock system you ran, in your own words. |
| The rebuild caused the one-third fall | Widened form of F4: your sentence gives the fall and the rebuild, not a cause | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." |

## Persona weights

| Persona | Weight | Why |
|---|---|---|
| Conversational / Rapport | 3 | Recruiter screens are friendly and unstructured; the logistics questions are still scored. |
| Skeptic | 2 | The knockout checks are SAP, production scheduling and the reporting line. These are where the pack expects the probe. |

No interviewer profile exists, so there is no interviewer read and no persona adjustment from one.

## Question banks

### Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me a bit about your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | About 90 seconds: the four years, the three depots, the supplier chasing, and the stock-count spreadsheet. Use your own sentences above. | Opening biography. F1 and F3 are the strongest matches to the advert, so say them first. |
| C2 | "How confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Say you rebuilt the stock-count spreadsheet. Answer slot: if it was in Excel, name it and say what you built; if it was in another tool, name that tool. | F6: your sentence says spreadsheet. Do not claim Excel skills beyond it. |

### Skeptic (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role lists SAP or similar. What's your experience with it?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Highest-ROI prep in this pack. Say the plain acknowledgment: "I've never used SAP." Then describe the in-house stock system you ran, in your own words. Answer slot: if you have worked with any other ERP or planning system, say which and what you did with it; if you have not, say so and say what you would learn first. | F7 is the likeliest knockout probe, and a plain, prepared answer avoids a defensive one. |
| B2 | "Have you coordinated production schedules with planning, the warehouse or QA?" | JD | [grounded] "I schedule deliveries for our three depots" | Say the delivery scheduling in your words. Answer slot: if you have worked to a schedule with a production, planning or QA team, say how; if you have not, say so plainly and say how you would approach it. | F2: the advert's first requirement, and your material does not reach it directly. |
| B3 | "Your stock-count rebuild: how did discrepancies fall?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say the rebuild and the one-third fall over a year, in those words. Weakest-assumption move: name in your own words anything else that changed over that year that could have moved the figure. If you do not know, say so. | F4: a figure from your CV gets probed on its counting. Name the assumption before she does. |
| B4 | "Do you report weekly on on-time dispatch?" | JD | none given | Answer slot: if you reported on delivery timeliness, say what, how often and to whom; if you did not, say so plainly and say what you would report first. | F5: the advert asks for this and your material is silent. The honest answer is ready before the question comes. |

### Logistics (fills her agenda; no further questions raised)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say it in those words, then stop and let her respond. If she names the band, you can ask what it is before going further. | Pay is her first item. The figure you stated fills this slot and raises nothing more. |
| A2 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Say it in those words. Do not add a travel method. | F8: your stated limit, kept at its own scope. |
| A3 | "What's your notice period?" | JD | none given | Give your actual notice period, as your contract states it. Your material does not give one, so there is no figure in this pack. | Notice is on her list. The answer is yours to supply. |
| A4 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say it in those words. Do not add a reason beyond them. | Her fourth item. Your reason is already stated. |

## Requirement coverage

| Advert requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | C1, F1 |
| Coordinate production schedules (planning, warehouse, QA) | B2, F2 |
| Track supplier deliveries and chase late orders | C1, F3 |
| Keep stock records accurate | B3, F4 |
| Weekly on-time dispatch report | B4, F5 |
| Excel | C2, F6 |
| ERP (SAP or similar), a plus | B1, F7 |
| Pay £38,000–£44,000 | A1 |
| Hybrid, two days at Avonmouth | A2, F8 |

## Reverse questions

Each one has a "why it lands."

1. "What does a typical week look like across planning, the warehouse and QA?" — Shows you are matching the advert's first requirement.
2. "How is on-time dispatch reported today, and who reads the weekly report?" — Opens the reporting requirement you have no material for.
3. "What systems do the planning and warehouse teams use day to day?" — Puts the SAP question in terms of what the team actually runs.
4. "How is the band set within £38,000–£44,000?" — Pay is her first item; this shows you have read the advert.
5. "What happens after this call?" — She said she would cover next steps; asking it first shows you were listening.

## Upgrade menu

- Quillmoor's published values, or its careers page → a values cheat sheet, if a values-style round follows.
- Your contractual notice period → a concrete figure for A3, in place of an instruction.
- Permission for web search → the research tier, Quillmoor's values and interview process, and a grounded version of the reverse questions.
- The interviewer's name for any later round → persona weights and reverse questions built from their public footprint.
- Deep research (L2), if you want it: up to 6 further searches and 2 further page fetches, with permission. It adds the company's strategy and recent news.
