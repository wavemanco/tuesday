**Please don't pay the €95 fee, send a passport photo or bank details, or deposit the cheque.** This has the hallmarks of a fake-cheque job scam. The email says:

> "transfer the €95 equipment registration fee to our supplier's account, IBAN ..."
> "reply with a photo of your passport and your bank details before the interview"
> "you deposit the cheque and send the balance on to the vendor"

Legitimate employers don't charge candidates for equipment or interview slots, and they don't send a cheque for you to forward the "balance" to a vendor. A deposited cheque can show as cleared for a few days before the bank reverses it when it bounces, and by then the money you sent is gone. Your passport and bank details are enough for identity theft even without a payment.

To check it, find the company's registration yourself (in Ireland, the CRO register) and its phone number and careers page, not the ones in this email. Ask them whether the role and the interview exist. Don't reply to this email with any documents or details. If you applied through a job board, check the listing there too.

If the role turns out to be real, here's how to prepare.

## What to expect

A 30-minute video call with the office manager, probably covering your background, how you handle a busy calendar, and how you'd work remotely. Expect a short practical question about Word or Excel.

## Fit snapshot

| Role requirement | Your evidence | Gap type | Bridge |
|---|---|---|---|
| Managing calendars | "ran the appointment book for four physios" | None | Strong match |
| Booking travel | Not in your material | Experience gap | "I haven't booked corporate travel, but I've coordinated schedules for four people across changing bookings and cancellations" |
| Word/Excel documents | "good with Word, okay with Excel" | Skill-level gap on Excel | Give a concrete example of a document you produced; say what you'd need to learn |
| Supplier invoices | "chasing unpaid invoices" | Partial: chasing is not processing | "I chased payments; I haven't processed supplier invoices end to end, but I know the follow-up side well" |
| Remote working | Not in your material | Experience gap | Describe how you stay organised and communicate without in-person contact, but only if that's true |

## Likely questions and answer guidance

1. **"Tell me about your background."** Give a 60-second version: two years as a receptionist, ran the appointment book for four physios, chased unpaid invoices. Keep it factual.
2. **"How do you handle conflicting bookings?"** Use a real example from the clinic: how you rearranged appointments, who you told, and how you prevented it next time.
3. **"How did you chase unpaid invoices?"** Describe your actual process: how often you followed up, what you said, when you escalated. Don't claim you ran accounts receivable unless you did.
4. **"How good are you at Excel?"** Be honest: "Okay. I use it for [what you actually do], and I'm building skills in [X]." Have one real example ready.
5. **"How do you handle confidential information?"** A physio clinic handles patient records, so describe how you kept those private.
6. **"Why this role?"** Connect it to the work you're good at (scheduling, admin, client-facing follow-up), not generic enthusiasm.

## Questions to ask them

- What does a typical week look like, and how is success measured?
- Which tools will I use for calendars, travel and documents?
- Who provides the equipment, and how is that handled?
- How are supplier invoices approved and paid, and who is my day-to-day contact?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

## Next step

Did you apply through a job board or the company's own website? If you applied directly, that tells us whether this email is consistent with your application.