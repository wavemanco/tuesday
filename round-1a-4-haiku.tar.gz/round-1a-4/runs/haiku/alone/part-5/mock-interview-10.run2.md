Before the prep, one thing in the invite. It says "Our hiring process is fully remote and is carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well." A hiring process run wholly by chat is a known scam pattern, and a chat alone does not show who you are dealing with. The invite asks for no money, bank details or documents, so I'm not calling it a scam. Until you've checked, send no payment, ID, documents or bank details here. To check, use the Lumenvale Software careers page or the contact details on its own website, not any number, email or answer in this chat. You applied through that page, so start there. You can also ask job-underwriter to check the invite as a separate request. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-5-rooms-case-10-denied-b7f88c0f/6b5ea629-1086-4524-a2d8-08a4a6f09527/scratchpad/lumenvale_customer-support-specialist_interview_pack.md`. I built it for a text-chat round with the team lead, since your message says that. Web search was declined, so the pack uses only your material and the requirements you summarised.

The highest-ROI prep is A2: "Tell me about an escalation you handled and what you did with it." The ad names escalations, your material doesn't show one, and the team lead will probably push there. Say the word and I'll play the Skeptic on A2 in this chat.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

Which country are you based in, and is the job open to applicants there? That decides whether the remote role's location and right-to-work requirement is one you can meet.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer-support-specialist_interview_pack.md -----
# Lumenvale Software: Customer Support Specialist interview prep pack

**Role:** Customer Support Specialist (remote)
**Company:** Lumenvale Software
**Interviewer:** support team lead (name not given)
**Round:** text chat on Telegram with the support team lead (per your invite)
**Built from:** your message only. No full job ad text, no company research (web search was declined), no interviewer profile.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a typed answer, not a script. In a text chat, your written length and pauses are part of the delivery.

Type key:

- **VAL**: behavioural or values alignment. Not used here, because no company values were available.
- **EXP**: work-experience deep dive. Tests whether your claims hold up.
- **JD**: the role's stated requirements. Can you do the listed job, gaps included?
- **CO**: company and strategy knowledge. Not used here, because no research ran.
- **CASE**: a live problem from the role, answered in writing.

## Fit snapshot

Requirements are quoted from your message. Your evidence is quoted from your message too. Gap and bridge language uses only what you stated.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your message) | "3 years as a customer service advisor at an energy supplier" (your message) | high | [grounded] | none | No gap on the count. Words: "I have 3 years as a customer service advisor at an energy supplier." Your material shows energy-supplier support, not software support. |
| F2 | "experience with Zendesk or a similar ticketing tool" (your message) | "I use Freshdesk every day" (your message) | high | [grounded] | presentation | Freshdesk is a similar ticketing tool, but it is not Zendesk. Words: "I use Freshdesk every day." Your material does not show Zendesk, and nothing here says you have used it. |
| F3 | "clear written communication" (your message) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Volume shows you write a lot. It does not show the writing is clear. Answer slot: name one written reply you sent to a customer or colleague and what it did. If none comes to mind, say so, then give the nearest thing your material carries. |
| F4 | "confidence handling escalations" (your message) | none given | none | [grounded] | discovery | Your material does not show an escalation. Answer slot: if you have handled one, say what it was and what you decided. If you have not, say so plainly and describe how you would handle one. |
| F5 | Software-company experience (role's sector) | "I've never worked for a software company." (your message) | none | [grounded] | capability | Words: "I've never worked for a software company." Then how you would learn the product and sector, as a plan for the future, never as a past. |
| F6 | Remote work from your location, and the right to work there (the invite says "fully remote"; no ad text quoted) | none given | none | [generic] | hard_gate | Your material does not establish your location or right to work for this role. Not bridged. The one question in the message asks it. |

Gap type is set by the routing rule in the skill's output template. Confidence grades your evidence. Provenance grades what this pack says about it.

## Prohibited claims

The pack will not coach these claims, because your material does not support them.

| Not coached | Basis | Honest form |
|---|---|---|
| "Zendesk experience" | Inflated form of F2 | "I use Freshdesk every day." Your material shows Freshdesk, not Zendesk. |
| "I designed the refunds process" | Inflated form of "I trained four new starters on our refunds process last year" (your message) | "I trained four new starters on our refunds process last year." |
| "I have worked for a software company" | Negative you stated, F5 | "I've never worked for a software company." A plain acknowledgment, with no answer slot. |

## Persona weights

Relationship prior: hiring manager, which is a team lead in a text chat. The prior is Case/Strategist plus Skeptic. Interviewer signals: none. Loop: single session.

| Persona | How it shows up in a text chat | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic | Pointed follow-ups on the gaps: Zendesk, escalations, the software background | Highest. The team lead is buying capability and checking the thin rows F2, F3 and F4 | Rehearse the escalation answer until it is plain and honest. Lead with the quoted tool, then the gap, then a plan | 5 |
| Case/Strategist | Written live problems from the role: a refund, a login, a bug | High. A support team lead tests reply quality and escalation judgement in writing | Clarify first, then the first reply, then the escalation or next step. Keep each reply short | 4 |
| Data-Driven Prober | Asks how the 60-a-day figure was counted and what the Freshdesk use covered | Medium. The volume figure is the headline claim in your message | Say what you know about the count. Name the weakest word, "around", before they do. Say plainly what you do not know | 4 |
| Pressure | Short written challenges on the software gap and on motivation | Lower in a text chat, but written challenges do come | Hold the core claim through two follow-ups. Concede the specific gap | 3 |
| Conversational | An opener and a casual question about the work | Certain as an opener. Casual questions are still scored | A 90-second arc about your journey. A plain, true answer to the casual question | 2 |

## Question banks

Provenance is listed before the guidance. Every candidate statement the guidance relies on is quoted.

### Skeptic (weight 5: five questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The role asks for Zendesk or a similar ticketing tool. Which ticketing tools have you used?" | JD | [grounded] "I use Freshdesk every day" (your message) | Lead with Freshdesk in your own words: "I use Freshdesk every day." Answer slot: if you have used Zendesk, name it and how you used it. If you have not, say so plainly and describe how you would learn it. | F2 is a presentation gap: the tool is similar but not the one named. JD because the ad names the tool. |
| A2 | "Tell me about an escalation you handled and what you did with it." | JD | [grounded] "I trained four new starters on our refunds process last year" (your message) | **The highest-ROI prep in this pack.** Open prompt: pick the escalation that taught you most. Say the customer's ask, what you decided, and how it ended. Answer slot: if you handled an escalation, name it and your decision in your own words. If you have not handled one, say so plainly, then give the nearest thing your material carries: the refunds process you trained four starters on. Hold through two follow-ups by returning to what you did, never by adding to it. | F4 has no quote. The ad names escalations, so this objection will come in some form. The rehearsed honest answer changes the interview. |
| A3 | "What about software support appeals to you, given your background is in energy?" | EXP | [grounded] "I've never worked for a software company." (your message); [grounded] "answering around 60 calls and emails a day" (your message) | Plain acknowledgment: "I've never worked for a software company." Then your own reason for this role. Your material gives no motive, so do not supply one. You can name the volume work you already do: "answering around 60 calls and emails a day." | F5 is the candidate's own negative. Motivation consistency is a Skeptic question. |
| A4 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Answer slot: name the tool and the escalation areas you have not yet shown, then a learning plan for the first week. Keep it entirely in the future. | Classic Skeptic stem. The answer is a plan, not a past. |
| A5 | "The role asks for 2+ years in customer support. What has that support work looked like for you?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | Give the role and the years in one sentence, then the volume: "answering around 60 calls and emails a day." Answer slot: name the channels you handled, in your own words. | Covers the 2+ years requirement with your own numbers. |

### Case/Strategist (weight 4: four questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer says a refund has not arrived after two weeks. What do you do first, and what do you write back?" | CASE | [generic] | Check the refund status before you reply. Say what you found. Give a date for the next update. Decide whether it needs escalating. About 90 seconds in writing. | A live refund problem. It makes no claim about your past. |
| B2 | "A customer cannot log in and is angry. Write your first reply in two short lines." | CASE | [generic] | Acknowledge the frustration in one line. Give one concrete next step. Say what you need from them. | Tests clear written communication directly, in the medium the role uses. Covers the written-communication requirement. |
| B3 | "A bug is hitting many customers and you cannot fix it. What do you tell customers, and who do you escalate to?" | CASE | [generic] | Say what is known, what is not, and when they will hear next. Escalate to the team that owns the fix. | Escalation judgement in a live problem. Covers the escalation requirement. |
| B4 | "A customer asks for a refund you are not allowed to approve. What do you write?" | CASE | [generic] | Say what you can do now, what needs approval, who decides, and when they will hear. | Tests refund handling without asking you to claim authority you have not stated. |

### Data-Driven Prober (weight 3: four questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was the 60 calls and emails a day counted?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Say how you know the figure, in your own words. Weakest-assumption move: name the part you would defend least. The word "around" is where a prober will test. Answer slot: if you know how it was counted, say how. If you do not, say so plainly. | A headline figure. Defend-the-number slot: how counted, what it is sensitive to, which part was yours. |
| C2 | "How many of those were calls, and how many were emails?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Answer slot: if you know the split, give it. If you do not, say so plainly, then say how you would track it. | A denominator question. Same defend-the-number slot as C1. |
| C3 | "How did you check that your four new starters had the refunds process?" | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Answer slot: if you checked, say what you checked and how. If you did not check, say so plainly, then say what you would check next time. | The question presumes a check your message does not mention. The second branch allows that no check was made. |
| C4 | "What do you use Freshdesk for day to day?" | EXP | [grounded] "I use Freshdesk every day" (your message) | Answer slot: say what you use it for, in your own words. If you use it only for part of the work, say which part. | Tests depth on the one tool you have named. |

### Conversational (weight 2: two questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey so far." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | A 90-second arc: the role, the energy supplier, the daily volume, Freshdesk, and training four starters. Each beat is a sentence you gave. | A chat opener. Casual questions are still scored. |
| D2 | "What's the part of support work you enjoy most?" | EXP | [generic] | Answer in one true sentence. If the honest answer is the training you did, say that. | Tests communication economy and genuine interest, not a claim about your past. |

### Pressure (weight 3: three questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Those 60 a day: how much of that was actually you?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Hold: say what you answered yourself, in your own words. Concede specifically the part you cannot verify, such as the exact count. If some contacts were handled by others, say so. | A pressure version of C1. Tests composure as much as content. |
| E2 | "You have never worked for a software company. Why should we take that risk on you?" | JD | [grounded] "I've never worked for a software company." (your message) | Plain acknowledgment: "I've never worked for a software company." Hold the core claim with the volume and tool work you quoted. Concede the product learning curve in your own words, once. | F5 is your own negative, so you can say it plainly. Hold before you concede. |
| E3 | "Give me one sentence: why this role, and why now?" | EXP | [generic] | Answer slot: one sentence with your own reason. The pack supplies none. If pushed, keep to that reason. | A time-boxed motivation probe. |

### Requirement coverage

| Requirement (your message) | Questions covering it |
|---|---|
| 2+ years in customer support | A5, D1 |
| Zendesk or a similar ticketing tool | A1, C4 |
| Clear written communication | B2, B1 |
| Confidence handling escalations | A2, B3 |
| Remote work, location and right to work | None, and why: this is a gate, asked in the message, not in the interview |

Total: 18 questions.

## Reverse questions

Ask any of these. Each one has a reason it helps you.

- **"What happens to an escalation after the first reply? Who owns it next?"** Why it lands: it shows you think about hand-offs, which is how the role is judged.
- **"Which ticketing tool does the team use, and how are views and macros set up?"** Why it lands: it meets the Zendesk question head-on and shows you know what these tools do.
- **"How do you judge a good written reply here?"** Why it lands: written communication is the whole interview medium.
- **"What does a new starter's first month look like?"** Why it lands: it tests the learning plan in A4 against the team's own answer.
- **"What's the team's biggest support challenge right now?"** Why it lands: it shows you listen, and it lets you tie an answer back to escalations.
- **"Is there a call or video step after this chat?"** Why it lands: it lets you plan prep time. It asks about the process only.

## Sources

- **Provided documents:** your message (the invite text and your background), and the job ad requirements as you summarised them. No full ad text was supplied.
- **Searches and fetches:** one search, "Lumenvale Software careers Customer Support Specialist", was refused because web search permission was not granted. No fetch ran.

Research tier: L1, searches 0 of 6 (one refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Values cheat sheet, section 10. Dropped: no values published in hand. |
| 2. Lumenvale interview process for this role family | unavailable | Loop structure and persona weights. Search refused, so the weights use the relationship prior only. |
| 3. Lumenvale strategy and recent news | unavailable | Company and strategy bank. No CO questions were written. |
| 4. Interviewer name and Lumenvale | n/a | No name given, so no query could be formed. |
| 5. Representative Customer Support Specialist job ad | unavailable | Fit snapshot requirement quotes, with `[inferred]` labels. Search refused, so the requirements come from your summary only. |

## Upgrade menu

- The full job ad text → each requirement quoted verbatim, and the gap rows re-graded.
- Your country and right-to-work status → F6 becomes a bridged row, not a gate.
- The team lead's name, once you have verified the invite through Lumenvale's own contact details → an interviewer read, and a tailored reverse question.
- Lumenvale's published values, pasted or fetched → a values cheat sheet and a values-style question bank.
- Web search permission → the company and process targets above, which would confirm the role and loop structure.
