Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-5-rooms-case-13-denied-810f4ace/c9908c23-a4e6-4e41-9f88-06f7dadd2948/scratchpad/quillmoor_operations-coordinator_interview_pack.md. I built it for a recruiter screen, as Hannah described it, and I ran no company research, so the company answer (A7) rests on the advert and your own work.

The pack's three main points:

- **Highest-ROI prep (B1):** "This role coordinates production schedules between planning, the warehouse and QA. Where's your experience of that?" Your material shows delivery scheduling across three depots, not production planning or QA. Say that plainly and say how the delivery work would carry over.
- **Pay, notice and hybrid:** Your figure is "I'm hoping for £42,000," said as it is. Your hybrid answer is two days works and three is your ceiling, in your words, with nothing added.
- **Reason for the move:** Lead with the closure, then the Reading point, with no criticism of the employer.

Two things I could not fill from what you gave me:

- **Notice period:** Hannah asked for it and you haven't said it. The pack gives you an instruction, not a line to say.
- **Right to work in the UK:** It isn't in the advert, but it is a common screen knockout, and the pack can't cover it without your answer.

Two questions for you:

1. What is your notice period?
2. Do you have the right to work in the UK without sponsorship?

If you want to rehearse, I can play the Skeptic on B1 with follow-ups. A `tuesday-dossier.md` could also record the gaps this prep exposed for later sessions. The file also says where it stops and what each missing input would add.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

**Role:** Operations Coordinator, Avonmouth (Bristol), hybrid
**Company:** Quillmoor Diagnostics
**Interviewer:** Hannah Lowther, Talent Partner (recruiter). Relationship: recruiter screen.
**Format:** 30-minute phone call, Thursday 2pm. Hannah will ring your mobile.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Tag | Meaning |
|---|---|
| JD | Does the listed job's requirement or term hold up? |
| EXP | Does your own experience hold up when asked about? |
| CO | Do you know the company? (not scored here, no research run) |
| CASE | Live problem from the role (not used in this screen) |
| VAL | Values fit (not used: no values-style round detected) |

Guidance is scaffolding, not a script. Quote only your own words.

This pack has 13 questions. That is below the usual 18 to 26 for a full pack, because a 30-minute screen cannot rehearse more than that. Each question has a guidance cell and a rationale.

## Prep triage

Prep time is not stated, so no triage schedule is given. Two things to settle before Thursday: your notice period (A2) and right to work in the UK (F9).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | transferability | Your material shows delivery scheduling across three depots, not production schedules and not QA. Keep the bridge at that scope. Answer slot: if you have coordinated anything between planning, the warehouse or QA, say what and how; if you have not, say so plainly and say how delivery scheduling would carry over. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | high | [grounded] | presentation | Your words already reach this: "chase suppliers when orders slip." No method is added. |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | presentation | Your words already reach this. The sentence shows the rebuild and the fall. It does not show how much of the fall the rebuild caused alone, so do not claim that. |
| F4 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | presentation | The rebuild is your only Excel evidence. Say that. Do not list functions you have not named. |
| F5 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | Your quote already reaches this. Say it in those terms. |
| F6 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | You stated the absence. Plain acknowledgment: "I've never used SAP." Then how you would learn it, said as a plan and never as a past. Do not describe your in-house system as ERP experience. |
| F7 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show dispatch reporting. Answer slot: if you have reported on dispatch or delivery timing, say what you reported and how often; if not, say so and say how you would track it. |
| F8 | "Hybrid: two days a week at our Avonmouth site" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Your stated limit is three days. Say it in your own words and do not offer more flexibility than that. |
| F9 | Right to work in the UK (not in the advert) | none given | none | [generic] | hard_gate | Your material does not establish this. The one question about it is asked in the message that delivers this pack. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I plan production schedules" or "I've coordinated planning, the warehouse and QA" | Inflated form of F1 | Your quote at its own scope: "I schedule deliveries for our three depots." Pack observation: your material shows delivery scheduling, not production scheduling. |
| "I cut discrepancies by a third" | Inflated causal form of F3 | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Pack observation: the sentence does not show that the rebuild alone caused the fall. |
| "I have ERP or SAP experience" | Negative you stated (F6) | "I've never used SAP." |

## Persona weights

Relationship prior for a recruiter screen: Conversational plus light Skeptic (personas.md). No interviewer profile exists, so there is no adjustment.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport (weight: top) | Friendly opener about your background; pay, notice and hybrid asked in a light register | High. Recruiter screens run in this register, and the logistics are scored even when they sound casual. | Practise the 90-second background arc. Treat every logistics answer as scored. |
| Light Skeptic (weight: second) | Probes on the gaps: planning and QA, SAP, dispatch reporting, why this role and why now | Medium. These are the advert's requirements your material does not reach. | Plain acknowledgment where you stated a gap. Answer slots for the rest. Do not bluff. |
| Pressure, Data-Driven Prober, Case | Not weighted | Low. Not in the recruiter-screen prior, and the call is 30 minutes. | None needed for this screen. |

## Question banks

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." (your message) | Say your figure in your own words: "I'm hoping for £42,000." That is the whole answer. If asked what you earn now, you can decline and redirect: "I'd rather we talk about the role's band." Do not add a range, floor or flexibility beyond what you have said. | Pay is the first topic Hannah named. Your figure sits inside the advert's £38,000 to £44,000. |
| A2 | "What's your notice period?" | JD | [generic] | Instruction: give your actual notice period in one sentence. Your material does not state it, so this slot stays open until you fill it in. | Hannah named it. The pack has no figure and will not supply one. |
| A3 | "How would the two days at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | Say that two days works and that three is your ceiling, in those words. Add nothing to them. | The advert fixes two days. Your stated ceiling is the only boundary you gave (F8). |
| A4 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message) | Lead with the closure, then the Reading point, in those terms. Keep to the facts. Do not criticise the employer. | A closure is a reason that does not invite a follow-up about the employer. |
| A5 | "Walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" and "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | 90-second arc: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for three depots; you chase suppliers when orders slip. Stop at the quotes. | An open opener, scored as conversation. These are the only sentences you gave for it. |
| A6 | "What's the piece of work you're proudest of?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | Say what you rebuilt and what happened over the year, in those words. Stop there. | Your strongest measured result is this rebuild (F3). Lead with it. |
| A7 | "Why Quillmoor, and why this role?" | CO | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | Name the part of the advert that matches your own work, in your words. The scheduling and supplier chasing are the link your material shows. Do not claim knowledge of the company. | No research has been run, so the company answer has to come from the advert and your own work. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates production schedules between planning, the warehouse and QA. Where's your experience of that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | Highest-ROI prep in this pack. Say that your scheduling is delivery scheduling across three depots, in those words. Answer slot: if you have coordinated anything between planning, the warehouse or QA, say what and how; if you have not, say so plainly, and say how delivery scheduling would carry over. Hold through one follow-up by returning to the delivery work. | F1 is the largest gap and the likeliest probe. The planning and QA requirement is the core of the role. |
| B2 | "You've not used SAP. Is that a problem?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." (your message) | Plain acknowledgment: "I've never used SAP." Then how you would learn it, as a plan. Do not describe your in-house system as ERP. | F6 is a stated gap, so you can say it plainly. The plan is a plan, not a past. |
| B3 | "The role reports weekly on on-time dispatch. Have you produced that kind of report?" | JD | [grounded] (advert: "report weekly on on-time dispatch") | Answer slot: if you have reported on dispatch or delivery timing, say what you reported and how often; if not, say so and say how you would track it. | F7 is a gap your material is silent on. Its words are an answer slot, not a claim. |
| B4 | "Why this role, and why now?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message) | Give the closure and what you want from the next role, in your own words. Answer slot: if you had a reason to move beyond the closure, say it; if the closure is the whole reason, say so. | Probes motive. The closure is your stated reason, and the want is yours to supply. |
| B5 | "How did you count the discrepancies?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | Say what you rebuilt and what fell. Defend-the-number slot: if you know how the discrepancy count was taken, say so and name the assumption you would defend least. If you do not know, say "I don't know how the count was taken." | The figure raises a defend-the-number probe. The honest branch is allowed. |
| B6 | "The role chases late orders from suppliers. How do you do that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | Say that you chase suppliers when orders slip, and describe your method in your words. Add no figure. | F2 is a presentation match. The advert's wording is close to your own. |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A5, F5 |
| Coordinate production schedules (planning, warehouse, QA) | B1 |
| Track supplier deliveries, chase late orders | B6 |
| Keep stock records accurate | B5, A6 |
| Weekly on-time dispatch reporting | B3 |
| Confident with Excel | B5 (rebuild is the only evidence; F4) |
| ERP (SAP or similar), a plus | B2 |
| Salary £38,000 to £44,000 | A1 |
| Hybrid, two days at Avonmouth | A3 |
| Notice period (logistics) | A2 |
| Reason for move (logistics) | A4, B4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like for whoever holds this role?" | Shows you are picturing the job, not only the title. |
| R2 | "Where do planning, the warehouse and QA usually hand work to each other?" | Shows you have spotted the seam the role sits on. |
| R3 | "How is the two-day Avonmouth pattern usually set up for this team?" | Confirms the days and the site without negotiating them. |
| R4 | "What would a good first 90 days look like for the person in this role?" | Turns the call toward delivery, and gives you a plan to say aloud. |
| R5 | "What happens after this call, and roughly when?" | Next steps are Hannah's stated agenda, so this is a natural close. |

## Sources

- Provided documents: the advert text; Hannah Lowther's LinkedIn message; your background message.
- Research tier: L0. No searches or fetches were run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Would have added a values line. Not needed for a recruiter screen. |
| 2. Quillmoor Diagnostics interview process | unavailable | Would have confirmed what follows this screen. |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | Would have sharpened A7 (why Quillmoor). |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Would have given a public-footprint read and a more specific R-question. |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot. |

## Upgrade menu

- Your notice period in one sentence → A2 moves from an instruction to your own stated line.
- Right to work in the UK, stated in your words → F9 gets a stated line and the hard gate closes.
- Any production planning, warehouse or QA coordination you have done → B1 and F1 move from transferability toward grounded.
- Any dispatch or delivery-timing reporting → B3 gets a sentence to quote.
- Research at L1 (up to 6 searches and 2 page fetches) → the company values, strategy and Hannah's public footprint, which sharpen A7 and R-questions.
- Prep time before Thursday → a prep triage section with the order to rehearse in.
- A `tuesday-dossier.md` file → would carry verified evidence and the gaps from prep into this pack.
