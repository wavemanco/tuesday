# Interview Prep Pack: Fourth Grade Teacher, Halvering Elementary (Orrinsford CSD)

Saved to `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-5-rooms-case-9-canned-e55a9d4c/5804fce2-d975-48d7-9977-46992adc284c/scratchpad/grace-fourth-grade-prep-pack.md`

**Format:** 45-minute panel: Principal Dolores Vantongeren plus two fourth-grade team members, on Thursday.
**Build basis:** your invite and resume only. I ran no web research, so anything not from those is marked `[generic]`.

## 1. Fit snapshot

| JD requirement (inferred from invite) | Your evidence (quoted from resume) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| Valid Illinois PEL, elementary endorsement | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | High | None | Meets the requirement. |
| Elementary classroom teaching | "Six years teaching third grade at a public elementary school in Joliet." | High | Grade level | "I haven't taught fourth grade, but six years in third grade means I know what students bring into your grade." |
| Curriculum / reading instruction | "I led our grade level's move to a new reading curriculum in 2024." | Medium (your role's scope isn't stated) | Detail | Describe the decisions you made, not the title. |
| Family communication | "I write a weekly email to families." | High | None | Concrete, ongoing practice. |
| Reading support | "I've run the after-school reading club for the last two years." | High | None | Bridges to the reading focus of 4th grade `[generic]`. |
| Team leadership | "I've never been a team lead." | Known gap | Experience | "I haven't held the title. I did lead a grade-level change in 2024, the closest I've come." |

## 2. Prohibited claims (don't say these)

- That you have taught fourth grade or know its content from experience.
- That you were a team lead or had formal authority over colleagues.
- That the 2024 curriculum change was yours alone, or that it produced measured results, unless you can cite the data.
- Any reading-club outcome numbers you can't cite.

Basis: your own resume statements.

## 3. Interviewer read

Not built. No panelist profiles were provided.

## 4. Persona weights

| Persona | Weight | Why |
|---|---|---|
| Principal | High | Panel lead; likely asks about leadership, vision and family communication `[generic]`. |
| Fourth-grade peer | High | Will test planning with a team and your grasp of 4th-grade expectations. |
| Second peer | Medium | Likely probes collaboration and classroom practice. |
| Skeptic (from the team-lead gap) | Medium | Panels often probe a stated gap directly. |

## 5. Question bank

`[resume]` = your own sentence. `[generic]` = standard practice.

**Principal**

- **Q1. Tell us about a time you led without formal authority.** *(Behavioral)*
  Guidance: Use the 2024 curriculum move. Cover who you convinced, what you did first, and what you'd change.
  Provenance: `[resume]` "I led our grade level's move to a new reading curriculum in 2024."
- **Q2. How do you keep families informed, and what do you hope they take away?** *(Values)*
  Guidance: Describe the weekly email: contents, how you adjust it, and one family response.
  Provenance: `[resume]` "I write a weekly email to families."

**Fourth-grade peers**

- **Q3. You haven't taught fourth grade. What would you do in the first month?** *(Situational)*
  Guidance: Name what you'd review first (4th-grade standards, the current scope and sequence), whom you'd ask, and how your third-grade knowledge helps. Don't claim familiarity you lack.
  Provenance: `[resume]` "I've never taught fourth grade."
- **Q4. How do you plan with a grade-level team when people teach differently?** *(Collaboration)*
  Guidance: Use the 2024 curriculum move. Describe the real process and a disagreement you handled.
  Provenance: `[resume]` "I led our grade level's move to a new reading curriculum in 2024."
- **Q5. What does a strong reading block look like to you?** *(Technical)*
  Guidance: Draw on reading-club and third-grade practice. Name the components and how you check progress.
  Provenance: `[resume]` "I've run the after-school reading club for the last two years."

**Skeptic**

- **Q6. You've never been a team lead. Why hire you for a leadership role?** *(Pressure)*
  Guidance: Don't argue the title. Name what you've led and what you'd do to build the rest. Be honest about the gap.
  Provenance: `[resume]` "I've never been a team lead."

## 6. Values cheat sheet

Not built. Your materials don't mention the school's values, and I ran no research.

## 7. Reverse questions

1. "What does the fourth-grade team most want from a new member in the first semester?" *(Shows you plan to join the team.)*
2. "How does the team plan and share curriculum decisions?" *(Tests how collaborative the work is.)*
3. "What would success look like in this role at the end of the year?" *(Aligns expectations with the principal.)*

## 8. Before Thursday

- **Bring:** a copy of your PEL and your resume. Have your license number ready.
- **Don't bring or share** your Social Security number or other ID numbers in the interview process. Districts collect those through official hiring paperwork, not in interviews or by email.
- **Practice:** answer Q1–Q6 aloud, 2–3 minutes each.

## 9. Upgrade menu

- **Job description (paste it):** replaces the inferred requirements in section 1 with the real ones.
- **Panelists' roles:** enables the interviewer read and adjusts persona weights.
- **The 2024 curriculum name and your role in choosing it:** lets answers name specifics.
- **Focus areas from the recruiter or HR:** tells us which questions to weight.
- **Deeper research (optional):** would add the school's values, district priorities and 4th-grade standards. Say yes to run it.

---

**Offers (no pressure):**
- I can run a **drill**: I play a panelist, ask Q1–Q6 with follow-ups, and give feedback on each answer.
- I can save your answers as a **dossier** file to carry into future rounds.

**Questions that would reshape this pack:**
1. Can you paste the job description?
2. Do you know the panelists' roles, or what the recruiter said they'll focus on?
3. Which 4th-grade reading curriculum does the school use, and what was your part in the 2024 change?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: grace-fourth-grade-prep-pack.md -----
# Interview Prep Pack: Fourth Grade Teacher, Halvering Elementary (Orrinsford CSD)

**Format:** 45-minute panel. Principal Dolores Vantongeren plus two fourth-grade team members. Thursday.
**Build basis:** Your invite and resume only. No web research was run (L0), so anything not from those is marked `[generic]`.

## 1. Fit snapshot

| JD requirement (inferred from invite) | Your evidence (quoted from your resume) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| Valid Illinois PEL, elementary endorsement | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | High | None | Meets the stated requirement. |
| Elementary classroom teaching | "Six years teaching third grade at a public elementary school in Joliet." | High | Grade level | "I haven't taught fourth grade, but six years in third grade means I know what students bring into your grade." |
| Curriculum / reading instruction | "I led our grade level's move to a new reading curriculum in 2024." | Medium (scope of your role not stated) | Depth of detail | Describe the decisions you made, not the title. |
| Family communication | "I write a weekly email to families." | High | None | Concrete, ongoing practice. |
| Extra-curricular / reading support | "I've run the after-school reading club for the last two years." | High | None | Strong bridge to the reading focus of 4th grade `[generic]`. |
| Team leadership | "I've never been a team lead." | Known gap | Experience gap | "I haven't held the title. What I have done is lead a grade-level change in 2024, which is the closest thing I've done." |

## 2. Prohibited claims (do not say these)

- That you have taught fourth grade, or that you know its content from experience.
- That you were a team lead, or had formal authority over colleagues.
- That the 2024 curriculum change was your decision alone, or that it produced measured results, unless you can name the data.
- Any reading-club outcome numbers you cannot cite.

Basis: taken from your own resume statements.

## 3. Interviewer read

Not built. No profiles were provided, and no public research was run. Ask for the panelists' roles if you want this section.

## 4. Persona weights

| Persona | Weight | Why |
|---|---|---|
| Principal | High | Panel lead; asks about leadership, vision and family communication `[generic]`. |
| Fourth-grade peer | High | Will test whether you can plan with a team and what you know about 4th-grade expectations. |
| Second peer | Medium | Likely to probe collaboration and classroom practice. |
| Skeptic (inferred from the team-lead gap) | Medium | Panels often probe the gap directly. |

## 5. Question bank

**Provenance labels:** `[resume]` = your sentence; `[generic]` = standard practice, not from your materials.

### Principal (vision, leadership, families)

**Q1. Tell us about a time you led others without formal authority.** *(Behavioral)*
- Guidance: Use the 2024 reading-curriculum move. Walk through who you convinced, what you did first, and what you'd change.
- Provenance: `[resume]` "I led our grade level's move to a new reading curriculum in 2024."

**Q2. How do you keep families informed, and what do you hope they take away?** *(Values / communication)*
- Guidance: Describe the weekly email: what goes in it, how often you adjust it, and one example of a family response.
- Provenance: `[resume]` "I write a weekly email to families."

### Fourth-grade peers (content, collaboration)

**Q3. You haven't taught fourth grade. What would you do in the first month?** *(Situational / gap)*
- Guidance: Name what you'd review first (the 4th-grade standards and the current year's scope and sequence), who you'd ask, and how you'd use your third-grade knowledge. Do not claim familiarity you don't have.
- Provenance: `[resume]` "I've never taught fourth grade."

**Q4. How do you plan with a grade-level team when people teach differently?** *(Collaboration)*
- Guidance: Use the 2024 curriculum move as your example. Describe the actual process and any disagreement you handled.
- Provenance: `[resume]` "I led our grade level's move to a new reading curriculum in 2024."

**Q5. What does a strong reading block look like to you?** *(Technical)*
- Guidance: Use your reading-club and third-grade practice. Name the components you use and how you check progress.
- Provenance: `[resume]` "I've run the after-school reading club for the last two years."

### Skeptic (gap probes)

**Q6. You've never been a team lead. Why should we hire you for a leadership role?** *(Pressure)*
- Guidance: Don't argue the title. Name what you've led and what you'd do to build the rest. Be honest about the gap.
- Provenance: `[resume]` "I've never been a team lead."

## 6. Values cheat sheet

Not built. Your materials don't mention the school's published values, and no research was run. Ask the school for its values statement if you want this section.

## 7. Reverse questions

1. "What does the fourth-grade team most want from a new member in the first semester?" *(Why it lands: shows you plan to join the team, not just teach.)*
2. "How does the team plan and share curriculum decisions?" *(Why it lands: tests how collaborative the work is.)*
3. "What would success look like for this role at the end of the year?" *(Why it lands: aligns expectations with the principal.)*

## 8. Before Thursday (logistics)

- **Bring:** a copy of your Illinois PEL and your resume. Have your license number ready.
- **Do not bring or share** your Social Security number or other ID numbers during the interview process. Districts handle those through official hiring paperwork, not in an interview or by email.
- **Practice:** answer Q1–Q6 aloud in 2–3 minutes each.

## 9. Upgrade menu

Each item, if you add it, would improve this pack:

- **The job description** (paste it): would replace the inferred requirements in section 1 with the real ones.
- **Panelists' roles or titles** (if known): would enable the interviewer read and adjust persona weights.
- **The 2024 curriculum name and your role in choosing it**: would let the answers name specifics.
- **Any focus areas the recruiter or HR named**: would tell us which questions to weight.
- **A research pass (deep, optional)**: would add the school's values, the district's published priorities and 4th-grade standards. Takes more searches; say yes to run it.
