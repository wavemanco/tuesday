**Before the prep pack:** this invite has the hallmarks of a common job scam, so treat it as unverified until you've checked it. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview." It also says successful candidates get "a €1,850 cheque to buy a laptop and desk ... you deposit the cheque and send the balance on to the vendor." Legitimate employers don't charge candidates for equipment or registration, don't ask for passport photos or bank details before an offer, and don't have you send money from a cheque you've deposited. Don't pay anything, send ID, or deposit a cheque. To check the company, find Brennock Facilities Ltd on the Companies Registration Office register and on its own website, and call a number you find there, not one from this email. You can also ask for a verification through a job-underwriter service, using contact details you find yourself.

# Interview prep pack: Remote Administrative Assistant

**Built on:** the job-ad duties and your background as you described them. I had no full job description and ran no company research, so nothing about Brennock is verified. I've assumed the 30-minute video call with the office manager is a first-round screen with a hiring manager.

## 1. Fit snapshot

| Requirement (from ad) | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| Managing calendars | "ran the appointment book for four physios" | Strong | None | You scheduled for four people with changing demands. That's the same core skill. |
| Booking travel | Not in your material | Gap | Missing | "I haven't booked travel for a team yet. Here's how I'd learn it quickly, and how I'd handle the calendar side." |
| Word documents | "good with Word" | Partial (self-rated) | Evidence needed | Name one document you built or formatted and what it was for. |
| Excel | "okay with Excel" | Partial (self-rated) | Evidence needed | Be specific about what you actually do in it. |
| Supplier invoices | "chased unpaid invoices" | Partial | Transferable | "I chased unpaid invoices, so I know how payment status and follow-up work. Processing them in their system is what I'd need to learn." |

## 2. Prohibited claims

- Don't claim experience with travel-booking tools you haven't used.
- Don't describe yourself as advanced in Excel.
- Don't claim you managed calendars for anyone beyond the four physios unless that's true.

## 3. Persona weights

- **Hiring manager (primary, about 70%):** checks you can do the duties.
- **Skeptic (secondary, about 30%):** a clinic background for an office role invites doubt.

## 4. Question banks

### Hiring manager

| # | Question | Type | Provenance | Guidance |
|---|---|---|---|---|
| 1 | Tell me about your role at the physio clinic. | Background | Candidate-sourced: "ran the appointment book for four physios, chased unpaid invoices" | Lead with the appointment book, then invoices. Keep it to 60–90 seconds. |
| 2 | How would you manage a busy calendar for several people? | Role competence | Candidate-sourced: "ran the appointment book for four physios" | Describe how you handled clashes, changes and priorities. Give one concrete example. |
| 3 | Have you booked travel before? | Experience | Gap: no material from you. Answer slot: [your honest answer] | If no, say so plainly. Then bridge through your calendar work and say how you'd learn. |
| 4 | How comfortable are you with Excel? | Skill | Candidate-sourced: "okay with Excel" | Be specific about what you do. Don't inflate "okay." |
| 5 | Walk me through how you'd handle a supplier invoice. | Process | Candidate-sourced: "chased unpaid invoices". Gap: processing not shown | Describe the chasing you did, then say what you'd need to learn about their system. |
| 6 | Why are you moving from clinic reception to an admin role? | Motivation | Gap: no material from you. Answer slot: [your reason] | Give a real reason in two sentences. Don't criticise the clinic. |

### Skeptic

| # | Question | Type | Provenance | Guidance |
|---|---|---|---|---|
| 7 | Your experience is in a clinic, not an office. Why should I believe it transfers? | Challenge | Candidate-sourced: "two years as a receptionist at a physiotherapy clinic" | Acknowledge the difference, then name the shared skills: scheduling, documents, invoices. |
| 8 | How much of the appointment book was really you, and how much was the physios' own system? | Honesty probe | Candidate-sourced: "ran the appointment book for four physios" | Be exact about your role. This is the question most likely to catch an inflated answer. |
| 9 | You're only "okay" with Excel. How would you cope with a complex spreadsheet on day one? | Pressure | Candidate-sourced: "okay with Excel" | Hold your position. Say what you'd do: ask, practise, use training. |

**Highest-return prep:** question 8. Rehearse one honest answer that names exactly what you did.

## 5. Reverse questions

- "What does a typical week look like, and who would I be supporting?" *Why it lands:* shows you're thinking about the job itself.
- "Which tools do you use for calendars, travel and invoices?" *Why it lands:* the answer tells you how the job really works, and a vague answer is information too.
- "What would success look like after three months?" *Why it lands:* signals you plan to deliver.

## 6. Upgrade menu

- **Full job-ad text:** a fuller fit snapshot and more duty-specific questions.
- **Any travel-booking or invoice software you've used, even briefly:** moves those rows from gap or partial to strong.
- **Interviewer name, if the company gives one that you can check:** an interviewer read.
- **Research pass on Brennock (up to 6 searches, 2 page fetches):** company context. Verify the company through official registers, not through this email.

---

**Offers (neither pushed):**
- **Drill:** I can play the hiring manager and ask these questions with follow-ups, then give feedback on each answer.
- **Dossier:** I can save this pack's notes to a `tuesday-dossier.md` file for later updates.

**Questions:**
1. Is the 30-minute call with the office manager the first round, and have they said what they want to focus on?
2. Have you used any travel-booking or invoice software, even briefly?
3. Do you want me to run the research pass on Brennock described above?

The pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-5-rooms-case-12-denied-04a67894/756db5ad-7958-4c72-ab74-0b6b98ec6a71/scratchpad/mock-interview-aoife-brennock.md`.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: mock-interview-aoife-brennock.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd (candidate: Aoife)

**Built on:** the job-ad duties and your background as you described them. No full job description, no company research (L0: provided material only). The round is assumed to be a 30-minute video call with the office manager, treated as a hiring-manager screen. Nothing about Brennock itself has been verified.

## 1. Fit snapshot

| Requirement (from ad) | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| Managing calendars | "ran the appointment book for four physios" | Strong | None | You scheduled for four people with changing demands; that is the same core skill. |
| Booking travel | Not in your material | Gap | Missing | "I haven't booked travel for a team yet; here is how I'd learn it quickly and how I'd handle the calendar side." |
| Word documents | "good with Word" | Partial (self-rated) | Evidence needed | Name one document you built or formatted and what it was for. |
| Excel | "okay with Excel" | Partial (self-rated) | Evidence needed | Be specific about what you do in it. Do not upgrade "okay" in the room. |
| Supplier invoices | "chased unpaid invoices" | Partial | Transferable | "I chased unpaid invoices, so I know how payment status and follow-up work. Processing them in their system is what I'd need to learn." |

## 2. Prohibited claims (built locally)

- Do not claim experience with travel-booking tools you have not used.
- Do not describe yourself as advanced in Excel.
- Do not claim you managed calendars for executives or teams beyond the four physios, unless that is true.

## 3. Interviewer read

Skipped: no interviewer profile was provided.

## 4. Persona weights

- **Hiring manager (primary, about 70%):** first-round screen; wants to know you can do the duties.
- **Skeptic (secondary, about 30%):** a clinic background for an office role invites doubt.

## 5. Question banks

### Hiring manager

| # | Question | Type | Provenance | Guidance |
|---|---|---|---|---|
| 1 | Tell me about your role at the physio clinic. | Background | Candidate-sourced: "ran the appointment book for four physios, chased unpaid invoices" | Lead with the appointment book, then invoices. Keep it to 60–90 seconds. |
| 2 | How would you manage a busy calendar for several people? | Role competence | Candidate-sourced: "ran the appointment book for four physios" | Describe how you handled clashes, changes and priorities. Give one concrete example. |
| 3 | Have you booked travel before? | Experience | Gap: no candidate material. Answer slot: [your honest answer] | If no, say so plainly. Then bridge through your calendar work and say how you would learn. |
| 4 | How comfortable are you with Excel? | Skill | Candidate-sourced: "okay with Excel" | Be specific about what you do. Do not inflate "okay." |
| 5 | Walk me through how you would handle a supplier invoice. | Process | Candidate-sourced: "chased unpaid invoices". Gap: processing not shown | Describe the chasing you did. Say what you would need to learn about their system. |
| 6 | Why are you moving from clinic reception to an admin role? | Motivation | Gap: no candidate material. Answer slot: [your reason] | Give a real reason in two sentences. Avoid criticising the clinic. |

### Skeptic

| # | Question | Type | Provenance | Guidance |
|---|---|---|---|---|
| 7 | Your experience is in a clinic, not an office. Why should I believe it transfers? | Challenge | Candidate-sourced: "two years as a receptionist at a physiotherapy clinic" | Acknowledge the difference. Name the shared skills: scheduling, documents, invoices. |
| 8 | How much of the appointment book was really you, and how much was the physios' own system? | Honesty probe | Candidate-sourced: "ran the appointment book for four physios" | Be exact about your role. Do not overstate it. This is the question most likely to catch an inflated answer. |
| 9 | You are only "okay" with Excel. How would you cope with a complex spreadsheet on day one? | Pressure | Candidate-sourced: "okay with Excel" | Hold your position. Say what you would do: ask, practise, use training. |

**Highest-return prep:** question 8. Rehearse one honest answer that names exactly what you did.

## 6. Reverse questions

- "What does a typical week look like, and who would I be supporting?" *Why it lands:* shows you are thinking about the job itself.
- "Which tools do you use for calendars, travel and invoices?" *Why it lands:* the answer tells you how the job really works. A vague answer is also information.
- "What would success look like after three months?" *Why it lands:* signals you plan to deliver.

## 7. Values cheat sheet

Skipped: no company values were detected (no research run).

## 8. Delivery coaching

Skipped: no working-style assessment was provided.

## 9. Upgrade menu

- **Full job-ad text:** gives a fuller fit snapshot and more duty-specific questions.
- **Any travel-booking or invoice software you have used, even briefly:** upgrades those rows from gap or partial to strong.
- **Interviewer name, if the company gives one and it can be checked:** unlocks an interviewer read.
- **Research pass on Brennock (L1: up to 6 searches, 2 page fetches):** adds company context. Verify the company through official registers, not through this email.
