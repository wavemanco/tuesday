# Interview pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Format: 45-minute panel. Principal Dolores Vantongeren, plus two members of the fourth-grade team (names not yet known). Thursday.
Built from: the invitation and your resume as stated in our conversation. No job posting, no research run.

## How to use + type key

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Types: **VAL** behavioral/values · **EXP** your experience, closely examined · **JD** the listed job · **CO** company knowledge (not included; no research run) · **CASE** live problem.
- Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | Met by your material. Say the license and its expiry in those words. Nothing to add. |
| F2 | "Fourth Grade Teacher position" (invitation) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | medium | [grounded] | capability | You stated the absence, so the words are yours: "I haven't taught fourth grade." Then the third-grade work, at its own scope. Your material does not show any fourth-grade planning or assessment. |
| F3 | Reading instruction for grade 4 (role-family, not quoted from a source) | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your CV) | medium | [generic] | presentation | Reword only what these sentences say. Your material does not show outcomes for either. Answer slot: if you measured anything about student reading, say what and how it was counted; if you did not, say so and say what you would measure first. |
| F4 | Family communication (role-family, not quoted from a source) | "I write a weekly email to families" (your CV) | medium | [generic] | none | Lead with the sentence as written. Describe what the email contains. Do not claim response rates or outcomes unless you have them. |

Team lead is not a requirement the invitation states, so it has no row. It is covered in the prohibited list and question A3.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I've been a team lead" | Negative you stated: "I've never been a team lead" | "I haven't been a team lead." Then the grade-level move, at its own scope. |
| "I've taught fourth grade" | Negative you stated: "I've never taught fourth grade" | "I haven't taught fourth grade." Then the third-grade years. |
| "I led the reading curriculum across the school" | Inflated form of "I led our grade level's move to a new reading curriculum in 2024" | Your sentence as written. The material says grade level, not school. |
| "I started the reading club" | Inflated form of "I've run the after-school reading club for the last two years" | "I've run it for two years." |

## Persona weights

| Persona | Who | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|---|
| Skeptic | Principal | "You haven't taught fourth grade." | high | Gap F2 is the obvious probe | Rehearse A1 until it is plain and unhurried |
| Peer Evaluator | Team members | "Where would you need us?" | high | A panel with fourth-grade teachers prices what the hire adds to their load | Ask for specifics; offer what you bring |
| Case/Strategist | Principal | A live fourth-grade reading problem | medium | Principals test planning under a problem | Clarify, then structure, then act |
| Data-Driven Prober | Team members | "What did the reading club show?" | medium | Team members read the resume closely | Know what you can and cannot say about how results were counted |
| Conversational | Opener | "Walk us through your path." | medium | Openers are scored too | Keep a 90-second arc ready |
| Values/Behavioral | Any | Scenario about a published value | low | No values were supplied or researched | Covered only by the generic questions here |

## Question banks

### A. Skeptic (principal), highest weight

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. Why should we hire you for this class?" | JD | [grounded] "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | **Highest-ROI prep.** Say "I haven't taught fourth grade," then your six years of third grade in Joliet. Hold through two follow-ups by returning to what you have done. Answer slot: name one thing from third grade you expect to carry over, and one thing you would learn first. | F2 is the gap this panel will most likely test. Asked by the principal, so it is the Skeptic's question. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] stem | Name the honest weak spot: fourth-grade content and pacing, which you have not taught. Then your ramp plan: what you would read, observe, and ask for first. | Skeptic stem; the answer is a plan, not a past claim. |
| A3 | "Tell us about a time you led a team." | VAL | [grounded] "I've never been a team lead" (your message); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Begin with the honest line: "I haven't been a team lead." Then the grade-level move, in your sentence. Answer slot: describe what you did on that move, in your own words. | Team lead is not in the invitation, but the prohibited list names it. The open prompt is a persona stem. |
| A4 | "Your resume says you led the grade-level reading move. What changed for students?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: if you measured student results, say what and how it was counted; if you did not, say so plainly and say what you would measure. Never describe a result you did not track. | F3. The question presupposes an outcome your material does not carry, so the honest branch is required. |

### B. Peer Evaluator (team members), highest weight among team

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We plan together as a fourth-grade team. What would you need from us in your first month?" | JD | [generic] stem | Name two concrete asks, such as planning time or shared reading materials. Then one thing you bring, using your curriculum work: "I led our grade level's move to a new reading curriculum in 2024." | Peer seam question. Reciprocity: what you bring as well as what you need. |
| B2 | "When your grade-level team disagreed about a curriculum decision, how did you handle it?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: if there was disagreement, say how it was settled and what part was yours. If there was no disagreement, say so plainly. | Peer probe into disagreement style. The premise of disagreement is not in your material, so the second branch must be available. |
| B3 | "Walk us through a weekly family email. What's in it?" | EXP | [grounded] "I write a weekly email to families" (your CV) | Describe the email's purpose and its typical contents, in your words. Do not claim replies or outcomes. | F4. A premised question on a sentence you stated. |
| B4 | "What did the reading club show about students' progress?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Answer slot: if you tracked anything, say what and how it was counted; if you did not track it, say so and say what you would track. | F3. Data-prober question on a club whose results your material does not show. |

### C. Case/Strategist (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader is reading two levels below peers by October. What is your first week?" | CASE | [generic] | Clarify first: which assessment, what the current reading program is. Then diagnose, group, adjust instruction, and contact the family. Think aloud. | Core fourth-grade reading problem. Needs no claim about your past. |
| C2 | "A parent says their child's reading dropped after the new curriculum. What do you say?" | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Acknowledge the concern, say how you would check the data, and say what you would do if the curriculum is the cause. Do not claim the change had no effect unless you know it. | Ties a live problem to your curriculum work without claiming results. |

### D. Conversational (opener)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk us through your path to teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've run the after-school reading club for the last two years" (your CV) | A 90-second arc: Joliet, six years of third grade, the reading curriculum move, the reading club, and why fourth grade now. | Openers are scored. Keep it to what you have done. |

## Reverse questions

1. "What does a strong first year look like for a new fourth-grade teacher here?" Why it lands: it asks them to define success in their own terms.
2. "How does the fourth-grade team plan reading instruction together?" Why it lands: it shows you want to work with the team.
3. "What has the fourth-grade team changed recently, and what is still being worked on?" Why it lands: it shows you have thought about what is current.
4. Peer reciprocity, for the team members: "What could a new person do in their first month that would genuinely help your team?" Why it lands: it turns the seam into a shared problem.
5. "What do you most want the person in this role to have accomplished by December?" Why it lands: it asks the principal to name the bar.

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| Valid Illinois PEL with elementary endorsement | none | Met by your material. The panel may verify it. |
| Fourth Grade Teacher position | A1, A2, C1 | Gap F2 |
| Reading instruction for grade 4 | A4, B4, C1, C2 | Gap F3 |
| Working with a grade-level team | B1, B2 | |
| Family communication | B3 | |

## Sources

- Provided: the invitation and your resume, as stated in our conversation.
- Research: none run (tier L0). School values, interview format, and recent context are not established. There is no values cheat sheet and no grounding brief.

Research tier: L0. No searches or fetches were run.

| Target | Status | What it would have moved |
|---|---|---|
| Halvering or Orrinsford values | unavailable | Values cheat sheet |
| Interview format for this role | unavailable | Loop structure and persona weights |
| Recent school or district news | unavailable | Grounding brief |
| Principal's public footprint | unavailable | Interviewer read |
| Representative job posting | unavailable | Requirements marked [inferred] |

## Upgrade menu

- The job posting text → turns F2 and F3 from role-family prose into quoted requirements, and adds JD-tagged questions.
- The names of the two team members → personas per member and more specific reverse questions.
- Any focus areas or a demo lesson from HR → a section for the graded piece.
- Research on the district's values and interview format → values cheat sheet and loop structure.
- Prep time before Thursday → a prioritized schedule.
