# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Round:** 45-minute panel, Thursday 26 November 2026
**Panel:** Principal Dolores Vantongeren (likely your future supervisor), plus two fourth-grade team members
**Built on:** your message and CV lines as provided. No job description supplied. No research run (see Sources).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **Experience** (what you did), **Situational** (what you would do), **Role knowledge** (what you know about the work), **Collaboration** (how you work with others), **Motivation** (why this job).
- Guidance is scaffolding, not a script. Speak it in your own words, in 90–120 seconds.
- Personal details: your Social Security number is not needed for this prep, and I have not used or repeated it. Do not share it, or your IEIN, in interview materials unless a formal application step specifically requires it.

## Prep triage (about two days)

1. **Tuesday:** Rehearse **B2** aloud until you can answer in under two minutes. It is the most likely hard question.
2. **Tuesday:** Walk through **A1** (the 2024 curriculum change) as a story: what was the old setup, what did you do, what would you change.
3. **Wednesday:** Practice **A2**, **B1** and **C1**, then say the reverse questions aloud.
4. **Thursday morning:** One short run-through of B2 and C1. Stop there.

Everything else is insurance.

## The fit snapshot

Requirements come from the invite and from typical elementary-teacher panels. Your evidence is quoted from your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | high | [grounded] | none | No gap. Have your license status ready to state. Do not state the license number in the room. |
| F2 | Fourth-grade teaching, implied by a "fourth-grade team" panel — invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [grounded] | transferability | Your material says third grade, not fourth. Bridge: "For six years I taught third grade." Answer slot: name one thing from third grade that carries into fourth, or say you are not yet sure what carries. |
| F3 | Fourth-grade teaching experience — invite implies it | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap that cannot be closed by wording, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn it, as a plan, never as a past. |
| F4 | Team leadership on a grade-level team — generic for a team-based panel | "I've never been a team lead" — your message | none | [grounded] | capability | Words: "I haven't been a team lead." Then the closest real example: "I led our grade level's move to a new reading curriculum in 2024" — your CV. Do not stretch it into team-lead experience. |
| F5 | Leading a curriculum or practice change — generic | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | presentation | Strong evidence of leading a change. Be ready to say what you decided and what the team decided. |
| F6 | Reading instruction and intervention — generic | "I've run the after-school reading club for the last two years" — your CV | medium | [inferred] | none | Strong evidence. Answer slot: how did you group students in the club, and how do you know the grouping worked? |
| F7 | Family communication — generic | "I write a weekly email to families" — your CV | medium | [inferred] | none | Strong evidence. Answer slot: what does a typical email cover, and how do you handle a parent's concern? |

**Gap type key:** none; transferability (your evidence is adjacent); presentation (evidence exists but needs framing); capability (not yet held); discovery (the material does not show it); hard_gate (a requirement you cannot meet).

## Prohibited claims

Things this pack will not coach you to say, and the honest form of each.

| Claim | Why it is blocked | Honest form |
|---|---|---|
| Any fourth-grade teaching experience | Not in your material; you said you have not taught it | "I've taught third grade for six years, and I haven't taught fourth." |
| Any team-lead experience | You said you have not been one | "I haven't been a team lead. I have led a grade-level change." |
| Results from the 2024 curriculum change (scores, growth) | No data was provided | Describe what you did and what you saw, in plain terms. "I can't give you a score comparison, but here is what I noticed." |
| Results from the reading club (student gains) | No data was provided | Describe what the club did and how you tracked it. |

## Personas

| Persona | How it shows up | Likelihood (reasoning) | Counter-strategy |
|---|---|---|---|
| Evaluator (Principal) | Structured questions on experience and fit, asks what you would do | High. Principals lead panels and ask about the grade-level gap | Answer with a concrete example, then a plan |
| Collaborator (fourth-grade teammate) | Asks what you know about fourth-grade reading and how you would work with them | High. They will test the grade-level transition | Name what carries over, admit what does not, ask what they see |
| Skeptic (teammate pressing the gap) | Pushes on team-lead and fourth-grade gaps | Medium. Likely from one panel member | Acknowledge plainly, then bridge with one real example |

Weights are priors from round type, since no interviewer profile was provided. They are not evidence about these people.

## Question banks

### Evaluator bank (weight 0.4)

| ID | Type | Provenance | Question | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | Experience | [grounded]: "I led our grade level's move to a new reading curriculum in 2024" — your CV | Tell us about the reading curriculum change you led in 2024. | Start with the old setup, then the steps you took, who was involved, and what you decided yourself versus what the team decided. End with one thing you would change. Do not claim results without data. | Your strongest leadership-adjacent evidence. The panel will test whether "led" means decided or organized. |
| A2 | Experience | [grounded]: "I've run the after-school reading club for the last two years" — your CV | How do you group students who read at very different levels? | Describe the grouping you used in the club and why. If you did not group by level, say what you did and what you would do in a classroom. Answer slot: the club's grouping method is not in your material. | Connects reading club work to a fourth-grade reading block. |
| A3 | Situational | [generic]: no candidate sentence carries this. Selection scaffold: "Pick a time you started with a group you didn't know well." Honest branch: "I haven't started with a fourth-grade team, so here is how I would learn it." | What would your first month with a fourth-grade team look like? | Learn the current unit plans, observe reading blocks, ask the team what they would want you to know, then propose one change after you understand the work. | Targets the fourth-grade gap with a plan, not a past. |
| A4 | Motivation | [generic]: no candidate sentence carries this. Answer slot: what drew you to fourth grade? | Why do you want to move from third to fourth grade? | Say what you want to learn at fourth grade, and why your third-grade work prepares you for it. Your own words; the material does not say what drew you. | Motivation questions are common; a clear answer stops the panel from assuming the move is accidental. |

### Collaborator bank (weight 0.35)

| ID | Type | Provenance | Question | Guidance | Rationale |
|---|---|---|---|---|---|
| B2 | Collaboration | [grounded]: "I've never taught fourth grade and I've never been a team lead" — your message | You haven't taught fourth grade, and you haven't led a team. Why should we hire you? | **Highest-ROI prep.** Say plainly: "I haven't taught fourth grade, and I haven't been a team lead." Then two bridges: six years of third-grade work, and leading the 2024 reading curriculum change. Then what you would do in your first month. Keep it under two minutes. | The most likely objection. Naming it first makes you sound steady, not defensive. |
| B1 | Role knowledge | [grounded]: "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your message | What is the biggest difference between third- and fourth-grade reading for students? | Describe what you have seen in third grade: students moving from learning to read toward reading to learn. Label this as what you have observed and what you expect, not as fourth-grade experience. Ask the team what they see. | Fourth-grade teammates will test whether you understand the shift. Honest observation beats a confident guess. |
| B3 | Collaboration | [grounded]: "I led our grade level's move to a new reading curriculum in 2024" — your CV | How have you worked with colleagues on a shared decision? | Describe how you brought colleagues into the curriculum change: meetings, trials, who disagreed and how it was settled. Say who made the final call. | Shows how you work with peers, which matters more on a team panel. |

### Skeptic bank (weight 0.25)

| ID | Type | Provenance | Question | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | Collaboration | [grounded]: "I've never been a team lead" — your message | You've never been a team lead. What would you do if your team disagreed with you? | "I haven't been a team lead. In the curriculum change, here is how I handled disagreement." Then the example, then how you would handle it on a team. Answer slot: if there was no real disagreement in your past, say so and give the plan. | Pressure on the team-lead gap. Use a real example or say plainly that you have not had one. |
| C2 | Experience | [grounded]: "I write a weekly email to families" — your CV | How do you handle a parent who is upset about their child's progress? | Describe what your weekly emails cover and how you respond to a concern: listen first, then a meeting or call. Answer slot: if you have a specific example, use it; if not, describe your approach. | Tests communication with families, a regular part of the job. |

## Reverse questions

Ask two or three, depending on time.

| # | Question | Why it lands |
|---|---|---|
| R1 | What would success look like for the fourth-grade team in the first year? | Shows you want the team's goals, not just the job. |
| R2 | How does the fourth-grade team plan reading units together? | Tests the collaboration model before you join it. |
| R3 | What support does a new teacher to the grade get in the first semester? | Shows you plan to learn, and asks about the support you will need. |
| R4 | What is the current reading curriculum, and how has the team found it? | Shows you care about the instructional materials and invites a candid answer. |
| R5 | What are the biggest priorities for the school this year? | Asks the principal what she is focused on, and gives you a chance to connect your answers to it. |
| R6 | (To a team member) What do you enjoy most about teaching fourth grade here? | Reciprocity with the teammates. Ask it only if you have time. |

## Sources

- **Provided documents:** your message, which includes the invite text and your CV lines.
- **Research tier:** L0, provided documents only. You did not consent to research, so no search or fetch was run.
- **Target accounting:**
  - Company research: skipped.
  - Interviewer public footprint (Principal Dolores Vantongeren): skipped.
  - Job description: not supplied.
  - Values or strategy brief: skipped.
  - Round-type priors: used, labeled as priors.

## Upgrade menu

- The full job posting or description → the `[generic]` requirements become `[grounded]`, and the fit snapshot gets exact requirement quotes.
- The panel's focus areas, or any demo lesson or task → the question banks get weighted to that task.
- Principal Dolores Vantongeren's public profile → personalized persona weights and a tailored reverse question.
- Deep research on the school and district (L2) → a grounding brief on current reading programs and district strategy.
- Your notes on what you actually did in the 2024 curriculum change, in your words → sharper A1 and B3 answers.
