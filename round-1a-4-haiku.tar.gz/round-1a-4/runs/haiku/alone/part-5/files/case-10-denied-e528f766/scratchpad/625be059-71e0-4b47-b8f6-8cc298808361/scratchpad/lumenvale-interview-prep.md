# Interview prep: Customer Support Specialist (remote), Lumenvale Software

**Built on:** your summary of the job ad, your CV summary, and the invite text. No full JD, no company research (L0, provided material only).
**Assumed round:** a text-chat interview on Telegram with the support team lead.

## Fit snapshot

| Requirement | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| 2+ years in customer support | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | High | None (title and sector differ) | "My three years were customer service at an energy supplier, mostly calls and emails at high volume." |
| Zendesk or a similar ticketing tool | "I use Freshdesk every day" | Medium-high | Tool-specific | "I use Freshdesk daily. I haven't used Zendesk itself, but I'd expect the core ticket workflow to transfer quickly." |
| Clear written communication | "answering around 60 calls and emails a day" | Low-medium | Evidence-thin | Answer slot: a written reply you are proud of (see Q5). |
| Confidence handling escalations | None quoted. Adjacent: "I trained four new starters on our refunds process last year" | Low | The material says nothing about escalations | Answer slot (see Q3). |
| Software-company background | "I've never worked for a software company" | High | Structural | "I haven't worked in software, so I'd expect to learn your product and tools fast." |

## Prohibited claims (built locally)

These are claims a candidate reaches for under pressure. Do not claim them in the interview:

- Hands-on Zendesk experience, or any Zendesk admin or macro work.
- Software or SaaS support experience.
- Owning escalations, unless you personally did so. Say what you actually did.
- Exact figures you can't back up, such as CSAT scores or ticket counts beyond "around 60 a day".
- Credit for the refunds process itself, unless you designed or wrote it. Training others on it is what you can claim.

## Question banks

Persona weight: **support team lead**, operational and practical. High weight on experience and escalation handling. Medium on motivation.

**Q1 · Experience** — "Tell me about your current role."
*Provenance: candidate-sourced: "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day."*
Guidance: Give a 60-second version. Cover the volume, the channels, and one thing you owned. Rehearse only what you did.

**Q2 · Skill-fit** — "You use Freshdesk. How would you get up to speed on our tool?"
*Provenance: candidate-sourced: "I use Freshdesk every day."*
Guidance: Name what transfers (queues, tagging, reply templates). Say plainly you haven't used Zendesk. Give one concrete learning step, such as working through the help docs or shadowing an experienced agent.

**Q3 · Behavioural (answer slot)** — "Tell me about a case you escalated. What did you check first, and what happened next?"
*Provenance: answer slot. Your material does not show escalations. If you have an example, give it as situation, action, result. If you don't, say so, and describe how you decide what to escalate under the refunds process you trained others on.*

**Q4 · Situational** — "A customer is angry that a refund is late. Walk me through your reply."
*Provenance: answer slot, with the adjacent sentence "I trained four new starters on our refunds process last year."*
Guidance: Acknowledge the frustration. State what you can do now. Give a specific time. Escalate if policy requires it, and say so.

**Q5 · Written communication (answer slot)** — "Draft a reply to this customer in the chat."
*Provenance: answer slot. Prepare one short written reply in advance, in your own words.*
Guidance: Keep it short. Name the next step and when it happens. Avoid jargon.

**Q6 · Motivation** — "Why support in software rather than energy?"
*Provenance: candidate-sourced: "I've never worked for a software company."*
Guidance: Give your honest reason. Don't invent enthusiasm for their product.

**Q7 · Skeptic** — "You haven't worked in software. Why would you cope?"
*Provenance: candidate-sourced: "I've never worked for a software company."*
Guidance: Name the gap in one sentence. Bridge with your volume and your training experience. Don't argue the point.

## Reverse questions

- "What does a typical week look like for this role, in channels and volume?" *Why it lands: shows you're weighing workload realistically.*
- "Once a case is escalated, who owns it?" *Why it lands: shows you understand escalation ownership.*
- "Which tools would I use on day one?" *Why it lands: connects your Freshdesk experience to their stack.*

## Values cheat sheet

Omitted. No company values were detected, because no research was run.

## Upgrade menu

- **Full job description:** tightens the fit snapshot and may add requirements.
- **An escalation example:** answers Q3 properly and turns an answer slot into a story.
- **Company research (L2, offered once):** adds company values, interview format, and recent strategy. Up to 6 further searches and 2 page fetches.
- **Round details from Marcus:** whether the chat has a time limit or a written task.
- **Optional dossier from job-underwriter:** adds verified evidence and risk notes, but is not required.
