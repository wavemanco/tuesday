# Recruiter Screen Prep: Operations Coordinator, Quillmoor Diagnostics

**Call:** Thursday 2pm, 30 min, by phone to the mobile on your application, with Hannah Lowther (Talent Partner)
**Built from:** the advert and your background as you described them. No company research run (L0).

## 1. Fit snapshot

| JD requirement | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| 2+ years in operations or logistics coordination | "4 years as a logistics coordinator at a building-supplies wholesaler" | High | None | Lead with this. |
| Coordinate production schedules between planning, warehouse and QA | "I schedule deliveries for our three depots" | Medium | Experience transfer | "My scheduling has been delivery-side across three depots, not production runs. I haven't scheduled production or worked alongside QA, so I'd be learning those hand-offs." |
| Track supplier deliveries; chase late orders | "chase suppliers when orders slip" | High | None | Give one concrete example. |
| Keep stock records accurate | "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year" | High | None | Say "I rebuilt" and "fell by about a third over a year." Do not credit the whole drop to the spreadsheet alone. |
| Weekly on-time dispatch reporting | Not in your material | None | Missing | "I haven't produced an on-time dispatch report. What I've tracked is [your actual tracking, if any]." Fill from your real practice only. |
| Confident with Excel | Rebuilt the stock-count spreadsheet | Medium | Level not stated | Confirm your actual Excel level (formulas, pivots, lookups) before the call. |
| SAP or similar ERP (plus) | "Never used SAP — we run our own in-house stock system" | None for SAP; partial for ERP-style | Missing, nice-to-have | "I haven't used SAP. I work daily in our in-house stock system, which covers [what it does]." |

## 2. Prohibited claims (do not say these)

- That you have used SAP or any ERP beyond your in-house stock system.
- That you have scheduled production runs, or worked with QA or planning in a manufacturing setting.
- That you have produced weekly on-time dispatch reporting, unless you have.
- That you alone reduced discrepancies by a third.
- Anything about your current salary or what you earn now.
- That you are willing to relocate to Reading.

## 3. Likely objections and how to answer

**The most likely objection: "You're asking £42k against a £38–44k range. Why this figure, and is it firm?"**
Rehearse this one hardest. Answer in your own words:
- "I'm hoping for £42,000. That's based on the role's scope and the range you've listed."
- If pushed on flexibility: "That's my working figure. I'd like to hear the full package before I say more." Do not go below £38k on the spot.

**Notice period:** Say the number once, plainly. Do not explain it unless asked.

**"What's prompting the move?"** Say what happened, then stop:
"Our Bristol office is closing next year. The only offer I've had is relocating to Reading, and I'm not looking to move. I'd like to stay in Bristol."
Do not add criticism of the employer.

**Hybrid:** "Two days at Avonmouth works for me. I live in north Bristol. I'd want to keep it to two, with three as my limit."
If she asks about commute time, answer from your actual journey, not an estimate.

**"Would you consider Reading, or more days in the office?"**
"I'd prefer to stay in Bristol with two days at Avonmouth. Three is the most I'd manage." Stop there.

**"Tell me about yourself" (opener):**
"I'm a logistics coordinator with four years at a building-supplies wholesaler. I schedule deliveries across three depots and chase suppliers when orders slip. I rebuilt our stock-count spreadsheet, and discrepancies fell by about a third over the year. I'm looking for coordination work in a manufacturing setting, and Quillmoor's role is closest to what I do now."

**SAP gap:** "I haven't used SAP. I work in our in-house stock system every day, and I'm keen to learn an ERP if the role needs one."

## 4. Reverse questions (ask at the end)

1. "What does a typical week look like for this role, across planning, the warehouse and QA?"
2. "How is on-time dispatch measured today, and who reviews the weekly report?"
3. "Which ERP does the team use, and how much of the role is in it?"
4. "How does the two-day Avonmouth pattern work in practice: which days, and is it fixed?"
5. "What are the next steps after this call, and roughly when?"

## 5. Upgrade menu

- **Notice period:** unlocks the notice-period answer (not in the material).
- **Excel level:** unlocks a stronger Excel line in the fit snapshot.
- **Real on-time or dispatch tracking:** unlocks a bridge for the reporting gap.
- **Company research (L1 or L2):** unlocks specifics on Quillmoor's sites and team for the reverse questions.
- **Tuesday dossier from job-underwriter (if you have one):** adds an evidence check and a stronger objection rehearsal.
