# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Role: Fourth Grade Teacher. Company: Orrinsford Community School District (Halvering Elementary School). Format: 45-minute panel interview with Principal Dolores Vantongeren and two members of the fourth-grade team. Date: "Thursday", not yet confirmed (see the upgrade menu).

Built without a job description. Requirements come from the invite, the district's published pages, and your own message.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only the parts your material supports.

| Tag | Meaning |
|---|---|
| VAL | Behavior that shows one of the district's published beliefs |
| EXP | What you actually did in your past roles, and how much of it was yours |
| JD | The stated requirements of the role |
| CASE | A live classroom or team problem, reasoned aloud |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite, HR) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | Met. Say it plainly: "I hold an Illinois Professional Educator License with an elementary endorsement, active through June 30, 2029." No slot. |
| F2 | "Fourth Grade Teacher position" (invite, HR) | "Six years teaching third grade at a public elementary school in Joliet." (your CV) — "I've never taught fourth grade" (your message) | low | [grounded] | capability | You stated the absence, so the words are yours: "I haven't taught fourth grade." Then the adjacent years, in your words: "Six years teaching third grade at a public elementary school in Joliet." The plan for fourth grade is a plan, not a past. Answer slot: say how you would learn the fourth-grade year (its standards and the team's sequence) and what you would do first. |
| F3 | "Panels ask about reading instruction" (district hiring page, fetched) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) — "I've run the after-school reading club for the last two years." (your CV) | medium | [grounded] | none | Both quotes reach reading instruction in role terms, so no bridge is needed. Lead with the 2024 move in those words. Expect a probe on which decisions were yours; see A3. |
| F4 | "how you work with families" (district hiring page, fetched) | "I write a weekly email to families." (your CV) | medium | [grounded] | transferability | Your material carries written contact, not conversation. For the district's belief that each teacher speaks with every family each term, the bridge is the quote at its own scope: "I write a weekly email to families." Answer slot: if you have spoken with each family in a term, say how; if not, say so and say what you would do. |
| F5 | "Leading or contributing to a grade-level team" ([generic], role-family prose; no posting text supplied) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) — "I've never been a team lead." (your message) | low | [grounded] | capability | You stated the absence, so: "I haven't been a team lead." Then the 2024 move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Do not describe it as leading the team. Answer slot: which decisions were yours, and which the grade level made together. |

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated (F2) | "I haven't taught fourth grade." No slot. |
| Has been a team lead | Negative you stated (F5) | "I haven't been a team lead." No slot. |
| Led the grade-level team | Inflated form of the F3/F5 CV line | "I led our grade level's move to a new reading curriculum in 2024." The limit is this pack's observation, not a claim for you: your material says the move, not the team. |
| Reading-club results or measured student growth | Inflated form of the club line (F3) | "I've run the after-school reading club for the last two years." Your material gives no outcomes, so none are claimed. |
| Talks with every family each term | Inflated form of the weekly-email line (F4) | "I write a weekly email to families." |

## Question banks

Weights, from the panel's composition: the principal leads and runs the scored questions (Skeptic and Case, about 60 percent); the two team members run the peer and values questions (about 40 percent). The principal's public record (see Reading the interviewer) makes reading probes likely.

### Bank A — Skeptic (principal, highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What would you do in your first month?" | JD | [grounded] "I've never taught fourth grade" (your message) | The highest-ROI rehearsal in this pack. Hold: "I haven't taught fourth grade." Then a plan in your own words: what you would read first (the fourth-grade standards and the team's sequence) and who you would ask. Do not describe any fourth-grade experience. | F2 is the requirement the role most depends on, and the question presses on it directly. |
| A2 | "Six years in third grade: what carries over to fourth?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Story-mapped on F2: six years, third grade, Joliet, in those words. Name one skill you used in third grade that a fourth-grade classroom also needs, only if you can say how you used it. Answer slot: if you cannot name one, say so and describe the nearest thing you did. | F2's adjacent years are the honest bridge; this question asks for the link, and the link must come from your own experience. |
| A3 | "Tell me about the 2024 reading move. What did you decide, and what did the team decide?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Story-mapped on F3: the move, 2024, grade level. Answer slot: if any step was yours to set, say which and how you decided; if the grade level decided together, say that and describe your part. Never claim the whole decision. | F3 is the strongest match to the reading priority, and it is where the principal's probe will land. |
| A4 | "Team leadership isn't on your résumé. Why would a team want you to lead it?" | EXP | [grounded] "I've never been a team lead." (your message) | Hold the true position: "I haven't been a team lead." Then the 2024 move at its own scope. Hold through two follow-ups by returning to the move. Concede plainly where you have not yet led anything. | F5 is a stated absence. This question pushes past it; the rehearsal is holding it without overreaching. |
| A5 | "Sixty seconds: why fourth grade?" | Pressure | [generic] | Answer slot: your stated reason, in your own words. No reason appears in your material, so if you do not state one, the pack gives none for you. Keep it under sixty seconds. | Pressure bank: the principal tests composure and motive. The pack cannot supply your motive. |

### Bank B — Case / Strategist (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A student reads two grades below level in February. What do you do in the first two weeks?" | CASE | [generic] | Structure it: what you would check first (the assessment and the student's reading history), what you would try in small groups, when you would bring in the family and the team, and how you would know it is working. Name no past case. | A live reading problem from the district's own reading priority. [generic] because it is a pattern, not a fact about you. |
| B2 | "Your team wants a reading test that is mostly timed. What do you say?" | CASE | [inferred] "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." (district page, fetched) | Structure it: what the test measures, what decision it informs, what you would keep, and how you would raise it with the team. Use the district's belief as the frame. | The district names this belief as a hiring value; the question tests whether you can hold it in a team discussion. |
| B3 | "Two families disagree with a term grade. How do you respond?" | CASE | [generic] | Structure it: listen first, check the grade's basis, meet with the family, bring the team in if needed. Name no past case. | Tests family partnership, a published belief, as a decision. |
| B4 | "What would a good first term look like for the reading block?" | CASE | [generic] | Structure it: the first assessment, the first routine, the first family update, and what success would look like by December. Say what you do not yet know about this school. | Tests planning at the principal's altitude; a plan, not a claim. |

### Bank C — Values (principal and both team members)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Every Child a Reader. Tell me about a student who needed a reading plan." | VAL | [grounded] "I've run the after-school reading club for the last two years." (your CV) | Story-mapped on F3: the club, two years, in those words. Answer slot: if you can name one student's reading plan, say what it was and what changed; if no such student comes to mind, say so, then give the club as the nearest thing you did. | The district's first belief, read directly from its published page. |
| C2 | "Families Are Partners. How do you keep families in the loop?" | VAL | [grounded] "I write a weekly email to families." (your CV) | Story-mapped on F4: the weekly email, in those words. Answer slot: the district expects each teacher to speak with every family each term; say what you do, and if you do not yet, say so and say what you would do. | The second belief, with the quote and the gap both visible. |
| C3 | "Teach for Tomorrow, Not for the Test. How have you used assessment to change what you taught?" | VAL | [generic] | Selection scaffold: pick a time an assessment changed your next lesson. If none comes to mind, say so, then describe how you would use one. | No quote in your material carries this belief; the honest branch is required. |

### Bank D — Peer Evaluator (team members)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What would you need from us in your first month?" | JD | [generic] | Name what you would ask for: planning time, the team's sequence, the shared assessments. Ask it as a question back. | Reciprocity framing: what you need, and what you bring. |
| D2 | "The 2024 reading move: who else did the work?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024." (your CV) | Story-mapped on F3 at its own scope. Name the others from your own knowledge; if you cannot, say so. Never claim the work was yours alone. | Credit-sharing probe; the team member is checking the same claim. |
| D3 | "Our fourth-grade reading block and your third-grade work: where would we collide?" | CASE | [generic] | Name the seam as a principle: how the two grades hand off, and who owns the bridge. Do not claim to know the seam. | Peer seam probe; the team's concern is handoff. |
| D4 | "When you disagree with a colleague on a team, what do you do?" | VAL | [generic] | Selection scaffold: pick a disagreement that changed a plan. If none comes to mind, say so, then describe how you would approach one. | Peer disagreement style. |

### Bank E — Conversational (opener)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk us through your journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." (your CV); "I've run the after-school reading club for the last two years." (your CV) | A 90-second arc in this order: six years in Joliet, the 2024 move, the club, the weekly email, and then your honest statement that you have not taught fourth grade. Say the quotes in your own words. | Opener scored for economy; the honest gap belongs in your arc, not at the end. |
| E2 | "Anything you're curious about?" | JD | [generic] | Use the reverse questions below. Never answer "no". | Rapport slot weighted heavily as a preparation signal. |

## Reading the interviewer

Public footprint only. The principal is Dolores Vantongeren, principal of Halvering Elementary School since 2022, after nine years as a reading specialist. Her 2025 forum talk, "Small Groups, Big Readers," covered weekly reading conferences in grades 3 to 5. Implications:

- Expect reading probes from the principal, because reading is her own record.
- Grades 3 to 5 is the band she has spoken about; a question about the third-to-fourth handoff is likely to land.
- Ask about weekly reading conferences in a reverse question. It shows you read her work.

The two team members are not named. Their panel roles are unknown.

## Values / principles cheat sheet

Source: the district's published "Mission and Beliefs" page (fetched) and its "How we hire teachers" page (search result), which says panels ask about reading instruction, classroom routines and how you work with families.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Every Child a Reader | No student leaves third grade without a reading plan. | F3, quoted in C1: "I've run the after-school reading club for the last two years." |
| Families Are Partners | Each teacher speaks with every family each term. | F4, quoted in C2: "I write a weekly email to families." Selection scaffold for the term-level conversations. |
| Teach for Tomorrow, Not for the Test | Assessments inform teaching and never replace it. | No quote carries this. Selection scaffold in C3, with its honest branch. |

## Reverse questions

Each lands for a reason given after the question.

1. "How does the fourth-grade team plan reading blocks together?" Why it lands: shows you already know the team's work is shared.
2. "What does a new teacher's first term look like here?" Why it lands: gets the plan before you are asked for one.
3. "How do families hear from teachers here, and how often?" Why it lands: tests the district's family belief against practice.
4. "You spoke in 2025 about weekly reading conferences in grades 3 to 5. How do those run in fourth grade?" Why it lands: ties the principal's own path and talk to the role; this is the question built on her public record.
5. "What could a new person do in their first month that would genuinely help your team?" Why it lands: reciprocity framing for the peers.
6. "Is there a demonstration lesson or written task after the panel?" Why it lands: tells you what to prepare; it is a process question, not a check on the invite.

## Sources

- Provided: the invite (HR, Orrinsford Community School District); your résumé and message.
- Research tier: L1 — searches 4 of 6, fetches 1 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District Halvering Elementary School values` | yes | Values cheat sheet, section above. Query returned "Mission and Beliefs" (orrinsfordschools.example/about/mission-and-beliefs); fetched it. |
| 2. `Orrinsford Community School District fourth grade teacher panel interview` | yes | Panel format and the hiring page's stated focus areas (reading instruction, classroom routines, families). Query returned "How we hire teachers" (orrinsfordschools.example/careers/how-we-hire-teachers). |
| 3. `Orrinsford Community School District current strategy news` | skipped | Could not have moved a question here: the invite and the district's own pages already set the panel's focus. No query sent. |
| 4. `Dolores Vantongeren Halvering Elementary Orrinsford` | yes | Reading the interviewer, and reverse question 4. Returned a forum speaker page (ilprincipalsforum.example/speakers/dolores-vantongeren). |
| 5. Representative fourth-grade teacher JD | skipped | No JD was supplied; the invite and district pages stand in. A representative JD would add requirement rows, labeled [inferred]. |

Search results were read as snippets plus the two pages named above. No claim is made from any other source.

## Upgrade menu

- The full job posting or JD text → the requirement rows currently built from the invite and the district page become [grounded] JD rows, and new JD questions are added.
- The HR contact's note on focus areas, a demo lesson or a written task → the bank is weighted to that task, and a graded-deliverable section is added.
- Your prep time before Thursday → a prioritized schedule, tied to question IDs.
- The two team members' names → per-member persona weights and their own reverse questions.
- A full research pass (L2: the district's strategy, the principal's talks, recent district news) → a grounding brief and deeper questions on current priorities. Offered once; it runs only if you say so.
