# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd (candidate: Aoife)

**Built on:** the job-ad duties and your background as you described them. No full job description, no company research (L0: provided material only). The round is assumed to be a 30-minute video call with the office manager, treated as a hiring-manager screen. Nothing about Brennock itself has been verified.

## 1. Fit snapshot

| Requirement (from ad) | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| Managing calendars | "ran the appointment book for four physios" | Strong | None | You scheduled for four people with changing demands; that is the same core skill. |
| Booking travel | Not in your material | Gap | Missing | "I haven't booked travel for a team yet; here is how I'd learn it quickly and how I'd handle the calendar side." |
| Word documents | "good with Word" | Partial (self-rated) | Evidence needed | Name one document you built or formatted and what it was for. |
| Excel | "okay with Excel" | Partial (self-rated) | Evidence needed | Be specific about what you do in it. Do not upgrade "okay" in the room. |
| Supplier invoices | "chased unpaid invoices" | Partial | Transferable | "I chased unpaid invoices, so I know how payment status and follow-up work. Processing them in their system is what I'd need to learn." |

## 2. Prohibited claims (built locally)

- Do not claim experience with travel-booking tools you have not used.
- Do not describe yourself as advanced in Excel.
- Do not claim you managed calendars for executives or teams beyond the four physios, unless that is true.

## 3. Interviewer read

Skipped: no interviewer profile was provided.

## 4. Persona weights

- **Hiring manager (primary, about 70%):** first-round screen; wants to know you can do the duties.
- **Skeptic (secondary, about 30%):** a clinic background for an office role invites doubt.

## 5. Question banks

### Hiring manager

| # | Question | Type | Provenance | Guidance |
|---|---|---|---|---|
| 1 | Tell me about your role at the physio clinic. | Background | Candidate-sourced: "ran the appointment book for four physios, chased unpaid invoices" | Lead with the appointment book, then invoices. Keep it to 60–90 seconds. |
| 2 | How would you manage a busy calendar for several people? | Role competence | Candidate-sourced: "ran the appointment book for four physios" | Describe how you handled clashes, changes and priorities. Give one concrete example. |
| 3 | Have you booked travel before? | Experience | Gap: no candidate material. Answer slot: [your honest answer] | If no, say so plainly. Then bridge through your calendar work and say how you would learn. |
| 4 | How comfortable are you with Excel? | Skill | Candidate-sourced: "okay with Excel" | Be specific about what you do. Do not inflate "okay." |
| 5 | Walk me through how you would handle a supplier invoice. | Process | Candidate-sourced: "chased unpaid invoices". Gap: processing not shown | Describe the chasing you did. Say what you would need to learn about their system. |
| 6 | Why are you moving from clinic reception to an admin role? | Motivation | Gap: no candidate material. Answer slot: [your reason] | Give a real reason in two sentences. Avoid criticising the clinic. |

### Skeptic

| # | Question | Type | Provenance | Guidance |
|---|---|---|---|---|
| 7 | Your experience is in a clinic, not an office. Why should I believe it transfers? | Challenge | Candidate-sourced: "two years as a receptionist at a physiotherapy clinic" | Acknowledge the difference. Name the shared skills: scheduling, documents, invoices. |
| 8 | How much of the appointment book was really you, and how much was the physios' own system? | Honesty probe | Candidate-sourced: "ran the appointment book for four physios" | Be exact about your role. Do not overstate it. This is the question most likely to catch an inflated answer. |
| 9 | You are only "okay" with Excel. How would you cope with a complex spreadsheet on day one? | Pressure | Candidate-sourced: "okay with Excel" | Hold your position. Say what you would do: ask, practise, use training. |

**Highest-return prep:** question 8. Rehearse one honest answer that names exactly what you did.

## 6. Reverse questions

- "What does a typical week look like, and who would I be supporting?" *Why it lands:* shows you are thinking about the job itself.
- "Which tools do you use for calendars, travel and invoices?" *Why it lands:* the answer tells you how the job really works. A vague answer is also information.
- "What would success look like after three months?" *Why it lands:* signals you plan to deliver.

## 7. Values cheat sheet

Skipped: no company values were detected (no research run).

## 8. Delivery coaching

Skipped: no working-style assessment was provided.

## 9. Upgrade menu

- **Full job-ad text:** gives a fuller fit snapshot and more duty-specific questions.
- **Any travel-booking or invoice software you have used, even briefly:** upgrades those rows from gap or partial to strong.
- **Interviewer name, if the company gives one and it can be checked:** unlocks an interviewer read.
- **Research pass on Brennock (L1: up to 6 searches, 2 page fetches):** adds company context. Verify the company through official registers, not through this email.
