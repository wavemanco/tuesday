# Interview prep: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: office manager (name not given). Round: 30-minute video call. Built from the ad summary and invite text you gave; no web research was run (research tier L0).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Types: **VAL** behavioural/values, **EXP** your past work, **JD** the listed job, **CO** company knowledge, **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words, and stop where your own experience stops.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — your message | "where I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Say it in those words: you ran an appointment book for four physios. That is scheduling for several people, not a claim about executive diaries. |
| F2 | "booking travel" — your message | none given | none | [grounded] | discovery | Answer slot: if you have booked travel for anyone, say what, for whom and how. If you have not, say so plainly, and say how you would learn the booking tools before your first trip. |
| F3 | "preparing documents in Word and Excel" — your message | "I'm good with Word" — your message | medium | [grounded] | presentation | Use the sentence as written. Do not add a document type or a skill level your material does not name. |
| F4 | "preparing documents in Word and Excel" — your message | "okay with Excel" — your message | low | [inferred] | discovery | Your material touches Excel without showing whether it reaches this task. Answer slot: if you have built or changed a spreadsheet for a real task, say what it did; if you have not, say so plainly and name the Excel task you would learn first. |
| F5 | "processing supplier invoices" — your message | "chased unpaid invoices" — your message | low | [inferred] | transferability | Chasing unpaid invoices is adjacent to processing them, not the same work. Its words: "I chased unpaid invoices." Answer slot: if you logged, matched or paid any invoices, say which; if you only chased them, say that and stop there. |
| F6 | "Remote Administrative Assistant" — the invite | none given | none | [grounded] | discovery | Your material says nothing about working remotely. Answer slot: if you have worked remotely, say how; if you have not, say so plainly and say how you would structure your day. |

Your sentences are the only ones this pack quotes about your past. The gaps above are the pack's own observations, not words for you.

## Prohibited claims

Not coached, and why. Each is a stretched version of a sentence you did say; the honest form is that sentence at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| "Managed calendars for a whole office" | Inflated form of F1 | F1's quote at its own scope: an appointment book for four physios. |
| "Processed supplier invoices" | Inflated form of F5 | F5's quote at its own scope: you chased unpaid invoices. |
| "Expert in Excel" | Inflated form of F4 | "okay with Excel", at its own scope. |
| "Expert in Word" | Inflated form of F3 | "I'm good with Word", at its own scope. |

## Personas

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Lays the ad's four tasks beside your CV and asks about the gaps | High. An admin role is scored on exactly these tasks, and your CV is about a clinic | Rehearse A2 until it is plain. Say what you did in your own words, and say when you have not done something |
| Case / Strategist | Gives a practical problem from the job | Medium. An office manager with a 30-minute slot often moves to a practical task | Clarify first, offer options, say what you would record |
| Conversational | Opens with "walk me through" and casual questions about the role | Medium. Short calls often open with rapport | Keep a 90-second arc ready; treat casual questions as scored |

Weights: Skeptic 5 questions, Case 4, Conversational 3. Total 12, below the usual band, because one ad and one short background give the banks less to probe. The upgrade menu says what would add more.

## Question banks

### Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What drew you from a physiotherapy clinic to this kind of admin role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | Motivation in 60 to 90 seconds: the clinic years, what they showed you about admin work, and why this role. Say the clinic years plainly and do not dramatise them. | A Skeptic motivation probe. It draws on F1 and F5 for the evidence. |
| A2 | "Which of the tasks in this ad is furthest from anything in your background?" | JD | [grounded] "chased unpaid invoices" — your message; "I'm good with Word, okay with Excel." — your message | **Highest-ROI prep in this pack.** Name the task. If it is booking travel: answer slot, so if you have booked travel say how, and if you have not, say so plainly and say how you would learn it first. If it is invoices: say what you did at its own scope, "I chased unpaid invoices", and what you would learn. Hold through two follow-ups by returning to what you did, and concede a gap specifically rather than folding on the core. | This objection will come in some form. It draws on F2 and F5, the two rows with the thinnest evidence. |
| A3 | "You chased unpaid invoices. Did you ever process one from start to finish?" | JD | [grounded] "chased unpaid invoices" — your message | Answer slot: if you did any part of processing an invoice, say which steps and which were yours. If you did not, say so plainly and return to chasing. | Premised question on F5. The second branch lets the premise be false. |
| A4 | "Excel is part of this job. What have you built in it?" | JD | [grounded] "okay with Excel" — your message | Answer slot: if you have built a sheet for a real task, say what it did and whose it was. If you have not built anything, say so plainly and name the Excel task you would learn first. | Premised question on F4. The second branch lets the premise be false. |
| A5 | "Tell me about a time a booking went wrong. What did you do?" | EXP | [grounded] "where I ran the appointment book for four physios" — your message | Open prompt. Pick one real instance from the appointment book and tell it in order: what went wrong, what you did, how it ended. If none comes to mind, say so plainly, then give the nearest thing your material carries. | Open prompt on the ad's "managing calendars" line. It draws on F1. |

### Case / Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two people need the same boardroom in the same slot, and you can see both diaries. What do you do?" | CASE | [generic] | Clarify who needs it more and what is fixed. Offer two options, confirm with both, and record the decision. Makes no claim about your past. | A live calendar problem from the ad's "managing calendars" line. It is a decision, not a record. |
| B2 | "A supplier invoice does not match its purchase order. Walk me through what you would do." | CASE | [generic] | Check the purchase order and the invoice line by line. Hold payment until the mismatch is resolved. Raise it with the supplier in writing, with the difference shown. | Tests the "processing supplier invoices" line as a plan. No claim about your past. |
| B3 | "How would you set up a simple Excel tracker for invoices due this month?" | CASE | [generic] | Columns first: supplier, invoice number, amount, due date, status. Add a total and check it against the source. Say what you would verify, not what you already know how to build. | Tests F4 and F5 as a plan. |
| B4 | "Draft the first two lines of a note to a supplier about a late payment. What tone would you use?" | CASE | [generic] | Name the tone you would choose and why, then write the two lines. | Tests Word output in a live task, the "preparing documents in Word" line. |

### Conversational (weight: lower)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios" — your message; "chased unpaid invoices" — your message | A 90-second arc: the clinic, the appointment book, the invoices you chased, and what you want to do next. Use your own words; the quoted sentences are the whole of the content. | The opener. The arc is built only from your own sentences. |
| C2 | "What do you actually do day to day in Word?" | JD | [grounded] "I'm good with Word" — your message | Name what you have produced in Word, in your own words. If the list is short, say so. | Casual wording, scored. It draws on F3. |
| C3 | "What would you want to learn in your first month here?" | JD | [generic] | Name two things you would learn first. Keep them to plans, not past experience. Booking travel and the invoice process are the obvious two, and they are a plan, not a claim. | A casual question on the two thinnest rows, F2 and F5. |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| managing calendars | A5, B1, C1 |
| booking travel | A2 |
| preparing documents in Word and Excel | A4, B3, B4, C2 |
| processing supplier invoices | A3, B2, B3 |
| Remote Administrative Assistant | none, and why: the ad text you gave states no remote-working task beyond the title |

## Reverse questions

1. "What does a normal week look like, and how is the time split between calendars, travel and documents?" Why it lands: it shows you listened to the ad's four tasks.
2. "Who sends the supplier invoices, and who signs off payment?" Why it lands: it shows you care about the approval step.
3. "How do you share calendars and documents across a remote team?" Why it lands: it asks about the remote part of the role.
4. "What would a successful first month look like?" Why it lands: it asks about the goal, not the process.
5. "What is the next step after this call?" Why it lands: it asks about the process itself, which helps you plan the next conversation.

No interviewer profile was given, so no reverse question ties to the interviewer's own path.

## Sources

Provided documents: the ad summary and the invite text, both from your message. No searches or fetches were run.

Research tier: L0. You have not consented to research, so the pack uses only what you pasted.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Would have moved a values section; none was built at L0 |
| 2. `Brennock Facilities Ltd interview process Administrative Assistant` | unavailable | Would have confirmed the loop; the pack assumes a single 30-minute call, as the invite states |
| 3. `Brennock Facilities Ltd strategy / recent news` | unavailable | Would have moved a grounding brief; none was built at L0 |
| 4. `{interviewer name} Brennock` | n/a | No name was given, so there was no query to form |
| 5. Representative `Remote Administrative Assistant` JD | unavailable | The ad summary you gave stands in; a full JD would turn F1 to F6 into [grounded] rows with the exact wording |

## Upgrade menu

- The full text of the ad → the fit snapshot's requirements become exact quotes, and the JD-tagged questions can be checked against the ad's own list.
- Any hard requirements in the ad, such as hours, location or right to work → the pack gets gate rows.
- A spreadsheet or document you have made for real work → moves F4 and F3 from thin evidence to a concrete example.
- The interviewer's name and role → a tailored reverse question, and persona weights from their public footprint.
- Consent to L1 research → the company's public values and recent news, to sound current on the call.
