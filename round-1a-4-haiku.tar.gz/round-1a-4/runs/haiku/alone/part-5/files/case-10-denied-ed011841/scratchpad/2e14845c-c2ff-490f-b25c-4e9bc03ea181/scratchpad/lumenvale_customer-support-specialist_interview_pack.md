# Interview prep: Customer Support Specialist, Lumenvale Software (remote)

**Interviewer:** support team lead (name not given). **Round:** text-chat interview on Telegram. **Relationship:** team lead, role not yet confirmed as manager or peer.
**Built from:** your message (job-ad summary, your background, the invite). No full job ad, no web research.

## 1. How to use

Personas are how the question is asked. Types are what is being scored:

- **Experience:** what you have actually done.
- **Situation:** how you would handle a case you have not yet met.
- **Skill:** tools and written communication.
- **Motivation:** why this role.
- **Reverse:** questions you ask them.

Guidance is scaffolding, not a script. In a text chat your written answers are the whole interview. Write each answer out, read it back, and keep it to about 120 words.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your message) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | none | Your material gives the years and the role. Say them as they are: "I have 3 years as a customer service advisor at an energy supplier." |
| F2 | "Zendesk or a similar ticketing tool" (your message) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | Freshdesk is a similar ticketing tool, and the quote says you use it daily. Do not claim Zendesk. If asked, say how you would learn it, as a plan. |
| F3 | "clear written communication" (your message) | "answering around 60 calls and emails a day" (your message) | low | [grounded] | presentation | The emails are your written work, but the material does not show how clear they were. Bridge in the quote's own terms only: "I answer around 60 calls and emails a day." Answer slot: name one written reply you are proud of and say why it worked. |
| F4 | "confidence handling escalations" (your message) | none given | none | [inferred] | discovery | The material says nothing about escalations. Answer slot: think of the nearest case where a call or email went beyond your first answer. Say what you did next and who you passed it to. If there was no such case, say so and say how you would handle the first one. |

## 3. Prohibited list

These claims are not coached, because the material does not support them.

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Inflated form of F2 | "I use Freshdesk every day." Zendesk is a plan, not a past. |
| Handled escalations as a team | No quote carries escalations | Answer slot (F4) only, at the scope you describe. |
| Software or product support experience | You said you have never worked for a software company | "I've never worked for a software company." Then the bridge: what transfers, and what you would learn first. |
| Owned or led the refunds process | Material says you trained others on it | "I trained four new starters on our refunds process last year." |

## 4. Question banks

### Persona: Support team lead (weight: high, since this round is with the lead)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | Experience | "Tell me about your customer support work." | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); "answering around 60 calls and emails a day" (your message) | Open with your role and your volume, in your own words, as the quotes state them. Then name the tool: "I use Freshdesk every day." | Gives the lead the facts first. Figures you can state are stronger than adjectives. |
| A2 | Situation | "Tell me about a time you had to escalate a case." | [inferred] answer slot; no quote carries escalations | Use the F4 slot. If you have a real case, say what you did next and who you passed it to. If not, say so and describe how you would handle the first one. | This is the most likely gap in the pack and the one to rehearse hardest. |
| A3 | Skill | "Have you used Zendesk?" | [grounded] "I use Freshdesk every day" (your message) | "I use Freshdesk every day." Then one plan line: how you would learn Zendesk in your first week. | Answering with the tool you use, and a learning plan, is honest and shows initiative. |
| A4 | Experience | "Have you trained anyone?" | [grounded] "I trained four new starters on our refunds process last year" (your message) | Give the quote, then the refunds process as steps you took. Stop once the steps are covered. | Training is a concrete, checkable example of communication. |
| A5 | Skill | "How do you make sure your written replies are clear?" | [grounded] "answering around 60 calls and emails a day" (your message) | Describe your practice of writing emails. If you have one example, use it. If not, use the F3 slot: say how you would check a reply is clear before sending. | Clear writing is the requirement with the least evidence, so a plan is the honest answer. |

### Persona: Skeptic (weight: medium)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | Experience | "You've never worked for a software company. Why would you be good at supporting our product?" | [grounded] "I've never worked for a software company" (your message) | Agree with the fact in one sentence. Then say what transfers: daily ticket volume, a ticketing tool, training others. Then say what you would learn first. Claim no product knowledge. | The skeptic is testing whether you overclaim. Agreeing with the fact is the strongest reply. |
| B2 | Situation | "Escalations are the hard part of this role. Show me you can handle one." | [inferred] answer slot (F4) | The highest-ROI prep in this pack. Rehearse the F4 slot until you can say it in about 90 seconds, twice, with no invented detail. | Escalations are the gap the job ad names and your material does not show. |

## 5. Reverse questions

Each question has a reason it lands.

1. "What does a typical first week look like, and which tools will I use?" Why it lands: it shows you are already thinking about the tools.
2. "How do escalations move from first contact to the team lead, and who decides when to escalate?" Why it lands: it targets the gap in F4 and gives you the process.
3. "How is quality measured for this role in the first 90 days?" Why it lands: it shows you care how your work is judged.
4. "What comes after this chat stage, and how is an offer confirmed?" Why it lands: knowing the stages lets you prepare for each. Ask it as a question about the process only.
5. "What would make someone in this role excellent after a year?" Why it lands: it turns the interview toward their expectations.

## 6. Sources

- **Provided:** your message (job-ad summary, background, the invite text).
- **Searches:** one attempted to check the company and its hiring process. Refused: permission to use web search was not granted. Nothing returned.
- **Fetches:** none.
- **Research tier:** L0 (provided documents only).

**Target accounting**

| Target | Status |
|---|---|
| Company values | unavailable |
| Loop structure | unavailable |
| Current strategy | unavailable |
| Interviewer public footprint | skipped (no name given) |

## 7. Upgrade menu

- Full job ad text → the four requirements are quoted exactly, and their rows become [grounded] with exact wording.
- Team lead's name → a tailored reverse question, and persona weights read from their public footprint.
- Whether the team lead is your manager or a peer → reweights the banks.
- `tuesday-dossier.md` → verified evidence and a stronger rehearsal of the escalation gap.
