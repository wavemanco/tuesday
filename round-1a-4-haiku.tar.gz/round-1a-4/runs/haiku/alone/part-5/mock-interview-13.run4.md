Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-5-rooms-case-13-denied-d2f300cd/9efe14b8-8c46-4153-8ea5-30dd992c2dec/scratchpad/Quillmoor_Operations-Coordinator_interview_pack.md`.

Three things to know before Thursday:

- **Notice period:** your message doesn't include it, and Hannah will ask. Find the real figure now. The pack doesn't guess it.
- **SAP:** the advert lists SAP as a plus, and you haven't used it. The pack gives you one honest line to rehearse: "I haven't used SAP. We run our own in-house stock system."
- **Research:** my two web searches about Quillmoor were refused by permission, so the pack has nothing on their values or interview process. Those are the first things I'd add if you grant permission.

The pack also covers your pay figure, hybrid limit and reason for moving, plus five reverse questions for Hannah, and a short call-day checklist. I kept the pay answer to the £42,000 you gave, with no range or counter-offer added.

I can also run a short practice call where I play Hannah, or save a `tuesday-dossier.md` recording the gaps this prep exposed for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quillmoor_Operations-Coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** 30-minute phone recruiter screen, Thursday 2pm, with Hannah Lowther (Talent Partner). She will call the mobile number on your application.
**Candidate:** Sam
**Research tier:** L0 (your material only). Two web searches were attempted and refused by permission, so nothing about the company was researched. See Sources.
**Round type:** no loop source confirms the process, so persona weights rest on the recruiter-screen archetype, not on Quillmoor's documented process.

## How to use this pack

- **Personas** describe how a question arrives (friendly, skeptical, probing). **Types** describe what is being scored: EXP (your experience), JD (the advert's requirements), CASE (a live problem), CO (company knowledge), VAL (values).
- Guidance is scaffolding for a spoken answer, not a script. Say it in your own words.
- Answer slots (in italics or in "Answer slot:" text) are instructions for the call, not questions to answer here.

## Prep triage

In priority order, for Thursday:

1. **Notice period.** Your message does not give it, and Hannah will ask. Find your actual notice period and say it in weeks or months. Do not guess.
2. **The SAP answer (B1, D3).** This is the highest-return prep in the pack. Say it aloud until it is boring: "I haven't used SAP. We run our own in-house stock system."
3. **Salary (A4).** Say your figure once, in your own words.
4. **Reverse questions.** Choose two from the list below.
5. **Call-day checklist:** the mobile number on your application is correct and you have signal; the advert and this pack are open; you are somewhere quiet. If the time changes, message Hannah on LinkedIn, as she asked.

Everything else is insurance.

## The fit snapshot

Quotes are from your message unless marked.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material says delivery scheduling across three depots, not production scheduling, so the bridge stays at that scope: "I schedule deliveries for our three depots." Answer slot: if you ever coordinated with planning or QA on what gets made, say what; if not, say so and say how you would learn the production side |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I chase suppliers when orders slip" (your message) | medium | [grounded] | none | The quote reaches the requirement. Lead with it in your own words |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet" and "discrepancies fell by about a third over a year" (your message) | medium | [grounded] | presentation | Reword the quote only: "I rebuilt our stock-count spreadsheet, and discrepancies fell by about a third over a year." The third is a figure, so it raises the defend-the-number slots in B3 |
| F4 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if you reported on delivery timing, say what you tracked; if you did not, say so and say how you would set up the weekly report |
| F5 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | Meets the requirement. Say it as written |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | A spreadsheet rebuild shows use, not level. Answer slot: name the functions you used; if you used only the basics, say so |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | none | [grounded] | capability | You stated the SAP absence, so the words are yours: "I haven't used SAP. We run our own in-house stock system." Answer slot for "or similar": if the in-house system did what an ERP does across functions, say which; if it only recorded stock, say so |
| F8 | "Hybrid: two days a week at our Avonmouth site" (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Meets the requirement. Say it in those terms |

## The prohibited list

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Production scheduling experience | Inflated form of F1 | "I schedule deliveries for our three depots." Your material says delivery scheduling, not production scheduling |
| SAP or ERP experience | Negative you stated (F7) | "I haven't used SAP." Then how you would learn it, as a plan |
| Sole credit for the drop in discrepancies | Inflated form of F3 | "I rebuilt our stock-count spreadsheet, and discrepancies fell by about a third over a year." Your material does not say what else changed |

## Persona table

| Persona | How it shows up | Likelihood (reasoning) | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly opener, "walk me through your background" | High: a recruiter screen opens this way (archetype) | A 90-second arc from your own sentences; casual questions are still scored |
| Skeptic | Pins down the SAP gap and the production-scheduling gap | High: the advert names both, and your message names one | Rehearse the SAP answer until it is boring; give the limit plainly |
| Data-driven Prober | "How was that third counted?" | Medium: a figure on your CV draws this | Say what you know and what you do not |
| Pressure | Sharp "why you?" | Low to medium | Pause, restate, hold once, concede only what is true |

Persona weights: Conversational 5 questions, Skeptic 4, Prober 3, Pressure 2. No Values, Case-strategist or Peer bank, because no values page was read and no loop source names those rounds.

## Question banks

### Conversational / Rapport (weight: 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me a bit about your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots"; "I chase suppliers when orders slip" | A 90-second arc: the role, the scale, what you do day to day, then the stock-count result as stated. Say it in your own words | Opener for every recruiter screen; it is scored on clarity and on whether it matches the advert |
| A2 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say the fact as you said it. Then one sentence on what you want from the next role. Answer slot: state that sentence in your own words; the pack does not supply it. Do not criticise the employer | Reason for leaving is a logistics slot; a plain, positive answer is the safe one |
| A3 | "What's your notice period?" | JD | [grounded] none given: you have not stated one | Instruction: give your actual notice period, in weeks or months. Do not guess | Logistics slot; it is missing from what you shared, so find it before Thursday |
| A4 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say the figure once. If you want the band first, ask what the role's band is before you give a figure. The advert says £38,000–£44,000. Add nothing: no range, no floor, no counter-offer | Logistics slot; the figure you stated fills it and raises no further question |
| A5 | "How do you feel about the hybrid pattern?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" | Say it in those terms. Do not explain your commute | Logistics slot; you already stated the limit |
| A6 | "What would your last manager say you're strongest at?" | EXP | none given | Selection scaffold: pick one thing a manager would notice and name one example from your own work. If you cannot name one, say so and give the nearest thing | Open prompt; your material does not carry a strength, so the guidance supplies none |
| A7 | "What made you apply here?" | EXP | none given | Answer slot: say what in the advert drew you, in your own words | Open prompt; the reason to apply is yours to give |

### Skeptic (weight: 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert asks for SAP or similar. What's your experience?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | **Highest-ROI prep in this pack.** "I haven't used SAP. We run our own in-house stock system." Answer slot for "or similar": if the in-house system did what an ERP does across functions, say which; if it only recorded stock, say so. Hold the line once; do not pretend | F7 is the requirement you do not meet, and she will ask it in some form |
| B2 | "Have you done production scheduling?" | JD | [grounded] "I schedule deliveries for our three depots" | "I schedule deliveries for our three depots." Answer slot: if you coordinated with planning or QA on what gets made, say what; if not, say so and say how you would learn it | F1's gap; the production side is the advert's first requirement |
| B3 | "Your discrepancies fell by a third. How much of that was you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet"; "discrepancies fell by about a third over a year" | Say the spreadsheet is what you rebuilt, and what it changed. Answer slots: how the third was counted; the assumption you would defend least; which part was yours. If you do not know how it was counted, say so | A figure raises defend-the-number slots; the drop is over a year, so other changes are possible |
| B4 | "How comfortable are you in Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Name the functions you used in that rebuild. Answer slot: if you used only the basics, say so | F6: a rebuild shows use, not level |

### Prober (weight: 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you count the discrepancies?" | EXP | [grounded] "discrepancies fell by about a third over a year" | Answer slot: if you know how it was counted, say so in your own words; if not, say so. Never describe a method you did not use | Defend-the-number slot on the figure you gave |
| C2 | "Has any part of your work involved reporting on on-time delivery?" | JD | none given | Answer slot: if you reported on delivery timing, say what you tracked; if you did not, say so and say how you would set up a weekly report | F4: the advert asks for weekly reporting and your material is silent on it |
| C3 | "Three depots report late stock on the same day. What do you do first?" | CASE | [generic] | Structure: find out what is late and why, check the stock record, chase suppliers in order of impact, then tell the depots. Make no claim about your past | A live problem from the advert's late-order work; generic, so it makes no claim about you |

### Pressure (weight: 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What's the weakest part of your background for this role?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Name the SAP gap first. "I haven't used SAP." Then how you would learn it, as a plan. Do not add a second weakness you have not been asked about | Honest self-assessment; the answer you can defend is the same answer as B1 |
| D2 | "Give me the case for why you, not an internal candidate, in sixty seconds." | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" | Pause, restate, then give the overlap your material shows: scheduling, chasing suppliers, stock records. Hold once; concede only what is true | Pressure delivery of the core fit |

## Reverse questions

Each has a "why it lands". Choose two.

1. "What does a typical first 90 days look like in this role?" Why it lands: shows you are planning the job, not only the offer.
2. "Which teams does this role work with most day to day: planning, the warehouse or QA?" Why it lands: maps the advert's three groups and invites her to name the hard handoff.
3. "How is on-time dispatch measured today?" Why it lands: asks about the weekly report the advert names.
4. "You said you'd tell me about the team. How big is it, and who would this role report to?" Why it lands: she promised this part of the call, so it keeps her agenda.
5. "Is the two-day Avonmouth pattern fixed, and is the salary band set for this role?" Why it lands: confirms the terms you already stated before any offer.

Reciprocity question: not applicable, the interviewer is not a peer.

## Requirement coverage

| Advert requirement | Question IDs |
|---|---|
| Coordinate production schedules | B2, C2 |
| Track supplier deliveries, chase late orders | A1, C3 |
| Keep stock records accurate | B3, C1 |
| Weekly on-time dispatch reporting | C2 |
| 2+ years in operations or logistics coordination | A1, D2 |
| Confident with Excel | B4 (no question for level beyond this) |
| ERP (SAP or similar) a plus | B1, D1 |
| Salary £38,000–£44,000 | A4 |
| Hybrid, two days at Avonmouth | A5 |
| Notice, reason for leaving | A2, A3 |

## Sources

- **Provided documents:** your message, which includes Hannah's message, the advert text and your background.
- **Research:** two web searches were attempted, `Quillmoor Diagnostics values` and `Quillmoor Diagnostics interview process operations coordinator`. Both were refused by permission and returned nothing. Nothing about the company's values, process or strategy is used in this pack.

**Target accounting**

- Research tier: L1 requested, 0 of 6 searches and 0 of 2 fetches completed (permission refused).
- Target 1, company values: unavailable (refused).
- Target 2, interview process: unavailable (refused).
- Target 3, strategy: skipped (budget spent on refused targets 1 and 2).
- Target 4, interviewer footprint: n/a (no interviewer name given; the recruiter is the screen).
- Target 5, representative JD: skipped (JD supplied).

## Upgrade menu

- Permission to run the web searches → the company's values and interview process, which would add a values bank and a loop-structure check.
- The company's values page, pasted → a values cheat sheet, if the screen uses values language.
- The recruiter's prep email, if she sends one → confirms the round's content and any named focus areas.
- The hiring manager's name, after this screen → persona weights and a tailored reverse question.
