Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." before your slot is confirmed, to "reply with a photo of your passport and your bank details before the interview", and it says "you deposit the cheque and send the balance on to the vendor". A fee before an interview, passport and bank details before any offer, and a cheque you deposit and then partly pay back out are very likely a scam, and this job is very likely a scam. Hold all three: don't pay, deposit the cheque, or send documents or bank details until you've checked the invite with the employer, using a phone number or address from its own website or careers page, not anything in this email. If you want the invite weighed, job-underwriter can check it as a separate request. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a4-runs-haiku-alone-part-5-rooms-case-12-denied-1ba1c8bb/31cf06fb-c2e4-42a6-bc6f-4748bcd63e06/scratchpad/Brennock_Remote_Administrative_Assistant_interview_pack.md. I built it for a 30-minute screen with the office manager. I could not check the company online, because web search permission was refused, so the pack relies only on your ad and your background.

Say the word and I'll play the office manager on A2 and B3, the two questions the pack flags as the hardest, and give feedback after.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

Would the office manager be someone you'd report to, or someone you'd work alongside?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock_Remote_Administrative_Assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Interviewer:** office manager (name not given). **Round:** 30-minute video call. **Relationship:** assumed to be a manager-type screen, since the office manager runs the call. Persona weights below rest on that assumption.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored.

- **EXP**: what you actually did
- **JD**: a requirement from the job ad
- **CASE**: a practical situation you would have to handle
- **MOT**: why this role
- **PROC**: how the job runs day to day

Guidance is scaffolding, not a script. Speak in your own words.

## Fit snapshot

Requirements are the ad's duties as you described them. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (the ad, as you described it) | "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your material says the appointment book, for four physios. Say it in those words: "I ran the appointment book for four physios." Do not stretch it to cover calendars you did not keep. |
| F2 | "booking travel" (the ad, as you described it) | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if you have booked travel for anyone, say what, for whom and how, in your own words. If not, say so plainly, and say how you would learn the booking tools. |
| F3 | "preparing documents in Word" (the ad, as you described it) | "good with Word" — your message | medium | [grounded] | none | Your own words already reach this requirement. Use them as they are. |
| F4 | "preparing documents in Excel" (the ad, as you described it) | "okay with Excel" — your message | low | [grounded] | discovery | "Okay" is the word you chose; keep it. Answer slot: name one thing you have built or formatted in Excel. If none, say so and say what you would learn first. |
| F5 | "processing supplier invoices" (the ad, as you described it) | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Chasing unpaid invoices is adjacent to processing supplier bills, not the same work. Say what chasing involved. Answer slot: have you entered, matched or approved invoices for payment yourself? If yes, say how. If no, say so. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I have booked travel for executives" | Inflated form of F2 | F2's answer slot only. Nothing is written for you to say here. |
| "I'm advanced in Excel" | Inflated form of F4 | "I'm okay with Excel," plus the one thing you have built, if any. |
| "I have processed supplier invoices for payment" | Inflated form of F5 | "I chased unpaid invoices," at its own scope. The F5 slot asks the rest. |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Practical office manager | Asks what you did day to day and how you would run the work | High. A 30-minute screen from the person who runs the office tests daily fit first | Answer with the named work, then one concrete example |
| Prober | Asks for numbers and specifics on your CV lines | Medium. Your CV lines (appointment book, chasing invoices, Excel "okay") invite checks on scale | Give the figure you know; say plainly when you don't know it |

## Question banks

### Bank A: Practical office manager (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "ran the appointment book for four physios" — your message | Tell it in your own words: how bookings were made, how clashes and cancellations were handled. Answer slot: say how you handled clashes; if a rule was set for you, say what the rule was. | F1 is the calendar requirement and the likeliest place for a follow-up. EXP tests what you actually did |
| A2 | "Have you ever booked travel for anyone?" | JD | [grounded] | Answer slot from F2. If you have, say what, for whom and how. If not, say so plainly and say how you would learn the booking tools. | F2 is the gap the ad names most directly. JD because the ad lists the duty |
| A3 | "A physio asks you to move a client's booking at short notice, and it clashes with a session already booked. What do you do?" | CASE | [generic] | Structure it: check who holds each slot, decide priority with the person who sets it, tell the affected people first, record the change. The question needs no claim about your past | A live scheduling problem from the calendar duty. [generic] because it is a pattern, not a fact about this employer |
| A4 | "The job includes Excel. How would you set up a monthly supplier invoice list?" | JD | [grounded] "okay with Excel" — your message | Describe the columns you would use: supplier, invoice number, amount, due date, status (received, approved, paid, overdue). Say how you would check the totals. Answer slot from F4: name a real thing you have built, or say you would learn the functions you need first | F4 is the thin spot. The question presses on the spreadsheet side of the invoices duty |
| A5 | "What did chasing unpaid invoices involve?" | EXP | [grounded] "chased unpaid invoices" — your message | Say who you contacted, how often, and what you recorded. Answer slot from F5: if you also entered invoices for payment, say so; if you did not, say so | F5's adjacent-work gap. EXP because it tests what you did |

### Bank B: Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "How many invoices a month did you chase, and what share did you recover?" | EXP | [grounded] "chased unpaid invoices" — your message | Give the figure only if you know it. If you don't, say so and say how you tracked it. Do not round up | Probers ask for the denominator. The guidance adds no number |
| B2 | "Your Excel is 'okay'. What's the most complex thing you've done in it?" | JD | [grounded] "okay with Excel" — your message | Name it in your own words. If the answer is basic, say so plainly. Do not upgrade it | F4 is where a prober will press. The honest answer is the one that holds |
| B3 | "You haven't booked travel before. Why should I think you'll do it well?" | JD | [grounded] | Hold first: say what you would check before booking, such as the traveller's dates, the budget and the policy. Then answer the F2 slot honestly: what you have booked, or that you have not and how you would learn | Pressure on F2. The hold-then-answer structure keeps you from over-claiming |

## Reverse questions

Each one is for the office manager. None asks them to check anything about the invite.

1. "What does a typical week look like for whoever holds this role?" Why it lands: shows you are planning the work, not just the title.
2. "Which calendar and travel tools does the team use?" Why it lands: shows you will learn their tools, and tests fit.
3. "How are supplier invoices approved and paid here, and who signs off?" Why it lands: shows you understand the invoice cycle the role runs.
4. "What would a good first month look like in this role?" Why it lands: signals outcome thinking.
5. "How do you prefer a remote admin to get updates: chat, email, or a set call?" Why it lands: shows you have thought about remote working.
6. "What happens after this call?" Why it lands: a process question. You want to plan your availability.

## Sources

Provided documents: the job ad as you described it, your message with your background, and the invite text you pasted.

Research tier: L1 — searches 0 of 6, fetches 0 of 2. Both searches were refused: web search permission was not granted in this session.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Values cheat sheet, not produced. Queries sent, refused: "Brennock Facilities Ltd"; "Brennock Facilities Ltd careers recruitment scam" |
| 2. `Brennock Facilities Ltd interview process` | unavailable | Loop structure and persona weights. Query sent, refused: "Brennock Facilities Ltd careers recruitment scam" |
| 3. Company strategy / recent news | unavailable | Current priorities. No query sent before the search was refused |
| 4. Interviewer name + company | n/a | No name given, so there was no query to form |
| 5. Representative JD | skipped | The ad fixes the fit snapshot and the duty-based questions |

## Upgrade menu

- A full job posting, found on the employer's own website rather than in the invite → requirements quoted in full, not as your summary; sharpens A4 and B2
- Your CV → the fit snapshot quotes your own document instead of your message
- The office manager's name → persona weights from their public footprint, if you want them
- Prep time available → a prioritized schedule for the 30 minutes you have
- `tuesday-dossier.md` → one line: it would record the gaps this prep exposed, for the next session
