**Don't go ahead. This is a scam, and a well-known type. Don't send your IBAN, PPS number, passport photo or any money.** I haven't researched Velloway Logistics online. I don't need to, because the messages show it.

**What gives it away**
- **They asked for your passport, PPS number and IBAN before any real interview.** A genuine employer only collects these after a signed contract. Collecting them early is identity theft.
- **"You passed our first screening" and "you passed the interview" came with no real interview.** The chat only collected your details and willingness to comply.
- **They asked you to pay €349 for equipment.** Real employers don't charge new hires for equipment, and a "refund with your first wages" is the standard advance-fee hook.
- **The €2,850 cheque is the main trap.** It's an overpayment scam. Your bank may credit the cheque quickly, but it can bounce days or weeks later. You would then owe the bank the full amount, and the money you transferred to the "equipment partner" would be gone for good. The "keep €350 as a bonus" line is bait to make it feel safe.
- **The details around it fit the pattern too:**
  - The hiring runs entirely on Telegram with no calls.
  - The contact email is a throwaway-style address, not a company domain.
  - The posting promises €26/hour for no experience, with flexible hours and commission.
  - The job suits your background closely, which is how these postings are written to draw people in.

**What to do now**
1. Stop replying and block @VellowayHiring. Don't argue with them or tell them you've caught on.
2. If a cheque arrives, don't lodge it.
3. Your IBAN alone is low risk, but don't send it to them, and keep your PPS number and passport details private.
4. Report it to the Gardaí, to the Telegram account, and to the jobs site so they remove the posting. If you ever do pay or lodge anything, call your bank immediately.

**Your actual job search**
Your background is a good fit for real roles. Three years of high-volume Zendesk work at a courier, training new starters and running an Excel tracker maps well to order processing, dispatch coordination, customer operations or team-lead roles. €30k is realistic for those in Ireland. I'd start with the careers pages of courier, freight and e-commerce companies, since you already know that sector. A real employer will:
- interview you on a call or video, or in person
- email from a company domain
- ask for bank and PPS details only after you've signed a contract
- never ask you to pay anything or pass money on

If you'd like, I can help you tighten your CV for those roles. I can also check any future posting for you before you reply to it.