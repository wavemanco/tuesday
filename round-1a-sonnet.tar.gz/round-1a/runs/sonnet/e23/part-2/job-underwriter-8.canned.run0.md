I read the skill's rules and checked your posting and the three Telegram messages against them.

## Decision snapshot

**No, don't go ahead. This is almost certainly a fake-cheque and identity-harvesting scam, and nothing should be sent. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (income of at least €30,000 a year)
- `must_have` — direct: R2, R3
- `important` — direct: R4
- `preferred` — unclear: R5 (a quiet place to work)

Your fit is not the problem: R2, R3 and R4 are the posting's real requirements and your background covers them. The opportunity is what fails.

**Opportunity ledger.** The register shows three severe red flags that together form the classic scam sequence: RR1 (ID and IBAN up front), RR2 (a fee from you) and RR3 (a cheque you forward). RR4 to RR7 add to that, and RR6 leaves open whether Velloway Logistics exists as described.

- **Hard gates:** none failed; unconfirmed: R1 (Income of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`).
- **What would change this:** a verified registered company, a live posting on its own careers site, and a video interview with a named manager, with no payment, cheque or ID requested before a signed contract. The cheque request alone is enough to stop.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics", named in the posting. Not checked: I ran no search, so I can't say whether it exists or whether someone is using its name | `[grounded]` posting header; existence not established |
| Mandate | "Order Processing Coordinator". The posting doesn't say whose orders, which systems, or what the work involves | `[grounded]` posting |
| Pay and hours | Up to €26/hour plus unspecified commission, 15–30 hours a week. That is at most €20,280 a year at 15 hours and €40,560 at 30 hours, and "up to" means the actual rate is unknown | `[grounded]` posting, with arithmetic of rate × hours × 52 weeks |
| Process | Telegram only, no calls or video. ID and bank details are requested before the "chat interview" | `[grounded]` posting and messages |
| Contradictions | (a) The posting mentions no equipment cost, yet you're asked for €349. (b) The cheque is €2,850, of which you keep €350 and send €2,500, though the kit costs €349. (c) The posting says "no experience needed", yet you "passed screening" before being asked anything | `[grounded]` posting and messages |
| Market calibration | Not run, because no search was sent | `[generic]` none made |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Income of at least €30,000 a year (your stated minimum) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated constraint. Fit is unclear because €30,000 needs about 22 hours a week at the maximum €26 rate, which is only an "up to" figure, so the guaranteed pay is unknown | `[grounded]` your constraint; `[grounded]` posting figures | Moot given RR1–RR3 |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day, and you keep a weekly team tracker, both described by you. No artifact has been inspected | `[grounded]` your account | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You maintain the team's weekly tracker in Excel. This is self-reported with no sample seen | `[grounded]` your account | none |
| R4 | Good written English | important | direct | medium | none | Written customer-service replies in Zendesk for three years, and you trained two new starters | `[grounded]` your account | none |
| R5 | A quiet place to work | preferred | unclear | low | discovery | You haven't said, and it's trivial to meet | `[grounded]` silence in your message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Income floor (R1, hard_gate) | hard_gate | Pay is "up to €26/hour" with commission unspecified | A real offer would need a guaranteed rate to test against your €30,000 | A written rate and hours guarantee in a contract from a verified employer | Employment contract naming the registered company | `[grounded]` posting wording |
| G2 | Quiet workspace (R5, preferred) | discovery | Not stated | Minor | Your home set-up | None needed | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | IBAN, PPS number and passport photo requested before any interview | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | Together these let someone commit identity fraud or use your account. A real employer needs them only after a signed contract | `[generic]` known pattern for fake-job scams | Why does payroll need my passport and PPS number before I have a contract, and can I provide them after signing? | unresolved |
| RR2 | Candidate asked to pay €349 | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | Legitimate employers don't charge hires for equipment. The "refund" is the hook | `[generic]` known pattern | Why can't the company supply equipment directly, and where is this fee in a written contract? | unresolved |
| RR3 | Cheque to lodge, then funds forwarded | red_flag | high | "keep €350 as a welcome bonus and transfer the rest to our equipment partner" | The cheque may bounce days or weeks after the bank credits it, and you could owe the bank the money you forwarded | `[generic]` fake-cheque pattern | Why would the company send me €2,850 to forward €2,500 to a third party when the kit costs €349? | unresolved |
| RR4 | Telegram-only hiring, with an offer after a chat | risk_signal | medium | "no calls or video interviews" | Taken alone it could be a remote-first style, so I rate it medium. Combined with RR1–RR3 it removes any chance to verify the people | `[inferred]` from the posting and messages together | Can I have a video call with a named manager and the team? | unresolved |
| RR5 | Contact via an anonymous handle and a non-company email | risk_signal | medium | "email velloway.hr@postmail.example" | The address isn't on a Velloway domain, so it can't be tied to the company | `[grounded]` address as written | Can you write from a company-domain address and give the company's registered number? | unresolved |
| RR6 | Employer not established | unknown | — | "Velloway Logistics" | No search was run, so the company's existence, or whether its name is being borrowed, is unchecked | `[generic]` standing check, not a finding | Where is this role on your own careers site, and under what registered company name? | unresolved |
| RR7 | Pay vague | unknown | — | "up to €26 an hour plus commission" | Commission and the actual rate aren't stated | `[grounded]` posting | What is the guaranteed hourly rate and how is commission calculated? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't send the IBAN, PPS number or passport photo, and don't paste the IBAN you have ready | RR1; together these enable identity fraud | `[grounded]` RR1 | proposed |
| A2 | Don't pay the €349. If a cheque arrives, don't lodge it or transfer anything | RR2, RR3 | `[grounded]` RR2, RR3 | proposed |
| A3 | Stop replying, block @VellowayHiring, and report the account and the posting to the jobs site and to Telegram | Protects other applicants | `[generic]` standard practice | proposed |
| A4 | Keep the messages as they are, in case anything else is sent or a cheque arrives | Useful to your bank or An Garda Síochána | `[generic]` standard practice | proposed |
| A5 | Look for real coordinator or customer-operations roles on employers' own careers pages. Your Zendesk volume, trainer experience and Excel tracker are the evidence | R2–R4 | `[grounded]` your account | proposed |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | The posting and messages already fix the decision. A real "Velloway" would not clear RR1–RR3, since a scammer can borrow a real name. It would have moved RR6 only |
| 2. Role-family sweep | skipped | It cannot change `no_go`. It would have added a market band for the pay claim |
| 3. Hiring manager's public footprint | n/a | No manager name was given |

I haven't passed any ID or IBAN into a tool, and I won't use one. You don't need to share those with me either.

I can write all of this up as `tuesday-dossier.md` whenever you like.

**Upgrade menu**
- A link to the live posting, or the company's own careers page → settles RR6.
- A registered company number or the email's full headers → confirm or rule out whether the name is being borrowed.
- A role-family search → adds a pay band for this kind of work.

**Questions**
1. (RR1) Have you given them anything beyond your interview answers, such as your full name, address, phone number or CV?
2. (RR6) Which jobs site was the posting on? That tells you where to report it.

Answer here, paste details, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.