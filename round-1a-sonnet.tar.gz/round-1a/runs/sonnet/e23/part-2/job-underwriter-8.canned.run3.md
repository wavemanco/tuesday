I'm checking whether Velloway Logistics exists, and what an order-processing job like this normally pays. Then I'll give you the full assessment.
# Job underwriting: "Remote Order Processing Coordinator", Velloway Logistics

## Decision snapshot

**No, don't go ahead, and don't send the IBAN, PPS number or passport photo. Status: `no_go`.**

This pattern is a known scam: an advance fee, ID harvesting and a fake cheque. You haven't sent anything yet, so you've lost nothing.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Income of at least €30,000 a year)
- `must_have` — direct: R2, R3, R4
- `important` — unclear: R5 (A quiet place to work)

**Opportunity ledger.** The role fails on its own merits, whatever your fit. Three things are demanded before any real hiring step: payment, identity documents and a cheque to be forwarded (RR1, RR2, RR3). The employer is also not established (RR5).

- **Hard gates:** unconfirmed: R1 (Income of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR5 (`severity: high`).
- **Reason for `no_go`:** confirmed severe red flags (RR1, RR2, RR3), per the decision rules.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics"; a search returned no results, so existence is not established | `[grounded]` search "Velloway Logistics", empty |
| Mandate | Process orders from home, 15–30 hours a week, "set your own hours" | `[grounded]` posting |
| Pay | "Up to €26 an hour plus commission". Reaching €30,000 a year takes about 22 hours a week, every week, at the maximum rate. The "up to" wording means that is a ceiling, not an offer | `[inferred]` arithmetic from the posting's figures |
| Hiring process | Telegram only, no calls or video. A free-mail-style address (postmail.example) is given for "HR" | `[grounded]` posting and messages |
| Market calibration | Not established. The pay search returned nothing, so there is no band for this title | `[generic]` nothing found |
| Unknowns | Employer's legal entity, address, contract type, who "payroll" is | — |
| Contradictions | A "passed first screening" and "passed the interview" with no named interviewer and no questions about your experience. You said the chat only asked questions, with no role-specific assessment | `[grounded]` your messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Your floor: €30,000 a year | hard_gate | unclear | high | hard_gate | Confidence grades your stated constraint. Fit is unclear because pay is "up to €26" and hours are 15–30; €30k needs the top rate at about 22 hours or more every week | `[inferred]` arithmetic; `[grounded]` your stated floor | Moot given `no_go`; see RR4 |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day for 3 years is specific, relevant work. It is your own account, with no artifact | `[grounded]` your background | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You maintain your team's weekly Excel tracker | `[grounded]` your background | none |
| R4 | Good written English | must_have | direct | medium | none | Written ticket replies daily, and you trained two new starters | `[grounded]` your background | none |
| R5 | A quiet place to work | important | unclear | low | discovery | Not covered in what you shared | `[grounded]` silence | none; moot |

You'd meet the stated requirements, which is part of why this works as bait. Fit doesn't offset the red flags.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against your floor (R1, hard_gate) | hard_gate | "Up to €26" with no guaranteed rate or hours | A real offer would need a stated rate and contract before this could be tested | A written contract naming the employer, rate and minimum hours | A contract from a verifiable registered employer | `[inferred]` from the posting's wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Upfront payment demanded before any work | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | Advance-fee scam. Real employers don't ask applicants to pay, and the "refund with first wages" never arrives | `[generic]` common job-scam pattern, not a claim proven about this sender | Which registered company is the "equipment partner", and why can't you ship the kit or pay me first? | unresolved; do not pay |
| RR2 | ID documents requested before an interview | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport" | Identity-theft harvesting. Payroll details come after a signed contract, not before screening | `[generic]` common job-scam pattern | Where is the signed contract, naming the employer, that justifies collecting a PPS number? | unresolved; do not send |
| RR3 | Cheque overpayment: you lodge a cheque and forward most of it | red_flag | high | "keep €350 as a welcome bonus and transfer the rest" | The cheque is likely counterfeit or will be recalled. Your bank can reverse the credit after you've sent real money, leaving you liable, and you could be used as a money mule | `[generic]` common cheque-overpayment scam pattern | Why would an employer send more than any equipment cost and ask me to forward the difference? | unresolved; do not lodge or transfer |
| RR4 | Pay is "up to" with commission and open hours | risk_signal | medium | "Earn up to €26 an hour plus commission" | Headline pay is bait; a real offer would state a rate and minimum hours | `[inferred]` from the posting's wording | What is the guaranteed hourly rate and weekly hours? | unresolved |
| RR5 | Employer not established | risk_signal | high | "Velloway Logistics" | No web presence found, and it combines with the payment, ID and free-mail flags, which raises severity | `[grounded]` empty search, combined with the other flags | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Telegram-only hiring, no calls, a free-mail address | risk_signal | medium | "no calls or video interviews" | Avoids traceability and identity checks | `[generic]` common pattern | Can we do a video call with a named hiring manager? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send no IBAN, PPS number or passport photo, and make no payment. If a cheque arrives, don't lodge it | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | Stop replying and block @VellowayHiring. Keep the chat screenshots first, as evidence | Silence is safe; engaging gives them more to work with | `[generic]` common advice | pending your approval |
| A3 | Report the posting to the jobs site, and the contact to An Garda Síochána and the Telegram report function. If you ever share details or send money, call your bank straight away | Reports help the next applicant and your own case | `[generic]` common advice | pending your approval |
| A4 | Check any replacement role by finding the employer's own website, registered company details and a named recruiter before sharing documents. Your Zendesk, Excel and training experience fits real customer-service and order-processing jobs, and I can help draft truthful CV lines | Your background is the asset, not this posting | `[inferred]` from your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics"; empty, so not established. Moved RR5 and role reality's organization row |
| 2. Role-family sweep | yes | Searched "remote order processing job Telegram cheque overpayment equipment fee scam Ireland"; empty. Moved nothing, so no market band; scam patterns above are `[generic]` |
| 3. Hiring manager's public footprint | n/a | Only a Telegram handle was given, not a name, so there was no query to form |

I'll write this up as `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- The jobs-site link → can confirm whether the posting is live and consistent, and supports your report.
- Any message that includes names, addresses, phone numbers or payment details → lets me check what the sender already holds.
- A deeper pass on Velloway Logistics and the handle (up to 5 more searches and 2 more fetches) → say the word and it runs.

## Questions

1. (RR2) Besides your answers to their interview questions, did you give them anything identifying, such as your full name, address, phone number or email?
2. (RR5) Which jobs site was the posting on, and can you paste the link?
3. (A4) Do you want me to look at what real roles pay against your €30,000 floor?

Answer in text, paste a transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.