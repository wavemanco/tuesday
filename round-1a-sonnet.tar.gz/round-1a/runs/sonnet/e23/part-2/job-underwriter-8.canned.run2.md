Quick status: the skill's reference files are read. Next I'll run two web checks on whether Velloway Logistics exists, then write up the assessment.
**No, don't go ahead. Three register entries rate `severity: high` (RR1, RR2, RR5), and together they match the standard fake-job, fake-cheque scam. Status: `no_go`.** Don't send your IBAN, PPS number or passport photo. Don't pay the €349. If the cheque arrives, don't lodge it or transfer anything out of it.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Pay of at least €30,000 a year)
- `must_have`: direct: R2, R3, R4 · unclear: R5 (A quiet place to work)

Your fit isn't the problem. The employer is: the posting and the messages show payment demands and a cheque-forwarding step (RR1, RR2), which no fit makes safe.

**Opportunity ledger.** The register holds an upfront fee (RR1), a cheque you would forward part of (RR2), identity documents requested before any interview (RR3) and an employer I could not establish (RR5). It also holds a Telegram-only process (RR4) and unstated base pay (RR6), and I found no positive signals.

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR5 (`severity: high`)
- **What would change this:** Velloway would have to be verifiably a real, registered employer. It would have to hire through a channel you can check independently, state base pay and guaranteed hours in writing, and never ask you to pay or forward money. No wording on my side can fix that.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics". The one search on the name and handle returned no results, so I could not attribute it to a real entity | `[grounded]` search returned nothing; not established |
| Role | Remote Order Processing Coordinator, 15–30 hours a week, "up to €26 an hour plus commission" | `[grounded]` posting |
| Pay structure | Only a ceiling hourly figure is given. Base rate and commission rate are not stated | `[grounded]` posting |
| Hiring process | Telegram only, no calls or video | `[grounded]` posting |
| First-year outcomes | None stated | `[grounded]` posting silent |
| Market calibration | Irish order-processing and customer-operations coordinators: median base €31,200 a year, interquartile range €28,400–€34,100, salaried roles only. At 40 hours a week, €26 an hour is €54,080 a year, well above that range for a "no experience needed" role. It is a ceiling with no stated base, so I treat it as a mismatch signal rather than an offer | `[generic]` salary guide, 2026 Ireland; `[inferred]` annualisation |
| Unknowns | Who the employer is, base pay, commission rate, employment status, who "payroll" is | — |
| Contradictions | The posting's requirements list never mentions buying equipment. The €349 "work kit" appears only in the chat, after you "passed screening" | `[grounded]` posting against the chat messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your non-negotiable) | hard_gate | unclear | high | hard_gate | Confidence grades your stated floor. Fit is unclear because the posting gives only a ceiling rate and variable hours. At €26 an hour the floor needs about 22 hours a week every week (30,000 ÷ 26 ÷ 52), and that is at the maximum rate | `[grounded]` your constraint and the posting; `[inferred]` arithmetic | Needs a written base rate and guaranteed hours; see G1 |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 tickets a day in Zendesk is specific, but it is self-reported with no artifact | `[grounded]` your account | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Self-reported, nothing inspected | `[grounded]` your account | none |
| R4 | Good written English | must_have | direct | medium | none | Three years of written customer replies to tickets implies it, but I have seen no samples | `[inferred]` from the ticket work | none |
| R5 | A quiet place to work | must_have | unclear | low | discovery | You haven't said | `[grounded]` not stated | none: the decision doesn't depend on it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Base pay and hours (R1, hard_gate) | hard_gate | A ceiling of €26 an hour and 15–30 hours, with no base rate, commission rate or guaranteed hours | Your €30,000 floor can't be checked without them | Not recall-based. Only the employer can supply this | A signed contract on company letterhead from an employer you have verified independently | `[grounded]` posting; `[inferred]` that the unstated terms cannot be recovered from this employer |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Applicant asked to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | Legitimate employers supply or reimburse equipment through payroll and do not ask recruits to pay a third party first. The money is likely never refunded | `[generic]` common advance-fee pattern, not proof about this sender | Which registered company is the "equipment partner", and why is it not paid by Velloway directly? | unresolved |
| RR2 | Cheque to lodge, balance to be forwarded | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | Cheques can appear as available funds before they clear. If it later bounces, the bank takes the money back from you, including the roughly €2,500 you sent on | `[generic]` fake-cheque pattern | Why would payroll send a new hire more money than owed and have them forward the balance to a third party? | unresolved |
| RR3 | Identity and bank details requested before any interview | red_flag | medium | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | Employers normally collect these after a written offer or contract. Together they enable identity fraud. Rated medium alone, but it compounds RR1 and RR2 | `[generic]` hiring sequence and fraud pattern | What contract or offer letter requires my PPS number and passport before I have an offer? | unresolved |
| RR4 | Telegram-only process, offer with no substantive assessment | risk_signal | medium | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | The "interview" may be a script to move you toward payment | `[inferred]` from the sequence in your messages | Who will I report to, and can I speak to them by phone or video before accepting? | unresolved |
| RR5 | Employer not established | risk_signal | high | "Velloway Logistics", "@VellowayHiring", "velloway.hr@postmail.example" | A name and handle with no findable footprint, plus contact from a generic mail domain rather than a company domain, may not be a real employer. Rated high because the flags above are also present | `[grounded]` the search returned nothing; `[inferred]` the domain reading | Can you point me to this role on your own website, your registered company number, and an email address at your company's domain? | unresolved |
| RR6 | Base pay withheld, only a ceiling stated | unknown | — | "Earn up to €26 an hour plus commission" | The ceiling may be bait, given the salary-guide comparison in role reality | `[inferred]` against the `[generic]` band | What is the guaranteed base hourly rate and weekly hours? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Stop replying and block the contact. Send nothing: not the IBAN, PPS number, passport photo, or the €349 | See RR1, RR3. Your IBAN plus PPS and passport is the material used for identity fraud | `[generic]` | pending your approval |
| A2 | If a cheque arrives, don't lodge it and don't transfer any money onward. Take it to your bank and ask | See RR2 | `[generic]` | pending your approval |
| A3 | Screenshot the chat, report the posting to the jobs site, and report it to your bank's fraud team and the Gardaí | A report helps stop others being caught by the same posting | `[generic]` | pending your approval |
| A4 | Redirect the search to employers you can verify. Your courier support, Zendesk, training and Excel tracking background fits order-processing and customer-operations roles, which the salary guide places around your €30,000 floor | See R2–R4 and the salary-guide band | `[inferred]` fit; `[generic]` band | pending your approval |

## Evidence status

Verified: none yet. No rows are verified claims, and no unverified leads came from earlier context.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics order processing coordinator Telegram @VellowayHiring". No results, so the employer is not established. Moved the RR5 standing entry |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator hourly pay Ireland entry level", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). Moved role reality's market calibration and RR6 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |
| Outside declared targets | yes | Searched "fake job scam Telegram cheque overpayment equipment laptop headset transfer remainder Ireland". No results. Moved nothing, so the scam-pattern claims above are `[generic]` and not sourced from this search |

I can also write this up as `tuesday-dossier.md` if you want a file to keep or hand to your bank or the Gardaí.

**Upgrade menu**

- The name of the jobs site and a link to the posting would let me check whether it is still live and whether other listings use the same handle. That would firm up RR5.
- Screenshots of the full Telegram chat would let me check RR1 to RR4 against the exact wording, including any claim of company registration.
- Any company registration number they gave would let me check RR5 properly.
- A deeper research pass on Velloway (up to 5 more searches and 2 more fetches) is available if you say the word.

**Questions**

- RR3: Did your answers in the chat include your address, phone number, date of birth, or a photo of yourself? If so, tell me what, and I'll adjust the steps above.
- RR5: Which jobs site was the posting on? If you can paste the link, I'll read it as a provided document.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.