Both searches came back empty, so I'm running one simpler role-family search. Then I'll write up the assessment.
**No. Don't go ahead, and don't send anything else.** R6, your €30,000 floor, is the only gate in play and nothing fails it. The reason is RR1, RR2 and RR3, three severe red flags (`severity: high`) that together form a known fake-job scam pattern. Status: `no_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R6 (Income of at least €30,000 a year)
- `must_have`: direct: R2, R3 · adjacent: R1 (Strong attention to detail)
- `important`: unclear: R4 (A quiet place to work)

R2 is read from your Excel tracker, R3 from your written ticket work, and R1 as an implied trait, not a shown one. Your fit is not the problem. The employer side is.

**Opportunity ledger.** The money flows are the problem: you pay out first (RR1), you move cheque funds to a third party (RR2), and you hand over identity and bank details before any contract (RR3). The process is text-only with an instant "pass" (RR4), and I couldn't establish the employer exists (RR5).

- **Hard gates:** failed: none; unconfirmed: R6 (Income of at least €30,000 a year); met: none.
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`).
- **What would change this:** a registered company you find yourself, not through their links. No upfront payment and no cheque. Passport, PPS and IBAN requested only after a signed written contract. I don't expect any of that.

**What to do now:**
- Don't send your IBAN, PPS number or passport photo. I haven't used or repeated any of them.
- Don't pay the €349.
- If the cheque arrives, don't lodge it or transfer anything.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics" is not established as a real company; a search on the name returned no results | `[grounded]` search, nothing found |
| Mandate | "Order Processing Coordinator", with no description of actual systems, volumes, clients or reporting line | `[grounded]` posting |
| Pay and hours | Up to €26/hour plus commission, 15–30 hours a week, "no experience needed" | `[grounded]` posting |
| Hiring process | Telegram only, no calls or video. Hired the same chat as a "screening" and an "interview", with no named person | `[grounded]` posting and messages |
| Contradictions | The posting mentions no equipment cost, cheque or ID collection. Those only appear in the chat, after you "passed" | `[grounded]` posting against messages |
| Scope read | A role with no named employer, systems, location or manager. The only concrete details are payment requests | `[inferred]` from what the posting and chat omit |
| Market calibration | Not run. The decision doesn't depend on a pay band | n/a |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Strong attention to detail | must_have | adjacent | low | discovery | About 60 tickets a day implies accuracy, but no error-rate or QA evidence has been shown | `[grounded]` your account, uninspected | none; the role is not worth pursuing |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel; no artifact seen | `[grounded]` your account | none |
| R3 | Good written English | must_have | direct | medium | none | Written Zendesk ticket handling at volume, plus training two starters; your messages here are clear | `[grounded]` your account | none |
| R4 | A quiet place to work | important | unclear | none | discovery | Not stated | `[grounded]` silence | none |
| R6 | Your constraint: at least €30,000 a year | hard_gate | unclear | high | hard_gate | The constraint is yours and confirmed, so confidence grades it. Fit is `unclear` because the pay is "up to €26". Reaching €30,000 needs about 22 hours a week at the top rate every week. Even 30 hours at €26 for 52 weeks is only about €40,500, and nothing says the top rate is guaranteed | `[grounded]` your constraint and the posting's figures | moot given the red flags |

R5 is deliberately unused. "No experience needed" is not a requirement.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Income floor (R6) | hard_gate | Only "up to €26/hour", no guaranteed rate or hours | A hard gate can't be fixed by wording | n/a | A written contract from a verified employer stating the rate and hours | `[grounded]` posting |
| G2 | Attention to detail (R1) | discovery | Volume stated, accuracy not | Only matters for a real version of this role | Ticket QA scores, tracker error checks | A QA score or team-lead feedback | `[inferred]` from your account |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employee asked to pay €349 up front for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | A real employer ships equipment or reimburses expenses. Taking money first is the standard advance-fee pattern | `[generic]` well-known scam pattern; `[grounded]` the request itself | Will the company ship the laptop and headset to me directly, at no cost to me? | confirmed in the messages |
| RR2 | Cheque for €2,850, keep €350, transfer the rest to a third party | red_flag | high | "keep €350 as a welcome bonus and transfer the rest to our equipment partner" | A fake or fraudulent cheque. Your bank may credit it, then reverse it days or weeks later when it bounces. The roughly €2,500 you sent would be your loss | `[generic]` overpayment and cheque-fraud pattern; `[grounded]` the instruction itself | Why would an employer send me money to forward to a supplier, instead of paying the supplier itself? | confirmed in the messages |
| RR3 | Passport photo, PPS number and IBAN requested before any contract | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport" | Collection for identity theft or to use your account for fraud. Real payroll takes these after a signed contract | `[generic]` hiring practice; `[grounded]` the request | Can I see a written contract and your company registration before I send any identity documents? | confirmed in the messages |
| RR4 | Telegram-only hiring, instant "pass", no named person | risk_signal | medium | "Our whole hiring process runs on Telegram" | A text-only flow with no accountable person makes verification and recourse impossible. Taken alone, a lower-severity flag | `[inferred]` from the process described | Who is the named hiring manager, and can we do a video call? | unresolved |
| RR5 | Employer not established | risk_signal | medium | "Velloway Logistics" | Either a non-existent company or one with no web presence | `[grounded]` name search returned nothing; `[inferred]` the contact email's domain shows no sign of being the company's own | What is your registered company number and your official website? | unresolved |
| RR6 | Pay stated only as a maximum | unknown | — | "Earn up to €26 an hour plus commission" | The guaranteed rate may be well below €26 | `[grounded]` posting | What is the guaranteed hourly rate and weekly hours in the contract? | unresolved |

No positive signals found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Stop replying. Block @VellowayHiring and don't use the email address | see RR1–RR3 | `[grounded]` register | pending your approval |
| A2 | Don't lodge the cheque, don't pay anything, don't send ID or bank details. If a cheque arrives, keep the envelope and take it to your bank | see RR2 | `[grounded]` RR2 | pending your approval |
| A3 | Report it: to your bank's fraud team, to An Garda Síochána, and via the jobs site and Telegram's report tools. If you ever shared documents, tell your bank | Helps stop others being caught | `[generic]` standard practice | pending your approval |
| A4 | Redirect your search to genuine employers. Your background suits customer-service and order-support roles at known couriers, 3PLs and e-commerce firms, with a verifiable company, a named recruiter and a video interview | Your evidence is real and sellable | `[inferred]` from R1–R3 | pending your approval |
| E1 | CV: lead with the roughly 60 tickets a day in Zendesk, training two new starters, and the weekly Excel tracker, using only those facts | Real strengths, currently scattered | `[grounded]` your account | pending your approval |

## Evidence status

Verified: none yet. These are your own statements, not inspected artifacts.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics": no results, so the employer is not established. Feeds RR5 |
| 2. Role-family sweep | skipped | A market pay band would change no row; the decision rests on RR1–RR3 |
| 3. Hiring manager's public footprint | n/a | Only a Telegram handle was given, no name |
| Un-numbered | yes | Searched "fake cheque job scam Ireland" and a longer variant: no results. Moved nothing; RR1–RR3 are labeled `[generic]` accordingly |

## Dossier offer and upgrade menu

I can write this up as `tuesday-dossier.md` if you'd like to keep it.

- The jobs site and a link to the original posting → I could check whether it's still live and report it.
- The email domain and any payment details they sent → they help your bank and the Gardaí.
- A real role's JD and the company's name → I can check it for fit and legitimacy the same way.
- A deeper research pass (up to 5 more searches and 2 more fetches) → it would not change this result.

## Questions

1. (RR1–RR3) Beyond your chat answers, have you sent them anything, such as an address, date of birth, bank details, or a payment? If so, what?
2. (A4) Do you want help finding and vetting genuine remote or hybrid roles at €30,000 or more? Is Ireland, or remote within the EU, a firm limit for you?

Answer either, or skip it; a skip counts as an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.