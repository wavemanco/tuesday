**Don't prepare for this interview. Don't pay anything or send anything yet. This email has the hallmarks of a fake-cheque scam, which is also an identity-theft attempt.**

**Why it looks like a scam**
- **Fee to get an interview.** A real employer never asks a candidate to pay a "registration fee" to be interviewed. The €95 goes to an IBAN, and the receipt is then emailed to an address that proves you paid.
- **The cheque.** They send you €1,850 for a "laptop and desk" and you forward the balance to a "vendor". The cheque will bounce days or weeks after your bank shows the funds. Whatever you sent on is your own money, and the bank will hold you liable for the cheque.
- **Passport photo and bank details before any interview.** That is enough to open accounts or take loans in your name. Genuine employers only check ID after an offer, and usually in person or through a secure HR system.
- **Pay before a "confirmed" slot.** The ad's duties are real-sounding but generic, and they probably were copied from a real posting.
- **Sending money to the "supplier" and "vendor".** Real employers buy equipment themselves or ship it directly. They don't send candidates cheques to forward on.
- **The `.example` domain.** I'm assuming this is a placeholder from your copy. If the real address is a free-mail or lookalike domain, that's another red flag.

**What to do now**
1. Don't reply, pay, or send your passport or bank details. Don't deposit any cheque if one arrives.
2. If you already sent anything, contact your bank immediately. If it was your passport, report it to An Garda Síochána and consider a fraud alert with your bank.
3. Check the company independently. Search the Companies Registration Office (CRO) for "Brennock Facilities Ltd" and look at who the directors are. Then phone a number you find yourself, not one from the email.
4. Report the email to the job site where you applied, to the Gardaí, and to the bank that holds the IBAN if you can identify it. Reporting to the National Cyber Security Centre (NCSC) is also worthwhile.
5. Keep the email as evidence.

**Your preparation isn't wasted**

I haven't built a full prep pack, because it would coach you for a conversation that probably isn't a real job. Your background fits the duties in that ad well, so it will carry into genuine admin interviews:
- **Calendars and travel:** you ran the appointment book for four physios.
- **Supplier invoices:** you chased unpaid invoices at the clinic. Be ready to say how you tracked them and what you did when they stayed unpaid.
- **Word:** a strength you can talk about.
- **Excel:** your "okay" is the likely gap. Practise a few basics (sums, filters, simple pivot tables, VLOOKUP or XLOOKUP) so you can answer honestly about what you can do now.

If you send me a real job description for a genuine role, ideally with your CV, I'll build the full pack. It would cover likely questions, answers drawn from your actual clinic experience, and a plan for the Excel gap. It would also include questions for you to ask them, including how they handle onboarding and equipment. That last one also helps you spot scams.

Three things would help me tailor it:
1. Which company and role is the genuine one?
2. Is the interview with a manager, HR, or both?
3. Do you want me to research the company beyond the job ad?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.