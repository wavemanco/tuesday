**Don't prep for this interview yet. The email has the hallmarks of a fake-cheque job scam.** I haven't built the full prep pack because there is probably no real interview behind it. Here is why:

- **Fee before the interview.** Real employers don't charge candidates an "equipment registration fee" to confirm an interview slot.
- **Passport photo and bank details before any interview.** This is what identity thieves collect. A real employer asks for ID only after a signed offer, through a proper HR system.
- **The cheque.** They send you €1,850 and ask you to forward "the balance" to a vendor. The cheque will eventually bounce, usually days or weeks after your bank first shows the funds. The money you sent on is real and gone, and you owe the bank the difference.
- **The rest of the pattern.** The invite comes straight after your application, the payment goes to a third-party "supplier", and the receipt goes to an `.example` address. A real employer buys or ships equipment itself.

**What to do now**
1. Don't pay the €95. Don't send your passport photo or bank details.
2. If you've already sent either, tell your bank today. If it was your passport, report it to An Garda Síochána and consider a credit-file alert.
3. Check the company independently, with a search for Brennock Facilities Ltd on the CRO register and its official website. Contact the company through those details, not the email's. Also check whether the job exists on their real careers page.
4. Report the email to the job board where you applied, and to An Garda Síochána's fraud line if you want to.
5. Don't deposit any cheque from them.

If Brennock turns out to be real, a legitimate employer will have no problem with this response. They'd confirm the interview with no fee, send an offer before asking for ID, and never ask you to move money on.

**Your background is good for real admin roles.** Running a four-physio appointment book and chasing unpaid invoices maps directly onto calendar management and invoice processing. If you want, I'll build a proper prep pack for a genuine role: a fit-gap map, likely questions with answers grounded in your clinic experience, and a plan for the Excel gap. For that I'd need a real job ad (or the company and title), and ideally your CV.