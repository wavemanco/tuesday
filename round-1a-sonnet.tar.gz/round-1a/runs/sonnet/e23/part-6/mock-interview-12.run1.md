Aoife, please don't prepare for this interview yet. The email has the hallmarks of a recruitment scam, and I'd stop before any money or documents leave your hands.

## Why it looks like a scam

- **A fee to get an interview.** Legitimate employers never charge candidates, and an "equipment registration fee" paid to a "supplier's account" is a standard advance-fee scam.
- **The cheque and the balance.** They send a €1,850 cheque, you deposit it and send the balance to a "vendor". This is the classic overpayment fraud. The cheque eventually bounces, often days or weeks later, and the money you sent is real and gone. You'd owe your bank the full amount.
- **Passport photo and bank details before any interview.** That is identity theft material. A real employer asks for these only after a signed offer, through a proper HR process.
- **Everything else points the same way.** The offer comes before anyone has assessed you, and it asks you to move money first. A fake-looking `.example` HR address and a "30-minute video call" with an "office manager" are only a thin cover story.

## What to do

1. **Don't pay, and don't send the passport or bank details.** If you've already sent anything, call your bank now and ask them to stop or recall it. Change any passwords you shared.
2. **Check the company independently.** Look Brennock Facilities Ltd up on the Companies Registration Office (CRO) register, and use only contact details you find yourself, not ones from the email.
3. **Report it.** In Ireland, that means the Garda National Economic Crime Bureau, or your local Garda station, and your bank. You can also report the job ad to the site where you found it.
4. Don't reply to the email, except to decline if you want to.

If the company turns out to be real, a genuine employer will confirm everything through a verifiable channel and will drop the fee and the cheque. That reply would also tell you a lot.

## Prep for a real admin interview

Your background is a good fit for the duties in the ad, so real interviews for similar roles should go well. Expect these:

- **Calendar and scheduling.** "Tell me about managing the appointment book for four physios." Prepare one concrete story: how you handled double-bookings or last-minute changes, and how you decided whose time took priority.
- **Invoices and chasing payments.** Be ready to explain your chasing process, how you stayed polite with people who were late, and what happened as a result. Quantify only what you really know.
- **Excel.** You said you're "okay with Excel". Say that plainly and say what you've actually done in it. Before the interview, practise SUM, VLOOKUP/XLOOKUP, filters, and basic formatting, because skills tests are common for admin roles.
- **Travel booking.** You may not have done much of this. Say so, and describe the nearest thing you have done, such as organising logistics or booking for patients, plus how you'd learn it quickly.
- **Remote working.** Interviewers will ask about self-management, communication and keeping to deadlines without supervision.

When you have a real role, send me the job description and CV. I'll then build the full pack with a question bank, fit gaps, honest answer guidance and questions for you to ask.

Do you want me to build one now for a real admin job you're considering? And did you send the €95 or any documents yet?