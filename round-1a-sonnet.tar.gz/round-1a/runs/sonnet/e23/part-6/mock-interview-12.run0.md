**Don't pay anything or send any documents yet. This email has the marks of a scam.** The company may be real, but this message looks like a well-known fake-job pattern.

**Red flags in the email**
- **A fee before the interview.** Real employers never charge candidates, whether it's called an "equipment registration fee" or anything else.
- **The payment goes to a "supplier's account".** A genuine company wouldn't route a candidate's money to a third party.
- **The cheque-then-forward scheme.** They send a €1,850 cheque and you send the balance to a "vendor". The cheque will bounce days later, after the bank has let you send real money. You would owe the bank that money, and the bounced cheque doesn't get you out of it.
- **A passport photo and bank details before any interview.** That is identity-theft material. No legitimate employer needs it at this stage.
- **A generic, rushed process.** You're invited to interview before anyone has discussed your CV, and the whole process is remote.
- **The `.example` email domain.** Check the real sender address and domain carefully.

**What to do**
1. Don't pay, and don't send the passport or bank details. If you already sent either, tell your bank now and ask them to freeze or flag your accounts. Consider replacing the passport and report the theft to the Gardaí.
2. Verify independently. Find Brennock Facilities Ltd in the CRO (Companies Registration Office) register. Phone the number on their official website, not one from the email. Ask whether the role exists.
3. Report it to the Gardaí and the job board where you applied, and forward the email to your email provider's phishing report.
4. Reply only if a verified contact confirms the role. A real interview invite should need nothing beyond a time slot and a video link.

**Your prep is still useful.** I'm not going to build a full company-specific pack around this invitation until the employer is verified. If it turns out to be real, or another admin interview comes up, this is what to expect for the role in the ad:

- **Calendar management.** Expect "how do you handle conflicting bookings?" You ran four physios' appointment books, so lead with that: double-bookings, cancellations, and who got priority and why.
- **Travel booking.** You haven't done this, so say so. Offer an honest bridge: you coordinated patient schedules with tight constraints, and you can learn booking tools quickly.
- **Word and Excel.** Be straightforward: strong in Word, comfortable in Excel. Practise VLOOKUP/XLOOKUP, sorting and filtering, and a simple pivot table. Interviewers often follow up on this, and a small gap you've started closing is better than a bluff.
- **Supplier invoices.** Your clinic invoice-chasing is your best evidence. Prepare one specific example: how many invoices, how you followed up, and what happened.
- **Remote working.** Be ready for "how do you stay organised and communicate without an office?" and "how do you handle an unclear request?"
- **Questions to ask them:** who you'd support, how they handle approvals on invoices, what tools they use, and what the first 90 days look like.

Use real numbers from your clinic work. Don't stretch what you did.

**Closing offers**
- Once the employer is verified, I can build the full prep pack: question banks, a fit map of the ad against your experience, and reverse questions.
- I can also run a live mock interview for the admin role.
- If you have your CV, I can map it against the ad.

Is the sender's address on a real Brennock domain, and did they contact you first or only after you applied? Either answer changes how worried you should be.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.