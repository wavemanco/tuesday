I'd hold off on prepping for this one, because it matches a well-known job scam pattern. I can't be certain it's fake, but several things line up:

- **No company or role.** The message names neither. "Jess, a recruitment consultant" doesn't say which agency or which employer. The mock-interview skill needs a company and role title to run at all, and here there's nothing to build on.
- **Unsolicited WhatsApp from an unknown number.** Real recruiters usually come through email, LinkedIn or a job board, and they can say which application or posting you're being considered for. This one just says "your profile online".
- **The whole process happens over text.** The interview, contract and onboarding are all by message, with no call or video. That's a common way to avoid being identified and to move quickly to the next step.
- **Remote, flexible hours, instant match.** That's the standard lure.
- **Pressure on timing.** Asking about "tomorrow at 11am" leaves you little time to check anything.

Many of these scams follow the same pattern. A text "interview" is followed by a quick "job offer", then a request for ID or bank details, a fee for equipment or training, or a task like receiving and forwarding payments. That's why the skill's guidance is not to hand over ID, and why I wouldn't send any.

**What I'd do before tomorrow:**
1. Reply with something like: "Thanks. Which agency and which employer is this for, and which application is it linked to? Please email me from your company address." A real recruiter answers that easily. A scammer dodges it or pushes you to hurry.
2. Look up the agency yourself. Check its website, find a switchboard number from there (not from the chat), and ask whether Jess works there.
3. Check your sent applications. If none match a role like this, that's another bad sign.
4. Don't send your CV, ID, address, bank details or a "refundable" fee. Don't click any links she sends.
5. If it turns out to be fake, block and report the number in WhatsApp.

If Jess answers with a real company, a named role and a verifiable contact, send me the job description and your CV and I'll build the full interview prep pack. If you'd like, I can also draft the verification reply for you.