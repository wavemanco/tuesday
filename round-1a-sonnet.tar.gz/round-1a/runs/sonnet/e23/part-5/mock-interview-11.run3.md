I can't build an interview prep pack from this message, and I'd hold off on the interview itself. It has several hallmarks of a recruitment scam.

**Red flags**
- **No company or role.** "A remote position with flexible hours" names neither an employer nor a job title. I need both before I can prepare you for anything, and a real recruiter would give them up front.
- **An unsolicited WhatsApp from an unknown number.** Legitimate agencies usually reach out by email or LinkedIn first, and they can tell you which application or job board they found you through.
- **Everything over text, from interview to contract.** Refusing calls or video is a classic way to avoid being identified. These scams typically end in a "task" job, a fee for equipment or training, requests for ID or bank details, or being used to move money.
- **A vague pitch and a next-day interview.** The time pressure stops you checking anything.

You may well have applied to many places, but that doesn't mean this message comes from one of them.

**What I'd do before replying**
1. Ask Jess: which company is hiring, the exact job title, the agency's name and website, and which of your applications this relates to. Ask for a video or phone call, and for an email from a company domain.
2. Check that the agency exists, using a site you find yourself rather than a link she sends. Look at Companies House or the equivalent registry, and at the recruiter's LinkedIn page and its connections.
3. Don't send a CV, ID, bank details or a National Insurance or Social Security number. Don't pay for anything, and don't install anything.
4. If the answers are evasive or she insists on WhatsApp only, block and report the number to WhatsApp. In the UK you can also report it to Action Fraud.

**If she turns out to be legitimate**
Send me the company, the role and the job description, and ideally your CV. I'll build the full prep pack and run a live practice interview. If she doesn't give you those, that tells you what you need to know.

If you'd like, I can draft a short, polite reply asking the verification questions.