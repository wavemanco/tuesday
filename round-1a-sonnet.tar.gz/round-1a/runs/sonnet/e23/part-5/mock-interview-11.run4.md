Before we prepare, I'd treat this message as a probable scam. It matches a well-known WhatsApp job fraud pattern.

**Red flags**
- **Unknown number.** It names no company, role or employer.
- **"Found your profile online."** This is generic flattery that doesn't mention anything you applied for. Real recruiters usually reference a specific job or application.
- **Remote work with flexible hours.** This is the standard bait.
- **Interview and contract all on WhatsApp, with no calls or video.** Real employers almost never do this. It lets the sender avoid being identified and rush you into signing.
- **Tomorrow at 11am.** The short notice is meant to stop you checking.

**What these scams usually do next**
- Ask for your ID, passport, bank details or National Insurance/SSN number "for the contract".
- Ask you to pay for equipment, training or a background check.
- Send you "tasks" such as liking videos or boosting products, then ask you to deposit money to unlock your pay.
- Pass you on to a "manager" and move you to Telegram.

**Before you reply, check:**
1. Which company is it? Ask for the company name, the job title and a link to the job posting.
2. Compare the details against the applications you sent. If none of them match, it didn't come from one of those.
3. Look up the company's official site and call or email them through contact details you find yourself. Don't use any the sender provides.
4. Search the recruiter's name and the company with "scam".
5. Look at the number's WhatsApp profile for a new account, a stock photo or a foreign country code.

**If you reply, don't share:**
- Your ID
- Bank details
- Your address
- Any payment

If they refuse a video or phone call, or won't name the company, that confirms it. Block and report the number in WhatsApp.

If it checks out and you get a real company, role and job description, I'll build the mock-interview prep pack for it. That includes likely questions, answer guidance and questions for you to ask them. If you'd like to rehearse in the meantime, send me one of the real roles you applied for and we can prepare for that.

Which company did they say they were with?