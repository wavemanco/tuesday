I'll load the skill. First, though, this message has several classic job-scam signs, which I'll cover once the skill is loaded.
I haven't built the prep pack, because this message looks like a job scam rather than a real interview invitation. The skill also needs a company and a role title, and this message gives neither.

**Warning signs in the message**
- **No company or role is named.** A real recruiter says who they work for and what the job is, even in a first message.
- **The whole process happens over WhatsApp.** Interview, contract and "no calls or video" is the standard setup for these scams. Real employers want to see or hear a candidate at some point.
- **The contact came from a number you don't recognise,** with a vague line about "found your profile online" and a "remote, flexible hours" role. That pattern matches task scams, fake-cheque scams and identity harvesting.
- **The interview is tomorrow at 11am.** The short deadline stops you from checking anything.
- **It could easily be unrelated to your applications.** Scammers scrape job boards and CV sites, and they rely on people who have applied widely assuming it's a reply.

**What I'd do**
1. Don't confirm the interview yet. Reply with something like: *"Thanks. Which company is the role with, what's the job title, and can you send the job description and your agency's website?"*
2. Look up the agency yourself. Check it's a registered company and that its website and LinkedIn page are real. Find a contact number from the agency's own website, not from the chat.
3. Check your sent applications and emails for any company that matches.
4. Never send your ID, passport, bank details or a payment. Don't buy equipment, pay "onboarding" fees, or accept money you're asked to forward or return. A legitimate employer does none of these.
5. If they dodge the questions or push for urgency, block and report the number on WhatsApp.

**If it turns out to be real**
Once they name the company and role, send me that and the job description if you have it. Add your CV if you're happy to share it. I'll build the full mock-interview pack for you, and the text-only format is easy to rehearse for. If you'd like, paste their reply to your questions here and I'll help you read it.