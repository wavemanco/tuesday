Before we prep, I'd treat this message as a likely scam. I can't build a pack for it either, because there's no company or role to prepare for.

**Red flags in the message**
- **No company or role named.** A genuine recruiter says who the client is, or at least the job title and sector.
- **"Found your profile online."** This is generic, and it doesn't reference any application you sent.
- **Everything is done over WhatsApp, with no calls or video.** This is the classic fake-recruiter pattern. It avoids anything that could be traced or verified.
- **The contract is signed by message.** Legitimate employers don't do this without a real interview.
- **Unknown number, a vague "remote, flexible hours" role, and a next-day deadline.** The urgency is meant to stop you checking.

You may have applied to many places, but that doesn't make this a reply to one of them. Scammers rely on that assumption.

**What to do before tomorrow**
1. **Don't share anything sensitive.** That means ID, passport, bank details, National Insurance or SSN, or "onboarding" documents. Don't pay for equipment, training or background checks, and don't click any links.
2. **Ask Jess for specifics.** Ask for the company name, the job title, the job posting link, her agency's name and her work email. Ask for a video or phone interview instead, since a real recruiter will accept that.
3. **Verify her.** Search the agency's website and call its main number yourself. Check whether Jess has a LinkedIn profile that matches the agency. Check the job on the company's own careers page.
4. **If she dodges or pushes,** block and report the number in WhatsApp. If you've lost money or shared details, report it to your national fraud service (Action Fraud in the UK, FTC in the US).

A reply you could send:

> Thanks Jess. Before I confirm, could you tell me the company, the role title, and send the job description? Also your agency's name and work email. I'm happy to do a video or phone interview tomorrow.

**If it turns out to be real**, send me the company, the role title, the job description if you have it, and your CV. I'll build the full prep pack from those.

Do you want help checking whether the number or agency is legitimate, or should I tidy up that reply?