I'm still reading the skill's reference rules, which cover research tiers, privacy and how the pack must be shaped. Then I'll build your prep pack.
I'm running a last check on the saved pack for stray brackets, and I'm taking the note about your ID numbers out of the file. The file may get shared, and the note belongs in my message instead.
Your prep pack is saved as `Orrinsford_fourth-grade-teacher_interview_pack.md`. I built it for a panel with Principal Vantongeren in the hiring-manager seat and the two fourth-grade teachers as peers. It has 20 practice questions, six reverse questions to ask them, and a list of claims I won't coach you to make.

Your résumé text included a Social Security number. I didn't use it and it's not in the pack, because interview prep doesn't need it. I'd remove it, and the educator ID number, from anything you send an employer.

Your licence line already meets the invite's requirement, so I treated it as met.

The biggest rehearsal priority is question A1: "You've taught third grade, but never fourth. What will be the hardest part of your first month?" The pack coaches you to say "I've never taught fourth grade," then say what you did teach, and stop.

The district's hiring page says the panel asks about reading instruction, classroom routines and working with families. Your material is thinnest on routines, so write your own answers to those slots before Thursday.

I found the district's three published beliefs, the principal's background as a reading specialist, and an August 2026 literacy plan. That plan includes a new grades 3–5 reading curriculum from fall 2027, which connects directly to the curriculum move you led in 2024. I only saw a snippet of the literacy-plan page and didn't open it, so check it before Thursday.

Say the word and I'll play the skeptical panelist on A1, the question the pack names as your highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Two things would change the pack. Can you paste the full job posting, if there is one? And did HR mention a demo lesson or written task, or tell you who the two fourth-grade teachers are?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Orrinsford_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

- Round: one 45-minute panel on Thursday
- Panel: Principal Dolores Vantongeren and two members of the fourth-grade team (names and roles not given)
- Built on this assumption: the principal sits in the hiring-manager seat and the two teammates in the peer seat, so the panel blends those two relationships

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs |
| EXP | Whether what you say about your experience survives follow-up questions |
| JD | Whether you can do the role as described, including its gaps |
| CO | How well you know the district's current direction |
| CASE | How you reason through a live classroom problem |

Quotes in the fit snapshot and in the Provenance column are your own sentences. Anything the pack writes for you to say is one of those sentences, a plain acknowledgment of something you stated, or an answer slot: a place where only your own account can fill in the answer. Provenance labels: grounded means traceable to your documents or to cited research, inferred means derived from a representative source, generic means a pattern with no claim about you or this district.

## Prep triage

The panel is Thursday. In order:

1. Say A1 aloud until the plain acknowledgment and the one sentence behind it come out without padding. It is the question most likely to be asked in some form.
2. Say A2 and A5 aloud, then B1. They all rest on the same curriculum sentence, so rehearse them together, staying inside that sentence.
3. Say the E1 arc once at 90 seconds.
4. Write down your own answers to the answer slots in F3, F4 and F5 below. They are where the panel's published topics meet gaps in what your material shows.
5. Pick two reverse questions from the reverse list, including R1.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — interview invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The gate is shown met by your CV line, and the grades range you wrote includes grade 4. The line has nothing inspected behind it, so expect the panel to confirm it against the record. Say it in the line's own terms: Illinois Professional Educator License, Elementary Education (grades 1–6) endorsement, active through June 30, 2029 |
| F2 | "Fourth Grade Teacher position" — interview invite | "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [grounded] | transferability | Your material says third grade, not fourth, and the words stay there: "I've never taught fourth grade." Then: "For six years I taught third grade at a public elementary school in Joliet." Answer slot: if any part of fourth grade is already familiar to you from any source, say which part and where it comes from, in your own words; if none is, say so plainly and name the first thing you would learn |
| F3 | "Panels ask about reading instruction, classroom routines and how you work with families." — Orrinsford "How we hire teachers" page (reading instruction) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | transferability | Your material carries a curriculum move and a club, not how you teach reading in class, and the words stay at those scopes: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: the page lists reading instruction as a panel topic, so expect a probe on how you teach reading; if you can say how you teach it, say so in your own words; if your reading work has mostly been the move and the club, say so plainly and stay with those |
| F4 | "Panels ask about reading instruction, classroom routines and how you work with families." — Orrinsford "How we hire teachers" page (classroom routines) | none given | none | [grounded] | discovery | The pack's observation is that your material does not show your routines. Answer slot: the page lists classroom routines as a panel topic; if you can say which routines you run and why, say so in your own words; if you have not set them out before, say so plainly and say how you would set them in a fourth-grade room |
| F5 | "how you work with families" — Orrinsford "How we hire teachers" page; "each teacher speaks with every family each term" — Orrinsford "Mission and Beliefs" page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | Your sentence is an email and the published belief is a conversation each term; that is the pack's observation. Words: "I write a weekly email to families." Answer slot: if you have also spoken with families, say how and how often in your own words; if the email is the main channel, say so plainly and say how you would meet the each-term expectation |
| F6 | work with the grade-level team, from a representative posting on a jobs board; the invite names "two members of our fourth-grade team" on the panel | "I've never been a team lead." — your message; "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | transferability | Plain acknowledgment: "I've never been a team lead." Then the sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: expect a follow-up on what leading the move meant day to day; if part of it was yours to decide, say which part, in your own words; if your share was smaller than "led" suggests, say so plainly and stay with the sentence |
| F7 | teach across subjects beyond reading, from a representative posting on a jobs board | none given | none | [inferred] | discovery | The posting is another employer's, so the panel may not ask this. Answer slot: if you have taught subjects beyond reading, say which, in your own words; if not, say so plainly and say which you would want support with first |
| F8 | "assessments inform teaching and never replace it" — Orrinsford "Mission and Beliefs" page | none given | none | [grounded] | discovery | The pack's observation is that your material does not show assessment work. Answer slot: if you have used assessment information to change what you taught, say one instance in your own words; if not, say so plainly and say what you would look at first |

## Reading the interviewer

Public professional footprint only. Nothing is known about the two teammates beyond the invite.

| Fact | Source | Provenance | Implication for you |
|---|---|---|---|
| Principal of Halvering Elementary since 2022, after nine years as a reading specialist | ilprincipalsforum.example speaker page (search result snippet) | [grounded] | Reading instruction questions from her may go deeper than from a generalist. Describe your reading work at the scope of your own sentences and let her probe |
| Gave a 2025 forum talk, Small Groups, Big Readers, covering weekly reading conferences in grades 3 to 5 | ilprincipalsforum.example speaker page (search result snippet) | [grounded] | A probe on small-group reading is plausible. Do not borrow the talk's phrases. If you have a view of small-group reading, say it in your own words, and use R1 to ask about it |
| Mirror opportunity: reading is shared ground, not a shared career jump. Pair her path with your own sentence from F3 | F3 evidence | [grounded] | The sentence to use is "I've run the after-school reading club for the last two years." Say it at that scope and do not suggest it equals her specialist work |
| Two members of the fourth-grade team sit on the panel, names and roles not given | Your invite | [grounded] | Treat them as peers who will work beside you. Ask HR for names and roles if you can, and see the upgrade menu |

## Persona table

The loop is documented: one 45-minute building panel of the principal and two grade-level teachers, with topics of reading instruction, classroom routines and families (Orrinsford "How we hire teachers" page). Per the panel blend rule, the principal takes the hiring-manager personas and the two teammates take the peer personas, then your stated gaps adjust the weights.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent questions about fourth grade and team leadership | high: you stated both gaps yourself, and the role title names fourth grade | Rehearse the single most predictable objection until it is boring; plain acknowledgment plus your sentence at its own scope, then a plan |
| Peer Evaluator | Teammates asking about the seam between your room and theirs, and about credit | high: two of the three panelists are teammates who will work beside you | Reciprocity framing: say what you would offer them and what you would ask for; propose principles for the seam rather than pretending to know it |
| Case/Strategist | A live reading or routines problem, and the district's literacy plan | medium: the principal sits in the hiring-manager seat and the panel topics are practical classroom ones | Clarify first, then objective, approach and how you would know it is working; think aloud |
| Values/Behavioral | Questions mapped to the district's three published beliefs | medium: the district says the beliefs guide every hire, though its hiring page names no values round | Pick the true story where one exists and use the honest branch where none does |
| Conversational | The opening "tell us about yourself" and warm follow-ups | medium: panels open this way and the casual register is still scored | Rehearse the 90-second arc; treat casual questions as scored |
| Data-Driven Prober | Follow-ups on how you knew the curriculum move worked | low: your CV carries no figures to defend, and the probes that remain are about method | Say plainly what you do and do not know about how things were tracked |
| Pressure | Time-boxed or devil's-advocate challenges | low: nothing documents a stress format, so there is no bank; hold-then-concede is built into A1 and A5 | Pause, restate the question, hold through two follow-ups, then concede specifically |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years but never fourth. What will be the hardest part of your first month?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I've never taught fourth grade." Then the sentence at its own scope: "For six years I taught third grade at a public elementary school in Joliet." Name the hardest part from your own sense of it and say how you would close it as a plan, never as something already done. First follow-up, that this is a big step: hold by returning to those two sentences. Second follow-up, on what makes you ready: concede the limit once, specifically, that you have not taught fourth grade, and stop; add no fourth-grade knowledge you do not have. Answer slot: if any part of fourth grade is already familiar to you from any source, say which and where it comes from; if none is, say so plainly and name the first thing you would learn | F2 is the largest stated gap and the role title names the grade, so this objection arrives in some form. JD because it scores the role's stated grade level, delivered with Skeptic quiet persistence |
| A2 | "You haven't been a team lead. How would you fit into a fourth-grade team as a newer member?" | EXP | [grounded] "I've never been a team lead." "I led our grade level's move to a new reading curriculum in 2024" | Plain acknowledgment: "I've never been a team lead." Then the sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Say the sentence and stop; let the panel decide what it shows. Answer slot: expect a follow-up on what leading the move meant day to day; if part of it was yours to decide, say which part, in your own words; if your share was smaller than "led" suggests, say so plainly and stay with the sentence. For how you would fit in, describe how you would work with the team as a plan, not as a past | F6 holds the stated team-lead limit, and two teammates on the panel make it likely to come up. EXP because it tests what was actually yours |
| A3 | "Why fourth grade, and why now?" | JD | [generic] | Your reasons are yours and the material does not show them, so this is an answer slot: say in your own words what draws you to this role and this school; if part of the reason is wanting a change from third grade, say so plainly. If one of the district's published beliefs or its literacy plan is part of why, say so; if not, do not borrow it | F2 is the gap that makes motivation questions likely; JD because it scores fit with the stated role. Generic because it makes no claim about you or the district |
| A4 | "Your teaching has been in third grade and your reading club is after school. What makes you think that carries into a fourth-grade classroom?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've run the after-school reading club for the last two years." | Say each sentence at its own scope, then stop. Answer slot: say what you expect to carry over and what you expect to differ, in your own words; if you cannot yet say what would differ, say so plainly. Do not tell the panel what your work proves | F2 and F3 are both transferability rows: adjacent work whose limits the panel will test. EXP because it checks how far your stated experience reaches |
| A5 | "How much of the reading-curriculum move was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold-then-concede. Hold: say the sentence at its own scope. First follow-up: say your part within the word "led". Second follow-up: concede specifically what you cannot claim. Answer slot: if any part of the move was yours to decide, say which part, in your own words; if none was, say so plainly and stay with leading your grade level's move. Do not describe choosing or writing the curriculum | F3 and F6 both rest on this one sentence, so it is the likeliest to be pressed. EXP because it tests attribution |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell us about the move your grade level made to a new reading curriculum." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on F3 using only the beats the sentence states: your grade level, the new reading curriculum, 2024, and that you led. Tell them in order, in your own words, with "we" for the grade level and "I" only for the leading the sentence states. Answer slot: say what your part was, in your own words; if part of it belonged to someone else, say so plainly | Teammates price what a hire adds to their own work; F3 is the evidence they can test. EXP because it tests what was actually yours |
| B2 | "How do you handle credit when work spans a grade level?" | JD | [generic] | Selection scaffold: pick a time work was shared across a team that you can describe with a named share, what you said about who did what, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6 is the teamwork requirement, and credit questions are a standard peer probe. Generic because it names no event |
| B3 | "What would you bring to a team like ours, and what would you want from us in your first month?" | JD | [grounded] "I've run the after-school reading club for the last two years." "I write a weekly email to families." | Reciprocity framing. Offer the two sentences at their own scope and do not say what they achieved. Answer slot: say what you would want from the team in your first month, in your own words; if you do not yet know, say what you would ask them | The peer persona scores whether you reduce or add to their load; F3 and F5 supply what you can honestly offer |
| B4 | "Two of us run our rooms differently. Where's the line between your classroom routines and the team's way, and what happens when we disagree?" | CASE | [generic] | Offer principles, not a claim about this team's seam: what you would keep as yours, what you would align on and why, and how you would raise a disagreement. Say it as your view and as a plan. If you have not faced this exact call, say so plainly and say how you would approach it | F4 and F6 meet here: routines are a published panel topic and teamwork is the peer's concern. CASE because it is a live situation in the role |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader is reading well below the rest of the class partway through the year. What do you do first?" | CASE | [generic] | Think aloud in order: what you would want to know first and from whom, what you are aiming for, what you would try, how you would know it is working, and how you would keep the family in the loop. Challenge one premise politely, for example what below grade level is measured against. It asks about no past, so the guidance makes no claim about yours | Reading instruction is a published panel topic (F3). CASE because the question asks for structure and reasoning on a problem from the role |
| C2 | "Our board adopted a literacy plan this August, with a new reading curriculum for grades 3 to 5 from fall 2027. What does that mean for a fourth-grade teacher?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say what you know of the plan in your own words and what you would ask, rather than reciting it. Then say the sentence once at its own scope and let the panel draw the link. Answer slot: if part of your experience of that move bears on what a new curriculum asks of teachers, say it in your own words; if none does, say what you would ask first | The plan is current and specific to this district, which most candidates will not touch. F3 holds your nearest evidence. Source is a search result snippet; the page itself was not opened, so check it before Thursday |
| C3 | "It's the second week of school. Walk us through the first hour of the day with your class." | CASE | [generic] | Routines are a published panel topic and nothing in your material shows yours, so build this from your own practice. Answer slot: say which routines you would want running and why, in your own words; if some come from your six years in third grade, say which; if you would build fresh for fourth grade, say so plainly | F4 is the row with no evidence and a named panel topic. CASE because it asks you to describe a room in action |
| C4 | "Fourth grade covers more than reading. Which subject would you want the most support in at first?" | JD | [inferred] a representative posting lists reading, writing, math, science and social studies; its source is a jobs-board search result, not this district | Honest self-assessment: pick the one that is true and say what support you would seek, as a plan. Answer slot: if you have taught subjects beyond reading, say which, in your own words; if not, say so plainly | F7 is derived from another employer's posting, so this is a lower-probability question. Inferred because the posting is not this district's |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our first belief is Every Child a Reader. Tell us about a time you helped a student who wasn't yet reading well." | VAL | [grounded] "I've run the after-school reading club for the last two years." | Selection scaffold: pick one student or moment where you can name what was at stake, what you did and what changed. The nearest thing your material carries is the club, so the sentence is available at its own scope. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The belief is published on the district's mission page and its first words are about reading (F3). VAL because it scores a named belief |
| D2 | "Families Are Partners. Tell us about a time you worked with a family to help a child." | VAL | [grounded] "I write a weekly email to families." | Selection scaffold: a named child or situation, what you did, and the relationship afterwards. The nearest thing your material carries is "I write a weekly email to families." The belief names a conversation each term, so if you have spoken with families one to one, say how often and about what, in your own words. If no such time comes to mind, say so plainly and say how you would meet the expectation | F5 is the row where the belief and your sentence do not quite match; this rehearses saying so without flinching. VAL because it scores a published belief |
| D3 | "Teach for Tomorrow, Not for the Test. Tell us about a time an assessment changed what you taught." | VAL | [grounded] | Selection scaffold: one assessment, what it showed, what you changed. Say only what you can stand behind under a second question. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F8 has no evidence, and the belief is on the district's published page. The label stands alone because the guidance makes no claim about your past |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through your journey." | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." "I write a weekly email to families." | A 90-second arc, one clause per sentence, in this order: the licence and endorsement, the six years in third grade, the curriculum move, the club, the weekly email. Each at its own scope, in your own words. Close with why this role, which is an answer slot: say it in your own words, and if you do not yet have a clear reason, say what you would want to learn from this panel | The opener is scored, and the arc lets you say your strongest true sentences before the harder questions arrive. F1 to F6 all draw on it |
| E2 | "What are you reading with your club these days?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Answer slot: name one book you are actually using with your club and say why, in your own words; if you cannot name one, say so plainly and say what you would choose first | A casual question about a hot panel topic (reading) is still scored, and it checks that the club is real to you (F3) |

### F. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "How did your grade level know the new curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if your grade level tracked anything, say what was tracked and how it was counted, in your own words; if nothing was tracked, or tracking was not yours, say so plainly and return to the sentence. Say plainly what you do not know about how it was counted | The district's belief that assessments inform teaching (F8) makes this a plausible probe of F3. EXP because it tests what you know about your own claim |
| F2 | "What does a session of your after-school reading club look like?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Use only the sentence's beats: after school, a reading club, the last two years. Answer slot: describe a session only from your own running of it, in your own words; if sessions are informal or someone else sets them, say so plainly | F3 rests partly on the club, and a probing panelist asks for the detail behind it |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 licence | — none, and why: the gate is shown met by your CV line, and the panel will confirm it rather than ask about it; E1 says it once |
| F2 fourth grade | A1, A3, A4, E1 |
| F3 reading instruction | A5, B1, C1, C2, D1, E2, F1, F2 |
| F4 classroom routines | B4, C3 |
| F5 families | D2, E1 |
| F6 grade-level team | A2, B1, B2, B3, B4 |
| F7 other subjects | C4 |
| F8 assessments | D3, F1 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. How does that shape what you look for in fourth-grade reading instruction?" | It ties to the principal's own path and shows you read about her, not only the district | [grounded] |
| R2 | "How do fourth-grade teachers here organize small-group reading, and where would a new teacher start?" | It follows the topic of the principal's public talk without borrowing its words, and asks about your first weeks | [grounded] |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for the two teammates; it frames you as adding to their work | [generic] |
| R4 | "How do teachers meet the each-term family conversation in practice, and how do fourth-grade teachers split that work with the team?" | It shows you read the published belief and links to F5 | [grounded] |
| R5 | "How is the new grades 3 to 5 reading curriculum from fall 2027 expected to change fourth grade between now and then?" | It uses current district news and tests whether your C2 homework holds up | [grounded] |
| R6 | "The hiring page says references come after the panel. What is the timeline from here?" | A practical close that uses the published process | [grounded] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or knows fourth-grade content from teaching it | Negative you stated, F2 | The plain acknowledgment: "I've never taught fourth grade." Then "For six years I taught third grade at a public elementary school in Joliet." |
| Has been a team lead, or led the fourth-grade team | Negative you stated, F6 | The plain acknowledgment: "I've never been a team lead." |
| Designed, chose or wrote the new reading curriculum | Inflated form of F3 and F6 | The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024". The limit is the pack's observation: your sentence says the move, not what the curriculum was or who chose it. A5's slot stays inside the word "led" |
| Spoke with every family each term | Inflated form of F5 | The quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: your sentence is an email, not a conversation. D2's slot asks only whether you have also spoken with families |

## Sources

Provided documents: the interview invite and your résumé text.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

Searches sent:

- "Orrinsford Community School District values mission" returned https://orrinsfordschools.example/about/mission-and-beliefs
- "Halvering Elementary School Orrinsford principal Dolores Vantongeren" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "Orrinsford Community School District hiring interview process teacher" returned https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Orrinsford Community School District news strategic plan" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "fourth grade teacher job description Illinois elementary responsibilities" returned https://k12jobsboard.example/listings/fourth-grade-teacher

Pages fetched: the mission-and-beliefs page and the how-we-hire-teachers page above. The principal's speaker page, the literacy-plan news item and the jobs-board listing were read as search result snippets only; the listing's snippet was cut off.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | The three published beliefs and the D bank; no values cheat sheet, because the hiring page names no values round |
| 2. Orrinsford interview process | yes | Loop structure: one 45-minute panel, three panelists, three topics; persona weights follow it |
| 3. Orrinsford strategy and recent news | yes | C2 and R5, from the August 2026 literacy plan; page not opened |
| 4. Principal Dolores Vantongeren | yes | The interviewer read, R1 and R2 |
| 5. Representative fourth grade teacher posting | yes | F6 and F7, labeled inferred, and C4; the snippet was cut off, so little came from it |

## Upgrade menu

- The posting's own text: F6 and F7 move from inferred to grounded, and the JD-tagged questions are rechecked against its list
- The recruiter's prep notes, including whether a demo lesson or written task is expected: any announced deliverable gets its own build section, and coverage stops resting on the hiring page alone
- The names and roles of the two fourth-grade teammates: the interviewer read extends to them and the peer weights are retuned
- Your own answers to the answer slots, especially F3, F4, F5 and F6: each answer enters the fit snapshot verbatim and the rows and questions that draw on them are regenerated
- A printout of your active licence record: F1 confidence moves from medium to high
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches and several more minutes, which would open the literacy-plan page and add a grounding brief for C2 and R5
- A tuesday-dossier.md from an earlier engagement would add verified evidence and a named highest-risk objection
