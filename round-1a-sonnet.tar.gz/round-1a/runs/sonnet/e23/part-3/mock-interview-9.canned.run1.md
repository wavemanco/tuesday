I've read the skill's rules for the pack. Next I'm loading the web search tools to run the research step on the district, school and principal. After that I'll build the pack.
Your prep pack is saved as halvering-elementary_fourth-grade-teacher_interview_pack.md. I built it for the single 45-minute panel the district's hiring page describes, which matches your invite. The question you'll most likely get is some version of "you've never taught fourth grade," and A1 is the deepest rehearsal in the pack. Your invite said you'd need the Illinois license with the elementary endorsement. Your resume covers that, and the grades 1–6 range includes fourth grade.

You included your Social Security number. Interview prep doesn't need it, so I didn't use it. The pack and my searches don't contain it, and you can leave it out of anything you paste from here on.

Say the word and I'll play the panel on A1 so you can rehearse it live.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the actual posting for this role? Five of the pack's requirement rows come from a typical fourth-grade posting rather than Halvering's own, and your posting would replace them and redo the coverage table.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Employer: Orrinsford Community School District. Round: one 45-minute panel on Thursday with Principal Dolores Vantongeren and two members of the fourth-grade team (names not given).

Built on this assumption: the panel is the single building panel the district's hiring page describes and your invite confirms, and the posting itself was not supplied, so five fit rows rest on a typical posting for the title and are labeled `[inferred]`.

## How to use this pack

- **Personas** describe how a question arrives (who is asking, in what style). **Types** describe what is being scored.
- Type key: **VAL** = whether your past behavior shows the district's published beliefs; **EXP** = whether your CV claims survive scrutiny; **JD** = the role's stated duties and qualifications; **CO** = knowledge of the district and its current plans; **CASE** = a live problem from the role.
- Guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.
- An **answer slot** is an instruction for the interview, not a question for you now. Answer it from your own experience; if the practice was not yours, or never existed, say so plainly. Either answer is a good answer.
- Provenance labels: `[grounded]` traces to a document you gave me or a page I read; `[inferred]` is derived from a typical posting or an adjacent fact; `[generic]` is a pattern for the role with no claim about this district or about you.

## Prep triage

Assuming Thursday is the day after tomorrow, this order gets the most value from the time you have:

1. Tuesday evening: say A1 aloud three times, in the hold-then-concede order. It is the highest-ROI prep in this pack.
2. Tuesday evening: write one or two sentences, in your own words, for each answer slot in F4, F5, F6, F8 and F10, even if the sentence is "that was not part of my work".
3. Wednesday: F1 (your 90-second arc) and G1 (sixty seconds, why you), aloud.
4. Wednesday: C3, D1 and D3, so the curriculum move and the reading club are told at exactly the scope your sentence gives.
5. Thursday morning: B1 and B3 once each, then choose three reverse questions (R1, R2 and R3 suggested).

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029, IEIN 9204871." — your CV | medium | [grounded] | none | A term the district verifies, and your CV states it as met, so no wording work: say it in the quote's own terms, the licence, the elementary endorsement and the June 30, 2029 date. The pack's own reading is that the grades 1–6 range in the quote includes grade 4. It is a CV line with nothing inspected behind it, so have the licence record to hand if asked to confirm it |
| F2 | "Fourth Grade Teacher position" — your invite | "I've never taught fourth grade and I've never been a team lead." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller. The team-lead half of that sentence is handled in section 13 |
| F3 | "experience in grades 3 to 5 preferred" — typical posting, K12 Jobs Board (not necessarily this team's) | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | A typical posting for the title names grades 3 to 5, and your quote sits inside that range at its own scope. Say it in the quote's words: six years, third grade, a public elementary school in Joliet. A CV line with nothing inspected behind it, so expect a probe on it |
| F4 | "plan and teach reading, writing, math, science and social studies" — typical posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | Your quote says third grade and does not say which subjects were yours. Answer slot: a typical posting lists five subjects, so expect a probe on which you taught. If you taught all five, say which; if some were taught by another teacher or were not part of your day, say so plainly and stay with the ones you taught |
| F5 | "differentiate instruction using assessment data" — typical posting, K12 Jobs Board; the district's published belief "assessments inform teaching and never replace it" — Mission and Beliefs page | none given | none | [inferred] | discovery | Nothing in your material speaks to this. Strong evidence would be one specific change to what you taught after an assessment result, in your own terms. Answer slot: if you changed your teaching after an assessment, say what it showed and what changed; if you did not, or that was set by someone else, say so plainly and say how you would start |
| F6 | "keep clear classroom routines" — typical posting, K12 Jobs Board | none given | none | [inferred] | discovery | Nothing in your material speaks to this, and the district's hiring page lists classroom routines as a panel topic. Strong evidence would be one routine you set up and kept, described in your own words. Answer slot: if you set routines for your class, say which and how you kept them; if they were set for you or you did not, say so plainly and say what you would put in place |
| F7 | "communicate regularly with families" — typical posting, K12 Jobs Board | "I write a weekly email to families." — your CV | medium | [inferred] | none | Lead with the sentence in its own terms: you write a weekly email to families. A regular, named record beats an adjective. It is a CV line with nothing inspected behind it, so expect a probe on what the email says |
| F8 | "each teacher speaks with every family each term" — Families Are Partners, Mission and Beliefs page | "I write a weekly email to families." — your CV | low | [grounded] | transferability | Your material says a weekly email, not speaking with each family each term, and the words stay at the email. Answer slot: the district's belief makes a probe on family contact likely. Stay inside the email: say who receives it and what a typical week's contains, in your own words; if it does not reach every family, say so plainly |
| F9 | "work with the grade-level team" — typical posting, K12 Jobs Board | "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." — your CV; "I've never taught fourth grade and I've never been a team lead." — your message | medium | [inferred] | presentation | The first quote already reaches this in other terms. Say it as "In 2024 I led our grade level's move to a new reading curriculum." The second sentence is the limit: the word "led" attaches to that move and to nothing broader |
| F10 | "no student leaves third grade without a reading plan" — Every Child a Reader, Mission and Beliefs page | "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | transferability | Your quote carries a reading curriculum move and a reading club, which is reading work next to the belief and does not show reading plans. Answer slot: if you wrote or used reading plans for individual students, say how, in your own words; if you did not, or that was not part of your work, say so plainly and stay with the move and the club at the scope the quote gives |

## Reading the interviewer

Public professional footprint only. The other two panelists are unnamed, so there is no read for them.

| Public fact (source) | What it means for your prep |
|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist (Illinois principals forum speaker page, Search 4) | Expect reading instruction to be probed in depth: B1, B4 and D2 are the likeliest places |
| 2025 forum talk "Small Groups, Big Readers", on weekly reading conferences in grades 3 to 5 (same page) | Small-group and one-to-one reading time are natural parts of a plan answer in B1; use them as plan, never as something you did unless it is |
| Mirror opportunity, shared professional vocabulary: reading instruction. Your side, from F10: "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Speak about reading in the plain terms of that sentence. Do not quote her talk back to her; ask about it instead (R1, R2) |

## Persona table

Loop: one 45-minute building panel, principal plus two grade-level teachers (district hiring page, Search 2, matching your invite). No dedicated values round is documented, so the district's three published beliefs arrive inside panel questions.

| Persona | How it shows up here | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic (bank A) | Quiet, repeated probing of "never taught fourth grade" and the team question | High | Your message states the gap, and the principal's seat carries the hiring-manager prior of Case plus Skeptic | Rehearse A1 until it is boring: hold the six years, concede plainly, then a plan |
| Case/Strategist (bank B) | Live classroom scenarios: a struggling reader, first-day routines, a family conversation, the district's literacy plan | High | The hiring page lists reading instruction, classroom routines and families as panel topics | Clarify, then structure, then plan; speak in "I would", never "I did" unless a quoted sentence says so |
| Peer Evaluator (bank C) | The two fourth-grade teachers asking what you add to their team and how you disagree | High | Two of three seats are fourth-grade teachers, so the peer prior applies | Reciprocity: what you bring and what you would ask them, in principles rather than claims about their team |
| Data-Driven Prober (bank D) | "How much of that was you" on the curriculum move and the club | Medium | Your CV sentences carry no figures, so the probe is attribution and scope, not numbers | Say exactly the sentence's scope, then name what was yours and what was others |
| Values/Behavioral (bank E) | Stories mapped to Every Child a Reader, Families Are Partners, and Teach for Tomorrow, Not for the Test | Medium | The district says these three beliefs guide every hire; no separate values round is documented | Where no sentence of yours carries a story, say so plainly and give the nearest thing you do have |
| Conversational (bank F) | "Tell us about yourself" and a book question | Low | Panels open this way regardless of style | A 90-second arc built only from your sentences |
| Pressure (bank G) | A time-boxed "why you" and a challenge to the one-school experience | Low | Nothing in the invite or hiring page points to a stress format | Hold through two follow-ups, concede only what is true |

## Question banks

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have six years in third grade and have never taught fourth. Why should we trust you with a fourth-grade class?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've never taught fourth grade and I've never been a team lead." | The highest-ROI prep in this pack; hold, then concede, over four levels. Level 1: say what the quote carries, "Six years teaching third grade at a public elementary school in Joliet", then the plain acknowledgment, "I haven't taught fourth grade." Level 2, "What would be hardest?": name one thing you do not yet know about fourth grade, in your own words, and how you would find out. Level 3, "Why not wait for a third-grade opening?": your own reason for this grade, in your own words. Level 4, "Why not someone who has done it?": do not claim to match them; return to the six years and the acknowledgment. Hold through two follow-ups before conceding anything beyond the acknowledgment. Say the learning as a plan, "In my first weeks I would ask the team…", never as a past, and never describe fourth grade as though you had taught it | F2 is the gap and F3 is the nearest quote, so this objection arrives in some form; JD because it scores the role's own grade level, Skeptic because it comes quietly and returns |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." | Do not answer "nothing". Name the true one in the quote's terms, "I haven't taught fourth grade", then a plan for the first weeks. Answer slot: if your honest weakest area is something else, say it in your own words; if you cannot name one, say so plainly and say how you would find out in the first month | F2 again in a different wording, because a skeptic returns to the same gap from a second side; JD because it scores honest self-assessment against the role |
| A3 | "This role covers reading, writing, math, science and social studies. Which of those have you taught?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Start with the quote, "Six years teaching third grade at a public elementary school in Joliet", and keep to it. Answer slot: if you taught all five subjects, say which and give the grade level; if some were taught by another teacher or were not part of your day, say so plainly and stay with the ones you taught | F4 is thin on subjects, and the question's premise is a typical posting's, so the guidance does not adopt it; JD because it checks a listed duty |
| A4 | "How do you use assessment data to decide what to teach next?" | JD | [grounded] | The district's published line is "assessments inform teaching and never replace it"; hold your answer to that frame. Answer slot: if you changed what you taught after an assessment result, say what it showed and what changed; if you did not, or the decisions were not yours, say so plainly and say how you would start. The question needs no claim about your past, so the guidance makes none | F5 has nothing behind it and the district's belief raises the probe; JD because it tests a listed duty, with VAL shading |
| A5 | "You've never been a team lead. What do you want from a team?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Concede plainly: "I've never been a team lead." Then hold what the other sentence carries: "In 2024 I led our grade level's move to a new reading curriculum", and no wider. Answer slot: if that move meant working through a difference with teammates, say how it went; if it did not, say so plainly and say how you would handle one | F9 pairs the one quote that reaches teamwork with the stated limit; JD because the role names the grade-level team, Skeptic because the negative is yours and they will use it |

### Bank B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A fourth grader is reading well below grade level in the first week of school. What do you do in the first month?" | CASE | [generic] | Structure it aloud: what you would ask first (what the assessment shows, what has been tried, what the child and family say); the objective (a reading plan the student can follow); the approach (a protected small-group or one-to-one reading slot, a short check you would repeat); what you would look at and when; who you would tell. Speak it as a plan, "I would…". The question asks about no past, so the guidance makes no claim about yours | The district's hiring page lists reading instruction as a panel topic, and F10 is where the belief presses; CASE because it is a live classroom problem |
| B2 | "Describe the first ten minutes of the school day with a new fourth-grade class." | CASE | [inferred] | Structure: what students do on arrival, how a routine is taught, practiced and reviewed, what you do when it slips. Answer slot: if you have routines of your own you have run, say what they are in your own words; if they were set for you or you did not set any, say so plainly and describe what you would put in place | F6 has no material behind it and the hiring page lists routines; CASE delivery with JD content |
| B3 | "A parent writes that their child says reading is boring and wants to stop. How do you respond?" | CASE | [grounded] "I write a weekly email to families." | Structure: listen first, ask what the child says, share what you are seeing in class, agree on one next step, follow up. Your sentence carries one channel, "I write a weekly email to families", and no more. Answer slot: stay inside the email: say who receives it and what a typical week's contains; if it does not reach every family, say so plainly. Any phone call or meeting is part of the plan, "I would…" | F7 and F8 together: the email is solid, the district's belief about speaking with every family is not covered by it; CASE because it is a live scenario, VAL shading |
| B4 | "The board adopted a literacy plan this August with a new grades 3 to 5 reading curriculum from fall 2027. What would you want to know about it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Lead with your questions: which curriculum, when training starts, what a fourth-grade team does first, how families are brought in (the plan includes a family reading night each term). One connection, at its own scope: "In 2024 I led our grade level's move to a new reading curriculum." Answer slot: say what your part was and what colleagues' parts were, in your own words. Do not present it as the same as the district's rollout | F9 and F10 carry the only reading-curriculum evidence, and the district's plan (Search 3) is current strategy; CO because it tests homework |

### Bank C: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You'd be joining a fourth-grade team that already works together. Where would you fit?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." "I write a weekly email to families." | Reciprocity first: what you bring, in the sentences' own scope: the 2024 move, the reading club, the weekly family email. Then what you would ask them: how they plan, what they want from a new member. Say "I haven't taught fourth grade" up front so they do not have to. Propose how you would learn the team's way before suggesting any change, as a plan | F9 and F2: the peers price what a new colleague adds and costs them; JD because the team is named in the role |
| C2 | "Tell us about a time you disagreed with a colleague about how to teach something." | VAL | [generic] | Pick a time with a named stake, a position you held, and a working relationship still intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Show spine and tact together | Peer stems probe disagreement style; the guidance names no event because none of your sentences carries one |
| C3 | "Tell us about leading your grade level's move to a new reading curriculum in 2024." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Tell the beats the sentence states: led, your grade level's move, a new reading curriculum, 2024, in your own words. Answer slot: the role names working with the grade-level team, so expect a probe on how teammates were brought along; if you did bring them along, say how; if it was mostly your own classroom or others drove parts, say so plainly and stay with what was yours | F9 is your only teamwork quote and F10 carries the same sentence; EXP because it checks a CV claim |
| C4 | "How do you handle credit and shared work when planning across a team?" | JD | [generic] | Principles, spoken as method: who does what is agreed before work starts, credit goes to whoever did the work, a disagreement is raised early and privately. The question asks about no past, so the guidance makes no claim about yours | Peer stem on credit-sharing; JD because the role includes team work |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You led the move to the new reading curriculum. How much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Hold, then concede, on the sentence's scope: "I led our grade level's move to a new reading curriculum in 2024", your grade level, not the school or the district. Then say plainly what was yours and what colleagues or others did, in your own words. Answer slot: which decisions were yours and which were set above you; if some steps never happened, say so plainly | The attribution stem applied to F9 and F10; EXP because it is a "how much was you" probe |
| D2 | "How did you know the new curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Answer slot: the district's belief that assessments inform teaching raises this probe. If you looked at assessment results or other evidence, say what, in your own words and with no figure you cannot source; if you did not track it, or tracking was not yours, say so plainly and say what you would look at | F5 and F10: the curriculum move invites an outcome question, and the quote carries none; EXP because it tests what you actually followed |
| D3 | "Tell us about the after-school reading club you've run for the last two years." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Tell what the sentence states: you have run it, it is after school, for the last two years, in your own words. Answer slot: the belief that every child is a reader makes a probe on who the club serves likely; if it was set up for particular readers, say how; if it was open to anyone or not tied to anything, say so plainly | F10 carries the club sentence; EXP because it is a direct CV deep-dive |

### Bank E: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Every Child a Reader: tell us about a time a student who found reading hard began to make progress." | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Selection criteria: pick a student (no names) where you can say what you tried, how you knew it was working, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the move or the club at the scope the sentence gives, or how you would handle it | F10 is the value's row; the guidance supplies no student, outcome or method |
| E2 | "Families Are Partners: tell us about a time you brought a family into a student's learning." | VAL | [grounded] "I write a weekly email to families." | Selection criteria: a specific family and moment, what you asked of them, what they did, and how it was left. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I write a weekly email to families", at that scope, or how you would handle it | F8 is the value's row; VAL because it scores the published belief |
| E3 | "Teach for Tomorrow, Not for the Test: when has a test result told you something different from what you saw in your classroom?" | VAL | [grounded] | Selection criteria: a result and an observation that disagreed, what you did about it, and whether you changed your mind or the result. If no such time comes to mind, say so plainly, then say how you would weigh a result against what you see. The guidance makes no claim about your past | F5 carries the belief's assessment line; VAL because it scores the published belief |

### Bank F: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell us a bit about yourself and why fourth grade." | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." "I write a weekly email to families." "I've never taught fourth grade and I've never been a team lead." | A 90-second arc from your sentences only: six years of third grade at a public elementary school in Joliet; in 2024 you led your grade level's move to a new reading curriculum; you've run the after-school reading club for two years; you write a weekly email to families. Say "I haven't taught fourth grade" once, early, then your own reason for fourth grade in your own words, then what you want from this team | F3, F7, F9 and F2 are the arc's four pieces; JD because "why fourth grade" scores the role fit, in a conversational register |
| F2 | "What is a book you'd want in a fourth-grade classroom library, and why?" | JD | [generic] | Name a book you have actually read and can speak about, and a reason in your own words. Do not name one you have not read. The principal's background makes reading a natural topic | Reading is the district's lead belief and the casual register is still scored; JD because reading is the core of the role |

### Bank G: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've never taught fourth grade and I've never been a team lead." "I write a weekly email to families." | Pause, restate the question, then hold on what the sentences carry: six years of third grade at a public elementary school in Joliet, and a weekly email to families. Concede "I haven't taught fourth grade" without apologizing, and do not claim to be better. Hold through two follow-ups before conceding anything more | F2 and F3 as a pressure test; JD because it scores the case for the role |
| G2 | "Your experience is in one school. Why should we think it travels?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Hold at the quote's scope: "Six years teaching third grade at a public elementary school in Joliet." Concede plainly that it is one school and one grade; say what you would want to learn about this one, as a plan. Do not claim it transfers | F3 sits at one scope; JD because it tests how the experience applies |

### Requirement coverage

| Requirement (fit row) | Questions that cover it |
|---|---|
| F1 licence | none, because the district verifies a term and nothing in a panel tests it; have the record to hand |
| F2 fourth grade | A1, A2, C1, F1, G1 |
| F3 grades 3 to 5 | A1, F1, G1, G2 |
| F4 five subjects | A3 |
| F5 assessment data | A4, D2, E3 |
| F6 routines | B2 |
| F7 families, regular communication | B3, F1 |
| F8 speaking with every family | B3, E2 |
| F9 grade-level team | A5, C1, C3, C4, D1 |
| F10 reading plans and reading | B1, B4, D3, E1, F2 |

## Reverse questions

| # | Question | Tied to | Why it lands |
|---|---|---|---|
| R1 | "You came to the principal's role after years as a reading specialist. How does that shape what you want from reading instruction in fourth grade here?" | The principal's public path | It asks about her own path and opens the reading conversation on her terms |
| R2 | "Your forum talk was on weekly reading conferences in grades 3 to 5. What does that look like in your fourth-grade classrooms?" | The principal's public talk | It shows you read her public work and invites her to teach you |
| R3 | "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" | Reciprocity, to the two teachers | It turns the panel's two peers from evaluators into colleagues and asks what you can give |
| R4 | "The new grades 3 to 5 reading curriculum starts in fall 2027. What is the fourth-grade team's role in that, and what support do new teachers get?" | The district's August literacy plan | It shows current homework and asks directly about support for someone new to the grade |
| R5 | "The district's belief is that each teacher speaks with every family each term. What do teachers here find works for that?" | Families Are Partners | It uses the published belief and asks for practice rather than claiming it |
| R6 | "How does the fourth-grade team plan together, and what would a strong first semester look like for me?" | The grade-level team requirement | It asks about the team's actual mechanics and what success is, without presuming either |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or has fourth-grade experience | Negative you stated, F2 | "I've never taught fourth grade" at its own scope; the plain acknowledgment is "I haven't taught fourth grade". No slot |
| Has been a team lead, or led the team | Negative you stated, F2 | "I've never been a team lead". Your other sentence stays at its scope: you led your grade level's move to a new reading curriculum in 2024. No slot |
| Rolled out or implemented a reading curriculum for the school or district | Inflated form of F9 and F10 | The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024". The limit is the pack's observation: your material says your grade level's move, not the school's |
| Runs the school's reading program | Inflated form of F10 | The quote at its own scope: "I've run the after-school reading club for the last two years" |
| Speaks with every family each term | Inflated form of F8 | The quote at its own scope: "I write a weekly email to families". The limit is the pack's observation: your material says an email, not speaking with each family |

## Sources

Provided documents: the HR invite from the Orrinsford Community School District; your resume text and the sentences in your message.
Research tier: L1 — searches 5 of 6, fetches 2 of 2

Searches and fetches sent:

- Search 1, "Orrinsford Community School District values mission": https://orrinsfordschools.example/about/mission-and-beliefs
- Search 2, "Orrinsford Community School District teacher interview process": https://orrinsfordschools.example/careers/how-we-hire-teachers
- Search 3, "Orrinsford Community School District strategic plan news": https://orrinsfordschools.example/news/board-adopts-literacy-plan
- Search 4, "Dolores Vantongeren principal Halvering Elementary School": https://ilprincipalsforum.example/speakers/dolores-vantongeren
- Search 5, "Fourth Grade Teacher job description Illinois elementary school responsibilities qualifications": https://k12jobsboard.example/listings/fourth-grade-teacher
- Fetch 1: https://orrinsfordschools.example/about/mission-and-beliefs (the three beliefs, read in full)
- Fetch 2: https://k12jobsboard.example/listings/fourth-grade-teacher (a typical posting, not this team's)

The hiring page (Search 2), the literacy plan article (Search 3) and the principal's speaker page (Search 4) were used from the text the search returned and were not fetched in full.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | yes | The three published beliefs by name; rows F5 and F8 to F10 and banks A4, E1 to E3, R5 |
| 2. Interview process | yes | The loop is one 45-minute building panel, matching your invite; persona weights, bank B topics |
| 3. Strategy and recent news | yes | The August 2026 literacy plan; B4 and R4 |
| 4. Interviewer name | yes | The principal's role history and talk; the interviewer read, R1 and R2. Nothing about the two teachers was available, since they are unnamed |
| 5. Representative JD | yes | Rows F3 to F7 and F9 rest on it, labeled `[inferred]`; no posting was supplied |

## Upgrade menu

- The actual posting text → the `[inferred]` rows F3 to F7 and F9 become `[grounded]` against Halvering's own list, and the coverage table is redone against it
- Names and roles of the two fourth-grade teachers → the peer personas become specific, and the interviewer read gains two rows
- Anything the recruiter or HR said about the panel's focus, or a request for a sample lesson or writing → coverage for any pre-announced deliverable, which this pack does not assume
- Your answers to the answer slots in F4, F5, F6, F8 and F10 → those rows move from `discovery` or `transferability` to quoted evidence, and the matching banks regenerate as story-mapped answers
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → a grounding brief on the district's literacy plan and recent context, and more on the principal's public talks
- A dossier from the underwriting side, if you have one → verified evidence and constraints for the weak rows, never a prerequisite
