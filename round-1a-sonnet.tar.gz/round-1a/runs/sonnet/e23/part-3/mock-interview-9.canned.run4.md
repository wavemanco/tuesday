I'm running the pack's default research pass, with up to 6 searches and 2 fetches on the school, the district, the principal and a typical fourth-grade posting. Then I'll write the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/e23/part-3/rooms/case-9-canned-a721894e/Halvering-Elementary_fourth-grade-teacher_interview_pack.md`. It has 20 questions across six interviewer styles, a prep schedule for the next two days, and six questions for you to ask the panel. Your resume shows the license requirement met: the Illinois license with the elementary endorsement, active through June 30, 2029. I left out your Social Security number and license number because interview prep doesn't need them. You may want to remove them from anything you share.

I built the pack without the actual job posting, so two of its rows rest on a typical fourth-grade posting rather than this school's. I also used the district's published beliefs, its hiring page, the board's literacy plan and public information on Principal Vantongeren.

Your biggest exposure is that you've never taught fourth grade, and you said you've never been a team lead. Question A1 rehearses that answer. A2 and B4 rehearse how your resume line about leading the move to a new reading curriculum sits beside the team-lead gap. The "not coached" table lists the claims to avoid, such as having taught fourth grade or having been a team lead.

Say the word and I'll play the Skeptic on A1 so you can rehearse it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Do you have the text of the actual job posting? Pasting it would turn the two posting-based rows from role-family guesses into the school's own words.
2. Did HR say anything beyond the invite, such as a sample lesson or documents to bring? That would add a section for each requested item.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering-Elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. A 45-minute panel on Thursday with Principal Dolores Vantongeren and two members of the fourth-grade team (their names were not given). Built from your invite, your resume text, and the district's published pages. It was built without the posting text, so rows F7 and F8 below are role-family rows, not the school's own words.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Every guidance cell is scaffolding, not a script: say it in your own words, and say only what you did. Your material contains no figures and no results, so this pack supplies none.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs, not generic virtue |
| EXP | Whether the resume's claims survive scrutiny, and what was actually yours |
| JD | The role's stated duties and qualifications, gaps included |
| CO | Homework on the school and district, and current priorities |
| CASE | A live problem set in the role, scored on structure and reasoning |

A question with two plausible tags carries its primary tag, and the rationale says why. There is no bank F, so that F1 to F8 can stay the fit-snapshot rows.

## Prep triage

You have about two days. Do these in order, out loud, and treat everything else as insurance.

1. A1, three times through. It is the objection most likely to be asked, and a rehearsed, calm answer changes the room.
2. A2, B4 and G1 together. They all turn on two of your sentences sitting side by side without a wobble: the move you led, and the team lead you have not been.
3. E1, your 90-second opening, then D1 on families.
4. Read the board's literacy plan and the district's beliefs page (URLs under Sources), then C2 and reverse questions 3 and 5.
5. C1 and C3 once each.

Everything else in the banks is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met, and the quote already speaks to it in the requirement's own terms; the grades 1–6 range it names includes fourth grade as written. Lead with it as written. It is a CV line with nothing inspected behind it, which is why this row is medium, so be ready for the license record to be checked rather than the line to be probed |
| F2 | "the Fourth Grade Teacher position" — your invite | "I've never taught fourth grade" — your CV; "Six years teaching third grade at a public elementary school in Joliet." — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then, at its own scope: for six years you taught third grade at a public elementary school in Joliet. Then how you would get ready, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "reading instruction" — the district's careers page: "Panels ask about reading instruction, classroom routines and how you work with families." | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | none | Both quotes sit in reading, so there is no gap in subject. Lead with them in their own terms: you led your grade level's move to a new reading curriculum in 2024, and you have run the after-school reading club for the last two years. Expect a probe on what leading the move involved; A2 and G1 rehearse it |
| F4 | "classroom routines" — the district's careers page, same sentence as F3 | none given | none | [grounded] | discovery | Silence, not absence: your material shows no routines either way. Answer slot: the careers page names classroom routines as a panel topic, so expect a probe on a routine you have run. If you have run one, say which and how it worked, in your own words; if you have not, or it was not yours, say so plainly and describe what you would set up first |
| F5 | "how you work with families" — the district's careers page, same sentence as F3 | "I write a weekly email to families" — your CV | medium | [grounded] | none | The quote reaches the requirement: a weekly email is a named, regular channel. Lead with it in its own terms, and expect a follow-up beyond the email, which F6 covers |
| F6 | "each teacher speaks with every family each term" — the district's beliefs page, under Families Are Partners | "I write a weekly email to families" — your CV | low | [grounded] | discovery | The quote touches the belief without showing a conversation. Answer slot: the belief says each teacher speaks with every family each term, so expect a probe on direct contact. If you speak with families directly, say how and how often, in your own words; if the weekly email is the main channel, or the conversations were not yours, say so plainly and stay with the email |
| F7 | Typical fourth-grade postings list teaching across the core subjects (a representative posting seen as a search result, not fetched, and not this school's posting) | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | The quote touches the requirement without showing which subjects were yours. No slot, because no source read for this school raises it. If asked, name the subjects you taught yourself as a plain list in your own words; if some were taught by others, say so plainly and stay with the ones you taught |
| F8 | Work as part of a grade-level team (role-family requirement, no source read for this school) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | low | [generic] | transferability | Words: the move at its own scope, "I led our grade level's move to a new reading curriculum in 2024", and the negative you stated, "I've never been a team lead." Any wider step is yours to add, not this pack's |

## Reading the interviewer

Public professional footprint only. The two team members on the panel are unnamed, so there is nothing to read for them.

| Fact | Provenance | Source | What it means for you |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022 | [grounded] | ilprincipalsforum.example/speakers/dolores-vantongeren (search result) | She is the decision-maker in a panel of three, so A1 is most likely to come from her seat |
| Nine years as a reading specialist before that | [grounded] | same page | Reading questions may run deeper than a generalist's: expect C1 and G1 to go two levels down |
| 2025 forum talk, Small Groups, Big Readers, on weekly reading conferences in grades 3 to 5 | [grounded] | same page | If small groups or reading conferences come up, give a view or what you would do; nothing in your material says you run them, so do not claim it |
| Shared vocabulary: reading | [grounded] | same page, beside F3: "I led our grade level's move to a new reading curriculum in 2024" | Mirror her vocabulary lightly (reading groups, conferences) and let the F3 sentence stand at its own scope. This is shared subject matter, not a shared career jump, and nothing more is offered as one |

## Persona table

Weights follow the panel's makeup (the principal plus two grade-level teachers, per your invite and the district's careers page) and the topics that page names. The reasoning is shown so you can recalibrate if you know something this pack does not.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet, persistent probing of fourth grade and the team-lead gap | High. You stated both gaps in your material (F2, F8), and the principal's seat is where a hiring decision is derisked | Rehearse A1 until it is boring. Bridge only from what you stated: the six years of third grade, at its own scope. Say the plan in the future tense |
| Peer Evaluator (bank B, 4) | Two fourth-grade teachers asking what you would need from them and bring to them; the same objections in collegial packaging | High. Your invite puts two members of the fourth-grade team on the panel | Reciprocity: what you bring, in your quoted sentences, and what you need, in your words. Offer principles for how disagreement is settled; do not pretend to know their seam |
| Case/Strategist (bank C, 3) | Live problems in the careers page's named topics: reading instruction, classroom routines, families | Medium. The district's careers page says panels ask about these topics. A principal who was a reading specialist may press reading cases | Clarify, objective, approach, how you would check, risks. Think aloud and name the question you would ask first |
| Values/Behavioral (bank D, 3) | Scenario questions themed on the district's three beliefs | Medium. The careers page names panel topics and no values round, so no values-style round is detected and there is no values cheat sheet; the beliefs page says they guide every hire, so they theme these questions | One story or an honest scaffold per belief; "we" for the grade level, "I" for what you did |
| Conversational (bank E, 3) | A friendly opener and casual questions about the club and books | Medium. Assumed: no source read describes the panel's opening, so this rests on the pattern that panels begin conversationally | A 90-second arc built only from your quoted sentences; treat casual questions as scored |
| Data-Driven Prober (bank G, 2) | Line-by-line questions on the curriculum move and the family email | Low. Your material has no figures to probe, so the probes arrive as attribution questions, which A2 also rehearses | Know what you can and cannot say about each line; say plainly when you do not know |
| Pressure | Interrupting, time-boxing | Not banked. No source read suggests it for this panel; A2 carries the hold-then-concede structure if it appears | n/a |

## Question banks

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade, not fourth. What will be hardest for you in fourth grade?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet." | The highest-ROI rehearsal in this pack. Open with the facts as your material states them, and say them without apology: "I've never taught fourth grade. For six years I taught third grade at a public elementary school in Joliet." Then name the one thing you expect to be hardest, your pick, because the pack does not choose it for you. Close with a plan in the future tense: what you would learn first and who on the fourth-grade team you would ask. Nothing in your material says you have started, so describe it as what you would do. Hold through two follow-ups by returning to the six years, and never describe fourth-grade work as already yours | F2 is the one gap you stated and the most predictable objection to your candidacy. JD because it tests the stated role; it could also be scored as EXP, but the stated requirement decides the tag |
| A2 | "You led your grade level's move to a new reading curriculum. How much of that was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold only what the quote carries, once and plainly: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: the careers page names reading instruction as a panel topic, so expect a follow-up on what leading the move involved. Say in your own words what you did; if part of it was not yours, or there was no such step, say so plainly and return to the move. Hold through two follow-ups, concede only what is true and specific, and do not fold the core sentence to restore harmony. Add no title, committee or result the quote does not carry | F3 is the strongest reading evidence, so attribution probes land there. EXP because it tests what was yours; the Skeptic delivers it quietly |
| A3 | "Why fourth grade, and why Halvering?" | CO | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Your reasons are yours; the pack writes none. Selection criteria: one reason about fourth grade itself and one about Halvering, each specific enough to draw a follow-up. Draw the Halvering reason from what is published: the district's Every Child a Reader belief, and the board's August 2026 literacy plan with its new grades 3–5 reading curriculum from fall 2027 (Sources). The six years of third grade are your context, not your reason. If no reason about Halvering comes to mind, say so plainly, then say what you would want to learn about the school | F2 makes motivation a likely probe. CO because the strongest answer rests on homework about this district; it is also a motivation question |
| A4 | "Which part of this job would be weakest for you on day one?" | JD | [grounded] "I've never taught fourth grade" | Pick a weakness that is true. The one your material states is fourth grade itself: say "I've never taught fourth grade," name the specific part you would most want help with, and give your first step. Do not offer a strength in disguise. If nothing beyond fourth grade itself comes to mind, say so plainly and stay with it | F2 again, asked from the stem version of the Skeptic. JD because it scores the role's demands against you |
| A5 | "Suppose you're asked to teach a reading curriculum and you disagree with part of it. What do you do?" | CASE | [generic] | Structure it: what you would ask first (what the part is for, what you could check), how you would teach it as designed while you gather evidence, who on the team you would raise it with, what specific change you would propose and why, and how you would accept the decision. The question needs no claim about your past, so the guidance makes none | F3 and the board's new grades 3–5 curriculum make a new-curriculum disagreement a natural probe. CASE because it tests how you disagree, not what you did |

### Bank B: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our team plans together. What would you need from us in your first month, and what would you bring?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | Reciprocity first. What you bring is those three sentences at their own scope: "I led our grade level's move to a new reading curriculum in 2024. I've run the after-school reading club for the last two years. I write a weekly email to families." What you need is yours to say: two items at most, one of them about fourth grade, since "I've never taught fourth grade". Promise no outcome | F8 and F2: peers price what a hire costs and contributes. JD because it scores the team-work requirement, which is a role-family requirement here, so the tag rests on F8 as written |
| B2 | "When two teachers on a grade team disagree about how to teach something, what should happen?" | CASE | [generic] | Offer principles, not your guess at their seam: ask how this team decides; agree what evidence would settle it; try one approach for a defined stretch; keep the disagreement about the students' work; once the call is made, commit to it. If a real time you handled a disagreement comes to mind, you may use it in your own words; if none does, say so plainly and say how you would handle it | The peer stem on disagreement between equals. CASE because it asks for reasoning on a live problem; F8 is the requirement behind it |
| B3 | "Tell me about a time work spanned several teachers. How did credit get shared?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on the one quote, at its own attribution: the move was your grade level's, the leading was yours. Use "we" for the grade level and "I" for "I led". Say what part was yours in your own words; if part of it was not yours, say so plainly and stay with "I led our grade level's move". Name no colleague's role you have not stated | F8, and the peer stem on credit. VAL because it scores whether you share credit, not what you built |
| B4 | "You've never been a team lead. What role do you picture on our team?" | JD | [grounded] "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | Plain acknowledgment first, in your stated words: "I've never been a team lead." Then the move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Then the role you picture, which is yours to say; keep it to what you would do, in the future tense, and tell no leadership story your material does not carry | F8 and the pack's team-lead entry: A2's objection returning in collegial packaging. JD because it scores the team requirement |

### Bank C: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader is reading well below grade level. Walk me through your first month with them." | CASE | [grounded] | Clarify first: what assessment information exists and whether a reading plan already comes with the child. The district's beliefs page says no student leaves third grade without a reading plan, so asking for this child's plan is a grounded question. Then the objective, how you would group or work with the child, how you would check progress and adjust, and how you would keep the family informed. The question needs no claim about your past, so the guidance makes none | F3, on the careers page's named topic of reading instruction, and the Every Child a Reader belief. CASE because it scores structure and reasoning; the principal's reading background (interviewer table) makes depth likely |
| C2 | "The board adopted a literacy plan this year. What do you know about it, and where would you fit?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I write a weekly email to families" | Say what is public: a three-year plan adopted in August 2026 with structured phonics from kindergarten to second grade, a new grades 3–5 reading curriculum from fall 2027, and a family reading night at every school each term (Sources). Read the page before Thursday, and say plainly what you have not read. For where you would fit, use the two sentences at their own scope and no more: "I led our grade level's move to a new reading curriculum in 2024. I write a weekly email to families." Do not claim any of it matches the board's plan | The CO question grounded in current strategy. F3 and F5 are the evidence you can stand beside it; CO because it tests homework at the district's altitude |
| C3 | "Walk me through the routines you'd set up in the first week of a fourth-grade classroom." | CASE | [generic] | Structure it from what a school day needs (arrivals, transitions, the reading block, dismissal): what you would set up first, how you would teach it to the students, and how you would adjust. Answer slot: the careers page names classroom routines as a panel topic, so expect a follow-up on a routine you have actually run. If you have run one, say which and how it worked, in your own words; if you have not, or it was not yours, say so plainly and stay with what you would set up | F4, the row with no evidence. CASE because it asks for a plan; the slot keeps the follow-up honest |

### Bank D: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our district believes each teacher speaks with every family each term. How do you work with families?" | VAL | [grounded] "I write a weekly email to families" | Story-mapped on the one quote: weekly, email, families. Those are its beats; what is in the email is yours to describe, in your own words. Answer slot: the belief says each teacher speaks with every family each term, so expect a probe on direct contact. If you speak with families directly, say how and how often; if the weekly email is the main channel, or the conversations were not yours, say so plainly and stay with the email | F5 and F6, on the Families Are Partners belief. VAL because it scores a published belief against what you did |
| D2 | "Tell me about a time a student's reading was falling behind and you changed what you were doing." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection criteria, from the Every Child a Reader belief: a real instance, a student you do not name, what you noticed, what you changed, and what followed. The pack supplies none of it. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I've run the after-school reading club for the last two years", at its own scope (it does not say who attends), or say how you would handle it | F3, and the first belief by name. VAL because the story must show the belief in a decision, not recite it |
| D3 | "How do you use assessment results in your teaching, and when would you not trust them?" | VAL | [grounded] | Answer slot: the beliefs page says assessments inform teaching and never replace it, so expect a probe on how you use results. If you do, say how, in your own words, and name one limit you would put on a result; if you did not, or it was not yours, say so plainly and say what you would want a result to tell you before you acted on it | Your material says nothing on assessment, so no row carries this one. VAL because Teach for Tomorrow, Not for the Test is the belief it scores |

### Bank E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through your journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families"; "I've never taught fourth grade" | A 90-second arc from the quotes in order: the six years of third grade, the move you led, the reading club you have run, the weekly email, then your reasons for fourth grade and Halvering from A3, in your own words. Decide in advance whether you name "I've never taught fourth grade" yourself at the end; doing so means the Skeptic's question arrives second, not first | F2 and F3. EXP because the biography question tests whether the resume holds as a story; asked in the friendly register |
| E2 | "Tell me about the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Its beats are the quote's: you run it, it is after school, it is about reading, and it has been two years. What the club does, who comes and what you read are yours to say, in your own words; say only what you actually do | F3. EXP because it checks a resume line; casual in register, still scored |
| E3 | "Is there a book you love putting in a fourth grader's hands?" | JD | [generic] | Pick a real book you would genuinely hand a fourth grader: one sentence on why, one on the kind of reader it suits. If no title comes to mind, say so plainly and say what kind of book you would look for. Do not choose a title to impress | F3, and the principal's reading background (interviewer table). JD because it scores reading-instruction fit in a casual register |

### Bank G: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through how your grade level's move to the new reading curriculum went." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The beats are the quote's: your grade level, the move, a new reading curriculum, 2024, and that you led it. Tell it in your own words and say what you did; if part of it was not yours, say so plainly and return to "I led our grade level's move". Your material gives no figure or outcome, so supply none. If asked how you know it went well, say what you actually know, or say plainly that you have no measure | F3. EXP because it checks the line to its edges, which is where a prober goes first |
| G2 | "Tell me about the weekly email to families — what goes in it?" | EXP | [grounded] "I write a weekly email to families" | The beats are weekly, email, families. What goes in it is yours to describe; say only what is actually in it. If asked how families respond, say what you actually know, and say plainly if you do not track it | F5. EXP because it checks a resume line at its edges |

### Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| F1 license | none, and why | A gate your material shows met; no source read says the panel interviews on it |
| F2 fourth grade | A1, A3, A4, B4, E1 | |
| F3 reading instruction | A2, A5, C1, C2, D2, E2, E3, G1 | |
| F4 classroom routines | C3 | |
| F5 families, general | D1, G2 | |
| F6 speaking with every family | D1 | |
| F7 core subjects | none, and why | No source read for this school raises it, so asking would presuppose it; the posting text would change this |
| F8 team | A2, B1, B3, B4 | |
| Belief: Every Child a Reader | C1, D2 | |
| Belief: Families Are Partners | D1 | |
| Belief: Teach for Tomorrow, Not for the Test | D3 | |

## Reverse questions

| # | Question to ask them | Why it lands |
|---|---|---|
| 1 | "You came to the principal's seat after nine years as a reading specialist. How does that shape what you look for in a fourth-grade reading block?" | Ties to the principal's own path (interviewer table), and it is a question only someone who read about her would ask |
| 2 | "Your talk on small groups and weekly reading conferences covered grades 3 to 5. What does that look like in a Halvering fourth-grade classroom?" | Uses her published talk, shows you read it, and moves the conversation to the thing she cares about most |
| 3 | "The board's plan brings a new grades 3–5 reading curriculum from fall 2027. What will the fourth-grade team be doing between now and then?" | Shows you read the plan, and tells you whether you would be teaching the old curriculum or the new |
| 4 | "What could a new person on the fourth-grade team do in the first month that would genuinely help your team?" | The peer reciprocity question: it flips the panel from evaluating you to advising you |
| 5 | "How does the fourth-grade team plan together, and what should a teacher new to the grade read or observe first?" | Names your fourth-grade gap (F2) as a plan, not a worry, and invites mentoring |
| 6 | "The district's belief is that every teacher speaks with every family each term. What does that look like here beyond written updates?" | Uses the Families Are Partners belief by name, and tells you what F6's follow-up is really expected to look like |

## Prohibited claims

What this pack will not coach, and why. Each is a sentence you may be tempted to reach for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F2 | "I've never taught fourth grade." Then the six years of third grade at its own scope |
| Has been a team lead, or led the grade-level team | A negative you stated, F8 | "I've never been a team lead." Then the move at its own scope: "I led our grade level's move to a new reading curriculum in 2024" |
| Chose, designed or wrote the new reading curriculum | Inflated form of F3 | The quote at its own scope. The limit is the pack's observation: your material says you led the grade level's move to a curriculum, not that you chose or wrote it. A2 and G1 stay inside the move |
| Led reading across the school or district | Inflated form of F3 | The quote at its own scope: your grade level, in 2024. The pack observes that your material names a grade level and a club, not a school or district role |
| Started or founded the reading club | Inflated form of F3 | "I've run the after-school reading club for the last two years." The pack observes that the quote says run, not started, and E2 stays with the verb |

## Sources

Provided documents: your invite; your resume text. Your Social Security number and license number (IEIN) were not used, since they are not needed for interview prep.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | Fetched the beliefs page: three beliefs by name, which theme bank D and C1 |
| 2. `Halvering Elementary School Orrinsford fourth grade teacher interview` | yes | Fetched the careers page: one 45-minute building panel, with named topics; it fixed the persona weights and F3 to F5, and it names no values round, so no values cheat sheet |
| 3. `Halvering Elementary School Orrinsford district news strategic plan` | yes | The board's literacy plan (search result only): C2, A3 and reverse question 3 |
| 4. `Dolores Vantongeren principal Halvering Elementary` | yes | The interviewer table and reverse questions 1 and 2 (search result only) |
| 5. representative `Fourth Grade Teacher` job posting | yes | A representative posting (search result only, truncated, not fetched): rows F7 and F8 as unquoted, inferred or generic requirements; nothing from it is quoted |

Searches sent and what came back:

- `Orrinsford Community School District values mission` returned https://orrinsfordschools.example/about/mission-and-beliefs
- `Halvering Elementary School Orrinsford fourth grade teacher interview` returned https://orrinsfordschools.example/careers/how-we-hire-teachers
- `Halvering Elementary School Orrinsford district news strategic plan` returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
- `Dolores Vantongeren principal Halvering Elementary` returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- `fourth grade teacher job posting Illinois elementary qualifications responsibilities` returned https://k12jobsboard.example/listings/fourth-grade-teacher

Pages fetched: https://orrinsfordschools.example/about/mission-and-beliefs and https://orrinsfordschools.example/careers/how-we-hire-teachers.

## Upgrade menu

- The posting's own text → F7 and F8 become grounded rows, and a JD question can be added for each requirement now covered by "none, and why"
- Anything HR told you about Thursday beyond the invite, such as a sample lesson or documents to bring → a build section for each declared deliverable; usually one email to HR
- The two team members' names → a tailored interviewer read and a peer reverse question
- Your own answers to the slots in A2, C3, D1, D3 and E2 → rows F3, F4 and F6 regenerate with your confirmed words, and the matching guidance sharpens
- A printout of your license record → F1 moves from medium to high, because a license record is the inspectable artifact in a regulated field
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief with the board's literacy plan and the principal's talk read in full, and sharper C2 and reverse questions
