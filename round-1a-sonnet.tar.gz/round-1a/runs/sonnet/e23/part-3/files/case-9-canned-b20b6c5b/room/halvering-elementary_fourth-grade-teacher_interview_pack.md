# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Candidate:** Grace
**Employer:** Orrinsford Community School District (HR sent the invite)
**Round:** One 45-minute panel on Thursday: Principal Dolores Vantongeren plus two members of the fourth-grade team (names not given)
**Relationship assumed:** the principal as the hiring-manager voice, the two team members as peers. The invite does not say, so this is an assumption, and the persona weights below show how it was used.
**Built from:** the invite, your resume text and the two things you told me you have not done, plus the district's published pages (Sources). No job posting was supplied.

## How to use this pack

- **Personas are how a question is asked; types are what it is scoring.** Every question carries both.
- **Guidance is scaffolding, not a script.** Say it in your own words. Wherever the guidance is an answer slot, answer from what actually happened, and if it did not happen, or was not yours, say so plainly.
- **Highest-ROI prep:** A1, "You haven't taught fourth grade before." It will be asked in some form. G1 is the same answer under a sixty-second clock.
- **No values cheat sheet.** Nothing I read documents a dedicated values round, so that section is dropped. The district's three published beliefs still shape bank D and several other questions.

| Type | Name | What it is scoring |
|---|---|---|
| VAL | Behavioral / values alignment | Whether your past behavior shows the district's published beliefs |
| EXP | Work-experience deep-dive | Whether your resume claims survive scrutiny, and what was actually you |
| JD | Role-driven | Whether you can do the job as described, gaps included |
| CO | Company knowledge | Whether you know what the district is doing now |
| CASE | Live problem | Structure and reasoning on a problem from the actual role |

## Fit snapshot

No posting was supplied, so the requirements come from the invite, the district's published beliefs, and two role-family lines written as unquoted prose.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your material shows this gate met. It is a CV line with nothing inspected behind it, so expect it to be verified. Say it in the quote's own terms and add nothing: "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029." |
| F2 | "Fourth Grade Teacher position" — the invite | "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." The adjacent sentence stays at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Then a plan, said as a plan and never as a past. Answer slot: say in your own words what you would ask the fourth-grade team and learn before the first day; if you have no plan yet, say so plainly and say what you would ask first. Nothing is added to make the gap feel smaller |
| F3 | Plan and deliver grade-level elementary instruction (role-family requirement, written without a posting, unquoted) | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [generic] | none | No gap in kind, but a CV line with nothing inspected behind it. Lead with it in its own terms: "Six years teaching third grade at a public elementary school in Joliet." The line names a grade and a type of school, not subjects, curricula or results, and the words stay there |
| F4 | "Every Child a Reader: no student leaves third grade without a reading plan." — the district's Mission and Beliefs page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Your material says a curriculum move and a club, with nothing inspected behind either, and the words stay there: "I led our grade level's move to a new reading curriculum in 2024. I've run the after-school reading club for the last two years." Answer slot: the page's line about every student having a reading plan makes a probe on individual reading plans likely. If you wrote or tracked reading plans for individual students, say how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the curriculum move and the club |
| F5 | "Families Are Partners: each teacher speaks with every family each term." — the district's Mission and Beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | A weekly email is adjacent to speaking with families, not the same thing, and the bridge does not stretch it: "I write a weekly email to families." Answer slot: if you spoke with families beyond the email, say how and how often, in your own words; if you did not, or it was not part of your practice, say so plainly and stay with the weekly email |
| F6 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — the district's Mission and Beliefs page | none given | none | [grounded] | discovery | Your material is silent on assessment. Answer slot: the belief makes a probe on how assessment shapes your teaching likely. If assessment results ever changed what you taught, say what and how, in your own words; if they did not, or that was not yours to decide, say so plainly and say how you would want assessment to inform your teaching |
| F7 | Work as part of the fourth-grade team (role-family requirement, written without a posting, unquoted) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | low | [generic] | transferability | The quote shows grade-level work, not a team-lead role, and you have said you have not held one. Words: "I led our grade level's move to a new reading curriculum in 2024. I've never been a team lead." Both sentences together, never one without the other |

## Reading the interviewer

Public professional footprint only. The two team members are not named, so nothing is researched about them.

| Fact or reading | Source | Provenance |
|---|---|---|
| Dolores Vantongeren has been principal of Halvering Elementary School since 2022 | Illinois principals forum speaker page (S2) | [grounded] |
| Nine years as a reading specialist before becoming principal | S2 | [grounded] |
| 2025 forum talk "Small Groups, Big Readers" on weekly reading conferences in grades 3 to 5 | S2 | [grounded] |
| Reading instruction is the likeliest place the principal goes deep, because her career before the principal role was reading and her talk is on it | Derived from S2 | [inferred] |
| Her talk spans grades 3 to 5, which includes this role's grade, so C2 is where a specific, informed answer matters most | Derived from S2 | [inferred] |
| Do not claim small-group reading conferences unless you have run them; C2 holds the slot for it | Derived from S2 and F4 | [inferred] |
| Shared vocabulary, not a shared career jump: reading. The pairing is her published path with your sentence from F4: "I've run the after-school reading club for the last two years." No jump of yours is offered, because no row's evidence carries one | S2 and F4 | [inferred] |

## Persona table

| Persona | How it shows up here | Weight, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | The principal, if she acts as hiring manager (assumed), and teachers asking about the grade change | Highest. F2 and F7 hold the two negatives you stated, and a panel choosing who joins a grade team probes there first | Rehearse A1 until it is boring: acknowledgment, your own sentence, a plan, a concession |
| Peer Evaluator | The two fourth-grade team members | High. Two of three panelists are on the team, and they are pricing what you add to their work | Offer what you bring, ask what you need, propose principles for the seam rather than claiming to know it (B1, B2) |
| Case/Strategist | The principal, on the board's literacy plan (S3) and reading instruction (S2) | Medium. Her background and the plan both point at reading | Clarify, objective, approach, how you would check it, risks; think aloud (C1 to C3) |
| Values/Behavioral | Any panelist, themed on the district's three published beliefs | Medium. The page says three beliefs "guide every hire", but no source documents a values round, so it is not weighted higher | One honest story or an honest "none comes to mind" per belief (D1 to D3) |
| Conversational/Rapport | The opening "walk me through your journey" | Low to medium. It is likely the first question, and it is still scored | A 90-second arc built only from your own sentences (E1, E2) |
| Data-Driven Prober | A teacher reading the resume closely | Low. The resume has no figures, so probes land on attribution instead | Know exactly which part of each line was yours (F1, F2) |
| Pressure | Not signaled by any source | Low. Included so no style is met for the first time live | Hold through two follow-ups, concede one specific limit (G1, G2) |

## Question banks

### A. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade before. What would your first month look like?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | The highest-ROI rehearsal in this pack. Open with the acknowledgment: "I've never taught fourth grade." Then the adjacent sentence at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Then a plan, said as a plan. Answer slot: say what you would ask the fourth-grade team and learn before the first day; if you have no plan yet, say so plainly and say what you would ask first. Follow-up 1, "What changes between third and fourth?": say what you know from your own experience; if you have not seen it, say so plainly and say who you would ask. Follow-up 2, "Isn't that a risk on day one?": concede it exactly: "It is a real ramp, and I'd rather name it than hide it," then return to the plan. Never say what third grade proves about fourth. The limit is the pack's observation: your material shows third grade and says nothing about which parts carry over | F2 is the biggest gap and the one you stated yourself, so this is the objection that arrives in some form. JD because it scores the role's grade level; it is the deepest rehearsal because it gets three levels and exact concession wording |
| A2 | "You led your grade level's move to a new reading curriculum. Were you the team lead?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Hold both sentences together: "I led our grade level's move to a new reading curriculum in 2024. I've never been a team lead." Do not let "led" grow into a title. If asked what leading meant, answer from what you remember, in your own words; if it was narrower than the sentence sounds, say so plainly. The limit is the pack's observation: your material says the grade level's move, not who chose the curriculum | F7 and F4 meet here, and a panel will test whether "led" means a title. EXP because it tests attribution |
| A3 | "Why fourth grade, and why Halvering?" | JD | [grounded] | Give one real reason in your own words, and tie it to something the district actually publishes only if it genuinely matters to you: its belief "Every Child a Reader", or "Families Are Partners". If no reason comes to mind that you would say aloud, say so plainly, then say what you want to learn about fourth grade. The pack supplies no reason for you | A motivation probe for a candidate changing grade level; the published beliefs are the raising source for what is specific to this district |
| A4 | "Can you confirm your license and endorsement for us?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Answer in the quote's own terms and stop: "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029." Have your license record ready to show if asked. Add nothing about what it qualifies you to teach beyond what the line says | F1 is the invite's one stated requirement, so it is the cheapest question to get wrong by over-talking |

### B. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where's the seam between what a new teacher decides alone and what our team decides together, and what happens when we disagree?" | CASE | [generic] | Propose principles and do not pretend to know their seam: you would ask how the team already splits it before proposing anything; decisions about what the whole grade teaches belong to the team; decisions inside your own day stay provisional until you have learned the team's norms. On disagreement: raise it directly, say what you would concede, and say what you would not move on. Name one limit: you cannot know their seam until you ask | A peer probe on turf and disagreement style; CASE because it is a live problem. `[generic]` because it is a pattern for the problem, not a fact about this team |
| B2 | "What would you need from us in your first month, and what could you bring to the team?" | JD | [grounded] "I've never taught fourth grade"; "I write a weekly email to families"; "I've run the after-school reading club for the last two years" | Reciprocity framing. What you need: tie it to the quote, "I've never taught fourth grade", and ask what the team would want you to read or see first. What you bring: offer, as things you could share if useful, "I write a weekly email to families" and "I've run the after-school reading club for the last two years". Offer them; do not claim results from them | F2 is why the need is real; F4 and F5 hold what can honestly be offered. JD because it scores the role's team fit |
| B3 | "How do you handle credit when work spans a team?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | "We" for context, "I" for contribution, and the "I" sentence is exactly the quote: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if teammates carried parts of that move, say whose and what, in your own words; if you cannot say, or it was not like that, say so plainly and stay with the sentence | A peer credit probe; F4's sentence is the only one that involves a group, and EXP because it tests attribution |
| B4 | "A student in your class is well behind in reading by mid-year. Who do you involve, and what do you do?" | CASE | [grounded] | Structure aloud: clarify what is known and what has been tried; state the objective; say who you would involve, including the family and the team; say how you would check progress. The district's page says no student leaves third grade without a reading plan, so expect the team to listen for a plan. Concede what you cannot know until you see the student's data. The question asks about no past, so the guidance makes no claim about yours | A live reading problem from the district's own published belief; F4 is the requirement it presses on |

### C. Case/Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The board's literacy plan brings a new grades 3–5 reading curriculum from fall 2027. How would you help a fourth-grade team get ready for it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Clarify first: what has been chosen, where the rollout stands, what the team already uses. Then objective, approach, how you would know it is working, and risks, including that you would be learning fourth grade at the same time. The one story you can tell is the sentence: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if any part of that move was yours to set, say which part and how you decided, in your own words; if there was no such part, or it was not yours, say so plainly and stay with the sentence | The plan is the district's current strategy (S3, a search snippet; confirm the dates on the page); F4 is the evidence it presses on. CO content with CASE delivery |
| C2 | "Walk me through how you would plan a week of reading for a fourth-grade class." | CASE | [grounded] "I've run the after-school reading club for the last two years" | Structure it: what you would ask first about the curriculum and the assessments, the objective, the approach, how you would check it is working, the risks. Answer slot: the principal's published talk covers weekly reading conferences in grades 3 to 5, so expect a probe on small-group reading. If you have run reading conferences or small groups, say how, in your own words; if you have not, or there was no such step, say so plainly and stay with "I've run the after-school reading club for the last two years", then say what you would want to learn | The interviewer read puts reading at the center of her background; F4 is the evidence. CASE because it is a live planning problem |
| C3 | "Suppose October assessment results show a good part of your class reading below grade level. What do you do first?" | CASE | [grounded] | Clarify what the assessment measured and who is affected before acting. Use the results as one input: the district's page says assessments inform teaching and never replace it, so say what else you would look at. Then the plan, how you would tell the families, and when you would check again. Concede what you cannot know until you see the data. No claim about your past is made | F6 is the requirement it presses on, and the answer holds up without any evidence of your own |

### D. Values/Behavioral (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you made sure a struggling reader had a plan." | VAL | [grounded] "I've run the after-school reading club for the last two years"; "I led our grade level's move to a new reading curriculum in 2024" | Selection scaffold, because no sentence of yours carries this story: pick a time with a specific student, a decision that was yours, and what changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I've run the after-school reading club for the last two years" or "I led our grade level's move to a new reading curriculum in 2024", at its own scope | The belief "Every Child a Reader" is the raising source; F4 is its row |
| D2 | "Tell me about a time you worked with a family to solve something." | VAL | [grounded] "I write a weekly email to families" | Selection scaffold: pick a time with a named stake, something you did yourself, and a relationship that was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I write a weekly email to families." Answer slot: the belief says each teacher speaks with every family each term, so if you spoke with families beyond the email, say how, in your own words; if not, say so plainly | The belief "Families Are Partners" is the raising source; F5 is its row |
| D3 | "Tell me about a time assessment data changed what you taught." | VAL | [grounded] | Selection scaffold: it needs a specific piece of data, a change you made because of it, and what happened afterwards. If no such time comes to mind, say so plainly, then say how you would use data without letting it replace your judgment, which is how the district words the belief | The belief "Teach for Tomorrow, Not for the Test" is the raising source; F6 is its row, and your material holds no sentence to map |

### E. Conversational/Rapport (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through your journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc whose beats are these four sentences and nothing else, in your own words, then one close on why fourth grade and why here. The close is your own reason; if you have none you would say aloud, say so plainly and say what you want to learn. Do not add dates, numbers or outcomes the sentences do not state | The likeliest first question; F3, F4 and F5 are the rows it draws on |
| E2 | "Tell us about the reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Only the beats the sentence states: it is a reading club, it is after school, and you have run it for the last two years. If asked for particulars, answer from what you actually know and say plainly where you do not | Friendly in register but scored; F4's second sentence is the reading evidence closest to the principal's background |

### F. Data-Driven Prober (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through your part in the move to the new reading curriculum." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The sentence is all the pack can put in your mouth: "I led our grade level's move to a new reading curriculum in 2024." After it, say what leading meant from what you actually remember, in your own words; if you cannot describe a part, say so plainly. Add no step, date or outcome you could not defend under a second question | F4's headline claim, and the one a prober tests first |
| F2 | "Which of the things on your resume were mostly your own work, and which were the team's?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | Go line by line. For each, say the sentence as written, then which part was yours and which was not, in your own words. If you are unsure how much was yours, say so plainly rather than rounding up | Attribution honesty across F4 and F5, asked directly |

### G. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why a third-grade teacher for a fourth-grade classroom?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | Pause, restate the question, then A1's three beats in sixty seconds: "I've never taught fourth grade." Then "Six years teaching third grade at a public elementary school in Joliet." Then your plan, as a plan. Hold the position through two interruptions by returning to those beats; concede one specific limit, that you have not taught the grade, and do not fold on the rest | A1 under a clock; F2 is the row |
| G2 | "That reading curriculum move — how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Restate the question, then anchor on the sentence: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if other parts of the move were yours, say which, in your own words; if not, say so plainly and say that the sentence is what you are claiming. Hold through two follow-ups by returning to the sentence, never by adding to it | The stem every pressure interviewer uses on a leadership claim; F4 is the row |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 license and endorsement | A4 |
| F2 fourth-grade position | A1, A3, B2, G1 |
| F3 plan and deliver grade-level instruction | C2, E1 |
| F4 Every Child a Reader | A2, B3, B4, C1, C2, D1, E1, E2, F1, F2, G2 |
| F5 Families Are Partners | D2, B2, E1, F2 |
| F6 Teach for Tomorrow, Not for the Test | C3, D3 |
| F7 work as part of the team | A2, B1, B2 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| 1 | "You spent nine years as a reading specialist before becoming principal. How does that shape what you want a fourth-grade reading block to look like?" | Ties to the principal's own path and invites her to talk about her work, which turns the interview into a conversation | [grounded] |
| 2 | "The board's plan brings a new grades 3–5 reading curriculum from fall 2027. What would the fourth-grade team want a new teacher to understand about where that stands?" | Shows you read the district's current plan and asks about the team's view, not the announcement | [grounded] |
| 3 | "The district's beliefs say each teacher speaks with every family each term. What does that look like at Halvering in practice?" | Asks about practice rather than the slogan, which is the question a candidate who read the page asks | [grounded] |
| 4 | "How does the team use assessment results day to day, given the belief that assessments inform teaching and never replace it?" | Moves from the published belief to how it works in a classroom | [grounded] |
| 5 | "What could a new person do in the first month that would genuinely help the fourth-grade team?" | Reciprocity question for the two peers on the panel; it shows you are thinking about their load | [generic] |
| 6 | "Is there anything I could read or observe before the first day to learn what fourth grade asks of students?" | Turns F2 from a gap into a plan, which is how a panel hears it | [generic] |
| 7 | "What does a good first year in this role look like?" | A standard question that lets the principal name her priorities | [generic] |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F2 | The acknowledgment you gave: "I've never taught fourth grade." No slot |
| Has been a team lead | A negative you stated, F7 | The acknowledgment you gave: "I've never been a team lead." No slot |
| Chose or designed the new reading curriculum | Inflated form of F4 | F4's quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The limit is the pack's observation: your material says the grade level's move, not the choice or design of the curriculum. C1 and G2's slots stay inside the move |
| Ensured every student had a reading plan | Inflated form of F4 | F4's quotes at their own scope. D1's slot asks only about a specific student and a decision that was yours |
| Spoke with every family each term | Inflated form of F5 | F5's quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: your material says the email, not conversations |

## Sources

**Provided documents:** the HR invite; your resume text and the two statements about what you have not done, quoted in the fit snapshot.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Query or fetch | What came back |
|---|---|
| S1 search: "Orrinsford Community School District mission values" | https://orrinsfordschools.example/about/mission-and-beliefs |
| S1 fetch: that page | The three beliefs by name, each with its one-line definition |
| S2 search: "Dolores Vantongeren principal Halvering Elementary School" | https://ilprincipalsforum.example/speakers/dolores-vantongeren |
| S2 fetch: that page | Principal since 2022; nine years as a reading specialist; 2025 talk "Small Groups, Big Readers" |
| S3 search: "Orrinsford Community School District news strategic plan" | https://orrinsfordschools.example/news/board-adopts-literacy-plan — search snippet only, page not opened: the three-year literacy plan adopted in August 2026, including a new grades 3–5 reading curriculum from fall 2027 and a family reading night at every school each term |
| S4 search: "Illinois fourth grade teacher job posting elementary PEL requirements" | https://k12jobsboard.example/listings/fourth-grade-teacher — a truncated snippet from another employer's listing, not opened, and nothing from it appears inside quotation marks |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | F4 to F6 requirement rows, banks D and B4, reverse questions 3 and 4; the page documents no values round, so no cheat sheet |
| 2. `Orrinsford Community School District interview process fourth grade teacher` | skipped | Could not have moved the persona table or banks: the invite already fixes the loop as one 45-minute panel with the principal and two fourth-grade team members |
| 3. `Orrinsford Community School District strategy` or recent news | yes | C1 and reverse question 2; the snippet gives the plan's dates, so they are worth confirming on the page |
| 4. `Dolores Vantongeren Halvering Elementary School` | yes | The interviewer read, C2 and reverse question 1; the two team members have no names, so nothing was researched about them |
| 5. representative `Fourth Grade Teacher` JD | yes | Moved nothing quoted: it returned one truncated snippet from another employer and the fetches went to targets 1 and 4, so F3 and F7 are unquoted `[generic]` prose |

## Upgrade menu

- The full job posting → F3 and F7 become quoted `[grounded]` rows, and every JD-tagged question can be checked against the posting's own list in the coverage table
- Names and roles of the two fourth-grade team members → a per-member interviewer read, persona weights adjusted per person, and a tailored reverse question
- Anything HR or the principal said about a demo lesson, work sample or portfolio → a build section for it
- Your answers to the slots in F2, F4, F5 and F6, stated outside a drill → those rows move from bridge language to story-mapped answers
- A printout or screenshot of your license record from the state's educator license lookup → F1 moves from medium to high confidence
- The district's literacy-plan news page opened and its dates confirmed → C1 and reverse question 2 move from a search snippet to a read page
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the district, the other panelists' footprint if they are named, and any loop reports for the district
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and any prohibited claims, replacing the locally built list
