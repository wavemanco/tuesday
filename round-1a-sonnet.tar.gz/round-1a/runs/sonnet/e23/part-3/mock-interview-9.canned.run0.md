Status: I've loaded the mock-interview skill and read its rules. Next I'll run a small, budgeted research pass on the district and the principal, then build your prep pack.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a/runs/sonnet/e23/part-3/rooms/case-9-canned-29e3126e/orrinsford_fourth-grade-teacher_interview_pack.md`. I built it for a panel round, with Principal Vantongeren as the hiring-side voice and the two fourth-grade teachers as peers. I had only the invite, not the full posting.

- **License:** Your license and elementary endorsement meet the invite's requirement, so I treated that as met.
- **Biggest risk:** The question to rehearse most is A2, "You've taught third grade, not fourth. What changes for you?" The pack's answer uses only your own words: concede "I've never taught fourth grade," then hold on your six years of third grade.
- **"Led" vs. team lead:** You said you led your grade level's curriculum move and also that you've never been a team lead. A3 and G2 prepare you for a panelist who presses on that.
- **The principal:** She spent nine years as a reading specialist and gave a 2025 talk on small-group reading in grades 3 to 5. Expect reading questions that go deeper than curriculum, so C3 and D2 are worth practicing.
- **District plan:** The board adopted a literacy plan in August with a new grades 3–5 reading curriculum from fall 2027. C2 and one of the reverse questions use it.
- **Your SSN:** You don't need it for interview prep, so I didn't use it or put it in the pack. Leave it off anything you share with the district.

Say the word and I'll play the Skeptic on A2 so you can rehearse it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did the district tell you to prepare anything, such as a demo lesson, a writing sample, or questions sent ahead? If so, I'd add a build section for it.
Can you paste the full posting? It would replace three requirements I could only infer from a typical listing with the real ones.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: orrinsford_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Panel interview, 45 minutes, Thursday. Panel: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). Built from the invite and your pasted background, with no full posting and no recruiter guidance beyond the invite. Panel weights follow the invite's relationships: the principal as the hiring-side voice, the two team members as peers.

## How to use this pack

Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs, not generic virtue |
| EXP | Whether your background claims hold up when probed, and what was actually yours |
| JD | The stated role and requirements, including the gaps |
| CO | Knowing the district's own plans and context |
| CASE | A live problem set in the role, scored on structure and reasoning |

## Prep triage

You have until Thursday. In this order:

1. A2, the question the pack names as the highest-ROI prep. Say it aloud until the concession and the plan sound ordinary.
2. D1, your opening arc, built only from your own sentences.
3. A3 and G2, the two answers where the word "led" meets your own statement about team leads.
4. C2, so you can ask good questions about the district's literacy plan.
5. The reverse questions, picking three.

Everything else is insurance.

## Fit snapshot

Requirements come from the invite (the one gate), from the district's published Mission and Beliefs page, and from a typical fourth-grade listing found in search (labeled inferred, not this posting).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your CV states the gate in the invite's own terms. Nothing was inspected here, so expect it to be verified. Say it as you wrote it. The range you stated, grades 1–6, covers fourth grade |
| F2 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board typical listing, from a search result, page not fetched | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | discovery | Typical for the role, not this team's stated practice. Your sentence gives the grade and the years and does not say which subjects. Answer slot: say which subjects you taught, in your own words; if some were taught by someone else, say so plainly and stay with the six years |
| F3 | "Fourth Grade Teacher position" — invite | "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then the adjacent fact at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Then how you would learn the grade, said as a plan and never as a past |
| F4 | "communicate regularly with families" — K12 Jobs Board typical listing, from a search result, page not fetched | "I write a weekly email to families" — your CV | medium | [inferred] | none | Your sentence already reaches the requirement in role-relevant terms. Lead with it as written. It is a CV line with nothing inspected behind it, so expect a probe on what the email holds |
| F5 | "each teacher speaks with every family each term" — Orrinsford Mission and Beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | discovery | The district's belief is about speaking with families, and your sentence is about an email. Your material does not show whether you have spoken with families directly. Answer slot: if you have, say how, how often and about what; if you have not, say so plainly and stay with the email |
| F6 | "work with the grade-level team" — K12 Jobs Board typical listing, from a search result, page not fetched | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | presentation | Say the move in the quote's own words and stop, without adding what leading it involved. Your message says "I've never been a team lead", so the word "led" stays on the move and nowhere else |
| F7 | "assessments inform teaching and never replace it" — Orrinsford Mission and Beliefs page | none given | none | [grounded] | discovery | Your material does not show assessment work either way. Answer slot: if assessment results changed what you taught, say what they showed and what you changed; if that did not happen, or was not yours to decide, say so plainly and say how you would use results |
| F8 | "no student leaves third grade without a reading plan" — Orrinsford Mission and Beliefs page | "I've run the after-school reading club for the last two years" — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | Both sentences are adjacent reading work and neither says anything about reading plans, so they stay at their own scope. Answer slot: if a child in the club or in your class had a reading plan, say who set it and what part was yours; if there was none, or it was not yours, say so plainly and stay with the club |

## Prohibited claims

Built from the fit snapshot before the banks were written. None of these is coached anywhere in the pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or has fourth-grade experience | Negative you stated, F3 | "I've never taught fourth grade." Then "Six years teaching third grade at a public elementary school in Joliet" at its own scope. No slot |
| Has been a team lead, or led the fourth-grade team | Negative you stated, F6 | "I've never been a team lead." Then "I led our grade level's move to a new reading curriculum in 2024" at its own scope, the word "led" staying on the move |
| Chose or designed the new reading curriculum | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation, not words for you: your material says the move, not who chose the curriculum |
| Speaks with every family each term | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says a weekly email, not conversations with families |

## Reading the interviewer

Public professional footprint only. The two team members were not named, so nothing is read about them.

| Fact | Provenance | What it means for you |
|---|---|---|
| Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist | [grounded] | Reading questions will probably go below the curriculum level. Rehearse D2, C3 and F1 |
| Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5 | [grounded] | Small-group reading is her stated subject, so C3 is likely in some form. Answer it as the plan it is unless you have run small groups |
| Shared reading vocabulary, from F8 | [grounded] | Her reading-specialist background and your sentence "I've run the after-school reading club for the last two years" share a subject. Use it to speak her vocabulary, not to claim her expertise |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Provenance | Counter-strategy |
|---|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet, persistent probing of the fourth-grade gap and of "why now" | High. The invite names a panel with the principal as the hiring-side voice, whose prior is Case plus Skeptic, and F3 is a gap you stated | [generic] | Rehearse A2 until it is boring. Bridge only from F2 and F6 at their own scope, plus a plan in your own words |
| Peer Evaluator (bank B, 3) | The two team members asking what you would need and bring, and how you disagree with equals | Medium. Two of the three panelists are grade-team colleagues, whose prior is Peer plus Prober | [generic] | Reciprocity framing: what you bring them, not only what you need. Propose principles for working together instead of pretending to know their routines |
| Case / Strategist (bank C, 3) | Live problems from the role, from the principal | Medium. Hiring-side prior, and the district's August literacy plan gives her live material | [grounded] | Clarify, then objective, approach, how you would check it, risks. Think aloud |
| Conversational (bank D, 3) | Opening "walk us through your journey", family-communication chat | Medium. Any panel opens this way, and casual questions here are still scored | [generic] | A 90-second arc built from your own sentences |
| Values / Behavioral (bank E, 3) | Scenario probes themed on the district's three published beliefs | Medium. The invite names a panel and no values round, so none is detected; the beliefs are published and may still theme questions | [grounded] | Where a sentence of yours carries a story, map it at its own scope; where none does, pick an instance or say so plainly |
| Data-Driven Prober (bank F, 2) | Line-by-line probing of what your CV sentences cover | Low. Your sentences carry years and a frequency but no headline figures; the team peers may still probe the curriculum move | [generic] | Know what you can and cannot say about each sentence, and say "I don't know" where true |
| Pressure (bank G, 2) | Time-boxed, devil's-advocate challenges | Low. No signal in the invite or the research that this panel interrupts | [generic] | Pause, restate, hold on what you wrote, concede what you have never done |

## Question banks

Highest-ROI prep in this pack: **A2**. It is the objection most likely to be asked in some form, and a rehearsed, non-defensive answer changes the interview.

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | Name the gap before they do, in your own words: "I've never taught fourth grade." Then the adjacent fact at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Close with a plan: what you would learn first about the grade and how you would learn it. Say it as a plan, not as something you have done | F3 is a gap you stated, so the plainest form of the question is likely. JD because it scores the role honestly, including its gap |
| A2 | "You've taught third grade, not fourth. What changes for you in fourth grade?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | The deepest rehearsal here. Concede first and specifically: "I've never taught fourth grade." Hold on the one adjacent fact: "Six years teaching third grade at a public elementary school in Joliet." Follow-up 1, what you know about the grade: say what you know, in your own words; if little, say so plainly and say how you would find out. Follow-up 2, why not someone who has taught it: do not claim you are better; return to the six years and the plan. Follow-up 3, your first month: the plan, in your own words. Never add to the quote to win the exchange | F3 is the biggest gap in the material and the one the panel can see on the invite. JD because it scores the stated role |
| A3 | "You led your grade level's move to a new reading curriculum. Have you been a team lead?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | The honest answer is your own sentence: "I've never been a team lead." Then the move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Do not let "led" travel beyond the move. Answer slot: if parts of the move were yours, say which, in your own words; if it was shared, or "led" was smaller than it can sound, say so plainly and return to the move as you wrote it | F6 holds both the word "led" and your statement about team leads, which is where a careful panelist will press. EXP because it tests what was actually yours |
| A4 | "Why fourth grade, why this school, and why now?" | JD | [generic] | Give your actual reasons, because the pack has none from you. Pick the one you would still give on a second ask; two at most. If you cite the district, use only the beliefs you share, from its Mission and Beliefs page named in Sources. No claim about your past is needed, so none is made | F3 makes the motivation probe likely. JD because it scores whether you want the listed job |
| A5 | "Which subjects did you teach in third grade?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: say which subjects you taught, in your own words; if some were taught by someone else, say so plainly and return to the six years | F2 is a typical-listing requirement, and your sentence does not state subjects. JD because it scores a listed responsibility |

### Bank B: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you want from us as the newest member of this team, and what could you bring us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Ask for what you need, and say plainly that fourth grade is the grade you have not taught. Then bring something back at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Offer it as experience of a change, since the district's plan brings a new grades 3–5 reading curriculum from fall 2027. Answer slot: if anything from that move would help a team preparing for a new curriculum, say what, in your own words; if nothing carries over, say so plainly and describe how you work with a team | F6 is your only team-facing evidence, and peers price what a hire adds to their work. JD because it scores the listed team requirement |
| B2 | "Tell me about a time a colleague disagreed with you about how to teach something." | EXP | [generic] | Pick a time with a real disagreement, what each of you wanted for the students, what you did, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Peer prior: disagreement style with equals. EXP because it tests a real past instance; F6 has no sentence about disagreement, so this is a scaffold |
| B3 | "Two colleagues who have taught fourth grade for years plan a unit one way, and you see it differently. What do you do?" | CASE | [generic] | Structure it: ask what they are aiming for, say what you would change and why, defer on grade-specific facts you have not taught, and agree how you would check which worked. Needs no claim about your past | F3 makes the seam concrete for this team. CASE because it is a live scenario |

### Bank C: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader starts in September reading well below grade level. How do you find out where they are, and what do you do first?" | CASE | [grounded] | Say it aloud as a structure: what you would ask first, including what the child's third-grade reading plan said and what the family says; the objective; your approach; how you would check progress; the risks. The question needs no claim about your past, so the guidance makes none | F8's published belief, Every Child a Reader, sets the live problem. CASE because it asks for reasoning, not a record |
| C2 | "The board adopted a literacy plan in August with a new grades 3–5 reading curriculum from fall 2027. What would you want to know about it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Ask before you structure: what changes for fourth grade, on what timeline, with what support for teachers. Do not recite the plan back. If asked about experience with a change, say your sentence as written and stop: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if you can say what the move involved from your side, say it in your own words; if parts were someone else's, say so plainly | The plan comes from the district's own news page (see Sources); F6 is the one link to your background. CO because it tests knowing the district's current direction |
| C3 | "How would you build small-group reading time into a fourth-grade week, and how would you know it's working?" | CASE | [grounded] | Structure it: ask about time and group sizes, state the goal, how you would group children, how you would check progress, the risks. Answer slot: if you have run small groups or reading conferences, say how often and with whom; if you have not, say so plainly and answer as the plan it is | The principal's public talk is on weekly reading conferences in grades 3 to 5 (see Reading the interviewer). F8 shows reading work but not this practice. CASE because it is a live planning problem |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk us through your journey to this application." | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029"; "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc in this order, each beat in your sentence's own words: the licence and endorsement, the six years of third grade, the curriculum move, the reading club, the weekly email. Add no numbers or outcomes. End on your reason for fourth grade, in your own words; the pack has none from you | F1 is the invite's gate, and F3 is the gap the panel will carry through the rest of the session. JD because it opens on the gate, though the delivery is conversational |
| D2 | "What are you thinking about in how you teach reading right now?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | Pick one thing you genuinely are thinking about; the pack does not know it. If it is the curriculum move, the words are "I led our grade level's move to a new reading curriculum in 2024". If it is the club, they are "I've run the after-school reading club for the last two years". Say what you are thinking in your own words | Casual questions about the principal's subject are scored (see Reading the interviewer). F8 holds your reading work. EXP because it tests whether your claims have real thought behind them |
| D3 | "How do you keep families in the loop?" | JD | [grounded] "I write a weekly email to families" | Start with your sentence: "I write a weekly email to families." Answer slot: say what the email holds and how families respond, in your own words; if you have also spoken with families directly, say how often and about what; if you have not, say so plainly and say how you would do it here | F4 is covered by your sentence, and F5 is where the district's belief goes further. JD because it scores a listed responsibility |

### Bank E: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Every Child a Reader is the district's first belief. Tell us about a time you made sure a child had a plan for their reading." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Story-map only at your sentence's scope: "I've run the after-school reading club for the last two years." Answer slot: if a child in the club or in your class had a reading plan, say who set it and what part was yours; if there was none, or it was not yours, say so plainly and describe the club as you ran it, in your own words | F8 is where the belief meets your material. VAL because the theme is a published belief |
| E2 | "Families Are Partners. Tell us about a time a family changed what you did for a child." | VAL | [grounded] "I write a weekly email to families" | Pick a time a family told you something about their child that changed what you did; it needs what they said, what you changed (no child's name), and how it turned out. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I write a weekly email to families", or how you would handle it | F5 sets the district's belief beside your email sentence. VAL because the theme is a published belief |
| E3 | "Teach for Tomorrow, Not for the Test. Tell us about a time assessment results and your own judgment about a child pointed different ways." | VAL | [grounded] | Pick an instance with what the results showed, what you saw, what you did and what followed. If no such time comes to mind, say so plainly, then say how you would weigh results against what you see in class. No sentence of yours carries this story, so none is mapped | F7 has no evidence in your material. VAL because the theme is a published belief |

### Bank F: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk us through the move to a new reading curriculum at your grade level in 2024." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Open with your sentence and nothing before it: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: say what the move involved from your side, which parts were yours and which were shared or someone else's; if you do not remember a detail, say so plainly | F6 and F8 both lean on this sentence, so a peer will probe it. EXP because it tests what was actually yours |
| F2 | "Your weekly email to families: how many families get it, and how do you know it's being read?" | EXP | [grounded] "I write a weekly email to families" | Open with the sentence: "I write a weekly email to families." Answer slot: say how many families receive it and how you counted; say whether you know it is read, and how; if you do not know, say so plainly and name the assumption you would defend least. Offer no figure you cannot back | F4 and F5 rest on this one sentence. EXP because it is the defend-the-figure probe in its mildest form |

### Bank G: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024" | Pause and restate the question. Hold on what the two sentences carry: "Six years teaching third grade at a public elementary school in Joliet" and "I led our grade level's move to a new reading curriculum in 2024". Concede specifically: "I've never taught fourth grade." Do not claim you are better. If interrupted twice, return to the same two sentences instead of adding to them, then close on the plan | F3 in time-boxed form. JD because it scores the stated role |
| G2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Pause and restate. Hold on the sentence: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: which parts were yours and which were shared, in your own words; if it was shared, or smaller than "led" sounds, say so plainly. If pressed on leadership, concede exactly: "I've never been a team lead." Do not fold the core claim | F6 again, in attribution form. EXP because it tests what was actually yours |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 licence gate | D1 |
| F2 subjects | A5 — a typical-listing item, so one question and no more until you share the full posting |
| F3 fourth grade | A1, A2, G1 |
| F4 regular family communication | D3, F2 |
| F5 speaking with every family each term | D3, E2 |
| F6 work with the grade-level team | A3, B1, B3, G2 |
| F7 assessments inform teaching | E3 |
| F8 reading plans | C1, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | To Principal Vantongeren: "You came to the principalship after nine years as a reading specialist. What does that background make you look for when a fourth-grade teacher teaches reading?" | It ties to her own path from the public record, and turns the hardest reading probe into a conversation between two people who care about the same subject |
| R2 | To the team: "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer panel: it shows you are pricing what you add, not only what you need |
| R3 | "How do fourth-grade teachers here get support when they are new to the grade?" | It owns F3 in the open and turns the concession into a plan, as A2 asks |
| R4 | "The board's plan brings a new grades 3–5 reading curriculum from fall 2027. What will fourth grade look like between now and then?" | It shows you read the district's own plan and asks about the part that touches this role |
| R5 | "What do you expect beyond a weekly email for staying in touch with families?" | It maps to the district's published belief about speaking with every family each term, and signals that you saw it |
| R6 | "What does a strong first year in this role look like to you?" | It lets each panelist state what they actually score, and gives you something to aim at |

## Sources

Provided documents: the interview invite from Human Resources, Orrinsford Community School District; your pasted background (licence, teaching, curriculum, reading club, weekly email, and your two statements about fourth grade and team lead). The identification number in your message was not used.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Query or fetch | Returned |
|---|---|
| Search: Orrinsford Community School District mission values | https://orrinsfordschools.example/about/mission-and-beliefs |
| Search: Halvering Elementary School Orrinsford principal Dolores Vantongeren | https://ilprincipalsforum.example/speakers/dolores-vantongeren |
| Search: Orrinsford Community School District strategic plan news | https://orrinsfordschools.example/news/board-adopts-literacy-plan |
| Search: fourth grade teacher job description Illinois elementary school responsibilities qualifications | https://k12jobsboard.example/listings/fourth-grade-teacher (text cut off before its qualifications) |
| Fetch: Mission and Beliefs page | Returned the three beliefs and their one-line definitions |
| Fetch: principal's forum speaker page | Returned her role, tenure and 2025 talk summary |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. District values | yes | F5, F7, F8 and bank E: the three beliefs by name |
| 2. Interview process | skipped | The invite already fixes this session as one panel with the principal and two team members, which sets the persona weights; no values round is named, so section 10 was dropped |
| 3. Strategy and recent news | yes | C2 and R4: the board's August literacy plan. Read from the search result, not fetched |
| 4. Interviewer footprint | yes | Reading the interviewer, C3, D2, R1 |
| 5. Representative posting | yes | F2, F4, F6, labeled inferred. The listing is a typical one from search, not the posting you applied to |

## Upgrade menu

- The full posting text: F2, F4 and F6 move from inferred to grounded, the JD-tagged questions get real raising sources, and the requirement-coverage table is checked against the posting's own list
- Anything the district told you about preparing (a demo lesson, a writing sample, questions sent ahead): adds a build section for each graded deliverable
- The two team members' names: per-member persona weights and an interviewer read for each
- Your answers to the slots in F2, F5, F7 and F8 and to the curriculum-move slots in A3, F1 and G2, stated outside the pack: those rows move from discovery to quoted evidence and the banks that use them are regenerated
- A copy of your licence record: F1 can move from medium to high confidence
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes, adding a grounding brief on the literacy plan, the principal's talks and recent district context
- A prior dossier file, if you have one: a verified objection and strategy limits per weak area, in place of the ones this pack inferred
