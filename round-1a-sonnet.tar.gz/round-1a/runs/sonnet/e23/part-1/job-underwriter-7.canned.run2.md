Reading the underwriting rules is done. Next I'm loading the web search tools to check that the employer and the posting are real.
## Decision snapshot

**Yes, this one is worth applying for, on the conditions below. Status: `conditional_go`.** R1 and R2, both hard gates, are met on your CV. The gaps in R5, R8 and R9 are unconfirmed rather than missing. The Doppler gap (R12) sits in the preferred tier.

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R4, R7 · adjacent: R6 (Catheter and continence care), R10 (Caring for housebound adults at home) · unclear: R5 (Leg-ulcer care), R8 (End-of-life visits), R9 (Clear, timely written records)
- `important` — adjacent: R11 (Small caseload of your own)
- `preferred` — absent: R12 (Doppler assessment)

R5, R8, R9 — wording to firm up with your answers; R6, R10, R11 — bridges from your discharge-to-assess work, limits named in the map; R12 — your stated gap, not a blocker at its tier.

**Opportunity ledger.** The role has real support built in: a senior nurse behind you (RR3), a salary range set against the survey band (RR2) and a team lead who has spoken about Doppler training (RR4). Two things are open: I could not confirm the vacancy is live (RR1), and the hours, on-call and contract basis are not stated (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the vacancy is confirmed open and the closing date known (RR1); (2) R5, R8 and R9 are resolved either way and written up as exactly what you did; (3) R10, R11 and R12 are framed as bridges and a stated gap, never as district-nursing, caseload or Doppler experience (RR3, RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff in four locality hubs | `[grounded]` company About page, found by search |
| Role and mandate | Band 5 community staff nurse in the district nursing team, caring for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration and care planning, on an electronic patient record | `[grounded]` advert |
| Support and caseload | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Essentials and desirable | Essential: NMC Adult registration, full UK driving licence, one year post-registration, clear and timely records. Desirable: Doppler assessment | `[grounded]` advert |
| Pay and car | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Scope read | A conventionally scoped Band 5 community post. The duties are core district-nursing tasks, and the advert expects a first caseload | `[inferred]` from the duty list and the "small caseload" wording |
| Market calibration | A 2026 survey of Band 5 community staff nurses in England (n=1,240) gives median basic pay £34,300 and interquartile range £32,400 to £36,600. The posting's range encloses that interquartile range. In the survey 61% were paid mileage and 24% had a pool or lease car | `[generic]` Wardround 2026 pay guide for the band; `[grounded]` advert for the posting's figures |
| Hiring lead's public footprint | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` community nursing forum speaker page |
| Unknowns | Contract basis (permanent or fixed-term); hours, weekend and on-call pattern; caseload size; induction; closing date | `[grounded]` advert silent |
| Contradictions | None between the advert and the About page on who the employer is. The careers page did not load, so the live posting is not corroborated (RR1) | `[grounded]` About page; careers-page fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Your CV gives a PIN, "registration active", revalidation due March 2028. Nothing inspected yet, so `medium`. The NMC register is public, so the employer can check it | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B. The advert says pool cars are provided | `[grounded]` CV and advert | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, per your CV. A length-of-experience requirement is graded as a requirement, not a gate | `[grounded]` CV | none |
| R4 | Wound care | must_have | direct | medium | none | CV: wound care including pressure ulcers and surgical wounds. Leg ulcers are a separate row (R5) | `[grounded]` CV | A signed wound-care competency record would raise this to `high` |
| R5 | Leg-ulcer care | must_have | unclear | low | discovery | CV is silent on leg ulcers or compression. Your wound care is adjacent, but nothing confirms this task | `[grounded]` CV silence | See G1 |
| R6 | Catheter and continence care | must_have | adjacent | medium | discovery | CV states catheter care. Continence care is not stated, so I took the lower fit | `[grounded]` CV | See G5; add continence work only if it is true |
| R7 | Insulin administration | must_have | direct | medium | none | CV states insulin administration. The advert pairs it with care planning, which the CV does not mention | `[grounded]` CV | none |
| R8 | End-of-life visits | must_have | unclear | low | discovery | CV is silent on end-of-life care. An acute medical ward may include it, but that is not evidence of what you did | `[grounded]` CV silence; `[generic]` that acute medical wards may include end-of-life care | See G2 |
| R9 | Clear, timely written records on an electronic patient record | must_have | unclear | low | discovery | CV does not mention records or any electronic patient record system. Five years of ward work implies documentation but does not show it was timely or electronic | `[grounded]` CV silence; `[inferred]` from the ward role | See G4 |
| R10 | Caring for housebound adults in their own homes | must_have | adjacent | medium | transferability | Eighteen months on a discharge-to-assess team, visiting patients at home in their first week after discharge. Limit: a short post-discharge window, not a long-term housebound caseload | `[grounded]` CV | See G3 |
| R11 | Holding a small caseload of your own, with senior support | important | adjacent | medium | transferability | You told me you have never held your own caseload. Bridge: the home visits on the discharge-to-assess team. Limit: whether those patients were yours to plan and escalate is not established. The advert says a senior nurse supports the post | `[grounded]` your statement, CV and advert | See G3; ask about caseload build-up in the chat with Rhiannon |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have never done one. Closure path: training after appointment. The team lead spoke on Doppler training for staff new to community work, which suggests it may be offered to new starters, though no posting says so | `[grounded]` your statement; `[grounded]` forum page; `[inferred]` that training may be available | Ask whether it is provided (RR4) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R5, must_have) | discovery | Wound care is stated; leg ulcers and compression are not | A must-have duty, and the team lead has spoken publicly on leg-ulcer clinics | Dressing venous leg ulcers on the ward; applying or reviewing compression bandaging or hosiery; escalating a leg wound for vascular review | A signed wound-care competency record or a training certificate | `[grounded]` CV silence; `[grounded]` forum page on the lead's talk |
| G2 | End-of-life care (R8, must_have) | discovery | CV is silent | An advertised duty. Resolving it moves a `must_have` row | Caring for dying patients on the ward; anticipatory medicines or symptom-control reviews; supporting families; rapid discharge home to die | A reflective account or an end-of-life training record | `[grounded]` CV silence; `[generic]` that this is a recurring duty in district nursing |
| G3 | Own-caseload autonomy (R10, R11) | transferability | Home visits on the discharge-to-assess team are stated; who planned the visits and who decided escalation is not | The advert expects a first caseload and offers senior support, so this decides how you frame the bridge | Planning your own visit round; deciding when to escalate to a GP or senior nurse; following a patient across several visits | A team rota or a discharge-to-assess pathway description | `[grounded]` CV and advert. Not asked this turn; carried |
| G4 | Records and electronic patient record (R9, must_have) | discovery | CV does not mention documentation or any electronic patient record | An essential in the advert | Which electronic record system you used; audit results on documentation; timeliness standards you worked to | An audit extract or a system name on the CV | `[grounded]` CV silence. Carried; no question this turn |
| G5 | Continence care (R6, must_have) | discovery | Catheter care is stated; continence care is not | The advert pairs the two | Bladder and bowel assessment; continence product or pad assessment; catheter trials without catheter | A competency record | `[grounded]` CV and advert. Carried; no question this turn |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not corroborated on the employer's site | risk_signal | low | "Current vacancies are listed on our careers page." | The page may have moved, the vacancy may be listed elsewhere, or the posting may be stale. Severity is `low` because the employer is established from its own About page | `[grounded]` the careers-page fetch returned no page; `[generic]` that listings often move | Is this vacancy open now, and what is the closing date? | unresolved |
| RR2 | Pay range encloses the survey's interquartile range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Pay is set at a market-normal level for the band, so a start low in the range would be a normal outcome | `[grounded]` advert figures; `[generic]` survey band, a pattern and not this employer's offer | Where in the range would someone with five years' ward experience and no community post be appointed? | noted |
| RR3 | Senior support stated | positive_signal | — | "supported by a senior community nurse" | The small caseload is built up with support, which fits a first community post | `[grounded]` advert | What induction and caseload build-up does a nurse new to district nursing get? | noted |
| RR4 | Doppler is desirable, and the lead has spoken on training | positive_signal | — | "Desirable: Doppler assessment for leg ulcers" | Training may be available to new starters | `[grounded]` advert and forum page; `[inferred]` that training may be offered | Is Doppler training provided on appointment, and how soon? | unresolved |
| RR5 | Hours, on-call, weekends and contract basis unstated | unknown | — | "Join our district nursing team" | Community nursing often runs a weekend rota, and the post may be anything from permanent to fixed-term | `[generic]` pattern for community nursing posts, not a claim about this employer | What is the working pattern, including weekends and on-call, and is the post permanent? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the vacancy is open and when it closes, through the employer's careers page or by asking Rhiannon | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Use the informal chat the advert offers to ask the RR2, RR3, RR4 and RR5 questions word for word | The register doubles as call preparation | `[grounded]` advert and register | pending your approval |
| E1 | Put the 18-month discharge-to-assess secondment and home visiting first on the CV. Make wound care (pressure ulcers, surgical wounds), catheter care and insulin administration visible bullets, using only your CV's facts | see R4, R6, R7, R10. Reorders and surfaces; adds no new fact | `[grounded]` CV | pending your approval |
| E2 | Say the caseload gap in your own words: "I haven't held my own caseload; for 18 months I visited patients at home on a discharge-to-assess team" | see R11. Candour about the limit reads better than spin | `[grounded]` your statement and CV | pending your approval |
| E3 | Say you have not done a Doppler assessment and ask whether training is provided. Do not claim district-nursing or Doppler experience | see R12 | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet. Everything above from your CV is a lead until you confirm it or attach proof. I did not use the National Insurance number you included. It isn't needed to judge this role, and you should leave it off applications until an employer asks for it at the right stage.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Role reality's organization and contradictions rows; RR1 |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 salary Calderdale Yorkshire", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Role reality's market calibration; RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook Community Health", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Role reality's footprint row; R12 and RR4 |

## Upgrade menu

- A link to the live posting, or the vacancy listed on the employer's own careers page → RR1 closes; the first condition for go is met.
- Your answers to G1 and G2 → R5 and R8 move off `unclear`, or settle as honest gaps.
- A signed wound-care or catheter competency record, or an extract of your online NMC register entry → R1, R4 and R6 can rise to `high`.
- Your answers to G3, G4 and G5 → R10, R11, R9 and R6 firm up.
- Your non-negotiables (pay floor, hours, weekends, notice period) → the hard-gate checks against you stop reading "unknown".
- A deeper research pass on Calderbrook Community Health (leadership changes, staff and candidate reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

I can turn this into `tuesday-dossier.md` whenever you like.

**G1** — Have you personally dressed venous leg ulcers or applied or reviewed compression bandaging or hosiery? Were you signed off for it, and how often?
**G2** — Have you personally cared for dying patients, whether on the ward or on the discharge-to-assess team? What was yours to do, such as symptom review, anticipatory medicines, or talking with families?
**Constraints** — Do you have non-negotiables I should check the role against, such as a pay floor, no weekends or on-call, or a notice period?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.