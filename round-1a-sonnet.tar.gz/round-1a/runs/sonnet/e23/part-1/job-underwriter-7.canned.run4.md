Checking whether Calderbrook exists and the posting is live, then running the pay and role-scope sweep. After that I'll write the assessment.
## Decision snapshot

**Yes, this one is worth applying for. R13 (Doppler) and R10 (own caseload) are the honest gaps to name. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R6 · adjacent: R5 (Care for housebound adults in own homes) · unclear: R4 (Clear, timely written records)
- `important`: direct: R9 · adjacent: R8 (Catheter and continence care), R10 (Own small caseload and care planning) · unclear: R7 (Leg-ulcer care), R11 (End-of-life visits), R12 (Electronic patient record)
- `preferred`: absent: R13 (Doppler assessment for leg ulcers)

R10 is a first caseload with a senior supporting; R13 is a trainable preferred item; R4, R7, R11, R12 are CV silences you can answer in a sentence each.

**Opportunity ledger.** The post states its pay range, pool cars and a named senior-support arrangement (RR4, RR5). Whether the posting is still open (RR1), the employment terms of a CIC (RR2) and the working pattern (RR3) are unconfirmed.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed live (RR1); (2) the employment terms are confirmed (RR2); (3) records evidence for R4 and R12 is confirmed and on the CV.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health: a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` its About page, read as a search snippet |
| Posting status | Not confirmed live: the careers page address tried returned no page (RR1) | `[grounded]` fetch result |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration and care planning, recorded on an electronic patient record | `[grounded]` JD |
| Autonomy and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Essentials as written | NMC Adult registration; full UK driving licence (pool cars provided); at least one year post-registration; clear, timely written records. Doppler is desirable | `[grounded]` JD |
| Scope read | An entry-level community post: small caseload, senior support, Doppler only desirable | `[inferred]` from the JD's caseload and support wording |
| Market calibration | The advertised £31,050–£37,800 spans the survey's interquartile range of £32,400–£36,600 and its median of £34,300 for England community staff nurses at Band 5. Pool cars are the less common arrangement there (24% had a pool or lease car; 61% were paid mileage) | `[grounded]` JD for the advertised range; `[generic]` survey snippet (Wardround 2026 pay guide), a pattern and not this employer's offer |
| Hiring contact | The advert's named contact leads the Halifax district nursing team and has spoken on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. Whether Calderbrook provides Doppler training is unknown | `[grounded]` public speaker listing, read as a search snippet |
| Unknowns | Employment terms for a CIC; hours, weekends and on-call; caseload size; mileage rate; Doppler training provision | `[inferred]` from the JD's silence |
| Contradictions | None between the JD and the About page; both place the service in Calderdale | `[grounded]` About page snippet and JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Your CV states Registered Nurse (Adult), active, revalidation due March 2028. Self-reported and not checked against the NMC register in this analysis | `[grounded]` CV | none needed; a register-entry screenshot would raise to high |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Full licence, category B, stated by you; nothing inspected | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward at a district general hospital | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | The CV says nothing about record-keeping, so there is no claim to grade yet | `[grounded]` CV silence | see G1 |
| R5 | Caring for housebound adults in their own homes | must_have | adjacent | medium | transferability | Eighteen months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge. Limit: that is short-term post-discharge visiting, and it is not stated whether those patients were housebound or long-term | `[grounded]` CV | see G3 |
| R6 | Wound care (the advert pairs it with leg-ulcer care) | must_have | direct | medium | none | Your CV names wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R7 | Leg-ulcer care | important | unclear | low | discovery | Leg ulcers and compression therapy are not named in your account | `[grounded]` CV silence | see G2 |
| R8 | Catheter and continence care | important | adjacent | medium | discovery | Catheter care is stated; continence care beyond catheters is not | `[grounded]` CV | fold into the Q2 answer if relevant; otherwise carried as minor |
| R9 | Insulin administration | important | direct | medium | none | Insulin administration is stated on your CV | `[grounded]` CV | none |
| R10 | A small caseload of your own, with care planning | important | adjacent | low | transferability | You have never held your own caseload. Adjacent: home visiting in the discharge-to-assess role. Limit: whether you planned your own visits or worked alone in homes is not stated. Taking the lower band where the two claims differ | `[grounded]` your statement and CV | see G3 |
| R11 | End-of-life visits | important | unclear | low | discovery | Nothing in the CV on end-of-life care | `[grounded]` CV silence | see G2 |
| R12 | Recording on an electronic patient record | important | unclear | low | discovery | The JD says all care is recorded on an electronic patient record. Requirement inferred from that sentence; the CV names no record system | `[inferred]` from the JD sentence | see G1 |
| R13 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have never done a Doppler assessment. A 2025 talk by the team lead on Doppler training for staff new to community work is a lead to ask about | `[grounded]` your statement; speaker listing | state it plainly; ask about training in the informal chat (A1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Record-keeping and electronic records (R4, must_have; R12, important) | discovery | The CV names no record system and says nothing on record quality | R4 is a `must_have` row and the one thing a short answer can move from `unclear` | An electronic record you entered observations or discharge notes on; notes written on home visits; a documentation audit result; record-keeping training you signed off | An audit summary, a training certificate, a reference line | `[grounded]` CV silence; `[generic]` that community posts of this kind are screened on written records |
| G2 | Leg-ulcer and end-of-life care (R7, R11, important) | discovery | Wound care is stated, but leg ulcers and end-of-life care are not named | Two named duties in the JD; either could be `direct` if the work exists | Compression bandaging, ward or tissue-viability link work, caring for a dying patient at home on a discharge visit, contributing to an end-of-life plan | A wound-care competency record, a training certificate | `[grounded]` CV silence |
| G3 | Own visits and caseload (R5, must_have; R10, important) | transferability | Home visiting is stated. Whether you set your own visit list, worked alone in homes or wrote care plans is not | The bridge from ward to caseload rests here; the limit has to be named wherever it is used | Sequencing your own visits; deciding when to escalate to a GP or a district nursing team; a patient list you were responsible for in a given week | A role description for the discharge-to-assess team, a reference | `[grounded]` CV; `[inferred]` that this is where an interviewer would probe |
| G4 | Doppler assessment (R13, preferred) | capability | No Doppler experience, by your own account | A preferred item, not an essential | A closure path, not a recall prompt: training provided on appointment, or a course | A course certificate, if you later complete one | `[grounded]` your statement; the training question is on the register (RR3) |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Join our district nursing team" | The page may have moved, or the post may be closed or stale | `[generic]` pattern for postings copied between sites; `[grounded]` the careers fetch returned no page | Is this post currently open, and what is the closing date? | unresolved |
| RR2 | Employment terms for a CIC unstated | unknown | — | "£31,050–£37,800 a year plus mileage" | Pension, sick pay and leave terms may differ from an NHS trust's | `[inferred]` from the CIC status against the JD's silence | Is this post on Agenda for Change terms, and with which pension? | unresolved |
| RR3 | Working pattern and training unstated | unknown | — | "hold a small caseload of your own" | Hours, weekend or on-call duty, caseload size and Doppler training may be unspecified | `[inferred]` from the JD's silence | What hours and weekend or on-call duty does the post carry, how large is the caseload, and is Doppler training provided? | unresolved |
| RR4 | Pool cars, named support, informal-chat contact | positive_signal | — | "pool cars are provided"; "supported by a senior community nurse"; "informal chat" | The role is supervised and supplied, not left to a new starter alone | `[grounded]` JD; `[generic]` that pool cars are the minority arrangement in the survey | Who is the senior community nurse, and how much supervised time do new starters get? | noted |
| RR5 | Pay range disclosed and consistent with the survey | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range is transparent and typical | `[grounded]` JD; `[generic]` survey band | What is the mileage rate? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move your own line "last 18 months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge" to the top of your experience, in your wording | R5 | `[grounded]` CV | resume_edits_pending_approval |
| E2 | Show "Wound care including pressure ulcers and surgical wounds; catheter care; insulin administration" as a skills line near the top, in the same words; add no leg-ulcer, continence, caseload or Doppler claim | R6, R8, R9 | `[grounded]` CV | resume_edits_pending_approval |
| E3 | In the supporting statement, say: "I have not held my own caseload and have not done Doppler assessment." | R10, R13 | `[grounded]` your statement | pending your approval |
| A1 | Take up the informal chat with the named team lead and use RR1 to RR3's questions, plus Doppler training | RR1–RR3, R13 | `[grounded]` JD | pending your approval |
| A2 | Confirm the post is open before writing the application | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet. Not used: the National Insurance number in your message, which is not needed to evaluate a role.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax community staff nurse Band 5", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about), read as a snippet. The fetch of calderbrookhealth.example/careers returned no page. Moved role reality's organization row and RR1 |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing pay scale Agenda for Change 2026/27", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide), read as a snippet. Moved market calibration and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott), read as a snippet. Moved the scope read and A1 |

If you want, I can write this up as `tuesday-dossier.md`.

## Upgrade menu

- A link to the live posting, or the careers page → RR1 closes.
- The recruiter's or team lead's answer on terms and hours → RR2 and RR3 close.
- A wound-care or catheter competency sign-off, or a training certificate → R6, R8, R9 to `high`.
- An NMC register-entry screenshot → R1 to `high`.
- A documentation audit or reference line → R4 and R12 move from `unclear`.
- A deeper research pass on Calderbrook (staff and service reports, news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — Which electronic record system(s) have you recorded in on the ward and in the discharge-to-assess team, and has your record-keeping ever been audited or commended?

G2 — Have you done compression bandaging or leg-ulcer care, or cared for a patient at end of life at home, and what did you personally do?

G3 — In the discharge-to-assess team, did you plan your own visit list, work alone in patients' homes or write care plans, and what was yours versus the team's?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.