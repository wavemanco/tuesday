I'll read the reference files the skill points to before building the assessment.
**Yes, worth applying. R1 and R2, the hard gates, are met on your CV, and R3 (the one-year experience requirement) is direct. The two things you flagged, R11 (own caseload) and R12 (Doppler), are an adjacent row and a desirable-tier row. Status: `go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · adjacent: R5 (caring for housebound adults) · unclear: R4 (clear, timely written records)
- `important`: direct: R6a, R7a, R9 · adjacent: R11 (small caseload of your own) · unclear: R6b (leg-ulcer care), R7b (continence care), R8 (end-of-life visits), R10 (care planning)
- `preferred`: absent: R12 (Doppler assessment)

R12 — preferred tier, desirable not essential; R5 and R11 — adjacent through your discharge-to-assess home visits; R4, R6b, R7b, R8 and R10 — your CV is silent, so these are discovery gaps, not capability gaps.

**Opportunity ledger.** The employer exists as described and the pay band sits around the market figure I found (RR2). Supervision is built in (RR3). Two things are unconfirmed: the posting could not be confirmed live (RR1), and the rota and contract terms are not stated (RR4). Whether Doppler training is provided is also unstated (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the post turning out to be closed (RR1), or a rota, hours or contract term (RR4) that conflicts with a constraint you haven't given me.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` search result, "About Calderbrook Community Health" |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration, care planning, on an electronic patient record | `[grounded]` JD |
| Working pattern | A small caseload of your own, supported by a senior community nurse; pool cars provided; mileage paid on top of salary | `[grounded]` JD |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse; at the 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` speaker page, "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" |
| Scope read | A first-caseload community post with named supervision, not a stand-alone senior role | `[inferred]` from the JD's "small caseload" and "supported by a senior community nurse" |
| Market calibration | Band 5 community staff nurses in England: median basic pay £34,300, interquartile range £32,400 to £36,600; 61% paid mileage, 24% had a pool or lease car. The posting's £31,050–£37,800 spans that range. One survey, so a pattern and not this employer's offer | `[generic]` Wardround 2026 pay guide (n=1,240); `[grounded]` JD for the posted band |
| First-90-days outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Whether the post is open; rota, weekend and on-call pattern; contract basis and hours; caseload size and length of supervised period; whether Doppler training is provided | `[grounded]` JD silent on each |
| Contradictions | None between the posting and the About page; the careers page could not be fetched (see RR1) | `[grounded]` About page snippet; careers page fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states Registered Nurse (Adult), PIN 19F4417X, active, revalidation due March 2028; self-reported, register entry not inspected | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states category B full licence; the JD says pool cars are provided. Self-reported | `[grounded]` CV and JD | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, per the CV; this is a length-of-experience requirement, not a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | CV is silent on documentation and on any electronic record system; the JD names its own electronic patient record | `[grounded]` CV silence, JD text | Question G4 held for a later turn |
| R5 | Caring for housebound adults in their own homes | must_have | adjacent | medium | transferability | 18 months visiting patients at home in their first week after discharge; limit: a short post-discharge window, not ongoing care of long-term housebound patients. The JD lists this as the role's mandate, not under Essential | `[grounded]` CV; `[inferred]` bridge | Bridge in E1 |
| R6a | Wound care | important | direct | medium | presentation | CV lists wound care including pressure ulcers and surgical wounds; it sits in a skills list and isn't tied to home care | `[grounded]` CV | E1 |
| R6b | Leg-ulcer care | important | unclear | low | discovery | CV mentions pressure ulcers and surgical wounds, not leg ulcers; the adjacent wound work is indirect context | `[grounded]` CV | Question G2 |
| R7a | Catheter care | important | direct | medium | none | CV lists catheter care | `[grounded]` CV | none |
| R7b | Continence care | important | unclear | low | discovery | CV states catheter care only; continence care is not claimed | `[grounded]` CV | Question G5 held for a later turn |
| R8 | End-of-life visits | important | unclear | low | discovery | CV silent; the acute ward and discharge team are context only, not a claim | `[grounded]` CV silence | Question G3 held for a later turn |
| R9 | Insulin administration | important | direct | medium | none | CV lists insulin administration; the JD's "and care planning" is carried separately as R10 | `[grounded]` CV | none |
| R10 | Care planning | important | unclear | low | discovery | CV silent on care planning; discharge-to-assess work is indirect context | `[grounded]` CV silence | Question G5 held for a later turn |
| R11 | Holding a small caseload of your own | important | adjacent | medium | transferability | You told me you have never held your own caseload; the bridge is your discharge-to-assess home visits, and its limit is that nothing says they were a standing list you owned. The JD supports a first caseload with a senior nurse | `[grounded]` your statement, CV, JD | Question G1 |
| R12 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You told me you have never done one; no adjacent evidence | `[grounded]` your statement | Closure path in G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload (R11, important) | transferability | Home visits in the first week after discharge; no stated list you owned | A caseload is a stated duty, and a bridge with its limit named reads weaker and interviews stronger | Planning your own day's visits; deciding visit frequency; escalating or handing over to community teams | Secondment role description, a service leaflet, a reference from the discharge-to-assess lead | `[grounded]` CV and your statement; `[inferred]` that these would count |
| G2 | Leg-ulcer care (R6b, important) | discovery | Pressure ulcers and surgical wounds only | Leg-ulcer care is named in the JD's opening line and Doppler is desirable | Dressing venous leg ulcers; applying compression; tissue viability link-nurse work; leg-ulcer training | Competency record, training certificate | `[grounded]` JD and CV |
| G3 | End-of-life visits (R8, important) | discovery | CV silent | A named duty | Verifying expected death; anticipatory medicines; end-of-life care plans; family conversations | Training record, end-of-life course certificate | `[grounded]` CV silence |
| G4 | Written records and electronic patient record (R4, must_have) | discovery | CV silent on records | Essential on the posting | An electronic record on the ward or in the team; documentation audits | Record system name, an audit result | `[grounded]` CV silence, JD |
| G5 | Continence care and care planning (R7b, R10, important) | discovery | Catheter care stated; continence and care planning not | Both are named duties | Bladder and bowel assessment; writing discharge or care plans | Competency record, an anonymised plan format | `[grounded]` CV silence |
| G6 | Doppler assessment (R12, preferred) | capability | None, in your words | Desirable, not essential. Calderbrook's team lead has spoken publicly on Doppler training for staff new to community work | A Doppler course or a supervised competency programme | A training provider's course record | `[grounded]` your statement and the speaker page |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The careers page returned no page, so the post may be closed, hosted elsewhere, or the page may have moved | `[grounded]` the fetch returned no page; `[inferred]` the causes | Is this post currently open, and what is the closing date? | unresolved |
| RR2 | Pay band brackets the market figure | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Posted band spans the surveyed interquartile range for this title; pool cars provided | `[grounded]` JD band; `[generic]` survey band, one source | What mileage rate applies, and where in the band would my experience place me? | noted |
| RR3 | Supervision built into a first caseload | positive_signal | — | "supported by a senior community nurse" | A first caseload comes with a named senior | `[grounded]` JD | How is that supervision structured, and how large is a starting caseload? | noted |
| RR4 | Rota, hours and contract basis unstated | unknown | — | "end-of-life visits" | Visiting end-of-life patients may involve evening or weekend work, which the posting doesn't describe | `[inferred]` from the JD's duties against its silence on shifts and contract | What are the shift pattern, weekend and on-call expectations, and is the post permanent? | unresolved |
| RR5 | Doppler training provision unstated | unknown | — | "Desirable: Doppler assessment for leg ulcers" | Doppler may be taught on appointment; the team lead has spoken on training staff new to community work | `[grounded]` speaker page; `[inferred]` that it applies to this post | Is Doppler training offered on appointment, and how soon? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put your discharge-to-assess work near the top of the CV in your own words: "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge" | See R5, R11 | `[grounded]` your CV sentence | pending your approval |
| A1 | In the application, say plainly that you have not held your own caseload and have not done Doppler assessment | See R11, R12; your own statements | `[grounded]` your statements | pending your approval |
| A2 | Take up the offered informal chat with Rhiannon Mabbott and ask the RR1, RR3, RR4 and RR5 questions | The JD invites it; the register's questions are written to be asked aloud | `[grounded]` JD, register | pending your approval |

These rows are proposals. Nothing goes on your CV or to the employer until you approve it, and that covers E1's wording and the A1 and A2 advice alike (`resume_edits_pending_approval`).

## Evidence status

Verified: none yet. I haven't used the National Insurance number in your message; it isn't needed to evaluate a role.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC Community Staff Nurse Band 5 district nursing Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about); fetched calderbrookhealth.example/careers, which returned no page. Role reality's organization and contradictions rows; RR1 |
| 2. Role-family sweep | yes | Searched "district nurse Band 5 community staff nurse Agenda for Change pay scale 2026/27 Doppler training requirement", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration and RR2; one survey source |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Role reality's team-lead row, G6, RR5 |

I can turn this into a `tuesday-dossier.md` whenever you want one.

## Upgrade menu

- A link to the live posting, such as the employer's listing or a recruiter email, closes RR1.
- Your NMC register entry link would let me read it and raise R1 toward `high`.
- A secondment role description or a reference from the discharge-to-assess lead would strengthen R5 and R11.
- Your non-negotiables (pay floor, hours, days, shifts) would let the hard-gates line check against them instead of flagging them unknown, and would settle RR4.
- A deeper research pass on Calderbrook (funding, leadership changes, staff and candidate reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

1. **Constraints.** Do you have any non-negotiables for this role, such as a pay floor, days or hours you can't work, or a limit on weekend or on-call work?
2. **G1.** In the discharge-to-assess secondment, did you plan your own list of visits and decide visit frequency or escalation yourself, and who set or reviewed your list?
3. **G2.** Have you ever dressed or managed a venous leg ulcer, applied compression, or done any leg-ulcer training, on the ward or in the team?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.