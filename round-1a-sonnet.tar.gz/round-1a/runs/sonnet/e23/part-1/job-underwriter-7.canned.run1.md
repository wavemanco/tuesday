I've run three searches and I'm now fetching the employer's careers page to check the posting is live and matches your paste.
## Decision snapshot

**Yes, this is worth applying for. You meet the two gates, R1 and R2, and the main step up is from ward and home-discharge work to a community caseload. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R6 · adjacent: R5 (housebound adults in their own homes) · unclear: R4 (clear, timely written records)
- `important` — direct: R8, R10 · adjacent: R7 (leg-ulcer care), R13 (small caseload of your own) · unclear: R9 (continence care), R11 (care planning), R12 (end-of-life visits)
- `preferred` — absent: R14 (Doppler assessment)

R5, R13 — the step from ward and discharge-to-assess visiting to a community caseload; R4, R9, R11, R12 — CV silent, closable by your answers; R7 — leg ulcers not on the CV; R14 — preferred, not held.

**Opportunity ledger.** Sound on what is visible: supported caseload (RR2), a team lead with published Doppler-training work (RR3), and a pay range that spans the survey's interquartile range (RR4). Open points are whether the post is live (RR1), mileage alongside pool cars (RR5), and hours and terms (RR6).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The post is confirmed live on Calderbrook's own careers page (RR1).
  2. Your record-keeping, and any electronic record use, is confirmed in your own words (R4, G1).
  3. The caseload and Doppler gaps are stated plainly as gaps, not papered over (R13, R14).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health: a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` About page, found by search |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning; small own caseload, supported by a senior community nurse | `[grounded]` advert |
| Scope read | Entry-level community post with a named support structure, not a lone-practitioner role | `[inferred]` from "small caseload" and "supported by a senior community nurse" |
| Hiring manager | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse; spoke at a 2025 forum on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Market calibration | A 2026 survey of Band 5 community staff nurses in England puts median basic pay at £34,300 (interquartile range £32,400 to £36,600); 61% were paid mileage and 24% had a pool or lease car. The advert's £31,050–£37,800 spans that range. The survey is a pattern, not Calderbrook's offer | `[generic]` role-family sweep, one salary-survey search; `[grounded]` advert for its own figures |
| Unknowns | Hours and rota; weekend or evening work; lone-working arrangements; pension and other terms; mileage alongside pool cars; whether the post is live | — |
| Contradictions | None between the advert and the About page; the careers page could not be fetched, so the posting itself is unconfirmed | `[grounded]` About page; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states registered nurse (adult), PIN given, active, revalidation due March 2028. Self-reported at intake, so `medium`; the NMC register is the inspectable artifact | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full licence, category B. Nothing inspected, and a licence document is not needed at this stage | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. This is an experience requirement, so it is graded as fit, not as a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | CV is silent on documentation and on any electronic record. Ward nursing normally involves record-keeping, but no practice is stated, so none is claimed | `[grounded]` CV silence; `[generic]` that ward work involves records | G1 |
| R5 | Caring for housebound adults in their own homes | must_have | adjacent | medium | transferability | 18 months visiting patients at home in their first week after discharge is real home-based care. Limit: short post-discharge episodes, not ongoing care of housebound adults | `[grounded]` CV; `[inferred]` on the limit, from the CV's "first week after discharge" | G6 |
| R6 | Wound care | must_have | direct | medium | none | CV names pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R7 | Leg-ulcer care | important | adjacent | medium | transferability | Pressure-ulcer and surgical-wound care is adjacent; leg ulcers are not on the CV | `[grounded]` CV; `[inferred]` adjacency | G5 |
| R8 | Catheter care | important | direct | medium | none | CV names catheter care | `[grounded]` CV | none |
| R9 | Continence care | important | unclear | low | discovery | Not stated on the CV; catheter care is related but is not the same thing | `[grounded]` CV silence | G3 |
| R10 | Insulin administration | important | direct | medium | none | CV names insulin administration | `[grounded]` CV | none |
| R11 | Care planning | important | unclear | low | discovery | CV is silent | `[grounded]` CV silence | G4 |
| R12 | End-of-life visits | important | unclear | low | discovery | CV is silent. Acute medical wards often care for dying patients, but nothing is stated | `[grounded]` CV silence; `[generic]` ward pattern | G2 |
| R13 | A small caseload of your own | important | adjacent | medium | transferability | You say you have never held a caseload. The bridge is home visits on the discharge team; whether you planned them yourself is unknown | `[grounded]` your statement and CV | G6 |
| R14 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You say you have never done one. It is desirable, not essential | `[grounded]` your statement | closure path in plan row A3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records, electronic patient record (R4, must_have) | discovery | No mention of documentation or systems | The only `must_have` row below `adjacent`; the advert asks for clear, timely records | Documenting visits on the discharge team; the ward's electronic record; handover or discharge summaries | A system name, an audit or documentation feedback | `[grounded]` CV silence; `[inferred]` that an answer could lift R4 |
| G2 | End-of-life visits (R12, important) | discovery | Nothing on palliative or end-of-life care | Part of the advertised work | Caring for dying patients on the ward; anticipatory medication; family support | A reflective account or training record | `[grounded]` CV silence |
| G3 | Continence care (R9, important) | discovery | Catheter care only | Advertised alongside catheters | Bladder and bowel care on the ward; assessing continence needs | A training record | `[grounded]` CV silence |
| G4 | Care planning (R11, important) | discovery | Nothing on care planning | Advertised and tied to the caseload | Writing or updating plans on the ward or discharge team | An anonymised plan | `[grounded]` CV silence |
| G5 | Leg-ulcer care (R7, important) | transferability | Other wound care only | The advert names it, and the hiring manager has published on leg-ulcer clinics | Dressing or assessing leg wounds; any compression experience | A competency record | `[grounded]` CV and forum page; `[inferred]` the bridge |
| G6 | Own caseload, home-based care (R13 and R5) | transferability | Discharge-to-assess home visits, no caseload | The biggest step in the role, and the advert pairs it with senior support | Planning your own visit list; escalation decisions made alone | A rota or job description for the secondment | `[grounded]` CV and your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's careers page | unknown | — | "Join our district nursing team" | The careers page may be down, moved, or the post may have closed | `[inferred]` from the failed careers fetch | Is this post still open, and what is the closing date? | unresolved |
| RR2 | Supported, small caseload | positive_signal | — | "small caseload of your own, supported by a senior community nurse" | Stated structure suggests a post designed for newer community nurses | `[inferred]` from the advert wording | How is the caseload built up, and how long before I hold it? | noted |
| RR3 | Team lead has published on Doppler training for new community staff | positive_signal | — | "Doppler training for staff new to community work" (forum page, not the advert) | The service may train new starters in Doppler assessment | `[inferred]` from one forum page; it does not say Calderbrook offers it | What Doppler and leg-ulcer training and sign-off do new starters get? | noted |
| RR4 | Stated pay | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range sits around the survey median; where an offer would fall is unknown | `[grounded]` advert; `[generic]` survey | Where in the range would this post be offered? | unresolved |
| RR5 | Pool cars and mileage both stated | unknown | — | "pool cars are provided"; "plus mileage" | Mileage may apply to some journeys or to staff using their own car | `[inferred]` from the two phrases side by side | When is mileage paid if pool cars are provided? | unresolved |
| RR6 | Hours, rota and terms unstated | unknown | — | (silent) | Weekend, evening or lone-working duties may exist; pension terms are not stated | `[generic]` community nursing often involves rotas | What are the working hours and rota, and what pension and terms apply? | unresolved |

## Application plan

Every row and block below is proposed and finalised only on your approval. That covers the CV edit, the framing lines and the action rows alike: `resume_edits_pending_approval`.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Open the CV with: "Adult nurse (NMC registered). Five years as a staff nurse on an acute medical ward at a district general hospital; the last 18 months seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge. Full UK driving licence, category B." | Puts the home-visiting work first (R5, R13). Every clause is from your CV | `[grounded]` your CV | `resume_edits_pending_approval` |
| E2 | Add a records line only after you answer G1, in your own words | Nothing about documentation is stated yet, so none is written (R4) | `[grounded]` G1 | pending your approval |
| F1 | Say plainly: "I haven't held my own caseload; my home visiting has been on discharge-to-assess" and "I haven't done Doppler assessment and I'd want to train in it" | Both are your own statements (R13, R14) | `[grounded]` your statements | pending your approval |
| A1 | Phone Rhiannon Mabbott for the informal chat, using the questions in RR1, RR3, RR5, RR6 | The advert invites it; the register doubles as chat prep | `[grounded]` advert, register | pending your approval |
| A2 | Check the post is live on Calderbrook's careers page before drafting | RR1 | `[grounded]` RR1 | pending your approval |
| A3 | Doppler closure path: ask about in-service training in the chat; any outside course is for you to weigh | R14 is preferred and the hiring manager has published on this training (RR3) | `[inferred]` from RR3 | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Your National Insurance number was in your message. It isn't needed to assess a role, so I haven't used it and it appears nowhere above.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). That confirmed the employer exists as described. A fetch of calderbrookhealth.example/careers returned no page, so the posting is unconfirmed (RR1) |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 salary Agenda for Change 2026/27 pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). It fed the market calibration and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). It fed the scope read and RR3 |

I can write this up as `tuesday-dossier.md` if you want to carry it forward.

**Upgrade menu**
- A direct link to the role on Calderbrook's careers page would settle RR1.
- Your answer to G1 could lift R4 and unlock a records line on the CV.
- Your answers on G2, G3 and G4 could lift R12, R9 and R11.
- Anything showing you plan your own visits (a rota, secondment description) would firm up R13 and R5.
- Any stated constraints, such as a pay floor, hours or rota limits, would let me check hard gates against them.
- A deeper research pass on Calderbrook (public employee and candidate reports, recent news, leadership changes): up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions**

G1 — On the ward and on the discharge team, what did you record after patient contacts, and was it on an electronic system? Roughly how soon after each contact? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G6 — On the discharge-to-assess secondment, did you plan your own visit list and decide when to escalate, or visit to a list someone else set?

G2 — Have you cared for dying patients, on the ward or on home visits? What was your part in it?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.