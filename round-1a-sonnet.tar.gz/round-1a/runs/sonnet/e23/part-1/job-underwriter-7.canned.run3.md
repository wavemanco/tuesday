I'll read the reference files the skill points to before building the assessment.
Research is done, so I'm now writing up the assessment.

## Decision snapshot

**Yes, this is worth applying for, as `conditional_go`.** R1 and R2, the hard gates, are met on your CV, and R3 is direct. R4 (written records) needs your own account before the case is firm.

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (clear, timely written records)
- `important`: direct: R5, R7a, R8a · adjacent: R6 (leg-ulcer care), R10 (housebound adults at home), R11 (own caseload) · unclear: R7b (continence care), R8b (care planning), R9 (end-of-life visits)
- `preferred`: absent: R12 (Doppler assessment)

R6, R10, R11 — adjacent, so the bridge and its limit have to be stated; R4, R7b, R8b, R9 — your CV is silent, which is not the same as absent; R12 — absent, and marked desirable in the advert.

**Opportunity ledger.** The post looks sound on duties, senior support and pay (RR2, RR6). Four things remain unknown: whether the posting is live (RR1), what induction is offered (RR3), the working pattern (RR4) and the contract terms (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live with a closing date (RR1); (2) you confirm your record-keeping in your own words (R4); (3) R6, R10, R11 and R12 are presented as adjacent or absent, never as direct experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC runs adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. It was founded in 2015 and has 410 staff across four locality hubs. | `[grounded]` About Calderbrook Community Health (calderbrookhealth.example/about) |
| Role | Band 5 community staff nurse in the Halifax district nursing team, caring for housebound adults at home. The work is wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, recorded on an electronic patient record. You would hold a small caseload, supported by a senior community nurse. | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage; pool cars provided. | `[grounded]` advert |
| Market calibration | The advert's range brackets the survey median for community staff nurse Band 5 in England (£34,300, interquartile range £32,400–£36,600). In that survey 61% were paid mileage and 24% had a pool or lease car. This is a pattern, not this employer's offer. | `[generic]` Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide), snippet only; `[grounded]` advert for the range |
| Scope read | This reads as an entry route into district nursing: one year of experience is the minimum, a senior nurse supports you, and the caseload is small. | `[inferred]` from the essential list and the support line in the advert |
| Named contact | Rhiannon Mabbott leads the Halifax district nursing team and previously spent eleven years as a district nurse. At the 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. The advert names her for informal chats; it does not say she is the hiring manager. | `[grounded]` Community Nursing Forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott), snippet only |
| Unknowns | Closing date, shift pattern, weekend or on-call cover, lone-working arrangements, caseload size, induction or preceptorship, which electronic record system, permanent or fixed-term. | `[grounded]` advert silent on each |
| Contradictions | The advert and the About page agree on organisation and service. The careers page was not found at the address I guessed, so the posting is not confirmed live. | `[grounded]` About page; fetch of calderbrookhealth.example/careers returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states Registered Nurse (Adult), registration active, revalidation due March 2028. This is self-reported and not checked against the register. | `[grounded]` CV | none; an NMC register entry would raise to high |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | CV states a full UK licence, category B. The advert provides pool cars. | `[grounded]` CV and advert | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. This is a length-of-experience requirement, so it is graded as a requirement, not a gate. | `[grounded]` CV | none |
| R4 | Clear, timely written records (on the electronic patient record) | must_have | unclear | low | discovery | CV is silent on record-keeping and on any record system. Five years of ward nursing makes this plausible, but that is not a stated claim, so it is carried as a question. | `[grounded]` CV silence; `[inferred]` plausibility from the ward and discharge-to-assess roles | see G1 |
| R5 | Wound care (advert: "wound and leg-ulcer care") | important | direct | medium | none | CV names pressure ulcers and surgical wounds. | `[grounded]` CV | none |
| R6 | Leg-ulcer care | important | adjacent | medium | transferability | Your wound care carries over. Limit: no leg-ulcer, compression or Doppler work is stated. Leg ulcers are a distinct wound type from pressure and surgical wounds. | `[grounded]` CV; `[generic]` that leg-ulcer care is distinct from other wound care | see G4 |
| R7a | Catheter care | important | direct | medium | none | CV names catheter care. | `[grounded]` CV | none |
| R7b | Continence care | important | unclear | low | discovery | CV names catheter care only; continence care more widely is not mentioned. | `[grounded]` CV silence | see G5 |
| R8a | Insulin administration | important | direct | medium | none | CV names insulin administration. | `[grounded]` CV | none |
| R8b | Care planning | important | unclear | low | discovery | CV does not mention care planning; the discharge-to-assess role may have involved it, but that is not stated. | `[grounded]` CV silence | see G5 |
| R9 | End-of-life visits | important | unclear | low | discovery | CV is silent on end-of-life care. | `[grounded]` CV silence | see G2 |
| R10 | Caring for housebound adults in their own homes | important | adjacent | medium | transferability | You spent 18 months visiting patients at home in their first week after discharge. Limit: that is a short post-discharge window, not ongoing care of housebound patients. | `[grounded]` CV and your words | see G3 |
| R11 | Holding a small caseload of your own, supported by a senior community nurse | important | adjacent | medium | transferability | You confirm you have never held your own caseload. The home visits are the adjacent work. Whether you visited alone, and how many patients, is unstated. The advert pairs the caseload with senior support. | `[grounded]` your statement, CV, advert | see G3 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You confirm you have never done a Doppler assessment. The advert lists it as desirable, not essential. | `[grounded]` your statement and advert | closure path: ask in the informal chat whether training is given (A1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | CV does not mention records or any record system. | R4 is the one `must_have` row below `direct`, so it decides whether the status moves from `conditional_go` to `go`. | Electronic observation or care-plan systems on the ward; discharge-to-assess visit notes; audit results or ward-manager feedback on documentation | An audit result, a manager's comment, or a named system on your CV | `[grounded]` CV silence; `[inferred]` that this moves the status |
| G2 | End-of-life visits (R9, important) | discovery | CV is silent on end-of-life care. | The advert lists end-of-life visits as a core duty, so the interview is likely to probe it. | End-of-life care on the acute ward; supporting rapid discharge home for patients nearing end of life; family conversations | A reflective account from your revalidation portfolio, or a reference | `[grounded]` CV silence and advert; `[inferred]` that interviews probe core duties |
| G3 | Home visiting and caseload (R10, R11) | transferability | You visited patients at home for 18 months; solo or paired, and volume, are unknown. | A solo visit pattern is the strongest bridge to a caseload of your own; its absence is the limit to name. | Visiting alone; planning a day's visits; escalating to a clinician on call | A reference or a job description for the secondment | `[grounded]` CV and your statement; `[inferred]` that solo visiting is the strongest bridge |
| G4 | Leg-ulcer care and Doppler (R6, R12) | transferability | Wound care is evidenced; leg-ulcer care and Doppler are not. | Doppler is only desirable, and the named contact has spoken on Doppler training for new community staff; whether this employer trains is unconfirmed. | Compression bandaging on the ward; shadowing a tissue viability nurse | A training record or a tissue viability competency | `[grounded]` CV, advert, forum page; `[inferred]` that training may be offered |
| G5 | Continence care and care planning (R7b, R8b) | discovery | CV names catheter care only and does not mention care planning. | Both are listed duties, so a stated example would close two rows. | Bladder or bowel care plans; writing discharge or community care plans | A care-plan example, anonymised | `[grounded]` CV silence and advert |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting live and closing date not confirmed | unknown | — | the advert gives no closing date or reference | The posting may be live and the careers page simply at another address, or it may be stale. | `[inferred]` from a guessed careers URL returning no page, against the About page confirming the employer | Is this post currently open, and what is the closing date? | unresolved |
| RR2 | Senior support and defined duties | positive_signal | — | "supported by a senior community nurse" | The post is built as supported entry to caseload work, and the duties are specific. | `[grounded]` advert | Who is the senior nurse, and how much of your time do they have? | noted |
| RR3 | Induction and training unstated | unknown | — | "Desirable: Doppler assessment for leg ulcers" | Without a stated induction, how a new community nurse gets signed off on leg-ulcer care and Doppler is unclear. | `[inferred]` from the advert's silence against its desirable list | What induction or preceptorship do new community nurses get, and is Doppler training provided? | unresolved |
| RR4 | Working pattern unstated | unknown | — | the advert names "end-of-life visits" and insulin administration without hours | Time-sensitive care may need evening or weekend cover, and lone working is likely. | `[inferred]` from the duties named | What are the shift pattern, weekend and on-call expectations, and how is lone working supported? | unresolved |
| RR5 | Contract terms unstated | unknown | — | the advert gives a salary range and no contract type | The advert does not say whether the post is permanent, or which terms apply. | `[grounded]` advert silent | Is the post permanent, and what terms (leave, pension, sick pay) apply? | unresolved |
| RR6 | Pay stated, with pool cars and mileage | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range brackets the survey median; there is no sign of a mismatch. | `[grounded]` advert; `[generic]` survey | Where on the range would my five years' experience place me? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the summary in the edits table below. | The discharge-to-assess home visiting is your closest evidence for R10 and R11. | `[grounded]` your CV | pending your approval |
| P1 | In the application, lead with the 18-month discharge-to-assess home visiting. Say plainly that you have not held your own caseload or done Doppler assessment, and do not claim leg-ulcer experience. | The limits are named in R6, R11 and R12; stating them up front avoids having them found. | `[grounded]` your statements | pending your approval |
| A1 | Use the informal chat with Rhiannon Mabbott before applying: ask the questions of RR1, RR3, RR4 and RR5, and whether Doppler training is offered (R12). | She is the named contact. Her talks suggest Doppler training for new staff is something she has thought about; whether this employer offers it is unconfirmed. | `[grounded]` advert, forum page; `[inferred]` that training may exist | pending your approval |

**Proposed CV edit** — `resume_edits_pending_approval`:

| # | Current | Proposed | Source in your words | Status |
|---|---|---|---|---|
| E1 | Opening lines as they stand on your CV | "Registered Nurse (Adult), five years' acute medical ward experience, the last 18 months seconded to a discharge-to-assess team visiting patients at home in their first week after discharge. Wound care (pressure ulcers, surgical wounds), catheter care, insulin administration. Full UK driving licence (category B); based in Halifax." | Each clause traces to your own sentences; the registration line stays as you have it. | pending your approval |

## Evidence status

Verified: none yet. Not used: the National Insurance number in your message is not needed to evaluate a role, so I have not used it; the NMC PIN was taken as stated and not looked up.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Community Staff Nurse Band 5 district nursing Calderbrook Community Health CIC Halifax vacancy"; both returned "About Calderbrook Community Health" (calderbrookhealth.example/about). A fetch of calderbrookhealth.example/careers, an address I guessed, returned no page. Moved: role reality's organization and contradictions rows, and RR1. |
| 2. Role-family sweep | yes | Searched "Band 5 community district nurse role scope caseload Agenda for Change pay 2026/27", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: the market calibration row and RR6. It returned pay figures only, not scope norms. |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook Community Health", which returned her speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: role reality's contact row, A1 and R12's closure path. |

## Upgrade menu

I can also write this up as `tuesday-dossier.md` whenever you want a saved record.

- Your account of record-keeping (G1) → R4 resolves.
- Your answer to G2 → R9 resolves.
- Your answer to G3, or a reference for the secondment → R10 and R11 firm up.
- An NMC register entry → R1 moves to `high`; a competency record for wound, catheter and insulin → R5, R7a and R8a rise.
- Your pay floor, hours or weekend limits, notice period and current pay → the hard-gate checks against your constraints, now unknown, can run.
- The live posting or closing date → RR1 closes.
- A deeper research pass on Calderbrook (staff reports, recent news, leadership changes; up to 5 more searches and 2 more fetches) — say the word and it runs.

Three questions, each tagged to its row:

- **G1 (R4):** Which patient record systems did you document in on the ward and in the discharge-to-assess team, and is there anything inspectable, such as an audit result or manager feedback, about your record-keeping?
- **G2 (R9):** Have you cared for patients at the end of their lives, on the ward or in discharge-to-assess? What was your part, and did it include any home visits?
- **G3 (R10, R11):** On the discharge-to-assess visits, did you go out alone, roughly how many patients were you visiting in a week, and who did you escalate to?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.