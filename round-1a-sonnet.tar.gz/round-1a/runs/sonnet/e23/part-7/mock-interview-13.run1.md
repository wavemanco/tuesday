Status: I've loaded the mock-interview skill and read its rules. Next I'll run a few light searches on Quillmoor, then build your recruiter-screen prep pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/e23/part-7/rooms/case-13-denied-8d15e186/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. It has a fit snapshot, 19 questions across five interviewer styles, reverse questions, a list of claims it won't coach, and an upgrade menu.

I built it as a friendly recruiter screen with some knockout checks, using only your advert, Hannah's message and your notes. My three web searches (Quillmoor's values, recent news, Hannah) were all refused. So there is no company research or read on Hannah, and the "why Quillmoor" question (A6) is generic.

- **Most likely hard question (B1):** the advert's first duty is production scheduling, and what you've told me is delivery scheduling across three depots. Hold your own sentence, "I schedule deliveries for our three depots and chase suppliers when orders slip." Where the answer goes beyond it, the pack leaves a slot for you to fill truthfully.
- **Hannah's four topics (A1, A3, A4, A5):** your answers are already in your own words: the Bristol closure and Reading offer, two days fine and not more than three, "I'm hoping for £42,000", and your notice period.
- **SAP:** the honest line is "I've never used SAP", followed by how you'd learn it. The pack doesn't call your in-house stock system an ERP or say you're confident with Excel, because your notes say only "spreadsheet".
- **The stock-count figure:** keep "about a third over a year" as you said it. Be ready to say how it was counted, or that you don't know.

I can play Hannah on B1, the question I'd rehearse most. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word if you'd like.

1. What is your notice period? Your material doesn't say, and it is one of Hannah's four topics.
2. Do you want a deeper research pass on Quillmoor (up to 6 more searches and 2 more fetches, several more minutes)? It would need search permission, which was refused this time.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter phone screen, Thursday 2pm, 30 minutes, with Hannah Lowther (Talent Partner). She will ring the mobile number on your application. Her stated agenda, in her order: "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", then she tells you about the team and next steps. If anything changes, she asked you to message her on LinkedIn.

**Candidate:** Sam. This is a first pack, not a regeneration.

## How to use this pack

- Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.
- Type tags: VAL (values alignment), EXP (work-experience deep-dive), JD (the advert's stated requirements), CO (company knowledge), CASE (a live problem).
- Provenance labels: grounded (traceable to something you or the advert or Hannah wrote), inferred (a named derivation), generic (a pattern, no claim about you or Quillmoor).
- An answer slot is an instruction for the interview. It asks nothing of you here.
- Highest-ROI prep: B1. The four topics Hannah named are A1, A3, A4 and A5; say each aloud once before Thursday.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — JD | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says delivery scheduling across three depots, not production schedules, and nothing in it shows planning or QA. The words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on that interface likely. If any of your work touches teams like those, say how and what your part was, in your own words; if it does not, or was not yours, say so plainly and return to the depots |
| F2 | "track supplier deliveries and chase late orders" — JD | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | Chasing is in your own words and matches the advert's. Lead with it: you chase suppliers when orders slip. Answer slot: the advert also says track, so expect a probe on how you know an order has slipped. If you use a record or report for that, say which; if there was no such step, or it was not yours, say so plainly and stay with the chasing |
| F3 | "keep stock records accurate" — JD | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | Your sentence already reaches the requirement. Keep its words, including "about" and "over a year". Expect a probe on the number (C1, E2): how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. The sentence states the rebuild and the fall, and says nothing on whether one caused the other |
| F4 | "report weekly on on-time dispatch" — JD | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: if you report on deliveries or dispatch, say what and how often, in your own words; if you do not, say so plainly and say how you would start |
| F5 | "2+ years in operations or logistics coordination" — JD | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | Your sentence reaches the requirement in the advert's own terms. Say it as written |
| F6 | "confident with Excel" — JD | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Derivation: your sentence says spreadsheet and does not name Excel. Answer slot: if the stock-count spreadsheet was in Excel, say what you built into it, in your own words; if it was another tool, say so plainly and say what you have used |
| F7 | "ERP experience (SAP or similar) a plus" — JD | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used SAP." Then how you would learn it, said as a plan and never as a past. The advert marks this a plus, which is the pack's reading of its wording |
| F8 | "ERP experience (SAP or similar) a plus" — JD | "we run our own in-house stock system" — your message | low | [inferred] | discovery | Derivation: the advert says "or similar", and your sentence names an in-house stock system without saying what it does or what you do in it. Answer slot: if you work in that system, say what for, in your own words; if it is not something you would compare to SAP, say so plainly |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — JD | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | A term you state yourself and it meets the advert. Keep the wording as you gave it: two days is fine, and you wouldn't want more than three. Do not harden "wouldn't want" into a rule |
| F10 | "£38,000–£44,000" — JD | "I'm hoping for £42,000." — your message | high | [grounded] | none | A figure you gave, inside the advert's band. Keep your word "hoping", which is not a floor, and do not harden it into one |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. It is a term, so nothing is bridged and no wording can shape it |
| F12 | "what's prompting a move" — Hannah's message | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | You gave the reason plainly and it is a strong one. Say it in those terms. It is a stated reason with nothing inspected behind it, so expect a follow-up (A1, B4) |

## Persona table

Weights are the recruiter-screen priors, adjusted by Hannah's own message. The loop is established only for this one session, by her message; later rounds are unknown, so no later-round personas are weighted.

| Persona | How it shows up | Likelihood and reasoning | Provenance | Counter-strategy |
|---|---|---|---|---|
| Conversational / Rapport Builder (A, 6 questions) | Friendly walk-through of background, motivation, pay, notice, hybrid | Highest. Hannah's own agenda is four logistics-and-motivation items in a friendly register; casual questions here are still scored | [grounded] | A 90-second arc, the four named topics said aloud once beforehand, a real answer ready for "any questions for me?" |
| Skeptic (B, 5 questions) | Quiet knockout checks on gaps and consistency | High. Her topics include notice period, hybrid and the reason for leaving, which are where a screen filters; the advert's production-scheduling duty and the SAP line are the visible gaps | [grounded] | Rehearse B1 until it is boring; state limits plainly, never bridge past your own sentences |
| Data-Driven Prober (C, 3 questions) | Defends the stock-count figure and the tracking practice | Medium. A recruiter rarely drills a number, but yours is the one quantified claim you have, so it may come as a quick "how did you measure that" | [generic] | Know what you can and cannot say about how the figure was counted; say plainly when you do not know |
| Case / Strategist (D, 3 questions) | A short live scenario drawn from the duties | Low to medium. Unusual for a screen, but the advert's duties are easy to turn into one-minute scenarios | [generic] | Clarify, then structure, then answer; think aloud |
| Pressure / Stress (E, 2 questions) | Time-boxed "why you" and attribution | Low. Recruiter screens are rarely adversarial, but a time-boxed "why you" is common | [generic] | Pause, restate, anchor in your own sentences |
| Values / Behavioral | Not weighted | No values-style round is detected: no loop source names one, and the company's values were not retrieved | [generic] | None needed this session |
| Peer Evaluator | Not weighted | Hannah is a Talent Partner, not a peer on the team | [grounded] | None needed this session |

## Question banks

### A. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What's prompting a move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say it in your own terms, briefly: the Bristol office is closing next year, the only offer is relocating to Reading, and you don't want that. Stop there and let her ask. Answer slot: if something in this role specifically draws you beyond the closure, say it in your own words; if nothing beyond the fit to the duties yet, say that plainly and name the duties that matched | Hannah listed it by name. F12 is the evidence. EXP because it asks what actually happened, though the scoring is consistency, which is why B4 follows |
| A2 | "Walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." and "I schedule deliveries for our three depots and chase suppliers when orders slip." and "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc with only the beats the sentences state: four years as a logistics coordinator at a building-supplies wholesaler, scheduling deliveries for three depots, chasing suppliers when orders slip, and the stock-count spreadsheet rebuild with the fall in discrepancies. Then one sentence into A1. Answer slot: if you had earlier roles you want in the arc, add them in your own words | The standard opener and the 90-second arc is the counter-strategy for this persona. F5 and F3 carry it |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say it as you gave it: you live in north Bristol, two days at Avonmouth is fine, and you wouldn't want more than three. Answer slot: if particular days do not work for you, say which; if none, say so plainly | Hannah listed it by name. F9 is the evidence; it is a term you state, so the aim is clarity, not persuasion |
| A4 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say it as you gave it: you're hoping for £42,000, which sits inside the advert's range. Then ask where in the band the role sits. If she comes in lower, say plainly what you can accept: that decision is yours and the pack does not make it. Answer slot: if she asks your current salary, give the figure only if you choose to; otherwise say plainly you would rather talk about this role's range | Hannah listed it by name. F10 is the evidence. The word "hoping" is yours and the guidance keeps it |
| A5 | "What's your notice period?" | JD | [grounded] | Answer slot: state your notice in your own words, exactly as your contract has it. If you are unsure, say so plainly and say you will confirm it. If any of it is flexible, say how, and only if that is true | Hannah listed it by name. F11 is a gate row: your material does not establish it, so the pack offers no wording |
| A6 | "What drew you to Quillmoor?" | CO | [generic] | No research on Quillmoor ran this session, so the only facts the pack holds are the advert's own: "diagnostic-test manufacturer, about 400 staff". Answer slot: say which duties in the advert you responded to, in your own words. If you read anything on their site before Thursday, name the one thing you read; if you have not, say so plainly and stay with the advert | A casual company question that is still scored. Generic because the company's values and news could not be retrieved; the upgrade menu says what search access adds |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert has you coordinating production schedules between planning, the warehouse and QA. What have you done like that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack. Hold what the sentence carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Follow-up 1, "how is that different from scheduling production?": answer slot: if any of your work feeds or touches a production plan, say how, in your own words; if it does not, or was not yours, say so plainly and return to the depots. Follow-up 2, "what would you need from planning and QA in your first week?": this asks about no past, so answer with the questions you would put to them, in the order you would ask them. Follow-up 3, "how long before you'd be useful on production scheduling?": answer as a plan, naming what you would learn first, and give no number you cannot stand behind | F1 is the widest gap between the advert's first duty and your material, so this objection arrives in some form. JD because it scores the stated duty |
| B2 | "Have you used SAP or a similar ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain acknowledgment: "I've never used SAP." Then answer slot: if you work in the in-house stock system, say what for, in your own words; if it is not something you would call comparable, say so plainly. Close with how you would approach learning SAP, said as a plan | F7 and F8. The advert marks ERP a plus, so the aim is a calm, short answer rather than a defence |
| B3 | "How confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Start from what the sentence says: you rebuilt the stock-count spreadsheet. Answer slot: if it was an Excel workbook, say what you built into it, in your own words; if it was another tool, say so plainly and say what you have used | F6 is low confidence because the sentence says spreadsheet and not Excel, so the pack does not assert Excel |
| B4 | "Is the office closing the only reason you're looking, or are you interested in us specifically?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Hold the truth you have already stated: the closure is why you are looking. Do not retreat from it. Answer slot: say what in the role's duties interests you, in your own words; if nothing beyond the fit so far, say that plainly and name the duties that matched | A Skeptic test of motivation consistency. F12 is the evidence. EXP because it asks what happened, scored for consistency with A1 |
| B5 | "Two days is fine today. What if it became three or four?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Stay with your own sentence: two is fine, and you wouldn't want more than three. Answer slot: if there is flexibility under some conditions, say what they are; if there is none, say so plainly | Hybrid is one of Hannah's named topics and the site is the one fixed term in the advert. F9 is the evidence |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you count that one-third fall in discrepancies?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say the sentence as written, keeping "about" and "over a year". Answer slots, each in your own words: how it was counted; what it is most sensitive to; the assumption behind it you would defend least; and which part was yours. "I don't know how it was counted" is an honest answer. Never name a method you did not use | The one quantified claim in your material, so the likeliest to be probed. F3 is the evidence |
| C2 | "What did you rebuild in the spreadsheet?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Beats the sentence states: it was the stock-count spreadsheet and you rebuilt it. Answer slot: what changed in it, in your own words; if any part of the rebuild was not yours, say so plainly | A follow-up on the verb "rebuilt", which is the word interviewers test. F3 |
| C3 | "How do you track supplier deliveries and know when one is late?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Beats the sentence states: scheduling deliveries for three depots and chasing suppliers when orders slip. Answer slot: the advert says track, so expect this probe. If you use a record or report to know an order has slipped, say which; if you find out another way, say how; if there was no tracking step, say so plainly and stay with the chasing | F2. The practice is the advert's, not your sentence's, so the guidance holds a slot |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you a batch will arrive three days late, and QA need it for Friday. What do you do first?" | CASE | [generic] | Structure it aloud: what exactly is late and what depends on it, who needs to know today, what the options are, and what you record. The question asks about no past, so the guidance makes no claim | A live problem from the advert's chase-late-orders and schedule-coordination duties. Generic because it is a pattern, not a fact about Quillmoor |
| D2 | "The stock record says 40 units and the shelf says 34. Walk me through it." | CASE | [generic] | Structure it: confirm the count, check recent movements, find where the two differ, correct the record and note why. No claim about your past | Tests the advert's stock-accuracy duty as a decision. F3's requirement, asked as a problem |
| D3 | "On-time dispatch fell two weeks running. How would you start looking?" | CASE | [generic] | Clarify first: how on time is defined and where the dates come from. Then split where time is lost and say what you would check first. No claim about your past | Covers the advert's weekly on-time dispatch report, which F4 shows your material is silent on |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, when your background is a building-supplies wholesaler?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." and "I schedule deliveries for our three depots and chase suppliers when orders slip." and "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Pause, restate, then three beats the sentences state: four years coordinating logistics, chasing suppliers when orders slip, the stock-count rebuild. Hold through two follow-ups by returning to those sentences, never by adding to them. Concede the limit in your own words. Answer slot: if scheduling production is not something you have done, say so plainly | F5, F2 and F3 are the evidence. The limit sits in F1 and is the pack's observation, not words for you |
| E2 | "How much of that stock-count result was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold the verb you used: you rebuilt the spreadsheet. On the fall, answer slot: if anything else contributed, say what; if you do not know what else contributed, say so plainly | An attribution probe on the one figure you hold. F3 |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Production schedules between planning, the warehouse and QA | B1, D1, E1 |
| Track supplier deliveries and chase late orders | C3, D1, A2 |
| Keep stock records accurate | C1, C2, D2, E2 |
| Report weekly on on-time dispatch | D3 — a scenario only, because your material is silent on reporting (F4) |
| 2+ years in operations or logistics coordination | A2, E1 |
| Confident with Excel | B3 |
| ERP experience (SAP or similar) | B2 |
| Hybrid, two days at Avonmouth | A3, B5 |
| £38,000–£44,000 | A4 |
| Notice period (Hannah's topic) | A5 |
| What's prompting a move (Hannah's topic) | A1, B4 |
| Company knowledge | A6 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which days at Avonmouth are fixed, and which would be flexible?" | You answered the hybrid question, so this tests the real pattern and shows you have thought about the commute |
| R2 | "What does the process look like after this call, and who would I meet?" | She offered to cover next steps; asking for names and stages shows you are planning, not waiting |
| R3 | "How is on-time dispatch measured today, and who reads the weekly report?" | Ties to the advert's reporting duty and shows you read the duties list |
| R4 | "Which systems does the team use for stock and orders today?" | Opens the SAP topic yourself, with curiosity instead of a defence |
| R5 | "Is this a new role or a replacement, and what would you want solved in the first three months?" | Tells you what the hire is for and signals you are thinking about the work |
| R6 | "Where in the advertised range does the role usually sit?" | Follows your A4 answer without repeating it, and gets her view on flexibility |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says depots and deliveries, not production |
| Cut stock discrepancies by a third | Inflated form of F3 | F3's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The limit is the pack's observation: the sentence states the rebuild and the fall, not that one caused the other |
| Is confident with Excel, or used advanced Excel | Inflated form of F6 | F6's quote at its own scope: your sentence says "spreadsheet". The limit is the pack's observation that it does not name Excel |
| Has ERP experience, or used a system comparable to SAP | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system". B2 holds the slot inside that scope |
| Has used SAP | Negative you stated, F7 | The plain acknowledgment: "I've never used SAP." No slot |
| £42,000 is my minimum, or three days is my hard limit | Inflated form of F10 and F9 | Your own words: "I'm hoping for £42,000", and "I wouldn't want more than three." Both are stated preferences, not rules |

## Sources

Provided: the advert text; Hannah Lowther's LinkedIn message as pasted; your own notes on your background and what you would say. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The search was refused. It would have moved A6 and could have themed VAL questions; no values round is detected, so no cheat sheet |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | skipped | No call was sent. Hannah's message fixes the one session and its agenda, which sets the persona weights |
| 3. `Quillmoor Diagnostics Avonmouth news` | unavailable | The search was refused. It would have moved A6 and one reverse question |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The search was refused. It would have supplied an interviewer read, which is absent; her own message is the only interviewer information used |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and every JD-tagged question |

Searches sent: `Quillmoor Diagnostics values` — refused; `Quillmoor Diagnostics Avonmouth news` — refused; `Hannah Lowther Quillmoor Diagnostics` — refused.

## Upgrade menu

- Your notice period → F11 stops being a gate row with nothing behind it and A5 gets a grounded answer
- Search access, re-run → company values and recent news make A6 grounded and add a tailored reverse question; an interviewer read of Hannah's public footprint becomes possible
- Deeper research, once: up to 6 more searches and 2 more fetches, several more minutes → a company strategy brief for CO questions, which would need search permission
- What your stock-count spreadsheet was built in, and what changed in the rebuild → F6 and F3 firm up; the before-and-after count or a discrepancy report would raise F3 from medium to high
- How the discrepancy figure was counted, in your own words → C1 and E2 move from slots to story
- Whether you report on deliveries or dispatch → F4 moves from discovery to a quoted row
- Whether your work touches anything like planning or QA, and what your part was → F1 firms up and B1 gets a story map
- What the in-house stock system does and what you do in it → F8 firms up and B2 gets a story map
- How much prep time you have before Thursday → a prioritised schedule sized to it
- A tuesday-dossier.md from a prior job-underwriter run → a verified-evidence list and prohibited claims set by someone other than this pack
