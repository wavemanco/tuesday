I'll read the reference files the skill points to before writing anything.
Search was refused for every target, so I'm building the pack from what you gave me. Writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/e23/part-7/rooms/case-13-denied-bc0ab1d3/quillmoor_operations-coordinator_interview_pack.md`. I built it for a recruiter screen, using Hannah's agenda, the advert and what you told me about yourself. My web searches on Quillmoor and Hannah were refused, so nothing in it comes from outside research. It has 18 questions across six interview styles.

The question the pack names as your highest-value prep is B1, "which part of this advert would you be weakest at on day one?". It covers your SAP gap and the fact that your experience is delivery scheduling rather than production scheduling.

Say the word and I'll play Hannah on B1 and follow up on what you actually say.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What notice period does your current contract give you? It's the one item on Hannah's list that nothing you sent covers, and your answer reshapes A5.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Interviewer: Hannah Lowther, Talent Partner. Recruiter screen, Thursday at 2pm, a 30-minute phone call to the mobile number on your application. Her stated agenda: your salary expectations, your notice period, how the hybrid pattern would work for you, and what is prompting a move; then the team and the next steps.

Built from your message, the advert you pasted and Hannah's message. No web research ran (see Sources).

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behaviour shows how you work with others, not generic virtue |
| EXP | Whether what you said about your work survives a follow-up; what was actually you |
| JD | A requirement or term the advert or the recruiter states |
| CO | What you know about the company and why you chose it |
| CASE | How you structure a live problem from the role |

Question IDs run A to E, then G (the letter F is skipped so that bank IDs never share a name with fit-snapshot rows F1 to F12). An answer slot is an instruction for the interview, not a question for you now.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries for three depots and chasing suppliers, and says nothing about planning, QA or production. The words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's coordination line makes a probe on your scheduling likely. If any part of the delivery scheduling was yours to set, say which part and how you decided, in your own words; if none was, or there was no such step, say so plainly and stay with the depots |
| F2 | "chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe on a particular late order. Lead in the quote's own terms: you chase suppliers when orders slip |
| F3 | "track supplier deliveries" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | The sentence touches supplier deliveries without showing how they are tracked. Answer slot: expect a probe on how you keep track of what suppliers are due to deliver. If you keep a record or a view of it, say what it is, in your own words; if you don't, or it was someone else's, say so plainly and stay with the depots |
| F4 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap in kind, but a figure with nothing inspected behind it, so expect it to be probed. Lead with "I rebuilt our stock-count spreadsheet" and the figure at its own scope: fell, about a third, over a year. How it was counted, what it is sensitive to, the assumption you would defend least and which part was yours are answer slots in C1 and D1 |
| F5 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Your material does not show whether you report on deliveries or dispatch. Answer slot: expect a probe on what reporting you do. If you produce regular reports on deliveries or orders, say what, how often and to whom, in your own words; if you don't, say so plainly and stay with the depots |
| F6 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. Say it in the quote's own terms: four years, logistics coordinator, a building-supplies wholesaler |
| F7 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The sentence says a spreadsheet, and does not say which tool. Answer slot: expect a probe on what the spreadsheet is built in and how comfortable you are in it. Say which tool, in your own words; if you can't speak to it, say so plainly and stay with "I rebuilt our stock-count spreadsheet" |
| F8 | "ERP experience (SAP or similar) a plus" — the advert | "Never used SAP — we run our own in-house stock system." — your message | medium | [grounded] | transferability | You stated the SAP gap, and the words are yours: "I haven't used SAP." The adjacent work stays at its own scope: "we run our own in-house stock system." Answer slot: expect a probe on what your in-house stock system does day to day. Say what you do in it, in your own words; if what you do in it is limited, say so plainly and stay with the sentence |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | A term your own statement shows met. Keep both halves as you wrote them: two days is fine, and three is your ceiling. Neither is softened into a preference nor hardened into a requirement |
| F10 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | A term your own statement shows met: your figure sits inside the advert's range. Keep the word "hoping"; your sentence is not a minimum |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish it. Nothing for the pack to bridge: it is a fact about your contract, and it is asked of you below the pack |
| F12 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | Lead with the sentence's three facts, in order, in your own words: the office closes next year; the only offer is relocating to Reading; you don't want it. Your material says nothing about redundancy terms, other roles or timing beyond "next year", so none of those goes in |

## Persona table

The weights rest on the recruiter-screen prior and on Hannah's own agenda, not on a documented Quillmoor process. Her message establishes this one call; what follows it is unknown.

| Persona | How it shows up in this call | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Her four agenda items asked as friendly, unscripted questions, plus the background walk-through | High: the recruiter-screen prior is Conversational plus a light Skeptic, and her message lists logistics and motivation items. Bank A, five questions | Pre-rehearse the four agenda answers (A1, A3, A4, A5) and the background arc (A2); treat each casual question as scored |
| Skeptic | The gaps and the move: weakest area, the Reading offer, why this role | Medium: the prior is light, raised because F1 and F8 are visible gaps and "what's prompting a move" is itself a consistency probe. Bank B, three questions | Rehearse B1 until it is boring: state the gap plainly, then your sentence at its own scope; B1 is the highest-ROI prep in this pack |
| Data-Driven Prober | One figure (F4), the tool behind it, and reporting | Medium-low: her agenda lists no experience deep-dive, and there is one number on the page. Bank C, three questions | Know what you can and cannot say about how the figure was counted, and say plainly where you don't know |
| Pressure / Stress | The salary figure and the SAP gap pushed harder | Medium-low: the pay and SAP topics are where a screen can push; no stress style is signalled. Bank D, three questions | Pause, restate, hold the sentence through two follow-ups, concede only what is true |
| Case / Strategist | A live supply or stock problem | Low: nothing in her message signals a case; the advert's duties make one possible in a later round, whose shape is unknown. Bank E, two questions | Clarify, then structure, then think aloud; nothing about your past is needed |
| Values / Behavioral | A tell-me-about-a-time question | Low: no values round is documented and no published values are in hand (the search was refused). Bank G, two questions | Choose a specific occasion or say plainly none comes to mind |
| Peer Evaluator | — | Not plausible for a recruiter call; no bank | — |

## Question banks

### A. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — what's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Three facts, in this order, in your own words: the Bristol office is closing next year; the only offer is relocating to Reading; you don't want it. Say it as plainly as your sentence does and stop. Nothing about redundancy terms, other options or timing beyond "next year" is in your material, so none goes in. Keep it free of criticism of your employer | F12 is the first topic Hannah names; EXP because it tests whether the account of your job history holds up under a follow-up |
| A2 | "Walk me through your background — the 90-second version." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" and "I schedule deliveries for our three depots and chase suppliers when orders slip." and "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Three beats, each a clause your sentences state: the role and the four years; the depot scheduling and the supplier chasing; the stock-count rebuild with the figure at its own scope: fell, about a third, over a year. Tell them in your own words and in that order. Add no team size, system or tool | F6 and F2 are the lines she is screening against; EXP because it is the test of whether your account holds, delivered conversationally |
| A3 | "How would the hybrid pattern, two days a week at Avonmouth, work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Answer the advert's two days in your sentence's own terms: you live in north Bristol, so two days at Avonmouth is fine. Stop there. Your three-day ceiling is "I wouldn't want more than three": use it only if she asks about flexibility, in those words. Nothing about your commute is in your material, so none goes in | F9 is a term the material shows met, and her agenda names it; JD because it scores a term the advert states |
| A4 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say the figure in the quote's words, "I'm hoping for £42,000", which sits inside the advert's £38,000–£44,000, and stop. Answer slot: she may ask for your lowest figure. If you have one, settle it before Thursday and say it in your own words; if you don't, say £42,000 is what you're hoping for and stay with that | F10 is on her agenda by name; JD because it scores a term the advert states |
| A5 | "What's your notice period?" | JD | [generic] | The fact is yours alone and nothing in your material states it, so the pack supplies none. Check your contract before Thursday and give the figure as written. If you can't confirm it on the call, say so plainly and say you'll confirm it by message; mention any room to leave earlier only if it is true | F11 is on her agenda by name; JD because it scores a term. The label is generic because the pack makes no claim about you here |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." and "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack; it has the most follow-up levels. Level 1: name the gap you stated, in your own words: "I haven't used SAP; we run our own in-house stock system." Then your sentence at its own scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." Level 2, she presses on the coordination line: hold the sentence and add nothing. Answer slot: if any part of the delivery scheduling was yours to set, say which part and how you decided; if none was, or there was no such step, say so plainly and stay with the depots. Level 3, she asks what your in-house stock system does: say what you do in it, in your own words; if it is limited, say so plainly. If she asks how you would close the SAP gap, answer as a plan in your own words, never as something already done. Concede the gap specifically; do not retract the sentence | F1 and F8 are the visible gaps and the likeliest place to be probed in some form; JD because it scores the advert's list, with a Skeptic's delivery |
| B2 | "Help me understand why Reading isn't an option for you." | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Hold the facts: the only offer is relocating to Reading, and you don't want it. Through two follow-ups, return to those facts in your own words, without criticism of your employer. If she goes past the sentence into other roles, timing or terms, answer only what is true, and say plainly where you don't know or didn't ask | F12 is the move's motivation, which a Skeptic tests for consistency; EXP because it tests the account of your job history |
| B3 | "Why this role, and why Quillmoor?" | CO | [generic] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Selection scaffold. Pick one or two lines of the advert you can honestly say interest you, and say why in your own words; the pack can't tell which are true for you. The search was refused, so nothing about Quillmoor beyond the advert is in hand: read its own site before Thursday and say only what you read. If no reason comes to mind beyond location, say so plainly, then give the nearest thing your material does carry: "I schedule deliveries for our three depots and chase suppliers when orders slip." | F12 raises the why-leave half; this is the why-here half. CO because it tests homework, and generic because no research ran |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 'about a third' was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say the sentence at its own scope: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part of it was yours. "I don't know how it was counted" is an honest branch. Keep "about a third"; don't sharpen it | F4 holds the one headline figure, which draws a defend-the-number question; EXP |
| C2 | "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: the advert asks for confidence with Excel, so expect a probe on what the stock-count spreadsheet is built in and what you rebuilt in it. Say which tool, in your own words; if you can't speak to it, say so plainly and stay with "I rebuilt our stock-count spreadsheet" | F7 is a stated requirement and the sentence touches it without reaching it; JD |
| C3 | "The role tracks supplier deliveries and reports weekly on on-time dispatch. What tracking and reporting have you done?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you keep track of what suppliers are due to deliver, or produce regular reports on deliveries or orders, say which, how often and to whom, in your own words; if you do neither, or it was someone else's, say so plainly and stay with "I schedule deliveries for our three depots and chase suppliers when orders slip." | F3 and F5 are advert lines your material does not settle; JD because it scores them, with the premise left open |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That drop in discrepancies: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold, then concede. Hold: "I rebuilt our stock-count spreadsheet" is the part you can stand on, in the sentence's own verb. Through two follow-ups, return to the sentence and add nothing. Answer slot: say which part of the fall you can attribute to the rebuild and what else you know about what moved the figure, in your own words; if you can't separate them, or don't know how much was down to the rebuild, say so plainly and return to the sentence. Don't turn "fell" into "I cut" | F4's attribution probe in its harshest form; EXP because it tests what was actually yours |
| D2 | "Sixty seconds: why should we shortlist you over someone who has used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." and "I schedule deliveries for our three depots and chase suppliers when orders slip." | Hold, then concede, in sixty seconds. Concede first, plainly: "I haven't used SAP." Then what you do have, in the sentences' own words: "we run our own in-house stock system" and "I schedule deliveries for our three depots and chase suppliers when orders slip." Through two follow-ups hold both and stay with what the sentences say; the advert lists SAP or similar as a plus. Close on how you would learn the system, as a plan in your own words | F8 is the gap a pressure interviewer tests; JD because it scores the advert's line |
| D3 | "Would you consider anything below £42,000?" | JD | [grounded] "I'm hoping for £42,000." | Hold the sentence: "I'm hoping for £42,000." The advert's range starts at £38,000. Answer slot: if you would consider less, decide before Thursday where, and say it in your own words; if you wouldn't, say £42,000 is what you're hoping for and stay there. Don't turn "hoping" into "minimum", and don't state a floor you haven't set | F10 under pressure; JD because it scores the same stated term |

### E. Case

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you on Wednesday that Friday's delivery will arrive a week late. What do you do first?" | CASE | [generic] | Structure it aloud: clarify first (what is on that delivery, who is waiting on it, whether part can arrive sooner); who needs to know (the advert names planning, the warehouse and QA); the options and their trade-offs; what you record and report; when you chase again. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's chase-late-orders line (F2); generic because it is a pattern for the problem |
| E2 | "A stock count and the system disagree on a line. How do you work out which is right?" | CASE | [generic] | Structure it aloud: recount, check recent movements and paperwork, correct the record with the reason noted, look for a pattern, say what you would report. No claim about your past is needed | A live problem from the advert's stock-records line (F4); generic because it is a pattern |

### G. Values

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time a supplier let you down and you had to give someone bad news." | VAL | [generic] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Selection scaffold. Pick one specific order that slipped: it needs a named stake, who you had to tell, what you said, and how it ended. Your sentence says chasing slipped orders is part of the job, not which occasion. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2's theme as an open prompt; VAL because it scores behaviour, low weight because no values round is documented |
| G2 | "Tell me about a time you had to get something done with people who weren't on your team." | VAL | [generic] | Selection scaffold. Pick one occasion with a named task, who the people were, and how it ended. If no such time comes to mind, say so plainly, then say how you would approach it | The advert's cross-team coordination line (F1) as an open prompt; generic because the pack makes no claim about your past here |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 production schedules across planning, warehouse and QA | B1, E1 |
| F2 chase late orders | A2, E1, G1 |
| F3 track supplier deliveries | C3 |
| F4 keep stock records accurate | A2, C1, D1, E2 |
| F5 weekly on-time dispatch reporting | C3 |
| F6 2+ years | A2 |
| F7 Excel | C2 |
| F8 ERP, SAP or similar | B1, D2 |
| F9 hybrid pattern | A3 |
| F10 salary | A4, D3 |
| F11 notice period | A5 |
| F12 what's prompting a move | A1, B2, B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Is this a new post or a replacement, and how long has it been open?" | Shows interest in the team's shape; the answer tells you whether the role is growth or backfill |
| R2 | "In the coordination between planning, the warehouse and QA, where does the coordinator spend most of the week?" | Uses the advert's own words, and tells you which line to prepare for the hiring manager |
| R3 | "Which system does the team use for stock and orders, and how is a new coordinator trained on it?" | Turns the SAP gap into a ramp conversation while you stay with your own sentence about the in-house system; tells you how much the plus matters in practice |
| R4 | "On the two Avonmouth days, are the days fixed or agreed with the team?" | Tests whether the pattern in F9 works in practice, and shows you have thought it through |
| R5 | "What would the first three months need to show, and how is on-time dispatch doing today?" | Ties to the advert's weekly dispatch report and tells you what the number is measured against |
| R6 | "When you describe the next steps, could you tell me what each stage covers so I can prepare?" | Asks for the coverage a recruiter is best placed to give, and it is the kind of guidance that sharpens this pack |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinates production schedules with planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." The limit is the pack's observation, not words for you: the material says deliveries for three depots and chasing suppliers. B1's slot stays inside the depots |
| Has used SAP | Negative you stated, F8 | The plain acknowledgment F8's quote gives: "Never used SAP — we run our own in-house stock system." In your words: "I haven't used SAP." No slot |
| Has ERP experience | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: the material says an in-house stock system. B1's slot asks only what that system does |
| Confident or advanced in Excel, or rebuilt the stock count in Excel | Inflated form of F7 | F7's quote at its own scope: "I rebuilt our stock-count spreadsheet." C2's slot asks only what it is built in |
| Cut stock discrepancies by a third, or by a precise percentage, by rebuilding the spreadsheet | Inflated form of F4 | F4's quote at its own scope: "discrepancies fell by about a third over a year." The limit is the pack's observation: the sentence gives the rebuild and the fall, with no count method or cause. C1 and D1 ask only the defend-the-number slots |
| £42,000 is my minimum or non-negotiable | Inflated form of F10 | F10's quote: "I'm hoping for £42,000." The limit is the pack's observation: the sentence says hoping |
| My role is being made redundant | Inflated form of F12 | F12's quote at its own scope: the office is closing next year and the only offer is relocating to Reading. The limit is the pack's observation: the material says nothing of redundancy terms |

## Sources

Provided documents: the Quillmoor advert you pasted; your own message (the ABOUT ME and WHAT I'D TELL HER notes); Hannah Lowther's LinkedIn message as pasted. No dossier.

Searches sent (all refused, none returned a result): "Quillmoor Diagnostics values" — refused; "Quillmoor Diagnostics interview process operations coordinator" — refused; "Quillmoor Diagnostics Avonmouth news strategy" — refused; "Hannah Lowther Quillmoor Diagnostics Talent Partner" — refused. No pages fetched.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every call refused. Would have given published value names for G1 and G2; no values round is detected in the loop as it stands |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Every call refused. Would have named the rounds after this call and tuned persona weights; the weights rest on Hannah's message and the recruiter-screen prior |
| 3. `Quillmoor Diagnostics Avonmouth news strategy` | unavailable | Every call refused. Would have grounded a CO question; B3 is generic |
| 4. `Hannah Lowther Quillmoor Diagnostics Talent Partner` | unavailable | Every call refused. Would have given an interviewer read and a reverse question tied to her path; both are absent |
| 5. representative Operations Coordinator JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access → company values, any documented loop, recent company news and Hannah's public professional footprint: B3 becomes grounded, persona weights follow the documented rounds, an interviewer read and a reverse question tied to her path become possible. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) could add a strategy brief and role-family loop reports
- Your notice period → F11's evidence cell, and A5's guidance can be tailored to it
- Your answers to the answer slots (rows F1, F3, F5, F7, F8, and the figure's four defend-the-number slots) → each quoted into the fit snapshot, moving those rows from discovery toward grounded
- Your CV → F1 to F8 currently rest on your message alone; CV lines would add quotes and could lift medium rows
- Any extra note from Hannah about the call → coverage of anything she wants prepared
- How many hours you have before Thursday → a prep triage ordering the few things to do well
- A tuesday-dossier.md from an earlier role evaluation → verified evidence and a named objection in place of the inferred one
