# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, a 30-minute phone call on Thursday at 2pm, with Hannah Lowther (Talent Partner). She will ring the mobile number on your application.
**What she said she will cover:** salary expectations, notice period, how the hybrid pattern would work for you, what is prompting a move. Then she tells you about the team and next steps.
**Built on:** your message, the advert text and Hannah's LinkedIn message, with no company research (see Sources).

## How to use this pack

Personas are how a question arrives. Types are what it is scoring. Guidance is scaffolding for your own words, not a script, and where it says answer slot it is a prompt for you to answer truthfully either way.

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment |
| EXP | Work-experience deep-dive: do your claims survive a follow-up |
| JD | Role or advert-driven: the stated requirements and terms |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role |

Highest-ROI prep in this pack: B2, the gap between delivery scheduling and production scheduling. It is the one probe most likely to come in some form, and a calm, plain answer changes the call. Then A1, A3, A4 and A5, because Hannah told you she will ask them.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling for three depots, not production scheduling, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so expect a probe on who the schedules were coordinated with. If any of your scheduling involved those teams, say which and what you did, in your own words; if none did, or it did not involve production, say so plainly and stay with the depots |
| F2 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | The quote touches deliveries and suppliers without showing whether you track them. Answer slot: if you follow supplier deliveries against what was promised, say how you know where an order stands; if you do not track them as such, say so plainly and stay with the chasing |
| F3 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but one line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you chase suppliers when orders slip |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | The quote already speaks in the advert's terms: a stock-count spreadsheet, discrepancies, a fall of about a third over a year. The word about stays in. The figure is a magnet for a probe, so C1 rehearses it |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: if you report on delivery or dispatch performance, say what and how often, in your own words; if you do not, say so plainly and stay with the scheduling you do |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap. Four years against a two-year ask; say it in the quote's own terms |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote says spreadsheet, and does not say which tool. Answer slot: if it was Excel, say what you did in it, in your own words; if it was another tool, say so plainly |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [grounded] | transferability | Your words on SAP are plain: "I haven't used SAP." The second half of your sentence is about what your company runs, at that scope. Answer slot: the advert says SAP or similar, so expect a probe on the in-house system. If you work in it yourself, say what you do in it; if you do not, or it is not something you would call an ERP, say so plainly and stay with SAP |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure sits inside the advertised range. Say the number plainly |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Two days is what the advert asks and what you said is fine. Your limit is the second half of the same sentence, kept exactly as you said it |
| F11 | "your notice period" — Hannah, LinkedIn | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. Hannah will ask it directly, so it needs a plain figure before Thursday (see the question closing this message) |
| F12 | "what's prompting a move" — Hannah, LinkedIn | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | No gap. Your reason is specific and checkable. Say it in your own words and stop at what you said |

## Persona table

The loop is established by Hannah's own message: one 30-minute call with her, then the team and next steps. No values round is documented, and later rounds are not prepared here.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (A) | Friendly, structured walk through her four topics: pay, notice, hybrid, why you are moving | Highest. A recruiter screen starts here by default, and her message is a list of questions asked in a friendly register. Casual still counts as scored | A 90-second arc for the biography and the move; one clear sentence each for pay, notice and hybrid |
| Skeptic (B) | Quiet probing of the gaps: production scheduling, SAP, reporting, and the reason you are leaving | Medium. Light by default in a screen, and the advert's list of requirements gives her three obvious places to probe. Your reason for leaving is already on her agenda | Rehearse B2 until it is boring. Say each gap plainly, stay inside what you have said, add a short ramp plan |
| Data-Driven Prober (C) | One or two follow-ups on your stock-count figure and your Excel use | Low to medium. Not on her agenda, but a CV-style line like the one-third fall is the usual target when it is mentioned | Say plainly what you do and do not know about how the figure was counted |
| Pressure / Stress (D) | A blunt shortlisting or motivation challenge | Low. Her stated style is a conversation, and nothing she wrote suggests time-boxing | Pause, restate, hold what you actually said through two follow-ups |
| Values / Behavioral (E) | A scenario question about a late supplier or working with another team | Low. No values round was found in what I was given, and the advert's own lines are the only source for the themes | Selection scaffolds; if no instance comes to mind, say so plainly |
| Case / Strategist (F) | A short live problem from the role | Low. A recruiter rarely sets a case, but the next round probably will, so these are cheap insurance | Clarify, structure, then answer; think aloud |

Peer Evaluator: not plausible for this round, so no bank.

## Question banks

### A. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey: what you do now, and what's prompting the move." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Three beats, each a clause your sentences state: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; and the reason you are looking, that the Bristol office is closing next year and the only offer is relocating to Reading, which you don't want. Say the reason plainly and without criticism of anyone. Answer slot: close on what in this advert interested you, in your own words; if the honest answer is mostly that the coordination work matches what you do now and the site is in Bristol, say that | F12 is the reason she asked for; F1 and F6 are the work she is placing. EXP because it checks that the biography and the reason hold together |
| A2 | "What do you know about Quillmoor, and why this role?" | CO | [grounded] | Research on the company did not run, so this stays at the advert's level: a diagnostic-test manufacturer of about 400 staff, with a hybrid pattern at Avonmouth. Say what you actually know, and say which part of the advert drew you. Answer slot: if you looked at anything beyond the advert, name it; if you did not, say so plainly and ask her to tell you more, which is better than guessing at their strategy | The advert is the only company source in hand, so a current-strategy answer is not possible here, and the upgrade menu says what would change that. CO because it scores homework depth |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say that you live in north Bristol and two days a week at Avonmouth is fine. If she asks about flexibility, say what you said here: you wouldn't want more than three. Answer slot: if she asks how you would get to Avonmouth, answer in your own words | F10 is a term she lists explicitly. JD because it scores a stated term of the advert |
| A4 | "What's your notice period?" | JD | [grounded] | Give the figure exactly as your contract states it, then say in one clause whether it can move. Answer slot: if you are not sure of the exact wording, say you will check your contract and confirm by message, which is a complete and acceptable answer | F11 is the one row your material does not settle. JD because she lists it as a stated term of the process |
| A5 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say the figure and tie it to the advert: "I'm hoping for £42,000, which sits within the range you advertised." Then stop. Do not call it a minimum or a floor, and do not say it is flexible, since you have said neither. Answer slot: if she asks whether there is room to move, decide your honest answer before Thursday and say it plainly | F9 is on her list. JD because the advert states the range |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "If the Reading option weren't on the table, would you still be looking?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Hold your own sentence: you are looking because the Bristol office is closing next year and the only offer is Reading, which you don't want. Answer slot: if something in this role would interest you regardless, say what, in your own words; if the move is driven by the closure, say so plainly and add what you want in the next role | F12 is the reason she will test for consistency. EXP because it checks the story under a hypothetical |
| B2 | "This role coordinates production schedules between planning, the warehouse and QA. How does what you do now compare?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack. Level one, hold only what the quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Level two, if she asks who you coordinate with: answer slot, if any of your scheduling involved planning, warehouse or QA teams, say which and what you did; if none did, or it was not production scheduling, say so plainly and return to the depots. Level three, if she asks what you would need to learn: say, as a plan and not a past, what you would want to understand first about how those three teams hand over to one another. The concession is the limit of your own sentence, never a claim added to close the gap | F1 is where the advert presses hardest and where your material is adjacent rather than direct. JD because it scores the headline responsibility |
| B3 | "The advert mentions SAP or similar as a plus. What ERP experience do you have?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say it plainly: "I haven't used SAP." Then your second clause at its own scope: your company runs its own in-house stock system. Answer slot: if you work in that system yourself, say what you do in it; if you do not, say so plainly and stay with SAP. Finish with a short ramp plan, said as a future: how you would approach learning a new system | F8 is a stated negative with an adjacent clause. The advert calls it a plus, so this is a probe and not a knockout. JD because it scores a stated requirement |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Choose the gap you honestly rank first, say it in one sentence and give a ramp plan in one more. If it is SAP, your sentence is "I haven't used SAP." The pack's observation is that F1, F5 and F8 are the rows where your material is thinnest, and the choice among them is yours. Answer slot: if you would rank a different part of the role first, say which and why, in your own words | A named weakness with a plan reads better than a hunt for one. JD because it scores the advert's list |
| B5 | "The role reports weekly on on-time dispatch. Have you done any regular reporting on delivery performance?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you report on delivery or dispatch performance, say what, to whom and how often, in your own words; if you do not, say so plainly and stay with the scheduling you do: "I schedule deliveries for our three depots." Add what you would want to know about how the weekly report is used here | F5 is silent in your material. JD because the weekly report is a stated responsibility |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that one-third drop in stock-count discrepancies was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say the sentence at its own scope: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Keep the word about. Answer slots, each in your own words: how the discrepancies were counted; what the figure is sensitive to; the assumption behind it you would defend least, including whether the whole fall came from the rebuild; and which part was yours. If you do not know how it was counted, say so plainly | F4 is the one number in your material. EXP because it tests attribution |
| C2 | "What did you rebuild in that spreadsheet, and what is it built in?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Start from the sentence: the stock-count spreadsheet you rebuilt. Answer slot: if it is in Excel, say what you used it for, in your own words; if it is another tool, say so plainly and say how comfortable you are in Excel | F7 is a discovery row. JD because the advert says confident with Excel |
| C3 | "How do you decide which late order to chase first?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Start from the sentence: you chase suppliers when orders slip. Answer slot: if you prioritise orders, say how you decide, in your own words; if you chase them as they come up, or someone else sets the order, say so plainly | F3 and F2 are where the day-to-day of the role sits. JD because it scores the chasing requirement |

### D. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we shortlist you over someone who has used SAP?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "Never used SAP — we run our own in-house stock system." | Pause and restate. Hold: four years as a logistics coordinator, scheduling deliveries for three depots and chasing suppliers when orders slip. Concede specifically: "I haven't used SAP." Hold through two follow-ups by returning to what you said, never by adding to it. Do not claim to be the better candidate; say what you bring and let her weigh it | F6 and F8 are the two rows the challenge sits between. JD because it scores the headline fit |
| D2 | "So the office closing is what's pushing you out. You're not really choosing us, are you?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Concede what is true without flinching: the office is closing, and that is why you are looking. Hold on the rest. Answer slot: say in your own words what in this advert you are choosing; if it is mostly the match with your current work and staying in Bristol, say that plainly | F12 is a sensitive reason. EXP because it tests the story under a blunt reading |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time a supplier delivery slipped and you had to deal with the consequences." | VAL | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Selection scaffold: pick one occasion that has a named order, what you did about it and how it ended, with your own part clear. Your sentence says you chase suppliers when orders slip; the occasion itself has to come from you. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme comes from the advert's late-orders line. VAL because it is behavioral and its source here is the advert and not a published value |
| E2 | "Tell me about a time you worked with another team to sort out a problem." | VAL | [generic] | Selection scaffold: a named problem, the other team, what you did and the outcome. If no such time comes to mind, say so plainly, then say how you would approach it | The theme comes from the advert's line about planning, the warehouse and QA. No sentence of yours carries an occasion, so this is a scaffold |

### F. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "A supplier tells you a component for tomorrow's production run is two days late, and QA are waiting on it. What do you do first?" | CASE | [generic] | Clarify first: what the component is for, which runs and orders it holds up, whether a partial or alternative is available, and what the supplier can firmly commit to. Then structure: tell planning, the warehouse and QA what is known, set out the options, agree one, and set a time to check back. Close with what you would record. The question asks about no past, so the guidance claims none | A live problem built from the advert's responsibilities. CASE because it scores structure on a role problem |
| F2 | "Stock records don't match the physical count at one site. How would you start?" | CASE | [generic] | Clarify the size and pattern of the mismatch; check a sample by recounting; trace the movements that explain it; fix the cause and not only the figure; record what changed. The question asks about no past, so the guidance claims none | Built from the advert's stock-records line. CASE because it scores structure |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B2, E2, F1 |
| Track supplier deliveries | C3, E1 |
| Chase late orders | C3, E1 |
| Keep stock records accurate | C1, F2 |
| Report weekly on on-time dispatch | B5 |
| 2+ years in operations or logistics coordination | A1, D1 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B3, B4 |
| £38,000–£44,000 | A5 |
| Hybrid: two days a week at Avonmouth | A3 |
| Notice period (Hannah's message) | A4 |
| What is prompting a move (Hannah's message) | A1, B1, D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like for this role between planning, the warehouse and QA?" | It shows you read scheduling across those teams as the heart of the job, and it tells you how far your delivery scheduling is from it |
| R2 | "What does good look like for on-time dispatch, and how is it measured today?" | It picks up the advert's weekly reporting line and shows you would own a number |
| R3 | "Which system is stock held in at Avonmouth, and how are new starters trained on it?" | It turns the SAP gap into an onboarding question and gets the answer to whether it matters |
| R4 | "On the two days at Avonmouth, is the pattern set or does the team agree it?" | It follows up on the hybrid topic she raised and gets the practical detail |
| R5 | "What would you want me to have achieved in the first three months?" | It signals you are thinking about delivery, not just getting through the screen |
| R6 | "What are the next steps, and roughly when would I hear?" | She said she would cover next steps; this confirms the timing and shows you are planning |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| That you have used SAP or any ERP | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't used SAP." The in-house clause stays at its own scope, and B3 asks only what you do in it |
| That you coordinate production schedules across planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says delivery scheduling for three depots, not production scheduling. B2's slot stays inside what your scheduling involved |
| That you cut stock discrepancies by a third, or own stock accuracy | Inflated form of F4 | F4's quote at its own scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. C1's slots ask only how it was counted and which part was yours |
| That you are being made redundant, or that nothing else was possible at your employer | Contradicted by what you stated, F12 | F12's quote: the office is closing next year and the only offer is relocating to Reading, which you don't want |
| That £42,000 is your minimum, or that it is flexible | Not stated, and F9 says only that you are hoping for it | "I'm hoping for £42,000." A5's slot asks only for your own honest answer on room to move |
| That you can work more than three office days a week | Contradicted by what you stated, F10 | F10's quote, kept exactly: two days is fine, and you wouldn't want more than three |

## Sources

Provided: the advert text; Hannah Lowther's LinkedIn message; your message. No dossier was present.

Searches sent, each refused by the host before returning anything:

- `Quillmoor Diagnostics values` — refused
- `Quillmoor Diagnostics Avonmouth news strategy` — refused
- `Hannah Lowther Quillmoor Diagnostics` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every call was refused. It would have moved the VAL questions E1 and E2 (their themes come from the advert only) |
| 2. `Quillmoor Diagnostics interview process operations` | skipped | Hannah's message fixes the one session (a 30-minute call with her) and her agenda, so it fixes the persona weights and the banks |
| 3. `Quillmoor Diagnostics strategy` and recent news | unavailable | Every call was refused. It would have moved A2, which stays at the advert's level |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Every call was refused. It would have moved an interviewer read, which is absent, and a reverse question tied to her path |
| 5. representative Operations Coordinator advert | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → F11 stops being a bare gate, and A4 gets your actual figure in your own words
- Whether the stock-count spreadsheet is in Excel, and how the discrepancies were counted → F7 and F4 move up, and C1 and C2 become story-mapped
- Whether any of your scheduling involved planning, the warehouse or QA → F1 moves from transferability toward a story, and B2 gets its second level
- Whether you report on delivery performance, and whether you track supplier deliveries → F5 and F2 move from discovery to grounded, and B5 and C3 become story-mapped
- Quillmoor's values or about page pasted in, or search permission granted → E1 and E2 can map to published values, and A2 gets a current-strategy answer
- Hannah's public professional profile → an interviewer read and a reverse question tied to her own path
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, which also needs search permission → a company grounding brief
- Whether Hannah has anything to add to her four topics, which is usually one message to her → coverage assumed from the round-type prior becomes her own stated focus
- A tuesday-dossier.md from job-underwriter, if you have one → a verified-evidence base and a named objection, never a prerequisite
