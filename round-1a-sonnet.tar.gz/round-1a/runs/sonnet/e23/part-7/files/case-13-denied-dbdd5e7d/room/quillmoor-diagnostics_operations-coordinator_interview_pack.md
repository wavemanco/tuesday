# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Round: recruiter screen, a 30-minute phone call with Hannah Lowther (Talent Partner), Thursday at 2pm. She will ring the mobile number on your application. Candidate: Sam.

Loop: the one session Hannah's message names. No later rounds are established by any source, so the persona weights below rest on her message plus the recruiter-screen prior, not on this company's documented process.

## How to use this pack

Personas are how a question is asked; types are what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

Hannah's message names four things she wants to cover: salary expectations, notice period, how the hybrid pattern would work, and what is prompting a move. A2 to A5 are those four, in her order. Everything else is what a screen might add.

Type key:

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values. None appear in this pack: no values-style round is documented for this call and no published values were retrieved |
| EXP | Whether what you have said about your work survives a follow-up |
| JD | Whether you can do the advertised job, gaps included |
| CO | What you know about the company |
| CASE | A live problem from the role, answered aloud |

Highest-ROI prep: B1, the pay question asked as a skeptic. It sits where your figure meets the advert's gaps, and it is the question most likely to be asked in some form.

## Fit snapshot

Requirements are quoted from the advert you pasted. Evidence is quoted only from your message. There is no CV in the inputs, so every evidence cell is your own description, not an inspected document.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap, but a self-described line with no document behind it, so expect a probe. Lead with the quote's own terms: four years as a logistics coordinator at a building-supplies wholesaler |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | transferability | Your sentence is delivery scheduling across three depots. Your material does not say production schedules, planning or QA, so the words stay at: "I schedule deliveries for our three depots." Answer slot: the advert's line makes a probe on working with planning and QA likely. If any of your scheduling was done with or for a planning or quality function, say how, in your own words; if it was not, say so plainly and stay with the depots |
| F3 | "chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | presentation | The advert says chase late orders; your sentence says chase suppliers when orders slip. Reword only that: "I chase suppliers when orders slip." Nothing is added about how often, how many or with what result |
| F4 | "track supplier deliveries" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | low | [grounded] | discovery | The sentence touches deliveries without showing whether you track what suppliers send. Answer slot: if you keep track of supplier deliveries in some way, say how, in your own words; if there is no such step, or it is not yours, say so plainly and return to chasing suppliers when orders slip |
| F5 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap on the quote's terms. It carries a figure, so expect a defend-the-number probe: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. C1 and D2 carry those slots |
| F6 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [grounded] | discovery | The sentence says spreadsheet, not Excel, and says nothing about your level. Answer slot: say what the spreadsheet was built in; if it was Excel, say what it did, in your own words; if it was not, say so plainly |
| F7 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Your material does not show a regular report. Answer slot: if you produce any regular report on deliveries, say what it covers and who reads it; if you do not, say so plainly and say what you would track first |
| F8 | "ERP experience (SAP or similar) a plus" — the advert | "Never used SAP — we run our own in-house stock system" — your message | medium | [grounded] | transferability | Words you can say: "I haven't used SAP." Then the second half of your sentence at its own scope: "we run our own in-house stock system." Your material does not say what you do in that system. Answer slot: if you work in it, say what you do in it, in your own words; if you do not, say so plainly |
| F9 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | The figure sits inside the advert's range, below its top. Your own statement of it is the strongest evidence there is for it. Say it plainly: "I'm hoping for £42,000." |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | The advertised pattern sits inside what you said. Say it as you said it: two days at Avonmouth is fine. Your limit of three is yours to state if asked about flexibility, not before |

Notice period has no row: the advert states no term for it and your message gives none. A3 carries it as an answer slot.

## Persona table

Weights are shown with their reasoning so you can recalibrate if you know something I do not.

| Persona | How it shows up in this call | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; Hannah's four named topics asked as chat | Highest (A, 5 questions). The recruiter-screen prior is Conversational plus a light Skeptic, and her message lists her agenda in a friendly register. The risk is treating it as unscored | Short, pre-practised answers for each of her four topics (A2 to A5) and a 90-second arc for A1 built on your quoted sentences |
| Skeptic | Quiet probing of pay against gaps, of fit to a manufacturer, and of why you are moving | Second (B, 4 questions). The prior names a light Skeptic, and her motivation and pay topics are where that register fits | Rehearse B1 until it is boring: hold what your sentences carry, concede the limits plainly, say a ramp plan as a plan |
| Data-Driven Prober | A line-by-line check of the stock-count figure, the spreadsheet, the reporting | Third (C, 3 questions). A 30-minute recruiter call has little room for depth, but the figure is the one number you have given | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Pressure / Stress | A time-boxed "why you" or a push on how much was yours | Fourth (D, 3 questions). Nothing in her message suggests a stress register; kept because short-answer challenges are cheap to rehearse | Pause, restate, hold the position your sentences carry through two follow-ups, concede specifically |
| Case / Strategist | A quick situational or a company-knowledge question | Fifth (E, 3 questions). Her message describes no case, and she plans to tell you about the team and next steps, so this is insurance | Clarify before structuring; say your structure aloud |
| Values and Peer | Not built | No values-style round is documented for this call and no peer is named, so neither is plausible here. If you learn your next round is with a peer or the hiring manager, the banks reweight | none needed now |

## Question banks

### A. Conversational / Rapport Builder (highest weight, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey: what have you been doing, and what's led you to us?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 90-second arc on the beats the quotes state: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with the discrepancies falling by about a third over a year. Tell them in your own words and stop there. Close with one sentence on what in the advert drew you, said as your own interest. Answer slot: the advert asks for coordination across planning, the warehouse and QA, so expect a follow-up on which part of that is closest to your work; say which part is closest, or say plainly that none of your work matches it closely and name the part you would be learning | The biography question opens most recruiter calls and is scored as communication economy. F1 to F5 are the beats available; EXP because it tests whether your account holds together |
| A2 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say it as you said it, in one breath: your Bristol office is closing next year and the only offer is relocating to Reading, which you don't want. Then stop, and turn to the role in one sentence of your own about what you want next. Answer slot: if she asks whether anything else is behind the move, say whether there is, in your own words; if the closure is the whole reason, say so plainly | Hannah named this as one of her four topics, and a recruiter is checking that the reason is consistent with your other answers. EXP because it is a fact about your situation she will test for consistency, not a competency |
| A3 | "How much notice do you have to give?" | JD | [grounded] Hannah's message: "your salary expectations, your notice period" | Your material does not state a notice period, so there are no words here to coach. Answer slot: state your contractual notice in your own words, and whether any of it is flexible; if you do not know, say so plainly and say you will check your contract and tell her | Hannah named it. JD is the closest tag, as role terms rather than a competency; it is included because it is on her agenda, not because a skill is scored |
| A4 | "How would the hybrid pattern work for you, two days a week at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Say that two days at Avonmouth is fine for you. If she asks about flexibility, say your limit as you stated it: you wouldn't want more than three. Do not offer a wider range than that. Answer slot: if she asks how you would get there, say what you would do, in your own words; if you have not worked it out, say so plainly | Hannah named it, and F10 shows you meet the advertised pattern. JD because the pattern is in the advert |
| A5 | "What are you looking for salary-wise?" | JD | [grounded] "I'm hoping for £42,000" | Say it plainly: "I'm hoping for £42,000." The advert's range is £38,000–£44,000, so you need not defend it unprompted. Answer slot: if she asks what you earn now, answer in your own words, or say you would rather talk about this role's range; the choice is yours | Hannah named it first in her list. F9 is where the figure sits against the range. JD because it scores a stated term of the role |

### B. Skeptic (second weight, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The range is £38,000 to £44,000 and you're hoping for £42,000. What supports that?" | JD | [grounded] "I'm hoping for £42,000"; "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year"; "Never used SAP — we run our own in-house stock system" | The highest-ROI rehearsal in this pack. Hold only what your sentences carry: four years as a logistics coordinator, against the advert's 2+ years; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Name the limit before she does: "I haven't used SAP." Follow-up 1, on production scheduling or planning and QA: stay with "I schedule deliveries for our three depots." Follow-up 2, on whether you would take less: your material does not say. Answer slot: decide before Thursday whether there is a figure below which you would not go on, and say it plainly if asked; if you have not decided, say you would want to hear the full package first. Never add experience to close a gap, and return to the quotes after each follow-up | Pay near the top of a range is where a skeptic register checks the gaps, and F2, F6, F7 and F8 are where yours are. The objection is aimed at exactly where the material is thinnest, so the rehearsal is a held, bounded answer, not a thicker one. JD because it scores whether your evidence meets the advertised level |
| B2 | "Which part of this advert would be newest to you on day one?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip"; "Never used SAP — we run our own in-house stock system" | Pick from the advert's own list, the parts your material does not show: production schedules between planning, the warehouse and QA; the weekly report on on-time dispatch; SAP. Say which is newest, plainly: for SAP, "I haven't used SAP." Then a ramp plan, said as a plan about the future and not as a past: what you would ask for or look at first. Answer slot: if you work in your in-house stock system, say what you do in it, in your own words; if you do not, say so plainly | The Skeptic stem is a standard probe of the gaps. F2, F7 and F8 are the three candidates; the plan stays future-tense because the quotes carry no past for it. JD because it scores the advertised list |
| B3 | "Your background is in building supplies, and this is a manufacturer of diagnostic tests. What makes you think it transfers?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Describe the overlap at the scope of your sentence: scheduling deliveries and chasing suppliers when orders slip, set beside the advert's lines on tracking supplier deliveries and chasing late orders. Do not claim more than the overlap. Answer slot: the advert names QA, so expect a probe on it; if your work touched a quality function, say how, in your own words; if it did not, say so plainly and return to the deliveries and supplier chasing | A recruiter is checking that the move to a manufacturer is thought through. F2 is the bridging row and F3 the closest match; JD because it scores the gap between a wholesaler and the advertised role |
| B4 | "If your office weren't closing, would you be looking?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | The answer is yours and only you know it. Answer slot: say honestly whether the closure is the whole reason or whether the work itself also matters, in your own words; if the closure is the whole reason, say so plainly and say what you want in the next role | A recruiter tests whether a forced move becomes real interest in this job. Same material as A2, different angle; EXP because it checks consistency with what you have already said |

### C. Data-Driven Prober (third weight, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say what the quote says: you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. Answer slot: say how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words; where you do not know how it was counted, say so plainly, which is a credible answer. Do not supply a baseline or method you did not use | The only figure in your material, and the usual first target. F5 carries it; EXP because it tests attribution and the defend-the-number slots |
| C2 | "Tell me about your Excel work." | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Start from the sentence: you rebuilt the stock-count spreadsheet. Answer slot: say what it was built in; if Excel, say what it did, in your own words; if it was not Excel, say so plainly. Name no function or feature you did not use | The advert says confident with Excel and your sentence says spreadsheet, as F6 records. JD because it scores a stated requirement |
| C3 | "When have you reported on delivery or dispatch performance?" | JD | [grounded] the advert's "report weekly on on-time dispatch" | Selection scaffold: pick a time you gave someone a view of how deliveries were going, naming what you measured, who it went to and how often. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I schedule deliveries for our three depots." | The advert's reporting line is the one requirement F7 shows no evidence for. JD because it covers a requirement that would otherwise get no rehearsal |

### D. Pressure / Stress (fourth weight, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, rather than someone who has already worked in manufacturing?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "Never used SAP — we run our own in-house stock system" | Pause, restate the question, then hold: four years as a logistics coordinator; scheduling deliveries for three depots and chasing suppliers when orders slip. Concede specifically: "I haven't used SAP." Hold the same ground through two follow-ups, and concede only what the quotes show is a limit. Answer slot: if she asks what you would do first on joining, say it as a plan, in your own words | A time-boxed challenge on the same gap as B1, in a stress register. F2 and F8 are where it presses; JD because it scores fit against the advertised role |
| D2 | "That stock-count result: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold what the sentence says: you rebuilt the spreadsheet. Concede what it does not say: your sentence is that discrepancies fell after the rebuild, not that the rebuild alone made them fall. Answer slot: if anyone or anything else contributed to the fall, name it; if you do not know, say so plainly | Attribution is the probe the Pressure stem exists for. F5 is the row; EXP because it tests the share that was yours |
| D3 | "You're moving because of Reading. Isn't this just any job in Bristol?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want"; "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Do not get defensive and do not deny the location matters: it is what you said. Hold the facts as you stated them, and concede that part of the reason is that you want to stay in Bristol. Answer slot: say in your own words what about this role, beyond its location, draws you; if nothing beyond the location does, say so plainly | The pressure form of A2 and B4, aimed at motivation consistency. EXP because it tests the same stated facts |

### E. Case / Strategist (fifth weight, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you on Monday morning that a delivery your plan depends on will arrive three days late. What do you do first?" | CASE | [generic] | Structure aloud: what exactly is late and what is waiting on it; who needs to know (the advert names planning, the warehouse and QA); what options exist; what you tell them and when; what you record. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's supplier-chasing and scheduling lines (F3, F4), asked as a decision. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| E2 | "The system says 120 of an item and the warehouse counts 100. What do you do?" | CASE | [generic] | Structure aloud: recount first; look at recent movements; find the cause; correct the record; record the cause so it does not recur. The question needs no claim about your past | A live problem from the advert's stock-records line (F5). `[generic]`, as above |
| E3 | "What do you know about us?" | CO | [grounded] the advert: "diagnostic-test manufacturer, about 400 staff" | Say only what the advert says: a diagnostic-test manufacturer of about 400 staff, with a site at Avonmouth. No further research could be retrieved for this pack, so do not recite more than that as fact. Answer slot: if you read more about the company before Thursday, say what you found, in your own words; if you found nothing more, say you have read the advert and ask her to tell you about the team, which she said she would | A recruiter checks that you did some homework. The company-strategy research was not available, so this stays at the advert's level; CO because it scores company knowledge |

## Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in operations or logistics coordination | A1, B1, D1 |
| Coordinate production schedules between planning, the warehouse and QA | B2, B3, E1 |
| Track supplier deliveries and chase late orders | A1, B3, E1 |
| Keep stock records accurate | C1, D2, E2 |
| Report weekly on on-time dispatch | C3 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B1, B2, D1 |
| £38,000–£44,000 | A5, B1 |
| Hybrid, two days a week at Avonmouth | A4 |
| Hannah's stated topics: notice period, what is prompting a move | A3, A2, B4, D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I work most closely with across planning, the warehouse and QA?" | The advert names all three, and the answer tells you what the coordination actually is day to day |
| R2 | "What would a good first three months look like in this role?" | It signals you are thinking about delivery, and it surfaces how the role is judged |
| R3 | "Who reads the weekly on-time dispatch report, and what do they do with it?" | It shows you read the advert closely, and it tells you what the reporting is for |
| R4 | "Which systems does the team use day to day, and how is training handled if I haven't used one of them?" | It names your SAP limit as a plan to learn, not a worry, and it tells you what the advert's ERP line means in practice |
| R5 | "Which days do the team usually share at Avonmouth?" | It shows the hybrid pattern is something you have thought through, and it is a practical fact you need |
| R6 | "What will the next stage look like, and who would I meet?" | Hannah said she would cover next steps; this asks what the next round scores, which tells you what to prepare |

## Prohibited claims

What this pack will not coach, and why. It was built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | A negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't used SAP." No slot |
| Has experience of systems like SAP through the in-house stock system | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation, not words for you: your material does not say what you do in that system. B2's slot stays inside that sentence |
| Has coordinated production schedules between planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says delivery scheduling, not production scheduling. B3's slot stays inside the depots |
| Is confident or advanced with Excel | Inflated form of F6 | F6's quote at its own scope: "I rebuilt our stock-count spreadsheet." Your material says spreadsheet, not Excel and not a level. C2's slot asks what it was built in |
| Cut discrepancies by about a third through the rebuild alone | Inflated form of F5 | F5's quote at its own scope: discrepancies fell by about a third over a year after the rebuild. D2's slot asks what else contributed |
| Would consider the Reading relocation | Contradicted by your quote | "the only offer is relocating to Reading, which I don't want" |
| Is looking for reasons other than the office closure, such as outgrowing the current role | Contradicted by your quote | "I'm looking because our Bristol office is closing next year" |
| Is happy to work more than three days at Avonmouth | Contradicted by your quote, F10 | "I wouldn't want more than three" |

## Sources

Provided documents: the advert text you pasted; Hannah Lowther's LinkedIn message as you pasted it; your description of yourself and what you would tell her. Nothing was fetched from a user link.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, all refused by the host (no permission granted), so nothing came back and nothing from any of them is in this pack:

- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Quillmoor Diagnostics Avonmouth news strategy" — refused
- "Hannah Lowther Quillmoor Diagnostics" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Every call was refused. It would have supplied official value names for possible VAL themes; no VAL question is in the pack, and no values cheat sheet, which a values-style round would have required |
| 2. Quillmoor Diagnostics interview process, operations coordinator | unavailable | Every call was refused. It would have tested the persona weights against documented rounds; they rest on Hannah's message and the recruiter-screen prior |
| 3. Quillmoor Diagnostics strategy or recent news | unavailable | Every call was refused. It would have grounded E3 in current strategy; E3 stays at the advert's level and the grounding brief is absent |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Every call was refused. It would have supplied public professional footprint for an interviewer read and a reverse question tied to her path; both are absent |
| 5. Representative Operations Coordinator advert | skipped | You supplied the advert, which fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period, and whether any of it is flexible → A3's answer slot becomes your own words
- Your CV or the job-history lines from your LinkedIn → F1 to F6 evidence cells quote your own CV, which can raise confidence and sharpen B1, C1 and C2
- What your stock-count spreadsheet was built in and how the discrepancies were counted → F5 and F6 rows, C1, C2, D2
- Any regular report you produce on deliveries → F7 and C3
- Whether you work in the in-house stock system day to day → F8 and B2
- How much time you have before Thursday → a prioritised prep triage sized to it
- Search access for Quillmoor's values, loop, strategy and Hannah's public professional footprint → E3 becomes current, an interviewer read and a path-tied reverse question appear; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available once search is allowed
- Hannah's own notes on the later stages, if she shares them → per-round persona weights in place of the single-call weighting
- A tuesday-dossier.md from an earlier evaluation of the role, if you have one → verified evidence, a named strongest objection and a hard prohibited-claims list in place of the inferred ones here; never required
