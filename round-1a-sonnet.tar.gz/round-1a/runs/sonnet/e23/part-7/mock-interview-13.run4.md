I'll read the reference files the skill requires before writing the pack.
Web search was refused in this session, so the company facts in the pack come from the advert and your message only. I'm writing the pack now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/e23/part-7/rooms/case-13-denied-59987171/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. I built it for a recruiter screen with Hannah, using her own four-item agenda. Web research was refused in this session, so everything about Quillmoor comes from the advert and your message.

The pack has 18 questions, a fit table of the advert against your own sentences, reverse questions, and a list of claims it won't coach. Its highest-ROI rehearsal is B1, the wholesaler-to-manufacturer question. Your material shows delivery scheduling, not production scheduling, so the pack has you hold what you said, concede the limit plainly, then give a learning plan.

Say the word and I'll play Hannah on B1 or on her four announced items.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What's your notice period, and is any of it negotiable? It's the one item on Hannah's list your material doesn't answer.
Can you paste a few CV bullets? Your answers on Excel, what you do in the in-house stock system, and any regular delivery reporting would firm up several rows.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, a 30-minute phone call, Thursday at 2pm.
**Interviewer:** Hannah Lowther, Talent Partner. Her own agenda, from her LinkedIn message: "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", then the team and next steps.
**Built on this assumption:** no CV was supplied, so the evidence is the background you described in your message. Web research was refused in this session, so nothing here about Quillmoor comes from outside the advert.

## 2. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script. Answer slots are instructions for the interview, not questions for you now. Each has two honest branches, and either one is a good answer.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | A live problem set in the role |

## 3. Prep triage

Thursday is two days out. In order:

1. Say A1 to A4 aloud until each is under a minute. They are the four items Hannah announced.
2. Rehearse B1, the highest-ROI prep in this pack. Hold what your sentence says, concede its limit plainly, then give a learning plan.
3. Write one honest line for each answer slot on B2, B3 and A4: Excel, what you do in the in-house system, and your notice period.
4. Read the reverse questions once and pick three.

Everything else is insurance.

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap, but it is a self-reported line with nothing inspected behind it. Lead with it in its own terms: four years, logistics coordinator, building-supplies wholesaler |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling across three depots, not production scheduling, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on cross-team coordination likely. If any of your scheduling involved other teams, say which and what you did, in your own words. If it did not, or none of it was production scheduling, say so plainly and stay with the depots |
| F3 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | The quote carries chasing, and does not show whether you track supplier deliveries. Answer slot: if you keep any record of what suppliers have delivered or are due to deliver, say what it is, in your own words. If you don't, say so plainly and stay with chasing |
| F4 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap. Say it in the quote's own terms: "I chase suppliers when orders slip." Expect a probe on what you do next, which C3 rehearses |
| F5 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, but it holds a figure, so expect to be asked how it was counted. Say the sentence as you said it, no wider. C1 rehearses the figure |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote says spreadsheet and does not say Excel. Answer slot: if the spreadsheet was in Excel, say what you did in it, in your own words. If it was another tool, or you would not call yourself confident, say so plainly and stay with the rebuild |
| F7 | "ERP experience (SAP or similar) a plus" — advert, the SAP half | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used SAP." Then how you would learn it, said as a plan and never as a past. The advert calls it a plus, which is the pack's observation |
| F8 | "ERP experience (SAP or similar) a plus" — advert, the "or similar" half | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | transferability | The quote says the company runs an in-house stock system, and does not say what you do in it. Answer slot: if you work in it day to day, say what you do there, in your own words. If you only see its figures or someone else enters the data, say so plainly and stay with "we run our own in-house stock system" |
| F9 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show any regular reporting. Answer slot: if you produce any regular report on how deliveries performed, say what it is, in your own words. If you don't, say so plainly and stay with the stock-count rebuild |
| F10 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Within the advert's range. It is a hope, not a floor, so the words stay "I'm hoping for £42,000", with no minimum and no flexibility added |
| F11 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Met on your own statement. Keep both halves: two days is fine, and you wouldn't want more than three. The advert says two |
| F12 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. Nothing here can stand in for it. A4 holds the slot for the number |
| F13 | "what's prompting a move" — Hannah's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | No gap. The words are the quote at its own scope. It says the office is closing and the only offer is relocating, which is not the same as saying your role is cut |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| 2+ years in operations or logistics coordination | A5, B1 |
| Coordinate production schedules between planning, the warehouse and QA | B1, D1 |
| Track supplier deliveries | C3, D1 |
| Chase late orders | C3, D1 |
| Keep stock records accurate | C1, D2 |
| Confident with Excel | B3 |
| ERP experience (SAP or similar) | B2, E1 |
| Report weekly on on-time dispatch | D3 |
| £38,000–£44,000 | A3, E2 |
| Hybrid, two days at Avonmouth | A2, E3 |
| Notice period | A4 |
| What's prompting a move | A1, B4 |

## 8. Persona table

Hannah's message is the loop source for this session: one 30-minute phone call with her. It names no later rounds, so the weights rest on her stated agenda plus the recruiter-screen prior (conversational, with a light Skeptic). Recalibrate if you know something I don't.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Hannah's four announced items, asked in a friendly register | High. She listed salary, notice, hybrid and motivation herself, and the recruiter-screen prior points the same way. These are scored although they feel casual | A 90-second arc for A5 built from the F1 to F5 quotes. A short, flat answer for each logistics item |
| Skeptic | Quiet probing of the wholesaler-to-manufacturer step, SAP, and why leave | Medium-high. The advert names production schedules, QA and ERP, and your material shows delivery scheduling, a stated "Never used SAP", and a stated reason for leaving | Rehearse B1 until it is boring. Bridge only from what you said, and name the limit plainly |
| Data-Driven Prober | A recruiter reading "about a third" and asking how it was counted | Medium-low. A recruiter is less likely than a hiring manager to go deep, but the figure is on your own lips | The defend-the-number slots in C1: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours |
| Case/Strategist | A quick what-would-you-do on a late supplier or a stock mismatch | Low. A screen rarely runs cases, and the hiring manager would more likely ask. It is still the way the advert's tasks would be tested | Clarify, then structure, then answer. Think aloud |
| Pressure | A push on the number or on office days | Low-medium. Salary is on her agenda, and a push on £42,000 or on days is a common move | Hold what you said through two follow-ups. Concede only what you have already decided |

Depth is 5, 4, 3, 3 and 3 questions. The low-weight personas sit at 3 to reach the pack floor of about 18.

## 9. Question banks

### A. Conversational (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, what's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Story-mapped on F13, with the three beats the quote states: the Bristol office is closing next year, the only offer is relocating to Reading, and you don't want that. Say them in your own words and stop. Answer slot: the advert's lines on production schedules and late orders make why this role the likely next beat. If something in the role draws you, say what, in your own words. If the honest answer is that staying in Bristol is the main reason, say so plainly. Hold to the quote's scope. It does not say redundancy | Hannah named this item. F13 is the evidence. EXP because it tests whether the story stays the same under follow-up, and a consistent reason is what the screen scores |
| A2 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say both halves as stated: "I live in north Bristol, so two days at Avonmouth is fine." Offer the limit only if she asks how flexible you are: "I wouldn't want more than three." Add no commute details or arrangements you haven't said | Hannah named it. F11 is met, and the advert's two days sit inside your stated limit. JD because it scores a stated term of the role |
| A3 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Say the figure plainly, "I'm hoping for £42,000", then stop and let her respond. The advert's range is £38,000–£44,000, so the figure sits inside it, which is the pack's observation. Answer slot: if she asks what you earn now, or whether you would move on the figure, there is nothing in your material to supply. Decide beforehand. If £42,000 is firm, say so plainly. If there is room, say what it depends on, in your own words | Hannah named it. F10 is high-confidence because it is your own stated number. JD because pay is a stated term of the role |
| A4 | "What's your notice period?" | JD | [grounded] | Say the notice period your contract states, and whether any of it is negotiable or has leave booked. The pack holds none of these facts. Answer slot: give the number as it is, in your own words. If you don't know it offhand, say you will confirm it today | Hannah named it. F12 is a gate your material does not settle, so the pack asks nothing of it and leaves the number to you. JD because it is a stated logistics term |
| A5 | "Tell me about your current role." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip."; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc with the beats the quotes state, in your own words: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for three depots; you chase suppliers when orders slip; you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. End on why you are looking, which is A1 | The biography question is the usual opener, and casual questions are still scored. F1, F4 and F5 are the evidence. EXP because it tests the CV's claims in your words |

### B. Skeptic (weight: medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This site makes diagnostic tests, and the role coordinates production schedules between planning, the warehouse and QA. Your background is a wholesaler. How do you see that translating?" **Highest-ROI prep in the pack.** | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip." | Hold: say what your sentences say, at their scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." Follow-up one: which teams did you work with. Answer slot: if your scheduling involved other teams, say which and what you did, in your own words. If it did not, or none of it was production scheduling, say so plainly and stay with the depots. Follow-up two: how you would learn production planning. Say it as a plan: what you would ask first, and who you would ask. Follow-up three: could you run it on day one. Concede specifically, in your own words, what you would not know yet. Never describe production scheduling as something you have done | F2 is the biggest gap in the snapshot, and the advert names the three teams. JD because it scores a stated responsibility. It is the deepest rehearsal because it is the most predictable objection, and your material is thinnest exactly there |
| B2 | "Have you used SAP, or a similar ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say the stated negative: "I haven't used SAP." Then the second half at its own scope: "we run our own in-house stock system." Answer slot: if you work in it day to day, say what you do there, in your own words. If you only see its figures, or someone else enters the data, say so plainly and stay with that sentence. Then a plan: how you would learn a new system. Never call the in-house system an ERP unless you know it is | F7 is a stated gap and F8 is the nearest thing your material carries. The advert marks ERP as a plus, so this is a probe and not a block. JD because it scores a stated plus |
| B3 | "You rebuilt a stock-count spreadsheet. What did that involve in Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | The question treats the spreadsheet as Excel, and the quote does not say so. Answer slot: if it was Excel, say what you did in it, in your own words. If it was another tool, or you wouldn't call yourself confident, say so plainly and stay with the rebuild: "I rebuilt our stock-count spreadsheet." Don't describe Excel features you did not use | F6 is a discovery row. The advert's "confident with Excel" is the probe. JD because it scores a stated requirement |
| B4 | "Why this role, rather than taking the Reading offer?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Hold the quote: the office is closing, the only offer is Reading, and you don't want it. Answer slot: if there is a reason beyond not wanting Reading, say it, in your own words. If that is the whole reason, say so plainly, and add what draws you to this role only if something does. Don't criticise your employer, and don't add reasons you haven't stated | A recruiter checks motivation consistency, so this is A1 asked as a challenge. F13 is the evidence. EXP because it tests whether the story survives cross-questioning |

### C. Data-Driven Prober (weight: medium-low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say the sentence as you said it. Then the four slots a figure raises, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you don't know how it was counted, say so plainly. Name the weakest assumption before she does. Don't describe a counting method or baseline you can't repeat under a second question | F5 holds the only figure in your material, and a figure is where a prober goes first. EXP because it tests attribution and counting |
| C2 | "How many deliveries a week are you scheduling across the three depots?" | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you know the volume, say it as you know it. If you don't have it to hand, say so plainly and stay with "I schedule deliveries for our three depots." Don't estimate a number you can't defend | The advert's coordination work is volume-sensitive, and the quote gives no number. F2 is the row. EXP because it tests whether the scale claim is yours |
| C3 | "When a supplier order slips, walk me through what you do." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Story-mapped on F4, with the beats the quote states: an order slips, and you chase the supplier. Answer slot: the advert's chase-late-orders line makes the next step the likely probe. If you also tell the depots or re-plan deliveries, say what you do, in your own words. If you don't, say so plainly and stay with chasing | F4 is the clearest match to the advert. EXP because the probe checks what you actually do |

### D. Case/Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you on Monday that a delivery due Friday will be a week late, and production is meant to start Friday. What do you do?" | CASE | [generic] | Clarify first: how firm the new date is, what is affected, whether there is an alternative. Then who needs to know: planning, the warehouse and QA, which are the advert's three teams. Then the options and what you would record. The question asks about no past, so the guidance makes no claim about yours | It is the advert's track-and-chase and coordination lines as a live problem. CASE because it scores structure. `[generic]` because it is a pattern, not a fact about Quillmoor's process |
| D2 | "The stock record says 40 and the warehouse counts 32. How do you work out which is right?" | CASE | [generic] | Clarify what moved since the last count, then the records and the physical stock, then the likely causes, then what you would correct and how you would record it. Think aloud. No claim about your past | It is the advert's stock-accuracy line as a live problem. CASE because it scores structure |
| D3 | "What would you put in a weekly on-time dispatch report, and how would you build it?" | CASE | [generic] | Clarify what counts as on time and where the dispatch data lives, then what the report shows, then how it is checked. Answer slot for F9: if you already produce a regular report of any kind, say what it is, in your own words. If you don't, say so plainly and answer the question as a design | It covers the report line, which has no evidence behind it. CASE because it scores a design built live |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we take you without SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Hold, then concede. Hold: the advert calls ERP a plus, which is the pack's observation. Concede at its stated scope: "I haven't used SAP." Then the plan to learn a system, said as a plan. Follow-up: what do you do in the system you have. Answer slot: if you work in it, say what you do there, in your own words. If you only see its figures, say so plainly. Don't turn the in-house system into SAP experience | F7 is the gap, and this is B2 under time pressure. JD because the probe is on a stated plus. It tests composure over content |
| E2 | "That's at the top end of what we expected. Is there any flexibility?" | JD | [grounded] "I'm hoping for £42,000." | Hold: "I'm hoping for £42,000." The advert's range tops out at £44,000, so the figure is not at the top, which is the pack's observation. Answer slot: whether you have room is your decision, and the pack has no lower figure. If it is firm, say so plainly. If there is room, say what it depends on, in your own words. Concede nothing you haven't decided | F10 is your stated number. JD because pay is a stated term. A push on salary is a common recruiter move |
| E3 | "What if the site needed you in four days a week for a busy spell?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Hold: "I wouldn't want more than three." Answer slot: if there are circumstances where you would, say which and for how long, in your own words. If there are none, say so plainly. Don't offer flexibility you have not said you have | F11 is a stated limit, and this is the test of it. The advert says two days, so the question is a hypothetical. JD because it scores a stated term |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do planning, the warehouse and QA hand over schedules today, and where does it get stuck?" | It is the advert's central responsibility, so it shows you are thinking about the coordination itself |
| R2 | "What would a good first three months look like in this role?" | It gives you a measure to work to and gets her to describe the job's real priorities |
| R3 | "Which ERP does the site use, and how is training handled for new starters?" | It turns the SAP gap into curiosity. Ask it after you have said plainly that you haven't used SAP |
| R4 | "Who reads the weekly on-time dispatch report, and what decisions does it drive?" | It follows the advert's reporting line and shows you care what the report is for |
| R5 | "How is the Avonmouth hybrid arranged day to day: fixed days, or agreed with the team?" | It is the practical follow-up to A2, and it shows you have thought about the days |
| R6 | "What are the next steps, and who would I meet next?" | She said she would cover next steps, so this confirms the format and timing for you |

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has SAP or ERP experience | Negative you stated, F7 | "I haven't used SAP." No slot, only a learning plan |
| Has scheduled production | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: the material says deliveries, not production |
| My role is being made redundant, or I was pushed out | Inflated form of F13 | F13's quote at its own scope: the office is closing and the only offer is relocating. The limit is the pack's observation: the material does not say what happens to your role |
| My stock-count rebuild cut discrepancies by a third | Inflated form of F5 | F5's quote as said: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The pack's observation: the quote does not say the rebuild caused the fall. C1's slots ask only how it was counted |
| Fully flexible on office days | Inflated form of F11 | F11's quote at its own scope: two days is fine, and you wouldn't want more than three |
| £42,000 is my minimum | Inflated form of F10 | F10's quote as said: "I'm hoping for £42,000." |

## 14. Sources

**Provided documents:** your message, which holds the advert, your background, what you plan to say, and Hannah Lowther's LinkedIn message. No dossier was used.

**Searches sent, all refused (permission was not granted in this session):**

1. "Quillmoor Diagnostics values" — refused
2. "Quillmoor Diagnostics interview process operations coordinator" — refused
3. "Quillmoor Diagnostics Avonmouth news" — refused
4. "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every call was refused. It would have fed a values cheat sheet, which this pack does not carry because no values-style round is detected |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Every call was refused. It would have shown later rounds. Hannah's message establishes this session only, so the weights rest on her agenda and the recruiter-screen prior |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Every call was refused. It would have given a CO question grounded in current strategy, and the pack has none |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Every call was refused. It would have fed an interviewer read and a reverse question tied to her path, and both are absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## 15. Upgrade menu

- Your notice period → A4 gets your actual answer, and F12 gets its evidence cell.
- Your CV or a few bullet points → the answer slots on F2, F3, F6, F8 and F9 can become quoted evidence, and the discovery and transferability rows get firmer bridges.
- Search access, or pasted text from Quillmoor's About and careers pages plus one recent news item → a CO question grounded in what the company says, which this pack lacks. A deeper research pass would add up to 6 more searches and 2 more fetches and take several more minutes, if you want it.
- Hannah's public professional footprint, if you can paste her profile → an interviewer read and a reverse question tied to her path.
- A `tuesday-dossier.md` from a job-underwriter pass → the objection to rehearse deepest would come from evidence rather than inference, and each weak area would carry a stated strategy.
