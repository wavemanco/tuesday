Searches were refused, so I'm building the pack from what you pasted. I'm writing it now.
**Check Lumenvale is real before you reply with a time.** Interview, offer and onboarding all happening only on Telegram, with no company email or video call, matches a common recruitment-scam pattern. It may still be genuine, but I couldn't check, because web search was refused. So I haven't verified that Lumenvale, the role or Marcus Hale exist.

- **Verify the job:** find the listing on Lumenvale's own website and look for a contact address on their domain.
- **Ask for more:** a video call and an offer from a company email address (reverse question 5 in the pack covers this).
- **Hold back:** don't pay for anything, send ID or bank details, or install software before a written contract arrives through an official channel.

Your prep pack is saved as `lumenvale_customer-support-specialist_interview_pack.md` in the working directory. It assumes the invitation is genuine and is built as a hiring-manager round, since the message doesn't say how the team lead relates to the role.

- **Highest-ROI question (B1):** "You've worked in energy, not software. What will be hardest in your first month?" You've told me you haven't worked for a software company. Say that plainly, then point to "I use Freshdesk every day" and give a learning plan.
- **Strongest material:** your three years, the daily Freshdesk use and training four new starters. The pack doesn't claim Zendesk use, escalation handling, ticket counts or that you designed the refunds process, because your message doesn't say those things.
- **What the pack couldn't cover:** nothing about Lumenvale's values or product was verified, so the company question is generic.

Say the word and I'll play the team lead on B1 as a live typed-chat drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

1. Can you paste the ad's full text? It would replace my paraphrase with their own words and show any requirement I missed.
2. Do you know if the team lead would be your direct manager? That would reweight the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer-support-specialist_interview_pack.md -----
# Lumenvale Software — Customer Support Specialist — interview prep pack

Interviewer: the support team lead, by text chat on Telegram; the relationship is not stated, so this is built as a hiring-manager round (assumed). Candidate: Imani. This pack assumes the invitation is genuine; the reverse questions in section 11 include the checks worth making either way.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and in a text chat keep each message short.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values: past behavior, not generic virtue |
| EXP | Work-experience deep-dive: do your claims survive a follow-up |
| JD | Role or ad-driven: can you do the listed job, gaps included |
| CO | Company knowledge: homework on what Lumenvale does |
| CASE | A live problem from the actual role, answered in the chat |

Provenance labels: grounded means traceable to something you wrote or a cited source; inferred means derived from a representative source, with the derivation named; generic means a role-family pattern with no claim about you or Lumenvale.

## Fit snapshot

Requirements are the ad as you described it in your message, not the ad's own text. Evidence cells hold only your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you described it | "3 years as a customer service advisor at an energy supplier" — your message, "answering around 60 calls and emails a day" — your message | medium | [grounded] | none | The years are covered in your own words. It is your own account with nothing inspected behind it, so expect a probe. Lead with it as written: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day. Keep the number attached to calls and emails, not tickets |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | none | Name the tool you use: "I use Freshdesk every day." Your material does not mention Zendesk. Answer slot: if you are asked about Zendesk by name, say whether you have used it and how, in your own words; if you have not, say so plainly and return to Freshdesk |
| F3 | "clear written communication" — the ad, as you described it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote includes emails but does not show how clear they were, and the bridge should not claim it. Answer slot: if anyone checked, scored or praised your written replies, say what they said; if nobody did, say so plainly. This interview is typed, so every message you send is also a writing sample |
| F4 | "confidence handling escalations" — the ad, as you described it | none given | none | [inferred] | discovery | Your material does not show escalations either way. Answer slot: the ad's escalations line makes a probe likely. If an escalated case came to you, say what it was and what part was yours, in your own words; if none did, or it was not yours, say so plainly and describe how you would handle one |
| F5 | Software-product context (typical of software support roles; not in the ad as you described it) | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | A strength you offered, not an ad requirement | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Say it as written: you trained four new starters on your refunds process last year. Your material says you trained them, not that you built the process or the training |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material names Freshdesk, not Zendesk. The slot stays on whether you have used it |
| Handled 60 tickets a day | Inflated form of F1 | "Around 60 calls and emails a day." The count is of calls and emails, and your material does not say how they were counted |
| Writes excellent or consistently clear customer emails | Inflated form of F3 | F3's quote at its own scope: you answered emails. The slot asks only what feedback existed |
| Designed or owned the refunds process or its training | Inflated form of F6 | F6's quote at its own scope: you trained four new starters on the refunds process. The limit is the pack's observation: the material says you trained them |
| Has worked in or supported a software product | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." No slot |

## Persona table

The loop rests on your own description: one text chat with the support team lead, with the offer in the same chat. No loop source beyond your message was read, so the weights come from the hiring-manager prior, adjusted for a typed, remote setting. No dedicated values round is detected.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live ticket scenarios you answer by typing | Highest: a team lead hiring support staff most easily tests a reply, and the chat format suits it | Clarify first, structure, then write the actual reply; one clarifying question per case |
| Skeptic | Probes the software gap, Zendesk, escalations | High: F5 is a gap you stated, F4 has no evidence in your material | Rehearse B1 until it is boring; bridge only from your quoted sentences |
| Conversational | Chatty opener, "tell me about yourself", remote working | Medium: the opening of any chat; still scored | A short typed arc from your own sentences; never "I think you've covered everything" at the end |
| Data-Driven Prober | Asks how 60 a day and the four trainees were counted | Medium-low: your figures are small and specific, which invites one follow-up | Say what you know of how each was counted; say plainly where you do not |
| Pressure | Time-boxed, devil's advocate on your fit | Medium-low: typed chats compress this into short challenges | Hold your quoted position through two follow-ups, then concede the specific limit |
| Values/Behavioral | "Tell me about a time…" stories | Low-medium: no published values were read, so themes come from persona stems | Selection scaffold, ending in the honest branch |
| Peer Evaluator | Not expected: the interviewer is the team lead | Low | Not rehearsed |

## Question banks

Highest-ROI prep: B1, the software-company question. It will arrive in some form because F5 is a gap you have stated.

### A. Case/Strategist (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes that the product lost their saved work and they are furious. What is your first reply?" | CASE | [generic] | Structure: acknowledge the problem in one plain sentence, ask only for what you need to investigate, say what happens next and when, and name who you would involve if it looks like a fault. Then type the reply itself, short. The question needs no claim about your past, so the guidance makes none | A live problem from the support role, sized for a typed chat; CASE because it scores structure and reply writing together |
| A2 | "Three tickets arrive together: a billing error, a login problem, and a customer threatening to cancel. In what order do you take them, and why?" | CASE | [generic] | Say your ordering rule aloud before applying it (impact, urgency, what is quick to resolve), apply it to all three, and name the one assumption you would check first. No claim about your past | Prioritization is a standard support-lead probe; CASE because the reasoning is scored, not the order |
| A3 | "A customer wants a refund outside policy and asks for your manager. Walk me through it." | CASE | [generic] | Clarify what the policy allows, what you can offer inside it, what you would tell the customer about the next step, and what you would pass on to whoever decides, in writing. No claim about your past | The ad's escalations line, F4's requirement, asked as a decision rather than a record |
| A4 | "A customer reports a bug you cannot reproduce. What do you ask them for, and what do you pass on?" | JD | [generic] | List what you would ask for (what they did, when, on what device or version, a screenshot or message) and what a handover to a colleague needs so nobody asks the customer twice. If you have not handed a fault to a technical team before, say what you would ask them to show you; that is a plan, not a past | The software-context gap, F5, tested through a live problem rather than a biography |
| A5 | "Write me a two-line reply to a customer who has been told twice that their issue is fixed and it is not." | CASE | [generic] | Type it: an owned apology, what you are doing now, when they will hear back. Two lines, no filler | F3's requirement tested directly: in a typed interview this is the writing sample |

### B. Skeptic (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have worked in energy, not software. What will be hardest for you in your first month?" | JD | [grounded] "I've never worked for a software company" — your message, "I use Freshdesk every day" — your message | The highest-ROI rehearsal. Open with the plain acknowledgment: "I haven't worked for a software company." Then the nearest thing your material carries, at its own scope: "I use Freshdesk every day." Then a plan, said as a plan: what you would learn first about the product and how you would ask for it. Follow-up one, "why should that not worry us": hold to what the two sentences carry. Follow-up two, "what if the product is far more technical": concede it specifically, name what you do not know yet, and restate the plan. Never claim familiarity with software products | F5 is the largest stated gap and the question is aimed at it; JD because it scores fit to the role, Skeptic because it probes the gap |
| B2 | "The ad asks for Zendesk or a similar ticketing tool. What have you used?" | JD | [grounded] "I use Freshdesk every day" — your message | Say: "I use Freshdesk every day." Answer slot: if you are asked about Zendesk by name, say whether you have used it and how, in your own words; if you have not, say so plainly and return to Freshdesk | F2 is covered but is the ad's most checkable line, so expect it in plain terms |
| B3 | "Tell me about a time you handled an escalation." | JD | [generic] | An open prompt, so choose the instance: pick a case that came to you after someone else could not resolve it, with a named stake, what you did, and how it ended. Answer slot: if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle one. Do not describe a case you did not handle | F4 has no evidence in your material and the ad names escalations; the scaffold keeps the answer honest whichever way it falls |
| B4 | "Why customer support at a software company, and why now?" | VAL | [generic] | Your reason is not in your material, so the pack supplies none. Answer slot: say your actual reason in two sentences, in your own words; if it is partly that the role is remote or software is new to you, say that plainly. Do not offer a reason you do not hold | The standard motivation probe, sharper for someone changing sector; VAL because it tests consistency of motive |

### C. Conversational (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me about your background." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" — your message, "I use Freshdesk every day" — your message, "I trained four new starters on our refunds process last year" — your message | Three beats, each one of these sentences in your own words: the role and the three years, the tool you use daily, the training you gave last year. Then one line on why this role, from B4's answer slot. Typed, it should fit in a few short messages | The opening of nearly any chat; EXP because every beat is checkable |
| C2 | "What do you know about Lumenvale and what we build?" | CO | [generic] | Nothing about Lumenvale was verified for this pack, so it supplies nothing. Before the chat, read their own website and product pages, then say what you actually found and one question it raised. If you found little, say so plainly and ask what the team would like you to know | F5's gap makes company homework matter more; generic because no source about Lumenvale was read |
| C3 | "This is a remote role. How do you keep on top of a queue without a team around you?" | JD | [generic] | Answer slot: if you have worked remotely, say how, in your own words; if you have not, say so plainly and describe how you would organise the day. The ad's remote setting raises the question | The ad is remote and your material does not say whether you have worked that way |

### D. Data-Driven Prober (weight medium-low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that counted, and what was the split?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Say it as written: around 60 calls and emails a day. Answer slot: how it was counted, what it varies with, the part of the figure you would defend least, and which part was yours; if you do not know how it was counted, say so plainly | F1's figure is the number a prober picks; EXP because it tests the claim's edges |
| D2 | "You trained four new starters on your refunds process. What did that involve?" | EXP | [grounded] "I trained four new starters on our refunds process last year" — your message | Say what you did with them, in your own words, staying inside the sentence: you trained four new starters on the refunds process last year. Answer slot: how the four were counted and which part was yours; if any part was not yours, say so plainly and stay with the training you gave | F6 is your best unprompted story and the one a prober tests for attribution |

### E. Pressure (weight medium-low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "In two lines: why you over someone with software support experience?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" — your message, "I use Freshdesk every day" — your message | Hold: three years as a customer service advisor and a ticketing tool you use daily. Concede specifically if pressed: "I haven't worked for a software company." Hold through two follow-ups; never concede the three years or the daily tool | F5 turned into a time-boxed challenge; hold-then-concede keeps both honest |
| E2 | "A customer has written four times in an hour, in capitals. You have a minute. What do you type?" | CASE | [generic] | Type one reply: name what they are upset about in their words, say what you are doing right now, give a time. Resist a long explanation. No claim about your past | A typed pressure test of composure, built from the ad's escalations line |

### V. Values/Behavioral (weight low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you put a customer ahead of an internal target." | VAL | [generic] | An open prompt, so choose the instance: a moment with a named stake, a choice you made, and how it ended. Answer slot: if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Stem from the standard values persona; no published Lumenvale values were read, so the theme is generic |
| V2 | "Tell me about a time you had to give someone news they did not want." | VAL | [generic] | An open prompt: choose a case where the news really landed, say what you said and what happened. Answer slot: if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Support work is delivering refusals; the scaffold stops you supplying an ending you did not live |

## Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in customer support | C1, D1, E1 |
| Zendesk or a similar ticketing tool | B2 |
| Clear written communication | A1, A5, E2 |
| Confidence handling escalations | A3, B3, E2 |
| Software-product context (not in the ad as you described it) | A4, B1, E1 |
| Remote working (the ad's setting) | C3 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a good first month look like, and how is it split between queue work and learning the product?" | Turns B1 into a plan you ask for, and shows you are thinking about ramp-up |
| "Which ticketing tool does the team use, and how are newcomers trained on it?" | Answers F2 openly from the other side of the table |
| "How do escalations move between support and the technical team, and what does a good handover look like?" | Shows you think in handovers, which A4 and A3 test |
| "How does the team judge the quality of written replies?" | Invites the feedback F3's slot asks about and shows you care about the writing |
| "Could the final stage include a video call with the team lead, and will any offer come from a company email address with a written contract?" | A reasonable employer can answer this plainly, and the answer tells you something either way |
| "Is this an employed role or a contract, and who would my manager be?" | Basic terms you should know before accepting anything |

## Sources

Provided: your message, including the Telegram text you pasted and your description of the ad and your background. No dossier.

Searches sent, all refused by the host, none returned results:

- Lumenvale Software company values — refused
- Lumenvale Software interview process Customer Support Specialist — refused
- Lumenvale Software Telegram recruiter scam — refused (outside the declared targets)

Research tier: L1 — searches 3 of 6, fetches 0 of 2; every search was refused, so this pack rests on provided material only.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software company values | unavailable | Every call refused. Would have fed a values cheat sheet and CO questions; both are absent or generic |
| 2. Lumenvale Software interview process, support roles | unavailable | Every call refused. The loop rests on your own description of one text chat |
| 3. Lumenvale Software strategy and recent news | unavailable | No call was sent after the first refusals. Would have grounded C2; it stays generic |
| 4. Interviewer name and company | n/a | The support team lead is unnamed, so there is no query to form; the interviewer read is absent |
| 5. Representative Customer Support Specialist JD | skipped | The requirements you gave fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → the fit snapshot rows quote the ad itself instead of your description, and any requirement you did not mention gets a question
- Your answers to F2, F3 and F4's slots (Zendesk use, any feedback on your writing, any escalated case) → those rows are regenerated from your own words
- Whether you have worked remotely → C3 becomes a story map instead of a slot
- The team lead's name and their relationship to the role → persona weights and a reverse question tied to their path
- Search access, or Lumenvale's own careers and about pages pasted in → a real company brief, CO questions grounded in what they build, and a values sheet if published values exist
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), if search access is granted → strategy-grounded CASE and CO questions
- How much prep time you have → a prioritized schedule instead of the full pack
- A tuesday-dossier.md from an earlier underwriting pass → verified evidence and any claims to avoid, without being a prerequisite
