Before you prep, I'd verify this message. Several things in it match a common recruitment scam, and I wouldn't reply with a time yet.

**Why it looks suspicious**
- Legitimate recruiters usually first contact you by email from a company domain, or through the application portal. A cold Telegram message is unusual, even after you applied.
- The message says the interview, the offer and the onboarding will all happen in the Telegram chat. Real companies normally use video calls, a company email and a formal contract.
- It's flattering and generic ("impressed by your CV") and gives no detail about the role, the team or the interview format.
- Scams like this usually move on to asking for ID scans, bank details, a payment for equipment or software, or "training tasks". These requests tend to arrive during the "onboarding" step.

I can't tell you it's definitely fake. Some small companies do recruit informally. It is easy to check, though:
1. Look at the Lumenvale careers page directly, typing the address yourself or finding it by search rather than from this message. Check that this exact role is listed.
2. Check whether your application confirmation came from a Lumenvale email address, and whether you gave your Telegram number or handle on the application form.
3. Find Marcus Hale on LinkedIn and check that he works at Lumenvale. Better still, email the company's published contact or recruiting address and ask them to confirm the contact.
4. Ask for a calendar invite from a company email address and for a video interview. A real recruiter won't object, and a scammer will usually dodge or push back.

**Until you've confirmed it:** don't send ID, a passport, bank details or an address. Don't pay for anything, install software, or accept a cheque or transfer. Don't move to another app at their request.

**Your fit for the role**
- **Customer support experience (2+ years):** strong. You have 3 years at an energy supplier handling about 60 calls and emails a day.
- **Ticketing tool:** a good match. Freshdesk is very similar to Zendesk, so say so directly and don't claim Zendesk experience.
- **Written communication:** strong, backed by the daily email volume. Have an example ready.
- **Escalations:** you haven't mentioned a specific example yet. Pick one real case where you handled a difficult customer or escalated an issue, so you can describe it in detail.
- **Training four new starters on refunds:** a useful extra that shows you can lead and explain a process.
- **Gap:** you've never worked for a software company. Be upfront about it and show you can learn quickly.

Tell me what you find, particularly whether the role is on their careers page and whether Marcus checks out. If it's genuine, I can build you a full prep pack with likely questions, answer guidance based on your real experience, and a live practice round where I play the interviewer.