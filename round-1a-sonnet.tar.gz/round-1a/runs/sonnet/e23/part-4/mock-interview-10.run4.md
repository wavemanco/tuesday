I'll load the interview-prep skill. First, though, there's something in that message you should check before you reply.
Before you reply, check one thing: this message has several features common to fake-recruiter scams.

**Red flags**
- The whole process, including the offer and onboarding, happens in a Telegram chat. Real companies run interviews through their own email, an applicant tracking system, or a video call, and they send offers as formal documents.
- It's a text-only interview with no video or voice. That's unusual for a support role.
- A first contact on Telegram right after you applied on a careers page is unusual. Scammers often scrape applicants or job boards and then message them.
- The message is generic. It doesn't name an interviewer or give a time, and it says nothing specific about your CV, which "impressed" them.

I can't tell from here whether it's fake, and a small company might genuinely do this. It's cheap to check, though.

**What to do before replying with a time**
1. Find Lumenvale's official website yourself, not through any link in the chat. Check that the Customer Support Specialist role is listed on their careers page, and that Marcus Hale appears on LinkedIn as working there.
2. Email the talent team at an address from the official site, or reply through the careers-page application system. Ask them to confirm the Telegram message and the interview.
3. Ask Marcus to move the interview to a video or phone call, or to send the invite from a company email address. A real recruiter will usually agree.
4. In the chat, don't share your ID, passport, bank details, address or national insurance number. Don't pay for equipment or training, and don't accept a cheque or "reimbursement". If an "offer" asks for any of that, it's a scam.

A neutral reply that costs you nothing: *"Thanks Marcus, I'm interested. Could you confirm the interview by email from your Lumenvale address and share the interviewer's name? I'd also prefer a video call if possible."*

**Quick prep for the genuine version**

Your fit against the ad:
- **2+ years in customer support:** you have 3 years as an energy supplier advisor, handling about 60 calls and emails a day.
- **Zendesk or similar:** you use Freshdesk every day, so say "Freshdesk, which is the same kind of tool as Zendesk."
- **Written communication:** the emails you answer daily are your evidence. Have one or two examples ready.
- **Escalations:** you haven't told me about specific cases yet. Pick a real escalation you handled, and I'll help you shape it.
- **Gap:** you've never worked for a software company. Don't hide it. Frame it as moving from supporting a utility's customers to supporting a product's users, then show you can learn a product quickly. Your training of four new starters on refunds supports that.

If you verify the process and want the full prep pack, I need three things from you:
1. Do you know who the interviewer is, such as the support team lead's name?
2. Can you paste the full job ad? Your CV would help too.
3. Do you want me to research Lumenvale's values and recent news, or work only from what you've given me?

I can also run a live mock interview where I play the support team lead. Tell me when you want to start.