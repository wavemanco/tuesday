Before you prep, check whether this is a real invitation. Several things in that message match a common recruitment scam.

**Red flags**
- **Telegram only.** The interview, the offer and the onboarding all happen in one chat. Real software companies use email from a company domain, a video or phone call, and a proper HR or applicant-tracking system.
- **Unprompted contact.** Did you put your Telegram handle or number on the application? If you didn't, they got it from somewhere else.
- **Generic wording.** "We were impressed by your CV" has no detail about your actual background. It would fit anyone.
- **Onboarding in chat.** This is where these scams usually pay off. You're asked for ID, bank details, a fee for equipment or training, or to start doing "test tasks".

I can't verify that Lumenvale Software or Marcus Hale exists, and I haven't searched. This may be legitimate, but check before you invest time.

**How to check**
1. Find the careers page you applied through. Look for a confirmation email, and see whether the company's official site lists this role.
2. Email the careers or HR address on the official site and ask them to confirm that Marcus Hale contacted you and that Telegram is a real stage of their process.
3. Ask Marcus for a video call, or for an email from a company-domain address. A real recruiter will agree. A scammer will push back or stall.
4. Search the company name together with "scam" or "fake recruiter". Check whether the company is registered and has a real LinkedIn presence.

**Until then**
- Don't send ID, a passport, bank details, your address or your National Insurance number.
- Don't pay for anything, and don't buy equipment on a promise of reimbursement.
- Don't click links the chat sends you.
- Don't reply with a time yet. If it's real, a day's delay costs you nothing.

**If it is legitimate, this is how I'd frame your background**
- **Strengths:** your three years and 60 contacts a day clearly exceed "2+ years". You use Freshdesk daily, which is a strong stand-in for Zendesk. Training four new starters shows you can explain things clearly and have some leadership.
- **Gap 1, no software experience.** Say that you handle high volumes of customers who are often frustrated about billing. You can pick up a product quickly because you already know how to learn one under pressure. Don't pretend to know software-specific tooling you haven't used.
- **Gap 2, Zendesk versus Freshdesk.** Name the overlap: ticket queues, macros, tagging, SLAs and escalation paths. Say you'd expect to be productive within days.
- **Gap 3, escalations.** You didn't mention one. Pick a real case where you passed something up or calmed an angry customer, and be ready to give the situation, what you did and the result. Use only what actually happened.
- **Written communication.** Expect a live text exercise, so practise short, warm, structured replies.

I can build the full prep pack for this role. It would have a question bank, answer guidance tied to your own words, and questions for you to ask. I can also run a live practice interview where I play the support team lead. Would you like one of those, and did you give your Telegram details on the application?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.