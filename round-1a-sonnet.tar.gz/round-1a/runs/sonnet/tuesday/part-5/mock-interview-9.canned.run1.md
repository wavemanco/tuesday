I've read the mock-interview playbook and am now running a small research pass on the district, the school and the principal. After that I'll build the prep pack.
Fixing a question-ID collision: the Prober bank used F1 and F2, which clash with the fit-snapshot rows. I'll rename it to bank G.
Your prep pack is saved as `Halvering-Elementary-School_fourth-grade-teacher_interview_pack.md` in your working folder. I built it for Thursday's 45-minute panel with Principal Vantongeren and two fourth-grade teachers. I had no full job posting, so some requirements come from the district's own pages and one sample posting, and the pack labels those as inferred.

- **What the research found:** The district's hiring page confirms the panel format and says it asks about reading instruction, classroom routines and working with families. Its three published beliefs are "Every Child a Reader", "Families Are Partners" and "Teach for Tomorrow, Not for the Test". The board's August 2026 literacy plan brings a new grades 3–5 reading curriculum in fall 2027. Principal Vantongeren spent nine years as a reading specialist and gave a 2025 talk on weekly reading conferences, so expect reading questions from her. The principal result came from a search snippet only, and the pack says so.
- **Your license:** It meets the invite's requirement as you wrote it, and the pack treats it as met.
- **Your two stated gaps:** Never teaching fourth grade and never being a team lead are the likeliest objections. The pack's A1 and A2 rehearse them using only your own sentences, and its prohibited-claims section lists what not to claim.
- **Your ID number:** I didn't need your SSN and haven't used or repeated it. Leave it off anything you send out.

Say the word and I'll play the Skeptic on A1, the day-one question about moving from third grade to fourth. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two questions would change the pack:
1. Do you have the full posting text? If so, the inferred rows become grounded in the real posting.
2. Did HR mention any focus areas or a demo lesson? That would add a section for it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering-Elementary-School_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

- **Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
- **Round:** one 45-minute panel on Thursday
- **Panel:** Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
- **Built on:** the invite and your résumé text. No full posting was supplied, so JD-style requirements come from the district's own pages and one representative posting, and are labeled `[inferred]` where they do.
- **Highest-ROI prep in this pack:** question A1, the day-one question about moving from third grade to fourth. You have stated the gap yourself, so it will be asked in some form.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether your résumé claims survive follow-up questions, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the district's current direction |
| CASE | How you reason through a live classroom problem |

An answer slot is an instruction for the interview, not a question for you now. Answer it from your own experience, or say plainly that the practice was not yours or did not exist.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "valid Illinois Professional Educator License with an elementary endorsement" — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A term your own words show met, so no bridge is needed. Nothing has been inspected here, so expect to be asked to confirm it. Say it as written: license, endorsement, status. Checking the record is yours; the pack uses no license number |
| F2 | "Fourth Grade Teacher position" — your invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then say how you would learn the grade, as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "Fourth Grade Teacher position" — your invite | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [grounded] | transferability | Adjacent work, held at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Your material does not say which parts of third-grade work carry over. Answer slot: if you know what changes between third and fourth in reading, say what, in your own words; if you do not, say so plainly and say what you would ask the fourth-grade team first |
| F4 | "reading instruction" — district hiring page: "Panels ask about reading instruction, classroom routines and how you work with families." | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Both sentences are adjacent to daily reading instruction, and the words stay at their scope: you led your grade level's move, and you have run the club. Answer slot: the panel is said to ask about reading instruction, so expect a probe on what a reading lesson in your room looks like. If you can describe your reading block, do so in your own words; if the move and the club are the nearest thing you have, say so plainly and stay with those |
| F5 | "classroom routines" — district hiring page; "keep clear classroom routines" — representative posting, K12 Jobs Board (typical for the role, not this team's practice) | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | Six years of teaching touches routines without showing which ones were yours. Answer slot: if there are routines you ran every day that you would bring to fourth grade, name them in your own words; if you ran none you can name, say so plainly and say how you would set up the first two weeks |
| F6 | "how you work with families" — district hiring page; "communicate regularly with families" — representative posting (typical for the role); "Families Are Partners: each teacher speaks with every family each term." — district beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | A weekly email is one channel at its own scope. The district's belief speaks of speaking with every family, and your material says the email, not conversations. Answer slot: if you also speak with families in other ways, say how and how often, in your own words; if the email is the main channel, say so plainly and stay with it |
| F7 | "work with the grade-level team" — representative posting (typical for the role); the invite names two fourth-grade team members on the panel | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | presentation | The sentence already reaches team work in other terms. Say it as written and add no steps, trainings or reactions it does not state. Answer slot: if any part of the move was yours to set, say which part in your own words; if the move was shared or the parts were not yours, say so plainly and return to the sentence |
| F8 | "differentiate instruction using assessment data" — representative posting (typical for the role); "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — district beliefs page | none given | none | [inferred] | discovery | Nothing in your material speaks to this. Strong evidence would be a specific time an assessment changed what you taught next, in your own words. Answer slot: if you have used an assessment that way, say what and how; if you have not, say so plainly and say what you would look at first |
| F9 | "Every Child a Reader: no student leaves third grade without a reading plan." — district beliefs page | "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I've run the after-school reading club for the last two years" — your CV | low | [inferred] | discovery | Both sentences touch reading for third graders without showing a plan for any child. Answer slot: if you have written or followed a reading plan for a child, say what it held, in your own words; if the practice did not exist in your school, or was not yours, say so plainly and stay with the club |

## 3. Reading the interviewer

Public professional footprint only. The two fourth-grade team members are unnamed, so no read of them is possible.

| Fact (source) | Practical implication |
|---|---|
| "Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist." — Illinois principals' forum speaker page, search result only, page not fetched | Expect reading-instruction questions from someone who has specialized in reading. Banks C and E lean that way |
| "Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5." — same page | Her published theme may return as a question on how you spend one-to-one or small-group reading time. E2 and E3 carry slots for it. The talk's range of grades 3 to 5 covers both your grade and this one |

- **Shared vocabulary:** reading. Her path (nine years as a reading specialist) and F4's quote, "I've run the after-school reading club for the last two years", sit in the same field. That is vocabulary to share, not a shared career move; no row's evidence carries a matching jump, so none is offered.
- **Persona assignment:** Principal Vantongeren is most likely the Case/Strategist and Skeptic. The two team members are most likely Peer Evaluator and Data-Driven Prober.

## 4. Persona table

The loop is established by the district's own page: "Teacher hiring at Orrinsford is one 45-minute building panel: the principal and two grade-level teachers." Persona weights rest on that, not on an archetype.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet probing of the gaps: fourth grade, team leadership, why now | High. You stated two gaps yourself (F2 and the team-lead limit), and the panel includes fourth-grade teachers who will hold the role's day-to-day | Rehearse A1 until it is boring. Plain acknowledgments only where you stated them; bridges only from your own quoted sentences |
| Peer Evaluator (bank B) | Seam questions, credit, what you need from them | High. The invite puts two fourth-grade team members on the panel | Offer what you bring and what you would ask in return; propose principles, not a seam you have not seen |
| Case/Strategist (bank C) | Live classroom problems and the new curriculum | High. The principal sets the panel's direction, and the district's news page reports a new grades 3 to 5 reading curriculum from fall 2027 | Clarify, structure, answer; think aloud; challenge one premise respectfully |
| Values/Behavioral (bank D) | Open prompts built on the district's three beliefs | Medium. The beliefs page says three beliefs guide every hire, but the hiring page names no values round, so none is detected | Use a selection scaffold and its honest branch; never invent the ending |
| Conversational (bank E) | The opener, the reading club, license confirmation | Medium. Any panel opens this way, and casual questions here are still scored | A 90-second arc built only from your own sentences |
| Data-Driven Prober (bank G) | How you know reading is improving | Low. Your résumé text holds no figures to defend, and the beliefs page ties assessment to teaching | Know what you can and cannot say about how you judge progress; say plainly when you do not know |
| Pressure | Time-boxed challenge | Low. Nothing in the district's description of the panel points to it. No dedicated bank; A4 carries the hold-then-concede structure | A4 |

## 5. Question banks

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You'd be moving from third grade to fourth. Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet." | The highest-ROI rehearsal in this pack. Hold only what the quotes carry: "I've never taught fourth grade." Then, at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: name in your own words the part of fourth grade you expect to be newest to you; if none comes to mind, say so plainly and say what you would ask the fourth-grade team in your first weeks. Do not argue that third grade is the same job | F2 and F3 are the row pair this question presses on. JD because it scores the job's stated grade, with the gap treated as the target |
| A2 | "You haven't been a team lead. How do you see your role on a team that already knows this grade?" | JD | [grounded] "I've never been a team lead" "I led our grade level's move to a new reading curriculum in 2024" | Say the acknowledgment plainly: "I've never been a team lead." Then the sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if any part of that move was yours to set, say which part and how you decided; if the parts were shared or not yours, say so plainly and return to the sentence. Then what you would ask of this team, as a plan | F7 is the row this presses on, and the limit is one you stated. JD because the invite puts grade-level teammates on the panel |
| A3 | "Why fourth grade, and why now?" | EXP | [generic] | Your actual reason, in your own words. Answer slot: give the real reason; if part of it is about this school or this district, say which part and how you know. Do not borrow the district's wording for a reason that is yours | The Skeptic's motivation probe: why leave, why here, why now. EXP because it scores consistency of your story. `[generic]` because the question makes no claim about your past |
| A4 | "You led your grade level's move to a new reading curriculum. How much of that was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The attribution probe, held in the shape hold-then-concede. Hold: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: which parts were yours, in your own words; if any were not, or were shared, say so plainly and specifically, then return to the sentence. Hold through two follow-ups by returning to the sentence, never by adding to it | F7 and F4 both rest on this one sentence, so it is the likeliest claim to be tested. EXP because it scores attribution |
| A5 | "What do you know about how fourth grade differs from third in reading?" | JD | [generic] | No claim about your past is needed. Answer slot: say what you know and where you know it from, in your own words; if you do not know, say so plainly and say what you would ask the team and what you would read first | A grade-knowledge probe from the same gap as A1. JD because it scores the job's grade. `[generic]` because the pack does not know this district's fourth-grade reading program |

### Bank B: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our team sits side by side. Where would you lean on us, and what would you bring?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I write a weekly email to families." | Reciprocity first: what you would bring, then what you would ask in return. What you bring can be those two sentences at their own scope, in the order you choose, without calling them proof of anything. Propose principles for the seam, not a seam you have not seen | F7 and F6 hold the evidence. JD because it scores fit with the grade-level team |
| B2 | "Tell me about a time you and a colleague disagreed about how to teach something." | EXP | [generic] | Selection scaffold: pick a time with a named point of disagreement, what you said, and how the working relationship stood afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | A peer disagreement stem. EXP because it scores what actually happened. `[generic]` because your material has no sentence for it |
| B3 | "We'll be teaching new material side by side this year. What would you need from us in the first month?" | CASE | [generic] | A live problem, so no claim about your past. Structure: what you would ask first, what you would watch, what you would offer back. Name no practice you have not stated | The panel's team members price what a hire costs their work. CASE because it is a decision, not a record |
| B4 | "How do you keep families informed week to week, and how would that fit with how we do it?" | JD | [grounded] "I write a weekly email to families." | Say what you do, as stated: "I write a weekly email to families." Answer slot: if there are parts beyond the email, such as calls or conferences, say so in your own words; if the email is the main channel, say so plainly. On fit, propose principles and ask how the team does it | F6 is the row; the district's belief "Families Are Partners" raises the probe. JD because it scores the stated family-communication duty |

### Bank C: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The board has adopted a plan with a new grades 3 to 5 reading curriculum from fall 2027. As a fourth-grade teacher, what would you want to know first?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Clarify, then structure. What is changing and from what, the timeline, what support comes with it, who decides pacing. Then objective, approach, risks. You may name the quoted sentence once, at its own scope. Answer slot: if any step of that 2024 move would shape how you would start here, say which step and what was yours; if none would, or none was yours, say so plainly and return to the sentence | Grounded in the district's news page (search result, Sources). CO because it scores whether you can think at the district's altitude |
| C2 | "A fourth-grader arrives reading well below the rest of the class. Walk me through your first two weeks." | CASE | [grounded] | A live problem, so no claim about your past. Start with what you would observe and ask, including a conversation with the family and the assessment you would use, then what you would try and how you would check it. "Assessments inform teaching and never replace it" is the district's framing; let your answer show it without quoting it | The district page lists reading instruction as a panel topic, and the beliefs page frames assessment as informing teaching. CASE because it is a decision |
| C3 | "The fall reading screener comes back and half the group is below benchmark. What do you do with that?" | JD | [inferred] | Structure: what you would look for in the data, what you would change in grouping or instruction, how you would tell families. Answer slot: if you have used assessment results that way, say what and how, in your own words; if you have not, say so plainly and say what you would look at first | F8 is the row. The posting is a representative one, so the duty is typical for the role, not stated for this team. JD because it scores a stated responsibility |
| C4 | "It's the second week of school. Walk me through a normal morning in your fourth-grade room." | CASE | [inferred] | Describe the morning as you would run it: arrival, the first lesson, transitions, how a child knows what to do next. Answer slot: if there is a routine you ran in third grade that you would keep, name it; if you would start fresh, say so plainly | F5 is the row; "classroom routines" is on the district's panel topic list. CASE because the answer is a design |

### Bank D: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you made sure a struggling reader was not left behind." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold: pick a time with a child (no names), what you noticed, what you changed, and what was different afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the reading club at its own scope, or how you would handle it. Never supply an ending | The district's belief "Every Child a Reader: no student leaves third grade without a reading plan." raises it. F9 is the row |
| D2 | "Tell me about a hard conversation with a family." | VAL | [grounded] "I write a weekly email to families." | Selection scaffold: a named concern, what you said, how it stood afterward. If no such conversation comes to mind, say so plainly, then give the nearest thing, the weekly email at its own scope, or how you would handle it | Raised by "Families Are Partners: each teacher speaks with every family each term." F6 is the row |
| D3 | "Our belief is that assessments inform teaching and never replace it. What does that mean in your classroom?" | VAL | [grounded] | Answer slot: if you have used an assessment to change what you taught next, say what and how, in your own words; if you have not, say so plainly and say how you would decide. The words in your answer are yours, not the district's | Raised by "Teach for Tomorrow, Not for the Test". F8 is the row |

### Bank E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey. How did you get to teaching, and to this chair?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families." | A 90-second arc, one clause per sentence, each in your own words and at its own scope. The start of the story, why you became a teacher, is yours; nothing here supplies it. Do not describe your work as proof of a skill | The opener on any panel. F3, F4, F6 and F7 supply the quotes |
| E2 | "How do you get time with individual readers?" | JD | [grounded] | Answer slot: the principal's published talk covers weekly reading conferences in grades 3 to 5, so expect this. If you meet with readers one to one or in small groups, say how and how often, in your own words; if you do not, say so plainly and say what you would try | Interviewer's published theme, Sources. JD because reading instruction is a panel topic |
| E3 | "Walk me through the reading club you run." | EXP | [grounded] "I've run the after-school reading club for the last two years" | The beats the sentence states: after school, run by you, for two years. Answer slot: given the principal's published interest in small groups, expect a probe on how club time is spent. If you ran it in small groups or one to one, say how; if not, say so plainly and describe what you did | F4 is the row. EXP because it scores what you actually did |
| E4 | "Tell us about your license: what you hold and where it stands." | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | State it as written. Facts only: license, endorsement, status. No elaboration | F1 is a stated requirement in the invite. A plain question gets a plain answer |

### Bank G: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "How do you know a child is reading better than in September?" | JD | [inferred] | Answer slot: if you have a way you check progress, name it and say what it does and does not tell you, in your own words; if you do not, say so plainly and say what you would use. Say plainly where you do not know how something is counted | F8 is the row. JD because it scores the stated assessment duty. Your material holds no figures, so there is no defend-the-number question |
| G2 | "Tell me about something you changed in how you teach reading, and what made you change it." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Selection scaffold: a named change, what you saw before, what you saw after. If no such change comes to mind, say so plainly, then give the nearest thing your material carries or how you would approach it | Reading instruction is a panel topic. EXP because it scores what you actually changed |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "valid Illinois Professional Educator License with an elementary endorsement" | E4 |
| "Fourth Grade Teacher position" | A1, A3, A5 |
| "reading instruction" | C1, C2, D1, E1, E2, E3, G2 |
| "classroom routines" | C4 |
| "how you work with families" | B4, D2 |
| "work with the grade-level team" | A2, A4, B1, B2, B3 |
| "differentiate instruction using assessment data" | C3, D3, G1 |
| "Every Child a Reader" | D1 |
| team-lead experience, a stated limit, not a requirement in any source | A2 — none beyond it, because no source names it as a requirement |
| figures on your résumé | — none, and why: your material states none, so there is nothing to defend |

## 6. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. What do you look for in a fourth-grade reading block now, from this chair?" | Ties to her published path ("after nine years as a reading specialist"), and shows you researched her, not only the district |
| R2 | "Your 2025 talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5. How does that look in fourth grade here?" | Her own published theme, asked as a peer conversation |
| R3 | "The board's plan brings a new grades 3 to 5 reading curriculum from fall 2027. What does the fourth-grade team want from it, and what support comes with it?" | Shows you read the plan, and points at the work the team will actually do |
| R4 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for the two team members on the panel |
| R5 | "What does a strong first term look like for someone new to fourth grade on this team?" | Turns your stated gap into a plan the team gets to define |
| R6 | "How does the team share families' questions and communicate with families across the grade?" | Connects to "Families Are Partners" and lets you compare it with the weekly email |
| R7 | "When would you expect to reach out for references?" | The district page says "References are taken up after the panel." A practical close |

## 7. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or has fourth-grade experience | Negative you stated, F2 | "I've never taught fourth grade." Then "Six years teaching third grade at a public elementary school in Joliet." at its own scope |
| Has been a team lead, or led the fourth-grade team | Negative you stated: "I've never been a team lead" | "I've never been a team lead." Then "I led our grade level's move to a new reading curriculum in 2024" at its own scope |
| Chose, wrote or designed the new reading curriculum | Inflated form of F7 and F4 | The quote at its own scope. The limit is the pack's observation: your material says you led the grade level's move, not who chose the curriculum. A2 and A4 slots stay inside the move |
| Speaks with every family every term, or runs family conferences | Inflated form of F6 | The quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: your material says the email, not conversations. B4's slot stays inside the email |
| Has written or followed reading plans for students | Inflated form of F9 | F9's quotes at their own scope. The limit is the pack's observation: the material shows the club and third-grade teaching, not any plan. D1 stays an open prompt |

## 8. Sources

- **Provided documents:** the interview invite and your résumé text, pasted into this conversation. A license number and a government ID number appear in what you sent; neither is used in this pack or in any search.
- **Dossier:** none present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | VAL bank D and F6, F8, F9. Three beliefs by name, fetched from the district page. No values round is detected, so there is no values cheat sheet |
| 2. `Orrinsford Community School District teacher interview process fourth grade` | yes | The loop: one 45-minute panel of principal and two grade-level teachers, with topics. Persona weights follow it, and no archetype fallback is used |
| 3. `Orrinsford Community School District news reading curriculum 2026` | yes | C1 and R3: the board's literacy plan, adopted August 2026 |
| 4. `Halvering Elementary School Orrinsford principal Dolores Vantongeren` | yes | Section 3, E2, E3, R1, R2. The page was a search result only and was not fetched; the two team members are unnamed |
| 5. representative `Fourth Grade Teacher` JD | yes | F5, F6, F7, F8 and C3, G1. A search snippet only, cut off at its qualifications line; the fetch budget had gone to targets 1 and 2 |

Searches sent, with what came back:

- `Orrinsford Community School District values mission`: https://orrinsfordschools.example/about/mission-and-beliefs
- `Halvering Elementary School Orrinsford principal Dolores Vantongeren`: https://ilprincipalsforum.example/speakers/dolores-vantongeren
- `Orrinsford Community School District teacher interview process fourth grade`: https://orrinsfordschools.example/careers/how-we-hire-teachers
- `Fourth Grade Teacher job posting Illinois elementary school requirements`: https://k12jobsboard.example/listings/fourth-grade-teacher
- `Orrinsford Community School District news reading curriculum 2026`: https://orrinsfordschools.example/news/board-adopts-literacy-plan

Pages fetched: https://orrinsfordschools.example/about/mission-and-beliefs and https://orrinsfordschools.example/careers/how-we-hire-teachers.

## 9. Upgrade menu

- The full posting text → the `[inferred]` rows F5, F6, F7 and F8 become `[grounded]`, and any requirement not on this list gets a question
- The names of the two fourth-grade team members → per-member persona weights and a tailored reverse question
- Anything HR said about focus areas, or a demo lesson or other deliverable → a build section for it and a more exact bank mix
- Which grades your reading club serves and how a session runs → F4 and E3 move from slot to story-mapped guidance
- Your actual reading block, routines and use of assessments, answered in your own words → F5, F8 and F9 move from discovery rows to quoted evidence, and the pack regenerates around them
- How much prep time you have → a prioritized schedule of the few things to do first
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on the district's literacy plan and recent organization context, and loop reports for this role
- A `tuesday-dossier.md` → confirmed evidence per requirement, so the bridges above can draw on checked material
