Search permission was declined, so I'm building the pack from your advert, Hannah's message and what you told me, and I'll record that in the pack's Sources. Writing the file now.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-5/rooms/case-13-denied-b65aeb92/quillmoor-diagnostics_operations-coordinator_interview_pack.md`.

I built it for a recruiter screen with Hannah, using only her message, the advert and what you told me. My four web searches were refused (search permission wasn't granted), so I didn't research Quillmoor's values, interview process or news, or Hannah herself. The pack says so in its Sources section and doesn't state anything about the company. The CASE questions are generic scenarios for the same reason.

The pack has 18 questions, a fit snapshot, six reverse questions and a list of claims it won't coach.

- **Your four answers:** your own words go straight into the pay, hybrid and reason-for-leaving answers. You didn't mention a notice period, so that answer is an instruction to give your actual notice, not a figure.
- **Most important to rehearse:** question B2, "You haven't used SAP. How would you get up to speed on our ERP?" Hold your own words ("never used SAP", and your company's in-house stock system), then give how you'd learn theirs as a plan.
- **Wording to be careful with:** your pay figure is "hoping for £42,000", not a minimum. Your reason for leaving is that the office is closing and the only offer is Reading, so don't recast it as redundancy.
- **Gaps from your message:** it says deliveries across three depots, not production scheduling, and a spreadsheet, not Excel specifically. The pack has slots for you to answer both from what is true.

I can play Hannah in a live drill, starting with B2. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word, if you'd like either.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, Thursday 2pm, a 30-minute phone call. Hannah Lowther (Talent Partner) rings the mobile number on your application.
**What she said she will cover:** salary expectations, notice period, how the hybrid pattern would work for you and what is prompting a move. Then she tells you about the team and the next steps.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for your own words, not a script. Where a cell says "Answer slot" or "Logistics slot", that is an instruction for the call: answer from what is true for you, or say plainly that a step was not yours or did not exist.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behaviour shows the company's published values (none in this pack: no values-style round is established for this call) |
| EXP | Whether what you say about your experience survives follow-up, and what was actually you |
| JD | The advert's stated duties, requirements and terms |
| CO | Knowledge of the company and its strategy (none in this pack: no company research was possible) |
| CASE | A live problem set in the role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries across three depots, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you coordinate with likely. If any of your scheduling was agreed with other teams, say which and how, in your own words; if it was not, or none of it was yours, say so plainly and stay with the delivery scheduling |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | Lead with the chasing in the sentence's own terms: you chase suppliers when orders slip. Answer slot: the advert's word track makes a probe on how you learn an order has slipped likely. If there was a step you took to find out, say what it was, in your own words; if there was none, say so plainly and stay with the chasing |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | Lead with the sentence at its own scope: about a third, over a year. The sentence puts the rebuild beside the fall and does not say one caused the other. It is the one figure a prober checks, so the defend-the-number slots in C1 and E3 apply: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show whether you produce any regular report. Answer slot: if you do, say what it covers, how often and who reads it, in your own words; if you do not, or it was not yours, say so plainly and stay with the stock-count work |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | Say it as written: four years as a logistics coordinator. The advert asks for two or more, and a CV line with nothing inspected behind it invites a probe on what the role covered, which F1 to F3 answer at their own scope |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The sentence names a spreadsheet, not the tool, and says nothing of its features. Answer slot: if it was Excel, say so and name what you built in it, in your own words; if it was another tool, say so plainly and say what you used |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | transferability | The advert marks this a plus. Words: "I've never used SAP", and then the system at its own scope: "we run our own in-house stock system." Answer slot: the advert's ERP line makes a probe on what you do in that system likely. If you record, look up or adjust stock in it yourself, say which, in your own words; if others work in it, or you only read from it, say so plainly and stay with the system as the one your company runs |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | A term you have stated as met. Give the two-day answer first, in your own words. The ceiling of three is the second half of your own sentence, for if she asks about flexibility |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | A term you have stated, inside the advert's band. You said hoping, so the pack keeps it as a hope and never as a floor |

## Persona table

The loop for this call comes from Hannah's own message: one 30-minute phone call run by her, covering four named topics. That establishes this session and nothing about later rounds, so no archetype is assumed for them and the weights rest on the recruiter-screen prior for this call.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational | Friendly, unstructured; pay, notice, hybrid and "what's prompting a move" arrive as chat | High. Her message lists exactly these four topics, and the recruiter-screen prior puts logistics and motivation first. Depth 5 | A short arc for the background question; treat every casual question as scored; give the logistics answers as your own plain words |
| B. Skeptic | Quiet probing of gaps: why here, why now, the missing system, delivery versus production | Medium. The recruiter prior says "light Skeptic", and your own message gives two obvious places to probe: no SAP, and deliveries rather than production. Depth 4 | Rehearse B2 until it is boring; hold on what your sentences say; name limits plainly |
| C. Data-Driven Prober | Asks how a figure was counted; checks the reporting and Excel lines | Low to medium. A recruiter rarely drills numbers, but the one figure in your material is the kind that gets a follow-up if your application repeats it. Depth 3 | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| D. Case / Strategist | A quick "what would you do if" drawn from the advert's duties | Low. Recruiter screens seldom run live problems, but this is a coordination role and a short scenario is possible. Depth 3 | Clarify first, then structure, then act; say the structure aloud |
| E. Pressure | Questions motive, asks for sixty seconds, asks how much was you | Low as a style. Depth is 3 rather than 2 because the reason for leaving is the item a screen most reliably tests | Pause, restate, hold the position through two follow-ups, then concede only what is true and specific |

## Question banks

### A. Conversational (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc with three beats, each one a clause of those sentences: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Tell them in your own words and add no detail beyond them. End by stopping, not by summarising | F5 is the requirement this answers, F2 and F3 are the beats most likely to be followed up; EXP because it tests what you say about your own work |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot, filled by your own words: "I'm hoping for £42,000." The advert's band is £38,000–£44,000, which your figure sits inside. Say the figure once and stop. If she asks what you earn now, give your own current figure or say you would rather stay with the figure you are seeking, whichever is true for you | F9 is the stated term; JD because it is the listed job's term and she named it as a topic |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in the wording of your contract. If she asks whether it could be shorter, answer only with what you know to be true | You gave no notice figure, so the pack supplies none. No fit row speaks to it; JD because it is a term of the listed job |
| A4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot, filled by your own words: "I live in north Bristol, so two days at Avonmouth is fine." Keep "I wouldn't want more than three" for if she asks about flexibility. If she asks about the journey, give your own | F8 is the stated term and the advert's pattern sits inside it; JD because it is the listed job's term |
| A5 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot, filled by your own words, as that sentence says it: the Bristol office is closing next year, the only offer is relocating to Reading, and you do not want that. Say it plainly and stop. Do not recast it as redundancy or as a long-held plan (section 13) | The reason for leaving is the topic every screen covers, and your sentence is the whole of what the material carries; EXP because it tests whether the reason holds under follow-up |

### B. Skeptic (weight: second)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why this role, and why now?" | JD | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | "Why now" is A5's sentence in your own words. For "why this role", pick what in the advert you can speak to from your own work: it lists coordinating schedules, tracking supplier deliveries and chasing late orders, keeping stock records accurate, and reporting weekly on dispatch. Choose the duties where you have something real to say. If no reason beyond staying in Bristol comes to mind, say so plainly, then say what you would want to learn about the role | A5 gives the "why now"; the "why this role" half is where a screen looks for consistency; JD because it scores fit with the advert |
| B2 | "You haven't used SAP. How would you get up to speed on our ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | The highest-ROI rehearsal in this pack: this question will arrive in some form. Hold what the sentence carries: "I've never used SAP", and "we run our own in-house stock system." Answer slot: if you record, look up or adjust stock in that system yourself, say what, in your own words; if you do not, say so plainly and stay with the system as the one your company runs. Then say how you would learn theirs as a plan, in your own words, never as something already done. Hold through two follow-ups by returning to the sentence, and concede only what it says: SAP is not something you have used | F7 is the requirement and the largest stated gap; the advert marks it a plus, which is the context a recruiter will hear. JD because it scores a listed requirement |
| B3 | "Our scheduling is production scheduling across planning, the warehouse and QA. How does what you do map across?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Start from the sentence at its own scope: you schedule deliveries for three depots and chase suppliers when orders slip. Answer slot: if any of that scheduling was agreed with other teams, say which and how, in your own words; if it was not, or none of it was yours, say so plainly and stay with the delivery scheduling. Do not describe your work in the advert's words | F1 is where the advert's duty presses hardest against the material; JD because it scores the stated responsibility |
| B4 | "Walk me through what you do when an order slips." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The beats the sentence states: an order slips, you chase the supplier, the deliveries are for three depots. Answer slot: the advert's tracking line makes a probe on how you find out an order has slipped likely, and on what happens when chasing does not work. Say what you did, in your own words; if there was no further step, or it was not yours, say so plainly and stay with the chasing | F2 is the requirement; EXP because it tests whether the story has an actual instance behind it |

### C. Data-Driven Prober (weight: middle)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that one-third was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say the figure at its own scope: about a third, over a year. Four slots, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly | F3 holds the only figure in the material; EXP because it tests whether the number survives scrutiny |
| C2 | "Which tools do you work in day to day, and how confident are you in Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if the spreadsheet was in Excel, say so and name what you built in it, in your own words; if it was another tool, say so plainly and say what you used. Name nothing you did not use | F6 is the requirement and the sentence does not name the tool; JD because it scores a listed requirement |
| C3 | "The role reports weekly on on-time dispatch. What reporting have you done?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if you produce any regular report, say what it covers, how often and who reads it, in your own words; if you do not, or it was not yours, say so plainly and stay with the stock-count work: you rebuilt the spreadsheet and discrepancies fell by about a third over a year | F4 has no quoted evidence, so this is where the gap is rehearsed; JD because it scores a listed duty |

### D. Case / Strategist (weight: middle)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you a delivery QA needs for tomorrow's batch will arrive two days late, and the warehouse has already cleared the slot. What do you do?" | CASE | [generic] | Structure it aloud: what you would ask first (what the batch depends on, whether a part-shipment would do, who owns the call), what the options are, who you tell in planning, the warehouse and QA, and what you record and follow up. The question needs no claim about your past, so the guidance makes none | A live problem drawn from the advert's supplier and QA lines (F1 and F2); [generic] because it is a pattern for the problem, not a fact about this employer |
| D2 | "Planning wants to pull a large order forward, and the warehouse is already at capacity. How do you handle it?" | CASE | [generic] | Clarify the ask and the constraint, say what you would need from each side, propose an option and name its cost, and say how the three teams hear the decision. Challenge one premise politely. No claim about your past | F1's requirement set as a decision; [generic] for the same reason as D1 |
| D3 | "A stock count shows a gap on a component production needs today. What do you do first?" | CASE | [generic] | Say what you would check before assuming the record is wrong, who you would tell, and how you would record what you found. No claim about your past | F3's requirement set as a decision; [generic] for the same reason as D1 |

### E. Pressure (weight: low, depth 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Your office is closing. Why not just take Reading? Isn't this simply a way out?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Pause and restate the question. Hold through two follow-ups by returning to the same sentence: the office is closing, the only offer is Reading, and you do not want it. Concede only what the sentence says: the closure is what prompted the search. Answer slot: say what in the advert you would want, in your own words; if it is mainly that the role is in Bristol, say so plainly | A5's sentence tested for motive; EXP because it scores whether the reason holds |
| E2 | "You've come from a wholesaler and we make diagnostic tests. Sixty seconds: why you?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Hold on the two sentences: four years as a logistics coordinator, scheduling deliveries for three depots and chasing suppliers when orders slip. Answer slot: if any of your work touched manufacturing or production, say how, in your own words; if it did not, say so plainly and stay with the coordination | F5 and F1 are where the sector change presses; JD because it scores fit with the listed job |
| E3 | "That one-third. How much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold what the sentence gives you: you rebuilt the stock-count spreadsheet. The fall is the part to concede carefully. Answer slot: if other changes or other people contributed, say what, in your own words; if you do not know what else changed, say so plainly. Never say the rebuild caused the fall unless you can stand behind that | F3 is the figure; EXP because attribution is what the question tests |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B3, D1, D2, E2 |
| Track supplier deliveries and chase late orders | B4, D1 |
| Keep stock records accurate | C1, D3, E3 |
| Report weekly on on-time dispatch | C3 |
| 2+ years in operations or logistics coordination | A1, E2 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B2 |
| Hybrid, two days a week at Avonmouth | A4 |
| £38,000–£44,000 | A2 |
| Her named topics not in the advert: notice, reason for leaving | A3, A5, B1, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which handoff between planning, the warehouse and QA is the hardest to coordinate at the moment?" | It uses the advert's own three groups and shows you read the duty as coordination between teams |
| R2 | "What does the weekly on-time dispatch report look like today, and who reads it?" | It turns the reporting duty into a conversation and tells you how much of the role it is |
| R3 | "Which system does the team work in day to day, and how is someone new to it brought up to speed?" | It raises the ERP point yourself, on your terms, and shows you are thinking about the ramp |
| R4 | "Are the two days at Avonmouth fixed days, or agreed with the team?" | It tests the hybrid term you said is fine and shows you have planned around it |
| R5 | "Is this a new role or a replacement, and who does it report to?" | It tells you what the role is for and who will run the next round |
| R6 | "Is there anything in my background you would like me to say more about before this goes to the hiring manager?" | It invites the objection while you can still answer it, and recruiters weight a closing question that is not generic |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says deliveries across three depots, not production schedules between planning, the warehouse and QA. B3's slot stays inside the delivery scheduling |
| Has used SAP | Negative you stated, F7: "Never used SAP" | The plain acknowledgment: "I've never used SAP." No slot |
| Has ERP experience | Inflated form of F7 | F7's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: your material says the system, not what you do in it. B2's slot stays inside it |
| Advanced Excel skills | Inflated form of F6 | F6's quote at its own scope: a stock-count spreadsheet. The limit is the pack's observation: your material names a spreadsheet, not the tool or its features. C2's slot asks only which tool |
| Cut discrepancies by a third because of the rebuild | Inflated form of F3 | F3's quote at its own scope: "about a third over a year", beside the rebuild. The limit is the pack's observation: the sentence places both and does not say one caused the other. E3's slot stays on what else changed |
| Was made redundant, or had been planning to leave anyway | Inflated form of the reason for leaving, A5 | The quote at its own scope: the office is closing next year, the only offer is Reading, and you do not want it |
| £42,000 is my minimum | Inflated form of F9 | F9's quote at its own scope: "I'm hoping for £42,000." |

## Sources

Provided documents: Hannah Lowther's LinkedIn message (her own words, which establish this call and the four topics she will cover), the advert you pasted, and your own account of your background and what you would tell her. No dossier was present.

Searches sent, all refused because search permission was not granted:
- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Quillmoor Diagnostics Avonmouth news" — refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Would have decided whether a values cheat sheet applies; none is built, and no company values are stated anywhere in this pack |
| 2. Quillmoor Diagnostics interview process, operations coordinator | unavailable | Would have named later rounds and moved persona weights beyond this call; weights here rest on Hannah's message and the recruiter-screen prior |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | Would have grounded a CO or CASE question in current priorities; D1 to D3 are labelled [generic] instead |
| 4. Hannah Lowther at Quillmoor Diagnostics | unavailable | Would have supplied an interviewer read and a reverse question tied to her path; both are absent |
| 5. Representative Operations Coordinator advert | skipped | The advert you pasted fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Your notice period → fills A3 with your own words in place of an instruction
- Permission to run the four searches above, or a pasted careers or values page → company values, the shape of later rounds and recent news, which would turn D1 to D3 from [generic] into questions set in this company's own work. A deeper pass would add a strategy brief, her public professional footprint and recent organisation news: up to 6 more searches and 2 more fetches, several more minutes
- Whether your current job produces any regular report, and whether the stock-count spreadsheet was in Excel → upgrades rows F4 and F6, and turns C3 and C2 from slots into story-mapped answers
- Your CV or the application text Hannah has in front of her → quoted evidence for F1 to F7 from the document she is reading, and a check that what you say matches it
- A tuesday-dossier.md from an earlier fit check, if you have one → verified evidence, a prepared objection and a list of claims to avoid, in place of the ones inferred here
