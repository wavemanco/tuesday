The four company searches were refused, so I'm building the pack from your advert, your message and Hannah's message, and I'll mark the research targets as unavailable. Writing the pack now.
Your prep pack for Thursday's call is saved at `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-5/rooms/case-13-denied-33e2b46d/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. I built it for a recruiter screen with Hannah. Company research wasn't available, so it rests only on the advert, your message and hers.

I tried four searches (the company's values, its interview process, its strategy, and Hannah's public profile) and all four were refused. The company questions are therefore generic, and there's no values sheet or interviewer read. Your answers to her four topics (pay, notice, hybrid, reason for moving) are covered, quoting your own words.

Say the word and I'll play Hannah on B2. That's the question the pack marks as your highest-value prep. It's the advert's headline duty, coordinating production schedules across planning, the warehouse and QA, set against your delivery scheduling.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What's your actual notice period? Hannah will ask, your message doesn't give it, and the pack leaves that answer blank for you.
Can you paste your CV? The pack currently quotes only your message, and the CV would let it quote more.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Interviewer:** Hannah Lowther, Talent Partner. **Round:** recruiter screen, a 30-minute phone call on Thursday at 2pm. She will ring the mobile number on your application.
**Built for:** Sam. Session mode, one call.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words.
- Types: VAL is behaviour against the company's published values. EXP is whether your own claims hold up. JD is a stated requirement of the advert. CO is company and strategy knowledge. CASE is a live problem from the role.
- Every sentence about your past is one you wrote to me, quoted. Where the pack could not honestly say more, you will see an **answer slot**: an instruction for the interview with two branches, and the second always allows that the thing never happened or was not yours. A slot asks nothing of you here.
- A **logistics slot** is the same idea for pay, notice, location and reason for leaving: the only safe answer is your own.
- There are no VAL questions because no values-style round is documented and the company's values could not be fetched. The call is Hannah's four topics, so banks D and G are insurance for later rounds.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling across three depots, not production scheduling, and shows nothing of planning or QA. Words stay at the quote's scope: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you coordinated with likely. If any of your scheduling involved those functions, say which and what you did, in your own words; if it did not, or it was not yours, say so plainly and stay with the three depots |
| F2 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | presentation | The quote already reaches the line in other terms. Reword only the quote: "When orders slip, I chase the suppliers." Nothing is added: the quote does not say how an order is found to have slipped or what resolves it |
| F3 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | The quote touches deliveries without showing how you follow them. Answer slot: the advert's track-supplier-deliveries line makes a probe on how you know when an order is due likely. If you follow deliveries in some way beyond the chasing, say how, in your own words; if you do not, or it is not yours, say so plainly and stay with chasing when orders slip |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you rebuilt the spreadsheet and discrepancies fell by about a third over a year. Answer slots, the four a figure raises, each in your own words: how it was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. "I don't know how it was counted" is an honest branch |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material is silent. Answer slot: the advert's weekly dispatch line makes a probe on what you report, to whom and how often likely. If you report on deliveries or dispatch, say what, in your own words; if you do not, or it is not yours, say so plainly, then say what you would track first |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap. Lead with the quote in its own terms. A line in your message with nothing inspected behind it, so expect a probe on what the four years held |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Your message says spreadsheet, not Excel, and nothing of what it does beyond the rebuild. Answer slot: the advert's Excel line makes a probe on what you build in it likely. If the stock-count spreadsheet is in Excel, say so and say what it does, in your own words; if it is another tool, or you have not used Excel for it, say so plainly and stay with the spreadsheet you rebuilt |
| F8 | "ERP experience (SAP or similar) a plus" — advert, the SAP half | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never used SAP." Then how you would learn it, said as a plan and never as a past. The advert lists it as a plus |
| F9 | "ERP experience (SAP or similar) a plus" — advert, the "or similar" half | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | Your message says the in-house system is one "we run", not that you work in it. Answer slot: the advert's "or similar" makes a probe on that system likely. If you work in it yourself, say what you do in it, in your own words; if you do not, or it is not like an ERP system, say so plainly and stay with "we run our own in-house stock system" |
| F10 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | No gap: your figure sits inside the advertised band. It is a hope, so keep it one. If pressed on flexibility, answer from your actual position, which your message does not state |
| F11 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | No gap. Both halves are yours: two days is fine, and you would not want more than three. Say them together if the pattern comes up and drop neither |
| F12 | "your notice period" — Hannah Lowther's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period |
| F13 | "what's prompting a move" — Hannah Lowther's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | No gap. The Bristol office is closing next year, the only offer is relocating to Reading, and you don't want that. Your message says no more, so say no more |

## Persona table

The recruiter-screen prior is Conversational plus a light Skeptic. Hannah's own message fixed this one session: a 30-minute call on four named topics, then the team and next steps. What follows the call is unknown, so no loop archetype is assumed.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational (bank A) | Friendly walk through your background, then her four topics: pay, notice, hybrid, reason for the move | High. The recruiter prior says so, and she listed the four topics herself. The risk is treating a friendly call as unscored | Prepare the 90-second arc (A1) and answer each of the four logistics rows in your own words (A2 to A5) |
| Skeptic (bank B) | Quiet probing of the gaps: production scheduling, SAP, why this role | Medium. Light on a recruiter call, but F1 is the advert's headline duty with only adjacent evidence and F8 is a stated gap | Rehearse B2 until it is boring. Bridges only from your own sentences, limits said plainly |
| Data-Driven Prober (bank C) | Line-by-line on the stock-count figure, the spreadsheet and the reporting line | Low to medium on this call. Likelier with a hiring manager, and F4 is the figure to defend | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Case/Strategist (bank D) | A live problem from the role | Low on this call. The round after it is unknown | Clarify first, structure, then answer. Think aloud |
| Pressure (bank E) | Short, challenging versions of the gap questions | Low. Recruiters rarely stress-test, but the gap questions can arrive blunt | Hold through two follow-ups, then concede specifically |
| Peer (bank G) | Seam-splitting between teams | Low now. Hannah said she will tell you about the team, so a team conversation may come later | Reciprocity framing: say what you bring their team, not only what you need |

## Question banks

**Highest-ROI prep in this pack: B2.** The advert's headline duty is production schedules across planning, the warehouse and QA, and F1's evidence is delivery scheduling. Some form of this question is the one most likely to land on you.

### A. Conversational (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP, JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler."; "I schedule deliveries for our three depots and chase suppliers when orders slip."; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year."; "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Four beats, each one a sentence you wrote: the role and its four years; what you do now, scheduling deliveries for the three depots and chasing suppliers when orders slip; the stock-count rebuild with its figure worded as "about a third over a year"; then the move, in A2's words. About 90 seconds. Describe what you did and let her draw the link to this role | The opener is almost certain on a recruiter call. F6 is the experience requirement, F1, F2 and F4 are the work it will be matched against, and F13 is why you are on the call. EXP because it tests what you did |
| A2 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot, and it is your reason. Say it in your own words and no further: the Bristol office is closing next year, the only offer is relocating to Reading, and you don't want that. If she asks whether you have decided about Reading, answer from where you actually are, which your message does not state. Then say what draws you to this role, from the advert, in your own words; if nothing specific does, say so plainly | She listed it herself, and a reason that stays the same across the screen and later rounds is what she is checking. F13 is the evidence. EXP because it is your reason, not the role's requirement |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot. Give your own number, in your own words: you are hoping for £42,000, inside the advertised £38,000 to £44,000. No salary history, because none is in your message. If she asks whether that is firm, say how firm it actually is | Pay is the first logistics item she named. F10 is the evidence. JD because the advert states the band |
| A4 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period. If you do not have it to hand, say you will check and confirm it to her | She named it. Your material does not establish it (F12), so this row asks you for it and supplies nothing. JD because it is a term of the job's start |
| A5 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot. Say both halves together in your own words: two days is fine, you live in north Bristol, and you would not want more than three. If she asks about travel or which days, answer from what you actually plan, which your message does not state | She named the hybrid pattern. F11 is the evidence. JD because the advert sets the two days |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system."; "I schedule deliveries for our three depots and chase suppliers when orders slip." | Choose the one you honestly think is weakest. If it is SAP, the plain words are "I have never used SAP", then how you would learn it, said as a plan. If it is the planning, warehouse and QA coordination, stay with the quote: you schedule deliveries for the three depots, then say how you would pick up the rest. Do not name a weakness you do not believe | Skeptics ask it as a stem. F8 is a stated gap and F1 is the widest gap against a headline duty, so both candidates for your answer are on the table. JD because it scores the whole advert |
| B2 | "You schedule deliveries. This role coordinates production schedules between planning, the warehouse and QA. What part of that have you done?" | JD, EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal. The hold is only what the quote carries: "I schedule deliveries for our three depots." Answer slot: if any of your scheduling involved planning, the warehouse or QA, say which and what you did, in your own words; if none did, or it was not yours, say so plainly and describe the scheduling you do. Hold through two follow-ups by returning to the three depots, never by adding to them. When you concede, make it specific to what you have not done, then give the plan for learning it | F1 is where the advert presses hardest and the evidence is adjacent. The question presupposes only the quote and lets the premise be false. JD because it scores the headline duty, EXP because it tests what was yours |
| B3 | "I see you've never used SAP. How would you get up to speed?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say it plainly: "I have never used SAP." Then the plan, in your own words, for how you would learn it. The advert lists ERP as a plus. Answer slot: if you work in the in-house stock system yourself, say what you do in it; if you do not, or it is not like an ERP system, say so plainly and stay with "we run our own in-house stock system" | F8 is a stated gap and F9 is the open half of "or similar". The question's premise is your own sentence. JD because it scores a listed plus |
| B4 | "Why this role at Quillmoor?" | CO | [generic] | Selection scaffold. Pick the one or two lines of the advert that you actually want to do, and say why, in your own words. For the company, say only what you have read yourself on its own website and write down two things before the call. The advert describes a diagnostic-test manufacturer of about 400 staff and nothing more is established here. If no line of the advert draws you in particular, say so plainly and say what does | A "why us" question follows any reason for leaving, and the advert's lines are the only raising source. Research could not run, so the company knowledge is for you to add. CO because it tests homework |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that stock-count figure was counted." | EXP, JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slots, each in your own words: how the count was done; what the figure is sensitive to; the assumption behind it you would defend least; which part was yours. Keep the figure at "about a third over a year", not a percentage. If you do not know how it was counted, say so plainly | F4 is the figure a prober targets. The honest rehearsal is how it was counted and what was yours. EXP, JD because it scores the stock-accuracy duty |
| C2 | "You rebuilt the stock-count spreadsheet. What was it built in, and what did it do?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if it is an Excel spreadsheet, say so and say what it does, in your own words; if it is another tool, or you have not used Excel for it, say so plainly and stay with the spreadsheet you rebuilt | F7 is discovery: your message says spreadsheet, not Excel. JD because the advert asks for Excel |
| C3 | "What do you report on today, and how often?" | JD | [grounded] | Answer slot: if you report on deliveries or dispatch, say what and how often, in your own words; if you do not, or it is not yours, say so plainly, then say what you would track first. The question claims nothing, and your message gives nothing to quote | F5 is silent in your material and the advert's weekly dispatch line makes this likely. JD because it scores a listed duty |
| C4 | "Tell me about the last time a supplier order slipped and you chased it." | EXP, JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Two beats the sentence states: orders slip, and you chase suppliers. Answer slot: the advert's chase-late-orders line makes a probe on a real occasion likely. If one comes to mind, say what happened and what you did, in your own words; if none does, say so plainly and stay with the sentence | F2 is the evidence and F3 is the part it does not show. EXP because an occasion tests what was yours, JD because it scores the duty |

### D. Case/Strategist (insurance for a later round)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you on Monday that a delivery the warehouse is waiting for will be a week late. Planning has a run scheduled to use it. What do you do?" | CASE | [generic] | Structure it: what you would ask first (what is delayed, what depends on it, how firm the new date is); who needs to know and when (planning, the warehouse, QA); what options you would put to planning; what you would record and when you would check again. It asks about no past, so the guidance makes no claim | A live problem from the advert's schedule-coordination and late-order lines. `[generic]` because it is a pattern for the problem. CASE because it scores structure |
| D2 | "On-time dispatch fell this week. How would you find out why?" | CASE | [generic] | Clarify what counts as on time and what changed. Split the cause by where the order was held up. Say which you would check first and why, and what you would report. Think aloud and name one assumption | From the advert's weekly dispatch line. CASE because it scores structure |
| D3 | "The stock records show more than is on the shelf. What do you do?" | CASE | [generic] | Say what you would check first (the count, the recent movements), who you would tell, how you would correct the record and how you would stop it recurring. A hypothetical, so no claim about your own past | From the advert's stock-accuracy line. CASE because it scores reasoning |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has used SAP?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip."; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year."; "Never used SAP — we run our own in-house stock system." | Pause, restate the question, then hold on the two sentences about your work: the deliveries and suppliers, and the spreadsheet rebuild with its figure. Concede the gap plainly and specifically, "I have never used SAP", and give the plan. Do not claim an ERP system you have not used | F8 is the stated gap a blunt version of B3 would use. JD because it scores the plus |
| E2 | "That stock figure. How much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold at the sentence: you rebuilt the spreadsheet. Answer slot: if anything else changed in that year that moved the figure, say what; if nothing did, or you do not know, say so plainly. Never claim the whole fall as yours beyond what the sentence says | F4 again, pressed on attribution, the stem a pressure interviewer uses. EXP because it tests what was yours |

### G. Peer (insurance for a later round)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Planning wants a run brought forward and the warehouse says it cannot pick in time. How do you handle that between two teams?" | CASE | [generic] | Propose principles rather than pretending to know their seam: get both constraints stated, put the trade-off to both, agree a decision and who owns it, record it. Say what you bring the other team. It asks about no past | From the advert's planning-and-warehouse coordination line. CASE because it is a live problem |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed teams, with a named stake and a moment where credit was shared or contested; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer stem. No sentence of yours carries a story, so it is a scaffold. VAL because it scores partnership, though no published value was available |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "Coordinate production schedules between planning, the warehouse and QA" | B1, B2, D1, G1 |
| "chase late orders" and "track supplier deliveries" | C4, D1 |
| "keep stock records accurate" | C1, D3, E2 |
| "report weekly on on-time dispatch" | C3, D2 |
| "2+ years in operations or logistics coordination" | A1 |
| "confident with Excel" | C2 |
| "ERP experience (SAP or similar) a plus" | B3, E1 |
| "£38,000–£44,000" | A3 |
| "Hybrid: two days a week at our Avonmouth site in Bristol." | A5 |
| "your notice period" | A4 |
| "what's prompting a move" | A2, B4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I coordinate with day to day across planning, the warehouse and QA, and where do they sit?" | Turns the F1 gap into learning the job, and shows you are thinking about the seams the advert names |
| R2 | "How are the two days at Avonmouth usually set: fixed days, or agreed with the team?" | Covers the hybrid terms before an offer, and F11's limit only matters if the pattern grows |
| R3 | "What does the weekly on-time dispatch report look like today, and who reads it?" | Shows interest in the duty you have least evidence for (F5), and gets you the format before a later round asks |
| R4 | "What does the team use to track stock and orders, and how are new joiners trained on it?" | Gets the answer on SAP or similar (F8, F9) from her rather than guessing, and frames it as ramp-up |
| R5 | "What would a good first three months look like in this role?" | Shows you are thinking about delivery, and tells you what the hiring manager will weigh |
| R6 | "What are the next steps and who would I meet next?" | Tells you which of banks D and G to rehearse, and she said she would cover it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says delivery scheduling, not production scheduling. B2's slot stays inside the three depots |
| Has used SAP | Negative you stated, F8 | The plain acknowledgment F8 gives: "I have never used SAP." No slot |
| Has used an ERP system | Inflated form of F9 | F9's quote at its own scope: "we run our own in-house stock system." B3's slot asks only what you do in it |
| Cut stock discrepancies by 33% | Inflated form of F4 | F4's quote at its own scope: "about a third over a year." C1's slots ask only how it was counted |
| Was made redundant | Inflated form of F13 | F13's quote at its own scope: the Bristol office is closing next year and the only offer is relocating to Reading, which you don't want |
| Turned down the Reading offer | Inflated form of F13 | The quote says you don't want it, which is not the same as having declined it. A2's slot answers from where you actually are |

## Sources

Provided: Hannah Lowther's LinkedIn message, the Operations Coordinator advert, and Sam's message. No dossier was present.

Searches sent, all refused:

- `Quillmoor Diagnostics values` — refused
- `Quillmoor Diagnostics interview process operations coordinator` — refused
- `Quillmoor Diagnostics strategy news` — refused
- `Hannah Lowther Quillmoor Diagnostics` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Would have fed a values cheat sheet and VAL questions. None is in the pack, and B4 is `[generic]` |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Would have named later rounds. Persona weights rest on Hannah's own message for this call and make no claim about later rounds |
| 3. `Quillmoor Diagnostics strategy news` | unavailable | Would have grounded a CO or CASE question in current strategy. D1 to D3 and G1 are `[generic]` |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Would have fed an interviewer read and a reverse question tied to her path. Both are absent |
| 5. representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV pasted in → evidence cells quote it instead of only your message, and F2, F4, F6 and F7 can move up a band where it says more
- Your answers to the slots in F1, F3, F5, F7 and F9, outside any drill → each row gets your own sentence and the matching bank rows become story-mapped
- Your notice period → F12 and A4 are filled in your own words
- Search permission for this session → targets 1 to 4 run and the CO bank, a values sheet and the interviewer read move from `[generic]` or absent to `[grounded]`; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available on your yes
- Hannah's description of the next steps → which of banks D and G to weight, and per-round mini-packs
- Hannah's LinkedIn profile → an interviewer read and a reverse question tied to her path
- A `tuesday-dossier.md` from an earlier pass → verified evidence and absolute prohibited claims, which would sharpen the guidance cells
