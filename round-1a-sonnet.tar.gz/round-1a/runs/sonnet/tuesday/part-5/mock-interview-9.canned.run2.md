I'm reading the last reference files (evidence vocabulary, reframing audit, research rules), then I'll run a short L1 research pass and build your pack.
Status: I finished the research (6 searches and 2 fetches) and I'm now writing the pack file. I'll send it to you once it's saved.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-5/rooms/case-9-canned-18a44396/Orrinsford_fourth-grade-teacher_interview_pack.md`. It has 24 questions for a panel of Principal Vantongeren (read as a hiring manager) and two fourth-grade teammates (read as peers). I had no job description, so the role requirements come from a representative fourth-grade posting I couldn't tie to Halvering, plus the district's published beliefs. Rows resting on that posting are labelled `[inferred]`.

Your Social Security number isn't needed for any of this, so I haven't used it. I also left your licence number out of the pack. I'd avoid pasting either into job-prep chats going forward.

- **Biggest rehearsal target:** A1, "What will be hardest about moving to fourth grade?" You've said you've never taught fourth grade, so hold your six years of third grade and say plainly that you haven't taught fourth.
- **Next biggest:** A2 and H2. You wrote that you "led" the reading-curriculum move and also that you've never been a team lead. A probing panel will put those side by side.
- **Useful find:** The board adopted a literacy plan in August 2026 with a new grades 3–5 reading curriculum from fall 2027. Question C4 and two of the reverse questions use it. The district's own pages I could read give no sign of a role requirement beyond the licence, and yours is active through 2029.

Say the word and I'll play the skeptical principal on A1, with follow-ups and feedback against the pack's own guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the full job description from Halvering or the district? Pasting it would turn the `[inferred]` rows into `[grounded]` ones, but I can proceed without it.
Would you like a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) on the district's strategy and the panel?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Orrinsford_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

**Round:** one 45-minute panel, Thursday. **Panel:** Principal Dolores Vantongeren (hiring-manager relationship) and two members of the fourth-grade team (peer relationship, names not given).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only say what you actually did.

Question IDs skip the letter F so they never collide with the fit-snapshot rows (F1 to F10).

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs, not generic virtue |
| EXP | Whether what you wrote survives scrutiny; what was actually you |
| JD | The listed responsibilities and qualifications, including their gaps |
| CO | Whether you know the district's current direction |
| CASE | A live problem from the actual role, answered out loud |

## Prep triage

You have until Thursday. Do these in order; everything else is insurance.

1. Tonight: say A1 aloud twice, then H1 against a 60-second clock. This is the highest-ROI prep in the pack.
2. Tonight: A2 and H2 together. "Led" and "never been a team lead" will sit side by side in the panel's minds.
3. Wednesday: say your own answer to each answer slot (F2, F5, F8, F9, F10), aloud, in your own words.
4. Wednesday: C4, D2 and G1.
5. Thursday morning: choose three reverse questions and read the prohibited-claims section once.

Everything else is insurance.

## Fit snapshot

Requirements come from three places. The invite is your own HR's words (`[grounded]`). The Orrinsford Mission and Beliefs page was fetched (`[grounded]`). No job description was supplied, so rows from the K12 Jobs Board listing are a representative fourth-grade posting that I could not attribute to Halvering, framed as typical for the role (`[inferred]`).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met: licence, endorsement, status and expiry are all in the quote. Nothing inspected sits behind it, so expect it to be confirmed. Checking the public licence record is yours to do; your licence number is deliberately left out of this pack |
| F2 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board listing, representative | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | Your material says third grade and years, and does not show which subjects those years covered. Answer slot: a typical fourth-grade posting lists these five areas, so expect a probe on which you taught. If you taught all of them, say so; if some were taught by others, say which; if you did not teach some at all, say so plainly and stay with the six years of third grade |
| F3 | "experience in grades 3 to 5 preferred" — K12 Jobs Board listing, representative | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | none | No gap on this line: third grade sits inside the range it names. Lead with the quote's own terms: six years, third grade, a public elementary school. The limit on fourth grade is F4's, not this row's |
| F4 | "the Fourth Grade Teacher position at Halvering Elementary School" — the invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would get ready, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | "differentiate instruction using assessment data" — K12 Jobs Board listing, representative | none given | none | [inferred] | discovery | Your material is silent here, which is not the same as an absence. Answer slot: expect a probe on how assessment results shaped your teaching. If they did, say what the data was, what changed and whose call it was, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the six years of third grade |
| F6 | "keep clear classroom routines" — K12 Jobs Board listing, representative | none given | none | [inferred] | discovery | Silent in your material. Answer slot: expect a probe on the routines you run. If you set them, name one and what it is for, in your own words; if they were set by someone else, or there were none worth naming, say so plainly and stay with the six years of third grade |
| F7 | "communicate regularly with families" — K12 Jobs Board listing, representative | "I write a weekly email to families." — your CV | medium | [inferred] | none | Lead with the quote's own terms: you write it, weekly, to families. It is a CV line with nothing inspected behind it, so expect a probe on what the emails contain; that is yours to describe |
| F8 | "each teacher speaks with every family each term" — Orrinsford Mission and Beliefs | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | Your material says a weekly email, and the words stay there: "I write a weekly email to families." Answer slot: the belief's wording makes a probe on direct contact with families likely. If you were in direct contact, say when and how, in your own words; if email was the channel, say so plainly and stay with it |
| F9 | "work with the grade-level team" — K12 Jobs Board listing, representative | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | none | The first quote reaches the requirement; the second limits what it can be taken to mean, and a probing panel will set the two side by side. Hold the first at its own scope. Answer slot: what "led" meant in that move is yours to say, which parts were yours and which were shared; if the word was narrower than the panel will assume, say so plainly |
| F10 | "no student leaves third grade without a reading plan" — Orrinsford Mission and Beliefs | "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" — your CV | low | [grounded] | discovery | Your material says a curriculum move and a club, and does not show reading plans for individual students. Answer slot: expect a probe on how individual readers were tracked. If you kept or wrote plans for individual readers, say how and whose they were, in your own words; if that was not part of your work, say so plainly and stay with the move and the club |

## Reading the interviewer

Public professional footprint only; nothing about the two teammates, whose names were not given.

| Fact | Source | What it may mean for Thursday | Provenance |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | ilprincipalsforum.example speaker page, search excerpt | Reading questions may go deeper than a generalist's (A5, C1, E1) | [grounded] |
| Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5 | same page | Small-group reading and the grades 3 to 5 range may come up in her questions | [grounded] |
| Reading depth and small groups as likely themes | derived from the two rows above | Prepare to describe your reading instruction in plain, specific words rather than program names | [inferred] |

Mirror opportunity: shared vocabulary is reading, and the pairing is F10's own sentence, "I've run the after-school reading club for the last two years". No shared career jump is established, so none is offered.

## Persona table

The panel blends the top two personas of each member's relationship: the principal reads as a hiring manager (Skeptic, Case/Strategist), the two teammates as peers (Peer Evaluator, Prober). The loop source is your invite, which gives one panel of the principal and two fourth-grade team members; the district's careers page excerpt agrees (one 45-minute building panel, topics reading instruction, classroom routines, families). I read that page as a search excerpt only, not in full. No values-style round is named in either, so none is assumed.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet, persistent probing of the fourth-grade and team-lead gaps | High: F4 and F9 are the two limits you have stated, and a hiring-manager principal is buying capability and derisking gaps | Rehearse A1 until it is boring: hold "Six years teaching third grade at a public elementary school in Joliet", concede "I've never taught fourth grade", then a plan |
| Peer Evaluator (B) | Colleagues pricing what you add to their work; disagreement and credit | High: two of three panelists are teammates | Reciprocity: say what you would bring them, from your quotes at their own scope, and what you would need from them |
| Case/Strategist (C) | Live problems from a fourth-grade classroom and the district's literacy plan | Medium-high: hiring-manager prior, and the board adopted a literacy plan in August 2026 | Clarify first, then structure; think aloud; challenge one premise politely |
| Values/Behavioral (D) | Questions framed by the three published beliefs | Medium: the beliefs page says they guide every hire, but no round is documented as a values round | Map a story to a belief only where one of your quoted sentences carries it; otherwise pick an instance, and say plainly if none comes to mind |
| Data-Driven Prober (E) | Asks what exactly you did and with what data | Medium: peers and a reading specialist can press on detail | Know what you can and cannot say about each line; say plainly when you do not know |
| Conversational (G) | Friendly opener, "walk us through your path" | Medium: any panel opens this way, and casual questions are scored | A 90-second arc built only from your quoted sentences |
| Pressure (H) | Time-boxed challenge | Low: unusual in an elementary building panel, included so no style is first met live | Pause, restate, hold through two follow-ups, then concede specifically |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 licence with elementary endorsement | — none, and why: a gate your material shows met, with nothing to rehearse beyond confirming it |
| F2 plan and teach five subject areas | E3, G1 |
| F3 experience in grades 3 to 5 | A1, G1, H1 |
| F4 the fourth-grade position | A1, A3, A4, H1 |
| F5 differentiate using assessment data | A5, C1, D3, E1 |
| F6 clear classroom routines | E2 |
| F7 communicate regularly with families | C2, D2, G3 |
| F8 families as partners (belief) | C2, D2, G3 |
| F9 work with the grade-level team | A2, B1, B2, B3, B4, C3, H2 |
| F10 every child a reader (belief) | C1, C4, D1 |

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade. What will be hardest about moving to fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Hold what the first quote carries: six years, third grade, a public elementary school. Concede what the second states: "I haven't taught fourth grade." Then say what you would do to get ready, as a plan. Answer slot: the hardest part is yours to name; say which part you expect to be hardest and what you would do about it, and if nothing comes to mind, say so plainly and say what you would ask the team first. Hold through two follow-ups by returning to the quotes, never by adding to them | F4 is your biggest stated limit and the title of the role, so this objection arrives in some form; JD because it scores the posted grade |
| A2 | "You led your grade level's move to a new reading curriculum, and you haven't been a team lead. Help me understand how both are true." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Say both plainly, side by side, in the quotes' own words. Answer slot: what "led" meant is yours to say; name which parts of the move were yours and which were shared, in your own words, and if the word was narrower than the question assumes, say so plainly. Then stay with the move at its own scope; do not widen it to the school or the district | F9 puts two of your sentences in tension, and a Skeptic will find it; EXP because it tests what was actually yours |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Name one real weakness, small enough to be true and specific enough to be believed. The one your material states is "I've never taught fourth grade"; if you name a different one, it has to be one you would say to a friend. Then the plan. If no weakness comes to mind, say so plainly and say what you would want to learn first | A standard Skeptic stem, aimed at F4; JD because it scores the role's demands against you |
| A4 | "Why Orrinsford, why fourth grade, and why now?" | CO | [grounded] "I've run the after-school reading club for the last two years" | Your reasons are yours; this pack supplies none. Anchor the "why here" in a belief you can speak to from your own work, by name: Every Child a Reader, Families Are Partners, or Teach for Tomorrow, Not for the Test. If you choose reading, the quote carries only this: "I've run the after-school reading club for the last two years." Let the panel draw the link. If no belief fits, say so plainly and say what draws you to the school instead | Motivation consistency is what a Skeptic scores; F4 and F10 are the rows it touches; CO because it needs the published beliefs |
| A5 | "Tell me about a time assessment results changed how you taught." | JD | [inferred] | Pick one instance with a named assessment, a named change and what you saw afterward, told in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5 is silent in your material and the posting line is typical for the role; an open prompt supplies no event, and the guidance is a scaffold because no quote carries one |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you disagreed with a colleague about how to teach something." | VAL | [generic] | Pick one instance with a named disagreement, how you raised it, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Say "we" for the context and "I" for your own part | The peer stem on disagreement with equals; F9 is the row it probes; `[generic]` because it is a pattern, not a fact about this team |
| B2 | "Walk us through the move to the new reading curriculum on your grade level." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on F9: the move, the grade level, the new reading curriculum and 2024 are the beats the quote states; tell them in your own words. Answer slot: a typical posting lists working with the grade-level team, so expect a probe on how your colleagues took part. If they disagreed or you adjusted, say what happened and which part was yours; if there was no such step, or it was not yours, say so plainly and stay with the move | F9 is your strongest team-facing evidence and the likeliest place a peer digs; EXP because it tests what was actually yours |
| B3 | "We'll share students, plans and hallways. What would you need from us in your first month, and what would you bring us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | A reciprocity answer. Say what you would need, plainly, in your own words. For what you bring, name the two things as the quotes state them: the grade-level move, and the after-school reading club. Leave the team to decide what that means for them | Peers weight what the hire adds to their load; F9 and F10 are where your quotes sit; JD because it scores the team-fit requirement |
| B4 | "How do you handle credit when work spans the whole grade level?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Use "we" for the grade level's move and "I" only for what you personally did. The quote says "led", so what that covered is yours to state; where credit was shared, say so, and where it was yours, say that. Do not describe your role as larger than the quote | F9 again, as a collegial version of the A2 probe; VAL because it tests behavior with equals |

### C. Case/Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It's October. Your fourth graders arrive reading at very different levels. Sketch your first six weeks. What do you need to know first?" | CASE | [inferred] | Clarify before structuring: what assessment information exists and what comes with the class. Then your objective, how you would group readers, your approach, how you would know it was working, and what could go wrong. Think aloud and challenge one premise politely. The question asks about no past, so the guidance makes no claim about yours | Live problem from the posting's differentiate and reading lines (F5) and the belief in F10; `[inferred]` because the line comes from a representative listing |
| C2 | "A family writes that their child is falling behind in reading and wants to talk. What do you do?" | CASE | [grounded] | Structure it: what you would ask the family and the child's records first, when you would speak, what you would offer, and how you would follow up. The question asks about no past, so the guidance makes none | Built from the Families Are Partners belief (F8); no claim about your past is needed |
| C3 | "Partway through the year, half your team resists a new reading routine. What do you do?" | CASE | [generic] | Clarify what is being resisted and why before proposing anything, then structure: listen, find the real objection, test a small version, check the result. The question asks about no past | A live version of the F9 teamwork requirement; `[generic]` because it is a pattern |
| C4 | "The board's literacy plan brings a new grades 3 to 5 reading curriculum from fall 2027. What would you want to know about it, and how would you want to help the team prepare?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Clarify first: what is decided, what the team already knows, and what the timeline is. If you mention your own curriculum move, say it at the quote's scope: your grade level's move to a new reading curriculum in 2024. Let the panel draw the link. Answer slot: if a step in that move is relevant, say what it was and whether it was yours; if there was no such step, say so plainly and ask your questions instead | Current strategy (board literacy plan, August 2026, search excerpt only); touches F10 and F9 |

### D. Values/Behavioral (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader. Tell me about a student who was behind in reading and what you did." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Pick one student with a named starting point, a named step and what changed, told without identifying details. The quote carries only that you run the club, so a student story is not in it; if the club is where your example comes from, say that. If no such student comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F10 is where the belief meets your material; the open prompt supplies no event |
| D2 | "Families Are Partners. How do you build a relationship with a family?" | VAL | [grounded] "I write a weekly email to families." | Story-mapped on F8: the weekly email to families, in the quote's terms. Answer slot: the belief's wording makes a probe on direct contact likely. If you were in direct contact, say when and how, in your own words; if email was the channel, say so plainly and stay with it | F8 is a transferability gap and this is where the probe lands |
| D3 | "Teach for Tomorrow, Not for the Test. When have you used an assessment to inform your teaching rather than replace it?" | VAL | [grounded] | Pick one instance with a named assessment and a named change. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. No claim about your past is supplied here | The belief text is the raising source; F5 is silent in your material, so this is a scaffold |

### E. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "What does differentiating with assessment data look like in your room? What data, and what changed?" | JD | [inferred] | Answer slot: this is a typical posting line, so expect it. If you used data to adjust groups or lessons, say what the data was, what changed and whose call it was, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the six years of third grade. Say plainly when you do not know how something was measured | F5 is silent in your material; the question is premised on a practice only a typical listing raises, so the slot allows that it never existed |
| E2 | "Describe the routines you would set in the first weeks." | JD | [inferred] | Name one routine and what it is for, in your own words, as how you would teach. If you have run it before, say so; if no routine comes to mind that you would call your own, say so plainly and say how you would decide | F6 is silent in your material; asked as an open prompt so it supplies no event |
| E3 | "Which subjects did you teach, and which did others teach?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: the quote says third grade and six years, and does not say which subjects. Say which you taught and which were taught by others, in your own words; if you did not teach some at all, say so plainly | F2 is a discovery row, and this is the plain way a peer would check it |

### G. Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk us through the path that brought you here." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families." | A 90-second arc made only of those four sentences, in your own words and in that order: the six years, the move, the club, the weekly email. End on why fourth grade, which is your reason, not this pack's | F3, F9 and F10 give the spine; EXP because it is the CV in spoken form |
| G2 | "What are you reading with students right now that you love?" | VAL | [generic] | Name one real title or practice that you actually use, and say why, plainly. Nothing in this pack supplies one | Casual register but scored; the Every Child a Reader belief makes reading the likeliest warm-up topic |
| G3 | "What would the families of your students say about you?" | VAL | [grounded] "I write a weekly email to families." | Say what you do, in the quote's terms: you write to families weekly. What families say is theirs; speak for them only if you have actually heard it, and if you have, say what and when | F7 and F8; the quote carries what you send, not what families say |

### H. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over someone who has already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I've never taught fourth grade" | Pause, restate the question, then hold: the three quoted sentences at their own scope. Concede specifically: "I haven't taught fourth grade." Say what you would do about it as a plan. Do not claim to be a better candidate than the one asked about | F4 under time pressure; JD because it scores the posted grade |
| H2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Hold the quote at its own scope. Answer slot: say which parts were yours and which were shared, in your own words; if you do not know how to divide it, say so plainly. Concede the second quote without defensiveness, and never describe your part as a team lead's | The attribution probe on F9; EXP because it tests what was yours |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You were a reading specialist for nine years before becoming principal. How does that shape how you want fourth-grade reading to run here?" | Ties to the principal's own public path and invites her to talk about the subject she knows best |
| 2 | "Your 2025 talk covered weekly reading conferences in grades 3 to 5. What does that look like in a fourth-grade classroom here day to day?" | Shows you read her published work, and the grades 3 to 5 range is one your own experience sits inside |
| 3 | "The board's literacy plan brings a new grades 3 to 5 reading curriculum from fall 2027. What has the fourth-grade team decided, and what is still open?" | Shows current awareness of the district's direction, and a good question on its own |
| 4 | "What could a new fourth-grade teammate do in their first month that would genuinely help your team?" | The reciprocity question for the two peers: it asks about their load, not your needs |
| 5 | "What does a strong first term look like for a new fourth-grade teacher here?" | Turns the panel from judges to describers and tells you the real bar |
| 6 | "The literacy plan includes a family reading night each term. Who plans it, and where would a new teacher fit?" | Links to the Families Are Partners belief without claiming past experience |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F4 | "I haven't taught fourth grade." Then a plan. No slot |
| Has been a team lead | Negative you stated, F9 | "I haven't been a team lead." And the quote at its scope: "I led our grade level's move to a new reading curriculum in 2024". No slot |
| Led the school's or the district's reading curriculum or reading program | Inflated form of F9 and F10 | The two quotes at their own scope: a grade level's move, and an after-school club. The limit is the pack's observation: your material says a grade-level move and a club, not a school-wide program |
| Speaks with every family each term | Inflated form of F8 | The quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: your material says an email, not conversations. D2's slot stays inside the email |

## Sources

Provided: the invite, and your resume and message. No `tuesday-dossier.md` was present.

Searches and fetches sent:

- Search: "Orrinsford Community School District values mission" returned https://orrinsfordschools.example/about/mission-and-beliefs, which I fetched
- Search: "Halvering Elementary School Orrinsford fourth grade teacher" returned no results
- Search: "Orrinsford Community School District teacher interview process panel" returned https://orrinsfordschools.example/careers/how-we-hire-teachers (excerpt only, not fetched)
- Search: "Dolores Vantongeren Halvering Elementary principal" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren (excerpt only)
- Search: "Fourth Grade Teacher job posting Orrinsford Community School District Halvering Elementary" returned https://k12jobsboard.example/listings/fourth-grade-teacher, which I fetched; it is a generic board listing I could not attribute to Halvering, so it is representative only
- Search: "Orrinsford Community School District strategic plan news 2026" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan (excerpt only)

Research tier: L1 — searches 6 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford values` | yes | The three beliefs by name: bank D, A4, F8 and F10 |
| 2. `Orrinsford interview process teacher` | yes | One 45-minute panel, principal plus two grade-level teachers; persona weights follow it. Excerpt only, so a full read of the page is in the upgrade menu |
| 3. `Orrinsford strategy` / recent news | yes | The August 2026 board literacy plan: C4 and reverse questions 3 and 6 |
| 4. `Dolores Vantongeren Halvering Elementary` | yes | The interviewer read and reverse questions 1 and 2. The two teammates were not named, so nothing was searched for them |
| 5. representative `Fourth Grade Teacher` JD | yes | No job description was supplied. The first search returned no results; the second returned a generic listing I could not attribute to Halvering, so F2, F3, F5, F6, F7 and F9 are `[inferred]` rows |

## Upgrade menu

- The full job description from Halvering or the district → the six `[inferred]` rows (F2, F3, F5, F6, F7, F9) become `[grounded]` and the JD-tagged questions get a real raising source
- The two fourth-grade teammates' names and roles → an interviewer read for each, per-member persona weights and a peer reverse question tailored to them
- Your own answers to the slots in F2, F5, F6, F8, F9 and F10 → those rows move from `discovery` or `transferability` to quoted evidence, and the guidance in A2, B2, D2, E1 and E3 becomes story-mapped
- The full text of the district's "How we hire teachers" page, pasted → the loop detail rests on the page itself, not a search excerpt
- A look at your licence's public record, checked by you → F1 moves from `medium` to `high`
- A `tuesday-dossier.md` from an earlier session → the most likely objection and the prohibited claims arrive checked rather than inferred
- Any note from HR on focus areas or a requested deliverable → coverage of exactly what the panel was told to cover
