Building your prep pack for the Thursday call with Hannah now. The web searches I tried were refused, so it rests only on what you pasted.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-5/rooms/case-13-denied-cc3f8c80/quillmoor_operations-coordinator_interview_pack.md`. I built it for a recruiter screen with Hannah on the four topics she listed, using only your advert and your note about yourself. My two web searches (Quillmoor news and Hannah's profile) were refused, so the company question (A6) rests on the advert alone and there is no read on Hannah herself.

Say the word and I'll play the Skeptic on A5 (why you're moving), the pack's highest-ROI question, and run it as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste your CV, or just the lines about the stock-count work and deliveries? I've built everything without it, so skip this if you'd rather.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, Thursday 2pm, 30-minute phone call
**Interviewer:** Hannah Lowther, Talent Partner (recruiter). Her own agenda, from her message: salary expectations, notice period, how the hybrid pattern would work, and what is prompting a move; then the team and next steps.

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behaviour shows a company's published values |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | The advert's stated duties, requirements and terms, gaps included |
| CO | What you know about the company |
| CASE | A live problem set in the role |

Questions A2 to A5 are the four topics Hannah listed. A5 is this pack's highest-ROI prep. An answer slot is an instruction for the interview: it asks nothing of you here.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling for three depots, not production schedules, with nothing inspected behind it, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who your scheduling depends on likely. If the timing you set for the depots depended on another team, say who and how you settled it, in your own words; if it did not, or it was not yours to set, say so plainly and stay with the depots |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap in wording: lead with "chase suppliers when orders slip" as you said it. The sentence says chasing, not tracking, so expect a probe on how you know an order is late. Answer slot: if you keep a record of supplier deliveries, say what it holds; if you do not, say so plainly and stay with the chasing |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap in wording: "I rebuilt our stock-count spreadsheet" and "discrepancies fell by about a third over a year", at that scope. The sentence says a rebuilt spreadsheet and fewer discrepancies, not that you keep the records day to day, and the figure draws a probe (C1) |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show any dispatch reporting. Answer slot: the advert's weekly on-time dispatch line makes a probe on what you report today likely. If you report on deliveries or dispatch, say what and how often, in your own words; if you do not, say so plainly and say what you would want to measure first |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap: four years against a requirement of two or more. It is your own sentence with no CV behind it, so expect a request to confirm title and dates |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Your sentence says a spreadsheet, not Excel, so the bridge stays at "stock-count spreadsheet". Answer slot: the advert's Excel line makes a probe on what you do in it likely. If that spreadsheet was in Excel, say what you built in it, in your own words; if it was another tool, or you use Excel lightly, say so plainly and stay with the spreadsheet you rebuilt |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | medium | [grounded] | transferability | Plain acknowledgment, sourced to your message: "I've never used SAP." Then at its own scope: "we run our own in-house stock system." The advert calls ERP a plus, and your sentence does not say whether the in-house system works like an ERP. Answer slot: if you work in that system, say what you do in it, in your own words; if you do not, or it is not like an ERP, say so plainly and say how you would learn SAP, as a plan and not as a past |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Your stated constraint sits around the advert's two days: two is fine, three is your limit. Keep both halves in any wording; the second half is the part you said you would not trade |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure sits inside the advert's band. It is stated as a figure you are hoping for, and the pack adds no floor, flexibility or salary history to it |

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Conversational / Rapport Builder | Friendly logistics: pay, notice, hybrid, reason for leaving, a biography opener | High. The recruiter-screen prior is Conversational plus a light Skeptic, and Hannah's own message lists exactly these topics. No interviewer profile exists to adjust it, and no values-style round is detected: her words describe a single phone call | Treat each casual question as scored; fill each logistics slot with your own words and stop | A |
| Skeptic | The gaps and the motive, asked politely: SAP, production scheduling, why this role | Medium. The prior is a light Skeptic; F1 and F7 are the gaps it would pick, and "what's prompting a move" is on her list | Rehearse the likeliest objection until it is boring; bridge only from your stated sentences, and say the limit plainly | B |
| Data-Driven Prober | One or two probes on the figure and on what you track and report | Low to medium. A recruiter screen rarely goes deep, but F3 holds the pack's only figure and F4 is an open row | Know what you can and cannot say about how the figure was counted; say plainly when you do not know | C |
| Pressure / Stress Interviewer | A time-boxed "why you" or a push on the hybrid ceiling | Low. Reasoned from the prior's "light" Skeptic edge, not from anything Hannah said | Pause, restate, hold your stated position through two follow-ups | D |
| Case / Strategist | A short judgement scenario about a late supplier or a scheduling clash | Low. Recruiters seldom run cases; included so that a first scenario is not your first, since the advert describes coordination between teams. `[generic]` | Clarify first, then structure, then answer | E |

## Question banks

### Bank A: Conversational (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Can you walk me through your background?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Story-mapped on the beats those sentences state, in your own words and about 90 seconds: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies down by about a third over a year. Stop at the present and close with one clause taken from A5's sentence. Add no title, team size or tool the sentences do not give | The usual opener, scored for economy; F5, F2 and F3 are the rows it draws on. EXP because it tests what your own sentences carry |
| A2 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot, filled from your own sentence: say the figure you are hoping for, in your own words, at that scope. The pack adds no floor, no flexibility and no salary history. Say it once, then stop | Hannah's list names it; F9 is the row. JD because pay is a term of the listed job |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, in your own words. Your material does not state it, so the pack supplies no figure; if you do not know it exactly, say so plainly and that you will confirm it | Hannah's list names it. JD because notice is a term of starting the listed job |
| A4 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot, filled from your sentence at its scope: two days at Avonmouth is fine, and three is the most you would want. Say both halves. Offer no more flexibility than the sentence gives, and no commute detail you have not given | Hannah's list names it; F8 is the row. JD because it scores a term of the listed job |
| A5 | "What's prompting you to look at a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | The highest-ROI rehearsal in this pack. Say it as you gave it: the Bristol office closes next year, the only offer is relocating to Reading, and you don't want that. Keep "honestly" if it is how you would say it. Do not call it redundancy or a layoff; the sentence says an office closing and one offer. Follow-ups to rehearse: why this role (B3), whether you would be looking otherwise (D2), and why not Reading. On Reading the sentence says only "which I don't want". Answer slot: if you want to give a reason for not taking Reading, give it in your own words; if you would rather not, say plainly that it does not suit you and return to what you want from this role. Hold through two follow-ups by returning to the sentence, never by adding to it | Hannah's own list includes it, so it will be asked in some form, and motive consistency is what a recruiter scores. EXP because it tests what actually happened; highest-ROI because the follow-ups (B3, D2) all lead back here |
| A6 | "What do you know about Quillmoor, and what interested you in this role?" | CO | [grounded] | Selection scaffold: say what the advert tells you, a diagnostic-test manufacturer with about 400 staff and duties across planning, the warehouse and QA, and add only what you have read yourself. If you have read little beyond the advert, say so plainly and ask a question instead of bluffing | A casual company question is still scored. The pack could not research Quillmoor, so it carries no strategy or news; this row is advert-only |

### Bank B: Skeptic (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "SAP is listed as a plus. Where are you with ERP systems?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Hold only what the sentence carries: "I've never used SAP", then "we run our own in-house stock system." Answer slot: the advert's "SAP or similar" makes a probe on the in-house system likely. If you work in it, say what you do in it, in your own words; if you do not, or it is not like an ERP, say so plainly. Then say how you would learn SAP, as a plan and not as a past | F7 is the gap a Skeptic would pick first. JD because the advert marks it a plus; it is not a requirement |
| B2 | "This role sits between planning, the warehouse and QA. How close is that to what you do now?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Say what the sentence says: you schedule deliveries for three depots and chase suppliers when orders slip. Answer slot: if the timing you set for the depots depended on another team, say who and how you settled it, in your own words; if it did not, or it was not yours to set, say so plainly and stay with the depots. Do not describe the depots' scheduling as production scheduling | F1 is the adjacent-work row and the likeliest place to be probed on a coordination role. JD because it scores the first listed duty |
| B3 | "You've worked in building supplies for four years. Why a diagnostics manufacturer?" | JD | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Selection scaffold. Your stated reason for looking is the office closing, so do not invent a pull towards diagnostics. Answer slot: say in your own words what you actually want from this role, drawn from the advert's duties; if the honest answer is mostly that the move was forced, say so plainly and return to what the role involves | The motive follow-up that A5 sets up. JD because it scores fit with this role and sector; it carries the motive question under another face |
| B4 | "How confident are you in Excel, and what do you use it for?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if the stock-count spreadsheet was in Excel, say what you built in it, in your own words; if it was another tool, or you use Excel lightly, say so plainly and stay with the spreadsheet you rebuilt. Name no function, formula or feature you did not use | F6 is `low` because the sentence says spreadsheet and not Excel; the advert's requirement is explicit, so it will be checked |

### Bank C: Data-Driven Prober (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Story-mapped on the sentence's own beats: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Defend-the-number slots, each in your own words: how the fall was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Keep "about a third" as is; do not turn it into a precise figure | F3 holds the only figure in the pack, and quantified claims draw probes. EXP because it tests attribution |
| C2 | "How do you keep track of supplier deliveries and late orders today?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: the advert's "track supplier deliveries" makes a probe on what you keep likely. If you keep a record or tracker, say what it holds and who uses it, in your own words; if you do not, or someone else keeps it, say so plainly and return to "chase suppliers when orders slip" as you said it | F2's sentence says chasing, not tracking. JD because it scores the second listed duty |
| C3 | "This role reports weekly on on-time dispatch. What reporting do you do today, if any?" | JD | [grounded] | Answer slot: if you report on deliveries or dispatch, say what and how often, in your own words; if you do not, say so plainly and say what you would want to measure first. The pack supplies no report, metric or cadence | F4 has no evidence behind it, and the advert states the duty. JD because it scores the fourth listed duty |

### Bank D: Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we shortlist you over someone who has used SAP?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" "I schedule deliveries for our three depots and chase suppliers when orders slip." "Never used SAP — we run our own in-house stock system." | Pause and restate the question, then hold what you stated: four years as a logistics coordinator at a building-supplies wholesaler, scheduling deliveries for three depots and chasing suppliers when orders slip. Concede plainly that you have never used SAP, and say how you would learn it, as a plan. Hold through two follow-ups by returning to those sentences; add no claim about how fast you learn systems | F5 and F7 are the pair this challenge sets against each other. JD because it presses the advert's ERP line |
| D2 | "If the Bristol office weren't closing, would you be looking?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Answer from what is true, in your own words; the pack does not choose the direction for you. Your sentence already says the closure is why you are looking, so return to it rather than claiming a plan to leave or a wish to stay. Hold through two follow-ups, and concede only what is accurate | A motive probe delivered as a hypothetical. EXP because it tests what actually prompted the move |
| D3 | "Sixty seconds: what would it take for you to do four days at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Hold your stated limit: two days is fine and you wouldn't want more than three. Restate it calmly through two follow-ups. The sentence carries no concession beyond that, so none is coached. Answer slot: decide before the call whether any condition would change your limit, and say it in your own words; if none would, say plainly that three is the most you would want | F8's second half is a limit you stated; a pressure interviewer tests exactly that half. JD because it scores a term of the listed job |

### Bank E: Case (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you tomorrow's delivery of a key material will arrive two days late, and planning, the warehouse and QA all have schedules that depend on it. What do you do first?" | CASE | [generic] | Clarify before structuring: which orders and runs depend on it, what is already in stock, and whether the supplier can part-ship. Then objective, options, who must be told and in what order, and what you record. Make one premise explicit and check it. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's first two duties (F1, F2's requirements). `[generic]` because it is a pattern for the problem, not a fact about Quillmoor |
| E2 | "Planning wants an order moved up and the warehouse says it can't pick it until Thursday. How do you handle that?" | CASE | [generic] | Clarify what is behind each position, then name the decision that is not yours to make and who owns it, propose an option each side can accept, and say what you would record. The question needs no claim about your past, so the guidance makes none | The advert sets the role between planning and the warehouse; the case tests how you handle the seam. `[generic]` because it is a pattern, not a claim about this employer |

## Requirement coverage

| Requirement or topic | Question IDs |
|---|---|
| "Coordinate production schedules between planning, the warehouse and QA" | B2, E1, E2 |
| "track supplier deliveries and chase late orders" | C2, E1 |
| "keep stock records accurate" | C1 |
| "report weekly on on-time dispatch" | C3 |
| "2+ years in operations or logistics coordination" | A1, D1 |
| "confident with Excel" | B4 |
| "ERP experience (SAP or similar) a plus" | B1, D1 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A4, D3 |
| "£38,000–£44,000" | A2 |
| Notice period (Hannah's list) | A3 |
| Reason for the move (Hannah's list) | A5, B3, D2 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "How is the role split between coordinating production schedules and tracking supplier deliveries?" | The advert lists four duties; asking for the split shows you read them and tells you where the weight falls |
| R2 | "Which stock or ERP system does the team use, and how is training handled for someone coming from a different system?" | It raises the SAP gap on your terms, as a question about ramp-up, and asserts nothing about your past |
| R3 | "Are the two Avonmouth days fixed, or agreed with the team?" | Hybrid is on Hannah's list; you have said two is fine and three is your limit, so the answer tells you whether the pattern can drift |
| R4 | "What do the on-time dispatch numbers look like today, and how is the weekly report used?" | It treats the report as something you would own and shows interest in the outcome, not just the task |
| R5 | "Where in the £38,000–£44,000 band would you expect a hire with a logistics coordination background to land?" | Pay is on her list; the band is public, so this asks about placement, not whether you are in range |
| R6 | "What would a strong first three months look like?" | A standard question that signals you are already thinking about the work, and gives Hannah something concrete to take to the team |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has coordinated production schedules | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says delivery scheduling for three depots, not production schedules. B2's slot stays inside the depots |
| Has used SAP | Negative you stated, F7 | The plain acknowledgment F7 gives: "I've never used SAP." A slot asks only about the in-house system and the plan to learn |
| Has ERP experience | Inflated form of F7 | F7's quote at its own scope: "we run our own in-house stock system." The material does not say whether that system is an ERP |
| Is confident or advanced in Excel | Inflated form of F6 | F6's quote at its own scope: a stock-count spreadsheet. B4's slot asks only what that spreadsheet was built in |
| Cut discrepancies by a third, or by a precise figure | Inflated form of F3 | F3's quote at its own scope: "about a third over a year." C1's slots ask only how it was counted and which part was yours |
| Was made redundant | Inflated form of the A5 sentence | The A5 sentence at its own scope: the office is closing and the only offer is Reading. The material does not use the word redundancy |
| Is flexible on office days beyond three | Inflated form of F8 | F8's quote at its own scope: "I wouldn't want more than three." D3's slot asks only whether you decide a condition beforehand |

## Sources

**Provided documents:** the advert text you pasted; your own description of your background and wishes (quoted as "your message"); Hannah Lowther's LinkedIn message (her own words, which establish this session as a 30-minute call on pay, notice, hybrid and motive). No dossier was present.

**Searches sent:**
- "Quillmoor Diagnostics news strategy": refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics": refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | skipped | Could not have moved anything: Hannah's own message fixes this as one phone call on logistics and motive, so no values-style round is detected and the values cheat sheet is not in this pack |
| 2. Quillmoor interview process, operations roles | skipped | Hannah's message establishes this one session and what it holds, and the pack prepares only this session; later rounds are not asserted |
| 3. Quillmoor strategy or recent news | unavailable | The search was refused; it would have moved A6 from advert-only to a current-context question |
| 4. Hannah Lowther at Quillmoor | unavailable | The search was refused; it would have moved a reading of the interviewer and a reverse question tied to her path |
| 5. Representative Operations Coordinator advert | skipped | You supplied the advert, which fixes every requirement row and the JD-tagged questions |

## Upgrade menu

- Your CV, or the lines on stock-count work and deliveries → F1 to F7 take their evidence from a CV sentence as well as your message, and F6's Excel question may be settled
- Your own answers to the slots on F1, F4, F6 and F7 → those rows upgrade from discovery or transferability wording to quoted evidence
- Your notice period, in your own words → A3's logistics slot becomes your stated figure
- Search permission for Quillmoor and Hannah's public profile → A6 gains current company context, an interviewer read is added, and R-questions can tie to her path
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief for A6 and a reading of recent company changes, if you want it
- A tuesday-dossier.md, if you have one → verified evidence and prohibited claims arrive pre-graded; the pack does not need it
