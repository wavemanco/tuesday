I'm checking whether Lumenvale Software has a findable public footprint (values, hiring process, recent news) before I build your prep pack. I'm running three searches now.
Searches were refused, so I'm building the pack from your message alone. I'm saving it now.
Before the prep, one thing in the invite: it says "Our hiring process is fully remote and is carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern, and a chat-app message may not come from who it names. The invite itself only asks for a time, so I'm not giving a verdict on the job. Until you've checked, hold any payment, ID, bank or tax details and any signed paperwork. To check, find Lumenvale's own website or careers page yourself and use the contact details there, not the chat. Also see whether your application confirmation or the careers page mentions Telegram or Marcus Hale. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-5/rooms/case-10-denied-c76a90eb/Lumenvale_customer-support-specialist_interview_pack.md`. I built it for a hiring-manager-style text chat with the team lead, using your summary of the ad. My web searches were refused, so nothing in it is about Lumenvale itself. The case questions are generic.

The pack has 18 questions across five interviewer styles. It also has a fit snapshot against the four ad requirements, a requirement-coverage table, six reverse questions and a list of claims it won't coach. The one to rehearse hardest is B1, the move from an energy supplier to a software company. The pack's answers only use what you told me, and the places where I don't know what happened are marked as slots for you to fill in your own words.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the team lead who'll interview you the person you'd report to?
Can you paste the full text of the job ad, so I can swap my summary for its own wording?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Lumenvale_customer-support-specialist_interview_pack.md -----
# Interview pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: the support team lead, name not given. Format, in the invite's words: "a text chat" on Telegram, one session. Relationship assumed: hiring manager, because the invite names no other. If the team lead is a peer or someone you would not report to, the persona weights change.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for your own words, not a script.
- Type key: VAL tests behaviour against a company's published values. EXP tests whether a line of your experience survives questioning. JD tests a stated requirement of the role. CO tests knowledge of the company and its strategy. CASE is a live problem from the role.
- This pack has no VAL or CO questions: no published values or company facts were available to build them from (see Sources).
- Because the interview is a text chat, your written answers are also the sample of your written communication. Rehearse by typing, not by speaking.

## Fit snapshot

Requirements are quoted from your summary of the ad, not from the ad itself.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — your message | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with the years and the role in the quote's own terms: you were a customer service advisor at an energy supplier for 3 years |
| F2 | "experience with Zendesk or a similar ticketing tool" — your message | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Your material names Freshdesk and does not mention Zendesk. Whether the team counts Freshdesk as similar is theirs to say, so expect it to be asked. Words: "I use Freshdesk every day." Answer slot: if you have also used Zendesk, say so in your own words; if you have not, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — your message | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails appear in the sentence, but calls and emails are counted together and the sentence says nothing about how the writing was judged. Answer slot: if anyone ever gave feedback on your written replies, say what it was in your own words; if no one did, say so plainly and stay with the emails you answered |
| F4 | "confidence handling escalations" — your message | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: if you handed on a case or took one over, say what the case was and what part was yours, in your own words; if you did not, or it was not yours, say so plainly and say how you would handle one |
| F5 | "remote Customer Support Specialist job at Lumenvale Software" — your message | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan and never as a past. The nearest ground your material carries is F2, at its own scope |
| F6 | no matching line in the ad as you described it | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | No gap, an extra the ad did not ask for. Lead with it in the quote's terms: you trained four new starters on the refunds process. The quote says trained, not that you designed or ran a training programme, and expect a probe on it |

## Persona table

The persona weights rest on the relationship prior for a hiring manager and on the invite's own words about one text-chat session, not on any documented Lumenvale process.

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live support scenarios you answer in writing | Top, 5 questions. The hiring-manager prior puts it first, and F4 has no evidence, so a live problem is the cheapest way for them to test escalation judgement | Clarify first, then structure, then answer; say what you would ask before acting |
| B. Skeptic | Quiet probing of the software-company move and the tool gap | Top, 5 questions. The hiring-manager prior, and F5 is a gap you stated yourself | Hold-then-concede on the one predictable objection; concede the specific, not the whole |
| C. Conversational | Friendly openers, "walk me through your journey" | Mid, 3 questions. A typed chat reads as informal, and casual questions are still scored | A short arc built only from your own sentences |
| D. Data-Driven Prober | Reads your numbers line by line | Mid, 3 questions. Your message carries three numbers: 3 years, around 60 a day, four starters | Know what you can and cannot say about how each number was counted |
| E. Pressure | Time-boxed or challenging follow-ups | Low, 2 questions. Nothing in the invite signals it, and typed chat dampens interruption | Pause, restate, hold through two follow-ups |

Highest-ROI prep in this pack: B1, the move from an energy supplier to a software company. It will be asked in some form, and it sits exactly where F5 states a gap.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same unresolved problem and says they're thinking of cancelling. Write me the reply you'd send and tell me what you'd do behind it." | CASE | [generic] | Ask first what has been tried and how urgent it is. Then: one plain sentence acknowledging it, restate the problem so they know it was read, say what you will do and by when, name who owns the next step, and record the case so they do not have to repeat themselves. Decide whether it needs someone else. Write it as you would really write it; the reply is the sample. This makes no claim about your past | The live version of the written-communication requirement in F3, asked as a problem rather than a record. CASE because it scores reasoning shown in writing; generic because it is a pattern for the problem |
| A2 | "Your queue has a dozen open tickets. One customer cannot log in at all, another wants a copy of an invoice, and two others report the same error since this morning. What do you pick up first, and why?" | CASE | [generic] | Clarify what you would check first. Order by customer impact and urgency, and say why. Two reports of one error may mean something wider than two customers, so say you would flag it rather than answer each alone. Say what you would tell the people waiting. This makes no claim about your past | Tests the judgement behind F4's requirement without needing an escalation story you may not have. CASE because the order and the reasoning are the score |
| A3 | "Tell me about a time you escalated a case to someone else, or took over a case that was escalated to you." | JD | [grounded] | A selection scaffold, since nothing in your material carries this story. Pick a case where you had to decide on the handover: it needs a named reason you could not resolve it yourself, what you passed on, and what the customer was told. If no such case comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one, using the structure in A4 | F4 has no evidence, and the ad's escalation line makes this open prompt near certain. JD because it scores a stated requirement |
| A4 | "In this role, how would you decide whether to keep a ticket or hand it on, and what would your handover note need to say?" | JD | [generic] | Answer as a plan. Reasons to hand on: you lack access, authority or technical depth. The note should carry the customer's own words, what has been tried, what the customer has been told, and what you need back. Answer slot: if you have written handover notes in your own work, say what they held in your own words; if you have not, say so plainly and give the plan | F4's requirement asked as a decision, so you can answer well without claiming experience you did not state. JD because it scores the stated line |
| A5 | "A customer says a feature isn't working and you cannot make it fail on your side. They're getting frustrated. What do you do?" | CASE | [generic] | Do not argue with what they saw. Ask for specifics one at a time: what they did, what they saw, what device, a screenshot. Say what you will do with it, record it, and keep them updated even when you have no answer. Say plainly that you would learn the product's own troubleshooting steps. This makes no claim about your past | F5 is the likeliest weak point, and a case on software troubleshooting lets you show method without a software history. CASE because the structure is scored |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You'd be moving from an energy supplier into a software company. What would be hardest for you in your first month?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "answering around 60 calls and emails a day"; "I use Freshdesk every day" | The deepest rehearsal in the pack. Hold only what the quotes carry. Open with the plain acknowledgment: "I haven't worked for a software company." Then say what you do have, at its own size: 3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day, and "I use Freshdesk every day." Concede the specific: the product, its terms and who handles what are new; say which you think is biggest. Follow-up one, "why wouldn't that slow you down?": do not promise speed; say in your own words what you would do first. Follow-up two, "have you picked up a new tool quickly before?": if an instance comes to mind, say it in your own words; if none does, say so plainly and describe how you would learn. Never turn "I use Freshdesk every day" into "I learned Freshdesk quickly" | F5 is the stated gap and the likeliest objection; JD because it scores whether you can do the listed job, gaps included |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Your material does not show Zendesk, escalations or any feedback on your writing. Answer slot: name the one you honestly think is weakest, in your own words, then say how you would close it as a plan. Never answer that you have no weak area | A stock Skeptic stem aimed at the rows F2 to F5 where your material is thin. JD because it scores the stated requirements |
| B3 | "If our team uses Zendesk, how would you get up to speed coming from Freshdesk?" | JD | [grounded] "I use Freshdesk every day" | Say "I use Freshdesk every day." Answer slot: if you have used Zendesk, say so in your own words; if you have not, say so plainly. Then say how you would learn it, as a plan. Do not claim the two tools are the same | F2's gap in the interviewer's words; the premise is about the team's tool, not your history. JD because it scores the ad's tool line |
| B4 | "This role leans on written communication. How does your experience fit that?" | JD | [inferred] "answering around 60 calls and emails a day" | Say what the sentence says: around 60 calls and emails a day, counted together. Answer slot: if you know roughly how many were emails, say so; if you do not know the split, say so plainly rather than estimating one. Then add anything anyone said about your written replies, only if someone did | F3 is low confidence; the figure mixes calls and emails, and a prober will pull them apart. JD because it scores the stated requirement |
| B5 | "Why support at a software company, and why now?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Answer slot: your actual reason, in your own words; the pack supplies none, because none is in your material. Give two parts: why software support, and why now. For Lumenvale itself, say only what you have read on their own site; if you have not looked yet, look before the chat | Motivation consistency is what a Skeptic scores. EXP because it tests whether your story holds up from the experience you stated |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through your journey so far." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A short arc in three typed paragraphs. One: 3 years as a customer service advisor at an energy supplier. Two: answering around 60 calls and emails a day, and "I use Freshdesk every day." Three: you trained four new starters on the refunds process last year. Close with why this role, in your own words, using your answer to B5 | The biographical opener is scored even when it feels casual. EXP because it tests which parts of your experience you choose to lead with, drawing on F1, F2, F3 and F6 |
| C2 | "What are you actually using in support tools these days?" | JD | [grounded] "I use Freshdesk every day" | Say "I use Freshdesk every day." Answer slot: if you have tried other tools, name them in your own words; if you have not, say so plainly and say what you would want to learn first | A casual question on the ad's tool line, which is still scored. JD because it maps to F2 |
| C3 | "I saw you trained some new starters. How did that go?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell only what the sentence states: four new starters, the refunds process, last year, in your own words. If asked for more detail, answer from what you remember or say you do not remember. Do not describe it as running or designing a programme | F6 is a strength the ad did not ask for, and the quote is short, so the guidance stays short. EXP because it tests what was actually yours |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You mention around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot, in your own words: how the figure was counted, what it moved with, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Never present it as 60 emails | The number is the likeliest thing a prober picks up, per F3. EXP because it tests precise attribution of a figure |
| D2 | "How much of that was calls and how much was email?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: if you know the split, say it in your own words; if you do not, say so plainly rather than guessing one | The figure mixes the two, and F3 and the written-communication line depend on the email share. EXP because it tests what the number does and does not show |
| D3 | "The ad asks for two years. You have three at the energy supplier. Was it the same role throughout?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Say what the sentence says. Answer slot: if the role or team changed over the three years, say how in your own words; if it was the same role throughout, say so plainly. Add no promotion or title | F1 is a stated line with nothing inspected behind it, so a prober checks its shape. EXP because it tests the claim itself |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, with no software experience?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "answering around 60 calls and emails a day"; "I use Freshdesk every day" | Pause, restate the question, then hold. Hold what the quotes carry: 3 years as a customer service advisor at an energy supplier, around 60 calls and emails a day, Freshdesk daily. Concede one specific: "I haven't worked for a software company." Hold through two follow-ups before conceding anything more. Let them draw the conclusion; do not state what your work proves | B1 under time pressure, where the second follow-up breaks an answer that claims more than the quotes say. JD because it scores fit to the role |
| E2 | "That training you mention. How much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold: "I trained four new starters on our refunds process." Answer slot: if anyone else was involved or the process was set by someone else, say so plainly; if it was all yours to deliver, say that. Concede specifics, not the core claim | F6 is short, and attribution is where a pressure interviewer goes. EXP because it tests what was yours |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | D3, B1, C1 |
| "experience with Zendesk or a similar ticketing tool" | B3, C2, B2 |
| "clear written communication" | A1, B4, D1, D2 |
| "confidence handling escalations" | A2, A3, A4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which ticketing tool does the team use, and how long does a new starter usually take to be handling tickets on their own?" | Answers the Zendesk question for you and shows you are already thinking about your first weeks |
| R2 | "What would a good first month look like, and what would you want me to have learned by the end of it?" | Turns the software-company gap into a shared plan, and gets the interviewer to say what they actually weight |
| R3 | "How do escalations work on the team: who do they go to, and what does a good handover note look like?" | Shows you think about the handover as well as the hand-off, and covers the escalation requirement from your side |
| R4 | "How does the team judge the quality of written replies?" | Signals that written communication matters to you and tells you how it is scored |
| R5 | "What are the most common reasons customers contact support, and what has changed recently?" | Shows interest in the product and customers rather than only the role |
| R6 | "Is the rest of the process, such as the contract and onboarding, done through the company's own systems or email, and who is my contact for it?" | A legitimate employer answers this easily, and the answer helps you check who you are dealing with |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material says Freshdesk, not Zendesk |
| Has experience in software or SaaS support | Negative you stated, F5 | The plain acknowledgment: "I haven't worked for a software company." No slot |
| Ran or designed a training programme | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year." The quote says trained, not ran or designed |
| Handled 60 tickets or emails a day | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day", counted together |

## Sources

Provided documents: your message, containing the Telegram invite, your summary of the ad's requirements, and your background. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, all refused:

- "Lumenvale Software company values": refused
- "Lumenvale Software interview process customer support specialist": refused
- "Lumenvale Software news strategy": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Every call was refused. It would have moved a values cheat sheet and VAL questions, if a values round were documented. Nothing in the pack rests on it |
| 2. `Lumenvale Software interview process customer support` | unavailable | Every call was refused. It would have moved persona weights; the loop here rests on the invite's own words |
| 3. `Lumenvale Software strategy` / recent news | unavailable | Every call was refused. It would have moved company-specific CO and CASE questions; the CASE bank is generic as a result |
| 4. `{interviewer name} Lumenvale Software` | n/a | No interviewer name was given, so no query could be formed |
| 5. representative `Customer Support Specialist` JD | skipped | Your summary of the ad fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → F1 to F4's requirement quotes become the ad's own words, and any requirement your summary left out gets a question
- The interviewer's name, and whether they would be your manager → persona weights read from their public footprint, and a reverse question tied to their path
- What the recruiter said the chat will cover, and how long it runs → coverage and pacing for a one-session chat
- Lumenvale's own about or careers page text, pasted → company-specific CO questions, and VAL questions if a values round is documented
- A QA review, a customer-satisfaction result or a Freshdesk report on your own work, with customer details removed → F1 and F3 move from medium and low toward high
- Your answers to the slots in F2, F3 and F4 → those rows become quoted evidence and their questions become story-mapped
- A tuesday-dossier.md → verified evidence and recorded gaps from an earlier check, so the Skeptic bank rests on confirmed material rather than only your quoted lines
