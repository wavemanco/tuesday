Search access was declined, so I'm building the pack from your invite and your message alone. I'm writing it now.
Before the prep, there's a problem with the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN IE00 ..." before your interview slot is confirmed. It asks you to "reply with a photo of your passport and your bank details before the interview". It also says successful candidates get "a cheque for €1,850" and that "you deposit the cheque and send the balance on to the vendor". Asking for money, ID and bank details before any offer, and having you forward part of a cheque you've deposited, is a known scam pattern. The fee request, the cheque arrangement and the request for your passport and bank details are very likely a scam. Please hold all four (paying, depositing a cheque, and sending documents or bank details) until you've checked the invite with the employer. Use contact details you find yourself on its own website or careers page, not the email or any number in the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-5/rooms/case-12-denied-b1b82221/brennock-facilities_remote-administrative-assistant_interview_pack.md`. I built it for a 30-minute video call with the office manager, assuming a hiring-manager-style round because you didn't say how they relate to the role. The pack has 19 questions, answer guidance tied to your own words, reverse questions and a prohibited-claims list. Search access was declined, so there's no company research. It rests on the invite and your message.

The likeliest probes are the invoice side (you "chased unpaid invoices", but the ad says processing supplier invoices), Excel, and booking travel. For travel there's nothing in your material either way, so the pack gives you answer slots rather than invented answers.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager your future manager or a peer on the team? The answer reweights every question bank.
Can you paste the ad's full text, or shall I carry on with your summary of it?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock-facilities_remote-administrative-assistant_interview_pack.md -----
# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager, name not given. The invite describes one 30-minute video call. Relationship to you unknown, so this pack assumes a hiring-manager-style round.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say only what you actually did, in your own words.

| Type | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether a claim about your past survives scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and its strategy |
| CASE | A live problem from the role, scored on structure |

Provenance labels: `[grounded]` traces to your message or the invite; `[inferred]` is derived from an adjacent source; `[generic]` is a rehearsal pattern with no claim about you or the employer. No VAL or CO questions are included: no company values or strategy were available (see Sources).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — your message (the ad) | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | The quote already reaches the calendar line in other terms. Use its own term, appointment book, and let the interviewer map it: "I ran the appointment book for four physios." Nothing about how it was run is in your material, so describe that only in your own words |
| F2 | "booking travel" — your message (the ad) | none given | none | [grounded] | discovery | Your material does not show travel booking either way. Answer slot: the ad lists booking travel, so expect a probe on it. If you have booked travel in any role, say what and for whom, in your own words; if you have not, say so plainly and stay with the appointment book you ran |
| F3 | "preparing documents in Word and Excel" — your message (the ad) | "I'm good with Word, okay with Excel" — your message | medium | [grounded] | none | No gap on the Word half, but a self-assessment with nothing inspected behind it, so expect a probe. Lead with the sentence's own terms, good with Word, and let a document you can name carry it |
| F4 | "preparing documents in Word and Excel" — your message (the ad) | "I'm good with Word, okay with Excel" — your message | medium | [grounded] | discovery | The quote gives your level, okay with Excel, and nothing about what you have done in it. Answer slot: if you have prepared particular files or sheets, say which, in your own words; if not, say so plainly and say what you would practise first |
| F5 | "processing supplier invoices" — your message (the ad) | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing. It does not say whether those invoices were owed to the clinic or by it, or whether any were processed, and the words stay "chased unpaid invoices." Answer slot: the ad's supplier-invoices line makes a probe likely. If you handled invoices coming in from suppliers, say how, in your own words; if you did not, or it was not yours, say so plainly and stay with the chasing |

## Persona table

The loop is one 30-minute video call with the office manager, from the invite's own words. Weights start from the hiring-manager prior because your note did not say who the office manager is to you.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live mini-problems: a diary clash, a trip to book, an invoice that does not match | High. The ad's four duties are all things an interviewer can turn into a live problem in a short call. Five questions | Clarify first, then structure, then answer; think aloud |
| Skeptic | Quiet probing of what the clinic work does and does not cover, and why remote admin | High. Hiring-manager prior, and F2, F4 and F5 are the thin rows. Four questions | Rehearse the one predictable objection until it is boring; concede plainly where your material shows nothing |
| Conversational | Friendly opener, "walk me through your journey", first-week chat | Medium. A 30-minute call usually opens this way, and casual questions are still scored. Three questions | A 90-second arc from your own sentences |
| Data-Driven Prober | Asks what you actually did in the appointment book, the invoices and Excel | Medium. The ad names invoices and Excel, and your sentences are short enough to invite follow-ups. Three questions | Say what you did in your own words, and say plainly what you did not do |
| Peer Evaluator | Where your job ends and the office manager's begins | Low. Only if the office manager is a peer. Two questions | Propose seam principles rather than pretending to know the seam |
| Pressure | Time-boxed challenge, "how much of that was you" | Low. A short, scheduled video call makes it less likely. Two questions | Pause, restate, hold what you stated, concede what you did not do |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people whose calendars you look after want the same slot on Thursday, and one of them travels that afternoon. What do you do?" | CASE | [generic] | Structure it: what you would ask first, whose commitment can move and who decides, what you would do today, how you would tell both, and what you would note down. The question needs no claim about your past, so the guidance makes none | The ad's calendar line (F1) as a live problem; generic because it is a pattern for the problem, not a fact about this employer |
| A2 | "Someone has a 10am client meeting in another city. What do you need to know before you book anything?" | CASE | [generic] | Structure it: dates and times, who approves and any budget limit, the traveller's preferences, a buffer either side, how you would confirm and share the itinerary. No claim about your past | F2's requirement as a live problem, so you can show structure even where your material shows no travel booking |
| A3 | "A supplier invoice arrives and does not match the purchase order. Walk me through what you do." | CASE | [generic] | Structure it: what you would compare, whether to hold it rather than pass it on, who you would ask, whom you would tell, and what you would record. No claim about your past | F5's requirement as a live problem; the ad's invoice line (F5) is where your quoted work is thinnest |
| A4 | "Walk me through how you ran the appointment book for four physios." | JD | [grounded] "I ran the appointment book for four physios" | Story-mapped on F1: the appointment book and the four physios, which are the beats the quote states; tell them in your own words. Answer slot: the ad's managing-calendars line makes a probe on how changes and clashes were handled likely. If those were yours to handle, say how; if there were none, or they were not yours, say so plainly and describe how you ran the book | F1 is the evidence for the calendar line and a likely first probe; JD because it scores the stated duty |
| A5 | "Have you booked travel for anyone before?" | JD | [grounded] "I ran the appointment book for four physios" | Answer slot: if you have booked travel in any role, say what and for whom, in your own words; if you have not, say so plainly, then return to the one thing your material carries: "I ran the appointment book for four physios." Never describe a booking you did not make | F2 is a row with no evidence; this rehearses the honest answer before the probe arrives |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You chased unpaid invoices. This role processes supplier invoices. How do those compare?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I chased unpaid invoices." Answer slot: if you handled invoices coming in from suppliers, say how, in your own words; if you did not, or it was not yours, say so plainly and stay with the chasing. Hold through two follow-ups by returning to the chasing, never by adding to it, then concede in specific terms what you have not done and say how you would learn it as a plan, not a past | F5 is the biggest distance between your material and the ad, so this objection will arrive in some form; JD because it scores a stated duty |
| B2 | "Where would you put yourself in Excel, and what could you do in it today?" | JD | [grounded] "I'm good with Word, okay with Excel" | Say your level as you gave it: "I'm good with Word, okay with Excel." Answer slot: if you have prepared particular files or sheets, name them, in your own words; if not, say so plainly and say what you would practise first. Do not raise the level in the room | F4 is a stated middling level against a duty that names Excel |
| B3 | "This is a remote role with no front desk. What is drawing you from clinic reception to remote admin?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Start from the quote: "two years as a receptionist at a physiotherapy clinic." Your reason for moving is not in your material, so give your actual reason, in your own words, in two sentences | Motivation consistency is what a skeptic scores; EXP because it tests your own account of the move |
| B4 | "How would you keep on top of the work and stay visible when nobody sits near you?" | JD | [generic] | Structure it: how you would agree routines and priorities up front, when you would check in, how you would flag a blocker early, how you would keep a log others can see. No claim about your past | The role title says remote; generic because no remote-working requirement was supplied beyond it |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "I ran the appointment book for four physios" "chased unpaid invoices" | A 90-second arc with three beats the quotes state: two years as a receptionist at a physiotherapy clinic, the appointment book for four physios, and the chasing of unpaid invoices. Then, in your own words, why this role | The biography question is scored even when it sounds casual; EXP because it tests whether your own account holds together |
| C2 | "What did you enjoy most about running the appointment book?" | EXP | [grounded] "I ran the appointment book for four physios" | Answer slot: your quote does not say what you enjoyed, so say what you actually enjoyed, in your own words; if nothing stands out, say so plainly and describe the work in the quote's own terms | Casual enthusiasm questions are scored on genuine interest; F1 is the row it draws on |
| C3 | "What would a good first week look like for you in a role like this?" | JD | [generic] | Structure it: learn who you support and how they like to work, the tools and where files live, who approves what, and who to ask. No claim about your past | A common rapport-style question about starting up; generic because it makes no claim about this employer |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through a typical day with the appointment book." | EXP | [grounded] "I ran the appointment book for four physios" | Answer slot: the quote says you ran the book and nothing about its daily steps, so describe the steps you actually took, in your own words; if a step was not yours, say so plainly. No figures are in your material, so give none | A prober checks what lies behind a CV line (F1) |
| D2 | "Walk me through how you chased an unpaid invoice." | EXP | [grounded] "chased unpaid invoices" | Answer slot: say the steps you actually took, in your own words, and what you do not know about how the invoice was recorded. If part of it was someone else's job, say so plainly. Stay with the chasing | F5 is the row a prober tests for what was actually yours |
| D3 | "Tell me about a document you prepared in Word that you would be happy to show me." | JD | [grounded] "I'm good with Word, okay with Excel" | Selection scaffold: pick a document with a named purpose, a named reader and something you changed after feedback. If none comes to mind, say so plainly, then give the nearest thing your material carries, "I'm good with Word," or how you would approach one | The ad's Word duty (F3); an open prompt, so the pack supplies no document |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A request could be yours or mine. How do we decide?" | CASE | [generic] | Propose principles, not a map you cannot know: who owns the outcome, who has the information, what you would do first so nothing stalls, and how you would agree it afterwards. No claim about your past | Seam questions are a peer's favourite; generic because the real seam is unknown |
| E2 | "Tell me about a time you disagreed with a colleague." | EXP | [generic] | Selection scaffold: pick a time with a real disagreement, a view you held and the relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Disagreement style with equals is what a peer scores; open prompt, so no instance is supplied |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That appointment book: how much of it was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold the quote at its own scope: "I ran the appointment book for four physios." Answer slot: if parts of it were shared or set by others, say which, in your own words; if it was all yours, say so without adding to it. Hold through two follow-ups, then concede specifically what the quote does not cover | Attribution probes exist to catch inflation; F1 is your strongest row, so it is the one most worth holding precisely |
| F2 | "Sixty seconds: why you for this role?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" "I ran the appointment book for four physios" "chased unpaid invoices" | Three beats the quotes state, in order: two years as a receptionist at a physiotherapy clinic, the appointment book for four physios, the chasing of unpaid invoices. Pause before you answer, restate the question, stop at sixty seconds. Why you want this role is in your own words | A time-boxed motive question tests composure; the beats are limited to what you stated |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| "managing calendars" | A1, A4, F1 |
| "booking travel" | A2, A5 |
| Word half of "preparing documents in Word and Excel" | D3 |
| Excel half of "preparing documents in Word and Excel" | B2 |
| "processing supplier invoices" | A3, B1, D2 |
| Remote working (from the role title, no quoted line) | B3, B4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Whose calendars and travel would I look after, and roughly how many people?" | Shows you are sizing the real job, and the answer tells you whether F1 and F2 are central |
| R2 | "How do supplier invoices reach this role, and who approves them?" | Shows you understand invoices have an approval chain, and tells you what F5 would really involve |
| R3 | "How is equipment provided for remote staff, and which company email or contact will confirm it, so I can check it with HR through your website?" | A normal onboarding question that also gives you a way to verify what you are told |
| R4 | "Who would I report to day to day, and how often would we check in?" | Remote roles depend on rhythm; the answer shows how you would be supported |
| R5 | "What would make you say the first three months had gone well?" | Shows you aim at outcomes and gives you something concrete to work toward |
| R6 | "What do you wish the last person in this role had been able to do from day one?" | Invites a candid answer rather than a rehearsed one |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices." The limit is the pack's own observation: your material says chasing, not processing. B1's slot stays inside the chasing |
| Managed calendars and resolved scheduling conflicts for staff | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." A4's slot asks only how the book was run, in your own words |
| Advanced Excel skills | Inflated form of F4 | F4's quote at its own scope: "I'm good with Word, okay with Excel." B2's slot asks only what you have prepared in it |

## Sources

Provided documents: the invite email as you pasted it, and your message (the ad as you described it, and your background). No dossier was present.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

Searches sent: "Brennock Facilities Ltd values" (refused); "Brennock Facilities Ltd interview process administrative assistant" (refused).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Every call was refused. Would have fed VAL questions and a values cheat sheet; neither is in this pack |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | Every call was refused. The loop here rests on the invite's own words (one 30-minute video call with the office manager), and persona weights follow that and the hiring-manager prior |
| 3. `Brennock Facilities Ltd strategy` | unavailable | No call sent after the first two were refused. Would have fed CO questions, which are absent |
| 4. `{interviewer name} Brennock Facilities Ltd` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Remote Administrative Assistant` JD | skipped | The ad as you described it fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → F1 to F5 would quote the ad itself rather than your description, and the JD-tagged questions would carry the ad's own wording
- Whether the office manager is your future manager or a peer → persona weights recomputed and the banks reweighted
- Your own words on travel booking, Excel and invoices → the answer slots in F2, F4 and F5 become story-mapped answers
- The office manager's name → an interviewer read and a reverse question tied to their path
- The company's own published values or interview page, found through its own website and pasted here → VAL and CO questions
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, if search is available → a strategy brief for CO and CASE questions
- A tuesday-dossier.md from an earlier check of this role → verified evidence and prohibited claims arriving ready-made
