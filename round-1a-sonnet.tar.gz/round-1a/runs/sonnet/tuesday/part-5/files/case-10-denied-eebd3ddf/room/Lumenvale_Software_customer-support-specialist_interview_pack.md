# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: the support team lead, name not given. Format, per the invite: a text chat on Telegram. Relationship assumed hiring-manager style (the person you would work under); not confirmed.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values. None in this pack: no published values were read |
| EXP | Whether your CV and your account of your work survive follow-up questions |
| JD | Whether you can do the listed job, including its gaps |
| CO | What you know about the company and its strategy. None in this pack: no company research was possible |
| CASE | A live problem from the role, answered on the spot |

Guidance is scaffolding, not a script. Where guidance says "answer slot", it is an instruction for the interview: answer from your own experience, in your own words, and where the honest answer is "that was not mine" or "there was no such step", say that plainly. Because the interview is a text chat, your written replies are themselves what is being judged for "clear written communication".

## Fit snapshot

Requirements are quoted from the job ad as you listed it in your message. Evidence is your own words and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you listed it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap on the number, but it is a CV-style line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: three years as a customer service advisor at an energy supplier. Do not relabel it as software support |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you listed it | "I use Freshdesk every day" — your message | medium | [grounded] | none | Name the tool you use, in the quote's words: "I use Freshdesk every day." Your material says Freshdesk, not Zendesk, so any Zendesk claim sits outside it. Answer slot: the ad names Zendesk, so expect a probe on it. If you have also used Zendesk or another ticketing tool, say where; if not, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — job ad, as you listed it | "answering around 60 calls and emails a day" — your message | medium | [grounded] | discovery | The quote puts emails among your daily contacts; it does not show how clear the writing was or how many of the contacts were emails. Answer slot: the ad asks for clear written communication, so expect a probe on your writing. If any of your replies were reviewed, scored or reused by others, say how; if none were, say so plainly and describe how you write a reply |
| F4 | "confident handling escalations" — job ad, as you listed it | none given | none | [grounded] | discovery | Your material does not show escalation handling. Answer slot: the ad asks for it, so expect a probe. If you handled escalations, whether from upset customers or to a supervisor, say what happened and which part was yours; if none came to you, or they went to someone else, say so plainly and use the live-problem structure in A2 |
| F5 | Supporting customers of a software product — role-family, not quoted | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan and never as a past. Never a claim to software-support work, and nothing added to make the gap feel smaller |
| F6 | Helping colleagues learn a process — role-family, not quoted | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | presentation | Say it as you wrote it: last year you trained four new starters on your team's refunds process. Do not upgrade it to building or running a training programme. Expect a probe on what the training involved (D2) |

## Persona table

The loop is established by the invite's own words: one session, a text chat with the support team lead. Weights rest on the hiring-manager prior, because the relationship is unconfirmed.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live ticket scenarios typed into the chat | High (5 questions). The hiring-manager prior puts Case first, and a text chat suits typed scenario replies | Clarify before you answer, structure the reply, say what you would check and who you would involve |
| Skeptic | Quiet probing of the gaps | High (5 questions). F4 and F5 are the thinnest rows and a hiring manager is derisking exactly those | Rehearse the software-company objection until it is boring; plain acknowledgment plus a concrete ramp plan |
| Conversational | A friendly opener such as "walk me through your journey" | Medium (3 questions). Openers are near-universal and a chat format invites them; they are still scored | A 90-second arc built only from your own quoted sentences |
| Data-Driven Prober | Asks how your two figures were counted | Medium (3 questions). Your message carries two figures, around 60 contacts a day and four trainees | Know what you can and cannot say about each figure; say "I don't know how it was counted" where true |
| Pressure | Short time limits, challenges your motives | Low (2 questions). Nothing in the invite signals it, but escalation handling invites one test of composure | Pause, restate, hold your position through two follow-ups, concede only what is true |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same unresolved problem and says they want to cancel. Type me your reply." | CASE | [generic] | Structure it: acknowledge the repeat in one line, restate the problem to show you read it, say what you can do now and what you cannot, give a next step and a time you could actually keep, and say when you would hand it to someone else and what you would pass on. The question needs no claim about your past, so the guidance makes none | Live problem from the ad's escalation line (F4); CASE because it scores structure and tone in writing, which is also the F3 requirement |
| A2 | "A customer demands a manager and says they will post a public complaint. What do you do in the first few minutes?" | CASE | [generic] | Structure: stay calm and acknowledge, find out exactly what they want fixed, say what you can do yourself, state plainly when and why you would escalate, and what you would write in the handoff so the customer does not repeat themselves. Challenge one premise respectfully, such as asking what the team's escalation route is | The most direct test of F4's requirement, asked as a decision rather than a history; CASE because it asks about no past |
| A3 | "You start your shift with twelve open tickets: one angry customer, one waiting on engineering, one simple refund, and nine routine ones. How do you order them?" | CASE | [generic] | Clarify first: what priority rules the team uses and what the response-time targets are. Then structure by urgency, customer impact and what is blocking each ticket, and say what you would tell the customer whose ticket is waiting | Tests prioritisation, a ticketing-role skill implied by F2's requirement; the ordering matters less than clarifying before structuring |
| A4 | "A colleague started a ticket and went off shift. What do you need in a handoff note so you can pick it up cold?" | CASE | [grounded] "I use Freshdesk every day" | Structure: the customer's problem in one line, what has been tried, what was promised and by when, what is still unknown, and the next step. If you mention your tool, say it as you wrote it: "I use Freshdesk every day." Do not name features of any tool beyond that | F2 is the evidence for the ticketing requirement; CASE because it is a live problem, JD because the ad lists a ticketing tool |
| A5 | "A customer says our app 'just doesn't work'. You have never used our product. What do you ask first?" | CASE | [generic] | Clarify before you diagnose: what they were trying to do, what they expected, what they saw, when it started, on what device or version, and whether anything changed. Then say what you would check, and that you would involve the team rather than promise a fix you cannot back | F5 is the biggest gap, and a hiring manager can test it without any product knowledge; CASE because it scores how you act with none |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked for a software company. How would you get up to speed on our product?" | JD | [grounded] "I've never worked for a software company" and "I use Freshdesk every day" and "3 years as a customer service advisor at an energy supplier" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't worked for a software company." Then the ramp plan, said as a plan and not a past: use the product the way a customer would, work through whatever the team gives new starters, and ask what the team would want a new person to know first. Then the adjacent evidence at its own scope: "I use Freshdesk every day." Hold through two follow-ups by returning to those quotes, never by adding to them | F5 is where this hire is most likely to be challenged, so some form of this question is likely; JD because it scores fit for the listed job |
| B2 | "Tell me about a time you handled an escalation." | JD | [generic] | Selection scaffold: pick a time when a contact went beyond what you could settle, that has a named stake, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it using the A2 structure | F4 is silent in your material, so the honest branch matters; JD because the ad lists escalations |
| B3 | "What do you expect is different about supporting software customers compared with the customers you've served so far?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" and "I've never worked for a software company" | Say what you served, at its scope: three years as a customer service advisor at an energy supplier. Then say plainly that you have not supported software customers. Frame anything you expect as an expectation you would test with the team, not as knowledge | F5 again, in a gentler form; JD because it tests understanding of the job |
| B4 | "The ad says Zendesk or similar. Freshdesk is what you use. How quickly could you be working in our tool?" | JD | [grounded] "I use Freshdesk every day" | Say it as you wrote it: "I use Freshdesk every day." Answer slot: if you have also used Zendesk or another ticketing tool, say where; if not, say so plainly. Give any time estimate as an estimate, in your own words, and say what you would do to shorten it. Do not give a number you cannot stand behind | F2 is the evidence for the tool requirement; the likely probe is whether Freshdesk transfers; JD because it scores the stated requirement |
| B5 | "Why leave energy for software support, and why us, and why now?" | EXP | [generic] | Give your actual reason in your own words; this pack does not supply one. Keep it to what is true, keep it forward-looking, and keep it consistent with the rest of your answers. "Why us" needs facts about Lumenvale that this pack could not research | Motivation consistency is what a Skeptic scores; EXP because the reason for leaving is a logistics item about your history |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" and "I trained four new starters on our refunds process last year" and "I use Freshdesk every day" | A 90-second arc with three beats, each one a clause your sentences state: three years as a customer service advisor at an energy supplier; last year you trained four new starters on your refunds process; you use Freshdesk every day. Then why this role, in your own words. Tell it in your own words rather than as a script | F1, F6 and F2 are the material the opener should draw on; EXP because it invites the CV story |
| C2 | "Since we're typing: how do you keep a written reply clear when you can't hear the customer's tone?" | JD | [grounded] "answering around 60 calls and emails a day" | Say what you did, at its scope: you answered around 60 calls and emails a day. Answer slot: if you have a method for tone and clarity, say what yours is, in your own words; if you have no set method, say so plainly and describe how you write a reply. Show it as you answer: short paragraphs, one point at a time | F3 is the evidence for the written-communication requirement; JD because the ad lists it, and the chat itself is the sample |
| C3 | "Is there anything you'd like us to know that your CV doesn't show?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Do not answer "I think you've covered everything". Pick one true thing, in your own words. If you choose the training, say it as you wrote it: last year you trained four new starters on your refunds process, and stop there unless asked | Rapport-style interviewers weight this slot as a preparation signal; EXP because it asks what the CV leaves out |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You mention around 60 calls and emails a day. How was that figure counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say it as you wrote it: around 60, calls and emails together. Answer slot: say how the figure was counted, if you know; say what it varies with, if you know; name the assumption you would defend least; say which part was yours. Where you do not know, say "I don't know how it was counted", which is an honest branch | F3's figure is the likeliest number to be probed; EXP because it tests whether the figure survives scrutiny |
| D2 | "You trained four new starters. What did that involve, and how did you know it worked?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Say it as you wrote it: four new starters, your team's refunds process, last year. Answer slot: if you set out the materials or sessions, say what; if it was informal, or someone else set the format, say so plainly. If any result was measured, say what; if none was, say so plainly. Say which part was yours, in your own words | F6 is the one figure about helping others; EXP because the interviewer will ask what was actually you |
| D3 | "What did you actually do in Freshdesk, day to day?" | JD | [grounded] "I use Freshdesk every day" | Start from the quote: "I use Freshdesk every day." Answer slot: say what you did in it, in your own words. If your use was working the tickets assigned to you, or others set up the tool, say so plainly and stay with the quote. Do not name features you did not use | F2 is a one-line claim, so depth is the probe; JD because it scores the ticketing requirement |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already worked in software support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day" and "I trained four new starters on our refunds process last year" and "I've never worked for a software company" | Hold: three years as a customer service advisor at an energy supplier, "I use Freshdesk every day", and last year you trained four new starters on your refunds process. Hold that through two follow-ups by returning to those sentences. Concede: "I haven't worked for a software company." Never fold on the three years, and never add to them | F5 pressed hard by time; EXP because it tests what you can defend |
| E2 | "A customer is typing in capitals and says you've ignored them. You have thirty seconds. Reply." | CASE | [generic] | Pause, then write: acknowledge, say you are looking at it now, state what you will do and by when. Hold your approach if challenged. Concede only what is specific and true, such as "I'd need to check that with the team" | F4's requirement, tested live and under pressure; CASE because it asks about no past |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "2+ years in customer support" | B3, C1, E1 |
| "experience with Zendesk or a similar ticketing tool" | A3, A4, B4, D3 |
| "clear written communication" | A1, C2, E2 |
| "confident handling escalations" | A1, A2, B2, E2 |
| Software-company gap, not in the ad | A5, B1, B3, E1 |
| Your two figures | D1, D2 |

No VAL or CO questions are included, because no published values or strategy were read and writing them from memory would be invention.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Will the offer come as a written contract from a company email address, and can I review it before accepting?" | It is a normal, professional question, and a real employer answers it easily |
| R2 | "What does the first month look like for someone coming from outside software?" | It turns the B1 objection into a planning conversation |
| R3 | "Which ticketing tool does the team use, and how are escalations routed?" | It shows you read the ad's two requirements and want to know how they work in practice |
| R4 | "What does good look like at 90 days?" | It signals you think in outcomes and gives you something concrete to aim at |
| R5 | "What are the working hours and time-zone coverage for the remote team?" | It settles a practical term for a remote role, and rapport-style interviewers read it as engagement |
| R6 | "How do you give feedback on the written replies agents send?" | It ties to the ad's written-communication requirement and shows you expect to be coached |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked for a software company | Negative you stated, F5 | The plain acknowledgment: "I haven't worked for a software company." Then a plan, never a past |
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material says Freshdesk, not Zendesk |
| Built or ran the refunds training programme | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year." The limit is the pack's observation: your material says you trained four people, not that you designed the programme |
| Answered about 60 emails a day | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day", calls and emails together. The limit is the pack's observation: your material does not split the 60 between calls and emails |

## Sources

Provided documents: your message, containing the Telegram invite text, your background, and the job ad's requirements as you listed them. No full job ad text and no dossier were provided.

Searches sent, each refused (web search permission was not granted):

- `Lumenvale Software company values`: refused
- `Lumenvale Software interview process customer support specialist`: refused
- `Lumenvale Software news strategy`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software company values` | unavailable | Refused. Would have supplied published values for VAL questions, which are therefore absent |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | Refused. Loop structure rests on the invite's own words: one text chat with the support team lead |
| 3. `Lumenvale Software news strategy` | unavailable | Refused. Would have supplied CO questions, which are therefore absent |
| 4. `{interviewer name} Lumenvale Software` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Customer Support Specialist` JD | skipped | The four requirements you listed fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search permission → values, loop and news research at L1: CO questions and a values map become `[grounded]` where now there are none
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a company strategy brief for sharper CO and CASE questions
- The full job ad text → the `[generic]` requirement in F5 and F6 become quoted `[grounded]` rows, and any requirement beyond the four you listed gets a question
- The interviewer's name → a tailored reverse question and persona weights read from their public footprint
- The recruiter's guidance on the chat (length, topics, any scenario test) → coverage of anything pre-declared, and a reweighted bank
- Your own answers to the slots in F2, F3 and F4 → those three rows move from `discovery` or thin evidence to quoted evidence, and the matching banks regenerate
- A tuesday-dossier.md from an earlier session → verified evidence and a tighter set of prohibited claims
