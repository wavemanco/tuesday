# Interview pack: Customer Support Specialist, Lumenvale Software

Interviewer: the support team lead (name not given). Round: one text-chat interview, per the invite you pasted. Relationship assumed: your likely day-to-day manager.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, in short chat messages, and rehearse only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether what you have said about your work survives follow-up questions |
| JD | Whether you can do the listed job, including its gaps |
| CO | How well you know the company and its product |
| CASE | A live problem from the role, scored on structure and reasoning |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — your message, the ad's list as you gave it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but a statement with nothing inspected behind it, so expect a probe on it. Lead with the quote's own terms: 3 years as a customer service advisor at an energy supplier, and let the interviewer match it to the ad |
| F2 | "experience with Zendesk or a similar ticketing tool" — your message, the ad's list as you gave it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Say the tool by name, as the quote does: "I use Freshdesk every day." The words stay at Freshdesk and the interviewer judges the match to the ad's wording. Your material says Freshdesk, not Zendesk |
| F3 | "clear written communication" — your message, the ad's list as you gave it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote says calls and emails answered, and does not show how much of it was your own writing. Answer slot: the ad asks for clear written communication, so expect a probe on your writing. If some of those emails were yours to write, say what kind and how you kept them clear, in your own words; if most were calls, say so plainly and stay with the emails you did answer |
| F4 | "confidence handling escalations" — your message, the ad's list as you gave it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: the ad asks for confidence handling escalations, so expect a probe. If escalations were part of your work, say what kind and what you did, in your own words; if they were not, or were not yours, say so plainly and say how you would approach the first one |
| F5 | Familiarity with software products — not in the ad's list; role-family pattern with no source | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | Helping colleagues learn the work — not in the ad's list; role-family pattern with no source | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | No gap, but a statement with nothing inspected behind it. Lead with the quote's own terms: you trained four new starters, on your refunds process, last year. Your material says you trained them, not that you set the process |

## Persona table

The loop rests on your own words: one text chat with the support team lead. No company research ran, so no documented loop or published values informed these weights.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live support scenarios in chat: a furious customer, a spike of the same complaint | High. A team lead who may be your manager tends to test live problems from the role; the ad's escalations line (F4) is the natural source | Clarify first, then structure, then reply; challenge one premise politely |
| Skeptic | Probes the gap between energy-supplier work and software support | High. You have told me you have never worked for a software company (F5), and a manager-style interviewer prices gaps | Rehearse the one predictable objection until it is boring: acknowledge, state what your material carries, give a ramp plan |
| Conversational | Friendly opener, "tell me about yourself" | Medium. A chat format makes a relaxed opening likely; nothing documents it | Prepare a short arc from your own quoted sentences; treat casual questions as scored |
| Data-Driven Prober | Goes line by line through the numbers and the tool you named | Medium. Your material has a figure (F3) and a named tool (F2), which are the usual probe targets | Know how each figure was counted and say plainly when you do not know |
| Pressure | Short time-boxes, a rude customer role-played at you | Low. Nothing in the invite signals it, but support loops often include a hard-customer drill | Pause, restate, hold your position through two follow-ups, concede only what is true |

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in, furious that a feature they rely on stopped working this morning, and demands a refund. Walk me through your first three replies." | CASE | [generic] | Structure it aloud: acknowledge the impact without blaming; ask the few facts you need (what changed, what they see, when it started); say what happens next and when you will update them. Challenge one premise: is the refund the real ask or the fix? The question needs no claim about your past, so the guidance makes none | Live problem from the support role; also exercises the written-reply skill behind F3. CASE because it asks for reasoning, not history |
| A2 | "Fifty tickets arrive in an hour, all about the same login error. What do you do?" | CASE | [generic] | Confirm it is one pattern, send customers one clear holding reply, tell your team lead early with a short summary, and keep one place where updates go. Say your assumptions as you go. No claim about your past | Tests triage and calm under volume; a spike scenario fits the escalations line (F4). CASE because it is a live problem |
| A3 | "How would you decide when to escalate a ticket instead of keeping on with it yourself?" | JD | [generic] | Give criteria, not a story: it is beyond your authority or access, it needs a product or engineering fix, there is risk to the customer, or time is running out. Then the handoff: what the customer reported, what was tried, what you need, by when, and what you told the customer. No claim about your past | The ad raises escalations (F4), so this is its most direct question. JD because it scores the stated requirement, delivered as a decision |
| A4 | "Rewrite this for me in two lines: 'Unfortunately that isn't something we can do.'" | CASE | [generic] | In the chat itself: say what you can do instead, give the reason in a clause, and name the next step. Keep it short and warm. No claim about your past | The chat is itself a writing sample for the ad's clear-written-communication line (F3). CASE because it is a live task |
| A5 | "What do you know about our product and who uses it?" | CO | [generic] | Research did not run, so this is a scaffold. Before the chat, read the company's own product pages yourself. Say only what you actually found, and say plainly if you have not used the product. Then ask the interviewer one specific question about it | Homework depth is scored in any software support role; generic here because no search was permitted, and the upgrade menu says how it becomes grounded |

### B. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company — how would you handle the learning curve here?" | JD | [grounded] "I've never worked for a software company" and "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Acknowledge first, in your words: "I've never worked for a software company." Then what your material carries, as it stands: "I use Freshdesk every day." Then a ramp plan, said as a plan: what you would learn first and how. Never imply software experience you have not stated | F5 is the biggest stated gap, so this objection arrives in some form; JD because it scores whether you can do the listed job |
| B2 | "Your background is energy. How does that carry over to software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" and "answering around 60 calls and emails a day" | Say the quote at its own scope: "3 years as a customer service advisor at an energy supplier," answering "around 60 calls and emails a day." Answer slot: name the parts of the daily work that look the same as support here, in your own words; if some parts differ, say so plainly. Let the interviewer draw the conclusion | F1 is the evidence for the experience requirement and F5 is why the transfer is questioned; JD because it scores the stated requirement |
| B3 | "Tell me about a time you handled an escalation." | EXP | [grounded] | Selection scaffold: pick a time a case went beyond what you could resolve alone. It needs a named stake, what you did yourself, and where it ended up. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The ad raises escalations and F4 holds no evidence either way, so the pack supplies selection criteria, not a story; EXP because it tests what was actually yours |
| B4 | "Tell me about training the four new starters — what was your part in it?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Story-mapped on F6, with only the beats the quote states: you trained four new starters, on your refunds process, last year. Say what you did and what others did, in your own words, and keep the credit where it belongs | F6 is a quoted strength and a likely follow-up target; EXP because it tests attribution |
| B5 | "Why are you leaving energy for software, and why us?" | EXP | [generic] | Two sentences, your actual reason, in your own words. Do not invent an attraction to the product you have not verified; if you have not used it, say so plainly | Motivation consistency is scored when a background changes industry (F5); EXP because it tests whether the story holds |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — tell me about yourself and how you ended up applying." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier", "I use Freshdesk every day" and "I trained four new starters on our refunds process last year" | A three-beat arc in short messages, using the quotes as they stand: the 3 years as a customer service advisor at an energy supplier; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year." Then your own reason for applying, in your own words | The biography opener is the likeliest first question in a chat; F1, F2 and F6 supply the beats; EXP because it is about your history |
| C2 | "What do you enjoy most about helping customers?" | JD | [generic] | Pick something true and say it in a sentence or two, with one moment from your own work if one comes to mind. If none does, say so plainly and describe what you would want from the work | Casual questions about the core of the job are still scored; JD because it scores fit with the role |
| C3 | "Anything you'd like to ask us?" | JD | [generic] | Use two or three of the reverse questions below. Never answer "no, I think you've covered everything" | Rapport-style interviewers weight this slot heavily; JD because it tests interest in the actual role |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day — how was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep the quote's hedge: "around 60." Answer slot: say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words. If you do not know how it was counted, say so plainly | F3's figure is the likeliest number to be probed; EXP because it tests attribution |
| D2 | "You use Freshdesk every day — what do you actually do in it, and how does it compare to Zendesk?" | JD | [grounded] "I use Freshdesk every day" | Say in your own words what you do in it. Answer slot: the ad names Zendesk or a similar ticketing tool, so expect the comparison. If you have used Zendesk, say so; if you have not, say so plainly and stay with Freshdesk | F2 is the evidence for the tool requirement and the ad's wording makes the comparison likely; JD because it scores the stated requirement |
| D3 | "Written communication matters here. What makes a good support reply?" | JD | [grounded] "answering around 60 calls and emails a day" | Say your own standards in a few lines. Answer slot: if some of the emails in your 60 a day were yours to write, say what kind and what you aimed for; if most were calls, say so plainly and say how you would shift to writing | F3 holds thin evidence for the written-communication requirement; JD because it scores a stated requirement |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A customer says you're useless and demands a manager. You have sixty seconds." | CASE | [generic] | Pause, restate the problem, say what you can do now, and offer the handoff only if it is truly needed. Hold that position through two follow-ups, and concede only what is true, such as what you cannot promise. No claim about your past | A time-boxed hard-customer drill tests composure; CASE because it is a live problem |
| E2 | "Sixty seconds: what makes you confident you can handle escalations here?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" | Anchor on the quote at its own scope: 3 years as a customer service advisor at an energy supplier. Answer slot: if escalations were part of that work, say what kind and what you did; if they were not, or were not yours, say so plainly and say how you would approach the first one. Hold it through two follow-ups, then concede what your material does not show | F4 is thin and the ad raises it, so a pressured version is likely; JD because it scores the stated requirement |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | B2, C1, E2 |
| "experience with Zendesk or a similar ticketing tool" | D2, C1 |
| "clear written communication" | A1, A4, D3 |
| "confidence handling escalations" | A2, A3, B3, E2 |
| Software familiarity, not in the ad's list | B1, B2, B5, A5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a good first month look like for someone new to this product?" | It shows you are planning the ramp the Skeptic questions press on |
| 2 | "What kinds of issues reach escalation most often, and who owns them from there?" | It shows you take escalations seriously and gives you the real picture |
| 3 | "Which ticketing tool does the team use day to day?" | It picks up the ad's wording and lets you say how you would start |
| 4 | "How does the team review the quality of written replies?" | It ties to the written-communication requirement and shows you want feedback |
| 5 | "How are offers and onboarding handled — can the contract come from a company email address, and can I see the role on your careers page?" | It moves the offer and onboarding to channels you can check yourself |
| 6 | "What would make someone really successful in this role after three months?" | It invites the interviewer to name what they will actually measure |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has Zendesk experience | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material says Freshdesk, not Zendesk. D2's slot stays with Freshdesk |
| Has worked in software or software support | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Resolved or closed around 60 tickets a day | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day." The limit is the pack's observation: your material says calls and emails answered, not tickets or resolutions |
| Owned or designed the refunds process | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year." The limit is the pack's observation: your material says you trained them, not that you set the process |

## Sources

Provided documents: the Telegram message from Marcus Hale as you pasted it; the ad's requirements as you listed them; your background as you wrote it. No `tuesday-dossier.md` was present.

Searches sent, all refused (search permission was not granted):

- `Lumenvale Software company values` — refused
- `Lumenvale Software interview process customer support specialist` — refused
- `Lumenvale Software news strategy` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software company values` | unavailable | Would have fed published value names for VAL themes and A5; no values-style round is documented, so no cheat sheet either way |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | Would have fed loop structure and persona weights; the loop rests on your own words instead |
| 3. `Lumenvale Software news strategy` | unavailable | Would have grounded A5; it stays generic |
| 4. `{interviewer name} Lumenvale Software` | n/a | The team lead is not named, so there was no query to form |
| 5. representative `Customer Support Specialist` JD | skipped | The ad's requirements as you listed them fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full ad text → F1 to F4 become the ad's own words, and any requirement beyond the four you listed gets a row and a question
- Search access, or a pasted Lumenvale product or values page → A5 and the persona weights move from generic to grounded; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief
- The team lead's name and role → an interviewer read and a reverse question tied to their path
- Your answers to the F3 and F4 slots (emails you wrote, escalations you handled) → those rows move from discovery to grounded and the guidance can map real stories
- How much prep time you have → a prioritized schedule
- A `tuesday-dossier.md` from an earlier fit check → verified evidence and strategy constraints for the weak areas, never a prerequisite
