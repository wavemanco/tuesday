# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (name not given), on a 30-minute video call. Relationship to you not stated; this pack assumes a hiring-manager-type first interview, so persona weights are provisional until you say otherwise.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values (none detected for this loop, so unused) |
| EXP | Whether your CV claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (unused: no company research was possible this run) |
| CASE | A live problem from the role, scored on structure and reasoning |

## Fit snapshot

Requirements are quoted from the ad as you described it, or from the invite. Your evidence is quoted from your own message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Lead with the appointment book in the quote's own terms: "I ran the appointment book for four physios." The ad says calendars and your words say appointment book, so the bridge stays in yours. A CV line with nothing inspected behind it, so expect a probe, and the same sentence is the answer, held at its own scope |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material says nothing about travel, so the pack neither claims nor denies it. Answer slot: the ad names travel booking, so a probe is likely. If you have booked travel for anyone, say what and for whom, in your own words; if you have not, say so plainly, then say how you would approach it |
| F3 | "preparing documents in Word and Excel" (Word half) — the ad, as you described it | "I'm good with Word" — your message | low | [grounded] | discovery | A self-rating that shows no document. Answer slot: the ad names Word, so expect "what have you made in it". If you can name the kinds of documents you have made, say so in your own words; if you cannot, say so plainly and say how you would show your level |
| F4 | "preparing documents in Word and Excel" (Excel half) — the ad, as you described it | "okay with Excel" — your message | low | [grounded] | discovery | Keep your own word, "okay", and do not upgrade it. Answer slot: if you have built or used a spreadsheet, say what it did; if your use was light, or nothing beyond viewing one, say so plainly and say how you would get up to speed |
| F5 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your words stay at their scope: "I chased unpaid invoices." The pack's own observation is that your material says chasing unpaid invoices, not processing supplier ones. Answer slot: if any invoices you handled were ones the clinic received from suppliers, say what you did with them, in your own words; if none were, or it was not yours, say so plainly and stay with chasing unpaid invoices |
| F6 | "Remote Administrative Assistant" — the invite | none given | none | [grounded] | hard_gate | Your material does not establish whether you can work from home on the terms a remote role sets. This is a term, not experience: no wording bridges it, and this cell asks nothing of you |

## Persona table

Weights are provisional: the invite names the office manager and a 30-minute video call, and nothing else about the round.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist (5 questions) | Live mini-problems from the four listed duties: a calendar clash, a travel request, an invoice that does not match | High: a hiring-manager-type round buys capability on the listed duties, and the ad lists four | Clarify first, then structure, then answer; think aloud; ask what the company's own process is before inventing one |
| B. Skeptic (5 questions) | Quiet probing of where the material is thinnest: supplier invoices, travel, Excel | High: F2 to F5 carry no or thin evidence, and a hiring-manager-type round derisks gaps | Rehearse B1 until it is boring; bridge only from the quotes in F1 and F5; where the material is silent, say so plainly and give your plan |
| C. Conversational (4 questions) | A friendly opener, motivation, a story prompt; feels unscored | Medium: a 30-minute call leaves little room for more than a short biography and motivation | A 90-second arc built only from the quotes in C1; treat casual questions as scored |
| D. Data-Driven Prober (2 questions) | Asks how the appointment book and the invoice chasing actually worked | Low to medium: it only needs a CV read line by line, and your lines are few | Describe what you did in your own words; where you do not know how something was counted or what came of it, say so plainly |
| E. Peer Evaluator (2 questions) | Collaboration and handoff, especially remotely | Low: the office manager may also be a day-to-day colleague, which your note does not say | Say what you would bring to their load, and propose how work is handed over rather than assuming their process |

## Question banks

Highest-ROI prep in the pack: B1, the supplier-invoice question. It is the most predictable objection and it points at exactly where F5's evidence is thinnest.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people whose calendars you manage both need the same Thursday-morning slot with the same client, and neither knows the other asked. What do you do?" | CASE | [generic] | Structure aloud: what is fixed and what can move, who decides priority (ask rather than assume), how you confirm with each person, and how you record the outcome. The question needs no claim about your past, so the guidance makes none | The ad's "managing calendars" (F1) asked as a decision rather than a record; CASE because it scores structure |
| A2 | "A manager asks at 4pm for travel to another city, arriving the night before, within a budget. What do you ask first, and what do you do?" | CASE | [generic] | Clarify first: dates and times, budget, approvals, preferences, who needs the itinerary. Then options, a confirmation back to the manager, and a written itinerary. No claim about your past | The ad's "booking travel" (F2) has no evidence behind it, so this rehearses the method an interviewer can score without needing a past |
| A3 | "A supplier invoice arrives that does not match the purchase order. What do you do before anything is paid?" | CASE | [generic] | Say you would hold it, check it against what was ordered and received, ask the person who ordered it and the supplier, record what you found, and follow the company's approval route. Ask what that route is rather than guessing it | The ad's "processing supplier invoices" (F5); CASE so the answer rests on method, not on a past you do not carry in your quotes |
| A4 | "I need a one-page summary of a list of supplier invoices in Excel by Friday. How do you set it up, and what do you check before it goes to me?" | CASE | [generic] | Ask what the reader needs on the page, then describe your layout and your checks in plain words at your own level. Do not name functions or features you have not used. If you would look something up, say so | The Excel half of the ad's "preparing documents in Word and Excel" (F4); CASE so level is shown by method |
| A5 | "Someone sends you rough meeting notes at noon and wants a clean one-page summary in Word by end of day. How do you go about it?" | CASE | [generic] | Ask who it is for and what they need to decide or do, then structure, draft, check names and actions, and send with a note on anything unclear. No claim about your past | The Word half of the ad's "preparing documents in Word and Excel" (F3) |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see supplier invoices in your background. How would you handle that part of the role?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I chased unpaid invoices." Answer slot: if any invoices you handled were ones the clinic received from suppliers, say what you did with them, in your own words; if none were, or it was not yours, say so plainly and stay with chasing unpaid invoices. Then say how you would learn the company's process, as a plan and never as a past. Hold through two follow-ups by returning to that sentence, never by adding to it | F5 is where the ad presses hardest and the evidence is thinnest; JD because it scores a stated duty, asked in the Skeptic stem that points at a gap |
| B2 | "How much of the appointment book was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold: "I ran the appointment book for four physios." Answer slot: if any part of how it was run was set by someone else, say which part, plainly, and keep to what you ran; if all of it was yours, say that and stop. Hold through two follow-ups, concede only what is true and specific, and do not fold on the core sentence to ease the moment | F1's attribution probe; EXP because it tests what was yours, asked as a Pressure-style stem inside the Skeptic bank |
| B3 | "You say you're okay with Excel. What would you need to look up in this job?" | JD | [grounded] "okay with Excel" | Keep "okay with Excel" in your own words. Answer slot: name what you have actually done in a spreadsheet, if anything; if your use was light, say so plainly. Then give the plan: what you would learn first and how. Never upgrade "okay" to a stronger word | F4; the interviewer's premise is your own word, so the honest answer is already in hand and only needs rehearsing |
| B4 | "I don't see travel booking in your background. How would you handle it?" | JD | [grounded] | Answer slot: if you have booked travel for anyone, say what and for whom, in your own words; if you have not, say so plainly, then walk through your A2 method as a plan. Nothing here is a past you have not stated | F2 is silent in your material; JD because it scores a stated duty |
| B5 | "Why would we choose someone from a clinic reception over someone from an office admin background?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Hold at the quote's scope: "I spent two years as a receptionist at a physiotherapy clinic." Then connect only to what the quotes in F1 and F5 state, and concede plainly what the ad lists that your material does not show. Do not claim an office admin background | The background-mismatch probe a hiring-manager-type round predicts; EXP because it tests whether you can describe your own history precisely |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios"; "chased unpaid invoices" | A 90-second arc with only the beats these sentences state: the role and the two years, the appointment book for four physios, chasing unpaid invoices. Then one sentence of your own on why this job. Tell it in your own words | The biography question is the most certain question of the call and the casual register hides that it is scored |
| C2 | "Why a remote role?" | JD | [grounded] | Answer slot: give your own real reason in your own words, short and true; this pack does not supply one. If working remotely is new to you, say so plainly | The invite's "Remote" (F6) is a term of the role, and motivation for it is likely in a short call |
| C3 | "Tell me about a time you had to keep several people's plans straight at once." | EXP | [grounded] "I ran the appointment book for four physios" | Story-map on the quote: the book and the four physios are the beats it states. Tell them in your own words. If no specific time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | An open prompt whose theme comes from the ad's "managing calendars" (F1) |
| C4 | "What are you hoping to get from a role like this?" | JD | [generic] | Answer slot: your own reason, in your own words, in two or three sentences. Keep it about the work in the ad, not about the company, which this pack could not research | A standard motivation check that a short call usually keeps |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the appointment book worked day to day." | EXP | [grounded] "I ran the appointment book for four physios" | Describe what you did with it, in your own words, at the scope of the quote. Answer slot: if a part of how it worked was not yours, or there was no such part, say so plainly and stay with the book you ran | F1; EXP because it tests that you can describe your own work without borrowing a process |
| D2 | "How did you chase the unpaid invoices, and what came of it?" | EXP | [grounded] "chased unpaid invoices" | Say what you did to chase them, in your own words. Answer slot: if you know what came of it, say so as you know it; if you do not know how it was tracked or what was recovered, say that plainly. Do not add a figure | F5; EXP because "what came of it" is where an unrecorded outcome would be tested |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Working remotely, how would you keep me informed about what is done, what is waiting and what is stuck?" | CASE | [generic] | Propose a simple rhythm and ask what the office manager prefers, rather than assuming their process: when you report, in what form, and how you flag a block early. No claim about your past | The invite's "Remote" (F6) turns on how work is handed over |
| E2 | "A colleague asks you to book something you think breaks the company's approval rules. What do you do?" | CASE | [generic] | Ask what the rule is, check it, tell the colleague what you found, and escalate to the person who owns the rule if it is not settled. No claim about your past | The ad's travel and invoice duties (F2, F5) both involve approvals; CASE because it asks about no past |

### Requirement coverage

| Requirement | Questions covering it |
|---|---|
| "managing calendars" | A1, B2, C3, D1 |
| "booking travel" | A2, B4, E2 |
| "preparing documents in Word and Excel" | A4, A5, B3 |
| "processing supplier invoices" | A3, B1, D2, E2 |
| "Remote Administrative Assistant" | C2, E1; the gate (F6) itself is not a question for guidance |

## Reverse questions

Ask at least three of these; never answer "I think you've covered everything".

| # | Question | Why it lands |
|---|---|---|
| R1 | "When two people need the same slot, who decides, and how do you want to hear about it?" | It shows you would ask before deciding, which is what A1 scores |
| R2 | "What does a supplier invoice's path look like from arrival to payment, and which steps would be mine?" | It draws out what "processing" means in this job and answers B1 from their side |
| R3 | "How would work be handed over and checked when I am remote?" | It signals you have thought about the remote gate (F6) and matches E1 |
| R4 | "Which equipment does the company supply, who buys it, and when?" | A calm, practical question that gets a clear answer on who pays for what; a vague or evasive answer tells you something, and a clear one is useful to hear |
| R5 | "Which Word and Excel tasks come up most in the first month?" | It lets you gauge the level the job needs against F3 and F4 |
| R6 | "What would a good first month look like?" | A standard question that interviewers weigh as a preparation signal |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for a team or senior people | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation, not words for you: your material says the appointment book for four physios, not calendars for a wider group |
| Processed supplier invoices, or worked in accounts payable | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." Your material says chasing unpaid invoices, not processing supplier ones; the slots in B1 and D2 stay inside what you chased |
| Advanced Excel skills | Inflated form of F4 | "okay with Excel", in your word and no stronger |
| Expert-level Word | Inflated form of F3 | "I'm good with Word", in your word and no stronger |

## Sources

Provided: the invite email you pasted, your description of the ad's duties, and your own background note. The invite describes one session (a 30-minute video call with the office manager) and names no values-style round, so no values cheat sheet is built.

Searches sent: "Brennock Facilities Ltd values" (refused); "Brennock Facilities Ltd interview process administrative assistant" (refused). No pages were fetched.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | The call was refused; it would have moved the values cheat sheet, which is not built |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | The call was refused; it would have confirmed the loop beyond the single call the invite names |
| 3. `Brennock Facilities Ltd strategy` / recent news | unavailable | Search was refused during this run; it would have moved a CO bank, which is not built |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Remote Administrative Assistant` JD | skipped | The four duties you quoted from the ad fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → the fit rows move from your description of the ad to its exact words, and the JD-tagged questions are grounded in them
- The office manager's name and role → an interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- Whether the office manager is your future manager or a peer → persona weights and every bank reweighted
- A spreadsheet or Word document you made and could show → F3 and F4 could move from low confidence and the Excel and Word questions could be grounded in a real example
- Any invoice or travel work you did, even small → F2 and F5 move from answer slots to story maps
- Search access → company values, loop confirmation and any recent news, which would add the grounding and CO questions this pack lacks
- A `tuesday-dossier.md` from an earlier session → verified evidence and any prohibited claims carried into this pack
