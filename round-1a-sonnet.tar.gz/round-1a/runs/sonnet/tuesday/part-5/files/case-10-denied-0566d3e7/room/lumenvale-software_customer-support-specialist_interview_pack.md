# Interview pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: the support team lead, name not given. Format, per the invite: a text chat on Telegram. Relationship assumed: the person you would report to, so a hiring-manager-style round. No company research ran in this build, so nothing below about Lumenvale comes from outside your message.

## How to use this pack

- Personas are how a question is asked. Types are what it is scoring.
- Type key: VAL is values alignment through past behaviour. EXP is a deep-dive into what your own material says you did. JD is a question taken from the role's stated requirements. CO is company and strategy knowledge. CASE is a live problem from the role.
- Guidance is scaffolding, not a script. Because the round is typed, rehearse in short messages: answer first, then one or two lines of support.
- An answer slot is an instruction for the interview. Answer it from your own experience, or say plainly that the practice was not yours.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you described it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe on the job itself. Lead with the quote in its own terms: three years, customer service advisor, an energy supplier. Keep your own job title rather than switching to the ad's wording |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | The quote reaches the ad's "similar ticketing tool" in other terms, so say it as you wrote it: "I use Freshdesk every day." Your material says Freshdesk, not Zendesk. Answer slot: the ad names Zendesk, so a probe on it is likely. If you have used Zendesk, say where and how, in your own words; if you have not, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — job ad, as you described it | "answering around 60 calls and emails a day" — your message | medium | [grounded] | transferability | The quote carries volume across calls and emails together, not how clear the writing was, and it stays at that scope: "answering around 60 calls and emails a day." Answer slot: this round is itself typed, so your replies in the chat are read as writing. If you have a way of checking that a reply is clear, say what it is, in your own words; if you have no set method, say so plainly and return to the answering you do each day |
| F4 | "confidence handling escalations" — job ad, as you described it | none given | none | [grounded] | discovery | Your material does not show escalations either way, and the pack adds none. Answer slot: the ad's escalations line makes a probe likely. If you have handled an escalation, say what it was and what you did, in your own words; if you have not, or it was not yours, say so plainly and say how you would handle one |
| F5 | Software-company experience (not in the ad as you described it; you raised it) | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | Helping colleagues learn the work (not in the ad as you described it; a strength your material carries) | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | No ad requirement behind it, so it supports other answers rather than a row of its own. Keep it at its own scope: four new starters, the refunds process, last year |

## Persona table

The loop is established by your invite: one text chat with the support team lead. No other round is named, so no archetype fallback is used and no values-style round is detected.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live support scenarios you answer in writing: an angry repeat contact, an out-of-policy request, queue order | Highest. The hiring-manager prior in the persona model is Case plus Skeptic, and the role is the live handling of such scenarios | Clarify first, then structure: what you would ask, what you would do now, what you would pass on, what you would tell the customer. Think aloud in short lines |
| B. Skeptic | Quiet, persistent probing of the software gap, the Zendesk line and escalations | High. F5 is a gap you stated, F2 and F4 are the ad's named items with thin or no evidence | Rehearse B1 until it is boring. Bridge only from what you stated, say the limit plainly, then give a concrete plan |
| C. Conversational | A friendly opener, "walk me through the journey", casual questions about the day | Medium. A messaging-app chat leans informal, and casual questions are still scored | A short arc in the quotes' terms, kept to what you did; never answer "no, I think you've covered it" to the reverse-question slot |
| D. Data-Driven Prober | Reads your lines closely and asks how figures were counted | Medium. Your material carries two figures: around 60 calls and emails a day, and four new starters | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| E. Values / Behavioral | "Tell me about a time…" prompts | Lower. No values round is documented in your invite and no published values were read | Pick a specific moment with a stake and a decision; where none comes to mind, say so |
| F. Pressure | A time-boxed "why you" challenge, "how much of that was you" | Lower. Nothing in the invite signals time-boxing, but the software gap invites one challenge | Pause, restate, hold through two follow-ups, concede specifically |

Peer Evaluator is not weighted: the team lead is assumed to be a manager-type interviewer. If the lead turns out to be a peer, say so and the banks are reweighted.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same unresolved issue, and they are clearly angry. Write me your reply." | CASE | [generic] | Structure the reply: acknowledge the repeat, restate the issue in your own words, say what you will do now, say what you need from them, and say when they will hear back. The question needs no claim about your past, so the guidance makes none | The role is written support, so a live reply doubles as the writing sample F3 asks for. CASE because it is scored on structure |
| A2 | "A customer wants a refund outside policy and asks for a manager. What do you do, and what do you pass up the chain with it?" | CASE | [generic] | Structure it: what you would check first, what is yours to decide, what you would hand over and with what detail, and what you tell the customer meanwhile. No claim about your past | The ad's escalations line (F4) as a decision. CASE because it asks for reasoning on a live problem |
| A3 | "Ten tickets arrive at once: a customer who cannot log in, a billing query, a feature request. How do you order them?" | CASE | [generic] | Ask what priority rules the team already uses before proposing any. Then offer principles, not a claimed method: who is blocked, who is waiting longest, what is quick to close. No claim about your past | Tests clarify-before-structure in a ticketing context (F2's tool line). CASE because the answer is reasoning |
| A4 | "When you open a ticket for someone else to pick up, what do you want written in it?" | JD | [generic] | A principle answer: the problem in the customer's words, what has been tried, what is still needed, and the next step and owner. Say it as what you would want, not as something you did | Covers the ticketing-tool requirement (F2) at the level of habit. JD because it scores the stated tool requirement |
| A5 | "A customer writes only: your software doesn't work. What do you ask them?" | CASE | [generic] | Ask what they were doing, what they expected, what happened, when it started, and whether they can send a screenshot. Keep it to questions; no claim about your past | Speaks to the software-context gap (F5) without asking you to claim any. CASE because it is a live diagnosis |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked for a software company. What do you expect to be the hardest part of the switch?" | JD | [grounded] "I've never worked for a software company" "3 years as a customer service advisor at an energy supplier" "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Say the limit first and plainly: "I haven't worked for a software company." Then hold only what the quotes carry: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Then a plan, as a plan: what you would learn first, who you would ask, how you would check you had understood. Follow-ups to rehearse. If asked how fast you would be up to speed, concede specifically: you cannot give a number before seeing the product, and you can say how you would start. If asked what you would do when you cannot work a problem out, answer with the ask-and-hand-over plan. If asked why not stay in your own industry, give your own reason, in your own words | F5 is the single most predictable objection and the one you stated yourself. JD because it scores whether you can do the listed job, including its gap |
| B2 | "The ad asks for Zendesk or something similar. What have you used?" | JD | [grounded] "I use Freshdesk every day" | Say it as written: "I use Freshdesk every day." Answer slot: the ad names Zendesk, so expect a probe on it. If you have used Zendesk, say where and how, in your own words; if you have not, say so plainly and stay with Freshdesk | F2 is the ad's named tool against a different tool in your material. JD because it scores the stated requirement |
| B3 | "I don't see escalations in your background. How would you handle the escalations in this role?" | JD | [grounded] | Answer slot: if you have handled an escalation, say what it was and what you did, in your own words; if you have not, or it was not yours, say so plainly. Then give how you would handle one, as a plan: what you gather, who you hand it to, what the customer is told. No past is supplied here | F4 is silent in your material, and the ad names it. JD because it scores a listed requirement |
| B4 | "Why customer support at a software company, and why now?" | JD | [generic] | Selection scaffold: choose the reasons that are actually yours, a reason about the work and a reason about the move, and say them in your own words. If a reason does not come easily, say so plainly and give the nearest true one | Motivation consistency is what a Skeptic scores; F5 makes the question sharper. JD because it asks why this role |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey. How did you get to where you are, and what are you looking for next?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" "I use Freshdesk every day" "I trained four new starters on our refunds process last year" | A short arc of three beats, each stated by a quote: three years as a customer service advisor at an energy supplier, Freshdesk every day, training four new starters on the refunds process last year. Then what you are looking for next, which is yours to say in your own words | F1 and F6 supply the arc. EXP because it tests your own account of your work |
| C2 | "What does a normal day look like for you right now?" | EXP | [grounded] "answering around 60 calls and emails a day" "I use Freshdesk every day" | Describe the day in the quotes' terms: answering around 60 calls and emails a day, in Freshdesk every day. Anything else in your day is yours to add, in your own words, and only what you actually do | F1 and F2 in casual form. EXP because it tests what the day really contains |
| C3 | "This job is all writing. How do you make sure a reply is clear?" | JD | [grounded] "answering around 60 calls and emails a day" | The quote carries volume, not method. Answer slot: if you have a way of checking a reply is clear, say what it is, in your own words; if you have no set method, say so plainly and return to the answering you do each day. Your replies in this chat are part of the answer | F3 is the ad's writing requirement. JD because it scores the stated requirement |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You say around 60 calls and emails a day. How was that counted, and how many of them were emails?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep the figure with its noun: around 60 calls and emails a day, together. Answer slot: say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words; "I don't know how that was counted" is an honest branch | F1's figure is a prober's first target. EXP because it tests attribution and the weakest assumption |
| D2 | "You trained four new starters on the refunds process. What did that involve?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | The sentence carries four new starters, the refunds process and last year; say those in your own words. Beyond them this pack has no material, so describe only what you actually did, and where something was not yours, say so | F6 is a figure and a responsibility in one line. EXP because it tests what you actually did |
| D3 | "What do you do in Freshdesk on a typical day?" | EXP | [grounded] "I use Freshdesk every day" | Start from the sentence: "I use Freshdesk every day." Answer slot: the ad's ticketing-tool line makes a probe on what you do in it likely. Say which parts you use, in your own words; if your use is narrower than the probe assumes, say so plainly and return to using it every day | F2 at depth. EXP because it tests your real use of the tool |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you put a customer ahead of an internal metric." | VAL | [generic] | Selection scaffold: pick a moment with a named stake, a decision that was yours, and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem, since no published values were read. VAL because it scores behaviour |
| E2 | "Tell me about a time you delivered an unpopular truth to someone more senior." | VAL | [generic] | Selection scaffold: choose a time the hard truth actually landed and the relationship held afterwards. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem. VAL because it scores behaviour under pressure |
| E3 | "Tell me about a time you stayed calm with a customer who was escalating." | VAL | [grounded] | Raised by the ad's escalations line (F4). Selection scaffold: choose a specific contact, what the customer wanted, what you decided, and how it ended. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 has no quote, so no story is mapped. VAL because it scores behaviour |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who already works in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" "I use Freshdesk every day" "I've never worked for a software company" | Pause and restate the question. Hold only what the quotes carry: three years as a customer service advisor at an energy supplier, Freshdesk every day. Hold through two follow-ups by returning to them, never by adding to them. Then concede specifically: "I haven't worked for a software company," with your plan | F5 makes a "why you" challenge likely. JD because it scores fit to the role |
| F2 | "That training: how much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the sentence as written. Answer slot: if any of it was shared with someone else, say who did which part; if it was all yours, say so plainly and return to the sentence. Concede only what is true, specifically | F6 is the line a Pressure interviewer tests for attribution. EXP because it scores precise ownership |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | C1, C2, F1 |
| "experience with Zendesk or a similar ticketing tool" | A4, B2, D3 |
| "clear written communication" | A1, C3 |
| "confidence handling escalations" | A2, B3, E3 |
| Software-company experience (F5) | A5, B1, B4, F1 |
| Helping colleagues learn the work (F6) | D2, F2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the first month look like for someone new on the team?" | Shows you are planning your ramp, which is the thing a software-company switch is judged on |
| R2 | "Which ticketing tool does the team use, and how does an escalation move through it?" | Closes the Zendesk question from the other side and shows you think about hand-offs |
| R3 | "How do new starters learn the product?" | Puts your learning plan (B1) into the conversation |
| R4 | "What does good look like in the first three months?" | Gives you a concrete bar to rehearse against |
| R5 | "How are shifts and hours arranged across the team?" | A practical remote-work question that also shows you have thought about the job day to day |
| R6 | "After this chat, how do the next steps work: who sends the offer and contract, and from which company address or system?" | Shows seriousness and gives you something you can check independently |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experienced with Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material says Freshdesk, not Zendesk |
| Ran or led a refunds training programme | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your material says four new starters trained on the refunds process, not a programme |
| Handled around 60 emails or tickets a day | Inflated form of F3 | The quote with its noun kept: "answering around 60 calls and emails a day." The limit is the pack's observation: the figure covers calls and emails together |
| The volume of your replies shows your writing is clear | Inflated form of F3 | F3's quote at its own scope: it carries volume, not clarity |
| Has supported software customers or worked at a software company | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." No slot |

## Sources

Provided documents: the Telegram invite you pasted, and your message giving the ad's four requirements and your background. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, all refused (the host did not grant search permission):

- "Lumenvale Software company values" — refused
- "Lumenvale Software interview process customer support specialist" — refused
- "Lumenvale Software news strategy" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Every call was refused. It would have fed a values cheat sheet if a values round were documented; none is, so VAL questions use persona stems only |
| 2. Lumenvale Software interview process, customer support | unavailable | Every call was refused. It would have fed persona weights; they rest on your invite's one-chat description and the hiring-manager prior |
| 3. Lumenvale Software strategy and news | unavailable | Every call was refused. It would have fed a CO question grounded in current strategy; the bank has no CO question |
| 4. Interviewer name and company | n/a | The support team lead is not named, so there was no query to form; there is no interviewer read |
| 5. Representative Customer Support Specialist JD | skipped | Your four requirement lines fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full ad text → the four requirement rows become verbatim `[grounded]` quotes, and any further requirement in the ad gets a question
- The support team lead's name and role → an interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- The recruiter's guidance on the chat (length, topics, any task) → coverage of any pre-declared exercise
- Search access, and optionally a deeper research pass of up to 6 more searches and 2 more fetches, several more minutes → target rows 1 to 3 move from unavailable, a CO question grounded in Lumenvale's current strategy, and a values cheat sheet if a values round turns out to be documented
- An escalation you have actually handled, in your own words → F4 gets a quote, and B3 and E3 become story-mapped
- Any Zendesk use, in your own words → F2 moves from a slot to a quote
- Reply samples with customer details removed, or QA or satisfaction scores → F3 moves from medium toward high
- A tuesday-dossier.md from an earlier session → verified evidence and the objection to put first
