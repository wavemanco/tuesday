# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Panel interview, 45 minutes, Thursday. Panel: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). Relationship: principal as hiring decision-maker, two prospective teammates.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did. A line in quotation marks inside a Provenance cell is a sentence you wrote; guidance rests on those sentences and on nothing else.

| Type | What it tests |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs, not generic virtue |
| EXP | Whether your CV's claims survive scrutiny; what was actually you |
| JD | The stated job, including its gaps |
| CO | Homework on the district and its current plans |
| CASE | A live classroom problem, structured aloud |

Question IDs run by persona (A to E, then G and H) so that fit-snapshot rows keep F1 to F9 to themselves.

## Prep triage

Sized to the days before Thursday; everything else is insurance.

1. A1 and H1, the objection the pack expects the panel to raise (the highest-ROI prep in the pack). Say the plain acknowledgment aloud until it is boring.
2. G1, your opening arc, spoken in about 90 seconds.
3. A3, H2 and D3, the curriculum move: your part, at its exact scope.
4. A4 and the reverse questions in section 11.

## Fit snapshot

Requirements come from three named places: the invite, the district's own pages, and a representative fourth-grade posting that is not this district's (rows marked `[inferred]`). Evidence is your own sentences only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate, and your sentence shows it met in the invite's terms. Nothing has been inspected behind it here, so keep your licence record to hand; checking it is for you and the district. Say it in the quote's own terms |
| F2 | "Fourth Grade Teacher" — invite | "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I've never taught fourth grade" — your message | medium | [grounded] | transferability | Third grade is adjacent work, and you have stated the fourth-grade absence yourself. Words: "I've never taught fourth grade. I taught third grade for six years at a public elementary school in Joliet." Answer slot: if you can name what from those six years you would bring to fourth grade, say it in your own words; if you cannot, say so plainly and say how you would learn the grade |
| F3 | "Panels ask about reading instruction" — district hiring page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | presentation | Both quotes reach reading instruction, from the curriculum side and the club side. Lead with them in their own terms and keep each at its own scope: the grade level's move, and the club. Your material says the move and the club, not what happened in either. Answer slot: if you ran parts of either, say which, in your own words; if a part was not yours, say so plainly and return to the quote |
| F4 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board listing (a representative posting, not this district's) | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | The quote shows the grade, not the subjects. Answer slot: say which of those subjects you taught across the six years, in your own words; if you taught some and not others, or shared some with a partner teacher, say so plainly |
| F5 | "differentiate instruction using assessment data" — K12 Jobs Board listing | none given | none | [inferred] | discovery | Nothing in the material shows it either way. Answer slot: if you have used assessment results to change what you taught, say what and how, in your own words; if not, or it was not yours to decide, say so plainly and say what you would want to learn |
| F6 | "keep clear classroom routines" — K12 Jobs Board listing | none given | none | [inferred] | discovery | Nothing in the material shows it either way. Answer slot: if you set routines for your class, name one and how it worked, in your own words; if routines were set for you, or there were none you can name, say so plainly |
| F7 | "communicate regularly with families" — K12 Jobs Board listing | "I write a weekly email to families." — your CV | medium | [inferred] | none | The quote already reaches the requirement in role-relevant terms. Lead with it as written: a weekly email, to families |
| F8 | "Families Are Partners: each teacher speaks with every family each term." — district beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | discovery | An email and speaking with each family are not the same thing, and the quote does not show whether you also speak with families. Answer slot: if you do, say how and how often, in your own words; if the email is the whole of it, or it was not a set practice, say so plainly and return to the email |
| F9 | "work with the grade-level team" — K12 Jobs Board listing | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | discovery | The quote touches working with a grade level without showing how the work was shared. Answer slot: say which parts were yours, in your own words; if a part was set by someone else, or there was no such step, say so plainly and return to the quote |

## Reading the interviewer

Public professional footprint only. Two of the three panelists are unnamed, so only the principal is read.

| Fact | Source | What it may mean for you | Provenance |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022 | Illinois principals forum speaker page | The decision-maker for the building | [grounded] |
| Nine years as a reading specialist before that | Same page | Reading questions may run deeper than a general principal's; rehearse F3 and the curriculum rows to the second follow-up | [inferred] |
| 2025 forum talk "Small Groups, Big Readers", covering weekly reading conferences in grades 3 to 5 | Same page | Reading practice is a likely theme; the reverse question R2 uses it | [inferred] |

Mirror opportunity: reading is a shared professional subject. Your side of it is your own sentence, "I've run the after-school reading club for the last two years." (F3). Nothing in your material says you hold reading conferences or work in small groups, so do not offer either as shared ground.

## Persona table

Weights come from three passes: relationship priors (the principal reads as a hiring manager, the two teammates as peers, a panel blends each member's top two), then the principal's footprint, then the loop. The district's hiring page `[grounded]` documents one 45-minute building panel of the principal and two grade-level teachers, asking about reading instruction, classroom routines and family work.

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| A. Skeptic (5 questions) | The principal quietly probes the fourth-grade gap and why you are moving | Highest: hiring-manager prior, and F2 holds your stated absence | Rehearse the one predictable objection until it is boring; bridge only from your quoted third-grade years; add a plan, not a past |
| B. Peer Evaluator (4) | Teammates ask how you plan with others and what you would need from them | High: two of three panelists are teammates | Reciprocity framing; offer what you quoted, ask about their planning rather than pretending to know it |
| C. Case/Strategist (3) | Classroom scenarios in the principal's register | Medium: the panel asks about routines and family work, and the district's literacy plan makes reading cases natural | Clarify, objective, approach, how you would tell it is working, risks; think aloud |
| D. Data-Driven Prober (3) | Teammates press on how you knew the curriculum worked and how you use assessment results | Medium: the district's third belief names assessments | Say plainly what you do and do not know; name the assumption you would defend least |
| E. Values/Behavioral (3) | Questions mapped to the district's three published beliefs | Medium: the beliefs page says they guide every hire, but the hiring page names no values round, so none is detected and there is no values cheat sheet; VAL questions are themed on the beliefs as published | Choose real stories; where none comes to mind, say so, then give the nearest thing you quoted |
| G. Conversational (2) | The opener and the friendly asides | Medium `[generic]`: an opening biography question is a standard slot, and casual questions are still scored | A 90-second arc from your own sentences; never answer "any questions?" with "no" |
| H. Pressure (2) | A time-boxed challenge to your fit | Low: a school panel is an unlikely home for stress tactics, but a blunt "why you" is common | Pause, restate, hold through two follow-ups, concede only what is true |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see fourth grade in your background. How would you handle this classroom in your first month?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet." | The highest-ROI rehearsal in this pack. Name the limit before they press it: "I've never taught fourth grade." Then the years you did teach, in the quote's terms: "I taught third grade for six years at a public elementary school in Joliet." Answer slot: expect a follow-up on how you would get up to speed; say what you would find out first and from whom, as a plan; if you have already begun, say what, in your own words; if you have not, say so plainly. Hold through two follow-ups by returning to the six years; concede that the grade is new to you, and add nothing you did not say | F2 is the widest gap in the snapshot and the one this panel will name; JD because it scores the title's grade level, delivered in the Skeptic's register |
| A2 | "Which part of this job would be hardest for you on day one?" | JD | [inferred] | Choose one real item from the rows where your material is silent (F4, F5, F6) and name the one you would actually find hardest, then say how you would close it, as a plan. If none comes to mind, say so plainly and name the first thing you would ask the team. The guidance makes no claim about your past | Derived from the typical posting's duties, so `[inferred]`; the Skeptic's standard second probe after A1 |
| A3 | "You led your grade level's move to a new reading curriculum. What was your part?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead." | Story-mapped on F3: the move, your grade level, 2024, and "led", at exactly that scope: "I led our grade level's move to a new reading curriculum in 2024." Keep it beside the other sentence you wrote, "I've never been a team lead", rather than blending them. Answer slot: expect a follow-up on which parts were yours; say which, in your own words; if a part was not yours, or there was no such step, say so plainly and return to the quote | F3 and F9 hold the strongest sentence in your material, and a prober tests attribution against the stated limit; EXP because it tests what was actually you |
| A4 | "Why fourth grade, and why Halvering?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I've run the after-school reading club for the last two years."; "I write a weekly email to families." | Your material gives no reason, so the reason is an answer slot: state the real reason for moving up a grade, in your own words; if there is no single reason, say so plainly. For Halvering you may point to what the district publishes, the beliefs Every Child a Reader and Families Are Partners and the board's 2026–2029 literacy plan, and connect only to what you wrote: the reading club and the weekly email to families | Motivation consistency is the Skeptic's second line; JD because it asks why this job; the district facts come from the researched pages, listed in Sources |
| A5 | "This position requires an Illinois Professional Educator License with an elementary endorsement. Can you confirm yours?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Short and flat, in the quote's own terms: "I hold an Illinois Professional Educator License with an Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029." Have your licence record to hand; checking it is the district's job and yours | F1 is the invite's stated requirement, shown met by your sentence; a knockout check is asked early and costs nothing to rehearse |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell us about a time you disagreed with a colleague about how to do something, and how it ended." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Selection scaffold, because no sentence of yours carries a disagreement: pick a real time with a named disagreement, what you did, and a working relationship that stayed intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the grade-level move you led, at its own scope, or how you would handle it | Peers price what working beside you will cost; the theme is the Peer Evaluator's own stem; F9 is why the fallback is the move |
| B2 | "What would you need from us in your first month, and what would you bring to the team?" | JD | [grounded] "I've run the after-school reading club for the last two years."; "I write a weekly email to families." | Reciprocity: what you bring is what you wrote, in those words, offered as things you would gladly walk through with them. What you need goes as questions, not claims: how the team plans together, where its seams sit. Do not describe their planning as if you knew it | The peer's own stem; scores partnership fit and whether you add load or reduce it |
| B3 | "Tell us about the weekly email you write to families." | EXP | [grounded] "I write a weekly email to families." | Story-mapped on F7: the email, its weekly rhythm, its audience, told at that scope. Answer slot: the district's belief that each teacher speaks with every family each term makes a probe on contact beyond the email likely; if you also speak with families, say how and how often, in your own words; if the email is the whole of it, or it was not a set practice, say so plainly and return to the email | F7 and F8; EXP because it tests the sentence, and the belief is the reason a peer would push past it |
| B4 | "The district adopts a new grades 3–5 reading curriculum from fall 2027. How would you help our team through it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Name only what you wrote: "I led our grade level's move to a new reading curriculum in 2024." Then ask what the rollout looks like before proposing anything; a plan can be offered as the questions you would ask first. Answer slot: if any part of your 2024 move would carry over, say which, in your own words; if you cannot name one, say so plainly | The board's August 2026 literacy plan is the current-strategy hook (see Sources), and F3 and F9 are the only evidence you have near it |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student joins your fourth-grade class reading well below the others. What do you do in the first two weeks?" | CASE | [generic] | Structure it aloud: what you would ask first and of whom, your objective, the approach, how you would tell it is working, what could go wrong, and when the family hears from you. Challenge one premise politely: below the others by what measure? The question needs no claim about your past, so the guidance makes none | Reading is the district's first belief and the principal's background; `[generic]` because it is a problem pattern, not a fact about this employer |
| C2 | "It's week three and transitions in your class are slow and noisy. What do you look at, and what do you change?" | CASE | [inferred] | Same structure: clarify what you are seeing and when, the objective, the approach, how you would know it worked, the risk. No claim about your past | F6 is silent in your material; the posting's "keep clear classroom routines" and the panel's stated routines topic make a case likely |
| C3 | "A parent writes that they are worried their child is falling behind in reading. Walk us through your reply and what happens next." | CASE | [grounded] | Structure: acknowledge, clarify what the parent is seeing, say what you would look at before answering, and say when and how you will speak with them. The district's published belief is that each teacher speaks with every family each term; you may refer to it as the district's belief. No claim about your past | Joins reading and family work, the panel's two named topics; the belief is the district's published wording |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How do you use assessment results to decide what to teach next?" | JD | [grounded] | Answer slot: say how, in your own words; if you did not use results that way, or it was not yours to decide, say so plainly and say what you would want to learn. You may quote the district's own published words, "assessments inform teaching and never replace it", as the standard you are asking about, never as something you already do | F5 is silent in your material; the third belief names assessments and the posting names assessment data |
| D2 | "Which subjects did you teach in third grade, and how did you plan across them?" | EXP | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Start from the quote. Answer slot: a typical posting lists reading, writing, math, science and social studies; say which you taught, in your own words; if you taught some and not others, or did not plan across them, say so plainly and return to the six years | F4; the question's premise is the typical posting's, and the guidance does not adopt it |
| D3 | "How did your grade level know the new reading curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if the grade level looked at anything, say what, and what part was yours, in your own words; if nothing formal was looked at, or it was not yours, say so plainly and return to "I led our grade level's move to a new reading curriculum in 2024." The weakest-assumption move: say plainly what you do not know about how it was judged | F3 and F9; the figure here is a year, and the probe is how its success was told |

### E. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Every Child a Reader: tell us about a time a student in your class was not reading at the level you hoped, and what changed." | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I've run the after-school reading club for the last two years." | Selection scaffold, because no sentence of yours carries such a story: choose a real student from your six years, with a named need, what you tried, what honestly changed or did not, and your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the reading club, at its own scope, or how you would handle it | The district's first published belief; the beliefs page is the raising source |
| E2 | "Families Are Partners: tell us about a time you worked with a family who was hard to reach." | VAL | [grounded] "I write a weekly email to families." | Selection scaffold: a real family, what you tried, what the result honestly was, your part. If none comes to mind, say so plainly, then give the nearest thing your material carries, the weekly email, at its own scope, or how you would handle it | The second published belief; F8 shows the email does not settle it |
| E3 | "Teach for Tomorrow, Not for the Test: tell us about a teaching choice you made that a test would not have rewarded." | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024" | Selection scaffold: a real choice from your six years, what the alternative was, why you chose as you did, and what happened. If none comes to mind, say so plainly, then give the nearest thing your material carries, the curriculum move, at its own scope, or how you would handle it | The third published belief |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk us through your journey to this point." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years."; "I write a weekly email to families." | A 90-second arc in your own words, built from those four sentences in that order and at their own scope, ending on your real reason for fourth grade (A4's slot). Do not add a fifth chapter your sentences do not carry | The opener of nearly every panel, and still scored; EXP because every beat is checkable |
| G2 | "Tell us about the reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years." | Story-mapped on F3: after school, a reading club, the last two years. Answer slot: expect questions on what students do and how you know it helps; if you can say, do so in your own words; if there is no measure, or it was not yours, say so plainly and return to the quote | A friendly question on a hot JD topic; casual register, scored all the same |

### H. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024" | Pause and restate. Hold what the quotes carry: six years in third grade, the grade-level move you led, and, if you want more, the reading club and the weekly email, each at its own scope. Concede specifically: "I've never taught fourth grade." Do not rank yourself above the other candidate; say what you would offer. Hold through two follow-ups by returning to those sentences | A blunt "why you" against F2; hold-then-concede, and the position held is only what you wrote |
| H2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead." | Hold: "I led our grade level's move to a new reading curriculum in 2024", at the grade level's scope, not the school's. Concede specifically: which parts were not yours, and "I've never been a team lead", if pressed on leadership. Answer slot: say which parts were yours, in your own words; if a part was not, say so plainly and return to the quote | The attribution probe in its pressure form; the two sentences sit side by side so neither is stretched |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 licence and endorsement | A5 |
| F2 fourth grade | A1, A4, H1, G1 |
| F3 reading instruction | A3, C1, D3, E1, G2 |
| F4 subjects | D2 |
| F5 assessment data | D1 |
| F6 classroom routines | A2, C2 |
| F7 communicate with families | B3, E2 |
| F8 speaks with every family | B3, C3, E2 |
| F9 grade-level team | B1, B2, B4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal here. What does that background change about what you look for in a fourth-grade teacher?" | Ties to the principal's own path, from her public speaker page, and moves the conversation from interrogation to peer talk |
| R2 | "Your 2025 talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5. How does that look in a fourth-grade classroom here?" | Shows you read her published work; asks about practice without claiming it |
| R3 | "What could a new fourth-grade teacher do in their first month that would genuinely help your team?" | The reciprocity question for the two teammates; rapport-style panelists weight this slot |
| R4 | "How will the new grades 3–5 reading curriculum from fall 2027 reach fourth grade?" | Uses the board's current plan and shows you think at the district's level |
| R5 | "What does a strong first year in fourth grade look like here, and who supports a teacher who is new to the grade?" | Turns your stated gap into a planning conversation and shows ownership |
| R6 | "How do families hear from teachers across the building, and how is each teacher's term-by-term contact with every family supported?" | Uses the published Families Are Partners belief and lets you learn what the commitment means in practice |

## Prohibited claims

Built before the banks; no question, guidance cell or reverse question coaches these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F2 | The plain acknowledgment: "I've never taught fourth grade." No slot |
| Has been a team lead | Negative you stated, in your message | The plain acknowledgment: "I've never been a team lead." No slot |
| Led the reading curriculum change across the school or district | Inflated form of F3 and F9 | The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024". The limit is the pack's observation: your material says your grade level's move, not a wider one |
| Runs a family communication programme, or speaks with every family each term | Inflated form of F7 and F8 | The quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: your material says a weekly email, not conferences or calls. B3's slot stays inside the email |

## Sources

Provided documents: the interview invite and the resume text you pasted. No dossier was present. No identification numbers were used in any search or in this pack.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | Published beliefs by name, fetched in full; themed E1 to E3 and F8 and shaped C3 and D1. They are the raising source for those questions |
| 2. `Orrinsford Community School District interview process, teacher` | yes | Loop structure fetched in full: one 45-minute building panel of the principal and two grade-level teachers, asking about reading instruction, classroom routines and family work. It establishes the loop, set the persona weights, and detected no values round |
| 3. `Orrinsford Community School District strategy` / recent news | yes | The board's August 2026 literacy plan: moved B4 and R4. Seen in the search result only, not fetched |
| 4. `Dolores Vantongeren Halvering Elementary School` | yes | Interviewer read, the A and G rows' emphasis on reading, and R1 and R2. The result matched the name, the role and the school, so it is attributable |
| 5. representative `Fourth Grade Teacher` JD | yes | No JD was supplied, so this supplied F4 to F7 and F9 as `[inferred]` rows. The result text was cut off mid-sentence, so only the duties it shows are used and nothing from its qualifications line |

Queries and results:

- "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs
- "Orrinsford Community School District teacher interview process panel" returned https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Orrinsford Community School District news strategic plan" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "Dolores Vantongeren principal Halvering Elementary School" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "Fourth Grade Teacher job posting Illinois elementary school qualifications" returned https://k12jobsboard.example/listings/fourth-grade-teacher
- Fetched in full: the beliefs page and the hiring page above

Source quality: the first three are the district's own pages; the principal's page is a professional forum's speaker listing; the posting is a job board's generic listing and says nothing specific about Halvering.

## Upgrade menu

- The full text of this posting → the `[inferred]` rows F4 to F7 and F9 become `[grounded]`, and any named curriculum, assessment or duty becomes a JD question
- The names of the two fourth-grade teammates → a per-member read and persona weights, and a reverse question tied to each one's path
- Anything HR said about the panel's focus, or a sample lesson or other task → a build section for a graded deliverable, and sharper weights
- Your answers to the answer slots, said outside a drill → the discovery rows F4, F5, F6, F8 and F9 upgrade from slots to quoted evidence, and the guidance that rests on them regenerates
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on the district's strategy and recent organisational context, and sharper CO questions
- A saved `tuesday-dossier.md` from an earlier check of this role → verified evidence and the named top objection arrive ready-made, and the guidance is tightened to match
