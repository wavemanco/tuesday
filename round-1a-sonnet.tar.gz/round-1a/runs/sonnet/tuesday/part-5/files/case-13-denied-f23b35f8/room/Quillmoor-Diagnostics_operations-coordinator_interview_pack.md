# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, 30-minute phone call, Thursday at 2pm
**Interviewer:** Hannah Lowther, Talent Partner. She will ring the mobile number on your application.
**Built on this assumption:** the call covers what Hannah listed in her message: salary expectations, notice period, how the hybrid pattern would work, what is prompting the move. She then tells you about the team and next steps. No company research ran, because web searches were refused; every fact about Quillmoor below comes from the advert.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your CV claims survive scrutiny; what was actually you |
| JD | The advert's stated responsibilities and requirements, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap on length. A self-reported line with nothing inspected behind it, so expect a probe. Lead with the quote in its own terms: four years, logistics coordinator, a building-supplies wholesaler |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says delivery scheduling for three depots, not production schedules and not coordination with planning, the warehouse or QA, and the words stay at "I schedule deliveries for our three depots." Answer slot: the advert's three-way line makes a probe likely. If any of your scheduling involved planning, the warehouse or QA, say how, in your own words; if it did not, or it was not yours, say so plainly and stay with the deliveries you schedule |
| F3 | "chase late orders" — advert | "chase suppliers when orders slip" — your message | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms. Lead with it as you said it: you chase suppliers when orders slip. Nothing inspected behind it, so expect a probe |
| F4 | "track supplier deliveries" — advert | "chase suppliers when orders slip" — your message | low | [inferred] | discovery | Chasing is not tracking, and the bridge should not be stretched. Answer slot: if you followed supplier deliveries in a sheet or system, say which and how, in your own words; if you did not, or it was not yours, say so plainly and stay with chasing suppliers |
| F5 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. It says you rebuilt the spreadsheet and that discrepancies fell; it does not say one caused the other. The figure raises four slots, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. "I don't know how it was counted" is an honest branch |
| F6 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material shows nothing on reporting. Answer slot: if you produce regular reports, say what goes in them and who reads them; if you do not, say so plainly, and say what you would put in a weekly dispatch report first |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | A spreadsheet is not necessarily Excel, and the quote does not say. Answer slot: if the spreadsheet was in Excel, say what you did in it, in your own words; if it was other software, or you have not used Excel, say so plainly and return to the rebuild |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP" — your message; "we run our own in-house stock system" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used SAP." Then the second quote at its own scope: you run an in-house stock system. The pack's observation: your material does not say whether that system does more than stock, so it is not called an ERP here. Say how you would learn SAP as a plan, never as a past. The advert marks it a plus |
| F9 | "£38,000–£44,000" — advert; "salary expectations" — Hannah's message | "I'm hoping for £42,000" — your message | high | [grounded] | none | Inside the band. Keep it at "hoping for", as you said it; it is not a floor and not a final number |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert; "how the hybrid pattern would work for you" — Hannah's message | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | The advert's two days fit what you said. Say your limit as a limit, in the quote's own words, not as flexibility |
| F11 | "what's prompting a move" — Hannah's message | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | A plain, checkable reason. Say it as the quote carries it, and add nothing about terms, dates or how the decision was reached, since your material gives none |
| F12 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period, and nothing here supplies one. A3's slot is your own actual notice, in your own words |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured: "what's prompting the move?", "how would hybrid work?" | High. The recruiter-screen prior is Conversational plus a light Skeptic, and Hannah's own list is logistics and motivation in a friendly register. Her message and the advert give no reason to move it | Treat casual questions as scored; say the logistics in your own words, briefly |
| Skeptic | Quiet probing of the gaps: wholesaler to manufacturer, SAP | Medium-high. The prior is light; raised because F2 and F8 are the two places where the advert and your material are furthest apart | Rehearse the single most predictable objection (B1) until it is boring; concede only what the quotes support |
| Data-Driven Prober | Checks the one number and the Excel line | Medium. A recruiter rarely goes two levels deep, but the advert leans on Excel and weekly reporting and your one figure invites a glance | Know what you can and cannot say about how the figure was counted, and say plainly where you do not know |
| Pressure / Stress | Time-boxed "why you over someone with SAP?" | Low-medium. A screen is seldom adversarial; the questions that fit are the ones aimed at F8 and your stated limits | Pause, restate, hold the position the quotes carry through two follow-ups, concede specifically |
| Case / Strategist | A quick scenario from the role | Low. Recruiters seldom run live problems; kept to three so the pack reaches its 18-question floor, and useful insurance for a later manager round | Clarify, then objective, then approach, then what you would check |

Not included: Values/Behavioral (no values-style round is documented in your inputs) and Peer Evaluator (no peer is on this call). The loop for this session rests on Hannah's own message: one 30-minute call with her. Later rounds are unknown, so these weights are for this call only.

## Question banks

### Bank A: Conversational (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What's prompting a move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Logistics slot, in the quote's own terms: your Bristol office is closing next year and the only offer is relocating to Reading, which you don't want. Stop there; add nothing about terms or timing. Answer slot: if a line of the advert genuinely appeals, name it and say why, in your own words; if none does yet, say so plainly and ask Hannah what the team does | Hannah named this in her message, so it is certain to come; F11 holds the reason. EXP because it tests whether your story is consistent |
| A2 | "What are you hoping for salary-wise?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot, filled with your own figure at its own scope: "I'm hoping for £42,000." The advert's band is £38,000–£44,000, so you are inside it. Answer slot: if you would move on the figure, say how far in your own words; if not, say so plainly. Do not offer a salary history | Hannah named salary first, so expect it early; F9 holds the figure. JD because it tests the advert's stated terms |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, from your contract, in your own words. If she asks about start date, give the true constraint and say what you would need to confirm. The pack supplies no figure because your material gives none | Hannah named notice in her message; F12 is the gate row. JD because it tests the role's start terms |
| A4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot, in the quote's terms: you live in north Bristol, so two days at Avonmouth is fine, and you wouldn't want more than three. Say the limit as a limit | Hannah named it; F10 holds it. JD because the advert states the pattern |
| A5 | "What do you know about Quillmoor?" | CO | [grounded] | You can say what the advert says: a diagnostic-test manufacturer, about 400 staff, with a site at Avonmouth in Bristol. Anything more must come from something you read yourself on their site before Thursday; web searches were refused, so none of it was checked here. Say what you read and no more | A recruiter-screen staple. CO because it tests homework. Grounded in the advert only; no strategy brief was available |

### Bank B: Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This is a manufacturer, and you've been at a wholesaler. What carries across?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots"; "chase suppliers when orders slip" | The highest-ROI rehearsal in this pack. Name the limit before it is asked: your material shows delivery scheduling, not production scheduling. Hold what the quotes carry: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for three depots; you chase suppliers when orders slip. Answer slot: if any of your scheduling touched production or QA, say how, in your own words; if it did not, or it was not yours, say so plainly and return to the deliveries. Likely follow-ups: what you would need to learn first about production scheduling, and how you would work with planning and QA. Answer those as a plan, never as a past. Concession wording, in your own words: you have not done production scheduling here, and this is how you would start | This objection will arrive in some form. F2 is where it presses hardest; JD because it scores a stated requirement |
| B2 | "The advert says SAP or similar is a plus. What ERP experience do you have?" | JD | [grounded] "Never used SAP"; "we run our own in-house stock system" | Plain acknowledgment: "I haven't used SAP." Then your in-house stock system, described as you described it, and what you did in it, in your own words. Answer slot: if there is another ERP you used, name it; if there is not, say so plainly. Then how you would learn SAP, as a plan. Never imply SAP or ERP use | The advert raises it, and F8 is a stated gap. It is only a plus, so a calm acknowledgment is the whole job |
| B3 | "Tell me about a time a supplier order ran late and what you did." | EXP | [grounded] "chase suppliers when orders slip" | Open prompt. The quote gives the beat: you chase suppliers when orders slip. Answer slot: if a specific late order comes to mind, say what happened and which part was yours; if none does, say so plainly and describe how you chase suppliers. Supply no outcome you cannot repeat under a second question | The advert's "chase late orders" raises it; F3 is the evidence. EXP because it tests what was actually yours |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never used SAP" | Pick the one that is true for you. The pack's observation from F2, F6 and F8: your material shows no SAP, no production scheduling and nothing on weekly reporting. If you name SAP, say "I haven't used SAP", then how you would learn it. Calibrated candour beats naming a safe non-weakness | Skeptic stem for a gap interview. JD because it scores the whole listed job |

### Bank C: Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that one-third was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say what you said: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Answer slots, each in your own words: how it was counted; what it is sensitive to; the assumption you would defend least, named before they ask; which part was yours. If you do not know how it was counted, say that plainly | The one headline figure is where a prober starts; F5 holds it |
| C2 | "How would you report weekly on on-time dispatch?" | JD | [generic] | A how-would-you question; it makes no claim about your past. Structure: what counts as on time; where the data comes from; who reads it and when. Answer slot: if you produce regular reports now, say what is in them; if not, say so plainly | The advert's reporting line; F6 holds no evidence, so this is rehearsed as a plan |
| C3 | "What have you been doing in Excel lately?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Say what you did in the stock-count rebuild, as you said it. Answer slot: if it was in Excel, say what you did in it; if it was other software, or you have not used Excel, say so plainly and return to the rebuild | The advert asks for confidence with Excel; F7 is thin |

### Bank D: Pressure / Stress (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has already used SAP?" | JD | [grounded] "Never used SAP"; "4 years as a logistics coordinator at a building-supplies wholesaler"; "chase suppliers when orders slip" | Hold, then concede. Concede first and plainly: "I haven't used SAP." Hold on what the quotes carry: four years as a logistics coordinator at a building-supplies wholesaler, and you chase suppliers when orders slip. Hold through two follow-ups by returning to those, not by adding to them. Do not assert that you learn quickly; offer a plan instead | F8 against a likely stronger candidate. JD because it tests the advert's plus |
| D2 | "That result: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold: "I rebuilt our stock-count spreadsheet." Answer slot: if other things also contributed to the fall, say which, in your own words; if the rebuild was the main change, say so plainly. Concede only what is true; do not claim the whole fall | A standard attribution probe on the one figure; F5 |
| D3 | "What if the site needed you in four days?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Hold the limit as you stated it: "I wouldn't want more than three." Answer slot: if you would make an exception, say when and why in your own words; if not, say so plainly. Do not turn the limit into flexibility | Tests whether you hold a stated position without defensiveness; F10 |

### Bank E: Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Two suppliers are late for the same production run, and QA has a hold on a third batch. What do you do first?" | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify first: the dispatch date, which orders depend on what, who in planning, the warehouse and QA is affected. Then the objective, then priorities by dispatch impact, then who you tell and when | A live problem built from the advert's planning, warehouse and QA line |
| E2 | "The stock record and the shelf count disagree. Where do you start?" | CASE | [generic] | No claim about your past. Structure: confirm the count, check recent movements, find the cause, correct the record, record what you learned | Built from the advert's stock-records line |
| E3 | "Weekly on-time dispatch has dropped. How would you find out why?" | CASE | [generic] | No claim about your past. Clarify what changed and when; split by order, supplier and stage; look for the common cause; say what you would report | Built from the advert's reporting line |

## Requirement coverage

| Advert requirement | Questions |
|---|---|
| 2+ years in operations or logistics coordination | B1, D1 |
| Coordinate production schedules between planning, the warehouse and QA | B1, E1 |
| Track supplier deliveries and chase late orders | B3, E1 |
| Keep stock records accurate | C1, D2, E2 |
| Report weekly on on-time dispatch | C2, E3 |
| Confident with Excel | C3 |
| ERP experience (SAP or similar) a plus | B2, B4, D1 |
| Pay £38,000–£44,000 | A2 |
| Hybrid, two days at Avonmouth | A4, D3 |
| From Hannah's list, not the advert: reason for moving; notice period | A1; A3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first 90 days look like, and who would I coordinate with most across planning, the warehouse and QA?" | Mirrors the advert's three-way coordination line and shows you read it |
| R2 | "How are the two Avonmouth days chosen: fixed days for the team, or agreed with each person?" | Hybrid is on Hannah's list; this turns your stated limit into a planning question |
| R3 | "What does the team use today for stock and supplier tracking, and what training is there for it?" | Turns your SAP gap into a practical question without apologising for it |
| R4 | "What does the weekly on-time dispatch report look like today, and who reads it?" | Shows interest in the advert's reporting line |
| R5 | "What are the next steps after this call, and who would I meet next?" | Hannah said she would cover next steps; this gets the timeline and the next interviewer |
| R6 | "Is this a new role or a replacement?" | Tells you how established the process and the role are |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP or any ERP | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't used SAP." Then your in-house stock system at its own scope |
| Coordinates production schedules between planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: the material says deliveries, not production schedules |
| The spreadsheet rebuild caused the one-third fall | Inflated form of F5 | F5's quote at its own scope: you rebuilt the spreadsheet, and discrepancies fell. B-bank and D2 slots stay inside that |
| £42,000 is a firm floor | Inflated form of F9 | F9's quote: "I'm hoping for £42,000." |
| Open to any office pattern | Contradicted by F10's quote | F10's quote: two days is fine, and you wouldn't want more than three |

## Sources

Provided documents: the advert text, your background notes, and Hannah's LinkedIn message, all in your message to me. No dossier was present.

Searches sent, all refused:
- `Quillmoor Diagnostics values`: refused
- `Quillmoor Diagnostics interview process operations coordinator`: refused
- `Quillmoor Diagnostics Avonmouth news strategy`: refused
- `Hannah Lowther Talent Partner Quillmoor Diagnostics`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Would have fed the CO question A5 and a values read; no values-style round is documented in your inputs, so no cheat sheet either way |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Would have named later rounds; this call's loop rests on Hannah's own message |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Would have grounded A5 and the CO coverage; A5 uses the advert only |
| 4. `Hannah Lowther Talent Partner Quillmoor Diagnostics` | unavailable | Would have fed an interviewer read and a reverse question tied to her path; both are absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV: rows grounded in your CV's wording rather than your summary, and F7 and F5 firmed up
- Search access, or a look at Quillmoor's own careers and values pages: a grounded A5 answer and a tailored reverse question. A deeper pass would be up to 6 more searches and 2 more fetches, several more minutes, offered once and run only if you want it
- Your answers to F2, F4, F6 and F7 (what your scheduling covered, whether you track deliveries, whether you report regularly, what software the spreadsheet was in), and C1 (how the figure was counted): upgrades those rows from answer slots to your own words
- Anything else Hannah says about the later rounds: per-round persona weights
- Time you have before Thursday: a prioritised prep schedule
- A `tuesday-dossier.md`: would add verified evidence and a named top objection; never required
