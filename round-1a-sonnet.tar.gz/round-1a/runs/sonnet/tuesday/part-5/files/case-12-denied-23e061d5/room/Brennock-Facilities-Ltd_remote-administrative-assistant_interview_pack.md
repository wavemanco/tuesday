# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager, name not given, relationship to the role not stated. Format per the invite: a 30-minute video call. Candidate: Aoife.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment |
| EXP | Work-experience deep-dive: does what you told them survive a follow-up |
| JD | Role and ad driven: can you do the listed duties, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role |

An answer slot is an instruction for the interview, not a question for you now: say the true version, or say plainly that the step was not yours or did not exist.

## Fit snapshot

The requirements are quoted from your message, where you relayed the ad. The evidence column holds your own words only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — your message, relaying the ad | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your words are the appointment book and the four physios, with nothing inspected behind them, so expect a probe. Say it as you said it: "I ran the appointment book for four physios." Calendars is the ad's word; the pack adds no clash handling, rescheduling or other practice to your sentence |
| F2 | "booking travel" — your message, relaying the ad | none given | none | [grounded] | discovery | Your material does not show travel booking either way. Answer slot: the ad lists booking travel, so expect a probe on it. If you have booked travel for anyone, say what and for whom, in your own words; if you have not, or it was never your task, say so plainly and say how you would learn it, as a plan |
| F3 | "preparing documents in Word and Excel" (the Word half) — your message, relaying the ad | "I'm good with Word, okay with Excel" — your message | medium | [grounded] | presentation | Your words are a self-rating with nothing inspected behind it, so expect a probe on it. Say it at that scope: "I'm good with Word." No document types, features or templates are added to your sentence |
| F4 | "preparing documents in Word and Excel" (the Excel half) — your message, relaying the ad | "I'm good with Word, okay with Excel" — your message | low | [inferred] | discovery | Derived from the ad pairing Excel with document preparation and your own rating of it as "okay". Answer slot: if you have used Excel for something specific, say what, in your own words; if not much, say so plainly and say what you would practise first, as a plan |
| F5 | "processing supplier invoices" — your message, relaying the ad | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your words are chasing unpaid invoices; your material does not say processing supplier invoices. Say what you said: "I chased unpaid invoices." Answer slot: the ad says processing supplier invoices, so expect a probe on the difference. If any of your invoice work was on supplier invoices, say what you did with them; if it was not, or you did not handle them, say so plainly and stay with the chasing |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Small live problems from the ad's four duties: a calendar clash, a trip to book, invoices to sequence, a document to prepare | Highest. Your invite gives one 30-minute call with the office manager, the one session this pack prepares for, and I treated that person as the one the role serves day to day. The hiring-manager prior is Case/Strategist plus Skeptic. If they are actually a recruiter-style screener, weights shift to C | Clarify before you answer, structure aloud, and make the order of steps visible. These questions ask about no past, so make no claims about it |
| Skeptic (B) | Quiet probing of what a reception-desk background does not show: travel, supplier invoices, Excel | High, by the same prior and because F2, F4 and F5 are thin | Rehearse the most predictable objection (B1) until it is boring. Use only your own words, name the limit plainly, and give a concrete ramp plan |
| Conversational (C) | A friendly opener and open prompts, but still scored | Medium. A 30-minute video call usually opens with a biography question; this is the pack's reading of the format, not a fact about this employer | Prepare a 90-second arc from your own sentences; treat casual questions about the ad's topics as scored |
| Data-Driven Prober (D) | Follow-ups to the next level on your invoice chasing and Word | Medium-low. Excel and invoices are the ad's checkable skills; there are no figures in your material to probe | Know what you can and cannot say about how you worked, and say plainly when you do not know |
| Pressure (E) | Time-boxed challenges, "how much was actually you" | Low. Not signalled by anything in the invite; included so the style is not new live | Pause, restate, anchor in what you said, hold through two follow-ups |

The Peer Evaluator and Values/Behavioral personas are not weighted: nothing in your message points to a peer in the room or to a values round, and no loop source detected one, so there is no values cheat sheet.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people ask for the same Thursday-morning slot, and one of them is travelling that day. What do you do?" | CASE | [generic] | Structure it aloud: ask who decides priority between them, check the travelling person's time zone and availability, offer one or two alternative slots, confirm the outcome to both in writing, and note it. The question asks about no past, so the guidance makes no claim about yours | A live problem from the ad's calendars duty, covering F1's requirement; CASE because it scores structure rather than history |
| A2 | "You have to book a trip for a manager with a fixed 10 a.m. meeting on Tuesday. What do you need to know before you book anything?" | CASE | [generic] | Clarify first: budget and any travel policy, preferred times and traveller preferences, flexibility on fare type, who approves before you pay, and where the confirmation goes. Then say what you would send back for sign-off. No claim about your past is needed | Covers the ad's booking-travel line (F2); CASE with JD content, and it lets you show process where your material shows no travel booking |
| A3 | "Three supplier invoices arrive: one does not match its order, one looks like a duplicate, and one is due tomorrow. Which do you handle first and why?" | CASE | [generic] | Say your order aloud and why: the due-tomorrow one has a deadline, but check it is genuine and correct before it is paid; query the mismatch with whoever placed the order; flag the possible duplicate and hold it until confirmed. Offer to confirm any payment rule with the office manager rather than assuming one | Covers the ad's supplier-invoices line (F5) as a decision rather than a record; CASE with JD content |
| A4 | "I need a one-page document and a simple spreadsheet tracking supplier invoices by tomorrow. What do you ask me first, and how would you lay the spreadsheet out?" | CASE | [generic] | Ask who will read each, what decisions they need to make from it, and the deadline. Then say aloud the columns you would use, for example supplier, invoice number, date, amount, due date and status, and how you would keep the document consistent. If you have built a tracker like this, say what; if not, say so plainly and say how you would build it | Covers preparing documents in Word and Excel (F3, F4); CASE with JD content |
| A5 | "Working remotely, how will I know what is on your plate and what is waiting on me?" | CASE | [generic] | Propose a simple routine aloud: a short daily note or list of what is done, in progress and blocked, and a quick way to flag anything urgent. Offer to adapt it to how the office manager prefers to work. Asks about no past | The ad is for a remote role, so a working-pattern question is likely; CASE with JD content |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have two years as a receptionist at a physiotherapy clinic. Which part of this job would you be weakest at on day one?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" [grounded] "I ran the appointment book for four physios" [grounded] "chased unpaid invoices" [grounded] "I'm good with Word, okay with Excel" | The highest-ROI rehearsal in this pack. Open with what you have, in your own words: "I ran the appointment book for four physios." Then name, in your own words, the one duty you would need the most help with, and give a concrete ramp plan for it, said as a plan and never as a past. Follow-up 1: how fast would you get up to speed; say what you would do in your first week. Follow-up 2: what if you were still slow after a month; say what you would ask for and when. Hold by returning to what you said, never by adding to it. Answer slot: the ad lists booking travel and processing supplier invoices, and your material carries neither; if you have done either, say what, and if you have not, say so plainly | F2, F4 and F5 are where the ad presses against a reception-desk background, so this objection arrives in some form; JD because it scores the stated duties, and the honest branch is a limit, not a confession |
| B2 | "Tell me how you ran the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Story-mapped on F1: the appointment book, and the four physios, told in your own words. Answer slot: the ad's calendars line makes a probe on how the book was kept likely. If you set how it was organised, say how; if it was set for you, or there was no set method, say so plainly and describe how you ran it | F1 is your evidence for the calendars duty and the likeliest place to be probed; EXP because it tests what was actually yours |
| B3 | "You said you're okay with Excel. What have you used it for?" | JD | [grounded] "I'm good with Word, okay with Excel" | Hold at your own scope: "I'm good with Word, okay with Excel." Answer slot: name what you have used Excel for, in your own words; if it is little, say so plainly and say what you would practise before starting. Never describe a function or a report you did not use | F4 is the thinnest row for a duty the ad pairs with Word; JD because it scores the stated tool requirement |
| B4 | "You chased unpaid invoices. This job processes supplier invoices. How do those compare?" | JD | [grounded] "chased unpaid invoices" | Start with what you said: "I chased unpaid invoices." Answer slot: if any of your invoice work was on supplier invoices, say what you did with them; if it was not, or you did not handle them, say so plainly and stay with the chasing, then give a ramp plan as a plan. Do not describe the two as the same work | F5 is a transferability row: the quote reaches a neighbouring task, not the duty; JD because it scores the ad's invoices line |
| B5 | "Why this role, and why now?" | EXP | [generic] | Answer in your own words about what draws you to this kind of administrative work and to working remotely; the pack supplies no reason for you. If your reason is simple, say it simply. Do not describe a reason you do not hold | A motivation-consistency question every Skeptic asks; nothing in your material states a reason, so the answer is yours alone |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me about yourself." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" [grounded] "I ran the appointment book for four physios" | A 90-second arc with the beats your sentences state: two years as a receptionist at a physiotherapy clinic, and running the appointment book for four physios. Then, in your own words, where you want to go next and why this role. No further achievements are added | The biography question is scored even though it sounds casual; EXP because it sets the facts every later probe builds on |
| C2 | "What was a normal week at the clinic like for you?" | EXP | [grounded] "I ran the appointment book for four physios" [grounded] "chased unpaid invoices" | Stay with the beats your sentences carry: the appointment book for four physios and chasing unpaid invoices. Answer slot: if there were other regular parts of the week that touch the ad's duties, say what, in your own words; if not, say so plainly and describe the two you named | Casual openers become probes on F1 and F5; EXP because it tests which of your claims survive a friendly follow-up |
| C3 | "What would you most want to learn in this job?" | JD | [grounded] "I'm good with Word, okay with Excel" | Pick one duty from the ad, in your own words, and say how you would learn it. Excel is the area where you described yourself as "okay with Excel", so it is a natural and honest choice; if another duty is truer for you, use that. If nothing comes to mind, say so plainly and say what you would ask first | A learning question lets you show honest self-assessment, which F4's thin evidence needs; JD because it maps to the ad's tools |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you chased an unpaid invoice, from start to finish." | EXP | [grounded] "chased unpaid invoices" | Answer slot: say the steps you actually took, in your own words and in the order you took them; if you had no fixed routine, say so plainly and describe how you went about it. Do not name a system or a step you did not use | F5's quote is the only invoice evidence, so a prober goes straight to it; EXP because it tests what was actually yours |
| D2 | "Tell me about a time you caught a mistake in a document before it went out." | JD | [generic] | Selection scaffold: pick a time you spotted an error before it left your hands; it needs the error itself, how you noticed, and what changed after. If no such time comes to mind, say so plainly, then describe how you would check a document before sending it | Document accuracy matters to the ad's document-preparation line (F3); the open prompt supplies no event, so the story must be yours |
| D3 | "Which parts of Word do you use most?" | JD | [grounded] "I'm good with Word, okay with Excel" | Hold at your own scope: "I'm good with Word." Answer slot: name the parts you actually use, in your own words; if you cannot name much, say so plainly. Do not list features to sound stronger | F3's self-rating has nothing inspected behind it, so a prober asks what is under it; JD because it scores the stated tool |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, with two years as a receptionist?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" [grounded] "I ran the appointment book for four physios" | Pause, restate the question, then answer from what you said: two years as a receptionist at a physiotherapy clinic, and "I ran the appointment book for four physios." Hold through two follow-ups by returning to those sentences. Concede specifically where your material stops: the ad lists travel booking and supplier invoices, and your material carries neither as stated. Answer slot: if you have done either, say what; if not, say so plainly and give your ramp plan | Tests whether you hold a position without becoming defensive; JD because it scores fit against the ad |
| E2 | "That appointment book: how much of it was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold at the quote: you ran it. Answer slot: if some parts were shared or set by someone else, say which, plainly; if all of it was yours, say that and stay at "I ran the appointment book for four physios". Do not enlarge it under pressure | An attribution probe, aimed at F1; EXP because it tests precision about what was yours |

### Requirement coverage

| Ad requirement | Questions |
|---|---|
| "managing calendars" | A1, B2, C2, E1, E2 |
| "booking travel" | A2, B1 |
| "preparing documents in Word and Excel" | A4, B3, C3, D2, D3 |
| "processing supplier invoices" | A3, B4, D1 |

The most likely objection, and so the highest-ROI prep, is B1.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I report to day to day, and how often would we check in?" | Shows you are thinking about how remote work actually runs |
| R2 | "How are laptops and other equipment provided to remote staff, and who pays for them?" | A normal onboarding question; a straight answer tells you whether you would ever be asked to fund equipment yourself |
| R3 | "What does a good first month look like in this role?" | Signals you plan to contribute early and gives you a target to aim at |
| R4 | "Which systems does the team use for calendars, travel booking and supplier invoices?" | Ties directly to the ad's duties and shows you have read it closely |
| R5 | "What is the hardest part of this job for someone new?" | Invites candor about the role and shows you are ready to learn it |
| R6 | "How is the remote team organised, and where are the other members based?" | Helps you judge how much support you would have |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars or diaries for an office or for executives | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: your material says an appointment book for four physios, not an office's calendars. A1 and B2 stay inside the quote |
| Advanced or expert Excel skills | Inflated form of F3 and F4 | The quote at its own scope: "I'm good with Word, okay with Excel." B3's slot asks only what you have used it for |
| Processed supplier invoices, or has accounts-payable experience | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices." The limit is the pack's observation: your material says chasing, not processing. B4's slot stays inside the chasing |

## Sources

Provided documents: your message, containing the interview invite, your description of the ad, and your background. These supply every requirement and every evidence quote above. The loop comes from the invite's own words: one 30-minute video call with the office manager. No values-style round is documented in it, so there is no values cheat sheet.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Brennock Facilities Ltd values | unavailable | Search refused by the host. It would have fed a values cheat sheet, which is not detected here, and CO questions; nothing about the company is used beyond the invite |
| 2. Brennock Facilities Ltd interview process, remote administrative assistant | unavailable | Search refused by the host. It would have checked the loop against the invite; persona weights rest on the invite's own words and the hiring-manager prior |
| 3. Brennock Facilities Ltd strategy and recent news | unavailable | Search refused by the host. It would have fed a CO or strategy question; none is in the pack, and A-bank questions are generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. Representative Remote Administrative Assistant ad | skipped | Your description of the ad fixes the fit snapshot and the JD-tagged questions |

Queries sent, all refused: "Brennock Facilities Ltd values"; "Brennock Facilities Ltd interview process remote administrative assistant"; "Brennock Facilities Ltd Ireland company news".

## Upgrade menu

- The ad's full text → F1 to F5 requirements become exact quotes, and any duty beyond your summary gets a question
- The office manager's name and role → an interviewer read, persona weights adjusted from their public footprint, and a tailored reverse question
- Any travel you have booked, or Excel work you have done → F2 and F4 move from none given and low toward quoted evidence, and A2, A4 and B3 become story-mapped
- What your invoice work involved, and whose invoices they were → F5 and B4, D1 become story-mapped instead of slot-based
- Any prep email or focus areas from the employer → coverage of anything pre-declared
- Permission to run web searches, or the company's own website pages pasted in → rows 1 to 3 in Sources, and company-specific questions in place of the generic ones
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief and role-family loop reports, if searching is allowed
- A tuesday-dossier.md → verified evidence and a named most-likely objection, instead of the one inferred here
