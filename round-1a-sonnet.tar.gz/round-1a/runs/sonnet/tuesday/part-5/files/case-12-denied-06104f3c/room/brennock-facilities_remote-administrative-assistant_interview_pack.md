# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (name not given). Relationship assumed: the person you would report to day to day. Format per the invite: a 30-minute video call.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the employer's published values |
| EXP | Whether what you say about your past holds up under follow-up |
| JD | Whether you can do the listed duties, gaps included |
| CO | How well you know the company and its strategy |
| CASE | How you structure a live problem from the job |

Answer slots are instructions for the interview, not questions for you to answer here.

## Fit snapshot

Requirements are the duties as you described the ad. Your evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "two years as a receptionist at a physiotherapy clinic" — your message, "ran the appointment book for four physios" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with the quote in its own terms: "I ran the appointment book for four physios." |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: the ad names it, so expect a direct probe. If you have booked travel for anyone, say what and for whom, in your own words; if you have not, say so plainly and say how you would go about learning the tools |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it | "I'm good with Word" — your message | medium | [grounded] | discovery | The rating stays at its word: "I'm good with Word." Your message gives the rating, not the documents. Answer slot: name the documents you have actually made in Word, in your own words; if you have made few, say so plainly and stay with the rating |
| F4 | "preparing documents in Word and Excel" — the ad, as you described it | "okay with Excel" — your message | low | [inferred] | discovery | Derived from your own self-rating, which is thin, so the pack does not stretch it. Words: "I'm okay with Excel." Answer slot: if you have used Excel for particular tasks, say which, in your own words; if you have not used it for anything in particular, say so plainly and say what you would practise first |
| F5 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says you chased invoices, and the words stay there: "I chased unpaid invoices." It does not say whose invoices they were or what happened to them beyond the chasing. Answer slot: the ad's invoice line makes a probe likely. Say whose invoices they were and what you did with them, in your own words; if none of it was handling invoices for payment, say so plainly and stay with the chasing |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live mini-problems from the job: a clash in someone's diary, a trip to book, an invoice that does not match | High. Relationship prior for a hiring manager. Your invite is the loop source: one 30-minute video call, so no archetype was assumed | Clarify first, then structure, think aloud, finish with how you would confirm and record it |
| Skeptic | Probes the gaps: invoices, Excel, travel, and why leave a clinic for this | High. Same prior; F2, F4 and F5 are the thinnest rows | Rehearse the invoice question (B1) until it is boring: the quote's words, then a plan |
| Conversational | Friendly opener, "walk me through your journey" | Medium. A video call usually starts this way and the casual questions are still scored | A 90-second arc built only from your quoted sentences |
| Data-Driven Prober | Asks for detail behind the appointment book and the invoices | Medium. The ad names Excel and invoices, which invite detail | Say what you remember in your own words, and say plainly where you do not |
| Peer Evaluator | "How would we work together" | Low. An office manager may act as a colleague as much as a boss; this moves up if they are a peer | Offer what you bring, and propose working principles instead of pretending to know their set-up |

Pressure and Values/Behavioral are left out: nothing in your material names a stress format or a values round.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people you support both want the same hour tomorrow and neither will move. What do you do?" | CASE | [generic] | Structure it: what you would ask first, what you could offer each, who you would take it to if they cannot agree, and what you would confirm back in writing. It needs no claim about your past, so the guidance makes none | Scheduling is F1's requirement, asked as a decision rather than a record |
| A2 | "You are asked to book a two-night trip to another city for a meeting at 9am. What do you need to know first?" | CASE | [generic] | Clarify before answering: dates and flexibility, budget, who approves, traveller preferences, how it is booked and paid. Then give the order you would work in and what you would send back for confirmation. No claim about your past | F2 is empty, so a live problem lets you show structure without claiming experience |
| A3 | "A supplier invoice arrives and the total does not match the purchase order. What do you do?" | CASE | [generic] | Check what differs, do not pay on a guess, find who approves payment, query the supplier in writing, and record what was agreed. No claim about your past | F5's requirement set as a live problem, so the answer is a plan |
| A4 | "You need a one-page comparison of three suppliers' quotes by tomorrow. How do you go about it?" | CASE | [generic] | Ask what the comparison is for and what criteria matter, set out one simple table, check the totals, say where each figure came from, and ask the manager to look before it goes on. Say it as a plan at the level you could actually do | F3 and F4 together; a plan is safe where a claim would be thin |
| A5 | "A supplier emails to say their bank details have changed and asks you to pay the next invoice to a new account. What do you do?" | CASE | [generic] | Do not pay on the email alone. Contact the supplier using details you already hold, tell whoever approves payments, and keep a record. No claim about your past | A common invoice-fraud pattern and a direct test of F5's requirement |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role processes supplier invoices. What have you done with invoices?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. The hold is only what the quote carries: "I chased unpaid invoices." Answer slot: say whose invoices they were and what you did with them, in your own words; if none of it was handling invoices for payment, say so plainly and stay with the chasing. Hold through two follow-ups by returning to the chasing, never by adding to it. Then give a plan: what you would want to learn first about how invoices are approved and paid | F5 is where the ad presses hardest against your material, so this objection arrives in some form. JD because it scores a stated duty |
| B2 | "How comfortable are you with Excel?" | JD | [inferred] "okay with Excel" | Say it at its own level: "I'm okay with Excel." Answer slot: if you have used it for particular tasks, say which, in your own words; if not, say so plainly. Before the call, build one small sheet you could talk through and rehearse describing it | F4 is the thinnest rated skill, so this is the most probable probe after B1. JD because Excel is a listed duty |
| B3 | "Have you booked travel before?" | JD | [generic] | Answer slot: if you have booked travel for anyone, say what and for whom, in your own words; if you have not, say so plainly and say how you would go about learning the tools. The question assumes nothing about your past | F2 is empty. JD because travel is a listed duty |
| B4 | "Why move from a physiotherapy clinic to a remote administrative role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Give your own reason in your own words. It should be true, be about the work you want next, and be sayable without criticising the clinic. Keep it to two or three sentences. No reason is supplied here | Motivation is probed whenever the background and the role differ. EXP because it tests whether your story is consistent |
| B5 | "This is a remote role. How do you keep on top of a day with nobody next to you?" | JD | [generic] | Pick one real habit you use to keep track of tasks and say how it works in your own words. If no such habit comes to mind, say so plainly, then say how you would set one up in the first week | Remote work is in the role title. JD because it scores whether you can do the job as set |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "ran the appointment book for four physios" "chased unpaid invoices" "I'm good with Word" "okay with Excel" | A 90-second arc with only these beats: the two years as a receptionist at the clinic; the appointment book for four physios; the unpaid invoices you chased; Word and Excel at your own ratings. Close with why this role, in your own words | Casual openers are scored. EXP because it tests whether your account matches your CV |
| C2 | "What do you use Word for these days?" | JD | [grounded] "I'm good with Word" | Start with "I'm good with Word." Answer slot: name the documents you have actually made, in your own words; if you have made few, say so plainly and stay with the rating | F3 in casual register. JD because Word is a listed duty |
| C3 | "What did you like most about running the appointment book?" | EXP | [grounded] "ran the appointment book for four physios" | The book and the four physios are the beats the quote gives; tell them in your own words. What you liked is yours to say. No detail is supplied here | F1 is the strongest row, so a friendly question about it is likely. EXP because it tests what was yours |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "ran the appointment book for four physios" | Story-mapped on F1: the book and the four physios, which the quote states; tell them in your own words. Answer slot: the interviewer is likely to ask for detail beyond those words. Give it only from what you remember doing, and where you do not remember or something was not yours, say so plainly and return to the book you ran | F1 is the likeliest line to be read closely. EXP because it tests what was actually yours |
| D2 | "In Excel, how would you check that a column of invoice totals adds up?" | JD | [generic] | Say what you would actually do, even if it is simple, in your own words. If you do not know a particular function, say so and say how you would find it. No claim about your past | F4 tested without a claim. JD because it checks a listed skill |
| D3 | "How do you check your own work before you send a document or confirm a booking?" | JD | [generic] | Pick one real habit and describe it in your own words. If none comes to mind, say so plainly, then say what you would do | Accuracy matters across all four duties. JD because it scores how you do the job |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "My own diary is a mess. How would we split who keeps what straight?" | JD | [generic] | Propose principles, not a system you claim to know: who owns what, how changes reach you, how you confirm back. No claim about your past | F1's requirement in colleague form |
| E2 | "What would you need from me in your first two weeks?" | JD | [generic] | Reciprocity: say what you need (access, who approves what, who to ask) and what you will bring. No claim about your past | Peer-style questions test partnership, and ask for what you need |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" | A1, D1, E1, C3 |
| "booking travel" | A2, B3 |
| "preparing documents in Word and Excel" | A4, B2, C2, D2 |
| "processing supplier invoices" | A3, A5, B1 |
| Remote working (from the role title) | B5 |
| Why this move, and the opener | B4, C1 |
| First-month working relationship | E2 |

No CO question: no company research ran, so none could be grounded.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which system do you use for supplier invoices, and who approves a payment before it goes out?" | It ties to the invoice duty and shows you think about checks. The answer also shows how real that duty is |
| R2 | "What equipment does the company provide for this role, and how does it reach me?" | Gets the employer's own account of equipment, which you can compare with what the invite said |
| R3 | "Who would I report to day to day, and how often would we speak in my first month?" | A remote role depends on contact, and it shows you want to be managed well |
| R4 | "What would a good first month look like across calendars, travel and invoices?" | It names the three duties and invites them to rank what matters |
| R5 | "How is onboarding handled: contract, payroll and start date, and when would I get the written terms?" | Gets the process in the employer's words, so you can check it against what the invite said |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars | Inflated form of F1, the ad's word in place of yours | F1's quote at its own scope: "I ran the appointment book for four physios." |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation: your material says chasing, not the handling of invoices for payment |
| Skilled or advanced in Excel | Inflated form of F4 | F4's quote at its own scope: "I'm okay with Excel." |

## Sources

Provided documents: the invite email as you pasted it, the ad's duties as you described them, and your background as you described it. No dossier was present.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | No search sent: this pack stays on the documents you gave, so nothing from your application went to a search. It would have fed VAL themes; none are in this pack |
| 2. interview process | skipped | The invite fixes the loop (one 30-minute video call with the office manager), and persona weights follow from it |
| 3. company strategy and news | unavailable | No search sent, for the same reason. It would have fed CO questions; this pack has none |
| 4. interviewer | n/a | The invite gives a role, not a name, so there was no query to form |
| 5. representative JD | skipped | The duties you gave fix the fit snapshot and the JD-type questions |

## Upgrade menu

- The full ad text → the requirement column can quote the ad itself, and rows now resting on your description can become exact
- Your CV → F1, F3, F4 and F5 draw on one sentence of your message each; a CV could add systems, volumes and tasks, and turn guidance from scaffolding into story maps
- Your own words for the answer slots on F2 to F5 → each row regenerates from what you actually did
- The office manager's name → an interviewer read, persona weights adjusted from public professional information, and a reverse question tied to their path
- Company research, if you want it → up to 6 searches and 2 page fetches would add values and loop checks, and a deeper pass of up to 6 more searches and 2 more fetches, taking several more minutes, would add a strategy brief and CO questions
- A `tuesday-dossier.md` → verified evidence and any prohibited claims carried in, which would sharpen B1
