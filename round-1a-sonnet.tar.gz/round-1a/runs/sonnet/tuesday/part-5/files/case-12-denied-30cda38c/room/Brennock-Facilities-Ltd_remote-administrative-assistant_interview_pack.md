# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Round: one 30-minute video call with the office manager (name not given). Relationship to you: not stated, so the pack is built for a hiring-manager-style conversation.

## How to use this pack

- Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.
- Type key:
  - VAL: whether past behavior shows the employer's published values
  - EXP: whether the claims you make about your own work survive follow-up
  - JD: whether you can do the listed job, gaps included
  - CO: company and strategy knowledge
  - CASE: a live problem from the role, scored on structure
- An answer slot is an instruction for the interview, not a question for you now: answer from your own experience, or say plainly it was not yours.

## Fit snapshot

The ad's four duties are quoted from your description of it; the full ad text was not supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material says an appointment book for four physios, and the words stay there: "I ran the appointment book for four physios." Answer slot: the ad's calendars line makes a probe on what else was scheduled likely. If anything beyond the appointment book was yours to schedule, say what, in your own words; if not, say so plainly and stay with the book |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material is silent on travel, so the words are an answer slot: the ad's travel line makes a probe likely. If you have booked travel for anyone, say for whom and how, in your own words; if you have not, say so plainly and say what you would ask first |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it (Word part) | "I'm good with Word" — your message | low | [inferred] | discovery | A skill statement with nothing shown behind it, so the words stay at "I'm good with Word." Answer slot: the ad's documents line makes a probe on what you have used Word for likely. If you can say what you have used it for, say so in your own words; if you cannot, say so plainly and say what you would practise before day one |
| F4 | "preparing documents in Word and Excel" — the ad, as you described it (Excel part) | "okay with Excel" — your message | low | [inferred] | discovery | Your own word is "okay", and the pack does not lift it. Answer slot: if you can say what you have done in Excel, say it in your own words; if the answer is little, say so plainly, and give a plan for getting faster, said as a plan and never as a past |
| F5 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing, with nothing shown about handling the invoices themselves, and the words stay there: "I chased unpaid invoices." Answer slot: the ad's invoices line makes a probe on what you did with them likely. If you did anything with those invoices beyond chasing, say what, in your own words; if chasing was the whole of it, say so plainly |
| F6 | "Remote Administrative Assistant" — the invite | none given | none | [grounded] | hard_gate | Your material does not establish whether you can work remotely for this role |

### Requirement coverage

| Requirement | Questions covering it |
|---|---|
| F1 managing calendars | A1, A5, B1, D1, E2 |
| F2 booking travel | A2, B1, E1 |
| F3 Word | A4, B1, D3 |
| F4 Excel | A4, B2 |
| F5 supplier invoices | A3, B1, B3, D2 |
| F6 remote working | B4 |

## Persona table

The weights rest on the relationship prior for a manager-style interviewer, because the invite names one 30-minute call with the office manager and nothing about their relationship to you. No loop beyond that call is documented.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems from the ad's four duties: a clash in a diary, a trip to book, an invoice that doesn't match | Highest: the hiring-manager prior puts it first, and the ad lists concrete duties to turn into problems | Clarify first, then structure, then answer; think aloud; challenge one premise politely |
| B. Skeptic | Probing the distance between reception work and the ad's four duties | Highest: F2, F3, F4 and F5 are thin rows, so the gaps are where a probe lands | Rehearse B1 until it is boring; hold only what your quotes carry; add a ramp plan |
| C. Conversational | The opener, the journey question, "any questions for me?" | Medium: the invite describes a short video call, and the first and last minutes are where a casual register fits | A 90-second arc built from your quotes; treat casual questions as scored; never answer "I think you've covered everything" |
| D. Data-Driven Prober | Line-by-line questions on the figure you gave and on what chasing involved | Lower: no signal of a numbers-led interviewer in the invite | Know what you can and cannot say about "four physios"; say plainly when you do not know |
| E. Pressure | Time-boxed or devil's-advocate questions | Lowest: nothing in the invite points to it | Pause, restate, hold a position through two follow-ups, concede specifically |

## Question banks

### A. Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people whose diaries you manage want the same hour on the same day, and both say it can't move. What do you do?" | CASE | [generic] | Structure it aloud: ask what each meeting is for and how firm the time really is; check whether someone senior needs to decide; offer each a nearby alternative; confirm the outcome in writing to both. The question needs no claim about your past, so the guidance makes none | A live problem from the calendars duty (F1), asked as a decision; CASE because it scores structure |
| A2 | "Someone must be in Cork on Tuesday morning and back for a 9am meeting in the office on Wednesday. What do you ask first, and how do you book it?" | CASE | [generic] | Ask first: who is travelling, what the budget and approval route are, and what they prefer or cannot do. Then compare options on cost against timing, confirm, and send one itinerary with the booking details. The guidance makes no claim about your past | The travel duty (F2) is the row with no evidence, so a live problem lets you show method without a claim; CASE |
| A3 | "A supplier invoice arrives for more than the order says. Walk me through what you do." | CASE | [generic] | Hold the payment; compare the invoice with the order and any delivery record; ask the supplier in writing about the difference; tell whoever approves payments; keep the trail. The guidance makes no claim about your past | The invoices duty (F5), asked as a decision; CASE because the order of steps is what is scored |
| A4 | "You're asked for a one-page summary by end of day, using figures from a spreadsheet. How do you set it up?" | CASE | [generic] | Clarify who it is for and what decision it serves; check the figures before writing; draft in the format asked; proofread; ask for a quick review before it goes. The guidance makes no claim about your past | The Word and Excel duty (F3, F4) as a problem; CASE because clarifying before building is the scored move |
| A5 | "Tell me about a time you kept a busy schedule on track when plans changed." | JD | [grounded] "I ran the appointment book for four physios" | Story-mapped on F1: the appointment book, and the four physios, which are the beats the quote states; tell them in your own words. Selection scaffold for the change: pick a time with a named change, what you did about it and where it ended up; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | An open prompt from the calendars duty (F1); JD because it scores the stated duty |

### B. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role covers calendars, travel and supplier invoices. What part of that have you done yourself?" | JD | [grounded] "I ran the appointment book for four physios" "chased unpaid invoices" | The highest-ROI rehearsal in this pack. Limit, named before it is asked: your material shows the appointment book and the chasing of invoices; it does not show travel or what was done with the invoices. Hold: "I ran the appointment book for four physios, and I chased unpaid invoices." First follow-up ("which of those was you?"): return to the same two quotes. Second ("and travel?"): answer slot: if you have booked travel for anyone, say for whom and how; if you have not, say so plainly. Third ("so what would your first week look like?"): a plan, said as a plan: what you would ask about the diary, the travel process and the invoice routine. Concede the specific part you did not do; never fold on the two quotes | F1, F2 and F5 are the biggest distance between your material and the ad, so this question arrives in some form; JD because it scores the stated duties |
| B2 | "How would you rate your Excel?" | JD | [inferred] "okay with Excel" | Say "okay with Excel" in your own words, then stop adding adjectives. Answer slot: if you can say what you have done in Excel, say it; if the answer is little, say so plainly. Then the plan: what you would learn first and how, said as a plan | F4 is a low row on your own word, so the probe is predictable; JD |
| B3 | "Chasing unpaid invoices isn't the same as processing supplier invoices. How would you close that?" | EXP | [grounded] "chased unpaid invoices" | Hold: "I chased unpaid invoices." The limit is the pack's observation: your material says chasing, not processing. Answer slot: if you did anything with those invoices beyond chasing, say what, in your own words; if chasing was the whole of it, say so plainly. Then a ramp plan: what you would ask on day one about how invoices are approved and recorded | F5 is where the ad's wording reaches past the quote; EXP because it tests what was actually yours |
| B4 | "This is a remote role. What would make that work for you?" | JD | [grounded] | Describe your actual set-up and the hours you can work, in your own words. The guidance makes no claim about your situation, because the material does not state it | F6 is a gate row: the material does not establish it, so the answer is yours alone; JD |
| B5 | "What draws you to this role?" | JD | [generic] | Name one thing in the ad's four duties that you actually want to do more of, and say why in one sentence. If nothing in the list pulls you, say what does. No invented motive: use only what is true | The motivation probe a skeptic always includes; JD because it asks about this role |

### C. Conversational (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "I ran the appointment book for four physios" "chased unpaid invoices" | A 90-second arc of three beats: two years as a receptionist at a physiotherapy clinic; the appointment book for four physios; chasing unpaid invoices. Where you are pointing next is yours to say, in your own words | The opener is scored even in a casual register (F1, F5); EXP because it tests whether your account matches what you will be asked about |
| C2 | "What do you like about keeping a diary running smoothly?" | JD | [grounded] "I ran the appointment book for four physios" | Give one real reason in one sentence, then connect it to the appointment book at the beats the quote states, and stop. Do not claim what the work proved | A casual question on the calendars duty (F1); JD |
| C3 | "Do you have any questions for me?" | JD | [generic] | Pick two or three from the reverse questions below and ask them in your own words | Rapport-style interviewers weight this slot as a preparation signal; JD |

### D. Data-Driven Prober (lower weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Four physios: walk me through what running that appointment book involved." | EXP | [grounded] "I ran the appointment book for four physios" | Tell it at the quote's scope: the appointment book, the four physios. Answer slot: if you know how the four was counted, what it was sensitive to, the assumption you would defend least, and which part was yours, say it in your own words; if you do not know, say so plainly | The figure in F1 is a defend-the-number target; EXP |
| D2 | "What did chasing unpaid invoices look like in practice?" | EXP | [grounded] "chased unpaid invoices" | Tell it at the quote's scope: you chased them. Answer slot: if you know how many, how often or what came of it, say so in your own words; if you did not track it, say so plainly | F5 is the claim a prober tests for detail; EXP |
| D3 | "Which Word documents have you produced?" | JD | [inferred] "I'm good with Word" | Answer slot: if you can say what you have used Word for, name it in your own words; if you cannot, say so plainly and say what you would practise before day one. The quote stays at "I'm good with Word" | F3 is a low row raised by the ad's documents duty; JD |

### E. Pressure (lowest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone with an office-admin background?" | JD | [grounded] "I ran the appointment book for four physios" "chased unpaid invoices" | Pause and restate the question. Hold the two quotes through two follow-ups without adding to them. Concede the specific duty you have not done yourself, by name, if that is the true branch from the F2 and F5 slots, and say how you would learn it | A pressure question aimed at F2 and F5; JD because it scores fit to the stated duties |
| E2 | "How much of that appointment book was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold the quote: "I ran the appointment book for four physios." Answer slot: if anyone else shared the book, say so plainly and say which part was yours; if no one did, say that | An attribution probe on F1; EXP |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Could you tell me the company's registered name, and where this role is listed on your own website or careers page?" | It gives you something you can check yourself, independent of the invite |
| R2 | "Across a typical week, how is the time split between calendars, travel, documents and invoices?" | It shows you read the four duties and tells you where to practise |
| R3 | "Which systems do you use for diaries and for invoices?" | It shows you are thinking about the tools and answers how much Excel the role needs (F4) |
| R4 | "How is equipment provided for remote staff, and is anything paid by the employee before starting?" | It asks about the invite's own fee in the sender's words, so you can compare the answer with the company's website |
| R5 | "How will you and I work day to day, given the role is remote?" | It treats remote working as a practical matter (F6) and shows you have thought about it |
| R6 | "What would a good first month look like?" | It turns the interview into a plan and tells you what to rehearse |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: your material says an appointment book, not calendars. The slots in A5 and B1 stay inside the book |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices." The limit is the pack's observation: your material says chasing, not processing. B3's slot stays inside what was done with the invoices you chased |
| Prepared documents in Word and Excel | Inflated form of F3 and F4 | The quotes at their own scope: "I'm good with Word" and "okay with Excel." D3's slot asks only what you have used Word for |
| Advanced Excel skills | Inflated form of F4 | F4's quote at its own scope: "okay with Excel." B2's slot asks only what you have done in it |

## Sources

Provided documents: the invitation email you pasted; your description of the ad; your own summary of your experience. No dossier was present.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

Searches sent:
- "Brennock Facilities Ltd values careers": refused
- "Brennock Facilities Ltd interview process remote administrative assistant": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | The search was refused, so no published value names are in hand; it would have fed a values cheat sheet if a values round had been documented |
| 2. `Brennock Facilities Ltd interview process remote administrative assistant` | unavailable | The search was refused; it would have tested the loop against the invite's single 30-minute call and could have adjusted persona weights |
| 3. `Brennock Facilities Ltd strategy` / recent news | unavailable | No call sent, because search was refused on rows 1 and 2; it would have fed CO questions, which are absent from this pack |
| 4. `{interviewer name} Brennock Facilities Ltd` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Remote Administrative Assistant` JD | skipped | The four duties you described fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the ad → F1 to F5's requirement cells become full quotes instead of your description of it
- Whether the office manager would be your manager or a peer → persona weights reorder and a reciprocity question is added
- Your actual remote set-up and working hours → F6 can be answered from your own words and B4's guidance becomes story-mapped
- Anything you have done with travel, Word, Excel or invoices beyond what you wrote → F2 to F5 gain evidence and their answer slots become story-mapped
- Permission to run web search → the company's published values and process (rows 1 to 3 of the target table), including whether anything attributable can be found about the employer
- A tuesday-dossier.md → verified evidence and the gaps this prep exposed, carried into later sessions
