# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Interviewer and round:** Hannah Lowther, Talent Partner. A recruiter screen: a 30-minute phone call, Thursday at 2pm, to your mobile number on your application.

**What this was built on:** your summary of your background, the advert and Hannah's message. There was no CV and no company research, because search was not available in this session. Say so if any of that changes and the affected sections will be regenerated.

## How to use this pack

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding, not a script: where it quotes you, those are the beats to tell in your own words, and where it gives an answer slot, the honest answer is whichever branch is true for you.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included, and its stated terms |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, reasoned aloud |

No VAL or CO questions appear. No values-style round is documented, and no company research ran.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries for three depots, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you coordinate with likely. If any of your scheduling involved working with a planning, warehouse or quality function, say which and what part was yours, in your own words; if not, or it was not yours, say so plainly and stay with the three depots |
| F2 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | The sentence touches suppliers without showing whether you track their deliveries. Answer slot: if you follow supplier deliveries in some way, say how, in your own words; if you do not, or it is not yours, say so plainly and stay with chasing suppliers when orders slip |
| F3 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you chase suppliers when orders slip |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap on the wording, but a figure with nothing inspected behind it, so expect the defend-the-number probe. Say what the sentence says: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. The sentence states both, not that one caused the other |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show any reporting. Answer slot: if you report on deliveries or dispatch, say what, how often and to whom, in your own words; if you do not, or it is not yours, say so plainly and stay with scheduling deliveries and chasing suppliers |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap: your sentence already reaches the requirement in role-relevant terms. Say it as written |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The sentence says spreadsheet, not Excel, and nothing about confidence. Answer slot: if the spreadsheet was in Excel, say what you did in it, in your own words; if it was another tool, or Excel was not what you worked in, say so plainly and stay with the rebuild |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | medium | [grounded] | transferability | Your words: "I've never used SAP." Beside it, the in-house stock system at its own scope: "we run our own in-house stock system." Your material does not say whether that system is an ERP, and the pack does not call it one. Then how you would learn SAP, said as a plan and never as a past |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure sits inside the band. Say it as you said it: you are hoping for £42,000. The pack does not turn "hoping" into a floor, or into a figure you would drop |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The pattern is shown met. Say both halves as stated: two days at Avonmouth is fine, and you would not want more than three |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; asks for the agenda items one by one, then your story | High. A recruiter screen's prior is conversational with logistics, and Hannah's own message lists the agenda: "salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move". Four of the six A questions come straight from it | Treat each casual question as scored. Keep each answer to your own words and short; do not wait for "any questions?" to be generic |
| Skeptic | Quiet probing of the background mismatch and the reason for the move | Medium. "What's prompting a move" is on Hannah's list. The advert's first duty (F1) sits furthest from the quotes in your material, so the production-scheduling question is the likeliest objection | Rehearse B1 until it is boring. Bridge only from what you said, and say the limit plainly where it is a limit |
| Data-Driven Prober | Asks how a number was counted | Low. Thirty minutes and a recruiter's brief make a deep probe unlikely, but F4's figure is the one number you will mention, and a probe is cheap for her | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Pressure / Stress | Time-boxed challenge, tests composure | Low. Rare in recruiter screens; the one likely form is a quick "why you over someone with SAP" | Pause, restate, hold through two follow-ups on what you actually said, then concede the specific gap |
| Case / Strategist | A short live scenario | Low. Hannah's agenda lists no scenario; a one-line "what would you do if" is possible and cheap to rehearse | Clarify first, then structure, then say what you would record and who you would tell |

## Question banks

### A. Conversational (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot, in your own words and at the quote's scope: the Bristol office is closing next year, the only offer is relocating to Reading, and you do not want that. Say it plainly in under half a minute. Answer slot: if there is a further reason you want to share, say it in your own words; if there is not, say plainly that the move is why you are looking and go on to the role. Do not add a reason you have not told me | Hannah named this as an agenda item. EXP because it tests whether your story is consistent with what you wrote. F4 and F6 sit behind the same answer; no row is needed for the reason itself |
| A2 | "What salary are you expecting?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot filled by your own figure: "I'm hoping for £42,000." It sits inside the advert's £38,000–£44,000 band (F9). Do not turn "hoping" into a minimum or into a figure you would drop. If asked about flexibility, give your actual position in your own words. If asked for your current salary, either give your own answer or ask for the role's band first | Pay is the first item on Hannah's list, and F9 is the row it scores. JD because it tests the listed job's terms |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, as your contract states it. If you are unsure, check the wording before Thursday. You may also ask what start date she has in mind and answer from there. Supply no figure you have not checked | Hannah named notice. Your material does not state it, so the guidance is a slot and no number is supplied. JD because it tests the job's start terms |
| A4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot filled by your words at their scope: two days at Avonmouth is fine from north Bristol, and you would not want more than three. If she asks how you would get there, answer from your own knowledge of the journey; the pack has none of it | Hybrid is on Hannah's list and F10 is the row. JD because it tests the stated location terms |
| A5 | "So, walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc of three beats the quotes state, told in your own words: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies down by about a third over a year. Answer slot: for the close, say in your own words what you want next, if you know; if not, say so and go to a question for her | A recruiter's opener, and the arc is where F3, F4 and F6 first get heard. EXP because it tests whether the story matches your message |
| A6 | "Have you used SAP, or anything like it?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say it as stated: "I've never used SAP." Then "we run our own in-house stock system", at its scope. Answer slot: if you use the in-house system for particular tasks, say which, in your own words; if you would not call it comparable, say so plainly. Then, as a plan and not a past, how you would learn SAP | The advert marks ERP as "a plus" and casual questions on a stated plus are still scored. F8 is the row. JD because it tests a stated requirement |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules between planning, the warehouse and QA. What have you done like that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | **The highest-ROI prep in this pack.** Hold only what the quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: if any of your scheduling involved working with a planning, warehouse or quality function, say which and what part was yours, in your own words; if not, or it was not yours, say so plainly and stay with the three depots. Hold through two follow-ups by returning to the depots and never adding to them. Concede the specific limit, that your material shows deliveries and not production, only in your own words | F1 is the gap furthest from the quotes and the first duty in the advert, so this objection arrives in some form. JD because it scores the stated requirement; the hold-then-concede structure is the Skeptic's |
| B2 | "You've come from a building-supplies wholesaler. How do you see yourself fitting a manufacturer?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." | Start from the shared fact: four years as a logistics coordinator at a wholesaler. Answer slot: if something about manufacturing or this role interests you, say it in your own words; if the main reason you are looking is the office closure, say so plainly, consistent with A1. Do not claim enthusiasm for diagnostics you do not have, and this pack holds no company research to borrow from | The Skeptic tests why here, and a reason that matches A1 survives cross-examination. F1 and F6 sit behind it. JD because it scores fit to the listed job |
| B3 | "You mentioned relocating to Reading isn't for you. Is that a firm no?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | At the quote's scope: the only offer is relocating to Reading, which you do not want. Answer slot: if you have the closure date, give it as you know it; if you only know "next year", say that. If there is a further reason you want to share, say it in your own words; if not, say plainly it is not an option you want | Probes the reason for the move for firmness. The premise is the quote's own. EXP because it tests what you told me against what you say aloud |
| B4 | "Are you talking to other companies?" | EXP | [generic] | Answer slot: give your real situation in your own words, whether you are applying elsewhere and roughly where those stand. Never invent other processes or offers to seem in demand. If this is the only process, say so plainly | Recruiters ask this to gauge urgency. The question assumes nothing about your past, so the guidance makes no claim about it. EXP because it tests candor |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that drop in discrepancies was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what the sentence says: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Answer slot, each in your own words: how it was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. Say plainly if you do not know how the figure was counted. The sentence does not say the rebuild caused the fall, so say that only if you can back it | F4's figure is the one number you will mention. EXP because it tests whether the claim survives scrutiny |
| C2 | "Tell me what you did on that stock-count spreadsheet." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Beats the quote states: you rebuilt it, and discrepancies fell. Answer slot: the advert's "keep stock records accurate" makes a probe on ongoing upkeep likely; if you maintained the records after the rebuild, say how; if not, say so plainly and stay with the rebuild | F4 against the advert's accuracy line. EXP because it asks what was actually yours |
| C3 | "The role reports weekly on on-time dispatch. What reporting do you do today?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you report on deliveries or dispatch, say what, how often and to whom, in your own words; if you do not, or it was not yours, say so plainly and stay with scheduling deliveries and chasing suppliers. Do not describe a report you did not produce | F5 is a requirement with no quote, so the probe is likely and the honest branch must be ready. JD because it scores a stated requirement |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "I schedule deliveries for our three depots and chase suppliers when orders slip." "4 years as a logistics coordinator at a building-supplies wholesaler." | Pause and restate the question. Hold on what the quotes carry: four years as a logistics coordinator; scheduling deliveries for three depots; chasing suppliers when orders slip. Hold through two follow-ups by returning to those, not adding. Concede the specific gap plainly: "I've never used SAP." Then how you would learn it, as a plan. Do not claim you learn systems quickly unless you can name a time you did | F8 is a stated gap, and the advert calls it a plus. JD because it scores a listed requirement; hold-then-concede is the Pressure structure |
| D2 | "That result with the discrepancies — how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold the sentence's own attribution: "I rebuilt our stock-count spreadsheet." Answer slot: if other people or other changes contributed to the fall over that year, say what, in your own words; if none did, say so plainly. Never claim the whole drop as yours beyond what you can back | The stock figure is a magnet for the attribution probe. F4 is the row. EXP because it tests attribution honesty |

### E. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you at 4pm that a delivery QA needs for tomorrow's run will be two days late. What do you do?" | JD, CASE | [generic] | Structure it aloud: ask what the delivery feeds and what is waiting on it; tell planning, the warehouse and QA, the three functions the advert names; offer the options you see; chase the supplier for a firm date; record it. This is a live problem and the guidance makes no claim about your past | F2 and F3 and F1 in one scenario. JD content, CASE delivery. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| E2 | "The stock record says 40 units and the shelf has 32. What do you do?" | JD, CASE | [generic] | Structure it: recount before trusting either number, check recent movements, find where the difference arose, correct the record and note why. A live problem; nothing about your past is assumed | F4's accuracy line as a decision. JD content, CASE delivery. The numbers are the interviewer's illustration |
| E3 | "How would you build a weekly on-time dispatch report from raw order data in Excel?" | JD, CASE | [generic] | Structure it: what counts as on time, what data you need, how you would calculate it, how you would present it, what you would check before sending. Answer slot: name the Excel features you actually use, in your own words; if you do not use something, do not list it. Whether your stock-count spreadsheet was in Excel is a fact only you can state | F5 and F7 together. JD content, CASE delivery |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Coordinate production schedules (F1) | B1, E1 |
| Track supplier deliveries (F2) | E1 |
| Chase late orders (F3) | A5, E1 |
| Keep stock records accurate (F4) | C1, C2, D2, E2 |
| Report weekly on on-time dispatch (F5) | C3, E3 |
| 2+ years in operations or logistics coordination (F6) | A5, D1 |
| Excel (F7) | E3 |
| ERP experience (F8) | A6, D1 |
| Pay (F9) | A2 |
| Hybrid (F10) | A4 |
| Notice, and the reason for the move (Hannah's agenda) | A3, A1, B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I work with day to day across planning, the warehouse and QA?" | The advert names those three functions, so it shows you read the first duty |
| R2 | "What would a good first three months look like in this role?" | Turns the call toward what success means and gives you something to prepare for |
| R3 | "Which system does the team use for stock and orders, and how is training handled for someone who hasn't used SAP?" | Surfaces F8 on your terms; it names a gap you have already stated |
| R4 | "Are the two Avonmouth days fixed, or agreed with the team?" | Follows from your answer to A4 and shows you have thought about the pattern |
| R5 | "What does on-time dispatch reporting look like today, and who reads it?" | Tied to the advert's weekly reporting line, and tells you what F5 will mean in practice |
| R6 | "Who would I meet next, and what does the next round cover?" | Practical; Hannah said she would cover next steps, so listen first and ask only what she leaves out |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | Negative you stated, F8 | The plain acknowledgment: "I've never used SAP." No slot |
| Has ERP experience | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: your material does not say whether that system is an ERP. A6's slot stays inside the system |
| Coordinated production schedules across planning, warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: the material says deliveries, not production. B1's slot stays inside the depots |
| Cut stock discrepancies by a third through the rebuild | Inflated form of F4 | F4's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The sentence states both, not that one caused the other. C1's slots ask only how it was counted and what was yours |
| £42,000 as a firm floor, or as a figure you would drop | Changed form of F9 | F9's quote at its own scope: "I'm hoping for £42,000." |
| Three days a week at Avonmouth as your preference | Changed form of F10 | F10's quote at its own scope: two days is fine, and you "wouldn't want more than three." |

## Sources

Provided: Hannah Lowther's LinkedIn message, the advert, and your own summary of your background. No dossier was present.

Searches sent, all refused:

- `Quillmoor Diagnostics values about us` — refused
- `Quillmoor Diagnostics interview process operations coordinator` — refused
- `Hannah Lowther Talent Partner Quillmoor Diagnostics` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Search was refused. It would have supplied published value names for VAL questions and a values cheat sheet if a values round turned up; the pack has no VAL bank |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Search was refused. It would have shown whether later rounds exist and what they hold; persona weights rest on Hannah's own description of this call only |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | No call was sent, since search had just been refused. It would have grounded a CO question; the pack has none |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Search was refused. The interviewer read is absent and the reverse questions are role-generic |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or its lines for the current role → F1 to F8 evidence cells quote the CV, and some `discovery` rows may become `none`
- What the stock-count spreadsheet was built in, and what the in-house stock system does → F7 and F8, and the A6 and E3 slots become your own words
- Your actual notice period → A3's slot becomes your own quoted words
- Search access, or a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → Quillmoor's published values, any documented loop, and Hannah's public footprint, which would add CO questions and a tailored reverse question
- Any email or notes from Hannah beyond the LinkedIn message → coverage of anything she pre-declared
- A `tuesday-dossier.md` from an earlier fit check → verified evidence and named gap strategies in place of the ones this pack inferred
