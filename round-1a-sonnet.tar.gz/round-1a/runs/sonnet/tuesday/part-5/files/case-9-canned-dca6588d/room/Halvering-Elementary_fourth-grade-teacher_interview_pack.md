# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Round:** One 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
**Mode:** Session. Built with no posting text, since the invite carries none, and with the two team members assumed to be peers.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether what your CV says survives follow-up, and what was actually you |
| JD | The role's stated requirements, including the gaps |
| CO | Whether you know the district's current direction |
| CASE | A live problem set in the role |

## Prep triage

1. Rehearse A1 until it is boring. It is the highest-ROI prep in this pack.
2. Rehearse A3 and G2 together. Both test how much of the curriculum move was yours.
3. Say F1 and F2 aloud once each: the licence confirmation and your 90-second arc.
4. Pick two reverse questions from section 11 and know why you are asking them.
5. Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | No gap: the CV line states the licence, the endorsement and the status in the invite's own terms, and grade 4 falls inside the stated 1–6 range. Nothing has been inspected behind it, so expect a confirmation. Say it as written: kind, endorsement, range, active through the stated date. Checking that your own record matches what you say is yours to do before Thursday. This pack does not copy the licence number |
| F2 | "Fourth Grade Teacher position" — your invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "classroom routines" — district hiring page, search result text, page not opened | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [grounded] | discovery | The line shows six years in a third-grade classroom and says nothing about how it ran. Answer slot: the district says panels ask about routines, so expect a probe on how your classroom runs. Describe it in your own words; if a part was set by the school or was not yours, say so plainly and stay with the six years |
| F4 | "reading instruction" — district hiring page, search result text, page not opened | "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" — your message | medium | [grounded] | transferability | Both sentences carry reading work adjacent to the requirement. Words stay at their scope: the move, led by you, in 2024; the club, run by you, for two years. Answer slot: expect a probe on what "led" covered. Say what you did in your own words; if parts were decided or done by others, say so plainly and return to the sentence |
| F5 | "each teacher speaks with every family each term" — district beliefs page | "I write a weekly email to families" — your message | medium | [grounded] | discovery | The email is the only family contact your material shows. Answer slot: the belief sets a standard for every family each term, so expect a probe on how your family contact works beyond the email. If any does, say how in your own words; if none does, or it is not yours, say so plainly and return to the weekly email |
| F6 | Working with a grade-level team (role-family requirement, no quoted source) | "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" — your message | low | [generic] | discovery | The two sentences sit close together and must stay apart: you led a move, and you have not been a team lead. Answer slot: if the move involved other teachers, say what was theirs and what was yours, in your own words; if it did not, say so plainly |
| F7 | "assessments inform teaching and never replace it" — district beliefs page | none given | none | [grounded] | discovery | Nothing in your material speaks to assessment. Selection scaffold: pick a moment where information about a child changed what you taught next, with a named child (no names aloud), what you noticed, what you changed. If no such moment comes to mind, say so plainly, then say how you would use assessment information to decide what to teach next |

## Reading the interviewer

Public professional footprint only. The two team members are unnamed, so this covers the principal.

| Item | Finding | Provenance |
|---|---|---|
| Career pattern | Principal of Halvering Elementary School since 2022, after nine years as a reading specialist. Source: Illinois principals forum speaker page, search result text, page not opened | [grounded] |
| Published topic | 2025 forum talk "Small Groups, Big Readers", on weekly reading conferences in grades 3 to 5. Same source | [grounded] |
| Implication 1 | Reading questions may come from someone whose earlier work was reading specialism: precision about what you did will land better than polish | [inferred] |
| Implication 2 | Her talk's themes (small groups, weekly reading conferences) may come up. Nothing in your material says you hold weekly reading conferences, so answer from what you did or say plainly that you would learn it | [inferred] |
| Implication 3 | Reverse questions 1 and 2 in section 11 are tied to her path and her talk | [inferred] |
| Mirror opportunity | Shared professional ground is reading. Your side of it is F4: "I've run the after-school reading club for the last two years", and no more than that | [grounded] |

## Persona table

The loop is one panel: your invite names the principal plus two fourth-grade team members for 45 minutes, and the district's hiring page describes the same single panel. Weights follow the panel row of the priors: the top two personas of each member's relationship, adjusted by the signals above.

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| A. Skeptic | The principal and team probe the fourth-grade gap and "why here, why now" | high: F2 is a stated gap, and the principal's relationship prior leads with Skeptic | Rehearse the single objection (A1) until it is boring; plain acknowledgment plus a plan |
| B. Peer Evaluator | The two teachers ask what you would need from them, what you bring, how you disagree | high: two fourth-grade team members sit on the panel, and the peer prior leads with this persona | Reciprocity framing; propose how you would work with the team without pretending to know their routines |
| C. Case / Strategist | Scenario questions from the principal: a struggling reader, family communication, the district's plan | medium: the hiring-manager prior, and the district says panels ask about reading instruction, routines and families | Clarify, then objective, approach, how you would know it is working |
| D. Data-Driven Prober | Follow-ups on the curriculum move and the club | medium: peer prior second place; your CV carries no figures, so probes go to the two reading sentences | Say what you did and did not do; "I don't know" is an honest branch |
| E. Values / Behavioral | Scenario questions keyed to the three published beliefs | medium: the district says its beliefs guide every hire, but no values-style round is documented | Selection scaffolds, each ending in an honest branch |
| F. Conversational | Opening biography, typical-day questions, the licence confirmation | low: no signal pushes it up; it keeps three questions because F1 must exist | A 90-second arc built only from your own sentences |
| G. Pressure | A short-fuse challenge on why you and how much was you | low: a 45-minute building panel, and no public signal of a stress style | Hold through two follow-ups by returning to your quotes, then concede specifically |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see fourth grade in your background — how would you handle teaching it?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment F2 gives: "I haven't taught fourth grade." Then what you have, at its scope: six years teaching third grade at a public elementary school in Joliet. Then a plan, never a past: name two or three things you would find out from the fourth-grade team first, in your own list. Follow-up 1, likely "what would your first month look like?": answer as a plan. Follow-up 2, likely "what if it takes longer than we expect?": concede specifically, "I haven't taught fourth grade, so the first term will have things I need to learn from the team." Never say third grade is the same as fourth | F2 is the gap the whole panel is built around, so this objection arrives in some form. JD because it scores the role's grade; Skeptic because it is asked as a doubt |
| A2 | "Why fourth grade after six years in third, and why here, and why now?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Your material gives no reason, so the reason is yours to supply: one or two sentences you can stand behind. The district's published beliefs are Every Child a Reader, Families Are Partners, and Teach for Tomorrow, Not for the Test; cite one only if it truly matches why you applied. If no clear reason comes to mind, say so plainly, then say what you are looking for in the next role | Motivation consistency is what a skeptical panel scores; F3's six years frames the move. EXP because it tests whether your story holds together |
| A3 | "Tell me about leading your grade level's move to a new reading curriculum." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on F4. The beats are the ones the sentence states: the move, your grade level, 2024, and that you led it. Tell them in your own words. Answer slot: expect a probe on what "led" covered. Say what you did; if parts were decided or done by others, or there was no such step, say so plainly and return to the sentence | F4 is the strongest reading evidence and the likeliest place to be probed. EXP because it tests attribution |
| A4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Pick the weakness your material supports: it names one, in F2. Say it plainly, then the plan from A1. Do not hand them a second weakness you cannot back, and do not offer a disguised strength | A stock Skeptic stem, aimed at the one gap the material states. JD because it scores fit to the stated role |
| A5 | "Which of our three beliefs would be hardest for you to live up to?" | VAL | [grounded] "I write a weekly email to families" | Families Are Partners is the belief your material is thinnest on (F5), so it is the honest pick if it is true for you. The email is what your material shows: say it as written. Answer slot: the belief sets a standard for every family each term, so expect a probe on how your family contact works beyond the email. If any does, say how in your own words; if none does, or it is not yours, say so plainly and return to the weekly email | The beliefs are published and the district says they guide every hire. VAL because it scores alignment with the published belief; Skeptic because it asks for the weak point |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you need from us in your first month, and what could you bring to our team?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Needs: your own list, as a plan. Bring: the sentence at its scope, which is that you led your grade level's move to a new reading curriculum in 2024. Answer slot: if parts of that move would help this team, say which, in your own words; if you are not sure how much carries over, say so plainly | Peers price what the hire costs and contributes. JD because it scores the grade-level team work in F6 |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The sentence says it was your grade level's move, so a credit probe lands here. Say what was yours in the sentence's own terms and what was others', in your own words; if it was mostly one or the other, say so plainly. Credit freely where it is theirs | Stem from the peer persona. EXP because it tests attribution; F6 is the row it draws on |
| B3 | "Suppose the team does something differently from the way you would have done it. What happens?" | JD | [generic] | Make no claim about your past. Structure it: what you would ask first, what you would try their way for, how you would raise a difference respectfully, and where you would hold a view | A collaboration scenario; no past is presupposed, so `[generic]` is honest |
| B4 | "You haven't been a team lead. How do you see your place on a team of several teachers?" | EXP | [grounded] "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | Use the plain acknowledgment F6 gives: "I haven't been a team lead." Keep the second sentence at its scope: you led a move, which is not leading a team. Then how you would contribute, as a plan | The peer persona returns the Skeptic's objection collegially. EXP because it tests whether you keep the two sentences apart |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A child joins your class a month behind in reading. Walk me through your first two weeks." | CASE | [grounded] | Structure it: what you need to know first (what plan the child arrives with, what the family can tell you), the objective, the approach, how you would know it is working, who you would involve. The district's first belief says no student leaves third grade without a reading plan, so asking what plan a child arrives with fits its own terms. The guidance makes no claim about your past | A live problem in the role's reading focus. CASE because it asks for structure, and the published belief grounds it |
| C2 | "The board adopted a literacy plan in August with a new grades 3–5 reading curriculum from fall 2027. What would you want to know about it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say what the board's announcement states: a three-year plan, structured phonics from kindergarten to second grade, a new grades 3–5 reading curriculum from fall 2027, and a family reading night at every school each term. Then what you would ask. If you mention your own move, it is the sentence at its scope; nothing in your material says it was the same kind of curriculum or how it went | The one question that uses the district's current direction. CO because it scores knowledge of the plan; F4's sentence is the only link to your history |
| C3 | "How would you plan communication with the families of a new class in your first term?" | CASE | [grounded] "I write a weekly email to families" | Plan, not past: what you would send, what you would offer for conversations, and how you would reach families who do not respond, aimed at the standard the belief sets. Your present practice is the email, said as written | F5's thin row, asked as a plan so it can be answered honestly. CASE because it asks for a structure |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you know the new reading curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if anything was checked along the way, say what and by whom, in your own words; if nothing was, or it was not yours, say so plainly and return to the sentence. Your CV carries no figures, so give none | The prober's native question about any change. F4 is the row; EXP because it tests what was checked |
| D2 | "What role should assessment play in your teaching?" | VAL | [grounded] | The published belief is that assessments inform teaching and never replace it. Give your own view in your own words. If you have a concrete example from your own classroom, tell it; if none comes to mind, say so plainly and say how you would use assessment information to decide what to teach next | F7 has no evidence, so this is rehearsed as a view with an honest branch. VAL because it scores the third published belief |
| D3 | "Tell me about the after-school reading club you've run." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Beats the sentence states: the club, after school, the last two years, run by you. Answer slot: expect follow-ups on how the club runs and what you have seen come of it. Answer from what you did, in your own words; if a part was not yours, or there was no such thing, say so plainly and return to the two years | F4's second sentence, the most concrete reading evidence you have. EXP because it tests the claim |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you worked to make sure a child's reading was not left to chance." | VAL | [grounded] | Selection criteria: a child (no names aloud), what you noticed, what you did, what changed or did not. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Theme from Every Child a Reader. VAL because it scores the belief |
| E2 | "Tell me about a time a family disagreed with you. What happened?" | VAL | [grounded] | Selection criteria: a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Theme from Families Are Partners. VAL because it scores the belief; F5 is the row it draws on |
| E3 | "Which of our three beliefs is closest to how you already teach, and what shows it?" | VAL | [grounded] | Pick one and show it with a specific moment, in your own words. If no moment comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The district says its beliefs guide every hire, so choosing one with a reason is rehearsable. VAL because it scores the published belief |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Just to confirm for our records, you hold the Illinois Professional Educator License with the elementary endorsement?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it as written: the licence, the endorsement, the grade range, active through the stated date. The licence number is for the district to ask, and you may have it to hand | The invite's one hard requirement, asked in a friendly register. F1 is the row; JD because it is a stated requirement |
| F2 | "So, walk me through your journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc in this order, each at its own scope: six years in third grade in Joliet, the move you led in 2024, the club you have run for two years, the weekly email. End with your reason for fourth grade from A2, in your own words | The opening biography is scored even when it feels casual. EXP because it is your CV said aloud |
| F3 | "Describe how a typical day runs in your classroom." | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: describe your classroom's routines in your own words; this pack supplies none. If a routine was set by the school or was not yours, say so plainly and stay with your six years. If fourth grade might run differently, say you would ask the team | The district says panels ask about routines. JD because it scores a stated topic; F3 is the row |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has taught fourth grade?" | EXP | [grounded] "I've never taught fourth grade"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | Pause, restate the question, then three sentences from your own quotes: the move you led, the club you have run, and the plain limit, "I haven't taught fourth grade." Make no claim of being better than anyone else. Hold through two follow-ups by returning to what you did; concede specifically what you would have to learn | The Skeptic's objection under a clock. EXP because it tests whether you stay inside your own sentences |
| G2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold the sentence at its scope: you led your grade level's move, in 2024. Answer slot: say what part was yours in your own words; if parts were others', or the question's premise is wrong, say so plainly. Hold through two follow-ups, then concede specifically what you cannot claim | A stock Pressure stem aimed at F4. EXP because it is an attribution probe |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1: licence with elementary endorsement | F1 |
| F2: fourth-grade teaching | A1, A2, A4, G1 |
| F3: classroom routines | F3, A2 |
| F4: reading instruction | A3, C2, D1, D3, E1, G2 |
| F5: families | A5, C3, E2 |
| F6: grade-level team | B1, B2, B3, B4 |
| F7: assessment | D2, E3 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| 1 | "You spent nine years as a reading specialist before becoming principal. How does that shape what you look for in how a fourth-grade teacher runs reading?" | Ties to her own path and shows you read about her, not only the school | [grounded] |
| 2 | "Your 2025 talk covered weekly reading conferences in grades 3 to 5. What does that look like in a fourth-grade room here?" | Ties to her published topic and asks about their practice, not yours | [grounded] |
| 3 | "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" | Reciprocity question for the two peers: it asks what helps them | [generic] |
| 4 | "The literacy plan brings a new grades 3–5 reading curriculum from fall 2027. How is the fourth-grade team being involved in preparing for it?" | Shows you read the board's announcement and asks about their work | [grounded] |
| 5 | "What support does a teacher new to the grade get in the first term?" | Signals you plan to close the fourth-grade gap rather than hide it | [generic] |
| 6 | "Each teacher speaks with every family each term. What does that look like for fourth grade here?" | Asks about their practice on the belief where your material is thinnest | [grounded] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I haven't taught fourth grade." No slot |
| Is or has been a team lead | Negative the candidate stated, F6 | The plain acknowledgment F6 gives: "I haven't been a team lead." The move is quoted at its own scope, as the move you led |
| Chose, designed or wrote the new reading curriculum | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation, not words for you: your material says the move, not who chose the curriculum |
| Showed that the new curriculum raised reading levels | Inflated form of F4 | F4's quote at its own scope. Your material says the move and the club, and shows no outcome of either |
| Speaks with every family each term | Inflated form of F5 | F5's quote at its own scope: "I write a weekly email to families". The limit is the pack's observation: your material shows the email only |

## Sources

Provided documents: the interview invite and your CV, both in your message. No tuesday-dossier.md was present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Query or fetch | Returned |
|---|---|
| Search: Orrinsford Community School District mission values | https://orrinsfordschools.example/about/mission-and-beliefs |
| Search: Orrinsford Community School District teacher interview process panel | https://orrinsfordschools.example/careers/how-we-hire-teachers |
| Search: Orrinsford Community School District strategic plan | https://orrinsfordschools.example/news/board-adopts-literacy-plan |
| Search: Dolores Vantongeren principal Halvering Elementary School | https://ilprincipalsforum.example/speakers/dolores-vantongeren |
| Search: fourth grade teacher job description Illinois elementary school | https://k12jobsboard.example/listings/fourth-grade-teacher |
| Fetch: the district's beliefs page | Opened; the three beliefs and their one-line definitions |
| Fetch: the board's literacy plan announcement | Opened; the three-year plan, adopted August 2026 |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The three beliefs by name, used as raising sources for A5, C1, D2, E1, E2, E3 and F5 and F7. No cheat sheet: no values-style round is documented, so section 10 is dropped |
| 2. `{company} interview process {role family}` | yes | Confirmed one 45-minute building panel with the principal and two grade-level teachers, and the topics it asks about; persona weights follow it. The page was read as search result text only |
| 3. `{company} strategy` / recent news | yes | The August 2026 literacy plan feeds C2 and reverse question 4 |
| 4. `{interviewer name} {company}` | yes | The principal's career pattern and 2025 talk feed the interviewer read and reverse questions 1 and 2. The two team members are unnamed, so nothing was researched for them |
| 5. representative `{role title}` JD | yes | The result was a search snippet cut off mid-sentence and the page was not opened, so no requirement is quoted from it. It moved only F6, written as an unquoted role-family requirement |

## Upgrade menu

- The posting text for this role → F2 to F7 gain quoted JD requirements, F6 moves from `[generic]` to `[grounded]`, and the JD-tagged questions retune to its wording
- The names of the two fourth-grade team members → an interviewer read for each, per-member persona weights, and a reverse question tied to each one's public path
- Your own words on the answer slots for F3, F4, F5 and F6 → those rows upgrade from slots to quoted evidence, and A3, B2, D1, D3 and F3 regenerate
- A moment where assessment information changed what you taught, in your own words → F7 moves from `none given` to quoted evidence and D2 and E3 get a mapped story
- A deeper research pass (up to 6 further searches and 2 further fetches, several more minutes) → a grounding brief on the district's direction and the principal's talks, which would sharpen C2 and the CO bank
- A tuesday-dossier.md, if you have one → verified evidence and an evidence-derived objection to replace the one inferred here
