**Not yet. I wouldn't prep for this interview, or confirm it, until you've checked who sent the message. As it stands it's `no_go`, because of RR1 (`severity: high`): a hiring process run wholly by chat.**

## Decision snapshot

**Fit ledger.** There are no rows to project. The message states no requirement, and I have no CV or non-negotiables from you yet, so there is nothing to grade.

**Opportunity ledger.** The process is run entirely over WhatsApp (RR1). The sender, employer, role and pay can't be pinned down from the message (RR2, RR3). The contact also conflicts with your guess about where it came from (RR5), and the notice is short (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** RR1 (`severity: high`).
- **What would change this:** the employer is identified independently, the role is live on that employer's own careers page, and the interview happens by call, video or in person, not only in chat.

Interview prep is the mock-interview module's job, and I'd run it only once those checks clear.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Not named. "Jess, a recruitment consultant" gives no agency or company | `[grounded]` your message |
| Role | "A remote position with flexible hours"; no title, pay, location or contract type | `[grounded]` your message |
| Process | "Everything, from the interview through to your contract, is done right here over WhatsApp messages, so no calls or video are needed" | `[grounded]` your message |
| Timing | Interview "tomorrow at 11am", offered in the first message | `[grounded]` your message |
| Source of contact | The message says "we found your profile online"; you suspect one of your applications | `[grounded]` both statements; the two aren't reconciled, and I haven't picked one |
| Market calibration | Not possible: there is no title or pay to set against a band | `[grounded]` nothing stated |
| Unknowns | Employer, role title, pay, contract basis, interview format, who you'd report to | — |
| Contradictions | None inside the message. Only the origin mismatch above | `[grounded]` your message |

## Evidence map

No rows. The message names no requirements, and I haven't seen your CV.

## Gap recovery queue

No gaps to recover yet. The open items are about the opportunity, not about you, and sit in the register below.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Decision rule | Status |
|---|---|---|---|---|---|---|---|---|---|
| RR1 | Interview and contract handled wholly by chat | red_flag | high | "Everything, from the interview through to your contract, is done right here over WhatsApp messages, so no calls or video are needed" | The message says the interview and the offer happen only in chat, which takes away the usual ways to check who is on the other end. This sign takes no verdict from me, and the sender's identity is unresolved | `[generic]` hiring that people can verify usually involves a named employer and a live or recorded interaction; a pattern, not a finding about this sender | Which company is hiring, and can the interview be a call or video on that company's own platform? Ask this of the employer, through contact details you find yourself on its own site, once it is identified | Hold: don't confirm the slot, send documents, or share personal or financial details while this is open. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call | confirmed |
| RR2 | Employer not established | risk_signal | medium | "Jess, a recruitment consultant" | No company or agency is named, so nothing can be checked. The sender may be a very small outfit, the message may be mass-sent, or it may not come from who it claims; none is more likely from here. Medium, not high, because nothing yet ties this to a payment or ID request | `[generic]` pattern for unnamed senders, not a claim about this one | Can you point me at this role on your own careers site, and who I'd be interviewing with? | Verify the employer exists and the posting is live before investing prep effort | unresolved |
| RR3 | Role, pay and terms withheld | unknown | — | "a remote position with flexible hours" | Nothing here lets you test the role against your own limits | `[inferred]` from the message's silence on title and pay | What is the job title, salary range and contract type? | Get these in writing from the verified employer before any interview | unresolved |
| RR4 | Short notice | risk_signal | low | "Are you free for your interview tomorrow at 11am?" | A fast slot leaves little time to check anything. Low, because quick scheduling is also common in ordinary hiring | `[generic]` pattern, not a claim about this sender | Is there flexibility on the date so I can confirm details first? | A request to move the slot is reasonable; treat resistance as new information | unresolved |
| RR5 | Origin unconfirmed | unknown | — | "We found your profile online" | The contact may not trace to any of your applications | `[grounded]` your message against your own guess | Which of my applications does this relate to? | Check your own sent applications and inbox before replying | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't confirm the interview or send documents or personal or financial details yet | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Search your sent applications and email for any agency or employer matching this; then look the employer up yourself and use only contact details from its own site | see RR2, RR5 | `[grounded]` RR2, RR5 | pending your approval |
| A3 | Optional holding reply: "Thanks for getting in touch. Could you tell me the company, the role title, the pay range and the interview format? I'd prefer a call or video, and I'd like to confirm the role on the company's careers page first." | see RR1, RR3. Answers from the sender don't verify anything until you check them independently | `[grounded]` RR1, RR3 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | n/a | No employer or agency name was given, so there was no query to form. A name would let me check the employer exists and the role is live (RR2) |
| 2. Role-family sweep | n/a | No title or field was given. A title would give a pay and scope band (RR3) |
| 3. Hiring manager's public footprint | n/a | No name was given beyond a first name with no company |

I can write a `tuesday-dossier.md` of this assessment if you want to keep it.

**Upgrade menu**
- A company or agency name, or the role title → targets 1 and 2 can run, and RR2 and RR3 may close.
- A link to the live posting → RR2 and RR5 resolve.
- Your CV and non-negotiables (pay floor, location, hours) → the evidence map and hard gates get real rows.
- The recruiter's email domain, if one is given → the employer check gets a firmer starting point.

**Questions**
1. RR5 — Did any recent application go through an agency or name a company, and does anything in it match this message?
2. RR3 — What are your non-negotiables for a role (pay floor, location, hours, contract type)?
3. RR1 — Have you replied yet, or sent anything (CV, ID, bank or personal details)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.