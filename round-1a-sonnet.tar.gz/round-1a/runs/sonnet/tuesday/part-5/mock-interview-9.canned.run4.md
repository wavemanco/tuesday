Searches are back with real hits. I'm fetching the district's beliefs page and its hiring-process page, then I'll write the pack.
Your resume text included a Social Security number. A prep pack doesn't need it, so I haven't used or copied it. I'd leave it off anything you paste elsewhere. I also left your license ID number out of the pack and out of every search.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-5/rooms/case-9-canned-17e50167/Halvering-Elementary_fourth-grade-teacher_interview_pack.md`. I built it for the 45-minute panel your invite describes: Principal Vantongeren plus two fourth-grade teammates. The district's own hiring page confirms that format. I used a general fourth-grade teacher listing in place of the posting, which you didn't send, so the rows built on it are labeled inferred.

The most important prep is the question the pack calls A1, which is about your lack of fourth-grade experience. Say it once in your own words ("I've never taught fourth grade"), then give the six years of third grade and a plan for your first weeks. Don't claim the grades are alike. H1 is the same objection under time pressure.

- **License:** your PEL and elementary endorsement meet the invite's requirement as you've stated them. Confirming your registration status is yours to do.
- **Reading is your strongest ground.** The principal was a reading specialist for nine years and gave a 2025 talk on reading conferences. Your curriculum move and reading club fit that, and the pack keeps both at the scope of what you wrote.
- **Team lead:** you've said you've never been one, and the pack lets you say that plainly. It doesn't blend it with leading your grade level's curriculum move.
- **Where I stopped:** the pack has answer slots, such as whether you spoke with families directly beyond the weekly email. Where your material is silent, I didn't fill in a story for you.
- **What I read:** the principal, the district's literacy plan and the listing came from search snippets only. Read the full literacy plan before Thursday, since one question (G3) leans on it.

Say the word and I'll play the Skeptic on A1, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did HR say anything about what the panel will focus on, or ask you to prepare or bring something, such as a sample lesson? Either would restructure the banks.
Can you paste the posting's full text? Without it I'll keep working from the general listing.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering-Elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. One 45-minute panel on Thursday with Principal Dolores Vantongeren and two members of the fourth-grade team. Built from your invite, your resume text and your message, plus the research listed under Sources.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script, and every sentence about your past in this pack is one you wrote, quoted.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs |
| EXP | Whether your own claims hold up, and what part was yours |
| JD | The responsibilities and qualifications of the role |
| CO | Whether you know the district's current direction |
| CASE | A live problem set in the role |

An answer slot is an instruction for the interview, not a question for you now. A selection scaffold means the pack has none of your stories for that question and will not invent one.

## Prep triage

The panel is Thursday. In this order:

1. A1 and H1 until the plain acknowledgment and the plan sound ordinary (F9). This is the highest-ROI prep in the pack.
2. A5, E2, C1, D1 and D2: your reading work, told at the scope of your own sentences (F2).
3. Decide, from your own memory, how you would answer each answer slot in F2, F3 and F5 to F8: yes with how, or no.
4. B1 to B3 and the reverse questions R1, R2 and R4.

Everything else is insurance.

## Fit snapshot

Requirements come from three places: your invite, the district's published beliefs page, and a general fourth-grade teacher listing standing in for the posting, which you did not supply. Rows built on the listing are labeled inferred.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your material shows this gate met, in your own words, with nothing inspected here, so confirming your registration status is yours to do. This row asks nothing. The pack's own observation: the grade range in your quote includes fourth grade. Say it in the quote's terms: license, endorsement, registered and active through June 30, 2029 |
| F2 | "Every Child a Reader: no student leaves third grade without a reading plan" — district beliefs page | "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | This is adjacent reading work, not a reading plan for each student, and the words stay at each sentence's scope. Answer slot: the belief's reading-plan line makes a probe on reading plans likely. If you made or kept reading plans for students, say how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the move and the club |
| F3 | "Families Are Partners: each teacher speaks with every family each term" — district beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | A weekly email is what your sentence says; speaking with every family each term is a different practice your sentence does not state. Words: "I write a weekly email to families." Answer slot: if you spoke with families directly, say how and how often, in your own words; if there was no such step, or it was not routine, say so plainly and stay with the weekly email |
| F4 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it" — district beliefs page | none given | none | [grounded] | discovery | Your material says nothing about assessment practice. Strong evidence would be one specific assessment, what it showed, and what you changed, in your own words. Answer slot: if you have such an instance, say it; if there is none, say so plainly and say what you would look at first in fourth grade |
| F5 | "plan and teach reading, writing, math, science and social studies" — general fourth-grade listing, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | discovery | Your sentence says the grade and the school, not which subjects. Answer slot: the listing names five subjects, so expect a probe on each. For each one you taught, say how, in your own words; for any you did not teach, or that someone else taught, say so plainly and return to the six years of third grade |
| F6 | "differentiate instruction using assessment data" — general fourth-grade listing, K12 Jobs Board | none given | none | [inferred] | discovery | Same shape as F4. Strong evidence is a named result and what you changed for which students, in your own words. Answer slot: if you did this, say how; if there was no such step, or it was not yours, say so plainly and say what you would look at first |
| F7 | "keep clear classroom routines" — general fourth-grade listing, K12 Jobs Board | none given | none | [inferred] | discovery | Strong evidence is one routine you set and taught, in your own words. Answer slot: if you did this, say which and how; if there was no such step, or it was not yours, say so plainly and say how you would learn the team's routines first |
| F8 | "work with the grade-level team" — general fourth-grade listing, K12 Jobs Board | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | transferability | You stated a negative, and the words are yours: "I've never been a team lead." The move is a separate sentence and stays at its own scope; the two should not be blended. Answer slot: the listing's team line makes a probe on planning with colleagues likely. If you planned with colleagues beyond the move, say how; if there was no such step, say so plainly and stay with the move |
| F9 | "the Fourth Grade Teacher position" — your invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then a plan for your first weeks, said as a plan and never as a past. Never a claim to fourth-grade experience, and nothing added to make the gap feel smaller |

## Reading the interviewers

Public professional footprint only. The two teammates are unnamed in your invite, so only the principal is read.

| Item | Finding | Provenance | What it means for you |
|---|---|---|---|
| Principal's path | Principal of Halvering Elementary since 2022, after nine years as a reading specialist | [grounded] Illinois principals forum speaker page, search snippet | Expect reading to be probed more closely than other areas |
| Principal's talk | 2025 forum talk Small Groups, Big Readers, covering weekly reading conferences in grades 3 to 5 | [grounded] same page, search snippet | R1 is tied to it. Do not describe your own work in the talk's vocabulary |
| Mirror opportunity | Reading is the shared ground. Your F2 sentence, "I led our grade level's move to a new reading curriculum in 2024", sits beside the principal's public record | [inferred] pairing of the page with F2 | Say the sentence as it stands and let the follow-ups come. No career jump on either side is shown in your material, so none is offered |
| Panel format | One 45-minute building panel: the principal and two grade-level teachers; panels ask about reading instruction, classroom routines and how you work with families; references are taken up after the panel | [grounded] district hiring page, fetched | Establishes the loop, so persona weights rest on it and not on an archetype |
| Values round | The hiring page names no values or principles round, so none is detected and the values cheat sheet is left out. The published beliefs still theme the VAL questions | [grounded] district hiring page, fetched | If HR says a values segment exists, ask for the cheat sheet |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A Skeptic | Quiet probing of the move from third grade to fourth | High. The principal's role is the hiring-manager relationship, which weights Skeptic, and F9 is a stated gap | Rehearse the fourth-grade objection until it is boring: plain acknowledgment once, then a plan |
| B Peer Evaluator | Teammates asking what you would need and bring, and how you handle disagreement | High. Two fourth-grade teammates sit on the panel, the peer relationship | Reciprocity framing; propose seam principles rather than pretending to know the team's seam |
| C Values/Behavioral | Scenario prompts tied to the district's three published beliefs | Medium. The beliefs and the page's family and reading topics line up, but no values round is documented | Story where a quoted sentence carries one; a scaffold with the honest branch where none does |
| D Conversational | Warm opener and open-ended closers | Medium. Panels open this way and a casual question is still scored | A short arc built only from your own sentences |
| G Case/Strategist | A live classroom or family problem; the district's literacy plan | Medium. The hiring-manager prior plus a published three-year literacy plan | Clarify first, structure, think aloud |
| E Data-Driven Prober | Probing how you know something worked | Low. Your material has no figures to probe, so this arrives as attribution and assessment questions | Say plainly what you tracked and what you did not |
| H Pressure | Time-boxed, devil's-advocate framing | Low. Nothing found points to a stress style; included so no style is met for the first time live | Pause, restate, hold the position the sentences carry, concede specifically |

## Question banks

### A Skeptic (weight highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see fourth grade in your background. What will be newest for you?" | JD | [grounded] "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet" — your CV | The highest-ROI rehearsal in this pack. Say it once, in your stated words: "I've never taught fourth grade." Then what your material carries, at its own scope: six years teaching third grade at a public elementary school in Joliet. Then a plan, said as a plan: the one or two things you would ask about or watch for in your first weeks, from your own list, since the pack supplies none. Do not say the grades are alike or that the move is small. Hold through follow-ups by returning to the two sentences and the plan | F9 is the largest gap and this question will arrive in some form; JD because it scores the posting's grade level |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | Selection scaffold: choose one real item from the rows where your own material is thinnest, say it in a sentence, then say what you would do about it in your first month, as a plan. If no such item comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Skeptic's standard probe on the JD; F5 to F9 are where it would land |
| A3 | "This role teaches reading, writing, math, science and social studies. Which of those did you teach in third grade?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" — your CV | Start from your sentence: six years teaching third grade at a public elementary school in Joliet. Answer slot: the listing this pack uses as a stand-in names five subjects, so expect a probe on each. For each one you taught, say how, in your own words; for any you did not teach, or that someone else taught, say so plainly and return to the six years of third grade | F5; the subject list comes from a general listing, not from Halvering's posting, hence inferred |
| A4 | "Why this role, and why now?" | JD | [generic] | Your material states no reason, so the pack supplies none. Give your actual reason in two sentences, in your own words, and tie it to something the school or district has published rather than something you assume. If no clear reason comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach the question | Motivation consistency is what the Skeptic checks after a stated gap (F9) |
| A5 | "You led your grade level's move to a new reading curriculum. How much of that was you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Say the sentence as it stands: you led your grade level's move to a new reading curriculum in 2024. Answer slot: expect a probe on which parts were yours. If you set any step of the move, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with leading the grade level's move. Never describe a step you did not take | F2 is your strongest reading sentence and the likeliest place to be asked about attribution |

### B Peer Evaluator (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. What would you need from us in your first month, and what would you bring?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Reciprocity framing. What you need: your own short list, since the pack supplies none. What you bring: the sentence, at its own scope, that you led your grade level's move to a new reading curriculum in 2024, offered as something you can talk through. Add nothing about how it went unless you can say it in your own words | F8; peers price what a new teammate costs and contributes |
| B2 | "Tell us about a time you disagreed with a teammate. What happened?" | EXP | [generic] | Selection scaffold: pick a time with a named stake, your position, how it was settled, and a working relationship intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F8; disagreement style with equals is the Peer Evaluator's standard probe |
| B3 | "Have you served as a team lead?" | JD | [grounded] "I've never been a team lead" — your message; "I led our grade level's move to a new reading curriculum in 2024" — your CV | Plain acknowledgment, in your own stated words: "I've never been a team lead." The move is a separate sentence: you led your grade level's move to a new reading curriculum in 2024. Keep the two apart and do not blend them into "I've led teams". Then how you would fit a team that is already formed, said as a plan | F8; stating this honestly before it is found converts a gotcha into candor |
| B4 | "Walk us through the first week of school in your room." | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" — your CV | Start from your sentence: six years teaching third grade. Answer slot: the stand-in listing's routines line makes a probe on routines likely. If you set routines, say which and how you taught them, in your own words; if there was no such step, or it was not yours, say so plainly and return to the six years of third grade | F7; the routines line comes from a general listing, hence inferred |

### C Values/Behavioral (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our first belief is Every Child a Reader. Tell us about a time you helped a child who was not yet reading where you hoped." | VAL | [grounded] "I've run the after-school reading club for the last two years" — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV | Selection scaffold: pick one child or group you can describe from your own memory, with a starting point, what you did and what changed; the pack supplies no such story. If none comes to mind, say so plainly, then give the nearest thing your material carries, the club or the curriculum move, each only at its own sentence's scope, or how you would handle it | F2; the theme is the district's first published belief |
| C2 | "Families Are Partners is one of our beliefs. How do you work with your students' families?" | VAL | [grounded] "I write a weekly email to families" — your CV | Story-map from your sentence: you write a weekly email to families, said in your own words. Answer slot: the belief says each teacher speaks with every family each term, so expect a probe on conversations beyond the email. If you spoke with families directly, say how and how often, in your own words; if there was no such step, or it was not routine, say so plainly and stay with the weekly email | F3 |
| C3 | "Teach for Tomorrow, Not for the Test. Tell us about a time assessment results changed what you taught." | VAL | [grounded] | Selection scaffold: pick an instance from your own memory with the assessment, what it showed and what you changed; the pack supplies none. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | F4; the theme is the district's third published belief |

### D Conversational (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk us through your journey so far." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | A 90-second arc with three beats, each one a sentence you wrote: six years teaching third grade; leading your grade level's move to a new reading curriculum in 2024; running the after-school reading club for two years. Close on your reason for wanting fourth grade, in your own words, since the pack supplies none. Anything you add to a beat has to be something you can repeat under a follow-up | F2 and F9; a casual opener is still scored |
| D2 | "Tell us about the reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Say what the sentence says: an after-school reading club you have run for the last two years. Add only what you can answer a follow-up on. If a follow-up asks about something you did not do or decide, say so plainly and return to running the club | F2; the principal's public reading background makes this a likely warm-up |
| D3 | "Is there anything we haven't asked that you'd like us to know?" | EXP | [generic] | Selection scaffold: pick one thing from your own material the panel's questions skipped and say it in two sentences; the pack does not choose it. If nothing comes to mind, say so plainly and thank them | The closer is scored for preparation |

### G Case/Strategist (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Your class arrives reading at very different levels. What do you need to know first, and what does your first month look like?" | CASE | [grounded] | Clarify first: what the school already knows about each child. Then objective, groupings, approach, how you would check progress, risks. Think aloud and challenge one premise respectfully. The question asks nothing about your past, so the guidance makes no claim | F2 and F6; the theme is the district's first belief |
| G2 | "A parent emails on Sunday night upset about a grade. What do you do Monday?" | CASE | [generic] | Structure: what you would acknowledge and when, what you would check before replying, whether and how you would offer a conversation, what you would record. No claim about your past | F3; a pattern for the problem, not a fact about this district |
| G3 | "The board adopted a three-year literacy plan with a new grades 3 to 5 reading curriculum from fall 2027. You led your grade level's move to a new reading curriculum. What would you want to know before teaching from it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Say what the plan says only as the Sources give it, no more. Then your own questions about it. Your account of the earlier move stays at its sentence's scope: you led your grade level's move to a new reading curriculum in 2024. Do not extend the sentence | F2; the CO differentiator, resting on a search snippet, so read the plan before Thursday |

### H Pressure (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Suppose another finalist has taught fourth grade for years. Sixty seconds: why you?" | JD | [grounded] "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet" — your CV | Pause and restate. Concede exactly what you have stated: "I've never taught fourth grade." Hold on what your sentence carries: six years teaching third grade at a public elementary school in Joliet. Hold through two follow-ups by returning to those two sentences, never by claiming to be better than another finalist or that the grades are alike | F9 under time pressure |
| H2 | "In thirty seconds: one thing you would do differently in your teaching." | EXP | [generic] | Selection scaffold: pick one real thing, say what you would change and why. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Composure; a rehearsed non-defensive answer is the target |

### E Data-Driven Prober (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How do you use assessment results to plan what you teach next?" | JD | [inferred] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Your material states no assessment practice, so the pack supplies none. Answer slot: the listing's assessment-data line and the district's third belief make this likely. If you use results to plan, say which results and what changed, in your own words; if there was no such step, or it was not yours, say so plainly and return to leading the grade level's move to a new reading curriculum in 2024 | F4 and F6 |
| E2 | "How would you know the new reading curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Say what the sentence says: you led your grade level's move to a new reading curriculum in 2024. Answer slot: if you or the grade level tracked something, say what and how you read it, in your own words; if nothing was tracked, or it was not yours, say so plainly and stay with leading the move | F2 |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 license and endorsement | none: a gate your material shows met, so no question; checking registration status is yours |
| F2 Every Child a Reader | C1, D1, D2, A5, E2, G1, G3 |
| F3 Families Are Partners | C2, G2 |
| F4 assessments inform teaching | C3, E1 |
| F5 subjects | A3 |
| F6 assessment data | E1, G1 |
| F7 classroom routines | B4 |
| F8 grade-level team | B1, B2, B3 |
| F9 fourth grade | A1, A2, A4, H1 |

Your material contains no quantified results, so no defend-the-number question appears.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5. What does that look like in a fourth-grade classroom here?" | Tied to the principal's own public path; it shows you looked at the principal, not only the school |
| R2 | "The board adopted a literacy plan with a new grades 3 to 5 reading curriculum from fall 2027. Where will fourth grade sit in that rollout, and how will teachers be involved?" | Shows current awareness and asks about the thing that will most shape your first years |
| R3 | "The district's beliefs say each teacher speaks with every family each term. How does your team handle that in practice?" | Shows you read the beliefs and invites the teammates to describe their own routine |
| R4 | "What could a new fourth-grade teacher do in their first month that would genuinely help your team?" | The reciprocity question for peer interviewers |
| R5 | "What support do teachers new to fourth grade get here?" | Owns the gap openly and asks about the ramp |
| R6 | "What does the timeline look like from here, given references are taken up after the panel?" | Practical, and tied to the district's published process |

## Prohibited claims

Built from the fit snapshot before the banks were written. No cell in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has fourth-grade teaching experience | Negative you stated, F9 | The plain acknowledgment: "I've never taught fourth grade." No slot |
| Has been a team lead | Negative you stated, F8 | The plain acknowledgment: "I've never been a team lead." The move stays its own separate sentence |
| Chose or designed the new reading curriculum | Inflated form of F2 | F2's sentence at its own scope. The limit is the pack's observation, not words for you: your material says the grade level's move, not the curriculum's choice. A5's slot stays inside the move |

## Sources

Provided documents: your invite, your resume text, your message. No dossier was present.

Searches sent, by query, with what came back:

- "Orrinsford Community School District mission values": https://orrinsfordschools.example/about/mission-and-beliefs
- "Halvering Elementary School Orrinsford fourth grade teacher interview": https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Dolores Vantongeren principal Halvering Elementary": https://ilprincipalsforum.example/speakers/dolores-vantongeren (search snippet only)
- "Orrinsford Community School District strategic plan news": https://orrinsfordschools.example/news/board-adopts-literacy-plan (search snippet only)
- "fourth grade teacher job description Illinois elementary school responsibilities qualifications": https://k12jobsboard.example/listings/fourth-grade-teacher (search snippet only; a general listing, not Halvering's posting)

Fetched: the district's mission and beliefs page, and its how-we-hire-teachers page.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | The three published beliefs by name; rows F2 to F4 and bank C |
| 2. `Orrinsford interview process, elementary teacher` | yes | Loop: one 45-minute panel, principal plus two grade-level teachers; persona weights; no values round detected, so no cheat sheet |
| 3. `Orrinsford Community School District strategy` / recent news | yes | G3 and R2, from the board's literacy plan; snippet only |
| 4. `Dolores Vantongeren Halvering Elementary` | yes | The interviewer read, R1 and the Skeptic and reading emphasis; snippet only |
| 5. representative `Fourth Grade Teacher` JD | yes | F5 to F8 and A3, B4 and E1, all inferred; the listing is general, not Halvering's |

## Upgrade menu

- The posting's full text → F5 to F8 and A3, B4 and E1 move from inferred to grounded
- Anything HR said about the panel's focus, or a task to prepare or bring → coverage and weights adjusted, plus a build section if a deliverable was announced
- The two teammates' names → a fuller interviewer read and per-member persona weights
- Your own answers to the answer slots in F2, F3 and F5 to F8 → those rows upgrade and the matching banks gain mapped stories
- The full text of the board's literacy plan and of the principal's talk page, if you can paste them → G3, R1 and R2 currently rest on search snippets
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → a grounding brief on the district's direction and recent organizational context, and sharper CO and CASE questions; say so and I will run it
- If HR confirms a values segment in the panel → a values cheat sheet mapped to the three beliefs
- A tuesday-dossier.md, if you have one → verified evidence and sharper objections; never required
