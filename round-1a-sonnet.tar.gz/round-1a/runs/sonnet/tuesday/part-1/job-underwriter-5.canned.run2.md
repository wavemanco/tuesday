I'm partway through reading the job-underwriter playbook's reference files. The evidence model, gap taxonomy, and research rules are left, and then I'll write the assessment.
**Yes, it's worth applying.** R1, R2, R3, R4a, R5 and R6 all sit at `direct`. What's still open are R9 and R10, your own limits on location and pay. · `conditional_go`

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R9 (Remote (US) or Denver office), R10 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R1, R2, R3, R4a, R5, R6
- `important`: adjacent: R4b (BigQuery warehouse); unclear: R7 (data contracts), R8 (ingestion from app and CRM)

R4b is a credible bridge via your Snowflake and dbt work, with its limit named; R7, R8: nothing in your background says either way yet.

**Opportunity ledger.** The stated pay is a strength (RR3). Reporting line and team are unknown (RR1), scope may be wider than the usual single-domain remit (RR2), and the equity terms are unstated (RR4). Funding is self-reported (RR5).

- **Hard gates:** none failed; unconfirmed: R9 (Remote (US) or Denver office), R10 (Salary $148,000–$166,000 plus equity); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R9 and R10 clear your own limits; (2) data-contract and ingestion ownership (R7, R8) turn out to be things you have done or can credibly claim; (3) BigQuery is framed honestly as adjacent, never as experience (R4b); (4) the reporting line and scope questions (RR1, RR2) get clean answers in the loop.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` company About page, fetched via search result; funding not confirmed by any outside source (RR5) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD, careers page fetched |
| Seniority read | Posting asks 5+ years; the Datawright report says Senior at Series B–D typically means 5–8 years | `[grounded]` JD and your Datawright report |
| Scope read | The posting lists three jobs (ingestion, warehouse, contracts) and names no team, direct reports or first-year outcomes. The report's typical scope is one domain's pipelines with no direct reports, so this one may be wider (RR2) | `[inferred]` from the JD's three-part mandate against the report's typical scope |
| Market calibration | The posted $148,000–$166,000 runs from just under the report's median ($151,000) to above its interquartile top ($163,500); equity on top | `[grounded]` JD and Datawright report (n=2,310, Series B–D, base pay); `[generic]` that a band is a pattern, never this employer's offer |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Unknowns | Hiring manager and reporting line; team size; first-year outcomes; equity terms; how existing data contracts are enforced | `[grounded]` JD silent on each |
| Contradictions | None: the live careers page ("Accepting applications") matches the text you pasted | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company; self-reported, expect a probe | `[grounded]` your background summary | none |
| R2 | Strong SQL and Python | must_have | direct | low | none | You state daily use of both; depth, scale and what you built with them are not stated, so `low` | `[grounded]` your background summary | a sanitized model or DAG excerpt would raise it |
| R3 | dbt | must_have | direct | medium | none | You state you built your company's dbt project, about 180 models, on Snowflake; confirmed and specific but nothing inspectable yet, expect a probe | `[grounded]` your background summary | dbt docs or lineage screenshot, sanitized, would raise it |
| R4a | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse; the JD's requirement line says "a cloud warehouse", not BigQuery specifically | `[grounded]` JD requirement line and your background summary | none |
| R4b | A dbt-modelled warehouse in BigQuery (the role's stack) | important | adjacent | medium | transferability | Your dbt modelling and testing on Snowflake carry over. Limit: you have not used BigQuery, so none of its operation, cost or access handling is exercised. Warehouses differ in cost model and in how tables are laid out for speed, so tuning habits do not carry over wholesale | `[grounded]` your statement of no BigQuery use; `[generic]` warehouse differences | see gap queue G3 |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow was your orchestrator; confirmed, no inspectable artifact | `[grounded]` your background summary | a sanitized DAG excerpt would raise it |
| R6 | Experience with data quality testing | must_have | direct | medium | none | You state you set up the Great Expectations test suite; what it covered and whether it ran in CI is not stated | `[grounded]` your background summary | Great Expectations data docs or suite config, sanitized, would raise it |
| R7 | Data contracts analysts depend on | important | unclear | none | discovery | Your background says nothing on contracts between producers and analysts | `[grounded]` your summary silent on it | see gap queue G1 |
| R8 | Ingestion from the app and CRM | important | unclear | none | discovery | Your background does not say which sources you ingested from or whether you built the ingestion | `[grounded]` your summary silent on it | see gap queue G2 |
| R9 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and any work-location limits were not given, so whether the role's terms are met is unknown | `[grounded]` JD term; no candidate constraint stated | the closing question on R9 and R10 |
| R10 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor was not given, so whether the range clears it is unknown | `[grounded]` JD term; no candidate constraint stated | the closing question on R9 and R10 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Data contracts (R7, important) | discovery | Nothing about contracts in your background | The role names contracts as something analysts depend on, so owning them is part of the job; a clear example moves R7 off `unclear` | Agreeing a schema or freshness expectation with an analytics team; alerts or tests that block breaking changes from an upstream app team; a documented column-level agreement | A schema doc, a contract or test config, a change-notice thread, sanitized | `[grounded]` JD names contracts; `[inferred]` that your Great Expectations and dbt tests may be related work |
| G2 | App and CRM ingestion (R8, important) | discovery | Your summary does not name sources or who built ingestion | The JD lists ingestion first in the mandate; the answer shows whether this is repetition of your work or new ground | Loading data from a product database or event stream; syncing a CRM or similar SaaS API into the warehouse; owning a connector or CDC job | A pipeline diagram, connector list or DAG excerpt, sanitized | `[grounded]` JD; `[grounded]` your summary silent on sources |
| G3 | BigQuery (R4b, important) | transferability | The adjacent evidence is dbt and Snowflake, about 180 models by your count. Limit: no BigQuery use. A strengthener would be a small project running a slice of your dbt modelling pattern on BigQuery | A stated platform in the role is the most likely objection to your fit, so a stronger bridge narrows it | A personal or work project touching any Google Cloud data tooling; time-boxed BigQuery exercises | A small repo or write-up showing a transformed dataset in BigQuery | `[grounded]` your no-BigQuery statement; `[inferred]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | No hiring manager or reporting line named | unknown | — | "The posting names no hiring manager" (your note on the posting) | The role may sit under a data lead, engineering or an analytics head; which one changes what you inherit | `[generic]` postings often omit managers; `[inferred]` nothing here says which | Who does this role report to, and who else is on the data team? | unresolved |
| RR2 | Scope may exceed the typical single-domain remit | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | The role could cover the whole reporting stack for a 264-person company, wider than one domain | `[inferred]` from the JD's three-part mandate against the Datawright report's typical scope | Which pipelines and datasets would I own at the start, and what's the first-year goal? | unresolved |
| RR3 | Pay stated and at or above market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range runs from just under the report's median to above its interquartile top, so the stated figure is competitive for the band | `[grounded]` JD and Datawright report; `[generic]` a band, not this employer's offer | Where in the range would this role be levelled? | noted |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | Grant size, vesting and strike may range widely; the cash range alone does not show the total package | `[generic]` equity terms vary by company; nothing in the posting fixes these | What is the equity grant, vesting schedule and strike price? | unresolved |
| RR5 | Funding and headcount are company-reported only | unknown | — | "Series C ($52M, February 2026)" | The About page and careers page are both the company's own; no outside source returned | `[grounded]` search returned only the company's own page | Can you share the funding round's lead investor or a public announcement? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check R9 and R10 against your own limits before investing in the application | They are the two hard-gate rows and nothing about them is settled | `[grounded]` R9, R10 rows | pending your approval |
| A2 | In any application text, say plainly that your warehouse work is Snowflake and that you haven't used BigQuery | Keeps R4b honest; the bridge is dbt skill, not BigQuery experience | `[grounded]` R4b row | pending your approval |
| W1 | A small BigQuery project porting a slice of your dbt modelling pattern | The strengthener named in G3 | `[grounded]` G3 | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2, RR3 and RR4 in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Series C $52M" (returned "About Pellucid Learning", pellucidlearning.com/about); fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Role reality's contradictions row: the posting is live and its text matches what you pasted; the About page matches too. Funding stays company-reported (RR5) |
| 2. Role-family sweep | skipped | Your Datawright report is in hand with median, interquartile range, seniority and scope; a search would not change the calibration or the pay read |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

I'd offer to save this as a `tuesday-dossier.md` if you want it, no pressure.

## Upgrade menu

- A sanitized dbt docs or lineage screenshot, or a repo excerpt → R3 and R2 toward `high`.
- A sanitized Airflow DAG excerpt → R5 toward `high`.
- Great Expectations data docs or suite config → R6 toward `high`.
- Your answers on location and pay → R9 and R10 settle, and the status becomes `go` or `no_go`.
- A named hiring manager → role reality's scope read, and which story the plan leads with for that reader.
- A deeper research pass on Pellucid Learning (funding, leadership changes, public employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

- R9, R10 — What are your limits on location and on base pay, and does Remote (US) or Denver at $148,000–$166,000 clear them?
- G1 — Have you ever owned an agreement between a data-producing team and the analysts who rely on it, such as schemas, freshness, or what happens on a breaking change, and what exactly was yours?
- G2 — Which source systems did you ingest from at the payroll company, and did you build the ingestion yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.