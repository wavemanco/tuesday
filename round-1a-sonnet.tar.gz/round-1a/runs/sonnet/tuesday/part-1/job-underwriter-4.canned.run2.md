Checking the company's own careers page. The search snippet says the role is Leeds-based, four days a week, which contradicts the "fully remote" in your JD.
**Probably yes, but settle R1 before you apply: the employer's careers page says Leeds office four days a week, not fully remote. Status: `hold_pending_answers`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5a, R6, R7a, R8 · unclear: R5b (Monitor rating models), R7b (recommendations for product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance product knowledge)

R1 — the posting and the careers page disagree on location; R5b, R7b — unconfirmed, one question each; R10 — a bridge with its limit named.

**Opportunity ledger.** The employer and role are live and consistent with your JD except on location (RR1). The salary is withheld (RR2). The scope and reporting line are defined (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** if four days in Leeds works for you, or the recruiter confirms remote, this moves to `conditional_go`, with R5b and R7b as the conditions. If remote is a must and the role is Leeds-based, it becomes `no_go` on R1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; careers page |
| Mandate | Own pricing analytics for the pet product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD |
| Reports to | Director of Pricing, matching the JD | `[grounded]` careers page fetched |
| Working pattern | JD says "Fully remote (UK)"; careers page says "Leeds office four days a week" | `[grounded]` JD against the fetched careers page |
| People management | The JD lists no line-management requirement | `[grounded]` JD |
| Market calibration | A pay survey of UK insurers and insurtechs gives a senior pricing analyst median base of £58,400 (interquartile range £52,100 to £64,900). This is a band to expect, never Brindlemoor's offer, since the posting withholds pay (RR2). Scope norms for the title did not come back from the sweep. | `[generic]` one survey result, read as a search snippet; `[grounded]` JD for the withheld pay |
| Hiring manager | Odile Varga, Director of Pricing. A public profile lists a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books, and six years as head of pricing analytics at Calloway Re. | `[grounded]` one search result, snippet only |
| Unknowns | Salary; the true location terms; how much of the work is for product | — |
| Contradictions | Remote versus Leeds four days a week | `[grounded]` JD against careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You have not stated a location constraint, so there is nothing to grade. The two employer sources conflict, so whether the role meets any constraint you hold is unsettled. | `[grounded]` JD and careers page disagree | G1: ask whether the gate is met |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You stated 5 years of pricing analytics at a UK motor insurer, specific but nothing inspected yet. | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You stated daily use. Confirmed, but no artifact has been seen. | `[grounded]` your message | a sanitized query or notebook would raise it |
| R4 | GLM experience | must_have | direct | medium | none | You stated you built and maintained the GLM rating model for your young-driver book. | `[grounded]` your message | a sanitized factor table or model document would raise it |
| R5a | Build rating models | must_have | direct | medium | none | Same GLM claim as R4. | `[grounded]` your message | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" does not say what was monitored or how. I took the lower reading. | `[grounded]` your wording; `[generic]` that monitoring is a common interview probe for this duty | G2 |
| R6 | Design and read price tests | must_have | direct | medium | none | You stated you ran 14 price tests last year with the underwriting team. Which parts were designed by you versus read with the team is not itemised, so expect a probe. | `[grounded]` your message; `[generic]` that attribution is probed | a sanitized test write-up would raise it |
| R7a | Recommendations for underwriting | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting and run tests with that team. | `[grounded]` your message | none |
| R7b | Recommendations for product | must_have | unclear | none | discovery | Nothing in your background mentions product-side work. | `[grounded]` silence in what you gave | G3 |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly review to the head of underwriting. Underwriting is covered. Actuarial leads are not mentioned, and the requirement says "or". | `[grounded]` your message | a sanitized review deck would raise it |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a motor insurer. | `[grounded]` your message | none |
| R10 | Pet-insurance product knowledge (inferred from the role being the pet product; the JD does not state it) | preferred | adjacent | medium | transferability | Motor GLM rating work carries over. Limit: you have not priced pet, and pet usually turns on factors motor does not have. | `[inferred]` from the role's product; `[generic]` pet-versus-motor difference | G4: bridge case below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location terms (R1, hard_gate) | hard_gate | The JD says remote and the careers page says Leeds four days a week; your constraints are not stated | A failed gate caps the decision; wording cannot solve it | — | The recruiter's written confirmation of the working pattern | `[grounded]` two conflicting sources |
| G2 | Model monitoring (R5b, must_have) | discovery | You built and maintained the young-driver GLM; monitoring is not described | A must-have, and the hiring manager's published talk is on monitoring (see role reality) | Tracking actual versus expected after launch; drift or stability checks; a scheduled model review; a refit triggered by monitoring | A sanitized monitoring pack, a dashboard screenshot, a model review note | `[grounded]` gap in your wording; `[inferred]` that the talk makes this row weigh more |
| G3 | Product-side recommendations (R7b, must_have) | discovery | Your recommendations go to underwriting | The JD names product as a recipient | A test result that changed a proposition or feature; a pricing paper for a product or commercial owner | A sanitized recommendation memo | `[grounded]` silence on product |
| G4 | Pet knowledge (R10, preferred) | transferability | Motor GLM work is adjacent to pet rating | A preferred row, so a minor risk | Personal-lines rating work that carries over | A short note on how you would approach pet's different risk factors | `[inferred]` adjacency; `[generic]` that pet uses different factors |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location contradiction | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The posting copy may be stale or re-advertised, or the role may have changed. It is unproven which source is right. | `[inferred]` from two sources disagreeing | Is this role fully remote or Leeds four days a week, and what will the contract say? | unresolved |
| RR2 | Salary withheld | unknown | — | JD gives no salary | The figure may sit anywhere in or around the survey band | `[generic]` band; `[grounded]` JD silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Defined scope and reporting line | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | The mandate is concrete and the careers page matches it | `[grounded]` JD and careers page | What does success look like in year one? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with Brindlemoor before investing in the application | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with the three things you said: the young-driver GLM you built and maintained, the 14 price tests you ran with underwriting, and your quarterly review to the head of underwriting. Say only what you did. | see R4, R6, R8 | `[grounded]` your message | pending your approval |
| P2 | If you have monitoring evidence (G2), put it near the top, since the hiring manager has spoken publicly on monitoring | see R5b | `[grounded]` search result; `[inferred]` the emphasis | pending your approval |
| P3 | Frame pet as adjacent: your GLM rating work carries over, and you have not priced pet | see R10 | `[grounded]` your message | pending your approval |
| P4 | If asked about managing people, say plainly you have not line-managed; the JD lists no such requirement | see role reality | `[grounded]` your message; JD | pending your approval |
| Q1 | Ask the RR1, RR2 and RR3 questions verbatim in the process | the register doubles as interview preparation | `[grounded]` register | pending your approval |

If you go ahead, resume-tailor can turn P1–P3 into an approve-first CV edit ledger.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance careers"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). The posting is live and consistent except on location: this produced R1, RR1 and the working-pattern row. |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), snippet only. It moved the market calibration row; scope norms were not established. |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), snippet only. It moved the hiring manager row, G2 and P2. |

I'll save this as `tuesday-dossier.md` if you want a copy to carry forward; say the word.

## Upgrade menu

- Your answer on location, plus any pay floor or other non-negotiables → R1 closes and the hard-gates check runs against your real constraints.
- A sanitized monitoring pack, drift report or model review note → R5b can move to `direct`.
- A product-facing recommendation you made → R7b can close.
- A sanitized price-test write-up, factor table or quarterly review deck → R3, R4, R6 and R8 can reach `high`.
- The budgeted salary → RR2 closes against the survey band.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news, public employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Is four days a week in a Leeds office workable for you, or is fully remote a condition for you?

G2 — Have you personally owned monitoring of the young-driver GLM after launch? What did you track, how often, and did anything prompt a change?

G3 — Have you taken a price-test result to a product or commercial owner rather than underwriting, and what did they decide?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.