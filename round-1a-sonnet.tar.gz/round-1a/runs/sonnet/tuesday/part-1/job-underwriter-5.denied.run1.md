**Decision snapshot**

**Yes, worth applying, on conditions. Status: `conditional_go`.** The five `must_have` rows R3, R4, R5, R7 and R8 are `direct`, but R1 and R2 are not yet confirmed and the employer is not independently verified (RR1).

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R7, R8
- `important`: adjacent: R6 (a dbt-modelled warehouse in BigQuery); unclear: R9 (ingestion from our app and CRM), R10 (data contracts our analysts depend on)

R6 — Snowflake is the nearest evidence, with its limit named; R9, R10 — your background is silent on both.

**Opportunity ledger.** Sound but unverified. The employer and live posting rest on text you pasted (RR1), the reporting line is unnamed (RR2), and the remit's breadth is unplaced against the report's one-domain norm (RR3). Equity is unquantified (RR4). One entry runs the other way: the posted pay range (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and pay floor confirmed against R1 and R2; (2) the employer and live posting verified (RR1); (3) BigQuery framed honestly as adjacent to your Snowflake work, never as experience (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026). Not independently checked | `[grounded]` company page text you pasted |
| Mandate | Build and run the reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity; equity amount unstated | `[grounded]` JD |
| Reporting line | No hiring manager named | `[grounded]` posting, as you reported |
| Scope read | Ingestion, warehouse and contracts together read as end-to-end data platform ownership. The report's typical senior scope is one domain's pipelines | `[inferred]` from the JD's three responsibilities against the report's stated scope |
| Market calibration | At Series B–D companies, base median $151,000, interquartile range $139,000–$163,500; "Senior" typically 5–8 years, no direct reports. The posting's low end sits $3,000 under the median and its top $2,500 over the 75th percentile. This is the band to expect, not this employer's offer | `[generic]` Datawright 2026 report (n=2,310) from your recruiter; `[grounded]` JD range |
| Unknowns | Team size, reporting line, equity terms, whether pay varies by location, first-90-day outcomes | `[grounded]` JD silent on each |
| Contradictions | None between the JD and the company text, but both came from the employer's own site | `[grounded]` the two texts as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization were not stated, so the gate is neither met nor failed | `[grounded]` JD term; no constraint given | G1 |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your pay floor was not stated; the posted range cannot be tested against it | `[grounded]` JD range; no constraint given | G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years at a B2B payroll company. It is prose self-report with no artifact, so `medium` is the ceiling | `[grounded]` your background, prose | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You stated daily use of both. "Strong" is unprobed and no artifact was inspected | `[grounded]` your background, prose | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You stated you built the dbt project on Snowflake, about 180 models. Confirmed and specific, with no inspectable artifact yet; expect a probe on model design | `[grounded]` your background, prose | A sanitized dbt docs page or repo excerpt would raise it to `high` |
| R6 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Snowflake and dbt are the nearest evidence. Limit: you have never used BigQuery. Warehouse-specific cost and layout behaviour is what a probe would test | `[grounded]` your statement; `[generic]` that warehouses differ in cost and layout model | W1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You stated Airflow orchestration; its scale and your ownership of it are unstated | `[grounded]` your background, prose | none |
| R8 | Data quality testing | must_have | direct | medium | none | You stated you set up the Great Expectations suite; coverage and use are unstated | `[grounded]` your background, prose | A sanitized suite config would raise it to `high` |
| R9 | Ingestion from our app and CRM | important | unclear | low | discovery | Airflow work is indirect context only; the sources you ingested are unstated | `[grounded]` your background silent on sources | G2 |
| R10 | Data contracts our analysts depend on | important | unclear | low | discovery | Great Expectations and dbt tests are adjacent signals. Nothing states agreed schemas or analyst-facing guarantees | `[inferred]` from your test work; nothing stated on contracts | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay floor (R1, R2) | hard_gate | Neither your location nor your floor is stated | Two hard gates sit unconfirmed; either failing ends the decision | Not a recall item; a statement of your own terms | None needed | `[grounded]` gates unstated |
| G2 | Ingestion and contracts (R9, R10) | discovery | Orchestration, dbt and testing are established; ingestion sources and analyst-facing agreements are not | Two `important` rows stay `unclear` and could move to `direct` or `adjacent` | Pipelines from a product database or a CRM into the warehouse; agreeing schema changes with the engineers who produced the data; source freshness checks; documented definitions analysts relied on | A DAG listing, a schema doc, a sanitized test config | `[grounded]` background silent; `[generic]` that ingestion and contracts are core to this role family |
| G3 | BigQuery (R6) | transferability | Snowflake plus dbt, never BigQuery | The posting names BigQuery as the warehouse | Bridge: dbt design carries across warehouses. Limit: you have not run BigQuery workloads. Strengthener: a small dbt project run against BigQuery | A short public or private repo with a README | `[grounded]` posting and your statement; `[generic]` that interviews probe warehouse specifics |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not independently verified | risk_signal | low | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The JD and company text agree but both come from one site, so a stale posting or mismatched entity is not ruled out yet. Severity is low because the text is the employer's own | `[generic]` pattern for unchecked postings, not a claim about this company | Is this role still open, and what is your hiring timeline? | unresolved |
| RR2 | Reporting line and team unnamed | unknown | — | "The posting names no hiring manager" (your report) | Who the role reports to and how many data peers exist cannot be placed | `[grounded]` posting silent | Who does this role report to, and who is on the data team today? | unresolved |
| RR3 | Remit wider than the report's one-domain norm | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role may carry platform-level ownership, possibly as the first or only data engineer. Severity is low because the remit may simply be a team's | `[inferred]` from the JD set against the report's stated scope | Is this the team's only data engineer, and who owns the warehouse today? | unresolved |
| RR4 | Equity unquantified | unknown | — | "$148,000–$166,000 plus equity" | Grant size, vesting and valuation are unstated, so total pay cannot be assessed | `[grounded]` JD silent | What is the equity grant at this level, its vesting, and the latest valuation? | unresolved |
| RR5 | Pay range spans the market median | positive_signal | — | "$148,000–$166,000 plus equity" | The range runs from just below the report's median to above its 75th percentile, so it does not read as a seniority-pay mismatch | `[inferred]` from the JD range against the `[generic]` report quartiles | Where in this range does an offer for this role usually land? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your location and pay floor against the posting before investing effort | see R1, R2 | `[grounded]` R1, R2 rows | pending your approval |
| W1 | A small dbt project run against BigQuery, as a work sample | see R6, G3 | `[grounded]` R6 row | pending your approval |
| P1 | Lead with the dbt project (about 180 models, on Snowflake), the Airflow orchestration and the Great Expectations suite you set up; name Snowflake plainly and claim no BigQuery use | see R5, R7, R8, R6 | `[grounded]` your own statements | pending your approval |
| Q1 | Ask the register's questions RR1–RR5 verbatim with the recruiter or interviewers | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search and the fetch of the careers page were both refused, so nothing returned. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | skipped | The pasted Datawright report is in hand and fixes the market calibration line and RR5 |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

I can also save this as a `tuesday-dossier.md` to carry forward, if you want it.

**Upgrade menu**

- Permission for me to search and fetch the careers page and company site: RR1 and the organization row of role reality can be verified.
- Your location, work authorization and pay floor: R1 and R2 move to `direct` or `hard_gate_fail`, and the decision firms up.
- An answer to G2: R9 and R10 could move off `unclear`.
- A sanitized dbt docs page or repo excerpt and a Great Expectations suite config: R5 and R8 could move from `medium` toward `high`. Your resume would also allow tailoring to this role, which is a separate module (resume-tailor).
- The hiring manager's name: role reality's scope read and the positioning in P1 could be set for that reader.
- The employer's answers to RR2–RR4: the unknowns close.

**Questions**

G1 — What is your minimum base salary, and are you based in the US (or able to be in Denver)?

G2 — At the payroll company, did you own ingestion from an application database or a CRM, and did you agree schemas or data guarantees with the teams producing or consuming the data? What was specifically yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.