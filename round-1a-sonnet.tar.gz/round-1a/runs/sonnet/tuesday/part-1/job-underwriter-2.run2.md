Loading done. I'm running two research searches, one on Quartzline itself and one on what the market expects for this kind of API PM role. Then I'll write the full assessment.
**Decision snapshot**

**No, you're not wasting your time on this role, but it's a stretch. Status: `conditional_go`.** R3 and R4 land `direct`, and R2 and R5 are open, not closed. R1a (three or more years of titled PM experience) cannot be closed with evidence, because you have never held the title.

**Fit ledger.**

- `must_have` — direct: R3, R4 · adjacent: R1b (PM work under another title), R2 (Shipped API or platform product) · unclear: R5 (Owning the roadmap) · absent: R1a (3+ years titled PM)
- `important` — adjacent: R6 (Partner discovery), R7a (Writing specs), R9 (Launches with sales and support) · unclear: R7b (Agile delivery with squads), R8 (Adoption metrics)

R1a — the titled-years line, the one row the CV cannot answer; R1b and R2 — credible bridges, limits named; R5 (`low`) — waiting on the triage-tool answer.

**Opportunity ledger.** The employer could not be checked (RR1), pay is not stated (RR2), and the posting's must-have line is a titled-years screen your CV does not meet (RR3). The scope itself is concrete (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline verifies as a live employer with this role on its own careers page (RR1); (2) your answer on the triage tool lands and moves R5 and R2 (G1); (3) the application leads with R1b and names its limit, and R1a is routed to a human reader rather than a keyword screen (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B, as the posting describes itself | `[grounded]` JD header; not verified against any outside source |
| Mandate | Own the roadmap for a partner-facing API platform, with two engineering squads | `[grounded]` JD |
| Success measures | Adoption metrics are named, but no targets or first-year outcomes are stated | `[grounded]` JD silence on targets |
| Scope read | A single-product remit with a clear owner seat, not a bundle of unrelated jobs | `[inferred]` from one platform, two squads and one stakeholder list |
| Market calibration | Not calibrated: the role-family sweep did not run, so there is no pay band or title-norm comparison | `[grounded]` search refused, see Evidence status |
| Unknowns | Pay, location and work authorization, hiring manager, whether "3+ years" can be met by non-titled PM work | `[grounded]` JD silence |
| Contradictions | None visible inside the JD and resume as provided | `[grounded]` provided documents only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years of product management experience under a PM title | must_have | absent | none | capability | You have never held the title, so no row of evidence can satisfy it as written. The JD marks it "must-have", but a years-of-experience line is graded as a requirement, not a gate. Screens often apply such a line literally | `[grounded]` your statement; `[generic]` literal screening | G4: carry as a material risk; route to a human reader |
| R1b | Product management work done under another title | must_have | adjacent | medium | transferability | 30+ integrations scoped end to end, an internal playbook, and quarterly roadmap-input sessions are PM-shaped work. Limit: you fed roadmap decisions to product managers and did not make them | `[grounded]` resume | Lead with this and state the limit |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You delivered integrations against REST APIs and wrote the team playbook. Limit: nothing says you owned an API product that shipped to users | `[grounded]` resume; limit `[inferred]` from the resume's silence | G5: a work sample would narrow the limit |
| R3 | Technical fluency: API docs and schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading and 30+ REST integrations all point the same way. `medium` because nothing has been inspected | `[grounded]` resume | none |
| R4 | Stakeholder management across engineering, sales and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and product managers on custom builds. Limit: sales is not mentioned anywhere in the resume | `[grounded]` resume | none |
| R5 | Owning the roadmap and prioritization | must_have | unclear | low | discovery | The resume shows roadmap input, not ownership. An earlier-conversation note suggests you built an internal request-triage tool that support agents adopted; that is unconfirmed and works only as a question | `[inferred]` from a memory lead, unconfirmed | G1: Q1 |
| R6 | Discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and quarterly client feedback sessions are partner-facing, but they served delivery and product input, not a discovery practice you ran for a product | `[grounded]` resume | none beyond G1 |
| R7a | Writing specs | important | adjacent | medium | transferability | You wrote requirements documents and integration architecture for client builds. Limit: those were client-side specs, not specs for squads building a product | `[grounded]` resume | G5 |
| R7b | Agile delivery with engineering squads | important | unclear | low | discovery | The resume says you coordinated engineers but names no agile practice, cadence or squad | `[grounded]` resume silence | G3: Q2 |
| R8 | Defining and tracking adoption metrics | important | unclear | none | discovery | The resume gives no adoption measure. The triage tool, if confirmed, may be the one example | `[grounded]` resume silence | G1: Q1 |
| R9 | Launches with sales and support | important | adjacent | medium | transferability | A client go-live is a launch of a kind. Limit: it launched an integration for one client, not a product to a market | `[grounded]` resume | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Roadmap ownership and adoption metrics (R5, R8) | discovery | Roadmap input but no ownership; no adoption measure | R5 is a `must_have` at `unclear`; this answer is the likeliest to move it | A tool or process you decided to build; how you chose what to build next; how you knew people used it | A usage screenshot, a short write-up of the tool, a request list | `[grounded]` resume silence; `[inferred]` that this may move R5 |
| G2 | Shipped product evidence (R2) | transferability | Integrations and a playbook, no owned product | The JD's second requirement; the bridge is credible but visibly limited | The playbook's rollout across your team; any request you turned into a build | The playbook (sanitized), an adoption note | `[grounded]` resume |
| G3 | Agile delivery (R7b) | discovery | Coordination with engineers, no named practice | An important row at `unclear` | Sprint planning, backlog grooming, or release coordination with a build team | A ticket board export or release note | `[grounded]` resume silence |
| G4 | Titled PM years (R1a) | capability | No PM title | A must-have line that evidence cannot satisfy | Not a recall problem; closure paths: a PM-titled role elsewhere, a PM-scoped internal assignment, or targets that do not screen on titles | None | `[grounded]` your statement; `[generic]` that titles are screened literally |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small for a footprint, the posting may be stale, or it may not be a live hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | no pay figure appears in the JD | The posting may withhold pay, or it may simply not publish it | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Titled-years must-have against a title-less candidate | risk_signal | medium | "3+ years product management experience (must-have)" | The line may be read literally by a screen or a recruiter and filter you out before your integration work is read | `[generic]` pattern on years-of-experience lines | Does the 3+ years include product work done under another title, such as solutions or implementation leadership? | unresolved |
| RR4 | Concrete scope and delivery capacity | positive_signal | — | "Own the roadmap ... drive delivery with two engineering squads" | Scope and delivery capacity are defined | `[grounded]` JD | What outcomes does this role own in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the 30+ REST integrations, the playbook and the roadmap-input sessions, each in your own words; mark the roadmap sessions as input to product, never ownership | see R1b, R2, R6 | `[grounded]` resume | `resume_edits_pending_approval` |
| A1 | Verify Quartzline's own careers page and recruiter domain before applying | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Seek a referral or a direct note to the hiring manager so a person reads the application against the titled-years line | see R1a, RR3 | `[generic]` role-family pattern, not a fact about this employer | pending your approval |
| Q1 | Ask the verification questions in RR1 to RR4 verbatim in the first conversation | the register doubles as interview preparation | `[grounded]` register | pending your approval |

Nothing above is final until you approve it, and this covers the prose in the plan as well as the table.

## Evidence status

Verified: none yet. Unverified leads: the request-triage tool noted from an earlier conversation, unconfirmed, used only as a question.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused for lack of permission. It would have confirmed whether Quartzline exists as described and whether the role is live, feeding RR1 and role reality |
| 2. Role-family sweep | unavailable | The search was refused for lack of permission. It would have given a pay band and title norms for the market calibration row and the RR2 comparison |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

## Upgrade menu

- Permission to search, or a link to Quartzline's own careers page → RR1 and R-level role reality firm up, and the market calibration row gets a pay band.
- The hiring manager's name → role reality's scope read and which story the plan leads with.
- A sanitized copy of the integration playbook → R2 and R7a toward `high`.
- A usage record or write-up of the triage tool → R5 and R8 move from `unclear`.
- A deeper research pass on Quartzline (up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want this saved, I can emit it as `tuesday-dossier.md`.

Questions:

G1 — Tell me about the request-triage tool, if it is yours. Did you decide what it should do, who used it, and how did you know they adopted it? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 — On custom builds, did you work inside an agile cadence with engineers, such as sprints, backlog or release planning? What was your part in it?

Constraints — What are your non-negotiables on pay, location or remote, and work authorization for this role?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.