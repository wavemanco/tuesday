Search access was denied, so I underwrote from your pasted JD and resume summary alone. Here is the full first pass.

## Decision snapshot

**No, you are not wasting your time on this role. R3 and R4a read `direct`, and R1b, R2a, R5 and R6 read `adjacent`. R1a, the titled-years requirement, is `absent`, and RR1 is the risk it creates. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (PM work, any title), R2a (API integration work), R5 (Own the roadmap), R6 (Specs, two squads) · unclear: R2b (Any shipped product), R4b (Sales stakeholders) · absent: R1a (Titled PM years)
- `important` — adjacent: R7 (Partner discovery), R9 (Launches with sales, support) · unclear: R8 (Adoption metrics), R10 (Agile delivery)

R1a (`none`) — a title gap, carried by RR1; R1b, R2a, R5, R6 — real adjacent work, limits named in the map; R2b — a lead waiting on your word.

**Opportunity ledger.** The mandate is concrete, with named squads and adoption metrics (RR4). The open items are the literal titled-years reading (RR1), unstated pay (RR2), an employer I could not check (RR3), and unstated first-year outcomes (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the team counts PM work done under another title toward the years line — R1a, R1b, RR1; (2) you confirm a product you owned and shipped, or the integration and playbook work is accepted as the API-product evidence — R2a, R2b; (3) the employer and live posting verify — RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` the JD as you pasted it; unchecked, see RR3 |
| Mandate | Own the partner-facing API platform roadmap, run partner discovery, write specs and drive delivery with two squads, track adoption, coordinate launches with sales and support | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | A mid-level platform PM post | `[inferred]` from the "3+ years" line and the two-squad count |
| Market calibration | Not established; the role-family sweep could not run, so there is no pay or scope band | `[grounded]` search refused |
| Unknowns | Pay, decision rights, reporting line, first-year outcomes, whether the team accepts PM work done under another title | `[grounded]` JD silent on each |
| Contradictions | None visible inside the JD; the careers page was not checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, titled | must_have | absent | none | capability | You said you have never held a PM title, so nothing under that title exists. Length of experience is not a gate, so this is graded like any row; the substance is R1b. A literal reading of the line is the risk (RR1) | `[grounded]` your statement; `[generic]` that years lines are often read literally | No wording closes this; carried as RR1, ask its question early |
| R1b | Product-management work, whatever the title | must_have | adjacent | medium | transferability | Your summary shows requirements documents, integration architecture, roadmap-input sessions and coordination with PMs. Limit: it all served client builds or fed product's roadmap; nothing states you prioritised for a product or answered for its outcomes. Self-reported, nothing inspectable yet | `[grounded]` resume summary | G4 |
| R2a | Shipped API or platform products: the API integration work | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs and wrote the playbook the whole team uses. Limit: that is the implementation side of an API plus an internal playbook, not shipping an API product | `[grounded]` resume summary | Offer: the playbook, sanitized, as the inspectable artifact |
| R2b | Shipped API or platform products: any product you owned and shipped | must_have | unclear | low | discovery | Your summary states none. An earlier-conversation note suggests an internal request-triage tool that support agents adopted; unconfirmed, so it prompts a question and nothing more | `[inferred]` from a memory lead, derivation named | G1 |
| R3 | Technical fluency: API docs and schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading, plus seven years of integration architecture, state this directly. Medium because intake prose has no inspectable artifact | `[grounded]` resume summary; `[generic]` that fluency claims get probed on schemas | Optional: a sanitized integration-architecture diagram would raise to `high` |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and product managers, and ran workshops, UAT and go-live with clients | `[grounded]` resume summary | none |
| R4b | Stakeholder management with sales | must_have | unclear | none | discovery | The summary names engineering, clients and PMs; sales does not appear | `[grounded]` resume silence | G2 |
| R5 | Own the partner API platform roadmap | must_have | adjacent | medium | transferability | Quarterly roadmap-input sessions gathered client feedback for product. Limit: that is input to someone else's roadmap; whether you shaped priorities or trade-offs is not stated | `[grounded]` resume summary | G4 |
| R6 | Write specs and drive delivery with two engineering squads | must_have | adjacent | medium | transferability | Requirements documents and coordinating engineers on custom builds are close in activity. Limit: those were client-build specs; nothing states you worked a standing squad's backlog or answered for what shipped | `[grounded]` resume summary | G4 |
| R7 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and roadmap-input sessions are with the same kind of counterpart. Limit: scoping one client's integration differs from discovery that shapes a product bet, and what happened to the feedback is unstated | `[grounded]` resume summary | G5 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | SQL gives you the tooling; nothing states you defined or tracked adoption measures | `[grounded]` SQL listed, metrics unmentioned | G3 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Client go-lives are close. Limit: those are customer launches of integrations, with no stated sales or support partnership | `[grounded]` resume summary | G5 |
| R10 | Agile delivery experience | important | unclear | low | discovery | UAT and go-live on custom builds are indirect; sprints, backlogs and squad cadence are not mentioned | `[grounded]` resume summary | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Any shipped product (R2b, must_have) | discovery | No product you owned is stated; one unconfirmed lead about a support-facing tool | Resolving it could turn R2b from `unclear` toward `adjacent` or `direct`, which bears on condition 2 | An internal tool others adopted; a playbook or template that changed how a team worked; a workflow you specified and engineers built | Usage numbers, a spec, a screenshot, or a note from the support lead | `[grounded]` resume silence; `[inferred]` that it bears on the decision |
| G2 | Sales stakeholders (R4b, must_have) | discovery | Sales is absent from the summary | A named must-have the summary does not touch | Joint client calls with account executives; deal-support or pre-sales scoping; feedback loops between clients and sales | A deck, an email thread, or a pre-sales checklist | `[grounded]` resume silence |
| G3 | Adoption metrics and agile delivery (R8, R10) | discovery | SQL and UAT are present; defining measures and running sprints are not | Both are `important` and either may already exist in your history | Tracking integrations live per client or time-to-go-live; working inside a sprint cadence with engineers | A dashboard, a query, or a go-live tracker | `[grounded]` resume silence |
| G4 | Roadmap, specs and delivery ownership (R1b, R5, R6, transferability) | transferability | Strong adjacent work with its limit at the decision | This is the bridge: honest framing is "close adjacent work, accountability for priorities unconfirmed". A work sample would narrow the limit | Feedback you brought that was built; a spec an engineering team built from | A roadmap-session summary, or a spec with a shipped outcome | `[grounded]` rows R1b, R5, R6; `[generic]` that this is the usual objection |
| G5 | Partner discovery and launches (R7, R9, transferability) | transferability | Same counterparts, different purpose | Limit: client scoping is not product discovery | Workshops whose findings changed a product or process | A session write-up or go-live runbook | `[grounded]` rows R7, R9 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Titled-years line may be read literally | risk_signal | medium | "3+ years product management experience (must-have)" | A screen or recruiter may reject on title-years before reading the substance in R1b | `[generic]` pattern for years-of-title lines; `[grounded]` the JD marks it must-have | "Would the team count 3+ years of product work done under another title, and have you hired anyone through that path?" | unresolved |
| RR2 | Pay not stated | unknown | — | none given in the pasted JD | Cannot be calibrated, since the market sweep did not run | `[grounded]` JD silent | "What salary band is budgeted for this role?" | unresolved |
| RR3 | Employer not established from attributable sources | risk_signal | low | "B2B logistics-tech, ~150 people, Series B" | Not checked: both searches were refused. Pattern for unverified postings, not a claim about this company; severity kept at the lower value for that reason. Caps the decision at `conditional_go` | `[generic]` pattern, not a claim about this employer | "Can you point me at this role on your careers site, and who would I be interviewing with?" | unresolved |
| RR4 | Concrete mandate | positive_signal | — | "two engineering squads; define and track adoption metrics; coordinate launches with sales and support" | Responsibilities are specific and measurable | `[grounded]` JD | "Which product decisions does this role make alone, and which go to a head of product or engineering?" | noted |
| RR5 | First-year outcomes not stated | unknown | — | the JD lists duties, no 6- or 12-month outcomes | Success is undefined in the posting | `[grounded]` JD silent | "What would success look like twelve months in?" | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask RR1's question at the first contact, before investing in a full loop | see R1a, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Seek a human route: a referral, or a direct note to the hiring manager, alongside the portal | Roles with a literal years line tend to clear more easily through a person than a screen: a pattern, not a fact about Quartzline | `[generic]` | pending your approval |
| E1 | Reorder the resume so the 30+ integrations, the playbook and the roadmap-input sessions lead. Describe the work as what it was (solutions and implementation), with no PM title or PM-years claim and no new facts | see R1b, R2a, R5 | `[grounded]` resume summary | `resume_edits_pending_approval` |
| W1 | A one-page work sample: an adoption-metrics and roadmap proposal for a partner API, built only from public material | narrows the limits in R5, R8 | `[grounded]` rows R5, R8 | pending your approval |
| Q1 | Ask the register's verification questions (RR1 to RR5) verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

resume-tailor can turn E1 into an approve-first edit ledger once you decide to apply.

## Evidence status

Verified: none yet. Unverified leads: an earlier-conversation note about an internal request-triage tool, which prompts G1 and nothing more. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search was sent ("Quartzline logistics technology company API platform careers") and refused. It would have moved role reality's organization and contradictions rows and RR3 |
| 2. Role-family sweep | unavailable | One search was sent ("Product Manager platform API partner integrations salary requirements…") and refused. It would have moved market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can offer a full dossier file, `tuesday-dossier.md`, from this assessment if you want one.

## Upgrade menu

- Your actual resume text instead of the summary → raises R1b, R2a and R3 where dates, tools and outcomes are quantified.
- A sanitized playbook, an architecture diagram or a go-live record → R2a and R3 toward `high`.
- Your answer to G1 → R2b, and likely the biggest move in the fit.
- Search access → role reality's market calibration, RR2 and RR3.
- The hiring manager's name → role reality's scope read, and which story the plan leads with.

**Questions**

- G1 — An earlier note suggests you built an internal request-triage tool that support agents adopted; I haven't confirmed it. Is that right, and if so, what did you own, how many people used it, and how did you know it worked?
- G4 — In the quarterly roadmap-input sessions, what happened to the feedback you gathered? Is there an item that product built, or reprioritised, because of you?
- G2 — Have you worked with sales or support when a customer-facing change launched, and what part was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.