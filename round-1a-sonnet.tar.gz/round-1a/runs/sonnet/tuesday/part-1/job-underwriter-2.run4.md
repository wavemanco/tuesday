I'm still loading the underwriting playbook's reference files, so I haven't written any of the assessment yet. Next I'm reading the evidence rules and the output format, then I'll write it.
# Underwriting: Product Manager, Platform APIs at Quartzline

## Decision snapshot

**No, this isn't a waste of your time, but it is a stretch: R1a (3+ years in a titled PM role) is absent, and R1b and R2 are adjacent. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (PM-type work without a PM role), R2 (shipped API or platform products) · unclear: R4b (stakeholder management with sales), R5 (agile delivery) · absent: R1a (3+ years product management experience)
- `important` — direct: R7 · adjacent: R6 (own the roadmap), R8 (specs and delivery with two squads) · unclear: R9 (adoption metrics), R10 (launches with sales and support)

R1a — the posting's own must-have, with no titled years behind it; R2 — API work seen from the implementer's side; R9 — resume silent on adoption metrics.

**Opportunity ledger.** The role is clearly scoped around one partner-facing API platform (RR5). Level, pay and location are unstated (RR3) and decision rights are unevidenced (RR4). The titled-years requirement is a screening risk (RR2). The employer is unchecked from here (RR1).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR2 is settled, meaning a recruiter or hiring manager confirms that non-titled product work can count toward R1a; (2) RR1 clears, meaning the live posting and employer check out; (3) your answers to G1 firm up R2 and R9 into something you can show.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B, as the JD states it | `[grounded]` JD header; not checked against the company's own pages (RR1) |
| Mandate | Own the partner-facing API platform roadmap, run partner discovery, write specs, drive two engineering squads, track adoption metrics, coordinate launches with sales and support | `[grounded]` JD |
| Stated must-have | 3+ years PM experience is the only item the JD labels must-have | `[grounded]` JD |
| Scope read | The post bundles roadmap, discovery, specs, delivery, metrics and launches under one owner. That is a wide remit but not unusual for a single platform product | `[inferred]` from the JD's responsibility list; no outside comparison ran |
| Role-family norms | Platform and API PM roles commonly hire from technical implementation backgrounds, so your path is plausible. This is a pattern, not a claim about Quartzline's hiring | `[generic]` |
| Market calibration | Not done. The role-family search was refused, and the JD states no level or pay | `[grounded]` search refused; JD silent on level and pay |
| Unknowns | Level, pay, location or remote policy, who sets cross-squad priorities, the current adoption baseline | `[grounded]` JD silence |
| Contradictions | None visible inside the JD. It was not checked against a careers page | `[grounded]` JD as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, as a titled PM role | must_have | absent | none | transferability | You have never held a PM title, so the titled years do not exist. The adjacent work is carried separately in R1b. | `[grounded]` your statement | See G3: carry the bridge and its limit; ask the recruiter how this is read (RR2) |
| R1b | The work of product management: roadmap input, requirements, working with PMs and engineers | must_have | adjacent | medium | transferability | Specific and plausible: roadmap-input sessions, requirements documents and coordinating with PMs on custom builds. It is limited to feeding product and supporting delivery. Nothing shows owning prioritization or outcomes, and nothing inspectable has been seen. | `[grounded]` resume prose, unconfirmed beyond your own account | G3 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | discovery | You led 30+ end-to-end integrations of your employer's REST APIs and wrote the integration playbook the team uses. That is API work from the implementer's side, not shipping the product. A memory lead about a request-triage tool is not counted until you confirm it. | `[grounded]` resume prose; `[inferred]` adjacency; memory lead excluded | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading and integration architecture across 30+ projects. Self-reported, nothing inspected, so `medium`: expect a technical probe. | `[grounded]` resume prose | none |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs, and ran client workshops and UAT through go-live. Self-reported. | `[grounded]` resume prose | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | The resume does not mention sales. Nothing here shows or rules out the work. | `[grounded]` resume silence | G2 |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | The resume names no delivery method. Coordinating builds with engineers is only indirect context. | `[grounded]` resume silence | Optional; not asked this turn, which is a lower-ranked gap |
| R6 | Own the roadmap | important | adjacent | medium | transferability | Your quarterly roadmap-input sessions fed the roadmap. Nothing shows you deciding priorities or trade-offs. | `[grounded]` resume prose; `[inferred]` limit | G3 |
| R7 | Run discovery with integration partners | important | direct | medium | presentation | Scoping workshops and client feedback sessions with integrating clients are the same activity. The resume labels it as implementation, not discovery. | `[grounded]` resume prose | Wording is pending; see the plan |
| R8 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | You wrote requirements documents and coordinated engineers. Nothing shows you owning a squad's backlog or delivery. | `[grounded]` resume prose; `[inferred]` limit | G3 |
| R9 | Define and track adoption metrics | important | unclear | none | discovery | The resume gives no evidence of defining or tracking adoption. | `[grounded]` resume silence | G1 |
| R10 | Coordinate launches with sales and support | important | unclear | low | discovery | A memory lead involves support agents adopting a tool, which could bear on this. It is unconfirmed, so it can only prompt a question. | `[grounded]` resume silence; memory lead | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Something you built that others adopted (R2, R9) | discovery | A memory lead about a request-triage tool support agents adopted. Nothing confirms what it was, what you owned, or how adoption was known. | It is the one thing that could move R2 from implementer's-side work toward product ownership, and could supply R9's missing metric evidence. | An internal tool or process you defined, and the usage numbers you watched. A playbook change you measured. A feature request you carried into product and saw shipped. | A one-page spec or brief, a usage screenshot, the playbook itself (sanitized) | `[grounded]` memory lead unconfirmed; `[generic]` that this role's interviews probe ownership versus support |
| G2 | Sales and launch coordination (R4b, R10) | discovery | The resume is silent on sales and on launches. | Both sit inside the JD's responsibilities and its stakeholder requirement, and nothing here speaks to them. | A client go-live you coordinated with an account executive. Enablement material you wrote for sales or support. A release you announced to partners. | A launch checklist, an enablement doc, a go-live comms thread (sanitized) | `[grounded]` resume silence |
| G3 | Bridge for the titled-years requirement (R1a, R1b, R6, R8) | transferability | Adjacent evidence: roadmap input, requirements and delivery coordination across 30+ integrations. Limit: nothing shows owning prioritization, a backlog or outcomes. | R1a is the JD's stated must-have and cannot be closed by wording; the bridge and its limit are all you can honestly present. | See G1: anything where you decided and others acted on it. | A work sample: a short spec or roadmap proposal for a partner-facing API | `[inferred]` bridge derived from the resume; `[generic]` that titled-years requirements are often screened literally |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not checked from here | unknown | — | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The stated size and stage were not compared with the company's own pages because the searches were refused. | `[grounded]` searches refused; `[generic]` that unchecked postings are a standing risk | Can you point me to this role on your careers site, and tell me who I would work with? | unresolved |
| RR2 | Titled-years requirement may be screened literally | risk_signal | medium | "3+ years product management experience (must-have)" | A reader may treat this as a title bar rather than a skills bar. | `[generic]` pattern for titled-years requirements; not a claim about Quartzline | Would you count seven years leading partner-facing API integrations toward this requirement, or does the post need a prior PM title? | unresolved |
| RR3 | Level, pay and location not stated | unknown | — | "Product Manager, Platform APIs" (no level, pay or location given) | The figures may sit outside your range, or may simply not be in the posting. | `[inferred]` from the JD's silence | What level and pay band is this post, and is it remote or office-based? | unresolved |
| RR4 | Roadmap ownership against decision rights | unknown | — | "Own the roadmap … drive delivery with two engineering squads" | The post may own outcomes while priorities across the squads are set elsewhere. | `[inferred]` from the JD's scope against its silence on authority | Who sets priorities across the two squads, and which roadmap decisions does this role make alone? | unresolved |
| RR5 | Single, clearly named product focus | positive_signal | — | "Own the roadmap for our partner-facing API platform; run discovery with integration partners" | The role's users are integration engineers, and the scope is stated concretely. | `[grounded]` JD states the focus | Who are the main integration partners today, and what does adoption look like now? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter RR2's question before investing in the loop | See R1a, RR2 | `[grounded]` RR2 | pending your approval |
| A2 | Verify the live posting on Quartzline's own careers site, or ask the recruiter for it | See RR1 | `[grounded]` RR1 | pending your approval |
| W1 | A one-page work sample: a spec or roadmap proposal for a partner-facing API change you would prioritize and why | Narrows R1b, R6, R8's stated limit; it must be your own thinking, not a claim about work you did | `[grounded]` the R1b, R6, R8 rows | pending your approval |
| Q1 | Ask the questions in RR3 and RR4 verbatim in interviews | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Resume edits for this role are resume-tailor's job, best done after you've decided to apply.

## Evidence status

Verified: none yet. Unverified lead: a prior-context mention of a request-triage tool, unconfirmed, used only to prompt G1. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Quartzline logistics technology Series B partner API platform", "Quartzline Product Manager Platform APIs careers") were refused and returned nothing. They would have moved role reality's organization and contradictions rows and RR1. |
| 2. Role-family sweep | unavailable | One search ("platform API product manager hiring requirements solutions engineer transition to product management") was refused and returned nothing. It would have moved the market calibration row and RR2, RR3. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. A name would feed the scope read and which story the plan leads with. |

I've stopped trying to search. Everything labeled `[generic]` above is pattern, not fact about Quartzline.

I can save this as a `tuesday-dossier.md` you can reuse in later steps, if you'd like.

## Upgrade menu

- Search access, or the live posting and Quartzline's careers page → RR1 and role reality's contradictions row close; market calibration and RR2's pattern can be checked.
- The recruiter's answers on RR2 and RR3 → the decision likely simplifies to `go` or `no_go`.
- An answer to G1 with an inspectable artifact (a spec, a usage screenshot, a sanitized playbook) → R2 and R9 can rise above `medium`.
- An answer to G2 → R4b and R10 move off `unclear`.
- A prior resume or LinkedIn profile → may show product-flavored evidence the current resume omits.
- A hiring manager's name → the scope read and the plan's lead story.
- Your constraints (location, pay floor, work authorization) → hard-gate checks stop being unknown.

## Questions

G1 — Did you ever build or define something others adopted, such as an internal tool, process or playbook change? What did you own, and how did you know it was used?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Have you coordinated a go-live or release with sales or support, for example enablement material or a launch checklist? What was yours?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Constraints — Do you have non-negotiables on location or remote work, pay floor, or work authorization that this role could touch?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.