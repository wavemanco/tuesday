# Job Underwriting — Senior Data Engineer, Pellucid Learning

## Decision snapshot

**Yes, this looks worth applying to, on three conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R9 (Remote US or Denver), R10 (Pay $148,000–$166,000 plus equity)
- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — adjacent: R6 (BigQuery as the warehouse); unclear: R7 (Ingestion from app and CRM), R8 (Data contracts for analysts)

R6 — a credible bridge, its limit named; R7, R8 — your background is silent, so they wait on answers; R9, R10 — wait on your own constraints.

**Opportunity ledger.** Pay is stated and sits in the market's upper half (RR3). The people side is thin: no manager or team size named (RR1), scope spans three areas (RR2), employer facts are unchecked from here (RR4), and equity terms are unstated (RR5).

- **Hard gates:** none failed; unconfirmed: R9 (Remote US or Denver), R10 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and pay floor checked against R9 and R10; (2) team, reporting line and scope confirmed in the first call — RR1, RR2; (3) the BigQuery gap stated plainly as adjacent, never as BigQuery experience — R6.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about text you pasted; not checked against the live page (RR4) |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | Three areas under one title (ingestion, warehouse, contracts), with no team or reporting line named. This may be end-to-end ownership of the reporting data stack | `[inferred]` from the JD's list of areas against its silence on team |
| Market calibration | Posted band $148,000–$166,000: midpoint $157,000, above the Series B–D Senior Data Engineer base median of $151,000; low end $3,000 below that median; top above the upper quartile ($163,500). The report puts "Senior" at 5–8 years, with one domain's pipelines and no direct reports. This is the band to expect, not Pellucid's offer | `[generic]` Datawright 2026 report you were sent (US, n=2,310); `[grounded]` posting's figures |
| Unknowns | Hiring manager and team; equity terms; first-year outcomes; whether the posting is live as pasted | — |
| Contradictions | None between the JD and about text as pasted. The live pages were not checked | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company; stated, not yet probed, so `medium` | `[grounded]` your background as stated | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. "Strong" is a depth judgement that nothing inspectable yet shows | `[grounded]` your background as stated | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | You state building your company's dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse, so the requirement as worded is met | `[grounded]` your background as stated | none |
| R4 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration. Your own part in it (building versus using) is not stated | `[grounded]` your background as stated | none; your part will come up when you describe it |
| R5 | Experience with data quality testing | must_have | direct | medium | none | You state that you set up your company's Great Expectations test suite | `[grounded]` your background as stated | none |
| R6 | BigQuery as the warehouse | important | adjacent | medium | transferability | The dbt modelling layer carries over from Snowflake. Limit: nothing you described touched BigQuery, so warehouse-specific behaviour is unexercised. Teams hiring into a named warehouse often ask about it directly | `[grounded]` your stated Snowflake work and never using BigQuery; `[generic]` that such roles probe the named warehouse | see G1 |
| R7 | Ingestion from the app and CRM | important | unclear | low | discovery | The JD names these sources. Your background is silent on source-system ingestion. A payroll company plausibly had some, but that is not evidence | `[grounded]` JD text and your background's silence | see G2 |
| R8 | Data contracts analysts depend on | important | unclear | low | discovery | Your background is silent on contracts or on agreed interfaces with analysts | `[grounded]` JD text and your background's silence | see G3 |
| R9 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | The posting states the terms; where you are based and what you would accept have not been given | `[grounded]` JD; no constraint stated by you | Q1 below |
| R10 | Base $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The posting states the band; your pay floor has not been given | `[grounded]` JD; no constraint stated by you | Q1 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery as the warehouse (R6, important) | transferability | Bridge: about 180 dbt models on Snowflake. Limit: no BigQuery use. Strengthener: a small dbt project of your own run on BigQuery | The posting names BigQuery as the warehouse, so the gap will likely surface in a screen | A personal or side dbt project on BigQuery; a migration or evaluation you took part in that touched it | A repo or README of that project | `[grounded]` your stated work and gap; `[generic]` that named-warehouse gaps get probed |
| G2 | Ingestion from the app and CRM (R7, important) | discovery | Silent on source-system ingestion | The JD lists it first among the responsibilities, so it may decide the call | Pipelines loading from a product database, event stream or CRM; a connector or sync you built or maintained | An architecture diagram or a pipeline DAG screenshot, sanitized | `[grounded]` JD and your background's silence |
| G3 | Data contracts (R8, important) | discovery | Silent on contracts | The JD names the analysts' dependence on them | Agreed schemas or SLAs with analysts; schema-change checks that blocked breaking changes; Great Expectations suites that doubled as agreements | A sanitized schema spec, a contract doc or a test-suite summary | `[grounded]` JD and your background's silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | No hiring manager or team named | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the only or one of very few data engineers, with the reporting line unclear | `[inferred]` from the posting's silence on team and manager | Who would I report to, and who else is on the data team today? | unresolved |
| RR2 | Scope wider than the report's typical remit | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role may carry the whole reporting data stack. Between low and medium, so the lower is taken; the three areas could also be one domain | `[inferred]` from the JD's scope against the report's typical single-domain scope | Which of these three areas does this role own end to end, and what already exists versus gets built from scratch? | unresolved |
| RR3 | Pay stated, at or above the market median | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is transparent and competitive for the stage. Compared by midpoint and quartile, it is not an offer | `[grounded]` posting; `[generic]` band from the pay report you were sent | Where in that range would an offer for my background sit? | noted |
| RR4 | Employer facts not checked from here | unknown | — | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The facts may well be accurate, as they come from the company's own page; I could not open the live page or posting | `[grounded]` pasted text, unchecked | Can you point me at this role on your own careers page, and tell me who I would interview with? | unresolved |
| RR5 | Equity terms unstated | unknown | — | "plus equity" | Type, amount and vesting are unknown, so the equity cannot be weighed against the base | `[inferred]` from the posting's silence | What form is the equity (options or RSUs), how much, and on what vesting and exercise terms? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check R9 and R10 against your location and pay floor before investing effort | Hard-gate rows are unconfirmed | `[grounded]` R9, R10 rows | pending your approval |
| A2 | Lead with dbt, Airflow and Great Expectations, stated as you described them: dbt on Snowflake, about 180 models; Great Expectations suite set up; Airflow for orchestration | These match R3, R4 and R5 | `[grounded]` your background as stated | pending your approval |
| A3 | Say plainly that you haven't used BigQuery, then offer the dbt and Snowflake work as the nearest match. Claim neither BigQuery nor data-contract experience unless G2 or G3 produces it | The honest bridge for R6; claims beyond your evidence fail the first follow-up | `[grounded]` R6, R8 rows | pending your approval |
| A4 | Ask RR1, RR2, RR4 and RR5 verbatim in the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I sent two fetches (the Senior Data Engineer careers page and the about page) and both were refused for lack of permission. Role reality's organization and contradictions rows and RR4 rest on your pasted text alone |
| 2. Role-family sweep | skipped | The pay report you quoted is in hand and fixes the market calibration, the RR3 comparison and the scope norm |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there is no query to form |

## Upgrade menu

- Permission to open Pellucid's careers and about pages → RR4 and the contradictions row close; the posting is confirmed live.
- Your location and lowest acceptable base → R9 and R10 resolve; the decision likely becomes `go` or `no_go`.
- An answer to G2 or G3, or a sanitized diagram or test-suite summary → R7 or R8 rises from `low`.
- A small dbt-on-BigQuery repo → R6's limit narrows.
- The hiring manager's name → the scope read and which story to lead with.
- A deeper pass on Pellucid (funding, leadership churn, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you'd like, I can save this as `tuesday-dossier.md` so later steps start from it.

Questions:

- **Q1 (R9, R10):** Where would you work from, Denver or remote in the US, and what is the lowest base salary you would accept?
- **Q2 (G2):** At the payroll company, did you build or maintain pipelines loading from product or CRM-type source systems, and what part was yours?
- **Q3 (G3):** Did you agree schemas or data-quality expectations with analysts or other teams, and how were they enforced?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.