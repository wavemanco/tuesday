Running the job-underwriter on this. Web search was denied, so everything below rests on what you pasted.

## Decision snapshot

**Yes, worth applying to, once the posting verifies. Status: `conditional_go`.** Your must-haves R2, R3, R4, R5, R6 and R7 are all `direct`. Having no pet-insurance experience is R9 (`adjacent`), a tier below must-have.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — direct: R8a · adjacent: R9 (Pet-insurance domain knowledge) · unclear: R8b (Recommendations to product)
- `preferred` — direct: R10

R9 — a credible bridge, its limit named; R6 (`medium`) — design ownership waiting on an answer; R8b — nothing yet on the product side.

**Opportunity ledger.** Pending checks, nothing found against the role: the employer and live posting are unchecked (RR1), pay is not stated (RR2), and team size and reporting lines are not stated (RR3). One entry runs the other way: the posting names concrete outputs (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting verify on its own careers page (RR1); (2) your UK base is confirmed (R1); (3) the pet gap is framed as adjacent, never as pet expertise (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; not checked against any other source |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message |
| People management | The JD states no direct reports or management duty, so your never having managed anyone touches no map row | `[grounded]` JD silent |
| Scope read | A senior individual-contributor post | `[inferred]` from "Own pricing analytics" beside no stated team |
| Market calibration | Not established: no search ran, so no salary or scope band | — |
| Unknowns | Salary; team size; modelling stack; who in product consumes the recommendations | — |
| Contradictions | None within the pasted JD | `[grounded]` JD, one source only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | Your location and right to work are not stated; a UK employer suggests it without establishing it | `[inferred]` from your UK motor-insurer role | G1: confirm you are UK-based and can work in the UK |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years pricing analytics, 2 as senior analyst; self-reported, nothing inspectable yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Both stated as daily use; "strong" is unprobed, so expect a technical probe | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book, which is the JD's core method | `[grounded]` your background | offer: a sanitized model specification would raise to `high` |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" covers building; monitoring is implied by maintaining and not separately stated | `[grounded]` your background | none |
| R6 | Design and read price tests | must_have | direct | medium | discovery | "Ran 14 price tests with underwriting" is the same work; whether you designed them (hypothesis, sizing, readout) is not stated, so claims stay at "ran" | `[grounded]` your background | G2 |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background | offer: a sanitized review deck would raise to `high` |
| R8a | Recommendations for underwriting | important | direct | medium | none | Tests run with underwriting and a quarterly review presented to its head | `[grounded]` your background | none |
| R8b | Recommendations for product | important | unclear | low | discovery | Nothing in your background touches a product team | `[grounded]` your background silent | G3 |
| R9 | Pet-insurance domain knowledge | important | adjacent | medium | transferability | The GLM method carries over; the rating factors, claims patterns and cover structures of pet are untouched by motor work. The JD's insurance "plus" does not name pet-specific experience | `[inferred]` requirement, from the product named in the JD; `[generic]` that pet rating factors differ from motor's | G4: bridge case |
| R10 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK base (R1) | hard_gate | Nothing states where you live or work from | A location term the posting sets; unconfirmed it stays on the hard-gates line | Not applicable: a yes or no on the term | None needed | `[grounded]` JD term, your message silent |
| G2 | Test design ownership (R6, must_have) | discovery | Your 14 tests were run with underwriting; who framed them is not established | Moves R6 from "ran" to "designed", and a test readout is likely to be probed | Writing the test brief; choosing the hypothesis, cells or holdout; sizing the test; defining the success metric; owning the readout | A sanitized test brief or readout | `[grounded]` your 14-tests line; `[generic]` that readouts get probed in interviews for this title |
| G3 | Product-facing recommendations (R8b, important) | discovery | No product-side work is described | The JD names product as a recipient of your recommendations | Presenting a pricing change to a product or commercial team; a rating-structure or cover change you proposed that someone acted on | A sanitized recommendation paper | `[grounded]` your background silent; `[generic]` that pricing roles often serve more than one stakeholder |
| G4 | Pet-insurance knowledge (R9, important) | transferability | Motor GLM work, no pet exposure | The likeliest objection to your application | Bridge: the same GLM build, monitoring and test discipline on a different book. Limit: you have not rated for pet-specific factors such as breed or age, or handled pet claims patterns. Strengthener: a short note on how you would approach pet rating from your motor method (a work sample, pending your approval) | A one-page approach note | `[inferred]` bridge, derived from your GLM and test work; `[generic]` that the factors differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from here | risk_signal | low | "Brindlemoor (insurtech)" | No search could run, so nothing is confirmed in either direction; taking the lower severity because no result exists against the employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | No salary figure in the JD | The figure is unknown from the text provided | `[grounded]` JD silent | What is the salary range budgeted for this role? | unresolved |
| RR3 | Team size and reporting lines unstated | unknown | — | "Own pricing analytics" | Ownership may mean a lone analyst or a small team; the JD does not say | `[inferred]` from "Own" against no stated team | Who else works on pricing, and does this role have, or expect to have, direct reports? | unresolved |
| RR4 | Concrete outputs named | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope is defined by named deliverables | `[grounded]` JD | Which of those is the first priority in the opening months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV, resume_edits_pending_approval: lead with "Built and maintained the GLM rating model for the young-driver book" and "Ran 14 price tests with the underwriting team (last year)", keeping "ran" until G2 is answered | R4, R6 | `[grounded]` your own sentences | pending your approval |
| E2 | Positioning on pet: say "no pet-insurance experience; same GLM build, monitoring and testing discipline on a different book", never claiming pet expertise | R9 | `[grounded]` your own sentences | pending your approval |
| E3 | On management: say plainly that you have not managed anyone and don't imply mentoring or leadership | R-none; RR3 | `[grounded]` your own sentence | pending your approval |
| Q1 | Ask RR1, RR2 and RR3 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm the posting is live on Brindlemoor's own careers page before applying | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Brindlemoor pet insurance insurtech" and "Brindlemoor careers Senior Pricing Analyst" were refused; it would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | The search "Senior pricing analyst pet insurance UK salary remote" was refused; it would have given the market calibration row and a salary band for RR2 |
| 3. Hiring manager's public footprint | unavailable | The search "Odile Varga Director of Pricing" was refused; it would have informed the scope read and which story to lead with |

## Upgrade menu

- Granting web search: the three targets above run, and RR1 and RR2 close or sharpen.
- A sanitized model specification or monitoring pack → R4 and R5 to `high`.
- A sanitized price-test brief or readout → R6 to `high`, and G2 resolves.
- A sanitized quarterly pricing review deck → R7 to `high`.
- Your CV as a document → E1 and E2 are audited against its exact lines instead of your summary.

I can save this as `tuesday-dossier.md` if you want it to carry into later steps.

G1 — Are you UK-based and able to work in the UK on a fully remote basis for a UK employer?

G2 — On your 14 price tests, what did you personally own: the hypothesis, the design and sizing, the success measure, or the readout to underwriting?

G3 — Have you ever taken a pricing recommendation to a product or commercial team rather than underwriting, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.