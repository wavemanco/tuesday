Both web searches were refused, so this runs on your posting and your background alone.

## Decision snapshot

**No, this one isn't worth pursuing. R1 and R2, both hard gates, fail. Status: `no_go`.** The "off" feeling is real, and it comes from the terms, not from your fit.

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (Base pay $70–85k), R2 (On-site Austin 5 days a week)
- `must_have`: direct: R3, R4, R5
- `important`: unclear: R6 (SEO/content), R7 (Brand and PR), R8 (Partnerships and sales ops)

R1, R2 — failed terms, wording can't fix them; R3, R4, R5 — your stated background meets them; R6, R7, R8 — nothing you've told me covers them.

**Opportunity ledger.** The role conflicts with your pay floor (RR1) and your remote-only rule (RR2). Separately, it bundles several functions into one solo seat (RR3), signals always-on hours (RR4), gives no stable success metrics (RR5), and the employer is not established (RR6).

- **Hard gates:** failed: R1 (Base pay $70–85k), R2 (On-site Austin 5 days a week).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** a base of at least $150k (R1) and permission to work remotely from Portland (R2). The posting says "no exceptions" on location, so I'd expect neither.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting; the claims are unverified because search was refused |
| Mandate | Own revenue growth across paid, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` posting |
| Team and reporting | Team of one to start; reports to the CEO, dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus unquantified "meaningful equity" | `[grounded]` posting |
| Success metrics | "Will evolve as we learn", so none are defined | `[grounded]` posting |
| Scope read | Several full roles folded into one seat, for a "team of one" | `[inferred]` from the seven functions listed against the single hire |
| Market calibration | Not established: the role-family search was refused. I won't quote a market band from memory. | `[grounded]` search refused |
| Unknowns | Equity size and terms, budget, decision rights, whether the posting is live on Novaline's own careers page | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay $70–85k (your floor: at least $150k) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated floor. The failure is that the posting's top figure sits $65k under it. | `[grounded]` posting and your stated floor | Surface only; the employer would have to change the terms |
| R2 | On-site Austin 5 days a week (you are remote-only, in Portland) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated constraint. The posting rules out remote work in its own words, "no exceptions". | `[grounded]` posting and your stated constraint | Surface only |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You report 9 years, with Head of Growth and growth lead titles at two B2C subscription companies. It's your own account with nothing yet inspectable, so `medium`. A length-of-experience line is not a gate. | `[grounded]` your stated background | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid, with a budget you controlled during the $8M to $40M ARR scale-up. Self-reported, so expect a probe. | `[grounded]` your stated background | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze. Self-reported, so expect a probe. | `[grounded]` your stated background | none |
| R6 | SEO/content | important | unclear | low | discovery | Nothing in your background mentions SEO or content. | `[grounded]` silence in your account | Recall prompt G1 |
| R7 | Brand and PR | important | unclear | low | discovery | Nothing in your background mentions brand or PR. | `[grounded]` silence in your account | Recall prompt G2 |
| R8 | Partnerships and sales ops | important | unclear | low | discovery | Nothing in your background mentions partnerships or sales ops. | `[grounded]` silence in your account | Recall prompt G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, important) | discovery | Your account covers paid, lifecycle and experimentation, but not organic | `important`, so it could shape a pitch, but it can't offset R1 and R2 | A content or SEO program you directed, organic share of acquisition, an agency you managed | A channel-mix report or traffic dashboard | `[grounded]` silence in your account; `[inferred]` that it can't move the decision, since R1 and R2 are failed terms |
| G2 | Brand and PR (R7, important) | discovery | No brand or press work mentioned | Same as G1 | A rebrand, launch press, brand-tracking study | A launch brief or coverage list | `[grounded]` silence in your account |
| G3 | Partnerships and sales ops (R8, important) | discovery | No partnership or sales-ops work mentioned | Same as G1 | Affiliate or channel deals, CRM-to-sales handoffs | A deal list or process doc | `[grounded]` silence in your account |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay below your floor (R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | The pay is incompatible with your $150k floor. It may also sit low for a leader owning seven functions, but I couldn't check the market. | `[grounded]` posting figure against your floor; `[inferred]` on the seniority mismatch, from the 8+ years and mandate against the stated base | Is the base negotiable, and what are the equity percentage and vesting? | confirmed |
| RR2 | On-site 5 days a week, no exceptions (R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The posting closes off remote work in its own words. | `[grounded]` posting against your remote-only constraint | Is any remote arrangement possible for this role? | confirmed |
| RR3 | Bundled specializations with no team | risk_signal | medium | "team of one to start — we believe in players who don't need a bench" | Several full roles are folded into one seat with no stated budget or decision rights. | `[inferred]` from the seven listed functions against the single hire and the posting's silence on budget | What budget and decision rights come with this role, and when is the first hire planned? | unresolved |
| RR4 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | The hours expectation is open-ended and defined by the employer. | `[inferred]` from the posting's wording | What does a typical week look like, and how often do evenings and weekends happen? | unresolved |
| RR5 | No defined success metrics on a heavy mandate | risk_signal | medium | "success metrics will evolve as we learn" | You'd be accountable for revenue growth with no agreed definition of success. | `[inferred]` from the posting's wording | What does success look like at 90 days and at 12 months? | unresolved |
| RR6 | Employer not established | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | I couldn't check the company or the posting because search was refused. Possible reasons stay open: a small footprint, a stale posting, or no real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who I'd interview with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't spend application effort on this posting at its current terms | see R1, R2 | `[grounded]` R1 and R2 rows | pending your approval |
| P2 | If you decide to proceed anyway, ask RR1 and RR2's questions before anything else, since those two are what decide it | The register travels with you | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Novaline e-commerce enablement startup Austin Head of Growth" was refused. It would have moved role reality's organization and contradictions rows and the employer-not-established entry (RR6). |
| 2. Role-family sweep | unavailable | The search "Head of Growth salary startup Series A base salary range 2026" was refused. It would have moved the market calibration line and RR1's seniority-pay comparison. |
| 3. Hiring manager's public footprint | n/a | No name was given; the posting says only "the CEO". |

## Upgrade menu

- A link to the live role on Novaline's own careers page, or the recruiter's email domain → RR6 closes.
- The employer's actual budgeted base and equity terms → RR1 is updated, but the failed R1 and R2 would stay the deciding rows unless both terms change.
- Your SEO, brand/PR and partnerships/sales-ops history → R6, R7 and R8 firm up. That wouldn't change the status.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.