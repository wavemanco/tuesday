I've read the posting and run three searches (Quillfield, pay band, Tamsin Achebe's public profile). The full underwriting follows.

## Decision snapshot

**Yes, apply, but as a stretch: the billing-data side is a real gap, and Bristol and the pay are unconfirmed. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3, R4, R5 · adjacent: R6 (Experience owning a forecast) · unclear: R7a (Working with finance on revenue data) · absent: R7b (Working with billing data)
- `important` — direct: R8

R6 — a credible bridge, its limit named; R7b — a capability gap with a closure path; R5 (`medium`) — usage stated, depth unproven.

**Opportunity ledger.** The posting is clear and discloses pay inside the market band (RR1). Open points are who owns billing data and the forecast today (RR3), the option terms (RR4), and whether the posting is live on Quillfield's own site (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm Bristol two days a week and the pay work for you — R1, R2; if either fails this becomes `no_go`; (2) RR3's answer shows billing data and the forecast come with support, since R7b is a gap and R6 is adjacent; (3) you frame R6 and R7b plainly as what they are.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants; founded 2018 in Bristol; 96 employees; £11M Series A closed April 2025 | `[grounded]` "About Quillfield" page, quillfield.co.uk/about |
| Terms | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly forecast with the CFO | `[grounded]` posting |
| Scope read | One lead role spans four areas: CRM, billing data, reporting and forecasting. The posting does not say whether a team sits under it | `[inferred]` from the mandate list against the posting's silence on team |
| Market calibration | Pay guide: UK B2B software revenue operations lead, median base £64,200, interquartile range £57,800–£70,400. The posted band sits inside that range, around the median. The band is what to expect, not this employer's offer | `[generic]` Ledgerline 2026 UK pay guide, n=438; the snippet gives no Bristol split; `[grounded]` the posted figure |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years | `[grounded]` public profile snippet; the recruiter's naming of her is your report |
| Unknowns | Team size; current owner of billing data; who produces the forecast today; option grant and vesting; new role or backfill | — |
| Contradictions | None between the recruiter's statement and the public profile. The role itself did not surface on Quillfield's own site (RR2) | `[grounded]` search results |

## Evidence map

Your background is self-report from this conversation, so claims stay at `medium` at most until something inspectable is seen.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You have not stated location or commute constraints, so the gate is unsettled | `[grounded]` posting; no candidate statement | Gate question G1 |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | No pay floor stated; the posted band is mid-market, but whether it meets your floor is unknown | `[grounded]` posting; `[generic]` band position | Gate question G2 |
| R3 | 4+ years in revenue ops, sales ops or similar at a B2B software company | must_have | direct | medium | none | Five years of sales operations, the last two in revenue operations, exceed the years and match the function. Whether a B2B payments company counts as "B2B software" is the employer's call, a minor point | `[grounded]` your stated background | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; the certificate is inspectable but not yet seen | `[grounded]` your stated background | Offer: certification proof would raise to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | direct | medium | discovery | SQL weekly and Excel daily show use. How deep the SQL goes, and whether you have built financial or forecast models, is not stated, so "strong" is unproven | `[grounded]` your stated background | Offer: a sanitized query or model sample |
| R6 | Experience owning a forecast (the role runs the quarterly forecast with the CFO) | must_have | adjacent | medium | transferability | You have never owned the company forecast; finance did. Adjacent work: you run the monthly pipeline review with your sales director. Limit: that review is a pipeline view, not owning forecast numbers or answering to a CFO | `[grounded]` your stated background; `[inferred]` adjacency | Bridge case in G3 |
| R7a | Working with finance on revenue data (the posting says "billing or revenue data") | must_have | unclear | low | discovery | Renewal dashboards touch revenue figures, but you did not say whether you worked with finance on them | `[inferred]` from the renewal dashboards you rebuilt | Question G4 |
| R7b | Working with billing data, which the role owns | must_have | absent | none | capability | You have never worked on billing data. Billing is the posting's first-named data responsibility | `[grounded]` your own statement | Closure path in G5 |
| R8 | Pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt your team's pipeline and renewal dashboards; the dashboards themselves are not yet inspected | `[grounded]` your stated background | Offer: sanitized screenshots would raise to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Bristol two office days (R1, hard_gate) | hard_gate | Nothing on where you live or can work | A failed gate ends the case whatever the fit | — | — | `[grounded]` no statement given |
| G2 | Pay (R2, hard_gate) | hard_gate | The band is posted; your floor is not | Same | — | — | `[grounded]` no statement given |
| G3 | Forecast ownership (R6, must_have) | transferability | You run the monthly pipeline review; finance owned the forecast | The posting makes the forecast a core duty. The bridge is the pipeline review; the limit is that you never owned forecast numbers or answered to a CFO | Pipeline coverage or conversion assumptions that finance used; commit or best-case calls you made | A sanitized pipeline review deck | `[grounded]` your statements; `[generic]` that forecast ownership is core to this title |
| G4 | Finance on revenue data (R7a, must_have) | discovery | Renewal dashboards exist; no finance collaboration stated | Could move R7a to `adjacent` and soften R7b | Reconciling closed-won against invoiced revenue; renewal or ARR figures finance signed off | A reconciliation sheet or a renewal report finance used | `[grounded]` CV-style silence |
| G5 | Billing data (R7b, must_have) | capability | None, in your own words | The role owns billing data at an invoicing company | Closure path: learn the invoice, credit-note and subscription data model and build a worked ARR bridge from sample data, so you can say what you did, not claim experience | A small sample bridge you built | `[grounded]` your statement; `[inferred]` closure path |
| G6 | SQL depth, modelling (R5, must_have) | discovery | Frequency stated, depth not | "Strong" is the posting's word | Multi-table joins behind the dashboards; any forecast or scenario workbook | A sanitized query or model | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay disclosed and mid-band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | Terms are transparent and sit around the market median | `[grounded]` posted figure; `[generic]` Ledgerline band | Does the band flex with experience? | noted |
| RR2 | Posting not seen on Quillfield's own site | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The role may be listed only on the job board, or my search did not reach a careers page | `[grounded]` only the About page surfaced | Is this role open now, and who beyond Tamsin would I interview with? | unresolved |
| RR3 | Who owns billing data and the forecast today | unknown | — | "own our CRM and billing data … run the quarterly revenue forecast with the CFO" | The role may take on both while finance still holds the source systems, or it may be a new function | `[inferred]` from the scope language against the posting's silence on current owners | Who owns billing data and builds the forecast today, and what moves to this role? | unresolved |
| RR4 | Option terms unstated | unknown | — | "plus share options" | Value and vesting cannot be judged | `[inferred]` from silence on grant, vesting and strike | What is the option grant, vesting schedule and strike price? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the pipeline and renewal dashboard rebuild and the monthly pipeline review you run | R8, R6 | `[grounded]` your statements | pending your approval |
| A2 | Say plainly that finance owned the forecast and that what you ran was the pipeline review with your sales director | Keeps R6 as the honest adjacent bridge | `[grounded]` your statements | pending your approval |
| A3 | Say plainly you have not worked on billing data, and bring a concrete plan to learn it | R7b; a stated gap reads stronger than a discovered one | `[inferred]` from the gap | pending your approval |
| A4 | Ask RR1–RR4's questions verbatim at the recruiter stage | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | With Tamsin Achebe, lead with the sales-operations pipeline work, since her public profile shows a sales operations background | Reader-fit only; no inference about preferences | `[inferred]` from her public career pattern | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers Revenue Operations Lead"; page: "About Quillfield" (quillfield.co.uk/about). Confirmed the employer exists as described and moved the organization row. No careers-page listing surfaced for the role, which is RR2 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software forecast ownership"; page: "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved market calibration and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; page: "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the hiring-manager row and A5 |

If you'd like me to keep a record of this assessment, I can write it up as a `tuesday-dossier.md` for you.

**Upgrade menu**

- Your location and pay floor → R1 and R2 close, and the decision becomes `go` or `no_go`.
- Proof of your Salesforce certification → R4 to `high`.
- Sanitized dashboard screenshots, or a sample query or model → R8 and R5 toward `high`.
- An answer to G4 → R7a resolves, and R7b's framing improves.
- A link to the role on Quillfield's own careers page, or the recruiter's email domain → RR2 closes.
- A deeper research pass on Quillfield (funding, leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches) → fuller risk register. Say the word and it runs.

**Questions**

G1 — Can you do two days a week in the Bristol office?

G2 — What is your pay floor, and does £61,500–£67,000 clear it?

G4 — Have you worked with your finance team on revenue data, such as reconciling closed-won deals against invoiced revenue or renewal figures finance used? If so, what was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.