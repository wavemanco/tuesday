The two web searches I tried were refused. I can't check Novaline from here, so I'm answering from your message alone.

## Decision snapshot

**No, this one isn't worth pursuing as posted. R1 and R2, both hard gates, fail. Status: `no_go`.** Your "something feels off" is right. The match on paper is real, but the posting fails your two non-negotiables on its own stated terms.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site in Austin office 5 days a week), R2 (Compensation: $70–85k base)
- `must_have` — direct: R3, R4, R5
- `important` — adjacent: R9 (Team of one to start) · unclear: R6 (SEO/content), R7 (Brand, PR, partnerships), R8 (Sales ops)

R3, R4, R5 — the substance you cite as your match; R1, R2 — the failures are in the terms, not in your skills.

**Opportunity ledger.** The posting pairs a head-level, seven-function, one-person mandate with $70–85k base (RR1, RR3), and adds always-on hours and success metrics left undefined (RR4, RR5). Budget, authority and equity are unstated (RR6, RR7), and the employer is unverified (RR8). The one positive is the direct report to the CEO (RR9).

- **Hard gates:** failed: R1 (On-site in Austin office 5 days a week), R2 (Compensation: $70–85k base)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** the role would have to be workable fully remote from Portland (R1), and base would have to reach at least your $150k floor (R2). The posting says "no exceptions" on location and the top of its range is $65k under your floor.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, "e-commerce enablement startup, Series A, profitable since day one" | `[grounded]` the posting's own description; not independently verified (research refused) |
| Mandate | All revenue growth: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | Team of one to start; reports to the CEO, dotted line to the board | `[grounded]` JD |
| Hours | "Evenings and weekends when it matters is just who we are" | `[grounded]` JD |
| Success metrics | "Success metrics will evolve as we learn" | `[grounded]` JD |
| Location | On-site Austin, 5 days a week, "no exceptions" | `[grounded]` JD |
| Compensation | $70–85k base plus unquantified "meaningful equity upside" | `[grounded]` JD |
| Scope read | A "Head" title and seven functions with no team looks like one hire absorbing what are usually several roles | `[inferred]` from the function list against "team of one" and the pay band |
| Market calibration | Not established. Both research calls were refused, so no market band is claimed. The only comparison I can make is arithmetic: the top of the posted range is $65k below your floor | `[grounded]` JD figure and your floor |
| Unknowns | Marketing budget, decision rights, equity size and terms, who the first hires would be | `[grounded]` JD silence |
| Contradictions | None found between the JD and your message | `[inferred]` from the two sources only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin office 5 days a week, "no exceptions" (your constraint: remote-only, Portland, not relocating) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own confirmed constraint. The fit is a failure because the JD rules out any remote arrangement | `[grounded]` JD quote and your statement | Only the employer changing terms resolves it; see RR2 |
| R2 | Base of $70–85k (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your confirmed floor. The posted maximum is below it | `[grounded]` JD quote and your statement | Only the employer changing the band resolves it; see RR1 |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | 9 years, with growth lead then Head of Growth titles. This is self-reported, so expect a probe | `[grounded]` your summary | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid at two companies, with budget control during the $8M to $40M ARR scale-up. No inspectable artifact yet | `[grounded]` your summary | A channel or budget summary would raise this to `high` |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and have deep Braze skills. No artifact yet | `[grounded]` your summary | A lifecycle program doc or results readout would raise this to `high` |
| R6 | SEO/content | important | unclear | none | discovery | Nothing you described touches SEO or content | `[grounded]` your summary's silence | See G1 |
| R7 | Brand, PR, partnerships | important | unclear | none | discovery | Nothing you described touches these | `[grounded]` your summary's silence | See G2 |
| R8 | Sales ops | important | unclear | none | discovery | Nothing you described touches sales ops. The two B2C subscription roles suggest it may be thin | `[grounded]` your summary's silence; `[inferred]` from the B2C context | See G3 |
| R9 | Team of one to start, "players who don't need a bench" | important | adjacent | medium | transferability | You built and managed teams of 3–7 and controlled a budget. Limit: nothing shows you running seven functions solo | `[grounded]` your summary for the teams and budget; limit `[inferred]` | Not worth work while the gates stand |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, important) | discovery | Your summary doesn't mention SEO or content | Would only polish an `important` row; it can't move the decision past R1 and R2 | Content programs you directed, SEO-driven acquisition you owned, an editorial calendar you approved | A traffic or organic-growth report | `[grounded]` summary silence; `[inferred]` that it can't move the decision |
| G2 | Brand, PR, partnerships (R7, important) | discovery | Not covered in your summary | Same as G1 | Co-marketing deals, press placements, affiliate or referral partnerships | A partnership summary or coverage links | `[grounded]` summary silence |
| G3 | Sales ops (R8, important) | discovery | Not covered in your summary | Same as G1 | CRM/pipeline hygiene or lead-routing work you owned | A process doc or dashboard | `[grounded]` summary silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted pay conflicts with your floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The stated band can't meet a $150k floor, and the mismatch is factual. Whether it is also below market for the scope is not established | `[grounded]` JD figure and your floor | What is the budgeted base for this role, and is the range flexible? | confirmed |
| RR2 | On-site mandate conflicts with remote-only (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The employer states no flexibility, so the conflict is factual | `[grounded]` JD quote and your statement | Is any remote arrangement possible for this role? | confirmed |
| RR3 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | Several full roles are folded into one title and one person | `[generic]` common pattern for startup postings, not a claim about Novaline | Which of these functions would be built out with hires, and on what timeline? | unresolved |
| RR4 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be the norm rather than the exception | `[generic]` pattern for this wording | How often did the last person in a growth role work evenings or weekends? | unresolved |
| RR5 | Absent success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability without a fixed definition of success | `[generic]` pattern for this wording | What would count as a good first-year outcome? | unresolved |
| RR6 | Authority and budget unstated | unknown | — | "Own all revenue growth end to end" | The mandate is stated, but budget and decision rights aren't | `[inferred]` from the JD's silence | What marketing budget and decision rights come with the role? | unresolved |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | The size and terms of the equity are unknown | `[inferred]` from the JD's silence | What is the equity grant, vesting schedule and strike price? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | Direct line to the CEO | positive_signal | — | "Report to the CEO with a dotted line to the board" | Senior visibility and access | `[grounded]` JD | Who has held this role before, and where did they go? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply as posted | See R1, R2, RR1, RR2 | `[grounded]` the map and register | recommendation, your call |
| A2 | If you still want to test it, ask the employer, before investing effort, whether the role can be fully remote and whether base can reach $150k. Both conditions must hold together, since either one alone still fails a hard gate | See R1, R2 | `[grounded]` your two constraints | pending your approval |

## Evidence status

Verified: R1 and R2 (your own stated constraints, user-confirmed). The claims behind R3, R4, R5 and R9 come from your summary and are unverified leads.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Series A Austin Head of Growth"; the call was refused. It would have moved role reality's organization row and RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary startup Series A base compensation 2026"; the call was refused. It would have filled role reality's market calibration row and sharpened RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you want a record of this assessment, I can emit it as `tuesday-dossier.md`.

## Upgrade menu

- Search permission, so I can check the employer and the posting → RR8 closes or firms up, and the market calibration row gets filled.
- Your CV → R3, R4 and R5 can reach `high` with artifacts, and G1 to G3 get checked against your actual wording.
- The employer's answers on remote work, budgeted base and equity → R1, R2, RR1, RR2 and RR7 close, and the decision is re-run.

No questions this turn: no answer you could give would move the decision past R1 and R2.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.