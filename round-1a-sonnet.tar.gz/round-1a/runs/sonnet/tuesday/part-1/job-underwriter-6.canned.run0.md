**Revenue Operations Lead at Quillfield: should you apply?**

## Decision snapshot

**Yes, apply, on the conditions below. R7 and R8 are your two real stretches. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol, hybrid, two office days), R2 (Salary £61,500–£67,000 plus share options)
- `must_have` — direct: R3, R5 · adjacent: R6 (Strong SQL and spreadsheet modelling), R7 (Experience owning a forecast), R8 (Experience working with finance on billing or revenue data) · unclear: R4 (at a B2B software company)
- `important` — direct: R9

R7 — a bridge with its limit named; R8 (`low`) — one thread, unconfirmed; R4 — waiting on whether your employer sells software.

**Opportunity ledger.** Quillfield checks out as a real Bristol company, and the posting states its pay (RR2). Four things are open: the role isn't on Quillfield's own site (RR1), who owns the forecast today (RR3), team size (RR4) and the option terms (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid, two office days), R2 (Salary £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days works for you, and the pay clears your floor — R1, R2; (2) the posting is confirmed live on Quillfield's own site — RR1; (3) the forecast and billing-data gaps are presented as adjacent work, never as ownership — R7, R8; (4) the forecast split with the CFO is clarified in interview — RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` quillfield.co.uk/about, from a search result |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` JD |
| Compensation | £61,500–£67,000 plus share options; option terms not stated | `[grounded]` JD |
| Hiring manager | Tamsin Achebe is listed as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. That matches what the recruiter told you | `[grounded]` search result for her profile; the profile page was not opened |
| Scope read | One post covers CRM, billing data, reporting and the forecast. Team size and reporting line are not stated | `[inferred]` from the duty list against the posting's silence |
| Market calibration | Ledgerline's 2026 UK pay guide gives a median base of £64,200 for revenue operations lead roles in UK B2B software (n=438; interquartile range £57,800–£70,400). The posted band sits inside that range. The figure is UK-wide, not Bristol-specific, and is not Quillfield's own pay data | `[generic]` Ledgerline guide, found by one salary search; `[grounded]` JD for the posted band |
| Unknowns | Team size, who owns the forecast today, option terms, whether the role is listed on Quillfield's own site | — |
| Contradictions | None found between the posting and the about page. The posting itself was not found on Quillfield's site (RR1) | `[grounded]` about page; careers URL returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | The posting states the term. You gave no location or commute constraint, so it is unsettled until you answer | `[grounded]` JD; no candidate constraint given | Closing question G1 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | The posting states the pay. You gave no pay floor, so whether it clears is unsettled. Option terms are not stated | `[grounded]` JD; no candidate constraint given | Share your floor (upgrade menu) |
| R3 | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | 5 years in sales operations, the last 2 running revenue operations for the UK team. This is your own account with nothing inspected yet | `[grounded]` your message | none |
| R4 | The experience sits at a B2B software company | must_have | unclear | low | discovery | Your employer is a B2B payments company. Whether it sells software is not stated, so whether it counts is open | `[grounded]` your message; the JD wording | Row G5 |
| R5 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, self-reported. A credential ID or Trailhead profile link is the artifact that would raise it to `high` | `[grounded]` your message | Offer: certificate link |
| R6 | Strong SQL and spreadsheet modelling | must_have | adjacent | low | discovery | You use SQL weekly and Excel daily. That shows frequency, not strength, and no modelling work is described. Lower band taken | `[grounded]` your message | Row G6 |
| R7 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, and finance owned the company forecast. The limit: a pipeline review is not owning a forecast | `[grounded]` your message | Closing question G4 |
| R8 | Experience working with finance on billing or revenue data | must_have | adjacent | low | discovery | You have never worked on billing data. The renewal dashboards are the only revenue-adjacent work, and whether finance was involved is not stated | `[grounded]` your message | Closing question G3 |
| R9 | Build pipeline and renewal reporting | important | direct | medium | none | You rebuilt your team's pipeline and renewal dashboards. Who consumed them (sales, finance or both) is not stated | `[grounded]` your message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Bristol hybrid (R1, hard_gate) | hard_gate | The posting states the location and office days, and you gave no constraint | A failed gate would make this `no_go` whatever the fit | n/a, it is a yes or no on the term | None needed | `[grounded]` JD; `[inferred]` that the term could decide the status |
| G2 | Pay (R2, hard_gate) | hard_gate | The posted band is stated, and your floor is not | The same gate logic as G1 | n/a | None needed | `[grounded]` JD |
| G3 | Billing or revenue data with finance (R8, must_have) | discovery | You have not worked on billing data. Renewal dashboards are the only revenue-adjacent work described | A must-have and the widest distance in the map. A truthful bridge is the only way to narrow it | Renewal dashboards built on contract or invoice values; reconciling pipeline or renewal numbers with finance; any month-end or renewal-revenue figures finance relied on | A dashboard screenshot with figures removed, or a metric definitions doc | `[grounded]` your message; `[generic]` that this is the requirement a billing-data owner is most likely to probe |
| G4 | Forecast ownership (R7, must_have) | transferability | You run the monthly pipeline review, and finance owned the forecast | A must-have. The limit has to be stated honestly wherever the bridge is used | Pipeline numbers or coverage assumptions you supplied to finance; commit and best-case calls in your review; variance or accuracy tracking | A pipeline-review template, or a slide with figures removed | `[grounded]` your message |
| G5 | Software-company setting (R4, must_have) | discovery | A B2B payments company, with the product type unstated | A must-have wording that could read narrowly | What the company sells and to whom | The company's product page | `[grounded]` your message |
| G6 | Strong SQL and spreadsheet modelling (R6, must_have) | discovery | Usage frequency is stated, with no outputs | Shows what "strong" rests on | Queries behind your dashboards; models used for planning or targets | A query or workbook with data removed | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Role not found on Quillfield's own site | unknown | — | "Revenue Operations Lead, Quillfield | Tallyboard Jobs" | The role may be listed elsewhere on their site, the careers URL I tried was a guess, or the posting may be stale or aggregated | `[inferred]` from one guessed URL returning no page and a role search returning nothing | Can you send me the link to this role on Quillfield's own site? | unresolved |
| RR2 | Pay stated, inside the Ledgerline band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | Pay is transparent. Option terms are the open part | `[grounded]` JD; `[generic]` Ledgerline band | What are the option terms: number, vesting and strike? | noted |
| RR3 | Forecast split with the CFO unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The post may own the forecast model or only supply pipeline inputs to a finance-owned forecast. The Head of Revenue Operations sits above it | `[inferred]` from the JD's "with the CFO" and the hiring manager's listed title | Who builds and signs off the forecast today, and what would this role own in it? | unresolved |
| RR4 | Team size and scope unstated | unknown | — | "own our CRM and billing data, build the pipeline and renewal reporting ... and run the quarterly revenue forecast" | CRM, billing data, reporting and forecast fall to one post. Whether anyone supports it is not stated | `[inferred]` from the duty list against the posting's silence on reports | Does this role have direct reports or analysts, and who maintains the billing data today? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter for the link to this role on Quillfield's own site before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the pipeline and renewal dashboard rebuild and the monthly pipeline review with your sales director, in your own words | R9, R7 | `[grounded]` your message | pending your approval |
| A3 | Say plainly that finance owned the company forecast and that you have not worked on billing data, then describe the adjacent work. Don't claim ownership of either | R7, R8 | `[grounded]` your message | pending your approval |
| A4 | Ask the RR3 and RR4 questions verbatim in the first interview | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Her listed background is sales operations at a payments company, and yours is sales operations at a B2B payments company. That makes your payments-company experience a natural thread for the conversation with Tamsin Achebe | The hiring manager's public footprint | `[inferred]` from her listed career and your stated background | pending your approval |

## Evidence status

Verified: none yet. Your background is self-reported and treated like a CV.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers", which returned "About Quillfield" (quillfield.co.uk/about), and "Quillfield Revenue Operations Lead Bristol", which returned nothing. Fetched quillfield.co.uk/careers, which returned no page. Role reality: Quillfield exists as described. RR1: the posting is not corroborated on their own site |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Market calibration, and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Role reality's hiring-manager row, RR3's hypothesis and A5 |

## Closing

I can write this up as a `tuesday-dossier.md` if you want to keep it or carry it forward.

**Upgrade menu**
- Your pay floor, and whether Bristol with two office days works → R1 and R2 close, and the decision likely simplifies to `go` or `no_go`.
- Your Salesforce certification ID or Trailhead link → R5 to `high`.
- A redacted dashboard or query from your pipeline and renewal work → R6, R8 and R9 firm up.
- What your employer's product is → R4 resolves.
- A deeper research pass on Quillfield, covering funding, hiring patterns, public staff and candidate reports and recent news (up to 5 more searches and 2 more fetches). Say the word and it runs. It would help RR1 most.

**Questions**
- G1 — Does Bristol with two days a week in the office work for you?
- G3 — Did your renewal dashboards run on contract or invoice values, and did you work with finance on them or on any revenue figures they used?
- G4 — Which numbers or assumptions in your monthly pipeline review fed finance's forecast, and what did you personally own in them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.