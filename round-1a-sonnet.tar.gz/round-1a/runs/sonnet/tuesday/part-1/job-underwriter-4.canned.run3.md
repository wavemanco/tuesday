I've run three searches. The employer's careers page says "Leeds office four days a week", but your JD says fully remote. I'm fetching that page to confirm before I write this up.
# Job Underwriting — Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Probably yes on fit, but don't commit until the working pattern is settled. R1 (`hard_gate`) is unconfirmed. Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4a, R5
- `important` — direct: R6 · adjacent: R7 (Pet-insurance domain) · unclear: R4b (Monitoring rating models)
- `preferred` — direct: R8

R1 — decides the hold; R4b (`low`) — "maintained" is not stated as monitoring; R7 (`medium`) — a bridge with its limit named.

**Opportunity ledger.** The role is real and live, but the two sources disagree on where you would work (RR1) and the salary is withheld (RR2). One entry runs the other way: the hiring manager has published on the monitoring half of the job (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the awaited answer is the actual working pattern (R1, RR1). If it is Leeds four days a week and that doesn't work for you, R1 becomes `hard_gate_fail` and the status `no_go`. If it is remote, the status moves toward `conditional_go`, with R4b and R7 as the things to firm up.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product, with a live careers page for this role | `[grounded]` JD header; careers page fetched, "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst) |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | The Director of Pricing, Odile Varga | `[grounded]` JD and careers page both say the Director of Pricing |
| Working pattern | The JD you pasted says "Fully remote (UK)"; the careers page says "Leeds office four days a week" | `[grounded]` both quoted, and they conflict (RR1) |
| People management | The JD states no line-management requirement or direct reports | `[grounded]` JD |
| Compensation | Not stated in the JD | `[grounded]` JD silent |
| Market calibration | UK senior pricing analysts at insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900. This is the band to expect, never this employer's offer (RR2) | `[generic]` role-family sweep, "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (n=612), search snippet only, page not fetched |
| Scope read | A single-product analytics role, owned end to end, with underwriting and product as the audience | `[inferred]` from the JD's responsibilities list |
| Unknowns | First-year outcomes; team size and tooling; who owns monitoring today; salary; actual working pattern | `[grounded]` JD silent on each |
| Contradictions | JD "Fully remote (UK)" against careers page "Leeds office four days a week" | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You have not stated a location or working-pattern constraint, so there is no statement of yours to grade. Fit is `unclear` because the JD and the careers page disagree | `[grounded]` JD and careers page; no constraint given | RR1's question to the employer; your answer to the first closing question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics at a UK motor insurer, the last two as senior analyst. Specific and plausible, but intake prose has no inspectable artifact | `[grounded]` your background, prose | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily" is confirmed in your words; nothing inspectable yet | `[grounded]` your background, prose | none |
| R4a | GLM experience | must_have | direct | medium | none | You "built and maintained the GLM rating model for our young-driver book". Specific, with no inspectable artifact | `[grounded]` your background, prose | none |
| R4b | Monitor rating models | important | unclear | low | discovery | Your sentence says "maintained", which may or may not include ongoing monitoring such as actual-versus-expected tracking or drift checks. Taken at the lower band | `[grounded]` your wording; `[generic]` that "maintain" and "monitor" are often different work | G1 |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting; the audience matches | `[grounded]` your background, prose | none |
| R6 | Design and read price tests, turn results into recommendations | important | direct | medium | none | "Ran 14 price tests last year with the underwriting team" | `[grounded]` your background, prose | none |
| R7 | Pet-insurance pricing (the product the role owns) | important | adjacent | medium | transferability | A credible bridge from a motor rating model, price tests and underwriting-facing work. Limit: you have never worked on pet, so nothing in your history exercised pet rating. The JD does not list it as a requirement | `[inferred]` role's product from the JD header; `[grounded]` you have not worked on pet | G2 |
| R8 | Insurance experience a plus | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background, prose | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R4b, important) | discovery | "Built and maintained" a GLM; no statement of ongoing monitoring | The JD says "build and monitor", and the hiring manager's published talk is about monitoring rating models, so this is the half of the job she has spoken on | Tracking actual against expected by segment; a refresh triggered by drift; a dashboard or report others used; a post-release review of a rate change | A sanitized actual-versus-expected report, a dashboard screenshot, a model-governance note | `[grounded]` JD wording and the talk title from a search snippet; `[inferred]` that this is the likeliest probe |
| G2 | Pet-insurance pricing (R7, important) | transferability | Motor GLM, price tests and underwriting presentations. Carries over: the modelling method, test design and stakeholder work. Limit: no pet rating experience. Strengthener: a short, honest note on how you'd approach a pet rating structure | A new line for you is the objection most likely to be raised, and it is the one you flagged yourself | Any non-motor or low-volume segment you've modelled; any claims-cost trend or inflation work | A one-page sanitized approach note | `[grounded]` your stated lack of pet experience; `[generic]` that a new line is a common objection |
| G3 | Working pattern (R1, hard_gate) | hard_gate | Two sources, two answers | The one gate that could end this; it is a term, so no wording solves it | Not applicable: the question is whether the gate is met | The employer's written confirmation of the arrangement | `[grounded]` both sources quoted |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Remote against office conflict (R1) | risk_signal | medium | "Fully remote (UK)" (JD) against "Leeds office four days a week" (careers page) | The JD copy you hold may predate a change, or the careers page may be stale. Taken at the lower severity because it is unresolved | `[inferred]` from two sources disagreeing | Is this role fully remote, or is it based in the Leeds office four days a week? | unresolved |
| RR2 | Salary withheld | unknown | — | JD states no compensation | The figure may sit anywhere in the role-family band, or the employer may simply not publish it | `[generic]` the band in role reality; `[grounded]` JD silent | What salary range is budgeted for this post? | unresolved |
| RR3 | Hiring manager's published work matches the role | positive_signal | — | "Director of Pricing" (careers page); talk "Small Books, Loud Errors" on monitoring rating models in small books (search result) | The team may care about monitoring discipline, which suits the "monitor" half of the job | `[grounded]` search snippet, profile page not fetched; `[inferred]` that this signals team priorities | How is monitoring of the rating models run today, and what would this role own in it? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle the working pattern with the recruiter or Odile before investing in an application | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | When you write or speak to the application, lead with your own sentences: "built and maintained the GLM rating model for our young-driver book" (R4a), "I present the quarterly pricing review to the head of underwriting" (R5), and the 14 price tests last year with the underwriting team (R6). Say nothing about monitoring until G1 is answered | These map to the JD's GLM, presenting and price-test requirements without adding a claim | `[grounded]` your background, quoted | pending your approval |
| A3 | Say plainly that pet is a new line for you. Name what carries over (GLM method, price tests, underwriting-facing work) and the limit, that you have not priced a pet book | see R7, G2 | `[grounded]` your background | pending your approval |
| A4 | The JD asks for no line management and you have none, so there is nothing to defend or bridge there. Don't volunteer a leadership claim | JD states no such requirement | `[grounded]` JD | pending your approval |
| Q1 | Put the verification questions of RR1, RR2 and RR3 to the employer, verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

No CV was supplied, so no resume edits are proposed.

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). The employer is real and the posting is live, which moved the contradictions and working pattern rows and created RR1 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey); snippet only, page not fetched. Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga); snippet only, page not fetched. Moved RR3 and the lead-with line in A2 |

I can save this as a `tuesday-dossier.md` to carry forward. It's optional, and I'd do it only if you ask.

**Upgrade menu**

- Where you live and whether Leeds four days a week is workable: runs the R1 gate check against your constraints, and likely settles the status.
- The employer's answer on working pattern: closes R1 and RR1, and moves the decision to `conditional_go`, `go` or `no_go`.
- An answer to G1, ideally a sanitized actual-versus-expected report or dashboard: moves R4b and lets A2 mention monitoring.
- Your current CV: adds resume-edit rows, with approval before anything is finalized.
- Your salary floor: sets the budgeted range (RR2) against what you need.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news, candidate and employee reports; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

- R1 — Is fully remote a firm requirement for you, or could you work from Leeds four days a week? Where are you based? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- R4b — When you maintained the young-driver GLM, did that include ongoing monitoring (actual against expected, drift checks, triggering a refresh)? What did you own, and is there a report or dashboard others used? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.