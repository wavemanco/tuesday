Reading the posting is done; I'm now finishing the playbook's reference files (output rules, research tiers, worked example) before I write the assessment.
## Decision snapshot

**Yes, apply, as long as Bristol with two office days a week and the £61,500–£67,000 band both suit you (R1, R2). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, two office days a week), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3, R4, R5a · adjacent: R6 (Experience owning a forecast) · unclear: R5b (spreadsheet modelling), R7a (working with finance on revenue data) · absent: R7b (billing data)
- `important`: direct: R8

R6: adjacent, with forecast ownership as the limit; R7b: no billing-data work, a gap you stated yourself; R5b and R7a: not yet established.

**Opportunity ledger.** The posting is open about pay and working pattern, and the pay sits inside the market band (RR3). The employer exists as described (RR4). Two things are open: who owns the forecast alongside an existing Head of Revenue Operations (RR2), and whether the posting is live on Quillfield's own site (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid, two office days a week), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Bristol and the pay band work for you (R1, R2).
  2. Your forecast work is described as adjacent, never as ownership (R6).
  3. The hiring manager treats billing data as learnable on the job (R7b, RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` About Quillfield page |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, listed as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. This matches what your recruiter told you | `[grounded]` search result snippet; profile page not opened |
| Scope read | The posting bundles CRM ownership, billing data, reporting and forecasting under "Lead", and a Head of Revenue Operations already exists | `[inferred]` from the posting's scope against the hiring manager's listed title |
| Market calibration | Ledgerline's 2026 UK pay guide puts a revenue operations lead at a B2B software company at a median base of £64,200, interquartile range £57,800–£70,400 (n=438). The posting's band is inside that range. This is a market band, not Quillfield's offer | `[generic]` one pay-guide search; `[grounded]` posting figure |
| Unknowns | Forecast split with the Head of Revenue Operations; first-year outcomes (not stated); team and reporting line; share option terms; contract basis | — |
| Contradictions | None between the posting and the About page. The role is not confirmed on Quillfield's own careers page (RR1) | `[grounded]` About page read; careers URL I tried returned no page |

## Evidence map

Your background comes from your message, not a CV, so nothing is above `medium` and none of it is verified yet.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol office, hybrid, two days a week | hard_gate | unclear | none | hard_gate | You haven't said where you're based or what office days you'll accept, so there's no stated constraint to grade or compare | `[grounded]` posting; your message is silent | Closing question on R1 and R2 |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor, so the band can't be checked against it | `[grounded]` posting; your message is silent | Closing question on R1 and R2 |
| R3 | 4+ years in revenue operations, sales operations or similar analytics at a B2B software company | must_have | direct | medium | none | Five years in sales operations, the last two running revenue operations for the UK team: the years and function match. The employer is a B2B payments company, and reading that as "B2B software" is an inference, which is the limit | `[grounded]` your account; `[inferred]` that a payments company reads as B2B software | Describe your employer's product plainly on the application |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | You are Salesforce admin certified; the certificate is checkable but nobody has inspected it | `[grounded]` your account | A verification link for the certification would raise this to `high` |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly. "Strong" is the posting's word, and your sentence gives frequency, not depth | `[grounded]` your account | A sanitized query or dashboard source would raise it |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | Excel daily shows use, not that you build models; the posting's word is "modelling" | `[grounded]` your account, silent on models | See G4 |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director and rebuilt the pipeline dashboards, which are inputs to a forecast. Finance owned the forecast, so ownership is the limit | `[grounded]` your account | See G1 |
| R7a | Working with finance on revenue data | must_have | unclear | low | discovery | You rebuilt renewal dashboards, but you haven't said whether finance worked with you on them | `[grounded]` your account, silent on finance contact | See G2 |
| R7b | Working with finance on billing data | must_have | absent | none | capability | You've never worked on billing data | `[grounded]` your own statement | See G3 |
| R8 | Pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt both sets of dashboards. Who used them, finance included, isn't stated, so the claim stays at what you said | `[grounded]` your account | A sanitized screenshot would raise it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | transferability | **Carries over:** pipeline review and dashboards feed a forecast. **Limit:** finance owned the forecast and you didn't. | The posting has this role run the quarterly forecast with the CFO, and R6 is a `must_have` at `adjacent` | A pipeline-weighted rollup or commit and best-case view you built; a renewal forecast from your renewal dashboards; figures finance took into its forecast | A sanitized rollup sheet, a pipeline-review deck, a forecast-versus-actual comparison | `[grounded]` your statement that finance owned it and the posting's mandate |
| G2 | Finance contact on revenue data (R7a, must_have) | discovery | Renewal dashboards exist; finance's involvement isn't stated | It would turn R7a from `unclear` to something gradeable, and it's the nearest bridge to R7b | Reconciling closed-won or renewal figures with finance's numbers; agreeing ARR or renewal definitions with finance; tracing a revenue discrepancy back to CRM data | A sanitized reconciliation sheet or a definitions doc | `[grounded]` your account, silent on finance contact |
| G3 | Billing data (R7b, must_have) | capability | No stated direct or adjacent work | It's a gap on a `must_have` and a named part of the role's mandate. Carry it as a material risk and say it plainly | Closure path: ask how much billing-system knowledge is expected on day one; a small self-built exercise matching a sample invoice export to CRM opportunities would show how you work | A short sanitized exercise write-up | `[grounded]` your own statement; `[inferred]` that the exercise narrows the gap without closing it |
| G4 | Spreadsheet modelling (R5b, must_have) | discovery | Daily Excel use; model-building not stated | A `must_have` currently at `unclear` | Scenario or forecast workbooks; commission or renewal-cohort models; any workbook others relied on | A sanitized workbook | `[grounded]` your account, silent on models |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's own site | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The role may be listed only on the job board, or my one careers URL guess was wrong. Quillfield itself is established (RR4) | `[inferred]` from one careers URL returning no page | Is this role live on Quillfield's own careers page, and is it a new post or a backfill? | unresolved |
| RR2 | Forecast ownership versus an existing Head of Revenue Operations | unknown | — | "run the quarterly revenue forecast with the CFO" | Forecast duties may be shared or split between this role, the Head of Revenue Operations and the CFO | `[inferred]` from the posting's mandate against the hiring manager's listed title | Who owns the quarterly forecast today, and how would it divide between this role, the Head of Revenue Operations and the CFO? | unresolved |
| RR3 | Pay and share options stated | positive_signal | — | "Salary £61,500–£67,000 plus share options" | Pay is within the market band, so there's no seniority-pay mismatch. The option terms are unstated | `[grounded]` posting figure; `[generic]` Ledgerline survey band | What are the share option terms: amount, vesting, strike price? | noted |
| RR4 | Employer matches its description | positive_signal | — | "invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol; 96 employees" | A real, funded company of the size and product the posting implies | `[grounded]` About Quillfield page | How large is the revenue operations team now, and who would report to this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before investing effort, ask the recruiter whether the role is live on Quillfield's own site and whether it's new or a backfill | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Build the application on your own statements: Salesforce admin certification, the rebuilt pipeline and renewal dashboards, and the monthly pipeline review with your sales director. Say plainly that finance owned the forecast and that you haven't worked on billing data; don't use forecast-ownership or billing wording | see R3, R4, R8, R6, R7b | `[grounded]` your own sentences | pending your approval |
| A3 | Take the RR2 and RR4 questions to Tamsin Achebe nearly verbatim, and ask what billing-data knowledge is expected in the first months | see RR2, RR4, R7b | `[grounded]` register rows | pending your approval |
| A4 | If R1 and R2 hold, ask the RR3 share-option question before an offer stage | see RR3 | `[grounded]` RR3 | pending your approval |

Every action above is proposed, not applied.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers Revenue Operations Lead", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page. Moved: the organization row, RR1 and RR4 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software UK", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: the market calibration row and RR3. Only pay was swept, not title or remit norms |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Snippet only; the page wasn't opened. Moved: the hiring manager row, RR2 and A3 |

Would you like this saved as `tuesday-dossier.md` so a later step can build on it? Say so and I'll write it.

## Upgrade menu

- Your location and pay floor: R1 and R2 become met or failed, and the status likely becomes `go` or `no_go`.
- A verification link for your Salesforce certification, a sanitized renewal-dashboard screenshot, or a sample SQL query: raises R4, R8 and R5a from `medium` toward `high`.
- A sanitized forecast rollup, pipeline-review deck or modelling workbook: strengthens R6 and R5b.
- A link to the role on Quillfield's own careers page: closes RR1.
- A deeper research pass on Quillfield (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

1. **R1 and R2:** Do Bristol with two office days a week and the £61,500–£67,000 band both work for you, and is that band at or above your pay floor?
2. **G1:** Have you built any forecast or rollup, even a pipeline-based one, that your sales director or finance used? What was yours in it?
3. **G2:** Have you worked with finance on revenue or renewal numbers, such as reconciling or agreeing definitions? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.