Web search was refused, so this runs on your JD and background alone, and every outside-world claim below is labelled `[generic]` or `[inferred]`.

## Decision snapshot

**Yes, apply, on conditions. Status: `conditional_go`.** R1 (a hard gate) is unconfirmed, and the employer is unverified (RR1).

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6a, R7a, R8 · unclear: R6b (Designing price tests), R7b (Recommendations for product)
- `important` — adjacent: R10 (Pet-insurance domain)
- `preferred` — direct: R9

R6b, R7b — what you ran versus designed, and any product-side audience, both unconfirmed; R10 (`medium`) — a credible bridge, its limit named.

**Opportunity ledger.** The employer can't be verified from here (RR1), the salary is withheld (RR2), and decision rights and team size are unstated (RR3, RR4). One entry runs the other way: the posting's scope and reporting line are concrete (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor verifies as a live employer with this role, per RR1; (2) you confirm that fully remote UK working fits you, per R1; (3) the test-design and product-recommendation questions are answered, per R6b and R7b; (4) pet-insurance experience is framed as adjacent, never as direct, per R10.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. Its existence and the live posting are unchecked (RR1) | `[grounded]` JD header |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Reporting line | Hiring manager is Odile Varga, Director of Pricing | `[grounded]` JD |
| People management | The JD lists no direct reports and no management requirement, so "never managed anyone" is not a stated gap. Whether reports come with the role is open (RR4) | `[grounded]` JD silent on both |
| Scope read | An individual-contributor analytic post that sits close to the pricing director | `[inferred]` from "own pricing analytics" and a named director as hiring manager |
| Market calibration | Not established: the role-family sweep did not run and the posting states no salary, so there is no band to set against (RR2) | `[grounded]` JD silent; sweep refused |
| Unknowns | Salary; contract basis; team size; whether the rating models are built from scratch or inherited; tooling; first-year outcomes | `[grounded]` JD silent on each |
| Contradictions | None between the JD and your background. The JD against the careers page is unchecked | `[grounded]` the two documents provided |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You gave no constraints. A UK motor insurer suggests you are UK-based, but nothing states it. Confidence grades your statement of the constraint, which is absent | `[inferred]` from UK employer in your background | Question G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics at a UK motor insurer. Self-reported, nothing inspected yet. A years requirement is not a gate | `[grounded]` your background statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily", confirmed in your prose, with no inspectable artifact | `[grounded]` your background statement | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book | `[grounded]` your background statement | Optional: a sanitized model spec or governance note would raise it to `high` |
| R5 | Build and monitor rating models | must_have | direct | medium | none | Build is stated, and "maintained" is the nearest your words come to monitoring. Expect the interviewer to ask what monitoring you ran | `[grounded]` your background statement; `[generic]` that interviewers for this kind of post tend to probe monitoring | Be ready to say what you tracked, or confirm it in reply |
| R6a | Read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your background statement | none |
| R6b | Design price tests | must_have | unclear | low | discovery | "Ran" does not settle whether you designed them: control groups, sample sizing, success measures. Resolved downward until you say | `[grounded]` your wording; `[inferred]` the design part is open | Question G2 |
| R7a | Recommendations for underwriting | must_have | direct | medium | none | You worked the tests with underwriting and present the quarterly pricing review to the head of underwriting | `[grounded]` your background statement | none |
| R7b | Recommendations for product | must_have | unclear | low | discovery | Nothing in your background names a product team as an audience | `[grounded]` background silent on product | Question G3 |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background statement | none |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background statement | none |
| R10 | Pet-insurance domain, implied by owning the pet product's pricing | important | adjacent | medium | transferability | GLM rating, tests and stakeholder work carry over from motor. The limit: no pet claims data and no pet-specific rating factors or product knowledge. The JD does not require pet experience, and its "a plus" is for insurance generally | `[inferred]` from the JD's product scope; `[generic]` that pet rating factors and claims behaviour differ from motor | Gap queue G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and eligibility (R1, hard_gate) | hard_gate | The JD says "Fully remote (UK)", and you stated no constraints | A gate is met or it isn't. Wording can't fix it | Not applicable: this is a yes/no term | Your own statement | `[grounded]` JD term; `[inferred]` UK base from your employer |
| G2 | Price-test design (R6b, must_have) | discovery | You ran 14 tests with underwriting. The inputs don't say who designed them | A must-have in the JD's own first-line duties; the answer sets whether your CV says "ran" or "designed" | Choosing test and control splits; sizing tests; deciding what counted as a win; writing the test brief underwriting signed off | A test brief, a results readout, a monitoring dashboard screenshot (sanitized) | `[grounded]` your wording; `[generic]` that this kind of role usually probes test design |
| G3 | Recommendations for product (R7b, must_have) | discovery | Underwriting is named as your audience. Product is not | The JD names product as a second audience | Presenting results to a product or proposition team; changing a product feature, cover tier or rating factor on the back of a test | A readout deck or decision note (sanitized) | `[grounded]` background silent on product; `[inferred]` an adjacent audience may exist |
| G4 | Pet-insurance domain (R10, important) | transferability | Adjacent: motor GLM rating, price tests and underwriting stakeholders. Limit: no pet data or pet-specific factors. Strengthener: a short sanitized note on how you would set up pet pricing, labelled as your own approach and not pet experience | The likeliest objection to your application is "never worked on pet" | Self-directed work on pet or other non-motor lines, or on claims frequency and severity modelling outside motor | A one-page approach note (see the extra offer below) | `[inferred]` bridge from your motor work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. I could not check, because search was refused | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | No compensation appears anywhere in the posting as provided | The figure may sit below what a senior role needs, or the employer may simply not publish it | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Ownership asserted, decision rights unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" may mean sole analyst advising underwriting and product, with decisions elsewhere | `[inferred]` from "own" beside "recommendations for underwriting and product" | Which pricing decisions does this role make, and which go to underwriting, product or you reporting to the director? | unresolved |
| RR4 | Direct reports or team size unstated | unknown | — | "Senior Pricing Analyst" | The post may be an individual contributor, or it may grow into line management | `[inferred]` from a title and JD with no reports named | Does this post have direct reports now, or is that expected within the first year? | unresolved |
| RR5 | Concrete duties, requirements, location and hiring manager are all stated | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope is defined and checkable | `[grounded]` JD | Who owns the existing rating models today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify Brindlemoor before investing effort: find its own careers page, confirm the posting is live, and check that the recruiter's email domain matches | See RR1 | `[grounded]` RR1 | pending your approval |
| E1 | `resume_edits_pending_approval`: move to the top of the CV, in your own wording, three items: built and maintained the GLM rating model for the young-driver book; ran 14 price tests last year with the underwriting team; present the quarterly pricing review to the head of underwriting. Use "ran", not "designed", until G2 is answered | See R4, R6a, R6b, R8 | `[grounded]` your background statement | pending your approval |
| P1 | Positioning, `pending your approval`: say the gap yourself. For example: "I haven't priced pet insurance. I built and maintained a GLM rating model for a motor young-driver book." Every clause traces to your own sentences | See R10 | `[grounded]` your wording | pending your approval |
| Q1 | Put the RR2 to RR4 verification questions to Odile Varga in the loop, verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused. It would have set RR1 and the contradictions row in role reality |
| 2. Role-family sweep | unavailable | The search was refused. It would have given the market calibration line and a salary comparison for RR2 |
| 3. Hiring manager's public footprint | unavailable | The search was refused. It would have fed the scope read and which story the plan leads with for Odile Varga |

Extra offer (beyond spec): a one-page "how I would approach pet pricing" note for G4, built only from your own motor work and clearly labelled as an approach, not experience. This engagement earns it because R10 is the likeliest objection. I'll write it only if you approve.

I can also save all of this as `tuesday-dossier.md` if you'd like a copy to carry forward.

**Upgrade menu**

- Allowing web search → targets 1 to 3 can run, which would settle RR1 and calibrate RR2.
- Your answer on location and eligibility → R1 closes.
- A test brief or readout (sanitized) → R6b resolves and R4 or R6a may reach `high`.
- Any product-facing readout → R7b resolves.
- The recruiter's salary range → RR2 closes.

**Questions**

G1 — Are you UK-based, and does fully remote UK working suit you, with any constraint on pay, hours or location that this role would touch?
G2 — On the 14 price tests, which parts did you personally own: designing the splits and sample sizes, defining success, or running and reading them?
G3 — Have you ever taken a test result to a product or proposition team, and did anything change as a result?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.