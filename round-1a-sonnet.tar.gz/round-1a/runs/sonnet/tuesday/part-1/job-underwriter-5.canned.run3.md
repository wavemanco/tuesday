Read the playbook and fetched both Pellucid pages. Here is the assessment.

## Decision snapshot

**Yes, it's worth applying, on conditions. Status: `conditional_go`.** Every must-have (R3, R4, R5, R6, R7) lands `direct`. What's open is whether R1 and R2 fit your location and pay floor, and R8 is a bridge rather than direct BigQuery experience.

**Fit ledger.**

- `hard_gate` — unclear: R1 (US remote or Denver office), R2 (Pay $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery warehouse) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts for analysts)

R8 (`medium`) — a Snowflake-to-BigQuery bridge with its limit named; R9, R10 — responsibilities your background doesn't speak to yet; R1, R2 — waiting on your location and pay floor.

**Opportunity ledger.** Transparently priced and consistent with the market: the posted band sits inside the survey's range (RR1), and the employer's own pages match the posting (RR5). The open items are equity terms (RR2), team and reporting line (RR3), and what "build and run" means for on-call load (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (US remote or Denver office), R2 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 confirmed against what you can't flex; (2) R8 presented as adjacent, never as BigQuery experience; (3) RR2, RR3 and RR4 answered cleanly in the interviews.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, Denver, founded 2016, 264 employees, Series C ($52M, February 2026). These are the company's own statements, not independently confirmed | `[grounded]` About page, fetched |
| Posting status | Live on the company's own site, marked "Accepting applications" | `[grounded]` careers page, fetched |
| Mandate | Build and run the reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Requirements | 5+ years data engineering; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Terms | Salary $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` JD |
| Scope read | One domain's pipelines (reporting), no direct reports mentioned. This matches the typical scope in your pay report | `[grounded]` Datawright report as supplied; `[inferred]` that the posting matches it, from the JD's silence on reports |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500, n=2,310. The posted low end is $3,000 below the median and the top is $2,500 above the range's upper bound. The report covers base pay only, so equity is outside the comparison. This is a band, not this employer's offer | `[generic]` role-family band from the supplied report; `[grounded]` the posting's figure |
| Unknowns | Equity terms; team size and reporting line (no hiring manager is named); on-call expectations; whether BigQuery is expected on day one, since the requirements say "a cloud warehouse" but the scope names BigQuery | `[grounded]` JD silence |
| Contradictions | None between the text you pasted and the fetched pages | `[grounded]` pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | US remote or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you'd work from, so nothing settles it. Confidence grades your statement of the constraint, and none was given | `[grounded]` JD; no candidate statement | Closing question G1 |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The band is stated; your floor isn't, and the equity terms are unstated | `[grounded]` JD; no candidate statement | Closing question G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-reported and not yet inspectable. A length-of-experience requirement is graded on fit, not treated as a gate | `[grounded]` your stated background; the report puts typical "Senior" at 5–8 years | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both is stated. "Strong" is a level nothing inspectable shows yet, and what the Python was used for isn't stated | `[grounded]` your stated background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. That meets the requirement as worded; BigQuery is handled in R8 | `[grounded]` your stated background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named directly, so "or similar" isn't needed | `[grounded]` your stated background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. What it covered and caught isn't stated | `[grounded]` your stated background | none |
| R8 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The dbt modelling layer carries over from Snowflake. The limit is that you've never used BigQuery, so its own table design and cost behaviour are untested by you | `[grounded]` JD, and your statement that you haven't used it; `[generic]` that warehouses differ in table design and cost | Bridge case in G4; strengthener W1, pending your approval |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Your pipelines are stated, but not what the sources were | `[grounded]` background silent on sources | Closing question G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | A Great Expectations suite is related, but it tests data. It isn't a stated agreement between producers and consumers, and whether you defined or enforced one isn't stated | `[grounded]` background silent; `[inferred]` that the two are related, from the suite's purpose | Closing question G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2; hard_gate) | hard_gate | Posting terms are stated; your constraints aren't | A conflict on either would cap the status, whatever the fit | Anything you cannot flex: working outside the US, a pay floor above the band, equity you'd need to value | None; your own statement settles it | `[grounded]` JD terms; your constraints not given |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Pipelines at a payroll company are stated; their sources are not | A named responsibility with no evidence yet. Resolving it could move R9 to `adjacent` or `direct` | Pulling product or application database data; loading from a CRM or other SaaS API; syncing tables on a schedule | A pipeline diagram, a README, or a source list | `[grounded]` background silent on sources |
| G3 | Data contracts (R10, important) | discovery | A test suite is stated; an agreement with upstream owners or analysts is not | Named in the posting as what analysts depend on | Agreeing column definitions or freshness expectations with a data producer or consumer; failing a build on a broken schema | A schema doc, a contract or SLA note, or the suite's expectation list | `[grounded]` background silent; `[inferred]` relation to the suite |
| G4 | BigQuery (R8, important) | transferability | Snowflake plus dbt at volume | The posting names BigQuery as the warehouse | n/a | A small public dbt project run on BigQuery | `[grounded]` your statement that you haven't used it |

**Bridge case for G4.** What carries over is the dbt modelling work, about 180 models. The limit is that you haven't run anything on BigQuery itself. The strengthener is W1 below.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and in line with the survey | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is transparent and sized to the seniority, assuming the posted figure is base | `[grounded]` posting and the supplied Datawright report | Is the posted salary base pay, and where in the range would this role start? | noted |
| RR2 | Equity named without terms | unknown | — | "plus equity" | The grant may be modest or hard to value without size, vesting and strike price | `[inferred]` from the posting naming equity and giving no terms | What is the equity grant range for this level, how does it vest, and what is the strike price? | unresolved |
| RR3 | Team and reporting line unstated | unknown | — | "Build and run the pipelines" | You may be the main or only owner of these pipelines | `[inferred]` from "build and run" beside silence on team and manager | Who else is on the data team, and who does this role report to? | unresolved |
| RR4 | Operational load unstated | unknown | — | "Build and run" | "Run" may include on-call duty | `[inferred]` from the word "run" | Is there an on-call rotation for these pipelines, and how often did it page last quarter? | unresolved |
| RR5 | Employer and posting match the pasted text | positive_signal | — | "Accepting applications" | The employer exists as described and the role is live. Funding and headcount are self-reported | `[grounded]` both pages fetched | What did the Series C change for the data team's plans this year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm equity terms and the posted salary's basis with the recruiter before investing in the loop | see R2, RR1, RR2 | `[grounded]` register | pending your approval |
| W1 | A small public dbt project run on BigQuery, to narrow R8's limit. It shows you have used BigQuery, and nothing more | see R8, G4 | `[inferred]` from R8's limit | pending your approval |
| P1 | Say it plainly: "Six years of data engineering at a B2B payroll company; I built our dbt project, about 180 models, on Snowflake; I haven't used BigQuery yet." Add Airflow, and the Great Expectations suite you set up | see R3, R5, R6, R7, R8 | `[grounded]` each clause traces to your own sentences | pending your approval |
| Q1 | Ask the verification questions of RR2, RR3 and RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and "About Pellucid Learning" (pellucidlearning.com/about). You named these URLs as the source of the text you pasted, so the fetches count as research. Both matched your paste, and the posting shows "Accepting applications". Moved: role reality's organization, posting status and contradictions rows, and RR5 |
| 2. Role-family sweep | skipped | The Datawright report you supplied fixes the market calibration and the pay and scope checks that target feeds |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager |

I can write this up as a `tuesday-dossier.md` for you to keep, if you'd like.

**Upgrade menu**

- Your CV → the `medium` rows get read against what it actually says, and any presentation gaps show up.
- An answer to G2 or G3 → R9 or R10 moves from `unclear`.
- A public artifact (a repo, a README, a schema doc) → R5 or R7 could reach `high`.
- Your location and pay floor → R1 and R2 close, and the status likely firms to `go`.
- The hiring manager's name → the scope read and what to lead with for that reader.
- A deeper pass on Pellucid (funding and leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — Does anything in the posting's terms, working from the US remotely or from Denver and $148,000–$166,000 plus equity, conflict with something you can't flex?
G2 — What data sources did your pipelines pull from at the payroll company (an app database, a CRM or other SaaS tool), and which ones did you set up yourself?
G3 — Have you ever agreed on expectations with a data producer or analysts about a table's schema or freshness, and did anything enforce it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.