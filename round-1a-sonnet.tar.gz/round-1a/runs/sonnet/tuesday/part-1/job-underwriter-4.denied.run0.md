Web search wasn't permitted, so I've underwritten this from your JD and background alone.

## Decision snapshot

**Yes, go for it. R2, R3, R4, R5, R6 and R7 (the must-haves) are `direct`, and pet-insurance experience is only a `preferred` row (R10). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK-based)
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — adjacent: R8 (Recommendations to product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance product knowledge)

R8 — underwriting side evidenced, product side not; R10 (`medium`) — motor rating work bridges, pet-specific factors untested.

**Opportunity ledger.** The outputs are concrete (RR4). Team shape and decision rights (RR2), pay (RR3) and the posting itself (RR1) are still open.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you're UK-based with the right to work there — R1; (2) the posting and employer verify on Brindlemoor's own careers page — RR1; (3) your pet-insurance gap is framed as adjacent, never as pet expertise — R10.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; not independently confirmed (RR1) | `[grounded]` JD header |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Requirements | 4+ years pricing or actuarial analytics; strong SQL and Python; GLM; presenting to underwriting or actuarial leads; "insurance experience a plus" | `[grounded]` JD |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing; her public footprint was not researched | `[grounded]` your message |
| People management | The JD states no line-management duty or requirement; whether the role has reports is unstated (RR2) | `[grounded]` JD, silent on it |
| Scope read | A single-product ownership role pitched at the level of your current senior-analyst title | `[inferred]` from "Senior" and 4+ years against your 5 years, 2 as senior |
| Market calibration | Not established: the role-family sweep did not run, and the posting you pasted states no pay | `[grounded]` search refused; JD silent on pay |
| Unknowns | Team shape, who signs off rate changes, salary, contract type | `[grounded]` JD silent on each |
| Contradictions | None visible in the JD text; no check against the employer's own pages was possible | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | low | hard_gate | You haven't stated where you live or your right to work. A UK employer history is indirect. Confidence grades what you've said about the constraint, which is little so far | `[grounded]` JD; `[inferred]` UK base from your UK-insurer history | Confirm it (question Q1) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics, the last 2 as senior analyst. Confirmed in prose, but no CV or artifact has been inspected | `[grounded]` your background | none |
| R3 | Build and monitor rating models | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. "Maintained" is your word. What ongoing monitoring you personally ran wasn't stated, so expect a probe | `[grounded]` your background | none; be ready to say what monitoring you ran |
| R4 | GLM experience | must_have | direct | medium | none | The same young-driver GLM model, built and maintained by you. No inspectable artifact yet | `[grounded]` your background | none |
| R5 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is a level claim that daily use supports but doesn't prove | `[grounded]` your background | A sanitized notebook, query or repo link would raise this to `high` |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with underwriting. "Ran" is your word. Which parts were yours (design, sample sizing, readout) wasn't stated, so expect a probe | `[grounded]` your background | none; be ready to say which parts you owned |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R8 | Turn results into recommendations for underwriting and product | important | adjacent | low | discovery | The underwriting half is evidenced through the price tests and the quarterly review. Nothing you've said touches a product team, so I took the lower band | `[grounded]` your background; `[inferred]` that the product half is unevidenced from your silence on it | G1 question |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background and JD | none |
| R10 | Pet-insurance product knowledge (not a stated requirement; implied by the product) | preferred | adjacent | medium | transferability | Your GLM rating and price-test work carries over as a method. The limit: you've never worked on pet insurance, so its own risk factors and claims patterns are untested by you | `[inferred]` bridge from your motor work; `[generic]` that pet pricing rests on different risk factors from motor | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Recommendations to product (R8, important) | discovery | Underwriting recommendations are evidenced. No product, proposition or commercial counterpart is mentioned | The JD names product as a recipient of your recommendations, and it's the one half of R8 with nothing behind it | A price-test result that changed a product feature, a rating-factor decision taken to a product or commercial team, a launch or repricing you advised on | A readout deck, a decision note or a test summary with identifying details removed | `[grounded]` your background silent on product; `[inferred]` that it matters for this role from the JD's wording |
| G2 | Pet-insurance knowledge (R10, preferred) | transferability | Motor GLM and price-test work; no pet exposure, which you told me directly | A `preferred` row, so a minor risk, but it's the likeliest first interview question | Nothing to recall; this is a bridge, not a memory prompt. The strengthener is a short, honest note on how you'd approach pet-specific rating factors | A one-page approach note, clearly labelled as your thinking and not as experience | `[inferred]` bridge from your motor work; `[generic]` that interviewers probe the domain switch |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not yet verified | unknown | — | "Brindlemoor (insurtech)" | Nothing found either way: the checks didn't run, so the employer and posting are neither confirmed nor doubted | `[grounded]` all four searches were refused | Can you point me at this role on your own careers site, and who I'd be interviewing with? | unresolved |
| RR2 | Team shape and decision rights unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The post may be an individual-contributor seat or may carry reports. Rate-change sign-off may sit with pricing, underwriting or product | `[inferred]` from the JD's "own" against its silence on team and authority | Does this role have direct reports, and who signs off rate changes? | unresolved |
| RR3 | Salary not stated | unknown | — | No salary appears in the posting as pasted | The figure may be published elsewhere or withheld; no band was checked | `[grounded]` JD silent; `[inferred]` nothing else | What salary range is budgeted for this post? | unresolved |
| RR4 | Concrete, named outputs | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product" | Scope is defined in specific work, and the hiring manager's title is named | `[grounded]` JD wording | How will success in the first year be judged? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the role on Brindlemoor's own careers page before putting effort in | See RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with three of your own statements, in your wording: "built and maintained the GLM rating model for our young-driver book", "ran 14 price tests last year with the underwriting team", and presenting "the quarterly pricing review to the head of underwriting" | They map to R4, R6 and R7 | `[grounded]` your background | pending your approval |
| A3 | On pet insurance, say plainly: "I haven't worked on pet insurance; the transferable part is my GLM rating and price-test work on motor" | Mirrors R10's bridge and its limit | `[grounded]` your own statements | pending your approval |
| A4 | If people management comes up, say you haven't managed anyone. Don't reframe other work as management | You've told me you've never managed anyone; the JD states no such duty | `[grounded]` your statement; JD silent | pending your approval |
| Q1 | Ask the RR2 and RR3 questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech UK" and "Brindlemoor careers Senior Pricing Analyst"; both were refused. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst insurance UK salary remote"; refused. It would have moved the market calibration line and RR3 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; refused. It would have moved the scope read and which story the plan leads with |

I can save this as `tuesday-dossier.md` if you'd like a file to carry forward.

## Upgrade menu

- Permission to search the web → RR1 may close, role reality gets a market band for pay, and the plan can be tuned to Odile Varga's public work. A deeper pass would add up to 5 more searches and 2 more fetches.
- A sanitized notebook, query or repo link → R5 to `high`.
- A price-test readout or decision note with identifying details removed → R6 to `high`.
- An answer to G1 → R8 firms up or stays adjacent.
- Your location and right to work → R1 closes.
- Your pay floor and any other non-negotiables → hard-gate checks against them become possible, which is what the "candidate constraints not given" flag is waiting on.

## Questions

Q1 (R1) — Are you based in the UK with the right to work there, and is fully remote from there what you want?
Q2 (G1) — Have you taken price-test or rating-model results to a product, proposition or commercial team, not just underwriting? What did you own, and what changed?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.