**Yes, apply. You're a credible fit: R1, R2, R3, R4 and R5, the five must-haves, are all `direct`. Status: `conditional_go`, because the employer could not be verified (RR3) and the posting gives no pay figure (RR1).**

Search permission was declined, so this runs on the JD and your background only.

**Fit ledger.**

- `must_have`, direct: R1, R2, R3, R4, R5
- `important`, direct: R7a · adjacent: R6 (Define and maintain the metrics layer) · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred`, adjacent: R9 (Healthcare data experience, HIPAA)

R6 is related work, with ownership of a definitions layer unconfirmed; R9 is a real adjacency with its limit named; R7b and R8 have nothing stated yet.

**Opportunity ledger.** The role is clearly scoped, with named responsibilities (RR2). The employer is unverified (RR3), the pay is withheld (RR1), and the authority that comes with the mentoring is unstated (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting verify, per RR3; (2) pay is disclosed and clears your floor, per RR1; (3) the HIPAA gap is framed honestly as adjacent, never as healthcare experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C, care-navigation app | `[grounded]` JD header; not independently verified |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, roadmap partnership, mentoring two junior analysts | `[grounded]` JD |
| Scope read | A senior individual-contributor role with light people leadership. Five responsibilities, none obviously a bundled second job | `[inferred]` from the JD's responsibility list against its stated mentoring scope |
| Market calibration | Not established. The salary and role-family searches did not run, and I won't state a band from memory | `[generic]` placeholder; see upgrade menu |
| Unknowns | Pay; who you report to; experimentation traffic volume; clinician access; the current metrics layer | `[grounded]` JD silent on each |
| Contradictions | None found within the JD. No second source was checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a ~2M-subscriber company. It is specific, but a typed background has no inspectable artifact yet | `[grounded]` your background, self-report | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" is a self-grade, and an interviewer may probe it | `[grounded]` your background | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year, with you designing and running the program, including the pricing test behind an 11% retention lift. Be ready to say which parts were yours | `[grounded]` your background | none |
| R4 | Looker or similar BI, self-serve dashboards | must_have | direct | medium | none | You built the Looker instance from scratch, with 40+ governed dashboards. This is the same tool the JD names | `[grounded]` your background | none |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product | `[grounded]` your background | A redacted memo would raise this to high |
| R6 | Define and maintain the metrics layer | important | adjacent | low | discovery | Governed dashboards and a consent-state model sit close to metric definitions. Owning shared definitions is not stated, so I took the lower band | `[grounded]` your background; `[inferred]` that governed Looker work involves definitions | G1 |
| R7a | Partner with product managers on roadmap decisions | important | direct | medium | none | Monthly presentations to the VP Product, and the pricing test shows analysis feeding a decision | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing in your background mentions working with domain experts such as clinicians | `[grounded]` background silent | G2 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Mentoring is not mentioned, so nothing supports it yet. That is not the same as having none | `[grounded]` background silent | G3 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Your GDPR/CCPA handling and consent-state model carry over for privacy-aware data work. The limit: you have not worked with PHI or HIPAA, and the posting calls it a plus | `[grounded]` your background; `[generic]` that regulated-data teams value this adjacency | Frame as adjacent only |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, important) | discovery | Governed dashboards and a consent-state model, but no stated ownership of shared metric definitions | The JD lists it first among responsibilities, and it is the likeliest probe in an interview | Defining "active subscriber" or "retention" once for the whole company; LookML models or a dbt metrics layer; a metric dictionary others used | A metric dictionary, a LookML snippet, or a definitions doc, redacted | `[grounded]` background silent on ownership; `[generic]` that this is a core remit of the role family |
| G2 | Clinician partnership (R7b, important) | discovery | No domain-expert collaboration is mentioned | The JD names clinicians as partners, and the claim cannot be made without evidence | Working with nutritionists, operations or other specialists to shape a test or a metric | A project brief or a test write-up naming the specialist partner | `[grounded]` background silent |
| G3 | Mentoring (R8, important) | discovery | No mentoring or people-lead experience is mentioned | The JD makes it an explicit duty | Onboarding analysts, reviewing others' SQL or experiment designs, running a shared analytics practice | A named mentee, an onboarding doc, or a review process | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | no figure in the JD | The posting may withhold pay, or it may be disclosed later | `[inferred]` from the JD's silence | What is the budgeted range for this role? | unresolved |
| RR2 | Clear, defined responsibilities | positive_signal | — | "define and maintain the metrics layer, design and analyze A/B tests…" | Scope reads as concrete rather than vague | `[grounded]` JD | Which of these five responsibilities is the top priority in the first 90 days? | noted |
| RR3 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and who I would be interviewing with? | unresolved |
| RR4 | Mentoring authority unstated | unknown | — | "mentor two junior analysts" | You may be mentoring without reporting authority or hiring input | `[inferred]` from the JD naming mentoring and saying nothing about reporting lines | Do the two analysts report to this role, or is mentoring informal? | unresolved |
| RR5 | Experiment traffic volume unknown | unknown | — | "experiment design at scale" | Test volume in a care-navigation app may be much lower than in a 2M-subscriber consumer business, which limits what can be tested | `[inferred]` from the JD's silence on user volume | What is the weekly active user base, and how many experiments run per quarter? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the experimentation program and the pricing test, stating exactly which parts you owned | see R3 | `[grounded]` your background | pending your approval |
| E2 | Position the GDPR/CCPA and consent-state work as adjacent privacy experience, with no healthcare or HIPAA claim | see R9 | `[grounded]` your background | pending your approval |
| E3 | Put the Looker build next to a metric-definition example once G1 is answered | see R4, R6 | `[grounded]` your background | pending your approval |
| Q1 | Ask RR1, RR3, RR4 and RR5 verbatim in the first recruiter conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report at the intake ceiling, not proof.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Harborlight Health care navigation app Series C" was refused (permission not granted). It would have decided RR3 and the contradictions row |
| 2. Role-family sweep | unavailable | The search "senior product analyst digital health salary range 2026" was refused (permission not granted). It would have supplied the market calibration and a check on RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer and upgrade menu

I can save this as `tuesday-dossier.md` if you'd like to keep it.

- Search access (or a link to the live posting on the company's careers page) → RR3 closes and market calibration appears.
- A redacted metrics memo → R5 to `high`.
- A metric dictionary or LookML example → R6 to `medium` or better.
- The hiring manager's name → role reality's scope read, and which story to lead with.
- The budgeted pay range → RR1 closes against your floor, which you haven't told me yet. Tell me your pay floor and any other non-negotiables and I'll check them against the role.

## Questions

G1 — Did you personally own the shared definitions of key metrics, such as "active subscriber" or retention, and what did that look like in Looker or the warehouse?
G2 — Have you worked alongside a domain specialist, such as a nutritionist or an operations lead, to shape a test or a metric? What did you own?
G3 — Have you mentored or onboarded other analysts, formally or informally?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.