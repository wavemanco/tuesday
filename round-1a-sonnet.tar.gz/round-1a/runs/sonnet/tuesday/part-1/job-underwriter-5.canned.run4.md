I'm checking that the posting is still live and that the Series C is real, then I'll write the assessment.
**Yes, apply. The role fits your background and pays in line with the market, and nothing I found counts against it.** Status: `conditional_go`. The conditions are two things only you can check: where you'd work and what your pay floor is.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (BigQuery); unclear: R10 (data contracts), R11 (ingestion from app and CRM)

R9 (`medium`) — a Snowflake-to-BigQuery bridge with its limit named; R10, R11 — your background doesn't mention either, so each gets one question.

**Opportunity ledger.** The posting is live on the company's own site and its stated pay sits inside the market range you sent (RR1, RR4). The open items are equity terms (RR2), the team around the role (RR3) and the funding claim (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 checked against your own location and pay floor; (2) BigQuery presented as adjacent, never as experience (R9); (3) the team and ownership questions in RR3 answered acceptably in interviews.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 US states; Denver, founded 2016, 264 employees, Series C ($52M, February 2026) | `[grounded]` about page, which is the company's own statement; the funding is not independently confirmed (RR5) |
| Mandate | Pipelines behind reporting: ingestion from app and CRM, a dbt-modelled warehouse in BigQuery, data contracts for analysts | `[grounded]` posting |
| Location | Remote (US) or Denver office | `[grounded]` posting |
| Seniority | 5+ years data engineering, which fits "Senior" at 5–8 years | `[grounded]` Datawright report you sent |
| Scope read | The mandate reads like ownership of one domain's pipelines. The posting is silent on team size and reports | `[inferred]` from the posting's wording against the report's typical scope (one domain, no direct reports) |
| Market calibration | The posted range is $148,000–$166,000 against a base median of $151,000 and an interquartile range of $139,000–$163,500 for Series B–D companies. The bottom of the range is near the median and the top is just above the 75th percentile. This is the market band, not a promise of where you'd land | `[grounded]` posting and your report (n=2,310) |
| Unknowns | Equity terms, team size, hiring manager (none named), success measures | — |
| Contradictions | None between the posting you pasted and the live careers page | `[grounded]` page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are or what you'll accept. Confidence is `none` because there's no stated constraint to grade | `[grounded]` posting; your location not given | Question 1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor stated, so I can't say whether the range clears it | `[grounded]` posting; floor not given | Question 1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You have 6 years at a B2B payroll company, stated in the conversation. That is self-report with no inspectable artifact yet | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" rests on your word, and a live exercise will probe it | `[grounded]` your background | none |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models. Ownership and scope are stated but not inspectable | `[grounded]` your background | none |
| R6 | A cloud warehouse | must_have | direct | medium | none | The posting asks for "a cloud warehouse", and you have Snowflake in production | `[grounded]` your background and posting wording | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You use Airflow, and it's named in the posting | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. That's a stated claim; a sanitized suite layout would be the inspectable artifact | `[grounded]` your background | none |
| R9 | BigQuery, named in the role description | important | adjacent | medium | transferability | The dbt and warehouse skills carry over, and you've never used BigQuery. BigQuery bills and tunes differently from Snowflake, so the limit is real | `[inferred]` requirement from the mandate text; `[generic]` on the platform differences | Work sample: a small dbt-on-BigQuery project (pending your approval) |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Nothing in what you've told me touches contracts, schema agreements or analyst-facing guarantees. Your payroll work may include something like it | `[grounded]` silence in your background | G2 |
| R11 | Ingestion from app and CRM sources | important | unclear | low | discovery | Your background doesn't say what source types you ingested | `[grounded]` silence in your background | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Strong dbt and Snowflake work. No BigQuery use | It's named in the role description, so you'd probably be asked about it | Work where you moved or compared warehouses; tuning query cost or partitioning in Snowflake | A small public dbt-on-BigQuery project, or a short write-up of how Snowflake concepts map across | `[inferred]` bridge from your Snowflake work; `[generic]` that interviewers probe the specific platform |
| G2 | Data contracts (R10, important) | discovery | Nothing on contracts or schema agreements | The posting names contracts as the thing analysts depend on | Agreeing column definitions or freshness guarantees with analysts; schema-change notices; tests that block a bad upstream change | A contract doc, a schema-change policy, or a test config | `[grounded]` background silent on contracts |
| G3 | App and CRM ingestion (R11, important) | discovery | Source systems unstated | Ingestion is the first thing the posting lists | Product-event or SaaS API ingestion; CRM syncs; CDC from an app database | A pipeline diagram or DAG list | `[grounded]` background silent on sources |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay posted and inside the market range | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is transparent and in line with Series B–D market pay | `[grounded]` posting and your report | Where in the range would someone with my experience start? | noted |
| RR2 | Equity stated without terms | unknown | — | "plus equity" | The grant size, vesting and strike price could make it worth a lot or very little | `[inferred]` from the posting's silence on terms | What is the grant size, vesting schedule and strike price, and when was the last valuation? | unresolved |
| RR3 | Team and ownership unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be the only data engineer, or one of several. The report's typical scope is one domain with no reports | `[inferred]` from the JD's wording against `[grounded]` the report's typical scope | Who else is on the data team, who does this role report to, and who is on call for pipelines? | unresolved |
| RR4 | Posting live on the employer's own site | positive_signal | — | "Accepting applications." | The role is real and current | `[grounded]` careers page fetched | Who would I interview with? | noted |
| RR5 | Funding rests on the company's own page | unknown | — | "Series C ($52M, February 2026)" | One search returned only the company's about page, so the round isn't independently confirmed | `[grounded]` search result | How is the Series C budgeted for the data roadmap? | unresolved |

## Application plan

Every row is a proposal. Nothing here is final until you approve it, and that covers the advice as well as the edits.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the dbt project (about 180 models), the Airflow orchestration and the Great Expectations suite you set up | These match R5, R7 and R8 directly | `[grounded]` your background | pending your approval |
| E2 | State Snowflake as your warehouse and don't claim BigQuery | See R9 | `[grounded]` your background | pending your approval |
| W1 | A small dbt-on-BigQuery project, optional | Narrows R9's limit | `[inferred]` from R9 | pending your approval |
| Q1 | Ask RR1, RR2, RR3, RR4 and RR5 verbatim in interviews | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer), which is live and matches your paste. Searched "Pellucid Learning Series C $52M tutoring Denver", which returned only the about page. Moved: role reality's contradictions row and RR4. RR5 stays open because the funding rests on the company's own statement |
| 2. Role-family sweep | skipped | Your Datawright report is in hand and already fixes the market calibration line and the pay check (RR1) |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form |

If you want, I can write all of this up as `tuesday-dossier.md`.

## Upgrade menu

- Your location and pay floor → R1 and R2 close, and `conditional_go` likely becomes `go`.
- Your CV → I'd read it for R3–R8, and the presentation gaps would show.
- An inspectable artifact such as a sanitized Great Expectations suite layout or a dbt lineage screenshot → R5 and R8 could rise to `high`.
- The hiring manager's name, if the recruiter has it → role reality's scope read and which story the plan leads with.
- Deeper diligence on funding and recent news (up to 5 more searches and 2 more fetches) → RR5. Say the word and it runs.

## Questions

1. **R1, R2** — Where are you based, would you take the remote or the Denver option, and what's the lowest base salary you'd accept?
2. **G2** — Have you ever agreed definitions, freshness or schema-change rules with the analysts who used your models? What did you own and what happened?
3. **G3** — What source systems did you ingest from at the payroll company (app database, event stream, CRM, vendor APIs)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.