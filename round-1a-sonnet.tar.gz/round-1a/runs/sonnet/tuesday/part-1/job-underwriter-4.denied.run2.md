Searches were denied, so this runs on the JD and what you told me only.

## Decision snapshot

**Yes, apply. Status: `conditional_go`.** Neither worry you raised is a requirement in the posting. It lists insurance experience as a plus (R8), not pet insurance, and it states no people-management duty (RR3).

**Fit ledger.**

- `hard_gate` — unclear: R9 (Fully remote (UK))
- `must_have` — direct: R1, R2, R3, R4, R5a · adjacent: R6 (Design and read price tests) · unclear: R5b (Monitor rating models)
- `important` — direct: R7a · unclear: R7b (Recommendations to product)
- `preferred` — direct: R8

R6 — close to direct, waiting on what you personally designed; R5b — "maintained" is not "monitored" until you say so; R7b — product-side audience unevidenced.

**Opportunity ledger.** The posting names concrete outputs (RR4), but I could not verify the employer (RR1), and it is silent on pay (RR2) and on team and reporting scope (RR3).

- **Hard gates:** none failed; unconfirmed: R9 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor verifies as a real employer with a live posting — RR1; (2) you confirm you are UK-based and eligible to work there — R9; (3) you can say plainly which of the 14 price tests you designed, not only ran — R6.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; not independently verified |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message; public footprint not researched |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | One product's pricing analytics under a Director of Pricing; team size and any direct reports not stated | `[inferred]` from the JD's single-product ownership language and its silence on reports |
| Market calibration | Not run, because the role-family search was denied, so I will not quote a salary band from memory | `[grounded]` the search was refused |
| Unknowns | Salary; team size and reporting lines; who the product-side audience is; whether the role is new or a backfill | — |
| Contradictions | None found between the JD and your background; the employer's own pages could not be checked | `[grounded]` the two inputs provided |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Self-reported, with no document yet. A years requirement is a tier, not a gate | `[grounded]` your background, stated | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily" is specific and confirmed. "Strong" is the employer's judgement and nothing here is inspectable | `[grounded]` your background, stated | none |
| R3 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. The scope is one book, so I keep it to that wherever it is used | `[grounded]` your background, stated | An artifact such as a sanitized model summary would raise it to `high` |
| R4 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, which matches the JD's audience | `[grounded]` your background, stated | none |
| R5a | Build rating models | must_have | direct | medium | none | Same GLM claim as R3. Building is stated | `[grounded]` your background, stated | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" is the nearest word you used. It does not establish monitoring such as actual-versus-expected tracking or drift checks, so I take the lower reading. | `[grounded]` the wording gap; `[generic]` that "maintain" and "monitor" are often the same work in practice | Ask G2 |
| R6 | Design and read price tests | must_have | adjacent | medium | discovery | You ran 14 price tests with underwriting last year. Running a test is not the same as designing it, and ambiguity resolves downward. If you designed them, this becomes `direct` | `[grounded]` your background, stated | Ask G1 |
| R7a | Turn results into recommendations for underwriting | important | direct | medium | none | The quarterly review to the head of underwriting and the tests run with underwriting both point here | `[grounded]` your background, stated | none |
| R7b | Turn results into recommendations for product | important | unclear | low | discovery | Nothing you described touches a product team | `[grounded]` silence in your background | Ask after G1–G2 if the decision is still open |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years in motor insurance meets the stated plus. The JD does not ask for pet insurance | `[grounded]` JD wording and your background | none |
| R9 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | The JD states the term. You gave no location or right-to-work constraint, and a UK employer suggests but does not establish it | `[inferred]` from your UK employer | Ask the R9 question below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Designing price tests (R6, must_have) | discovery | 14 tests run with underwriting, with no detail on who set the hypothesis, split, sample size or read-out method | R6 is a `must_have` row at `adjacent`, and "design and read" is half the job title's remit | Choosing test and control groups; sizing a test; deciding the read-out period; calling a result and recommending a rate change | A sanitized test plan or read-out slide from one of the 14 | `[grounded]` the "ran" wording; `[generic]` that interviews for this kind of role probe design ownership |
| G2 | Monitoring rating models (R5b, must_have) | discovery | The GLM was built and "maintained", but no tracking routine is described | R5b is a `must_have` row at `unclear`, and "monitor" is in the first line of the mandate | Actual-versus-expected reports; drift or lift tracking; deciding when to refit; reporting performance to underwriting | A sanitized monitoring dashboard or refit note | `[grounded]` the wording gap; `[generic]` that monitoring routines are standard in pricing teams |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Medium because I only know it is unchecked, not that anything failed | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | none; the JD as pasted has no salary or band | The figure may have been left out of the paste, or the employer may not publish it | `[grounded]` the pasted JD is silent | What salary range is budgeted for this post? | unresolved |
| RR3 | Team and reporting scope unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The post may be a one-person analytics function or may carry reports. I cannot tell from the JD | `[inferred]` from the single-product ownership wording against silence on team | Does this role have direct reports now or planned, and who else sits in pricing under Odile? | unresolved |
| RR4 | Responsibilities are concrete | positive_signal | — | "build and monitor rating models, design and read price tests" | The mandate names real outputs rather than vague ownership | `[grounded]` JD wording | What would you want the first model or test this person owns to be? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead the application with three things, in your own words: the young-driver GLM you built and maintained, the 14 price tests you ran with underwriting, and the quarterly pricing review you present to the head of underwriting | see R3, R6, R4 | `[grounded]` your background | pending your approval |
| P2 | Say plainly that your insurance experience is motor and that pet is new to you. Do not claim pet-specific knowledge | see R8 | `[grounded]` your background; `[generic]` that pet pricing typically has its own rating factors such as breed and age | pending your approval |
| P3 | If asked about managing people, say plainly that you have not had direct reports. Don't raise it unprompted, since the JD doesn't ask | see RR3 | `[grounded]` your background and the JD | pending your approval |
| P4 | Ask the questions of RR1, RR2 and RR3 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Turning P1 into CV wording is resume-tailor's job.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Brindlemoor pet insurance careers Senior Pricing Analyst" was refused. It would have fed role reality's organization row and RR1 |
| 2. Role-family sweep | unavailable | The search on UK senior pricing analyst salary and scope was refused. It would have fed the market calibration row and the pay check on RR2 |
| 3. Hiring manager's public footprint | unavailable | The search "Odile Varga Director of Pricing Brindlemoor" was refused. It would have fed the scope read and which story P1 leads with for that reader |

## Offer and upgrade menu

I can save this as `tuesday-dossier.md` if you want a record to carry into later steps.

- Permission to search → targets 1–3 rerun, which could clear or raise RR1, add a salary band for RR2, and show what Odile Varga has published.
- Your answer on location, right to work and any pay floor → R9 and RR2 close.
- A sanitized test plan or read-out from one of the 14 tests → R6 can reach `direct`, and R4 can reach `high`.
- A sanitized monitoring dashboard or refit note → R5b resolves.

**Questions**

- R9 — Are you UK-based with the right to work there, and is there a pay floor or any other term you won't trade?
- G1 — Of the 14 price tests, which did you personally design (hypothesis, split, sample size, read-out), and which did you run from someone else's design? What did you recommend, and what did underwriting do with it?
- G2 — After you built the young-driver GLM, what did you track on it (for example actual versus expected, drift), how often, and what triggered a refit?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.