Search permission wasn't granted, so I'm working from the JD and your background alone, with no employer check.

## Decision snapshot

**Yes, apply. You're a credible fit: R1, R2, R3, R4 and R5, the `must_have` rows, all land `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: adjacent: R7a (Partner with product managers) · unclear: R6 (Define and maintain the metrics layer), R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience, HIPAA)

R9 (`medium`) — a credible bridge, its limit named; R6, R8 — duties your background does not mention either way.

**Opportunity ledger.** The employer was not checked, because research was unavailable (RR1). Pay is unstated (RR2), and the mandate is silent on resources and success measures (RR3). The posting does name its tools, stakeholders and team shape (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and employer verify on Harborlight's own careers site (RR1); (2) your history on metric definitions and on mentoring is confirmed or honestly framed as absent (R6, R8); (3) pay and location are checked against your own limits, which I haven't seen.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header (not independently checked) |
| Mandate | Own product analytics: metrics layer, A/B tests, Looker self-serve dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | A senior individual-contributor role with light people-leadership, since two juniors is mentoring-sized rather than a management span | `[inferred]` from "mentor two junior analysts" |
| Market calibration | Not available; no role-family sweep ran, so no band is given | `[generic]` nothing asserted |
| Unknowns | Pay; who owns the metrics layer today; data-engineering support; how success is measured; whether the mentoring is formal | — |
| Contradictions | None inside the JD; it was not compared with a careers page | `[grounded]` JD read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | 6 years of product analytics at a meal-kit company, ~2M subscribers. Confirmed and specific, but no document to inspect | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on Snowflake. "Expert" is the JD's word; you stated daily use and no level, so expect a live SQL probe | `[grounded]` your background; `[generic]` that senior analyst loops usually include one | Offer: a sanitized query or model sample would raise it to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the experimentation program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift. "At scale" is unquantified: traffic per test isn't stated | `[grounded]` your background | Offer: a sanitized test readout |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch: 40+ governed dashboards | `[grounded]` your background | Offer: dashboard screenshots or a LookML sample |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads, and present to the VP Product monthly | `[grounded]` your background | Offer: a sanitized memo excerpt |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | "Governed dashboards" suggests metric definitions were involved, but you never said who defined them or in what layer. Not inferred into a claim | `[grounded]` background silence on metric ownership | G1 |
| R7a | Partner with product managers | important | adjacent | low | discovery | Monthly VP Product presentations are confirmed. Day-to-day work with PMs on roadmap decisions is not stated. Limit: executive reporting is not the same working relationship | `[grounded]` VP Product presentations; `[inferred]` that the experiments involved PMs | G2 |
| R7b | Partner with clinicians | important | unclear | low | discovery | Nothing in your background mentions working with clinical or other domain-expert partners | `[grounded]` background silence | G3 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Your background doesn't mention mentoring or managing, so nothing is claimed | `[grounded]` background silence | G4 |
| R9 | Healthcare data experience (HIPAA) a plus | preferred | adjacent | medium | transferability | You have handled GDPR/CCPA consumer PII and built the consent-state model for the warehouse. Limit: you have never worked in healthcare, and HIPAA's rules on health information are a different regime from consumer privacy | `[grounded]` your background; `[generic]` the regime difference | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | discovery | Governed dashboards, but not who defined the metrics or where | The JD leads with this duty, and it is the likeliest probe for a role that "owns" analytics | Defining a canonical metric like retention or churn; LookML or dbt models others built on; a metrics glossary; resolving two teams' conflicting numbers | A metric definitions doc, LookML excerpt, or glossary | `[grounded]` JD duty and your silence; `[generic]` that this is probed |
| G2 | PM partnership (R7a, important) | discovery | VP-level presentations only | A senior hire is expected to influence roadmaps, not only report | Tests where a PM changed a decision; a roadmap item driven by your analysis | A decision memo or test readout | `[inferred]` from the JD's roadmap language |
| G3 | Clinician partnership (R7b, important) | discovery | Silent | A different stakeholder from your current setting | Working with ops, medical or domain-expert partners; translating an expert's question into a metric | A project brief or write-up | `[generic]` for the role family |
| G4 | Mentoring (R8, important) | discovery | Silent | Mentoring two juniors is an explicit duty | Onboarding analysts, reviewing their queries, coaching on experiment design | A mentee, review process or onboarding doc | `[grounded]` JD duty |
| G5 | Healthcare data (R9, preferred) | transferability | Consent and PII work carries over, with the limit above | A `preferred` row, so a minor risk, but the one differentiator here | Data minimization, access controls, de-identification or audit work in your warehouse | The consent-state model write-up | `[grounded]` your background; `[generic]` the HIPAA limit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The search was declined, so nothing was checked. The firm may be fully real, and the posting may or may not be live | `[generic]` pattern for any unchecked employer, not a claim about this one | Can you point me at this role on your careers site, and who I would interview with? | unresolved |
| RR2 | Pay unstated | unknown | — | no pay or band appears in the JD | The posting may simply not publish pay, and I have no band to compare against | `[inferred]` from the JD's silence | What is the budgeted band for this role? | unresolved |
| RR3 | Ownership without stated resources or success measures | unknown | — | "Own product analytics for our care-navigation app" | The role may carry the whole analytics mandate without data-engineering support or defined first-year outcomes | `[inferred]` from the JD's silence on both | Who owns the metrics layer today, what data-engineering support is there, and what would success look like in year one? | unresolved |
| RR4 | Specific tools, stakeholders and team shape | positive_signal | — | "build self-serve dashboards in Looker … mentor two junior analysts" | The scope reads as concrete rather than a bundled mandate | `[grounded]` JD | Where does the analytics team sit, and who does it report to? | noted |

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

*(That line applies only if a request for money or personal details ever appears. None has here, so disregard it.)*

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the lines you wrote: "built the company's Looker instance from scratch — 40+ governed dashboards" and "designed and ran the experimentation program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | R3, R4 | `[grounded]` your background | pending your approval (`resume_edits_pending_approval`) |
| E2 | Frame privacy work as "handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse", and never claim HIPAA experience | R9 | `[grounded]` your background | pending your approval |
| Q1 | Ask RR1 to RR4's questions in the loop, verbatim | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A1 | Verify the posting on Harborlight's own careers site before investing in a tailored application | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Harborlight Health care navigation app Series C", "Harborlight Health careers Senior Product Analyst") were refused for lack of permission. They would have confirmed the employer and that the posting is live (RR1, role reality) |
| 2. Role-family sweep | unavailable | One search ("senior product analyst digital health salary range Looker SQL experimentation") was refused. It would have given a market-calibration band (RR2, role reality) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'd suggest the dossier, `tuesday-dossier.md`, once you've answered a question or two; say the word and I'll write it.

## Upgrade menu

- Granting search permission → the L1 pass runs: employer and posting verified (RR1 closes or escalates) and a pay band (RR2). A deeper pass (leadership, funding and news; up to 5 more searches and 2 more fetches) can follow if you want it.
- An answer on metric ownership (G1) → R6 moves off `unclear`.
- A sanitized query, test readout, memo or dashboard screenshot → R2 to R5 toward `high`.
- Your pay floor, location and work-authorization limits → hard-gate checks run instead of showing "unknown".
- The hiring manager's name → the scope read and which story to lead with.

G1 — Did you define the metrics behind your dashboards, such as retention or churn? Where were the definitions kept, and who relied on them?

G4 — Have you onboarded, coached or reviewed the work of other analysts? What did you own, and for how long?

C1 — What are your non-negotiables for this move: pay floor, location or remote, and work authorization?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.