Loading is done. Next I'm checking that the Pellucid posting and company page are live and match what you pasted.
**Yes, it's worth applying, with conditions. Status: `conditional_go`.** The six `must_have` rows R3, R4, R5, R6, R7 and R8 are `direct`. The one real gap is R9 (BigQuery), which is `adjacent`.

I fetched the careers page and ran one search on the company. The posting is live ("Accepting applications") and matches what you pasted. The company's about page matches too, and it was the only result the search returned.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (a dbt-modelled warehouse in BigQuery) · unclear: R10 (ingestion from our app and CRM), R11 (the data contracts our analysts depend on)

R9 — a credible bridge, its limit named; R10 and R11 — no evidence on the page yet, waiting on your answers; R1 and R2 — waiting on your location and pay floor.

**Opportunity ledger.** The role looks sound on the page: the stated pay sits inside the report's range (RR1). The unknowns are who you'd report to (RR2), how wide the scope runs (RR3), the equity terms (RR4), and employer facts that rest on the company's own pages (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The location and pay terms work for you (R1, R2).
  2. You present BigQuery honestly as a gap with a bridge, not as experience (R9).
  3. Ingestion and data-contract ownership are probed in the loop (R10, R11, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company about page, fetched via search result; own-site claim only (RR5) |
| Mandate | Build and run pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` careers page, fetched |
| Requirements stated | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` careers page |
| Working pattern | Remote (US) or Denver office | `[grounded]` careers page |
| Compensation | $148,000–$166,000 plus equity; equity terms not stated | `[grounded]` careers page |
| First-90-days outcomes | Not stated | `[grounded]` careers page silent |
| Scope read | Ingestion, warehouse and contracts together may run wider than one domain's pipelines | `[inferred]` from the posting's mandate set against the report's typical scope |
| Market calibration | Report figures for Series B–D Senior Data Engineers: base median $151,000, IQR $139,000–$163,500; "senior" typically 5–8 years; typical scope is one domain's pipelines, no direct reports. The posting's range starts $3,000 under the median and tops out $2,500 over the upper quartile. It is a market band, never this employer's offer | `[grounded]` Datawright 2026 report you supplied (n=2,310); `[generic]` as a role-family pattern |
| Unknowns | Hiring manager (none named); data team size; equity terms | `[grounded]` posting names no hiring manager, per what you shared |
| Contradictions | None between what you pasted and the live pages | `[grounded]` careers and about pages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you'd work from, so whether the terms are met is unsettled. Confidence is `none` because no constraint of yours has been stated | `[grounded]` posting; your message gives no location | Question Q1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor hasn't been stated, so the band can't be checked against it. The equity terms are separately unstated (RR4) | `[grounded]` posting; your message gives no floor | Question Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. Intake prose is CV-equivalent, so `medium` with no inspectable artifact yet | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. Confirmed and plausible; nothing inspectable yet, so expect a probe | `[grounded]` your background | none |
| R5 | dbt | must_have | direct | medium | none | You state you built the dbt project on Snowflake, about 180 models. Specific, no artifact yet | `[grounded]` your background | Offer: a sanitized model count or lineage screenshot would raise to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is the cloud warehouse in your work; the requirements list asks for "a cloud warehouse" without naming one. BigQuery is carried separately in R9 | `[grounded]` your background; `[grounded]` posting's requirements list | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration; it is the named tool | `[grounded]` your background | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You state you set up the Great Expectations suite. The posting asks for the practice, not a named tool | `[grounded]` your background | Offer: a sanitized suite config or data-docs page would raise to `high` |
| R9 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | You've never used BigQuery (your word). The adjacent work is dbt on Snowflake. Limit: none of your warehouse work touched BigQuery. It is `important` rather than `must_have` because the requirements list asks only for a cloud warehouse and BigQuery appears in the mandate | `[grounded]` your background; `[grounded]` posting's mandate sentence | See gap G1 |
| R10 | Ingestion from the app and the CRM | important | unclear | none | discovery | Your background names no ingestion work from product or CRM sources, and the CV may not have been the place for it | `[grounded]` your background is silent | Question Q2 |
| R11 | The data contracts analysts depend on | important | unclear | low | discovery | Thread exists, not evidence: the Great Expectations suite and a dbt project of that size may have involved agreements with analysts. Nothing confirms it | `[inferred]` from the dbt and Great Expectations work you described | Question Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Dbt and a cloud warehouse in depth; no BigQuery work | The posting names it as the warehouse, so it is the most visible gap on the page | A side project or pilot on BigQuery's free tier; any migration or cross-warehouse work at your company | A small public repo or a dbt project run against BigQuery | `[grounded]` your confirmation that you've never used it; `[inferred]` that the posting's naming makes it visible |
| G2 | Ingestion from app and CRM (R10, important) | discovery | Nothing about how data reached the warehouse | One of the three named jobs; a direct answer could take R10 to `direct` | Loading product events or a CRM export (Salesforce, HubSpot) into the warehouse; building or maintaining an ingestion job or connector; an API pull or change-data-capture setup | A pipeline diagram, a DAG, or a design note | `[grounded]` background silent |
| G3 | Data contracts (R11, important) | discovery | Testing exists; agreed contracts with consumers are not stated | The posting says analysts depend on them | Agreed schemas or column definitions with analysts; tests failing a deploy when a contract broke; documented ownership of key tables | A contract doc, a schema agreement, a dbt contract config | `[inferred]` from the tests and models you described |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Stated pay against the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is disclosed and sits in the report's range, with the ceiling above its upper quartile | `[grounded]` posting and the report you supplied | Where in the $148,000–$166,000 range would a candidate with six years land, and what decides it? | noted |
| RR2 | Hiring manager and reporting line unnamed | unknown | — | Posting names no hiring manager | Who sets the data team's priorities and how big the team is are not known from the page | `[grounded]` posting, per what you shared | Who does this role report to, and who else is on the data team? | unresolved |
| RR3 | Scope breadth | unknown | — | "Build and run the pipelines … ingestion … warehouse … data contracts" | The role may span ingestion, warehouse and contracts, wider than one domain's pipelines, with no direct reports | `[inferred]` from the mandate set against the report's typical scope | Which of ingestion, the warehouse and the contracts would I own, and how many data engineers are there today? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | The grant size, vesting and basis are not on the page, so it can't be valued | `[grounded]` posting names equity with no terms | What is the equity grant, vesting schedule, and the latest valuation it is based on? | unresolved |
| RR5 | Employer facts rest on the company's own pages | unknown | — | "Series C ($52M, February 2026)" | The funding and headcount figures came only from the company's about page; my one search returned nothing independent | `[grounded]` search returned only the company's own page | What is the Series C earmarked for on the data side? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the dbt project on Snowflake (about 180 models) and the Great Expectations suite, in your own wording | See R5, R8 | `[grounded]` your background | pending your approval |
| A2 | State the BigQuery gap yourself: dbt and Airflow on Snowflake, and no BigQuery use yet. Claim no equivalence | See R9, G1 | `[grounded]` your confirmation | pending your approval |
| A3 | Check your location and pay floor against the posting before applying | See R1, R2 | `[grounded]` posting | pending your approval |
| A4 | Ask RR1 to RR5's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning Series C $52M online tutoring K-12 Denver", which returned "About Pellucid Learning" (pellucidlearning.com/about); fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Role reality's contradictions row: the posting is live and matches your paste. Only the company's own pages came back (RR5) |
| 2. Role-family sweep | skipped | The Datawright report you pasted is in hand and fixes the market calibration line and RR1; a search could not change them |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Say the word if you'd like me to write this up as a `tuesday-dossier.md` to keep.

## Upgrade menu

- A sanitized model count or lineage screenshot, or a Great Expectations config → R5 and R8 to `high`.
- Your location and pay floor → R1 and R2 close, and the hard-gates line stops flagging your constraints as unknown.
- The hiring manager's name, from the recruiter → role reality's scope read, and which story to lead with for that reader.
- The data team's size, from the recruiter → RR3.
- A deeper research pass on Pellucid (funding, leadership churn, candidate and employee reports, recent news; up to 5 more searches and 2 more fetches) → RR5 and the opportunity ledger. Say the word and it runs.

**Questions**

- **Q1 (R1, R2):** Do the location and pay work for you: where would you work from, and is $148,000 at or above your floor?
- **Q2 (G2):** Have you built or owned ingestion from a product app or a CRM into your warehouse? What was yours, which sources, and how did you know it was reliable?
- **Q3 (G3):** Did you agree schemas or definitions with the analysts who used your models, and what happened when something broke them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.