Status: I've read the job-underwriter playbook and its reference files. Next I'm loading the web tools to check that the posting is live and that Pellucid is real, and then I'll write the assessment.
**Yes, it's worth applying — `conditional_go`.** The only open conditions are R1 and R2, the location and pay terms, which I can't check without your constraints.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (BigQuery warehouse); unclear: R10 (App and CRM ingestion), R11 (Data contracts)

R9 — a Snowflake-to-BigQuery bridge, its limit named; R10, R11 — not yet probed, waiting on your answers.

**Opportunity ledger.** Pay is stated and sits inside the market band (RR1), the employer checks out (RR4), and scope breadth, equity terms and on-call duty are open (RR2, RR3, RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you are US-based and authorized to work, which settles R1; (2) your pay floor sits at or below $148,000, which settles R2; (3) the scope behind RR2 verifies as one coherent role.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` About page, fetched |
| Mandate | Build and run the reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD, matches the live careers page |
| Posting status | Live, "Accepting applications", and word-for-word the same as your pasted text | `[grounded]` careers page, fetched |
| Pay and market calibration | The posting's $148,000–$166,000 starts $3,000 below the report's $151,000 median and ends $2,500 above the top of its $139,000–$163,500 interquartile range. Basis: Datawright 2026, US, n=2,310, Series B–D. Pellucid is a Series C. This is a market band, never Pellucid's offer | `[grounded]` JD range and report figures; `[generic]` for where the range sits among employers |
| Seniority | The posting asks for 5+ years. The report says "Senior" typically means 5–8 years, and you have 6 | `[grounded]` JD, report and your background |
| Scope read | Three areas are named (ingestion, warehouse, contracts). The report's typical senior scope is one domain's pipelines with no direct reports. The posting names no reports, so this reads as an individual-contributor role, but that is only a reading | `[inferred]` from the JD against the report's typical scope |
| Unknowns | Team size, who the hiring manager is, equity terms, on-call expectations, Denver or remote preference, interview process | — |
| Contradictions | None between the JD, the careers page and the About page | `[grounded]` pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you live or your authorization. Nothing in the material settles it | `[grounded]` JD term; your location not given | Gate question below |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The range is stated. Your pay floor hasn't been given, so whether it meets your floor is not established. The equity terms aren't stated either | `[grounded]` JD term; your floor not given | Gate question below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years of data engineering at a B2B payroll company, confirmed in your message. No inspectable artifact yet, so `medium`. Expect a probe on scope | `[grounded]` your stated background | Offer: your CV or LinkedIn would let me check dates and titles |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You say you use both daily. Nothing inspectable yet | `[grounded]` your stated background | Offer: a repo or code sample |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models. A model count is specific, but nothing inspectable yet | `[grounded]` your stated background | Offer: a dbt docs site or lineage screenshot, sanitized |
| R6 | A cloud warehouse | must_have | direct | medium | none | The JD asks for "a cloud warehouse", and you used Snowflake. BigQuery is a named tool in the role, carried separately as R9 | `[grounded]` JD wording and your background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named directly, for your team's orchestration | `[grounded]` your stated background | none |
| R8 | Data quality testing experience | must_have | direct | medium | none | You set up the Great Expectations suite, which is testing you owned | `[grounded]` your stated background | Offer: a sanitized list of suites or checks |
| R9 | BigQuery (named in the role description) | important | adjacent | medium | transferability | Credible bridge: the same dbt, SQL and warehouse-modelling work on Snowflake. Limit: you haven't used BigQuery, so its cost model, partitioning and clustering are untested. The posting makes it a tool in the role, not a listed requirement, which is why it is `important` | `[inferred]` bridge from Snowflake work; `[grounded]` JD names BigQuery only in the role description | Bridge case in the gap queue, plus a small BigQuery work sample |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Your sources at the payroll company aren't stated, so I can't tell whether you've done app-event or CRM ingestion | `[grounded]` background silent on sources | Question G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Great Expectations is related, but a data contract is an agreement with a producer or consumer, and nothing says you had one | `[grounded]` background silent; `[generic]` that contracts and tests are distinct practices | Question G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake and dbt work that carries over. Nothing on BigQuery specifics | The posting names BigQuery, so an interviewer will likely ask how your warehouse experience transfers | Query tuning or cost work on Snowflake; partitioning or clustering decisions; any GCP exposure | A small public dbt project run against BigQuery's free sandbox | `[inferred]` bridge from Snowflake work; `[generic]` that interviewers probe tool transfer |
| G2 | App and CRM ingestion (R10, important) | discovery | The sources feeding your pipelines at the payroll company aren't stated | Ingestion is the first thing the posting says you will build | Event or API ingestion from a product; CRM syncs such as Salesforce or HubSpot; third-party connector tools or custom extractors | An architecture diagram or an ingestion runbook, sanitized | `[grounded]` background silent on sources |
| G3 | Data contracts (R11, important) | discovery | Testing is established. Agreements with upstream producers or analyst consumers aren't | The posting calls contracts something analysts depend on | Schema agreements with app engineers; versioned model interfaces or dbt model contracts; SLAs with analysts | A contract doc, a model contract config, or an incident writeup, sanitized | `[grounded]` background silent; `[generic]` that testing and contracts differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and in the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is transparent and competitive for the title | `[grounded]` JD range against the report's figures | Where in the range would my experience place me? | noted |
| RR2 | Scope may be broader than a typical senior post | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | One person might own three areas where the market norm is one domain. Severity stays low because the posting may simply describe a team's remit | `[inferred]` from the JD's three areas against the report's typical scope | How many data engineers are on the team, and which of ingestion, warehouse and contracts would I own? | unresolved |
| RR3 | Equity unspecified | unknown | — | "plus equity" | The grant type, size and vesting aren't stated, so its value can't be weighed | `[grounded]` JD states no terms | What form does the equity take, and what are its size and vesting for this level? | unresolved |
| RR4 | Employer verified and recently funded | positive_signal | — | "Series C ($52M, February 2026)" | A Series C closed in February 2026 makes a funded role more likely than not | `[inferred]` from the funding round on the About page | What is the data team's roadmap for the next year? | noted |
| RR5 | On-call expectation unstated | unknown | — | "Build and run the pipelines" | "Run" may include pager duty | `[inferred]` from the word "run" | Is there an on-call rotation, and how often would I be on it? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with dbt (about 180 models), the Airflow orchestration and the Great Expectations suite, in that order, because they match R5, R7 and R8 | see R5, R7, R8 | `[grounded]` your stated background | pending your approval |
| W1 | A small dbt project on BigQuery's free sandbox, to turn the R9 bridge into something inspectable | see R9, G1 | `[grounded]` R9 row | pending your approval |
| Q1 | Ask the questions of RR1, RR2, RR3 and RR5 verbatim in the interviews | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Frame BigQuery as "Snowflake and dbt experience, new to BigQuery". Don't claim BigQuery experience | see R9 | `[grounded]` R9 row | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): live, "Accepting applications", same text as yours. Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about), matching your pasted description. Moved: contradictions row (none), RR4 |
| 2. Role-family sweep | yes | Searched "senior data engineer salary BigQuery dbt Series C US 2026", which returned "Datawright 2026 Data Engineering Pay Report" (datawright.example/2026-data-engineering-pay-report). I saw only its snippet, which matches the figures your recruiter sent. Moved: the pay and market calibration row, RR1, RR2 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

## Upgrade menu

- Your CV, or a dbt docs page or Great Expectations suite list (sanitized) → R3, R5, R8 could rise to `high`.
- Your location, authorization and pay floor → R1 and R2 close, and the decision becomes `go` or `no_go`.
- The hiring manager's name, from a recruiter → role reality's scope read, and which of your stories to lead with.
- Answers on equity, team size and on-call → RR2, RR3, RR5 close.
- A deeper research pass on Pellucid (funding history, leadership changes, employee reports; up to 5 more searches and 2 more fetches) → the register gets firmer. Say the word and it runs.

I can save all this as a `tuesday-dossier.md` for you if you'd like.

Questions:

- R1/R2 — Are you US-based and authorized to work, and is there a pay floor or location preference that would rule this out?
- G2 — What sources fed your pipelines at the payroll company (app events, APIs, CRM, files), and which ingestion did you personally build?
- G3 — Did you ever agree schema or freshness expectations with the teams producing or consuming your data, and what happened when they broke?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.