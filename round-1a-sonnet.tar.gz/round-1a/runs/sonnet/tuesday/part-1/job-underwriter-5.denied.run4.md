## Decision snapshot

**Yes, this is worth applying to. R3, R4, R5, R7 and R8, the five `must_have` rows, all land `direct`, and the open items are R1, R2 and RR4. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R7, R8
- `important`: adjacent: R6 (BigQuery) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts analysts depend on)

R6 is a credible bridge with its limit named; R9, R10 are unconfirmed because your summary says nothing either way.

**Opportunity ledger.** The pay is competitive with the report you shared (RR1). The equity terms, team size and reporting line are unstated (RR2, RR3), and I could not verify the employer independently (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed: you are in the US with work authorization, and remote or Denver works. (2) R2 clears your own pay floor, and the equity is worth something to you (RR2). (3) The employer and live posting check out (RR4). (4) The BigQuery bridge is framed as adjacent, never as BigQuery experience (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; not independently checked (RR4) |
| Mandate | Build and run reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Requirements | 5+ years data engineering; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver | `[grounded]` JD |
| Scope read | Three layers (ingest, model, contract) with no team size or manager stated. It could be one domain's pipelines or the whole data platform | `[inferred]` from the JD's three responsibilities against its silence on team |
| Market calibration | Report median base $151,000, interquartile range $139,000–$163,500; "Senior" typically 5–8 years; typical scope is one domain's pipelines, no reports. The posted range straddles the median, and its top sits above the interquartile ceiling. Your 6 years sit inside the typical band | `[grounded]` the Datawright report you supplied, not independently verified; `[inferred]` the comparison with the posting's range |
| Unknowns | Hiring manager (none named), team size, equity terms, on-call or "run" expectations, first-year outcomes | `[grounded]` JD silent |
| Contradictions | None between the JD text and the about-page text you pasted. The live pages were not checked | `[grounded]` the two texts as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You gave no location or authorization, so there is no statement to grade and the gate is unsettled | `[grounded]` JD; no candidate statement | Question R1 below |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The pay is stated but your floor was not given, so whether it clears is open | `[grounded]` JD; no candidate statement | Question R2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-reported, so no inspectable artifact yet | `[grounded]` your summary | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is a judgment an interviewer will probe | `[grounded]` your summary | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | Your dbt project on Snowflake has about 180 models. The JD's requirement says "a cloud warehouse", and its warehouse is BigQuery (see R6) | `[grounded]` your summary | none |
| R6 | BigQuery (from "dbt-modelled warehouse in BigQuery") | important | adjacent | medium | transferability | The dbt work on Snowflake carries over. The limit is that you have never used BigQuery, so its cost model, partitioning and dialect are untested by you. Warehouse differences like these are usually learnable on the job | `[grounded]` your summary; `[generic]` that warehouse differences are usually learnable | G1, a small dbt-on-BigQuery sample |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You use Airflow, which the JD names | `[grounded]` your summary | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` your summary | none |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Your summary does not say what sources fed your pipelines or whether any were app or CRM data | `[grounded]` your summary's silence | G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | A test suite is adjacent to contracts but does not establish them. Nothing says whether you defined or agreed schemas with analysts | `[grounded]` your summary's silence | G3 and question below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | About 180 dbt models on Snowflake, with no BigQuery use | The one named-tool gap; the bridge needs its limit stated | A dbt project run against BigQuery; migrating or porting models between warehouses; any GCP data work | A small public repo or write-up | `[grounded]` your summary; `[generic]` that this is the likeliest objection |
| G2 | App and CRM ingestion (R9, important) | discovery | Sources not stated | The JD opens its mandate with this layer | Loading product event data; syncing a CRM or similar SaaS source; building or maintaining connectors | A pipeline diagram or DAG list, sanitized | `[grounded]` your summary's silence |
| G3 | Data contracts (R10, important) | discovery | A test suite, but no stated agreements with analysts | The JD names contracts as something analysts depend on | Schema or freshness agreements with downstream analysts; breaking-change processes; alerting on failed expectations | A sanitized contract doc or expectation list | `[grounded]` your summary; `[inferred]` that your tests could underlie contracts |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Stated pay sits at or above market | positive_signal | — | "$148,000–$166,000 plus equity" | The range is transparent and competitive for the title | `[grounded]` JD and the report you supplied | Where in the range would someone with my background land? | noted |
| RR2 | Equity unquantified | unknown | — | "plus equity" | Grant size, vesting and strike terms are not stated, so the equity's worth is unknown | `[grounded]` JD silent | What is the equity grant, vesting schedule and latest valuation basis? | unresolved |
| RR3 | Team, manager and scope unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You might be the sole data engineer owning three layers, or one of several | `[inferred]` from the three layers against the silence on team | How many data engineers are there, who does this role report to, and what is on-call like? | unresolved |
| RR4 | Employer not independently verified | risk_signal | low | "Series C ($52M, February 2026)" | The pasted text came from the company's own pages, but I could not check the live posting. The research call was refused | `[generic]` pattern for any employer not checked, not a claim about this one | Can you confirm the role is live on your careers site, and who I would interview with? | unresolved |

## Application plan

All rows are proposals pending your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with your dbt project on Snowflake (about 180 models), Airflow and the Great Expectations suite, in your own words | R3, R5, R7, R8 | `[grounded]` your summary | `resume_edits_pending_approval` |
| W1 | Build a small dbt-on-BigQuery sample so R6 has an inspectable artifact | See R6, G1 | `[grounded]` R6 row | pending your approval |
| Q1 | Ask the RR2 and RR3 questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

If you decide to apply, resume-tailor can turn E1 into specific edits.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both the page fetch and the search ("Pellucid Learning online tutoring K-12 Denver Series C") were refused permission, so nothing was returned. It would have checked the posting is live and the about-page facts. RR4 stays open |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes market calibration, so a search would add little |
| 3. Hiring manager's public footprint | n/a | The posting names no manager, so there was no query to form |

## Upgrade menu

- Granting search and fetch access, or the live careers-page link → RR4 closes, and the JD can be checked against the live posting.
- A deeper pass on the company (funding, leadership changes, employee reports; up to 5 more searches and 2 more fetches) → feeds RR3 and RR4. Say the word and it runs.
- An answer on your location and pay floor → R1 and R2 settle, and the decision likely moves to `go`.
- A sanitized pipeline diagram or expectation list → G2 and G3 can move toward `high` confidence.
- A hiring manager's name → scope read and positioning.
- A BigQuery sample repo → R6 gets an inspectable artifact.

I can save this as `tuesday-dossier.md` if you'd like a version to carry into other steps.

**Questions**

R1 — Are you in the US with work authorization, and would you take the role remote or in Denver?

R2 — What base salary and equity would you need for this to be worth taking, and does the $148,000–$166,000 range clear it?

R10 — At your payroll company, did you agree schemas, freshness or breaking-change rules with the analysts who used your data, and what exactly did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.