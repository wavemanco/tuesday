Web search wasn't permitted in this session, so I'm assessing from the posting and your background alone. Both search attempts count against the research budget.

# Job Underwriting — Head of Growth at Novaline

## Decision snapshot

**No, this isn't worth pursuing as posted. R1 and R2, both hard gates, fail. Status: `no_go`.** Your "something feels off" is right, and it comes from the posting's terms, not from your fit.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site Austin 5 days a week), R2 (Base $70–85k)
- `must_have` — direct: R3, R4, R5 · unclear: R6 (SEO/content)
- `important` — unclear: R7 (Brand, PR, partnerships), R8 (Sales ops), R9 (Team of one)

R3, R4, R5 (each `medium`) — confirmed in your own words, no inspectable artifact yet; R6 — your background is silent.

**Opportunity ledger.** The role conflicts with both of your non-negotiables (RR1, RR2). Separately, it bundles seven functions into one solo seat (RR3), expects unpaid extra hours (RR4), and has no stable success definition (RR5). The employer is also unestablished (RR6). One entry runs the other way: it reports to the CEO (RR7).

- **Hard gates:** failed: R1 (On-site Austin 5 days a week), R2 (Base $70–85k).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** a written offer of at least $150k base and remote work from Portland, neither of which the posting hints at. It says "no exceptions" on location, and its top of range is $65k under your floor.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting text; the claims are unverified (RR6) |
| Mandate | All revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team and reporting | Team of one to start; reports to the CEO, dotted line to the board | `[grounded]` posting |
| Working pattern | Austin office five days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity figures | `[grounded]` posting |
| Success metrics | "Will evolve as we learn" | `[grounded]` posting |
| Scope read | Seven functions that usually belong to a team, in one seat, at the compensation stated | `[inferred]` from the function list against "team of one" and the pay band |
| Market calibration | Not established: no search ran. I'm not using memory for market bands, so I can't say what this title and scope normally pay. | `[generic]` nothing asserted; research unavailable |
| Unknowns | Budget, decision rights, equity size and vesting, who the board contact is, what "bench" hiring later looks like | — |
| Contradictions | "Own all revenue growth" with a dotted line to the board, yet "a team of one" and no stated budget | `[inferred]` from the posting's own language |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, "no exceptions" (your constraint: remote only, Portland) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated limit, which is specific and confirmed. Fit fails because the posting rules out remote work and you're not relocating. | `[grounded]` posting quote and your statement | Only an employer change to the terms resolves this |
| R2 | Base $70–85k (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. Fit fails because the top of the posted range is $65k below it, so no point in the range is close. | `[grounded]` posting figure and your statement | Only an employer change to the terms resolves this |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years, including Head of Growth at two companies. It's self-report with no inspectable artifact yet, so `medium`. | `[grounded]` your stated background | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid at both companies, with a controlled budget. The $8M to $40M ARR scale-up is stated, not inspected. | `[grounded]` your stated background | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze. | `[grounded]` your stated background | none |
| R6 | SEO/content | must_have | unclear | none | discovery | You haven't mentioned SEO or content. The gap may be real or may just be unstated. | `[grounded]` your background's silence | See G1 |
| R7 | Brand, PR, partnerships | important | unclear | none | discovery | Nothing in your background touches these. Under `no_go` the gap is moot. | `[grounded]` your background's silence | none while R1, R2 fail |
| R8 | Sales ops | important | unclear | none | discovery | Nothing stated. | `[grounded]` your background's silence | none while R1, R2 fail |
| R9 | Operate as a team of one | important | unclear | low | discovery | You've built teams of 3–7, which doesn't show whether you've worked solo. You do state hands-on ownership of paid, lifecycle and experimentation. | `[grounded]` your stated background; `[inferred]` that hands-on ownership may carry over | none while R1, R2 fail |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, must_have) | discovery | Nothing on SEO or content in your background | It's a `must_have` row at `unclear`, but with R1 and R2 failed, closing it can't move the decision | Owning organic traffic targets; commissioning content; working with an SEO lead on lifecycle or landing pages | Organic-traffic dashboard screenshots, a content calendar | `[grounded]` background silence; `[inferred]` that closing G1 alone can't change the status |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay below your floor (see R2) | red_flag | high | "$70–85k base" | The posted range is incompatible with your $150k floor, so this role is a red flag for you whatever the market thinks of it | `[grounded]` posting figure and your stated floor | Is the base negotiable, and is there any range above $85k? | confirmed |
| RR2 | Location rules out remote (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The posting leaves no room for a Portland-based hire | `[grounded]` posting quote and your stated constraint | Is there any scenario in which this role is hired remotely? | confirmed |
| RR3 | Bundled specializations in a team of one | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… a team of one" | Several full roles folded into one seat may be priced as a single role | `[inferred]` from the function list against the stated pay | What budget and hiring plan exist for specialists or contractors? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be routine and unpaid, since "when it matters" is undefined | `[inferred]` from the posting's phrasing | How often have evenings and weekends been needed in the last quarter? | unresolved |
| RR5 | No stable success definition on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability for all revenue growth with no defined target | `[inferred]` from the quote against the mandate | What would a good first 90 days look like, and who decides? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and say who I'd interview with? | unresolved |
| RR7 | Reports to the CEO | positive_signal | — | "Report to the CEO with a dotted line to the board" | Proximity to the decision-maker | `[grounded]` posting | Does the CEO own the growth budget? | noted |

I'm going only on what you've shared and what the posting says, and I can get this wrong. Before you reply or send anything, please confirm the employer is real. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply as posted | R1, R2 | `[grounded]` map rows | pending your approval |
| A2 | If you want to test the terms anyway, ask in writing, before spending effort, whether remote work and a base of at least $150k are possible | RR1, RR2 | `[grounded]` register | pending your approval |
| A3 | If you proceed despite `no_go`, ask the questions in RR3 to RR6 verbatim in the first conversation | Those questions become essential | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Series A"; the call was refused. It would have moved role reality's organization row and RR6. |
| 2. Role-family sweep | unavailable | Searched "Head of Growth Series A startup salary base range"; the call was refused. It would have moved the market calibration row and sharpened RR1's comparison. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

Would you like me to put this into a `tuesday-dossier.md`? It's optional.

## Upgrade menu

- A search permission grant, then the employer's careers page, would settle RR6 and fill the market calibration row.
- The hiring manager's name would add a scope read for role reality.
- A written reply on remote work and base would resolve R1 and R2. That is the only thing that changes the decision.
- Evidence of SEO or content ownership, such as an organic-traffic dashboard, would close G1.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.