**Yes, apply, but check two things first. Status: `conditional_go`.** R1, R2, R3, R4, R5a, R6a and R7 all land `direct`. R10 (UK-remote terms) is unconfirmed, and RR1 (employer not yet verified) is open.

**Fit ledger.**

- `hard_gate` — unclear: R10 (Fully remote, UK)
- `must_have` — direct: R1, R2, R3, R4, R5a, R6a, R7 · unclear: R5b (Designing price tests), R6b (Recommendations to product)
- `preferred` — direct: R8 · adjacent: R9 (Pet-insurance domain)

R5b and R6b — one question each could settle them; R9 — a credible bridge, its limit named (motor pricing, not pet); R10 — location and right to work are not stated.

**Opportunity ledger.** The employer is unverified because no research ran (RR1). Pay is not stated (RR2) and line-management scope is unstated (RR3). On the plus side, the responsibilities are specific and map onto your background (RR4).

- **Hard gates:** none failed; unconfirmed: R10 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R10 confirmed: UK-based with the right to work; (2) RR1 cleared: the role is live on Brindlemoor's own careers page; (3) the pet-insurance bridge (R9) is framed as adjacent, never as pet-pricing experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech, with a pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` your message |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | An owner-level individual contributor for one product's pricing. The JD names no direct reports | `[inferred]` from "Own" and three named duties, against silence on a team |
| Market calibration | Not run. Web search was not permitted, so no pay band is given and none is taken from memory | `[grounded]` search refused (see Evidence status) |
| Unknowns | Pay; team shape and any reports; success measures; who in product receives recommendations | `[grounded]` the JD does not state them |
| Contradictions | None found between the JD and what you told me. The employer's own pages were not checked | `[grounded]` inputs compared; no page fetched |

## Evidence map

Your background came as typed prose, which counts as CV-equivalent self-report. That caps every row at `medium` until something inspectable is seen.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics at a UK motor insurer, stated by you. Confirmed and specific, with no inspectable artifact yet | `[grounded]` your intake message | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily", stated. The depth is not described | `[grounded]` intake message | none |
| R3 | GLM experience | must_have | direct | medium | presentation | You built and maintained the GLM rating model for the young-driver book. The CV is not in hand, so how it presents this is unknown | `[grounded]` intake message; CV not seen | A sanitised model summary would raise to high |
| R4 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" the young-driver GLM covers both verbs | `[grounded]` intake message | none |
| R5a | Run price tests with underwriting | must_have | direct | medium | none | 14 price tests last year with the underwriting team, stated | `[grounded]` intake message | none |
| R5b | Design price tests | must_have | unclear | low | discovery | "Ran" does not say whether you designed them: hypothesis, control, sample size, readout metric. Taken at the lower reading | `[grounded]` the wording of your claim; `[inferred]` that design may sit within it | See G1 |
| R6a | Recommendations for underwriting | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` intake message | none |
| R6b | Recommendations for product | must_have | unclear | low | discovery | Nothing said about product-team work | `[grounded]` silence in your message | See G2 |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly review to the head of underwriting. Actuarial audiences are not mentioned | `[grounded]` intake message | none |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurance is insurance | `[grounded]` intake message | none |
| R9 | Pet-insurance domain knowledge | preferred | adjacent | medium | transferability | The JD asks only for insurance experience; pet is implied by the product. You stated no pet work. Rating mechanics carry over, but pet pricing typically turns on factors motor does not, such as breed, age and pre-existing conditions | `[inferred]` requirement from the product line; `[generic]` on pet rating factors | See G3 |
| R10 | Fully remote, UK | hard_gate | unclear | low | hard_gate | Your employer is UK-based, but your location and right to work were not stated. Confidence is low because the constraint is unconfirmed | `[inferred]` from the UK employer | G4 question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Designing price tests (R5b, must_have) | discovery | "Ran 14 tests" is established. Who set the hypothesis, control and sample size is not | The JD says "design and read", so design is half of the duty | Choosing the test and control cells; setting duration or sample size; picking the readout metric; deciding what counts as a win | A test-design note or a readout deck, sanitised | `[grounded]` JD wording; `[generic]` that screens probe design ownership |
| G2 | Recommendations to product (R6b, must_have) | discovery | Underwriting audience established; product audience not | The JD names both audiences | A test result that changed a cover tier, excess option or renewal rule; working with a product owner | A recommendation paper, sanitised | `[grounded]` JD; `[inferred]` that motor pricing meets product somewhere |
| G3 | Pet-insurance domain (R9, preferred) | transferability | Adjacent: GLM rating and price testing carry over. Limit: no pet-specific rating factors or claims patterns exercised | A preferred row, but the likeliest probe | Any exposure to age-banded or health-related rating; claims-inflation work | A short note on how you would adapt your young-driver model approach to pet | `[generic]` that pet differs from motor; `[inferred]` the bridge from your motor GLM work |
| G4 | Location and right to work (R10, hard_gate) | hard_gate | Not stated | A term you either meet or do not; wording cannot fix it | n/a | n/a | `[grounded]` not stated in inputs |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Brindlemoor (insurtech)" | The search that would check this was refused, so this is not a finding about Brindlemoor. A small or new firm may simply have a thin footprint, or the posting may be stale | `[generic]` pattern for companies of this size, not a claim about this one | Can you confirm this role is live on your own careers page, and who I would interview with? | unresolved |
| RR2 | Pay not stated | unknown | — | (no pay figure in the posting as given) | The pay may be below or in line with market; I cannot say | `[grounded]` posting silent; nothing assumed | What salary range is budgeted for this post? | unresolved |
| RR3 | Line-management scope unstated | unknown | — | "Own pricing analytics" | It may be a solo owner role, or it may grow into leading analysts | `[inferred]` from "Own" against silence on reports | Does this role have reports now or planned, and what does the pricing team look like? | unresolved |
| RR4 | Specific, checkable responsibilities | positive_signal | — | "build and monitor rating models, design and read price tests" | The duties are concrete and map onto your stated work | `[grounded]` JD | What would success look like in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Brindlemoor's own careers page, and that the recruiting contact's email domain matches it, before spending effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with your own sentences: five years' pricing analytics at a UK motor insurer; built and maintained the young-driver GLM rating model; ran 14 price tests last year with the underwriting team; present the quarterly pricing review to the head of underwriting | R1, R3, R4, R5a, R7 | `[grounded]` each clause traces to your intake message | pending your approval |
| A3 | Describe pet as adjacent: "I price motor; I haven't priced pet, and here's how I'd adapt my approach". Don't imply pet experience | R9 | `[grounded]` your statement that you have no pet experience | pending your approval |
| A4 | Ask the register's verification questions of RR1 to RR4 in the loop | The register doubles as interview prep | `[grounded]` register | pending your approval |

Nothing in the plan or the JD calls for management experience, so I made no row for it. Raising it unprompted would add a gap the JD does not name. RR3 is the question that settles whether it matters.

## Evidence status

Verified: none yet. The CV and any artifacts have not been seen.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech careers"; permission was not granted. Would have moved role reality's contradictions row and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst pet insurance UK remote salary"; permission was not granted. Would have moved the market calibration line and RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; permission was not granted. Would have moved the scope read and the positioning in A2 |

Everything outside your own words is therefore labeled inference or generic pattern, and I have not retried the searches.

I can write this up as a `tuesday-dossier.md` if you want to carry it into later steps.

**Upgrade menu**
- Your CV → R3 and R4 checked for how they read, and R1 to R8 firmed against it.
- A sanitised model summary or test readout → R3, R5a and R5b toward `high`.
- Web search permitted → targets 1 to 3 rerun, moving RR1, RR2 and the scope read.
- A reply on G1, G2 and G4 → R5b, R6b and R10 move off `unclear`.

**Questions**
- G4 — Are you UK-based with the right to work in the UK without sponsorship, and does fully remote UK work meet your own requirements?
- G1 — On the 14 price tests, which parts did you personally set: the hypothesis, the control cells, the sample size, the readout metric?
- G2 — Did any test result go to a product owner, and did it change a cover tier, an excess option or a renewal rule?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.