Search permission was declined, so I worked from the posting and your background alone. Both refused calls are counted below.

# Job Underwriting Assessment: Head of Growth at Novaline

## Decision snapshot

**No, this is not worth pursuing. R1 and R2, both hard gates, fail on the posting's own terms. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site in Austin 5 days a week), R2 (Base pay $70–85k)
- `must_have` — direct: R3, R4, R5, R6
- `important` — unclear: R7 (SEO/content), R8 (Brand, PR, partnerships), R9 (Sales ops), R10 (Team of one to start)

R3 — nine years against the posting's eight; R4 — the $8M to $40M ARR scale-up; R7 — silent in your background, not absent.

**Opportunity ledger.** Your "something feels off" is borne out on the role itself, apart from your constraints. The posting stacks pay against mandate (RR1), bundled functions (RR2), no stated resources (RR3), expected after-hours work (RR4), undefined success (RR5) and an employer I could not verify (RR6). The one favorable entry is the CEO reporting line (RR7).

- **Hard gates:** failed: R1 (On-site in Austin 5 days a week), R2 (Base pay $70–85k).
- **Severe red flags:** none found.
- **What would change this:** the employer would have to allow remote work (R1) and put base pay at $150k or more (R2). Nothing in how you present yourself can move either.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, described as an e-commerce enablement startup, Series A, "profitable since day one"; I could not check any of this | `[grounded]` posting's own claim, unverified (see RR6) |
| Mandate | Own all revenue growth across paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin five days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside"; equity unquantified | `[grounded]` posting |
| Scope read | A department's worth of functions with no team and no stated budget | `[inferred]` from the posting's function list against "team of one to start" |
| Success metrics | None stated; "will evolve as we learn" | `[grounded]` posting |
| Market calibration | Not established. The pay search was refused, so I give no market band; the only comparison is the posting's figure against your floor (R2) | `[grounded]` posting figure and your stated floor |
| Unknowns | Real company size and funding; what "sales ops" covers; equity terms; budget; first-year outcomes | — |
| Contradictions | None found, but only the posting was available to compare | `[grounded]` single source |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated limit (remote-only, Portland, not relocating). The fail is the posting's "no exceptions" against that limit | `[grounded]` JD quote and your stated constraint | Surface only; the employer changing terms or you revising the constraint is the only resolution |
| R2 | Base pay $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your $150k floor. Even the top of the posted range is $65k below it (arithmetic on the two figures) | `[grounded]` JD quote and your stated floor | Surface only; equity cannot be weighed against a base-pay floor |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then Head of Growth at two B2C subscription companies. The claim is specific, but it is self-reported with nothing inspectable yet. A years requirement is not a gate | `[grounded]` your stated background | none |
| R4 | Own revenue growth end to end | must_have | direct | medium | none | Scaled one company from $8M to $40M ARR over three years with a budget you controlled; self-reported. Fit covers revenue ownership in B2C subscription, not every function the posting lists | `[grounded]` your stated background | If it ever matters: a sanitized growth P&L or board-deck page would raise this to `high` |
| R5 | Paid acquisition | must_have | direct | medium | none | You stated you owned paid at both companies; no artifact yet | `[grounded]` your stated background | none |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle and name Braze, SQL and GA4; no artifact yet | `[grounded]` your stated background | none |
| R7 | SEO/content | important | unclear | none | discovery | Nothing in your background mentions it. That is silence, not proof of absence | `[grounded]` background silent | See G2 |
| R8 | Brand, PR, partnerships | important | unclear | none | discovery | Same silence, across three functions that are usually distinct | `[grounded]` background silent; `[generic]` these are usually separate specialties | See G2 |
| R9 | Sales ops | important | unclear | none | discovery | Background silent. "Sales ops" suggests a sales-led motion, which differs from B2C subscription | `[grounded]` background silent; `[inferred]` sales-led motion from the term | See G2 |
| R10 | Team of one to start | important | unclear | low | discovery | You built and managed teams of 3–7; operating alone is not stated. Adjacent at best | `[grounded]` team sizes you gave; no solo evidence | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Remote-only and $150k floor against on-site and $70–85k (R1, R2, hard_gate) | hard_gate | Both terms conflict with your stated non-negotiables | Decides the status; no fit elsewhere offsets a failed gate | Not applicable; wording cannot solve a gate | A written change of terms from the employer | `[grounded]` JD and your constraints |
| G2 | SEO/content, brand/PR/partnerships, sales ops (R7, R8, R9, important) | discovery | Background is silent on all of these | Only matters if the gates move, since the decision rests on R1 and R2 | Owning a content or SEO program; running affiliate or partner deals; building lead-routing or CRM for a sales team | A content plan, partner agreement or sales-ops dashboard | `[grounded]` silence; `[inferred]` that it only matters if the gates move |
| G3 | Operating without a team (R10, important) | transferability | Teams of 3–7 built and managed; solo work not shown | Next to the pay and hours signals, this is the part of "team of one" that would be a real cost | A stretch running growth alone, e.g. early at a company or a solo launch | Org chart or role history showing the period | `[grounded]` team sizes; `[inferred]` limit of the bridge |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Seniority-compensation mismatch | risk_signal | medium | "8+ years growth leadership required" / "$70–85k base plus meaningful equity upside" | The base may be low for a head-level mandate with CEO and board reporting; no market band was checked, so I rate it at the lower severity | `[inferred]` from the posting's scope against its stated base, no market search | How was the base set for this seat, and what is the equity (percentage, vesting, strike)? | unresolved |
| RR2 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | Several full roles may be folded into one seat | `[inferred]` from the length of the function list against "team of one" | Which of these functions do I own directly, and which will you hire for, and when? | unresolved |
| RR3 | Responsibility without resources | risk_signal | medium | "team of one to start — we believe in players who don't need a bench" | Accountability for all revenue with no stated budget or headcount | `[inferred]` from the posting's silence on budget | What budget and headcount are committed for the first year? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be a cultural default rather than an exception | `[inferred]` from the phrase "just who we are" | In the last quarter, how many evenings or weekends did the team work, and why? | unresolved |
| RR5 | Success metrics absent on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You may be held accountable without a fixed definition of success | `[inferred]` from the posting's silence on targets | What would a good first 90 days and first year look like, in numbers? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Where is this role posted on your own careers site, and who would I interview with? | unresolved |
| RR7 | Direct CEO reporting line | positive_signal | — | "Report to the CEO with a dotted line to the board" | Suggests genuine seniority and access, whatever the pay | `[grounded]` posting | How often does the board see growth reporting? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Do not apply as posted | See R1, R2 | `[grounded]` fit map | pending your approval |
| A2 | Only if you want to test flexibility: one note to the recruiter or CEO asking whether remote work and a $150k+ base are available, and stop if either is no | The employer is the only party who can change R1 and R2; the register questions RR1–RR6 become essential if you proceed anyway | `[grounded]` R1, R2 | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused. It would have confirmed Novaline exists and the posting is live (RR6, role reality's organization row) |
| 2. Role-family sweep | unavailable | The search was refused. It would have given a market band for the mismatch check (RR1) and the market calibration row |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save this as `tuesday-dossier.md` if you want to carry it forward.

## Upgrade menu

- A live link to the posting, Novaline's own careers page, or the recruiter's email domain → RR6 and the organization row.
- A salary search (the one that was refused) → a market band for RR1 and the market calibration row.
- The full compensation terms, with equity percentage, vesting and strike → RR1.
- The employer's written answer on remote work and base pay → R1 and R2, and the decision.
- A sanitized growth P&L or a board-deck page showing the $8M to $40M ARR → R4 to `high`.
- Evidence on SEO/content, brand/PR/partnerships or sales ops → R7, R8 and R9.
- The hiring manager's name → the scope read and which of your stories to lead with.

No questions this turn: no answer from you could change the decision.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.