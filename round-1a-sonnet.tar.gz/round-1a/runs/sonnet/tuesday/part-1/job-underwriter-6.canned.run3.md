# Job Underwriting Assessment: Revenue Operations Lead at Quillfield

## Decision snapshot

**Yes, worth applying to, as a stretch rather than a clean fit. R8a (Billing data) is absent and R7 (Experience owning a forecast) is only adjacent. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, hybrid, two days a week in the office), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3a, R4, R5 · adjacent: R6 (Strong SQL and spreadsheet modelling), R7 (Experience owning a forecast) · unclear: R3b (At a B2B software company), R8b (Working with finance on revenue data) · absent: R8a (Billing data)

R7: a credible bridge through the pipeline review, its limit named; R8a: no billing-data evidence, against a seat that says it will "own our CRM and billing data"; R6 (`low`): usage is confirmed, "strong" and "modelling" are not shown.

**Opportunity ledger.** The employer is established (RR4) and the pay is stated and in band (RR3). The reporting line (RR1), share options (RR2), live posting (RR5) and the forecast split with finance (RR6) are unknowns that cost one conversation to close.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid, two days a week in the office), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1 and R2 work for you; (2) the forecast split is clarified as a ramp, not a day-one expectation (R7, RR6); (3) billing data is confirmed learnable on the job (R8a); (4) your employer counts as a B2B software company (R3b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. It was founded in Bristol in 2018, has 96 employees and closed a £11M Series A in April 2025. | `[grounded]` search result "About Quillfield", quillfield.co.uk/about |
| Mandate | Own the CRM and billing data. Build the pipeline and renewal reporting that sales and finance run on. Run the quarterly revenue forecast with the CFO. | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Compensation | £61,500–£67,000 plus share options; the option terms are not stated | `[grounded]` posting |
| Hiring manager | Tamsin Achebe is listed as Head of Revenue Operations at Quillfield, and was previously a sales operations manager at Corvane Payments for four years. | `[grounded]` search result "Tamsin Achebe — Head of Revenue Operations, Quillfield" (public listing); you report the recruiter named her |
| Scope read | A lead seat under a Head of Revenue Operations, so probably not the top revenue-operations post. | `[inferred]` from the title "Lead" against her listed title |
| Market calibration | The posting's midpoint (£64,250) sits close to the guide's median (£64,200). The range sits inside the guide's interquartile range (£57,800–£70,400). The guide is UK-wide, not Bristol-specific, and is the posting's band, never a promise of the offer. | `[generic]` search result "Ledgerline 2026 UK Revenue Operations Pay Guide" (n=438); `[grounded]` posting figures |
| Unknowns | Reporting line and team size; share-option terms; who builds the forecast model today; whether Quillfield runs Salesforce or HubSpot (the posting accepts either); whether the role is live on Quillfield's own careers page | — |
| Contradictions | None between the posting and the about page | `[grounded]` posting and "About Quillfield" |

## Evidence map

I haven't seen your CV, so your background is treated as self-reported and capped at `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | The posting states the term. You haven't told me where you live or what you'll commute, so the gate is not established. | `[grounded]` posting; no stated constraint from you | Gate question below |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | The posting states the band. Your pay floor is not given, so this is not established. | `[grounded]` posting; no stated constraint from you | Gate question below |
| R3a | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | You describe 5 years in sales operations, the last 2 running revenue operations for the UK team. The claim is specific, but there is no inspectable artifact. | `[grounded]` your background statement | none |
| R3b | …at a B2B software company | must_have | unclear | low | discovery | Your employer is a B2B payments company. Whether it sells software, as the posting's wording implies, is not stated. | `[grounded]` your statement; the posting's qualifier is quoted | A one-line answer from you, or ask the recruiter if it counts |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | You are Salesforce admin certified, which the posting's "or" accepts as written. Which CRM Quillfield runs is unknown. | `[grounded]` your statement | Certification link would raise to `high` |
| R5 | Build the pipeline and renewal reporting that sales and finance run on | must_have | direct | medium | none | You rebuilt your company's pipeline and renewal dashboards. I can't judge presentation without the CV. | `[grounded]` your statement | A sanitized dashboard screenshot would raise to `high` |
| R6 | Strong SQL and spreadsheet modelling | must_have | adjacent | low | discovery | You use SQL weekly and Excel daily, but frequency of use does not show "strong" or "modelling". Lowest band taken. | `[grounded]` your statement; limit is `[inferred]` from what the statement omits | A sanitized SQL query or workbook would settle it |
| R7 | Experience owning a forecast (and running the quarterly forecast with the CFO) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, which supplies forecast inputs. Finance owned the company forecast, so you have not owned the number. | `[grounded]` your statement; the bridge is `[inferred]` | Gap queue G3 |
| R8a | Experience with billing data | must_have | absent | none | capability | You have never worked on billing data. The role is also asked to "own our CRM and billing data". | `[grounded]` your statement | Gap queue G1 |
| R8b | Working with finance on revenue data | must_have | unclear | low | discovery | Renewal dashboards touch revenue figures, but your statements don't say finance was involved in them. | `[grounded]` your statement; the dashboard link to finance is `[inferred]` | Gap queue G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Billing data (R8a, must_have) | capability | You have never worked on billing data. | The posting puts billing data in the seat's own mandate and the company sells invoicing software. It is the clearest objection to your application. Closure paths: learn the billing system early, or show the nearest real work. | Reconciling renewal values in the CRM against what was invoiced; querying invoice or payment status in SQL; fixing contract-value mismatches with finance | A sanitized reconciliation sheet or a data-dictionary page | `[grounded]` your statement; `[generic]` that this is the likeliest objection |
| G2 | Finance on revenue data (R8b, must_have) | discovery | The renewal dashboards touch revenue, but finance involvement is not stated. | It decides whether R8b is adjacent or still unclear, and it may surface billing-adjacent work for G1. | Agreeing renewal or ARR definitions with finance; reconciling a dashboard figure to finance's number; building a report finance later relied on | A metric-definition doc or a sanitized dashboard spec | `[grounded]` your statement's silence; `[generic]` that finance usually reconciles these figures |
| G3 | Owning a forecast (R7, must_have) | transferability | The monthly pipeline review is the bridge. Finance set the company number. | The posting asks for forecast experience and the CFO runs it with this seat. A stated bridge with a stated limit reads stronger than a stretched claim. Strengthener: a small work sample, such as a pipeline-coverage or renewal-forecast view built for your own review. | Putting commit, best-case or expected-renewal figures into the pipeline review; tracking forecast against actuals for your own team | A sanitized coverage view or a forecast-versus-actual tracker | `[inferred]` bridge derived from your review description |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Reporting line and team size unstated | unknown | — | "Revenue Operations Lead, Quillfield." | The seat may sit under the Head of Revenue Operations with no reports, or may be asked to build a team. | `[inferred]` from the title against Tamsin Achebe's listed title and the posting's silence | Who does this role report to, and are there analysts or other reports in the team? | unresolved |
| RR2 | Share-option terms unstated | unknown | — | "plus share options" | The grant size, vesting and strike basis are unknown, so total pay cannot be compared yet. | `[generic]` option terms at funded companies vary widely, a pattern, not a claim about Quillfield | What is the option grant for this role, and how does it vest? | unresolved |
| RR3 | Pay stated and inside the market band | positive_signal | — | "Salary £61,500–£67,000" | The posting is transparent on base pay and sits within the guide's range. | `[grounded]` posting figure; `[generic]` guide band, UK-wide | Where in the range does an offer for this seat typically land? | noted |
| RR4 | Employer established as described | positive_signal | — | "Quillfield" | The company exists, sells the product the posting implies, and has recent funding. | `[grounded]` quillfield.co.uk/about | How has the revenue team grown since the Series A, and where does this seat fit? | noted |
| RR5 | Posting seen on a jobs board, not on the company's own careers page | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid: two days a week in the office." | The listing is probably current, but I did not reach a Quillfield careers page to confirm it. | `[inferred]` from the research reaching only the about page | Can you send me this role's link on Quillfield's own careers page? | unresolved |
| RR6 | Forecast ownership split with finance unstated | unknown | — | "run the quarterly revenue forecast with the CFO" | The seat may co-run a forecast finance still builds, or may take it over. | `[inferred]` from "with the CFO" against your report that finance owned it where you work | Who builds the forecast model today, and what would this role own in its first quarter? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm Bristol with two office days and the £61,500–£67,000 band work for you before investing in the loop | see R1, R2 | `[grounded]` posting | pending your approval |
| P1 | Lead with your Salesforce admin certification, the pipeline and renewal dashboards you rebuilt, and the monthly pipeline review you run with your sales director | see R4, R5, R7 | `[grounded]` your own statements | pending your approval |
| P2 | Say the limits first, in your own words: "Finance owned the company forecast; I run the monthly pipeline review with our sales director. I haven't worked with billing data." | see R7, R8a; they are the rows an interviewer is likely to probe | `[grounded]` your statements; `[generic]` that interviewers probe stated gaps | pending your approval |
| P3 | Ask RR1, RR2, RR5 and RR6 verbatim, plus how the role is onboarded to billing data | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P4 | Build one sanitized work sample, such as a pipeline-coverage or forecast-versus-actual view | strengthens R6, R7; see G3 | `[grounded]` R6, R7 rows | pending your approval |
| P5 | Lead for Tamsin Achebe with the pipeline and renewal reporting. Her listed background is in sales operations. | see R5 | `[inferred]` from her public listing | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers Revenue Operations Lead Bristol"; it returned "About Quillfield" (quillfield.co.uk/about). Moved role reality's organization and contradictions rows, and RR4. No careers page was reached, hence RR5. |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol"; it returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration and RR3. |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; it returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the hiring-manager and scope rows, RR1 and P5. |

If you'd like, I can write this up as a `tuesday-dossier.md` to keep.

**Upgrade menu**

- Where you live, your commute tolerance and your pay floor: R1 and R2 close, and the status is likely to move to `go` or `no_go`.
- Your CV: shows whether R4 and R5 are communicated or buried, which I can't judge from prose.
- A Salesforce certification link: R4 to `high`.
- A sanitized dashboard screenshot: R5 to `high`.
- A sanitized SQL query or workbook: R6 settles.
- A forecast-style work sample or review pack: R7's bridge strengthens.
- Any renewal-to-invoice reconciliation, even informal: R8a and R8b improve.
- The recruiter's answers on reporting line, option terms and the forecast split: RR1, RR2 and RR6 close.
- A link to the role on Quillfield's own careers page: RR5 closes.
- Stage: I've assumed you're still evaluating, not yet applied.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

R1, R2: Is Bristol with two office days a week workable for you, and is £61,500–£67,000 at or above your floor?

G3: In your monthly pipeline review, do you put forecast numbers on the table (expected closes or renewals), and who set the final figure?

G2: Have you ever reconciled renewal or revenue figures with finance, even informally? What did you own, and what changed as a result?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.