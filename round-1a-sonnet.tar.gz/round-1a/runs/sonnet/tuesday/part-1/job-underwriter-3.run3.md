Web search was denied, so this runs on the posting and your message alone.

## Decision snapshot

**No. R1 and R2, both hard gates, fail, so this posting isn't worth pursuing as written · `no_go`.** Your sense that something is off holds up on the role itself, separate from your constraints. The register entries below show where.

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site Austin 5 days), R2 (Base $70–85k)
- `must_have`: direct: R3, R4, R5, R6
- `important`: unclear: R7 (SEO/content), R8 (Brand, PR, partnerships, sales ops)

R3, R4, R5, R6: your stated experience maps directly, self-reported; R7, R8: not covered by anything you've told me; R1, R2: conflict with your two stated constraints.

**Opportunity ledger.** The posting folds seven functions into one title for a team of one (RR3, RR4), expects evenings and weekends (RR5) and leaves success undefined (RR6). Equity is unquantified (RR7) and the employer is unverified (RR8). One entry runs the other way: a direct CEO reporting line (RR9).

- **Hard gates:** failed: R1 (On-site Austin 5 days a week), R2 (Base $70–85k)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** the posting's on-site term (R1) and its base range (R2) would have to be different. Nothing in the gap queue can move the status while those stand.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` the posting's own claim, not verified |
| Mandate | Own all revenue growth across paid, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` posting |
| Reporting and team | Reports to the CEO, dotted line to the board. A team of one to start | `[grounded]` posting |
| Working pattern | Austin office five days a week, no exceptions. Evenings and weekends "when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside", not quantified | `[grounded]` posting |
| Success metrics | "Will evolve as we learn". No first-90-day or first-year outcomes stated | `[grounded]` posting |
| Scope read | Several full functions bundled under one title, with no budget or headcount named | `[inferred]` from the seven-function list against "team of one" and the posting's silence on budget |
| Market calibration | Not established: the role-family search was refused. The pay comparison rests only on the posting's figure and your stated floor (R2) | `[grounded]` posting figure and your stated floor |
| Unknowns | Employer verification, budget, equity terms, what "success" means | — |
| Contradictions | None inside the posting. Nothing was cross-checked against a careers page | `[grounded]` posting only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated limit (remote-only, Portland, not relocating), which is specific and confirmed. Fit is a failed gate because the posting rules out any remote arrangement. | `[grounded]` JD quote and your stated constraint | Surface only. The posting's terms would have to change. |
| R2 | Base pay $70–85k, against your floor of at least $150k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. Fit fails because the posting's top figure, $85k, is $65k below it. | `[grounded]` JD figure and your stated floor | Surface only. The posting's range would have to change. |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You report 9 years in growth, as growth lead and then Head of Growth at two companies. How those years split between leading and doing isn't stated, so the leadership portion is unconfirmed. | `[grounded]` your stated background, self-reported | none needed for the decision |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid at both companies. Confirmed and specific, with no artifact inspected. | `[grounded]` your stated background | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze. Confirmed and specific, with no artifact inspected. | `[grounded]` your stated background | none |
| R6 | Own revenue growth outcomes with a budget | must_have | direct | medium | none | You scaled one B2C subscription company from $8M to $40M ARR over three years, with a budget you controlled. No inspectable proof yet. | `[grounded]` your stated background | an ARR or channel-spend summary would raise this to `high` |
| R7 | SEO/content | important | unclear | low | discovery | Your background as stated doesn't mention SEO or content. That could be an omission or a real gap. | `[grounded]` silence in what you told me | see G1 |
| R8 | Brand, PR, partnerships, sales ops | important | unclear | low | discovery | Same: none of these four appears in what you told me. | `[grounded]` silence in what you told me | see G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R7, important) | discovery | Nothing on organic or content work in your stated background | It can't move the decision while R1 and R2 stand | Owning an organic-traffic or content program; directing an agency or writers | A traffic report or content-calendar summary | `[inferred]` from R1 and R2 being failed gates |
| G2 | Brand, PR, partnerships, sales ops (R8, important) | discovery | Nothing on these four in your stated background | Same as G1 | Running affiliate or partner programs; co-marketing; launch PR with an agency; sales–marketing handoff work | A partner-program summary or launch brief | `[inferred]` from R1 and R2 being failed gates |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site requirement conflicts with your remote-only constraint (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | Conflicts with a stated non-negotiable, so this is a red flag for you whatever the market norm. Don't invest effort unless the posting's term changes. | `[grounded]` posting quote against your stated constraint | Is five days on-site in Austin a fixed condition of this role? | confirmed |
| RR2 | Pay range sits below your floor (R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The top of the range is $65k under your floor. Whether it's low for the title in general is not established, because the band search was refused. | `[grounded]` posting figure against your floor; `[inferred]` that the 8+ years and seven functions are priced low | Is the $70–85k base range firm for this role? | confirmed |
| RR3 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | Several full roles may be folded into one title. | `[inferred]` from the function list against "team of one" | Which of these functions does this role execute itself, and which are covered by agencies or contractors? | unresolved |
| RR4 | Responsibility without stated resources | risk_signal | medium | "You will be a team of one to start — we believe in players who don't need a bench." | You'd be accountable for all revenue growth with no named budget or headcount. | `[inferred]` from the posting's silence on budget | What budget and hiring plan come with this role? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be routine, not occasional. | `[inferred]` from the phrasing | How often have evenings and weekends been needed in the last quarter? | unresolved |
| RR6 | Demanding mandate, no success metrics | risk_signal | medium | "success metrics will evolve as we learn" | You'd be accountable without a stated definition of success. | `[inferred]` from the posting's silence on metrics | What would success look like at 90 days and at 12 months? | unresolved |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | The stake, vesting and valuation are all unstated. | `[grounded]` the posting gives no figure | What percentage, vesting schedule and strike price does the grant carry? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The searches were refused, so nothing was checked either way. The company may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and say who I'd interview with? | unresolved |
| RR9 | CEO reporting line, stated profitability | positive_signal | — | "Report to the CEO with a dotted line to the board… profitable since day one" | A senior reporting line suggests real access. The profitability claim is the posting's own and unchecked. | `[grounded]` posting, unverified | Who has final say on growth budget: you or the CEO? | noted |

## Application plan

No CV or outreach language is proposed, so nothing needs a language audit.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Pass on this posting as written. | See R1, R2, RR1, RR2. | `[grounded]` map and register | pending your approval |
| A2 | If you choose to proceed anyway, ask RR1, RR2, RR3, RR4 and RR8 verbatim before spending effort. | The register doubles as interview preparation. | `[grounded]` register | pending your approval |

## Evidence status

Verified: R1, R2, the two constraints in your own words. Unverified: the career claims behind R3, R4, R5, R6, which are self-reported with no artifact inspected. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused ("Novaline e-commerce enablement startup Austin Series A" and "Novaline Head of Growth Austin careers"). They would have fed role reality's organization and contradictions rows and RR8. |
| 2. Role-family sweep | unavailable | One search was refused ("Head of Growth salary base compensation Series A startup 2026"). It would have fed the market calibration row and RR2's comparison. |
| 3. Hiring manager's public footprint | n/a | No name was given; the posting names only "the CEO". |

I can write this up as `tuesday-dossier.md` if you'd like a saved record.

**Upgrade menu**

- Search permission would let me check that Novaline exists and the posting is live, which closes or confirms RR8. It would also give a market band for the title.
- A link to the live posting, or the recruiter's email domain, would also settle RR8.
- Different written terms from Novaline on location or base would re-grade R1 and R2.
- An ARR or channel-spend summary, or a sanitized Braze dashboard, would raise R3–R6 to `high`.
- Evidence of SEO, brand, PR, partnership or sales-ops work would resolve R7 and R8, though it only matters if the terms change.
- A hiring manager's name would sharpen the scope read.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.