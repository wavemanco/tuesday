Running the L1 research now: checking whether Brindlemoor and the role exist, a pricing-analyst market sweep, and Odile Varga's public footprint.
**Yes on the substance, but settle R1 before you invest in the application. Your pasted JD says "Fully remote (UK)". Brindlemoor's own careers page says "Leeds office four days a week". Status: `hold_pending_answers`.**

I checked Brindlemoor's careers page, a UK pay survey and Odile Varga's public profile. Your two worries, pet insurance and never having managed anyone, don't block you. The people-management row below shows why.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R6a, R7 · unclear: R5 (Monitor rating models), R6b (Designing price tests)
- `preferred` — direct: R8 · adjacent: R9 (Pet-insurance product knowledge)

R5 and R6b — your wording ("maintained", "ran") doesn't yet show monitoring or test design; R9 — a motor-to-pet bridge, its limit named.

**Opportunity ledger.** The posting is clear about the mandate (RR4), but its terms contradict each other on working pattern (RR1). It withholds the salary (RR2), and little public footprint turned up beyond its careers page (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the hold waits on two answers.
  - **Working pattern:** whether the role is remote or Leeds four days a week, and whether that works for you (R1, RR1). If it is Leeds four days and you can't do that, the status becomes `no_go` on R1.
  - **Pay floor:** whether your pay floor sits under the posting's eventual figure (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, with a pet-insurance product; the careers page describes the role and nothing else I found describes the company | `[grounded]` careers page fetched; no other result for the company |
| Mandate | Own pricing analytics for the pet-insurance product; build and monitor rating models, design and read price tests, make recommendations to underwriting and product | `[grounded]` your pasted JD; the careers page matches it on the product and the reporting line |
| Reporting line | Reports to the Director of Pricing | `[grounded]` careers page |
| Working pattern | Your JD says fully remote (UK); the careers page says Leeds office four days a week. The two disagree | `[grounded]` JD against careers page |
| People management | The JD states no line-management duty; the role is described as owning analytics | `[grounded]` your pasted JD |
| Compensation | Not stated in the JD you pasted | `[grounded]` your pasted JD |
| Market calibration | A senior pricing analyst at UK insurers and insurtechs has a median base of £58,400, interquartile range £52,100 to £64,900 (n=612, 2026 survey, read from the search snippet only). This is the band to expect, never this employer's offer | `[generic]` role-family search, Pricewell 2026 survey |
| Hiring manager | Odile Varga: spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors" (monitoring rating models in small books); previously head of pricing analytics at Calloway Re for six years | `[grounded]` public profile, search snippet |
| Unknowns | The real working pattern; the salary; the pricing team's size; the insurer or entity behind the product | — |
| Contradictions | Remote (JD) against Leeds four days (careers page) | `[grounded]` as above |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The JD and the careers page disagree, and you haven't stated a location or working-pattern constraint, so there is no stated constraint to grade | `[grounded]` JD against careers page | Ask the gate question (C1 below) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years pricing analytics at a UK motor insurer, 2 as senior analyst; typed background, no inspectable artifact. A years requirement is graded on fit, not treated as a gate | `[grounded]` your background as typed | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated; the "strong" level isn't independently shown, so expect a probe | `[grounded]` your background as typed | A sanitized notebook or query set would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book; the method matches, the line (motor) differs | `[grounded]` your background as typed | A sanitized model spec or documentation would raise to high |
| R5 | Monitor rating models | must_have | unclear | medium | discovery | "Maintained" is confirmed, but whether that included tracking performance and drift is not stated; taken at the lesser reading | `[grounded]` your background as typed | See gap queue G2 |
| R6a | Price-test work with underwriting (JD: "design and read price tests") | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team; "ran" is read as executing and working through them with underwriting, which the JD's "read" half draws on | `[grounded]` your background as typed | none |
| R6b | Designing price tests specifically | must_have | unclear | low | discovery | "Ran" doesn't say you designed them; whether you chose structure, segments or sample is unknown | `[grounded]` your background says "ran", not "designed" | See gap queue G3 |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting; your evidence names the underwriting audience, not product, which the mandate also lists | `[grounded]` your background as typed | none |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background as typed | none |
| R9 | Pet-insurance product knowledge (derived from owning pricing for that product) | preferred | adjacent | medium | transferability | You have not worked on pet insurance (your statement). The bridge is rating-model and price-test work on another line; its limit is that pet-specific pricing was never exercised | `[inferred]` from the JD's "pet-insurance product" against your stated background | See gap queue G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | JD says remote; careers page says Leeds four days | A gate that could end the application; the one thing the hold waits on | — (a term to confirm, not an experience) | The recruiter's written confirmation of the working pattern | `[grounded]` JD against careers page |
| G2 | Monitoring rating models (R5, must_have) | discovery | "Maintained" the GLM; no mention of ongoing performance tracking | The JD's mandate names monitoring explicitly | Tracking the model's performance against actuals; drift or relativity reviews; reporting performance of the young-driver model to underwriting | A monitoring pack, a dashboard screenshot, a review note | `[grounded]` background wording; `[inferred]` that the role weights this, from the JD's "build and monitor" |
| G3 | Designing price tests (R6b, must_have) | discovery | You "ran" 14 tests; design ownership not stated | The JD says "design and read", and design is the half your wording doesn't cover | Choosing test and control cells; setting sample size or duration; defining the success measure with underwriting | A test plan, a test readout, a write-up | `[grounded]` background wording |
| G4 | Pet-insurance knowledge (R9, preferred) | transferability | Motor pricing only | Preferred, so a minor risk; a stronger bridge narrows the objection most likely to come up | Any pricing for a product with sparse data or a new line; learning a new line's rating factors quickly | A short note on how you approached a new segment | `[inferred]` bridge from motor to pet; `[generic]` that a new-line objection is the likeliest one |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source may be stale, or the role may have changed from remote to office-based | `[inferred]` from the two sources disagreeing | Is this role fully remote, or office-based in Leeds four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | (no figure in the JD as pasted) | The figure may sit below or inside the role-family band in role reality, or the employer may not publish it | `[inferred]` from the JD's silence against the `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR3 | Little public footprint beyond the careers page | risk_signal | low | "Brindlemoor careers" page only; no results for the company itself | The company may be small or new, or the product may sit under another legal entity | `[generic]` pattern for companies of this size, not a claim about this one | Which entity underwrites the pet-insurance product, and how large is the pricing team? | unresolved |
| RR4 | Mandate and reporting line are stated | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | The ownership is real and the line goes to the Director, whose public talk is on monitoring rating models | `[grounded]` careers page and public profile | What would success look like in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Get the working pattern confirmed in writing before applying | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the young-driver GLM you built and maintained, then the 14 price tests you ran with the underwriting team; say "ran", not "designed", until G3 is answered | see R4, R6a, R6b | `[grounded]` your background wording | pending your approval |
| A3 | Say plainly that you haven't worked on pet insurance, and offer the rating-model and price-test work as the part that carries over, with its limit stated | see R9, G4 | `[inferred]` from R9 | pending your approval |
| A4 | Read Odile Varga's 2025 Insurance Pricing Forum talk if it is public before any conversation; its subject, monitoring rating models, is the thing G2 asks about | see R5, RR4 | `[inferred]` from the talk title in a search snippet | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Role reality's working-pattern and contradictions rows, and RR1 and RR3 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read from its snippet. Market calibration, labelled `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Role reality's hiring-manager row, RR4 and A4 |

I'd like to offer a one-page tailored positioning sheet for this role, built only on your approval.

## Upgrade menu

- The working pattern confirmed (remote or Leeds four days), plus your location → R1 and RR1 close, and the decision moves to `go`, `conditional_go` or `no_go`.
- Your pay floor → the gate check on pay, set against the survey band for RR2.
- A sanitized notebook or model spec → R3 and R4 move to `high`.
- A test plan or readout from one of the 14 tests → R6b resolves.
- A model-monitoring pack or dashboard screenshot → R5 resolves.
- A deeper research pass on Brindlemoor (funding, leadership, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

C1 (gate, tied to R1) — Where are you based, and could you work in Leeds four days a week if the role turns out to be office-based, or is fully remote essential for you?

G3 — In the 14 tests, did you choose the test and control cells, the sample size or duration, and the success measure, or were those set by someone else?

C2 (constraints) — What is your pay floor, and is there any other term you won't trade?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.