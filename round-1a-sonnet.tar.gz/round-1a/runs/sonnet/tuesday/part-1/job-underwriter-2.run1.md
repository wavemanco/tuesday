Still working: I've loaded the underwriting playbook and I'm reading its decision and risk rules so I can write your assessment in the required format.
**Research note:** my search permission was refused, so I couldn't check Quartzline or the market. Everything below comes from your resume and the JD. Anything that isn't tied to one of them is labeled as a pattern, not a finding.

## Decision snapshot

**Not a waste of time, but the 3+ years requirement is your hardest hurdle. R1a (3+ years in a PM role) is absent by title, while R3 and R4a are direct and R1b, R2, R6, R7 and R8 are adjacent. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (PM-type work for 3+ years), R2 (shipped API or platform products) · unclear: R4b (launches with sales and support), R5 (agile delivery) · absent: R1a (3+ years in a PM role, by title)
- `important` — adjacent: R6 (own the roadmap), R7 (discovery with integration partners), R8 (specs and delivery with squads) · unclear: R9 (define and track adoption metrics)

R1a — the one literal miss; R1b, R2, R6, R7, R8 — real bridges, each with its limit named; R4b, R5, R9 — unconfirmed and cheap to close.

**Opportunity ledger.** The role is clearly scoped (RR4), but the employer is unverified (RR1), pay is unstated (RR2), and nothing shows whether the titled-years bar is flexible (RR3).

- **Hard gates:** none in the posting, so none failed; your constraints (pay floor, location, remote) weren't given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR3 comes back flexible, or an introduction gets your adjacent experience read by a person before any title screen (R1a); (2) the employer verifies (RR1); (3) the request-triage tool is confirmed with specifics (G2).
- **What would change this:** if Quartzline confirms the bar means titled PM time, expect the status for this posting to move down. The pivot itself would not change.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header. It is not independently verified (RR1). |
| Mandate | Own the roadmap for the partner-facing API platform, run partner discovery, write specs, drive two squads, track adoption metrics, coordinate launches | `[grounded]` JD |
| Scope read | A normally-bounded platform PM post: one product surface, two squads, named responsibilities | `[inferred]` from the responsibility list. The JD is silent on reporting line and decision rights. |
| Market calibration | Platform and API PM roles often recruit from solutions, implementation and integration engineering, because the partner and technical fluency is hard to teach. Titled-years bars are often screened literally by recruiters and flexed by hiring managers. | `[generic]` pattern from general knowledge. No search ran, so this is not a finding about Quartzline and no pay band is offered. |
| Unknowns | Salary, location or remote, level, reporting line, whether the years bar flexes | `[grounded]` JD silence |
| Contradictions | None visible inside the JD | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years in a PM role, by title | must_have | absent | high | capability | Confidence grades your own statement that you have never held a PM title. Titled years are a risk to screen, not a gate. | `[grounded]` your statement, JD | RR3 question; see G1 |
| R1b | 3+ years of PM-type work | must_have | adjacent | medium | transferability | Roadmap-input sessions for product and requirements documents on custom builds are product-adjacent. Limit: your resume does not say you made a roadmap or prioritization decision. | `[grounded]` resume | See G2 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You shipped 30+ integrations of your company's REST APIs and wrote the integration playbook. Limit: those are deployments and an internal playbook, not API products you owned. | `[grounded]` resume | See G2 |
| R3 | Technical fluency: API docs and schemas | must_have | direct | medium | none | Integration architecture, Postman, SQL and OpenAPI reading are stated. Medium because nothing is inspectable yet. | `[grounded]` resume | A sanitized integration-architecture doc would raise it to high. |
| R4a | Stakeholders across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs, and ran client workshops. | `[grounded]` resume | none |
| R4b | Launches with sales and support | must_have | unclear | low | discovery | The resume is silent on sales and on support, and a go-live is not a launch. | `[grounded]` resume silence | See G4 |
| R5 | Agile delivery experience | must_have | unclear | low | discovery | The resume does not mention sprints or a delivery cadence. | `[grounded]` resume silence | See G3 |
| R6 | Own the roadmap | important | adjacent | low | transferability | You collected client input for product, so the roadmap itself was the PMs'. | `[grounded]` resume | See G2 |
| R7 | Discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops on 30+ integrations and quarterly roadmap-input sessions. Limit: not stated whether any session changed a product decision. | `[grounded]` resume | See G2 |
| R8 | Specs and delivery with two squads | important | adjacent | medium | transferability | You wrote requirements documents and coordinated engineers on custom builds. Limit: you did not run a squad's backlog. | `[grounded]` resume | See G2 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | The resume states no usage or adoption measure. The earlier-conversation note is a lead only. | `[grounded]` resume silence | G3's question, asked at the end |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | 3+ years in a PM role (R1a, must_have) | capability | No PM title | A recruiter screen may read this literally. Wording cannot change the fact. | None by title. Closure is an introduction, a flexible hiring manager, or a PM-titled step first. | none | `[generic]` how screens often work; `[grounded]` your statement |
| G2 | Product ownership (R1b, R2, R6, R7, R8; must_have and important) | transferability | Playbook, roadmap-input sessions, requirements documents, custom builds | This is the bridge a hiring manager would probe | A custom build where you decided scope; the playbook; the triage tool, if it is yours; a roadmap-input session that changed what product built | A sanitized playbook page, a session summary, tool usage numbers | `[inferred]` bridge from your resume |
| G3 | Agile and metrics (R5, R9) | discovery | Nothing stated | Metrics are a named responsibility | Sprint work with a client or team; any usage or adoption figures you tracked | Dashboards, a status report | `[grounded]` resume silence |
| G4 | Sales and support launch coordination (R4b) | discovery | Nothing stated | Launches are a named responsibility | Go-live handoffs to support; enablement for sales or support | A handoff checklist | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be real and just small, or the posting may be stale. I could not check. | `[generic]` pattern, not a claim about this firm | Can you point me at this role on your careers site, and who the hiring manager is? | unresolved |
| RR2 | Compensation not stated | unknown | — | (the JD is silent) | Pay may sit below what the seniority implies, or the company may just not publish it | `[inferred]` from the JD's silence | What is the budgeted range for this role? | unresolved |
| RR3 | Titled-years bar versus flexibility | unknown | — | "3+ years product management experience (must-have)" | The hiring manager may weigh adjacent product work, or the bar may be a hard filter | `[generic]` how these bars often work | Is the 3+ years read as titled PM time, or does adjacent product-owning work count? | unresolved |
| RR4 | Clear scope and metrics named | positive_signal | — | "define and track adoption metrics" | Success is defined and the role is bounded | `[grounded]` JD | Which adoption metrics does the team track today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Seek an introduction or a direct note to the hiring manager before the portal, asking RR3 | A person can flex a titled bar. A filter may not. | `[generic]` hiring pattern | pending your approval |
| E1 | Resume: move "Wrote the internal integration playbook the whole team uses" and "Ran quarterly roadmap-input sessions collecting client feedback for product" above the per-integration bullets. Reorder only, no new wording. Keep your real title. Do not write "product manager", "owned the roadmap" or "specs" for work you described as requirements documents. Full tailoring is resume-tailor's job. | See R1b, R7, R8 | `[grounded]` resume | `resume_edits_pending_approval` |
| W1 | A one-page sanitized write-up of one integration, covering what you scoped, what you decided, and what happened after go-live | Raises R3, R1b and R8 toward high | `[inferred]` from the gap queue | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: an earlier-conversation note that you built an internal request-triage tool adopted by support agents. It is unconfirmed, it is evidence for nothing, and it is asked about below. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I searched "Quartzline B2B logistics technology partner API platform" and it was refused. It would have settled RR1 and the contradictions row. |
| 2. Role-family sweep | unavailable | I searched for platform API PM pay and solutions-engineer-to-PM transitions and it was refused. It would have grounded the market calibration and RR2. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

I can offer a one-file `tuesday-dossier.md` of this assessment if you want to carry it into later steps.

**Upgrade menu**
- A link to the live posting or Quartzline's careers page → RR1 closes.
- Search permission → rows 1 and 2 run, and the market calibration and RR2 can then be grounded.
- A sanitized playbook page or integration-architecture doc → R3 and R8 can reach high.
- Triage-tool details and any usage numbers → R1b and R9 move up.
- The hiring manager's name → positioning for that reader.

**Questions**
1. G2 — The request-triage tool from an earlier conversation: did you build it, who decided what it did and what to prioritize, how many support agents used it, and how did you know it worked?
2. G3 — On your integrations, did you ever track usage or adoption numbers, and did you work in sprints with a client or engineering team?
3. Constraints — What are your pay floor and location or remote needs, so I can check the hard gates?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.