Checking whether Harborlight Health and this role can be verified, plus market pay for the title, before I write the assessment.
I couldn't run the research: both web searches were refused, so nothing about Harborlight Health is verified outside the JD you pasted.

## Decision snapshot

**Yes, apply. You're a fit on the core: R1, R2, R3, R4 and R5, every must-have, are `direct`. Status: `conditional_go`, pending the posting and employer verifying (RR1).**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — direct: R8a · adjacent: R8b (Partner with clinicians) · unclear: R7 (Define and maintain the metrics layer), R9 (Mentor two junior analysts)
- `preferred` — adjacent: R6 (Healthcare data experience, HIPAA)

R6 (`medium`) — a credible bridge, its limit named; R7 and R9 — unconfirmed, a question each.

**Opportunity ledger.** Plausible but unverified: the employer could not be established from here (RR1), pay is not stated in the posting as shared (RR2), and success measures and decision rights over metric definitions are unstated (RR3). One entry runs the other way: the mentoring scope is concrete (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting verify — RR1; (2) the pay band is disclosed and clears your floor once you give me one — RR2; (3) the scope of the two-junior mentoring is confirmed in the loop — R9, RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people, Series C | `[grounded]` JD header; not checked against any outside page |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, roadmap partnership with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Stage | Assumed evaluating; you haven't said otherwise | `[inferred]` from your question |
| Scope read | A senior individual-contributor post with light mentoring, not a people-management post: the JD says "mentor", not "manage" | `[inferred]` from the JD's verb choice |
| Market calibration | Not established: the role-family sweep could not run, so there is no pay band to set against the posting or your floor. Experimentation plus a metrics layer plus mentoring is a common remit for this title | `[generic]` pattern, no search behind it |
| Unknowns | Pay; success measures; who decides a metric's definition when PMs and clinicians disagree; who the two juniors report to | `[grounded]` JD silent on each |
| Contradictions | None within the JD itself; not cross-checked against a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics. Specific and plausible, but self-reported with nothing inspectable yet | `[grounded]` your background as typed | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on a Snowflake warehouse is strong evidence of use. "Expert" is a level your sentence doesn't state; hiring loops for senior roles often test it live | `[grounded]` your background; `[generic]` on the live test | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program, 30+ A/B tests a year, including a pricing test in that program that sits behind an 11% retention lift. Test volume is stated. Traffic per test is not, and "at scale" will be probed | `[grounded]` your background; `[generic]` on the probe | A sanitized experiment brief or readout would raise it to `high` |
| R4 | Looker or a similar BI tool, self-serve dashboards | must_have | direct | medium | none | You built the Looker instance from scratch with 40+ governed dashboards. Your sentence says governed, not self-serve, so how much was self-serve use is untested | `[grounded]` your background | A dashboard screenshot or usage summary would raise it to `high` |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly | `[grounded]` your background | A sanitized memo would raise it to `high` |
| R6 | Healthcare data experience (HIPAA), a plus | preferred | adjacent | medium | transferability | You've handled GDPR/CCPA consumer PII and built the consent-state model. Limit: you have not worked in healthcare, so protected health information, business-associate agreements and de-identification are untouched | `[grounded]` your background; `[generic]` on what HIPAA work involves | See G4 |
| R7 | Define and maintain the metrics layer | important | unclear | low | discovery | The 40+ governed dashboards and the metrics memo suggest definition work, but nothing says you owned shared metric definitions. Taking the lower band | `[grounded]` background silent on definition ownership | See G1 |
| R8a | Partner with product managers to turn analysis into roadmap decisions | important | direct | medium | none | You present monthly to the VP Product and write the memo the exec team reads | `[grounded]` your background | none |
| R8b | Partner with clinicians | important | adjacent | low | transferability | No clinician or specialist-team work is stated; the PM and executive partnership is the adjacent evidence. Limit: clinical judgment as an input to analysis is unexercised | `[grounded]` background silent on specialists | See G3 |
| R9 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in your background mentions mentoring or training analysts | `[grounded]` background silent | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R7, important) | discovery | A Looker build and a metrics memo, but not who owned shared metric definitions or how they were governed | A "define and maintain" duty named first in the JD; a clear answer moves R7 to `direct` | Writing and maintaining reusable Looker measures behind many dashboards; a metric dictionary; settling a dispute over how retention or churn is calculated; warehouse-level metric tables | A sanitized metric glossary, a LookML excerpt, or a definitions page | `[grounded]` background silent; `[inferred]` that this moves R7 |
| G2 | Mentoring (R9, important) | discovery | No mention of mentoring | The JD names two juniors; whether you have done this shapes how the role is framed | Reviewing a junior's SQL; onboarding a new analyst; pairing on test design; running a SQL or experiment-design session | An onboarding doc, a training deck, or a review checklist | `[grounded]` background silent |
| G3 | Specialist partnership (R8b, important) | transferability | Partnership with the VP Product and PMs, nothing with a specialist team | The JD names clinicians as partners; a bridge narrows the objection | Any specialist team, such as nutrition, culinary or supply chain, whose judgment changed what you tested or measured | A test brief or readout naming that partner | `[grounded]` background; `[generic]` that this is the likely objection |
| G4 | Healthcare data (R6, preferred) | transferability | GDPR/CCPA handling and a consent-state model; no health data | A plus, not a requirement; the honest bridge with its limit is the strongest case | The consent-state model's design, who could see what, and how consent changes propagated | A short sanitized design note of the model | `[inferred]` bridge from your consent-state model; `[generic]` on HIPAA concepts |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | The posting as pasted contains no pay figure | The figure may sit below what 5+ years plus mentoring buys, or the pasted copy may simply omit it | `[inferred]` from the pasted text's silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Success measures and decision rights unstated for a broad mandate | unknown | — | "define and maintain the metrics layer" | The role may own metric definitions without authority when PMs and clinicians disagree | `[inferred]` from the JD's responsibility list against its silence on authority | What does success look like at twelve months, and who has final say on a metric's definition? | unresolved |
| RR4 | Mentoring scope named concretely | positive_signal | — | "mentor two junior analysts" | The people duty is bounded and is mentoring, not line management | `[grounded]` JD | Who do the two junior analysts report to today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put the experimentation program first on the resume: that you designed and ran it, 30+ tests a year, with the pricing test as a test in it; claim no more than your own sentence says | R3 | `[grounded]` your background | pending your approval |
| E2 | Frame the consent-state model and GDPR/CCPA work as adjacent privacy-data experience, never as healthcare or HIPAA experience | R6, G4 | `[grounded]` your background | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2, RR3 and RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm the role on Harborlight's own careers page, found independently, before investing effort | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused. It would have settled whether Harborlight exists as described and the posting is live; carried as RR1 |
| 2. Role-family sweep | unavailable | The search was refused. It would have given a pay band and market-normal scope for the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

## Upgrade menu

- Granting web search lets me run the employer and posting check and the pay band (up to 5 searches and 2 fetches), which would close RR1 and RR2.
- Your resume as a document, not prose: lets me find where evidence is buried (presentation gaps) and propose approved edits.
- A sanitized experiment readout, memo, or dashboard screenshot → R3, R4 or R5 to `high`.
- A metric glossary or LookML excerpt → R7 to `direct`.
- Your pay floor, location and work-mode limits → hard-gate checks against the role's terms can run.
- The hiring manager's name → the scope read and which story to lead with.

I can also write all of this to `tuesday-dossier.md` if you'd like to keep it or carry it into later steps.

G1 — Have you personally owned how shared metrics were defined, such as how retention or churn is calculated, in Looker or the warehouse? What did you own, who disagreed, and how was it settled?

G2 — Have you mentored, onboarded or reviewed the work of other analysts, formally or informally? What did you do, and for whom?

C1 — Do you have non-negotiables for this move, such as a pay floor, location or remote requirements, or a start date?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.