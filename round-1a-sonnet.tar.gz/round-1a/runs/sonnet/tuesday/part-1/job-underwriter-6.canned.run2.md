Company, salary band and hiring manager searches are back. I'm now fetching Quillfield's own About page to confirm the posting matches the company.
## Decision snapshot

**Should you go for it? Yes, it's worth applying to as a stretch you can defend, with two named gaps: R4 (owning a forecast) is `adjacent` and R5a (billing data) is `absent`. Status: `conditional_go`.** The decision is yours.

**Fit ledger.**

- `hard_gate`: unclear: R7 (Bristol hybrid, two office days a week), R8 (Salary £61,500–£67,000)
- `must_have`: direct: R1, R2, R3a, R6 · adjacent: R4 (Owning a forecast) · unclear: R3b (Spreadsheet modelling), R5b (Working with finance on revenue data)
- `important`: absent: R5a (Working with billing data)

R4: a credible bridge, its limit named; R5b: the route to the finance requirement as the posting words it, waiting on an answer; R5a: a real gap, stated by you.

**Opportunity ledger.** Sound on what is stated. Pay is stated and sits inside the survey band (RR2), and the forecast is run with the CFO rather than alone (RR5). Open items are the role's absence from Quillfield's own site in my search (RR1), the share-option terms (RR3) and the team behind a broad scope (RR4).

- **Hard gates:** none failed; unconfirmed: R7 (Bristol hybrid, two office days a week), R8 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the office terms and pay work for you: R7, R8; (2) you can show forecast-adjacent and finance-facing revenue work, or you accept those gaps will be tested head-on: R4, R5b; (3) the role verifies on Quillfield's own careers page: RR1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. It was founded in 2018 in Bristol, has 96 employees, and closed a £11M Series A in April 2025 | `[grounded]` About page fetched (quillfield.co.uk/about) |
| Role and terms | Revenue Operations Lead, Bristol, hybrid with two office days a week, £61,500–£67,000 plus share options | `[grounded]` the posting you linked, read |
| Mandate | Own the CRM and billing data, build the pipeline and renewal reporting "our sales and finance teams run on", and run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Requirements | 4+ years in revenue ops, sales ops or a similar analytics role at a B2B software company; HubSpot or Salesforce administration; strong SQL and spreadsheet modelling; experience owning a forecast; experience working with finance on billing or revenue data | `[grounded]` posting |
| Hiring manager | Tamsin Achebe's public profile reads Head of Revenue Operations at Quillfield, earlier sales operations manager at Corvane Payments for four years. That matches what the recruiter told you, and the posting names no hiring manager | `[grounded]` profile search result (snippet only); `[inferred]` that the role reports to Tamsin |
| First-year outcomes | Not stated | `[grounded]` posting silent |
| Scope read | One title spans data ownership, reporting and forecasting; team size and reports are not stated | `[inferred]` from the mandate wording against the posting's silence |
| Market calibration | The stated range sits inside a 2026 UK B2B software revenue-operations-lead survey band (median £64,200; interquartile range £57,800–£70,400; n=438). The band is not Bristol-specific, and it is not Quillfield's offer | `[generic]` Ledgerline pay guide, snippet only; `[grounded]` posting figures |
| Unknowns | Share-option terms; team and reports; how the forecast splits between this role and the CFO; first-year outcomes; the interview loop | `[grounded]` posting silent on each |
| Contradictions | None between the posting and the About page's description of the company. The role did not turn up on Quillfield's own careers page in my search (RR1) | `[grounded]` About page against posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years in revenue ops, sales ops or similar analytics role at a B2B software company | must_have | direct | medium | none | You describe 5 years in sales operations, the last 2 running revenue operations for the UK team. That clears the years. Whether a payments company's product counts as "software" is not stated, so the sector detail is read downward | `[grounded]` your intake description (CV-equivalent) | none now; make the product explicit on the CV |
| R2 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, as you stated; nothing inspected yet | `[grounded]` your intake description | a credential listing would raise to high |
| R3a | Strong SQL | must_have | direct | medium | none | You use SQL weekly. Level ("strong") is not stated, so expect a technical probe | `[grounded]` your intake description | none |
| R3b | Spreadsheet modelling | must_have | unclear | low | discovery | You use Excel daily; modelling depth is not stated. Taking the lower band | `[grounded]` your intake description; `[inferred]` that daily use does not establish modelling | describe one model you built; not asked this turn |
| R4 | Experience owning a forecast | must_have | adjacent | medium | transferability | You have not owned the company forecast; finance did. The nearest work stated is the monthly pipeline review you run with the sales director. Limit: you did not own the number, and whether your pipeline work fed finance's forecast is not stated | `[grounded]` your intake statement; `[inferred]` adjacency from the pipeline review | gap queue G1 |
| R5a | Working with billing data (the role "owns CRM and billing data") | important | absent | none | capability | You told me you have never worked on billing data. There is no evidence to find, and the tier reflects that the posting's requirement line reads "billing or revenue data" | `[grounded]` your intake statement | closure path in G3; carried as a material risk |
| R5b | Working with finance on billing or revenue data | must_have | unclear | low | discovery | The posting says "billing or revenue", so revenue data alone may meet it as written. You rebuilt renewal dashboards, but finance's involvement in them is not stated | `[grounded]` your statements and the posting wording; `[inferred]` that the "or" admits the revenue arm | gap queue G2 |
| R6 | Build pipeline and renewal reporting that sales and finance teams run on | must_have | direct | medium | none | You rebuilt your team's pipeline and renewal dashboards. Whether finance used them is not stated | `[grounded]` your intake description | sanitized dashboard screenshots would raise to high |
| R7 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | The posting states the term. You have not told me where you are based or whether two Bristol days work, so the gate is not established | `[grounded]` posting; your constraint not yet given | ask: closing question |
| R8 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | The posting states the range. Your floor and current pay were not given | `[grounded]` posting; your constraint not yet given | ask: closing question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R4, must_have) | transferability | You run the monthly pipeline review with your sales director; finance owned the company forecast | A must-have, and the posting has the role run the quarterly forecast with the CFO. A stronger bridge narrows the likeliest objection | Producing the pipeline or renewal numbers finance's forecast started from; tracking forecast versus actual; building a coverage or commit view the sales director signed off | A sanitized forecast-versus-actual view, or a pipeline review deck | `[grounded]` your statements; `[inferred]` that this is the likeliest objection |
| G2 | Finance-facing revenue data (R5b, must_have) | discovery | Renewal dashboards exist; finance's role in them is not stated | If the revenue arm counts, the must-have moves from `unclear` toward `adjacent` or better | Agreeing renewal or ARR definitions with finance; reconciling renewal figures to finance's; a dashboard finance used for review | A definitions doc, a reconciliation sheet, or a dashboard screenshot | `[grounded]` posting wording and your statements; `[inferred]` that this could move the row |
| G3 | Billing data (R5a, important) | capability | No billing-data experience, by your own statement | The role's mandate includes owning billing data | Not applicable as claimed experience. A closure path: learn how invoices, CRM records and finance data connect before the interviews, and say plainly it is new | none now | `[grounded]` your statement; `[generic]` that learning the data flow is a normal closure path |
| G4 | Office terms and pay (R7, R8, hard_gate) | hard_gate | Terms stated in the posting; your constraints not given | A failed gate caps the decision however strong the fit | none; this is a yes or no on the terms | none | `[grounded]` posting; your constraints not given |
| G5 | Spreadsheet modelling (R3b, must_have) | discovery | Daily Excel use; depth not stated | Resolves a `low` row cheaply | A renewal, pipeline-coverage or headcount model you built | A sanitized workbook | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Role not located on Quillfield's own careers page | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The role may be listed through the job board only, or the careers page was not indexed. One empty search is not evidence of absence | `[generic]` pattern for small companies; no claim about this one | Is this role listed on Quillfield's own careers page, and is Tamsin Achebe the hiring manager? | unresolved |
| RR2 | Pay stated and inside the survey band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The range shows no seniority-pay mismatch on the figures alone. The band is UK-wide, not Bristol-specific | `[grounded]` posting figures; `[generic]` survey band | Where in the range would you expect to hire for this role? | noted |
| RR3 | Share-option terms unstated | unknown | — | "plus share options" | The options may carry meaningful value or very little; the posting gives no terms | `[inferred]` from the posting's silence | What are the option terms: size of grant, vesting and strike price? | unresolved |
| RR4 | Broad scope under one title; team unstated | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting ... and run the quarterly revenue forecast with the CFO" | The role may be carrying several specialisms alone. I rate it low because a Head of Revenue Operations appears to sit above it, which suggests some team exists | `[inferred]` from the mandate wording against its silence on team and reports | Who is on the team around this role, and who owns billing data day to day today? | unresolved |
| RR5 | Forecast run "with the CFO" | positive_signal | — | "run the quarterly revenue forecast with the CFO" | The forecast may be co-run rather than solely owned, which could soften the R4 gap. The posting still lists owning a forecast as a requirement | `[inferred]` from the posting wording | How is the forecast split between this role and the finance team? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the pipeline and renewal dashboard rebuild and the monthly pipeline review you run with your sales director | see R6, R4; the strongest stated evidence | `[grounded]` your own statements | `resume_edits_pending_approval` |
| E2 | Say plainly in the application that the company forecast and billing data sat with finance in your current role, then say what you did around them | see R4, R5a; an honest limit survives follow-up questions | `[grounded]` your own statements | pending your approval |
| A1 | Confirm the Bristol two-day terms and the pay range against your floor before investing in the loop | see R7, R8 | `[grounded]` posting terms | pending your approval |
| A2 | Ask the recruiter for the listing on Quillfield's own careers page and for the interview loop | see RR1 | `[grounded]` register | pending your approval |
| Q1 | Put the register's verification questions (RR3, RR4, RR5) to the interviewers verbatim | the register doubles as interview preparation | `[grounded]` register | pending your approval |
| W1 | Before any call, learn how billing, CRM and finance data connect in invoicing software, so R5a is a stated gap with a plan | see G3 | `[generic]` closure path | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company", which returned "About Quillfield" (quillfield.co.uk/about). Searched "Quillfield careers Revenue Operations Lead Bristol", which returned no results. Fetched "About Quillfield" (quillfield.co.uk/about). Role reality's organization and contradictions rows: the employer exists as described; the role was not located on its own site (RR1) |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide), read as a snippet only. Market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), read as a snippet only. Role reality's hiring-manager row |

## Upgrade menu

- Your CV, or the text of it, would let me check R1, R2 and R6 against the document and not your summary. It would also show how it reads against this posting.
- Sanitized dashboard screenshots or a credential listing → R6 and R2 can reach `high`.
- Your location and pay floor → R7 and R8 settle, and the hard-gates line firms up.
- Answers to G1 and G2 → R4 and R5b move, and the decision may firm up to `go` or soften.
- A description of a spreadsheet model you built → R3b closes.
- Quillfield's own careers listing, or the recruiter's email domain → RR1 closes.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

I can also write this up as `tuesday-dossier.md` if you want to keep it or carry it into later steps.

**Questions**

G1 — In your monthly pipeline review, did your numbers feed finance's forecast, and what did you own versus finance?

G2 — Have you worked with finance on renewal or revenue figures (agreeing definitions, reconciling numbers, a dashboard they used)? What was yours?

R7, R8 — Do two office days a week in Bristol and a £61,500–£67,000 range both work for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.