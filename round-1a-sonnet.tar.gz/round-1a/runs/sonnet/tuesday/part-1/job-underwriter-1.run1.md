**Yes, apply. You're a fit: R1, R2, R3, R4 and R5, the `must_have` rows, are all `direct`. Healthcare experience (R9a) is the main gap, and it is only a preferred row. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — direct: R7a · adjacent: R6 (Metrics layer) · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9b (HIPAA, regulated personal data) · absent: R9a (Healthcare data experience)

R6 — implied by your governed Looker work but not stated; R7b and R8 — nothing said either way yet; R9a — a preferred gap that no wording can close.

**Opportunity ledger.** The employer is not established (RR1) and the pay is unstated (RR2). The duties may bundle analytics engineering into the analyst role (RR3), and how experiments are reviewed in a clinical setting is unknown (RR5). One entry runs the other way: the mandate is tied to roadmap decisions (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) the pay meets your floor, once you tell me what that is (RR2); (3) the HIPAA gap is framed honestly as adjacent privacy work, never as healthcare data experience (R9a, R9b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header; existence not checked (see Evidence status) |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, roadmap partnership with PMs and clinicians | `[grounded]` JD |
| Team | Mentor two junior analysts, so a senior individual contributor with light leadership | `[grounded]` JD |
| First 90 days / first year | Not stated. Likely to inherit the metrics definitions and the experiment cadence first | `[inferred]` from the JD's verb order ("define and maintain", "design and analyze") |
| Scope read | The five duties together cover what often splits into an analytics-engineering role and an analyst role | `[generic]` role-family pattern, not a claim about this employer (RR3) |
| Market calibration | Not done. The role-family search was refused, and the posting as given states no pay | `[grounded]` no search ran; `[grounded]` JD silent on pay |
| Unknowns | Pay, location or remote policy, who owns the models upstream of the metrics layer, how clinicians partner with analysts, which experimentation platform is used | — |
| Contradictions | None between the JD and your background. JD versus careers page is unchecked | `[grounded]` the two documents provided |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics at a ~2M-subscriber company, confirmed and specific. Intake prose is not an inspectable artifact, so `medium`: expect a probe | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" is a self-grade, so a query sample or a data-model diagram would be the inspectable proof | `[grounded]` your background | offer: a sanitized query or model diagram would raise to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran the program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift. "At scale" is met at ~2M subscribers; whether this employer's volume is comparable is unknown | `[grounded]` your background; `[generic]` that experimentation "at scale" is usually read as program volume plus rigor | offer: an experiment readout or pricing-test write-up would raise to high |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | Built the Looker instance from scratch, 40+ governed dashboards. It is the named tool | `[grounded]` your background | offer: a dashboard screenshot or governance doc |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Writes the monthly metrics memo the exec team reads; presents monthly to the VP Product | `[grounded]` your background | offer: a redacted memo |
| R6 | Define and maintain the metrics layer | important | adjacent | low | discovery | "Governed dashboards" and a metrics memo sit close to metric definitions, but you did not say you owned the definitions or a modeled layer. Limit: I won't assume that | `[grounded]` what you stated; `[inferred]` closeness from governed dashboards | G1 |
| R7a | Partner with product managers | important | direct | medium | none | Monthly presentations to the VP Product. Day-to-day PM partnership is not described, so `medium` | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing stated either way, and no claim exists yet | `[grounded]` silence in your background | G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background says nothing about mentoring or managing, so it is unrecorded rather than absent | `[grounded]` silence in your background | G2 |
| R9a | Healthcare data experience | preferred | absent | none | capability | None stated, and you said you have never worked in healthcare. A plus, so a minor risk | `[grounded]` your statement | closure path: read up on PHI handling before interviews |
| R9b | HIPAA and regulated personal data | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model in the warehouse are a credible bridge. Limit: neither exercised PHI rules, minimum-necessary access, de-identification or covered-entity agreements | `[grounded]` your background; `[generic]` that these are the usual HIPAA differences | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | discovery | Governed dashboards and a metrics memo, but no statement of who defined the metrics or where the definitions lived | Owning the definitions is the first named duty, and resolving it would move R6 to `direct` | Writing the canonical definition of an activation or retention metric; LookML measures or a metrics doc others had to use; resolving "two dashboards, two numbers" disputes | A metrics dictionary, a LookML snippet, a definition-change log | `[grounded]` background silent on definitions; `[inferred]` that the answer likely moves R6 |
| G2 | Mentoring (R8, important) | discovery | Nothing on mentoring or reviewing others' work | The role names two direct mentees, so a blank here reads as no experience | Reviewing a junior analyst's SQL or experiment designs; onboarding a new hire; running an analytics office hour, formal or informal | A review checklist, an onboarding doc | `[grounded]` background silent; `[generic]` that senior analyst roles probe this |
| G3 | Clinician partnership (R7b, important) | discovery | No domain-expert stakeholders mentioned | Clinicians are a named partner, and the role's evidence standards may differ from a consumer product's | Working with culinary, nutrition or food-safety staff on a metric or test; translating a technical result for domain experts who push back on method | A joint readout, a test brief co-written with a domain team | `[grounded]` background silent; `[generic]` that clinical partners tend to challenge causal claims |
| G4 | Healthcare data (R9a, R9b, preferred) | transferability | Consent-state model and GDPR/CCPA handling, with no PHI | A plus, not a requirement, but the interview may probe the line between consumer privacy and PHI | Access controls or retention rules you designed; a privacy review you passed; any health-adjacent data such as dietary preferences or allergy fields | The consent-state model doc, a privacy-review sign-off | `[grounded]` your background; `[inferred]` bridge from consent modeling to HIPAA-adjacent work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The role may be real and the entity simply unchecked, since no research ran. Nothing here suggests otherwise | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay unstated | unknown | — | The JD as provided states no pay | The figure may sit anywhere in the market band, or the posting may simply omit it | `[grounded]` JD silent; no band was researched | What is the budgeted salary range for this post? | unresolved |
| RR3 | Possibly bundled specialisms | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker" | Metrics-layer upkeep may sit on one analyst with no analytics-engineering support | `[generic]` pattern for scale-up analyst roles, not a claim about this employer | Who owns the data models beneath the metrics layer, and is there analytics-engineering support? | unresolved |
| RR4 | Roadmap-linked mandate | positive_signal | — | "turn analysis into roadmap decisions" | The role is positioned to influence decisions and is not a reporting seat | `[grounded]` JD states it | Which roadmap decisions did analysis change last quarter? | noted |
| RR5 | Experiment governance in a care setting | unknown | — | "design and analyze A/B tests" for "our care-navigation app" | Tests touching clinical guidance may need clinical sign-off, which would shape how fast you can run them | `[generic]` pattern for healthcare products, not a claim about this employer | How are experiments reviewed when they touch clinical content, and who signs off? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the summary with: "Designed and ran the experimentation program (30+ A/B tests a year) at a ~2M-subscriber meal-kit company, including the pricing test behind an 11% retention lift" | see R3. Every clause traces to your statement | `[grounded]` your background | `resume_edits_pending_approval` |
| E2 | Describe the consent-state model as "Built the consent-state model for the warehouse; handled GDPR/CCPA consumer PII". Do not describe it as healthcare or HIPAA work | see R9b, and the limit named there | `[grounded]` your background | `resume_edits_pending_approval` |
| E3 | Add a metrics-definition line only if G1 confirms you owned definitions | see R6 | `[grounded]` R6 row | pending your approval |
| Q1 | Ask RR1, RR2, RR3 and RR5's questions verbatim with the recruiter or hiring manager | The register doubles as interview preparation | `[grounded]` register | pending your approval |

If you apply, resume-tailor can turn E1 to E3 into a full edit ledger.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app company careers"; the host refused it. It would have confirmed the employer and live posting, feeding role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "Senior Product Analyst digital health salary range scope experimentation Looker"; the host refused it. It would have fed the market calibration row and the pay check on RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

I can save this as `tuesday-dossier.md` so later steps can build on it, if you'd like.

## Upgrade menu

- Search permission, so I can run the company and posting check → RR1 and role reality's organization row close, and the decision may move from `conditional_go` to `go`.
- A pay floor, location and any other must-haves → the hard-gates line gets real checks, and RR2 can be tested against your floor.
- A redacted metrics memo, a LookML snippet or a metrics dictionary → R5 and R6 can rise toward `high`.
- A pricing-test write-up or experiment readout → R3 to `high`.
- A sanitized SQL sample or data-model diagram → R2 to `high`.
- The hiring manager's name → role reality's scope read, and which story the plan leads with.

Questions (all optional; answer in text, paste a voice transcript, attach a document, drop a link, or say skip):

- G1 — Did you personally define the canonical metrics (retention, activation or similar) that the 40+ dashboards used? Where did the definitions live, and who had to follow them?
- G2 — Have you reviewed, coached or onboarded other analysts, formally or informally? What did you own, and how many people?
- G3 — Have you worked with domain experts outside product and data (nutrition, culinary, food safety) on a metric or a test? What happened when they pushed back on the method?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.