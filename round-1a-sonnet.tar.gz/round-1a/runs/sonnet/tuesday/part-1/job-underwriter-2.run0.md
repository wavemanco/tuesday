I'm reading the underwriting playbook's remaining reference files so the assessment follows its required format. After that I'll write it.
**No, you're not wasting your time. But this is a stretch application, not a clean fit: R1a (3+ years of titled PM experience, `must_have`) is `absent`, and it's where a literal screen could stop you. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1b (PM work without the title), R2 (shipped API or platform products) · absent: R1a (3+ years titled PM)
- `important` — direct: R4, R6 · adjacent: R7 (roadmap, specs, delivery with two squads) · unclear: R5 (agile delivery), R8 (adoption metrics), R9 (launches with sales and support)

R1a — where a literal years screen could stop you; R1b, R2, R7 — adjacent, limits named; R5, R8, R9 — unclear, waiting on your answers.

**Opportunity ledger.** The employer couldn't be checked from here (RR1), and the posting doesn't say whether equivalent work can stand in for the titled years (RR2), what it pays (RR3), or who decides priorities (RR4). One entry runs the other way: the mandate is a partner-facing API platform with named duties (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting verify (RR1); (2) the years requirement proves flexible, or a human reads your application past it (RR2, R1a); (3) your answers to G1, G2 and G3 show product-ownership evidence beyond the CV.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not independently verified |
| Mandate | Own the roadmap for a partner-facing API platform, with discovery, specs, adoption metrics and launches | `[grounded]` JD |
| Team | Two engineering squads, plus sales and support coordination | `[grounded]` JD |
| Scope read | A single-product remit with a real delivery team. The partner-facing API focus matches your integration background more closely than most PM postings would | `[inferred]` from the JD's duties against your CV |
| Market calibration | Not established: the sweep could not run, and the posting states no salary | `[generic]` nothing asserted; see Evidence status |
| Unknowns | Salary; decision rights over priorities; whether equivalent experience can substitute for the titled years; reporting line | — |
| Contradictions | None found between the JD and your resume | `[grounded]` both documents |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years of product management experience, titled | must_have | absent | none | transferability | You have never held a PM title. A years-of-experience requirement is a screening risk, not a legal gate, so it is graded like any other row. The adjacent work sits in R1b. | `[grounded]` your statement and CV | RR2's question; see A2 |
| R1b | Product-management work done without the title | must_have | adjacent | medium | transferability | You ran quarterly roadmap-input sessions, wrote requirements documents and coordinated with product managers on custom builds. That is input to product decisions, not ownership of them: the limit is who decided priorities. | `[grounded]` CV, user-stated, no inspectable artifact yet | G3 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ end-to-end integrations of your vendor's REST APIs and wrote the playbook the team uses. Limit: you delivered integrations of a product, you did not own one's lifecycle. A recalled triage tool may bridge this, but it is unconfirmed. | `[grounded]` CV; `[inferred]` bridge | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading, plus integration architecture across 30+ clients, is direct evidence. Limited inspectable proof, so expect a technical probe. | `[grounded]` CV | none |
| R4 | Stakeholder management across engineering and customers | important | direct | medium | none | You coordinated your engineers, client engineers and product managers, and ran client scoping workshops. Sales is covered separately in R9. | `[grounded]` CV | none |
| R5 | Agile delivery | important | unclear | low | discovery | The CV shows UAT and go-live delivery but doesn't name an agile practice. | `[grounded]` CV silence on method | G4 |
| R6 | Discovery with integration partners | important | direct | medium | none | Scoping workshops with clients and feedback sessions for product are direct discovery with the API's users. | `[grounded]` CV | none |
| R7 | Roadmap, specs, and delivery with two squads | important | adjacent | medium | transferability | You wrote requirements documents and coordinated custom builds. Limit: no stated authority over what got built or in what order. | `[grounded]` CV | G3 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | The CV is silent. An unconfirmed memory of a request-triage tool that support agents adopted is a lead only. | `[inferred]` from the memory lead; nothing confirmed | G1 |
| R9 | Coordinate launches with sales and support | important | unclear | none | discovery | Nothing in the CV touches sales or support involvement in launches. | `[grounded]` CV silence | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product built or shipped, adoption measured (R2, R8) | discovery | A possible internal triage tool that support agents adopted, unconfirmed and undescribed | It could turn R2 and R8 from thin to credible, and it is the most likely single piece of proof of ownership | An internal tool you specified or built; counting who used it; a process or playbook others adopted and you tracked | A usage screenshot, a one-page spec, the rollout note | `[inferred]` lead from earlier-conversation memory, unconfirmed |
| G2 | Launch coordination with sales and support (R9) | discovery | No sales or support involvement is visible | The JD names it as a duty and the CV is silent | Briefing sales or support before a go-live; writing a handover or enablement doc; handling escalations after launch | A handover document or launch checklist | `[grounded]` CV silence |
| G3 | Priority-setting authority (R1b, R7) | transferability | You gathered feedback and wrote requirements, but who chose what got built is not stated | This is the core PM claim, and it decides how far the bridge goes | A custom build you scoped, cut or sequenced; a trade-off you recommended that was adopted | A requirements document showing a decision, with client details removed | `[inferred]` from the CV's wording |
| G4 | Agile delivery (R5) | discovery | UAT and go-live are described, no sprint or backlog practice | An important row, cheap to close | Sprint reviews with the client's team; backlog grooming on a custom build | A sprint board screenshot | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "B2B logistics-tech, ~150 people, Series B" | The company may be too new or small to have a visible footprint, the posting may be stale, or it may not match its description | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and who I would be interviewing with? | unresolved |
| RR2 | Titled PM years may be screened literally | risk_signal | low | "3+ years product management experience (must-have)" | A recruiter or an automated screen may filter on the title, while the hiring manager may value equivalent work | `[generic]` hiring pattern, not a claim about this employer | Can equivalent product work, such as owning API integrations and customer roadmap input, count toward the 3+ years? | unresolved |
| RR3 | Compensation not stated | unknown | — | no pay figure in the posting | The band could sit below or above what a career changer will accept, and a first PM role may come at a different level than your current one | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR4 | Authority over priorities unclear | unknown | — | "Own the roadmap" and "coordinate launches with sales and support" | Sales requests could drive the roadmap, so the role could be accountable without final say | `[inferred]` from the JD's scope language | Who makes the final call on roadmap trade-offs, and who does this role report to? | unresolved |
| RR5 | Mandate matches partner-API work | positive_signal | — | "partner-facing API platform ... discovery with integration partners" | The remit is concrete and draws on the work you already do | `[grounded]` JD against your CV | What does success look like at 12 months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move the roadmap-input sessions and cross-functional coordination to the top of the resume, stated as what they were: client feedback collected for product, no ownership claimed | see R1b, R6, R7 | `[grounded]` CV | pending your approval |
| E2 | Lead with API integration depth: 30+ integrations, the playbook, OpenAPI and Postman | see R2, R3 | `[grounded]` CV | pending your approval |
| W1 | A one-page partner-onboarding spec or adoption-metric proposal for a platform API, labeled as a work sample and not as shipped work | see R2, R8 | `[grounded]` gap rows | pending your approval |
| A1 | Verify the employer and the live posting before investing effort | see RR1 | `[grounded]` register | pending your approval |
| A2 | Try to reach the hiring manager or a current Quartzline employee before applying cold, and ask RR2's question | see R1a, RR2 | `[generic]` how screens usually work | pending your approval |

The edits above are proposals only, and nothing is finalized without your explicit approval. If you decide to apply, resume-tailor can turn E1 and E2 into the resume edits.

## Evidence status

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | The search for Quartzline was refused, so the employer and posting are unverified (RR1). |
| 2 | Role-family sweep | unavailable | The search was refused. The market calibration and the pay band stay unestablished (RR3). |
| 3 | Hiring manager's public footprint | n/a | No name was given. |

## Upgrade menu

- **A link to the live posting or the company's careers page:** it settles RR1 and could move the status toward `go`.
- **The triage tool's details:** a usage screenshot, spec or rollout note would raise R2 and R8 from `low` or `medium` toward `high`.
- **A requirements document with a decision in it, client details removed:** it would show the priority-setting ownership R7 and R1b turn on.
- **A sprint board or backlog screenshot:** it would settle R5.
- **A salary range or a pay floor:** it would let me check RR3.
- **Your own constraints** (location, pay floor, work hours): hard-gate checks stay unknown without them.
- **Permission to run web searches:** it would let me verify the company, and calibrate the role's pay and title against market norms.

I can also package this as a `tuesday-dossier.md` for later steps. Say the word and I'll emit it.

**Questions**

G1 — Your earlier request-triage tool: what did you specify or build, did support agents actually use it, and how did you know? (This also covers R8.)
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Before a go-live, did you ever brief or hand over to a client's support team or your own sales team? What did you prepare?

G3 — On a custom build, who decided what was in scope, and was there a time you cut or reordered something? What happened?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.