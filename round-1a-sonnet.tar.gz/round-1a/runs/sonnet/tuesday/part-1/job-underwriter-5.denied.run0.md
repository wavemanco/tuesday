Two web lookups were declined (the careers page and a company search), so this runs only on what you pasted.

## Decision snapshot

**Yes, worth applying to, on conditions: your pay floor and location (R9, R10) are unconfirmed, and BigQuery (R4) is a learning curve and not a blocker. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R9 (Compensation $148,000–$166,000 plus equity), R10 (Remote (US) or Denver office)
- `must_have` — direct: R1, R2, R3, R5, R6
- `important` — adjacent: R4 (BigQuery); unclear: R7 (ingestion from app and CRM), R8 (data contracts)

R4 (`medium`) — the warehouse differs, the dbt practice carries over; R7, R8 — your background doesn't yet speak to them.

**Opportunity ledger.** A clearly paid role with a wider remit than the report's typical one (RR1, RR2). Its reporting line and 12-month success measures are unstated (RR3), and the company facts are unchecked (RR4).

- **Hard gates:** none failed; unconfirmed: R9 (Compensation $148,000–$166,000 plus equity), R10 (Remote (US) or Denver office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R9 and R10 hold against your pay floor and location; (2) the BigQuery switch is acceptable to you and framed honestly as new (R4); (3) the answers to RR2 and RR3 show a scope you would actually want.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; Denver; founded 2016; 264 employees; Series C ($52M, February 2026) | `[grounded]` pasted About page; not checked against the live site |
| Mandate | Build and run reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` pasted JD |
| Pay and equity | $148,000–$166,000 plus equity; equity terms not stated | `[grounded]` pasted JD |
| Location | Remote (US) or Denver office | `[grounded]` pasted JD |
| Manager, team size, first-year outcomes | Not stated; no hiring manager named | `[grounded]` pasted JD is silent |
| Scope read | Three layers in one title: ingestion, modelling and contracts | `[inferred]` from the JD's three named responsibilities set against the report's one-domain norm |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, IQR $139,000–$163,500; "Senior" typically 5–8 years; typically one domain's pipelines, no reports. The posted range straddles the median and its top sits above the IQR's upper bound. Your 6 years is inside 5–8 | `[grounded]` Datawright 2026 report as supplied by your recruiter (n=2,310); `[inferred]` that the posted "salary" is base |
| Unknowns | Equity size and terms; team size; reporting line; who owns ingestion today; success measures | `[grounded]` JD silence |
| Contradictions | None between the pasted JD and About text; neither checked against live pages | `[grounded]` pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company clears the bar; self-reported, no inspectable artifact yet | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | You use both daily; "daily" evidences use, and "strong" is the JD's word with nothing inspected yet | `[grounded]` your background | offer: a sanitized model or script sample would raise to high |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | You built your dbt project on Snowflake, about 180 models; the requirement names "a cloud warehouse", and BigQuery appears only in the responsibilities (R4) | `[grounded]` your background; JD wording | offer: a sanitized lineage graph or the dbt docs model count would raise to high |
| R4 | Work in BigQuery (the JD's "dbt-modelled warehouse in BigQuery") | important | adjacent | medium | transferability | Same dbt-on-a-cloud-warehouse practice. Limit: you have never used BigQuery, so nothing about its specifics is exercised. Warehouses differ in cost and tuning behaviour, so expect a probe on it | `[grounded]` your statement; `[generic]` that warehouses differ in cost and tuning | see G3 |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is your orchestrator; the JD names it | `[grounded]` your background; JD | none |
| R6 | Data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite | `[grounded]` your background | offer: a sanitized suite summary would raise to high |
| R7 | Ingestion from the app and CRM | important | unclear | low | discovery | Airflow work is indirect context only; your background names no sources or ingestion work | `[grounded]` background silent on sources | see G1 |
| R8 | Data contracts analysts depend on | important | unclear | low | discovery | Great Expectations tests are adjacent at most; an agreement between data producers and analysts is not established | `[grounded]` background silent on contracts | see G2 |
| R9 | Pay $148,000–$166,000 plus equity (candidate's floor not given) | hard_gate | unclear | none | hard_gate | No stated floor, so the gate cannot be checked. The range is at or above the report's median (RR1) | `[grounded]` JD; no candidate constraint supplied | see G4 |
| R10 | Remote (US) or Denver office (candidate's location not given) | hard_gate | unclear | none | hard_gate | Your location and work authorization were not stated, so the gate cannot be checked | `[grounded]` JD; no candidate constraint supplied | see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R7, important) | discovery | Airflow orchestration, but no named sources or loading work | An `important` row at `unclear`; the JD lists ingestion first among its responsibilities | Loading from a product database or event stream into the warehouse; syncing a CRM into the warehouse; building or fixing a loader that others depended on | A sanitized DAG screenshot, an ingestion README, a source list | `[grounded]` background silent; `[inferred]` that the JD's order signals priority |
| G2 | Data contracts (R8, important) | discovery | Great Expectations tests, with no agreed producer-to-consumer terms | The JD names analysts depending on these contracts | Agreeing schemas or freshness with app engineers; dbt model contracts or versioned models; a process for breaking changes; tests that failed and got routed to an owner | A schema agreement, a dbt contract config, a test-failure runbook | `[grounded]` background silent on contracts |
| G3 | BigQuery (R4, important) | transferability | Strong dbt and cloud-warehouse practice, no BigQuery use | The likeliest objection to your application | Bridge: your dbt practice on Snowflake. Limit: BigQuery itself untouched. Strengthener: a small dbt project run against a BigQuery sandbox | A repo link or short write-up | `[grounded]` your statement; `[inferred]` that a small sandbox project narrows the limit |
| G4 | Pay floor and location (R9, R10, hard_gate) | hard_gate | Neither your floor nor your location is known | Either could flip the status either way | — | — | `[grounded]` no constraints supplied |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, and at or above the report's median | positive_signal | — | "Salary $148,000–$166,000 plus equity" | A disclosed, market-aligned range suggests the budget is set | `[grounded]` JD and the Datawright report, comparing base figures; `[inferred]` that "salary" means base | Where in the range would an offer for my background land, and how is the equity sized and vested? | noted |
| RR2 | Scope wider than the report's typical one | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role may be the sole data engineer across three layers, where the report's typical senior owns one domain. Low because the posting may just list a team's combined remit | `[inferred]` from the JD against the report's typical scope | How many data engineers are there today, and which of ingestion, modelling and contracts would I own at the start? | unresolved |
| RR3 | No manager, team or success measures stated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The posting gives no reporting line or definition of success | `[grounded]` JD silent; no hiring manager named | Who would I report to, and what would a good first year look like? | unresolved |
| RR4 | Company facts unchecked | unknown | — | "Series C ($52M, February 2026). 264 employees." | These are the company's own figures and I could not check them or the live posting | `[grounded]` pasted About page; the lookups were declined | Can you confirm the data team is funded in the current plan after the February round? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle your pay floor and location against R9, R10 before investing in the loop | see R9, R10 | `[grounded]` R9, R10 rows | pending your approval |
| A2 | Lead with your dbt project on Snowflake (about 180 models) and the Great Expectations suite you set up, worded as you gave them to me | see R3, R6 | `[grounded]` your background | pending your approval |
| A3 | Say plainly that BigQuery is new to you, with dbt on a cloud warehouse as the bridge; make no BigQuery claim | see R4 | `[grounded]` your statement | pending your approval |
| A4 | Ask the RR2, RR3 and RR4 questions verbatim at the recruiter screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Optional: a small dbt project on a BigQuery sandbox to narrow R4's limit | see G3 | `[inferred]` from the R4 gap | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A fetch of the careers page and a search on the company and its funding were both refused. They would have confirmed the posting is live and the company facts (role reality, RR4) |
| 2. Role-family sweep | skipped | The pasted Datawright report already fixes the market calibration and the RR1 and RR2 comparisons |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there is no query to form |

## Upgrade menu

- Permission for the careers-page and company lookups, or the live posting text pasted → RR4 closes and the posting-live check completes.
- The hiring manager's name, from the recruiter → role reality's scope read, and which story the plan leads with for that reader.
- A sanitized dbt lineage graph or Great Expectations suite summary → R3 and R6 to `high`.
- An answer to G1 or G2 → R7 or R8 can move from `unclear`.

I can write this up as a `tuesday-dossier.md` if you want one to keep.

G4 — What is your pay floor, and where are you based (US state, and are you authorized to work in the US without sponsorship)?

G1 — Have you built ingestion that pulled from a product database, event stream or CRM into your warehouse? What did you own, and which sources?

G2 — Have you agreed schemas, freshness or breaking-change rules with the teams producing your data? What did you own, and how were they enforced?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.