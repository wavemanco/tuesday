I'm underwriting this role from the posting and your background alone. Web search was denied, so I couldn't check the employer or the market.

## Decision snapshot

**Yes, apply. You fit the substance of the role. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R7 · unclear: R5 (Define and maintain the metrics layer)
- `important`: direct: R6a · unclear: R6b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience, HIPAA)

R5: governed Looker work suggests it, but metric definitions aren't stated; R6b and R8: your background is silent; R9 (`medium`): the consent-state model is the bridge, its limit named.

**Opportunity ledger.** Plausible on its face but unverified. The employer is not established from here (RR1), compensation is not stated (RR2), the JD bundles several specializations into one post (RR3), and success measures are not stated (RR4). RR5 runs the other way: it names its tools and its team.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify on Harborlight's own careers page (RR1); (2) you confirm you owned metric definitions, not just dashboards (R5, G1); (3) you learn the pay range and location terms before investing in the loop (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C | `[grounded]` JD header, as stated and not verified |
| Mandate | Own product analytics for the care-navigation app | `[grounded]` JD |
| Named duties | Metrics layer, A/B test design and analysis, self-serve Looker dashboards, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Pay, location, reporting line | Not stated | `[grounded]` JD silence |
| Scope read | A senior individual-contributor post with a light mentoring duty. The JD says "mentor", not manage | `[inferred]` from the JD's verb |
| Market calibration | Not available this run; see Evidence status | — |
| Unknowns | Pay; location; reporting line; who owns the data models behind the metrics layer; how much access to clinicians the role has | `[grounded]` JD silence |
| Contradictions | None inside the JD. It was not checked against a careers page | `[grounded]` JD read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a consumer-subscription company. It is self-reported and not inspected, which caps it at `medium` on a first pass | `[grounded]` your background against the JD quote | none |
| R2 | Expert SQL | must_have | direct | medium | none | You state daily SQL on Snowflake. "Expert" is a level only a sample or a probe can show | `[grounded]` your background; `[generic]` that screens for this title commonly include a live SQL exercise | Offer a sanitized query or model as an artifact |
| R3 | Experiment design at scale | must_have | direct | medium | none | You state that you designed and ran the program, at 30+ A/B tests a year, including the pricing test behind an 11% retention lift. The JD doesn't define "scale", and this company's traffic is unknown | `[grounded]` your background | Offer a sanitized test readout |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You state that you built the Looker instance from scratch, with 40+ governed dashboards. You didn't say "self-serve", so I don't claim it | `[grounded]` your background | none |
| R5 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" suggests metric definitions, but nothing states that you wrote or owned them | `[grounded]` your background, which is silent on definitions | See G1 |
| R6a | Partner with product managers to turn analysis into roadmap decisions | important | direct | medium | none | You present to the VP Product monthly, and the pricing test led to an 11% retention lift. Both are stated, and neither is inspected | `[grounded]` your background | none |
| R6b | Partner with clinicians | important | unclear | none | discovery | Nothing in your background touches clinical stakeholders, and nothing rules it out | `[grounded]` your background, which is silent | See G3 |
| R7 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads. It is confirmed and specific, with no artifact yet | `[grounded]` your background | Offer a sanitized memo to raise this to `high` |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in your background mentions mentoring, onboarding or reviewing others' work | `[grounded]` your background, which is silent | See G2 |
| R9 | Healthcare data experience (HIPAA) a plus | preferred | adjacent | medium | transferability | You have GDPR/CCPA consumer PII handling and built the consent-state model. The limit: you have no healthcare data, and nothing you described exercised health-data safeguards | `[grounded]` your background; `[generic]` that the two regimes differ in what they protect and how | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R5, must_have) | discovery | Governed Looker dashboards, with no statement of who defined retention, churn or conversion | R5 is the one `must_have` row not at `direct`, so resolving it could lift the decision toward `go` | Writing LookML or a shared metric dictionary others queried; settling how a core metric was defined and getting teams to adopt it; a certified-metrics list behind the dashboards | A sanitized metric-definitions doc, a LookML excerpt, a governance note | `[grounded]` background silent on definitions; `[inferred]` that resolving it moves the status |
| G2 | Mentoring junior analysts (R8, important) | discovery | No mention of mentoring or onboarding | It is an explicit duty in the JD | Onboarding a new analyst; reviewing others' SQL or test write-ups; running analyst office hours | An onboarding doc or a review checklist | `[grounded]` background silent |
| G3 | Working with clinicians (R6b, important) | discovery | No domain-expert partnership described | Clinician partnership is named in the JD alongside PMs | Translating a test result for a domain expert who owned a quality or compliance decision, such as a nutritionist, a culinary lead or a food-safety owner | A readout or brief shown to a non-analyst expert | `[grounded]` background silent |
| G4 | Healthcare and HIPAA (R9, preferred) | transferability | Consent-state model and GDPR/CCPA PII handling | A plus, not a requirement, so a stronger bridge helps but doesn't gate | Design decisions behind the consent-state model; access controls or de-identification you applied | A short written description of the consent-state model | `[grounded]` your stated work; `[generic]` that healthcare teams ask how consumer-privacy experience carries over |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | The JD states no compensation | The range may or may not fit a senior analyst; the band could not be checked this run | `[inferred]` from the JD's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Several specializations bundled into one post | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards" | Analytics-engineering work may be folded into an analyst role | `[inferred]` from the JD's duty list | Who owns the data models and pipelines upstream of the metrics layer? | unresolved |
| RR4 | Success measures not stated | unknown | — | The JD gives no first-year outcomes | The mandate may be broad without defined results | `[inferred]` from the JD's silence | What would a successful first year look like, and which roadmap decisions is this role expected to influence? | unresolved |
| RR5 | Named tools and named team | positive_signal | — | "mentor two junior analysts", "Looker" | The scope looks concretely defined | `[grounded]` JD | Who do the two analysts report to today, and who would this role report to? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Harborlight's own careers site before spending effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | `resume_edits_pending_approval`: lead the summary with "Designed and ran an experimentation program of 30+ A/B tests a year, including the pricing test behind an 11% retention lift", then the Looker build: "Built the company's Looker instance from scratch: 40+ governed dashboards". | R3, R4. Each clause traces to your own sentences, with no "self-serve" added | `[grounded]` your background | pending your approval |
| A3 | Frame the HIPAA gap honestly: "Built the consent-state model for our warehouse; handled GDPR/CCPA consumer PII; no healthcare or HIPAA experience yet" | R9. The limit is stated, not hidden | `[grounded]` your background | pending your approval |
| A4 | Ask the RR2, RR3 and RR4 questions verbatim in screens | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Prepare a sanitized monthly metrics memo as a work sample | R7 | `[grounded]` your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for the company and its careers page were refused. They would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | A search for the senior product analyst salary band was refused. It would have fed market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier and upgrade menu

I can save this as a `tuesday-dossier.md` to carry forward if you'd like.

- Search access for the company site and a salary band → RR1 could clear, market calibration fills in, and RR2 gets a benchmark.
- The posting's pay range or a recruiter's answer → RR2 closes.
- A sanitized metric-definitions excerpt or LookML sample → R5 resolves, and R4 moves toward `high`.
- A sanitized metrics memo → R7 moves toward `high`.
- A sanitized test readout → R3 moves toward `high`.
- The hiring manager's name → scope read and which story to lead with.
- Your non-negotiables → hard-gate rows get checked against them.

## Questions

G1 — Did you define the metrics behind the Looker dashboards (retention, churn, conversion) yourself, in LookML or a metric dictionary others used? What did you own, and who relied on it?

G2 — Have you mentored or onboarded analysts, formally or informally? Who, over what period, and what did you do?

Constraints — Do you have any non-negotiables on location or remote work, pay floor, or work authorization?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.