Checking Brindlemoor's own careers page, because the search snippet says Leeds office four days a week and your JD says fully remote.
# Job Underwriting Assessment: Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Probably yes, but check one thing first: Brindlemoor's own careers page contradicts your JD on R1, the working pattern. Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5a, R6, R7 · adjacent: R5b (Monitor rating models)
- `important`: unclear: R8 (Recommendations for product)
- `preferred`: direct: R9 · adjacent: R10 (Pet-insurance product knowledge)

R1 — the careers page contradicts the JD and decides the case; R5b (`medium`) — "maintained" is your word, monitoring is unprobed; R10 (`low`) — a bridge from motor, its limit named.

**Opportunity ledger.** The role is live on the employer's own site and matches the JD on scope (RR2). The working pattern conflicts between the two sources (RR1), pay is unstated (RR3), and whether the post carries direct reports is unknown (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the hold waits on two answers. First, whether the post is fully remote or Leeds four days a week (R1, RR1). Second, whether you can do Leeds four days a week if that is the real arrangement (R1). If it is remote, the status moves to `go`. If it is Leeds four days and you can't do that, it becomes `no_go`.

Your lack of pet-insurance and people-management experience does not drive this decision. R10 is a `preferred` row, and the JD states no management requirement (RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; careers page fetched |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD; careers page repeats "own pricing analytics for our pet-insurance product" |
| Reporting line | Director of Pricing, Odile Varga | `[grounded]` JD and careers page |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` both sources |
| Scope read | A hands-on analytics post for one product. Neither source states direct reports | `[inferred]` from the JD's verbs ("build", "design", "read") against its silence on managing |
| Market calibration | A 2026 survey of UK insurers and insurtechs gives a median base of £58,400 and an interquartile range of £52,100 to £64,900 for senior pricing analysts. The posting withholds pay, so this is the band to expect, not Brindlemoor's offer (RR3) | `[generic]` role-family sweep, one search; survey result read from its snippet, page not fetched |
| Hiring manager | Odile Varga spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books. She was previously head of pricing analytics at Calloway Re for six years | `[grounded]` public professional profile, from a search result |
| Unknowns | Working pattern; salary; direct reports; pet-specific data and tooling | n/a |
| Contradictions | The JD says fully remote; the employer's careers page says Leeds four days a week | `[grounded]` careers page fetched against the JD you pasted |

## Evidence map

Your background was typed in, so it counts as self-report. That caps every row at `medium` until something inspectable is shown.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You have stated no working-pattern constraint, so confidence has nothing to grade. Fit is `unclear` because the JD and the careers page disagree | `[grounded]` JD against careers page; no candidate statement | Ask Brindlemoor (RR1); ask you the R1 question below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years of pricing analytics at a UK motor insurer, two of them as senior analyst; typed self-report, nothing inspected yet | `[grounded]` your intake message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily"; confirmed and specific on frequency, with no artifact | `[grounded]` your intake message | offer: a sanitized query or notebook would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your intake message | offer: a sanitized factor-review or model-spec page would raise to high |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built the young-driver GLM | `[grounded]` your intake message | none |
| R5b | Monitor rating models | must_have | adjacent | medium | discovery | "Maintained" is your word. Whether it covered monitoring after release (actual-versus-expected, drift, thresholds) is not stated, so the row takes the lower reading. Odile Varga's published talk is on model monitoring, so it is likely to be probed | `[grounded]` your wording; `[inferred]` from her talk topic that it is probed | G2 |
| R6 | Design and read price tests | must_have | direct | medium | none | 14 price tests last year with the underwriting team; the 14 counts tests, not visits or segments | `[grounded]` your intake message | offer: a sanitized test readout would raise to high |
| R7 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your intake message | none |
| R8 | Turn results into recommendations for product | important | unclear | low | discovery | Your recommendations went to underwriting; nothing says they went to a product team. The JD names both audiences | `[grounded]` the JD's two audiences against your one | G3 |
| R9 | Insurance experience a plus | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your intake message | none |
| R10 | Pet-insurance product knowledge (not required by the JD) | preferred | adjacent | low | transferability | You have never worked on pet insurance, so no direct evidence exists. What carries over is the method: GLM rating, price tests and model upkeep on an insurance book. Limit: you have not exercised pet-specific rating factors or claims patterns. Pet pricing typically involves different factors from young-driver motor | `[inferred]` bridge from your motor GLM work; `[generic]` that pet and motor rating factors differ | G4 (bridge case, no question) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | The JD says fully remote; the careers page says Leeds four days a week; you have not told me your constraint | It is the one row that could turn this into a `no_go`, and no strength elsewhere offsets it | n/a: this is a term you meet or don't | Brindlemoor's written confirmation of the working pattern | `[grounded]` the two sources disagree; `[inferred]` that the status turns on it |
| G2 | Monitoring rating models (R5b, must_have) | discovery | "Maintained" the young-driver GLM, with no detail on post-release monitoring | A must-have at `adjacent`; the hiring manager has published on this topic | Actual-versus-expected reports; drift or lift checks on rating factors; a trigger that led to a refit or a rate change | A sanitized monitoring pack, a dashboard screenshot, a refit note | `[grounded]` your wording; `[generic]` that monitoring depth is commonly probed in pricing interviews |
| G3 | Recommendations to product (R8, important) | discovery | Underwriting is the only audience evidenced | The JD names product as a second audience, and the row sits at `unclear` | A price-test result taken to a product, proposition or commercial lead; a rate-change proposal that shaped a product feature | A deck or memo addressed to a product or commercial reader | `[grounded]` the JD against your intake message |
| G4 | Pet-insurance knowledge (R10, preferred) | transferability | Method carries over from motor; pet-specific factors were not exercised | A preferred row; the honest framing of the bridge decides how this reads | n/a: a bridge case. Adjacent evidence is the frequency and severity modelling you did on motor. Limit: no pet claims or rating-factor work. Strengthener: a short note on how pet rating differs, written by you after reading up | A short self-written comparison note | `[inferred]` derived from your motor GLM work; `[generic]` on how pet rating differs |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern differs between the JD and the careers page (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The pasted JD may come from an older or different version of the posting, or the arrangement may be flexible. Both stay open | `[inferred]` from two texts that cannot both be current | "Is this role fully remote, or based in the Leeds office four days a week?" | unresolved |
| RR2 | Role live on the employer's own site and consistent on scope | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | The posting is real and the mandate matches the JD | `[grounded]` careers page fetched | "Who does the Director of Pricing's team consist of today?" | noted |
| RR3 | Pay not stated | unknown | — | JD gives no salary | The figure may sit inside or outside the survey band in role reality, or may simply not be published | `[inferred]` from the posting's silence, set against the `[generic]` survey band | "What salary range is budgeted for this post?" | unresolved |
| RR4 | Direct reports unstated | unknown | — | "Own pricing analytics" | The post may be individual-contributor, or may grow into managing, which you have not done. The JD does not say | `[inferred]` from the JD's silence | "Does this role have direct reports now, or is that expected later?" | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Get the working pattern confirmed in writing before investing in the application | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Reorder your CV so the GLM rating model, the price tests and the quarterly review to the head of underwriting lead the page. This adds no new claims; every item is already in your own sentences | see R4, R5a, R6, R7 | `[grounded]` your intake message | `resume_edits_pending_approval` |
| P1 | Frame the motor-to-pet move as adjacent: say the method carries over and that you have not worked on pet rating factors. Do not claim pet experience | see R10 | `[grounded]` your own statement that you have never worked on pet insurance | pending your approval |
| P2 | Prepare one account of how you monitored the young-driver model, using only what you actually did. If monitoring was never part of it, say so plainly rather than stretching "maintained" | see R5b | `[grounded]` the speaker profile; your wording | pending your approval |
| Q1 | Ask RR1, RR3 and RR4's verification questions of Odile Varga or the recruiter, verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers" and fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the employer and live posting (RR2) and surfaced the working-pattern contradiction (RR1, R1). It stated no salary |
| 2. Role-family sweep | yes | Searched "senior pricing analyst insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). I read the snippet only. It moved role reality's market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). It moved role reality's hiring-manager row, R5b's reasoning and P2 |

## Dossier offer

If you'd like a `tuesday-dossier.md` of this assessment to keep or carry forward, say so and I'll build it.

## Upgrade menu

- Brindlemoor's written confirmation of the working pattern closes R1 and RR1 and settles the decision.
- The budgeted salary closes RR3 and lets me set it against the survey band.
- A sanitized model-monitoring pack, a price-test readout or a GLM factor review would raise R4, R5b and R6 toward `high`.
- Your answer to G3 resolves R8.
- A deeper research pass on Brindlemoor (funding, leadership changes, staff and candidate reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

R1 — If Brindlemoor's careers page is the accurate one, could you work from the Leeds office four days a week? Or is fully remote a requirement for you?

G2 — When you maintained the young-driver GLM, did that include monitoring it after release (actual versus expected, drift, thresholds)? What did you personally own?

G3 — Have you taken price-test results to a product, proposition or commercial lead rather than underwriting? What was it, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.