Web access was denied for both research calls (the values page and the strategy search), so I'm building the pack from what you pasted and will log the refusals in the Sources section.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-8-denied-c4ee561f/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it in loop mode, with a mini-pack for each of the three rounds on 26 November.

Web access was denied for both research calls. I tried to check your pasted values page and the strategy points, so I could not confirm either is current. The pack runs on what you pasted. The Sources section logs both refusals.

- **Biggest gap to rehearse (C1):** the Head of Member Services is likely to press on the step from a branch complaints log to owning the process across branches and the contact centre. You have told me you haven't worked in a contact centre and haven't presented above regional level, so C1 rehearses conceding those two plainly.
- **Contact centre (B1) and senior presenting (B3, D2):** both come up before the panel, so they get their own questions.
- **Round 3 (panel):** the four values each get a question, and there are four complaint-escalation cases (G1 to G4) for the 20-minute case.
- **Thin spots:** your material says "spreadsheet" rather than Excel, and it doesn't show what rules the complaints log ran under. It also says nothing about digital teams, and your escalation coaching so far is of new tellers, not supervisors. These show up as answer slots for you to answer from your own experience.

Say the word and I'll play the Head of Member Services on C1 and follow up on what you actually say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop (26 November 2026), three rounds, loop mode:** Round 1, 30 minutes with the recruiter. Round 2, 45 minutes with the Head of Member Services (your future manager), mostly behavioural. Round 3, 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case; the panel is also the values round and scores against the four values.
**Interviewer names:** none assigned beyond the roles above.

## How to use this pack

- Personas describe how a question is asked; types describe what is scored. Rehearse both.
- Type key: VAL is behavioural or values alignment. EXP is a deep-dive on your own experience. JD is a stated requirement of the role. CO is company and strategy knowledge. CASE is a live problem.
- Guidance is scaffolding, not a script. Say what you did in your own words. An answer slot is an instruction for the interview: answer it truthfully from your own experience, and if the practice was not yours or never existed, say so plainly.
- Question IDs run A to H across the three rounds. Round 1 is A and B. Round 2 is C, D and E. Round 3 is F, G and H.
- The highest-ROI rehearsal in the whole pack is **C1**: the step up from a branch complaints log to a role that owns the process across branches and the contact centre, and reports upward. Rehearse it until it is boring.

## Grounding brief

What you relayed from Ashgrove's July 2026 strategy brief. I have not seen the brief itself, and my check of it was refused (see Sources).

| Item | What it says | Provenance |
|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | [grounded] your message, brief as relayed |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | [grounded] your message, brief as relayed |
| New product | "launch a small-business lending product in Q1 2027" | [grounded] your message, brief as relayed |
| Competitive pressure | "the main competitive pressure is app-only banks" | [grounded] your message, brief as relayed |

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint after it was logged likely. If any complaint's path from log to close was yours to drive, say which and what you did, in your own words; if the log was where your part ended, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Monthly and complaints are in your sentence; volumes and resolution times are not. Answer slot: if the spreadsheet counted volumes or how long complaints took, say which and how it was counted; if it did not, say so plainly and say what you would measure first |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | "Spreadsheet" is your word and this pack does not turn it into a named tool. Answer slot: say which tool you built it in, in your own words; if it was Excel say so, and if it was another tool say so plainly and say what you have used |
| F5 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on length, which is not a gate. A line with nothing inspected behind it, so expect a probe on what the six years held. Lead with it in the quote's own terms: six years in retail banking, the last three as a branch supervisor |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | "Formal" is in your sentence; which rules or deadlines applied is not. Answer slot: the JD's word "regulated" makes a probe on the rules the log ran under likely. If you know which rules and deadlines applied, say them in your own words; if you do not know, or setting them was not your part, say so plainly and stay with the log |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | transferability | Your sentence is about new tellers, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: if you have coached anyone at your own level or above on escalations, say who and what; if not, say so plainly and stay with the new tellers |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital teams. Answer slot: if you have worked with a digital, IT or contact-centre team on anything members use themselves, say what and what your part was; if not, say so plainly and say how you would start |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented above regional level." Then how you would prepare, said as a plan and never as a past. Never a claim to leadership presenting |

## Persona tables and question banks

### Round 1: recruiter screen (30 minutes)

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through of your background, logistics asked casually | Dominant: the recruiter-screen prior is Conversational plus a light Skeptic, and the recruiter's email gives no other focus | A 90-second arc for the biography question; treat every casual question as scored |
| Skeptic | Gentle probing of the contact-centre gap and Excel comfort | Light: the JD's contact-centre line and your stated gap make a knockout check likely | State the gap plainly, then the plan; do not bluff |

**Conversational bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your six years in retail banking and what brought you to this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Story-mapped on F5: six years in retail banking, the last three as a branch supervisor; those are the beats the quote states, told in your own words. Then why this role: say it in your own reasons, in under 30 seconds | The opener of nearly every screen, and F5 is the evidence for the experience requirement; EXP because it tests your own history |
| A2 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. Do not offer a salary history | The recruiter row of the persona weights puts pay in every screen; JD because it is the job's terms. The posting you sent states no pay |
| A3 | "What is your notice period?" | JD | [generic] | Logistics slot: give your actual notice period | Standard screen logistics; JD because it is the job's terms |
| A4 | "Is the location and working pattern workable for you?" | JD | [generic] | Logistics slot: state your own constraint, or say it is open. The posting you sent states no location or hours, so ask the recruiter what they are | Standard screen logistics; the posting is silent, so this may be the first time the terms are named |
| A5 | "What is prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your own reason, in your own words, kept to what drew you to this role rather than what is wrong with your current one | Reason for leaving is asked of every candidate; EXP because it tests consistency with your story |

**Skeptic bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked in a contact centre, and this role covers one. How do you see that?" | JD | [grounded] "Never worked in a contact centre" | Say it plainly: "I haven't worked in a contact centre." Then a plan: what you would learn first about how complaints reach and leave that team. A plan is a future, so claim no past. Do not offer branch work as a substitute for contact-centre work | F2 is a stated gap and the JD names the contact centre outright; JD because it scores a stated requirement |
| B2 | "How comfortable are you with Excel reporting?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Start from the sentence: you built a monthly complaints spreadsheet that your regional manager uses. Answer slot: say which tool it was built in, in your own words; if it was Excel, say so, and if it was another tool, say so plainly and say what you have used | F4 is where the Excel line is thin, and the screen is a cheap place to knock it out; JD because it is a stated requirement |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" and "I've never presented to anyone above regional level" | Pick from what you have said: "I haven't worked in a contact centre" and "I haven't presented above regional level." Name one, pair it with how you would close it, and hold the rest of your answer on what you do have. Hold the choice through a second push before adding a second gap | F2 and F9 are the two stated gaps; JD because it scores honest self-assessment against the listed job |

**Reverse questions, round 1**

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "What is the most important thing for the Member Experience Lead to have changed in the first six months?" | Shows you are thinking about outcomes, and gives you the recruiter's own priorities for rounds 2 and 3 |
| R1-2 | "Is there anything in my background you would want me to address before I meet the Head of Member Services?" | Invites the objection early so you can rehearse the real one rather than the assumed one |
| R1-3 | "What will the 20-minute escalation case in the panel look like: written, talked through, and do I get materials beforehand?" | Cheap to ask and the answer reshapes the G bank |
| R1-4 | "Who are the two branch managers on the panel, and what do they own day to day?" | Turns an unassigned panel into named roles you can prepare for |
| R1-5 | "How does the contact centre sit relative to the branches in the complaints process today?" | Signals you are taking the contact-centre half of the role seriously rather than avoiding it |

### Round 2: Head of Member Services (45 minutes, your future manager, mostly behavioural)

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probing of scope, the contact-centre gap, senior presenting and regulated complaints | High: the hiring-manager row pairs Skeptic with Case, and the manager is buying capability and derisking gaps | Rehearse C1 until it is boring; bridge only from what you have stated |
| Values and Behavioral | Past-behaviour prompts about complaints, escalation and working across teams | High: the recruiter's email says the round is mostly behavioural, which moves this above the usual hiring-manager Case weight | Map a story where one of your sentences carries one; where none does, choose an instance with the scaffold and say so if none comes to mind |
| Case and Strategist | A couple of strategy questions on digital and hub changes | Lower: the recruiter described the round as mostly behavioural, but the manager owns the strategy's service side | Clarify, structure, then metrics and risks; use Ashgrove's own words |

**Skeptic bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your background is a branch complaints log, and this role owns the process across branches and the contact centre. What makes you ready for that scope?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." and "Never worked in a contact centre" and "I've never presented to anyone above regional level" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I handled the branch's formal complaints log." Concede the two limits before they are pressed: "I haven't worked in a contact centre" and "I haven't presented above regional level." Hold through three follow-ups: (1) what from the branch carries over, answered at the log's scope and never wider; (2) what you would do first in the contact-centre half, answered as a plan; (3) "we wanted someone with contact-centre experience", answered by conceding and returning to what you have said. Never fold on the core claim to restore harmony, and never add to the log | F1, F2 and F9 together are the biggest gap between the JD and your material, so this objection arrives in some form; JD because it scores the stated scope |
| C2 | "You trained new tellers on your escalation script. The role is coaching branch supervisors. What changes?" | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what the sentence says: you trained new tellers on your escalation script. Answer slot: supervisors are at your own level or above, so expect a probe on whether you have coached at that level; if you did, say who and what; if not, or it was not your part, say so plainly and stay with the new tellers | F7 is the only coaching evidence and it concerns a different audience; JD because it scores the stated requirement |
| C3 | "Tell me about your monthly complaints spreadsheet: what goes in it and who uses it?" | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Beats the quote states: you built it, it is monthly, it is about complaints, your regional manager uses it. Answer slot: the JD asks for volumes and resolution times, so expect a probe on what it counted; if it counted either, say which and how it was counted; if it did not, say so plainly and say what you would measure first | F3 is the evidence for the reporting line and the likeliest place to be probed; EXP because it tests what was actually yours |
| C4 | "The role needs experience of regulated complaints. What made the complaints in your log formal, and what rules applied?" | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from the sentence: it was the branch's formal complaints log. Answer slot: if you know which rules and deadlines applied, say them in your own words; if you do not know, or those were set above you, say so plainly and stay with the log | F6 is a thin row on a stated requirement, and the word "regulated" invites a probe; JD because it scores the listed requirement |

**Values and Behavioral bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you took a complaint from first contact to a fix." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1 only as far as the quote goes: you handled the branch's formal complaints log. Answer slot: choose one complaint you saw through; say what you did yourself and what happened; if your part stopped at the log, or no such case comes to mind, say so plainly and stay with the log | The JD's end-to-end line and the published value "Own the Fix" both raise this theme; VAL because it scores behaviour against a published value |
| D2 | "Tell me about a time you had to give a senior person an unwelcome message." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact working relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not claim presenting above regional level | The JD's senior-leaders line and the persona stem raise this; VAL because past behaviour is scored. F9 is why the honest branch matters |
| D3 | "Tell me about a time a colleague disagreed with how a complaint should be handled." | VAL | [generic] | Selection scaffold: pick a case with a real disagreement, what you stood on, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's escalation line raises this; VAL because it scores disagreement style |
| D4 | "Tell me about a time you worked with a team outside your branch to improve something members use." | VAL | [generic] | Selection scaffold: pick a case with a named other team, what you needed from them and what came of it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's digital-teams line raises this and F8 has no evidence; VAL because it scores cross-team behaviour |

**Case and Strategist bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Ashgrove plans to move 40% of member service to digital channels by 2028. What does that do to complaints?" | CO | [grounded] strategy brief as relayed: "move 40% of member service to digital channels by 2028" | Clarify first: what counts as digital service and who owns a complaint that starts in the app. Then the effects: where complaints are raised, how they reach the process, and what to measure. Use "Own the Fix": whoever finds the problem keeps hold of it, whichever channel. The question needs no claim about your past | The strategy raises this and the JD names self-service journeys; CO because it tests company-level thinking |
| E2 | "Eight branches become five hubs over 2027. What would you watch in complaints?" | CO | [grounded] strategy brief as relayed: "consolidate eight branches into five hubs over 2027" | Clarify what is changing for members and when. Then what to watch: the volume and the mix of complaints, resolution times in the affected branches, and what members say about their branch. Tie to "Neighbours, Not Numbers". The question needs no claim about your past | The strategy raises this and your role spans branches; CO because it tests whether you think at the company's altitude |

**Reverse questions, round 2**

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What would you want the Member Experience Lead to have changed in complaints by the end of the first year?" | Asks your future manager for the outcome they would judge you on |
| R2-2 | "How do complaints move between branches and the contact centre today, and where do they get stuck?" | Shows you are working on the contact-centre half and gives you the real problem |
| R2-3 | "As branches consolidate into hubs, who owns a complaint that begins in a branch that is closing?" | Ties to the brief and to "Own the Fix" |
| R2-4 | "What does a good monthly complaints report look like to the people you present it to?" | Finds out what senior leaders look for before you present to them |
| R2-5 | "What would you want me to learn first, given that I have not worked in a contact centre?" | Names the gap yourself and asks your manager to shape the ramp |

### Round 3: panel of two branch managers (60 minutes, values round and a 20-minute case)

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values and Behavioral | Scenario probes scored against Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | Dominant: the recruiter's email says the panel scores against the four values | One story per value where a quote carries one, otherwise the scaffold; "we" for context, "I" for your own part |
| Case and Strategist | The 20-minute complaint-escalation case | High: 20 minutes of the 60 are the case, as the recruiter said | Clarify, objective, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Peer Evaluator | What you would need from branch managers and what they would get | Lower: branch managers are the people whose supervisors you would coach, but the recruiter did not give this round a peer focus | Reciprocity framing; propose principles rather than pretending to know the seam |

**Values and Behavioral bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided from the member's side of the counter when it was not the easy option." | VAL | [grounded] values page as pasted: "Members First, Always" | Selection scaffold: pick a decision with a named member, what the easy option was, and what you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Raised by the published value; VAL because it scores behaviour against it |
| F2 | "Tell me about a time a member needed something explained twice. What did you change?" | VAL | [grounded] values page as pasted: "Plain Words" | Selection scaffold: pick a case where the explanation did not land and what you changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not claim your escalation script was written in plain words | Raised by the published value; VAL because it scores behaviour against it |
| F3 | "Tell me about a time you weighed a local circumstance against a standard process or number." | VAL | [grounded] values page as pasted: "Neighbours, Not Numbers" | Selection scaffold: pick a case with a named local circumstance, the standard and what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Raised by the published value and the hub changes; VAL because it scores behaviour against the value |
| F4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] values page as pasted: "Own the Fix", and "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1 only as far as the quote goes: you handled the branch's formal complaints log. Answer slot: if you kept a complaint from the log through to its close, say one and what you did yourself; if the log passed complaints to others, or that was not your part, say so plainly and stay with the log | Raised by the published value and the JD's end-to-end line; VAL because it scores behaviour against the value |

**Case and Strategist bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member complained at their branch about a fee they say they never agreed. The supervisor says it is resolved. The member has now rung the contact centre, where there is no record of the branch complaint, and says they will take it further. What do you do?" | CASE | [generic] | A hypothetical, so it needs no claim about your past. Suggested pacing: about 3 minutes clarifying, 5 structuring, 8 on approach, 4 on metrics and risks. Clarify first: what was promised, what is recorded, and what rules and timescales apply, asked rather than assumed. Objective: the member's outcome with one owner. Approach: challenge the premise that it is resolved by checking whether the member agrees; one record across both channels; a plain reply; the owner keeps hold until it is solved. Metrics: volumes, time to resolve, repeat contacts. Risks: conflicting records, early closure | The 20-minute case is on the recruiter's schedule; `[generic]` because it is a pattern for the problem, not a fact about Ashgrove. CASE because it is a live problem from the role |
| G2 | "Resolution times at one branch have doubled over two months. Diagnose it." | CASE | [generic] | A hypothetical. Clarify first: doubled against what, which complaint types, any change in staff or volume. Segment: intake, routing, resolution, closure. Say which data you would pull and what each cut would show. Then the coaching angle for the supervisor, since that is the role | Pairs the JD's reporting and coaching lines; CASE because it is diagnostic |
| G3 | "A member starts a complaint in the app, is told to visit a branch, then phones the contact centre. Map where it went wrong and what you would fix." | CASE | [generic] | A hypothetical. Map the three hand-offs, say where the record breaks, and say which fix is owned by whom. Link to the digital shift in the brief. State one assumption aloud and say what would change it | The JD's digital line and the brief's 40% target raise this; CASE because it is a live problem |
| G4 | "Members of a branch that is merging into a hub say they have lost their branch and are complaining. How do you handle it, and how do you report it?" | CASE | [grounded] strategy brief as relayed: "consolidate eight branches into five hubs over 2027" | A hypothetical set inside the brief's plan. Separate the complaints about the change from the ones about service. Say how you would log and route them, what you would report monthly, and how you would keep the branch's community voice in the reporting, in line with "Neighbours, Not Numbers" | The brief raises the hub change and the panel are branch managers; CASE because it is a live problem |

**Peer Evaluator bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our supervisors are stretched. What would you need from us, and what would we get from you?" | JD | [generic] | Reciprocity: say what you would bring to the branches before what you need. Propose principles for the seam, such as who owns a complaint and when it moves, rather than pretending to know today's seam. Ask what is not working now | The role coaches supervisors in the panel's branches; JD because it scores the coaching line as a working relationship |
| H2 | "How do you handle a branch manager who disagrees with an escalation call?" | VAL | [generic] | Selection scaffold: pick a case with a real disagreement, what you stood on and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's escalation coaching raises this; VAL because it scores disagreement style with an equal |

**Reverse questions, round 3**

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What is the complaint you most wish had been handled differently in your branch, and what would you have changed?" | Gets the panel talking about real cases rather than the case you rehearsed |
| R3-2 | "What would you want from the Member Experience Lead in your first month with your branch?" | The reciprocity question: it asks what a new person could do that would help them |
| R3-3 | "How will the move to hubs change what supervisors need from a complaints lead?" | Ties to the brief and to the people you would coach |
| R3-4 | "Which of the four values do you see tested hardest in a complaint?" | Invites a real story and shows you took the values seriously |
| R3-5 | "How do your branches hear about changes to the complaints process today?" | Shows you think about adoption, not only design |

## Values cheat sheet

The panel scores against these four values. The names and wording are as you pasted them from ashgrovecu.org/about/values; my check of the page was refused.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold (F1 in the bank): pick a decision with a named member and what the easy option was. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs it explained twice, the writing was wrong | Selection scaffold (F2 in the bank): pick a case where an explanation did not land and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold (F3 in the bank): pick a local circumstance weighed against a standard. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1 row: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Say you handled the log; if you saw a complaint through, say one and what you did yourself, and if not, say so plainly |

## Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| Own the member complaints process end to end | C1, D1, F4, G1 |
| Across branches and the contact centre | B1, C1, G3 |
| Report monthly on complaint volumes and resolution times | C3, G2 |
| Coach branch supervisors on escalations | C2, G2, H1, H2 |
| Work with digital teams on self-service journeys | D4, E1, G3 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | C4 |
| Confident presenting to senior leaders | B3, C1, D2 |
| Comfortable with Excel reporting | B2, C3 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not words for you: the material says the log, not the process |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't presented above regional level." No slot |
| Has coached branch supervisors | Inflated form of F7 | F7's quote at its own scope: "I trained new tellers on our escalation script." C2's slot stays with the tellers |
| Has regulated-complaints expertise | Inflated form of F6 | F6's quote at its own scope: the branch's formal complaints log. C4's slot asks only what rules you know applied |
| Has reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: you built the monthly complaints spreadsheet. C3's slot asks only what it counted |

## Sources

Provided documents: the job description you pasted; the values text you copied from ashgrovecu.org/about/values; the recruiter's email about the process; the four points you relayed from the July 2026 strategy brief (I have not seen the brief itself); your background as you described it in your message. No CV text was provided.

Calls sent, both refused, so nothing came back from either:

- Fetch of ashgrovecu.org/about/values, to check your pasted values wording: refused.
- Search "Ashgrove Credit Union 2026 strategy digital 40% branch hubs", to check the strategy points: refused.

Research tier: L1 — searches 1 of 6, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | unavailable | The fetch to check your pasted values was refused; it would have confirmed the four names and wording in the cheat sheet and the F bank are current |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the rounds, who runs each and how long; persona weights follow it |
| 3. `Ashgrove Credit Union strategy` / recent news | unavailable | The search to check the relayed strategy points was refused; it would have confirmed they are current and could have moved E1, E2, G3 and G4 |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer names were given, so there was no query to form |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web access, if you allow it → a check that the values wording and strategy points you pasted are current, and a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) for a fuller strategy picture and role-family loop reports
- Interviewer names for rounds 2 and 3 → persona weights read from their public footprint, an interviewer read, and a reverse question tied to each person's path
- Your CV text → evidence cells quoted from the CV rather than your message, and any lines it carries on rows F3, F4, F6, F7 and F8
- Your answers to the slots on F1, F3, F4, F6, F7 and F8 (what the log ran under, what the spreadsheet counted and was built in, any coaching of peers or supervisors, any work with digital or contact-centre teams) → those rows firm up and the matching bank guidance becomes story-mapped
- The recruiter's answers on the case format, the role's location and hours, and the pay band → the G bank, A2 and A4 stop being generic
- A `tuesday-dossier.md` from an earlier run → verified evidence and prohibited claims would replace the ones this pack built from your message
