Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-7-canned-913c9c5d/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 20 questions, 9 fit-snapshot rows, 6 reverse questions and a Wednesday-to-Friday triage.

I built it for a hiring-manager round. Saltmarsh's interviewing page says there is one 60-minute session with the hiring manager. The first half is a live-incident tabletop on a simulated outage during a live event, and the second half is a values conversation. There is no take-home, so the pack leans on live-problem questions and the three published values.

- **Biggest prep item:** C1. It asks how you coordinate four teams when you've never led one, and the pack gives you the plain acknowledgment plus what you can safely say about the calendar you ran.
- **Second gap:** C3 covers in-app purchases. Saltmarsh's Project Larkspur announcement (September 2026) moves two titles to a season-pass model, so expect it to come up.
- **Strongest story:** B3, the release checklist QA still uses, maps to the "Leave the Build Greener" value.
- **About Tobias:** the pack uses his GDC 2026 talk, Patch Notes Are a Promise, and his earlier QA background. Both come from a search snippet, because I couldn't fetch the talk page within the fetch budget.

Say the word and I'll play Tobias on C1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Will Tobias be your direct manager, or someone more senior? The answer reweights every bank.
2. Did the recruiter say anything about what the outage tabletop covers?
3. Do you want a deeper research pass, with up to 6 more searches and 2 more fetches taking several more minutes? It would read his talk in full and sweep recent Saltmarsh news.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager. Saltmarsh's interviewing page says the single 60-minute session is run by the hiring manager, and your note did not say how Tobias relates to the role. If he is a skip-level or someone else, the persona weights below change.

Format, from Saltmarsh's own page: a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home.

## How to use this pack

Personas are how a question is asked. Types are what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your own claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's current strategy |
| CASE | Structure and reasoning on a live problem from the role |

Bank letters A to E and G are personas. Fit rows are F1 to F9. The letter F is skipped for banks so the two never collide.

## Prep triage

You have until Friday. Done well, in this order:

1. Wednesday: C1, then C3. These are the objections you will be asked in some form. Say the plain acknowledgments out loud until they are boring.
2. Thursday: A1, A2 and A5 aloud, as a structure each time. Then B3 and B1.
3. Friday morning: the G1 arc, then the reverse questions R1 to R3.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Your material gives four years as an associate producer and a weekly content-drop calendar. It does not say whether the title was live-service, and the pack does not assume it. Answer slot: the JD's live-service line makes a probe on what live-service meant at your studio likely. If the game ran on continuous updates, say how, in your own words; if it did not, say so plainly and stay with the weekly content drops you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap on the words, but it is one line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: for the last two years you ran the weekly content-drop calendar for your main title |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one main title and content drops, not live events and not two titles, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on a second calendar likely. If you ever ran more than one calendar, say which and how; if not, say so plainly and stay with the one calendar you ran |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | The quote shows a calendar, not whom it was coordinated with. Answer slot: the JD names four disciplines, so expect a probe on how each drop moved between them. If you worked with any of those teams on drops, say which and how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the calendar |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you ran a review or owned the KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe on who decided what was reported likely. Say which part of the numbers was yours, in your own words; if you presented numbers someone else produced, say so plainly and stay with the presenting |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and QA still uses it, not that you managed releases against it, and the words stay there: "I wrote the release checklist our QA team still uses." Answer slot: the JD's manage-with-QA line makes a probe on how the checklist runs each release likely. If you ran releases against it with QA, say how; if you did not, or it was not yours, say so plainly and stay with the checklist you wrote |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap on the words, though nothing is inspected behind the line. Lead with the monthly presenting in the quote's terms. The defend-the-number slots in D1 and E2 are where a prober will go |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist QA still uses is a written document, but the quote does not show how clear it was. Answer slot: if anything else you wrote was acted on by other people, say what and who used it; if you have no other written example, say so plainly and stay with the checklist |
| F9 | Working knowledge of in-app purchases and season-pass events — not in the JD; Saltmarsh's September 2026 Project Larkspur announcement moves two titles to a season-pass model | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make it feel smaller |

## Graded deliverables

Dropped: Saltmarsh's interviewing page says there is no take-home, and no deliverable was announced.

## Reading the interviewer

Public professional footprint only, from a search result snippet. The talk page itself was not fetched.

| Observation | Source | Implication |
|---|---|---|
| Head of Live Operations at Saltmarsh Games | Talk listing, GDC 2026 | He runs the group the role sits in [inferred] |
| Previously a QA lead at a console studio | Talk listing, GDC 2026 | Release checklists and QA are native ground for him [inferred] |
| His talk, Patch Notes Are a Promise, argues a live team is judged by how often its patch notes describe what actually shipped | Talk listing, GDC 2026 | Expect a probe on whether what you announce matches what shipped (D3, A5). It also lines up with the Ship the Patch Not the Promise value [inferred] |

Mirror opportunity: he came up through QA, and F6 says in your own words "Wrote the release checklist our QA team still uses." Offer it as that sentence and nothing wider. Do not build on any shared background beyond this professional path.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Case / Strategist | The Outage Hour tabletop: a simulated outage during a live event | Highest. Saltmarsh's interviewing page makes the tabletop the first half of the session; hiring managers also default here | Clarify, structure, then answer. Think aloud. Challenge one premise politely |
| B Values / Behavioral | The second half: a values conversation | High. The same page documents it, and Saltmarsh publishes three values by name | Map a story to each value only where your quoted sentences carry one; otherwise pick a real instance or say none comes to mind |
| C Skeptic | Quiet probing of team leadership, in-app purchases, live events across two titles | High. Two gaps are ones you stated; the hiring-manager prior adds it | Rehearse the plain acknowledgment until it is boring; bridge only from what you said; give a ramp plan |
| D Data-Driven Prober | Retention numbers, how they were counted, whether announcements match what shipped | Medium. You presented retention monthly; Tobias's published theme is shipped versus announced | Know what you can and cannot say about how the numbers were counted. Say plainly when you do not know |
| E Pressure | Time-boxed tabletop, interruptions, why you over someone with more | Medium-low. A simulated outage tends to carry time pressure, but no source says this loop is a stress interview | Pause, restate, hold the position through two follow-ups, concede specifically |
| G Conversational | Opening biography, motivation | Low-medium. The values half is conversational, so a casual opener is plausible | A pre-scripted 90-second arc built from your quotes |

No peer persona: a hiring-manager round does not weight it. If Tobias is a peer or skip-level, say so and this table gets rebuilt.

## Question banks

### A. Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event started an hour ago and a reward is not being granted to a share of players. Community is already reporting it. Walk me through your first fifteen minutes." | CASE | [generic] | Structure it aloud: what you need to know first (who, since when, how many), who you pull in (engineering, QA, community), what players are told and when, whether to pause, roll back or patch, and what you record. Put players first, which is Saltmarsh's first published value. The question asks about no past of yours, so the guidance makes no claim about it | This is the shape of the Outage Hour that the interviewing page describes; CASE because it is a live problem with no history presupposed |
| A2 | "Engineering says the fix is ready. QA has not finished the release checklist. The event ends in three hours. Ship or hold?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Say your decision rule first, then what you would ask (what is still open on the checklist, what the fix risks against what the bug costs), who decides, and what players are told either way. If you refer to the checklist, use only "I wrote the release checklist our QA team still uses." Do not say you managed releases | F6 is the evidence and the likeliest seam in this scenario; CASE because it is a live trade-off, JD because it scores the checklist requirement |
| A3 | "Project Larkspur puts two titles on one shared events calendar from February 2027. What would you want to know before planning it?" | CASE | [grounded] Saltmarsh's September 2026 Project Larkspur announcement, search result in Sources | Clarify the objective (what a shared calendar must achieve for two titles), constraints (audience overlap, shared freeze windows), then segmentation, approach, metrics and risks. Challenge one premise respectfully, for example who owns a collision between two titles' events. Ask which two titles the role covers. Making no claim about your past | The strategy differentiator question: current company news that a prepared candidate can use; CO and CASE because it asks for company-level thinking in a live format |
| A4 | "After a two-week event, what goes in the post-event review and which numbers does it report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you would include, as a plan: what was expected, what happened, why, what changes next time. Then your own sentence, at its scope: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe on who chose the numbers likely. If you chose or defined any of them, say which and how, in your own words; if someone else set them, or there was no such review, say so plainly and stay with presenting retention | F5 is a transferability row, so this is where the requirement is tested; JD because it scores the stated requirement, CASE in delivery |
| A5 | "Give me the player notice for this outage, out loud, in three sentences." | JD | [generic] | Say what happened, what players should expect or do, and what you are not promising. State only what is confirmed, which is the spirit of Saltmarsh's second value, we announce what is built and not what is hoped. No claim about your past | The JD's written-communication line tested live, and Tobias's published theme is shipped versus announced; JD tag, CASE delivery |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] Saltmarsh's published value Players Before Plans; nearest material "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick a time a schedule and the players' experience pulled apart, with a named stake, a call you made or argued for, and a relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years.", or how you would handle it | Your quotes carry no story of a clash, so this is the scaffold case; VAL because it maps to a published value |
| B2 | "When have you had to say what was actually shipped when people wanted to hear what was planned?" | VAL | [grounded] Saltmarsh's published value Ship the Patch Not the Promise; nearest material "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a moment where the honest status was less welcome than the plan, with what you said and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "Presented the monthly retention numbers to the studio head.", or how you would handle it | Tobias's talk theme and the value point the same way, so a prepared story here lands twice; VAL |
| B3 | "Tell me about a release or process you left in better shape than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F6: you wrote the checklist, and QA still uses it. Those are the beats the quote states; tell them in your own words. Answer slot: the value says every release leaves the checklist better, so expect a probe on how it changed after releases. If it changed, say how and who changed it; if it was not revised, or the changes were not yours, say so plainly and stay with the checklist you wrote and the fact QA still uses it | The strongest story your material carries for any published value; VAL |
| B4 | "Tell me about a time you delivered an unwelcome truth to someone senior." | VAL | [generic] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time a number was bad and you said so, with a named stake and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "Presented the monthly retention numbers to the studio head.", or how you would handle it. Do not supply an ending the quote does not | Persona stem for the values interviewer; your quote shows presenting to leadership but not an unwelcome message, so this stays a scaffold; VAL |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The job is to coordinate design, art, engineering and community on each update. You haven't led a team. What gets four teams moving on your calendar?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI prep in this pack, and the hold is only what the quotes carry. Say the acknowledgment first: "I haven't led a team." Then stay with the JD's own verb, coordinate, and the calendar: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's four disciplines make a probe on how each drop moved between them likely. If you worked with any of those teams on drops, say which and how, in your own words; if there was no such step, or it was not yours, say so plainly and return to the calendar. Then a plan, as a plan: what you would set up with each team in your first month. Hold through two follow-ups, for example what if engineering says no, by returning to the calendar and the plain limit. Concede the specific point, that authority over a team is not something you have had | Your two stated negatives plus the JD's coordinate line make this the objection most likely to be asked, in some form; F4 is the row behind it; JD because it scores the stated requirement |
| C2 | "The JD asks for three years producing live-service games. What did live-service mean at your studio?" | JD | [inferred] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years." | Say the facts in those words: four years as an associate producer at a puzzle-game studio, and the weekly content-drop calendar. Answer slot: the JD's live-service line makes a probe on what was live about it likely. If the game ran on continuous updates, say how, in your own words; if it did not, say so plainly and stay with the calendar you ran | F1 is a discovery row, so the honest answer is the slot, rehearsed before the probe; JD because it scores a stated requirement |
| C3 | "Saltmarsh is moving both titles to a season-pass model. You haven't worked on a game with in-app purchases. How would you get up to speed?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Acknowledge it plainly: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan: what you would learn first about how the season pass is structured, and from whom. No slot and no bridge, because you stated the absence. Hold-then-concede: do not stretch the puzzle-game work into monetization experience; concede that this is new | F9 is a stated capability gap, and the announcement makes it more likely to come up; JD because the season-pass model shapes the role |
| C4 | "You ran the weekly content-drop calendar for your main title. This role runs live events across two. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say the quote at its scope. Answer slot: the JD's two-titles line makes a probe on a second calendar likely. If you ran more than one, or ran any event-style content, say which and how; if not, say so plainly and stay with the one calendar. Then what you would want to learn first about how the two titles differ, as a plan | F3 is the transferability row; JD because it scores the calendar requirement |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented, in the quote's words. Answer slot on the four defend-the-number slots: how the figures were counted, what they are sensitive to, the assumption behind them you would defend least, and which part was yours. Answer each in your own words; if you do not know how something was counted, say so plainly. "I do not know how that was counted" is an honest answer | F5 and F7 rest on one line, and a prober goes line by line; EXP because it tests attribution |
| D2 | "Which retention numbers belong in a post-event review, and what would make you distrust one?" | JD | [generic] | A method, not a history: say which numbers you would want and why, and what would make you doubt one, such as a small sample or an overlapping event. Name the weakest assumption in your own approach before he does. No claim about your past | JD line on retention metrics, asked at a conceptual level; JD because it scores comfort with retention metrics |
| D3 | "Before an update goes out, how do you make sure the patch notes describe what actually shipped?" | JD | [inferred] "Wrote the release checklist our QA team still uses." | Derived from the interviewer's published talk theme. Start from "I wrote the release checklist our QA team still uses." Answer slot: if that checklist had a step matching the notes to the build, say what it was; if there was no such step, or it was not yours, say so plainly and say what you would add | The one question built on Tobias's own published theme; JD because it scores the checklist requirement |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events for years?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head."; "Never led a team, and never worked on a game with in-app purchases." | Pause, restate, then those three sentences at their own scope. Hold the position through two follow-ups by returning to them. Then concede specifically, in the plain terms of the last quote, that you have not led a team or worked on a game with in-app purchases. Do not fold on what you did to restore harmony, and do not add to it | Pressure persona stem; F1 to F9 together are the defence, so every claim is a quote |
| E2 | "That retention number: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold the quote: you presented the monthly retention numbers to the studio head. Answer slot: say which part was yours, in your own words; if the numbers came from someone else, say so plainly. Do not widen the claim | Attribution probe built from F5; EXP |

### G. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc made of those four sentences in order, each at its own scope, in your own words. End on the role you are interviewing for, in your own reason | A casual opener is still scored; EXP because it tests the story against the rest of the hour |
| G2 | "Why Saltmarsh, and why now?" | JD | [generic] | Your reasons are yours, and the pack supplies none. Answer slot: give your actual reasons in your own words. Mention a Saltmarsh value only if it is true for you | Motivation probe from the Skeptic stems; the answer cannot be written for you |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A3, C4 |
| Coordinate design, art, engineering and community on each update | A2, C1 |
| Own the post-event review and the KPIs it reports | A4, D2, E2 |
| Manage the release checklist with QA | A2, B3, D3 |
| 3+ years producing live-service games or apps | C2, G1 |
| Experience running a content calendar | C4, G1, B1 |
| Comfortable with player-retention metrics | D1, D2, E2 |
| Clear written communication | A5 |

## Values cheat sheet

A values-style round is documented on Saltmarsh's interviewing page, and the three values come from its values page.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold, B1. Nearest material, F2: "I ran the weekly content-drop calendar for our main title for the last two years." If no such time comes to mind, say so plainly |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold, B2. Nearest material, F5: "Presented the monthly retention numbers to the studio head." If no such time comes to mind, say so plainly |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | B3, F6: "Wrote the release checklist our QA team still uses." |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Project Larkspur retires per-title event teams in favour of one live-ops group. Which two titles does this role cover, and does it sit in that group?" | Shows you read the announcement, and answers a structural unknown before you accept |
| R2 | "Your 2026 talk argued a live team is judged by how often its patch notes describe what shipped. How does your team measure that today?" | Ties to his own published work and asks for a concrete practice |
| R3 | "You were a QA lead before running live ops. What from that stuck in how this team runs its release checklist?" | Tied to his own career path; it opens a conversation about the checklist you wrote |
| R4 | "Which two numbers must the post-event review report, and who decides an event was a miss?" | Defines what owning the KPIs means in practice |
| R5 | "What should a new producer have shipped by day sixty?" | Calibrates success and shows you plan to ramp |
| R6 | "Where do new producers learn the season-pass economy here?" | Surfaces the ramp for the area you have said is new, and reads as diligence |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated, F9 | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Ran live events across two titles | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says one main title and content drops, not live events or two titles |
| Owned the post-event review or the KPIs | Inflated form of F5 | F5's quote at its own scope: the material says you presented the retention numbers. A4's slot asks only which part was yours |
| Managed releases with QA | Inflated form of F6 | F6's quote at its own scope: the material says you wrote the checklist QA still uses. B3's and D3's slots stay inside that |

## Sources

Provided: the JD you pasted, and your background in your message. No dossier was present.

Searches sent:

- "Saltmarsh Games values" returned https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games strategy mobile games news" returned https://saltmarshgames.com/news/project-larkspur (search snippet only; the page was not fetched)
- "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only; the page was not fetched)

Fetches sent: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both read in full.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and B1 to B3: the three values by official name |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: the Outage Hour tabletop plus a values conversation; persona weights and A1 to A5 follow it |
| 3. `Saltmarsh Games strategy` / recent news | yes | A3 and C3 and R1: Project Larkspur, a season-pass model and one shared calendar from February 2027 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read, D3, R2 and R3: his GDC 2026 talk and his QA background, from a snippet only |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Whether Tobias will be your direct manager → persona weights are rebuilt if he is not, and the reverse questions retune
- Anything the recruiter said about what the tabletop covers → A1 to A5 become specific to it instead of `[generic]`
- Which two titles the JD covers → A3, C4 and R1 become title-specific
- Your answers to the slots on F1, F3, F4, F5, F6 and F8 → those rows move from `[inferred]` or a thin quote toward `[grounded]`
- A sample of something you wrote for others to act on, such as a drop announcement or a checklist excerpt → F8 rises from low
- The retention report you presented, or any note on how its numbers were counted → F5 and F7 can reach high, and D1 and E2 gain real material
- Tobias's GDC talk read in full → a sharper R2 and D3
- A tuesday-dossier.md from an earlier evidence check → verified claims and a named top objection, replacing the inferred ones here
