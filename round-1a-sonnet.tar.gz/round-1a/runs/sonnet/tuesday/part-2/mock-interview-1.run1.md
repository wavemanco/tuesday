Search permission was declined, so I'm building the pack from your material alone and labeling it that way. I'm writing the pack file now.
I couldn't run that check, so I haven't verified the table shapes or stray brackets by script. I read the file as I wrote it and saw none.

The pack is saved at `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-1-denied-7993c544/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It has 22 questions, built for a single 60-minute peer conversation with Dan. Web search permission was declined for all four searches, so everything rests on your material and nothing was checked against Northwind's own pages.

- **Weighting:** Peer Evaluator and Data-Driven Prober lead. Case/Strategist and Skeptic come next, then Conversational, Pressure and Values. The pricing and monetization lean shapes the case questions.
- **Highest-ROI rehearsal (D2):** Dan's likely "I don't see sales ops or quota-setting in your background, and that's my world every day." It has the deepest rehearsal, including three follow-ups and exact concession wording.
- **The ~$400M claim (B1, F2):** The pack coaches Priya to say "proposed" and "credited with", never "led" or "drove". The "how was it counted" and "how much was you" answers are left as slots for her own words.
- **Volume targets:** The pack keeps "volume targets" separate from "quotas" throughout, so she doesn't stretch the claim.
- **Left out:** There is no values cheat sheet, prep triage, graded deliverable or delivery coaching, because nothing in your material triggers them. The pack says why.
- **Unverified:** Your research note on the three priorities and the bundling threat is undated, and I couldn't check it. Dan's public footprint wasn't established, so the interviewer read uses your description only.

The pack also includes a requirement-coverage table, seven reverse questions (including one tied to Dan's startup chapter and one reciprocity question), a prohibited-claims list and an upgrade menu.

Say the word and I'll play Dan as the Prober or Skeptic on D2 as a live drill. I can also save a `tuesday-dossier.md` with the gaps this prep exposed, or convert the pack to Word.

Two questions that would change the pack:
1. Could you paste the full JD text and the CV's own lines for the store-surface change, the revenue model, the volume targets and the SQL/Tableau work? Until then the pack stays at the scope of your highlights.
2. Did the recruiter mention any focus areas or a pre-work deliverable for this conversation?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy at Northwind Data, a peer (both report to the same VP). **Format:** one 60-minute conversation with Dan.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Behavior and values alignment: whether past behavior shows how you work with others |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny and what was actually yours |
| JD | Role and JD-driven: the stated responsibilities and requirements, gaps included |
| CO | Company and strategy knowledge: thinking at Northwind's altitude |
| CASE | A live problem from the role, scored on structure and reasoning |

The one item to rehearse above all others is **D2**, the sales-ops and quota objection. It is the single most predictable objection to this candidate, and Dan works in that territory every day. D2 gets the deepest rehearsal in the pack.

Sections left out, and why: prep triage (no prep time stated), graded deliverables (none announced), grounding brief (no research pass ran and the provided note is short), values cheat sheet (no values-style round is documented and no published values were read), delivery coaching (no assessment provided).

## Fit snapshot

The JD side is your highlights, not the full posting. There is no gate row, because none of the highlights states a term such as location, travel or pay.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | The material says product strategy and ops, not taking a product to market, and the words stay there: "For nine years I worked in product strategy and ops at a large consumer-tech company." Answer slot: the JD's two-new-product-lines line makes a probe on go-to-market work likely. If any of that work took a product to market, say what and how, in your own words; if none did, or it was not yours, say so plainly and stay with product strategy and ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The quote shows a proposal credited with an uplift, not a look across customer stages, and the words stay at that scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's land/adopt/expand/renew line makes a probe on stage-by-stage whitespace likely. If you have looked for whitespace across customer stages, say what you looked at and what you found; if you have not, or it was not yours, say so plainly and stay with the change you proposed |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | discovery | The quote names the tools and does not show whether any analysis was run independently. Answer slot: Dan's self-description makes a probe past the word skilled likely. If there is an analysis you ran yourself, say which and what you did at each step, in your own words; if the hands-on work was shared or someone else's, say so plainly and say which part was yours |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The quote shows a revenue model used in negotiations, not the design of a partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the required-experience line makes a probe on the motion itself likely. If any part of how the partnership operated, beyond the model, was yours to design, say which and how you decided; if the model was the extent of it, or the rest was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | Lead with the quote's own terms: "I set annual volume targets with cross-org consensus." It is a coach's-notes line with nothing inspected behind it, so expect a probe on how consensus was reached; the probe is rehearsed in A4 |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | discovery | The quote shows daily use and does not show whether any AI product or feature work sits behind it. Answer slot: a casual question about AI is likely and is scored. Say which tools and for what, in your own words; if the use is for your own productivity and not for building or shipping anything, say so plainly |
| F7 | Sales-ops and quota-setting fluency: not a JD line; raised by your note and by the interviewer's role | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it has been stated. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. The pack observes that F5's quote says volume targets, not quotas, and no row may treat them as the same thing |

## Reading the interviewer

Public footprint (talks, writing) was not established; every row below rests on your description of Dan.

| Signal | Source | Practical implication | Provenance |
|---|---|---|---|
| Director of Sales Strategy; a peer; same VP | your message | Peer Evaluator leads: seam-splitting, "what would you need from me", credit and disagreement. Offer reciprocity, not only asks | [inferred] — signal from your message, implication from the persona rules |
| Self-described "relentlessly data-driven" | Dan's profile as you described it | Every number is probed to its assumptions (B1 to B4). Know what you can and cannot say about how each figure was counted, and say plainly where you do not know | [inferred] — signal from your message, implication from the persona rules |
| Career spine in pricing and monetization | your message | Case answers land best in packaging, pricing and unit-economics terms (B5, C1 to C3). Mirror, paired with F4: "built a partner-level revenue model used in carrier negotiations". The revenue vocabulary overlaps; the model is not pricing work and the pack does not offer it as such | [inferred] — signal from your message, implication from the persona rules |
| One early-stage-startup chapter | your message | Expect a probe on large-company pace and on building without a playbook (D3). Reverse question R2 is tied to that chapter. No row carries a startup story of yours, so none is offered as a mirror | [inferred] — signal from your message, implication from the persona rules |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Peer Evaluator | Seam questions, "what would you need from me", credit, disagreement | Highest. Peer is the dominant prior for this relationship, and you report to the same VP | Reciprocity framing; propose seam principles instead of pretending to know the seam; disagreement stories with spine and tact |
| B. Data-Driven Prober | Reads your claims line by line, asks how numbers were counted, goes two levels deep | Highest. Peer prior, raised by "relentlessly data-driven" | Know what you can and cannot say about each number; name the weakest assumption you know of before Dan does; say plainly when you do not know |
| C. Case/Strategist | Live problems on Northwind's priorities; pricing and packaging angles | Medium. Not a peer prior, but the pricing and monetization spine and a strategy role pull it up | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| D. Skeptic | Quiet probing of F4, F7 and the large-company move | Medium. Your gaps sit in territory Dan owns | Rehearse D2 until it is boring; bridges only from what you stated; calibrated candor over bluffing |
| E. Conversational | Biography opener; casual AI question | Low to medium. A single 60-minute conversation usually opens with a walk-through; casual questions are still scored | Pre-script the 90-second arc; treat the AI question as scored; never leave the reverse-question slot generic |
| F. Pressure | Time-boxed, interrupting, attribution challenges | Low. No peer prior; the probing style of B can feel like it | Pause, restate, hold through two follow-ups, concede specifically |
| G. Values/Behavioral | Scenario probes about unpopular truths and trade-offs | Low. No values-style round is documented and no published values were read, so these are persona-model stems, not Northwind values | Selection scaffolds with an honest branch |

Loop note: your description of one 60-minute conversation with Dan is the loop source. If other rounds follow, persona weights shift (a values round would raise G).

## Question banks

### A. Peer Evaluator (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between what you'd own and what Sales Strategy owns, and what happens when we disagree?" | JD | [generic] | Do not pretend to know the seam. Ask what Dan's team owns today on the two lines, then propose principles: one named owner per decision, shared definitions for stages and metrics, disagreements argued from data both sides trust and taken to the shared VP only after that. Offer a first-month walk-through of the boundary. The question needs no claim about your past, so the guidance makes none | F1's requirement is the one that creates the seam, and the peer prior puts seam-splitting first. JD because it scores "own GTM strategy"; the peer delivery is the persona |
| A2 | "What would you need from me in your first ninety days?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Pair each ask with something you bring. Asks: how Sales Strategy defines its stages and which data it trusts. Bring: what the quote carries, which is that you built a partner-level revenue model used in carrier negotiations; ask Dan where it would and would not transfer. Say the limit yourself: a model, not a motion | F5's requirement is tested through reciprocity, and F4 supplies the only partner-side quote. JD because it scores cross-functional influence; peer delivery |
| A3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | Open prompt, so pick an instance: a time work spanned teams and credit was split or contested. It needs your own piece named exactly, the others' pieces named, and what you said about the split. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I set annual volume targets with cross-org consensus", or how you would handle credit going forward | F5 is the nearest evidence for cross-team work. VAL because it scores behavior toward equals, not a stated skill |
| A4 | "Tell me about a time you disagreed with someone in another org and had to land a shared answer." | JD | [grounded] "set annual volume targets with cross-org consensus" | The beats the quote states: annual volume targets, cross-org, consensus. Tell them in your own words. Answer slot: the question makes a probe on whether positions differed likely. If they differed, say what the disagreement was and how it was resolved, in your own words; if consensus came without one, or someone else brokered it, say so plainly and stay with the targets you set | F5's bridge needs a rehearsed answer for the probe it invites. JD because it scores cross-functional influence; spine-and-tact stories are the peer counter-strategy |
| A5 | "What would you bring to this team's work that it doesn't have today?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Frame it as an offer plus a question. Put on the table what the quote carries: you built a partner-level revenue model used in carrier negotiations. Do not claim Dan's team lacks anything; ask what it is short of. Limit, said by you: a model, not pricing work | F4 is the only quote that gives Dan something concrete to evaluate. JD because it scores the role's partner dimension; reciprocity is the peer counter-strategy |

### B. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The ~$400M ARR uplift credited to the store-surface change you proposed: walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open with the sentence at its own scope: you proposed the change, and it was credited with the uplift. Then four slots, each in your own words, none supplied here: how the number was counted; what it is sensitive to; the assumption behind it you would defend least, named before Dan names it; and which part was yours. Where you do not know how it was counted, say so plainly. Keep "proposed" and "credited" as written | F2 holds the pack's only headline metric, and a self-described data-driven interviewer will go to it first. EXP because it tests whether the claim survives scrutiny |
| B2 | "Walk me through the partner-level revenue model you built for the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | The beats the quote states: a model, at partner level, used in carrier negotiations. Describe it only as far as you actually know it. Answer slot: the JD's partner-motion line makes a probe on whether anything beyond the model was yours likely. If any part of how the partnership operated was yours to design, say what; if the model was the extent of it, or the rest was not yours, say so plainly and stay with the model | F4 is the evidence for a required experience and the likeliest place for a probe on attribution. EXP because it tests what was actually yours |
| B3 | "Tell me about an analysis you took from question to answer in SQL or Tableau." | JD | [grounded] "skilled in SQL/Tableau" | Open prompt, so pick an instance: one where you wrote the queries or built the view yourself, with a named question and a decision it informed. Say what you did at each step. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries, "skilled in SQL/Tableau", or how you would approach one | F3's quote names tools only, so the probe goes past the word skilled. JD because it scores the stated requirement |
| B4 | "Walk me through how the annual volume targets got set." | EXP | [grounded] "set annual volume targets with cross-org consensus" | The beats the quote states: you set annual volume targets, with cross-org consensus. Answer slot: expect a probe on where the targets came from. If you can say where the numbers came from and who had a say, say it in your own words; if you cannot, or it was not yours to decide, say so plainly and stay with the quote. Do not call them quotas | Targets are Dan's native ground, so F5's claim will be pressed here, and F7 sits right beside it. EXP because it tests what was actually yours |
| B5 | "A new product line shows strong expansion but flat renewals. What do you pull first, and how would you cut it?" | CASE | [generic] | Think aloud. State a hypothesis early. Clarify first: how renewal and expansion are defined, and whether they are measured on the same customers and period. Then structure: cohorts by land date, depth of adoption, where expansion came from, and whether it was price or packaging led, which is Dan's lens. Say how you would pull it in SQL and show it in Tableau as a plan. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The JD's land/adopt/expand/renew line and the SQL/Tableau line (F2, F3) both land here, and a data-driven interviewer favors a diagnosis problem. CASE because it is a live problem; the Prober persona is who delivers it |

### C. Case/Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "If you could put real weight behind only one of enterprise expansion, the Compass launch or reaching profitability in your first ninety days, which, and how would you decide?" | CO | [grounded] (your research note: the three stated priorities) | Clarify first: which two product lines the role covers, and whether Compass sits in one of them; do not assume. Then state criteria before choosing: size of the whitespace, time to revenue, effect on margin, and dependence on the other two. Choose, and name what you would deliberately deprioritize and why. Add one premise you would test. This is the shared public-style answer, so bring one consensus point to show you did the homework, then your own divergence. The question needs no claim about your past | The three priorities are the company-altitude test, and F1's requirement is about owning strategy for the new lines. CO with CASE delivery; grounded on your note, which is undated and unchecked |
| C2 | "A much larger platform vendor starts bundling something like what we sell into its suite. What does that do to land, adopt, expand and renew on a new product line, and where do you look first?" | CO | [grounded] (your research note: bundling by a much larger platform vendor) | Go stage by stage and state each as a hypothesis to test, not a fact: which stage does bundling pressure first, and what would you look for in the data to tell. Use Dan's pricing and packaging lens: where does standalone price or packaging matter, and where does integration depth matter. Say what you would look at first and why. The question needs no claim about your past | The bundling threat is the stated competitive frame, and F2's requirement maps to the same four stages. CO because it needs strategy fluency; CASE delivery |
| C3 | "We're launching a product line with no installed base. How would you design the partner motion?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Clarify what kind of partners (resell, refer, integrate) and what the line needs from them. Then objective, partner segments, the economics each side would need, a small pilot, metrics, risks. Say the one fact the quote carries, that you built a partner-level revenue model used in carrier negotiations, and its limit: a model, not a motion. Everything else is how you would design it, said as a plan | F4's requirement is marked required, so a live design problem is how it is tested. JD content, CASE delivery |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Name one that is true, calmly, before Dan does. The pack's reading is that F4 and F2 are the thinnest rows, but pick the one you believe. Say what your material carries at its scope (for F4, a model used in carrier negotiations), say the limit, then give a ramp plan as a plan: who you would ask, what you would read, what you would want to have drafted by day thirty. Do not offer a weakness you do not have. If a different requirement is your real weakest, say that one | F4 is the required experience with the thinnest evidence. JD because it scores the posting's own list; Skeptic delivery |
| D2 | "I don't see sales ops or quota-setting anywhere in your background, and that's my world every day. Where does that leave you on day one?" | EXP | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal in the pack.** Hold only what the quotes carry. Open with the plain acknowledgment: "I haven't had classic sales-ops or quota-setting experience." Then one sentence, "What I have done is set annual volume targets with cross-org consensus," and stop; do not say it is equivalent. Follow-up 1, "Volume targets aren't quotas, reps fight quotas": agree they differ; answer slot: if any of those targets was contested between teams, say what and how it was resolved; if not, or it was not yours, say so plainly. Follow-up 2, "What do you need from me so you don't slow us down?": ask for a walk-through of how quotas and capacity are set and where they break, and say what you would take off Dan's plate as a plan. Follow-up 3, "What's the first thing you'd get wrong?": name the one thing you would least trust yourself on, in your own words. Concession wording: "Quota mechanics are the part I'd be learning from you, not teaching." Limit, named before it is asked: your material says volume targets, not quotas. Never fold on the quote itself; never stretch it | F7 is the stated gap and F5 is the nearest quote, so this objection arrives in some form from a Director of Sales Strategy. EXP because it tests what your claim actually covers; it is the deepest item because it hits where the material is thinnest |
| D3 | "You've spent nine years at a large company, and these are two new product lines. Tell me about a time you built something where there was no playbook." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "proposed a store-surface change credited with a ~$400M ARR uplift" | Open prompt, so pick an instance: something you started without a template, with the gap you saw, what you did first, and who you needed. If the store-surface proposal is the nearest thing, tell it only as the quote has it: you proposed the change and it was credited with the uplift. If no such time comes to mind, say so plainly, then say how you would start with no playbook | The JD's two-new-product-lines line raises building without a playbook, and a large-company career invites a pace probe (F1). EXP because it asks for an actual instance |

### E. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey: consulting, then nine years in consumer tech, and now Northwind. What's pulling you here?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc built from the quote's beats: two years of strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company. Then your own reason for the move, in your own words, tied to something true about this role; say only what you would say to a friend. Do not add a reason that is not yours | The biography question opens most conversations, and it is scored. EXP because it tests the career story's consistency |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it at the quote's scope: you use AI tools daily. Answer slot: name which tools and what for, in your own words. If the use is for your own work and not for building or shipping something, say so plainly. Do not describe Compass or any AI product you have not worked on; asking Dan what he sees in it is fine | F6's plus is asked casually here. JD content in a casual register |

### F. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Pause, restate the question, then make a fit statement, not a comparison. Use the two quotes at their scope: a partner-level revenue model used in carrier negotiations, and annual volume targets set with cross-org consensus. Concede that an internal candidate knows Northwind better. Hold through two follow-ups by returning to what you have said you did, never by running down an internal candidate | The peer prior is low on Pressure, but a time-boxed challenge is the easiest way to test composure. JD because it scores fit against the role; F4 and F5 supply the quotes |
| F2 | "That ~$400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed the change. It was credited with a ~$400M ARR uplift." Concede specifically. Answer slot: if you know how the credit was attributed, say how, in your own words; if you do not, or the credit was not yours to assign, say so plainly. Hold through two follow-ups by returning to proposed and credited; never upgrade to led or drove | The attribution probe is the most standard stress question on a headline figure (F2). EXP because it tests how much of the claim was yours |

### G. Values/Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Open prompt with no quote carrying a story, so this is a selection scaffold: pick a time where the stake was named, the message was hard, you did not fold, and the relationship was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | A persona-model stem, kept low because no values-style round is documented. VAL for what it scores |
| G2 | "When did you put a partner or customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a decision where the partner or customer cost was visible, the internal metric was named, and you can say what you chose and why. If no such time comes to mind, say so plainly, then say what you would weigh | A persona-model stem, kept low for the same reason. VAL because it scores a trade-off, which matters more once partners are in scope |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | A1, C1, C2, C3, D3 |
| identify whitespace across land/adopt/expand/renew | B5, C2 |
| run independent analysis in SQL and Tableau | B3, B5 |
| partner-motion design experience required | B2, C3, D1 |
| strong cross-functional influence | A1, A2, A3, A4, A5, B4 |
| AI experience a plus | C1, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which two product lines does this role cover, and is Compass one of them?" | Fixes the one fact C1 depends on and shows you listened to the stated priorities |
| R2 | "You've spent much of your career in pricing and monetization and had a stint at an early-stage startup. How did that shape where you'd draw the line between pricing, partner and sales-strategy decisions on new products?" | Ties to Dan's own path and turns the pace probe into a peer conversation |
| R3 | "What could someone in this role do in the first month that would genuinely help your team?" | The reciprocity question for a peer; it shows you are pricing what you cost him |
| R4 | "Of enterprise expansion, Compass and profitability, which is most constraining on how the new lines go to market right now?" | Shows you read the priorities and asks for the live trade-off, not the slogan |
| R5 | "Where does bundling by the larger platform vendor show up in deals you see today: at land, or mainly at renewal?" | Tests the competitive frame against what Dan sees on the ground |
| R6 | "Where would you most want a new GTM lead to push back on your team's assumptions?" | Invites a collegial disagreement and signals spine with tact |
| R7 | "What would a good first ninety days look like to you and to our VP?" | Aligns to the shared boss and surfaces any gap between the two views |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led, drove or delivered the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope. The pack's observation: the material says proposed and credited, not led or delivered. B1 and F2 stay inside the quote |
| Has sales-ops or quota-setting experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot |
| The volume targets were quotas | Inflated form of F5 | F5's quote at its own scope. The pack's observation: the material says volume targets, not quotas. B4 and D2 stay inside the quote |
| Designed or owned partner motions | Inflated form of F4 | F4's quote at its own scope. The pack's observation: the material says a revenue model, not a motion. B2 and C3 stay with the model |
| Has AI product or GTM experience | Inflated form of F6 | F6's quote at its own scope: you use AI tools daily. E2 asks only what tools and what for |
| Has taken products to market or run whitespace analysis across customer stages | Inflated form of F1 and F2 | F1 and F2's quotes at their own scope. The pack's observation: the material says product strategy and ops, and a proposed change, not go-to-market or stage-by-stage analysis |

## Sources

Provided documents: your message, which holds the JD highlights, the candidate summary (cited as the coach's notes), the interviewer profile, and your research note on Northwind's three stated priorities and the bundling threat. The research note is undated, and its freshness could not be checked. No dossier was present, so none was consumed.

Searches sent, all refused (search permission was not granted):

- `Northwind Data company values` — refused
- `Northwind Data interview process strategy GTM` — refused
- `Northwind Data Compass AI copilot launch enterprise strategy` — refused
- `Dan Kovac Director of Sales Strategy Northwind Data` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The search was refused. It would have supplied published value names for VAL themes; it would only have fed a cheat sheet if a values-style round were documented, and none is |
| 2. `Northwind Data interview process` | unavailable | The search was refused. It would have shown whether other rounds follow; your own words fix this conversation, so persona weights rest on that |
| 3. `Northwind Data strategy` / recent news | unavailable | The search was refused. It would have checked your note's freshness and added detail for C1 and C2; they rest on your note alone |
| 4. `Dan Kovac Northwind Data` | unavailable | The search was refused. It would have added public talks or writing to the interviewer read; that section rests on your description alone |
| 5. representative `Senior GTM Strategy Lead` JD | unavailable | No call was sent after the four refusals. It would have added requirements beyond your highlights as `[inferred]` rows |

## Upgrade menu

- Full JD text → the six JD rows are built from your highlights; the full text could add requirements, including any gate such as location, travel or pay, and would let every JD-tagged question quote the posting itself
- The CV's own lines for the store-surface change, the revenue model, the volume targets and the SQL/Tableau work → upgrades F1 to F6 from coach's-notes quotes to the CV's own words and may make the answer slots in B1, B2, B3 and B4 answerable
- Your answers to the answer slots (what you actually did in F1, F2, F3, F4 and F6) → each answer, once you state it outside a drill, enters the fit snapshot as a quote and regenerates the rows that draw on it
- Recruiter or HR guidance, such as stated focus areas or a pre-work deliverable → replaces the coverage assumed from the peer prior and adds a build section for any announced deliverable
- Search access, then a research pass (default budget 6 searches and 2 fetches; a deeper pass adds up to 6 searches, 2 fetches and several more minutes) → Northwind's published values and any documented loop, a fresh check of your strategy note, and Dan's public talks or writing for the interviewer read
- A `tuesday-dossier.md` from an earlier evaluation of this role → adds an evidence-graded map and a named top objection to replace the one inferred here
