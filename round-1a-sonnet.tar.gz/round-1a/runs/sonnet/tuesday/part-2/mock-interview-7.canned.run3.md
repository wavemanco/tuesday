Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-7-canned-ee5b321c/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it on the assumption that Tobias runs the whole 60 minutes as Saltmarsh's "Outage Hour": a live-incident tabletop, then a values conversation.

Say the word and I'll play the Skeptic on C2, the season-pass and no-in-app-purchases question. The pack names it as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, or someone you'd work alongside? The answer reweights every bank. Did the recruiter say anything about what the outage tabletop will cover? That would let me rebuild the A bank on the real scenario.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Built as a hiring-manager round, 60 minutes, for Friday. Candidate: Femi.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. Every question carries one persona letter, one type tag and a provenance label.
- Type key: VAL is values alignment, EXP is work-experience deep-dive, JD is role and requirement-driven, CO is company and strategy knowledge, CASE is a live problem.
- Guidance is scaffolding, not a script. Where it quotes you, those are your own words from your message; where it shows an answer slot, the answer has to come from your own experience.
- Rows labeled generic make no claim about you or the employer. Rows labeled inferred name their derivation.

## Prep triage (Tuesday to Friday)

1. Tuesday: read Saltmarsh's values page and the full Project Larkspur announcement (this pack used only the announcement's summary line, so read the page itself). Then work through C2 aloud.
2. Wednesday: C2 and C3 aloud until they are boring, ideally recorded. Then A1 aloud three times as a first-thirty-minutes structure.
3. Thursday: for B1 to B3, either pick a real story or rehearse the honest branch. Rehearse A4. Choose three reverse questions.
4. Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | The quote carries four years as an associate producer, and the material does not show whether the studio's title was a live service. Words: "For four years I was an associate producer at a puzzle-game studio." Answer slot: the JD's live-service wording makes a probe on this likely. If the title was a live service, say what made it one, in your own words; if it was not, or not in the way the JD means, say so plainly and stay with the weekly content drops in F2 |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a self-report with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: "For the last two years I ran the weekly content-drop calendar for our main title." A cadence and a duration beat an adjective |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Adjacent work: the quote says weekly content drops for the main title, while the JD says live events across two titles. Use your own words and let them map it: "I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles wording makes a probe on scope likely. If you ever planned or coordinated across more than one title's calendar, say how, in your own words; if you did not, say so plainly and say what you would need to know first |
| F4 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap, with nothing inspected behind it. Lead in the quote's terms: you presented the monthly retention numbers to the studio head. Your material gives no figure, so the pack coaches no number. Expect probes on which numbers and how they were counted (E1, D1) |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | low | [inferred] | discovery | Presenting retention numbers touches the KPIs a review reports and shows nothing about a post-event review. Answer slot: if there was a review after a drop or an event, say how it ran and what part was yours; if there was none, or it was not yours, say so plainly and stay with presenting the monthly retention numbers |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Words: "I wrote the release checklist our QA team still uses." The material says wrote it and still used, and does not say who ran releases against it. Answer slot: the JD's manage-with-QA wording makes a probe on how the checklist was used at release likely. If you ran releases against it with QA, say how; if you did not, or others ran it, say so plainly and stay with having written it |
| F7 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | The quote touches the drops these teams would have worked toward and shows nothing about who coordinated them. Answer slot: if design, art, engineering or community worked to your calendar, say how you got them to, in your own words; if that was someone else's job, or the teams did not work that way, say so plainly and stay with having run the calendar |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | Reword only the quote: "I wrote the release checklist our QA team still uses", a document other people work from. Say it in those terms and add nothing to it |

No row is a gate: the JD states no location, schedule, pay or authorization term. Your message also says "Never led a team, and never worked on a game with in-app purchases." Neither is a JD requirement as quoted, so both are handled in the Skeptic bank (C2, C3) and the prohibited list rather than as snapshot rows.

## Reading the interviewer

| Public fact | Source | What it means for you |
|---|---|---|
| Head of Live Operations at Saltmarsh Games; GDC 2026 talk titled "Patch Notes Are a Promise" | Search result for the talk, talks.gdconf.example/2026/patch-notes-are-a-promise (summary only, page not fetched) | Expect the theme of what is announced against what actually shipped, which sits beside the company's value "we announce what is built, not what is hoped". Describe what you did at its true size |
| His argument, as summarized: a live team is judged by how often its patch notes describe what actually shipped | Same result | A claim that outruns your own account will be tested against that standard; B2 and the prohibited list are the rehearsal |
| Described in the same summary as previously a QA lead at a console studio | Same result | The release checklist is likely familiar ground for him. Your own words on it are F6: "Wrote the release checklist our QA team still uses". Say that and no more, and expect a probe on how it was used at release |
| Shared jump | None offered | Your material carries no sentence for your side of a career jump like his, so none is offered as a mirror opportunity |

## Persona table

The loop rests on Saltmarsh's own interviewing page, which describes one 60-minute session with the hiring manager: a live-incident tabletop on a simulated outage during a live event, then a values conversation, and no take-home. The weights below follow that page, not an archetype. I assumed Tobias runs the whole session; if he does not, tell me and the banks reweight.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The outage tabletop, plus a question on the shared calendar | High. Hiring-manager prior, and the page documents the tabletop as the session's first half. Questions: 5 | Clarify, then objective, then segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Values / Behavioral | The values conversation after the tabletop | High. The page documents a values conversation in this session, and the company publishes three values. Questions: 4 | Map a story to each value only where your own sentences carry one; otherwise rehearse the selection scaffold and its honest branch |
| C. Skeptic | The gaps: season-pass model, never led a team, associate-producer level | Medium-high. Hiring-manager prior, and your message states two gaps. Questions: 3 | Rehearse the single most predictable objection until it is boring; concede plainly; return to what your sentences carry |
| D. Pressure | Time-boxed challenge on attribution and fit | Low. The tabletop format may carry some of this register. Questions: 2 | Pause, restate, hold through two follow-ups, concede only the specific limit |
| E. Data-Driven Prober | Retention numbers and the post-event review | Low. The JD names retention metrics and the review, and nothing public says he reads CVs line by line. Questions: 2 | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| F. Conversational | Opening biography, written communication | Low. Casual register, still scored. Questions: 2 | A 90-second arc built only from your own sentences |

Peer Evaluator is left out: nothing here suggests a peer round.

## Question banks

Provenance quotes are your own sentences from your message. Answer slots end without a question because they are instructions for the interview, not questions for this conversation.

### A. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day two of a live event, reward claims are failing for a share of players and the community channels are filling up. You're the producer on call. Talk me through your first thirty minutes." | CASE | [generic] | Clarify first: what is failing, for whom, since when, and whether it is spreading. State the objective aloud: stop players being hurt, then fix. Name who you pull in by discipline and what you ask each: engineering for the fix, QA to confirm it, community for what players are seeing. Decide what you tell players first, saying only what is confirmed, in the spirit of the company's own value, "we announce what is built, not what is hoped". Close with what you record for the post-event review. Think aloud and challenge one premise, such as whether the event should pause. The question needs no claim about your past, so the guidance makes none | The page documents a simulated-outage tabletop as the session's first half, so this is the likeliest shape of the opening. Saltmarsh's actual scenario is unknown, so this is generic rehearsal, not a prediction. CASE because it scores structure |
| A2 | "The outage is fixed, but players want the event extended. The next event starts in two days and art and engineering have committed to it. What do you do?" | CASE | [generic] | Name your decision rule first, using the published value "when the calendar and the players disagree, the players win". Then test it: what players actually lost, what an extension costs the next event, and who has to agree. Say the trade-off aloud rather than pretending it is free, give a recommendation and what would change your mind, and say what players hear and when. The question needs no claim about your past, so the guidance makes none | The first published value is built around exactly this conflict, so a tabletop is a natural place to test it. Generic because the scenario is invented for rehearsal |
| A3 | "For that outage, what goes in the post-event review, and which numbers would it report?" | JD | [generic] | Walk the review in order: timeline, player impact, cause, what changes in the checklist so the next release leaves it better than it found it (the company's own phrasing is that every release leaves the checklist better), and who owns each follow-up. Name the KPIs you would report and why, and name in your own words the assumption you would trust least behind your headline number. The question is a live problem and the guidance makes no claim about your past | Covers the JD's post-event review and KPI line (F5). JD content with a CASE delivery, because it asks for a structure rather than a history |
| A4 | "From February 2027 we run one shared events calendar across both titles with a single live-ops group. Sketch how you would plan its first quarter. What do you need to know first?" | CASE | [inferred] | Clarify first: which events are shared and which stay per-title, how the season-pass cadence sets the calendar's spine, who owns the calendar once per-title event teams are folded in, and where art, engineering and QA windows collide. Then objective, segmentation (shared against title-specific), approach, metrics, risks. Challenge one premise politely, such as whether one calendar serves two player bases equally. If what Tobias tells you differs from the announcement, follow him. The question needs no claim about your past, so the guidance makes none | Grounded in the current-strategy target: derived from the one-line Project Larkspur summary returned by search, not from the full page. Strategy questions are where a prepared candidate separates from the field, so CASE with a CO flavor |
| A5 | "It's the night before an event goes live and QA marks one checklist item red. Engineering says it's low risk. Walk me through it." | JD | [grounded] "Wrote the release checklist our QA team still uses" | Clarify the item and what a failure would do to players; ask QA what they saw and engineering what low risk rests on. Lay out the options: ship with a mitigation, ship without the feature, or delay. Say who decides and what you recommend. Hold two points: QA's red stays on the record either way, and what players are told matches what ships. If you mention your own checklist, say only what the quote says: you wrote it and QA still uses it | Covers the JD's manage-the-checklist-with-QA line (F6). JD content, CASE delivery. The checklist is also the natural bridge to the interviewer's QA background, per the interviewer read |

### B. Values / Behavioral (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Players Before Plans. Tell me about a time the calendar and the players disagreed, and what you did." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Your sentences carry no such occasion, so this is a scaffold: pick a time a drop's date or content ran against what players needed. It needs a named stake, what you changed, and what it cost the calendar, told with we for context and I for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is having run the weekly content-drop calendar for the last two years, or say how you would decide | One of the three published values; the loop page documents a values conversation. F2 is the nearest evidence. VAL because it scores whether behavior shows the published value |
| B2 | "Ship the Patch, Not the Promise. Tell me about a time you told players or leadership only what was built, not what was hoped." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Scaffold: pick an occasion where you held back an announcement or a figure until it was confirmed. It needs a named stake, the pressure to say more, and what you said instead. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is presenting the monthly retention numbers to the studio head, or say how you would decide what to announce | Second published value, and the theme of the interviewer's public talk. F4 is the nearest evidence, held at its own scope |
| B3 | "Leave the Build Greener. When have you left a checklist or a process better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F6: you wrote the checklist, and QA still uses it. Those are the beats the quote states; tell them in your own words. Answer slot: the value's checklist wording makes a probe on how the checklist changed after releases likely. If it changed, say what changed and why, in your own words; if it was never revised, or the revisions were not yours, say so plainly and stay with having written it and QA still using it | Third published value, which names the checklist directly. F6 is the evidence. VAL because the value is the scoring frame |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped on F4: you presented the monthly retention numbers to the studio head. Answer slot: a probe on whether any month's numbers were unwelcome is likely. If any were, say what you told them and what happened, in your own words; if none were, or the numbers were produced by others, say so plainly and stay with presenting them monthly. Choose a story where the hard truth actually landed; where your material shows none, say so rather than supplying an ending | A standard values-round question that pairs with the interviewer's patch-notes theme. VAL because it scores candor under pressure |

### C. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" and "Never led a team, and never worked on a game with in-app purchases." | Pick the requirement where your material is thinnest; F5 and F7 show it. Answer as a plan: where no step of yours is on record, say so plainly, then say what you would do in your first weeks. If you bring up the season-pass side, the words are "I haven't worked on a game with in-app purchases", followed by the ramp, said as a plan and never as a past | A standard Skeptic stem. JD because it scores the stated requirements, including the gaps; F1 is the title-level exposure |
| C2 | "Saltmarsh is moving Tidepool Tactics and Lantern Row to a season-pass model from February. You haven't worked on a game with in-app purchases. What would you need to learn first?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." | **Highest-ROI prep in this pack.** Say the concession once and flat: "I haven't worked on a game with in-app purchases." Then answer the question asked: what you would ask first, about how the pass sets the event cadence, what the team already tracks, and what a producer may and may not decide. Follow-up one is likely to be that you can't say how events should work with the pass. Hold: correct, not from experience, and here is how you would find out. Return to the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Follow-up two is likely to be why they should take the risk. Concede the specific limit again, say what you would ask for in your first weeks as a plan, and do not argue that your calendar work proves anything about purchases; say what you did and let them draw the inference. The limit, named before it is asked: your material shows no exposure to purchases at all, so do not reach for an adjacent claim you cannot state in your own words | The season-pass move is the likeliest reason a Skeptic presses on a gap you stated yourself. This is inferred, since no dossier named an objection, and it sits where the material is thinnest, which is why it gets the deepest rehearsal. CO because the company's strategy supplies the premise |
| C3 | "You've never led a team. This role coordinates design, art, engineering and community on every update. How do you get four disciplines to move to your calendar when they don't report to you?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years" | Plain acknowledgment first: "I haven't led a team." Then hold on what the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's coordination line makes a probe on how the disciplines worked to your calendar likely. If design, art, engineering or community worked to your calendar, say how you got them to, in your own words; if that was someone else's job, or it did not work that way, say so plainly and stay with having run the calendar. Hold through two follow-ups by returning to the quote, never by adding to it | Covers the JD's coordination line (F7), the second thing your message says you have not done. JD because it scores a stated responsibility |

### D. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented the monthly retention numbers to the studio head. How much of that was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Pause, restate, then hold the quote: "I presented the monthly retention numbers to the studio head." Answer slot: if you built or analyzed any of them, say which part and how, in your own words; if the numbers came from someone else and you presented them, say so plainly and stay with presenting them each month. Hold through two follow-ups by returning to the quote, never by adding to it, and concede the specific limit, not the whole. Name in your own words the assumption you would trust least behind any figure you presented; if you do not know how they were counted, say so plainly | The attribution probe F4 invites. EXP because it scores what was actually yours |
| D2 | "Sixty seconds: the JD has you running the calendar for two titles. Why you?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Pause, restate, then: "For the last two years I ran the weekly content-drop calendar for our main title." State what you did and let them draw the inference; do not tell them it proves you can do two. Answer slot: if you ever planned across more than one title, say how; if you did not, say so plainly and say what you would need to know first (A4). Hold through two follow-ups by returning to the quote | Pressure version of the scope gap in F3. JD because it scores the stated calendar requirement (F2, F3) |

### E. Data-Driven Prober (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The JD asks for comfort with player-retention metrics. Walk me through the monthly retention numbers you presented: which ones, and how were they counted?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Start from what the quote carries: you presented the monthly retention numbers to the studio head. Answer slot: the JD's retention wording makes a probe on which measures and how they were counted likely. If you chose or defined them, say which and how, in your own words, and name the assumption you would trust least; if they were defined elsewhere, or you do not know how they were counted, say so plainly and stay with presenting them each month | Covers the JD's retention requirement (F4). No figure in your material, so this is a method probe, not a defend-the-number row |
| E2 | "The JD has you owning the post-event review and the KPIs it reports. Walk me through how you reviewed a content drop after it shipped." | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: the JD's review wording makes a probe on this likely. If there was a review after a drop, say how it ran, what it reported and what part was yours, in your own words; if there was none, or it was not yours, say so plainly and stay with presenting the monthly retention numbers. Do not describe a review step you did not take | F5 is the thinnest row against a stated duty, so the probe is likely. JD because it scores that duty |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey: how did you get from where you are to this role?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years" and "Wrote the release checklist our QA team still uses" and "Presented the monthly retention numbers to the studio head" | A 90-second arc with four beats in order: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for the last two years, the release checklist QA still uses, and presenting the monthly retention numbers. Why live ops at Saltmarsh and why now are yours to say, in your own words; this pack cannot supply a reason. Answer slot: if there is a part of the journey the interviewer should hear that these sentences do not carry, say it plainly in your own words. End on the role, not on a claim | A casual opener that is still scored, and the place the biography gets set. F1 to F4 hold the beats |
| F2 | "The JD asks for clear written communication. What have you written that other people work from?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F8: you wrote the release checklist, and QA still uses it. Say what the quote says and stop; a named document that is still in use is the evidence. If asked what made it clear, answer in your own words; if you do not know beyond QA still using it, say so plainly. Check what you may share before the interview in case they ask to see it | Covers the JD's written-communication line (F8). JD because it scores the stated requirement; casual register |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| 3+ years producing live-service games or apps | C1, F1 |
| experience running a content calendar | D2, B1 |
| comfortable with player-retention metrics | E1, D1 |
| clear written communication | F2 |
| plan and run the live-events calendar for two titles | D2, A4 |
| coordinate design, art, engineering and community on each update | C3, A1 |
| own the post-event review and the KPIs it reports | E2, A3 |
| manage the release checklist with QA | A5, B3 |

Your material gives no headline figure, so there is no defend-the-number row. If you have one, it is an upgrade-menu line below.

## Values cheat sheet

Values are quoted from Saltmarsh's published page; the loop page documents a values conversation.

| Value | Working meaning | Your mapped story or scaffold |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Scaffold (B1): pick a time a drop ran against what players needed, with a named stake and a cost to the calendar. If none comes to mind, say so plainly, then F2's "I ran the weekly content-drop calendar for our main title for the last two years" at its own scope |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Scaffold (B2): pick an occasion where you held a figure or announcement back until it was confirmed. If none comes to mind, say so plainly, then F4's "Presented the monthly retention numbers to the studio head" at its own scope |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | Story-mapped (B3): F6's "Wrote the release checklist our QA team still uses", with the answer slot on whether it was revised after releases |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Project Larkspur describes one shared events calendar and a single live-ops group from February. Where does this role sit in that, and does it plan per title or for the shared calendar?" | Shows you read the announcement, and the JD's wording is about two titles, so the answer tells you what you would actually be running |
| 2 | "In your GDC talk you argued a live team is judged by how often its patch notes describe what actually shipped. How does your team measure that today?" | Ties to his own public work and turns an interview into a conversation about his thesis |
| 3 | "You have a QA background. What did it change about how you want producers to run the release checklist?" | A question tied to his own path; ask it only if his QA background is confirmed from his own profile or the talk page, since this pack saw it in a summary only |
| 4 | "What does a good post-event review produce here? What has changed because of one?" | Maps to the JD's review duty and to the value about leaving the checklist better, and it shows you think of the review as a lever, not a report |
| 5 | "Given the move to a season pass, who would a new producer learn the monetization side from?" | Names the gap without confessing it, asks for a ramp path, and answers something you genuinely need to know |
| 6 | "What would a good first event look like for a new producer, and who across design, art, engineering and community would I work with most?" | Ties to the JD's coordination line and shows you are already planning the first month |

## Prohibited claims

Built from the fit snapshot before the banks were written. No guidance, slot, bridge or rationale coaches these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked on a game with in-app purchases, or has monetization experience | Negative you stated: "Never led a team, and never worked on a game with in-app purchases." | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan. No slot |
| Has led a team or managed people | Negative you stated: "Never led a team, and never worked on a game with in-app purchases." | The plain acknowledgment: "I haven't led a team." Then C3's slot, inside the calendar you ran |
| Ran the live-events calendar for two titles | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says the weekly content-drop calendar for the main title, not two titles. D2's slot stays inside that quote |
| Defined, owned or produced the retention numbers and KPIs | Inflated form of F4 and F5 | F4's quote at its own scope. The limit is the pack's observation: your material says presented, not defined or computed. E1 and D1's slots stay inside the quote |
| Managed releases with QA, or owned the release process | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your material says wrote the checklist and still used, not ran each release. A5 and B3's slots stay inside the quote |

## Sources

Provided: the JD and your background as written in your message. No tuesday-dossier.md was present; the pack was built from raw inputs.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Queries sent:
- "Saltmarsh Games values" returned saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer" returned saltmarshgames.com/careers/interviewing
- "Saltmarsh Games strategy mobile news" returned saltmarshgames.com/news/project-larkspur
- "Tobias Wrenfield Saltmarsh Games" returned talks.gdconf.example/2026/patch-notes-are-a-promise

Fetched: saltmarshgames.com/values and saltmarshgames.com/careers/interviewing. The Larkspur announcement and the talk page were read only as search-result summaries and not fetched.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet: three values by name, B1 to B3 |
| 2. Saltmarsh Games interview process, live operations | yes | Loop: one 60-minute session, tabletop then values conversation, no take-home; persona weights and A and B banks |
| 3. Saltmarsh Games strategy and recent news | yes | A4 and C2, from the Project Larkspur summary line only |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Interviewer read and reverse questions 2 and 3, from the talk summary only |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The release checklist itself, or a redacted copy, or another document you wrote that others work from → F6 and F8 move toward high confidence, since a document is the inspectable proof for this field
- Any figure from the retention work, and how it was counted → a defend-the-number row, and F4 and F5 get firmer evidence
- Your own answers to the slots in F1, F3, F5, F6 and F7, said outside a drill → those rows become story maps instead of slots
- The recruiter's note on what the Outage Hour tabletop covers → A bank rebuilt on the real scenario instead of generic ones
- The full Project Larkspur page and Tobias's talk, pasted → A4, C2 and the interviewer read rest on the pages instead of summaries
- Any term the recruiter named, such as location, schedule or pay → gate rows in the snapshot
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on Saltmarsh's strategy and Tobias's public talks, and sharper A4 and C2
- A tuesday-dossier.md from an earlier pass → verified evidence and a named top objection in place of the inferred one
