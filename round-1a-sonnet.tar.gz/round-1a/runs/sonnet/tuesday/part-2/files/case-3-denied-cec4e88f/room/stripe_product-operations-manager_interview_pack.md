# Interview prep pack: Product Operations Manager, Stripe (final round)

Interviewer: not given. Relationship: not given. Built as a session-mode pack with blended persona weights.
This pack contains no facts about Stripe, because no research ran and no documents were supplied. Everything is a pattern for the role, labeled `[generic]`.

## How to use this pack

- **Personas are how a question is asked; types are what is scored.** Every question carries one persona (its letter) and one type tag.
- Types: **VAL** = behavior against published values. **EXP** = a work-experience deep-dive. **JD** = role and responsibilities. **CO** = company and strategy knowledge. **CASE** = a live problem.
- Guidance is scaffolding, not a script. You gave no CV, so no guidance cell tells you what you did. Each one is a way to choose a story from your own history, and each ends with an honest branch for when none fits.
- The question the pack ranks highest for rehearsal is **A1**.

## Fit snapshot (worksheet)

You gave no CV and no JD, so this is the worksheet variant. The requirements are role-family patterns written as plain prose, not quotes from a Stripe posting. Every evidence cell is empty until you give your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate launches or releases across several teams (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is one named launch or release you coordinated, the teams involved, and your own part in it. Selection scaffold: pick a launch where several teams needed different things from you; if no such launch comes to mind, say so plainly, then give the nearest coordination work you have done, or how you would run one |
| F2 | Build and run an operating cadence such as planning, reviews and roadmap communication (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a recurring process you set up or ran, with who used it and what changed because of it. Selection scaffold: pick a rhythm you ran for more than one cycle; if none comes to mind, say so plainly, then give the nearest recurring process you have been part of, or how you would start one |
| F3 | Use metrics to diagnose problems and set priorities (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is one number you reported, how it was counted, and a decision it informed. Selection scaffold: pick a figure you can explain end to end; if none comes to mind, say so plainly, then give the nearest analysis you have done, or how you would approach one |
| F4 | Bring customer and field feedback into product decisions (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a feedback loop you used or built and a decision it changed. Selection scaffold: pick a time feedback from customer-facing colleagues reached a product decision; if none comes to mind, say so plainly, then give the nearest thing your history carries, or how you would sort the signal |
| F5 | Influence product, engineering and go-to-market partners without formal authority (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a peer team and how it resolved, in your own account. Selection scaffold: pick a case where you needed something from a team you did not manage; if none comes to mind, say so plainly, then give the nearest collaboration, or how you would handle it |
| F6 | Design tools and process that scale as teams grow (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a tool or process you chose or built and what happened when more people used it. Selection scaffold: pick one you would reuse anywhere; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would evaluate options |

No row is a gate, because no posting supplied terms such as location, authorization, schedule or pay. If your JD has any, they become `hard_gate` rows once you share it.

## Persona table

Assumption: the final round is with someone you will work with or for, and the format is unknown. No loop source establishes this company's rounds, so persona weights rest on the Generic archetype (screen, hiring manager, panel) with flat weights. If your final is several back-to-back sessions, share the schedule and I will build per-session mini-packs.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet, persistent probing of fit gaps and motivation | Medium-high: a hiring-manager prior applies if that is who you meet, and a final round is the stage where gaps get tested | Rehearse the one predictable objection until it is boring; give a ramp plan and avoid bluffing |
| Case / Strategist (B) | Live problems: diagnose, plan, prioritise | Medium-high: same hiring-manager prior; a process-and-metrics role is easy to test live | Clarify first, then structure, then answer; think aloud; challenge one premise politely |
| Peer Evaluator (C) | Seam-splitting with adjacent teams, credit and disagreement | Medium: applies if a peer or cross-functional partner sits in the loop | Frame what you bring their team, and propose principles for the seam instead of claiming to know it |
| Values / Behavioral (D) | Scenario questions about behavior | Medium: no loop source documents a values round, so it is not assumed | Choose stories where the hard truth landed, and where none fits, say so |
| Conversational (E) | Friendly, chatty, still scored | Medium: openers are common in any round | Prepare a 90-second arc of your own journey; treat casual questions as scored |
| Pressure (F) | Time-boxing and devil's advocate | Low-medium: depends on the interviewer's style, which is unknown | Pause, restate, hold a position through two follow-ups, then concede specifically |
| Data-Driven Prober (G) | Probes how a number was counted | Low-medium: likely only if a metrics-heavy interviewer is present | Say plainly how a figure was counted, and name the assumption you would defend least |

## Question banks

Every row is `[generic]` for lack of a CV. Open prompts carry a selection scaffold ending in an honest branch, and CASE questions ask about no past.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack. Choose the real answer from your own history, not the safest one. Structure: name the part, say plainly why it is the weakest, then give a concrete ramp plan for the first thirty days. Hold it through two follow-ups, then concede what you do not know. If you cannot name one, say so plainly and name where you would ask for help first | F1 to F6 are all unevidenced in this worksheet, so this question will be asked in some form and nothing in the material yet says where you are thin. JD because it scores the role's own requirements |
| A2 | "Why product operations, why this company, and why now?" | EXP | [generic] | Give one reason for each of the three, in your own words, with no claim about your past beyond what you can stand behind. Keep it under ninety seconds. If one of the three has no honest answer yet, say which, and say what you are still working out | Motivation consistency is the Skeptic's core test. EXP because the answer is your own history, not a role fact |
| A3 | "Which part of a product operations role is furthest from what you've done so far, and what is your plan for it?" | JD | [generic] | Selection scaffold: pick the distance honestly, state what you would do in the first sixty days, and say who you would learn from. If nothing feels far, say so plainly, then name the part you would be most careful about | F1 to F6 give no evidence either way, so the gap question has to be rehearsed blind. JD because it scores the listed job |
| A4 | "What would you do in your first thirty days?" | JD | [generic] | A plan, not a past: listen to partner teams, learn the current cadence, find one process that is visibly costing time, and agree what success looks like with your manager. Adapt it in your own words; it makes no claim about what you have done | F2 and F6 are the rows this plan speaks to. JD because it is the role's own opening question |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A launch is two weeks out and three teams disagree about what ships. What do you do first?" | CASE | [generic] | Clarify first: who decides, what is fixed, what is the real constraint. Then objective, options, trade-offs, who needs to agree, how you would communicate the result. Challenge one premise politely | F1 and F5 meet here. CASE because it is a live problem with no claim about your past |
| B2 | "An adoption metric dropped 20% after a release. Diagnose it." | CASE | [generic] | Clarify the definition and the time window, check data quality before cause, segment, then list hypotheses ordered by test cost. Say which number you would pull first | F3 is the row. CASE because it is a standard diagnose-it problem |
| B3 | "Sketch an operating cadence for several product teams. What do you need to know first?" | CASE | [generic] | Ask what decisions the cadence must serve and who makes them. Then propose a small set of recurring forums, who attends, what each produces, and how you would retire a forum that is not working | F2 and F6 are the rows. CASE with a JD flavor: the role is partly about this |
| B4 | "How would you decide which customer and field feedback reaches the roadmap?" | CASE | [generic] | Propose criteria: breadth, severity, fit with stated priorities, evidence quality. Say how you would close the loop with the people who raised it. Name one risk of your approach | F4 is the row. CASE because it asks for a method, not a past |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam between us, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam instead of pretending to know it: who owns decisions, who owns process, when to escalate. Show a way to disagree that keeps the relationship intact. Ask what the seam looks like today | F5 is the row. JD because it tests the role's partnership mandate |
| C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a piece of cross-team work and say who did what, with we for context and I for your contribution. If no such work comes to mind, say so plainly, then say how you would share credit | F5 again. VAL because it scores collaboration behavior |
| C3 | "What would you need from me in your first month, and what would you bring my team?" | JD | [generic] | Lead with reciprocity: name what you would bring that reduces their load, then your needs, kept short and specific. Do not claim a specific past contribution | F5. JD because it prices the hire from a peer's side |

### D. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a moment with a named stake, a message you did not soften, and an intact relationship afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5. VAL because it scores candor |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the two pulled apart, say what each pulled toward, and what you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4. VAL because it scores customer orientation |
| D3 | "Pick a project that went well and say what part of it was yours and what part was the team's." | EXP | [generic] | Selection scaffold: pick one, then split it cleanly in your own words. Attribution honesty is the whole score. If you cannot split it, say so plainly and describe your part | F1 and F5. EXP because it tests attribution |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in your own words: where you started, the turn toward this work, what you want next. Use only what you can defend under a follow-up | Opener in almost any round, and still scored. EXP because it is your history |
| E2 | "What have you been following about how this company's products and customers are changing?" | CO | [generic] | No research ran, so this pack cannot supply current facts. Do your own reading first and say only what you read. If you have not, say so plainly and say what you would look at first | Homework depth is scored in a final round. CO and `[generic]` because the research was not run; the upgrade menu says what would fix that |
| E3 | "What are you actually playing with these days in tooling or process for running a team's work?" | JD | [generic] | Selection scaffold: pick one tool or habit you really use and say why. If nothing comes to mind, say so plainly and name what you would try first | F6. JD because process tooling is part of the job |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over the other finalists?" | JD | [generic] | Pick the one role requirement your own material speaks to most directly, say it in a sentence you can stand behind, add one honest limit and how you would close it. Do not disparage others | F1 to F6 are unevidenced here, so the one-sentence pitch has to come from you. JD because it scores fit to the role |
| F2 | "Tell me about a time you held a position under pressure from someone senior." | VAL | [generic] | Selection scaffold: pick a moment with a stake, a challenge you did not fold to, and a relationship still intact. Hold through two follow-ups, then concede specifically. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5. VAL because it scores composure |

### G. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Choose a number you've reported on and walk me through how it was counted." | EXP | [generic] | Selection scaffold: choose a figure you can explain end to end, say plainly how it was counted, and what it is sensitive to. If you do not know how a figure was counted, say so | F3. EXP because it tests whether a number survives scrutiny |
| G2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name the weakest assumption you know of before they do, in your own words. If you do not know of one, say so plainly | F3. EXP because naming your own weak spot converts a gotcha into credibility |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Coordinate launches | A4, B1, D3 |
| F2 Operating cadence | A4, B3 |
| F3 Metrics | B2, G1, G2 |
| F4 Customer and field feedback | B4, D2 |
| F5 Influence without authority | B1, C1, C2, C3, D1, D3, F2 |
| F6 Tools and process that scale | A4, B3, E3 |
| Motivation and fit (no row) | A1, A2, A3, E1, E2, F1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How does the product operations function work with product and engineering day to day, and where does the seam sit today?" | Shows you are thinking about how the work is divided, which is the role's core |
| R2 | "What would a successful first six months look like, and how would you and I know?" | Makes the expectation concrete and shows you plan for evidence of progress |
| R3 | "Which operating process is working least well right now, and what has been tried?" | Shows diligence about the real problem instead of the brochure |
| R4 | "How does feedback from customer-facing teams reach roadmap decisions today?" | Tests whether the loop in F4 exists and who owns it |
| R5 | "What would you want a new person to challenge in their first ninety days?" | Signals you will question things with tact |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question, for use if the interviewer is a peer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None | No CV or candidate sentence was given, so there is nothing to inflate and no negative the candidate stated | This pack coaches no claim about your past. Every claim you make live should be one you can stand behind under a second question |

## Sources

Provided documents: none beyond your message (company, role, final round).

Searches sent, all refused, so nothing came back:
- "Stripe operating principles values": refused
- "Stripe interview process Product Operations Manager": refused
- "Stripe strategy news 2026": refused
- "Stripe Product Operations Manager job description": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have moved the values cheat sheet; it is dropped, and the VAL questions rest on persona stems |
| 2. Stripe interview process, product operations | unavailable | Would have moved persona weights and the loop; the Generic archetype and flat weights stand in |
| 3. Stripe strategy and recent news | unavailable | Would have moved the CO bank; E2 stays generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Would have moved the fit snapshot requirements from `[generic]` to `[inferred]` |

## Upgrade menu

- Permission to run web searches: rows 1, 2, 3 and 5 above run, which adds the values cheat sheet, a named loop and persona weights, current-strategy CO and CASE questions, and requirements drawn from a real posting
- The JD text: the six `[generic]` requirements become `[grounded]`, and any location, authorization or schedule terms become gate rows
- Your CV or background: the worksheet becomes a real fit snapshot, selection scaffolds become story-mapped guidance, and the prohibited list gets real entries
- Who you are meeting, and whether the final is several sessions: persona weights are recomputed, and per-session mini-packs become possible
- The interviewer's name: an interviewer read and a reverse question tied to their path
- The recruiter's prep email: coverage of any pre-declared deliverable or focus area
- A tuesday-dossier.md from an earlier session: confirmed evidence and a named highest-ROI objection, which would make guidance story-mapped and the A1 rehearsal sharper
