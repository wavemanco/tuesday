# Interview prep pack: Operations Manager, Atlas Freight

- **Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
- **Interviewer and relationship:** not known. Round type not known. Persona weights are flat on relationship and ordered only by what your fit snapshot exposes
- **Built from:** the JD text and your background summary, both from your message. No web research ran, so nothing here is a fact about Atlas Freight's values, loop or strategy

## How to use this, and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Name | What it is testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the values a company publishes, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth. No CO questions appear in this pack because no research ran |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem set in the role |

Answer slots in the guidance are instructions for the interview, not questions for me. Meet one by answering either branch truthfully.

## Prep triage

You said the interview is next week. Plan for a few focused sessions, in this order. Everything else in the pack is insurance.

1. Say A1 and A2 aloud until they feel boring. They are the highest-ROI prep in the pack.
2. Defend the number: C1 and D2, the 40% mis-pick result, out loud, including the answer slots.
3. Build the 90-second arc in E1.
4. Practice the structure for B1, B2 and B3 on paper once each. The structure matters more than the answer.
5. Write your honest Power BI answer (C3) and pick three reverse questions.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material shows warehouse and distribution work and a site's surge plan, and does not show terminal operations or four sites. The words stay at the quotes: "For two years running I ran the site's peak-season surge plan." Answer slot: the JD's terminal and four-site wording makes a probe on how your work compares likely. Say in your own words where your warehouse and distribution work is like terminal operations and where it is not; if you cannot say, say so plainly and stay with the work you have described |
| F2 | "drive on-time performance and cost-per-shipment down" — JD (on-time half) | none given | none | [grounded] | discovery | Your material says nothing on on-time or service measures. Answer slot: if you tracked on-time or service measures on your shift, say which and what you did about them, in your own words; if you did not, say so plainly, and say what you would want measured first |
| F3 | "drive on-time performance and cost-per-shipment down" — JD (cost half) | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | A mis-pick rate is not cost-per-shipment, and the bridge should not be stretched. Answer slot: if anything was tracked alongside the mis-pick rate, say what it showed; if nothing was, say so plainly and stay with "I cut the mis-pick rate 40% by redesigning the pick path" |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material gives three supervisors, not twelve, and the words stay there: "I'm a senior shift manager over 3 supervisors." Answer slot: the JD's twelve makes a probe on how you lead likely. Describe how you work with the three, in your own words; if part of that was set by others, say so plainly and stay with the three |
| F5 | "build reporting in Excel/Power BI" — JD (Excel half) | "solid Excel" — your message | low | [inferred] | discovery | Solid Excel is a skill, not reporting you built. Answer slot: if you built reports in Excel, say what and who used them, in your own words; if you used Excel for other work, or built none, say so plainly and say what you used it for |
| F6 | "build reporting in Excel/Power BI" — JD (Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material gives seven years in operations and a current supervisory role, and does not say how long you have supervised. Answer slot: the JD's 5+ line makes a probe on leadership years likely. If your supervising or managing years reach five, say how many and in which roles; if they are fewer, say so plainly and stay with the seven years in operations |
| F8 | "Lean/Six Sigma a plus" — JD (Six Sigma half) | "green belt certified" — your message | medium | [grounded] | none | No gap, but a stated certification with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: "I'm green belt certified." The quote is the certification and carries no project |
| F9 | "Lean/Six Sigma a plus" — JD (Lean half) | none given | none | [grounded] | discovery | Your material does not mention Lean. Answer slot: if you have applied any Lean method in your work, say which and where, in your own words; if you have not, say so plainly and stay with the green belt |

## Persona table

Your relationship to the interviewer is unknown and no loop source was read, so these weights rest on a generic screen, hiring manager, panel pattern, not on Atlas Freight's documented process. Weights are flat on relationship. The depth tilt below is the pack's own reading of where your fit snapshot has gaps, so recalibrate it if you know who is interviewing.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of span, terminal experience, leadership years and Power BI | Highest depth: F1, F4, F6 and F7 are where the material is thinnest, and a skeptic aims there | Rehearse the most predictable objection (A1) until it is boring; limits said plainly; bridges only from quoted material |
| Case / Strategist | Live problems from the role: on-time dips, cost-per-shipment, reporting across sites, surges | Highest depth: the JD is built from measurable operating problems, and these cases ask nothing about your past | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Reads the 40% line by line, asks how it was counted | Middle depth: one quantified claim (F3) is a magnet target | Know what you can and cannot say about how the figure was counted; name the assumption you would defend least; say plainly what you do not know |
| Pressure / Stress | Time-boxes you, asks how much was actually you | Middle depth: the step from three supervisors to twelve invites it | Pause, restate, anchor in what you stated; hold through two follow-ups before conceding anything real |
| Conversational / Rapport | Friendly biography and Lean questions that are still scored | Middle depth: a first screen is often this register, but the round type is unknown | Pre-script the 90-second arc (E1); treat casual questions on JD topics as scored |
| Peer Evaluator | Seam-splitting, credit-sharing, what you would need from them | Lower depth: only matters if a peer or cross-site lead is in the loop | Reciprocity framing; seam principles rather than a pretended seam |
| Values / Behavioral | Scenario questions mapped to company values | Lower depth: no published values were read and no values round is documented, so none is assumed | Selection criteria with an honest branch; stories only where your own sentences carry them |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Pick one gap your own words support and say it first, then the limit, then a plan said as a plan. Two honest candidates: "I've never used Power BI" (F6), or that twelve supervisors is wider than "I'm a senior shift manager over 3 supervisors" (F4). Follow-up 1 is likely to be how you would close it; answer with what you would do, never with something you already did. Follow-up 2 is likely to be what if it takes longer; concede that specifically and do not add a claim. Name the limit before they ask for it | F4 and F6 are where this objection arrives in some form, so a rehearsed non-defensive answer changes the interview; JD because it scores the stated requirements, Skeptic because it asks for self-assessment |
| A2 | "This role has twelve supervisors across four sites. What have you led, and how?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Stay at the quote: "I'm a senior shift manager over 3 supervisors." Answer slot: the JD's twelve and four sites make a probe on how you lead likely. Describe how you work with the three, in your own words; if part of that was set by others, or there was no such practice, say so plainly and stay with the three. Do not round three up to a team of any other size | F4 is the evidence for the span requirement and the likeliest place to be pressed; JD because it scores the stated number |
| A3 | "The posting asks for 5+ years of operations leadership. Walk me through your leadership years." | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Give the two quoted facts in your own words, with the seven years as operations and the supervising as what you currently do. Answer slot: if your supervising or managing years reach five, say how many and in which roles; if they are fewer, or you are unsure how to count them, say so plainly and stay with the seven years in operations | F7 is the row where the material does not settle the posting's own number; JD because it scores the requirement as written |
| A4 | "How does terminal operations differ from the warehouse and distribution work you've done?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start from what you have done: "7 years in warehouse and distribution ops." Answer slot: the JD's terminal wording makes this probe likely. Say in your own words where the two are alike and where they differ; if you do not know how the terminal differs, say so plainly and say what you would ask on day one | F1 is the row where the JD's setting and your material are furthest apart; JD because it scores the first stated responsibility |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of your terminals falls sharply over two weeks. Diagnose it." | JD | [generic] | Clarify before structuring: how on-time is defined and measured, which lanes, shifts and customers moved, and what changed two weeks ago. Then objective, segmentation, approach, metrics, risks. Think aloud and ask for the data you would pull first. The question needs no claim about your past, so the guidance makes none | JD content, case delivery: F2's requirement asked as a live problem; generic because it is a pattern for the problem, not a fact about this employer |
| B2 | "Cost-per-shipment is flat while volume is up. Where do you look first, and what do you need to know?" | JD | [generic] | Clarify what goes into the numerator and which shipments make the denominator before anything else. Then segment the cost into broad buckets, say which one you would test first and why, and name what would change your mind. No claim about your past | JD content, case delivery: F3's requirement asked as a decision; generic for the same reason as B1 |
| B3 | "You inherit four sites that each report daily performance differently. How do you build one view?" | JD | [generic] | Start with the decisions the view serves, then a small common set of measures with one definition each, a daily cadence, and an owner per site. Say which tool you would use to start and what you would learn first. If Power BI comes up, use your plain acknowledgment, "I've never used Power BI," then a plan. No claim about your past beyond that | F5 and F6 are the requirement's two halves; this is the question where both appear live, and the honest answer is rehearsed here |
| B4 | "Peak volume hits two of your four sites in the same week. How do you run it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: what you need to know, what you protect, how you decide where capacity goes, how you communicate. Where it helps, one sentence from your own history in the quote's words: "I ran the site's peak-season surge plan two years running." Its beats are the ones the sentence states: the plan, the site, the two years. Tell them in your own words and add no detail the sentence does not carry | F1 carries the surge sentence; CASE because the problem is live and the JD's multi-site setting is what makes it hard |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say it as stated: "I cut the mis-pick rate 40% by redesigning the pick path." Then the four slots, each in your own words. How the 40% was counted. What it is sensitive to. The assumption behind it you would defend least, named before they ask. Which part of the redesign was yours. If you do not know how it was counted, say so plainly and say what you do know | F3 is the only quantified claim in the material and a prober's first target; EXP because it tests attribution and counting |
| C2 | "The role is measured on cost-per-shipment. What did your mis-pick result do to cost, if anything?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Keep to the quote: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if anything was tracked alongside the mis-pick rate, say what it showed, in your own words; if nothing was, say so plainly and stay with the mis-pick result. Never turn the mis-pick rate into a cost result | F3's bridge is thin, so the honest answer is rehearsed before the probe arrives; JD because it scores the cost requirement |
| C3 | "This role builds reporting in Excel and Power BI. What have you done with each?" | JD | [grounded] "solid Excel"; "never used Power BI" | Say it in your own words: "I have solid Excel. I've never used Power BI." Answer slot for Excel: if you built reports in Excel, say what and who used them; if you used it for other work, or built none, say so plainly and say what you used it for. For Power BI, give how you would learn it as a plan and never as a past | F5 and F6 are the two halves of one requirement, graded on different bands; JD because it scores the stated tools |

### D. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you for this role?" | EXP | [grounded] "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified"; "never used Power BI" | Pause, restate, then lead with two quoted facts in their own terms, the surge plan and the mis-pick result. Hold that position through two follow-ups by returning to the quotes, never by adding to them. If pushed on fit gaps, concede the specific one: "I've never used Power BI," then your plan. Do not concede the core claim just to restore harmony | F1 and F3 carry the strongest quotes, and F6 is the concession; EXP because pressure is testing composure around your own history |
| D2 | "That mis-pick result: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the sentence as you said it: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: say which parts of the redesign were yours and which others carried; if the redesign was shared or directed by someone else, say so plainly and describe your part. Hold through two follow-ups by returning to the sentence. Concede specifically what you do not know, and do not fold on the core claim | F3 again, as the attribution probe; EXP because it tests what was actually yours |
| D3 | "Three supervisors today, twelve here. Why should we believe you can step up?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Hold at the quote: "I'm a senior shift manager over 3 supervisors." Concede the observation plainly in your own words: twelve is a wider span than your material shows. Then what you would do in the first weeks, said as a plan and never as something already done. Hold through two follow-ups; do not claim a span you have not led | F4 is the span gap; JD because it scores the stated number, with pressure as the delivery |

### E. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Build a 90-second arc from those five sentences, in the order that is true for you. They state the seven years, the current role, the pick-path result, the surge plan and the belt. Add nothing else about your history. Answer slot: say why this role in your own words; nothing here states it, and if you are not sure, say so plainly and say what draws you to the work | F1, F3 and F8 hold the quotes; EXP because biography is where claims first get fixed in the interviewer's mind |
| E2 | "Tell me where Lean or Six Sigma has shown up in your work." | JD | [grounded] "green belt certified" | Lead with the certification as stated: "I'm green belt certified." Answer slot: if you have applied any Lean or Six Sigma method in your work, say which and where, in your own words; if the belt was training only, or you have used no method, say so plainly and stay with the certification. Nothing in the quotes covers Lean, so do not claim it | F8 and F9 are the two halves of the JD's plus; JD because the posting names it |
| E3 | "Tell me about your current role day to day." | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Open from the quote: "I'm a senior shift manager over 3 supervisors." Any further detail is yours, in your own words, and this pack does not supply it. If a detail is something you set rather than ran, say which | F4 is the evidence; EXP because a casual question about the current role is still checked against the CV |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | VAL | [generic] | Propose seam principles rather than pretending to know the seam, and frame what you bring their team, not only what you need. For the disagreement part, pick a real disagreement with an equal where you held your view and the working relationship survived; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The persona stem for a peer round, which this pack cannot rule out; generic because no quoted sentence carries a story here |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Use "we" for context and "I" for your contribution. Pick one shared result where your part can be stated exactly; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The persona stem for credit-sharing probes; generic because no quoted sentence carries a story here |

### H. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, the hard truth actually said, and a relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values-round stem. No published Atlas values were read, so no value is named, and no quoted sentence carries the story |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: a real customer consequence, the metric you set aside, and what you did instead. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values-round stem; generic for the same reason as H1 |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Own daily terminal operations across 4 sites" | A4, B4 |
| "drive on-time performance" | B1 |
| "cost-per-shipment down" | B2, C2 |
| "lead a team of 12 supervisors" | A2, D3 |
| "build reporting in Excel/Power BI" | B3, C3 |
| "5+ years operations leadership required" | A3 |
| "Lean/Six Sigma a plus" | E2 |
| The 40% mis-pick figure (defend-the-number) | C1, D2 |
| No CO question | none, because no research succeeded and no strategy source was read |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance defined here, and which site is furthest from where you want it?" | It asks for the definition before committing, and it reads F2's requirement as something you want to get right |
| R2 | "What goes into cost-per-shipment here, and what has moved it most?" | It shows you will ask what is in the number before you promise to move it, which is the same discipline C1 rehearses |
| R3 | "Where does reporting live today, in Excel, Power BI or both, and who owns it?" | It puts the Power BI gap (F6) on the table as a thing to learn, and it tells you what the first month would be |
| R4 | "What would success look like at 90 days and at 12 months for this role?" | It makes you answer to the interviewer's own scoring sheet |
| R5 | "What is the hardest part of running four sites at once that the posting does not say?" | It invites the honest version of the job and signals you are thinking about the seam between sites |
| R6 | "If you are meeting a peer: what could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer round, asked only if the round turns out to be one |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned terminal operations across four sites | Inflated form of F1 | F1's quotes at their own scope: the site's surge plan and warehouse and distribution work. The limit is the pack's observation, not words for you: the material does not show terminal operations or four sites |
| Led a team of twelve supervisors | Inflated form of F4 | F4's quote at its own scope: three supervisors. The limit is the pack's observation: the material gives three, not twelve |
| Lowered cost-per-shipment | Inflated form of F3 | F3's quote at its own scope: the mis-pick rate. The limit is the pack's observation: the material says mis-pick rate, not cost |
| Has used Power BI | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never used Power BI." Then a plan, never a past. No slot |
| Led Six Sigma projects | Inflated form of F8 | F8's quote at its own scope: "green belt certified." The limit is the pack's observation: the quote is a certification and carries no project |

## Sources

- **Provided documents:** the JD text in your message; your background summary in your message. No dossier, interviewer profile or CV file was present.
- **Searches sent:**
  - "Atlas Freight regional logistics company values": refused
  - "Atlas Freight operations manager interview process": refused
  - "Atlas Freight regional logistics strategy news 2026": refused
- **Fetches sent:** none.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | All calls were refused. It would have fed a values cheat sheet and named values for VAL questions; the VAL bank is generic instead |
| 2. Atlas Freight interview process, operations role | unavailable | All calls were refused. It would have documented the loop and moved persona weights; the weights are flat |
| 3. Atlas Freight strategy and recent news | unavailable | All calls were refused. It would have fed CO questions; none are in the pack |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you are meeting, even without a name (recruiter screen, hiring manager, panel) → persona weights restructured and the banks reordered
- The interviewer's name → an interviewer read from their public professional footprint, and a reverse question tied to their path
- Any recruiter email or process details, including a pre-announced exercise → coverage of any case, presentation or take-home as its own build section
- Atlas Freight's published values page, pasted, or search permission granted → a values cheat sheet, named values in the VAL bank, and CO questions on current strategy
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), if search is permitted → a grounding brief and a CO bank
- Your CV text → every question's quotes could come from the CV, not a short summary, and more rows could become grounded
- Anything true that this pack asks about, stated outside the answer slots: your leadership years (F7), whether you have ever led more than three supervisors (F4), any terminal or multi-site exposure (F1), anything tracked on on-time or cost (F2, F3), Excel reports you built (F5), any Lean method you applied (F9) → each stated fact enters the fit snapshot as a quote and the rows that rest on it regenerate
- A `tuesday-dossier.md` from an earlier role check, if you have one → verified evidence, a named top objection, and absolute prohibited claims; not needed to use this pack
