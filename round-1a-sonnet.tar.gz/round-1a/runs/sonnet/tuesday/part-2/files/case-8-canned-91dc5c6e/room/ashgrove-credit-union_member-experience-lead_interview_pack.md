# Member Experience Lead — Ashgrove Credit Union: interview pack for Dara

Loop mode, three rounds on 26 November 2026. Built 17 November 2026.

| Round | Who | Length | What the recruiter said |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Not described beyond the slot |
| 2 | Head of Member Services, who would be your manager | 45 minutes | "mostly behavioural" |
| 3 | A panel of two branch managers | 60 minutes | "including a 20-minute case on a complaint escalation"; "the values round — they score against the four values" |

Interviewer names are not assigned, so there is no interviewer read; personas follow each round's relationship and the recruiter's description.

## How to use this pack

- Personas describe how a question is asked. Types describe what is scored: VAL (behavioural and values alignment), EXP (a deep-dive on your own work), JD (a stated requirement of the role), CO (company and strategy knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Every sentence about your past rests on a sentence you wrote, quoted in the Provenance cell. Where your material says nothing, the guidance is an answer slot: an instruction for the interview with two honest branches, never a blank to fill with something you did not do.
- Every guidance column is proposed language, pending your approval. Say only what you actually did, in your own words.
- Question IDs: first digit is the round, then the persona letter, then the number (2B1 is round 2, persona B, question 1).
- The highest-ROI rehearsal in the whole pack is 2B1, the contact-centre question. Its lighter round-1 version is 1B1.

## Prep triage

All three rounds fall on the same day, 26 November, nine days from today, so the same story should be told the same way to all three audiences. In order:

1. 2B1 and 1B1: the contact-centre answer, rehearsed until it is boring.
2. 1B3 and F2: your answer on regulated complaints, including which branch of the answer slot is true for you.
3. Round 3 values: pick one real story for each of the four values using the scaffolds in 3A1 to 3A4, or decide in advance that you will say you have none and give the nearest thing.
4. 3B1: rehearse the escalation case aloud, twice, clarifying before structuring.
5. 1B2: the senior-presenting answer.

Everything else is insurance.

## Fit snapshot (shared by all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on years in the quote's own terms, but it is a self-reported line with nothing inspected behind it, so expect a probe on what the branch role covered. Lead with it as you said it: six years in retail banking, the last three as a branch supervisor |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | The quote shows a formal complaints log, not whether the complaints in it were regulated, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's regulated-complaints line makes a probe on which rules governed those complaints likely. If a regulator's rules or deadlines applied to what was in the log, say which and what they required, in your own words; if you do not know, or none applied, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | The quote is one branch's log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's across-branches line makes a probe on whether any of that reached beyond your own branch likely. If any of it did, say how, in your own words; if it stayed in your branch, say so plainly and stay with the log |
| F4 | "Own the member complaints process end to end across branches and the contact centre" — JD, the contact-centre part | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote shows a monthly complaints spreadsheet, not that it carried volumes or resolution times, and the words stay there: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's volumes-and-resolution-times line makes a probe on what it tracked likely. If it counted either, say how each was counted, in your own words; if it tracked something else, or neither, say so plainly and describe what it did track |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | The quote is training new tellers on a script, not coaching supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on whether you have coached supervisors likely. If you have, say who and how, in your own words; if not, say so plainly and stay with the tellers |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you have worked with a digital team on any member journey, say which and what your part was, in your own words; if you have not, say so plainly and say what you would want to learn first |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would build that, said as a plan and never as a past. Your material does not say what you presented at regional level, so this pack says nothing about it |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says spreadsheet, not Excel. Answer slot: the JD's Excel line makes a probe on the tool likely. If it was Excel, say so and what you used it for, in your own words; if it was another tool, say which, plainly |

The JD states no gate, meaning no term such as a licence, location, schedule or pay figure, so the snapshot has no gate row.

## Grounding brief

The four points below are the ones you relayed from the July 2026 strategy brief; the full brief was not in hand, so nothing beyond them is used.

| Brief point | Source | Where it surfaces in this pack |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | Strategy brief, as you relayed it — [grounded] | 1A3, 2C1 area, 3E1; note the figure is of member service, not of complaints |
| Consolidate eight branches into five hubs over 2027 | Strategy brief, as you relayed it — [grounded] | 1L3, 2C1, 3E1 |
| Launch a small-business lending product in Q1 2027 | Strategy brief, as you relayed it — [grounded] | 2C2 |
| Main competitive pressure is app-only banks | Strategy brief, as you relayed it — [grounded] | 3B3 |

---

# Round 1 — the recruiter (30 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Conversational | Friendly opener, "walk me through your journey", a motivation question | High. A recruiter screen prior is Conversational plus a light Skeptic, and a 30-minute slot is mostly biography and motivation | A 90-second arc built from your own sentences; treat the casual questions as scored |
| B Skeptic, light | Knockout checks on the JD's hard lines, asked kindly | Medium. The JD's requirements are the recruiter's checklist, and your own message names two limits the recruiter may already have read | Plain acknowledgment of each limit, then the nearest thing your material carries, then stop |
| L Logistics | Pay, notice, location, reason for leaving | High, because a recruiter screen always carries them | Your own answer to each, in one sentence, with no invented figure |

## Question bank

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "Walk me through your background and what brought you to this role." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped in three beats, each a clause your quotes state: the years and the role ("6 years in retail banking, the last 3 as a branch supervisor"), the log ("I handled the branch's formal complaints log"), the spreadsheet ("I built the monthly complaints spreadsheet our regional manager uses"). Close with your actual reason for wanting this role, in your own words; the pack does not supply it | F1, F3 and F5 are the evidence the screen is reading against; JD because it scores the 4+ years line, delivered conversationally |
| 1A2 | "What draws you to a member-owned credit union?" | VAL | [grounded] | Choose one of Ashgrove's four published values by its name, say in your own words what it means for the work, and let your reason be your own. The pack makes no claim about your past here, and supplies no motive for you | The values are a raising source and a recruiter weighs motivation consistency; VAL because it scores fit to published values |
| 1A3 | "Ashgrove wants 40% of member service on digital channels by 2028. Where do complaints belong in that?" | CO | [grounded] | Structure it: what a member could sensibly do alone, what needs a person, and how a member moves between the two without telling the story twice. Use the brief's figure exactly: it is of member service, not complaints. Answer slot: the JD's digital-teams line makes a probe on your own digital work likely. If you have worked with a digital team on any member journey, say what and your part in it; if you have not, say so plainly and say what you would want to learn first | The brief's digital target is the strategy item most tied to the JD's self-service line (F7) |
| 1B1 | "This role covers the contact centre as well as branches. Have you worked in one?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Two sentences: "I haven't worked in a contact centre. I handled the branch's formal complaints log." Then stop and let the recruiter ask. The longer version is 2B1 | F4 is a limit you stated, so the recruiter will reach it early; JD because it scores the across-branches-and-contact-centre line |
| 1B2 | "The role presents to senior leaders. How comfortable are you with that?" | JD | [grounded] "I've never presented to anyone above regional level" | "I haven't presented to anyone above regional level." Then say, as a plan, what you will do before you start; do not describe the spreadsheet as a presentation, because your sentence says the regional manager uses it | F8 is a stated limit; JD because it scores a listed requirement |
| 1B3 | "The role asks for experience handling regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log" | Start with the quote at its own scope: "I handled the branch's formal complaints log." Answer slot: the JD's regulated-complaints line makes a probe on which rules governed those complaints likely. If a regulator's rules or deadlines applied, say which and what they required, in your own words; if you do not know, or none applied, say so plainly and stay with the log | F2 is the soft spot in a requirement the recruiter will screen on |
| 1L1 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give your own figure, or ask what the role's band is before you answer. The pack supplies no figure and no history | A recruiter screen carries pay, and only your own answer is safe |
| 1L2 | "What is your notice period?" | JD | [generic] | Logistics slot: give your actual notice period | Same reason |
| 1L3 | "Where can you work, and how often?" | JD | [generic] | Logistics slot: give your actual constraints. Ask which site the role would sit at, since the brief has eight branches consolidating into five hubs over 2027 | The posting names branches and a contact centre, and the brief says the branch map changes |
| 1L4 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: give your actual reason in one sentence, in your own words, without criticising an employer | The recruiter checks that your reason fits what this job offers |

## Reverse questions for the recruiter

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What would the Head of Member Services most like solved in the first six months?" | It shows you are already thinking about the job rather than the process |
| R1.2 | "Is this a new post or a replacement, and who looks after complaints across branches and the contact centre today?" | It tests whether the end-to-end ownership in the JD already exists |
| R1.3 | "What does the panel look for in the 20-minute case, and is there anything I should prepare?" | Recruiters can often answer this in one line, and it covers any announced material |
| R1.4 | "Where will the role sit once branches consolidate into hubs?" | It ties your question to the brief and to your own location answer |
| R1.5 | "Is there anything in my background you would want me to address before round two?" | It invites the recruiter to name a concern while it can still be answered |

---

# Round 2 — Head of Member Services, your would-be manager (45 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Values/Behavioral | "Tell me about a time…" prompts | High. The recruiter described the round as "mostly behavioural" | A story only where a quoted sentence carries one; otherwise a scaffold and the honest branch |
| B Skeptic | Quiet probing of the contact centre, coaching and motivation | High. A manager is buying capability and derisking gaps, and the JD's lines map onto your two stated limits | Plain acknowledgment, hold the quote, concrete plan |
| C Case/Strategist | A live problem set in Ashgrove's own plans | Low to medium. Hiring-manager prior, tilted down by "mostly behavioural" | Clarify, objective, segmentation, approach, metrics, risks, aloud |
| D Data-Driven Prober | Line-by-line questions on the reporting and Excel lines | Low. The JD names both, and the manager will read the CV | Know what you can and cannot say about what the spreadsheet tracked |

## Question bank

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2A1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold: pick a time when a figure or a finding was unwelcome to someone senior. It needs a named stake, what you said, and how the relationship stood at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I built the monthly complaints spreadsheet our regional manager uses", at its own scope, or say how you would handle it | The persona stem, relevant to reporting complaint volumes upward (F5) |
| 2A2 | "When did you put a member ahead of an internal metric?" | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: a specific decision, what the metric or process was, what you chose, what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would handle it. The first value, Members First, Always, is the raising source | Persona stem and published value; F3 is the nearest evidence |
| 2A3 | "Tell me about a time you disagreed with someone over how a complaint should be handled." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: who, what each of you wanted, what moved the decision, how you left it. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would handle it | The JD's escalation-coaching line (F6) makes disagreement over a complaint a likely theme |
| 2A4 | "Tell me about a time you taught someone to handle a hard conversation." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on what the quote states: the people, new tellers, and the thing, the escalation script. Say it in your own words. Answer slot: if you changed any wording of the script as you taught it, say what; if you taught it as written, say so plainly. Where the quote ends is where the story ends | F6 is the nearest evidence for the coaching line |
| 2B1 | "Complaints across the contact centre are part of this job. How would you own that when you have never worked in one?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | The highest-ROI rehearsal in this pack. Level 1, your concession in full: "I haven't worked in a contact centre. I handled the branch's formal complaints log." The limit, named before you are asked: your log quote is from a branch, so it supports branch complaints only, and does not stand in for phone handling. Level 2, likely follow-up, "what is different on the phone?": do not describe what you do not know; ask what Ashgrove's contact centre handles today and how its complaints reach branches. Level 3, "so why you?": hold by returning to the log and to a plan you can say as a plan, such as asking to spend your first weeks listening to how the contact centre handles complaints before you change anything. Concede specifically, never fold on the log | F4 is the stated limit and F3 the adjacent evidence; this is the question the JD's own-it-end-to-end line makes near-certain; JD because it scores a stated requirement, delivered by the Skeptic |
| 2B2 | "The role coaches branch supervisors on escalations. How would you approach that?" | JD | [grounded] "trained new tellers on our escalation script"; "the last 3 as a branch supervisor" | Say what you have, at its scope: "I trained new tellers on our escalation script." Observation, not words for you: your material says new tellers, not supervisors, and coaching peers differs from training new staff. Answer slot: the JD's coaching line makes a probe on supervisors likely. If you have coached any supervisor, say who and how; if not, say so plainly and stay with the tellers. Then describe, as a plan, how you would approach it | F6 is a transferability row, so the answer is the quote and its limit |
| 2B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pick one limit you have actually stated, either of the two quoted, say it plainly, then say what you would do about it as a plan. Do not choose a limit your material does not state. This is calibrated candour: naming it first costs less than having it found | The persona stem; F4 and F8 are the two stated limits |
| 2B4 | "What is drawing you from a branch supervisor post to leading complaints across the whole credit union?" | EXP | [grounded] "the last 3 as a branch supervisor" | Your actual reason, in your own words, one or two sentences. The quote fixes only the starting point, branch supervisor for the last three years. The pack supplies no reason | Motivation consistency, the same ground as 1L4 and 1A1 |
| 2C1 | "Ashgrove plans to consolidate eight branches into five hubs over 2027. What happens to complaints during that change?" | CASE | [grounded] | Clarify first: which branches, in what order, what members are told and when. Objective: no member loses their place in a complaint. Segment: members whose branch closes, members who move to a hub, members who go digital. Metrics: volumes and resolution times by branch, the two figures the JD names. Risks: a complaint half-finished at a closing branch. Challenge one premise respectfully. The case asks nothing about your past | A live problem from the brief's hub plan |
| 2C2 | "A small-business lending product launches in Q1 2027. What would you want in place on complaints before launch?" | CASE | [grounded] | Clarify: what the product is, who will take the first complaints, what the contact centre and branches are told. Then objective, approach, and risks. Do not invent product details; say what you would ask for. The case asks nothing about your past | The brief's second launch, relevant to the complaints process the role owns |
| 2D1 | "Walk me through the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Describe it at the quote's scope: you built it, it was monthly, it was about complaints, your regional manager used it. Answer slot: the JD's volumes-and-resolution-times line makes a probe on what it tracked likely. If it counted either, say how each was counted and the assumption you would defend least, in your own words; if it tracked something else, or neither, say so plainly and describe what it did track | F5 is the evidence for the reporting line; JD because it scores a stated requirement |
| 2D2 | "How comfortable are you with Excel for reporting, and what would you point to?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Point to the spreadsheet at its scope. Answer slot: the JD's Excel line makes a probe on the tool likely. If it was Excel, say so and what you used it for; if another tool, say which, plainly | F9 is a discovery row, so the answer is the quote and the honest slot |

## Reverse questions for the Head of Member Services

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What does good look like for this role at six months, in complaints terms?" | It asks your future manager for the measure they will use |
| R2.2 | "How is complaint handling split today between branches and the contact centre, and where does it break?" | It asks about the end-to-end seam the JD names |
| R2.3 | "How do member services and the digital teams work together today on self-service journeys?" | It turns the JD's digital line into a working question |
| R2.4 | "Which of the strategy's three moves, digital, hubs or small-business lending, will put pressure on complaints first?" | It shows you have read the brief |
| R2.5 | "What would you want a new lead to learn from the contact centre in the first weeks?" | It converts the contact-centre limit into a plan the manager helps shape |

---

# Round 3 — panel of two branch managers (60 minutes, including a 20-minute case)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Values/Behavioral | Scored stories against the four values | High. The recruiter said the panel "score against the four values" | One story per value, or the honest branch |
| B Case/Strategist | The 20-minute escalation case and a strategy question | High. A third of the hour is a case | Clarify, structure, think aloud, challenge one premise |
| C Peer Evaluator | "Where does your job end and mine begin?" | Medium. Branch managers sit on the other side of the JD's coaching line, and this pack assumes they do; their relationship to the role is not stated | Reciprocity framing and seam principles |
| E Pressure | A challenge to the strategy from the branch side | Low. Possible once hubs come up; not signalled | Pause, restate, hold, concede specifically |

## Question bank

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3A1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold for Members First, Always: a specific decision, whose side you took, what it cost, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would handle it | The first published value; F3 is the nearest evidence |
| 3A2 | "Tell me about a time something had to be explained to a member twice." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold for Plain Words: what was unclear, who found out, what was changed in the wording. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "trained new tellers on our escalation script", or how you would handle it. Answer slot: if you ever rewrote script wording, say what; if you taught it as written, say so plainly | The second published value; F6 is the nearest evidence |
| 3A3 | "Every branch is part of its town. Tell me about a time a number and a neighbour pulled in different directions." | VAL | [grounded] "the last 3 as a branch supervisor" | Selection scaffold for Neighbours, Not Numbers: a figure you were measured on, a person or place it affected, what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "the last 3 as a branch supervisor", at its scope, or how you would handle it | The third published value; F1 is the nearest evidence |
| 3A4 | "Tell me about a time you found a problem that was not yours and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold for Own the Fix: what you found, who it belonged to, what you did to keep hold of it, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would handle it | The fourth published value; F3 is the nearest evidence |
| 3B1 | "A member's complaint was logged at a branch and passed to the contact centre. They have rung back three times and say nobody owns it. What do you do?" | CASE | [generic] | Clarify first: what the complaint is, what the member was promised, who holds it now, and which deadlines apply, stating only the ones you know and saying so if you do not know them. Objective: the member hears from one named person. Approach: take the case yourself, then agree who holds it and tell the member in plain words. Metrics: resolution time. Risks: a hand-off that drops it again. Think aloud and challenge one premise. The case asks nothing about your past | The recruiter said 20 minutes is a complaint-escalation case; the shape draws on the values Own the Fix and Plain Words |
| 3B2 | "One branch's complaint volumes have doubled this month. What do you do before you report it?" | JD | [generic] | Clarify: one cause or many, a product, a closure, a one-off. Segment by type and by member group. Decide what the report shows: the JD's two figures, volumes and resolution times. Say what you would tell senior leaders and in what words. The case asks nothing about your past | A live problem on the JD's reporting line (F5) |
| 3B3 | "Why would a member stay with Ashgrove rather than an app-only bank when they have a complaint?" | CO | [grounded] | Use the brief's frame: app-only banks are the main competitive pressure. Anchor on the published values rather than on invented data, and say what you would want to find out. The question asks nothing about your past | The brief's competitive point |
| 3C1 | "Where does your job end and a branch manager's begin when a complaint is raised at the counter?" | JD | [grounded] "the last 3 as a branch supervisor" | Propose seam principles rather than pretending to know the seam: the member keeps one owner, the branch keeps the relationship, the lead owns the process. Reciprocity: say what a branch gets from the role. Your quote supports only that you were a branch supervisor for the last three years, so say nothing wider about what branch managers feel | The peer persona's seam question; F6 is the coaching line it presses on |
| 3C2 | "A supervisor in my branch keeps escalating things they should resolve at the counter. How would you coach them?" | JD | [grounded] "trained new tellers on our escalation script" | A structure: find out what they are afraid of, what they need to decide alone, and how you check it worked. Your quote supports "I trained new tellers on our escalation script" and nothing about supervisors. Answer slot: if you have coached a supervisor before, say how; if not, say so plainly. The question asks nothing else about your past | F6 again, from the branch manager's side |
| 3E1 | "This strategy moves member service online and merges eight branches into five hubs. Why should a branch manager trust you with their members' complaints?" | VAL | [grounded] | Pause, restate, then hold a position that is your own. Two anchors that are not claims about you: the brief says 40% of member service, not all of it, and the value reads "every branch is part of its town". Hold through two follow-ups; concede specifically, for example that you do not know which hubs or when. The question asks nothing about your past | A challenge from the branch side, tied to Neighbours, Not Numbers |

## Values cheat sheet

| Value (official name) | Working meaning | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold (3A1): a specific decision, whose side, what it cost. If none comes to mind, say so plainly, then the nearest thing F3 carries, "I handled the branch's formal complaints log", or how you would handle it |
| Plain Words | If a member needs it explained twice, the wording was wrong | Selection scaffold (3A2). If none comes to mind, say so plainly, then the nearest thing F6 carries, "trained new tellers on our escalation script", or how you would handle it |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold (3A3). If none comes to mind, say so plainly, then the nearest thing F1 carries, "the last 3 as a branch supervisor", or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Selection scaffold (3A4). If none comes to mind, say so plainly, then the nearest thing F3 carries, "I handled the branch's formal complaints log", or how you would handle it |

## Reverse questions for the panel

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What does a good escalation from your branch look like, and what makes you lose confidence in one?" | It asks the panel for their own bar |
| R3.2 | "How do you expect the move to hubs to change what reaches your supervisors?" | It ties the strategy to their daily work without assuming their branch is affected |
| R3.3 | "What could a new complaints lead do in the first month that would genuinely help your branch?" | The reciprocity question for a peer-style panel |
| R3.4 | "Which of the four values is hardest to hold on a busy day?" | It asks for a real example in their own words |
| R3.5 | "What would you want a monthly complaints report to show you?" | It ties to the JD's reporting line and the panel's own use of it |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | 1A1 |
| Experience handling regulated complaints | 1B3 |
| Own the complaints process end to end across branches and the contact centre | 1B1, 2B1, 3B1 |
| Report monthly on complaint volumes and resolution times | 2D1, 3B2 |
| Coach branch supervisors on escalations | 2B2, 3C2 |
| Work with digital teams on self-service journeys | 1A3 |
| Confident presenting to senior leaders | 1B2 |
| Comfortable with Excel reporting | 2D2 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says one branch's log, not a process across branches |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope: "I handled the branch's formal complaints log." The pack's observation is that the material does not say the complaints were regulated. 1B3's slot stays inside the log |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: "I trained new tellers on our escalation script." The pack's observation is that the material says new tellers, not supervisors |
| Reported on complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The pack's observation is that the material does not say what it tracked |
| Has contact-centre experience | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." No slot |

## Sources

Provided documents: the JD; the four published values, copied from ashgrovecu.org/about/values on 17 November 2026; the recruiter's email on the three rounds; the July 2026 strategy brief as you relayed it, four points only; your background in your own words.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The pasted values page is in hand and fixes the values cheat sheet and the VAL bank |
| 2. Ashgrove interview process, member services roles | skipped | The recruiter's email names the three sessions, who runs each and what each holds, so persona weights follow it |
| 3. Ashgrove strategy and recent news | skipped | The four brief points in hand fix the CO and CASE questions; the full brief would add more |
| 4. Interviewer name and Ashgrove | n/a | No names were given, so there is no query to form |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names for rounds 2 and 3 → an interviewer read and persona weights per person
- The full 2026 strategy brief → CO and CASE questions beyond the four points relayed
- A deeper research pass, offered once — up to 6 more searches and 2 more fetches, several more minutes → interviewer public footprint, loop reports for member-service roles, recent organisation context
- The recruiter's guidance on the 20-minute case, including whether to prepare anything → coverage of any announced material
- Your own answers to the answer slots, said outside a drill: whether the formal complaints were subject to a regulator's deadlines, what the spreadsheet tracked and what tool it was in, and whether you have coached a supervisor or worked with a digital team → F2, F3, F5, F6, F7 and F9 and the rows that draw on them (1A3, 1B3, 2A4, 2B2, 2D1, 2D2, 3C2) become story-mapped
- A redacted copy of the monthly complaints spreadsheet → F5 and F9 move from medium confidence toward high
- Hours per day available before 26 November → a triage sized to your time
- A tuesday-dossier.md → carries the gaps this prep exposed into later sessions
