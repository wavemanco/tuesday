# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode: three rounds on 26 November 2026 — a recruiter screen (30 minutes), the Head of Member Services who would be your manager (45 minutes, mostly behavioural), then a panel of two branch managers (60 minutes, including a 20-minute complaint-escalation case, also the values round). Interviewer names are not yet assigned.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores: VAL (values and behaviour), EXP (what you actually did), JD (the posting's stated requirements), CO (company and strategy), CASE (a live problem).
- Guidance is scaffolding, not a script. All wording suggested here is pending your approval: edit it into your own words, and say only what you did.
- An answer slot is an instruction for the interview, not a question for you now. A slot has two honest branches; either is a good answer.
- Question IDs are letters by persona within each round (A1, B1 for round 1; C1 onward for round 2; G1 onward for round 3) so a drill can name them.
- The highest-ROI rehearsal in the whole pack is C2, in round 2. Rehearse it until it is boring.

## Fit snapshot (shared across rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says the branch's log, not a process across branches, and the words stay at that scope. Answer slot: the JD's end-to-end line makes a probe on how the log was handled likely. If any step of how complaints in the log were handled was yours to set, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "and the contact centre" — JD (same line as F1) | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | Your material says a monthly complaints spreadsheet, not what it counts. Lead with it as stated. Answer slot: the JD's volumes-and-resolution-times line makes a probe on what the sheet tracked likely. Say what it counted, in your own words; if it did not track one of those, say so plainly and stay with what it did track |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | low | [inferred] | discovery | Your material says formal complaints, not which rules governed them. Answer slot: expect a probe on the rules behind your log. If the complaints in it were subject to rules or deadlines set outside the branch, say which and what you did to work to them, in your own words; if they were not, or you do not know which applied, say so plainly and stay with the log you handled |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers on the escalation script, not supervisors, and the words stay at that scope. Answer slot: the JD's coaching line makes a probe likely. If any teller you trained brought you a live escalation afterwards and you supported them, say what happened and what part was yours, in your own words; if that did not happen, or it was not you, say so plainly and stay with training them on the script |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on digital or self-service work. Answer slot: the JD's digital-teams line makes a probe likely. If you have worked with anyone on how members use an app, website or other self-service route, say what and what part was yours, in your own words; if you have not, say so plainly and say what you would ask the digital team first |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | The quote already reaches the years in other terms. Lead with it in its own terms: six years in retail banking, the last three as a branch supervisor, and let the interviewer read across to the posting's four |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Never a claim to presenting to senior leaders |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Your material says spreadsheet, not Excel, and not what it does. Answer slot: expect a probe on the tool. Say which tool the sheet was built in and what it did, in your own words; if it was not Excel, say so plainly and stay with what you built |

No JD line is a gate: the 4+ years line is a length-of-experience requirement, graded like the rest.

## Grounding brief (from the 2026 strategy brief as you summarised it, published July 2026)

| Item | What the brief says | Where it surfaces | Provenance |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | A2, F2 | [grounded] |
| Branch footprint | Consolidate eight branches into five hubs over 2027 | G3, round 3 reverse questions | [grounded] |
| New product | Launch a small-business lending product in Q1 2027 | Round 2 reverse questions | [grounded] |
| Competitive frame | The main competitive pressure is app-only banks | G1 | [grounded] |

## Round 1: recruiter screen (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through, motivation, logistics | High. The recruiter-screen prior is Conversational plus light Skeptic, and your email gives the recruiter 30 minutes alone | Pre-script the 90-second arc from A1's quotes; treat pay, notice and location as scored |
| Skeptic (light) | Knockout checks on the lines that sound hard | Medium. The JD's contact-centre and regulated-complaints lines are where your material is thinnest (F2, F4) | Say the limit first, short and plain, then stop |
| Prober, Pressure, Case, Values, Peer | Not signalled for this round | Low. Your email gives them their place in rounds 2 and 3 | Covered there |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Four beats, each a clause your quotes state, in your own words: six years in retail banking; the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Close on why this role as an answer slot: give your own reason in your own words; none of your material states one, so none is written here. About 90 seconds | The opener every screen has. F1, F3, F5 and F7 are the rows this arc touches; EXP because it tests whether the story matches the record |
| A2 | "What drew you to Ashgrove?" | CO | [grounded] | Pick one move from the brief that bears on complaints and say why it matters to you: 40% of service to digital by 2028, eight branches into five hubs over 2027, small-business lending in Q1 2027, or app-only banks as the pressure. The reason is yours; the pack supplies none. Answer slot: if what drew you is not in the brief, say what it is plainly | A motivation check in a friendly register, scored for homework; CO because it tests whether you read the brief. F6 is the JD requirement closest to the digital move |
| A3 | "What's prompting a move now?" | EXP | [generic] | Logistics slot: give your actual reason in your own words. None of your material states one, so the pack supplies none. Keep it short and forward-looking | The recruiter row's reason-for-leaving logistics; EXP because it tests consistency with the story in A1 |
| A4 | "What are you looking for on salary?" | JD | [generic] | Logistics slot: give your own figure, or ask for the role's band first. The JD gives no pay and your material gives no figure, so the pack supplies none | Pay is a logistics item on every recruiter screen; JD because it concerns the job's terms |
| A5 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period | Logistics; JD because it concerns the job's terms |
| A6 | "Any constraints on location or hours?" | JD | [generic] | Logistics slot: say your own constraints on where and how often you can work. The JD gives no location or schedule, so asking what the role expects across branches and the contact centre is reasonable | Logistics; JD because it concerns the job's terms |

### Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as the branches. What contact-centre experience do you have?" | JD | [grounded] "Never worked in a contact centre" | Short and plain: "I haven't worked in a contact centre." Then one sentence on how you would learn it, said as a plan. Reach for no adjacent claim; the quote is the limit | F2 is the row with a stated negative, so a knockout check on it is likely; JD because it scores a stated requirement |
| B2 | "The role asks for experience handling regulated complaints. What did that look like in your branch?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Start from the quote: you handled the branch's formal complaints log. Answer slot: if the complaints in it were subject to rules or deadlines set outside the branch, say which and what you did to work to them, in your own words; if they were not, or you do not know which applied, say so plainly and stay with the log you handled | F4 is where the JD's word and your material's word differ; JD because it scores a stated requirement |
| B3 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Lead with the quote: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: say which tool it was built in and what it did, in your own words; if it was not Excel, say so plainly and stay with what you built | F9; JD because Excel is a stated requirement, asked in a casual register |

### Reverse questions: round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "How is the contact-centre side of this role set up today, and how do complaints reach the lead?" | Shows you are already thinking about the part of the role you have not worked in, and gets you facts for C2 |
| 2 | "Which rules does the role's complaint work run under, and how does Ashgrove report against them?" | Tells you how hard the regulated-complaints probe will press before round 2 |
| 3 | "For the 20-minute escalation case, is there anything to read or prepare beforehand?" | A preparation signal, and it tunes G1 |
| 4 | "Which leaders see the monthly complaints report?" | Sizes the senior-presenting requirement (F8) before you are asked about it |
| 5 | "What does the Head of Member Services most want from the person in this role?" | Moves you from the interrogated to a partner and prepares round 2 |

## Round 2: Head of Member Services, your would-be manager (45 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the contact-centre and senior-presenting gaps | High. The hiring-manager prior is Case plus Skeptic, and a manager is derisking exactly F2 and F8 | Rehearse C2 until it is boring; concede the limit plainly, then give a plan |
| Values/Behavioural | "Tell me about a time" scenarios | High. Your email calls the round mostly behavioural, which tilts the prior away from Case | Story-map where a quote carries a story; use a selection scaffold ending in its honest branch where none does |
| Data-Driven Prober | Line-by-line on the spreadsheet and how resolution is counted | Medium. The JD's monthly-reporting line (F3) is the one this manager will own the output of | Know what you can and cannot say about what the sheet counts, and say plainly what you do not know |
| Case/Strategist | One or two live problems on the role's own agenda | Medium-low. The prior is Case, but your email says the round is mostly behavioural | Clarify, structure, then answer |

### Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Name the weakest part before they do, in your own words from your material: you have never worked in a contact centre, and you have never presented to anyone above regional level. Pick one, say it plainly, then give a plan for it, as a plan and never as a past: what you would learn first and from whom. Keep the other ready for a follow-up | F2 and F8 are the two negatives you stated; JD because it scores the posting's requirements |
| C2 | "You haven't worked in a contact centre, and this role owns complaints across it. Why should I trust you with it?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log and trained new tellers on our escalation script" | The highest-ROI rehearsal in this pack. Hold only what the quotes carry: you handled the branch's formal complaints log and trained new tellers on our escalation script. Concede plainly and before you are pushed: "I haven't worked in a contact centre." Then a plan, said as a plan: what you would ask and observe first and who you would ask. Follow-up 1, "What does your first month look like?": a plan built on what you would learn, with no contact-centre knowledge you do not have. Follow-up 2, "You handled one branch's log; this is every branch and the contact centre": hold the quote at its scope, say the scope is wider, and concede no more than that. Follow-up 3, "What if the contact-centre team doesn't take direction from a branch person?": answer as a method for working with them, not a story. Hold through two follow-ups before conceding anything further | F1 and F2 are where the JD's headline line presses hardest, so this objection arrives in some form; JD because it scores the stated requirement, Skeptic because it targets the gap |
| C3 | "You've never presented above regional level, and this role reports monthly to senior leaders. What changes for you?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Plain acknowledgment first: "I haven't presented to anyone above regional level." Then what the quote carries: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if you have presented the sheet or its findings to anyone, say who and in what setting; if you have not, say so plainly and stay with the sheet. Then a plan, as a plan: how you would prepare a first presentation, such as asking what the leaders decide from the report and building to that | F8 is a stated negative, and F3 is the closest thing your material carries; JD because it scores the requirement |
| C4 | "You've been a supervisor for three years. Why a lead role now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | State the fact as written: six years in retail banking, the last three as a branch supervisor. Answer slot: give your own reason for stepping into a lead role, in your own words; none of your material states one | F7; EXP because it tests consistency between your story and your reason |

### Bank D: Values/Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you coached someone through a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Story-mapped on F5: you trained new tellers on the escalation script, the beat the quote states; tell it in your own words. Answer slot: if any teller you trained brought you a live escalation and you supported them, say what happened and what part was yours; if that did not happen, or it was not you, say so plainly and tell the training itself | F5 is your closest evidence for the coaching line; JD because it scores a stated requirement, behavioural in delivery |
| D2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, what you said, and how the relationship stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem that probes the senior-audience gap in F8 without presupposing any history |
| D3 | "Tell me about a time you worked with a team outside your branch to change how members were served." | JD | [grounded] | Selection scaffold: pick a time you worked with people outside your own branch on something members experienced. Name who, what changed for members, and your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6 is silent in your material, and the JD's digital-teams line raises this theme |

### Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly complaints spreadsheet you built: what's in it and who reads it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | The beats the quote states: you built it, it is monthly, your regional manager uses it. Answer slot: say what the sheet holds and how it is laid out, in your own words; if you do not know how some figure in it was counted, say so plainly. Name the assumption behind the sheet you would defend least before they ask, if one comes to mind | The sheet is your one reporting artifact, so a prober starts there; EXP because it tests what was yours (F3, F9) |
| E2 | "How do you decide a complaint is resolved, and how is the time to resolve it counted?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Answer slot: if the log recorded when a complaint was opened and closed, say how those dates were set, in your own words; if it did not, or you do not know how resolution was counted, say so plainly and stay with the log you handled | The JD asks for reporting on resolution times (F3); JD because it scores that line |

### Bank F: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Your first monthly report shows resolution times lengthening at three branches but not in the contact centre. What do you do first?" | CASE | [generic] | Think aloud: clarify first (is resolved defined the same way in every channel, has the mix of complaints changed, how many complaints sit behind each branch), then objective, segmentation by branch, channel and complaint type, approach, metrics, risks. Challenge one premise respectfully, such as whether the three branches and the contact centre are comparable. No claim about your past is needed | A live problem from the JD's monthly-reporting line (F3), asked as a decision rather than a record |
| F2 | "The brief targets 40% of member service on digital channels by 2028. Which parts of complaints should move to self-service, and which should not?" | CO | [grounded] | Clarify what the target counts as member service; segment complaints by type and by what the member needs; choose criteria (members first, plain words); say what you would measure and the risk to members who need explaining twice. Challenge one premise respectfully. No claim about your past is needed | The one strategy question most candidates cannot touch; CO because it tests the brief, CASE in delivery. F6 is the related requirement |

### Reverse questions: round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would you want the first 90 days to have changed?" | Shows you are ready to own the outcome and tells you the manager's real priority |
| 2 | "What decisions does the monthly complaints report feed, and who reads it?" | Ties your spreadsheet background to the manager's use of it |
| 3 | "Where do complaints get stuck today between a branch and the contact centre?" | Meets the contact-centre gap head-on with curiosity |
| 4 | "How will the Q1 2027 small-business lending launch change what complaints reach the lead?" | Shows you read the brief and think ahead |
| 5 | "Where would you want me strongest on day one, and where would you give me room to learn?" | Invites the conversation about the gaps on your terms |
| 6 | "What do you expect to be hardest about coaching supervisors on escalations?" | Frames you as a coach in the making (F5) and invites candour |

## Round 3: panel of two branch managers (60 minutes, incl. 20-minute escalation case; values round)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioural | Scenarios mapped to the four published values | High. The recruiter says the panel is the values round and scores against the four values | One story per value; "we" for context and "I" for contribution; hard-truth endings only where your material shows one |
| Case/Strategist | The 20-minute complaint-escalation case | High. The recruiter names it, and it takes a third of the round | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Peer Evaluator | Branch managers pricing what you add to or take from their branches | Medium. Panel rule: blend each member's top personas, and names are not yet known | Reciprocity: what you give the branch, and principles for the seam rather than a pretended seam |
| Pressure | Time-boxed challenge | Low. Possible in a panel, but nothing in your email signals it | One rehearsed answer (J1) |

### Bank G: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member has complained at their branch and again through the contact centre, and neither has been resolved. They say they will move to an app-only bank. You own the process. Walk us through it." | CASE | [generic] | Use the 20 minutes: clarify first (when each complaint was made, what the member was told, which rules and timelines apply, what the member wants); objective (the member's problem fixed and held by one person); who holds it from now, what you tell the member and in what words, what you record, what you check afterwards; then the process question of why it bounced and what you would change. Challenge one premise, such as whether both complaints were formally logged. No claim about your past is needed | The recruiter names this case; the app-only-bank line reflects the brief's competitive pressure. Pattern, not this employer's actual case, so labelled generic |
| G2 | "A branch supervisor escalates a complaint they have clearly mishandled, in front of their team. How do you coach them?" | CASE | [generic] | Clarify what happened and what the supervisor already knows; objective (the member is fixed first, the supervisor keeps their standing); sequence: member first, a private conversation, a specific change, a check later; metric: whether the next escalation is cleaner. No claim about your past is needed | The JD's coaching line (F5) as a decision rather than a record |
| G3 | "Eight branches are becoming five hubs over 2027. A town's branch closes and its complaints now land on you. What do you set up?" | CASE | [grounded] | Clarify which branches and when; objective (members from the closed branch are heard as before); segmentation by member need and complaint type; approach, metrics, risks, with the town's loss of a local face named as a risk. No claim about your past is needed | Panel members whose branches may be consolidated will care; CO because it uses the brief's hub plan |

### Bank H: Values/Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Members First, Always: tell me about a time you decided from the member's side of the counter." | VAL | [grounded] | Selection scaffold: pick a time you decided at the counter by asking what the member needed, when another route was easier. Name the stake, what you chose, and how the member left. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Value 1; no quoted sentence of yours carries a story for it |
| H2 | "Plain Words: when has something said or written to a member needed explaining twice, and what happened next?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Story-mapped on F5: you trained new tellers on the escalation script, the beat the quote states. Answer slot: if the script's wording, or any wording members saw, was yours to write or change, say what and why; if it was not, say so plainly and stay with training the tellers on it | Value 2; the escalation script is the nearest quote to wording |
| H3 | "Neighbours, Not Numbers: when you report monthly on complaints, how do you keep the people and the branch behind the numbers in view?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Start from the quote: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if the sheet or your reporting carried anything beyond counts, such as which branch or what the member went through, say what and how, in your own words; if it held counts only, say so plainly. Then, as a plan, how you would keep branch and member in view | Value 3, set against a role that reports volumes (F3); the tension is the point |
| H4 | "Own the Fix: tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Story-mapped on F1: you handled the branch's formal complaints log, the beat the quote states. Answer slot: if you followed a particular complaint through to a fix yourself, say which, what you did and what part was yours; if the log was a record and others solved the complaints, say so plainly and tell how you handled the log | Value 4; F1 is the closest quote to ownership |

### Bank I: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "A complaint sits at one of our branches and you think it needs to move up. Where is the seam between you and the branch manager, and what happens when you disagree?" | CASE | [generic] | Offer principles, not a pretended seam: who the member hears from, who holds the fix, when the branch manager is told before the member, how a disagreement is settled quickly and in the member's favour. Add reciprocity as a plan: what you would give the branch manager in return. No claim about your past is needed | Branch managers will be the people you work alongside; the seam is the peer's native question |
| I2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams and say how credit was shared. It needs a named collaborator, your part, and the other side's. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer stem; no quoted sentence of yours carries a story for it |

### Bank J: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Sixty seconds: why you for this role when you have never worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Pause and restate. Hold only what the quotes carry: you handled the branch's formal complaints log and trained new tellers on our escalation script. Concede plainly: "I haven't worked in a contact centre." Then a plan. Hold through two follow-ups before conceding anything further | C2 again in a time-boxed register, in case a panel member lifts it from the round 2 notes |

### Values and principles cheat sheet (round 3)

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decisions are made from the member's side of the counter | Selection scaffold (H1): no quote of yours carries a story; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs something explained twice, the writing is at fault | F5: "I handled the branch's formal complaints log and trained new tellers on our escalation script"; answer slot at H2 |
| Neighbours, Not Numbers | Every branch is part of its town | F3: "I built the monthly complaints spreadsheet our regional manager uses"; answer slot at H3 |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script"; answer slot at H4 |

### Reverse questions: round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "What do you most want from whoever owns complaints, as branch managers?" | A reciprocity question: it asks what you can give them |
| 2 | "What helps and what gets in the way when a complaint at your branch needs escalating?" | Gets real seam facts and shows you listen before you design |
| 3 | "How do you expect the move to five hubs to change what a branch manager owns on complaints?" | Ties to the brief and to Neighbours, Not Numbers |
| 4 | "Which of the four values is hardest to hold on a busy day in a branch?" | Shows you take the values as practice, not slogans |
| 5 | "What would make you say, six months in, that this role is working?" | Leaves them describing the success you will aim at |

## Requirement coverage

| Requirement | Row | Questions |
|---|---|---|
| Own the complaints process end to end across branches | F1 | A1, B2, E2, G1, G3, H4, I1 |
| Across the contact centre | F2 | B1, C1, C2, G1, J1 |
| Report monthly on volumes and resolution times | F3 | B3, C3, E1, E2, F1, H3 |
| Experience handling regulated complaints | F4 | B2, E2, G1 |
| Coach branch supervisors on escalations | F5 | D1, G2, H2 |
| Work with digital teams on self-service journeys | F6 | A2, D3, F2 |
| 4+ years in financial-services customer operations | F7 | A1, C4 |
| Confident presenting to senior leaders | F8 | C1, C3, D2 |
| Comfortable with Excel reporting | F9 | B3, E1 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script". The limit is the pack's observation: your material says one branch's log. Slots stay inside the log |
| Coached supervisors on escalations | Inflated form of F5 | F5's quote at its own scope, as above. The limit is the pack's observation: your material says new tellers. D1's slot stays inside the tellers |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Has presented to anyone above regional level | Negative you stated, F8 | The plain acknowledgment: "I haven't presented to anyone above regional level." No slot |

## Sources

Provided documents: the JD (your message); the values text, pasted from ashgrovecu.org/about/values on 17 November 2026 (your message; not fetched); the recruiter's email on the three rounds (your message); the July 2026 strategy brief as you summarised it (your message); your background (your message). No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the cheat sheet and the VAL bank, with the four values by name |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the loop: three rounds, who runs each, the case and the values round; it sets every persona weight |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Your summary of the July 2026 brief already supplies the priorities that feed A2, F2 and G3 |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names were given, so there was no query to form; the upgrade menu says what a name unlocks |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Your CV → the fit snapshot's evidence cells quote it, which may lift F1, F3, F4 and F5 and tell us whether anything answers F6
- A sanitised sample of the monthly complaints spreadsheet, with member details removed → F3 and F9 can move from medium or low toward high, the strongest evidence in this field
- Your answers to the answer slots (F1, F3, F4, F5, F6, F9) → those rows regenerate from your own words, and the slots in B2, E1, E2, D1, H2, H3, H4 turn into story maps
- The two branch managers' and the Head of Member Services' names → an interviewer read, persona weights read from public footprint, and a reverse question tied to each one's path
- The full strategy brief text, or the recruiter's answers on the case format → CO questions use its wording and numbers instead of your summary, and G1 is tuned to the case
- Your prep time before 26 November → a prioritised schedule of the few things to do well, with everything else as insurance
- Deeper research, once offered: up to 6 more searches and 2 more fetches, several more minutes, covering role-family loop reports and recent organisation context → fewer generic rows in the CASE bank
- A tuesday-dossier.md, if you have one → verified-evidence and prohibited-claims constraints that tighten every guidance cell; never a prerequisite
