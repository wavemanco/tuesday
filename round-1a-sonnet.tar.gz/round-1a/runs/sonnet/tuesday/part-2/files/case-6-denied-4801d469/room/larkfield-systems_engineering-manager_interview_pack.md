# Interview pack — Engineering Manager, Larkfield Systems (loop mode, three rounds)

Candidate: Yusuf. Built from your message alone: no full posting text, no CV, no web research (see Sources). Rounds, in order:

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| Tuesday | Tuesday | Director of Engineering, your would-be boss | 45 min | Hiring manager |
| Panel | The Thursday after | Two staff engineers and a product manager | 60 min | Panel: technical peers plus cross-functional |
| Final | The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" | 30 min | Skip-level / executive, values-style |

## How to use this pack

Personas are how a question is asked; types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows how you lead, beyond generic virtue |
| EXP | Whether what you claim about your own work survives follow-ups, including what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge (none in this pack: no research ran) |
| CASE | A live problem from the role, scored on structure and reasoning |

Question IDs: T for Tuesday, P for the panel, M for Monday. Answer slots are instructions for the interview, not questions for you here.

One cross-round rule: the reliability story appears in T7, P4 and M1. Tell it the same way each time, at the scope of your own sentence, because three people will each hear it in a different register.

## Prep triage

Sequence is Tuesday, then Thursday, then Monday. Do these, in this order:

1. T2, the highest-ROI rehearsal in the whole pack: the hardware-adjacent roadmap objection. Rehearse it aloud until it is boring. It returns as P1's seam question and as M6.
2. T7, the reliability quarter with its four figure slots. The same story anchors P4 and M1.
3. T9, your 90-second arc, then T8, the hiring loop.
4. Before Thursday: P1, P5, P7. Before Monday: M1, M5, M3.

Everything else is insurance.

## Fit snapshot (shared by all three rounds)

Requirements are quoted from the role description in your message. Evidence is your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says a team of six, with nothing inspected behind it, and the words stay there: "I've been a team lead of six for three of my nine years in engineering." The step to two squads is the pack's observation, not words for you. Plain acknowledgment, sourced to your message: "I've never managed managers." The role description does not say whether anyone reports to this role beneath the 11 engineers, which is a reverse question for Tuesday. Answer slot: scale is the likely probe; say plainly what the six were and what you led, and if anything beyond that team was yours, say what, in your own words; if not, say so and stay with the team of six |
| F2 | "own delivery" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Say it at the sentence's scope: you pushed a reliability quarter through against roadmap pressure, and the on-call burden dropped 60% after. "After" is the sentence's order; it claims no more than that. The figure raises four slots, each in your own words: how the 60% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer slot: the posting's "own delivery" makes a probe on delivery commitments likely; if you held delivery for a team's roadmap, say what and how, in your own words; if delivery sat with someone else, or there was no such commitment, say so plainly and stay with the reliability quarter |
| F3 | "hiring" — role description | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | Lead with the loop in the quote's own terms: you run it, for backend roles, about 40 interviews last year. The quote does not say who decided on hires or set the bar, so neither is said for you. The figure raises its four slots; one to settle before you speak is whether the 40 were interviews you conducted or interviews the loop held |
| F4 | "growth for 11 engineers" — role description | none given | none | [grounded] | discovery | Nothing in your material shows or denies this. Answer slot: the posting names growth, so expect a probe; if you have supported an engineer's growth, say what you did and what changed, in your own words; if not, say so plainly and say how you would start |
| F5 | "device-management services" — role description | none given | none | [grounded] | discovery | Nothing in your material touches this domain. Answer slot: if any service you have worked on involved devices or connected hardware, say how, in your own words; if not, say so plainly and say what you would read or ask first |
| F6 | "partner with hardware and product on roadmap" — role description, hardware half | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | low | [grounded] | discovery | Plain acknowledgment, sourced to your message: "I've never owned a hardware-adjacent roadmap." The pack's observation: the posting says partner, not own, and your material does not show whether you have worked alongside a hardware or firmware team. Answer slot: if you have, say how and which part was yours, in your own words; if not, say so plainly and move to how you would build the working relationship |
| F7 | "partner with hardware and product on roadmap" — role description, product half | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [grounded] | transferability | The sentence carries roadmap pressure and a push against it, and does not say who applied the pressure. Words stay at that scope. Answer slot: if the pressure came from product, say who and how it was resolved, in your own words; if it did not, or the resolution was not yours, say so plainly |

## Round 1 — Tuesday: Director of Engineering (45 min)

### Persona weights

| Persona | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | High | Hiring-manager prior: they are buying capability and derisking gaps; your own message names two gaps, F1 scale and F6 hardware | Rehearse the single predictable objection until it is boring; concede the exact limit, then give a ramp plan |
| Case / Strategist | High | Hiring-manager prior: live problems from their actual roadmap; the role is delivery plus a hardware partnership | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Data-Driven Prober | Medium | Your CV-style claims carry figures (60%, about 40 interviews), which draw denominator questions | Know how each figure was counted and say plainly when you do not |
| Conversational | Medium | A 45-minute boss conversation usually opens with the biography; casual questions are still scored | A 90-second arc built only from your own sentence |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Pick the weakness your own words already name: "I've never owned a hardware-adjacent roadmap." Then a ramp plan in the future tense, as a plan and never as a past. Answer slot: if you have worked beside a hardware or firmware team, say how, in your own words; if not, say so plainly and go to the plan | F6 is the thinnest row and the posting names it, so this is the natural opener for the Skeptic; JD because it scores a stated requirement and its gap |
| T2 | "You've said you haven't owned a hardware-adjacent roadmap. How would you handle that in this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The highest-ROI prep in this pack. Round one, concede exactly: "I've never owned a hardware-adjacent roadmap." Do not concede more than that, and do not add to it. Round two, the follow-up on earning hardware's trust: answer as a plan, naming who you would sit with first and what you would learn, in your own words. Round three, the follow-up on dates slipping while product will not move: the only roadmap-pressure story your material carries is the sentence quoted here, so use it at its scope. Answer slot: if the pressure came from product, say who and how it was resolved; if it did not, or it was not yours to resolve, say so plainly. Close by conceding the ramp is a real risk and saying what you would make visible in the first weeks. Hold through three follow-ups by returning to the quoted limit, never by adding to it | F6 and F7 are where the posting presses hardest and your material is thinnest; this objection arrives in some form; JD because it scores a stated requirement |
| T3 | "Why this role, and why now?" | JD | [grounded] "currently at a payments company" | Say where you are now in the quote's terms, then your real reasons for this move, in your own words. Answer slot: give your actual reasons for moving into industrial IoT; nothing in your material states them, so none are supplied here. Keep them consistent with what you tell the VP on Monday | Motivation consistency is what the Skeptic scores, and the move from payments to device management is visible in F5; JD because it tests fit with the listed role |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T4 | "Sketch your first 90 days leading these two squads. What do you need to know first?" | CASE | [generic] | Clarify before structuring: what each squad owns, who consumes its services inside the company, what hardware and product currently expect, what the on-call picture is, and what each of the 11 engineers wants from the next year. Then objective, sequence, metrics, risks. Challenge one premise politely, for example whether two squads should be run identically. The question needs no claim about your past, so the guidance makes none | Stem from the Case persona; covers F1 and F4 as a plan rather than a claim; CASE because it is live and scores structure |
| T5 | "A hardware release slips by a quarter and product wants the device-management roadmap unchanged. Walk me through what you do." | CASE | [generic] | Clarify what actually depends on the release, structure the options with their costs, say who you would bring in and in what order, and state what you would decide yourself versus escalate. Offer a recommendation and one concession. No claim about your past is made or needed | Live problem on the hardware and product seam in F6 and F7; CASE |
| T6 | "Pages across both squads doubled in a month. Diagnose it." | CASE | [generic] | Clarify scope and baseline first, then segment by service, change window and alert type, then hypotheses ranked by cost to test, then what you would stop to protect on-call. Think aloud and name what you would not know yet | Diagnosis stem on the reliability theme the role's delivery duty touches, F2; CASE |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T7 | "Tell me about the reliability quarter. How was the 60% counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Beats the sentence states: a reliability quarter, roadmap pressure, you pushed it through, the on-call burden dropped 60% after. Four slots, each in your own words: how the 60% was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how something was counted, say so plainly. Do not turn "after" into "because" | F2's figure is the magnet for a prober; EXP because it tests attribution and counting |
| T8 | "Walk me through how you run the hiring loop for backend roles." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Beats the sentence states: you run it, for backend roles, about 40 interviews last year. Answer slot: the posting's hiring duty makes a probe on bar-setting and calibration likely; if you set or calibrated the bar, say how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the loop you run. Settle before speaking whether the 40 were interviews you conducted or the loop held, and say which | F3 is your strongest requirement row, so it gets probed for limits; EXP |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T9 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc built only from that sentence: nine years in engineering, three of them as a team lead of six, and where you are now. Answer slot: the step from here to this role is yours to say; give your real reason in your own words, since your material does not state it | The biography question opens most boss conversations and is still scored; EXP; F1 is the row it draws on |

### Reverse questions for Tuesday

| # | Question | Why it lands |
|---|---|---|
| TR1 | "What would the two squads have to look like at six and twelve months for you to call this a good hire?" | Turns an unspoken scorecard into stated outcomes you can then work to |
| TR2 | "Are there tech leads or managers beneath this role today, and is that expected to change?" | The posting is silent on it and your material says you have not managed managers, so the answer sizes the scale step honestly |
| TR3 | "Where does the hardware roadmap meet device management today, and where does it hurt?" | Shows you are pricing the F6 gap as a working relationship, not hiding it |
| TR4 | "How is on-call shared across the two squads, and how does reliability work earn a place on the roadmap?" | Connects to your own reliability sentence without claiming more than it says |
| TR5 | "What would you want to be different 90 days after I start?" | Gives you a concrete target and signals you plan to be measured |

## Round 2 — The panel: two staff engineers and a product manager (60 min)

### Persona weights

Blended from each member's relationship, since no names were given.

| Persona | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | High | Staff engineers price what a new manager costs and contributes to their work; the PM is a cross-functional counterpart on the seam | Reciprocity: what you bring them as well as what you need; offer seam principles instead of pretending to know the seam |
| Data-Driven Prober | High | Technical specialists verify depth; your figures and the hiring claim are both probe targets | Know how each figure was counted; name your weakest assumption first |
| Values / Behavioral | Medium | The PM is outside the function, so expect scenario questions on trade-offs and saying no | Map a story only where your own sentence carries one; otherwise a selection scaffold |
| Conversational | Low | Panels open lightly, but the slot exists for the question on what you are exploring in the domain | Treat it as scored |
| Pressure | Low | Not the dominant register for peers, though follow-ups can press | Hold, then concede specifically |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Where is the seam between an engineering manager and staff engineers on technical decisions, and what happens when we disagree?" | JD | [generic] | Offer principles, not a map of a seam you have not seen: who owns the outcome, who owns the technical call, how disagreement is surfaced early, and what a manager does not override. Then a disagreement shape with spine and tact. No claim about your past is made; where you tell a real example, use a selection scaffold: pick a disagreement with a senior engineer that had a named stake and an intact relationship afterwards, and if none comes to mind, say so plainly, then say how you would handle it | Peer persona stem; F1's leadership duty meets staff-engineer territory; JD |
| P2 | "How do you handle credit when work spans squads?" | VAL | [generic] | Selection scaffold: pick an occasion where credit had to be shared across teams, with a named person and a visible outcome; say what you did and what they got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer persona stem; VAL because it scores how you behave toward equals |
| P3 | "What would you need from the staff engineers, and what would you bring them?" | JD | [generic] | Lead with what you bring, as a plan: what you would take off their plate and what you would protect for them. Then what you need, kept short. No claim about your past is made | Reciprocity framing is the Peer counter-strategy; F1 |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P4 | "Which part of the on-call drop was yours, and which was the team's?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Your claim is what the sentence makes: you pushed a reliability quarter through against roadmap pressure. Four slots, each in your own words: how the 60% was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how something was counted, say so plainly. Tell it exactly as you told it on Tuesday | Same story as T7 asked as an attribution probe; F2; EXP |
| P5 | "You run the hiring loop. What is your bar for a backend hire, and how do you calibrate across interviewers?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start from the quote: you run the loop for backend roles, about 40 interviews last year. Answer slot: if you set the bar or calibrated interviewers, say how, in your own words; if there was no such step, or it was not yours, say so plainly and return to the loop you run. Say which kind of interview the 40 were | F3; the staff engineers are likely interviewers too, so this question is about to matter to them; EXP |
| P6 | "We need a backend engineer who can work close to firmware and nobody on your team has that background. How do you design the loop?" | CASE | [generic] | Structure it: what the role needs, what a hardware colleague should test, how you separate learnable from missing, and what a fair work sample looks like. Say where you would borrow hardware colleagues' judgement. No claim about your past is made | F3 meeting F5 and F6 as a live problem; CASE |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P7 | "Product wants a feature this quarter, and your engineers say reliability debt makes it risky. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure first: what each side risks, what evidence would change the call, who decides, what you tell the loser. If you answer from your own story, say only what the sentence says. Answer slot: if the pressure came from product, say who and how it was resolved, in your own words; if it did not, say so plainly | F7; the PM will hear this as a trade-off from their side; CASE |
| P8 | "Tell me about a time you said no to a stakeholder." | VAL | [generic] | Selection scaffold: pick an occasion with a named stake, a moment you did not fold, and a relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The reliability sentence may be your nearest, but it does not say that a no was said, so do not tell it as one | The PM-style behavioural probe; F7; VAL |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P9 | "What are you actually playing with in device fleets and IoT these days?" | JD | [generic] | Answer slot: if you are working with anything in this space, say what, in your own words; if not, say so plainly and say what you have started to read or would read first. Do not invent a side project | Persona stem on the JD's domain; F5 has no evidence, so the honest branch is the likely one |

### Reverse questions for the panel

| # | Question | Why it lands |
|---|---|---|
| PR1 | "Which technical decisions do staff engineers own here, and where has the line with the manager been unclear?" | Shows you are asking about the seam rather than assuming it |
| PR2 | "What could a new manager do in their first month that would genuinely help your work?" | The peer reciprocity question |
| PR3 | "What is on-call like today across the device-management services?" | Honest, specific, and ties to your reliability work without claiming it applies |
| PR4 | "When product, hardware and engineering disagree on a date, who has the last word?" | Aimed at the PM; draws out the seam behind F6 and F7 |
| PR5 | "Where do device-management features most often slip, and what would you want a manager to do about it?" | Invites each panellist to describe their own pain, which gives you something concrete to act on |

## Round 3 — Monday: VP Engineering (30 min, values and leadership philosophy)

### Persona weights

The recruiter's own description is the loop source for this round's values-style character. Published company values were not available, so no value is named in this pack.

| Persona | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | High | The recruiter described this round as "values and leadership philosophy" | A story only where your own sentence carries one; otherwise a scaffold ending in its honest branch; "we" for context, "I" for contribution |
| Pressure | Medium | Skip-level prior: altitude and composure, short time boxes in 30 minutes | Pause, restate, hold the position, concede specifically |
| Case / Strategist | Medium | Skip-level prior: strategy-heavy, though here it is leadership altitude | Say the structure aloud; one recommendation, one concession |
| Skeptic | Medium | A VP will re-ask the biggest gap from Tuesday's notes, F6 | Same limit, same words as T2 |
| Conversational | Low | Thirty minutes leaves little room for rapport | Be economical |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Beats the sentence carries: a reliability quarter, roadmap pressure, you pushed it through. Answer slot: if the truth you delivered was about the quarter's cost to the roadmap and it reached leadership, say who and what you said, in your own words; if the pressure came from somewhere else, or nothing of this was said upward, say so plainly. The sentence does not say the hard truth landed, so do not supply an ending. Same story as T7 and P4 | Persona stem; F2 and F7; VAL because it scores behaviour under pressure |
| M2 | "When did you put the people who rely on your service ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick an occasion with a named stake, a decision you made, and who relied on the service. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem adapted to a services role; VAL |
| M3 | "What is your philosophy of leading engineers?" | VAL | [generic] | The recruiter's own words, leadership philosophy, raise this. Pick two or three principles you actually practise, and for each give one real instance from your own work, in your own words. Do not recite principles you cannot attach to something you did; if no instance comes to mind for one, drop that principle and say so plainly | Raised by the recruiter's description of this round; VAL |
| M4 | "How do you think about growing engineers, and how would you know it is working?" | JD | [generic] | Answer slot: the posting's growth duty makes this likely; if you have supported an engineer's growth, say what you did and what changed, in your own words; if not, say so plainly and say how you would start and what you would watch | F4 has no evidence; JD |

### Pressure and Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M5 | "Sixty seconds: why you for two squads when you have led a team of six?" | JD | [grounded] "3 as a team lead of 6" | Hold: "I've been a team lead of six for three of my nine years in engineering." Concede the step in size plainly, as your own observation. If the question turns to managers, the sourced acknowledgment is "I've never managed managers." Then your ramp plan, as a plan. Hold through two follow-ups by returning to what the sentence carries | F1; the Pressure stem adapted; JD |
| M6 | "You have not owned a hardware-adjacent roadmap. Why should I be comfortable with that?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | A 60-second version of T2: the exact concession, "I've never owned a hardware-adjacent roadmap", then the plan, in your own words. Answer slot: if you have worked beside a hardware or firmware team, say how; if not, say so plainly | F6; the VP will have seen Tuesday's notes in some form; JD |

### Case / Strategist and Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M7 | "Six months in, what would make you decide that reliability matters more than the roadmap for these squads?" | CASE | [generic] | State the structure aloud: the signals you would watch, the threshold at which you would stop feature work, who you would take it to, and the cost you would name. One recommendation, one concession. No claim about your past is made; if you reach for your own story, use only the sentence quoted under M1 | A leadership-altitude version of the reliability theme in F2; CASE |
| M8 | "A year from now, what would you want your engineers to say about working for you?" | VAL | [generic] | Pick two or three things you would genuinely want said, and for each say what you would do to earn it. Selection scaffold: if one has an instance from your own work, give it in your own words; if none comes to mind, say so plainly and say how you would build it | Leadership-philosophy theme from the recruiter's description; VAL |

### Reverse questions for Monday

| # | Question | Why it lands |
|---|---|---|
| MR1 | "Which engineering leaders here have done well, and what do they have in common?" | Invites the VP to describe the philosophy you are being scored against |
| MR2 | "Which decisions do you want a manager at my level to escalate, and which to just make?" | Shows you want the boundaries stated |
| MR3 | "What gap is this role really meant to close for the org?" | Surfaces the purpose behind the posting |
| MR4 | "How do you hear about problems early, and what has made that hard?" | Fits a leadership-philosophy conversation and tests candour |
| MR5 | "What would make you regret this hire a year from now?" | Names the downside directly, which a values round rewards |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 "Lead two squads building device-management services" | T1, T4, T9, P1, P3, M5 |
| F2 "own delivery" | T5, T6, T7, P4, P7, M1, M7 |
| F3 "hiring" | T8, P5, P6 |
| F4 "growth for 11 engineers" | T4, M3, M4, M8 |
| F5 "device-management services" | T3, T4, P6, P9 |
| F6 "partner with hardware" | T1, T2, T5, P6, PR4, M6 |
| F7 "partner with product on roadmap" | T5, P7, P8, M1 |

No requirement is left without a question. No CO question exists because no research ran.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed or led two squads, or 11 engineers | Inflated form of F1 | F1's quote at its own scope. The pack's observation, not words for you: the material says a team of six, not two squads. T4 and M5 stay inside the team of six |
| Managed managers, or led leaders | Negative you stated, F1 and F6 | The plain acknowledgment: "I've never managed managers." No slot |
| Owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." The slots stay on partnering |
| Cut on-call burden by 60% through work you drove | Inflated form of F2 | F2's quote at its own scope: you pushed a reliability quarter through, and the burden dropped 60% after. The four figure slots in T7 and P4 |
| Designed or built the hiring process, or made the hiring decisions | Inflated form of F3 | F3's quote at its own scope: you run the loop for backend roles, about 40 interviews. T8 and P5 slots stay on the loop |

## Sources

Provided documents: your message, which contained the role description, the three round descriptions, the recruiter's phrase for the Monday round, and your background. No posting text, CV or interviewer profile was provided.

Searches sent, all refused by the host before returning anything:

- "Larkfield Systems values principles industrial IoT": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems industrial IoT device management strategy news": refused

No page was fetched. Everything company-specific that research would have supplied is absent, not generic-filled: no published values, no strategy context, no confirmation of the loop beyond your own description. The loop itself comes from your words: three sessions, who runs each, and the recruiter's description of the third.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have supplied the official value names for a values cheat sheet and for Monday's VAL themes; section dropped |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The search was refused. It would have checked the rounds against a published loop; persona weights rest on your description instead |
| 3. `Larkfield Systems strategy` | unavailable | The search was refused. It would have grounded one or more CO or CASE questions in current priorities; none are written |
| 4. interviewer name and company | n/a | No names were given, so there was no query to form; the interviewer read is absent |
| 5. representative `Engineering Manager` JD | unavailable | Search permission was refused on the three calls sent, so no further call was attempted. It would have added inferred requirements beyond the one-paragraph role description |

## Upgrade menu

- The full posting text → rows quoted from the role description become fuller, and any requirement the description omits gains a question
- Your CV → fit rows move from your message's sentences to inspectable CV lines, and several medium rows could rise or be corrected
- Recruiter guidance for each round (focus areas, a case, a take-home) → coverage for a pre-declared deliverable, and per-round persona weights tighten
- The names of the two staff engineers, the product manager and the two leaders → an interviewer read for each and reverse questions tied to their paths
- Web search permission, so the company's published values, process and strategy can be researched → a values cheat sheet for Monday, CO questions grounded in current priorities, and a loop check
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and a named top objection in place of the one inferred here
- Your answers to the slots in F1 to F7 → each row upgrades from an answer slot to a story with its beats mapped
