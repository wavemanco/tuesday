import re
p = '/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-4-denied-ec4bc30d/Quartzline_product-manager-platform-apis_interview_pack.md'
s = open(p).read()
Q = {
    'Q1': '"Led 30+ end-to-end client integrations of the vendor\'s REST APIs — scoping, requirements, architecture, UAT, go-live"',
    'Q2': '"Wrote the internal integration playbook her team uses"',
    'Q3': '"Ran quarterly roadmap-input sessions feeding client evidence to product"',
}
def f(m):
    return '| [grounded] ' + '; '.join(Q[q.strip()] for q in m.group(1).split(',')) + ' |'
s, n = re.subn(r'\| \[grounded\] (Q\d(?:, Q\d)*) \|', f, s)
print(n)
s = re.sub(r"Provenance quotes are the sentences.*?\n- Q3 = [^\n]*\n",
           "Provenance quotes are the sentences each cell rests on, copied from the fit snapshot. A row whose guidance makes no claim about you carries its label alone.\n",
           s, flags=re.S)
open(p, 'w').write(s)
print(re.findall(r'\bQ[123]\b', s))
