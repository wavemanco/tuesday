# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, Tuesday. Panel of Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: a 15-minute POV from you, then Q&A in which Ross will push on commercials.
**Built on:** your message only. No job description was supplied, the market report was attached to the recruiter's email but is not in my hands, and every web search I tried was refused. Where the pack would normally rest on Kelverton research it says `[generic]` instead.

## How to use this, and the type key

Personas describe how a question is asked. Types describe what is being scored. The guidance in each row is scaffolding for a spoken answer, not a script. Everything proposed for you to say is pending your approval, and none of it should go past what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Past behaviour against the company's published values. No question carries it here, because no values round is documented and no values page was read |
| EXP | Whether your own claims survive scrutiny, and what was actually you |
| JD | The stated job, including its gaps |
| CO | Knowledge of the company's strategy and market |
| CASE | A live problem set in the role |

## Prep triage (about four hours, spread over the weekend)

| Order | Time | Do this | Section | Done when |
|---|---|---|---|---|
| 1 | 80 min | Build the POV. You hold the market report, so pick your consensus item, your divergence and your anti-pick from it | Graded deliverable | You have three theses, each with its concession, and a close in operators' terms |
| 2 | 40 min | Say the POV aloud twice, timed, with no notes | Graded deliverable | It runs 13 minutes, leaving 2 spare |
| 3 | 45 min | Rehearse B2 aloud, then D1, with someone pushing twice on each | B2, D1 | You can concede and hold without adding anything new |
| 4 | 30 min | Write your own answers to the four slots on each figure | C1, C2 | You know which parts you can count and which you cannot |
| 5 | 20 min | Talk through A1 and A4 aloud, structure only | A1, A4 | You clarify before you structure |
| 6 | 15 min | Choose three reverse questions, one of them for Ross | Reverse questions | You have three you would actually ask |

Everything else in the pack is insurance.

## Fit snapshot

The requirements come from the recruiter's quoted email, or are role-family prose with no source. Your own sentences are quoted from your message.

Proposed language: pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material carries partnership work in payments, not operator partnerships, and the words stay at that scope: "For the last four years I ran the ISV channel at a payments company, and it went from 6 partners to 40." Answer slot: the recruiter's POV ask makes a probe on how that carries to operators likely. If any part of it put you in front of operators, say what, in your own words; if none did, or it was not yours, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says consulting on bus and light rail network planning. It does not show work inside an operator, or on heavy rail, and the words stay there: "I spent five years in transport consulting on bus and light rail network planning." Answer slot: if that work put you in front of operators' own teams, say who and what you did with them, in your own words; if it did not, or it was not yours, say so plainly and stay with the network planning |
| F3 | Grow a partner portfolio — role-family, no source | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | none | No gap on the requirement, but a line with nothing inspected behind it, so expect a probe on the counting (C2). Lead with the quote in its own terms: you ran the channel, and it went from 6 partners to 40 |
| F4 | "Ross will push on commercials" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The figure is influenced revenue, and the words keep it so: "roughly £4M of influenced revenue." Your material does not show how it was counted or what share was yours. Answer slot: say how it was counted if you know, what it is most sensitive to, the assumption you would defend least, and which part was yours, each in your own words; if you do not know how it was counted, say so plainly and return to the figure as stated |
| F5 | Carry a direct revenue target — role-family, no source | "Never sold into rail specifically and never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never carried a direct quota, only influenced revenue." Then how you would work to a number here, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | Sell into rail operators — role-family, no source | "Never sold into rail specifically and never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | You have stated it. Words: "I haven't sold into rail specifically." Then whom you would ask first and what you would ask, as a plan. Never a claim to rail sales |
| F7 | Understand how scheduling software fits operators' work — role-family, no source | none given | none | [generic] | discovery | Strong evidence here would be a specific piece of your own work where operators' scheduling constraints shaped a decision. Selection scaffold: pick work from your network planning years only if it shows a named constraint, what you did about it, and what happened; if no such work comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would learn it |

There are no gate rows. Without a job description, nothing stated is a term you either meet or do not, such as location or right to work. The upgrade menu says what the posting would settle.

## Graded deliverable: the 15-minute POV

The recruiter named it, so it is graded. Her words to build on are "where you'd take our operator partnerships over the next 18 months", "no slides needed, just talk us through it" and "Please land on what it means for the operators themselves".

**Grounded facts to build on.** Each is a sentence quoted exactly from the fit snapshot's evidence cell.

| Fact | Quote (from F-row evidence cell) | Use it at this scope |
|---|---|---|
| F3 | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | The channel and its scale, and the influenced figure called influenced |
| F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Network planning in consulting, bus and light rail. Let the interviewer ask what "the other side" meant, and answer in your own words |
| F5 | "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | The stated limits, used as the opening concession |

**Three theses.** Each has a mandatory concession. Spoken forms are proposed, pending your approval.

| Thesis | Spoken form (pending your approval) | Mandatory concession | Provenance |
|---|---|---|---|
| T1. Start from what changes for the operator, then work backwards to partners | "I'd start from what an operator's planning or operations team can do at month eighteen that they can't do today, and let that choose which partnerships we build." | "I'm building this without Kelverton's pipeline, win and loss data or partner data, so the first ninety days would test it." | [generic] |
| T2. Operator outcomes first; partner count follows | "I took the ISV channel from 6 partners to 40. Here I'd make operator outcomes the first measure and let partner count follow." | "I haven't sold into rail specifically, so this is a hypothesis to test with operators, not a lesson from rail." | [grounded] "took it from 6 partners to 40" and "Never sold into rail specifically" |
| T3. Report two numbers that both Ross and operators can audit | "I'd report partner-sourced and partner-influenced separately, and agree the definitions with Ross's team in month one, because I've only worked to influenced revenue." | "I have never carried a direct quota, only influenced revenue." | [grounded] "never carried a direct quota, only influenced revenue" |

**Differentiation from the report.** The strategy team circulated it, so Deepa and Ross have read it and so has every prepared candidate. Take one consensus item from it, to prove you read it. Then take one thing where you depart from it, with your reason. Do not recite its shortlist. Do not coach the interviewers on their own report. I have not seen it, so the pack names no item. The choice is yours, and the upgrade menu says what pasting it would change.

**The anti-pick.** The role includes saying no, so name one thing you would deliberately not do in the 18 months. T2 suggests one candidate: a partner-count target. Whatever you choose must come from your own judgement, with the criterion stated as operator outcome.

**The close the recruiter asked for.** Spend the last three minutes on operators. Name one thing an operator's planning or operations team can do at month eighteen that they cannot do now, in the operators' own words from the report. Then say what would make you wrong.

**Suggested clock (pending your approval).** Minutes 0 to 1: frame. 1 to 4: the consensus item and what you cannot know from outside. 4 to 10: the three theses, about two minutes each. 10 to 13: what it means for operators. 13 to 15: concessions and an invitation to push back.

## Persona table

The loop source is the recruiter's email, which establishes this one session: two interviewers, 60 minutes, a 15-minute POV and then Q&A. Weights start from relationship priors (Deepa as hiring manager, Ross as a commercial senior) and are adjusted by what the email says.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Live problems and follow-ups on your POV | high | Deepa is "your future manager", the hiring-manager row, and the POV sets a strategic frame the follow-ups will test | Clarify, structure, answer, name one premise you would challenge; the bank is A |
| Skeptic | Quiet probing of the gaps you have stated | high | Hiring-manager row, and F5 and F6 are stated limits that will be probed in some form | Rehearse B2 until it is boring; concede in your own stated words; the bank is B |
| Data-Driven Prober | Asks how each figure was counted | high | "Ross will push on commercials", and F4 is an influenced figure with nothing inspected behind it | Know which parts you can count and say plainly which you cannot; the bank is C |
| Pressure | Interrupts, time-boxes, tests whether you hold | medium | Ross's push on commercials, and the executive-altitude row, make time-boxed challenges plausible | Pause, restate, hold through two follow-ups, concede only what is true; the bank is D |
| Conversational | Friendly openers that are still scored | low | Opening question to a future manager is likely a biography question | A 90-second arc built only from your own sentences; the bank is E |
| Values/Behavioral | Stories mapped to published values | low | No loop source documents a values round, and no values page was read, so no bank | Not banked; the upgrade menu says what would change this |
| Peer Evaluator | Seam-splitting with an equal | low | Neither panellist is described as a peer on the team, so no bank | Not banked |

## Question banks

Proposed language in the guidance cells: pending your approval.

### A. Case/Strategist (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've been in the seat a month. What do you still need to learn before you'd commit to an eighteen-month plan?" | CASE | [generic] | Clarify before you structure: what the plan is for, which operators and which partner types it covers, what Ross's team already counts, what has been tried. Say which of those you can only learn from inside. Think aloud and name the one premise you would challenge. The question needs no claim about your past, so the guidance makes none | The natural first follow-up to a POV; CASE because it scores structure; `[generic]` because it is a pattern for the problem, not a fact about Kelverton |
| A2 | "Take two operators of very different size. What changes in your plan between them?" | CASE | [generic] | Segment first: what each needs from a partner, who decides, how fast either can change anything, what you would measure. Use the report's own segmentation language where you recall it, and say you are reasoning from the report and not from Kelverton's account data. No claim about your past | Tests the "land on operators" ask with a live segmentation; CASE because it asks for a structure |
| A3 | "What would you drop first if we halved the budget?" | CASE | [generic] | Your anti-pick from the deliverable is the answer. Show the criterion, operator outcome and not partner count, and concede that without Kelverton's data the ranking is provisional. No claim about your past | Cuts follow a POV that names priorities; CASE because it scores trade-off reasoning |
| A4 | "A partner is bringing us pipeline, but an operator is unhappy with the partner's work. What do you do?" | CASE | [generic] | Operator outcome first: who you speak to first, what you check before taking sides, what you record, how you tell the partner. Structure only, with no story about your past | A live tension between the commercial and operator sides of the POV; CASE |
| A5 | "What do you think an operator is actually buying when it buys scheduling software, and where could a partner change that?" | CO | [generic] | Say it as a hypothesis. Draw vocabulary from the report you have read: one consensus item, then your own divergence. Say plainly what you cannot know from outside. No claim about your past | The company-altitude question; `[generic]` because no Kelverton research could run, which the upgrade menu says |

### B. Skeptic (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail. What would you not know on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Open with the acknowledgment, in your own stated words: "I haven't sold into rail specifically." Then tell the consulting years as the quote has them: network planning, bus and light rail. Answer slot: if that work put you in front of operators' own teams, say who and what you did with them; if it did not, or it was not yours, say so plainly and stay with the network planning. Close with a plan: whom you would ask first and what you would ask | F6 is the stated limit and the most predictable opening; JD because it scores the stated role |
| B2 | "You've never carried a quota. Why should we trust you with a number here?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | **The highest-ROI rehearsal in this pack.** Level 0, concede exactly and first: "I have never carried a direct quota, only influenced revenue." Level 1, hold on what the quote carries, "roughly £4M of influenced revenue", never calling it sourced or booked. Follow-up one, likely "what's the difference in practice?": answer slot: if you know how the influence was counted and what part was yours, say so in your own words; if you do not, say so plainly and return to the figure as stated. Follow-up two, likely "would you take a direct number here?": answer slot: say your own position, including that you would want to see the pipeline first if that is true; the pack supplies no figure. Hold by returning to the quote, never by adding to it. The limit, named before it is asked: your material does not show how the figure was counted or your share of it | Ross will "push on commercials", and F5 is where that push lands hardest, so this arrives in some form; JD because it scores the stated job |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Pick one limit your own words support, not selling into rail or not having carried a direct quota, and say it in the acknowledgment words. Then give a plan, not a past. Do not choose a weakness your material does not show | The stem is the Skeptic's standard probe; it tests honest self-assessment against F5 and F6 |
| B4 | "Why leave payments, why us, and why now?" | EXP | [generic] | The reason is yours, in your own words, in about thirty seconds. The pack supplies none. Tie it to operators only if that is really why | Motivation consistency is what the Skeptic scores; EXP because it tests whether your story survives cross-examination |
| B5 | "What from your payments channel work would you deliberately not bring here?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | An open prompt: you choose. The quote carries the channel and its scale, 6 to 40 partners. Say what you would not carry over and why, as a judgement about the two settings. T2's partner-count point is one candidate. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide. Claim nothing about what worked there beyond the quote | Tests judgement about transfer, the other side of the F1 gap; EXP because it presses on your own channel work |

### C. Data-Driven Prober (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the roughly £4M of influenced revenue was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Defend the number. Four answer slots: how it was counted; what it is most sensitive to; the assumption you would defend least; which part was yours. Say each in your own words if you know it. If you do not know how it was counted, say so plainly, and return to the figure as stated. Name the weakest assumption before they do. The pack supplies no method, baseline or attribution model | F4 is the headline figure and the one Ross will test; EXP because it checks attribution |
| C2 | "Walk me through how the 6 and the 40 were counted, and how much of the move from one to the other was yours." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | The same four slots, applied to the partner count. Say what counted as a partner at each end if you know. If you do not know, or the count was not yours, say so plainly and return to "took it from 6 partners to 40" at its own scope | The second headline number on the line; EXP |
| C3 | "How would you report partner impact to Ross each quarter, and what is on the page?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | A forward-looking proposal, using T3: two numbers, partner-sourced and partner-influenced, with definitions agreed with Ross's team first, plus one operator-outcome measure from the report. Concede that you have only worked to influenced revenue. The guidance claims nothing about how you reported before | Raised by "Ross will push on commercials"; JD because it scores the stated job |
| C4 | "Two partners both claim credit for one operator deal. How do you decide?" | CASE | [generic] | Structure: what evidence each can show, what the operator says about who brought what, a rule agreed before any deal, who has the final call. Concede that some are judgement calls. No claim about how you handled it before | Attribution under pressure, in a form the Prober can press; CASE |

### D. Pressure (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has already sold into train operators?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Pause and restate. Concede first: "I haven't sold into rail specifically." Hold on what the quotes carry: nine years in partnerships, four of them on the ISV channel, 6 to 40; five years of transport consulting on bus and light rail network planning. Hold through two follow-ups by returning to those, and add no claim about how fast you learn. Concede one specific thing you would not know on day one | The stem is the Pressure persona's standard, aimed at F6; JD |
| D2 | "What number would you put your name against for the next eighteen months?" | JD | [grounded] | The question asks about the future, so the guidance makes no claim about your past. Answer slot: if you have a view on the right number, give it as your own position and say what it depends on; if you do not yet, say what you would need to see before committing, and when you would commit. Hold against being argued into a figure without data, and concede that any number is provisional | Raised by "Ross will push on commercials"; JD |
| D3 | "Why would an operator care about anything that comes through a partner and not from us directly?" | CASE | [generic] | Three beats: what a partner adds that the operator cannot get from Kelverton alone, what the operator would see change, and where a partner route is the wrong answer. Hold through two interruptions. No claim about your past | A time-boxed challenge to the POV's premise; CASE |

### E. Conversational (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | A 90-second arc, in the order the quotes give: five years of transport consulting on bus and light rail network planning; then nine years in partnerships, the last four running the ISV channel at a payments company. The reason you want this move is yours, in your own words; the pack supplies none | The biography question from a future manager, still scored; EXP |
| E2 | "What have you been reading or trying lately on scheduling for operators?" | CO | [grounded] "the market report their strategy team circulated internally last quarter, which I've read" | Answer slot: say what stood out to you in the report, in your own words; if nothing did, or you would rather not lean on it, say what else you have looked at, or say plainly that nothing else. Do not correct the interviewers on their own document | A casual question on a hot topic is scored; the report is the one source you hold that the pack does not |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "present a short POV on where you'd take our operator partnerships over the next 18 months" | Graded deliverable, A1, A2, A3, A4, B5, D3 |
| "Please land on what it means for the operators themselves" | Graded deliverable close, A2, A4, A5 |
| "Ross will push on commercials" | B2, C1, C2, C3, C4, D1, D2 |
| Sell into rail operators (role-family) | B1, B3, D1 |
| Grow a partner portfolio (role-family) | C2, B5, E1 |
| Understand how scheduling software fits operators (role-family) | A5, E2 |
| Values or behavioural alignment | none, no values round is documented and no values page was read |

## Reverse questions

There is no interviewer profile, so these are role-generic. Pick three and make one of them for Ross.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which operators, or which kinds of operator, does the team work with today, and which are you not yet reaching?" | Asks for what could not be researched, and shows you think in segments |
| R2 | "What would a good first six months look like in this seat, and what would tell you at month six that it wasn't working?" | Gets Deepa to state the scoring sheet, and lets you check it against your plan |
| R3 | "How is partner-influenced revenue counted here today, and who owns that number alongside the commercial team?" | Aimed at Ross: it opens commercials on terms you chose, and answers the question you will face in C1 |
| R4 | "What are operators asking for that the team can't answer yet?" | Moves the conversation to operators, the thing the recruiter asked you to land on |
| R5 | "Which part of the strategy report do you expect the team to disagree about most?" | Shows you read it as a document with live questions, not as a list to recite |
| R6 | "Where do partnerships end and the commercial team begin, and how do you two handle a deal both claim?" | A seam question to both of them; it tests whether the answer to C4 matches how they actually work |

## Prohibited claims

Built from the fit snapshot before the banks were written. No guidance cell, slot or drill feedback asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail, or has rail-operator sales experience | Negative you stated, F6 | The plain acknowledgment: "I haven't sold into rail specifically." No slot |
| Has carried a direct quota or owned a revenue target | Negative you stated, F5 | The plain acknowledgment: "I have never carried a direct quota, only influenced revenue." No slot |
| Sourced, closed or booked the £4M | Inflated form of F4 | The quote at its own scope: "roughly £4M of influenced revenue." The limit is the pack's observation: your material says influenced, and does not show how it was counted or your share. The slots in B2, C1 and C2 stay inside the quote |
| Built the channel from nothing | Contradicted by the F3 quote | The quote only: "took it from 6 partners to 40" |
| Knows the operator world from the inside, or has worked at an operator | Inflated form of F2 | The quote at its own scope. The limit is the pack's observation: your material says transport consulting on bus and light rail network planning, not work inside an operator or on heavy rail |

## Sources

**Provided.** Your message, including the recruiter's email as you quoted it. That email is the loop source for this one session. The market report was attached to the email but is not in my hands, so nothing in this pack comes from it.

**Searches sent, all refused.** No result came back from any of them.

- Kelverton Rail values: refused
- Kelverton Rail interview process partnerships: refused
- Kelverton Rail strategy scheduling software train operating companies: refused
- Deepa VP Partnerships Kelverton Rail: refused
- Ross Commercial Director Kelverton Rail: refused
- Senior Partnerships Manager rail technology job description train operating companies: refused

No page fetches were sent.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have fed a values cheat sheet if a values round were documented, and VAL questions if not; the pack has neither |
| 2. Kelverton Rail interview process, partnerships | unavailable | Would have tested the persona weights against documented loop reports; they now rest on the recruiter's email and relationship priors |
| 3. Kelverton Rail strategy and recent news | unavailable | Would have grounded A5 and E2 in current priorities; they are `[generic]` or rest on the report you read |
| 4. Interviewer public footprint | unavailable | Both calls were refused. It would have given an interviewer read and a reverse question tied to a career path; the pack has neither |
| 5. Representative role JD | unavailable | Would have given the fit snapshot role requirements to quote; the role-family rows are plain prose and raise no slots |

## Upgrade menu

- The job description pasted in → F3, F5, F6 and F7 get quoted requirements instead of role-family prose, any gate (location, right to work, travel) becomes a row, and the coverage table checks against its own list
- The market report's key pages pasted in → A2, A5, E2 and the deliverable's consensus item move from `[generic]` to `[grounded]`, and the differentiation advice names real items
- Each interviewer's surname or profile link → an interviewer read, tuned persona weights, and a reverse question tied to each person's path
- Search access granted for another attempt → Kelverton's published values (and a values cheat sheet if a round is documented), loop reports, and a current strategy sweep
- Your own words for the answer slots in F1, F2, F4, B1, B2, C1 and C2 → those rows become quoted evidence and the guidance can map a story instead of asking for one
- A tuesday-dossier.md from an earlier fit assessment of this role → verified evidence, a ranked objection list and a prohibited-claims list to build against
