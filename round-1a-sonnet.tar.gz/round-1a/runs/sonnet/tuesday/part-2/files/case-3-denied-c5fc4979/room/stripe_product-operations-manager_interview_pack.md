# Stripe — Product Operations Manager: final-round interview pack

Role: Product Operations Manager. Company: Stripe. Round: final round, structure not yet known. Interviewer(s): not known. Version 1.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Behavioral and values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, and what was actually you |
| JD | Role-driven: can you do the listed job, including its gaps |
| CO | Company and strategy knowledge: how deep is your homework |
| CASE | Live problem from the role: structure and reasoning |

This pack rests on nothing you have supplied about your background and on no research. Every row is labeled `[generic]` for that reason, and the upgrade menu at the end says what turns rows into `[grounded]` ones. The most valuable rehearsal here is B1, the question every final round asks in some form: why this role, why here, why now.

## Fit snapshot (worksheet)

No job description, no CV and no background was provided, so this is the worksheet variant: each requirement is role-family prose, not quoted, and every evidence cell is empty. Fill the evidence column yourself on paper before rehearsing; the bridge column says what strong evidence looks like.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate launches and programs across several teams (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is one launch or program you can describe by who was involved, what slipped or nearly did, and what you personally did about it. Selection scaffold: pick a time work crossed three or more teams and you were the person keeping it moving; it needs a named stake and a specific action of yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Design and run operating rhythms and processes for product teams (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a recurring process you introduced or changed, with what it replaced and whether it stuck. Selection scaffold: pick a process whose before and after you can describe plainly. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Use data and metrics to inform product decisions (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a number you can explain end to end: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. Selection scaffold: pick one metric you can defend under a second question. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influence partners without formal authority (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a disagreement with an equal or a senior person where you held a position and the relationship survived. Selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Prioritize and make calls under ambiguity (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a decision made with incomplete information and what you did when it turned out wrong or right. Selection scaffold: pick a decision where you can say what you knew, what you did not, and what you chose. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Motivation for this role and this company (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is reasons only you can give, in your words, including the true reason you are leaving your current role. Selection scaffold: three reasons, one each for the work, this company, and the timing. If one of the three is not a real reason, say so plainly and give the ones that are |

## Persona table

No loop source establishes this company's final round: your message names a final round but not how many sessions it holds or who runs them. The pack therefore falls back to the generic archetype, flat persona weights, and says so. If your final is several back-to-back sessions, the upgrade menu asks for the schedule so the pack can be split per session.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live problems from the role: plan this, fix this process | Even weight, highest depth: a product operations role is judged on structure and process thinking, and a final round usually tests a live problem | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Quiet probing of motivation, gaps, reason for leaving | Even weight: a final round is where fit doubts get tested, and your background is not yet known to this pack | Rehearse the most predictable objection until it is boring; build bridges only from things you actually did |
| Peer Evaluator (C) | Seam-splitting with adjacent teams, credit, disagreement | Even weight: the role sits between teams, so collegial seam questions are likely whoever the interviewer is | Reciprocity framing; propose seam principles, not a claimed seam; show spine and tact together |
| Values/Behavioral (D) | Scenario probes, STAR-shaped stories | Even weight, no values page in hand: cannot tell whether a dedicated values round exists, so no values are named in this pack | Pick stories where the hard truth landed; where none did, say so rather than supplying an ending |
| Data-Driven Prober (E) | Line-by-line probing of your numbers | Even weight: any metric you cite will be followed two levels down | Know how each number was counted; say plainly when you do not know |
| Pressure (F) | Time-boxed, devil's advocate | Even weight, lower depth: composure tests appear in final rounds but this pack has no signal about this interviewer | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational (G) | Friendly openers that are still scored | Even weight, lower depth: the biography opener and "any questions for me" are near-certain in some form | A 90-second arc; treat casual questions as scored |

## Question banks

No answer cell below makes a claim about your past. Where a question asks for your experience, the guidance is a selection scaffold that ends with the honest branch. Names of Stripe products, values and strategy are deliberately absent because no source for them was reachable.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A cross-team product launch slips two weeks the day before ship date, and you are the product operations partner. What do you do in the first hour, and what do you change before the next launch?" | CASE | [generic] | Clarify first: what slipped, who is blocked, whether the date or the scope is fixed. State the objective, offer two or three options (hold, ship partial, re-sequence), name who you tell and when, then give the process fix as a separate step. Challenge one premise aloud, such as whether the date is really fixed | Live problem from the role family; CASE because it scores structure, not a past event |
| A2 | "Product teams say the weekly business review has become a status recital. How would you redesign it?" | CASE | [generic] | Ask what decisions the meeting is meant to drive and who is in the room. Propose a design (decisions first, metrics pre-read, owners named), a trial period, and how you would know it worked. Think aloud; offer one thing you would stop doing | Tests process design, the core of F2; generic pattern, no claim about this employer |
| A3 | "Two product teams disagree about who owns a shared dependency, and both look to you. Walk me through it." | CASE | [generic] | Separate the facts from the positions, ask what each team is trying to protect, propose a decision rule rather than a verdict, and say when you would escalate and to whom | Tests F4 without presupposing any past; the seam scenario returns in the Peer bank |
| A4 | "How would you tell whether product operations is working? What would you measure first?" | CASE | [generic] | Say what outcomes the function exists to improve, then pick two or three measures with an honest limit for each, including what the measure cannot show. Name the assumption you would defend least | Tests F3 and the weakest-assumption move on a hypothetical |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why product operations, why here, and why now?" | CO | [generic] | The highest-ROI prep in this pack. Three parts, each in your own words: what pulls you to the work, what pulls you to this company stated only in things you have read or used yourself, why the timing is right. Rehearse two follow-ups: "why not stay where you are" and "what would make you leave this role". If one of the three is not a real reason, say so plainly and give the ones that are | F6; every final round asks it in some form, and a rehearsed non-defensive answer changes the interview. CO because "why here" tests homework, JD because it tests the role |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one real gap in your own words and a concrete first-30-days plan to close it. If you cannot name one, say so plainly and say what you would ask the team to test first. Calibrated candor beats bluffing | F1 to F5; a persona stem from the Skeptic. The question has no JD behind it yet, so it stays generic |
| B3 | "Why are you leaving your current role?" | EXP | [generic] | Give your actual reason in your own words, short, forward-looking, and consistent with B1. Do not supply a reason you do not hold | Reason-for-leaving probe; EXP because the answer must survive a second question |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of pretending to know the seam: who decides, who informs, what gets escalated. Say how you disagree with an equal, and that you would ask how they prefer to work | F4; persona stem, and the seam is where role overlap shows |
| C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | State your principle in a sentence, then pick an instance if you have one: what was shared, what was yours. If no such instance comes to mind, say so plainly and give the principle alone | F4; persona stem |
| C3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Reciprocity: lead with what you would bring the peer's team, then what you need. Keep the ask specific and small | Peer reciprocity; tests partnership fit |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship at the end. Use "we" for context, "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4; persona stem |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a real trade-off, what the metric cost, and what you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5; persona stem |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a metric you have owned or reported. Walk me through how it was counted." | EXP | [generic] | Four things in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. If you do not know how it was counted, say so plainly and say how you would find out. Never describe a method you did not use | F3; defend-the-number rehearsal |
| E2 | "A dashboard you rely on shows a surprising swing. How do you decide whether it is real before you escalate?" | CASE | [generic] | Check the instrument before the story: definition changes, data delays, segment mix. Say what you would verify, who you would ask, and what you would tell people while you check | F3 on a hypothetical, no past claimed |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, answer in what you actually bring and can show, hold through two follow-ups, concede only what is real. Do not disparage anyone | F6; persona stem, composure test |
| F2 | "Pick a result you are proud of. How much of it was actually you?" | EXP | [generic] | Hold-then-concede: say exactly which part was yours, concede the shared parts specifically, and never fold on the part that was yours. If you cannot separate your part, say so plainly | Attribution probe; persona stem |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in your own words: where you started, what led to product operations, what you do now, why this role is next. Every beat must be one you can back up. If a beat is not true, leave it out | F6; the biography opener is scored |
| G2 | "What have you read or used from Stripe lately?" | CO | [generic] | Name only what you have actually read or used and one thing you noticed. If you have not, say so plainly and say what you will look at first. This pack could not research the company, so go and look yourself before the interview | CO homework check; stays generic because no research ran |

## Requirement coverage

| Requirement row | Covered by |
|---|---|
| F1 Coordinate launches and programs | A1, A3, C1 |
| F2 Operating rhythms and processes | A2, A4 |
| F3 Data and metrics | A4, E1, E2 |
| F4 Influence without authority | A3, C1, C2, C3, D1 |
| F5 Prioritize under ambiguity | A1, B2, D2 |
| F6 Motivation and fit | B1, B2, B3, F1, F2, G1, G2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first 90 days look like in this role, and how will you know?" | Shows you think in outcomes and gives you the interviewer's own scoring sheet for the role |
| R2 | "Where does this role end and neighboring teams' work begin?" | Surfaces the seam you would otherwise guess at, and signals you care about turf |
| R3 | "Which recurring process does the team own today that you most want to be different a year from now?" | Moves the conversation from your background to their problem |
| R4 | "How is the impact of this role measured, and who sees it?" | Tests whether the role is valued, and echoes A4 |
| R5 | "What do the people who have been most successful here have in common?" | Invites a description of how the team really works, not the posting's |
| R6 | "What is the hardest trade-off the team is facing this quarter?" | Rapport-style interviewers weight a specific, current question heavily |

## Prohibited claims

Nothing is listed because no background was supplied, so there is no sentence of yours for this pack to inflate. The standing rule applies to everything you say from this pack: no claim about your own past that you did not state, and no figure, team size, ownership or outcome you cannot repeat under a second question.

| Not coached | Basis | Honest form |
|---|---|---|
| Any specific about your past that you have not told me | No candidate material was supplied | Answer slots and selection scaffolds above: say what you did, or say plainly it was not yours |

## Sources

Provided documents: your message only (company, role title, final-round stage). No job description, CV, interviewer profile or recruiter guidance was provided.

Searches sent, all refused, none returned a result:

- "Stripe operating principles values" — refused
- "Stripe interview process product operations manager final round" — refused
- "Stripe strategy news 2026 annual letter stablecoins agentic commerce" — refused
- "Stripe Product Operations Manager job description" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have supplied published value names for a values cheat sheet and VAL questions mapped to them; section 10 is dropped |
| 2. Stripe interview process, product operations | unavailable | Would have established the loop and moved persona weights; weights are flat and the archetype is generic |
| 3. Stripe strategy and recent news | unavailable | Would have grounded CO and CASE questions in current priorities; CO questions stay generic |
| 4. Interviewer name and company | n/a | No name was given, so no query could be formed; the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Would have replaced the role-family requirements with quoted, inferred ones and sharpened the JD-tagged questions |

## Upgrade menu

- Permission to search the web, then say so and I will rerun the L1 research: values, loop structure, strategy and a representative JD each turn `[generic]` rows into `[grounded]` or `[inferred]` ones
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, for a strategy brief, role-family loop reports and org context
- The job description text: replaces the role-family requirements with quoted ones and unlocks JD-tagged questions per requirement
- Your CV or a few sentences about your background: turns the worksheet into a real fit snapshot and replaces selection scaffolds with story-mapped guidance
- Who you are meeting and your relationship to them (manager, peer, skip-level, cross-functional, recruiter): reweights every bank
- Your interviewer's name: an interviewer read and a reverse question tied to their path
- The recruiter's prep email, including any pre-declared deliverable: coverage of stated focus areas and a build section per deliverable
- If your final is several sessions, the schedule: per-session mini-packs with their own persona weights
- A tuesday-dossier.md from earlier prep, if you have one: sharper objections and strategy constraints per weak area
