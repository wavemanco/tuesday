# Interview pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager, because the interviewing page names the Outage Hour as the hiring-manager interview (see Sources). **Candidate:** Femi. **Round:** one 60-minute session, built from the loop source as a live-incident tabletop followed by a values conversation. **Interview date:** Friday 20 November 2026.

## 1. How to use this pack

Personas are how a question arrives. Types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows Saltmarsh's published values, not generic virtue |
| EXP | Whether your own account of your work survives follow-up questions |
| JD | The listed responsibilities and requirements, gaps included |
| CO | Whether you can think at Saltmarsh's altitude: its strategy and recent moves |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you here. It tells you where a probe is likely and gives both honest branches: say how it worked in your own words, or say plainly it did not happen or was not yours.

## 2. Prep triage

Three days, Tuesday to Thursday. Do these in this order and do them out loud.

1. **C1, three times aloud.** The plain statement, then the learning plan. This is the highest-ROI prep in the pack.
2. **A1 and A2 as a timed run.** Fifteen minutes of outage reasoning, then write the player message by hand. The first half of the hour is this shape.
3. **B3 and E2.** Decide in advance which branch of each answer slot is true for you. Say the checklist story in your own words.
4. **B1 and B2.** Find a real instance for each, or settle on the honest branch. Do not build an instance you cannot defend.
5. **Read two things yourself before Friday:** the Project Larkspur announcement (A3, C1, reverse question 3 lean on a search snippet of it) and Tobias's GDC talk (reverse questions 1 and 2 lean on a snippet of it).
6. **G1 at 90 seconds** from your four sentences.

Everything else is insurance.

## 3. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and does not say whether that title ran as a live service, so the JD's wording makes that the likely probe. Words: "I spent four years as an associate producer at a puzzle-game studio." Answer slot: if the title ran as a live service, say how, in your own words; if it did not, or not for all four years, say so plainly and stay with the calendar you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: weekly, content drops, your main title, two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your quote carries one title's weekly content drops, not events and not two titles, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on holding more than one calendar likely. If you kept or coordinated a second title's calendar, say how, in your own words; if you did not, say so plainly and stay with the one you ran |
| F4 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in the nouns, but the verb is presented. The material does not say whether you produced or defined the numbers, so say "I presented the monthly retention numbers to the studio head" and let the follow-up find out the rest. Expect a probe on how the numbers were counted |
| F5 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | A document QA still uses is adjacent evidence, not evidence of clarity or of other kinds of writing. Words: "I wrote the release checklist our QA team still uses." The writing is tested live in A2 rather than from your past |
| F6 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | low | [inferred] | discovery | The quote touches the requirement and does not show whether it reaches it. Words: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's review-and-KPI line makes a probe on what happened around those numbers likely. If you chose which numbers went in, or what the review concluded, say so in your own words; if the numbers came to you ready-made, or no review followed, say so plainly and stay with the presentation |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap in the nouns, and the verb is wrote, so lead with that. Say you wrote it and that QA still uses it, and do not upgrade wrote to managed |
| F8 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | discovery | Never led a team is not never coordinated across teams, and your material is silent on the second, so no negative about coordination is written for you. Answer slot: the JD's coordinate line makes a probe on your weekly drops likely. If design, art, engineering or community were part of them, say which and how you worked with each, in your own words; if none were, say so plainly and stay with the calendar you ran |
| F9 | Season-pass monetization — not a JD line; derived from Saltmarsh's announced model in a search result, see Sources | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## 4. Reading the interviewer

Public professional footprint only, from one search snippet (Sources, target 4): Tobias Wrenfield, Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio. His GDC 2026 talk is titled "Patch Notes Are a Promise", and its argument, as the snippet gives it, is that a live team is judged by how often its patch notes describe what actually shipped.

| Signal | Practical implication |
|---|---|
| Talk theme: patch notes judged against what shipped | Expect accuracy of what you announce to be scored: A2, B2 and E1 are where it surfaces. Never promise an outcome engineering has not committed to |
| Earlier QA lead role | F7 is the row he is best placed to probe, so B3 and E2 deserve the most exact wording. Say wrote, not managed |
| Published talk | Reverse questions 1 and 2 build on it; read the talk before using either |

Mirror opportunity: his path runs through QA, and F7's evidence is "Wrote the release checklist our QA team still uses". That is a shared professional adjacency, not a shared jump, so reverse question 2 asks about his path and does not claim a parallel. No coaching builds on shared identity.

## 5. Persona table

Weights start from the hiring-manager prior in the persona model (Case/Strategist plus Skeptic), then follow the loop source: a tabletop, then a values conversation. Peer Evaluator is left out: the relationship is manager, not peer.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A Case/Strategist | The simulated outage during a live event | High: the interviewing page names a live-incident tabletop as the first half of the hour, and the hiring-manager prior agrees | Clarify, objective, who you pull in, what players hear, what you decide, what you record; challenge one premise respectfully |
| B Values/Behavioral | The values conversation on three published values | High: the interviewing page names it as the second half of the hour, so a values-style round is documented, not assumed | Map a story to each value where one of your quoted sentences carries one, a selection scaffold where none does; we for context, I for contribution |
| C Skeptic | Probing the gaps: in-app purchases, team leadership, one title to two | Medium: the hiring-manager prior, and F8 and F9 are open | Rehearse C1 until it is boring; bridges only from adjacent evidence you stated, and the limit said plainly |
| D Data-Driven Prober | Retention numbers and the post-event review | Medium-low: the JD asks for retention comfort, and the snippet of his talk makes accuracy a theme; nothing found describes him as analytics-heavy, so that signal is not applied | Know what you can and cannot say about how each number was counted; say plainly when you do not know |
| E Pressure | Time-boxed calls inside the tabletop | Low: nothing read says his style is a stress interview; the tabletop may still time-box you | Pause, restate, take a position, hold through two follow-ups, concede one specific thing |
| G Conversational | The opener and the casual closing questions | Low: a conversation opens and closes the hour, and casual questions are still scored | A 90-second arc from your four sentences; use the closing slot for real reverse questions |

## 6. Question banks

**Highest-ROI prep: C1.** The pack infers it, as no underwriter named one: F9 is your largest stated gap, and the announced model (Sources, target 3) makes it the likeliest place a skeptic presses. The link between the announcement and the two titles in the JD is `[inferred]` from a search snippet.

### A. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your event is an hour old, rewards aren't being granted for part of the player base, and engineering is still working out why. Walk me through your first fifteen minutes." | CASE, JD | [grounded] | Say the frame aloud first. What you need to know: how many players, which platforms, whether rewards are lost or only late, whether the cause is known, who is on call. Objective: protect players first, the event second. Who you pull in: engineering for cause and timing, community for the first player note, design for whether event rules can bend, art only if a client change is needed. What players hear: what is known, nothing hoped for. What you decide: whether the event clock keeps running. What you record: a timeline from minute one. Challenge one premise, such as whether rewards are lost or only delayed. The question needs no claim about your past, so the guidance makes none | The first half of the hour is a tabletop, so this is its likeliest shape, and F8's coordination line is where it presses. CASE because it asks about no past; JD because the JD's coordinate line is the scoring sheet |
| A2 | "Engineering says the fix is about two hours out but won't commit. Community wants to tell players it will be fixed by tonight. Draft me the player message." | CASE, JD | [inferred] derived from the published value Ship the Patch Not the Promise and the JD's written-communication line | Three sentences, written, then read aloud. Say what is known, what players should do now, and when the next update comes. Leave out any fix time engineering has not committed to. Keep the sentences short and plain. Offer to tighten the wording after. The question needs no claim about your past, so the guidance makes none | F5 carries a document, not player-facing text, so the written-communication line is tested live. CASE because it is a live drafting task; JD for the written-communication requirement; the published value supplies the theme |
| A3 | "Saltmarsh is moving to one shared events calendar across its mobile titles. What gets harder when two titles share a calendar?" | CO, JD | [inferred] derived from a search snippet of the Project Larkspur post, with "I ran the weekly content-drop calendar for our main title for the last two years" | Open with the calendar you ran, at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Then structure, claiming nothing: events from two titles landing in the same week, players who play both, one comms cadence versus two, who decides when two events collide, what the shared calendar must show each team. Answer slot: the JD's two-titles line makes a probe on holding more than one calendar likely. If you kept or coordinated a second title's calendar, say how, in your own words; if you did not, say so plainly and stay with the one you ran | F3 is where one title meets the JD's two, and the announcement is the strategy question the research supports. CO because it needs Saltmarsh's own current move; JD for the two-titles line |
| A4 | "An event just ended. What goes in the post-event review, and which KPIs do you report?" | CASE, JD | [grounded] | Structure it: what was planned, what happened as a timeline, the player impact, whether what we told players matched what shipped, two or three numbers against a baseline you name, what changes next with one owner each. Pick numbers you could define out loud, and name the assumption you would defend least. The question needs no claim about your past, so the guidance makes none | F6 is thin, so this rehearses the hypothetical before D2 asks for the past. CASE because it is a build-the-review task; JD for the review-and-KPI line |
| A5 | "Friday's update needs design, art, engineering and community. On Wednesday art says they're a day behind. What do you do?" | CASE, JD | [grounded] | Clarify what the day behind blocks. Lay out the options: cut scope, move the drop, ship without the asset. Say who decides and what each of the four teams hears. Run the release checklist with QA against whatever you choose. Take a position and name the one thing that would change it. The question needs no claim about your past, so the guidance makes none | F8 is the JD's coordination line with the least behind it, and F7 is the checklist link. CASE because it is a live scheduling problem; JD for the coordinate line |

### B. Values/Behavioral (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players wanted different things." | VAL | [grounded] | Selection scaffold: pick a time you held or moved a date because of what players were experiencing. It needs the date, the player signal, who you told and what the date became. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Players Before Plans, the first published value. F2 is the only calendar evidence and carries no such moment, so this is a scaffold, not a story map |
| B2 | "Tell me about a time you had to decide what to tell people about something that wasn't finished yet." | VAL | [grounded] | Selection scaffold: pick a time you announced, or chose not to announce, something unfinished. It needs what you knew, what you said and what happened to the date. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Ship the Patch Not the Promise, the second published value, and the theme of the interviewer's talk per the snippet. No quoted sentence carries this, so a scaffold |
| B3 | "Tell me about the release checklist you wrote." | VAL, EXP | [grounded] "Wrote the release checklist our QA team still uses" | Story map on F7, using only what the sentence states: you wrote it, and QA still uses it. Tell it in your own words, with I for the writing. Answer slot: the value's line about leaving the checklist better makes a probe on revisions likely. If you changed it after a release, say what and why; if it stayed as written, or the changes were not yours, say so plainly and stay with writing it and QA's continued use | Leave the Build Greener, the third published value, names the checklist, and F7 is the one row that carries one. VAL for the value; EXP because it tests what was actually yours |
| B4 | "Which of our three values would be hardest to hold in this role, and why?" | VAL | [grounded] | Use the official names. Pick the one you honestly expect to strain, say the tension in role terms, and say what you would do when it bites. The question needs no claim about your past, so the guidance makes none | A values conversation tests candor as much as recall, and this one cannot be answered with a slogan |

### C. Skeptic (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Have you worked on a game with in-app purchases, and how would you get up to speed on a season-pass model?" | CO, EXP | [inferred] season-pass link derived from a search snippet; "Never led a team, and never worked on a game with in-app purchases" | The highest-ROI rehearsal in this pack. Answer plainly, first: "I've never worked on a game with in-app purchases." Then the plan, said as a plan and never as a past: what you would learn first about how the pass is built, which numbers you would ask to see, who you would ask. Hold through two follow-ups by repeating the plain statement, never by adding to it. Concede what you do not know about the monetization side. Describe no monetization work | F9 is the largest stated gap, and the announced move makes it likely. CO for the strategy tie; EXP because it probes what the experience was |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] | Selection scaffold: choose from the JD's own lines the one you honestly expect to be weakest at, say it in your own words, then the first concrete thing you would do about it. The pack's observation is that F3 and F8 are where your quoted sentences carry least; if you pick another, hold it. If no part comes to mind, say so plainly, then name the nearest you do see, or how you would find out | The persona's standard stem, fitted to the JD's own lines. JD because it scores the listed requirements including their gaps |
| C3 | "You haven't led a team, and this role coordinates design, art, engineering and community. How do you get a date to hold?" | JD, EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Plain acknowledgment, first: "I've never led a team." Then method, never past: agree the date and the owner out loud, put the calendar where all four teams see it, raise a slip early with its effect on players. Answer slot: the JD's coordinate line makes a probe on your weekly drops likely. If design, art, engineering or community were part of them, say which and how you worked with each, in your own words; if none were, or it ran through someone else, say so plainly and stay with the calendar you ran | F8 holds the open coordination question and the stated negative. JD for the coordinate line; EXP because the negative invites an attribution probe |

### D. Data-Driven Prober (weight: medium-low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which retention numbers did you present to your studio head each month, and which one would you defend least?" | EXP, JD | [grounded] "Presented the monthly retention numbers to the studio head" | Name the numbers in your own words, at the scope of the sentence: you presented them. Name the one whose counting you would defend least, before the interviewer does; if you do not know how a number was counted, say so plainly. Answer slot: if you pulled or built the numbers, say so; if they came to you ready-made, say so plainly and stay with presenting them. The same slot covers how each was counted and what each is most sensitive to | F4 is the JD's retention line, and a presented number is the one probers go after. EXP for attribution; JD for the retention requirement |
| D2 | "Tell me about a time the numbers told you a content drop hadn't worked." | JD, EXP | [grounded] | Selection scaffold: pick a time a number moved after a release. It needs the number, what you thought caused it and what you did or recommended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6 is thin, so this asks for the past after A4 asked for the hypothetical. JD for the review line; EXP because it tests what was actually yours |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds. QA wants to hold tonight's release and the calendar says ship. What's your call?" | CASE, JD | [inferred] derived from the published value Players Before Plans and the JD's QA line | Pause, restate, and put your call in the first sentence, with the reason in player terms. Hold through two follow-ups, for example that the event starts tonight. Concede one specific unknown, such as how risky the fix is. The published value points one way, and the call is yours. The question needs no claim about your past, so the guidance makes none | F7 is where QA and the calendar meet. CASE because it is a decision under a clock; JD for the QA line |
| E2 | "That release checklist, how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold the quote at its own scope: "I wrote the release checklist our QA team still uses." Return to it through two follow-ups; do not add to it. Answer slot: if others contributed, name who and what; if it was only yours, say so plainly. Concede only what you do not know | F7 is the probe the interviewer's background makes most likely. EXP for the attribution probe |

### G. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP, JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc from these four sentences only, in this order: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for your main title, the checklist QA still uses, the monthly retention numbers presented. Use I only for what each sentence says is yours. Why this role: say your own reason in one sentence; the pack supplies none. Stop there | F1 to F7 are the whole supply of evidence, and this is where they are spoken first. EXP for the story; JD for the live-service years |
| G2 | "What live-service games are you playing right now, and what do their event calendars do well?" | JD, CO | [inferred] the titles named in a search snippet of the Project Larkspur post | Name games you actually play, and one calendar behavior you actually noticed. Saltmarsh's own titles, Tidepool Tactics and Lantern Row, belong in only if you have played them. If no title comes to mind, say so plainly, then name the nearest you do follow, or how you would study them | The persona's standard casual stem on the JD's live-events line. A casual question is still scored |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "3+ years producing live-service games or apps" | G1, C2 |
| "experience running a content calendar" | G1, A3 |
| "Plan and run the live-events calendar for two of our mobile titles" | A3, C2 |
| "coordinate design, art, engineering and community teams on each update" | A5, C3, A1 |
| "own the post-event review and the KPIs it reports" | A4, D2 |
| "manage the release checklist with QA" | B3, E1, E2 |
| "comfortable with player-retention metrics" | D1, A4 |
| "clear written communication" | A2 |

## 7. Values cheat sheet

The published values, by name, from the official page. A values conversation is documented in the loop (Sources, target 2).

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold, B1: no quoted sentence carries a calendar-versus-players moment. Pick a time you held or moved a date for player reasons, with the signal and the new date. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Ship the Patch Not the Promise | We announce what is built, not what is hoped | Selection scaffold, B2: no quoted sentence carries it. Pick a time you chose what to say about something unfinished. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F7: "Wrote the release checklist our QA team still uses" — your message. Tell it at the sentence's own scope. Answer slot as in B3: if you revised the checklist after a release, say what and why; if not, or it was not you, say so plainly |

## 8. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Your talk argues a live team is judged by whether its patch notes match what shipped. How do you measure that inside the team?" | Tied to his own published work, so it shows you read the talk rather than the careers page. Read the talk first; the pack only has a snippet of it |
| 2 | "You came to live ops from QA. What did that change about how you run a release?" | Tied to his path, and it opens the release-checklist ground you can speak to without claiming a parallel |
| 3 | "Saltmarsh's September announcement describes one shared events calendar and a single live-ops group from February. Where does this role sit in that, and what does it own in its first quarter?" | Shows you read the strategy and asks the question that decides what the job is. Read the post first; the pack only has a snippet of it |
| 4 | "What would a good first event from this producer look like, and what would tell you it had gone wrong?" | Turns the role into observable terms and tells you how you will be judged |
| 5 | "What does the post-event review look like today, who reads it, and what has it changed?" | Probes the review-and-KPI line from the owner's side |
| 6 | "When QA and the calendar disagree, who makes the call and how is it recorded?" | Tests how Players Before Plans works in practice, and what the checklist is for |
| 7 | "What does the team find hardest about coordinating design, art, engineering and community on an update?" | Hands you the real constraints behind F8 before you accept |

## 9. Prohibited claims

Built from the fit snapshot before the banks. Where a row is silence (F8), it is an answer slot, not a prohibition.

| Not coached | Basis | Honest form |
|---|---|---|
| Produced live-service games | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says four years as an associate producer at a puzzle-game studio, and not that it ran as a live service. F1's slot stays inside what the quote states |
| Planned and ran the live-events calendar for two titles | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says the weekly content-drop calendar for one main title. A3's slot stays inside that |
| Owned the post-event review and its KPIs | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: the material says the monthly retention numbers were presented. D1's slot asks only about those numbers |
| Managed the release checklist | Inflated form of F7 | F7's quote at its own scope: wrote it, and QA still uses it |
| Led a team | Negative you stated, F8 | The plain acknowledgment: "I've never led a team." No slot |
| Worked on a game with in-app purchases, or on a season pass | Negative you stated, F9 | The plain acknowledgment: "I've never worked on a game with in-app purchases." No slot; the plan is said as a plan |

## 10. Sources

**Provided:** the JD text and your background, both in your message. No `tuesday-dossier.md` was present.

**Searches (4):**

| Query | What came back |
|---|---|
| Saltmarsh Games values | https://saltmarshgames.com/values |
| Saltmarsh Games interview process live operations producer | https://saltmarshgames.com/careers/interviewing |
| Saltmarsh Games mobile studio strategy news | https://saltmarshgames.com/news/project-larkspur |
| Tobias Wrenfield Saltmarsh Games Head of Live Operations | https://talks.gdconf.example/2026/patch-notes-are-a-promise |

**Fetches (2):** https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both read in full. The Project Larkspur post and the talk page were not fetched; what the pack uses from them is the search snippet only. The interviewing page is the pack's loop source: it says how many sessions there are, who runs the session and what it holds, so no archetype fallback was used.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | The values cheat sheet, section 7: three values by official name; the VAL questions B1 to B4 |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure, one 60-minute session with a tabletop then a values conversation; persona weights; a values-style round detected |
| 3. `Saltmarsh Games strategy` / recent news | yes | A3, C1, G2 and reverse question 3, from the snippet of the Project Larkspur post; strategy under about six months old (September 2026), not read in full |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read in section 4 and reverse questions 1 and 2, from the snippet of one talk page; not read in full |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 11. Upgrade menu

- **Your CV** → the quotes in F1 to F7 come from your message; a CV adds its own sentences, and a stronger row needs an inspectable artifact: your weekly content calendar, the release checklist itself (with anything sensitive removed), or a retention deck you presented, which would lift F2, F4 and F7 from medium toward high
- **Your answers to the slots** (F1, F3, F6, F8, and the checklist revision in B3) → each answered slot becomes a quoted row and the guidance beside it becomes a story map
- **The text of the Project Larkspur announcement** → pasted here, the `[inferred]` rows A3, C1, G2 and reverse question 3 become `[grounded]`
- **The recruiter's prep email, or one question to the recruiter** (does the tabletop use one of the live titles, and is there a pre-read) → coverage of the tabletop's actual setting
- **A deeper research pass** (offered once) → up to 6 more searches and 2 more fetches, several more minutes: Larkspur read in full, Tobias's talk read in full, and reports on this role's loop; it would turn A3, C1, the interviewer read and reverse questions 1 to 3 from snippet-based to source-based
- **A `tuesday-dossier.md`, if you have one** → verified evidence and a named top objection would replace this pack's inferred ones
