# Interview pack: Engineering Manager, Larkfield Systems (loop of three rounds)

Candidate: Yusuf. Role as you described it: "Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap." Mode: loop, because you gave three scheduled rounds. Built from your message alone: no full posting, no interviewer names, no company research (see Sources).

| Round | When | Who and style | Length |
|---|---|---|---|
| 1 | Tuesday | Director of Engineering, the hiring manager and your would-be boss | 45 min |
| 2 | The Thursday after | Panel: two staff engineers and a product manager | 60 min |
| 3 | The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" | 30 min |

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say only what you actually did, in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows values and leadership, not generic virtue |
| EXP | Whether your own claims survive scrutiny, and what was actually you |
| JD | The stated responsibilities, including the ones you have not done |
| CO | Knowledge of the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` rests on your own quoted words, `[inferred]` is a derivation named in the row, `[generic]` is a pattern with no claim about you or Larkfield. An answer slot is an instruction for the interview, not a question for you: answer it from your own experience, or take the honest branch it gives.

## Prep triage

1. Before round 1: A1, A2, A4, C1. Say each aloud until the plain-acknowledgment lines on the prohibited list feel boring. A1 is the highest-ROI prep in the whole loop.
2. Between rounds 1 and 2: F1, H1, H2, E1. Rehearse the 60% figure until you can say how it was counted, or say plainly that you do not know.
3. Between rounds 2 and 3: I1, I3, K1. Write your own leadership philosophy; this pack supplies none, on purpose.
4. Everything else is insurance.

## Shared fit snapshot

Requirements are quoted from the role description in your message. Evidence is your own words only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of six, with nothing on two squads or on a second team, and the words stay there: "I have nine years in engineering, three of them as a team lead of six." Answer slot: the two-squad line makes a probe on how a second squad would be led likely. If either squad would have its own lead, say how you would work with them, in your own words; if you do not yet know the structure, say so plainly and ask how it is set up |
| F2 | "own delivery" — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Your material says a reliability quarter was pushed through and a team figure dropped after it. It does not say feature delivery, or how work was planned or tracked, and the words stay at the sentence's scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slot: the own-delivery line makes a probe on how delivery was planned and tracked likely. If any of that was yours to set, say how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the quarter |
| F3 | "hiring" — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap, but a claim with nothing inspected behind it, so expect a probe on the figure. Lead in the quote's own terms, that you run the loop for backend roles, and keep the 40 attached to interviews: the sentence counts interviews, not hires or candidates |
| F4 | "growth for 11 engineers" — role description in your message | none given | none | [grounded] | discovery | Your material does not show this requirement either way. Answer slot: the growth line makes a probe on how you have developed engineers likely. If you have worked on an engineer's growth, say what and how, in your own words; if you have not, or it was not yours, say so plainly and describe how you would approach it as a plan, not a past |
| F5 | "partner with hardware" — role description in your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | You stated you have never owned a hardware-adjacent roadmap, and the words are yours: "I've never owned a hardware-adjacent roadmap." The requirement is partnering, and your material is silent on working with hardware teams on a roadmap you did not own. Answer slot: if you have, say what and how, in your own words; if you have not, say so plainly, then say how you would learn it as a plan, never as a past |
| F6 | "partner with ... product on roadmap" — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The sentence touches roadmap pressure without showing who applied it or whether product was involved; this is the pack's derivation and not a fact about you. Answer slot: if product was one of the parties in that roadmap pressure, say what you and they each wanted, in your own words; if it was not product, or it was not yours to settle, say so plainly and return to the quarter |
| F7 | "industrial IoT" and "device-management services" — role description in your message | none given | none | [grounded] | discovery | Your material says a payments company and nothing about devices. Answer slot: the device-management line makes a probe on your closest systems experience likely. If any of your work touched devices or fleets, say what, in your own words; if none did, say so plainly and say how you would ramp, as a plan |

## Prohibited claims

Built before the banks. Nothing in this pack coaches these, and no answer slot, hold or bridge implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F5 | Your sentence: "I've never managed managers and never owned a hardware-adjacent roadmap." The plain acknowledgment is "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F5 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Partnering is a separate question and stays an answer slot (F5) |
| Led two squads, or an organisation of eleven | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a team lead of six, not two squads |
| Cut on-call burden by 60% single-handedly, or proved the quarter caused it | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the sentence says the burden dropped after the quarter, and does not say how it was counted or how much of it was yours. C1, F1 and H1 hold slots inside the quote |
| Owned delivery or the roadmap for the whole product | Inflated form of F2 | F2's quote at its own scope: a reliability quarter pushed through against roadmap pressure |
| Hired 40 people | Inflated form of F3 | F3's quote: about 40 interviews. The figure counts interviews |

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 Lead two squads building device-management services | A2, B2, H2, K1 |
| F2 own delivery | A4, B1, B3, F3, K2 |
| F3 hiring | C2, I4 |
| F4 growth for 11 engineers | G2, I1 |
| F5 partner with hardware | A1, B3, E1, J2 |
| F6 partner with product on roadmap | A4, E1, E2 |
| F7 industrial IoT, device-management services | B1, D2, F2, J1 |
| Motivation (not a JD line) | A3, D1, I3 |

## Sources

Provided documents: your message, including the role description as you pasted it. No dossier was present.

Searches sent, every one refused (the host did not grant search permission):

- `Larkfield Systems industrial IoT values` — refused
- `Larkfield Systems interview process engineering manager` — refused
- `Larkfield Systems strategy news device management` — refused
- `Engineering Manager device management IoT platform job description` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have fed a values cheat sheet; none is built, so section 10 is dropped. No Larkfield value name appears anywhere in this pack |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have documented the loop. Your own words already establish the three sessions and who runs each, so persona weights follow them |
| 3. `Larkfield Systems strategy news` | unavailable | Would have grounded CO and CASE questions; they are `[generic]` or marked as unsupported instead |
| 4. interviewer name and company | n/a | No name was given, so the interviewer read is absent |
| 5. representative `Engineering Manager` JD | unavailable | Would have turned role-family requirements into `[inferred]` rows; the fit snapshot uses only your description |

Nothing in this pack states a fact about Larkfield's values, loop, strategy or people.

---

# Round 1 — Tuesday, Director of Engineering (hiring manager), 45 min

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: hardware roadmap, scope jump from one team to two squads, why now | Highest. A hiring manager buys capability and derisks gaps, and F5 and F1 are the visible ones | Rehearse the single most predictable objection until it is boring; concede plainly; bridge only from what your quotes say |
| Case / Strategist | Live problems from the actual role | High. The hiring-manager prior; the role is defined by delivery across squads and a hardware seam | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Reads the figures line by line | Medium. Two figures are in your material (F2, F3) and a manager who reads closely will ask | Know how each figure was counted and say plainly when you do not know |
| Conversational / Rapport Builder | Opens with "walk me through the journey" | Lower, but the opener is scored | A 90-second arc built only from your own sentences |

## Question bank

### Skeptic (A)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in the pack, and the hold is only what the sentence carries: "I've never owned a hardware-adjacent roadmap." Concede it once, plainly, in those words, then stop adding to it. Say how you would learn it as a plan: who you would ask, what you would read, what you would want to see first, in your own words. Hold through two follow-ups by returning to what you stated, never by adding experience. Answer slot: if you have worked alongside hardware teams on a roadmap you did not own, say what and how; if you have not, say so plainly and stay with the plan | F5 is the biggest gap in the loop and this question arrives in some form in every round; JD because it scores the stated partner-with-hardware line |
| A2 | "You'd go from a team of six to eleven engineers across two squads. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Hold: "I have nine years in engineering, three of them as a team lead of six." What changes is a reasoning answer, said as a plan: what you would want to learn first about how the two squads are split and who plans and decides in each, in your own words. It makes no claim about having done it. Answer slot: if either squad would have its own lead, say how you would work with them; if you do not yet know the structure, say so plainly and ask how it is set up | F1 is where the scope jump presses; the question uses the role description's own numbers; JD tag because it scores the stated lead-two-squads line |
| A3 | "Why this role, and why now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Logistics-style slot, and the reason is yours: give your actual reason for moving, in your own words, tied to the role as you understand it. This pack supplies none. If your reason is not one you would say aloud to your would-be boss, choose the true part you would say | A recruiter-style motivation probe from a skeptic; F1 and F7 are the rows it tests; EXP because it checks consistency of your own story |
| A4 | "Tell me about a time you held a line with product on a roadmap trade-off." | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-map only the beats the sentence states: a reliability quarter, pushed through, against roadmap pressure. Tell them in your own words. Answer slot: the role's partner-with-product line makes a probe on who applied the pressure and what was deferred likely. If product was one of the parties, say what each side wanted and what part of the decision was yours; if it was not product, or the call was not yours, say so plainly and return to the quarter | F2 and F6 hold the only roadmap-pressure evidence; JD content with EXP delivery, because the follow-up asks what was actually yours |

### Case / Strategist (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A device-management service your squad owns is failing to push configuration updates to a slice of devices in the field. The hardware team says it is firmware. Product wants the next feature on schedule. What do you need to know first, and what do you do this week?" | CASE | [generic] | Structure it aloud: clarify (how many devices, which versions, since when, what changed), objective, segment the failures, approach for this week, metrics, risks. Challenge one premise respectfully: the firmware attribution is a hypothesis to test, not a fact. The question needs no claim about your past, so the guidance makes none | A live problem set in the role; covers F2 delivery and F7 domain, and the question asks for structure over a right answer |
| B2 | "You inherit two squads of eleven engineers and a roadmap you did not write. How do you spend your first 60 days?" | CASE | [generic] | Structure it: listen first, map who owns what, find the commitments already made, then decide where to change anything. Name what you would not change early. Say it as a plan, in your own words; the question asks about no past of yours | F1 is the scope question under the case; CASE tag because it tests structure on the actual first-month problem |
| B3 | "Hardware says a ship date is fixed. Your squads say the software is not ready. How do you make the call, and who needs to be in the room?" | CASE | [generic] | Clarify what is fixed and why, what the squads mean by not ready, what is cheaper to cut, who decides. Say plainly where you would want hardware's input because it is a seam you would be learning. Make no claim about having run a hardware date | The hardware seam from F5, asked as a decision rather than a record; F2 delivery sits under it |

### Data-Driven Prober (C)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Defend-the-number slots, each in your own words: how it was counted, what it is sensitive to. If you do not know how it was counted, say so plainly and say what you do know. The pack supplies no method, baseline or period | The only headline figure in F2 is a magnet for a prober; EXP because it tests whether the figure survives a second question |
| C2 | "You mention about 40 interviews last year. How was that counted, and what was your part in the loop?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Lead with the sentence: "I run our hiring loop for backend roles." Keep the 40 attached to interviews. Answer slot: how the figure was counted, and which parts of the loop were yours to set; if some were not, or the loop was not yours to shape, say so plainly and return to the loop you run | F3 is the strongest evidence in your material and the likeliest to be probed to its edge; EXP tag for attribution |

### Conversational / Rapport (D)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc built from the sentence: nine years in engineering, three as a team lead of six, now at a payments company. Add where you want to go next in your own words, as your own reason. No further beat is supplied by the pack | The opener is scored; F1 is the arc's only source |
| D2 | "What are you actually playing with in industrial IoT these days?" | JD | [generic] | Selection scaffold: name the nearest thing you have actually read, built or tried that touches devices, and what you took from it. If nothing comes to mind, say so plainly, then say how you would ramp. Claim nothing you have not done | A casual question about a hot JD topic; F7 is the gap under it; `[generic]` because the pack knows nothing of what Larkfield does beyond your description |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RA1 | "What does success look like for these two squads in the first six months, and how will you and I know?" | A boss hears you ask to be held to something specific; ties to own-delivery (F2) |
| RA2 | "Where does the hardware roadmap touch the squads most, and who owns that seam today?" | Opens the F5 topic on your terms without apologising for it |
| RA3 | "How are the eleven engineers split across the two squads, and does each squad have a lead?" | Shows you have thought about structure (F1) and gets a real answer to the question A2 circles |
| RA4 | "Where is hiring needed on the two squads?" | Moves the conversation onto F3, your strongest ground |
| RA5 | "What would you want to see from me in my first 90 days to say it is going well?" | Converts an evaluation into a shared definition of done |

---

# Round 2 — Thursday after, panel: two staff engineers and a product manager, 60 min

Names are not known, so personas are assigned by role, not per person. The staff engineers read as peers and technical specialists; the product manager reads as cross-functional.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting, "what would you need from me", credit across teams | Highest. Two staff engineers and a product manager are three peers pricing what your hire costs and contributes to their work | Reciprocity framing: what you bring them; propose seam principles, not a seam you do not know; disagreement stories that show spine and tact |
| Data-Driven Prober | Probes the numbers and the technical claims | High. The technical-specialist prior and two figures in your material (F2, F3) | Know how each figure was counted; name the assumption you would defend least; say plainly when you do not know |
| Values / Behavioral | Scenario probes from the product manager's side | Medium. The cross-functional prior; growth (F4) has not been touched elsewhere in the loop | Selection scaffolds ending in the honest branch; "we" for context, "I" for contribution |
| Pressure | Interrupts, tests attribution | Lower. The technical-specialist row carries some Pressure, and attribution probes ("how much was actually you") come from anyone | Pause, restate, hold the sentence you stated through two follow-ups, concede specifically |

## Question bank

### Peer Evaluator (E)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam between engineering management and product on the roadmap, and what happens when we disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Propose seam principles, not a seam you do not know: who owns the what and the why, who owns the how and the when, and how a disagreement gets escalated. Reciprocity: what you bring to product, not only what you need. The only disagreement beat the sentence carries is a reliability quarter pushed through against roadmap pressure; tell it in those terms. Answer slot: who applied the pressure and how it ended are not in your sentence; if you can say, do, and if you cannot, or it was not yours to decide, say so plainly and stay with the quarter | F6 and F5 meet in this question; JD because it scores the partner-with-product line |
| E2 | "Product brings you three priorities and your squads can take two. How do you decide?" | CASE | [generic] | Clarify what each priority is worth and by when, what each costs, what dependencies sit with hardware, and who needs to agree. Say the decision rule aloud and name what you would tell the one that did not make it. The question asks about no past of yours | A live prioritisation problem a product manager would run; F6 is the row behind it |
| E3 | "What would you need from the staff engineers on day one, and what could you do for them?" | JD | [generic] | Reciprocity first: what would make their work easier, in your own words, then what you would need from them. Make no claim about having led technical decisions; say that you would ask where those decisions are made today | Peer evaluators weight reciprocity; F1 is the row it touches |
| E4 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams and you can name who did what and how the credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | A peer's collegial form of the attribution question; `[generic]` because it asks about a pattern, not your past |

### Data-Driven Prober (F)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The weakest-assumption move, converted from gotcha to credibility. Name the assumption in your own words, and which part of the drop was yours. The pack names none; "I do not know how it was counted" is an honest branch. Do not claim the quarter caused the whole drop: the sentence says the burden dropped after it | F2's figure is the one a staff engineer will pull on; EXP because it tests knowing your own assumptions |
| F2 | "Which technical decisions in your squads would you stay out of, and which would you weigh in on?" | JD | [generic] | Principle, not history: you decide the what and the why with the squad, the squad owns the how, and you step in where the decision is hard to reverse or crosses a seam. Say it as how you would work, in your own words | A staff engineer scoring whether you will undercut or support them; F7 sits under it |
| F3 | "What would you want in place before you call a squad's delivery healthy?" | JD | [generic] | Name two or three signals in your own words and say what each tells you and what it hides. This is a way of working, not a story; it makes no claim about your past | The own-delivery line (F2) asked as a standard, not a record |

### Values / Behavioral (G)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Selection criteria: a named stake, a moment you did not fold, an intact relationship at the end. If the reliability quarter is the nearest thing, its beats are only those the sentence states: pushed through, against roadmap pressure. Answer slot: who you told and how it landed are not in your sentence; if you can say, do, and if the quarter was not that, or no such time comes to mind, say so plainly and give the nearest thing your material carries or how you would handle it | Persona stem for a values-style question; F2 is the only candidate evidence |
| G2 | "Tell me about a time you helped an engineer grow." | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Selection scaffold: pick someone whose starting point, what you did and what changed you can all name. If no such time comes to mind, say so plainly, then say how you would approach growth as a lead of eleven, as a plan. The pack supplies no story | F4 has no evidence at all, so this is the least rehearsed row in the loop; the sentence is only the nearest thing, the team lead of six |
| G3 | "Tell me about a time you disagreed with someone in another function. How did it end?" | VAL | [generic] | Selection criteria: a real disagreement, your own position stated and then tested, an outcome you can describe honestly, including if it did not go your way. If none comes to mind, say so plainly and give the nearest thing or how you would handle it | The partner-with-hardware-and-product line (F5, F6) asked behaviourally |

### Pressure (H)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "That reliability result. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause, restate the question, then hold only the sentence: "I pushed a reliability quarter through against roadmap pressure." Concede specifically and in your own words what was not yours, and say plainly if you do not know how the figure was counted. Never fold on what you did push through to restore harmony | The attribution probe F2 invites; the hold is exactly what the quote carries |
| H2 | "Sixty seconds: you have led a team of six and never managed managers. Why should we trust you with eleven across two squads?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap" | Hold: "I have nine years in engineering, three of them as a team lead of six." Concede plainly: "I've never managed managers." Then stop; do not add a lead you did not manage. Say how you would work with a lead in each squad as a plan. Answer slot: if either squad would have its own lead, say how you would work with them; if the structure is not known to you, say so plainly and ask | The panel version of A1; F1 and F5 are the rows behind it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RB1 | "What could a new EM do in the first month that would genuinely help your team?" | The reciprocity question for peers; it asks what you can do before what you need |
| RB2 | "Where do technical decisions get made today between staff engineers and engineering managers?" | Shows you want the seam, not turf; asks the staff engineers what they would otherwise decide for you |
| RB3 | "How does product input reach the squads today, and where does it get stuck?" | The product manager hears you looking for the real friction (F6) |
| RB4 | "What reliability or on-call pain do the squads carry today?" | Connects to your reliability evidence (F2) without claiming it applies here |
| RB5 | "What would you tell a new EM not to do in this role?" | Invites candour and tells you what a recent miss looked like |

---

# Round 3 — The following Monday, VP Engineering, 30 min

Described by the recruiter as "values and leadership philosophy". With 30 minutes you will cover perhaps five or six of these; rehearse I1, I3 and K1 first.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes on how you lead, grow and decide | Highest. The recruiter's own description is a dedicated values and leadership round | Map a story where one of your quoted sentences carries it; a selection scaffold ending in the honest branch where none does |
| Case / Strategist | Altitude: how two squads, hardware and product fit together | Medium. A VP row is strategy-heavy; the question is how you think, not what you know of Larkfield | Say the framework aloud; state your hypothesis early; make no Larkfield claim the pack cannot support |
| Pressure | Time-boxed, tests composure on the gaps | Lower. A VP row carries Pressure, and F5 is a stated gap | Pause, restate, hold the stated sentence, concede specifically |

## Question bank

### Values / Behavioral (I)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "What is your philosophy of leading engineers?" | VAL | [generic] | Selection scaffold, because the pack will not write your philosophy for you: pick two or three beliefs you actually hold, and for each, an example of something you did that shows it. If a belief has no example, say so plainly and give it as what you aim for, not as something you have done | The recruiter named leadership philosophy; F4 is the row it most exposes |
| I2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: a real customer-facing consequence, the internal metric you did not serve, what it cost you. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Persona stem for a values round; `[generic]` because the pack knows no Larkfield value and claims none |
| I3 | "Why management, and why now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Your own reason, in your own words, tied to the sentence: nine years in engineering, three as a team lead of six. The pack supplies none. A reason you would say aloud to a VP and mean | Skeptic-style motivation probe in a values round; F1 is the row behind it |
| I4 | "Tell me about a time a hiring decision did not go the way you expected." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Open with the sentence: "I run our hiring loop for backend roles." Selection scaffold for the story: a decision you can name, what you expected, what happened, what you changed. If no such time comes to mind, say so plainly and say how you would handle it | The role's hiring line (F3) in a values register; the sentence is your only hiring evidence |

### Case / Strategist (J)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Why Larkfield, and why industrial IoT?" | CO | [generic] | The pack holds no verified fact about Larkfield and will not supply one. Say what you have read or seen from public material yourself, in your own words, and name where you got it. If you have read nothing, say that plainly and say what you want to learn first | The research was not available, so this is the honest CO question; F7 is the row behind it |
| J2 | "If you had one quarter to improve how two squads and hardware plan together, what would you look at first?" | CASE | [generic] | Clarify what planning looks like today, find where commitments get made without the other side, pick one thing to change, say how you would know it worked. Say plainly that you would be learning the hardware side; make no claim about having done it | The altitude question for a VP; F5 is the seam |

### Pressure (K)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Sixty seconds: why you over a manager who has managed managers or owned a hardware roadmap?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "I've never managed managers and never owned a hardware-adjacent roadmap" | Hold on what you have: "I have nine years in engineering, three of them as a team lead of six," and "I run our hiring loop for backend roles." Concede both gaps plainly in your own words: "I've never managed managers." "I've never owned a hardware-adjacent roadmap." Then say what you would do in the first months as a plan. Never compare yourself to the other candidate | Persona stem adapted; F1, F3 and F5 are the three rows it weighs |
| K2 | "Suppose I told you tomorrow that the reliability work has to wait for a hardware launch. What do you say?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the position through two follow-ups, and the position is only what the sentence carries: you have pushed a reliability quarter through against roadmap pressure. Concede what you do not know about this hardware launch. Say aloud what you would ask first, what the cost of waiting is, and what you would be willing to give up. Answer slot: how the earlier case was argued is not in your sentence; if you can say how, in your own words, do; if you cannot, say so plainly and stay with the quarter | The reliability evidence (F2) tested at VP altitude; hold-then-concede applies |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RC1 | "What do you want engineering managers at Larkfield to be known for?" | Speaks to leadership philosophy from the VP's own side |
| RC2 | "How does leadership decide between a hardware date and software readiness?" | Opens the F5 seam at the altitude where it is decided |
| RC3 | "How do you grow the managers who report to you?" | Signals interest in the management layer without claiming you have run one |
| RC4 | "What does a growth path look like for an engineering manager here?" | Speaks to your own ambition and to F4 from the other side |
| RC5 | "What would make you regret this hire in a year?" | Hands the VP the chance to name the worry in front of you, which you can then answer |

---

## Upgrade menu

- Search access, or a pasted Larkfield values page and careers page → a values cheat sheet for Monday, a documented loop, and CO and CASE questions grounded in current strategy; today those are `[generic]` and the values and strategy rows are unavailable
- The full posting text → the F1 to F7 requirements become the posting's own quoted lines, and any mid-list requirement the summary dropped gets a question
- The interviewers' names → a reading of each interviewer's public professional path, per-person persona weights for Thursday's panel, and reverse questions tied to their own paths
- Anything the recruiter said about format for any round (a case, a presentation, something to bring) → a build section if a deliverable was announced, and a reweighted bank
- Your answers to the slots on F1, F2, F4, F5, F6 and F7, said outside a drill and in your own words → those rows move from answer slots to quoted evidence, and the guidance cells that draw on them regenerate
- How the 60% and the 40 interviews were counted, in your own words → C1, C2, F1 and H1 become story-mapped instead of slot-bearing
- A `tuesday-dossier.md` from an earlier session would supply verified evidence, prohibited claims and the objection worth the deepest rehearsal; the pack does not need one
- A deeper research pass at L2 (up to 6 more searches and 2 more fetches, several more minutes), only if search is allowed → a strategy brief, a documented loop, and recent organisational context
