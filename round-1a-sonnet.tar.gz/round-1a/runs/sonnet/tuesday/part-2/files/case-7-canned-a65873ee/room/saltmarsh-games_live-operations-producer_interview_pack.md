# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Taken as the hiring manager.
**Session:** Friday, 60 minutes. Built as one session. The company's careers page describes a single 60-minute interview with the hiring manager (the "Outage Hour"): a live-incident tabletop on a simulated outage during a live event, then a values conversation. This pack assumes Friday's session is that one.

## How to use this pack

- **Personas** describe how a question arrives (who is asking, in what style). **Types** describe what is being scored.
- Type key:
  - VAL: whether past behavior shows the company's published values.
  - EXP: whether your background claims survive scrutiny and what was actually you.
  - JD: stated responsibilities and qualifications, gaps included.
  - CO: company and strategy knowledge.
  - CASE: a live problem, scored on structure and reasoning.
- Guidance is scaffolding, not a script. Where a cell quotes you, the quote is the limit of what the pack will help you say.
- An answer slot is an instruction for the interview, not a question for you now. Meet it with either honest branch.

## Prep triage

Three days, Tuesday to Thursday. The few things done well, in order:

1. Tuesday: B1 out loud until the first sentence stops feeling hard. It is the highest-ROI prep in this pack.
2. Wednesday: the tabletop. Say A1, A2, A3 and E2 aloud, with a timer, thinking aloud as you structure. Then A5.
3. Thursday: C1 to C4 (pick a real story or say plainly you have none), D1 to D3, then the F1 arc and your reverse questions.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one title and a weekly drop calendar, not events across two titles, and the words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-titles line makes a probe on what the calendar held likely. Say what the weekly calendar held and how you decided what went in which week, in your own words; if you did not decide that, say so plainly and stay with running the calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | The sentence says leading, which the JD does not ask, and your material does not show whether you coordinated design, art, engineering or community on an update. Answer slot: the JD's four teams make a probe on coordination likely. If you worked with any of them on a drop, say which and what you did, in your own words; if you did not, or it was not yours, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you ran a post-event review or chose what it reported, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's KPI line makes a probe on who picked the numbers likely. If any of the numbers shown were yours to pick, say which and why, in your own words; if they were set by someone else, or there was no review beyond the monthly presentation, say so plainly and stay with the presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap in the terms, but a line with nothing inspected behind it, so expect a probe on it. Lead with it in the quote's own terms: you wrote the checklist, and your QA team still uses it, because a named document beats an adjective |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and two years on the weekly calendar, and does not say whether the game was live-service. Keep the title as written: associate producer. Answer slot: the JD's live-service line makes a probe likely. Say in your own words how the main title was kept live; if it was not live-service, say so plainly and stay with the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. Lead with it as quoted: you ran the weekly content-drop calendar for your main title for the last two years. Expect a probe on what it held, since nothing is inspected behind the line |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | Say it as it stands: "I presented the monthly retention numbers to the studio head." The words stay at presenting. Your material does not say how the numbers were counted or who produced them, so expect a probe there; if you do not know how a figure was counted, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written document QA still uses touches the requirement, and the link to clear writing is the pack's reading, not your claim. Answer slot: if you wrote anything else for players or for your team, say what, in your own words; if the checklist is the main writing you did, say so plainly and stay with it |
| F9 | Not a JD line: Saltmarsh news, September 2026, moves two titles to "a season-pass model" — Saltmarsh news | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [inferred] | capability | A gap wording cannot close, and you have said so. The pack reads a season pass as paid content, which the news snippet does not confirm. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to monetised-title work |

## Reading the interviewer

Public footprint only, from one search snippet that I could not open (see Sources for the caveat on that page). Confirm the talk exists before you cite it in the room.

- **Career pattern:** Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio.
- **Published argument:** a GDC 2026 talk titled "Patch Notes Are a Promise". Its stated argument is that a live team is judged by how often its patch notes describe what actually shipped.
- **Implications:**
  1. Anything you say about what was shipped, owned or fixed will be tested for exactness. This matches the pack's whole method: say only what you did, at its scope.
  2. In the tabletop, the player-facing message (A3) is likely read for what it promises. Say what is known, not what is hoped.
  3. A QA background makes the release checklist the nearest ground to his own, so expect depth on it (D3).
- **Mirror opportunity (shared vocabulary):** "release checklist". Your side of it is F4: "Wrote the release checklist our QA team still uses." No shared career jump is offered: no row carries your side of one.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The tabletop: a simulated outage during a live event, then follow-up problems | Highest. The careers page documents the tabletop for this loop, and the hiring-manager prior favors Case | Clarify, then objective, who you pull in, what players are told, what you record. Think aloud, challenge one premise |
| Skeptic | Quiet probing of the gaps: in-app purchases, team leading, live-service years | Second. Hiring-manager prior favors Skeptic, and F2, F5 and F9 are where the material is thinnest | Rehearse B1 until it is boring. Say each limit plainly, then stay inside what your own sentences carry |
| Values/Behavioral | The values conversation after the tabletop | Guaranteed in this session: the careers page documents a values conversation, and the values page names three | Pick real stories where one exists; where none does, say so plainly and give the nearest thing. "We" for context, "I" for contribution |
| Data-Driven Prober | Line-by-line questions on the calendar, the retention numbers and the checklist | Middle. Reading your background closely is typical of a hiring manager, and the public talk's theme is exactness about what shipped | Know exactly what you did on each line and say where it stops |
| Pressure | Interruptions inside the tabletop: choose now, with the clock running | Lower. No source says this interviewer uses stress, but a live incident invites it | Pause, restate the choice, decide, hold through two pushes, concede uncertainty specifically |
| Conversational | The opener and any casual chat | Lower. A recruiter call comes before this session, so the opener is likely brief | A 90-second arc (F1). Treat casual questions as scored |
| Peer Evaluator | Seam-splitting with an equal | Not expected: one session with the hiring manager, so no bank | None needed; B2 and the reverse questions cover coordination |

The weights rest on the company's documented loop, not on an archetype.

## Question banks

### Highest-ROI prep

B1. It will be asked in some form: the news puts a season-pass model on both titles, and you have said you have not worked on a game with in-app purchases. Rehearse it with all three follow-ups.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's mid-event and players tell us they can't enter. You're the producer on call. What do you need to know first, and what do you do first?" | CASE | [inferred] | Clarify before you structure: which title, how many players, since when, what changed last. Then your objective; who you pull in (engineering for the fault, community for what players are seeing, design and art if the event content is involved); what players are told and when the next update comes; and what you record for the review. Think aloud and state your assumptions. The question needs no claim about your past, so the guidance makes none | Derived from the careers page's live-incident tabletop on a simulated outage during a live event. CASE because it is a live problem; the four teams are the JD's coordination line (F2) |
| A2 | "The fix takes an hour and the event's reward window lost an hour of play. The next event is due tomorrow. Do you extend, compensate, shift the calendar or carry on, and who has to agree?" | CASE | [inferred] | Name your decision rule before the decision. The published value reads: "when the calendar and the players disagree, the players win." Give each option one cost, say who you need (engineering, design, community), say what players hear, and challenge one premise, such as whether tomorrow's event is still ready. No claim about your past | Applies the published first value to the tabletop. CASE; it tests whether you use the company's own vocabulary |
| A3 | "Write the first message players see about the outage, then the one that follows." | CASE, JD | [inferred] | Say what is known, what is being done and when the next update comes. The published value reads: "we announce what is built, not what is hoped." If the cause is unknown, say that and name no fix time. Speak it as you would post it; plain beats complete. No claim about your past | JD for the clear-written-communication line (F8); CASE as live writing. Derived from the values page and the interviewer's published talk title (see the interviewer read) |
| A4 | "An event ended last week and day-7 retention came in below the event before it. How would you run the post-event review, and what would it report?" | CASE, JD | [generic] | Clarify first: which cohort and platform, what else changed in the window, how day-7 was counted. Then structure: what the event was meant to do, what moved, what else could explain it, what you report and to whom, what the next event changes. Say what you would check before blaming the event. No claim about your past | JD for the post-event review and retention lines (F3, F7); CASE because it asks about no past. A pattern for the problem, not a fact about this employer |
| A5 | "From February both titles share one events calendar and one live-ops group. How would you plan that first shared calendar, and what do you need to know first?" | CO, CASE | [grounded] | Clarify: which two titles are yours (the JD names none; the news names two, and do not assume they are yours), what is already fixed, where events would collide for players who play both, who owns what in the single group. Then objective, approach, metrics, risks. Challenge one premise respectfully, for example whether both titles should run to one rhythm | The September 2026 news is the current-strategy grounding; CO because it needs company-level thinking, CASE because it is delivered as a plan. Ties to the JD's two-titles line (F1) |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our titles move to a season-pass model from February. You've never worked on a game with in-app purchases. How would you plan events for one?" | CO, EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | Say the limit first, in your words: "I've never worked on a game with in-app purchases." Then what you did carry, at its own scope: you ran the weekly content-drop calendar for your main title for the last two years, and you presented the monthly retention numbers to the studio head. Then a plan, never a past: what you would learn first and from whom, in your own words. Rehearse three follow-ups: what would you do in your first month; how would you tell an event worked (say what you would look at first, as a plan); isn't that a big gap. Concede the gap specifically, and never describe monetised work | The highest-ROI prep in the pack. F9 is the largest gap you have stated and the news makes it live. CO because it rests on the company's strategy; EXP because it tests whether you will inflate under pressure |
| B2 | "You haven't led a team. On each update you'd be coordinating design, art, engineering and community. How will you get that work moving?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Say it plainly and without sparring: "Never led a team." The JD says coordinate, and your material does not say whether you did. Answer slot: if you worked with any of the four on a drop, say who and what you did; if you did not, or it was not yours, say so plainly and stay with the calendar you ran. Then your method for keeping four teams to one date, as a plan in your own words | F2 shows the sentence says leading while the JD says coordinating. JD for the coordination line; Skeptic probes it as the visible gap |
| B3 | "The JD asks for 3+ years producing live-service games or apps. How does your background meet that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Say it at its own scope: four years as an associate producer at a puzzle-game studio, two of them on the weekly content-drop calendar for the main title. Keep the title "associate producer". Answer slot: say in your own words how the main title was kept live; if it was not live-service, say so plainly and stay with the weekly calendar | F5 is the row the requirement presses on. JD because it scores a stated qualification |
| B4 | "Why live operations, why Saltmarsh, and why now?" | EXP | [generic] | Answer slot: give your actual reasons in your own words, one about the work and one about this studio. If one of the three published values honestly matches how you work, name it and give an example from your own experience; if none does, do not claim one. Keep it to about a minute | The Skeptic's motivation-consistency check, and the reason for leaving is an EXP question. No claim about your past, so the guidance makes none |

### C. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players pulled in different directions." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Value: Players Before Plans. Pick a time a date and what players wanted disagreed, with a named stake, a decision, and what happened to the calendar. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (you ran the weekly content-drop calendar for your main title for the last two years) or how you would handle it | The published first value. F6 carries the calendar only, no disagreement, so this is a selection scaffold |
| C2 | "Tell me about a time you had to hold back something people expected to ship." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Value: Ship the Patch Not the Promise. Pick a time something was expected before it was ready: what you told people, and when. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (you wrote the release checklist and your QA team still uses it) or how you would handle it | The published second value. F4 carries the checklist, not a hold-back, so this is a selection scaffold |
| C3 | "When have you left a checklist or process better after a release?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Value: Leave the Build Greener. The beats the quote states: you wrote the checklist, and your QA team still uses it. Answer slot: the published value reads "every release leaves the codebase and the checklist better than it found them", so expect a probe on changes. If you revised it after a release, say what changed and why, in your own words; if it stayed as written, or others revised it, say so plainly and stay with having written it | The published third value maps onto F4 more directly than the other two. VAL |
| C4 | "Tell me about a time you delivered an unwelcome truth to senior people." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Pick a time the news was unwelcome, what you said, what changed and whether the relationship held. If your material shows none where the hard truth landed, say so plainly rather than supplying an ending, then give the nearest thing it carries (you presented the monthly retention numbers to the studio head) or how you would handle it | A persona-stem question that fits a live-ops head who values honest reporting. F7 carries presenting, not a hard message |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you ran the weekly content-drop calendar for your main title." | EXP, JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F1 and F6: the calendar, weekly, your main title, two years. Tell it in your own words and do not extend it. Answer slot: the JD's live-events line makes a probe on what the calendar held likely. Say what it held and how you decided what went in which week; if you did not decide that, say so plainly and describe how you ran it | F1 and F6 are the evidence for the calendar requirements and the likeliest probe. EXP because it tests what was actually yours; JD because it scores two stated requirements |
| D2 | "Take me through the retention numbers you presented to the studio head. How were they counted, and which part was yours?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The hold is the quote: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's retention line makes a probe on counting likely. If you know how a figure was counted and which assumption behind it you would defend least, say so in your own words; if you do not, or someone else produced the numbers, say so plainly and stay with the presenting | F7 and F3 draw on this same sentence. EXP because it tests attribution and honesty about how a figure was counted |
| D3 | "Walk me through the release checklist you wrote: what is on it and how does QA use it today?" | JD, EXP | [grounded] "Wrote the release checklist our QA team still uses." | The beats the quote states: you wrote it, and QA still uses it. Describe what is on it in your own words, only what is actually there. Answer slot: the JD says manage the checklist with QA, so expect a probe. Say which items on it were yours to set; if the items came from QA or elsewhere, say so plainly and stay with having written it | F4 is the strongest row and the likeliest to be probed in depth, given the interviewer's published QA background. JD for the checklist line; EXP for attribution |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run events on a title with in-app purchases?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Hold, then concede. Hold only what the quote carries: you ran the weekly content-drop calendar for your main title for the last two years. Concede specifically: "I've never worked on a game with in-app purchases." Hold through two pushes, never claim monetised work, and finish on how you would ramp. Pause and restate before answering | Pressure form of the F9 objection and F1's calendar. EXP because it tests whether you fold or inflate under time pressure |
| E2 | "Engineering says roll back, community says keep it live, and I need a call now. What is it?" | CASE | [inferred] | Pause and restate the choice. Ask the one question that would change it, then decide by the rule you named (players first) and say what would change your mind. Hold through two pushes before conceding anything real; concede uncertainty specifically ("I don't know the scope yet, so..."). No claim about your past | A time-boxed move inside the tabletop, derived from the values page and the careers page's live-incident format. CASE |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc in this order, each at its own scope: four years as an associate producer at a puzzle-game studio; running the weekly content-drop calendar for the main title for two years; writing the release checklist your QA team still uses; presenting the monthly retention numbers to the studio head. Close with your actual reason for live operations, in your own words (answer slot, no promises) | F5, F6, F4 and F7 are the arc's only sources. EXP; a casual opener is still scored |
| F2 | "What have you been playing of ours lately?" | CO | [grounded] | Before Friday, play one of the two titles Saltmarsh's news names and note one thing about how its events work. Say only what you actually saw. If you have not played, say so plainly and say what you will do. The JD names no title, so ask which ones this role covers | Casual-register questions about the product are scored. CO; the titles come from the September 2026 news |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles (F1) | A5, D1 |
| Coordinate design, art, engineering and community teams on each update (F2) | A1, B2 |
| Own the post-event review and the KPIs it reports (F3) | A4 |
| Manage the release checklist with QA (F4) | D3, C3 |
| 3+ years producing live-service games or apps (F5) | B3, F1 |
| Experience running a content calendar (F6) | D1, F1 |
| Comfortable with player-retention metrics (F7) | A4, D2 |
| Clear written communication (F8) | A3 |
| Not a JD line: the season-pass model (F9) | B1, E1 |

## Values and principles cheat sheet

The careers page documents a values conversation in this session, and the values page names three values.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | F6: "I ran the weekly content-drop calendar for our main title for the last two years." That sentence carries a calendar and no disagreement. Selection scaffold: pick a time a date and what players wanted disagreed, with a named stake and a decision. If none comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it (C1) |
| Ship the Patch Not the Promise | We announce what is built, not what is hoped | F4: "Wrote the release checklist our QA team still uses." That sentence carries the checklist and no hold-back. Selection scaffold: pick a time something was expected before it was ready and say what you told people. If none comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it (C2) |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." Beats: you wrote it, and QA still uses it. Whether it changed after a release is an answer slot (C3) |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your talk argued a live team is judged by how often its patch notes describe what actually shipped. How does your team check that today?" Only if you have confirmed the talk | Ties to his own published argument, so it reads as research on him and turns a quiz into a peer conversation |
| R2 | "You came to live operations from QA. What did that change about how you run an event?" | Ties to his own career path, as the public snippet describes it, and opens the checklist territory where your F4 sentence sits |
| R3 | "With one shared calendar and a single live-ops group from February, what would the producer for these titles own, and what sits with the group?" | Shows you read the news, and gets the scope of the role in his words |
| R4 | "Which two titles would this role cover?" | The JD names none; the answer sharpens A5 and F2 on the spot |
| R5 | "What does a post-event review look like here, who reads it, and what has one changed recently?" | Probes the KPI-ownership line (F3) and signals you will own the review |
| R6 | "Where has Players Before Plans cost the team something?" | Shows you took the value seriously enough to ask for the hard example |
| R7 | "What would make you say in six months that this hire was right?" | A standard that gets a concrete answer you can check yourself against |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team, or managed the teams on each update | Negative you stated, F2 | "Never led a team." The plain acknowledgment: "I've never led a team." No slot |
| Worked on a game with in-app purchases, or on a season-pass title | Negative you stated, F9 | "Never led a team, and never worked on a game with in-app purchases." The plain acknowledgment: "I've never worked on a game with in-app purchases." No slot |
| Ran the live-events calendar across both titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one title and a weekly drop calendar. D1's slot stays inside the calendar you ran |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says you presented the numbers. D2's slot asks only about the counting and which part was yours |
| Managed each release with QA | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says you wrote the checklist and QA still uses it. D3's slot stays inside what you wrote |

## Sources

Provided documents: the JD text and your background, as pasted in your message. No tuesday-dossier.md was found.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and the VAL bank: three values by official name, read from the fetched values page |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: one 60-minute hiring-manager session, tabletop then values conversation, no take-home. Persona weights, session mode and the values-style round detection follow from it |
| 3. `Saltmarsh Games strategy news mobile` | yes | A5, B1 and F2: the September 2026 news on a season-pass model, one shared calendar and a single live-ops group. Read from the search snippet only; the page was not fetched |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read and R1, R2. Read from the search snippet only; the page was not fetched |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries and what came back:

1. "Saltmarsh Games values" returned https://saltmarshgames.com/values, which I fetched.
2. "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing, which I fetched.
3. "Saltmarsh Games strategy news mobile" returned https://saltmarshgames.com/news/project-larkspur.
4. "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise.

Caveat on query 4: that page's host ends in ".example", an address reserved for documentation that cannot be a live public site, and I read only its search snippet. Treat the talk and the QA background as unconfirmed until you have found them on a source you trust; R1 depends on it. Nothing in your answer slots depends on it.

## Upgrade menu

- Confirmation that Tobias is the hiring manager and that Friday is the Outage Hour, plus anything the recruiter told you about the tabletop's format: firms up the persona weights and lets me tune A1 to A3 to the scenario.
- Which two titles the role covers (the JD names none): turns A5 and F2 from `[grounded]` on the news alone into questions about your actual titles.
- Your answers to the answer slots, stated in your own words in a message (what the weekly calendar held, whether you worked with design, art, engineering or community on a drop, whether you picked any of the retention numbers, whether the checklist changed after a release, how the main title was kept live): upgrades F1, F2, F3, F5 and F8, and turns the slots in B2, B3, C3, D1, D2 and D3 into story-mapped answers.
- The artifacts themselves, such as the release checklist, a monthly retention deck or a calendar sample: the inspectable proof that moves F1, F3, F4, F6 and F7 from `medium` toward `high`.
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): a strategy brief on the season-pass move, the interviewer's talk read in full, and loop reports. This is the one offer of it; it adds a grounding brief and sharper A5 and R1.
- A tuesday-dossier.md from an earlier application check: would add verified evidence and a worked-out objection list for this pack to build on.
