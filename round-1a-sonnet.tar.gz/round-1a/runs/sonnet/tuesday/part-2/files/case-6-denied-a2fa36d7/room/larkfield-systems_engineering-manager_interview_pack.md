# Interview pack: Engineering Manager, Larkfield Systems (three-round loop)

**Candidate:** Yusuf
**Mode:** loop, one shared fit snapshot plus a mini-pack per round
**Rounds:**
- Round 1: Tuesday, 45 min, the Director of Engineering, who would be your manager (hiring-manager round)
- Round 2: the Thursday after, 60 min, panel of two staff engineers and a product manager
- Round 3: the following Monday, 30 min, the VP Engineering, described by the recruiter as "values and leadership philosophy"

Interviewer names were not given. This pack was built from your message alone: no full job description, no CV, no research.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: every line that speaks about your past rests on a sentence you wrote, quoted beside it, and anything beyond that is an answer slot for you to fill from your own experience or to decline plainly. All proposed language in this pack is pending your approval, and you should change any wording that is not how you would say it.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior demonstrates values, not generic virtue |
| EXP | Work-experience deep-dive | Whether the claims survive scrutiny, and what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth, thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

Question IDs read round, persona letter, number (R1-A1 is Round 1, persona A, question 1).

## Fit snapshot (shared across the three rounds)

Requirements are quoted from the role description you gave. Evidence is your own sentences only. Bridge language is proposed, pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of six at a payments company, with nothing on two squads or on device management, and the words stay there: "I was a team lead of six." Answer slot: the role's two-squads and device-management line makes a probe on what is different likely. If any of the work you did carries over to device-management services, say which part in your own words; if none does, say so plainly and stay with the team you led |
| F2 | "own delivery" — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your sentence says you pushed a reliability quarter through, not that you owned a delivery plan, and the words stay there: "I pushed a reliability quarter through against roadmap pressure." The 60% raises four slots: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer slot: the role's own-delivery line makes a probe on how commitments were set and tracked likely. If any were yours to set, say which and how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the quarter you pushed through |
| F3 | "hiring and growth for 11 engineers" — role description, your message (the hiring half) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap in kind, but a line with nothing inspected behind it, so expect a probe on the figure. Lead with the loop in the quote's own terms: you run it, for backend roles. About 40 raises the same four slots as the 60%: how it was counted, what it is sensitive to, the assumption you would defend least, and which of those interviews were yours |
| F4 | "hiring and growth for 11 engineers" — role description, your message (the growth half) | none given | none | [grounded] | discovery | Your material does not show anything on growing engineers, which is not the same as showing there was none. Answer slot: the role's growth line makes a probe on how you develop engineers likely. If you have held growth conversations with engineers, say what they were and what part was yours, in your own words; if the team lead role did not include any, or there were none, say so plainly and say how you would approach it |
| F5 | "partner with hardware and product on roadmap" — role description, your message (the hardware half) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | discovery | You have stated that you have not owned a hardware-adjacent roadmap, and those are the only words this row gives back: "I've never owned a hardware-adjacent roadmap." The role's line is partnering, not owning, and your material is silent on partnering. Answer slot: if you have worked alongside hardware, say how and what part was yours, in your own words; if you have not, say so plainly. Then how you would learn it, said as a plan and never as a past |
| F6 | "partner with hardware and product on roadmap" — role description, your message (the product half) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The sentence puts you against roadmap pressure, and says nothing on who the pressure came from or on partnering with product. Answer slot: the role's product-partnership line makes a probe on how you work with product likely. If the pressure came from product, say how you handled it, in your own words; if it did not, or there was no conversation, say so plainly and stay with what you did |

F5's confidence is `none` because the only evidence is a stated absence. F6 is `[inferred]` because linking that sentence to product is this pack's derivation, not your words.

---

## Round 1 — Director of Engineering, hiring-manager round (Tuesday, 45 min)

### Persona table, Round 1

| Persona | Likelihood and reasoning | How it shows up | Counter-strategy |
|---|---|---|---|
| Skeptic | High. Hiring-manager prior is Case/Strategist plus Skeptic, and F1, F4 and F5 give a Skeptic real material | Quiet probing of the gaps: hardware, the step up from one team, why this role | Rehearse the single most predictable objection until it is boring; the limit said plainly, plus a plan |
| Case/Strategist | High. Same prior; the role description is the natural source of live problems | Plan-this, diagnose-that problems set in a device-management service | Clarify, objective, options, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Medium. Two figures in your message (60%, about 40) are easy to probe, and a boss-to-be checks claims | Asks how the numbers were counted | Know what you can and cannot say about each figure; say plainly where you do not know |
| Conversational | Low as a persona, but an opening biography question is likely in 45 minutes | "Walk me through the journey" | A 90-second arc built only from what your sentences say |
| Values/Pressure | Low this round. Round 3 carries values; no dedicated Pressure item, but R1-A1's follow-up ladder rehearses holding a position | | |

The depth here follows weight but is scaled to a nine-question mini-pack: Skeptic 3, Case/Strategist 3, Prober 2, Conversational 1.

### Question bank, Round 1 (proposed language, pending your approval)

**A. Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "What's your experience with hardware-adjacent roadmaps, and how would you handle that side of this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | **The highest-ROI rehearsal in this pack.** Open with what your material says, in its words: "I've never owned a hardware-adjacent roadmap." Then, as a plan and not a past, say how you would learn it: who you would sit down with first, the first questions you would ask them, how you would check you had understood. Name your own; the pack names none. Answer slot: the role's line is partnering with hardware, so expect a probe on whether you have worked alongside hardware at all. If you have, say how and what part was yours, in your own words; if you have not, say so plainly. Follow-up ladder below | F5 is the evidence and the largest gap the material shows against a stated requirement, so this objection arrives in some form; JD because it scores the role's own line, with Skeptic delivery |
| R1-A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Name one weakness and one plan, not a list. The hardware-adjacent roadmap is the one your own sentence supports: "I've never owned a hardware-adjacent roadmap." Then the first thing you would do about it, as a plan. Answer slot: if you see another weakness in the role's text, name it in your own words; the pack names none | F5 again, asked as self-assessment; the interviewer is testing whether your account of yourself matches what they will find |
| R1-A3 | "You've led a team of six. This is two squads and eleven engineers. What's different?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap." | Say what your material says: "I was a team lead of six." Then say what you expect to be different, as an expectation in your own words; do not claim to have led two squads. Answer slot: the role's growth line makes a probe on what a team lead did for people likely. If the team lead role included growth conversations, reviews or promotions, say which and what was yours; if it did not, say so plainly. If the squads have leads who would report to you, your words are "I've never managed managers", then your plan; the role text does not say whether they do, and R1-E2 asks | F1 and F4 are the rows this presses on; the pack's observation is that your material says team lead, not manager. JD with Skeptic delivery |

Follow-up ladder for R1-A1 (the deepest rehearsal; hold the plain limit and the plan, never add a past):

1. "What would you do in your first month?" — return to your plan, in your own words.
2. "What if hardware and product want opposite things?" — say what you would want to know before taking a side; this asks about no past, so claim none.
3. "Does that worry you about taking the role?" — hold the limit, then concede specifically and in your own words that this is the part you have the most to learn; the proposed wording is pending your approval and should be yours.

**B. Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-B1 | "Two squads share a device-management service. Hardware needs a change to land next quarter and product wants a customer feature first. How would you plan the quarter, and what do you need to know first?" | CASE | [generic] | Clarify before structuring: what each ask is, what moves if either slips, who is affected, what the dates are. Then objective, options, how and with whom you would decide, risks. Think aloud; challenge one premise respectfully. The question asks about no past, so the guidance makes no claim about yours | A live problem from the role's partner-with-hardware-and-product line (F5 and F6); CASE because it scores structure, `[generic]` because it is a pattern for the problem and not a fact about this employer |
| R1-B2 | "A release goes out and devices start dropping off the management service. Diagnose it: what is your first hour?" | CASE | [generic] | Structure it: what you would find out first, how you would limit the damage, who you would tell, how you would decide on a rollback, what you would record. The question needs no claim about your past | The role builds device-management services (F1) and owns delivery (F2), so an incident problem is likely; CASE, `[generic]` for the same reason as R1-B1 |
| R1-B3 | "How do you decide what two squads should not do this quarter?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F2, with the beats the sentence states: a reliability quarter, pushed through, against roadmap pressure. Tell them in your own words. Answer slot: the role's own-delivery line makes a probe on how the quarter's contents were decided likely. If you decided what went into or stayed out of the quarter, say how; if that was decided elsewhere, or not at all, say so plainly and describe what you did | F2 is the only evidence on delivery; JD because it scores the own-delivery line, CASE in delivery |

**C. Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-C1 | "Walk me through how that 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The four slots a figure raises, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least (say it before they do), and which part was yours. The pack supplies no method, baseline or assumption. If you do not know how it was counted, say so plainly | F2's headline figure; EXP because it tests attribution, and a prober reads a figure to its assumptions |
| R1-C2 | "You run the backend hiring loop. What would you change about it for device-management roles?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Story-mapped on F3: you run the hiring loop for backend roles, the beat the sentence states. Answer slot: the role's hiring line makes a probe on what the loop screens for likely. If you set what the loop assesses, say how, in your own words; if it was set elsewhere, or there were no fixed criteria, say so plainly. On the change, say what you would want to learn from this team about what its engineers need before changing anything | F3 is the evidence for the hiring half of the role; JD because it scores that line, and the figure's four slots are covered at R1-C1 |

**D. Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-D1 | "So, walk me through the journey. Why management, and why here?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc built from the beats the sentence states: nine years in engineering, three as a team lead of six, now at a payments company. Answer slot: the why-management and why-here parts have no source in your material; give your own reasons in your own words, and if you do not have a settled one yet, say what you want to learn | F1 is the whole of the biography the material holds; EXP because it tests whether the story matches the record |

### Reverse questions, Round 1

| # | Question | Why it lands |
|---|---|---|
| R1-E1 | "What would you want to be different in the two squads six months after I start?" | It asks your manager-to-be for the definition of success before you inherit it |
| R1-E2 | "Do the squads have leads who would report to me, or do all eleven engineers report in directly?" | It settles whether your stated gap on managing managers applies at all |
| R1-E3 | "How do hardware and product priorities get reconciled today, and where would I sit in that?" | It goes straight at the seam F5 and F6 flag, as diligence |
| R1-E4 | "What has been hardest about this seam for the squads so far?" | It surfaces the real problem before you are asked to solve it |
| R1-E5 | "What would you want me to have learned about hardware by the end of my first quarter?" | It converts your biggest gap into a shared plan with the person who judges it |

---

## Round 2 — Panel: two staff engineers and a product manager (Thursday after, 60 min)

### Persona table, Round 2

| Persona | Likelihood and reasoning | How it shows up | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | High. Staff engineers are technical peers pricing what a new EM costs and adds; a PM is a partner on the roadmap seam | Where is the seam, what happens when we disagree, how do you handle credit | Reciprocity framing; propose seam principles, do not pretend to know the seam; disagreement stories with spine and tact |
| Data-Driven Prober | High. Technical interviewers read claims closely, and the blend of each member's top two personas puts Prober near the top | Figures to their assumptions; a design-review-style technical probe | Know what you can and cannot say about each figure; say plainly where you do not know |
| Values/Behavioral | Medium. A PM is a cross-functional interviewer, and cross-functional prior is Values/Behavioral plus Conversational | Scenario probes, often from outside the function | Stories where your sentences carry them, scaffolds with an honest branch where they do not |
| Conversational | Low. Mixed panels bring friendly asides, and an industrial-IoT question is likely | "What are you playing with these days" | Treat casual questions as scored; say what you have actually done |
| Pressure | Low-medium. Technical specialists add deliberate follow-up pressure to attribution | "How much of that was actually you" | Hold through two follow-ups, concede specifically, never fold on the core claim |

Panel names are unknown, so personas are assigned by role. Mini-pack depth: Peer 3, Prober 2, Values 2, Conversational 1, Pressure 1.

### Question bank, Round 2 (proposed language, pending your approval)

**A. Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-A1 | "Our teams sit side by side. Where is the seam between what you decide as the EM and what we decide, and what happens when we disagree?" | JD | [generic] | Propose principles, not a seam you cannot know: who has the context, who carries the consequence, how it is written down, how a disagreement is resolved without either side being overruled by default. Reciprocity: what you bring the staff engineers' work, not just what you need. The question asks about no past, so the guidance makes none | F1's squads sit alongside staff engineers; JD because it scores partnering, Peer delivery |
| R2-A2 | "Tell me about a time you disagreed with a senior engineer on a technical decision." | EXP | [generic] | A selection scaffold. Pick a time with a named technical stake, a moment you stated your view and held it, and a working relationship intact afterwards; say what the decision was and who made the final call. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer Evaluator's disagreement stem; EXP because it tests attribution, `[generic]` because no sentence of yours carries a disagreement |
| R2-A3 | "How do you handle credit when work spans teams?" | VAL | [generic] | A scaffold with an honest branch: a named piece of work that spanned teams, who did what, how credit was recorded or said aloud. If no such time comes to mind, say so plainly, then say how you would handle it. Use "we" for context and "I" for what you did | The Peer Evaluator's credit stem; VAL because it scores behavior, not a claim about the role |

**B. Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-B1 | "You mention about 40 interviews last year. Walk me through how that figure was counted." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | The four slots, each in your own words: how about 40 was counted, what it is sensitive to, the assumption you would defend least, and which of those interviews were yours. The pack supplies no method or share. If you do not know how it was counted, say so plainly | F3's figure; EXP because the panel's staff engineers are likely to have sat on loops |
| R2-B2 | "A squad proposes rolling a configuration change to every device at once. What questions do you ask before it ships?" | CASE | [generic] | Structure it: what could go wrong at fleet scale, how the squad would know, how it would be undone, who is on call, what the smaller first step is. You are not expected to out-design the staff engineers; the guidance is to show the questions you ask. The question asks about no past | F1's device-management work probed by technical peers; CASE, `[generic]` as a pattern problem |

**C. Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-C1 | "You mention pushing a reliability quarter through against roadmap pressure. Walk me through what that pressure looked like and how you dealt with it." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F2 and F6: a reliability quarter, pushed through, against roadmap pressure. Tell them in your own words. Answer slot: the role's product-partnership line makes a probe on who the pressure came from likely. If it came from product, say how you handled it; if it did not, or there was no single source, say so plainly and stay with what you did | A product manager will press the roadmap tension; EXP because it tests what was yours, with the product-partnership line (F6) as the JD tie |
| R2-C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | A selection scaffold: a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Your sentence about the reliability quarter carries pushing and pressure, and nothing about who the pressure came from | The Values persona's stem; VAL, `[generic]` because no sentence of yours carries a message to leadership |

**D. Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-D1 | "What are you actually playing with in industrial IoT these days?" | JD | [generic] | Answer slot: name what you have read or tried, in your own words, if anything; if nothing yet, say so plainly and say what you would look at first. Treat it as scored. The pack supplies no topic | F1's device-management domain, asked casually; JD because the role is industrial IoT |

**E. Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-E1 | "That result, the 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold through two follow-ups on what the sentence carries: "I pushed a reliability quarter through against roadmap pressure." Then concede specifically: say what you do not know about the rest of the drop. Answer slot: if other changes happened in the period, say which; if none did, or you do not know, say so plainly. Never fold on the quarter you pushed through, and never add to it | F2's figure under attribution pressure; EXP because it tests exactly the claim inflated forms stretch |

### Reverse questions, Round 2

| # | Question | Why it lands |
|---|---|---|
| R2-V1 | "Where do technical decisions get made today, and where would you want the EM to stay out?" | Asks the staff engineers to draw the seam for you |
| R2-V2 | "What could a new EM do in the first month that would genuinely help your work?" | The reciprocity question for peers |
| R2-V3 | "How is the product roadmap reconciled with hardware release cycles today?" | Goes at the F5 and F6 seam, with the person who lives in it |
| R2-V4 | "What is the usual reason a roadmap item slips here?" | Shows diligence on delivery, from the person who sees the slips |
| R2-V5 | "What would make this panel say, six months on, that the hire was the right call?" | Makes the panel state its own bar |

---

## Round 3 — VP Engineering, values and leadership philosophy (following Monday, 30 min)

### Persona table, Round 3

| Persona | Likelihood and reasoning | How it shows up | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | High. The recruiter described the round as "values and leadership philosophy", which is a loop source naming a values-style round | Scenario probes on how you lead and what you will not trade | Map a story to each question where one of your sentences carries it; a scaffold with an honest branch where none does; "we" for context, "I" for contribution |
| Case/Strategist | High. Skip-level prior is strategy-heavy Case/Strategist plus Pressure, and altitude matters in 30 minutes | Altitude questions: how you would lead two squads, what device management has to get right | Clarify, structure, use the role's own vocabulary; say only what you have read about the company |
| Skeptic | Medium. A VP reads the step from a team of six to two squads | Where does this stretch you, why this move | The limit said plainly, a plan |
| Pressure | Low-medium. A time-boxed "why you" is a standard skip-level question | "Sixty seconds: why you" | Hold the position through two follow-ups; concede specifically |
| Conversational, Peer | Low. Round 1 covers the biography opener, and no peer sits in this round | | |

Mini-pack depth: Values 3, Case/Strategist 3, Skeptic 2, Pressure 1.

### Question bank, Round 3 (proposed language, pending your approval)

**A. Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-A1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A stance, then a showing. In a sentence or two, say what you believe about leading engineers; the pack supplies no belief. Then show it with one thing you did: if it is the reliability quarter, the sentence carries only that you pushed it through against roadmap pressure. Answer slot: if the quarter was your call to make, or the pressure came from a particular person or group, say so; if not, say so plainly and tell it as the sentence does. Describe no belief you do not hold | The recruiter's own words, "leadership philosophy", raise this; F2 is the only sentence that could show a belief. VAL because it scores whether behavior matches stated values |
| R3-A2 | "Tell me about a time a value you hold was tested at work." | VAL | [generic] | A selection scaffold: name the value, the stake, what it could have cost you, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The recruiter's "values" raises the theme; VAL, `[generic]` because no sentence of yours carries a value being tested |
| R3-A3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | The same scaffold as R2-C2: a named stake, a moment you did not fold, an intact relationship at the end, with the same honest branch. Use the same story if it is the right one; do not rehearse a second story you do not have | The Values persona's stem; a VP is the likeliest person to ask it, VAL, `[generic]` |

**B. Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-B1 | "How would you build trust with two squads you have just inherited?" | CASE | [generic] | Structure: what you would want to learn first, who you would talk to, what you would not change early, how you would know it was working. The question asks about no past, so the guidance makes none | F1's step to two squads, asked as leadership philosophy; CASE, `[generic]` |
| R3-B2 | "What does device management at a company like this one need to get right?" | CO | [generic] | State only what you have read about this company; the pack holds no research on it. Answer slot: name what you have read about its products or customers, in your own words; if nothing yet, say so plainly and say what you would want to learn first | F1's device-management domain at the VP's altitude; CO, `[generic]` because research did not run |
| R3-B3 | "How do you grow engineers, especially those deeper in a domain than you?" | JD | [generic] | Structure: what you would want to learn about each engineer, how you would give feedback, how you would use their depth. Answer slot: the role's growth line makes a probe on what you have done likely. If you have held growth conversations, say what and what part was yours; if not, say so plainly and say how you would approach it | F4 is the uncovered growth requirement; JD with a leadership delivery |

**C. Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-C1 | "Where does leading two squads stretch you most beyond leading a team of six?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap." | Name one stretch, the one you most believe. Your words are the quotes: "I was a team lead of six", and where it applies, "I've never owned a hardware-adjacent roadmap" or, if the squads have leads who would report to you, "I've never managed managers". Then the plan, as a plan. The role text does not say whether the squads have leads, and R1-E2 asks | F1, F4 and F5 are the stretch rows; a VP asks the same objection at a higher altitude |
| R3-C2 | "Why industrial IoT, and why leave payments?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: your reason for this move is not in your material; give it in your own words. If you do not have a settled one yet, say what you want to learn, plainly. The only fact the guidance rests on is that you are currently at a payments company | The Skeptic's why-here-why-now; EXP because motivation must survive cross-examination |

**D. Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-D1 | "Sixty seconds: why you over an internal candidate?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year."; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure."; "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Pause, restate the question, answer in sixty seconds from these three sentences and no others: "I run our hiring loop for backend roles", "I pushed a reliability quarter through against roadmap pressure", "I was a team lead of six." Describe what you did and let them draw the inference. Hold through two follow-ups by returning to those sentences, and concede specifically where challenged: the hardware roadmap is "I've never owned a hardware-adjacent roadmap" | A time-boxed motive question for a skip-level; EXP because it tests whether the claim survives, with F1, F2 and F3 as the evidence |

### Reverse questions, Round 3

| # | Question | Why it lands |
|---|---|---|
| R3-V1 | "What does an engineering manager here do in the first year that people later say mattered?" | Gets the VP's bar in the VP's words |
| R3-V2 | "How do you want engineering leaders to disagree with you?" | Tests the values you were just asked about from the other side |
| R3-V3 | "How do hardware and software cadences get reconciled at your level?" | Goes at F5's seam from the top |
| R3-V4 | "How do values show up in how decisions are made and how engineers are promoted?" | Turns the values round into a question about practice |
| R3-V5 | "Where do you hope engineering leadership looks different in two years?" | Invites the VP to place the role in their plan |

---

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Lead two squads building device-management services" (F1) | R1-A3, R1-B2, R2-A1, R2-B2, R2-D1, R3-B1, R3-B2, R3-C1 |
| "own delivery" (F2) | R1-B2, R1-B3, R1-C1, R2-C1, R2-E1, R3-A1 |
| "hiring and growth for 11 engineers", hiring (F3) | R1-C2, R2-B1 |
| "hiring and growth for 11 engineers", growth (F4) | R1-A3, R3-B3 |
| "partner with hardware and product on roadmap", hardware (F5) | R1-A1, R1-A2, R1-B1 |
| "partner with hardware and product on roadmap", product (F6) | R1-B1, R2-C1 |

## Prohibited claims

Each entry is a claim this pack will not coach, with its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative the candidate stated, F5 | "I've never managed managers and never owned a hardware-adjacent roadmap." The plain acknowledgment: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative the candidate stated, F5 | The same sentence; the plain acknowledgment: "I've never owned a hardware-adjacent roadmap." The slot on working alongside hardware stays outside this claim |
| Managed a team of six | Inflated form of F1 | F1's quote at its own scope: "9 years engineering, 3 as a team lead of 6, currently at a payments company". The limit is the pack's observation, not words for you: your material says team lead, not manager |
| The reliability quarter cut on-call burden by 60% | Inflated form of F2 | F2's quote at its own scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." The limit is the pack's observation: your sentence says after, not because |
| Owned delivery for the squads, or set the roadmap | Inflated form of F2 | The same quote at its own scope; your sentence says you pushed a reliability quarter through, and the pack's observation is that it does not say you owned a delivery plan |
| Made the hiring decisions for backend roles | Inflated form of F3 | F3's quote at its own scope: "I run our hiring loop for backend roles — about 40 interviews last year." The limit is the pack's observation: your sentence says the loop, not the decisions |

## Sources

Provided documents: your message (the role description, the three rounds as scheduled, and your background). No `tuesday-dossier.md` was present. No loop source other than your own words was available, and your words establish the loop: three scheduled rounds, each with who runs it, so no archetype fallback was used.

Searches sent, each refused (web search was not permitted in this session, so nothing returned):
- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

Nothing in this pack is stated about Larkfield Systems beyond what you wrote, and nothing comes from model memory.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have moved the values cheat sheet and the VAL themes for Round 3; the cheat sheet is not built |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have checked the loop; your own words already establish it, so persona weights stand, and it would have added how a values round is scored |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have grounded the CO bank; R3-B2 is `[generic]` instead |
| 4. `{interviewer name} Larkfield Systems` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Engineering Manager` JD | unavailable | No search was sent because search was not permitted; a full JD would have moved F1 to F6 requirements and the JD-tagged questions |

## Upgrade menu

- The full job description text → the six requirement rows become fuller, and a requirement not in your summary gets its own question
- Your CV → evidence cells quote the CV as well as your message, and F4 and F6 may move from `none given` and `low`
- Your answers to the answer slots on F1, F2, F4, F5 and F6 → quoted into the snapshot, and the rows and slots that draw on them are regenerated
- The interviewers' names → a reading of each interviewer, persona weights from their public footprint, and a reverse question tied to their own path
- The company's published values page → a values cheat sheet for Round 3, mapped to your stories
- Search access, and optionally a deeper pass of up to 6 more searches and 2 more fetches, several more minutes → loop structure and strategy research, and CO and CASE questions grounded in the company
- Anything the recruiter said about the panel's focus or a deliverable → Round 2 reweighted, and a build section if a deliverable was announced
- Your prep hours across the two weeks → a prioritized prep schedule
- A `tuesday-dossier.md` from earlier work → verified evidence, constraints on what each weak area may coach, and the objection worth the deepest rehearsal
