# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship not stated, so the pack is built as a hiring-manager round (assumption).
**Session:** one 60-minute interview, Friday.
**Research:** none ran. The searches sent were refused, so every fact about Saltmarsh and Tobias is absent or labeled generic (see Sources).

## 1. How to use this pack, and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | What it scores |
|---|---|
| VAL | Whether past behavior shows a value, not generic virtue |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework on the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

Where a cell says answer slot, it is an instruction for the interview. Answer from your own experience, or say plainly the practice was not yours. The pack never fills a slot for you.

## 2. Prep triage (Tuesday to Friday)

| Order | Do this | Where |
|---|---|---|
| 1 | Rehearse the concession and the hold aloud until it is boring. This is the highest-ROI prep in the pack | B2, then B1 |
| 2 | Settle your 90-second arc, and decide your own answers to the coordination and two-title slots | D1, B3, B4 |
| 3 | Decide your own answers to the retention and review slots | C1, C2, C3, D3 |
| 4 | Talk each case through aloud once, using the structure in the guidance | A1 to A5 |
| 5 | Pick three reverse questions | Section 10 |

Everything else is insurance.

## 3. Fit snapshot

Source for every evidence cell is your message. The JD has no gate requirement: the 3+ years line is a length of experience, not a term you meet or do not.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not events and not two titles, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's wording makes a probe likely on how your drop calendar compares with the one in this role. Say in your own words how your drops worked; if they were a different kind of thing, say so plainly and stay with the calendar you ran. For a second title, give a plan for how you would start, never a past |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Inferred only from a calendar sentence that touches coordination: your material says nothing about who you worked with on it. Answer slot: the JD's line makes a probe likely on who you worked with on a drop. Say who and what you did with them, in your own words; if the drops involved no other teams, or that part was not yours, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you owned a review or chose the KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's wording makes a probe likely on who chose and counted the numbers. If you chose or counted any, say how in your own words; if you presented figures others produced, or there was no review of an event, say so plainly and stay with presenting the retention numbers |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap in the terms the quote carries, but a message line with nothing inspected behind it, so expect a probe on it. Lead with the quote's own terms: you wrote it, and QA still uses it, because a named document beats an adjective |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material shows four years as an associate producer and two years of weekly drops, and does not show whether the studio's game was live-service across all four. Answer slot: the JD's three-years line makes a probe on that likely. If the earlier years were also on a live game, say what you worked on, in your own words; if they were not, say so plainly and stay with the two years of weekly drops |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap: the quote reaches the requirement in its own terms, and this is the strongest row in the snapshot. Lead with it as written, and expect a probe on how much of it was yours (P2) |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | Reword only the quote: "I presented the monthly retention numbers to the studio head." The pack's observation is that the quote shows presenting, not building, and nothing is added to it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | Inferred only from a written document that is still in use: your material shows nothing about how clear it was. Answer slot: the JD's line makes a writing question or a sample request likely. Say which written pieces were yours and who acted on them, in your own words; if the checklist is the main one, say so plainly and stay with it |

## 4. Persona table

Weights rest on the hiring-manager prior (assumed) and on your note that this is one 60-minute session. Depth follows weight: 5, 3 or 2 questions.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Live problems from the role: plan this, diagnose that | High: a hiring manager is buying capability, and the JD duties are operational, so they translate directly into cases | Clarify, objective, segmentation, approach, metrics, risks, thinking aloud; challenge one premise politely |
| Skeptic (B) | Quiet, persistent probing of the gaps | High: a hiring manager is derisking, and your own words state two gaps (see the prohibited list) | Rehearse the single most predictable objection (B2) until it is boring; bridge only from what you stated, and name the limit plainly |
| Data-Driven Prober (C) | Line-by-line questions on the retention numbers | Medium: the role reports KPIs and your material has one metric line | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational (D) | A friendly opener that is still scored | Medium: a 60-minute session usually opens with the biography question | A pre-scripted 90-second arc; treat casual questions about live events as scored |
| Peer Evaluator (E) | Seam-splitting between teams, credit, what you need from them | Medium-low: Tobias is assumed to be your manager, not a peer, but the JD is about cross-team work | Offer seam principles rather than claiming to know the seam; frame what you bring, not only what you need |
| Pressure (P) | Time-boxed, devil's advocate | Low: no signal in what you gave me | Pause, restate, hold through two follow-ups, concede specifically |
| Values / Behavioral (V) | Scenario probes against published values | Low: no values-style round is documented in your words, and no values page was read | Where a story exists, map it; where none does, say so plainly |

## 5. Requirement coverage

| JD requirement | Questions | Note |
|---|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | B4 (JD), A1, P1 | |
| "coordinate design, art, engineering and community teams on each update" | B3 (JD), E1 (JD), E2 (JD), A2 | |
| "own the post-event review and the KPIs it reports" | C3 (JD), B2 (JD), A4 | |
| "manage the release checklist with QA" | D3 (JD), A5 | |
| "3+ years producing live-service games or apps" | D1 (JD), B1 (JD) | |
| "experience running a content calendar" | B4 (JD), P2, A1 | |
| "comfortable with player-retention metrics" | C2 (JD), C1, A3 | |
| "clear written communication" | E3 (JD) | |

## 6. Question banks

### A. Case / Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you would plan the live-events calendar for two titles over the next two months. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Ask before you build: what each title's calendar holds today, what each team can ship in a week, what the events are meant to move. Then objective, segmentation by title and by team capacity, approach, metrics, risks, thinking aloud; challenge one premise politely. If you reach for your own experience, say it in the quote's terms (you ran the weekly content-drop calendar for your main title for two years) and stop there. For a second title, give a plan, not a past | The JD's first duty, set as a live problem. F1 is the history behind it, and the case scores structure more than history |
| A2 | "Two updates are due in the same week. Art is late on one and engineering is blocked on the other. How do you decide what ships?" | CASE | [generic] | Clarify first: what each delay blocks, what has been promised to players, who can say no. Lay out the options (slip one, cut scope on one, stagger them), pick one, and say what you would tell each team and the community. Name the risk of your pick. The question asks nothing about your past, so the guidance makes no claim about it | Tests the coordination line of the JD (F2's requirement) as a decision rather than a record |
| A3 | "Day-seven retention after the last event came in lower than after the one before. How do you diagnose it?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head." | Clarify before diagnosing: how the measure is defined, which players, compared with what, what changed between the two events. Segment, rank two or three hypotheses, say what you would check first and whom you would ask. If you use your own work, use the quote's words (you presented the monthly retention numbers to the studio head) and do not add how they were built. Say where your knowledge stops | Retention is a JD line (F7). A live diagnosis shows reasoning that a CV line cannot |
| A4 | "Walk me through what goes in a post-event review, and the three numbers you would put at the top." | CASE | [generic] | Structure it: what the event set out to do, what happened, why, what changes next time. Choose the three numbers from the event's goal rather than from a fixed list, and say which you would need help to read. The question asks nothing about your past, so the guidance makes none; C3 is where a past example is handled | The JD's review and KPI duty (F3's requirement) as a case, so it can be answered honestly from structure |
| A5 | "Two hours before an update goes live, QA flags a crash on one device family. What happens next?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Clarify: how many players, how severe, whether it can be rolled back, who makes the go or no-go call. Name the options, pick one, and say who you tell and when. If you mention the checklist, say it as the quote does: you wrote it and QA still uses it. What it contains is yours to say, and nothing here supplies it | The JD's release duty with QA (F4). CASE because it scores the call, not the document |

### B. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "I ran the weekly content-drop calendar for our main title for the last two years." | Pick one gap you can name plainly. Two are in your own words: "I haven't worked on a game with in-app purchases." and "I haven't led a team." Say one, then say what you would do first to close it, as a plan and not a past. Then return to what the second quote carries: you ran the weekly content-drop calendar for your main title | The standard Skeptic opener, asked of everyone. The honest answer is in the prohibited list's sourced entries, and F2 and F3 are where the material is thinnest |
| B2 | "You haven't worked on a game with in-app purchases, and every event here reports KPIs. Why should we trust you with that?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Concede first, in the sourced words: "I haven't worked on a game with in-app purchases." Then hold only what the second quote carries: you presented the monthly retention numbers to the studio head. Do not claim that this covers anything beyond retention numbers. Follow-up 1, expect what retention numbers do not tell you: say in your own words what you do not know about measuring such a game, and if you cannot name it yet, say so plainly. Follow-up 2, expect how you would get up to speed: give a plan in your own words, what you would ask to see first and whom you would ask. Follow-up 3 if pressed: stay with the concession and the quote, and never add experience to close the gap | The most predictable objection to this candidate: the gap you stated sits against the JD's KPI duty (F3, F7). It will be asked in some form, and a rehearsed, non-defensive answer changes the interview. JD because it scores a stated requirement |
| B3 | "This role coordinates design, art, engineering and community on every update, and you haven't led a team. How would you get those disciplines moving together?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "I ran the weekly content-drop calendar for our main title for the last two years." | Concede in the sourced words: "I haven't led a team." Answer slot: the JD's line makes a probe likely on who you worked with when you ran the calendar. Say who and what you did with them, in your own words; if the drops involved no other teams, or that part was not yours, say so plainly and stay with the calendar you ran. Then give a plan for how you would start with each discipline, what you would ask each team for, as a plan and not a past | F2 is a discovery gap and the missing leadership is stated. JD because it scores the coordination line |
| B4 | "Tell me about the calendar you ran for your main title, and what changes when the role has two." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F1: weekly content drops, your main title, two years. Those are the beats the quote states, so tell them in your own words. Answer slot: the JD's wording makes a probe likely on how your drops compare with the live-events calendar in the role. Say how your drops worked; if they were a different kind of thing, say so plainly and stay with the calendar you ran. For the second title, give a plan for how you would start | F1 and F6 are your strongest ground, and this tests the step from one to two titles. JD because it scores the first duty |
| B5 | "What is drawing you to this role and to Saltmarsh, and why now?" | CO | [generic] | Give your own reasons: what you want from this role that your current one does not give you. For why Saltmarsh, name something you have read or played yourself before Friday, because nothing in this pack supplies it. If you have nothing yet, say what you are curious about instead. Keep it to 60 to 90 seconds | The Skeptic's motivation check. CO because it scores homework, and generic because the research did not run |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented: how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Four slots, each in your own words: how the numbers were counted, what they are most sensitive to, the assumption behind them you would defend least, and which part was yours. If you do not know how a number was counted, say so plainly. That is a better answer than a method you cannot repeat under a second question. Offer to walk through an analysis end to end only if you did one | Probers go after the one metric line on the material (F7, F3). EXP because it tests attribution |
| C2 | "What does comfortable with retention metrics mean for you, and where does your comfort end?" | JD | [grounded] "Presented the monthly retention numbers to the studio head."; "Never led a team, and never worked on a game with in-app purchases." | Describe the comfort in the quote's terms: you presented the monthly retention numbers to the studio head. Then name where it ends, in your own words, which is the weakest-assumption move. One limit you can say from your own words is "I haven't worked on a game with in-app purchases." Do not describe analysis you cannot walk through | The JD's retention line (F7). The second half scores calibration |
| C3 | "How did your studio review a content drop after it shipped, and what was your part?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: the JD's post-event review line makes a probe on this likely. If you took part in reviewing drops, say how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with presenting the monthly retention numbers to the studio head | F3's requirement. The question's premise comes from the JD and is not adopted as fact about you |

### D. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey: where have the four years gone, and where is the live-service part?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc whose beats are the four quotes: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for your main title in the last two years, the release checklist you wrote that QA still uses, the monthly retention numbers you presented to the studio head. Close with what you want next, in your own words. Answer slot: the JD's three-years line makes a probe on the live-service part likely. If the earlier years were also on a live game, say what you worked on; if they were not, say so plainly and stay with the two years of weekly drops | The biography question arrives first and is scored (F5). JD because it scores the three-years line |
| D2 | "What mobile games are you playing at the moment, and what is one thing their live events do well?" | CO | [generic] | Name a game you actually play and one thing you really noticed, in your own words. If you do not play mobile games with live events, say so plainly and say what you will look at before Friday. The pack cannot know which titles Saltmarsh runs | Casual in register but scored for genuine interest. Generic because no research ran |
| D3 | "Tell me about the release checklist you wrote: what is it for, and how does QA use it?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote it, and QA still uses it, which are the beats the quote states. Answer slot: the JD's release line makes a probe on contents and use likely. Say what is in it and how QA uses it, in your own words; if you do not know how QA uses it day to day, or parts of it were not yours, say so plainly and stay with the sentence | F4's requirement, asked in a friendly register. JD because it scores the stated duty |

### E. Peer Evaluator (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam between live operations production and engineering, and what happens when we disagree?" | JD | [generic] | Offer seam principles rather than claiming to know the seam: who decides what ships and when, who decides what is safe to ship, how a disagreement is escalated. Add reciprocity: what you bring to engineering and what you would need from them. The question asks nothing about your past | The coordination line (F2's requirement) in collegial packaging, presupposing nothing |
| E2 | "How do you handle credit when an update spans design, art, engineering and community?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick a time work spanned teams and credit was shared; it needs the teams named, what you did, and how credit was given. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (you ran the weekly content-drop calendar for your main title) or how you would handle it. Use we for the team and I only for your own part | Peer evaluators probe credit-sharing. F2 is thin, so the answer is a scaffold, not a mapped story |
| E3 | "Give me an example of something you wrote that other teams had to act on." | JD | [grounded] "Wrote the release checklist our QA team still uses." | The nearest thing the quote carries is the checklist you wrote, which QA still uses, so start there in those words. Answer slot: the JD's written-communication line makes a probe on how clear it was likely. Say what it contained and how you knew it worked, in your own words; if you do not know, say so plainly. If another written piece was yours, name it; if the checklist is the only one, say so plainly | F8's requirement. JD because it scores the stated line |

### P. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you rather than someone who has already run live events on two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head."; "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question, then hold only what the quotes carry: you ran the weekly content-drop calendar for your main title for two years, you wrote the release checklist QA still uses, and you presented the monthly retention numbers to the studio head. Through two follow-ups, return to those three and never add to them. Concede specifically, in the sourced words: "I haven't worked on a game with in-app purchases." Do not fold on the three to restore harmony | A Pressure stem that tests composure. The hold rests on F1, F4 and F7 and on nothing wider |
| P2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Anchor in the quote. Answer slot: say which parts were yours and which were others', in your own words; if parts were shared or set by others, say so plainly and stay with what the sentence says. Hold through two follow-ups by returning to the quote, never by adding verbs | An attribution probe premised on F1's own quote. EXP because it tests what was actually yours |

### V. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time you gave leadership news they did not want; it needs the news, the stake, a moment you did not soften it, and a relationship intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (you presented the monthly retention numbers to the studio head) or how you would handle it. Do not supply that the numbers were bad, because your material does not say so | A standard Values stem. It is not tied to a published Saltmarsh value, since none was read |
| V2 | "When did you put the player ahead of an internal deadline?" | VAL | [generic] | Selection scaffold: pick a time a date and a player-facing problem pulled in different directions; it needs the problem, the call you made, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | A Values stem adapted from a customer-first prompt. Generic because no values page was read |

## 7. Reverse questions

| # | Question to ask | Why it lands | Provenance |
|---|---|---|---|
| 1 | "Do the two titles share design, art and engineering capacity, or does each have its own?" | It reads the two-title line as a capacity problem, which is where a calendar gets hard | [generic] |
| 2 | "How does a post-event review get used after it is written?" | It treats the review as an input to the next plan, not a report | [generic] |
| 3 | "Which numbers in a post-event review does this team trust most, and which are still debated?" | It shows you intend to learn the KPIs from the people who use them, and it is a natural bridge from B2 | [generic] |
| 4 | "What is the first thing a producer coming from a puzzle title would need to learn here?" | It names your gap as a question, invites coaching, and signals self-awareness | [generic] |
| 5 | "What would a strong first ninety days look like for this role?" | It gets their expectations on the table so you can answer against them | [generic] |
| 6 | "What is the hardest part of getting design, art, engineering and community to agree on an update?" | It shows you take the coordination line seriously and want the real friction, not the brochure version | [generic] |

## 8. Prohibited claims

Built from the fit snapshot before the banks. Nothing in the pack coaches these.

| Not coached | Basis | Honest form |
|---|---|---|
| Having led a team | Negative the candidate stated: "Never led a team, and never worked on a game with in-app purchases." — your message | The plain acknowledgment that quote gives: "I haven't led a team." No slot |
| Having worked on a game with in-app purchases | Negative the candidate stated: "Never led a team, and never worked on a game with in-app purchases." — your message | The plain acknowledgment that quote gives: "I haven't worked on a game with in-app purchases." Then a plan for getting up to speed, said as a plan and never as a past |
| Owned the post-event review and chose its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says you presented retention numbers, not that you owned a review. C3's slot stays inside the presenting |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a content-drop calendar for your main title. B4's slot stays inside that calendar |

## 9. Sources

**Provided documents:** the JD, as pasted in your message; your background, as written in your message; your note that the interviewer is Tobias Wrenfield, Head of Live Operations, and that the session is 60 minutes on Friday. No `tuesday-dossier.md` was present.

**Searches sent, all refused (no result returned):**

- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games strategy mobile games news": refused
- "Tobias Wrenfield Saltmarsh Games": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have fed a values cheat sheet if a values-style round were documented, and themed V1 and V2 on published values. Both are generic instead |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have named other rounds in the loop and moved persona weights. Weights rest on the hiring-manager prior and your one-session note |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have grounded a CO or CASE question in current strategy; A1 to A5, B5 and D2 are generic instead |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have produced the interviewer read and a reverse question tied to his path. Both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 10. Upgrade menu

- Permission for web searches: the four L1 targets above would run, adding Saltmarsh's published values, any documented loop, current strategy, and Tobias's public professional footprint. That would replace the generic rows in A1 to A5, B5 and D2 and add an interviewer read. A deeper pass is a further option, up to 6 more searches and 2 more fetches, several more minutes
- Whether Tobias is your future manager, a skip-level or a peer: reweights every bank
- The recruiter's prep email: any focus areas or pre-declared deliverable, which would get its own build section
- The schedule, if there are further rounds: per-round mini-packs
- Your own answers to the answer slots in F1, F2, F3, F5 and F8, written outside a drill: they enter the snapshot as your quoted words and upgrade those rows and the banks that draw on them
- A redacted content-calendar view, the release checklist, or one monthly retention deck: the artifacts that would move F1, F4 and F7 from medium toward high
- Your CV text: rows resting on your message would quote your CV instead
- A `tuesday-dossier.md` from an earlier session: it would add verified evidence and a recorded prohibited-claims list, and the highest-ROI objection would come from that record rather than from inference here
