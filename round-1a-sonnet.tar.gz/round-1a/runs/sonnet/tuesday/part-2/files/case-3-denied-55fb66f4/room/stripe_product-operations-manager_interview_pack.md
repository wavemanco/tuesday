# Interview prep pack: Product Operations Manager, Stripe

Final round. Interviewer and relationship: not known. Built with no JD, no CV and no company research (web search was not permitted in this session), so persona weights are flat and every candidate-specific cell is a worksheet.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: where it says to use your own words, it means words you can stand behind under a follow-up.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your experience claims survive scrutiny, and what was actually you |
| JD | The role's responsibilities and qualifications, including your gaps |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem |

Provenance labels: `[grounded]` traces to something you gave me or to cited research, `[inferred]` is derived from an adjacent source, `[generic]` is a role-family pattern with no claim about Stripe or about you. Every row below is `[generic]`, because I had neither your background nor a posting.

## Fit snapshot (worksheet)

No CV or background was provided, so every evidence cell is empty and every requirement is written from the role family, not from a Stripe posting. Fill the evidence column in your own words and each row becomes real.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Drive cross-functional launches or rollouts of product changes into operational teams (role family, no posting) | none given | none | [generic] | discovery | Strong evidence is one launch you can name, with your part separated from the team's. Selection scaffold: pick a launch where several teams had to change how they worked, with a named date and a named outcome. If no such launch comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would run one |
| F2 | Build and run operating mechanisms such as planning cadences, reviews or intake processes (role family, no posting) | none given | none | [generic] | discovery | Strong evidence is a recurring mechanism that still ran after the first cycle, with who attended and what it decided. Selection scaffold: pick one mechanism you set up or ran. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set one up |
| F3 | Use data to find, size and track operational problems (role family, no posting) | none given | none | [generic] | discovery | Strong evidence is a figure you can explain end to end: how it was counted, what it is sensitive to, which assumption you would defend least. Selection scaffold: pick one number you produced or relied on. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would size a problem |
| F4 | Work between product, engineering and go-to-market teams, influencing without authority (role family, no posting) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a peer team that resolved with the relationship intact. Selection scaffold: pick one where you had no formal authority and say what moved the other side. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Write and present clearly for senior stakeholders to drive a decision (role family, no posting) | none given | none | [generic] | discovery | Strong evidence is a decision a senior person made after your document or presentation, with what you recommended. Selection scaffold: pick one such moment, including one where the answer went against you. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would structure the recommendation |
| F6 | Improve processes and tooling as a team scales (role family, no posting) | none given | none | [generic] | discovery | Strong evidence is a before-and-after on a process you changed, with who adopted it. Selection scaffold: pick one change that was adopted by people outside your team. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it |
| F7 | Familiarity with payments, fintech or B2B platform products (role family, no posting) | none given | none | [generic] | discovery | Strong evidence is direct work on, or study of, such a product, stated at its true scope. Selection scaffold: pick the closest product you have worked on or used closely. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or what you would learn first |

## Persona table

No loop source establishes the final round's sessions, and your message did not name the interviewer, so the fallback is the generic archetype: flat weights, said plainly. Add the relationship and these reweight.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | A live problem from the role: launch reset, metric diagnosis, operating cadence | Equal weight. A final round for an operations role plausibly includes a live problem, but no source here confirms it | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Quiet probing of why this role, why now, and what you would be weakest at | Equal weight. Every candidate meets the motivation probe in some form | Rehearse the most predictable objection until it is boring; bridge only from what you actually stated |
| Values / Behavioral (C) | Scenario probes scored on past behavior | Equal weight. Stripe's published values were not retrievable, so no values mapping is built | Story where one of your sentences carries it; selection scaffold otherwise |
| Data-Driven Prober (D) | Follows a number two levels deep | Equal weight. Operations roles are measured, so numbers get tested | Know how each figure was counted; say plainly when you do not know |
| Peer Evaluator (E) | Seam between product operations and neighboring teams | Equal weight. A final round plausibly includes someone you would work beside | Reciprocity framing; seam principles, not a claimed seam |
| Pressure (F) | Time-boxed challenge to your positioning | Equal weight. Final rounds can include a stress register | Pause, restate, hold through two follow-ups, then concede specifically |
| Conversational (G) | Friendly biography and open questions that are still scored | Equal weight. Casual openers are common | A 90-second arc scripted from your own sentences |

## Question banks

Highest-ROI prep in this pack: B3, the attribution question. A coordination role invites "how much of that was actually you", and a rehearsed, non-defensive answer changes the interview. This pick is a role-family pattern, not something I found in your material.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product team is about to change how merchants are onboarded, and the support and sales teams hear about it two days before launch. What do you do, and what do you need to know first?" | CASE | [generic] | Clarify first: what changes, for whom, what breaks if support is unprepared, what the launch date can bear. Then objective, who must act and by when, a readiness check, a rollback trigger, and one metric you would watch. Challenge one premise, such as whether the date should hold. The question needs no claim about your past, so the guidance makes none | A live launch-readiness problem tied to F1's requirement; CASE because it scores structure |
| A2 | "An adoption metric for a feature launched last month fell 20 percent week over week. Diagnose it." | CASE | [generic] | Segment before theorizing: data issue or real change, which cohort, which channel, which release. State the hypothesis early, then the cheapest check for each. Say which result would change your mind | Diagnosis problem from F3's requirement; no past claimed |
| A3 | "Product, engineering and go-to-market have no shared cadence. What do you set up in the first 30 days?" | CASE | [generic] | Listen before building: who decides what today, where information is lost. Then propose principles, such as one intake path, one review, one owner per decision, and say what you would drop if it adds weight. Offer a design, never a claim that you have built one | F2 and F6 requirements as a design problem; CASE with JD content |
| A4 | "Why does a payments company need product operations, and what would you want to be true of the product organization for this role to work?" | CO | [generic] | Bring your own researched view of Stripe, drawn from its own published material, because this pack could not fetch any. Structure as: what the function is for, what conditions let it work, what you would check in your first month. Do not state a Stripe fact you have not read yourself | F7's requirement and the company-knowledge probe; CO, with the Stripe specifics left to you because research was not available |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the real gap from your own material, say how you would close it in the first weeks, and do not pick a fake weakness. Selection criteria: it should be something the role actually uses. If no honest gap comes to mind, say so plainly, then name the area where you have done the least | Stem for the Skeptic; JD because it scores honesty against the requirement list in F1 to F7 |
| B2 | "Why product operations, why Stripe, and why now?" | EXP | [generic] | Three short sentences in your own words: what draws you to the function, what draws you to this company, and what makes the timing real. Stripe-specific reasons must come from what you have read yourself. If one of the three is not true for you, say so plainly and give the part that is | Motivation consistency is the Skeptic's core score; EXP because it tests your own story |
| B3 | "Pick the result you are proudest of. How much of it was actually you?" | EXP | [generic] | The highest-ROI rehearsal. Choose a result and be able to say what you decided, what you did, and what others did, in your own words. Hold through two follow-ups by returning to what you can state, and concede the limit of your part specifically. If no result comes to mind where your part is separable, say so plainly, then give the nearest thing your material does carry | Coordination roles routinely get this probe, and F1 to F4 are where it lands; EXP because it tests attribution |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, a moment you did not soften it, and a relationship that was intact afterward. Use I for your contribution and we for context. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for the Values interviewer, touching F5; VAL because it scores behavior |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: the metric, what it cost, who pushed back, what you did. Name the customer impact only if you can state it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; VAL, with F4's cross-team tension underneath |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a number you produced or relied on. Walk me through how it was counted, and which assumption behind it you would defend least." | EXP | [generic] | Four things in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Where you do not know how it was counted, say so plainly instead of reconstructing a method | Defend-the-number probe for F3; EXP because it tests ownership of a figure |
| D2 | "Support tickets per merchant fell after a product change. What do you check before calling it a win?" | CASE | [generic] | Check measurement before meaning: definition changes, volume denominators, seasonality, channel shifts, cohort mix, whether the tickets moved elsewhere. Then say what evidence would convince you | Metric-skepticism problem from F3; no past claimed |
| D3 | "You have a long list of operational problems. How do you decide which three get this quarter?" | CASE | [generic] | State criteria out loud, such as reach, severity, cost to fix, dependence on other teams, and say what you would need to know to rank them. Name one thing you would deliberately not do | Prioritization problem for F2 and F6; CASE |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Offer principles, not a claimed seam: who owns the decision, who owns the follow-through, how disagreements escalate. Add what you would bring to their team. Do not state how Stripe divides these roles unless you have read it | Peer stem for F4 and F2; JD because it scores the role's boundaries |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection criteria: a project that crossed teams, where credit was a live question. Say what you did, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; VAL for collaboration behavior, F4 |
| E3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Pair a need with an offer: one dependency you would ask for, one thing you can take on. Keep both concrete and within what you could actually do | Reciprocity framing; JD because it scores partnership fit |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause and restate. Say only what your own material can support, in plain words, and hold it through two follow-ups. Concede specifically if pushed on something you have not done, then return to what you have. Do not claim knowledge of the team's internal bench | Persona stem; JD, scored on composure |
| F2 | "Product operations sounds like coordination. Convince me it is not overhead." | JD | [generic] | State your actual view of what the function is for, with one example from your own work if one comes to mind. Hold the position through two follow-ups, concede where the criticism is fair, and do not fold on the core point to restore harmony | Tests holding a position without defensiveness; JD, with F2 and F6 behind it |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in three beats, each written from your own sentences: where you started, the thread that connects your roles, why this role is next. Cut anything you could not defend in a follow-up | Persona stem; EXP, because casual biography is still scored |
| G2 | "What are you actually playing with in product operations these days?" | JD | [generic] | Name one practice, tool or idea you have actually tried or studied and what you took from it. If nothing comes to mind, say so plainly, then name what you have been reading and what you made of it | Persona stem adapted to the role; JD because it scores genuine interest, F6 and F7 |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Cross-functional launches | A1, B3, C2 |
| F2 Operating mechanisms | A3, D3, E1, F2 |
| F3 Data and metrics | A2, D1, D2, D3 |
| F4 Working between teams | C2, E1, E2, E3 |
| F5 Senior communication | C1, F1 |
| F6 Process improvement | A3, D3, F2, G2 |
| F7 Payments familiarity | A4, G2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first ninety days look like in this role, and how will you know it is working?" | Shows you think in outcomes and gives you the success bar |
| R2 | "Which decisions does product operations make here, and which does it only prepare for others?" | Probes the role's real authority, a common source of mismatch |
| R3 | "Where is the seam between this role and product management, and how do you handle it when it blurs?" | Shows you have thought about the boundary before it bites |
| R4 | "What is the problem you would most like a new person here to take off your plate?" | Turns the conversation to usefulness and reveals the actual need |
| R5 | "How is the impact of this role measured, and who sees it?" | Signals you expect to be held to a number |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question, strongest if the interviewer turns out to be a peer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any claim about your own past: launches run, mechanisms built, figures produced, decisions made | No candidate sentences were supplied, so there is nothing quoted to rest a claim on | Your own words, once you add them to the fit snapshot. Until then every guidance cell is a scaffold or an answer slot |
| Any statement of a Stripe fact, value, product or process | No research or source was available | State only what you have read yourself from Stripe's own material |

## Sources

Provided documents: none. Your message supplied the company, the role title and the round type.

Queries sent, all refused:
- "Stripe operating principles values" — refused
- "Stripe interview process product operations program manager final round" — refused
- "Stripe strategy 2026 annual letter stablecoins agentic commerce" — refused
- "Stripe Product Operations manager job posting responsibilities qualifications" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have supplied the values cheat sheet; dropped |
| 2. Stripe interview process, product operations | unavailable | Would have fixed the loop and persona weights; weights are flat |
| 3. Stripe strategy and recent news | unavailable | Would have grounded A4 and G2 in current priorities; they are generic |
| 4. Interviewer name and Stripe | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative product operations JD | unavailable | Would have turned F1 to F7 into inferred rows with quoted requirements |

## Upgrade menu

- Permission to run web search → Stripe's published values, loop structure and current strategy, replacing the generic CO and VAL rows and enabling a values cheat sheet
- A deeper research pass after that, up to 6 more searches and 2 more fetches, several more minutes → a strategy brief and role-family loop reports
- Your CV or a few sentences on your background → F1 to F7 become quoted rows, and stories get mapped to questions
- The Stripe job description → the requirement rows quote the posting and a coverage check runs against it
- The interviewers' names and roles → an interviewer read, tailored reverse questions, and persona weights read from their public footprint
- The recruiter's prep email → focus areas and any pre-declared deliverable
- A tuesday-dossier.md from an earlier role review → verified evidence and prohibited claims to build on
