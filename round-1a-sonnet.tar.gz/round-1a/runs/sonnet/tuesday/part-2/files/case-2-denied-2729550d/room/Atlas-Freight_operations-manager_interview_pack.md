# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager, Atlas Freight (regional logistics, 800 employees)
Interviewer: not known. Relationship and round type: not known, so persona weights are flat and the pack covers a full loop.

## How to use this pack

Personas are how a question is asked; types are what it is scoring. Guidance is scaffolding, not a script: say only what you actually did, in your own words. Where a row says "Answer slot", it is an instruction for the interview, with two honest branches; take whichever one is true.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the behavior asked about, not generic virtue |
| EXP | Work-experience deep-dive | Whether the claims you make survive scrutiny and attribution probes |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company & strategy knowledge | Homework depth. None in this pack: no research ran, see Sources |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem set in the role |

## Prep triage

You have until next week. Do these in order; each is tied to a row below.

1. E1: say the scale answer aloud until it is boring. It is the highest-ROI prep in this pack.
2. A1 and B2: say how the 40% mis-pick figure was counted and which part was yours, in your own words.
3. E2 and A3: settle your honest Power BI line and your Excel line.
4. F1: a 90-second arc for "walk me through the journey".
5. D2 and D3: think aloud through one surge case and one four-terminal case.

Everything else is insurance.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says the site's plan, not four sites, and the words stay there: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-sites line makes a probe on running more than one location likely. If any of your work spanned more than one site, say which and how; if none did, say so plainly and stay with the site you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material says a pick-accuracy result, not on-time performance or cost-per-shipment, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's two measures make a probe on whether you track either one likely. If you track on-time performance or cost-per-shipment, say how, in your own words; if you do not, or it is not your measure, say so plainly and stay with the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 supervisors; the JD says 12. The words stay at "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have led more than 3 supervisors at any time, say when and how many; if not, say so plainly and say how you would approach a larger team |
| F4 | "build reporting in Excel/Power BI" (the Excel part) — JD | "solid Excel" — your message | low | [inferred] | discovery | Your material says an Excel skill and does not show what you built with it. Answer slot: the JD's reporting line makes a probe on what you have built likely. If you built reports, say what each was for and who used it, in your own words; if you did not, or they were someone else's, say so plainly and stay with Excel as the tool you are solid in |
| F5 | "build reporting in Excel/Power BI" (the Power BI part) — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material says seven years in operations and a current supervisory role; it does not show how many of the seven were spent leading people. Answer slot: the JD's five years are leadership years, so expect a probe on which of yours were. If some of the seven were years leading people, say which and how many, in your own words; if few or none were, say so plainly and stay with the years in operations the quote gives |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a statement with no certificate inspected behind it, so expect a probe. Lead with it in the quote's terms: green belt certified. Keep it as its own claim and do not attach it to other results |

## Persona table

No loop source was read and no round type was given, so the fallback archetype is Generic (screen, hiring manager, panel) with flat weights. These rest on a pattern, not on Atlas Freight's documented process. If you know who you are meeting, tell me and every bank reweights.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Reads your numbers line by line | Flat. The 40% figure in F2 is a magnet for this style whoever is in the room | Know how the figure was counted and say plainly what you do not know |
| Pressure / Stress | Time-boxes, interrupts, questions motives | Flat. Unknown round type; a hiring manager or senior leader would raise it | Pause, restate, hold the quoted position through two follow-ups, concede specifically |
| Values / Behavioral | Scenario probes, STAR-shaped stories | Flat. No loop source documents a values round, so none is assumed | Pick stories you can stand behind; where none comes to mind, say so plainly |
| Case / Strategist | Live problems from the role | Flat. A multi-terminal operations role invites scenario questions | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Skeptic | Probes the gaps | Slightly deeper (4 questions): F3, F5 and F6 are the visible gaps for any interviewer | Rehearse the scale objection until it is boring; bridge only from your quotes |
| Conversational | Friendly, unstructured, still scored | Flat. Common in early rounds of any loop | A 90-second arc; treat casual JD questions as scored |
| Peer Evaluator | Seam-splitting between terminals | Flat. The JD's four sites mean peers exist, but a peer interviewer is unconfirmed | Reciprocity framing; propose principles, not a seam you have not seen |

## Question banks

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You cut mis-pick rate by 40%. Walk me through how that number was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say it in the quote's own terms: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say how the rate was counted and what it is sensitive to, in your own words; name the assumption behind it you would defend least; say which part of the redesign was yours. If you do not know how it was counted, say so plainly and return to the redesign | F2 holds your headline figure, and every headline figure gets a defend-the-number question. EXP because it tests attribution and counting, not the result |
| A2 | "On-time performance and cost-per-shipment are the two measures this job is judged on. How do you track each one today?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The question presupposes tracking that your quote does not carry. Answer slot: if you track either measure, say which and how, in your own words; if you do not, or it is not your measure, say so plainly and return to the mis-pick result you cut | F2 is the gap against the JD's headline measures, so this is where the JD's own lines get tested. JD because it scores the stated requirement |
| A3 | "When have you used Excel to report on operations?" | JD | [grounded] "solid Excel" | Open prompt, so pick one instance you can walk end to end: what the report was for, who used it, and what you did with it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is that you are solid in Excel, or how you would handle it | F4 is thin: a skill is stated and no reporting is shown. The theme comes from the JD's reporting line |

### B. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why you over someone who has already run a multi-terminal network?" | JD | [grounded] "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path" | Hold only what the quotes carry: "I ran the site's peak-season surge plan two years running" and "I cut mis-pick rate 40% by redesigning the pick path." Hold through two follow-ups by returning to those, never by adding to them; the quote says the site's plan, so the hold stays at one site. Answer slot: if any of your work spanned more than one site, say which; if none did, say so plainly and stay with the site you ran | F1 is where a comparison with a multi-site candidate lands. JD because it presses the four-sites requirement |
| B2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say which part of the redesign was yours and which was shared, in your own words; if others did parts of it, say so plainly and name the part that was yours. Concede specifically and never fold on the core claim to restore harmony | F2's headline figure is the likeliest target for an attribution probe. EXP because it tests what was yours |
| B3 | "A major customer's on-time delivery has slipped for three weeks and your four terminals are blaming each other. You have ten minutes. Go." | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify first (what changed, which lanes, which terminals), state the objective, split the problem by terminal and by stage, name the first data you would pull, then the risks of acting too early. Challenge one premise respectfully, such as whether the slip is the terminals' or the handoffs' | A live problem set in the JD's four-site, on-time performance mandate (F2, F1), delivered under time pressure |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and an intact relationship afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard persona stem. No published values were read, so this is [generic] rehearsal and no story is mapped for you |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time where the customer cost and the metric cost were both real, and say what you chose and why. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard persona stem, and a natural one for an on-time performance role (F2) |
| C3 | "Tell me about a time you got a supervisor to change how they ran their area." | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | Open prompt, so choose an instance that is yours. Your quote establishes that you are over 3 supervisors and nothing about any change you drove, so the story is yours to pick: what you saw, what you said, what changed, what part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F3 is the leadership requirement; the theme comes from the JD's supervisor-led team line |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Cost-per-shipment has risen across the network this quarter and on-time performance has not improved. Where do you start?" | CASE | [generic] | The question needs no claim about your past. Clarify what moved (fuel, labor, dwell, linehaul, mix), define the two measures and their baselines, split by terminal and lane, name the hypotheses you would test first and the data each needs, then the trade-off if the two measures pull apart | The two JD measures (F2) set against each other, the core tension of the role |
| D2 | "Peak season is eight weeks out and volume at your four terminals is forecast to rise unevenly. Sketch the surge plan. What do you need to know first?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | The case is live, so structure it: forecast by terminal, constraints, staffing and equipment levers, trigger points, communication. You may reference your own experience in one sentence at its own scope: "I ran the site's peak-season surge plan two years running." Do not describe what that plan contained unless you did it, and do not claim four terminals | F1 is your strongest operations evidence, and this case scales it to the JD's four sites without claiming it |
| D3 | "You take over four terminals on Monday. What do you look at in week one?" | CASE | [generic] | The question needs no claim about your past. Say what you would ask first, what you would observe on the floor, which numbers you would pull per terminal, whom you would meet, and what you would not change yet | Covers the JD's daily terminal-operations ownership line (F1) and doubles as the ramp plan for E1 |

### E. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "This role leads 12 supervisors across 4 sites. You are currently a senior shift manager over 3 supervisors. Walk me through what changes at that scale." | JD | [grounded] "currently a senior shift manager over 3 supervisors" | **Highest-ROI prep in this pack.** Level 1: "I'm currently a senior shift manager over 3 supervisors; this role is 12 across four sites." State the difference as the two numbers, without softening or inflating. Level 2, "What would you do in your first thirty days?": a plan, not a past, so choose only steps you would actually take (D3 is the working draft). Level 3, "Tell me about a supervisor you coached": open prompt, so pick one you can stand behind; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Level 4, the pressure version, "So you have not run a team this size": say only what the quote supports. Answer slot: if you have led more than 3 supervisors at any time, say when and how many; if not, say plainly that 3 is the number you lead now and return to the ramp plan. Hold through two follow-ups, then concede the specific limit, never the core claim | F3 is the biggest visible gap against a headline JD requirement and the objection every interviewer can see in your own numbers. Deepest rehearsal because it will be asked in some form |
| E2 | "The reporting here is built in Power BI. Where are you with it?" | JD | [grounded] "never used Power BI"; "solid Excel" | The plain acknowledgment is yours to say: "I haven't used Power BI." Then a plan, said as a plan: what you would learn first and how you would show progress. Pair it with the quote that is true: "I'm solid in Excel." Do not say you have touched Power BI, and do not describe an Excel report unless A3 gave you one | F5 is a stated gap that no wording closes; rehearsing it plainly turns it into a credibility gain. JD because it scores a stated tool requirement |
| E3 | "Why this role, and why now?" | EXP | [generic] | Give your actual reason in your own words; the pack supplies none, because none was given. Keep it to what draws you to this job and avoid criticizing a current employer | The standard motivation probe from this persona. EXP because it tests a consistent career story |
| E4 | "Five or more years of operations leadership is required. Which of your seven years were spent leading people?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Start from the quotes: "I have 7 years in warehouse and distribution ops" and "I'm currently a senior shift manager over 3 supervisors." Answer slot: if some of the seven were years leading people, say which and how many, in your own words; if few or none were, say so plainly and stay with the years in operations the quotes give | F6 is a titled-years requirement your material does not break down. JD because it scores the stated requirement |

### F. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | Build a 90-second arc from these four statements and nothing else: the seven years, the current role, the pick-path result, the surge plan. Your quotes give no chronology, so order the beats the way your career actually ran, and tell them in your own words | The biography question is asked in some form in most loops and is still scored. The beats are drawn from F2, F3 and F6 |
| F2 | "The posting mentions Lean and Six Sigma. What are you actually playing with there these days?" | JD | [grounded] "green belt certified" | Say it in the quote's terms: "I'm green belt certified." The question presupposes current practice that the quote does not carry. Answer slot: if you have used the method on your work, say which work and what you did, in your own words; if you have not, or the certification has not been used on a project, say so plainly and stay with the certification | F7 is the JD's plus point, so a casual question about it is likely and scored |
| F3 | "Tell me about the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Story-mapped on the beats the quote states: the plan, the site's, two years running; tell them in your own words. Answer slot: the JD's on-time and cost lines make a probe on how the plan's results were measured likely. If they were measured, say how, in your own words; if they were not, or the measure was not yours, say so plainly and return to the plan you ran two years running | F1 is your clearest operations evidence, so it will be asked about directly |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our terminals sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | The question needs no claim about your past. Propose seam principles rather than a seam you have not seen: who decides when volume moves between terminals, what data settles it, who escalates. Frame it as reciprocity: what you bring the other terminal, not only what you need | Covers the JD's four-site line (F1) from a peer's side |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time when work spanned teams and say how credit was shared, with "we" for context and "I" for your own part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer stem. Collegial packaging of the attribution probes in B2 |
| G3 | "Another terminal's supervisor runs shift handovers differently from the rest. How do you work that out?" | CASE | [generic] | The question needs no claim about your past. Ask what the difference is costing, who owns the standard, and whether it is a real problem or a preference; propose a short trial and a shared measure instead of a mandate. Say how you would disagree without making it personal | Tests leading supervisors you do not manage day to day (F3), the way a peer would |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | B1, D3, E1, G1 |
| "drive on-time performance and cost-per-shipment down" | A2, B3, D1 |
| "lead a team of 12 supervisors" | C3, E1, G3 |
| "build reporting in Excel/Power BI" | A3, E2 |
| "5+ years operations leadership required" | E4 |
| "Lean/Six Sigma a plus" | F2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does on-time performance look like across the four terminals today, and which one is furthest from where you want it?" | It shows you think in the JD's two measures and asks for the baseline you will be judged against |
| R2 | "How are the twelve supervisors spread across the four sites, and where is the team strongest and thinnest?" | It turns the scale gap in E1 into diligence and tells you what you would inherit |
| R3 | "What reporting exists today, and what is expected of whoever builds it: Excel, Power BI, or both?" | It finds out how much Power BI is day-one, which you need to know before accepting |
| R4 | "What would you want to see changed in the first ninety days?" | It makes the expectations concrete and gives you a plan to answer against |
| R5 | "When on-time performance and cost-per-shipment pull apart, how is the trade-off decided?" | It shows you understand the tension in the JD's two measures |
| R6 | "If I joined, what could I do in my first month that would help your terminal?" | Reciprocity question for use if a peer is in the room |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led 12 supervisors, or ran a multi-terminal or multi-site operation | Inflated form of F1 and F3 | F1 and F3's quotes at their own scope. The limit is the pack's observation: the material says the site's plan and 3 supervisors, not four sites or twelve |
| Drove on-time performance or cost-per-shipment down | Inflated form of F2 | F2's quote at its own scope. The material says a mis-pick result, not those two measures. A2's slot stays inside the quote |
| Built reports or dashboards | Inflated form of F4 | F4's quote at its own scope. The material says "solid Excel", not what was built with it. A3 and F4's slots stay inside the quote |
| Has used Power BI | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I haven't used Power BI." No slot |
| Has five or more years of operations leadership | Inflated form of F6 | F6's quotes at their own scope: seven years in operations. The material does not show how many were leadership years; E4's slot stays inside the quote |
| The pick-path result came from a Lean or Six Sigma project | Inflated form of F2 and F7 | Keep the two quotes separate: "cut mis-pick rate 40% by redesigning the pick path" and "green belt certified" |

## Sources

Provided documents: your message, which carried the JD lines and your background. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Query | What came back |
|---|---|
| Atlas Freight regional logistics company values | refused |
| Atlas Freight interview process operations manager | refused |
| Atlas Freight regional logistics terminals strategy news | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have moved the values cheat sheet and VAL themes. No published values were read; C1 to C3 and G2 are generic and no cheat sheet is included |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have moved loop structure and persona weights. The Generic archetype and flat weights stand in |
| 3. `Atlas Freight strategy` | unavailable | Would have moved the CO bank. The pack has no CO question and no grounding brief |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD lines you supplied fix the fit snapshot and the JD questions |

## Upgrade menu

- Who you are meeting and the round type → reweights every persona bank and, with a name, adds an interviewer read and a reverse question tied to their path
- The recruiter's prep email (focus areas, any assignment) → coverage of anything pre-declared, usually one email away
- Web search allowed for Atlas Freight → values by name, loop structure and strategy, turning generic C and G rows and the missing CO bank into grounded ones; a deeper pass adds up to 6 searches and 2 fetches and takes several more minutes
- The full posting text → more requirement lines, quoted, so the coverage table checks more of the real scoring sheet
- Your own answers to the slots in F1, F2, F3, F4 and F6 → those rows move from answer slots to quoted evidence and the matching bank guidance is regenerated
- The artifacts that would raise confidence: the green belt certificate (F7), the before and after count behind the 40% (F2, A1) and an Excel report you built (F4)
- A `tuesday-dossier.md` from an earlier role check → a named objection and verified evidence in place of the inferred ones
