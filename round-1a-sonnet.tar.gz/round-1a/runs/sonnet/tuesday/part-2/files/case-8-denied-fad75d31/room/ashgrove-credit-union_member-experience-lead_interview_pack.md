# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode, three rounds on 26 November 2026: recruiter screen (30 min), Head of Member Services who would be your manager (45 min, mostly behavioural), panel of two branch managers (60 min, including a 20-minute complaint-escalation case, and scored against the four published values). Interviewer names are not yet assigned. Built 17 November 2026, nine days out.

## How to use this pack

- Personas are how a question is asked. Types are what it scores: VAL (values and behaviour), EXP (what your experience really was), JD (the posting's own requirements), CO (company and strategy), CASE (a live problem).
- Guidance is scaffolding, not a script. Wherever it says "answer slot", it is an instruction for the interview: answer it from what really happened, or say plainly that the practice was not yours.
- Everything about your past in this pack is one of your own sentences, quoted. Where your material is silent, the pack leaves a slot and does not fill it.
- Labels: `[grounded]` traces to something you gave me, `[inferred]` is derived from it, `[generic]` is a pattern with no claim about you or Ashgrove.

## Prep triage

Nine days, assuming a few evenings. Do these in order; everything else is insurance.

1. Days 1-2: D1, the highest-ROI rehearsal in the pack. Say it aloud until the concession is boring. Then B2 and D3, which use the same plain acknowledgments.
2. Days 3-4: write your real answers to the round-1 logistics rows A3 to A6 (pay, notice, location, reason for leaving), then B3 and D2, whose slots only you can fill.
3. Days 5-7: find one real story for each of the four values (F1 to F4) and for C1 and C2. These are the stories the panel scores.
4. Day 8: say G1 and G2 aloud, timed to 20 minutes for the pair.
5. Everything else is insurance.

## Fit snapshot (shared across all rounds)

No gate rows: the JD you pasted names no licence, location, schedule or pay term. The 4+ years requirement is a length of experience and is graded like any other row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | Your sentence already carries the years. Say it in its own words and let the interviewer do the matching. A message line with nothing inspected behind it, so expect a probe on what the work was |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [inferred] | discovery | Your material says a formal complaints log, and does not show whether the complaints were regulated. Answer slot: if the complaints were handled under regulatory requirements, say which and what part was yours, in your own words; if they were not, or someone else applied the rules, say so plainly and stay with the log |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process, and one branch, not several. The words stay at: "I handled the branch's formal complaints log." Any wider step is an answer slot inside that scope |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | Your sentence says a monthly complaints spreadsheet your regional manager uses, and does not show what it counted. Answer slot: if it tracked complaint volumes or how long complaints took to resolve, say which and how each was counted, in your own words; if it tracked other things, say so plainly |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your sentence says new tellers and the script, not supervisors and coaching. The words stay at: "I trained new tellers on our escalation script." Any wider step is an answer slot inside the sessions you ran |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent. Answer slot: the JD names digital teams, so expect a probe on work with a team outside your branch; if you have worked with one on anything members used, say what it was and what part was yours, in your own words; if not, say so plainly and say what you would want to learn first |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then a plan, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | Your sentence says spreadsheet and does not name the tool. Answer slot: the JD says Excel, so expect a probe on the tool; say which one it was, in your own words, and if it was something else, say so plainly |

## Grounding brief

What the pack knows of Ashgrove's July 2026 strategy is the four points you passed on; the brief itself was not read.

| Point | What it means for the complaints job | Provenance |
|---|---|---|
| "move 40% of member service to digital channels by 2028" — your message | Complaints will increasingly start in digital channels, which is where the JD's self-service work sits | [grounded] |
| "consolidate eight branches into five hubs over 2027" — your message | Branch managers will be living through this while you coach their supervisors | [grounded] |
| "launch a small-business lending product in Q1 2027" — your message | A new product line is a new source of questions and complaints; no more is known | [grounded] |
| "the main competitive pressure is app-only banks" — your message | The comparison the panel is likely to draw is branch-and-neighbour service against app-only convenience | [inferred] |

## Round 1: recruiter screen (30 min)

### Persona weights, with reasoning

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Conversational (A) | Friendly journey and motivation questions, plus logistics | High. A recruiter screen's prior is Conversational with a light Skeptic, and the risk is treating it as unscored | A 90-second arc built only on your quoted sentences; treat every casual question as scored |
| Skeptic, light (B) | Knockout checks against the JD's own wording | Medium. The JD lists requirements your material only partly carries (F2, F3, F4), and a recruiter checks them in a friendly register | Plain acknowledgment plus a plan; no bridge beyond your sentences |

### Questions

**Persona A: Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc with three beats, each in your own words and no wider than the quote: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you built the monthly complaints spreadsheet your regional manager uses. Close with why this role, in your own words | The recruiter's opening question is the one every other answer hangs from; F1, F2 and F5 supply the beats; EXP because it tests what was yours |
| A2 | "Why Ashgrove, and why this role?" | CO | [grounded] | Pick the one of the four published values that really connects to you and name it by its words, for example "Plain Words". Answer slot: say why it connects, from your own experience; if none of them does, say so plainly and talk about the role instead. Reasons are yours to give and are not supplied here | The values page and the JD are the sources the recruiter will test your interest against; CO because it scores homework |
| A3 | "What are you looking for in terms of salary?" | JD | [generic] | Logistics slot: either give your own number, or ask for the role's band first. Do not state a figure you would not accept | Pay is the first logistics item a recruiter screen scores; JD because it concerns the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in the terms of your contract | Notice drives the recruiter's timeline; JD because it concerns the listed job's terms |
| A5 | "Where would you be working from, and how often could you be on site?" | JD | [generic] | Logistics slot: give your actual location and the days you could be on site. If the posting has not stated an office pattern, ask the recruiter what it is, which is also a reverse question below | Location is the third logistics item; JD because it concerns the listed job's terms |
| A6 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason, in words you would also say to the Head of Member Services. Do not invent a story; one honest sentence about what you want next is enough | The reason for leaving is the screen's motivation-consistency check, and the same reason is asked again in round 2; EXP because it tests what is true of you |

**Persona B: Skeptic, light**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role asks for 4+ years in financial-services customer operations. How does your time map to that?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Say your sentence: "I have six years in retail banking, the last three as a branch supervisor." Answer slot: if the recruiter asks what the customer-facing work was in those years, say what the work actually was, in your own words; if some of the years were not customer operations, say so plainly | F1 is the requirement the recruiter can check in one line; JD because it scores a stated requirement |
| B2 | "The role covers the contact centre as well as branches. Where does that leave you?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment first: "I've never worked in a contact centre." Then a plan, said as a plan: what you would want to see first about how complaints arrive there and how they reach branches. Say it as what you would do, never as something you have done | F4 is a gap you named, and the recruiter will find it either way; JD because it scores the stated scope |
| B3 | "What part of regulated complaint handling have you done yourself?" | JD | [grounded] "I handled the branch's formal complaints log" | Hold only what the quote carries: "I handled the branch's formal complaints log." Answer slot: if the complaints in that log were handled under regulatory requirements, say which and what part was yours, in your own words; if they were not, or someone else applied the rules, say so plainly and return to the log. The honest branch is a limit, not a confession | F2 is the row where the JD's word "regulated" presses hardest against your material; JD because it scores a stated requirement |
| B4 | "Which parts of this job are you closest to, and where is the stretch?" | JD | [grounded] "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I've never presented to anyone above regional level" | Closest: the two sentences, at their own scope. Stretch: the contact centre (B2) and senior presenting (D3), named plainly with the plan for each. Do not volunteer a third stretch the material does not show | The stated-negatives pair is exactly what "weakest on day one" lands on; JD because it scores the posting against you |

### Reverse questions for the recruiter

| # | Question | Why it lands |
|---|---|---|
| R1 | "For the panel's 20-minute complaint case, is it given in advance or on the day, and should I bring anything?" | Your email names the case and its length but not its format; the answer decides how Round 3 should be rehearsed |
| R2 | "Do you know yet who the two branch managers on the panel will be?" | Names unlock a public-footprint read of each and sharper reverse questions |
| R3 | "What is the office pattern for the role, and which site would I be based at?" | Closes the A5 logistics slot with the employer's answer and not a guess |
| R4 | "What would the Head of Member Services most want to hear in our 45 minutes?" | Gets the recruiter's own words on the round's focus, which are a raising source for the next bank |
| R5 | "What happens after the 26th, and by when would you expect to decide?" | Shows you are thinking past the day and gives you a timeline |

## Round 2: Head of Member Services, your would-be manager (45 min, mostly behavioural)

### Persona weights, with reasoning

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (C) | "Tell me about a time" questions around members, honesty with leadership, working across teams | High. The recruiter calls the round mostly behavioural | Stories only from what really happened; selection criteria where no quote carries one; the honest branch always allowed |
| Skeptic (D) | Probing the scope jump, the reporting, the senior-presenting gap | Medium-high. A hiring manager prior is Case plus Skeptic, because a manager is derisking gaps, and F3, F4 and F8 are the visible ones | Hold what your sentences carry, concede the rest exactly, give a plan |
| Case/Strategist (E) | Live questions from the 2026 strategy points | Medium. Lowered from the hiring-manager prior because the round is mostly behavioural; the four strategy points you supplied still give real CO material | Clarify, then structure, then measures, then risks; challenge one premise respectfully |

### Questions

**Persona C: Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "When did you put a member ahead of an internal metric?" | VAL | [grounded] | Selection scaffold: pick a time with a named stake, a decision that was yours, and an outcome you can describe without adding to it. The published value "Members First, Always" is the theme. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first of the four values is the likeliest behavioural theme in a complaints role; VAL because it scores a published value |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time where the news was unwelcome, you said it plainly, and the relationship survived. The monthly report reaching senior leaders makes this a live theme for the job. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's monthly reporting to senior leaders makes honest-bad-news the behavioural question under F5 and F8; VAL because it scores behaviour, and the theme is a persona stem |
| C3 | "You trained new tellers on the escalation script. Tell me about how you did that." | EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped to the quote and no wider: you trained new tellers on the escalation script. Answer slot: the JD says coach branch supervisors on escalations, so expect a probe on how you taught the script and whether it was coaching; say what you actually did in a session, in your own words; if it was a different kind of session, or the script was taught by someone else, say so plainly and stay with the tellers | F6 is the closest thing your material has to the coaching requirement and the likeliest place to be probed; EXP because it tests what was yours |
| C4 | "Tell me about a time you worked with a team outside your own to change something members used." | VAL | [grounded] | Selection scaffold: pick an instance with a clear outcome members could notice and a named part that was yours. The JD's digital teams and self-service journeys are the theme. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach a first project with a digital team | F7 is silent in your material, so this is where the JD's digital line is rehearsed; VAL because it is an open behavioural prompt |

**Persona D: Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've handled your branch's complaints log, and this role owns the process across branches and the contact centre. What is the gap between those, and how would you close it?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre" | **The highest-ROI rehearsal in the pack.** The limit, named before it is asked for: your material says one branch's log, not the process, and no contact centre. Hold: "I handled the branch's formal complaints log." Concede exactly: "I've never worked in a contact centre." Then a plan, said as a plan. Follow-up 1, "but that's one branch": return to the quote and concede the scope, and do not widen it. Follow-up 2, "how would you learn the contact centre": your first steps, as intentions. Follow-up 3, "so why you": your own reason in one sentence, built only on what you have actually said in these rounds. Hold two follow-ups before conceding anything beyond the scope | This is the objection the whole loop turns on: the role's ownership scope (F3, F4) against what the material carries. It will be asked in some form by the manager and echoed by the panel; JD because it scores the stated scope |
| D2 | "Walk me through the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped to the quote and no wider: you built it, it is monthly, your regional manager uses it. Answer slot: the JD says report on complaint volumes and resolution times in Excel, so expect a probe on what it counted and what tool it was in; say what it tracked and which program, in your own words; if it tracked other things, or was in another tool, say so plainly. No figure is given here, so no number is supplied to defend | F5 and F9 are the reporting requirements and the one place your material shows reporting; JD because it scores the stated requirement |
| D3 | "The role presents to senior leaders. Where are you on that today?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan, said as a plan: what you would ask before a first senior-leader presentation, and how you would prepare for it. Say it as intention and never as an experience | F8 is a gap you named; saying it first removes the question's sting; JD because it scores the stated requirement |

**Persona E: Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Ashgrove wants 40% of member service on digital channels by 2028. What does that mean for how complaints are raised and handled?" | CO | [grounded] | Structure aloud: clarify what counts toward the 40% and whether complaints do; objective; which members and which channels; what you would measure (the JD's volumes and resolution times); risks, such as members who want the counter ("Neighbours, Not Numbers"). Challenge one premise respectfully, for example whether every complaint should start in self-service. Makes no claim about your past | The strategy point you supplied is the one that meets the JD's self-service line; CO because it scores strategy at the company's altitude |
| E2 | "App-only banks are our main competitive pressure. Where should a member-owned credit union win on complaints?" | CO | [grounded] | Bring one point from the strategy as proof of homework, then one view of your own with a reason. The published values, such as "Plain Words", are language you can use without claiming a story. Makes no claim about your past | The competitive-pressure point is the most quotable line in the strategy; CO because it tests homework depth |
| E3 | "Eight branches are becoming five hubs over 2027. What happens to complaints?" | CASE | [grounded] | Clarify first: what changes for members and for supervisors. Then structure: where complaints land, who owns them during the move, how members in a closing branch are kept informed, and the measures you would watch. "Neighbours, Not Numbers" is the tension to name. Makes no claim about your past | The consolidation is the change the panel will be living through; CASE because it is a live problem from the role |
| E4 | "A branch supervisor is mishandling an escalation. How do you coach them?" | CASE | [generic] | Structure: find out what happened before judging; separate the member's outcome from the coaching conversation; what you would agree with the supervisor; how you would check it held. No claim about your past is made, and none is needed | The JD's coaching line asks this as a decision and not as a record; CASE because it is a live problem |

### Reverse questions for the Head of Member Services

| # | Question | Why it lands |
|---|---|---|
| R1 | "How does complaints reporting reach senior leaders today, and what would you want it to do differently?" | Shows you are thinking at the altitude of F8 without claiming experience there |
| R2 | "Which part of the shift to digital would complaints feel first?" | Ties your interest to the strategy point you read |
| R3 | "How are branch supervisors supported on escalations today, and where do they struggle?" | Tests the coaching requirement from the supervisors' side |
| R4 | "Where do branch and contact-centre handling of complaints differ most today?" | Turns the contact-centre gap into a question about the job |
| R5 | "In my first quarter, what would you want me to have seen: branches, the contact centre, or both?" | Gives you a plan shape for D1 and shows you are planning for the scope |

## Round 3: panel of two branch managers (60 min, including a 20-minute complaint-escalation case; scored against the four values)

### Persona weights, with reasoning

Names are not assigned, so personas are blended for the panel, not set per member.

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (F) | One question per published value, scored | Highest. The recruiter says the panel is the values round and scores against the four values | One real story per value, or the scaffold and its honest branch |
| Case/Strategist (G) | The 20-minute escalation case | High. The recruiter names it and gives it a third of the hour | Clarify, objective, approach, measures, risks; think aloud |
| Peer Evaluator (H) | The seam between the role and the branches, and what the role adds to a branch manager's load | Medium. Branch managers are the people whose supervisors the role coaches, and the hub plan affects their branches; this is the pack's inference and not a stated focus | Reciprocity: what the role brings to their branch; offer principles for the seam and do not pretend to know the seam |
| Pressure (I) | Short-time challenge on your own claims | Low. No signal in the recruiter's note points to it, but a panel can interrupt | Pause, restate, hold what you stated, concede specifically |

### Questions

**Persona F: Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Members First, Always: tell us about a decision you made from the member's side of the counter." | VAL | [grounded] | Selection scaffold: pick a decision that was yours, where the member's interest and a branch or internal interest pulled apart, and where you can say what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first published value; VAL because it scores that value, and the story is yours to find |
| F2 | "Plain Words: tell us about a time you had to explain something again because the first explanation did not land." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped to the quote and no wider: you trained new tellers on the escalation script. Answer slot: the value says that if a member needs it explained twice, we wrote it wrong, so expect a probe on whether anything in how the script was worded or taught was changed because it did not land; if it was, say what and why, in your own words; if you taught it as written, say so plainly and stay with the training | The second published value; F6 is the one quote that touches explaining; VAL because it scores that value |
| F3 | "Neighbours, Not Numbers: tell us about a time the needs of your branch's town and a number you were measured on pulled apart." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | The quote gives you a branch supervisor role of three years and nothing about a conflict. Selection scaffold: pick an instance where a local need and a number really pulled apart and what you did is clear to you. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Expect branch managers to hear this against the eight-to-five hub plan | The third published value; the panel are branch managers; VAL because it scores that value |
| F4 | "Own the Fix: tell us about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped to the quote: you handled the branch's formal complaints log. Answer slot: the value says whoever finds the problem keeps hold of it until it is solved, so expect a probe on a complaint you stayed with to the end; if one comes to mind, say what it was and which part was yours, in your own words; if none does, or the log's job was recording and not resolving, say so plainly and stay with the log | The fourth published value; F3's log is the one quote near it; VAL because it scores that value |

**Persona G: Case/Strategist**

The panel's case is unknown, so these are practice cases for the structure, not predictions of the real one. All are `[generic]` and make no claim about Ashgrove's process or your past.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member complained at a branch, was passed to the contact centre, and has now been given two different answers. They say they are moving to an app-only bank. Walk us through what you do." | CASE | [generic] | Clarify first: what each side told them, how long it has been open, what the member has asked for. Then objective (one answer, one owner, and an apology that is plain), who owns it from now, what you tell the member and when, what you check afterwards, and what you change so it does not repeat. Say aloud what you do not know yet | The case recruiter-described as "a complaint escalation" most plausibly sits between branch and contact centre, the JD's two channels; CASE because it is a live problem |
| G2 | "A branch supervisor wants to close a complaint early because it is hurting their numbers. What do you do?" | CASE | [generic] | Clarify what is open and what the supervisor believes. Separate the member's outcome from the supervisor's numbers; name "Own the Fix" as the principle; say what you would agree with the supervisor and what you would escalate. Challenge the premise that closing and resolving are the same | Tests the coaching line and the Own the Fix value together; CASE because it is a live problem |
| G3 | "In your first 30 days, what would you look at before changing anything?" | CASE | [generic] | A plan, said as a plan: how complaints currently arrive, move between branches and the contact centre, and are measured (the JD's volumes and resolution times); who you would want to listen to first. No claim about your past | The panel's scoping question for the whole role; CASE because it is a live problem |

**Persona H: Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our branches are part of the move from eight to five hubs. What would you need from us, and what would we get from you?" | CASE | [grounded] | Reciprocity framing: lead with what the role gives a branch manager, then what you need. Offer principles for the seam and do not pretend to know where it sits. Makes no claim about your past | The consolidation is the strategy point most felt by branch managers; CASE because it is a live problem |
| H2 | "Tell us about a time you disagreed with a manager about how a complaint should be handled." | VAL | [generic] | Selection scaffold: pick an instance where you disagreed, said so, and the relationship held. It needs a named stake and an outcome you can describe without adding to it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peers test spine and tact together; VAL because the theme is a persona stem |
| H3 | "A supervisor says the contact centre's handling of a member undermined their branch. How do you deal with credit and blame across the two?" | CASE | [generic] | Principles, said aloud: get both accounts before judging; treat it as one member's experience before it is a branch-versus-contact-centre argument; agree what is shared and what is each side's. Makes no claim about your past | The collegial packaging of the contact-centre gap (F4); CASE because it is a live problem |

**Persona I: Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "That complaints spreadsheet: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Pause, restate, then hold: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if anyone else set what it tracked or built part of it, say which part and who; if no one did, say so plainly. Concede only what is true | A pressure stem aimed at F5; EXP because it tests attribution |
| I2 | "You have sixty seconds: why you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | Three sentences, at their own scope, in your own words. Then one honest limit, in your own voice: the contact centre. Do not add a fourth claim to sound bigger | The panel's compression of the whole fit snapshot; JD because it scores the posting against you |

### Values cheat sheet

Published values, by their official names, as pasted from ashgrovecu.org/about/values.

| Value | Working meaning, paraphrased | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F3's quote "6 years in retail banking, the last 3 as a branch supervisor" is context only. Selection scaffold: a decision that was yours where the member's interest and an internal one pulled apart. If none comes to mind, say so plainly and give the nearest thing your material carries, or how you would handle it |
| Plain Words | If a member needs it explained twice, the writing was wrong | F6: "trained new tellers on our escalation script". Answer slot as in F2 above |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold as in F3 above, ending in its honest branch |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F3's row: "I handled the branch's formal complaints log". Answer slot as in F4 above |

### Reverse questions for the panel

| # | Question | Why it lands |
|---|---|---|
| R1 | "Where do escalations from your branch most often get stuck today?" | Branch managers know this first-hand, and it shows you start from their problem |
| R2 | "What would you want from this role that you do not get now?" | Reciprocity: it asks what you can add to their load and not only what you need |
| R3 | "How are you thinking about complaints during the move from eight branches to five hubs?" | Ties your interest to the strategy point you supplied |
| R4 | "Which of the four values is tested hardest in a normal week at your branch?" | Shows you took the values as working principles and not slogans |
| R5 | "What would make you say this person was easy to work with from the branch side?" | Ends on their definition of success for the seam |

## Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | D1, B2, G1, G2, H3 |
| "report monthly on complaint volumes and resolution times" | D2, I1, E1, G3 |
| "coach branch supervisors on escalations" | C3, E4, G2, F2 |
| "work with digital teams on self-service journeys" | C4, E1 |
| "4+ years in financial-services customer operations" | B1, A1, I2 |
| "experience handling regulated complaints" | B3 |
| "confident presenting to senior leaders" | D3, C2 |
| "comfortable with Excel reporting" | D2 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: your material says the branch's log, not the process |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says a formal log and does not show the complaints were regulated. B3's slot stays inside the log |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: new tellers and the script. The limit is the pack's observation |
| Reported on complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: a monthly complaints spreadsheet. The limit is the pack's observation: your sentence does not say what it counted |
| Has contact-centre experience | Negative you stated, F4 | The plain acknowledgment: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |

## Sources

Provided: the job description you pasted; the four values pasted from ashgrovecu.org/about/values (pasted text, not fetched); the recruiter's email on the three rounds; your summary of the July 2026 strategy brief (the brief itself was not read); your background as written in your message. No dossier was present.

Searches sent: none. Pages fetched: none. The pasted values were not compared against the live page.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values page already fixes the values cheat sheet and the F bank, and the VAL questions use its names |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email names the three sessions, who runs each and what each holds, which fixes the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The four strategy points you supplied, from a July 2026 brief under six months old, already fix the CO bank and the grounding brief |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer name was given beyond roles, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your actual CV, or the exact bullets behind the two complaints sentences → F1 to F6 and F9 would quote CV lines and not only your message, and the discovery rows (F2, F5, F9) might close
- Your answers to the answer slots, especially F2, F5, F7 and F9 → each becomes a story-mapped row with your own words, and the guidance upgrades from slot to story
- One real story per value, in your own words → F1 to F4 and C1 to C2 move from scaffolds to mapped stories
- The full 2026 strategy brief pasted → the grounding brief and E1 to E3, H1 become specific and not summary-level
- The names or profiles of the two branch managers and the Head of Member Services → an interviewer read, persona weights read from their public footprint, and reverse questions tied to their own paths
- The recruiter's answer on whether the 20-minute case is given in advance → G1 to G3 restructure around the real format
- A `tuesday-dossier.md` → verified-evidence grading and the underwriter's named objection would replace this pack's inferred one; never a prerequisite
- Deeper research, offered once → up to 6 more searches and 2 more fetches, several more minutes, covering a fuller strategy read, interviewer footprints, role-family loop reports and recent organisation context; say so if you want it
