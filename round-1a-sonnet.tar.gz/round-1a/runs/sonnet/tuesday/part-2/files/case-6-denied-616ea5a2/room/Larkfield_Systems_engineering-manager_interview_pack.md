# Interview prep pack — Engineering Manager, Larkfield Systems (loop mode, three rounds)

Candidate: Yusuf. Rounds: Tuesday, 45 minutes, the Director of Engineering (hiring manager, your would-be boss). The Thursday after, 60 minutes, panel of two staff engineers and a product manager. The following Monday, 30 minutes, the VP Engineering, described by the recruiter as "values and leadership philosophy".

Built on these assumptions: the Director sits one level above the role and the VP one level above the Director; the staff engineers would work alongside you, not report to you. Neither is stated in your message, so a correction reweights the panel bank (see the closing questions). No interviewer names were given, so there is no interviewer read.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script. Where guidance says "answer slot", it is an instruction for the interview: fill it from your own experience, or take the honest second branch.

Persona key: A Case/Strategist, B Skeptic, C Peer Evaluator, D Data-Driven Prober, E Values/Behavioral, F Pressure, G Conversational. Question IDs read round, persona, number: 1B1 is round one, Skeptic, first question.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the values and leadership approach the interviewer cares about |
| EXP | Whether claims on your CV survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack; see Sources) |
| CASE | A live problem from the role, scored on structure and reasoning |

## Prep triage (two weeks, three rounds)

The few things to do well, in order. Everything else is insurance.

| Order | Do this | Tied to |
|---|---|---|
| 1 | Rehearse the single most likely objection until it is boring: the hardware-roadmap gap. Say the plain acknowledgment once aloud, then the plan | 1B1, F5, and 3F1 for the Monday version |
| 2 | Be able to say, in your own words, how the 60% on-call figure was counted, what it is sensitive to, and what you would defend least. If you do not know how it was counted, say that plainly | 1D1, 2D2, 3F2 |
| 3 | Rehearse the two-minute reliability-quarter story, using only what your sentence states, with the answer slots filled from memory | 2D1, 2E1, 3E2 |
| 4 | Do one live drill per round with the persona that leads it. Tuesday: Skeptic. Thursday: Prober. Monday: Values | Round banks |
| 5 | After Tuesday, send me what the Director said about the panel and the VP. I will regenerate the later rounds | Step 5 regeneration |

## Fit snapshot (shared across all three rounds)

Proposed wording below is pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of six at a payments company, not two squads and not device-management, with nothing inspected behind it. The words stay there: "I've been a team lead of six, for three of my nine years in engineering." Answer slot: the role description's device-management line makes a probe on what carries over likely. If any of your current systems carries over to services that manage devices, say what, in your own words; if none does, say so plainly and stay with the team of six |
| F2 | "own delivery, hiring and growth for 11 engineers" (the delivery part) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence covers one reliability quarter and a 60% fall in on-call burden after it, not ownership of delivery generally, and nothing inspected sits behind the figure. The words stay at that scope: "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%." Answer slot: if you also set or sequenced the team's wider delivery commitments, say how, in your own words; if you did not, say so plainly and stay with the quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" (the hiring part) — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap in wording, but a claim with nothing inspected behind it, so expect a probe. Lead with the loop in the quote's own terms, that you run it for backend roles, and keep the number attached to what it counts, interviews. Expect the question of what that number covers (1D2) |
| F4 | "own delivery, hiring and growth for 11 engineers" (the growth part) — role description in your message | none given | none | [grounded] | discovery | The material does not show whether you have worked on engineers' growth. Answer slot: the role description's growth line makes a probe likely. If you have supported an engineer's development or progression, say what you did, in your own words; if not, or it was not yours, say so plainly and say how you would start with eleven people |
| F5 | "partner with hardware and product on roadmap" (the hardware part) — role description in your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "partner with hardware and product on roadmap" (the product part) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The sentence mentions roadmap pressure and does not say whom it came from or how you worked with them. Answer slot: if product was part of that pressure, say how you worked with them, in your own words; if it came from elsewhere, or there was no such conversation, say so plainly and stay with the reliability quarter |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 lead two squads, device-management | 1A1, 1A2, 1B2, 1G2, 2D3, 3A1 |
| F2 own delivery | 1A3, 1D1, 2D1, 2D2, 2E1, 3F2 |
| F3 hiring | 1D2, 2C4 |
| F4 growth for 11 engineers | 3E3, 1B2 |
| F5 hardware partnership | 1B1, 1A2, 3A2, 3F1 |
| F6 product partnership | 1A3, 2E1, 2E2, 2C3 |

Not covered by a question, and why: nothing is listed in the role description beyond these lines. A full JD would add rows (see the upgrade menu).

## Prohibited claims (shared)

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a hardware-adjacent roadmap | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never owned a hardware-adjacent roadmap." No slot |
| Managed managers | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never managed managers." No slot |
| Led two squads, or a team of eleven | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a team of six |
| Owned delivery for the team's roadmap | Inflated form of F2 | F2's quote at its own scope: the material says one reliability quarter pushed through |
| Cut on-call burden by 60% through your own work | Inflated form of F2 | F2's quote at its own scope: the burden dropped after you pushed the quarter through. 1D1 asks only how it was counted and which part was yours |
| Hired about 40 engineers | Inflated form of F3 | F3's quote at its own scope: about 40 interviews. The limit is the pack's observation: the material counts interviews, not hires |

---

# Round 1 — Tuesday, 45 minutes, Director of Engineering (hiring manager)

### Persona weights, with reasoning

| Persona | How it shows up | Weight, and why | Counter-strategy |
|---|---|---|---|
| B Skeptic | Probes the gaps: scope step-up, no hardware roadmap, why leave payments, why now | Highest. The hiring-manager prior is Case plus Skeptic: they are buying capability and de-risking gaps, and F5 is a stated gap | Rehearse the single most predictable objection until it is boring; bridge only from what you stated; a concrete ramp plan |
| A Case/Strategist | Live problems from the actual role: priorities for two squads, a hardware slip | High. Same prior; a boss tends to test how you would think on the job | Clarify, objective, approach, metrics, risks; think aloud; challenge one premise respectfully |
| D Data-Driven Prober | Reads your claims line by line, asks how numbers were counted | Medium. The CV-style claims (60%, 40 interviews) are exactly what a boss checks first | Know what you can and cannot say about how each number was counted, and say plainly where you do not know |
| G Conversational | Opens with the biography; casual questions that are still scored | Lower but certain: first five minutes of almost every round | A 90-second arc built only from your own sentences |

Loop note: the recruiter's description of the Monday round as "values and leadership philosophy" establishes a values-style round, and it sits in round 3, not here.

### Bank B — Skeptic (proposed wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in this pack. Name the gap as your message states it: "I've never owned a hardware-adjacent roadmap." Then give a plan, not a past: what you would learn first and from whom, in your own words. Hold through two follow-ups by returning to that sentence; concede the limit specifically rather than reaching for adjacent experience you did not describe | F5 is the biggest gap against the roadmap-partnership line, so this objection arrives in some form; JD because it scores the stated requirement, Skeptic because it asks you to name your own weakness |
| 1B2 | "You've been a team lead of six. This role is two squads and eleven engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Start from the quote at its own scope: team lead of six, for three of nine years. Answer slot: the role's two squads and eleven engineers make a probe on how the work changes likely. If you have worked with larger groups, say how, in your own words; if not, say so plainly and return to the team of six. A plan for your first weeks with two squads is fine as a plan | F1 is the scope step-up and the likeliest second objection; JD because the numbers come from the role description |
| 1B3 | "You've said you haven't managed managers. How would you approach that here?" | EXP | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Plain acknowledgment first: "I've never managed managers." Then a plan: what you would ask the Director about how the squads are structured, and how you would learn from them. Ask rather than assume the role involves managers. Do not describe leading leads as something you have done | F5 holds your stated negative; EXP because it tests whether your account of your own history stays honest under a direct challenge |
| 1B4 | "Why leave a payments company for industrial IoT, and why now?" | JD | [generic] | A scaffold, because your material does not state your reasons. Give your actual reasons in your own words: what draws you to this kind of product, and why this role and not a similar one at your current company. Keep it consistent with what you tell the VP on Monday | The standard motivation probe for a hiring manager; generic because no sentence in your material carries the answer |

### Bank A — Case/Strategist (proposed wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "You'd have two squads building device-management services. What do you need to know before you set their priorities?" | CASE | [generic] | Clarify first: what each squad owns today, what they have committed to, what depends on hardware and what depends on product. Then objective, segmentation of the work, approach, metrics, risks. Challenge one premise respectfully, such as whether the squads' split is the right one. The question needs no claim about your past, so the guidance makes none | F1's requirement as a live problem; generic because it is a pattern for the problem, not a fact about this employer |
| 1A2 | "A hardware release slips six weeks and your squads' plans depend on it. Walk me through the next two days." | CASE | [generic] | Structure aloud: what you would ask first, who you would tell and in what order, what you would re-sequence, what you would say to product, what you would record. Where you do not know how hardware planning works here, say so and say what you would ask. No claim about your past | The roadmap-partnership line as a live problem, which targets F5 without asking about a past you do not have; generic |
| 1A3 | "Your engineers want a reliability quarter and product wants features. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer the decision as a structure first: what evidence you would want, who has to be in the conversation, what you would trade. If you reference your own reliability quarter, say it only as your sentence does: you pushed it through against roadmap pressure, and on-call burden dropped 60% after. Answer slot: if you set the criteria for that decision, say what they were; if there were none formal, or it was not yours to set, say so plainly | Tests the trade-off at the heart of F2 and F6; CASE because it asks for a decision, with your own story as one optional example |

### Bank D — Data-Driven Prober (proposed wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1D1 | "Walk me through how the 60% on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Four slots, each in your own words, none filled for you: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say that plainly. The sentence says the burden dropped after you pushed the quarter through; stay at that scope | F2's headline number is the first thing a boss tests; EXP because it checks attribution |
| 1D2 | "You mention about 40 interviews last year. What does that number cover?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Same four slots: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. The number counts interviews, and the guidance supplies nothing about who conducted them or how many led to hires. If you know, say so; if not, say so plainly and return to running the loop | F3's number is the other headline figure; EXP |

### Bank G — Conversational (proposed wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1G1 | "So, walk me through the journey to here." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year" | A 90-second arc with only these beats, each at its stated scope: nine years in engineering, three as a team lead of six, currently at a payments company, you run the hiring loop for backend roles. Close on why this role, in your own words. Anything else in the arc is yours to choose, from experience you can defend | The biography question opens most rounds and is scored; F1 and F3 supply the beats |
| 1G2 | "What are you actually playing with in connected hardware or device management these days?" | JD | [generic] | A scaffold: if you have read, built or talked to anyone about anything in this area, say what, in your own words; if nothing, say so plainly and say what you would read first. Do not describe interest you have not acted on | A casual question on the role's central topic, still scored; generic because no sentence in your material carries it |

### Reverse questions — Tuesday

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What would make you say, ninety days in, that this hire worked?" | Shows you think in outcomes and gives you the Director's yardstick to aim every later round at |
| R1.2 | "Where do hardware and software roadmaps collide today, and who arbitrates?" | Turns F5 from a gap into a curious question about the real seam |
| R1.3 | "What is the mix across the eleven engineers, and are there leads in the squads already?" | Surfaces whether managing managers is actually part of the role, instead of assuming it |
| R1.4 | "When reliability work competes with roadmap commitments, how does that get decided here?" | Connects to the reliability quarter without claiming more than it was |
| R1.5 | "What worries you most about my background, and what would settle it?" | Lets you answer the objection live, with the Director's own framing |
| R1.6 | "How are engineers' growth and progression handled today?" | Covers F4 without pretending to experience |

---

# Round 2 — the Thursday after, 60 minutes, panel: two staff engineers and a product manager

### Persona weights, with reasoning

| Persona | How it shows up | Weight, and why | Counter-strategy |
|---|---|---|---|
| C Peer Evaluator | The staff engineers asking where the seams are and what happens when you disagree | Highest. They are colleagues-in-practice who will price what you cost and contribute to their work | Reciprocity: what you bring their team; propose seam principles, not claimed knowledge of the seam |
| D Data-Driven Prober | Technical depth on the reliability quarter and the 60% | High. Staff engineers verify; the reliability claim is your one technical story | Know what was yours and what was the engineers'; say plainly where you do not know |
| E Values/Behavioral | The product manager's scenario probes on roadmap partnership | Medium. A product manager is cross-functional, and the role description names product partnership | Stories where you can say "we" for context and "I" for contribution |

The panel prior blends the top two personas of each member's relationship. Members are assigned by role, not by name, because no names were given.

### Bank C — Peer Evaluator (proposed wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2C1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Offer principles for the seam rather than claiming to know it: who owns which decisions, how disagreement is raised early, how it is escalated. Add what you would bring the staff engineers' work, not only what you need. No claim about your past | The standard peer seam probe; generic because it is a pattern |
| 2C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A selection scaffold: pick a time work spanned teams, with a named contribution of yours, where the credit landed, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit-sharing is the peer probe; generic because none of your sentences carries a cross-team story |
| 2C3 | "A staff engineer tells you the roadmap you inherited is technically unsound. What do you do?" | CASE | [generic] | Structure aloud: what you would ask first, what evidence you would want, who else needs to be in the room, how you would involve product, what you would be willing to concede. No claim about your past | F6's partnership requirement as a live problem; CASE because it asks for a decision |
| 2C4 | "You run a hiring loop. What makes you say yes to a backend engineer?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Describe, in your own words, the signals you actually look for. Answer slot: the panel will probe how the loop decides. If your loop uses a rubric or scorecard, say how, in your own words; if there was no formal rubric, or it was not yours, say so plainly and describe how you run the loop. Keep the number at what it counts, interviews | Staff engineers interview too, and F3 is your strongest requirement, so this is where you can lead with substance |

### Bank D — Data-Driven Prober (proposed wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2D1 | "Walk me through the reliability quarter: what was in it, and where did you come in?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Tell the beats your sentence states: a reliability quarter, pushed through against roadmap pressure, on-call burden dropped 60% after. Answer slot: the probe will be on contents and your part in them. If you chose what went into the quarter, say how, in your own words; if the engineers did, or there was no such choice, say so plainly and describe what you did to push it through | F2 is the one technical story, and staff engineers will test depth; EXP because it tests attribution |
| 2D2 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Name the assumption in your own words, before they do, or say plainly that you do not know how the figure was counted. Reuse your answers to 1D1. The weakest-assumption move converts a gotcha into credibility | A staff-engineer probe of F2's headline number |
| 2D3 | "What would you need to learn about device-management services to challenge our designs?" | JD | [generic] | Be candid about the gap, as your material does not show device-management experience. Answer slot: if any of your current systems carries over, say what, in your own words; if none does, say so plainly and say what you would learn first and from whom. Do not claim a design opinion you cannot defend | F1's domain gap seen from the engineers' side; generic |

### Bank E — Values/Behavioral (proposed wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2E1 | "Tell me about a time you pushed back on a roadmap." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story map from your sentence: you pushed a reliability quarter through; there was roadmap pressure; on-call burden dropped 60% after. Answer slot: the product manager will probe who the pressure came from and how you handled it. If product was part of it, say how you worked with them; if the pressure came from elsewhere, or you did not have that conversation, say so plainly and stay with the quarter. "We" for context, "I" for contribution | The role description names product partnership, and F2 and F6 are your only roadmap evidence |
| 2E2 | "Tell me about a time you and a product partner disagreed about what to build next." | VAL | [generic] | A selection scaffold: pick a disagreement with a named stake, a position you held, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The product-partnership requirement asked behaviorally; generic because none of your sentences describes a disagreement |
| 2E3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | A selection scaffold: choose a time with a named stake, a moment you did not fold, and an intact relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for the Values interviewer; the product manager may use it to test candor |

### Reverse questions — Thursday

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What could a new engineering manager do in their first month that would genuinely help your work?" | The reciprocity question for peers: it frames you as reducing their load |
| R2.2 | "Where does the architecture hurt most when hardware changes underneath it?" | Technical, curious, and aimed at your biggest domain gap |
| R2.3 | "How are hardware and product priorities reconciled today, and where does it hurt?" | Asks the product manager for the roadmap seam directly |
| R2.4 | "When reliability work and roadmap features compete, who decides and how?" | Echoes the reliability quarter without claiming more than your sentence |
| R2.5 | "How do you prefer to hear that something is slipping?" | A low-cost, useful question for any partner |

---

# Round 3 — the following Monday, 30 minutes, VP Engineering ("values and leadership philosophy")

### Persona weights, with reasoning

| Persona | How it shows up | Weight, and why | Counter-strategy |
|---|---|---|---|
| E Values/Behavioral | Scenario probes on how you lead and why | Highest. The recruiter's own words, "values and leadership philosophy", put a values-style round here | Stories where your quoted sentences carry them, selection scaffolds where they do not; no invented principles |
| A Case/Strategist | Altitude questions on what the squads should become | Medium. A skip-level or executive prior is Case/Strategist, and the role includes hardware and product partnership | Think aloud at the right altitude; challenge one premise |
| F Pressure | Time-boxed challenge to your fit and your claims | Lower. The executive prior adds Pressure, but 30 minutes leaves little room | Pause, restate, hold through two follow-ups, concede only what is true |

No published Larkfield values were available, so there is no values cheat sheet: it needs the company's own value names, which come from research or a pasted page, never memory.

### Bank E — Values/Behavioral (proposed wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3E1 | "What's your philosophy of leading engineers, and where did it come from?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A scaffold: choose two or three principles you actually act on, each tied to something you did that you can describe in your own words. Two things you can point to are that you run the hiring loop for backend roles and that you pushed a reliability quarter through against roadmap pressure. Describe what you did and let the VP draw the inference; do not assert what it proves. If a principle has no example you can stand behind, leave it out | The recruiter's own words raise this question; VAL because it scores values and leadership approach |
| 3E2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Map your sentence: you pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60% after. Answer slot: the VP will probe who the pressure came from and how it landed. If it came from leadership, say how you raised it, in your own words; if it did not, or you did not raise it with leadership, say so plainly and tell it as the roadmap pressure it was. If no leadership-facing time comes to mind, say so plainly, then give the nearest thing your material does carry | A persona stem for Values; F2 is your only roadmap-pressure sentence |
| 3E3 | "How do you think about growing engineers, and what do you owe them?" | VAL | [generic] | A selection scaffold: pick a person or a moment where you supported someone's development, with your part named and the outcome as it actually was. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it with eleven people | F4's growth line, which your material does not show; generic, so rehearse the honest branch |
| 3E4 | "What kind of manager do you want to become, and what are you still learning?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | A natural place to acknowledge the limit without being asked: "I've never managed managers" and "I've never owned a hardware-adjacent roadmap." Then say what you want to learn and how. State learning as intent, not as past practice | A leadership-philosophy question invites self-assessment, and F5 holds the limits you stated |

### Bank A — Case/Strategist (proposed wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3A1 | "What would you want the two squads to look like in a year?" | CASE | [generic] | Say what you would need to learn before committing to a picture, then give a direction in outcomes you could track and a few risks. Stay at the altitude of principles, not specifics about this company that you cannot know. No claim about your past | F1's scope at a VP's altitude; generic |
| 3A2 | "The role partners with hardware on roadmap. How would you handle hardware and software planning on different rhythms?" | CASE | [generic] | Structure aloud: what you would ask first, how you would make dependencies visible, where you would put buffers, what you would escalate. Where you do not know how it works here, say so. No claim about your past | F5 as a live problem; generic |

### Bank F — Pressure (proposed wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3F1 | "Sixty seconds: why you over a manager who has already run a hardware roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "I run our hiring loop for backend roles — about 40 interviews last year" | Pause, restate, then hold only what your sentences carry: you run the hiring loop for backend roles, and you pushed a reliability quarter through against roadmap pressure. Concede the limit plainly: "I've never owned a hardware-adjacent roadmap." Hold through two follow-ups by returning to what you did, never by adding to it | The Pressure version of F5, the single most likely objection; the VP's time-box makes it concise |
| 3F2 | "That on-call result. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slot: say which part was yours, in your own words, starting from what your sentence states, that you pushed the quarter through. If the technical work was others', say so plainly. Concede specifically, never fold on what you did do | A persona stem for Pressure; attribution is where F2 is most exposed |

### Reverse questions — Monday

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What does the company need its engineering leadership to be better at over the next year?" | Shows altitude, and tells you what the VP is solving for |
| R3.2 | "What did the last manager you brought into this org get right in their first six months, and what did they get wrong?" | Reveals the real bar, if there has been one |
| R3.3 | "How do you want a new manager to disagree with you?" | A leadership-philosophy question turned around |
| R3.4 | "How do you protect reliability work when roadmap pressure builds?" | Connects to your own story as a question, not a claim |
| R3.5 | "What would make this role a mistake for me or for you?" | Invites candor and shows you are choosing too |

---

## Sources

Provided documents: the role description and your background as pasted in your message. No full job description, values page, interviewer profile or recruiter email was provided. The recruiter's description of the VP round, "values and leadership philosophy", is a provided source for the loop. No dossier was present.

Searches sent, all four refused (the host did not grant search permission):

- "Larkfield Systems industrial IoT values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems strategy news device management" — refused
- "Engineering Manager device management IoT platform job description" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have produced the values cheat sheet for the Monday round and VAL questions mapped to named values; the section is dropped |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have confirmed loop structure beyond what you were told and sharpened persona weights; weights rest on your description and relationship priors |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have enabled CO questions and strategy-grounded CASE questions; the pack has no CO question, and the CASE bank is generic |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there was no query to form; the interviewer read is absent |
| 5. representative `Engineering Manager` JD | unavailable | Would have added further requirement rows to the fit snapshot, labeled inferred |

## Upgrade menu

- Full JD text → more requirement rows in the fit snapshot and JD questions rewritten against the posting's own wording
- Interviewer names (the Director, the staff engineers, the product manager, the VP) → an interviewer read, personas assigned per person, and reverse questions tied to their paths
- The recruiter's guidance on the panel's focus, and any pre-declared deliverable → bank weights and any build sections
- The text of Larkfield's published values, pasted → the values cheat sheet for Monday and VAL stories mapped to named values
- Search access, or a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → company strategy for CO questions and strategy-grounded CASE questions
- Your answers to the slots on F1, F2, F4 and F6, given outside a drill → those rows regenerate with your own words, and the guidance that rests on them upgrades from slot to story
- A `tuesday-dossier.md` from a job-underwriter run → verified evidence and an evidence-derived objection in place of the one inferred here
