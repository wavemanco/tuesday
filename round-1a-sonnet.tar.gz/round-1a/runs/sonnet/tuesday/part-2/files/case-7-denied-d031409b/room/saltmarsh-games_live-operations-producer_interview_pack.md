# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. The relationship is assumed to be hiring manager, because your note did not say. Sixty minutes, one session, per your message.
**Built on:** your JD and your message only. Web research was refused, so nothing in this pack is a fact about Saltmarsh Games beyond what you pasted.

## How to use this pack

Personas describe how a question will be asked. Types describe what is being scored. Every question carries a persona letter (A to F), a type tag, the exact sentences of yours that its guidance rests on, and a rationale.

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values. None in this pack, because no published values were available |
| EXP | Whether your own experience survives scrutiny: what was actually you |
| JD | A stated responsibility or qualification in the posting, including its gaps |
| CO | Knowledge of the company and its strategy. None in this pack, because no company research was available |
| CASE | A live problem set in the role, scored on structure and reasoning |

Guidance is scaffolding for a spoken answer, not a script. An answer slot is an instruction for the interview: it tells you what the interviewer is likely to probe and gives two honest branches. Answer from your own experience, or say plainly that the step was not yours or did not exist. Where the pack has no sentence of yours for a question, it gives selection criteria instead of a story.

## Fit snapshot

Evidence is quoted from your message. Where you give me a CV, these quotes become exact CV lines.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says one main title's weekly content-drop calendar, not events across two titles, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title, live-events wording makes a probe on the step up likely. If you ever planned events, or planned across more than one title, say how, in your own words; if you did not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases" — your message | low | [inferred] | discovery | Your material says you have not led a team. The JD asks for coordination across four teams, which is a different thing, and your material does not show whether you coordinated any of them. The words for the part you stated: "Never led a team." Answer slot: if you worked with design, art, engineering or community on your weekly drops, say who and how, in your own words; if you did not, or it ran through someone else, say so plainly |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented the numbers, not that you owned a review or chose its KPIs, and the words stay there: "Presented the monthly retention numbers to the studio head." Answer slot: the JD's ownership wording makes a probe on who produced and chose those numbers likely. If any of that was yours, say which part, in your own words; if someone else produced them, or no review sat behind them, say so plainly and stay with the presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap in the words, but a CV-style line with nothing inspected behind it, so expect a probe. Lead with what the quote states: you wrote the checklist, and QA still uses it. Your material does not say who ran it release by release, so the words stay inside the quote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Your material says four years as an associate producer at a puzzle-game studio. It does not say how many of those years were on a live-service title. Answer slot: the JD's 3+ years makes a probe on which years count likely. Say which of your years were on a live title and what made it live, in your own words; if you cannot count three, say so plainly and say what the years you can count were |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap: the quote states it in the JD's own terms. You ran the calendar, weekly, for the last two years. Expect a probe on how much of it was yours (E1). The quote's limit is that it names one main title |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Presenting retention numbers monthly is adjacent to being comfortable with them, and the words stay at the presentation: "Presented the monthly retention numbers to the studio head." What sits behind the presentation is for the probe, and the slots are in C1 and C2 |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A written artifact is in your material, but a checklist is not the prose the JD points to. Answer slot: if you also wrote updates, event briefs or reviews, say what and for whom, in your own words; if the checklist is the main thing you wrote for others, say so plainly |

No row is a gate. The JD's "3+ years" is an experience requirement, so it is graded like any other row.

## Persona table

Weights come in three passes: relationship prior, interviewer signals, then the loop.

- **Relationship prior:** a hiring-manager round puts Case/Strategist and Skeptic first. This rests on your note not naming the relationship, so it is an assumption. Question (1) at the end of my message asks you to confirm it.
- **Interviewer signals:** none. No research on Tobias Wrenfield was possible, so no persona is adjusted for his public footprint.
- **The loop:** your words establish one 60-minute session with the Head of Live Operations. No loop source documents a values-style round, so no values round is detected and no archetype fallback is used.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the role: collide two events, diagnose a weak event, plan a release | High. The JD is all planning and running, and a hiring manager buys capability by watching you structure a problem | Clarify, then objective, constraints, options, decision rule, communication. Think aloud and challenge one premise |
| B. Skeptic | Quiet, persistent probing of the gaps | High. You have stated two gaps yourself, and a hiring manager derisks gaps | Rehearse B1 until it is boring. Bridge only from adjacent things you stated, say limits plainly, and give any ramp as a plan, never as a past |
| C. Data-Driven Prober | Reads your line by line and asks what is behind each | Medium. The JD names KPIs and retention, and your retention line invites it. Whether Tobias leans this way is unknown | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| D. Conversational | Friendly opener, casual questions that are still scored | Medium. Almost any 60-minute session opens this way | Pre-build the 90-second arc in D1. Treat casual questions on JD topics as scored |
| E. Pressure | Time-boxed challenges, attribution probes | Low-to-medium. Common at Head level, but nothing here points to this interviewer's style | Pause, restate, anchor in what you stated, hold through two follow-ups, then concede specifically |
| F. Peer Evaluator | Seam-splitting between teams, credit and disagreement | Low. No source says peers join, and it is included because the JD asks for coordination across four teams (F2) | Offer seam principles instead of pretending to know the seam, and frame what you bring them |

**Highest-ROI prep: B1**, "Which part of this JD would you be weakest at on day one?" It will arrive in some form, and your two stated gaps are where it lands. B2 and B3 are its follow-ups.

## Question banks

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two live titles both want a major event in the same fortnight, and engineering can only support one release. How do you decide, and who do you talk to first?" | CASE | [generic] | Clarify first: what each event is meant to move, what a delay costs, whether scope can be cut. State your decision rule aloud, name the risk it carries, and say how you would tell the team whose event moves. The question needs no claim about your past, so the guidance makes none | The JD's two-title calendar (F1) makes a collision the natural live problem. CASE because it scores the tradeoff, not a record |
| A2 | "Day three of an event, participation is well under plan. What do you look at first, and what do you do before it ends?" | CASE | [generic] | Ask what the plan was and how it was set. Check for a delivery fault before a design fault, then segment who is not participating. Decide whether to intervene or wait, and say what you would record for the review. No claim about your past | Tests the diagnose-then-act path behind F3 and F7. CASE because it is a live diagnosis |
| A3 | "It is 48 hours before an update ships and QA finds a blocker. Walk me through the next two days." | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Structure: severity, who decides, the options (fix, cut, delay), who is told and when, and what changes afterward. You may anchor in the checklist only as the quote states it: you wrote it and QA still uses it. If asked what is on it, answer from the checklist itself | F4 is the strongest evidence for the QA requirement, and a hiring manager tests it under pressure. CASE because it is a live decision, with the checklist as an anchor only |
| A4 | "You inherit the calendar for a live title on day one. In your first two weeks, what do you want to know before you change anything?" | CASE | [generic] | Name inputs and people, not conclusions: past event results and reviews, the KPIs in use, release lead times, team capacity. Name who you would talk to in design, art, engineering and community, and what you would deliberately not touch yet. No claim about your past | Covers the step up from one title (F1) and the coordination requirement (F2). CASE because it scores how you learn a new calendar |
| A5 | "Write me the three lines you would send design, art, engineering and community the morning an event goes live. What is in them?" | CASE | [generic] | Say what is live, what to watch, and who to call, in plain order. Offer to send a written sample after the interview if you have one that is yours to share. No claim about your past | The JD asks for clear written communication (F8) and coordination across four teams (F2). CASE because the writing is produced live |

### B. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | The highest-ROI rehearsal in the pack. Choose one weakness and say it in words your material carries: "I haven't worked on a game with in-app purchases" or "I haven't led a team." Then give the ramp as a plan in the future tense, what you would ask for in the first two weeks and from whom, never as something already done. Rehearse two follow-ups: how you would close it in the first month, and what you would do if it took longer. Hold your choice through both and concede the limit, not the role | F2 and the stated negatives are where a hiring manager derisks, so this objection arrives in some form. JD because it scores the stated requirements, gaps included |
| B2 | "You have not worked on a game with in-app purchases. What would you need to learn first to run events on a title that has them?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say, as a plan, the two things you would learn first and who you would learn them from, in your own words. Never describe monetization work as something you have done | The stated negative is the pack's clearest gap, and this is the premised form of B1. JD because it tests whether you can name your own ramp |
| B3 | "You have not led a team, and this role coordinates four disciplines on every update. How do you get work moving when nobody reports to you?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases", "I ran the weekly content-drop calendar for our main title for the last two years" | Open with the plain acknowledgment: "I haven't led a team." Answer slot: the JD asks you to coordinate design, art, engineering and community on each update. If you coordinated any of them on your weekly drops, say which and how, in your own words; if you did not, or it ran through someone else, say so plainly and stay with the calendar: "I ran the weekly content-drop calendar for our main title for the last two years." | F2 is the coordination requirement your material does not show. JD because the premise is the JD's coordination wording |
| B4 | "You ran the weekly content-drop calendar for one main title. What changes when you are planning events for two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Say what you ran, in those words. Answer slot: the JD says live events across two titles. If you ever planned events beyond content drops, or across more than one title, say how, in your own words; if you did not, say so plainly and say what you would set up first. The limit stays the pack's observation: your material says one title's weekly drops | F1 is the step up the JD names, and a hiring manager will test its edge. JD because it scores the stated requirement |
| B5 | "Why leave a puzzle-game studio, why live ops at Saltmarsh, and why now?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" | Your reasons are yours and the pack has none to give: say your actual reasons, one beat each for leaving, for live operations, and for now. Anything you say about Saltmarsh should come from your own reading of the JD, because no company research was available | The Skeptic's standing motivation probe, built on the one background fact in F5. EXP because it tests whether your story is consistent under cross-examination |

### C. Data-Driven Prober (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented to the studio head. What was in them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The beats the quote states: monthly, retention, presented to the studio head. Answer slot: the JD wants you comfortable with retention metrics. If you produced or analyzed any of those numbers, not only presented them, say which part and how, in your own words; if someone else produced them, or you only presented, say so plainly and stay with the presentation | F7 is the evidence for the retention requirement, and F3 for the review, so this is where the Prober starts. EXP because it tests what was actually yours |
| C2 | "Pick one retention number you presented. How was it counted, and which assumption behind it would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The weakest-assumption move, in your own words, before the interviewer reaches it. Say how that number was counted, what it is sensitive to, which assumption you would defend least, and which part was yours. "I don't know how it was counted" is an honest branch. The pack names no method and no figure | Rehearses the defend-the-number probe that F7 invites. EXP because it tests attribution precision |
| C3 | "After an event ends, what do you want the review to answer, and which numbers go on page one?" | CASE | [generic] | Question first: what the event was for, what moved against plan, what you learned, what changes next time. The numbers follow the objective, and you would agree the KPI set with the team before the event, not after. No claim about your past | The JD names a post-event review and its KPIs without listing them (F3). CASE because it asks for a structure |
| C4 | "The JD asks for three or more years producing live-service games or apps. How do your four years measure against that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years" | Say what you have: "4 years as an associate producer at a puzzle-game studio." Answer slot: say which of those years were on a live title and what made it live, in your own words; if you cannot count three, say so plainly and say what the years you can count were. Do not claim a count your material does not carry | F5 is a requirement the quote does not close, and a Prober reads the line to its edge. JD because it scores the stated requirement directly |

### D. Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head" | A 90-second arc in this order: four years as an associate producer at a puzzle-game studio; the last two running the weekly content-drop calendar for the main title; the release checklist QA still uses; the monthly retention numbers presented to the studio head. Close with why this role, in your own words. Tell each beat as the sentence states it | The opening is scored even when it feels casual. EXP because it tests whether the whole record holds together (F1, F3, F4, F5) |
| D2 | "What are you actually playing or following in mobile live service these days?" | JD | [generic] | Name your own: what you play or follow, and one thing a live event or update did well or badly in it, in your own words. If you do not follow mobile live-service titles closely, say so plainly and name what you have studied instead | Casual questions on the JD's field are scored for genuine interest. JD because it probes the live-service requirement (F5) |
| D3 | "You wrote a release checklist. What else do you write for the people around an update, and who reads it?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Start from the quote: you wrote the checklist and QA still uses it. Answer slot: if you also wrote updates, briefs or reviews, say what and for whom, in your own words; if the checklist is most of what you wrote for others, say so plainly | F8 is the thin row for written communication. JD because the JD lists it as a requirement |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Pause and restate. Hold the position the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Hold through two follow-ups by returning to the calendar, never by adding to it. Answer slot: if any part was someone else's, say which part, specifically; if none was, say so plainly | F6 is the claim an attribution probe tests hardest. EXP because it scores honesty under pressure |
| E2 | "Sixty seconds: why you over a candidate who has run live events on two titles and led a team?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses" | Pause and restate. Concede plainly: "I haven't led a team." Then offer only what the quotes carry: you ran the weekly content-drop calendar for the main title for the last two years, and you wrote the release checklist QA still uses. Do not disparage the other candidate, and do not add claims to close the gap | The comparison the Pressure persona makes to test composure around F2. JD because it scores fit against the stated requirements |

### F. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "If design wants to add an event the week engineering is stretched, where is the line between your call and theirs?" | CASE | [generic] | Offer seam principles, not a pretended map: who owns the calendar, who owns capacity, how a disagreement escalates. Add what you would bring each team in return. No claim about your past | The JD's four-team coordination (F2). CASE because it is a live seam problem |
| F2 | "How do you handle credit and blame when an update spans four teams?" | JD | [generic] | Selection criteria: pick a time work spanned teams and credit or blame had to be shared out. It needs a named stake, what you did, and an intact working relationship after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's coordination across four teams (F2). JD because it scores the stated requirement |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Live-events calendar for two titles (F1) | A1, A4, B4 |
| Coordinate design, art, engineering, community (F2) | A1, A4, A5, B3, F1, F2 |
| Post-event review and KPIs (F3) | A2, C1, C3 |
| Release checklist with QA (F4) | A3 |
| 3+ years live-service (F5) | B5, C4, D2 |
| Running a content calendar (F6) | B4, E1 |
| Retention metrics (F7) | A2, C1, C2 |
| Clear written communication (F8) | A5, D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which KPIs does the post-event review report on today, and which would you most want the new person to move?" | The JD names the KPIs without listing them, so this asks for the list and shows you want ownership of the number, not just the report |
| R2 | "How are the two titles' calendars planned today, and where does the planning most often get stuck?" | Shows you are thinking about the step from one title to two, and surfaces the problem you would inherit |
| R3 | "Of design, art, engineering and community, where does an update most often slip, and who has been the one to unblock it?" | Addresses the coordination requirement directly and gets you the real seam instead of a guessed one |
| R4 | "How do the titles' events connect to revenue, and which part of that would you want me to learn first?" | Turns your stated gap into a learning plan, in front of the person who will judge it |
| R5 | "What would make you say, ninety days in, that the hire was right?" | Gets the success criteria you would otherwise be guessing at, and lets you answer against them in the closing minutes |
| R6 | "What does the release checklist look like today, and where does QA wish it were different?" | Ties to the one requirement your material meets most directly (F4) and invites a conversation about it as a peer |

## Prohibited claims

What this pack will not coach, and why. The list was built before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated, "Never led a team, and never worked on a game with in-app purchases" | The plain acknowledgment: "I haven't led a team." Coordination is addressed only through B3's slot |
| Has worked on a game with in-app purchases | Negative you stated, same sentence | The plain acknowledgment: "I haven't worked on a game with in-app purchases." The ramp is a plan, never a past |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope: one main title's weekly content-drop calendar. The limit is the pack's observation, and B4's slot stays inside the calendar |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope: you presented the monthly retention numbers to the studio head. C1's slot asks only what sat behind the presentation |
| Managed the QA release process end to end | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist, and QA still uses it |
| Has three or more years of live-service experience | Inflated form of F5 | F5's quote at its own scope: four years as an associate producer at a puzzle-game studio. The limit is the pack's observation, and C4's slot asks which years were on a live title |

## Sources

Provided documents: the JD you pasted, and your message describing your background. No dossier was present.

Searches sent, all refused, none returned a result:

- `Saltmarsh Games values` — refused
- `Saltmarsh Games interview process live operations producer` — refused
- `Saltmarsh Games mobile studio news strategy` — refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations` — refused

No pages were fetched.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have moved a values cheat sheet and VAL questions. Neither is in this pack, and no values-style round is detected |
| 2. `{company} interview process {role family}` | unavailable | Would have moved the loop structure and persona weights. Your own words establish one 60-minute session, so the pack rests on that |
| 3. `{company} strategy` / recent news | unavailable | Would have moved a CO question grounded in current strategy. The pack has no CO questions |
| 4. `{interviewer name} {company}` | unavailable | Would have moved the interviewer read and persona adjustments. Both are absent, and R1 to R6 are role-generic |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV text → the evidence quotes become exact CV lines instead of lines from your message, and F4 and F6 can move toward `high` if you can point to the checklist or the calendar itself
- Your own answers to the slots, stated outside a drill, for F1, F2, F3, F5 and F8 → those rows regenerate on your words, and several `discovery` and `transferability` rows can close
- Whether Tobias is the person you would report to, and the recruiter's focus areas or any task to prepare → persona weights are recomputed, and a pre-declared deliverable gets its own build section
- Web search allowed for Saltmarsh Games and Tobias Wrenfield → published values (VAL questions and a cheat sheet), the documented loop, current strategy (CO questions), and an interviewer read with a reverse question tied to his path
- How many hours you have before Friday → a prioritized prep schedule sized to it
- A `tuesday-dossier.md` from an earlier session → verified evidence, and the gaps this prep exposed, carried across sessions
