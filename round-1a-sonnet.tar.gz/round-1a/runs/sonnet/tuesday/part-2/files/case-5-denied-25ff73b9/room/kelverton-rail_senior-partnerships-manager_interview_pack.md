# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, panel, 60 minutes. Per the recruiter's email as you quoted it: "The panel is Deepa (VP Partnerships, your future manager) and Ross (Commercial Director)." The first 15 minutes are your POV, with no slides. The rest is Q&A, and "Ross will push on commercials."

**Built on this assumption:** one session, two interviewers, no JD, and the market report not shared in this conversation. Research could not run, so nothing here rests on Kelverton's own sources. Every company-level row is labeled `[generic]`.

## 1. How to use this pack

Personas describe how a question arrives. Types describe what it is scoring. Guidance is scaffolding, not a script. Say only what you did, in your own words.

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment. No Kelverton values were available, so these themes come from the persona stems |
| EXP | Work-experience deep-dive: does the claim survive scrutiny, and what was actually you |
| JD | Role-driven: the stated job, including its gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem, thought through aloud |

An answer slot is an instruction for the interview, not a question for you now. It names what an interviewer is likely to probe. It has two honest branches, and the second allows that the practice never existed.

## 2. Prep triage (about 4 hours, in this order)

| Order | Time | Do this | Tied to |
|---|---|---|---|
| 1 | about 90 min | Pick one thesis, write its concession and the operator close, then speak the whole POV aloud against a clock. Do it twice | Section 3, A1, A4 |
| 2 | about 60 min | The highest-ROI rehearsal in this pack is C1: the rail and quota objection. Say it aloud until it is boring. Then C2, D1 and D3 | C1, C2, D1, D3 |
| 3 | about 50 min | The numbers. On a card, in your own words, write what you know about how the £4M and the 6-to-40 were counted. Where you do not know, write that. Then B4 for Ross's commercial push | B1 to B4, D2 |
| 4 | about 40 min | Reread the market report once for one consensus item and one place you diverge. Then the F1 arc and reverse questions R1 to R4 | Section 3, F1, F2, R1 to R4 |

Everything else (E and G banks, A2, A3, C3 and C4) is insurance. Skim it once.

## 3. Graded deliverable: the 15-minute POV

The recruiter's brief, quoted: "present a short POV on where you'd take our operator partnerships over the next 18 months" and "land on what it means for the operators themselves." This is graded. Build it as a deliverable, not as a Q&A answer.

### Grounded facts to build on

| Fact | Row | Quote, exactly as in the fit snapshot | Limit |
|---|---|---|---|
| Your channel work | F1 | "running the ISV channel" and "took it from 6 partners to 40" | A payments ISV channel. Your material does not say operator partnerships |
| Your transport background | F2 | "bus and light rail network planning" | Not train operating companies. "The other side" is yours to specify (C5) |
| Your stated limits | F4, F5 | "Never sold into rail specifically" and "never carried a direct quota, only influenced revenue" | These are plain acknowledgments in your own words. They are not for the POV's body, but you may say them in its first minute (see pacing) |

### Thesis options (pick one, with its concession built in)

| Thesis | One line you could say | Mandatory concession | Differentiation | Provenance |
|---|---|---|---|---|
| T1: fewer, deeper | Concentrate on a small number of operator partnerships and go deep over the 18 months, rather than widening | Slower headline partner count. Note that your own growth story is a count ("took it from 6 partners to 40"), so expect a probe on why depth here. Answer slot: say in your own words what you would do differently and why; if you would not, say so | Diverges from any reach-and-scale item on the report's shortlist. Check the report | `[generic]` |
| T2: start from the operator's outcome | Agree one operator-side outcome per partnership up front, and judge Kelverton's partner activity against it | Harder to commit early. Some outcomes sit outside a vendor's control, so commercial proof arrives later. Answer slot: name the operator-side outcome from the report or your own view; this pack does not supply one | Diverges from any item on the report that is framed around Kelverton's own growth | `[generic]` |
| T3: sequence around operator decision points | Order the 18 months by when operators can actually say yes | Ties your plan to calendars you do not control, with a risk of idle stretches. Answer slot: name the decision points only if you can source them; this pack did not research them | Diverges from a plan sequenced around Kelverton's own release or sales calendar | `[generic]` |

### Differentiate from the report, never recite it

Both interviewers can read the report, and its authors work there. Bring one consensus item to prove you read it, then one thesis-driven divergence with reasons. Where the role's real job includes saying no, add the anti-pick: one partnership type or request you would decline in the 18 months. Choose the three from the report text yourself. This pack has not seen it.

### The requested close: what it means for the operators

Give the last 3 minutes to this. Describe what an operator sees differently at month 6, month 12 and month 18, in the operator's words rather than Kelverton's. The specifics are yours. Do not claim insider knowledge of how operators run or decide; the F2 limit applies.

### Suggested pacing (coaching judgment, not a fact about this panel)

| Minutes | Segment |
|---|---|
| 1 | Frame, and say the limit yourself: "I haven't sold into rail specifically." Then what you bring, at its quoted scope |
| 2 | Your thesis in one sentence, and why |
| 5 | Three moves across the 18 months, each with its concession |
| 3 | What it means for the operators (the requested close) |
| 1 | The anti-pick and what you would drop if you could fund only one move (A1) |
| 3 | Buffer. Land at 12 minutes, not 15 |

`[generic]` provenance throughout this section except the quoted facts, which are `[grounded]` in your message.

## 4. Fit snapshot

Requirements come from the recruiter's quoted words, or are role-family expectations written as plain prose with no source supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — the recruiter's email, quoted in your message | "running the ISV channel" — your message; "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material says an ISV channel, not operator partnerships, and the words stay at that scope: "I ran the ISV channel and took it from 6 partners to 40." Answer slot: the brief's "operator partnerships" makes a probe on how the channel carries over likely. If any part of how you grew it applies to operators, say which and why, in your own words; if none does, or it was not yours, say so plainly and stay with the channel |
| F2 | "land on what it means for the operators themselves" — the recruiter's email, quoted in your message | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, which is not train operating companies, and it does not say which side of the table "the other side" was. Words: "I spent 5 years in transport consulting, on bus and light rail network planning." Answer slot: if the work showed you how operators run or decide, say what it showed you; if it did not reach that, say so plainly and stay with the planning work |
| F3 | "Ross will push on commercials" — the recruiter's email, quoted in your message | "roughly £4M of influenced revenue" — your message; "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | discovery | A figure with nothing inspected behind it, which is not the same as commercial terms. Answer slot: the push makes probes on how the £4M was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours likely. Answer each in your own words. If you do not know how it was counted, say so plainly |
| F4 | Experience selling or partnering into rail operators — role-family expectation, no source supplied, `[generic]` | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | Carrying a commercial target — role-family expectation, no source supplied, `[generic]` | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | Also a stated gap. Words: "I've never carried a direct quota; what I've had is influenced revenue." No slot, and no claim to a target |

## 5. Persona table

The loop source is the recruiter's email: one session, two interviewers, a 15-minute POV and then Q&A, with no values round named. Weights follow the panel rule (the top two personas of each member's relationship). Ross's relationship to you is not stated, so his row follows the recruiter's words instead.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Deepa probes the rail gap and the quota gap | High. Future manager (hiring-manager prior), and F4 and F5 are stated gaps. Gets the deepest rehearsal (C1) | Say the limit first, in the words F4 and F5 give. Give the adjacent evidence at its own scope. Offer a plan, not a past |
| Case / Strategist | Deepa pushes on the POV: sequencing, trade-offs, what you would drop | High. The POV is itself case-shaped, and she is the hiring-manager prior | Clarify, then objective, approach, metrics, risks. Challenge one premise respectfully. Think aloud |
| Data-Driven Prober | Ross takes the £4M and the 6-to-40 apart | High. "Ross will push on commercials" and both headline figures are influence or count figures | Know what you can and cannot say about how each figure was counted. Say plainly when you do not know. Name your weakest assumption first |
| Pressure | Ross interrupts and time-boxes: why you, how much was you, what about a quota | Medium. A push on commercials often arrives as pressure, but his relationship to you is unknown | Pause, restate, hold the quoted scope through two follow-ups, then concede the specific limit |
| Peer Evaluator | Where partnerships and commercial split, and what you need from each other | Medium, and uncertain. It applies only if Ross sits alongside partnerships rather than above it | Offer seam principles, not a claim to know the seam. Reciprocity: what you give his team |
| Conversational | The opening journey question; casual questions about the report | Low. Short and early in the hour, but still scored | A 90-second arc built from quoted sentences (F1) |
| Values / Behavioral | An unpopular truth, or a partner ahead of a metric | Low. No values-style round is named in the recruiter's email, and no published values were available | Selection scaffolds with the honest branch |

## 6. Question banks

Questions are IDed by persona. Provenance carries every candidate sentence the guidance rests on. The highest-ROI prep in the pack is C1.

### A. Case / Strategist (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "If you could fund only one of the moves in your POV, which one, and what do you drop?" | CASE | [generic] | Decide your ranking before Tuesday and give the reason in operator terms and in Kelverton's terms. State what you would drop and its cost. This makes no claim about your past | The most natural follow-up to any POV. CASE because it asks for reasoning, not history |
| A2 | "What is the biggest threat to our operator partnerships over the next 18 months?" | CO | [generic] | Choose one threat you can argue. Say where it comes from: your own judgment, or something you have actually read. Do not assert market facts you have not checked. This row becomes grounded only with research or the report | Company-altitude question. Generic because research could not run |
| A3 | "You could go deep with four of ten operators. How do you choose?" | CASE | [generic] | Clarify what deep means and what you are optimizing for. Then name the selection criteria in operator terms and in Kelverton's terms, how you would test them, and the risk. Challenge the ten-and-four premise once | A live problem set in the role. It tests structure, and may press T1 against a growth story built on partner count |
| A4 | "At month 18, what does success look like for an operator, in the operator's words rather than ours?" | JD | [generic] | This is your POV close, said as a Q&A answer. Describe what changes for an operator. Let the interviewer draw the conclusion. It makes no claim about your past | The recruiter asked you to land on this, so it is likely to recur. JD, because it scores the stated brief (F2) |

### B. Data-Driven Prober (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Say the figure as you gave it: roughly £4M of influenced revenue. Answer slots, in your own words: how it was counted, and what it is sensitive to. If you do not know how it was counted, say so plainly | F3 holds the figure. Quantified claims are magnet targets, and the slots here are the only four a figure raises |
| B2 | "Six partners to forty. Walk me through that growth." | EXP | [grounded] "took it from 6 partners to 40" | Say it as you gave it. Answer slots, in your own words: what counted as a partner, what the count is sensitive to, which part of the growth was yours. If you do not know how partners were counted, say so plainly | F1 holds the count. The question presupposes only the quoted sentence |
| B3 | "Which assumption behind that £4M would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" | Name, in your own words, the assumption you would defend least, before they find it. If you know of none, say so plainly. This pack does not name one for you | The weakest-assumption move converts a gotcha into a credibility gain. F3 |
| B4 | "Pick one operator partnership. What commercial measures would you track in the first year, and why?" | JD | [generic] | Structure it: what each side gets, the measures on each side, how you would know early whether it is working, and the risks. Name at least one measure that is the operator's, not Kelverton's. It makes no claim about your past | Ross's commercial push (F3) as a live problem. CASE delivery |

### C. Skeptic (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've not sold into rail and you've not carried a quota. Why should we believe you can do this job?" | JD | [grounded] "Never sold into rail specifically" "never carried a direct quota, only influenced revenue" "running the ISV channel" "took it from 6 partners to 40" | The highest-ROI rehearsal in this pack. **Beat 1, the limit first, in your words:** "I've never sold into rail specifically, and I've never carried a direct quota." **Beat 2, what you have, at its own scope:** "I ran the ISV channel and took it from 6 partners to 40, with roughly £4M of influenced revenue." Describe it and let them draw the inference. **Follow-up 1** ("why does a payments channel carry over?"): answer slot. If any part of how you grew it applies to operators, say which and why; if none does, or it was not yours, say so plainly and return to the channel. **Follow-up 2** ("how much of that was you?"): answer slot, which part was yours, in your own words. **Follow-up 3** ("what will you not know in month three?"): say, as a plan and not a past, the two things you would learn first and from whom; if none comes to mind, say so plainly. **Exact concession wording:** "That is a real gap, and I'm not going to dress it up." Hold the quoted scope through two follow-ups by returning to the channel, never by adding to it. Say the limit yourself in the POV's first minute, so it is not extracted | This question will be asked in some form. F4, F5 and F1 are where the material is thinnest. A rehearsed, non-defensive answer changes the interview |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" "never carried a direct quota, only influenced revenue" | Pick the limit you believe most from your own two, and name it plainly. Then say, as a plan and not a past, how you would close it. If neither is the real answer, say what is, truthfully | Stem question for the Skeptic. F4 and F5 |
| C3 | "Why leave payments, and why rail, and why now?" | EXP | [grounded] "5 years in transport consulting" | Your real reasons, which this pack does not hold. Criteria: true, specific, forward-looking, tied to what this role asks. You may mention the transport consulting as you stated it. If no clear reason comes to mind, say so plainly, then give the nearest true thing | The standard motivation probe, and the one an incoherent answer breaks. F2 |
| C4 | "What would your first 90 days look like?" | CASE | [generic] | Structure it: what you would learn, who you would meet, what one early commitment would be, and what you would not do yet. It makes no claim about your past | The same objection as C1 in plan form |
| C5 | "You say you know the operator world from the other side. Which side was that?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Answer slot: say which side of the table you sat on, in your own words. If the work never put you across from train operating companies, say so plainly and stay with bus and light rail network planning | The phrase "the other side" is yours and the material does not specify it. This is the likeliest follow-up to it (F2) |

### D. Pressure (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically" "running the ISV channel" "took it from 6 partners to 40" | Pause and restate. Hold what the quotes carry: "I ran the ISV channel and took it from 6 partners to 40." Hold through two follow-ups. Then concede the specific limit, "I've never sold into rail specifically," without claiming to be the better candidate | A time-box on C1. The stem is a Pressure staple. F4 and F1 |
| D2 | "That result. How much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40" "roughly £4M of influenced revenue" | Hold the scope the quote gives. The figure's own word is "influenced." Answer slot: which part was yours, in your own words. If you do not know how it was counted, say so plainly. Concede that specific uncertainty and nothing wider | Attribution probe, the one the quote's own word invites. F1 and F3 |
| D3 | "You've never carried a direct quota. What makes you think you can carry a number here?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Pause. The plain acknowledgment: "I've never carried a direct quota; what I've had is influenced revenue." Answer slot: if any commercial commitment was yours, say what it was, in your own words; if none was, say so plainly and return to the influenced-revenue figure | Ross's push on commercials (F3 and F5), in Pressure delivery |

### E. Peer Evaluator (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Partnerships and commercial sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Offer two or three seam principles and say plainly that you do not yet know how the seam runs here. Then selection scaffold for disagreement: pick a time you disagreed with an equal and kept the relationship; it needs a named stake and an outcome you can state. If none comes to mind, say so plainly and give how you would handle it | Applies if Ross is a peer. Flagged as uncertain in the persona table |
| E2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time credit for a result was shared across teams; it needs a named stake and what you did. If no such time comes to mind, say so plainly and give the nearest thing your material carries, or how you would handle it | The persona stem. Influence-based work makes it natural for this candidate |
| E3 | "What would you need from commercial to make operator partnerships work?" | JD | [generic] | Reciprocity first: what you bring his team, then what you would need. Principles, not claims about how this company works | The reciprocity move a peer scores |

### F. Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting" "bus and light rail network planning" "9 years in partnerships" "last 4 at a payments company running the ISV channel" | A 90-second arc. Beats are the quoted sentences, in your own words: the transport consulting, the partnerships, then the last four years running the ISV channel. Do not state a combined total of years. Final beat, answer slot: why this role now, in your own words. If there is no clear link, say so plainly | The openers are scored too. F1 and F2 |
| F2 | "What stood out for you in the market report?" | CO | [grounded] "which I've read" | Choose one item you can discuss and one place you diverge, with reasons. Do not recite the report; its authors work there. This pack has not seen it, so it supplies neither item | Casual questions about hot topics are scored. The report is equally available to rival candidates |

### G. Values / Behavioral (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to a partner or to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Persona-stem theme. There is no published-values source |
| G2 | "When did you put a partner's interest ahead of an internal metric?" | VAL | [generic] | Same scaffold: a named stake, a choice you made, and what it cost. If no such time comes to mind, say so plainly and give how you would decide | This ties to the brief's focus on operators. Persona-stem theme |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1: the POV | A1, A3, A4, B2, C4, D1, F1 |
| F2: what it means for the operators | A4, C5, E3 |
| F3: Ross's commercial push | B1, B3, B4, D2, D3 |
| F4: selling into rail | C1, C2, C3, D1 |
| F5: carrying a target | C1, C2, D3 |

## 7. Reverse questions

No interviewer profile was available, so these are role-generic.

| # | Question | Why it lands |
|---|---|---|
| R1 | To Deepa: "What would a strong first six months in this role change for the operators themselves?" | It returns the conversation to the brief's own close and shows you listened |
| R2 | To Deepa: "Where do operators' requests and what Kelverton can build pull apart, and who decides?" | It is diligence you need before accepting, and it signals the partnership seam |
| R3 | To Ross: "How are operator partnership commercials structured today, and what would you change?" | It meets his push head on and gives you real information about the terms |
| R4 | To both: "Does this role carry a revenue target, and how is it set?" | It surfaces F5 on your terms, and you need the answer to decide |
| R5 | To both: "Where did discussion inside the team differ from the strategy report?" | It shows you read the report and asks for what it left out |
| R6 | To Ross, reciprocity: "What could partnerships do in my first month that would help your team most?" | Peers score reciprocity, and it frames the seam as shared |

## 8. Prohibited claims

Built before the banks. These are what this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F4 | The plain acknowledgment F4 gives: "I've never sold into rail specifically." No slot |
| Has carried a direct quota or revenue target | Negative you stated, F5 | "I've never carried a direct quota; what I've had is influenced revenue." No slot |
| Generated, closed or owned £4M | Inflated form of F3 | The quote at its own scope. The limit is this pack's observation: your material says influenced revenue, not closed. The slots in B1, B3 and D2 stay inside the figure's four |
| Built the channel | Inflated form of F1 | "Running the ISV channel," at its own scope. Your material says running, not building |
| Knows how train operating companies run or decide | Inflated form of F2 | "Bus and light rail network planning" at its own scope. Your material does not say train operating companies or which side of the table. C5's slot asks only which side |

## 9. Sources

Provided documents: your message, including the recruiter's email as you quoted it. The market report was named but its contents were not shared in this conversation, so nothing here draws on it, and every CO and CASE row is `[generic]`. No dossier was present.

Searches sent, all refused:

| Query | Outcome |
|---|---|
| Kelverton Rail values | refused |
| Kelverton Rail interview process partnerships | refused |
| Kelverton Rail strategy scheduling software train operating companies | refused |
| Deepa VP Partnerships Kelverton Rail | refused |
| Ross Commercial Director Kelverton Rail | refused |
| Senior Partnerships Manager rail technology operator partnerships job description | refused |

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have moved the VAL themes in G1 and G2, and a values cheat sheet if a source documented a values round |
| 2. Kelverton Rail interview process, partnerships role family | unavailable | Would have moved persona weights if a source documented how this panel runs. The recruiter's email already fixes this session's structure |
| 3. Kelverton Rail strategy, recent news | unavailable | Would have moved A2, the CO and CASE rows, and a grounding brief |
| 4. Deepa and Ross at Kelverton Rail | unavailable | Would have moved the interviewer read and a reverse question tied to their paths. Two calls, both refused |
| 5. Representative Senior Partnerships Manager JD | unavailable | Would have moved the fit snapshot's requirement rows and the JD-tagged questions |

## 10. Upgrade menu

- The market report, or just its recommendations and executive summary → the CO and CASE rows become grounded, and section 3's consensus-versus-divergence step is built on what the report actually says. This is the largest upgrade available
- The JD, if there is one → the fit snapshot's requirement cells become quoted, the two role-family rows F4 and F5 are replaced by the posting's real requirements, and JD-tagged questions become grounded
- Search permission → the five research targets above (values, loop, strategy, both interviewers' public footprint, a representative JD); a further deep pass, up to 6 more searches and 2 more fetches and several more minutes, is available after that
- The interviewers' full names → an interviewer read, tuned persona weights, and a reverse question tied to their own paths
- A partner-influenced revenue report or a partner programme document behind the £4M and the 6-to-40 → F1 and F3 move from medium toward high, and the B bank sharpens
- Your answers to the slots (which side of the table for F2, how the £4M was counted, which part was yours) → F1, F2 and F3 regenerate from your own quoted words
- A `tuesday-dossier.md` from an earlier assessment of this role → verified evidence graded by that review, plus strategy constraints for each weak area
