# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop on 26 November 2026, three rounds (prepared 17 November 2026).

| Round | Who | Length | Format, as the recruiter's email gives it |
|---|---|---|---|
| 1 (IDs A) | The recruiter | 30 minutes | Screen |
| 2 (IDs B) | The Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 (IDs C) | Panel of two branch managers | 60 minutes | 20-minute case on a complaint escalation, then values; the panel scores against the four values |

No interviewer has been named, so there is no interviewer read. This is loop mode: one shared fit snapshot, then a mini-pack per round.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether your own account of your work holds up, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's strategy and can think at its altitude |
| CASE | A live problem, scored on structure and reasoning |

- Guidance is scaffolding, not a script. Say it in your own words.
- Every table of proposed wording in this pack is pending your approval. Rehearse only what is true for you.
- An answer slot is an instruction for the interview, not a question for me. You do not need to reply to it here. If you want a row upgraded, give me the answer and I will regenerate it (see the upgrade menu).
- The highest-ROI rehearsal in the pack is B6, the contact-centre objection. Rounds 1 and 3 ask it in other forms (A8, C10), so one rehearsed answer serves three rounds.

## Prep triage

You gave a date, not hours, so this is an order, not a schedule. Nine days remain.

1. B6, A8 and C10: the same objection in three registers. Say each aloud until it is boring.
2. The answer slots under F1, F3, F4, F5 and F6. Answer each for yourself first. Then send me the answers and I will upgrade the rows.
3. C5 and C6, the case shape: practise the structure aloud twice. The real case will differ.
4. C1 to C4: for each value, pick one real story or accept the scaffold's honest branch.
5. A4 to A7: write your own answers to pay, notice, location and reason for leaving.

Everything else is insurance.

## Fit snapshot

Proposed wording below is pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD (branch side) | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the stages beyond the log likely. If any stage was yours, say which and how, in your own words; if there was no such stage, or it was not yours, say so plainly and stay with the log |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD (contact-centre side) | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote shows a monthly complaints spreadsheet your regional manager uses. It does not show whether it tracked volumes or resolution times. Answer slot: the JD names both, so expect "did it track both?" If it tracked either, say which and how it was counted, in your own words; if it tracked neither, say so plainly and stay with what it did track |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | "Formal" is your word and "regulated" is the JD's. The quote does not show whether the log fell under a regulator's rules. Answer slot: if you know which rules governed it, say so in your own words; if you do not know, or it was not governed that way, say so plainly and stay with the log |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | The quote is tellers and a script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: if any of your coaching was with supervisors, say who and how, in your own words; if it was not, say so plainly and stay with the tellers |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing here, so a probe is likely. Answer slot: if you have worked with a digital team on anything members use, say what and which part was yours; if you have not, say so plainly and say what you would ask them first |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Say it in the quote's own terms: "Six years in retail banking, the last three as a branch supervisor." The pack does not relabel it as customer operations; the interviewer can decide that |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap you stated. Words: "I've never presented to anyone above regional level." Then a plan for the first presentation, said as a plan. Nothing that implies senior-level presenting |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Derived from the spreadsheet quote: it says spreadsheet, not Excel, and not what it reported. Answer slot: if it was built in Excel, say so and what it did, in your own words; if it was another tool, or a simple one, say so plainly and say what you would show instead |

No requirement in the JD is a gate: no authorisation, licence, location, schedule or pay term is stated, and the four-years line is experience, not a credential. Pay, notice and location are rehearsed as logistics rows in round 1 (A4 to A6).

## Grounding brief

The July 2026 strategy brief reached me only as your one-sentence summary of it, so this table holds what that sentence says and nothing more.

| Item | The brief, as you relayed it | Link to this role | Provenance of the link |
|---|---|---|---|
| Digital shift | 40% of member service to digital channels by 2028 | The JD's self-service journeys duty (F6) is where this lands for you; expect questions on complaints by channel | [inferred] |
| Branch consolidation | Eight branches into five hubs over 2027 | The value Neighbours, Not Numbers sits next to this plan, and the round 3 panel are branch managers; whether their own branches are affected is not in your material | [inferred] |
| New product | Small-business lending product in Q1 2027 | A new product is a new source of member contact; the brief as relayed says nothing about complaints on it | [inferred] |
| Competition | Main competitive pressure is app-only banks | The frame for any case about a member threatening to leave (C5) | [inferred] |

Ashgrove is member-owned with about 900 staff (the JD's own line).

# Round 1 mini-pack: the recruiter (A)

## Persona table, round 1

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured; logistics asked casually | High. The relationship prior for a recruiter screen. The recruiter's email says 30 minutes, with no stated focus beyond that | A 90-second arc from your own quotes; treat casual questions as scored |
| Skeptic (light) | Knockout-style checks on the JD's gaps | Medium. Same prior; F2 and F4 are the rows a screen would check | Rehearse the contact-centre acknowledgment until it is boring |

## Bank A: Conversational (with logistics)

Proposed wording below is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc using only the beats the quotes state: six years in retail banking, the last three as a branch supervisor; handled the branch's formal complaints log; trained new tellers on the escalation script; built the monthly complaints spreadsheet your regional manager uses. Tell each in your own words, "I" for what you did. Your reason for wanting this role next is an answer slot: give your actual reason, in your own words. End on the role, not on a recap | F7, F1, F5 and F3 hold these beats. EXP because it tests the story behind the CV; the casual register is still scored |
| A2 | "What attracted you to the Member Experience Lead role?" | JD | [grounded] "I handled the branch's formal complaints log" | Pick one duty from the JD and say it in the JD's own words, then why it draws you, in your own words. The reason is yours to give. Connect it only to what the quote carries: the branch's formal complaints log | Motivation consistency check. F1 is the only evidence this row can touch. JD because it scores the stated duties |
| A3 | "What do you know about Ashgrove and where it's heading?" | CO | [inferred] Derived from the strategy items in the grounding brief and the JD's duties | Bring one consensus item to show you did the homework: the 40% digital target by 2028, or eight branches into five hubs over 2027. Then one divergence, put as a question, not a claim: how a complaint is handled when a member moves between channels or sites. Say "as I read the July brief". Do not recite all four items | Any prepared candidate has the brief, so recitation scores as homework and a reasoned question scores as judgement. CO because it tests strategy fluency |
| A4 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give your own figure, or ask for the role's band first and give yours after. The posting you shared states no pay, so the choice is yours. Never state a figure you would not accept | Recruiter screens carry the logistics check. JD because it concerns the listed job's terms |
| A5 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, as your contract states it, in your own words | As A4 |
| A6 | "Where would you work from, and how often could you be in a branch or hub?" | JD | [generic] | Logistics slot: give where and how often you can work, in your own terms, or ask where the role is based before you answer. The posting you shared states no location or pattern | As A4. The brief's move to hubs is a reason to ask where the role sits |
| A7 | "Why are you looking to move on from your current or last role?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words. If there is more than one, lead with the one you would stand behind, and keep it about what you want next | The reason for leaving is a standard recruiter-screen item. EXP because it tests the consistency of your own story |

## Bank A: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A8 | "This role runs complaints across branches and the contact centre. Where does your experience sit against that?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre" | Two beats, in this order. What you handled: "I handled the branch's formal complaints log." Then plainly: "I have never worked in a contact centre." Then a ramp plan, said as a plan: what you would learn first and from whom. Answer slot: the JD says end to end, so if any stage beyond the log was yours, say which; if there was no such stage, or it was not yours, say so plainly and stay with the log | F1 and F2, in the form a screen asks them. JD because it is the first duty in the posting |
| A9 | "The role handles regulated complaints. What's your experience there?" | JD | [grounded] "I handled the branch's formal complaints log" | Start at the quote's scope: "I handled the branch's formal complaints log." Answer slot: the JD says regulated, so expect "what rules did it fall under?" If you know which rules governed it, say so in your own words; if you do not know, or it was not governed that way, say so plainly and stay with the log. Do not turn "formal" into "regulated" yourself | F4 is the only evidence for this requirement. The pack cannot tell from your material whether formal meant regulated, so the answer is yours to give |

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| RA1 | "Is the 20-minute case given in advance or live, and in what format?" | It gets the one fact about round 3 that is not in the email, and it signals you are preparing for the case |
| RA2 | "Is there anything the Head of Member Services or the panel will want from me in advance?" | It checks for any announced deliverable before it surprises you |
| RA3 | "Where is the role based, and how does that sit with the plan to move from eight branches to five hubs?" | It gets a fact you need before accepting, and ties to the brief |
| RA4 | "Which teams does the role work with day to day: branches, the contact centre, digital?" | It maps the JD's three audiences onto real people |
| RA5 | "What is the part of the complaints process you most want this hire to fix?" | It invites the recruiter to name a problem and echoes the value Own the Fix |

# Round 2 mini-pack: Head of Member Services, your future manager (B)

## Persona table, round 2

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes: a time you did X | High. The recruiter calls the round mostly behavioural | Quote-based stories where a sentence carries one; the honest branch where none does; "we" for context, "I" for contribution |
| Skeptic | Quiet probing of the gaps | High. Hiring-manager prior, and F2, F8 and F6 are the biggest gaps | Rehearse the single most predictable objection (B6) until it is boring |
| Data-Driven Prober | Asks what the spreadsheet tracked and how | Medium. The JD's monthly reporting duty and F3, your one built artefact | Say what it tracked in your own words, or plainly that it did not |
| Conversational | A friendly opener | Medium-low. A manager round usually opens with a biography question | Reuse the A1 arc |
| Case/Strategist | Live problems from the real roadmap | Low-medium. The hiring-manager prior favours it, but the email calls the round behavioural and the dedicated case is in round 3 | Clarify, then structure, then answer |

## Bank B: Values/Behavioral

Proposed wording below is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you helped a colleague handle an escalation better." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F5: new tellers, the escalation script, trained. Those are the beats the quote states, so tell them in your own words. Answer slot: the JD says coach branch supervisors, so expect "and supervisors?" If any coaching was with supervisors, say who and how; if it was not, say so plainly and stay with the tellers. Do not describe the script as something you wrote | F5 is the evidence for the coaching duty. JD because it scores that duty |
| B2 | "Tell me about a time you delivered an unpopular truth to a senior person." | VAL | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold: pick a time with a named stake, what you said and to whom, how it landed, and a relationship that was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the spreadsheet your regional manager uses, at its own scope, or how you would handle it. Do not supply an ending the material does not show | Persona stem for a behavioural manager. The nearest sentence rests on F3. VAL because it scores behaviour, not capability |
| B3 | "Tell me about a time a member's complaint changed how your branch did something." | VAL | [inferred] "I handled the branch's formal complaints log" | Selection scaffold: the complaint, what changed, who agreed to it, which part was yours. If none comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would handle it | The theme comes from the JD's ownership of the complaints process and from the value Own the Fix. The nearest sentence rests on F1 |
| B4 | "Tell me about a time you worked with a team outside your own on something members used." | JD | [generic] | Selection scaffold: the team, what members used, your part, and what the other team would say about working with you. F6 holds no quote, so this is an answer slot: if you have, say who and what; if you have not, say so plainly and say what you would ask a digital team first | The JD's digital-teams duty is the raising source. F6 has no evidence, so this is where a probe lands |

## Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Name one, plainly, at the quotes' scope. The contact centre is the stronger candidate because it sits in the first duty: "I have never worked in a contact centre." Presenting above regional level is the second: "I've never presented to anyone above regional level." Then how you would close it, as a plan. Do not call either minor | F2 and F8, the two gaps you stated. JD because it scores honest self-assessment against the listed duties |
| B6 | "You've never worked in a contact centre. How would you own complaints that start there?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | The highest-ROI rehearsal in this pack. Say the limit before it is asked: "I have never worked in a contact centre. I handled the branch's formal complaints log." Then a plan in the future tense, three parts in your own words: what you would learn first, from whom, and who keeps hold of a complaint when it moves between branch and contact centre, put as a question you would ask. Follow-up 1, "what would you do in your first 30 days?": restate the plan as a plan; for what a contact centre does, say "I would ask." Follow-up 2, "isn't that a big gap for an end-to-end owner?": concede specifically: "The contact-centre half is the part I would be learning." Follow-up 3, "who would you lean on?": "I would ask you." Never claim exposure the quotes do not carry | F2 is aimed at exactly where the material is thin, and F1 is the only sentence beside it. JD because it scores a listed duty |
| B7 | "You'd report to senior leaders each month. Have you presented at that level?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Plainly: "I've never presented to anyone above regional level." Then what is true: "I built the monthly complaints spreadsheet our regional manager uses." Then a plan for the first presentation: lead with the answer, then what drives it, then what you want decided; ask the Head of Member Services what the forum expects. No slot: you have stated the absence | F8 is a stated capability gap. The pack gives the plan and never a past |

## Bank B: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B8 | "Walk me through the monthly complaints spreadsheet you built. What did it track?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what it is: the monthly complaints spreadsheet your regional manager uses, which you built. Answer slot: the JD names volumes and resolution times, so expect "did it track both?" If it tracked either, say which and how it was counted; if it tracked neither, say so plainly and stay with what it did track. If you are asked how a figure in it was counted, say how, or say plainly that you do not know | F3 is the one thing you built, and the JD's reporting duty makes it the prober's first target. EXP because it tests what was yours |
| B9 | "How comfortable are you in Excel? What's the most advanced thing you've built?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | The quote says spreadsheet, not Excel and not its features. Answer slot: if it was built in Excel, say so and what it did, in your own words; if it was another tool, or a simple one, say so plainly and say what you would show instead. Offer to walk through how you built it. Name no feature you did not use | F9 is graded low because the tool is unknown. JD because Excel reporting is a listed requirement |

## Bank B: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B10 | "Walk me through how the branch's formal complaints log worked, from a member complaining to the entry being closed." | EXP | [grounded] "I handled the branch's formal complaints log" | Premised on the quote only. Say what you handled: the branch's formal complaints log. Answer slot: if the log had steps you set or followed, say which, in your own words; if there was no such step, or it was not yours, say so plainly and describe how you handled it. If any rules governed it, say which; if you do not know, say so | F1 and F4 in friendly packaging. EXP because it checks what you actually did |

## Bank B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B11 | "The strategy is 40% of member service on digital channels by 2028. What does that do to complaints, and what would you want in place?" | CO | [inferred] Derived from the brief's 40% target and the JD's self-service duty | Clarify first: what counts as member service, and whether complaints sit inside the 40%. Then objective, segmentation by channel, approach, metrics (volumes and resolution times are the JD's own), risks. Challenge one premise respectfully: whether a complaint should be self-service at all, or whether the journeys should be built so fewer become complaints. Say what you do not know. It asks about no past, and the guidance claims none | A CO question grounded in the brief. CO because it tests strategy fluency, with a case delivery |

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| RB1 | "Today, who keeps hold of a complaint when it moves between a branch and the contact centre?" | It echoes the value Own the Fix and gets the fact behind F1 and F2 |
| RB2 | "What does complaints reporting look like today, and who reads it?" | It tests the reporting duty without presupposing a report exists |
| RB3 | "Which self-service journeys come first under the 40%-by-2028 target?" | It ties to the brief and to the JD's digital-teams duty |
| RB4 | "Given I have not worked in a contact centre, what would you want to see from me in the first 90 days?" | It says the gap yourself, and turns the objection into a joint plan |
| RB5 | "Which forum would I present to first, and what does it expect?" | It answers the F8 gap with a practical question |

# Round 3 mini-pack: panel of two branch managers (C)

## Persona table, round 3

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | A scored values conversation | High. The recruiter says the panel scores against the four values | One story or one honest scaffold per value; hard truths that actually landed |
| Case/Strategist | The 20-minute escalation case | High. 20 of the 60 minutes | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Peer Evaluator | Seam questions: where is the line between your job and ours | Medium. The JD has you coaching branch supervisors, and branch managers sit next to that | Reciprocity framing; propose seam principles, not a pretended seam |
| Pressure | A time-boxed challenge to the gap | Low-medium. Not the panel's natural style, but B6's objection reaches any round | Pause, restate, hold what the quotes carry, concede specifically |

## Bank C: Values/Behavioral

Proposed wording below is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Value: Members First, Always. No quoted sentence carries this, so selection criteria: a decision where what the member needed and what a process or number wanted pointed different ways; what you decided, what it cost, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The published value is the raising source. VAL because it scores behaviour against that value |
| C2 | "Tell me about a time something you wrote or explained had to be explained twice." | VAL | [inferred] "trained new tellers on our escalation script" | Value: Plain Words. Selection scaffold: what it was, what the member or colleague did not follow, what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you trained new tellers on the escalation script, which says trained, not wrote. Do not claim you wrote the script | The nearest sentence rests on F5. VAL because it scores behaviour against that value |
| C3 | "Tell me about a time you weighed what a decision meant for one town or branch against a number." | VAL | [inferred] "6 years in retail banking, the last 3 as a branch supervisor" | Value: Neighbours, Not Numbers. Selection scaffold: the decision, the number, the town or branch, what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, a branch role of three years, which states no story, or how you would handle it | The nearest sentence rests on F7. The brief's branch-to-hub plan makes this value live for a branch-manager panel |
| C4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [inferred] "I handled the branch's formal complaints log" | Value: Own the Fix. Selection scaffold: the problem, how you found it, what kept you holding it, how you knew it was solved. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I handled the branch's formal complaints log", which says handled, not solved, or how you would handle it | The nearest sentence rests on F1. This value is also the structure of C5's answer |

## Bank C: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "A member comes into a branch angry. The contact centre told them one thing last week, the branch told them another today, and they say they are moving to an app-only bank. You have 20 minutes: what do you do for this member, and what do you change?" | CASE | [inferred] Derived from the published values, the JD's duties and the brief's competitive frame | Practice case; the real one will differ, so use the shape. Clarify: what was said by whom, what the member wants, and what rules apply; ask the panel rather than assume. Objective: solve the member's problem, and name who keeps hold of it now (Own the Fix). Segmentation: this member now, this complaint's cause, the pattern across branches and the contact centre. Approach: the first reply in plain words (Plain Words); who owns it as it moves. Metrics: the JD's volumes and resolution times, plus repeats. Risks: what you do not know. Challenge one premise: is the problem one complaint, or two answers? Think aloud. The guidance claims nothing about your past | The email says 20 of the 60 minutes are a complaint-escalation case. CASE because it scores structure, and it uses the company's own vocabulary |
| C6 | "A branch supervisor escalates a complaint you think they could have resolved at the counter. How do you handle it?" | CASE | [inferred] Derived from the JD's coaching duty and the value Own the Fix | Ask what they tried and what stopped them. Solve the member's problem first, with the supervisor still holding it if that is practical. Coach in a separate conversation, not in front of the member. Name what you would change if the cause is the process. Say what you would not decide alone. It asks about no past | The JD's coaching duty (F5) is the raising source. CASE because it is a live problem from the role |
| C7 | "We are going from eight branches to five hubs over 2027. What does that mean for complaints, and where would you look first?" | CO | [inferred] Derived from the brief's consolidation plan and the value Neighbours, Not Numbers | Clarify: which branches, when, and what changes for members in each town; say you do not know. Give hypotheses to test, not outcomes: where complaints cluster, resolution times around each change, whether complaint data can show which communities feel it first. Respect the plan; challenge one premise politely. It asks about no past | A CO question grounded in the brief, aimed at a branch-manager panel. CO because it tests strategic altitude |

## Bank C: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C8 | "You would coach our supervisors. Where is the line between your job and ours when a supervisor and a member disagree?" | JD | [inferred] Derived from the JD's coaching duty | Offer seam principles, not a pretended seam: who decides, who keeps hold, when you step in and when you coach afterwards. Add reciprocity: ask what the panel would want from you. Do not claim you know their current seam. It asks about no past | The JD's coaching duty is the raising source. Peer persona because a branch manager is pricing what the hire does to their load |
| C9 | "Tell me about a time you and a colleague at your level disagreed about how a complaint should be handled." | EXP | [inferred] "I handled the branch's formal complaints log" | Selection scaffold: the disagreement, what each of you wanted, how it resolved, the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I handled the branch's formal complaints log", or how you would handle it | Persona stem: disagreement with equals. The nearest sentence rests on F1 |

## Bank C: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C10 | "Sixty seconds: why you rather than someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Pause and restate. Say what is yours, at the quotes' scope: "I handled the branch's formal complaints log. I built the monthly complaints spreadsheet our regional manager uses." Concede specifically: "I have never worked in a contact centre." Do not claim you are better. Hold through two follow-ups by returning to what the quotes carry, never by adding to them. The held position is only what the quotes say | The same objection as B6, in the hold-then-concede form. F1, F2 and F3 are the only sentences it can lean on |

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| RC1 | "As eight branches become five hubs, how do you expect complaint handling to change for your teams?" | It tests the brief's plan against branch managers' experience |
| RC2 | "What would make a complaints lead useful to you as a branch manager?" | It converts the peer probe into a conversation |
| RC3 | "What could a new person do in their first month that would genuinely help your branch?" | The reciprocity question for a peer-style panel |
| RC4 | "Which of the four values is hardest to hold at the counter, and what does it look like when it slips?" | It speaks directly to the values round and invites a real example |
| RC5 | "Can you tell me about a complaint that was fixed well here, and what made it work?" | It invites an Own the Fix story you can use in your own words |

## Values cheat sheet (round 3)

Values are as you pasted them, from ashgrovecu.org/about/values on 17 November 2026.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decisions are made from the member's side of the counter | Selection scaffold, C1: no quoted sentence carries this one. Pick a decision where what the member needed and what a process wanted pointed different ways. If none comes to mind, say so plainly, then say how you would handle it |
| Plain Words | If a member needs it explained twice, the writing was wrong | F5 "trained new tellers on our escalation script" is the nearest, and says trained, not wrote. Scaffold C2, ending in the honest branch |
| Neighbours, Not Numbers | Every branch is part of its town | F7 "6 years in retail banking, the last 3 as a branch supervisor" is the nearest, and states no town story. Scaffold C3, ending in the honest branch |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1 "I handled the branch's formal complaints log" is the nearest, and says handled, not solved. Scaffold C4, ending in the honest branch |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | A8, B6, B10, C5, C10 |
| Report monthly on complaint volumes and resolution times | B8, B7 |
| Coach branch supervisors on escalations | B1, C6, C8 |
| Work with digital teams on self-service journeys | B4, B11 |
| 4+ years in financial-services customer operations | A1, B10 |
| Experience handling regulated complaints | A9 |
| Confident presenting to senior leaders | B7, B2 |
| Comfortable with Excel reporting | B9, B8 |

You gave no headline figures about your work, so no defend-the-number question applies.

## Prohibited claims

Each entry has a basis and an honest form. The banks were written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the branch's log, not the process. A8's slot stays inside the log |
| Has contact-centre experience | Negative you stated, F2 | "I have never worked in a contact centre." No slot |
| Has presented to anyone above regional level | Negative you stated, F8 | "I've never presented to anyone above regional level." No slot |
| Reported complaint volumes and resolution times to leaders | Inflated form of F3 | F3's quote at its own scope. The quote shows a monthly spreadsheet your regional manager uses, not what it reported. B8's slot asks only what it tracked |
| Handled regulated complaints | Inflated form of F4 | F4's quote at its own scope: "formal" is yours and "regulated" is the JD's. A9's slot asks only what rules governed the log |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: new tellers. B1's slot stays with the tellers |
| Wrote or designed the escalation script | Inflated form of F5 | F5's quote: trained on the script. C2 does not claim authorship |
| Built the report in Excel, with advanced features | Inflated form of F9 | F9's quote at its own scope: a spreadsheet. B9's slot asks only the tool and what it did |

## Sources

Provided documents:

- The job description, pasted.
- The values page text, pasted by you as copied from ashgrovecu.org/about/values on 17 November 2026. The page itself was not fetched.
- The recruiter's email about the process, pasted.
- Your one-sentence summary of the 2026 strategy brief published in July 2026. The brief itself was not read.
- Your background message.

No `tuesday-dossier.md` was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the four value names used in C1 to C4 and the cheat sheet |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email fixes the three rounds, who runs each, and the 20-minute case, so persona weights follow it |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The brief summary you pasted supplies the four strategy items behind A3, B11 and C7, and it is under six months old |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No name was given, so there was no query to form |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, and any artefact you can share (a redacted export of the complaints spreadsheet, the log's procedure, the escalation script): F1, F3, F4, F5 and F9 currently rest on one sentence each, so their confidence cannot rise past medium and F9 stays low
- Your answers to the answer slots under F1, F3, F4, F5, F6 and F9: they would upgrade A8, A9, B1, B4, B8, B9 and B10 from slots to story maps
- Names or profiles of the Head of Member Services and the two panelists: an interviewer read, reweighted personas, and a reverse question tied to each one's own path
- The recruiter's answer to RA1 on the format of the 20-minute case: C5 and C6 move from a practice shape to the real format
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): the strategy brief itself, which is read only as your summary here, plus recent organisation news; offered once
- A `tuesday-dossier.md` from an earlier evaluation of this role would add verified evidence and a named top objection; it is never required
