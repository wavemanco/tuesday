# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Interview day: 26 November 2026, three rounds, nine days from today (17 November 2026).

| Round | Who | Length | What the recruiter's email says | Mode of this pack |
|---|---|---|---|---|
| 1 | The recruiter (name not given) | 30 minutes | Screening conversation | Mini-pack 1 |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural | Mini-pack 2 |
| 3 | A panel of two branch managers (names not assigned) | 60 minutes | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values | Mini-pack 3 |

Built as loop mode, because the three rounds are scheduled and each one's length and interviewer are known. Assumption: the panel's two branch managers are people whose branches you would work with, so round 3 leans on values, the case, and the working relationship. If that is wrong, the round 3 weights change.

## How to use this pack, and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: where a cell quotes your own words, those words are the ceiling for what you say about your past. An answer slot is an instruction for the interview. It asks nothing of you here.

| Tag | Name | What it is testing |
|---|---|---|
| VAL | Behavioural and values alignment | Whether your past behaviour shows Ashgrove's published values |
| EXP | Work-experience deep-dive | Whether what you say about your work survives follow-up |
| JD | Role and JD-driven | The listed responsibilities and requirements, including the gaps |
| CO | Company and strategy knowledge | Whether you can think at the company's altitude |
| CASE | Live problem | Structure and reasoning on a problem set in the role |

## Prep triage

Nine days, sized in sessions because no hours per day were given. These few things done well beat covering everything.

| Order | When | Do this | Where it lives |
|---|---|---|---|
| 1 | Days 1 and 2 | Say the contact-centre answer aloud until it is boring, including the three follow-ups | D2, then B2 |
| 2 | Days 2 to 4 | Find one real story for each of the four values. The pack cannot supply them: write down the stories you already have and test each against the quoted limits | F1 to F4 in round 3, and the cheat sheet |
| 3 | Days 4 to 6 | Run the escalation case against a timer, twice, speaking aloud | G1, G2, G3 |
| 4 | Day 7 | Rehearse the presenting-to-senior-leaders answer and the 90-second journey | D3, A1 |
| 5 | Day 8 | A full drill of one round | See the offers after the pack |
| 6 | Day 9 | Reverse questions only, then rest | Reverse questions per round |

Everything else in this pack is insurance.

## Fit snapshot

Shared by all three rounds. Evidence cells hold only your own words, quoted. Where a cell says none given, the material you sent says nothing on it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the log of one branch, not the process across branches, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on which stages of a complaint sat with you beyond the log likely. If any were yours, say which and what you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Your sentence says a monthly complaints spreadsheet, built by you and used by your regional manager. It does not say what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours showed. If it counted either, say what was counted and how, in your own words; if it counted something else, or you do not know how a figure was counted, say so plainly and stay with the sentence |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your quote carries new tellers and an escalation script, so the words stay there: "I trained new tellers on our escalation script." Answer slot: if you coached anyone beyond new tellers, say who and how; if you did not, say so plainly and stay with the tellers and the script |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your material touches this. Answer slot: if you have worked with a digital team, say what the work was and which part was yours; if you have not, say so plainly and say what you would bring a digital team first, as a plan |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | The quote already carries the length. Say it as you said it: six years in retail banking, the last three as a branch supervisor. Do not rename the work in the JD's words; let them make the connection |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Your word is formal, and your material does not say what, if anything, governed the log. Answer slot: if you know which rules or timescales applied to the log and who set them, say so in your own words; if you do not know of any, say so plainly and describe how you kept the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Your own statement is the limit. Words: "I have not presented to anyone above regional level." Then a plan for getting ready, said as a plan. Your material does not say whether you have presented at regional level. Answer slot: if you have, say what you presented and to whom; if not, say so plainly |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Your sentence says spreadsheet and does not name the tool. Answer slot: name the tool it was built in and what it did, in your own words; if you did not build it in the tool the JD names, say so plainly and say what you built it in |

## Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| Own the member complaints process end to end across branches | A1, C3, G1, H1 | |
| ...and the contact centre | B2, D1, D2, E1 | D2 is the deepest rehearsal |
| Report monthly on complaint volumes and resolution times | C4, G3 | |
| Coach branch supervisors on escalations | C1, G2 | |
| Work with digital teams on self-service journeys | E1, E3 | |
| 4+ years in financial-services customer operations | A1, B3 | |
| Experience handling regulated complaints | B1 | |
| Confident presenting to senior leaders | D3, G1 | G1 is a spoken walk-through |
| Comfortable with Excel reporting | C4 | The tool slot sits in C4's guidance |

## Grounding brief

What the 2026 strategy brief says, as you relayed it, and the values page you copied this morning. Use the vocabulary; do not recite it.

| Item | Detail | Where it shows up | Provenance |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | E1, E3, R2b | [grounded] the brief, as you relayed it |
| Branch consolidation | Eight branches into five hubs over 2027 | E2, F3, R2d | [grounded] the brief, as you relayed it |
| New product | A small-business lending product in Q1 2027 | Reverse question R2c | [grounded] the brief, as you relayed it |
| Competitive pressure | The main pressure is app-only banks | A2, E1 | [grounded] the brief, as you relayed it |
| Values | Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | Round 3, F1 to F4 | [grounded] the values page, as you copied it |

## Prohibited claims

What this pack will not coach, and why. Built before the banks, so every answer below is written against it.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the log, not the process. Slots stay inside the log |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I have never worked in a contact centre." Then a plan, never a past |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: the material says formal, not regulated. B1's slot stays with the log |
| Coached branch supervisors | Inflated form of F4 | F4's quote at its own scope: new tellers, the escalation script |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I have not presented to anyone above regional level." Then a plan, never a past |
| Expert in Excel reporting | Inflated form of F9 | F9's quote at its own scope. The limit is the pack's observation: the material says spreadsheet, not which tool. C4's slot asks only which tool |

---

# Round 1: the recruiter, 30 minutes

## Persona table, round 1

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured; the journey, why Ashgrove, pay, notice, location, why you are leaving | High. The recruiter's email calls this a 30-minute conversation with the recruiter, and a screen's priors are logistics and motivation in a friendly register [inferred] from the relationship | Script a 90-second arc; treat every casual question as scored; the logistics answers are your own, not rehearsed ones |
| Skeptic, light | Knockout checks against the JD's headline requirements | Medium. F1, F2 and F7 are the rows where the JD's words reach furthest past your material | Concede plainly, then say the plan; do not stretch a quote to close a gap |

## Question bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc on three beats, each one a quoted clause: six years in retail banking with the last three as a branch supervisor; the complaints log and the new-teller training on the escalation script; the monthly complaints spreadsheet your regional manager uses. Tell them in your own words, at those scopes. Answer slot: close on why this role, in your own words; nothing is supplied for it here | F6 and F1 carry the opening. EXP because it tests how you describe your own work; a recruiter row also scores economy |
| A2 | "What draws you to Ashgrove?" | CO | [grounded] | Pick one of the four published values by its exact name and say why it matters to you, in your own words. Do not recite all four. If you mention the brief, one fact is enough, such as the move to digital or the hub plan. Do not claim a value as a thing you have lived unless a story is ready: see the cheat sheet | The values page and the brief are the pasted sources; CO because it scores homework depth |
| A3 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words. No reason is supplied here. Keep it about the move toward this role, and keep it true | Recruiter screens ask this to check motivation is consistent; EXP because it is about your own history |
| A4 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first and then say whether it fits. No figure is supplied here | A pay slot belongs to every recruiter screen; JD because pay is a term of the listed job. The posting you pasted carries no band |
| A5 | "What is your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, exactly as your contract says | Same screen logic as A4; JD because notice is a term of the job |
| A6 | "Where would you be working from, and are you comfortable with the location?" | JD | [generic] | Logistics slot: give where and how often you can work. Ask the recruiter where the role is based and how branch time is split | The posting you pasted names no location, so this is likely to come up; JD because location is a term of the job |

## Question bank B: Skeptic, light

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role needs experience handling regulated complaints. What does that look like for you?" | JD | [inferred] "I handled the branch's formal complaints log" | Say what you did, at the quote's scope: you handled the branch's formal complaints log. Answer slot: if you know which rules or timescales applied to the log and who set them, say so in your own words; if you do not know of any, say so plainly and describe how you kept the log | F7 is the JD row whose wording reaches furthest past your word formal; JD because it scores a stated requirement |
| B2 | "This role covers the contact centre as well as the branches. You haven't worked in one. Is that a concern?" | JD | [grounded] "Never worked in a contact centre" | The short form of D2. Concede in one line: "I have never worked in a contact centre." Then name two things you would want to find out first, in your own words, as plans. Do not offer the log as a substitute | F2 is the headline gap; this is the recruiter's knockout check. D2 holds the deep version |
| B3 | "The role asks for four-plus years in financial-services customer operations. Where do yours sit?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Say it as you said it: six years in retail banking, the last three as a branch supervisor. Stop there and let them connect it to the requirement | F6 is a presentation row: the evidence reaches the requirement in other terms, so the answer is the quote and not a re-wording |

## Reverse questions, round 1

| # | Reverse question | Why it lands |
|---|---|---|
| R1a | "What does the Head of Member Services want the person in this role to have changed by the end of the first six months?" | It asks for an outcome, not a task list, and it prepares you for round 2 |
| R1b | "For the panel round: what format is the 20-minute case, and is there anything to read beforehand?" | It is the one un-researchable fact that shapes round 3 prep, and it shows you are planning ahead |
| R1c | "Who is on the panel, and do you know yet which branches they run?" | The recruiter's email says names are not yet assigned. It converts that into information you can research |

---

# Round 2: the Head of Member Services, 45 minutes

## Persona table, round 2

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values and behavioural | Scenario probes, STAR-shaped stories | High. The recruiter's email calls this round mostly behavioural | "We" for context, "I" for contribution; pick stories where the hard truth actually landed; where your material shows no story, say so |
| Skeptic | Quiet, persistent probing of the gaps | High. This interviewer would be your manager, and a hiring manager is buying capability and weighing gaps [generic]. F2, F5 and F8 are the rows | Rehearse the single most predictable objection until it is boring; bridge only from what you quoted |
| Case and strategist | Live problems on the strategy | Medium. The brief's digital and hub moves give a hiring manager natural problems | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |

## Question bank C: Values and behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4, with only the beats the quote states: you trained new tellers, and it was on the escalation script. Tell it in your own words. Answer slot: the JD's coaching line makes a probe on whether you coached anyone beyond new tellers likely. If you did, say who and how; if you did not, say so plainly and stay with the tellers and the script. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 is where the JD's coaching requirement meets your material; JD because it scores a stated responsibility, with a behavioural delivery |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, what you said, and what happened to the problem and the relationship afterwards. Choose one where the hard truth landed. If no such time comes to mind, say so plainly, then say how you would handle it. No story is supplied for you | A standard behavioural probe at manager level; VAL because it scores behaviour, not virtue. Nothing in your material carries this one, so it is the scaffold case |
| C3 | "Tell me about a time you changed or fixed a step in a process you worked in." | JD | [grounded] "I handled the branch's formal complaints log" | The JD's end-to-end ownership line raises the theme. The quote gives you the log and nothing about changing it. Pick an instance where you changed how something worked, with a named before and after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: that you handled the branch's formal complaints log, or how you would handle it | F1 is the evidence for process ownership and stops at the log; JD because it scores the stated responsibility |
| C4 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3, with the three beats the quote states: you built it, it is monthly, your regional manager uses it. Answer slot: name the tool you built it in and what it counted, in your own words. If it showed figures, name the assumption behind them you would defend least, and say plainly if you do not know how a figure was counted. If something was not yours, or there was no such step, say so and return to the quote | F3 and F9 both rest on this sentence and it leaves the content open; EXP because it tests what you did |

## Question bank D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pick one and own it. Say the quoted limit in one line: "I have never worked in a contact centre" or "I have not presented to anyone above regional level." Then your plan, as a plan. Choosing is the honest move: a candidate who names no weakness reads as not having looked | F2 and F8 are your two stated absences; JD because it scores the listed job including its gaps |
| D2 | "You've never worked in a contact centre, and this role owns the process there as well as in the branches. Why should we believe you can do it?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | The highest-ROI rehearsal in this pack. Hold-then-concede, in four moves. First, concede in your own words: "I have never worked in a contact centre." Second, state only what you bring, at its scope: you handled the branch's formal complaints log. Do not call it comparable. Follow-up 1, if they say a branch log is not really comparable: concede that it is not a direct comparison, then say what you would want to find out first. Follow-up 2, if they ask what you would do in your first month: give a plan with three parts, who you would sit with, what you would read, what you would ask, each as something you will do and never something you have done. Follow-up 3, if they say the team may not take advice from a branch person: hold. Return to the plan and the asking. Do not add a claim to win the exchange | F2 is the largest gap against the JD's own headline line, and it arrives in some form in every round. Skeptic because it probes the gap, with a Pressure delivery. Deepest means the most follow-up levels and the limit named before it is asked for |
| D3 | "This role presents to senior leaders. How would you get ready for that, given you haven't presented above regional level?" | JD | [grounded] "I've never presented to anyone above regional level" | Concede in one line: "I have not presented to anyone above regional level." Then a plan, as a plan: what you would prepare, who you would ask to review it, how you would keep to one page. Answer slot: if you have presented at regional level, say what you presented and to whom; if not, say so plainly and return to the plan | F8 is a stated absence; JD because it scores the stated presenting requirement |

## Question bank E: Case and strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We aim to move 40% of member service to digital channels by 2028. What does that do to complaints?" | CO | [grounded] | Clarify before you structure: what counts toward the 40%. Then objective, who is affected, approach, the monthly measures the JD names (volumes and resolution times), risks. Think aloud. Challenge one premise respectfully, such as whether the share is the right measure for complaints. Say it in plain words, which is itself one of their values | The 40% target is in the brief you relayed; CO because it scores strategy at the company's altitude, and it is the differentiator question most candidates cannot touch |
| E2 | "Eight branches become five hubs over 2027. A member's complaint is open when their branch is folded into a hub. What happens to it?" | CO | [grounded] | Structure aloud: who holds the complaint, what the member is told and in what words, what the record shows at the handover, who tells the supervisor. State your assumptions aloud. Tie to a published value by its exact name | The hub plan is in the brief you relayed; CO because it tests whether the member's complaint stays owned through the change |
| E3 | "How would you work with the digital teams to design a self-service route for complaints?" | JD | [grounded] | Answer slot: if you have worked with a digital team, say what the work was and which part was yours; if you have not, say so plainly and say what you would bring a digital team first. Then structure the case: who the members are, what they need to be told, what a failed self-service attempt should hand over to a person | F5 is a discovery row and the JD line sits behind it; JD because it scores a stated responsibility, with a CASE delivery |

## Reverse questions, round 2

| # | Reverse question | Why it lands |
|---|---|---|
| R2a | "How do the contact centre and the branches work together on complaints today, and where do you want that to be?" | It follows the JD's own across-channel scope and gives you the context F2 needs |
| R2b | "How should complaints show up in the plan for 40% of service to move to digital?" | It uses the brief and puts the role inside the strategy |
| R2c | "With the small-business lending product launching in Q1 2027, what should the complaints process be ready for?" | It shows you read the brief past the digital and hub lines |
| R2d | "With the move from eight branches to five hubs, what should I be preparing the branches for?" | It converts the hub plan into a first-quarter priority |

---

# Round 3: the panel of two branch managers, 60 minutes

## Persona table, round 3

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values and behavioural | Scenario probes against the four published values | Highest. The recruiter's email says the panel is the values round and scores against the four values | Map a story to each value where a quote carries one; use a selection scaffold with its honest branch where none does |
| Case and strategist | The 20-minute escalation case | High. The recruiter's email says the round includes a 20-minute case on a complaint escalation | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Peer evaluator | Seam-splitting between a branch and the complaints lead | Medium. Branch managers are likely to be people you would work alongside or coach through, which is an [inferred] reading; the recruiter's email gives their role, not their relationship to you | Reciprocity framing; propose principles for the seam rather than pretending to know it |
| Skeptic | Gap probes | Low. The gaps are covered in rounds 1 and 2, and D2, D3 are enough if they return | Same counter-strategy as round 2 |

## Question bank F: Values and behavioural

Each published value gets one question. The theme of each comes from the value's own words, as you copied them.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Members First, Always: we decide from the member's side of the counter. When have you made a decision from the member's side of the counter?" | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold. Pick a time when the member's interest and something internal pulled in different directions, and you chose. It needs a named stake, what you decided, and what happened to the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: that you handled the branch's formal complaints log, or how you would decide | Your quotes carry the log and no member-side decision, so this is the scaffold case; VAL because it scores behaviour against a published value |
| F2 | "Plain Words: if a member needs it explained twice, we wrote it wrong. Tell me about a time something had to be explained more than once, and what you changed." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold on one thing your quote does carry: you trained new tellers on the escalation script. Answer slot: if you changed any wording of the script, say what and why; if the script was fixed and not yours, say so plainly and describe how you trained on it, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4's quote touches the idea of words a front-line person has to use; VAL because Plain Words is the value most testable by a branch manager |
| F3 | "Neighbours, Not Numbers: every branch is part of its town. When has knowing a branch's members changed what you did?" | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold. Pick a time local knowledge of members changed what you did, with a named stake and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: six years in retail banking, the last three as a branch supervisor, or how you would approach it. If hub consolidation comes up, say what you would want to know about a branch's town before changing how it is served | The hub plan is where this value bites hardest, and branch managers are the people who feel it; VAL because it scores the value. Your quote carries the tenure, not a story |
| F4 | "Own the Fix: whoever finds the problem keeps hold of it until it is solved. Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold. Pick a problem you found and kept hold of, with a named stake, how you kept hold of it, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: that you handled the branch's formal complaints log, or how you would keep hold of one. Do not describe the log as an owned process | F1 is the closest evidence and stops at the log, so the limit is named before it is asked for; VAL because it scores the value that matches the JD's ownership line |

## Question bank G: Case and strategist

The real case is theirs and is not known. G1 is a practice scenario with the same shape: a complaint escalation, 20 minutes.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member has complained twice at their branch about a fee. The branch sent the second complaint to the contact centre, and the contact centre says it is back with the branch. The member has now phoned the branch manager. You have 20 minutes: what do you do, and who do you tell." | CASE | [generic] | Structure aloud. Clarify first: what the member has been told so far, what time limits apply to this complaint, and who holds it right now. Objective: the member's side of the counter, and one named owner. Then three strands: the member today, the handover gap, and the people. Say what you would tell the member in plain words. State what goes in the record and in the monthly numbers. Name one root cause to look for and one risk. Challenge one premise respectfully. The case needs no claim about your past, so the guidance makes none | The recruiter's email puts a 20-minute escalation case in this round; CASE because it is a live problem. It is built on the JD's end-to-end line and carries no fact about this employer |
| G2 | "The supervisor who took the first complaint says they followed the script. How do you coach them?" | CASE | [grounded] "trained new tellers on our escalation script" | A coaching structure: hear their account first, compare what the script says with what the member needed, agree one change, and say how you will follow it up. You can say plainly what you have done: you trained new tellers on the escalation script, which is a different audience from a supervisor. Answer slot: if you have coached a peer or someone more senior, say who and how; if not, say so plainly and stay with the tellers | F4 holds the evidence and its limit; CASE because it is a hypothetical, with the JD's coaching line behind it |
| G3 | "Which two or three numbers would you put in the monthly report, and why?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | The JD names volumes and resolution times. For each number say what it tells the reader, what decision it supports, and one thing it cannot show. Answer slot: if your own spreadsheet showed any of these, say which and how each was counted, in your own words; if it showed something else, or you do not know how a figure was counted, say so plainly. Say it in plain words | F3 and F9 sit behind this question; CASE because the question asks for reasoning, with the JD's reporting line behind it |

## Question bank H: Peer evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our branches sit alongside whoever leads complaints. Where is the seam between my branch and your role, and what happens when we disagree?" | JD | [generic] | Propose principles, not the seam itself: you do not yet know how these branches work. For example, who holds the member relationship and who holds the process, and who decides when they disagree. Use the published value of keeping hold of a problem as the principle. Answer slot: if a disagreement with an equal comes to mind, say what it was and how you handled it; if none does, say so plainly and say how you would handle it | Peer-style seam questions from branch managers are likely given the JD's across-branches line; JD because it tests the stated cross-channel ownership |
| H2 | "How do you handle credit when work spans branches?" | JD | [generic] | Reciprocity framing: say what you would bring each branch, not only what you would need from them. Answer slot: if a time comes to mind when work spanned teams and credit was shared, say what it was and what part was yours; if none does, say so plainly and say how you would handle it | A standard peer probe; JD because the role works across branches |

## Values cheat sheet

Shown because the recruiter's email says the panel scores against the four values. Official names as you copied them.

| Value | Working meaning | Mapped story | Honest branch |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1: "I handled the branch's formal complaints log" is the nearest quote. Scaffold: a decision where the member's interest and an internal pull diverged | If none comes to mind, say so plainly, then give the nearest thing or how you would decide |
| Plain Words | If a member needs it explained twice, the writing is at fault | F4: "trained new tellers on our escalation script" is the nearest quote. Scaffold: a time the wording needed changing | If none comes to mind, say so plainly, then give the nearest thing or how you would handle it |
| Neighbours, Not Numbers | Every branch is part of its town | F6: "6 years in retail banking, the last 3 as a branch supervisor" is the nearest quote. Scaffold: a time local knowledge of members changed what you did | If none comes to mind, say so plainly, then give the nearest thing or how you would approach it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log" is the nearest quote and stops at the log. Scaffold: a problem you found and kept hold of | If none comes to mind, say so plainly, then give the nearest thing or how you would keep hold of one |

## Reverse questions, round 3

| # | Reverse question | Why it lands |
|---|---|---|
| R3a | "What could a new complaints lead do in their first month that would genuinely help your branch?" | The reciprocity question for a panel whose branches you would work with |
| R3b | "How would you want to hear about a complaint that touches your branch, before it reaches a monthly report?" | It puts the seam from H1 in their own terms and tests Own the Fix |
| R3c | "When the eight branches become five hubs, what do you most want to protect about how a branch deals with its members?" | It connects Neighbours, Not Numbers to the 2027 plan and gives you a value-in-use answer to carry back |

## Sources

Provided documents: the job description you pasted; the four values as you copied them this morning from ashgrovecu.org/about/values; the recruiter's email describing the three rounds; the 2026 strategy brief as you relayed it in four points, published July 2026, with the original text not seen; your background as you described it in your message. No dossier was present. The URL you named is the source of text you pasted, so it was not fetched.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Could not have moved the cheat sheet or the VAL bank: the values page you pasted already supplies all four names and their wording |
| 2. Ashgrove interview process, member service roles | skipped | Could not have moved the loop or persona weights: the recruiter's email names the three rounds, who runs each and what each holds |
| 3. Ashgrove strategy and recent news | skipped | Could not have moved the CO bank: the strategy brief, published July 2026, already supplies the priorities and the competitive frame |
| 4. Interviewer name and Ashgrove | n/a | No name was given for any interviewer, so there was no query to form; there is no interviewer read |
| 5. Representative Member Experience Lead job description | skipped | The job description you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → the fit snapshot's evidence cells now come from your message, and a CV would add quoted lines and could lift some `medium` rows
- Your answers to the answer slots in F1, F3, F4, F5, F7, F8 and F9 → each answered row becomes quoted evidence and its bridge and the questions that draw on it regenerate
- The strategy brief's own text → the grounding brief currently rests on four points as you relayed them
- The panel's names, once assigned → an interviewer read, persona weights tuned to their public professional footprint, and a reverse question tied to their own path
- The recruiter's answer on the case format and any reading beforehand (R1b) → G1 can be reshaped to the real format
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering the strategy in more depth, role-family loop reports and recent organisation context → the CO and CASE banks go further past what the brief already gives
- A `tuesday-dossier.md` from an earlier opportunity check, if you have one → it would give this pack evidence you had already confirmed and a named top objection, instead of the one inferred here
