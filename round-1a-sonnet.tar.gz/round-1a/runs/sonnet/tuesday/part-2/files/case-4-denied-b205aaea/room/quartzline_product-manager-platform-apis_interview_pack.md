# Interview prep pack — Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager, Thursday. Interviewer name and profile: not provided. Built on one assumption: a single session, run by the person you would report to. Your dossier carries no recruiter guidance, so none is assumed.

## How to use this pack

- Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored. Every question carries both.
- Type tags: **VAL** is behavioral and values alignment. **EXP** is a work-experience deep-dive. **JD** is a stated responsibility or requirement. **CO** is company and strategy knowledge. **CASE** is a live problem.
- Guidance is scaffolding, not a script. Say it in your own words.
- An answer slot is an instruction for the interview, not a question for you now. It names what the interviewer is likely to probe and gives two honest branches. Either branch is a good answer.
- Where a cell is labeled `[generic]`, it is a pattern for this kind of role and not a fact about Quartzline.

## Prep triage

Two days to Thursday; no hours figure was given, so this is an order and not a schedule.

1. Rehearse A1 aloud until it is boring, with all its follow-ups, then E1, which is the same answer in sixty seconds.
2. Settle your real answers to the slots in A3, A5, C2, C3 and F2, since these are where a prober finds a seam. Write each answer down once.
3. Do one pass of the Case bank (B1 to B5), thinking aloud.
4. Choose three reverse questions. Ask RQ1 and RQ2 whatever else you drop.

Everything else is insurance.

## Fit snapshot

Requirements are the dossier's `role_profile` lines. Evidence is your dossier's verified entries, quoted. Anything the pack says about your past rests on these quotes and on nothing else. No row is a gate: a length-of-experience requirement is graded like any other.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile (R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | The underwriter's strategy is bridge, and the limit goes in first: the pack's observation is that your material carries integration delivery and roadmap input, with no product title and no product years. The bridge is adjacent work and is never presented as product management experience. Words at the quotes' own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Plain acknowledgment, sourced by `prohibited_claims`: "I haven't held a product manager title." |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile (responsibility; R1 sub-claim) | none given | none | [grounded] | capability | The dossier records an acknowledge_gap strategy for roadmap ownership and prioritization authority (`uncertain_or_weak_areas`). The pack builds no bridge here, and F1's roadmap-input quote is not stretched to cover it. Words come only from the dossier fields: "I haven't owned a product roadmap" (`prohibited_claims`), then a ramp plan said as a plan and never as a past. No answer slot |
| F3 | "Shipped API or platform products" — dossier role_profile (R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The dossier lists this must-have as high priority but grades no weak-area row for it, so this call is the pack's own: the quote speaks of integrating the vendor's APIs through go-live, and does not show whether a product was shipped. Answer slot: the posting's API-and-platform requirement makes a probe on go-lives likely. If any go-live was yours to decide, say which and how you decided, in your own words; if there was no such decision, or it was not yours, say so plainly and describe how you led the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile (R3, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | medium | [inferred] | transferability | Both entries are high confidence in the dossier for what they say; the row sits at medium because they reach docs and schemas only by adjacency, and neither names either. Words at their scope: "I wrote the internal integration playbook my team uses." Answer slot: the posting's technical-fluency line makes a probe on the architecture step and the playbook likely. If you can say which part of each was yours, say so in your own words; if the architecture was another person's, or the playbook is a team document, say so plainly and describe what you did |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile (R4, important); customers leg | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | presentation | The client side is reached in other terms by these quotes, so the bridge rewords only them: "I led 30+ end-to-end client integrations of the vendor's REST APIs." The roadmap-input entry is confirmed with limited inspectable proof, so expect a probe: say what the sessions were, at the quote's scope, and nothing wider |
| F6 | "Stakeholder management across engineering, sales, customers" — dossier role_profile (R4, important); engineering and sales legs | none given | low | [inferred] | discovery | Silence on two of the three groups the requirement names, and the pack does not fill it. Answer slot: the posting's stakeholder line makes a probe on engineering and sales likely. If you worked with either on those integrations or sessions, say who and how, in your own words; if you did not, or it was not yours, say so plainly and stay with the client side |
| F7 | "Agile delivery experience" — dossier role_profile (R5, preferred) | none given | low | [grounded] | discovery | The underwriter's strategy is clarify, and no verified entry speaks to this requirement itself, so nothing about your past goes into an answer. Answer slot: the posting's agile-delivery line makes a probe on how you have worked likely. If you have worked in an agile delivery setting, say what and where; if you have not, say so plainly, and say what you would want to confirm about how their squads define it |

## Persona table

Weights are shown with their reasoning so you can recalibrate. Priors: a hiring manager row puts Case/Strategist and Skeptic first. Loop: your own words establish one session, a conversation with the hiring manager, and no values-style round is documented, so Values/Behavioral stays low. Dossier signals: the underwriter named the objection (raises Skeptic), and "Define and track adoption metrics" is a stated responsibility (raises Prober).

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet, persistent probing of the title and roadmap gap and of the roadmap-input sessions | Highest: a hiring manager is derisking the gap the dossier names, and F1, F2 and F3 are all thin | Rehearse A1 until boring; every bridge comes from F1's quotes with the limit said first; concede the roadmap and prioritization gap plainly with a ramp plan |
| Case/Strategist (B) | Live problems on the partner API platform: what to build, diagnose a drop, define metrics | High: a hiring manager row, and the posting's responsibilities are all things a case can test | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise; confirm the decision boundary and never assume it |
| Data-Driven Prober (C) | Reads the evidence line by line: the 30+ figure, the walk-through, the docs and schemas | Mid: a stated adoption-metrics responsibility and one headline figure invite it | Know how the figure was counted and say plainly where you do not; name the assumption you would defend least before they do |
| Conversational (D) | Friendly opener and casual questions about the playbook and ways of working | Mid: a 45-minute conversation opens with a biography question, and casual questions are still scored | A 90-second arc built from your three quoted beats; treat the casual agile question as scored |
| Pressure (E) | Time-boxed "why you over a PM with the title", and "how much was actually you" | Low: a hiring manager rarely runs a stress format, but the objection can arrive time-boxed | Pause, restate, hold the quoted claim through two follow-ups, concede specifically |
| Peer Evaluator (F) | The seam between you and the two squad leads, and credit across sales, engineering and partners | Low: the interviewer is not a peer, but the role works beside two squad leads, so the question arrives in the hiring manager's voice | Offer seam principles rather than pretending to know the seam; reciprocity: what you bring the squads, at your quotes' scope |
| Values/Behavioral (G) | Scenario probes on hard truths and customers over metrics | Low: no values round is documented, and Quartzline's published values were not available to this pack | Selection scaffolds with the honest branch; do not invent a story |

## Question banks

22 questions, ordered by persona weight. Provenance carries every quoted sentence the guidance rests on.

### A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; negatives sourced by `prohibited_claims` and the acknowledge_gap area in `uncertain_or_weak_areas` | The highest-ROI rehearsal in this pack: the underwriter named this objection, and it will arrive in some form. Order it. First concede, one plain sentence each: "I haven't held a product manager title." "I haven't owned a product roadmap." Then hold only what the quotes carry: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." And, at its scope, "I ran quarterly roadmap-input sessions feeding client evidence to product" — input, not ownership. That second entry is confirmed with limited inspectable proof, so say before they ask what you can show and what you cannot, in your own words. Then a ramp plan, said as a plan: in the first weeks, learn the roadmap as it stands, how adoption is measured, and where the squad leads' decisions end. Follow-up 1, whether integration work is product work: do not argue it; restate it as adjacent and return to the quotes. Follow-up 2, what you would get wrong first: name roadmap ownership and prioritization plainly. Follow-up 3, why not hire the PM: concede they may prefer that profile, say in one sentence what the quoted work gives them, and stop. Never say the integration work was product management | The underwriter's named objection, so the deepest rehearsal; F1 and F2 are where it presses. JD because it scores the stated requirement, with EXP delivery |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] the acknowledge_gap area and `prohibited_claims` in the dossier's handoff | Name it before they do: the roadmap ownership and prioritization part. Say it in one sentence: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then the ramp plan from A1. Do not offer a second weakness to soften the first, and do not call agile delivery a strength or a weakness, since nothing in your material shows which | F2 is the row the underwriter marked as a capability gap, so this is the question that finds it; calibrated candor outscores bluffing a competency the interviewer owns |
| A3 | "This role needs someone who has shipped API or platform products. Where does your experience sit against that?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the quote says, at its scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, through go-live." Answer slot: the posting's API-and-platform requirement makes a probe on go-lives likely. If any go-live was yours to decide, say which and how you decided; if there was no such decision, or it was not yours, say so plainly and describe how you led the integrations. Do not describe an integration going live as shipping a product | F3 is a must-have the dossier did not grade, and the likeliest place to be probed after A1; JD because it scores a stated must-have |
| A4 | "Why a product role, and why now?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Your motivation is yours to give, and the pack supplies none. Anchor on the one quoted beat: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: if those sessions are what pulled you toward product, say so, in your own words; if the pull came from elsewhere, say that plainly. For why Quartzline, use only what you have read yourself, since the pack had no company research to borrow from | The standard Skeptic motivation probe; F1 is the evidence it draws on. EXP because it tests whether the story survives cross-examination |
| A5 | "Walk me through how those quarterly roadmap-input sessions worked." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | The dossier marks this entry medium confidence, so the probe is coming; volunteer the limit first. Tell the beats the quote states: the sessions were quarterly, they were about roadmap input, and they fed client evidence to product. Answer slot: the posting's roadmap line makes a probe on whether the input changed anything likely. If something changed, say what and which part was yours; if nothing did, or you do not know, say so plainly and stay with the sessions as described | F5 holds this entry at medium; the Skeptic will find the seam, so it is rehearsed here. EXP because it tests what was actually the candidate's |

### B — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you would decide what the partner API platform should build next. What do you need to know first?" | CASE | [generic] | No claim about your past. Clarify first: who the partners are and which matter most, what adoption means today, who decides between the two squads (RQ1 and RQ2 are these same unknowns). Then objective, partner segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully, for example whether "next" is decided by this role alone. Describe yourself as recommending, never as deciding the roadmap | F2 is the sub-claim this case tests, and a case needs no claim about the past; `[generic]` because it is a pattern for the problem, and no company research was available |
| B2 | "Partner adoption of an API fell 20% quarter on quarter. Diagnose it." | CASE | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Define adoption and ask for the baseline first. Segment by partner type, by integration stage and by endpoint. The stages your quote names — scoping, requirements, architecture, UAT, go-live — are one way to cut an integration funnel; use them as a structure, not as a story of what you saw. State hypotheses, the first data you would pull, and challenge one premise: whether 20% is signal or noise | The posting names adoption metrics as a responsibility, and F3's integration stages give a natural funnel to reason with; `[inferred]` because the funnel cut is derived from the quote's stages |
| B3 | "Two partners ask for conflicting changes to the API in the same quarter, and both squad leads have a view. How do you decide?" | CASE | [generic] | No claim about your past. Name the criteria (partner impact, evidence, cost, strategic fit), the evidence you would gather, and who recommends and who decides. Confirm the decision boundary instead of assuming it, which is also RQ1. Never say you have set priorities for an engineering squad: section 13 holds that line | The dossier's open unknown is decision authority versus the squad leads; F2 is the row this probes. CASE because it is a live problem |
| B4 | "Name the first three adoption metrics you would put on a partner-facing API, and the assumption you would trust least in each." | JD | [generic] | No claim about your past. Ask for the current baseline first (RQ2). Propose three metrics, say what each measures and what it misses, and name the weakest assumption in each in your own words. These are proposals, not figures you tracked | The posting names defining and tracking adoption metrics as a responsibility and the dossier lists no baseline; JD because it scores that line |
| B5 | "Take a feature partners keep asking for. What goes in the one-page spec you hand the two squads?" | CASE | [generic] | No claim about your past. Structure it: the problem and the partner evidence, the outcome and the adoption measure, scope and explicit non-scope, acceptance criteria, open questions and risks, and who must agree before build. Say aloud what you would confirm with each squad lead | The posting names writing specs and driving delivery with two squads; CASE because it is a live artifact |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through one of those 30+ integrations from scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on the beats the quote states: scoping, requirements, architecture, UAT, go-live. Pick one integration and tell those five in your own words, with "I led" at the quote's scope. Answer slot: the posting's line on discovery with integration partners makes a probe on what that integration showed about the API itself likely. If it showed something you raised, say what and what happened next; if nothing did, or it was not yours to raise, say so plainly and stay with the integration you led | F1 is the evidence a prober tests first; EXP because it checks what was actually the candidate's |
| C2 | "Thirty-plus integrations — how was that counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The headline figure, and it attaches to integrations. Defend it in your own words on the four points a figure raises: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. The pack supplies none of these. "I don't know how that part was counted" is an honest answer | Every headline figure is a prober's target; F1 holds it. EXP because it tests attribution |
| C3 | "How would you judge whether an API's docs and schemas are good enough for a partner to integrate without help?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Build the criteria as a general answer first: completeness, accuracy, examples, error behavior, change communication. Then the bridge at its scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I wrote the internal integration playbook my team uses." Answer slot: the posting's technical-fluency line makes a probe on the architecture step and the playbook likely. If you can say which part of each was yours, say so in your own words; if the architecture was another person's, or the playbook is a team document, say so plainly and describe what you did | F4 is the technical-fluency row and rests on adjacency; JD because it scores the stated requirement |

### D — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each at its quote's scope: you led the integrations; you wrote the playbook your team uses; you ran the roadmap-input sessions. Choose an order you can stand behind. Close with the limit and the draw, said before they ask: this is adjacent work and not product title experience. Answer slot: if the sessions are what drew you toward product, say so; if the draw came from elsewhere, say that plainly | A biography opener opens a 45-minute conversation, and it is scored; F1 supplies all three beats |
| D2 | "Tell me about the integration playbook your team uses." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Two beats the quote states: you wrote it, and your team uses it. Add nothing about what is in it unless you say it from your own knowledge. Answer slot: the posting's adoption-metrics line makes a probe on how you know it is used likely. If you track it, say how; if you do not, say so plainly and stay with the two beats. The dossier marks this entry inspectable; if your employer allows sharing it, it is your one artifact, so check that first | F4's playbook entry is the inspectable one, which a casual question can open up; EXP because it tests what the candidate wrote |
| D3 | "How do you like to work with a squad day to day?" | JD | [grounded] the clarify strategy for the agile area in the dossier's handoff | No verified entry speaks to agile delivery inside a product org, so no story is mapped. Answer slot: the posting's agile-delivery line makes a probe on the cadence and ceremonies you have worked in likely. If you have worked that way, say what and in what setting; if you have not, say so plainly, and say what you would want to confirm: "How do your two squads run delivery today" | F7 is a discovery gap, and a casual register is where it gets asked; JD because the posting lists it as preferred |

### E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds. Why you, over a PM who has done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; negatives sourced by `prohibited_claims` | A1 in one breath. Pause, restate the question, then three sentences: the concession ("I haven't held a product manager title"), the quote at its scope ("I led 30+ end-to-end client integrations of the vendor's REST APIs"), the ramp plan. Stop. Hold through two follow-ups by returning to the quote, and concede specifics, never the core | The objection arrives time-boxed when the interviewer tests composure; F1 is the same ground as A1. JD because it scores the title requirement |
| E2 | "That number of integrations — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold "I led" at its scope, and do not widen it. Answer slot: say which integrations or stages you led yourself and where others carried parts, in your own words; if some of it was team work, say so plainly. Concede that specific, never the whole | A standard attribution probe, and F1 is the quote it tests |

### F — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Two squads, two leads, one platform roadmap. Where is the seam, and what happens when you and a lead disagree?" | JD | [inferred] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Offer seam principles rather than pretending to know the seam: ask where it sits today (RQ3), propose who recommends and who decides, and how disagreements escalate. Reciprocity: what you bring the squads is partner evidence, at the quote's scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." For a disagreement story, none of your sentences carries one, so choose by criteria: a named stake, a moment you held your view, an intact relationship; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Never claim to have set a squad's priorities | The posting names two squads, and the dossier's open unknown is authority over them; F2 is the row it probes. JD because it scores that line |
| F2 | "When sales, engineering and a partner each want something different, how do you handle it?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say first what the quote carries, which is the client side: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: the posting's stakeholder line names engineering, sales and customers. If you worked with engineering or sales on those integrations or sessions, say who and how; if you did not, or it was not yours, say so plainly and stay with the client side | F5 reaches customers and F6 is silent on the other two groups, so this is where that silence shows; JD because it scores R4 |

### G — Values/Behavioral

No values-style round is documented for this loop, and the company's published values were not available, so these two draw on persona stems and not on named values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | No sentence in your material carries this story, so this is a selection scaffold. Pick a time with a named stake, a moment you said the hard thing, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values probe; no values round is detected, so it is low weight and `[generic]` |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | A selection scaffold, since none of your sentences carries it. Pick a time with a named customer need, an internal measure that pointed the other way, and what you did about it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values stem, and relevant to a role that serves partners; `[generic]` because no company values were available |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| R1 3+ years product management experience | A1, A2, A4, E1 |
| R1 sub-claim: roadmap ownership and prioritization | A1, A2, A5, B1, B3, F1 |
| R2 Shipped API or platform products | A3, C1 |
| R3 Technical fluency: API docs, schemas | C3, D2 |
| R4 Stakeholder management across engineering, sales, customers | F1, F2, B3 |
| R5 Agile delivery experience | D3 |
| Run discovery with integration partners | C1, A5 |
| Write specs and drive delivery with two squads | B5, F1 |
| Define and track adoption metrics | B2, B4, D2 |
| The 30+ headline figure | C2, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's risk: decision authority is asserted in the posting and not evidenced. The hypothesis is that it may be shared or unclear, and the answer tells you what you would be accepting. It also reads as diligence |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's risk: adoption metrics are named as a responsibility with no stated baseline. The hypothesis is that the measure may not exist yet, so the answer sets what you would inherit |
| RQ3 | "How do the two squads divide the platform, and where does work cross between them?" | Shows you are thinking about the seam before you are in it; the answer feeds F1 |
| RQ4 | "What would you want someone new to this role to get right in the first ninety days?" | Gets the interviewer to name priorities, and your ramp plan from A1 can be set against what they say |
| RQ5 | "How do partners' integration problems reach the roadmap today, and who carries them there?" | Shows where evidence from the field enters product decisions, which is the ground F5 stands on |
| RQ6 | "What has made people in this team's roles succeed, and what has tripped them up?" | An open question that rapport-style and skeptical interviewers both answer candidly, and it surfaces what the posting does not say |

## Prohibited claims

Built before the banks; no guidance, slot, hold or rationale above asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | The plain acknowledgment that field supports: "I haven't held a product manager title." Then F1's first quote at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" |
| Having owned a product roadmap | Dossier `prohibited_claims`, and the acknowledge_gap area for roadmap ownership | The plain acknowledgment: "I haven't owned a product roadmap", plus a ramp plan said as a plan. No bridge and no answer slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | The plain acknowledgment: "I haven't set prioritization for an engineering squad." No bridge and no answer slot |
| Shipped API or platform products | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: your material says integrations of the vendor's REST APIs through go-live, not a shipped product. A3's slot stays inside the go-lives |
| Wrote or owned API documentation and schemas | Inflated form of F4 | F4's quotes at their own scope. The limit is the pack's observation: your material names an architecture step and a playbook, and neither docs nor schemas. C3's slot stays inside those two |
| Influenced or shaped the roadmap | Inflated form of F5's roadmap-input quote | "Ran quarterly roadmap-input sessions feeding client evidence to product", at that scope. The material says input was fed to product, not that it changed anything. A5's slot stays inside the sessions |

## Sources

**Provided:** `tuesday-dossier.md` (dossier_version 1.1, generated 2026-08-14). Consumed: `role_profile` (requirements and responsibilities stand as the posting's lines; its unknowns are analysis and are not quoted), and `handoff_to_mock_interview` (verified_candidate_evidence, uncertain_or_weak_areas, likely_interviewer_objections, opportunity_risks_to_validate, questions_for_employer, prohibited_claims). `decision` was read as context only. The dossier carries no evidence_map, risk_register or evidence_state.

**Loop:** established by your own words: one 45-minute conversation with the hiring manager. No values-style round is documented, so there is no values cheat sheet.

**Searches sent:** "Quartzline company values" — refused. "Quartzline interview process product manager" — refused. "Quartzline API platform strategy news" — refused. No fetches.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The call was refused. It would have named the published values for VAL themes; with no values-style round detected, no cheat sheet either way |
| 2. `Quartzline interview process product manager` | unavailable | The call was refused. It would have checked persona weights against a documented loop; they rest on your description and the hiring-manager priors |
| 3. `Quartzline strategy` / recent news | unavailable | The call was refused. It would have grounded a CO question and made B1 to B5 company-specific; they are labeled `[generic]` |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access for the three refused targets (up to 6 searches and 2 fetches; a deeper pass adds up to 6 and 2 more, several more minutes) → company-specific CO and CASE questions, named published values for the VAL bank, and persona weights checked against a documented loop
- The interviewer's name or profile → a reading of their career pattern, persona re-weighting, and a reverse question tied to their own path
- Any recruiter notes on focus areas or a pre-declared exercise → coverage of that exercise and a tighter bank
- A current copy of the posting, since the dossier was generated on 2026-08-14 → a check that the requirements and unknowns still match before Thursday
- Your answers to the slots in F3, F4, F6 and F7 → those rows can move from slots to story-mapped rows, and the affected banks regenerate
- The text of the integration playbook, if you can share it → F4's evidence for docs and schemas, which is currently adjacency only
