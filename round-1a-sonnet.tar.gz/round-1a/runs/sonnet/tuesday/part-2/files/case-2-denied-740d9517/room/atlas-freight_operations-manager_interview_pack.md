# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager, Atlas Freight (regional logistics, 800 employees). Interviewer: not known. Relationship and round type: not known, so this is a full-loop pack with flat persona weights. The weights rest on a generic pattern, not on Atlas's own process, because no loop source established it.

Highest-ROI prep in this pack: A2, the step from your current span to the role's twelve supervisors. It will be asked in some form, and a calm, rehearsed answer changes the interview.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. An answer slot is an instruction for the interview, not a question for now. Answer it from your own experience, or say plainly that the practice was not yours or did not exist.

| Type | What it is testing |
|---|---|
| VAL | Whether past behaviour shows values and judgment, not generic virtue |
| EXP | Whether your claims survive scrutiny, including what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — your JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution ops, a shift manager over 3 supervisors and a surge plan for the site, not terminals and not four sites. The words stay there: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's four-sites line makes a probe on coordination beyond one site likely. If any of your responsibility reached beyond one site, say what and how, in your own words; if none did, or none of it was at a terminal, say so plainly and stay with the surge plan you ran |
| F2 | "drive on-time performance" — your JD | none given | none | [grounded] | discovery | Your material does not show on-time performance. Answer slot: if you tracked or improved any on-time measure, say what it was and your part in it; if you did not, say so plainly and say what you would look at first |
| F3 | "cost-per-shipment down" — your JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | The quote is about the mis-pick rate and does not show a cost figure, so the bridge is not stretched. Answer slot: if any cost per unit was tracked and moved, say what and by how much; if none was, say so plainly and stay with the mis-pick result as you stated it |
| F4 | "lead a team of 12 supervisors" — your JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 supervisors; the role says 12. Keep your own number: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have led more than three at any point, say when and how many; if you have not, or it was not your role, say so plainly and stay with the three |
| F5 | "build reporting in Excel/Power BI" — your JD, the Excel half | "solid Excel" — your message | low | [inferred] | discovery | The quote says Excel skill, not reporting built. Answer slot: if you built reports in Excel, say what and for whom; if you used Excel but built no reports, or they were not yours, say so plainly and stay with "solid Excel" |
| F6 | "build reporting in Excel/Power BI" — your JD, the Power BI half | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then a plan, said as a plan and never as a past: how you would reach working level, building from the Excel you said you are solid in |
| F7 | "5+ years operations leadership required" — your JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material gives 7 years in operations and a current leadership post, and does not show how many of the 7 years involved leading people. Answer slot: if you led people for some of those years, say which role and for how long; if only the current post did, say so plainly and give the 7 years as you stated them |
| F8 | "Lean/Six Sigma a plus" — your JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a self-reported credential with nothing inspected behind it, so expect a probe on where you used it. Lead with it in its own terms: you are green belt certified |

## Persona table

Weights are flat because the round type and interviewer are unknown. The reasoning is shown so you can recalibrate if you know something I don't.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet, persistent probing of span, scope and tools | High: F1, F4, F6 are where the JD asks for more than your material shows, and any manager-level interviewer will go there | Rehearse the most predictable objection (A2) until it is boring; calibrated candor over bluffing |
| Case/Strategist (B) | Live operations problems: on-time slips, cost rises, surge | High: the JD is a list of operating outcomes, and a hiring manager buys capability live | Clarify, then objective, segmentation, approach, metrics, risks; think aloud |
| Data-Driven Prober (C) | Line-by-line on the numbers and tools | Medium-high: the 40% figure is a magnet, and Excel and Power BI are checkable | Know and say how the figure was counted, or say plainly you do not know |
| Pressure (D) | Interrupts, time-boxes, "how much was you" | Medium: a senior role invites composure tests, but the signals for it are weak | Pause, restate, hold through two follow-ups, concede only what is true |
| Conversational (E) | Chatty biography and motivation questions, still scored | Medium: nearly every loop opens this way | A 90-second arc from your own sentences |
| Values/Behavioral (F) | Scenario prompts about judgment | Low-medium: no values-style round was detected, since no loop source documents one and the generic pattern assumes none | Pick a real story with a named stake, or say plainly none comes to mind |
| Peer Evaluator (G) | Seams between teams, credit, disagreement | Low-medium: possible if a peer manager joins | Propose seam principles, not claims about the seam |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Name one real gap plainly, before they find it. The one your numbers show is span: you are "currently a senior shift manager over 3 supervisors" and the role leads twelve. Then give a first-weeks plan in your own words: who you meet, what you read first, how you learn each site. A plan, never a past claim. Do not volunteer a list of other weaknesses | F4 is the widest scope gap; JD because it scores the role's stated requirement |
| A2 | "You're a senior shift manager over three supervisors; this role leads twelve. How would you handle that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal here. Level one, say the numbers as they are: "I'm currently a senior shift manager over 3 supervisors." Level two, what changes at twelve: answer as a plan for how you would learn each person and each site, not as something you have done. Level three, have you led more. Answer slot: if you have led more than three at any point, say when and how many; if you have not, or it was not your role, say so plainly and return to the three. Concede the numbers; hold on how you would learn. Say the limit before they ask for it | F4 is where the JD presses hardest, so this objection arrives in some form; JD because it scores the stated team-size requirement |
| A3 | "This role owns daily operations across four sites. Tell me about the widest operation you've been responsible for." | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running" | Story-mapped on F1: you "ran the site's peak-season surge plan two years running", with those beats only: the plan, the peak season, the two years. Tell it in your own words. Answer slot: the JD's four-sites line makes a probe on coordination across sites likely. If any part reached beyond one site, say what and how; if none did, or it was not a terminal, say so plainly and stay with the plan you ran | F1 is the evidence for the multi-site requirement and the likeliest place to be pressed; JD because it scores the stated scope |
| A4 | "The posting asks for 5+ years of operations leadership. How much of your seven years was leading others?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Start with what you said: "7 years in warehouse and distribution ops", and your current post as a senior shift manager over 3 supervisors. Answer slot: if you led people for some of those years, say which role and for how long; if only the current post did, say so plainly and give the seven years as they are | F7 is the requirement your material does not yet settle; JD because the posting states it |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Imagine on-time performance at one terminal falls over a quarter while the others hold. What do you need to know first, and how do you diagnose it?" | JD | [generic] | Clarify first: what on-time means here, measured at which point, against what promise. Then objective, segmentation, approach, metrics, risks. Say the structure aloud and challenge one premise politely. The question needs no claim about your past, so the guidance makes none | F2 is the requirement your material does not reach, so live reasoning is the evidence you can give; JD content, CASE delivery |
| B2 | "Cost per shipment is rising at one site. Where do you look, and in what order?" | JD | [generic] | Define the number first: what sits in the cost, and what counts as a shipment. Split the numerator from the denominator, find which moved, then test causes, then name the one metric you would watch weekly. No claim about your past | F3 is thin, so reasoning aloud carries the weight; JD content, CASE delivery |
| B3 | "Design the daily review across four sites: what is in it, who joins, and what decisions come out of it." | CASE | [generic] | Clarify the purpose, then structure: what must be seen daily, what is decided on the call and what is escalated, and how each site is held to account. Propose it as a design, not as something you ran | F1 and F4 both press on running several sites through supervisors; CASE because it is a live design problem |
| B4 | "Volume runs well above forecast for several weeks and headcount cannot rise. What do you do in the first 48 hours?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: clarify, objective, segmentation, approach, metrics, risks. The case asks about no past. If you refer to your own plan, say it only as the sentence does: you "ran the site's peak-season surge plan two years running". Answer slot: if you can say what the plan covered, say it in your own words; if its details are not yours to give, say so plainly and use the structure | F1 holds your strongest stated operating story, and a surge scenario is the natural live test of it; CASE because it is a live problem |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% cut in mis-pick rate was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Four slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Name the weakest assumption before they do. If you do not know how it was counted, say so plainly | F3 holds your one headline figure, and probers go there first; EXP because it tests what was actually yours |
| C2 | "What did redesigning the pick path involve?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say what you redesigned, in your own words. The sentence states the redesign and the result and nothing else. Answer slot: if others took part, say which part was yours; if it was all yours, say that. Then return to the redesign | F3 is the evidence a prober opens first; EXP because it tests the claim behind the number |
| C3 | "Tell me about reporting you've built in Excel for operations." | JD | [grounded] "solid Excel" | Say it as you said it: solid Excel. Answer slot: the JD's reporting line makes a probe on what you built likely. If you built reports, say what and for whom; if you used Excel but built no reports, or they were not yours, say so plainly and stay with Excel | F5 is a skill claim with no reporting behind it in your material; JD because the posting states reporting in Excel |
| C4 | "The role builds reporting in Excel and Power BI. Where are you with Power BI?" | JD | [grounded] "never used Power BI"; "solid Excel" | The plain words are yours: "I haven't used Power BI." Then a plan in the future tense: how you would reach working level, building from the Excel you said you are solid in. Do not describe any Power BI work | F6 is a gap you named yourself, so the honest answer is already ready; JD because the posting states the tool |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That result: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause, restate the question, anchor in your sentence: you cut the mis-pick rate 40% by redesigning the pick path. Hold it through two follow-ups by returning to the sentence, never by adding to it. Answer slot: if parts were others', say which; if it was all yours, say so. Concede only what is true and specific; never fold on the core claim to restore harmony | F3 is the figure a pressure interviewer tests; EXP because attribution is what is scored |
| D2 | "Sixty seconds: why you over a candidate who has already led a dozen supervisors?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | Offer the three facts in those words and let them draw the inference. Hold through two follow-ups by returning to them. Concede the numbers in your own words: "I'm currently a senior shift manager over 3 supervisors" is your span today. Do not claim to be the stronger leader | F4 makes this comparison likely; JD because it tests fit to the stated team size |
| D3 | "Your background is warehouse and distribution. Why would that carry over to terminals?" | JD | [grounded] "7 years in warehouse and distribution ops" | Hold on what you said: "7 years in warehouse and distribution ops". Answer slot: the JD's terminals line makes a probe on what differs likely. If you have worked in a terminal, say when and what you did; if not, say so plainly and return to your warehouse and distribution work. Concede the difference without claiming the carry-over | F1's setting does not match the JD's setting; JD because it scores fit to the stated operation |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc built only from those five sentences, in that order or one you prefer. Add no roles, employers or dates you did not give. Close with your own reason for wanting this role, in your own words | F1, F2 and F8 carry the only stated history; EXP because it is scored as a CV walk |
| E2 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Open with the credential: you are green belt certified. Answer slot: if you use it now, say where and how; if it is a certification only, or you are not using it currently, say so plainly and stay with the certification. Do not link it to the pick-path redesign unless you can say it was done with those methods | F8 is the plus the JD names; JD because it is a stated plus, asked casually |
| E3 | "What draws you to a regional logistics company like Atlas Freight?" | CO | [generic] | Selection scaffold: give your own reason in your own words, and name only what you have actually read about Atlas. The pack could not research the company. If you have read nothing yet, read the company's site before the interview; failing that, say what drew you in the posting itself | The loop and company facts are not established; CO because it tests homework, kept generic where research could not run |

### F. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | No values round is detected; the theme is a standard behavioural stem. VAL because it scores judgment under pressure |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the customer and the metric pulled apart, say what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A customer-versus-metric choice is common in freight; VAL because it scores which way you lean when the two conflict |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where is the seam between your role and a peer manager's, and what happens when you two disagree?" | JD | [generic] | Offer seam principles, not claims about the real seam: who decides what, when it escalates, how you settle it. For disagreement, a selection scaffold: a time you held your view with tact. If none comes to mind, say so plainly, then describe how you would handle it | Four sites imply peers; JD because it scores the shared-ownership side of the role |
| G2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Use the sentence as it stands. Answer slot: if others contributed to that result, say who and what, and say what was yours; if it was all yours, say so plainly. Then give your principle for sharing credit in your own words | F3 is the one result you can attribute; EXP because it tests attribution honesty |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A1, A3, B3, B4, D3 |
| Drive on-time performance | B1 |
| Cost-per-shipment down | B2 |
| Lead a team of 12 supervisors | A1, A2, D2 |
| Build reporting in Excel/Power BI | C3, C4 |
| 5+ years operations leadership | A4 |
| Lean/Six Sigma a plus | E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| H1 | "What does good on-time performance look like at your four sites today, and where is it hardest to hold?" | It shows you think in outcomes and tells you where the job is hard |
| H2 | "How is cost per shipment tracked here, and who owns the number at each site?" | It puts a named owner on the metric the JD asks you to move |
| H3 | "What reporting exists today, and how much of it lives in Excel versus Power BI?" | It surfaces the tool gap on your terms, as a question about the real state |
| H4 | "How do the twelve supervisors split across the four sites, and where is the team strongest and where thinnest?" | It shows you are already thinking about the span |
| H5 | "What would you want to see from me in the first 90 days?" | It converts the interview into a shared plan and answers the day-one worry |
| H6 | "What happens after this conversation, and who else will I meet?" | It fills the loop gap and costs nothing |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed twelve supervisors | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says 3 supervisors. A2's slot stays inside the three |
| Owned or ran terminal or multi-site operations | Inflated form of F1 | F1's quotes at their own scope. The material says a shift manager and one surge plan, not terminals or four sites. A3's slot stays inside the plan |
| Drove on-time performance or cost per shipment down | Inflated form of F2 and F3 | F3's quote at its own scope: the material says mis-pick rate. B1 and B2 stay reasoning, not history |
| Built reporting in Excel | Inflated form of F5 | F5's quote at its own scope: "solid Excel". C3's slot stays inside it |
| Built or used Power BI dashboards | Negative the candidate stated, F6 | The plain acknowledgment: "I haven't used Power BI." No slot |
| Has 5+ years of operations leadership | Inflated form of F7 | F7's quotes at their own scope: 7 years in operations, a current leadership post. A4's slot asks only how many years involved leading people |
| Delivered the pick-path result through green belt methods | Inflated form of F8 and F3 | F8's quote and F3's quote kept separate. E2's slot allows either branch |

## Sources

Provided documents: the job description and background you pasted in your message. No dossier was present.

Searches sent, all refused by the host before returning anything:

- `Atlas Freight regional logistics company values`: refused
- `Atlas Freight interview process operations manager`: refused
- `Atlas Freight strategy recent news terminals`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have fed the values cheat sheet, which no detected values round calls for here; the VAL bank rests on standard stems instead |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have named the loop and moved persona weights; they fall back to the generic pattern, said above |
| 3. `Atlas Freight strategy recent news` | unavailable | Every call was refused. It would have fed a strategy-grounded CO or CASE question; E3 is generic instead |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you meet (manager, peer, HR) → reweighted persona table and a restructured question bank
- The interviewer's name, if the recruiter will give it → an interviewer read from their public footprint and a reverse question tied to their path
- The recruiter's prep email → format, focus areas and any announced deliverable
- Your CV → more verbatim evidence for the fit snapshot, with some rows upgraded from `[inferred]` to `[grounded]`
- Your answers to the slots on F1, F2, F3, F4, F5, F7 and F8, said in your own words and outside any drill → those rows regenerated from your facts
- Company text pasted (careers page, values, about) or permission to search → a values cheat sheet if the loop documents a values round, a strategy-grounded CO or CASE question, and a documented loop
- Hours available before the interview → a prep triage ordered to that time
- A tuesday-dossier.md from an earlier fit check, if you have one → verified evidence and absolute prohibited claims; never needed to use this pack
