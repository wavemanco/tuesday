# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, one 60-minute panel session on Tuesday. **Panel:** Deepa, VP Partnerships (your future manager), and Ross, Commercial Director. **Shape, in the recruiter's words:** a short POV for the first 15 minutes, then Q&A in which "Ross will push on commercials". **Mode:** session. **Prep time:** about four hours over the weekend.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding to speak from, not a script: where it says answer slot, the content is yours, in your own words, and the pack does not supply it.

| Tag | Name | What it is testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values. Not used in this pack: no values-style round is detected and no published values were read |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what was actually you |
| JD | Role / requirement-driven | Whether you can do what the recruiter's email says the role needs, gaps included |
| CO | Company and strategy knowledge | Homework depth and whether you can think at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role, delivered live |

Provenance labels: `[grounded]` rests on your message or the recruiter's words as you quoted them; `[inferred]` is derived from an adjacent source; `[generic]` is a role-family pattern that says nothing specific about this company. Everything in this pack that speaks about your past is one of your own sentences, quoted, or an answer slot. Proposed language in this pack is pending your approval; nothing here is final until you say so.

## 2. Prep triage (about four hours)

Do these in order. Each is tied to a section or question ID.

1. **90 minutes: the POV (section 5).** Build it from the three thesis options, say it aloud against a clock three times, and land on the operators in the last two minutes. This is the one graded deliverable.
2. **60 minutes: the objection rehearsal.** B1 first, then D1 and C4, out loud, with someone interrupting if you can. B1 is the highest-ROI prep in this pack.
3. **45 minutes: defend your numbers.** C1, C2, D2. Write down, in your own words and from what you actually know, how the figures were counted. The pack cannot supply this and must not.
4. **30 minutes: the journey and the close.** F1 as a 90-second arc, then pick your reverse questions (section 8).
5. **15 minutes: re-read the strategy team's report** for A4: choose one item to agree with and one to depart from, with reasons.

Everything else is insurance.

## 3. Fit snapshot

No job description was supplied, so the requirements come from the recruiter's own words as you quoted them, plus two role-family requirements written as plain prose and labeled `[generic]`. The bridge language below is proposed, pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, which is adjacent to operator partnerships and does not reach them, with nothing inspected behind it. The words stay at that scope: "My last four years have been at a payments company, running the ISV channel, and I took it from 6 partners to 40." The pack observes that your material does not show operator relationships |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | The quote names consulting in bus and light rail network planning. It does not say who the clients were, and it does not show train operating companies or employment inside an operator, so "the other side" is read at its lower meaning. Words: "I spent 5 years in transport consulting, in bus and light rail network planning." Answer slot: the recruiter's ask to land on the operators makes a probe on what you saw of how operators work likely. If your consulting put you in front of operators' own planners, say what you saw, in your own words; if it did not, or you saw operators only through clients, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | The quote says influenced revenue, with no period and no share of it marked as yours, and nothing inspected behind it. Answer slot: Ross's push makes a probe on this figure likely. Say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words; if you do not know how it was counted, say so plainly |
| F4 | Owning a commercial target for partnerships (role-family, no source) | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota; what I've carried is influenced revenue." Then how you would want a target defined, said as a plan and never as a past. Never a claim to have owned a target |
| F5 | Familiarity with rail operators as customers and partners (role-family, no source) | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then your ramp plan, said as a plan and never as a past; the adjacent evidence is F2's quote, at its own scope |

## 4. Prohibited claims

What this pack will not coach, built before the question banks and binding every cell in them.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail, or sold to train operators | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never sold into rail specifically." No slot |
| Has carried a quota or owned a revenue target | Negative the candidate stated, F4 | The plain acknowledgment F4 gives: "I've never carried a direct quota; what I've carried is influenced revenue." No slot |
| Generated or closed £4M | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: the quote says influenced, with no period and no share marked as yours. Slots stay on counting, sensitivity, weakest assumption and your share |
| Knows rail operations from the inside, or has worked for an operator | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says consulting in bus and light rail network planning, and does not show employment by an operator or work with train operating companies |
| Founded or built the ISV channel from nothing | Inflated form of F1 | F1's quote: "took it from 6 partners to 40". The limit is the pack's observation: the quote starts from 6 and does not say who signed the partners added |

## 5. Graded deliverable: the 15-minute POV

The recruiter's brief, quoted from your message: "present a short POV on where you'd take our operator partnerships over the next 18 months", "no slides needed, just talk us through it", and "Please land on what it means for the operators themselves". This section is proposed language, pending your approval.

**Grounded facts to build on.** Use them as one-line credentials, never as proof of the thesis; let the panel draw the inference.

- F1: "took it from 6 partners to 40"
- F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- F3: "roughly £4M of influenced revenue"

**Thesis options.** Pick one and build the 18 months around it. Each carries a mandatory concession, said aloud before the panel finds it. All three are `[generic]` structures: they assert nothing about Kelverton.

| Option | Thesis | Mandatory concession, in words you can say |
|---|---|---|
| T1 | Start from the outcome for the operator and work back to the partnership model | "I don't yet know which operator outcomes matter most here, so my first move is to ask, and the plan changes with what I hear." |
| T2 | Fewer, deeper operator partnerships made reference-grade before widening | "Depth costs reach, and I haven't done this in rail, so I'm arguing for it, not showing it." This uses F5's stated negative at its own scope |
| T3 | Agree early with each operator how the value is measured, so every partnership can be defended commercially | "I've never carried a direct quota, so I'd want Ross's view on how success is measured before I'd set a target." This is F4's plain acknowledgment |

T3 is the natural bridge to Ross's push; T1 is the natural carrier of the required close. Choosing T1 with T3 as its second move is one coherent option.

**Differentiate from the report, never recite it.** The strategy team's report was written by the interviewers' own side, so it is the consensus view the panel already holds. Bring one item from it to show grounding, then one thesis-driven departure with your reasons. I have not seen the report, so naming the items is yours. Where the role includes saying no, add the anti-pick: one partnership type or operator request you would decline in the 18 months, named in your own words with the criterion you used; if you cannot name one, say what criterion you would use to decide.

**Shape (a rehearsal structure, not a script).**

| Minutes | Beat |
|---|---|
| 0 to 1 | Frame: your thesis in one sentence, and one credential line from the facts above |
| 1 to 4 | The thesis, its concession, and the report item you agree with |
| 4 to 11 | The 18 months in three moves, each with what it asks of Kelverton and what it asks of operators; the one departure and the anti-pick sit here |
| 11 to 13 | **The close the recruiter asked for: what it means for the operators themselves.** Name who inside an operator feels the change, what they do differently, and how they would know, in your own words; if you do not know who the user inside an operator is, say that finding out is the first thing you would do |
| 13 to 15 | What you would test first, what you are least sure of, and an invitation to push |

Expect Ross to interrupt in the 4 to 11 block. D3 is that interruption.

## 6. Persona table

Weights are shown reasoning, so recalibrate if you know something the pack cannot. The loop is established by your own words: one 60-minute panel with a 15-minute POV, then Q&A. No values-style round is documented, so there is no values cheat sheet.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| Case/Strategist (A) | Live problems on operator partnerships, starting from your POV | High. Deepa is your future manager and the panel opens with a POV; the hiring-manager round row weights this persona first | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Quiet probing of the rail and operator gap and the move from payments | High. Same hiring-manager row; your own message states the rail gap, so the probe has a sourced negative | Rehearse B1 until it is boring: plain acknowledgment, adjacent evidence at its own scope, a concrete ramp plan |
| Data-Driven Prober (C) | Walk-throughs of the £4M and the 6 to 40 | High. "Ross will push on commercials" is the recruiter's own signal, and the technical-specialist row weights this persona | Know how each figure was counted and say plainly when you do not know; name the weakest assumption you know of before they do |
| Pressure (D) | Interruptions, time-boxed answers, "how much was actually you" | Medium. The same Ross signal; relationship to the role not stated, so weighted below the Prober | Pause, restate, anchor on what you stated, hold through two follow-ups before conceding anything real |
| Peer Evaluator (E) | The seam between partnerships and commercial | Low to medium. Ross sits on the commercial side of that seam, but a peer round was not described | Propose seam principles rather than pretending to know the seam; reciprocity, what you bring commercial |
| Conversational (F) | The journey and why Kelverton | Low as a style, but the opening minutes of a panel are often casual and still scored | A 90-second arc; treat casual questions as scored |
| Values/Behavioral | Not banked | Low. No values-style round is detected and no published values were read | Revisit if the recruiter names a values segment |

## 7. Question banks

Questions are the interviewer's lines. Answer slots end without a question mark and ask for no reply here.

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the plan for our operator partnerships over the next 18 months. What do you need to know first?" | CASE | [generic] | This is the POV in Q&A form (section 5). Clarify before you structure, name the objective, then the moves and how you would measure them, thinking aloud. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | F1 and F2 are where the panel will test this ask. CASE because it scores structure on the role's own problem |
| A2 | "Which operators would you start with, and how would you decide?" | CASE | [generic] | Say your selection criteria aloud, and say what you would need from Kelverton to apply them, such as the current operator list. Do not name operators or claim knowledge of the market you do not have | F1's requirement made concrete; JD content, CASE delivery |
| A3 | "What would you deliberately not do in the first 18 months?" | CASE | [generic] | The anti-pick from section 5: one thing you would decline and the criterion behind it. If nothing comes to mind, say what criterion you would use to decide | A partnerships role includes saying no; ties to F1's requirement |
| A4 | "You've read our strategy team's report. Where would you depart from it?" | CO | [grounded] "which I've read" | Bring one item you agree with to show grounding, then one departure with your reasons. What the report says is yours to supply; the pack has not seen it. If you have no real departure, say where you agree and what you would test | The report is the one provided strategy source; differentiating from it is the rubric's rule, and F1 is the requirement it serves |
| A5 | "An operator tells you the partnership isn't worth their team's time. What do you do?" | CASE | [generic] | Clarify what it costs them and what they get before you answer, then what you would offer, what you would concede, and when you would stop. This is the operator lens of your close, in a live problem | F2's requirement as a decision rather than a statement |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail. Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "last 4 at a payments company running the ISV channel" | **Highest-ROI prep in this pack.** Say the acknowledgment first, in the quote's terms: "I've never sold into rail specifically." Then the adjacent evidence at its own scope: the network planning in bus and light rail, and the ISV channel. Follow-up 1, "consulting isn't selling": agree that work was network planning in bus and light rail, and stay there. Follow-up 2, "that isn't train operating companies": agree it was bus and light rail, and stay there. Follow-up 3, "why take the risk": give your ramp plan, as a plan: what you would learn first and from whom, in your own words. Hold by returning to the quotes, never by adding to them | F5 is the likeliest objection, and the recruiter's own framing makes it near-certain in some form. JD because it scores the stated requirement, Skeptic because it probes the gap |
| B2 | "Why leave payments, why rail, and why now?" | EXP | [generic] | Give your actual reasons in your own words; the pack supplies none. Keep it to what is true, and tie it to what you want to do next, not to what you are leaving | The Skeptic's standard motivation probe; the pack has no source for your reasons |
| B3 | "Our partners are operators. Your channel was software vendors. What transfers and what doesn't?" | JD | [grounded] "last 4 at a payments company running the ISV channel" | Say what the channel was, in the quote's words, then give a view, not a track record: what you would expect to carry across and what you would not. If you do not know how operators decide, say that is the first thing you would ask | F1 is adjacent, not direct, so this is where the panel tests the bridge |
| B4 | "Where do you think we're wrong about our operator partnerships?" | CO | [generic] | You cannot know from outside. Say so, then offer one hypothesis, labeled as a hypothesis, and what you would check to test it. Do not assert a fact about Kelverton | F1's requirement from the panel's own seat; CO because it tests company-altitude thinking |

### C. Data-Driven Prober (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | The weakest-assumption move: say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words. If you do not know how it was counted, say so plainly. Keep the figure at "influenced" and "roughly" | F3 is the headline number and Ross's push lands here first |
| C2 | "You took the channel from 6 partners to 40. What counted as a partner, and what was your part?" | EXP | [grounded] "took it from 6 partners to 40" | The same four slots: what counted, what it is sensitive to, the assumption you would defend least, which part was yours, in your own words. If the part was not yours alone, say so plainly | F1's second quoted figure, and the one a prober tests next |
| C3 | "How would you judge whether one of our operator partnerships is paying for itself?" | JD | [generic] | Structure it: what the partnership costs, what it returns, over what period, and which measures you would want. Do not invent numbers; say what you would need from Kelverton's own model | F3's requirement as a live problem; JD content, CASE delivery |
| C4 | "You've never carried a direct quota. How would you feel about being held to a number?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Say the acknowledgment: "I've never carried a direct quota; what I've carried is influenced revenue." Then how you would want a target defined and agreed, as a plan, in your own words. Do not claim a comfort or a record you have not stated | F4 is where F3's numbers meet accountability |

### D. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has already sold into rail?" | JD | [grounded] "Never sold into rail specifically"; "took it from 6 partners to 40"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Hold-then-concede. Pause and restate. Concede precisely: "I've never sold into rail specifically." Hold on the two quotes, the channel and the network planning, through two follow-ups by returning to them, never by adding a claim. Do not argue that you would outperform | F5 under time pressure; JD content, Pressure delivery |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Pause. Say which part was yours, in your own words. If it cannot be separated, or you do not know, say so plainly. Hold at "influenced" and do not harden it through two follow-ups | F3's attribution probe |
| D3 | "Interrupting: why would an operator care about any of that?" | CASE | [generic] | Pause and restate. Answer from the operator-outcome sentence you chose for your close (section 5). Hold through two follow-ups; concede specifically what you do not yet know about operators and how you would find out | R2's requirement tested live, mid-POV |

### E. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where does partnerships end and commercial begin, and what happens when we disagree?" | CASE | [generic] | Propose principles for the seam rather than pretending to know it: who decides what, how a disagreement is raised, what you bring commercial. Say what you would ask first | F3's commercial pressure, seen from the seam between the two panel members' functions |
| E2 | "A deal comes in through a partner and our sales team closes it. Whose is it?" | CASE | [grounded] "never carried a direct quota, only influenced revenue" | Give your view on how credit should be agreed before the deal. Say honestly what you have carried: "I've never carried a direct quota; what I've carried is influenced revenue." Do not describe an arrangement you did not have | F4's gap in a collegial register |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40" | A 90-second arc on the beats the quotes state: consulting in bus and light rail network planning, then 9 years in partnerships, the last 4 running the ISV channel, which you took from 6 partners to 40. Add your own reason for each move, in your own words; the pack supplies none | F1 and F2 are the arc's spine; a casual question is still scored |
| F2 | "What drew you to Kelverton?" | CO | [grounded] "which I've read" | Say what caught you in the strategy team's report, in your own words. The pack has not seen it, so it cannot say. If nothing specific caught you, say what you would want to learn | Motivation and homework in one question; F1's requirement |

## 8. Reverse questions

No interviewer profile was researched, so none is tied to an interviewer's own path; the upgrade menu says what a profile would add.

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would need to be true about our operator partnerships at month 18 for you to call my first year a success?" | Lets Deepa state the measure, and shows you think in outcomes |
| 2 | "How do you decide today whether an operator partnership is paying for itself, and what does the evidence look like?" | Speaks directly to Ross's commercial lens and quietly addresses F4 by asking how success is measured here |
| 3 | "Where does a partner-sourced opportunity get credited between partnerships and commercial?" | Raises the seam from E1 as a working question, and matches your honest background in influenced revenue |
| 4 | "Of what the strategy team's report recommended, what has already moved, and what has stalled?" | Shows you read it and want the current picture, not the archived one |
| 5 | "What would you most like a new hire to have done by the end of month three?" | Gives you the panel's own definition of an early win, and a practical ramp target for B1 |
| 6 | "Which of today's operator relationships would you hold up as the model, and what made it work?" | Gives you a concrete reference for A2 and T2 |

## 9. Requirement coverage

| Requirement | Covered by |
|---|---|
| "present a short POV on where you'd take our operator partnerships over the next 18 months" | A1, A2, A3, A4, B3, B4 and section 5 |
| "Please land on what it means for the operators themselves" | A5, D3, B3 and section 5's close |
| "Ross will push on commercials" | C1, C2, C3, C4, D2, E1, E2 |
| Owning a commercial target (role-family) | C4, E2 |
| Familiarity with rail operators (role-family) | B1, D1 |
| "no slides needed, just talk us through it" | none, and why: it is the format of the POV, not a requirement; section 5 holds the shape |

## 10. Sources

**Provided:** your message, including the recruiter's email as you quoted it. **Not seen:** the market report attached to that email. No `tuesday-dossier.md` was present.

**Searches sent, all refused (no search permission was granted):**

- Kelverton Rail company values: refused
- Kelverton Rail interview process partnerships manager: refused
- Kelverton Rail strategy scheduling software train operating companies news: refused
- Deepa VP Partnerships Kelverton Rail: refused
- Ross Commercial Director Kelverton Rail: refused
- Senior Partnerships Manager Kelverton Rail job description: refused

Nothing about Kelverton's values, loop, strategy or the interviewers comes from outside your message, and the CO and CASE questions are `[generic]` for that reason.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | A values cheat sheet if a values round is documented; none is, so nothing is lost until research runs |
| 2. `Kelverton Rail interview process partnerships manager` | unavailable | Loop structure and persona weights; the weights rest on your recruiter's description alone |
| 3. `Kelverton Rail strategy` / recent news | unavailable | CO and CASE questions that cite current priorities; they stay generic |
| 4. `Deepa` and `Ross` with `Kelverton Rail` | unavailable | An interviewer read and a reverse question tied to each interviewer's path |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Fit rows quoted from a posting instead of role-family prose |

## Upgrade menu

- The job description → F4 and F5 stop being `[generic]` role-family rows, JD-tagged questions get real requirements, and any gate (location, travel, right to work) gets checked
- The report's headline conclusions, pasted → A4, F2 and the section 5 differentiation stop resting on your description of it
- Search access, or the facts from the recruiter → Kelverton's values, loop and strategy, so the CO bank stops being `[generic]`
- The interviewers' public profiles, or their full names → a reading of each and reverse questions tied to their paths
- Your own answers to the answer slots → rows F2 and F3 upgrade from slot to quote; for F3, a partner-sourced revenue report or attribution export, or your own summary of how the figure was counted, is the artifact that would raise it
- Your CV → fit rows quote it in place of your message, and any evidence your message dropped appears
- A `tuesday-dossier.md` from an earlier role check → verified evidence and absolute prohibited claims, in place of the locally built ones here
