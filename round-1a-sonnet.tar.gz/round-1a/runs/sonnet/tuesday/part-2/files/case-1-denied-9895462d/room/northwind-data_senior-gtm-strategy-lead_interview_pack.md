# Interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer (both report to the same VP). **Format:** one 60-minute conversation. **Built on:** your notes only. Web research was refused this session, so nothing here comes from the web.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding to rehearse from, not a script. Answer slots are instructions for the interview: where one appears, answer from your own experience or say plainly that the step was not yours. Sections dropped because their conditions failed: prep triage (no prep time given), graded deliverables (none announced), grounding brief (no deep research), values cheat sheet (no values round, no published values in hand), delivery coaching (no assessment).

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether the background claims survive scrutiny, and attribution honesty |
| JD | The stated responsibilities and qualifications, including the gaps |
| CO | Company and strategy knowledge, thought at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

No VAL questions appear. No values round is named in your notes and no published values were available.

**Highest-ROI prep: C1.** Dan will very likely raise the sales-ops and quota-setting gap in some form. Rehearse it until it is boring. Then rehearse A1 and F2, the $400M figure.

**Requirement coverage**

| Requirement | Questions covering it |
|---|---|
| Own GTM strategy for two new product lines | C2, C4, D2, D3, E1 |
| Identify whitespace across land, adopt, expand, renew | D1, A5 |
| Run independent analysis in SQL and Tableau | A3, A2, A5 |
| Partner-motion design experience (required) | C3, A2 |
| Strong cross-functional influence | A4, B1, B4 |
| AI experience (a plus) | E2, D2 |
| Sales-ops and quota-setting fluency (not a JD line) | C1, F1 |

## Fit snapshot

The JD lines are the highlights you supplied, not the full posting. The evidence is quoted from your message, not from a CV.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | Your material says product strategy and ops, not GTM ownership, and the words stay there. Answer slot: the JD's two-product-lines line makes a probe on go-to-market work likely. If any of that work took a product to market, say what and which part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with product strategy and ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | The quote says you proposed the change and that it was credited with the uplift; it shows no analysis by lifecycle stage. Answer slot: the JD's four stages make a probe on how the opportunity was found likely. If it came from analysis you did, say how; if not, or it was not yours, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — your message | medium | [grounded] | discovery | The quote names the tools, not an analysis run independently. Answer slot: expect a request to walk an analysis end to end. If you ran one yourself, say what you wrote or built and what it decided; if the work was shared or there was none, say so plainly and name what you did do in those tools |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not the design of a partner motion; the words stay at the model. Answer slot: if you also set how the partner relationship worked (who does what, how it is supported), say how; if your work was the model and its use, say so plainly and stay there |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | none | No gap, but a summary line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: annual volume targets, set with cross-org consensus |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — your message | low | [inferred] | discovery | Daily use is all the quote says. Derived from the JD's plus-line and the stated Compass priority in your research note. Answer slot: name which tools and one thing you use them for; if daily use is the whole extent, say that plainly |
| F7 | Sales-ops and quota-setting fluency, the ground a Sales Strategy peer works in (role-family expectation, not a JD line) | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | A gap the candidate stated. Words: "I haven't had classic sales-ops or quota-setting experience." Then the adjacent work at its own scope (F5: annual volume targets, with cross-org consensus), with the pack's observation that your material says volume targets, not quotas. Then how you would learn it, said as a plan and never as a past |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says product strategy and ops, not GTM ownership. C2's slot stays inside that |
| Designed a partner motion | Inflated form of F4 | F4's quote at its own scope. The material says a revenue model used in negotiations, not motion design. C3's slot stays inside the model |
| Drove or delivered the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: you proposed the change and it was credited with the uplift. The material does not say who counted it or how |
| Ran independent SQL or Tableau analysis | Inflated form of F3 | F3's quote at its own scope: skilled in SQL/Tableau. A3's slot asks for the walk-through and allows that there was none |
| Built or led AI products or AI strategy | Inflated form of F6 | F6's quote at its own scope: uses AI tools daily |
| Set or carried sales quotas | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot |

## Reading the interviewer

Everything in this table is your description of Dan's profile. Nothing was verified by search.

| Observation | Source | Implication | Provenance |
|---|---|---|---|
| Self-describes as "relentlessly data-driven" | Your profile notes | Every number gets probed to its assumptions: A1 to A4 | [grounded] |
| Career spine in pricing and monetization | Your profile notes | Native language is packaging, pricing, unit economics: D3 and reverse question R1 | [grounded] |
| One early-stage-startup chapter | Your profile notes | Builder stories can land, and expect "scrappiness" probes on large-company pace: C4. A shared professional path is fair game; do not trade on shared identity | [grounded] |
| Peer, same VP | Your message | He is pricing what you cost and contribute to his work: B1, B2, B4, reciprocity R3 | [grounded] |

**Mirror opportunity:** his monetization spine sits beside F4's quote, "built a partner-level revenue model used in carrier negotiations". Use shared vocabulary (revenue, negotiation inputs) without stretching the model into a partner motion.

## Persona table

The loop is established by your words: one 60-minute conversation with Dan. No archetype fallback is used. Weights start from the peer-round prior (Peer Evaluator plus Prober) and are then adjusted by the signals above.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | Line-by-line numbers, two follow-ups deep | Highest. Peer prior, raised by "relentlessly data-driven". 5 questions | Know how each figure was counted and say plainly when you do not; name the weakest assumption before he does; offer an end-to-end walkthrough |
| B. Peer Evaluator | Seam-splitting, "what do you need from me", credit | High. Peer prior. 4 questions | Reciprocity framing; propose seam principles, not a seam you cannot know; disagreement shown with spine and tact |
| C. Skeptic | Quiet probing of the gaps | Medium-high. The stated sales-ops gap, partner-motion stretch and startup chapter all feed it. 4 questions | Rehearse C1 until boring; bridges only from adjacent evidence you actually stated |
| D. Case/Strategist | Live problems on Compass, whitespace, bundling and pricing | Medium. Not a peer-round default, tilted up by his pricing spine. 3 questions | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise respectfully |
| E. Conversational | Friendly opener, "what are you playing with in AI" | Medium-low. Every opener is still scored. 2 questions | A 90-second arc for the biography; treat casual AI questions as scored |
| F. Pressure | Time-boxes, "how much was actually you" | Low. Peers rarely interrupt, but the attribution probe arrives collegially. 2 questions | Pause, restate, hold through two follow-ups, then concede specifically |

Values/Behavioral is not banked. No values round or published values are in hand, and disagreement-with-peers behavior is covered in B1.

## Question banks

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've described a store-surface change credited with a ~$400M ARR uplift. Walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Tell what the quote says: you proposed the change, and it was credited with the uplift. Four slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption you would defend least, named before he does; which part was yours. For any you do not know, say plainly that you do not know how it was counted. Never name a method or baseline you cannot repeat under a second question | F2 carries the headline metric, the first target for a data-driven peer. EXP because it tests attribution and counting |
| A2 | "Walk me through the partner-level revenue model you built for carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats are the quote's: partner-level, a revenue model, used in carrier negotiations. Answer slot: the JD's SQL and Tableau line makes a probe on where the inputs came from likely. If you built the data pull or inputs yourself, say how; if someone else did, or there was no such step, say so plainly and stay with the model. Add the assumption in it you would defend least, in your own words, or say plainly you cannot name one | F4 is his native territory (monetization). EXP because it tests what was actually yours |
| A3 | "Tell me about an analysis you ran yourself, start to finish, in SQL or Tableau." | JD | [grounded] "skilled in SQL/Tableau" | The quote supports only that you are skilled in these tools. Pick an analysis where you wrote the queries or built the view yourself, the decision it fed, and what you would check differently. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Offer to walk it end to end | F3 is the JD's independent-analysis line, and this interviewer will test it. JD because it scores a stated requirement; open prompt because no quote carries a story |
| A4 | "Walk me through the annual volume targets you set with cross-org consensus." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats are the quote's: annual, volume targets, cross-org consensus. Answer slot: the JD's cross-functional influence line makes a probe on where orgs disagreed likely. If they did, say what and which part was yours; if they did not, or none of it was yours, say so plainly and stay with the targets. Say how the targets were counted only if you know | F5 and F7 meet here: it is your nearest evidence for the quota question. EXP because the claim has to survive follow-up |
| A5 | "Net revenue retention on a new line is flat while new-logo bookings are up. Walk me through what you pull first and why." | CASE | [generic] | Clarify first: which segments, which period, how retention is defined. Then split the cohorts, name the metric for each lifecycle stage, say what each cut would change, and where the data would come from. The question needs no claim about your past, so the guidance makes none | Data-driven delivery of the whitespace requirement, in the JD's own lifecycle terms. CASE because it is a live diagnosis; `[generic]` because it is a pattern |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between GTM strategy for new products and Sales Strategy, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Offer seam principles, not a seam you cannot know: who owns the question, who owns the data, how a disagreement goes to your shared VP. For the disagreement, only the quote is yours: you set targets with cross-org consensus. Answer slot: if there was a disagreement along the way, say what happened and what part was yours; if there was none, or it was not yours, say so plainly | Peer-round staple; JD because the role is cross-functional by design |
| B2 | "What would you need from me in your first 90 days?" | JD | [generic] | Name two needs and pair each with what it lets you do for his team (data access, the account view, an early read on targets). Reciprocity first. No claim about your past | Peers price the cost of the hire. JD because it scores role fit; `[generic]` because it is a pattern |
| B3 | "How do you handle credit when work spans teams? That ~$400M — whose number is it?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Use the quote's words: you proposed the change; it was credited with the uplift. Answer slot: which part of the change, the credit and the counting was yours, and who else shaped it, in your own words; if you do not know, or little of it was yours, say so plainly | The $400M returns in collegial packaging. EXP because it scores attribution |
| B4 | "Two new product lines will both want my team's time this quarter. How do we decide whose gets it?" | CASE | [generic] | Clarify the constraint and the stakes first. Offer criteria (revenue at stake, readiness, strategic priority), the data you would bring, and the escalation route to your shared VP. Show that you would make his trade-off easier, not yours. No claim about your past | Tests turf awareness with an equal. CASE because it is a live problem |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your background doesn't include classic sales-ops or quota-setting. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal.** Say the limit before he asks: "I haven't had classic sales-ops or quota-setting experience." Hold on what the quote carries: "I set annual volume targets with cross-org consensus." Do not claim these are the same thing. Follow-up 1, "isn't that the same?": hold, and say the pack's observation in your own terms, that volume targets are not quotas. Follow-up 2, "what do you do in month one so it doesn't cost my team?": say your own ramp plan, the first things you would learn and who you would ask. Follow-up 3, "and if it does not transfer?": concede specifically, then say what you would do. Never fold on what you did do | F7 is the biggest gap and the likeliest question. JD because it scores the role's sales-strategy ground; Skeptic because it probes a stated gap |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | Pick your actual weakest area, not a rehearsed humble one. If it is the sales-ops gap, say it in the same words as C1 and follow with a ramp plan. Do not name a weakness you are not sure of, or one the quotes do not carry, just to sound candid | Calibrated candor beats bluffing a competency he personally owns. JD because it scores the whole role |
| C3 | "When have you designed how a company goes to market through partners?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats are the quote's: a partner-level revenue model used in carrier negotiations. Answer slot: the JD makes partner-motion design a required item, so a probe on how the partnership worked is likely. If you also set who does what or how the partner route runs, say how; if your work was the model and its use, say so plainly and stay there. If no time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 is the required-experience line with the thinnest bridge, so it is where the JD presses. JD, with Skeptic delivery |
| C4 | "You've spent nine years at a large consumer-tech company. What changes for you at an enterprise B2B company our size?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Describe the differences you actually know, in your own terms. Answer slot: if any of those years involved business customers or small-team building, say what; if none did, say so plainly and say how you would learn it. Do not claim startup-style experience the quote does not carry | His startup chapter raises scrappiness probes. EXP because it tests the background |

### D. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a data product: where's the whitespace across land, adopt, expand and renew, and how would you find it?" | CASE | [generic] | Clarify the product and buyer first. Define each stage with its own metric, segment accounts, show where the data would come from in SQL and Tableau, then size and prioritize the gaps and name the risks. State your hypothesis early. No claim about your past | The JD's whitespace line as a live problem. CASE with JD content |
| D2 | "Compass, the AI copilot, is a stated priority. Sketch the GTM plan: what do you need to know first?" | CO | [grounded] | Clarify the objective and buyer, segment, choose the approach, name the metrics and risks. Challenge one premise respectfully, for example whether it is sold alone or inside existing accounts. Say what you do not know. The Compass priority comes from your research note and was not verified | A strategy-grounded CO question. Grounded on your note only; it goes generic if the note is stale |
| D3 | "A much larger platform vendor bundles a competing capability into its suite. How do you package and price a new line so it still earns its place, while the company is also pushing for profitability?" | CO | [grounded] | Clarify the use case. Lay out packaging and pricing options and what each trades off, including a differentiation that a bundle cannot match. Name what you would say no to, not only what you would do. Priorities and the bundling threat come from your note and were not verified | His pricing spine makes this his home turf. CO because it tests company altitude |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey. Why this move, and why now?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc from the quote: consulting, then product strategy and ops at the consumer-tech company. Give your actual reason for the move, in your own words; do not use a rehearsed one that is not yours | A casual opener that is scored for economy and consistency. EXP because it tests the story |
| E2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" | Name the tools and one real use, in your own words. Answer slot: if you build with them, say what; if daily use is the extent, say so plainly. Never imply AI product work the quote does not carry | The JD's plus-line, asked casually. Low confidence, so coached only as a clarify note |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you rather than someone who has carried a number in sales strategy?" | JD | [grounded] "set annual volume targets with cross-org consensus", "built a partner-level revenue model used in carrier negotiations" and "No classic sales-ops or quota-setting experience." | Pause, restate. Hold: "I set annual volume targets with cross-org consensus, and I built a partner-level revenue model used in carrier negotiations." Concede specifically: "I haven't had classic sales-ops or quota-setting experience." Let him draw the inference. Hold through two follow-ups by returning to the quotes, not by adding to them | F7 returned as a stress question. JD because it scores fit; Pressure because it tests composure |
| F2 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold at the quote's scope: you proposed the change; it was credited with the uplift. Answer slot: which part of the change, credit and counting was yours; if little of it was, or you do not know how it was counted, say so plainly. Concede only what is true. Do not fold on the proposal | The attribution probe that exists to catch inflation. EXP because it scores precise honesty |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career runs through pricing and monetization. Where do pricing decisions and GTM plans pull against each other on a new product, and what do you wish the GTM side brought you earlier?" | Ties to his own path and turns an interrogation into a peer conversation |
| R2 | "You've also had an early-stage chapter. How do you approach launching a line before the data is clean?" | Another of his own path; invites a builder conversation without trading on shared identity |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer; shows you think about his load |
| R4 | "With bundling by a larger vendor the main competitive threat, where has it shown up in deals so far?" | Shows you did the strategy homework and asks for what only he knows |
| R5 | "What does good look like six months in for the two new lines, and which numbers will we both be judged on?" | Makes the shared-VP relationship concrete |
| R6 | "How do you and our VP split decisions on targets and pricing for new products today?" | Surfaces the real decision rights, which no document shows |

## Sources

**Provided documents:** your message (JD highlights, candidate summary, interviewer profile as described, research note on priorities and the bundling threat). No dossier.

**Searches sent (all refused, none returned results):**

- "Northwind Data company values principles" — refused
- "Northwind Data interview process strategy GTM" — refused
- "Northwind Data Compass AI copilot enterprise expansion profitability" — refused
- "Dan Kovac Northwind Data Director Sales Strategy" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Search refused. Would have supplied official value names for a cheat sheet; none is built |
| 2. Interview process | unavailable | Search refused. The loop is established by your words (one 60-minute conversation), so persona weights rest on that |
| 3. Strategy and recent news | unavailable | Search refused. D2 and D3 rest on your research note, unverified |
| 4. Interviewer footprint | unavailable | Search refused. The interviewer read rests on your profile notes only |
| 5. Representative JD | skipped | The JD highlights you supplied fix the fit snapshot and JD-tagged questions |

## Upgrade menu

- The full JD text → every row currently resting on highlights re-grounds on its own wording, and any gate terms (location, travel, schedule, pay) would appear as rows; mid-list requirements get questions
- Priya's CV → evidence cells quote the CV instead of your summary; scaffolds in A3, C3, C4 and E2 can become story maps; F1 to F4 may firm up
- Priya's answers to the slots in A1, A2, A4, B3, C3 and F2 (how the $400M was counted, what part of the model and targets was hers, whether she designed any partner motion) → F1, F2 and F4 regenerate with her own facts
- Search permission, then a re-run of research → official values, the loop and Dan's public footprint; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief for D2 and D3
- Recruiter's guidance for this conversation (any stated focus areas or pre-declared deliverable) → coverage tuned to what Dan has been told to test
- Dan's public talks or posts → his recurring themes become likely questions and sharper reverse questions
- A `tuesday-dossier.md` → verified evidence and prohibited claims arrive pre-graded, and the highest-ROI objection is evidence-derived rather than inferred
