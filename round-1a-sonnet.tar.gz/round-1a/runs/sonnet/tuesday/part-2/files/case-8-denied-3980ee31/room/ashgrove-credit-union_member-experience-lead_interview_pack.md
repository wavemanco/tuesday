# Interview pack: Member Experience Lead, Ashgrove Credit Union

**For:** Dara. **Mode:** loop, three rounds on 26 November 2026 (the recruiter's email is the loop source). Prepared 17 November 2026.

| Round | Who | Length | Shape |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Screen |
| 2 | Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | Panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation. Also the values round: scored against the four values |

Interviewers beyond their roles are not yet assigned, so there is no interviewer read in this pack.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Every question has a persona (its sub-table) and a type tag.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your claims survive scrutiny: what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude: strategy, competition, recent moves |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traces to a document you gave me; `[inferred]` is derived from a grounded fact, with the derivation named; `[generic]` is a pattern for the problem with no claim about Ashgrove or about you.

Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview: it names what an interviewer is likely to probe, then gives two honest branches — say what you did in your own words, or say plainly that it was not yours or did not exist, and return to what you did do. Both branches are strong answers. Rehearse only what you actually did.

## Prep triage

Nine days, 17 to 26 November. All three rounds fall on 26 November, so the same few stories have to work three times.

1. **Days 1 to 2: D2, with B1.** The contact-centre objection is the highest-ROI prep in this pack. It will be asked in some form in rounds 1 and 2. Say the plain acknowledgment aloud until it is boring, then rehearse the two follow-ups.
2. **Days 2 to 4: pick the real stories for G1 to G4 and C1, C2, C4.** Your message carries no specific complaint, decision or conversation, so these are selection scaffolds. One real story can serve several values. Choose them from your own history now; nothing in this pack can supply them.
3. **Days 4 to 6: H1, the 20-minute case.** Practise the structure aloud against a 20-minute clock, including the first two minutes of clarifying questions. A spoken run-through with someone playing the panel is worth more than rereading.
4. **Day 6: D1 and D4.** Know what the monthly complaints spreadsheet counted, which tool it was built in, and what made the complaints in the branch log formal.
5. **Days 7 to 8: E1, E2, H3 and the grounding brief.** Read the four strategy points until you can speak to each without notes.
6. **Day 9:** one run of A1 and the reverse questions for each round.

Everything else is insurance.

## Fit snapshot (shared across all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD, branch side | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's formal log, not a process across branches, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end, across-branches line makes a probe on how far your log reached likely. If the log, or anything you did on it, touched branches other than yours, say which and what part was yours, in your own words; if it did not, say so plainly and stay with your branch's log |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD, contact-centre side | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your sentence shows a monthly complaints spreadsheet, and not what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours tracked. If either was in it, say how it was counted, in your own words; if neither was, say so plainly and stay with the spreadsheet and how your regional manager uses it |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The sentence says spreadsheet, not which tool, so the words stay at "spreadsheet". Answer slot: if it was built in Excel, say so and say what you did in it, in your own words; if it was another tool, or you did not build the formulas yourself, say so plainly and stay with the spreadsheet you built |
| F5 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap, but a statement with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: six years in retail banking, the last three as a branch supervisor, because a named period beats an adjective |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | The sentence says formal, and not what made the complaints formal or what governed them. Answer slot: the JD's word regulated makes a probe on what the formal log had to meet likely. If you know, say what it was and what part of it was yours, in your own words; if you do not know, or the log was not governed by anything beyond branch practice, say so plainly and stay with the log you handled |
| F7 | "coach branch supervisors on escalations" — JD | "I trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and the escalation script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's supervisors line makes a probe on who else sat in those sessions likely. If anyone beyond new tellers did, say who and in what role; if not, say so plainly and stay with the new tellers |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare for it, said as a plan and never as a past. Never a claim to presenting at that level |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital work. Answer slot: if you have worked with any digital or online team on anything members used, say who and what part was yours, in your own words; if you have not, say so plainly and say what you would ask a digital team first |

No requirement in the JD is a gate: the 4+ years line is a length of experience, graded like any other row.

## Grounding brief: Ashgrove's July 2026 strategy

The four points are as you passed them on; I have not seen the full brief. They are under six months old on the interview date.

| Point | What the brief says (as you gave it) | Where it shows up in this pack | Provenance |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | E1, E2, round 2 reverse question 3 | [grounded] |
| Branch consolidation | Consolidate eight branches into five hubs over 2027 | H3, round 3 reverse questions | [grounded] |
| New product | Launch a small-business lending product in Q1 2027 | Round 2 reverse question 6 | [grounded] |
| Competitive pressure | The main competitive pressure is app-only banks | E1, E2 | [grounded] |

Everyone who prepares will have these four points. Bring one of them to show you did the reading, then bring one thesis of your own, with reasons.

---

# ROUND 1: the recruiter (30 minutes)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (A) | Friendly, unstructured; logistics and motivation questions | Highest. A recruiter screen's prior is Conversational plus a light Skeptic, and the recruiter's email names this as a 30-minute conversation. The risk is treating it as unscored | A 90-second arc for the biography question; treat casual questions as scored; use the reverse-question slot |
| Skeptic (B) | Quiet check of the gaps the JD makes obvious | Lower, but present: this is where a gap gets noticed first | Say the limit plainly in your own words before it is pulled out of you, then give the plan |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far, and what draws you to this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Three beats the quotes state, in your own words: six years in retail banking; the last three as a branch supervisor; the branch's formal complaints log you handled, and the monthly spreadsheet your regional manager uses. Then the draw: why this role, in your own words, with no added scope on any beat. About 90 seconds | The biography question opens most screens; F5, F1 and F3 are the rows it draws on |
| A2 | "What do you know about where Ashgrove is heading?" | CO | [inferred] derived from the brief's four points as you passed them on | One point to show you did the reading: the 40% digital target by 2028. Then your own thesis, labelled as yours: as more service moves to digital channels, a complaint is more likely to begin in the app and reach a person later, so the complaints process has to follow the member across channels. Ask whether that matches how they see it; this is a view, not a claim about Ashgrove's plans | The brief is public to every candidate, so the differentiator is the thesis, not the recital; CO because it scores homework depth |
| A3 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give your own figure, or ask what the role's band is before you name one. Say it once, plainly, and stop | Pay is a standard recruiter-screen check; JD because it concerns the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words, and anything about it that is flexible only if it truly is | A standard recruiter-screen check on the listed job's terms |
| A5 | "Where would you be working from, and does the branch and contact-centre footprint of this role work for you?" | JD | [generic] | Logistics slot: say where you are based and what travel or commuting you can really do. Your own answer; the posting you gave me does not state a location or travel pattern, so ask the recruiter what it expects | The posting's footprint (branches and contact centre) makes this likely; location is a standard screen check |
| A6 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: state your real reason, in one or two plain sentences. Keep it about where you are heading only if that is also true, and add nothing you would not say to your current employer | The reason for leaving is the screen's motivation-consistency check; EXP because it tests whether your story holds together |
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" | The highest-ROI rehearsal in this pack starts here. Say it plainly: "I haven't worked in a contact centre." Then a plan in the future tense, in your own words: what you would look at first and whom you would ask. Do not add a claim about contact-centre work | F2 is the gap the JD makes most visible, so this question arrives in some form; JD because it scores the stated requirement |
| B2 | "You'd be presenting to senior leaders here. Have you presented at that level?" | JD | [grounded] "I've never presented to anyone above regional level" | Say it plainly: "I haven't presented to anyone above regional level." Then how you would prepare, as a plan, in your own words. Do not describe a past presentation you did not give | F8 is a stated gap against a stated JD requirement; JD because it scores that line |

## Reverse questions for round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "Is there anything I can see beforehand about the complaint escalation case in round 3?" | The recruiter can answer this in one email, and it turns an unknown into a known |
| 2 | "Is there anything the Head of Member Services would like me to have read before we meet?" | Shows you are preparing for the next round, and gives you the one thing the recruiter can steer |
| 3 | "How is complaints work split today between the branches and the contact centre?" | Shows you are thinking end to end, and gives you the shape of the contact-centre side before round 2 |
| 4 | "Is this a new role or a replacement?" | Tells you what has been built and what has not |
| 5 | "What is the timeline from the 26th to a decision?" | Practical, and it closes the conversation on the next step |

---

# ROUND 2: Head of Member Services, your would-be manager (45 minutes)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (C) | Scenario probes: "Tell me about a time…" | Highest. The recruiter's email calls this round mostly behavioural, and that outranks the hiring-manager prior | Choose stories now; "we" for context, "I" for your contribution; where a story did not land well, say so |
| Skeptic (D) | Quiet, persistent probing of the gaps and the numbers | High. A manager is buying capability and weighing gaps; F1, F2, F3 and F6 are the rows to probe | Rehearse the contact-centre objection until it is boring; hold, then concede only what you stated |
| Case / Strategist (E) | Live problems from the role | Medium. The hiring-manager prior puts it high, the behavioural description pulls it down, and the role's digital and reporting lines make it likely | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a member's complaint had to be escalated, and what your part was." | EXP | [generic] | Selection scaffold: pick a complaint from your own history that went further than the first conversation. It needs a named stake for the member, the moment you acted, what changed afterwards, and which part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is that you handled the branch's formal complaints log, or how you would handle it | The JD's escalation and complaints lines make this likely; your message names no specific complaint, so the scaffold is the honest form. F1 and F6 are the rows behind it |
| C2 | "Tell me about a time you had to explain a complaint outcome to a member who was unhappy with it." | VAL | [generic] | Selection scaffold: pick a conversation where the member's reaction was real and your explanation was needed. It needs the outcome, how you said it, and where it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The published value Plain Words raises this theme, and a manager can ask it before the panel does; VAL because it scores behaviour against that value |
| C3 | "Tell me about a time you helped a colleague handle a difficult escalation." | EXP | [grounded] "I trained new tellers on our escalation script" | Story-mapped on F7: the new tellers and the escalation script are the beats the quote states; tell them in your own words. Answer slot: the JD's supervisors line makes a probe on who else sat in those sessions likely. If anyone beyond new tellers did, say who and in what role; if not, say so plainly and stay with the new tellers | F7 is the nearest evidence to the JD's coaching line; EXP because it tests what was actually yours |
| C4 | "Tell me about a time you delivered an unpopular truth to someone more senior than you." | VAL | [generic] | Selection scaffold: pick a moment where the truth was unwelcome and you said it anyway. It needs who it was, what you said, how it was received, and the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. Choose a story where the hard truth actually landed | A standard Values/Behavioral stem that fits a role reporting to senior leaders; the scaffold stays open because your message carries no such moment |
| D1 | "Walk me through the monthly complaints spreadsheet you built: what is in it, and how your regional manager uses it." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3 and F4: you built it, it is monthly, it is about complaints, and your regional manager uses it. Tell those in your own words. Answer slot: the JD names volumes and resolution times, so expect a probe on what it counted. If either was in it, say how it was counted, what it is sensitive to and which assumption you would defend least; if neither was, say so plainly and stay with the spreadsheet. Say which tool it was built in, and what you did in it, in your own words | The sentence is the evidence for the JD's reporting and Excel lines; the defend-the-number slots apply because the spreadsheet is the nearest thing to a figure in your material |
| D2 | "This role owns complaints across branches and the contact centre. What is your experience of the contact-centre side?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | The highest-ROI prep in this pack. Say it plainly: "I haven't worked in a contact centre." Then the one thing the quotes carry, at its scope: "I handled the branch's formal complaints log." Follow-up one, "so how would you own something you haven't worked in": hold, with the branch side as stated and a plan in the future tense, in your own words, of what you would look at first and whom you would ask. Follow-up two, "what if the contact-centre team resists a branch person": concede only what you said, that you would be learning their work, and do not fold on the branch side. Answer slot: if you have dealt with contact-centre staff on a member's complaint, say how and what part was yours; if you have not, say so plainly. Never claim to have handled calls | F2 is the gap and F1 the nearest evidence. This question arrives in some form in both round 1 and round 2, so it gets the most follow-up levels and the exact concession wording |
| D3 | "What have you had responsibility for beyond your own branch?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: the JD's across-branches line makes this likely. If the spreadsheet covered branches other than yours, say which and what part was yours, in your own words; if it did not, or the coverage was not yours, say so plainly and stay with the spreadsheet your regional manager uses | F1 is the end-to-end requirement and your material says one branch; the slot lets the premise be false |
| D4 | "The JD asks for experience handling regulated complaints. What made the complaints in your branch's formal log formal, and what governed how you handled them?" | JD | [grounded] "I handled the branch's formal complaints log" | Story-mapped only to the quote: you handled the branch's formal complaints log, in those words. Answer slot: if you know what made them formal and what governed them, say so and say what part was yours; if you do not know, or nothing beyond branch practice governed them, say so plainly and stay with the log you handled. Do not name a rule you cannot stand behind | F6 is the row; the JD's regulated is the raising source, so the question presupposes only that a formal log existed |
| E1 | "We are aiming to move 40% of member service to digital channels by 2028. What happens to complaints as that happens?" | CO | [grounded] the brief's digital-shift point as you passed it on | Structure it: clarify what counts as a complaint in a digital channel and where it lands now; objective; which channels and which kinds of complaint; approach; the monthly numbers you would watch (volumes and resolution times, the JD's two measures); risks, including members who start in the app and end up needing a person. Mention app-only banks as the brief's named pressure, then give one thesis of your own and challenge one premise respectfully. This question asks about no past of yours, so the guidance makes no claim | A strategy-grounded CO question from the brief, and the one most candidates cannot touch |
| E2 | "Sketch how you would work with the digital team on a self-service route for a member who wants to raise a complaint. What do you need to know first?" | CASE | [grounded] the JD's self-service journeys line | Clarify before structuring: who raises complaints online now, what the member is told, who owns the case next. Then objective, segmentation, approach, metrics, risks. Use plain words in any wording a member would read: the published value Plain Words says if a member needs it explained twice, it was written wrong. Answer slot: if you have worked with any digital or online team, say who and what part was yours; if not, say so plainly and say what you would ask a digital team first | F9 is the silent row; the JD's self-service line is the raising source, so the slot lets the premise be false |
| E3 | "You would present the monthly complaints report to our senior leaders. What would the first page tell them?" | CASE | [generic] | Structure it: start with the question the leaders will ask, then the two measures the JD names, volumes and resolution times, by channel, the trend, what has changed and what you are asking them to decide. One page, plain words. Your message gives a spreadsheet and no presentation above regional level, so say how you would prepare, as a plan, if asked | F8 and F3 meet here; CASE because it is a live problem set in the role |

## Reverse questions for round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "Where do complaints get stuck today between the branches and the contact centre?" | Invites the manager to hand you the problem you would own, and shows you think end to end |
| 2 | "What would a good first 90 days look like for this role?" | Sets expectations, and gives the contact-centre ramp a place to be said openly |
| 3 | "How does the 40% digital target change what the complaints process needs to do by 2028?" | Ties the role to the brief and shows you read it with the role in mind |
| 4 | "Which monthly numbers do senior leaders actually look at today, and which would you change?" | Ties to the reporting requirement and to the senior-leader audience you are being asked about |
| 5 | "Who in the contact centre would I work with in my first weeks?" | Turns the gap into a plan the manager can help with |
| 6 | "The brief says the small-business lending product launches in Q1 2027. What will that mean for member complaints?" | Shows you read the brief past the headline; ask it only if you have room |

---

# ROUND 3: panel of two branch managers (60 minutes, values round, 20-minute case)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (G) | Scenarios mapped to Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | Highest. The recruiter's email says the panel scores against the four values | One story per value where a quote carries one, a selection scaffold where none does; "we" for context, "I" for contribution |
| Case / Strategist (H) | The 20-minute complaint escalation case, plus strategy questions | High. The recruiter's email names the case; the brief's branch consolidation is a branch manager's own subject | Clarify first; say the structure aloud; time-box yourself |
| Peer Evaluator (J) | Seam-splitting between your role and a branch manager's; credit-sharing | Medium. Branch supervisors, whom the role coaches, work in the managers' branches, so the seam is where they would probe. This is my inference, labelled as such | Reciprocity: what you bring their branches, not only what you need; propose seam principles rather than pretending to know the seam |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [generic] | Selection scaffold, for Members First, Always: pick a decision where the member's side and the branch's side pulled apart. It needs the member's stake, what you decided, what it cost, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The published value raises this theme; your message carries no such decision, so the scaffold is the honest form |
| G2 | "Tell me about a time a member needed something explained twice, and what you did about it." | VAL | [grounded] "I trained new tellers on our escalation script" | For Plain Words: the quote carries the script and the new tellers and nothing about members or wording. Answer slot: the published value makes a probe on whether you ever changed wording because members needed it explained twice likely. If you did, say what and what part was yours; if not, say so plainly and stay with training new tellers on the script. If no such time comes to mind, say so, then give the nearest thing your material carries, or how you would handle it | F7 is the nearest sentence, at its own scope; the slot lets the premise be false |
| G3 | "Tell me about a time you weighed what a number said against what a branch or a town needed." | VAL | [generic] | Selection scaffold, for Neighbours, Not Numbers: pick a moment where a target and a local need diverged. It needs the number, the local need, your decision, and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The published value raises this theme; the scaffold stays open because your message carries no such moment |
| G4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | For Own the Fix: the quote carries handling the log, not any one problem or its end. Answer slot: the published value makes a probe on a single case you followed to the end likely. If you followed one, say what it was, where it started and ended and what was yours; if none comes to mind, or it was not yours to follow, say so plainly and stay with the log you handled | F1 is the nearest sentence; the slot allows the premise to be false |
| H1 | "Here is a case. A member's complaint has passed between a branch and the contact centre more than once, and the member now says they will close their account. How do you take hold of it?" | CASE | [generic] | Rehearse the structure aloud for 20 minutes. Clarify first: who holds it now, what the member has been told, what has been promised, and what deadlines apply to the process. Objective: the member's problem solved with one named owner. Then segment, approach, record, metrics, risks. Name the first conversation with the member and in what words, and say what you would ask the supervisor who handled it first. Challenge one premise respectfully. The actual case is unknown to me, so rehearse the structure, not this scenario | The recruiter's email names a 20-minute case on a complaint escalation; Own the Fix and Plain Words are scored in it |
| H2 | "A branch supervisor has escalated two complaints late this quarter. How do you coach them?" | CASE | [generic] | Structure it: listen first, find what is behind it, agree one specific next step, check back. This asks about no past of yours, so the guidance makes none | The JD's coaching line makes this live; CASE because it is a problem set in the role |
| H3 | "We are moving from eight branches to five hubs over 2027. What do you do with the complaints process while that happens?" | CO | [grounded] the brief's branch-consolidation point as you passed it on | Structure: what changes for a member whose branch closes, what stays local, what is recorded and where. One thesis of your own: members of a closing branch are likely to feel unheard, so the process needs a local face; link it to Neighbours, Not Numbers, as your view and not as the managers' position. Ask what they expect first | A strategy-grounded question on the managers' own subject; the thesis is inferred from the brief's figures |
| J1 | "Where is the seam between your role and a branch manager's, and what happens when we disagree?" | JD | [generic] | Propose principles, not the seam itself: who owns the member, who owns the record, how a disagreement is raised and settled. Reciprocity: say what you bring their branches. This asks about no past of yours, so the guidance makes none | A standard Peer stem; the role's coaching line puts it on the seam |
| J2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A principle: name who did what, early and aloud; "we" for context, "I" for your own part. Your message carries no instance, so do not tell one you cannot stand behind; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard Peer stem; VAL because it scores behaviour toward colleagues |

## Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold (G1): a decision where member and branch pulled apart, with its stake, decision, cost and end. If none comes to mind, say so plainly, then give the nearest thing your material carries (F1, "I handled the branch's formal complaints log"), or how you would handle it |
| Plain Words | If a member needs it explained twice, it was written wrong | F7: "I trained new tellers on our escalation script", at that scope only. Answer slot in G2 for the rest |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold (G3): a target against a local need. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log", at that scope only. Answer slot in G4 for a case followed to its end |

## Reverse questions for round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new person in this role do in their first month that would genuinely help your branch?" | The reciprocity question: it puts what you bring their branches before what you need |
| 2 | "Which escalation do your supervisors find hardest, and what do they wish they had been told?" | Aims at the coaching line, and gives you the managers' view of the supervisors you would coach |
| 3 | "How will the move from eight branches to five hubs change what branch managers need from the complaints process?" | Ties to the brief, and to Neighbours, Not Numbers, on the managers' own ground |
| 4 | "How do your branches hear back about a complaint that was fixed somewhere else?" | Asks about the hand-off the role would own, as a question and not a claim |
| 5 | "What does Own the Fix look like here when it goes well?" | Uses their value by its name and asks for an example you can hold onto |

---

## Requirement coverage

| Requirement (from the JD) | Questions |
|---|---|
| Own the complaints process end to end across branches | D3, D2, H1 |
| ...and the contact centre | B1, D2 |
| Report monthly on volumes and resolution times | D1, E3 |
| Coach branch supervisors on escalations | C3, H2 |
| Work with digital teams on self-service journeys | E1, E2 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | D4, C1 |
| Confident presenting to senior leaders | B2, E3 |
| Comfortable with Excel reporting | D1 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log". The limit is the pack's observation, not words for you: the material says the branch's log, not a process across branches |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: "I trained new tellers on our escalation script". The limit is the pack's observation: the material says new tellers, not supervisors |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses". The limit is the pack's observation: the material does not say what it counted |
| Handled regulated complaints | Inflated form of F6 | F6's quote at its own scope: "I handled the branch's formal complaints log". The limit is the pack's observation: the material says formal, not regulated |
| Presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." No slot |

## Sources

Provided documents: the JD; Ashgrove's four values as you copied them on 17 November 2026 from ashgrovecu.org/about/values (not fetched, since the text was in hand); the recruiter's email on the three rounds; the four points from Ashgrove's July 2026 strategy brief as you passed them on; your background in your message. No `tuesday-dossier.md` was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the values cheat sheet and the VAL bank |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email names the rounds, who runs them, their lengths and the panel's scoring, which fixes the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` | skipped | The strategy points you passed on, from a brief under six months old, fix the CO questions. Anything beyond those four points would be an L2 item |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer name was given, only roles, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A CV, or a few lines on one real complaint you escalated at the branch → F1, F3, F4 and F6 firm up, and the scaffolds in C1, C2, C4, G1 and G3 can become story-mapped rows
- The recruiter's note on whether the round 3 case scenario is shared in advance, or what it covers → H1 stops being a pattern and becomes the actual case
- The names of the Head of Member Services and the two branch managers → an interviewer read and a persona weight per panel member, plus reverse questions tied to their paths
- The full strategy brief, rather than four points → E1, E2, H3 and the grounding brief gain current detail
- Any recruiter guidance on focus areas for rounds 2 and 3 → coverage moves from round-type priors to what they said
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and a prohibited-claims list from that session would sharpen the fit snapshot
