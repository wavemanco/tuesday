Reading the prep rules is done. Now I'm running the four research searches (values, interview process, strategy, interviewer) before building your pack.
Femi, your prep pack is saved as `saltmarsh-games_live-operations-producer_interview_pack.md` in the working directory. It has 20 questions, with answer guidance for each.

I assumed Tobias is your future manager, because you gave his title but not his relationship to the role. Web search was refused, so nothing in the pack comes from Saltmarsh Games itself. That means no values, interview loop, strategy or Tobias background, and the pack says so rather than guessing. The persona weights rest on the hiring-manager pattern, not this company's real process.

- **Highest-ROI prep:** B1, "You haven't worked on a game with in-app purchases." Rehearse conceding it plainly, then giving your own ramp plan, without claiming any adjacent experience.
- **Second-likeliest probe:** the jump from one title's weekly drops to live events on two titles (B2), and presenting retention numbers versus owning the KPIs (C2).
- **Your strongest material:** the content-drop calendar you ran, the release checklist QA still uses, and the retention numbers you presented. The pack quotes your own sentences and keeps each claim at that scope. It doesn't say you managed releases, owned KPIs or led anyone.
- **Where I left blanks for you:** I didn't invent details in places your notes are silent, such as whether you coordinated design, art, engineering and community, or whether the puzzle title ran as a live service. Those are "answer slots" where you say what's true, including "that wasn't mine."

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, a skip-level or someone from another function, and did the recruiter name any focus areas or a task to prepare? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** 60 minutes, Friday. Built as a hiring-manager round: your message names his title and not his relationship to the role, so this is an assumption, and the persona weights below move if it is wrong.
**Basis:** The JD you pasted and your own background notes. Web research was refused this run, so nothing here is drawn from Saltmarsh Games itself. Company, values, loop and interviewer facts are absent rather than guessed (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. The guidance is scaffolding, not a script: every claim about your past rests on a sentence you wrote, quoted beside the question. Where the material does not show something, the guidance is an answer slot, an instruction to say what is true in your own words, including that a step did not exist or was not yours.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows values, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny and attribution probes |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth and altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role, live |

The single highest-ROI item in this pack is **B1** (in-app purchases). Rehearse it until it is boring.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, not a live-events calendar and not two titles. The words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on running more than one calendar likely. If you ever kept a second title's calendar going, say how you managed both; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | The quote does not say who the calendar was run with, so your material does not show coordination across those four teams. Answer slot: the JD names design, art, engineering and community, so expect a probe on how you worked with each. If you worked with any of them on the weekly drops, say which and how, in your own words; if some were not involved, or the coordination was not yours, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly numbers, not that you reviewed single events or owned KPIs. The words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-KPIs line makes a probe on who defined the numbers likely. If any were yours to define or choose, say which; if you presented figures someone else defined, or there was no review of individual events, say so plainly and stay with the presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Lead in the quote's own terms: "I wrote the release checklist, and our QA team still uses it." Your material says wrote and in use. It does not say you ran it on each release, so "manage" stays the JD's word and not yours. Expect a probe on how it is used |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | The quote gives the four years and the title. It does not say whether the game ran as a live service, and "associate producer" stays your title, not "producer". Answer slot: if the puzzle title was operated as a live service, say what that meant in your own work, in your own words; if it was not, say so plainly and stay with the weekly drop calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. A CV-style line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you ran it, weekly, for two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. "Presented" is not "comfortable", so expect a probe on which measures were in those numbers and how they were counted (answer slot at C1) |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Reword only the quote: "I wrote the release checklist, and our QA team still uses it" is a written document in use. Your material shows no other writing, so the pack offers none |
| F9 | Leading a team (role-family question; the JD names no direct reports) | "Never led a team" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't led a team." Then how you would get a result from design, art, engineering and community without authority over them, said as a plan and never as a past |
| F10 | Experience with in-app purchases (no JD line; asked because these are mobile titles) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to purchase or monetization work |

## Persona weights

No loop source establishes this company's loop (research was refused), so the weights rest on the hiring-manager relationship prior and a generic screen-then-manager-then-panel archetype. Treat them as a pattern, not this company's documented process. No interviewer signals were available, so none adjust them.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Live problems from the role: plan this, diagnose that | Highest. The hiring-manager prior puts it first, and the JD is built from planning, coordinating and reviewing tasks. 5 questions | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Quiet probing of gaps | Highest. Your own notes name two gaps (team leadership, in-app purchases), and the JD scope exceeds one title's drop calendar. 5 questions | Rehearse the most predictable objection until it is boring; calibrated candor over bluffing |
| Data-Driven Prober (C) | Walk-throughs of the retention work | Medium. The JD names retention metrics and your material includes presenting them. 3 questions | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational (D) | Friendly opener, casual JD probes | Medium. Often the first ten minutes; still scored. 3 questions | A 90-second arc for the biography question; treat casual questions as scored |
| Pressure (E) | Time-boxed challenges, attribution probes | Lower. Less typical in a first conversation with a function head, but cheap to rehearse. 2 questions | Pause, restate, hold the position through two follow-ups, concede specifically |
| Values / Behavioral (G) | Scenario probes | Lower. No published values were available and no values-style round is detected. Themes come from persona stems only. 2 questions | Selection scaffolds with an honest branch; "we" for context, "I" for contribution |

The Peer Evaluator persona is omitted: a Head of Live Operations is not a plausible peer. If it turns out Tobias is a peer or cross-functional, say so and the banks are rebuilt.

## Question banks

### A. Case / Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You would run the live-events calendar for two of our titles. What do you need to know first, and how do you structure your first eight weeks?" | CASE | [generic] | Clarify before structuring: what each title's goals are, the cadence each runs at, what team capacity looks like. Then objective, segmentation by title, approach, how events that collide get sequenced, metrics, risks. State one premise you would challenge. The question needs no claim about your past, so the guidance makes none | JD requirement F1 asked as a live problem; CASE because it scores structure, not history. Generic pattern, not a fact about Saltmarsh |
| A2 | "An update is due Thursday. Engineering says a build is at risk, art says assets are late, and community has already announced the event. Walk me through the next 24 hours." | CASE | [generic] | Structure it: confirm what is actually at risk, list the options (cut scope, delay, ship partial), say who decides each, what players are told and by whom, what the release checklist must confirm, and what you would record for the post-event review. No claim about your past is made | The JD's coordinate-four-teams line (F2) as a decision under pressure; CASE because it asks no history |
| A3 | "Day-three retention for a weekend event came in 20 percent below the previous event's. Diagnose it." | CASE | [generic] | Clarify the definition and the cohort first. Then compare against the baseline, check build version and bugs, acquisition mix, timing and seasonality; say what you would check first and why, and what you would tell the team before you know. Think aloud | Retention requirement (F7) as a live problem; the persona stem for the Case persona |
| A4 | "How would you run the post-event review for an event that underperformed? What goes in it, who is in the room, what happens afterwards?" | CASE | [generic] | Structure: the goals agreed before the event, the data, what was learned, decisions, owners and follow-ups. Say which KPIs you would propose and why, and that you would agree them with the teams beforehand. The question asks no history; if you have done something close, say what it was in your own words (F3 slot) | The JD's own-the-review line (F3); CASE because it is a method question |
| A5 | "How would you structure the release checklist for a live update, working with QA?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Open with the quote's own terms: you wrote it and QA still uses it. Then the method: what a go/no-go needs, who signs off, what gets re-tested after a late change. Never say you managed releases through it; your material says wrote and in use | JD requirement F4; CASE delivery on a JD item the quote partly reaches |

### B. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. If our events are tied to purchases, how do you ramp?" | JD | [grounded] "never worked on a game with in-app purchases" | **Highest-ROI prep in the pack.** Level 0, concede first and plainly: "I haven't worked on a game with in-app purchases." Level 1, if pressed on how you would ramp: give your own three concrete first steps (what you would read, who you would ask, what you would look at first in the data); these are a plan, and nothing in your material is a past. Level 2, if pressed on what you do bring: return to what you stated at its own scope, "I ran the weekly content-drop calendar for our main title" and "I presented the monthly retention numbers to the studio head", and let the interviewer draw the link. Level 3, if pressed again: do not add experience; restate the gap and the plan. The limit, named before it is asked for: nothing in your material covers purchases, pricing or revenue targets, so claim none of it. Hold the plan, concede the gap | F10 is the likeliest place to be probed at a mobile studio, so this objection arrives in some form; JD because it tests whether the role can be done with the gap |
| B2 | "You ran one title's weekly content drops. We are asking for live-events calendars for two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say it at its scope: one main title, weekly drops, two years. Answer slot: the JD's two-titles line raises a probe on more than one calendar. If you ever kept a second title's calendar going, say how; if not, say so plainly and stay with the calendar you ran. Then say what you would change, as a plan: what you would ask first about the second title, how you would keep both calendars visible side by side | F1 and the JD scope jump; JD because it scores the stated requirement |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team" "never worked on a game with in-app purchases" | Pick one honestly and give the ramp. The two gaps your material states are team leadership and in-app purchases; if you answer with one, use B1's concession wording and a different ramp than the one you rehearsed there. The JD's own-the-KPIs line (F3) is a third candidate: the material says presented, not owned. Do not name a "weakness" you would not stand behind | The persona stem for the Skeptic; chosen because your own notes name the gaps |
| B4 | "You haven't led a team. The role coordinates design, art, engineering and community on every update. Who decides when they disagree?" | JD | [grounded] "Never led a team" | Concede in the quote's terms: "I haven't led a team." Answer slot: the JD's coordinate line raises a probe on how you worked with each of the four. If you worked with any of them on the drops, say which and how; if you did not, or it was not yours, say so plainly. Then a principle, not a story: the person who owns each trade-off decides it, and your job is to surface it early with the facts | F9 and F2; JD because it asks how you handle the stated requirement |
| B5 | "The JD says three or more years producing live-service games. Yours was as an associate producer on a puzzle title. How do those line up?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Say it in the quote's words and keep "associate producer" as your title. Answer slot: if the puzzle title was operated as a live service, say what that meant in your own work; if not, say so plainly and stay with the weekly drop calendar. Never describe yourself as having produced a live-service game unless that is exactly what you did | F5 and the title step from associate to producer; JD because it scores a stated requirement |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Walk me through which measures were in them." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented, in the quote's words. Answer slot: the JD's retention line makes a probe on the measures and how each was defined likely. If you can name them, do; if you presented figures someone else produced, or you do not know how they were counted, say so plainly and return to the presenting. If you quote any figure, name the assumption behind it you would defend least before you are asked | F7, and the defend-the-number discipline for a metrics-heavy role; EXP because it tests attribution |
| C2 | "The JD has you owning the post-event review and the KPIs it reports. Where is the line between presenting numbers and owning them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold the quote: "I presented the monthly retention numbers to the studio head." Answer slot: if any of those numbers were yours to define or choose, say which; if they were defined elsewhere, say so plainly and say what you would need in order to own them. Hold through two follow-ups by returning to what you presented, and concede the difference in one sentence | F3; EXP because it tests how much was actually yours |
| C3 | "An event produced a retention spike that faded within two weeks. How would you tell whether it was worth repeating?" | CASE | [generic] | Define worth first (retention, effort, side effects), then cohorts against baseline, then what you would need from the team before judging. Think aloud and name what you would not conclude from one event. No claim about your past | F3 and F7 as a live problem |

### D. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc whose beats are the four quotes: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for the main title for the last two years, the release checklist QA still uses, the monthly retention numbers presented to the studio head. Tell it in your own words. Answer slot: why this role and why now is not in your material; say your actual reason, and if it is not yet clear to you, say what you are looking for | The biography question is the most likely opener; EXP because it is your history |
| D2 | "What live-events calendars in other mobile games have caught your eye lately, and why?" | CO | [generic] | Name two you actually follow and what you noticed about their rhythm or how events were spaced. If you do not follow any closely, say so plainly and name what you would study before starting. Do not invent examples | JD-adjacent interest question asked casually; casual questions are still scored |
| D3 | "Clear writing matters in this role. Tell me about something you wrote that other people relied on." | JD | [grounded] "Wrote the release checklist our QA team still uses." | An open prompt answered from the quote: the checklist, written by you, and QA still uses it. Those are the beats; tell them in your own words and let the fact that it is still in use speak. If asked about anything beyond that, answer only what you actually did | F8; JD because the written-communication requirement is a stated one |

### E. Pressure (weight: lower)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has already run live events for two titles and worked on purchases?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Pause and restate. Hold only what the quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years" and "I wrote the release checklist, and our QA team still uses it." Hold through two follow-ups by returning to those. Concede explicitly: "I haven't worked on a game with in-app purchases" and "I haven't led a team." Never fold on the core claim to restore harmony, and never add to it | The persona stem for Pressure; EXP because it tests holding an honest position |
| E2 | "That calendar you ran. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start from the quote's verb: "I ran the weekly content-drop calendar for our main title." Answer slot: this is the attribution probe. If there were calendar decisions you made yourself, say which; if others set the priorities and you scheduled them, say so plainly and return to the calendar you ran. Hold through two follow-ups, concede the specific, never the whole | F1 and F6; EXP because it tests attribution |

### G. Values / Behavioral (weight: lower)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact at the end. The only leadership-facing sentence in your material is the one quoted; it does not say any number was bad news or that anyone pushed back, so use it only if that is true, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona stem for a values probe; no published values were available, so the theme is the stem's |
| G2 | "When have you put players ahead of a schedule or a metric?" | VAL | [generic] | Selection scaffold: pick a time where the players' experience and a date or a number pulled apart, with the decision you made and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona stem adapted to players; generic because no values page was read |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, B2, E2 |
| "coordinate design, art, engineering and community teams on each update" | A2, B4 |
| "own the post-event review and the KPIs it reports" | A4, C2, C3 |
| "manage the release checklist with QA" | A5 |
| "3+ years producing live-service games or apps" | B5, D1 |
| "experience running a content calendar" | B2, E2 |
| "comfortable with player-retention metrics" | A3, C1, C3 |
| "clear written communication" | D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first 90 days look like for this role across the two titles?" | Shows you are planning the ramp, which is the honest answer to your two stated gaps, and gives you concrete targets to react to |
| R2 | "How are events chosen today, and what does the post-event review change afterwards?" | Tells you whether the review is a report or a decision point, which is what the JD's own-the-review line turns on |
| R3 | "Which KPIs does this role report, and who sets the targets?" | Surfaces the defined-versus-presented line from C2 before it becomes a surprise |
| R4 | "On an update, who has the final call on scope when design, art, engineering and community disagree?" | Shows you think about the trade-off structure, not just the schedule |
| R5 | "How do in-app purchases figure in the events today, and what is the best way for someone new to that area to get up to speed?" | Turns the gap you have named into a ramp question and signals you are already planning it |
| R6 | "What has surprised you most about running live events here?" | An open invitation for him to talk, which is the rapport-weighted slot; a prepared closer beats "I think you have covered everything" |

No interviewer profile was available, so none of these is tied to his own career path.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't led a team." No slot |
| Worked on in-app purchases, pricing or monetization | Negative you stated, F10 | The plain acknowledgment F10 gives: "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar, or calendars for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a weekly content-drop calendar for one main title. B2's slot stays inside that calendar |
| Owned the post-event review or the KPIs | Inflated form of F3 | F3's quote at its own scope. The material says presented the numbers, not owned them. C2's slot asks only which were yours to define |
| Managed releases with QA | Inflated form of F4 | F4's quote at its own scope. The material says wrote the checklist and in use; it does not say you ran it on each release |
| Was a producer on a live-service title | Inflated form of F5 | F5's quote at its own scope: associate producer at a puzzle-game studio. B5's slot asks only whether the title was operated as a live service |

## Sources

Provided documents: the JD text and your background notes. No dossier was present.

Searches sent (every one refused; no pages were fetched):

- `Saltmarsh Games values` — refused
- `Saltmarsh Games interview process live operations producer` — refused
- `Saltmarsh Games mobile studio strategy news` — refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Every call refused. Would have moved the values cheat sheet and the VAL bank; both fall back to persona stems and generic scaffolds |
| 2. `Saltmarsh Games interview process` | unavailable | Every call refused. Would have moved persona weights and the loop; they rest on the hiring-manager prior and a generic archetype |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Every call refused. Would have moved the CO bank and a grounding brief; D2 is generic |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Every call refused. Would have moved the interviewer read and a reverse question tied to his path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search access (refused this run) → values by name, the documented loop, current strategy for a real CO bank, and Tobias's public footprint for an interviewer read and a reverse question tied to his path; a deeper pass would add up to 6 more searches and 2 more fetches and take several more minutes
- Whether Tobias is your future manager, a skip-level or from another function → reweights every bank
- The recruiter's prep email, focus areas or any announced task → coverage of anything pre-declared
- Your answers to the slots in F1, F2, F3, F5 (said outside a drill) → those rows become `[grounded]` on your own words
- A retention slide from one of your monthly presentations, a screenshot of the drop calendar, or the release checklist itself → raise F3, F4, F6 and F7 toward `high`
- Any prior `tuesday-dossier.md` → verified evidence and a named top objection in place of the inferred one
