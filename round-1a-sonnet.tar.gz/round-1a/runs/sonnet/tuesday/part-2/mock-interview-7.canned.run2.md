Searches came back with real material. I'm now reading the values page and the interviewing page in full, then I'll write the pack.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-7-canned-5eefffb5/saltmarsh-games_live-operations-producer_interview_pack.md`.

I built it for the one session Saltmarsh's interviewing page describes. That session is a 60-minute "Outage Hour" with the hiring manager: a live-incident tabletop first, then a values conversation. I assumed Tobias is that hiring manager.

The pack has 22 questions across seven personas. The highest-ROI prep is C2, the season-pass and in-app-purchase question. It rests on Saltmarsh's "Project Larkspur" announcement, which moves both titles to a season pass. I read that page and Tobias's GDC talk only as search snippets, so read both yourself before Friday.

Say the word and I'll run the tabletop as Tobias: A1 first, then C2 with follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, or a skip-level or peer? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. **Relationship assumed:** hiring manager, because the interviewing page says the one session is with the hiring manager. Not confirmed with you.
**Session:** Friday, 60 minutes. The interviewing page describes it as the Outage Hour: a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home. The page gives no split of the hour.
**Candidate:** Femi.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Every line you say about your own past must be one you can stand behind on a second question, so where the pack does not know something about your work it gives you a slot to fill in your own words.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether your past behavior shows Saltmarsh's published values, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge | Whether you have done your homework and can think at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role, delivered live |

Provenance labels: `[grounded]` traces to a document you gave me or to research cited in Sources. `[inferred]` is my derivation, named. `[generic]` is a role-family pattern with no claim about you or Saltmarsh.

## Prep triage

You have Tuesday to Thursday, then the interview. The few things to do well, in order:

| When | Do this | Where |
|---|---|---|
| Today | Rehearse the season-pass and in-app-purchase question aloud until it is boring. It is the pack's highest-ROI prep. Then read the values page, the Project Larkspur page and Tobias's talk yourself: I read only a search snippet of the last two | C2, then C1; Sources |
| Wednesday | Run the outage tabletop aloud, then say the player update out loud with a timer. Then the three values stories | A1, A2, A3, A4; B1, B3, B4 |
| Thursday | Have someone interrupt you through the pressure bank. Know how your retention numbers were counted, or be ready to say you do not know | D1, D2, D3; E1 |
| Friday morning | Say your 90-second arc once. Pick three reverse questions. Add nothing new | F1; reverse questions |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one title, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-titles line makes a probe on events versus drops, and on a second title, likely. If any of the drops were timed events, say so; if there was no second title or no such events, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if any of your weekly drops needed several of those disciplines to land together, say which and what part was yours, in your own words; if the drops were delivered by one team, or the coordination was not yours, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Presenting monthly numbers is adjacent to owning a post-event review, and the words stay at the quote: "I presented the monthly retention numbers to the studio head." Answer slot: if any of those presentations reviewed a particular drop, say which; if they were routine monthly reporting, or the numbers were produced by someone else, say so plainly |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and QA still uses it, not that you managed it each release. Words: "I wrote the release checklist our QA team still uses." Answer slot: if running the checklist on each release was yours, say how; if that was QA's, or there was no such step, say so plainly and return to writing it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | The years and the weekly calendar are on the page. Whether the title was a live-service game is not. Words: "I have four years as an associate producer at a puzzle-game studio." Answer slot: if the main title was a live game that players saw change each week, say how it ran live; if it was not live-service, say so plainly and stay with the years and the calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you ran it, weekly, for the main title, for two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in terms, but nothing inspected behind the line, so expect a probe on how the numbers were counted. Lead with the quote's own terms: monthly, retention numbers, the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote reaches this requirement in other terms: a written document that another team still uses. Reword only that: "I wrote the release checklist our QA team still uses." Say what it is and let the interviewer judge how clear it is |
| F9 | "season-pass model" — Saltmarsh news, Project Larkspur, September 2026 (search snippet) | "never worked on a game with in-app purchases" — your message | none | [inferred] | capability | The posting does not mention monetization. This row exists because the Larkspur announcement moves both titles to a season-pass model, and my reading is that a season pass is bought with in-app purchases. A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team, or managed people | Negative you stated: "Never led a team" — your message | The plain acknowledgment: "I haven't led a team." No slot. The JD says coordinate, not manage, and C3 stays inside that |
| Worked on a game with in-app purchases, or on monetization or a season pass | Negative you stated: "never worked on a game with in-app purchases" (F9) | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Produced a live-service game, or held a producer-level role | Inflated form of F5 | F5's quote at its own scope: "4 years as an associate producer at a puzzle-game studio". The limit is the pack's observation, not words for you: the material says associate producer, and does not say live-service |
| Planned or owned the events calendar across titles | Inflated form of F1 | F1's quote at its own scope. The material says the weekly content-drop calendar for the main title |
| Managed the release process, or signed builds off | Inflated form of F4 | F4's quote at its own scope. The material says you wrote the checklist, not that you managed it each release. A2 and G1 slots stay inside the quote |
| Owned the retention KPIs, or produced the retention analysis | Inflated form of F3 and F7 | The quote at its own scope: you presented the monthly retention numbers. The material does not say who produced them |

## Reading the interviewer

Public professional footprint only, from search snippets; the talk page itself was not read.

| Public fact | Source | What it may mean for the hour | Label |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games | Search result for his name | He sits at the top of the function you would join, which fits the interviewing page's hiring-manager session | [grounded] |
| Previously a QA lead at a console studio | Same result | He may hear your release-checklist answers as someone who has done QA. Keep them to what the quote says, and use the A2 and G1 slots | [grounded] |
| GDC 2026 talk "Patch Notes Are a Promise". His argument: a live team is judged by how often its patch notes describe what actually shipped | Same result | The talk's theme matches the published value "Ship the Patch Not the Promise", so expect care about the difference between what was built and what was hoped. This is my reading of the two together | [inferred] |

Mirror opportunity, a shared professional vocabulary and not a shared jump: his QA background and F4, "Wrote the release checklist our QA team still uses". Use it only if the checklist comes up naturally. Do not build on any shared identity.

## Persona table

| Persona | How it shows up here | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The tabletop on a simulated outage | High. The interviewing page documents a live-incident tabletop in this session, and the hiring-manager prior favors this persona | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| Values / Behavioral | The second part of the hour | High. The same page documents a values conversation, and Saltmarsh publishes three values | Map a story to each value where one of your sentences carries it. Use "we" for context and "I" for what you did |
| Skeptic | Probes on the gaps you stated, and on the season-pass move | Medium-high. The hiring-manager prior includes it, and F9 plus "Never led a team" give it material | Rehearse the single most predictable objection until it is boring. Calibrated candor over bluffing |
| Pressure | Time-boxed decisions inside the tabletop | Medium. A simulated outage is time-boxed by its nature; this is my reading, not a documented format | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| Data-Driven Prober | Your retention numbers; how success is measured | Medium. The JD asks for comfort with retention metrics, and F7 is a number-presenting line with nothing inspected behind it | Know how each number was counted, and say plainly when you do not know |
| Conversational | The opening minutes | Low-medium. An opener is likely; its register is friendly, and it is still scored | A 90-second arc. Never answer "no questions" in the reverse-question slot |
| Peer Evaluator | QA seam and credit questions | Low. One session with the hiring manager has no peer in the room, but his QA background makes a seam probe plausible | Reciprocity framing. Seam principles, not a pretended seam |

Loop basis: the interviewing page establishes one 60-minute session run by the hiring manager, a tabletop then a values conversation. These weights rest on it, not on an archetype.

## Question banks

The highest-ROI prep in the pack is **C2**. The season-pass move is Saltmarsh's current strategy, F9 is a gap you have stated, and the question will arrive in some form.

### A. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a weekend event. Players say they can't claim the event reward and tickets are climbing. The on-call engineer and the community lead are on the line. Walk me through your first fifteen minutes." | CASE | [inferred] scenario written from the interviewing page's "live-incident tabletop", not Saltmarsh's actual scenario | Say what you need to know first: how many players, which platforms, whether it is the reward or the whole event, whether anything is being lost. State the objective. Say who you pull in, in what order, and what you decide now versus wait on. Challenge one premise, such as whether "can't claim" is one fault for everyone. What you tell players is what is known and built, nothing hoped. The question asks about no past, so the guidance makes none | The tabletop is the documented first half of the session, so this is the likeliest shape of the hour. CASE because it is a live problem; JD flavor from F2's requirement |
| A2 | "The calendar says the event goes live at noon. QA says the build isn't signed off, and marketing has already announced it. Decide." | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Clarify what QA's open items are and how serious, and whether any player-facing risk exists. Lay out the options: hold, ship partial, ship with a stated limit. Pick one and name the trigger that would change your mind. Players come before the calendar. Announce only what is built. If you mention your checklist, say it as the quote does: you wrote it and QA still uses it. Answer slot: the JD's manage-the-checklist-with-QA line makes a probe on who calls a build signed off likely. If a sign-off step in your checklist was yours to call, say how it worked; if sign-off was QA's, or there was no such step, say so plainly and return to writing the checklist | F4 is the evidence and the likeliest place to be probed. CASE because a decision is asked for; the values it brushes are published ones |
| A3 | "Both titles want the same weekend for their biggest event, and from February they share one calendar. How do you decide?" | JD | [inferred] scenario from the JD's two-titles line and the Larkspur announcement's shared-calendar line | Clarify what each event is for, what each team can ship, and what each set of players would lose. State your criteria and say the order they apply in. The players come first when the calendar and the players disagree. Say what you tell both teams. If you mention your own calendar, say it as the quote does: one title, weekly content drops, two years. Whether two titles change how that works is for you to ask about, not to assert. The quote: "I ran the weekly content-drop calendar for our main title for the last two years" | F1 is the evidence, and its gap is scope. The question tests the JD's calendar duty against Saltmarsh's announced direction; it carries JD tag with CASE delivery |
| A4 | "You have two minutes. Say aloud the first update you'd post to players about this outage." | JD | [inferred] scenario from the tabletop; requirement from the JD's written-communication line. [grounded] "Wrote the release checklist our QA team still uses" | Plain sentences. What is known, what is being done, what players should do, and when the next update comes, at a time you can keep. Say nothing about a fix time you cannot back. No hopes dressed as plans. If asked about your writing, say what you wrote and who still uses it, as the quote does, and let the interviewer judge how clear it is | F8 is the evidence. JD because it scores the written-communication line, with CASE delivery |
| A5 | "Day three of the event, retention for new players is down against the last event. Diagnose it." | CASE | [generic] | Clarify which measure, which cohort, and compared with what baseline. Segment by platform, source and outage exposure. List hypotheses: the outage, the reward fault, the event's design. Say what data you would ask for and from whom. Say what you would not conclude yet. The question asks about no past, so the guidance makes none | Tests the JD's retention line as a live problem; F7 is the related row. CASE because it is a diagnosis asked for aloud |

### B. Values / Behavioral (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold. Pick a time when what the schedule said and what players needed pulled apart. It needs a named stake, what you did, what happened, and whose call it was. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, that you ran the weekly content-drop calendar for the main title, or say how you would handle it | Published value one: "when the calendar and the players disagree, the players win". F1 carries the calendar, not a disagreement, so this stays a scaffold. VAL because it scores a published value |
| B2 | "Tell me about a time you had to be careful about what you said was shipping." | VAL | [grounded] values page, Sources | Selection scaffold. Pick a time when what you announced was narrower than what people hoped. It needs what you said, what was true, what you did about the gap, and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | Published value two: "we announce what is built, not what is hoped". No quote of yours carries it, hence a scaffold. His talk theme makes it likelier, per the interviewer read |
| B3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4. The beats are the ones the quote states: you wrote the checklist, and QA still uses it. Tell them in your own words. Answer slot: published value three makes a probe on how the checklist changed afterward likely. If it changed after later releases, say what and who changed it; if it did not, or the changes were not yours, say so plainly and return to writing it | Published value three: "every release leaves the codebase and the checklist better than it found them". F4 is the nearest evidence, and its limit is that it says wrote, not improved |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped on F3. The beats are the quote's: monthly, retention numbers, the studio head. Answer slot: if any month's numbers were unwelcome, say what was in them and how you said it; if none were, or it did not go that way, say so plainly and describe how you presented | A standard values probe, aimed at the one line of yours that reaches leadership. F3 limits it: the quote says presented, not that anything landed hard |

### C. Skeptic (weight: medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | The pack's reading, for you to check and not to say: your material does not show coordination across the four teams (F2) or a post-event review (F3). Pick the part you honestly believe, in your own words, and name it before he does. Then say what you did run, as the quote does, and what you would ask first. Calibrated candor beats bluffing a competency the interviewer owns | The JD-wide version of the gap question, so it arrives in some form. JD because it scores the listed job including its gaps |
| C2 | "Saltmarsh is moving both titles to a season-pass model next year. What's your experience with monetized live events?" | CO | [grounded] "never worked on a game with in-app purchases", "I ran the weekly content-drop calendar for our main title for the last two years" | **Deepest rehearsal.** Say the plain acknowledgment first: "I haven't worked on a game with in-app purchases." Then return to what you ran: "I ran the weekly content-drop calendar for our main title for the last two years." Follow-up one, how you would get up to speed: answer as a plan, the first things you would ask and of whom, in your own words. Follow-up two, whether that makes you a risk: hold the calendar sentence, concede the specific, that you would be learning that side on this job, and do not claim that anything you ran was monetized. Do not tell them what your calendar work proves | F9 against Saltmarsh's announced move. The negative has its source in your message. CO because it is the company's current strategy; Skeptic because it presses on the gap |
| C3 | "Tell me about a time you got several teams to ship to one date." | JD | [grounded] "Never led a team", "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold. The theme is the JD's coordinate-four-teams line. Pick a time that needs a named stake, what you coordinated, and what happened. The nearest thing your material carries is the calendar you ran. Answer slot: if any drop needed several disciplines to land together, say which and what part was yours; if the drops were delivered by one team, or you were not the one coordinating, say so plainly. If asked directly about leading: "I haven't led a team." | F2 is the requirement and its gap is silence, not absence. JD because it scores the coordination line |

### D. Pressure (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That calendar. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Pause, restate the question, then hold the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's plan-and-run line makes a probe on who set the plan likely. If the plan was yours, say how; if it was set by others and you ran it, or there was no separate plan, say so plainly. Hold through two follow-ups by returning to the sentence, never by adding to it | F1 and F6 are the evidence. EXP because it tests attribution |
| D2 | "Sixty seconds. The build is bad, the event starts in an hour, and the engineer says maybe. Go or no-go." | CASE | [inferred] scenario from the tabletop | Pause. Ask the one question that decides it, what maybe means for players. Give the decision and the trigger that would change it. Players come first. Say what you would tell them, only what is built. Hold the decision through one push before changing it, and change it only for a new fact. No past is claimed | A time-boxed version of A1 and A2. CASE because it is a decision under pressure |
| D3 | "Sixty seconds. Why you, when we could hire someone who has run a monetized live-ops calendar?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "never worked on a game with in-app purchases" | Anchor in what you said, in this order: four years as an associate producer at a puzzle-game studio, and you ran the weekly content-drop calendar for the main title for two years. Hold that through two follow-ups. Concede the specific: "I haven't worked on a game with in-app purchases." Do not call yourself a producer of a live-service game, and do not say what your work proves | F5 and F9 together. JD because it scores the 3+ years line against a stronger rival |

### E. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped on F7: monthly, retention numbers, the studio head. Answer slots, each in your own words: how the numbers were counted, what they were sensitive to, the assumption you would defend least, and which part of producing them was yours. If an analyst or a tool produced them and you presented them, say so plainly; if you do not know how a number was counted, say that | Retention is a JD requirement and F7 has nothing inspected behind it. You gave no figure, so the pack adds none |
| E2 | "Take me through a post-event review. What goes in it, and what is it for?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Build the structure as method: the question the review answers, the KPIs and why those, what happened against plan, actions with owners, who sees it. If you mention your own, say it as the quote does. Answer slot: the JD's post-event-review line makes a probe on whether you reviewed individual drops likely. If any presentation covered a specific drop, say so; if they were routine monthly reporting, say so plainly | F3 is the evidence and its gap is adjacent, not direct. JD because it scores the own-the-review line |
| E3 | "What would you want to see before you called an event a success?" | JD | [generic] | Name the KPIs you would use and why. Name the one you would trust least and its weakest assumption, before he asks. Say what baseline you would compare against. No past is claimed | The weakest-assumption move, practiced on a question that asks about no history. JD because the JD says to own the KPIs |

### F. Conversational (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head" | A 90-second arc in this order, each beat a clause the quotes state: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title for two years; the release checklist QA still uses; the monthly retention numbers to the studio head. Why live operations and why now is your own reason: say it in your own words, in one sentence. End by handing the conversation back | F5 and F1 are the spine. EXP because it is a walk through the record. A casual opener is still scored |
| F2 | "Why Saltmarsh, and why now?" | CO | [grounded] values page and the Larkspur search snippet, Sources | Your own reason, in your own words; the pack does not supply it. Pick the one published value that matches how you actually work, name it exactly, and say why in a sentence. You may mention Larkspur as something you read, not as inside knowledge. Do not recite the values page | Motivation consistency is scored in this slot. CO because it tests whether you did the homework |

### G. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where does your job end and QA's begin on a release?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Reciprocity: what you bring QA and what you need from them. Offer seam principles, such as who calls a build signed off, who owns what the checklist says and who tells the other teams, and do not pretend to know Saltmarsh's seam. Then say it as the quote does: you wrote the checklist and QA still uses it. Answer slot: the JD's with-QA line makes a probe on who owned what in the checklist likely. If you and QA split it, say how; if it was yours alone, or someone else's now, say so plainly and return to writing it | F4 against his QA background, per the interviewer read. JD because it scores the with-QA line |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold. Pick a time when work crossed teams and credit could have gone to one. It needs what was shared, who named whom, and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | A standard peer probe, and a low-weight one for a session with the hiring manager |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, D1 |
| "coordinate design, art, engineering and community teams on each update" | C3, A1 |
| "own the post-event review and the KPIs it reports" | E2, E3 |
| "manage the release checklist with QA" | A2, G1, B3 |
| "3+ years producing live-service games or apps" | D3, F1 |
| "experience running a content calendar" | D1, A3 |
| "comfortable with player-retention metrics" | E1, A5 |
| "clear written communication" | A4 |

You gave no figures, so no row is a defend-the-number question beyond E1's slots. Peer Evaluator has two questions, Conversational two, and the totals are 22 questions.

## Values cheat sheet

A values-style round is detected: the interviewing page documents a values conversation. The three values are named exactly as the values page names them.

| Value | Working meaning, paraphrased | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold, B1. Pick a time when the schedule and what players needed pulled apart, with a named stake and your own part in it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold, B2. Pick a time when what you announced was narrower than the hope. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses". The beats are the ones the quote states. Whether it improved later is an answer slot, B3 |

## Reverse questions

| # | Question | Why it lands | Basis |
|---|---|---|---|
| R1 | "Your GDC talk argued that patch notes are a promise. After a release, how does the group check that what was announced matches what shipped?" Read the talk first | It is his own argument, and it shows you researched him, not only the company. Ask it only if you have read the talk, since I saw a snippet | Interviewer read; tied to his path |
| R2 | "You came up through QA. What does a release checklist written by a producer need for QA to trust it?" | It turns the checklist question into a peer conversation on ground he knows | Interviewer read; tied to his path |
| R3 | "Project Larkspur moves the titles to one shared calendar and a single live-ops group. Where would this role sit in that group, and does two of our mobile titles still describe the scope in February?" | It asks the question the JD and the announcement jointly raise, without saying either is wrong. It shows homework | Larkspur search snippet |
| R4 | "Which parts of the season-pass move depend most on the events calendar?" | It lets him tell you how much monetization knowledge he expects from this seat, which F9 makes the thing you most need to know | Larkspur search snippet |
| R5 | "What did the last change to the release checklist come from, if there was one?" | It follows the published value about leaving the checklist better, and invites a story instead of a policy | Values page |
| R6 | "What does a strong first ninety days look like, and what would you want me to have shipped by then?" | It asks him to define success in the terms he will score you on | [generic] |

## Sources

**Provided documents:** the job description you pasted; your background as you described it in your message. No dossier was present.

**Searches sent:**
- "Saltmarsh Games values" returned https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games strategy recent news mobile" returned https://saltmarshgames.com/news/project-larkspur
- "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise

**Fetches sent:** https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both returned. The Larkspur page and the talk page were read as search snippets only; neither was fetched. The talk's domain is as the search returned it, and I did not verify it further. Larkspur is dated September 2026; the interviewing page carries no date.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | The values cheat sheet, the VAL bank and R5; three values by name from the official page |
| 2. `Saltmarsh Games interview process` | yes | Loop structure: one 60-minute session with the hiring manager, a tabletop then a values conversation; persona weights follow it |
| 3. `Saltmarsh Games strategy` / recent news | yes | A3, C2, F2, R3 and R4, from the Larkspur snippet; the page itself was not fetched |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read, R1 and R2; one result, a snippet |
| 5. representative `Live Operations Producer` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → the fit snapshot's evidence cells could quote your own CV lines, and several medium rows could rise
- The release checklist, a content-calendar page and a retention deck, or a screenshot of one → the artifacts a producer keeps; they could raise F4, F6 and F7 from medium toward high
- What the weekly drops involved, which teams delivered them and whether the main title was live → upgrades F2 and F5, and the C3 and D1 slots
- How the retention numbers were counted, and who produced them → upgrades F3, F7 and E1
- The recruiter's prep email, including whether the simulated outage has a prepared scenario → sharpens A1 and A2
- Whether Tobias is the person you would report to → reweights every bank
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes. It would read the Larkspur page and the talk in full, and add a strategy brief, so A3, C2, R1 and R3 stop resting on snippets
- A `tuesday-dossier.md` from an earlier role check → verified evidence and sourced prohibited claims, in place of the ones this pack built from your message
